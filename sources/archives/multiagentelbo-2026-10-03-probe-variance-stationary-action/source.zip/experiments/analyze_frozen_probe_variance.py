"""Decompose saved two-probe budget variance without rerunning trajectories."""
from __future__ import annotations

import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import time
import traceback
import zipfile

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PHASE = ROOT / "docs/research/2026-10-02-renormalization-completion"
INPUT = PHASE / "continuous-square-root-evidence"
LIFT = PHASE / "frozen-lift-comparison-evidence"
ARMS = ("candidate", "baseline", "candidate_minus_baseline")
GRIDS = ("coarse", "fine", "fine_minus_coarse")


def analyze(output: Path) -> int:
    r"""Estimate Var(Y)=E[Var(Y|path)]+Var(E[Y|path]) from paired probes."""
    output.mkdir(parents=True, exist_ok=False)
    start = time.perf_counter()
    receipt = {"status": "running", "utc": datetime.now(timezone.utc).isoformat(),
               "python": sys.executable, "numpy": np.__version__, "groups": [],
               "input": str(INPUT), "lift_input": str(LIFT), "checks": 0,
               "scope": "Posthoc variance estimates; negative residuals retained; no confidence bounds."}
    rows = []

    def check(actual: object, expected: object) -> None:
        """Check finite scientific values against an independent expression."""
        a, b = np.asarray(actual), np.asarray(expected)
        if a.shape != b.shape or not (np.isfinite(a).all() and np.isfinite(b).all()):
            raise ValueError("nonfinite values or incompatible shapes")
        if not np.allclose(a, b, atol=1e-10, rtol=1e-11):
            raise ValueError(f"arithmetic mismatch: {a} versus {b}")
        receipt["checks"] += 1

    try:
        with zipfile.ZipFile(output / "source.zip", "x", zipfile.ZIP_DEFLATED) as archive:
            for path in (Path(__file__).resolve(), PHASE / "probe-variance-CONTRACT.md"):
                archive.writestr(path.relative_to(ROOT).as_posix(), path.read_bytes())
        metadata = json.loads((INPUT / "metadata.json").read_text())
        comparison = json.loads((LIFT / "comparison.json").read_text())
        if metadata["status"] != "pass" or comparison["status"] != "pass":
            raise ValueError("both saved analyses must be complete")
        n, horizon = metadata["run"]["n_paths"], metadata["theory"]["horizon"]
        if (n, horizon, metadata["theory"]["n_probes"]) != (16, 1., 2):
            raise ValueError("declared sampling profile differs")
        expected = {f"N{size}-path{index:03d}.npz" for size in (512, 1024) for index in range(n)}
        for folder in (INPUT, LIFT):
            if {p.name for p in folder.glob("N*-path*.npz")} != expected:
                raise ValueError("incomplete saved path inventory")
        for size in (512, 1024):
            samples = {(grid, arm): [] for grid in GRIDS for arm in ARMS}
            for index in range(n):
                filename = f"N{size}-path{index:03d}.npz"
                with np.load(INPUT / filename) as native, np.load(LIFT / filename) as lift:
                    data = {}
                    for grid in ("coarse", "fine"):
                        probes = {"candidate": native[f"{grid}_probe_visible_kl"],
                                  "baseline": lift[f"{grid}_probe_baseline_visible"],
                                  "candidate_minus_baseline": lift[f"{grid}_probe_paired_visible"]}
                        check(probes["candidate"] - probes["baseline"], probes["candidate_minus_baseline"])
                        check(native[f"{grid}_drift_integral"], lift[f"{grid}_candidate_drift_integral"])
                        check(native[f"{grid}_total_integral"], lift[f"{grid}_candidate_total_integral"])
                        for arm in ARMS:
                            drift = float(lift[f"{grid}_{arm}_drift_integral"])
                            g = probes[arm]
                            if g.shape != (2,):
                                raise ValueError("exactly two probes are required")
                            check(horizon * g.mean(), lift[f"{grid}_{arm}_visible_integral"])
                            check(drift + horizon * g.mean(), lift[f"{grid}_{arm}_total_integral"])
                            data[grid, arm] = (drift, g)
                        check(data[grid, "candidate"][0] - data[grid, "baseline"][0],
                              data[grid, "candidate_minus_baseline"][0])
                    for arm in ARMS:
                        d0, g0 = data["coarse", arm]
                        d1, g1 = data["fine", arm]
                        data["fine_minus_coarse", arm] = (d1 - d0, g1 - g0)
                    for (grid, arm), (drift, g) in data.items():
                        total = float(drift + horizon * g.mean())
                        check(total, lift[f"{grid}_{arm}_total_integral"])
                        within = float(horizon**2 * (g[0] - g[1])**2 / 4)
                        check(within, horizon**2 * np.var(g, ddof=1) / 2)
                        samples[grid, arm].append((total, within))
                        rows.append({"n_agents": size, "path_index": index, "grid": grid, "arm": arm,
                                     "drift": drift, "probe_1": float(g[0]), "probe_2": float(g[1]),
                                     "total": total, "estimated_probe_variance": within})
            for (grid, arm), values in samples.items():
                y, v = np.asarray(values).T
                total_variance = float(np.var(y, ddof=1))
                pairwise = sum((float(y[i]) - float(y[j]))**2 for i in range(n) for j in range(i)) / (n * (n - 1))
                check(total_variance, pairwise)
                probe_variance = float(v.mean())
                residual = total_variance - probe_variance
                receipt["groups"].append({"n_agents": size, "grid": grid, "arm": arm, "n_paths": n,
                    "mean": float(y.mean()), "total_variance": total_variance,
                    "estimated_probe_variance": probe_variance, "estimated_path_variance": residual,
                    "total_mean_variance": total_variance / n, "estimated_probe_mean_variance": probe_variance / n,
                    "estimated_path_mean_variance": residual / n,
                    "estimated_probe_fraction": probe_variance / total_variance if total_variance > 0 else None})
        if len(rows) != 288 or len(receipt["groups"]) != 18:
            raise ValueError("incomplete analysis coverage")
        with (output / "paths.csv").open("x", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        receipt["path_group_rows"], receipt["status"] = len(rows), "pass"
    except Exception:
        receipt["status"], receipt["traceback"] = "failed", traceback.format_exc()
    receipt["elapsed_seconds"] = time.perf_counter() - start
    (output / "summary.json").write_text(json.dumps(receipt, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2, allow_nan=False))
    return 0 if receipt["status"] == "pass" else 1


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: analyze_frozen_probe_variance.py NEW_OUTPUT_DIR")
    raise SystemExit(analyze(Path(sys.argv[1]).resolve()))

