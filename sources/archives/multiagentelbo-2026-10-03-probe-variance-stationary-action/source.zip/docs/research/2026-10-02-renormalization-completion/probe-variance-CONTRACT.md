# Saved-probe variance decomposition

October 3, 2026. This posthoc calculation uses all sixteen paths at each of N512 and N1024 in continuous-square-root-evidence/ and frozen-lift-comparison-evidence/, on both grids. No trajectories, Gaussian updates, random probes or model coefficients are generated. The active run_lab.py neighborhood profile is outside this postprocessor and remains unchanged. The question is how much observed across-path variation comes from the two source probes, rather than from the trajectories. Results are descriptive, with one frozen model per size.

Condition on both native/message histories and the proposal-enriched meshes, or on simulation random streams 0 through 3. The two probes use independent uniform times and independent native-prefix uniforms from streams 4 and 5. Probe evaluation does not alter either trajectory or mesh. These are independence assumptions of the declared random-tape model; distinct deterministic PRNG seeds do not prove mathematical independence. Do not additionally condition on the probe times.

For horizon H, let D_i be the drift integral and G_im the visible-source probe, including the exact whole-current-assignment self correction. With M=2, Y_i=D_i+H(G_i1+G_i2)/2. The lift uses exact product-row KL at those same two times, without its own prefix sampling. The grids share probe times and uniforms. For the conditionally iid two probes, the unbiased estimate of conditional probe variance in Y_i is

$$
v_i=H^2(G_{i1}-G_{i2})^2/4.
$$

Across n=16 independent path tapes, report the ordinary sample variance s_Y^2, mean v_bar of v_i, and s_Y^2-v_bar. Their expectations are total variance, mean conditional probe variance, and variance of the conditional mean. The last estimate may be negative; retain its sign without clipping or taking a square root. Divide components by n for sample-mean variance. Report v_bar/s_Y^2 for positive denominator without restricting it to [0,1]; this noisy ratio is not an unbiased fraction or a confidence statement.

Analyze candidate, lift, and candidate-minus-lift on coarse, fine, and paired fine-minus-coarse data, giving eighteen size/grid/arm groups and 288 path/group rows. Difference source probes and drift integrals within each path before computing contrast variance. Two probes combine time and prefix noise and cannot separate them: there is no replicated prefix at fixed time.

Require complete 32-file input inventories and the existing successful study declarations. Reconstruct each saved visible and total integral from drift and probe values. Check paired arm and grid subtraction. Independently compute total sample variance by pairwise differences and within-path variance by the centered two-point sample variance. Preserve raw analysis rows, exact script, this contract, summary and terminal output. Use NumPy float64 on one CPU thread and a new output directory; retain and diagnose a failed invocation before any retry.

This analysis gives no absolute retained-path KL, finite-grid bias bound, confidence interval, optimal probe allocation or recursive formation result. Allocation would additionally require reliable variance estimates and measured trajectory/probe costs. The existing expectation-limit proof does not certify this finite sample or float64. O1 and O4 remain open.

