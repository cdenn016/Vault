<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-2f673c3806f5838530bd025b43174018904da19fe6af74fc8c24ae2e7bcf3e09","target_digest":"2f673c3806f5838530bd025b43174018904da19fe6af74fc8c24ae2e7bcf3e09"} -->
# Finite-rate construction

For every finite L>=2, the declared accelerated-energy nonlinear cyclic family with source proposal rate one has L actual formations, actual recognition and hidden-kernel changes, exact marked parents, and vanishing conditional, score, continuous-path and full assignment-history errors.

See proofs/finite-rate-adaptive-completion.md for the exact preparation, parameters, rates, distinctions and proof interfaces. The release record states whether independent reconstruction is complete.
