# Finite-depth nonlinear cyclic formation with moving source assignments

September 13, 2026. Joined construction for the [frozen positive-mobility target](evidence/2026-09-13-finite-rate-adaptive-cyclic-rg/problem-contract.json), digest `2f673c3806f5838530bd025b43174018904da19fe6af74fc8c24ae2e7bcf3e09`. This continues the [finite-rate source investigation](finite-rate-source-dynamics-investigation.md) and its [reconstruction](finite-rate-source-dynamics-check.md). The prior [nonlinear completion](nonlinear-adaptive-attention-completion.md) keeps its original fixed-assignment scope. The separate reconstruction checks the new proof and its full assignment-history coupling under the accelerated-energy admission.

## Statement and material assumptions

For every prescribed finite depth $L\ge2$, the normalized triangle-chain family has a nonempty positive-temperature regime and a specified neighborhood of positive smooth correlated initial laws with the following properties. Its inference realization has unit continuous mobility, microscopic source-assignment proposal rate one, and complete own-law generative-parameter natural-gradient learning. It undergoes $L$ actual successive coalescence episodes. Each exact normalized parent retains every loop, every source assignment and the complete conditional physical, optimizing, evaluator and occupancy marks. Each independently evolving parent activates from the full actual retained joint law and actual parameter. On one horizon $H_*=2/\epsilon$, an actual binary recognition-source row changes by total variation greater than $1/2$, while both first hidden physical and optimizing conditionals change by KL greater than $1/200$. Discarded-conditional KL and complete same-state score errors vanish at active reductions. Separate couplings control independently evolved continuous paths in the uniform norm scaled by their preparation amplitude and control the entire assignment histories in probability.

The carrier stays at one base point $c_*$ inside the declared local-section model. It has independent dynamic translation links and retained network holonomy. No base path, spatial transport or connection descent is used. The calibrated prior-learning model, compatible root observation, internal-neighbor source support, finite prescribed depth, prepared small normal amplitude and supplied energy contrasts are assumptions. The nonlinear coefficient $\delta=10^{-4}/n$ remains fixed and positive in standardized thermal coordinates. The kinetics are a declared VFE-descending inference realization; VFE alone does not uniquely select them or a physical clock.

The additional positive-rate separation is

\[
Q_L=8,\qquad Q_s=2Q_{s+1}+20,\qquad J_s=\epsilon^{-Q_s},\qquad
A^2=\epsilon^{3Q_1+20},\qquad T=A^2\epsilon^6.
\tag{P1}
\]

Thus even the weakest continuous energy grows, $J_L=\epsilon^{-8}$. This proves an admitted accelerated-energy family. It does not prove the same conclusion for the earlier normalization $J_L=1$. Source mobility remains one. Factoring out the common multiplier $\epsilon^{-8}$ produces a weakest-one comparison family with contrast recursion $q_s=2q_{s+1}+28$; it is not literally the old $+20$ contrast family with one added multiplier. The preparation is the common strict-margin normal center $Av_0$, Gaussian covariance $T\widehat K_1^{-1}$, zero loop center, independent equilibrium root and positive assignment masses near the initial product prior, enlarged by the explicitly bounded smooth label-dependent transport perturbations in [D1](finite-rate-coupled-formation.md). No Gaussian law is imposed after initialization.

## Proof assembly

The exact normalized model is [E1–E10 and E24–E29](nonlinear-endpoint-attention-model.md), evaluated at P1. [D1–D4](finite-rate-coupled-formation.md) verify positivity of its corrected physical prior, the exact marginalized sheet potential and every term of its full covector and inherited metric. The optimizer-conditioned parent proposal row is $R^p_{jk}(y,a)=E_{\Pi_a}[b_k(X,a)\mid P_pX=y,J=j]$. S9–S11 prove detailed balance and exact composition under another retention. This row generally differs from a regenerated heat bath on the coarse posterior. Static physical, optimizing and actual laws compose exactly through their fixed channels, with their own separate kernels and complete conditional marks.

[D5–D10](finite-rate-coupled-formation.md) construct the law-dependent learner locally and close its moment and parameter bounds without assuming conditional equilibration. The bounded source force estimate holds for arbitrary adapted assignment paths. Jumps do not move continuous coordinates. On every active level the full energy moment is at most $C_L[A^2J_{p+1}+T\log^2(1/\epsilon)]$; loop energy is $O_L(T)$. These bounds force the complete parameter velocity inward at $a=1$ and $a=2.1$ and imply $|\dot a|\le C_L\epsilon$. Every actual own-law parameter lies within $C_Lr_\epsilon$ of the reference $2-e^{-\epsilon t}$, where $r_\epsilon=A^2J_1+T\log^2(1/\epsilon)$. The reference is used for a bound, not supplied as the learner's schedule.

[F8–F17](finite-rate-conditional-entropy.md) derive two estimates needed when label masses change. Jumps can create discarded-conditional entropy, but their contribution is at most $\log|\mathcal J|+2B_0$, with no lower bound on actual label masses. The full differential/counting entropy has a quantitative floor, including the jump contribution. The actual projection entropy and energy then yield the activation budget F22. This budget applies to the full actual joint law, so subsequent reductions need no source-kernel reset.

[F26–F33](finite-rate-conditional-entropy.md) combine hidden logarithmic-Sobolev coercivity, the restricted source-support mixed derivative bound, moving-model score control, actual full relative-Fisher budget and the new jump contribution. At successive interface $s-1\to s$, after $\kappa_L\log(1/\epsilon)/J_s$ beyond activation,

\[
\Delta_{s-1:s}^{\rm discarded}=O_L(\epsilon^8),\qquad
|g_{s-1}(q,a)-g_s(C_sq,a)|=O_L(T\epsilon^4).
\tag{P2}
\]

The auxiliary entropy argument integrates the loop block only to obtain a bound. The true parent retains that block; the conditional KL chain rule transfers the bound to its actual discarded coordinates. P2 is a same-state score comparison, distinct from the independently evolving law comparison below.

The weighted flag geometry and strict residual margins give the disjoint formation windows [D11–D13](finite-rate-coupled-formation.md): $I_s=[t_s,2t_s]$, $t_s=k_L\log(1/\epsilon)/J_s$, with actual activation at $\tau_s=2t_s$. Choose $k_L\ge2\kappa_L$ and large enough for the geometric exponential decays. Then $t_s-\tau_{s-1}\ge t_s/2$ makes P2 valid throughout each window. On $I_s$ all formed residuals are below a fixed small multiple of $A$ and all future bridges remain above a fixed positive multiple of $A$. The exceptional probability tends to zero exponentially in $\epsilon^{-6}$ up to the horizon factor. Final coherence persists through $H_*$. The counts are $3\cdot2^{L-1}\to2^{L-1}\to\cdots\to1$. For $L=2$, two triangles and their bridge give $6\to2\to1$ agents and $19\to9\to8$ coordinates, retaining two loops and all sixty-four source assignments; $J_1=\epsilon^{-36}$, $J_2=\epsilon^{-8}$, $A=\epsilon^{64}$ and $T=\epsilon^{134}$.

The actual recognition-source movement follows S5–S7 now that D10 proves $a\ge7/4$ over the last ten units of the horizon. Averaging the microscopic source envelope inside an exact parent preserves that envelope, so the argument covers parents and actual lineages too. The first physical and optimizing hidden-condition changes follow the uniform bounded-tilt affinity inequality E23 after the corrected precision comparison in D1. The source deformation and its hidden non-Gaussianity remain fixed in standardized coordinates. Formation occurs early in P1, before most of the order-one recognition-row change; this construction does not assert that source learning creates the supplied hierarchy.

[D14–D15](finite-rate-coupled-formation.md) give an $O_L(A\epsilon^2)$ continuous-path coupling outside probability $C_L(1+H_*)e^{-c_L/\epsilon^2}$. They compare exact independently learning parents, with every actual initialization error included. Their proof tolerates different assignment histories because the force bound is uniform in the assignment. Thus it remains valid under the history coupling from the [source-history component](finite-rate-source-history-averaging.md), by a union bound on the correct marginal Gaussian maximum events. The independent root can be coupled identically.

That source-history proof uses a common rate-one proposal grid and a common averaged row
$B_{jk}(a)=E_{\Pi_a}[b_k(X,a)\mid J=j]$.
Exact optimizer-conditioned rate composition gives the same row for the fine process and every parent, after integrating their nonroot coordinates. Uniform fast sheet mixing, moving-target entropy control and a telescoping bound on the proposal-history kernels give, with $h=k\log(1/\epsilon)/J_L$ and finite $k$ sufficiently large,

\[
\Pr\{J_{[\tau,H_*]}\ne\overline J_{[\tau,H_*]}\}
\le C_L[\epsilon^7\log(1/\epsilon)+r_\epsilon/\epsilon]\longrightarrow0.
\tag{P3}
\]

This concerns complete assignment histories, including their jump times, via the common proposal grid. Close proposal pairs and events near actual deterministic activations are included in the error. No source state is refreshed at an activation. P3 does not follow from a one-time generator bound, and it does not assert convergence in total variation of continuous path laws.

## Scope of the conclusion

The construction meets the finite-family existence target under P1, the specified preparation and the declared inference kinetics. It establishes exact normalization and marked channel composition, quantitative conditional and complete-score approximation, actual finite-depth formation, and separate continuous and discrete history approximations. These are different mathematical statements and should not be collapsed into exact temporal lumpability.

The original $J_L=1$, $\nu=1$ regime remains open: the present conditional estimate leaves an order-one upper bound there, and the present averaging proof needs growing weakest sheet curvature. That observation is not a lower bound or a nonexistence result. Generic mixed-level source support, unsupplied contrast formation, arbitrary nonlinear deformation, infinite depth, resource savings and a physical clock also remain outside the theorem. Base transport stays deferred by the current pointwise scope gate.

The [independent reconstruction](finite-rate-independent-reconstruction.md) and [evidence record](evidence/2026-09-13-finite-rate-adaptive-cyclic-rg/final-report.md) record the final disposition. Document structure and source bindings cannot certify the mathematics; the written derivations and reconstruction are the mathematical evidence. No numerical trajectory, training run, GPU computation, Lean proof or prohibited tamper check is part of this result.
