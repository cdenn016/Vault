"""Freeze the positive-source-mobility continuation before certification."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

RUN = Path(__file__).resolve().parent
SCHEMA = "rigorous-theory-search/v1"

target = {
    "statement": "Construct finite-depth nonlinear adaptive cyclic RG with fixed positive source-assignment jump mobility, actual recognition-source change, full actual-law parent activation, and vanishing conditional, complete-score, continuous-path and source-history errors on one learning horizon.",
    "kind": "MATHEMATICAL",
    "quantifier_class": "MIXED",
    "quantifiers": "For every prescribed finite L>=2, exhibit a nonempty family and initial-law neighborhood within the normalized triangle-chain source model with fixed delta=B0/n>0 and microscopic source update rate nu=1, and an explicit positive-temperature energy-contrast regime as epsilon tends to zero. On H=2/epsilon, prove L actual successive coalescence episodes, exact normalized marked parents that retain every loop and assignment, activation from the complete actual preceding retained joint law, and well-posed model learning from each process's own full covector and inherited metric. An actual binary recognition-source row changes by TV>1/2 on the horizon, and a first hidden physical and optimizing conditional each changes by KL>1/200. At active reductions the actual discarded conditional KL and complete same-state model-score error tend to zero; independently evolving retained continuous paths have error o(A) outside a vanishing exceptional probability, and complete source-assignment histories admit a coupling whose disagreement probability tends to zero. Exhibit the two-level carrier and one simultaneous regime. Constants and preparation neighborhoods may depend on finite L.",
    "domains": ["One fixed base point c_* in the declared principal/associated-bundle local-section model.", "The finite triangle-chain Euclidean belief/model/link carrier times the full finite source-assignment set; independent dynamic links and retained loop coordinates.", "Smooth positive correlated joint recognition laws with explicitly controlled initial moments and entropy, and a regular positive generative parameter a."],
    "codomains": ["Exact normalized physical, optimizing and actual marked parent laws and inherited rates, scores and metrics.", "Quantitative conditional entropy and score bounds, actual recognition-source movement, successive formation, continuous-path approximation and source-history couplings."],
    "regularity": "Construct positive normalized laws and nonexplosive coupled diffusion/jump/parameter dynamics; justify all conditional densities, integrals, derivatives and entropy balances. Do not assume the desired continuation, attraction, mixing, or temporal closure.",
    "measures": ["Lebesgue measure in the Euclidean coordinates and counting measure on the complete finite source-assignment set.", "The normalized prior, evaluator/observation joint, optimizer and restricted-objective scalar are those of nonlinear-endpoint-attention-model.md E24-E29; keep them distinct.", "All actual retained labels, occupancies, loop marks and physical/optimizing kernels are pushed through the same fixed normalized channels."],
    "boundary_conditions": ["Global Euclidean carriers, positive temperatures, confining quadratic cores and proved decay/integrability; no omitted boundary currents."],
    "symmetries": ["Passive presentation changes push laws, coordinates, kernels and metrics together; retain independent network holonomy at c_*.", "No base-manifold transport, full noncompact Haar invariance or physical-time identification."],
    "equivalence": "Static common-channel laws and optimizer-conditioned jump-rate composition are exact at a fixed parameter. Independent parent continuous paths are only close in an explicitly stated scaled uniform metric. Source-history comparison concerns entire finite-horizon assignment histories under a coupling; it does not assert total variation convergence of continuous path laws or exact Markov lumpability.",
    "premises": ["Keep the normalized model and source likelihood family from the completed nonlinear construction, including compatible root observation, proper correlated prior and calibration-assisted learning.", "Use the positive-rate full-assignment heat bath S2 with nu=1 microscopically, and exact optimizer-conditioned parent rates S9-S11; never regenerate a parent heat bath or reset labels at activation.", "Microscopic energy strengths and amplitude/temperature may be chosen in an explicitly displayed common regime. Both the previous weakest-strength normalization J_L=1 and a separately labeled uniformly accelerated energy family are admissible approaches; the latter is an additional scale-separation assumption, not a conclusion about J_L=1.", "The nonlinear coefficient delta=B0/n is fixed and positive for fixed finite L. No limit sending source mobility to zero, no new level-dependent kinetic multiplier, and no instantaneous source equilibrium imposed on actual recognition.", "Supplied energy contrasts, finite depth and shrinking initial-law neighborhoods are permitted; every further preparation restriction must be explicit and nonempty."],
    "modeling_postulates": ["The diffusion, bounded-rate source jumps, and exact-law generative-parameter natural gradient are a declared inference realization, not a unique kinetic law selected by VFE alone."],
    "search_priors": [],
    "permitted_theorems": ["Existing normalized source and common-channel identities with their exact assumptions.", "Published nonlinear geometry, conditional and formation estimates only after proving their interfaces for varying source assignments.", "S1-S13 and their separate reconstruction at the precisely stated conditional scope.", "Primary-source logarithmic-Sobolev, entropy, diffusion/jump, averaging and measure-disintegration theorems with explicit hypothesis mapping; direct derivations may replace citations."],
    "negative_certificate_kind": "NONEXISTENCE_PROOF",
    "falsification_criterion": "Refutation requires a nonexistence proof covering the admitted family and the universal-in-finite-depth existence target. Failure of the original J_L=1 scaling, a proposed estimate or a particular averaging argument is a scoped obstruction, not target refutation.",
    "literature_policy": "Consult the live Research wiki, manuscripts and linked existing derivations before new research. Search primary English sources only for named mathematical dependencies, accessed September 2026. No exhaustive-search or priority claim; retire repeated mechanisms that gain no new proved interface."
}
digest = hashlib.sha256(json.dumps(target, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
meta = {"schema_version": SCHEMA, "contract_id": "contract-sha256-" + digest, "target_digest": digest}
for path in RUN.glob("*.json"):
    data = json.loads(path.read_text(encoding="utf-8"))
    data.update(meta)
    if path.name == "problem-contract.json":
        data["target"] = target
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
header = "<!-- rigorous-theory-search-metadata " + json.dumps(meta, sort_keys=True, separators=(",", ":")) + " -->"
for path in RUN.glob("*.md"):
    body = path.read_text(encoding="utf-8").split("\n", 1)[1]
    path.write_text(header + "\n" + body, encoding="utf-8")
print(json.dumps(meta))
