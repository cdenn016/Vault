"""Record the written finite-rate proof and its separately reviewed disposition."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


RUN = Path(__file__).resolve().parent
FRONTIER = RUN.parent.parent
CONTRACT = json.loads((RUN / "problem-contract.json").read_text(encoding="utf-8"))
META = {k: CONTRACT[k] for k in ("schema_version", "contract_id", "target_digest")}
HEADER = "<!-- rigorous-theory-search-metadata " + json.dumps(META, separators=(",", ":")) + " -->\n"


def digest(path: Path) -> str:
    """Identify retained bytes without treating their hash as mathematical evidence."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(name: str, data: dict) -> None:
    """Write a target-bound structural record."""
    (RUN / name).write_text(json.dumps(META | data, indent=2) + "\n", encoding="utf-8")


def narrative(name: str, text: str) -> None:
    """Write a narrative with the frozen metadata."""
    (RUN / name).write_text(HEADER + text + "\n", encoding="utf-8")


def main(release: bool) -> None:
    """Bind current derivations; --release records a completed separate reconstruction."""
    sources = {
        "model": "nonlinear-endpoint-attention-model.md",
        "rates": "finite-rate-source-dynamics-investigation.md",
        "rate-check": "finite-rate-source-dynamics-check.md",
        "geometry": "nonlinear-cyclic-formation-route.md",
        "conditional-geometry": "nonlinear-adaptive-conditional-route.md",
        "coupled": "finite-rate-coupled-formation.md",
        "conditional": "finite-rate-conditional-entropy.md",
        "history": "finite-rate-source-history-averaging.md",
        "joined": "finite-rate-adaptive-completion.md",
        "reconstruction": "finite-rate-independent-reconstruction.md",
    }
    if release and any(not (FRONTIER / name).exists() for name in sources.values()):
        raise RuntimeError("The full construction and separate reconstruction are required.")
    assumptions = [
        {"id": "A1", "kind": "MODELING_POSTULATE", "statement": "Fixed c_*, prescribed finite L>=2, triangle chain, independent links, complete retained loops and source assignments, compatible root observation and normalized evaluator/source/calibration model E1-E10."},
        {"id": "A2", "kind": "MODELING_POSTULATE", "statement": "Fixed delta=10^-4/n, internal-neighbor source support, supplied energies J_s=epsilon^-Q_s with Q_L=8 and Q_s=2Q_(s+1)+20, A^2=epsilon^(3Q_1+20), T=A^2 epsilon^6."},
        {"id": "A3", "kind": "MODELING_POSTULATE", "statement": "Unit continuous mobility, microscopic full-assignment Poisson proposal rate one, exact optimizer-conditioned parent rows, complete own-law natural-gradient covector and inherited microscopic model metric."},
        {"id": "A4", "kind": "MODELING_POSTULATE", "statement": "Common strict-margin initial normal center, independent equilibrium root, positive source masses near the initial prior, and the explicitly bounded smooth label-dependent transport preparation neighborhood in D1."},
        {"id": "A5", "kind": "MODELING_POSTULATE", "statement": "Nested orthogonal marked retentions and actual-law activation at D13; no source reset, new kinetic multiplier, physical clock or base transport."},
    ]
    proof_dir = RUN / "proofs"
    proof_dir.mkdir(exist_ok=True)
    evidence, bindings = [], []
    for key, name in sources.items():
        source = FRONTIER / name
        if not source.exists():
            continue
        snapshot = proof_dir / name
        snapshot.write_bytes(source.read_bytes())
        evidence.append({"id": "proof-" + key, "kind": "DERIVATION", "supports": True,
                         "scope": "Written derivation at its explicitly stated scope in " + name,
                         "side_conditions": [a["statement"] for a in assumptions],
                         "artifact_path": "proofs/" + name, "artifact_sha256": digest(snapshot)})
        bindings.append({"source": name, "snapshot": "proofs/" + name, "sha256": digest(source)})
    specs = [
        ("c1", "Exact normalized marked parent laws inherit reversible optimizer-conditioned proposal rows with conservative rate at most one and exact nested composition.", ["model", "rates", "rate-check", "coupled"], "Every finite admitted retention and positive parameter.", "An incorrect normalization, regenerated heat bath or omitted conditional mark refutes the identity."),
        ("c2", "The coupled fine and own-law parent processes exist uniquely on 2/epsilon, remain in [1,2.1], and satisfy the displayed energy, model-speed and O_L(r_epsilon) parameter bounds.", ["coupled"], "Every initial law in D1 for sufficiently small epsilon at each finite L.", "An unproved law-dependence step, circular moment estimate or parameter exit refutes continuation."),
        ("c3", "Actual marked activation has the stated entropy budget and each active discarded conditional has KL O_L(epsilon^8), with complete same-state covector discrepancy O_L(T epsilon^4).", ["conditional", "conditional-geometry", "coupled"], "Every finite successive interface after its stated entrance wait.", "A missing source entropy term, actual-mass floor or reset at activation refutes the bound."),
        ("c4", "The finite cyclic family has L actual successive coalescence episodes with separated future bridges and all loops retained, including the explicit 6-to-2-to-1 carrier.", ["geometry", "coupled", "joined"], "For every finite L>=2 on D13, outside the stated vanishing exceptional probability.", "Failure of a strict residual margin, a conflicting entrance wait or an unproved actual initial-law transfer refutes formation."),
        ("c5", "Actual learning changes one binary recognition-source row by TV>1/2 and each first hidden physical and optimizing conditional by KL>1/200.", ["model", "rates", "coupled"], "Between initialization and 2/epsilon, uniformly over retained inputs for the kernel statement.", "A borrowed coefficient schedule, stationary actual source mass or invalid precision comparison refutes the changes."),
        ("c6", "Complete fine and exact-parent assignment histories admit the displayed vanishing-mismatch coupling under the fixed rate-one kinetics.", ["history", "coupled", "rates", "joined"], "On the full horizon after each actual activation and every finite replacement lineage.", "A same-time-only rate comparison, wrong averaged row or hidden history conditioning invalidates the proof."),
        ("c7", "Independently evolving exact parents have continuous-path error O_L(A epsilon^2) under a coupling compatible with the assignment-history comparison.", ["coupled", "history", "joined"], "Uniformly from actual activation through 2/epsilon, outside the displayed vanishing exceptional probability.", "Incompatible initial coupling, incorrect marginal reference law or a largest-stiffness exponential refutes the bound."),
    ]
    existing = {e["id"] for e in evidence}
    claims = []
    for key, statement, proofs, quantifiers, falsifier in specs:
        ids = ["proof-" + p for p in proofs if "proof-" + p in existing]
        if release:
            ids.append("proof-reconstruction")
        claims.append({"id": key, "statement": statement, "quantifiers": quantifiers,
                       "kind": "MATHEMATICAL", "target_digest": META["target_digest"],
                       "state": "EVIDENCE_VERIFIED" if release else "CANDIDATE",
                       "assumption_ids": [a["id"] for a in assumptions], "evidence_ids": ids,
                       "bridge_premise_ids": [], "falsifier": falsifier})
    target = CONTRACT["target"]
    claims.append({"id": "target", **{k: target[k] for k in ("statement", "quantifiers", "kind")},
                   "target_digest": META["target_digest"], "state": "EVIDENCE_VERIFIED" if release else "CANDIDATE",
                   "assumption_ids": [a["id"] for a in assumptions], "evidence_ids": ["proof-joined"] + (["proof-reconstruction"] if release else []),
                   "bridge_premise_ids": [], "falsifier": target["falsification_criterion"]})
    record("claim-ledger.json", {"assumptions": assumptions, "evidence": evidence, "claims": claims})
    deps = {"target": [s[0] for s in specs], "c2": ["c1"], "c3": ["c1", "c2"], "c4": ["c2", "c3"], "c5": ["c1", "c2"], "c6": ["c1", "c2"], "c7": ["c2", "c4", "c6"]}
    record("dependency-dag.json", {"edges": [{"from": a, "to": b} for a, bs in deps.items() for b in bs]})
    ids = [c["id"] for c in claims]
    families = []
    for key, mechanism, gap, disposition in [
        ("FR-ACCELERATED", "Uniformly fast continuous sheets with exact marked Poisson rows; full proposal-history averaging and jump-aware entropy.", "Independent joined reconstruction pending." if not release else "", "completed within admitted scope" if release else "under reconstruction"),
        ("FR-WEAKEST-ONE", "Original weakest-energy normalization J_L=1 with positive source mobility.", "Current terminal conditional upper bound and proposal-history averaging do not vanish; no nonexistence proof.", "unresolved normalization"),
        ("FR-CONSTANT-ROW", "Constrained categorical Fisher flow with a constant recognition row.", "Actual marked activation need not preserve the constrained recognition family.", "retained scoped alternative"),
    ]:
        families.append({"family_id": key, "core_mechanism": mechanism, "target_obligation_ids": ids,
                         "representation": "Finite marked law/link carriers at c_*.", "invariant_or_obstruction": gap or "Exact channels, uniform fast-sheet coercivity and full history control.",
                         "obligations": [c["statement"] for c in claims], "bridge": "Explicit interfaces in the component derivations; no substitution of equilibrium for actual recognition.",
                         "failure_test": target["falsification_criterion"], "verified_results": ids if release and key == "FR-ACCELERATED" else [],
                         "open_gaps": [gap] if gap else [], "novelty_fingerprint": "Continuation of existing source and cyclic-formation construction; priority unassessed.", "disposition": disposition})
    record("approach-registry.json", {"mechanism_families": families})
    if release:
        ref = {"artifact_path": "proofs/" + sources["reconstruction"], "artifact_sha256": digest(FRONTIER / sources["reconstruction"])}
        attacks = [("rates", ["c1"], "Regenerating a coarse heat bath changes the rates.", "Reconstruct D3 and S9-S12; use only optimizer-conditioned rows."),
                   ("continuation", ["c2"], "Assumed slow learning or equilibrium moments could make the proof circular.", "D5-D10 construct the local coupled process and prove the moment and inward-velocity bounds before invoking mixing."),
                   ("entropy", ["c3"], "Source jumps can increase hidden conditional KL and label masses are not fixed.", "F8 and F12 include both contributions; F17-F33 use the actual projected law."),
                   ("preparation", ["c4", "c7"], "Independent order-A sheet centers would violate the thermal matrix-moment input.", "D1 uses a common center with small label-dependent transport perturbations; D13 includes the required conditional waits."),
                   ("movement", ["c5"], "A changing model posterior need not imply actual source mass movement.", "S5-S7 plus the proved D10 interval establish actual recognition movement; E23 is a separate uniform kernel discriminator."),
                   ("histories", ["c6", "c7"], "Instantaneous generator bounds do not control conditional history kernels or guarantee a compatible path coupling.", "Reconstruct the common Poisson-grid history kernels and marginal-reference augmentation, with bad gaps and activations included."),
                   ("scope", ["target", "c4", "c6"], "Accelerating all continuous energies might be confused with the original J_L=1 theorem or with vanishing source mobility.", "P1 keeps nu=1 and expressly declares growing weakest energy; all finite-depth quantifiers and the explicit two-level carrier are checked." )]
        record("adversarial-report.json", {"attacks": [{"id": k, "claim_ids": cs, "attack": a, "response": r, "disposition": "REJECTED", **ref} for k, cs, a, r in attacks],
              "independent_reconstruction": {"claim_ids": ids, "method": "Separate nonauthor reconstruction of the frozen contract, current component equations and all joins; shared source context is acknowledged.", "result": "PASS", "conclusion": "Written proof supports the admitted accelerated finite-depth target.", **ref},
              "oracle_erasure": {"claim_ids": ids, "method": "Check each dependency and explicit assumption after removing favorable expectations; inspect semantic circularity rather than only literal prior tokens.", "result": "PASS", "conclusion": "The proof uses the declared energy/preparation/kinetic assumptions and derived estimates; no affirmative search prior is needed.", **ref}})
    strongest = "For every finite L>=2, the declared accelerated-energy nonlinear cyclic family with source proposal rate one has L actual formations, actual recognition and hidden-kernel changes, exact marked parents, and vanishing conditional, score, continuous-path and full assignment-history errors."
    record("release.json", {"checkpoint": "separately reconstructed" if release else "joined proof under reconstruction", "target_claim": "target", "terminal_status": "COMPLETE_AFFIRMATIVE" if release else None, "certificate_claim": "target" if release else None, "strongest_result": strongest if release else "Candidate joined proof written; separate reconstruction pending.", "unresolved_obligations": [] if release else ["Full source-history proof and independent joined reconstruction."]})
    narrative("construction-or-strongest-theorem.md", "# Finite-rate construction\n\n" + strongest + "\n\nSee proofs/finite-rate-adaptive-completion.md for the exact preparation, parameters, rates, distinctions and proof interfaces. The release record states whether independent reconstruction is complete.")
    narrative("counterexample-register.md", "# Route failures and corrections\n\nS12 disproves coarse heat-bath regeneration. Conditional F35 proves that heat-bath descent can create conditional KL from zero. A same-time rate estimate cannot be substituted for full source-history averaging. The common-center correction in D1 prevents order-A between-sheet spread from entering a thermal covariance estimate. The J_L=1 route remains unresolved: a nonvanishing upper-bound term is not a lower bound or a nonexistence certificate. None of these points refutes the admitted accelerated-energy target.")
    disposition = "COMPLETE_AFFIRMATIVE." if release else "Checkpoint only; no terminal status."
    open_target = "None inside the frozen accelerated-energy target." if release else "Independent full reconstruction remains pending."
    narrative("final-report.md", f"""# Rigorous theory search report

## Frozen contract

{META['target_digest']}. {target['quantifiers']}

## Terminal status

{disposition}

## Certificate

Target claim `target`, with dependency claims c1-c7 and assumptions A1-A5, is supported by the current joined derivation and its component proofs. The exact statement and nonempty initial-law neighborhood are in proofs/finite-rate-adaptive-completion.md and proofs/finite-rate-coupled-formation.md. Source history, conditional entropy and the separate reconstruction are retained alongside them. The quantifier is existence for every prescribed finite L>=2 within the admitted accelerated-energy family.

## Strongest verified result

{strongest if release else 'The written construction is a candidate until the separate reconstruction is recorded.'}

## Dependency closure

The seven component claims concern exact normalized inherited rows, coupled continuation, actual conditional entropy and score, successive formation, actual source and kernel changes, full source histories, and compatible continuous paths. The dependency DAG records their order; continuation is established before conditional mixing is invoked. Current source snapshots and direct derivations bind the mathematical claims.

## Independent reconstruction

The separate nonauthor reconstruction examines the frozen contract and every component interface. Shared prior source continuity is acknowledged; no blind-review claim is made. Its written arguments, rather than investigator agreement, are the evidence. Structural validation checks schema, links, source bindings and closure structure only.

## Oracle erasure

There is no affirmative search prior in the contract. Inspecting the model admissions and proof steps after removing favorable expectations leaves the explicit energy and preparation assumptions and the derived continuation, entropy and mixing bounds. Growing weakest energy is an admitted restriction, not a disguised conclusion about the original J_L=1 family. The bound reconstruction records the semantic check across all dependencies.

## Unresolved obligations

{open_target} The original J_L=1 normalization, arbitrary mixed-level source support, learned creation of supplied contrasts, infinite depth and resource advantage remain outside the proved scope. Failure of the present global-mixing estimate at J_L=1 is not a nonexistence proof.

## Scope and limitations

The result is an analytical construction under declared modeling postulates. Fixed delta, unit continuous mobility and fixed positive source mobility are retained. Weakest energy grows as epsilon^-8, and formation precedes most source learning. Exact marked probability composition is distinct from continuous-path and assignment-history approximation. No operational resource advantage, physical clock, universal kinetics or base transport is inferred. There is no numerical trajectory or production implementation result. No Lean, GPU job, full suite, heavy replay or prohibited tamper check ran; tamper checks are user-excluded/not run.
""")
    record("document-bindings.json", {"proof_bindings": bindings, "scope": "Read-only source/snapshot identity; diagnostic provenance, not mathematical certification."})
    print(json.dumps({"claims": len(claims), "snapshots": len(bindings), "release": release}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", action="store_true")
    main(parser.parse_args().release)
