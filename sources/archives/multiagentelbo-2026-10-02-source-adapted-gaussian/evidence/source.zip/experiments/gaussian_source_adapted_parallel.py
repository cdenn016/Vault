"""Continue only missing paths from an explicitly prepared serial checkpoint."""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys

WORKERS = 4
OUTPUT_ROOT = str(Path(__file__).resolve().parents[1]/"artifacts/gaussian-source-adapted-continuation")


def main() -> int:
    """Run isolated single-thread CPU children from the named checkpoint."""
    if len(sys.argv) != 2:
        raise SystemExit("usage: gaussian_source_adapted_parallel.py CHECKPOINT_ROOT")
    sequential = os.environ.get("MKL_THREADING_LAYER") == "SEQUENTIAL"
    os.environ["MKL_THREADING_LAYER"] = "SEQUENTIAL"
    os.environ["OMP_NUM_THREADS"] = os.environ["MKL_NUM_THREADS"] = "1"
    interpreter = Path(os.environ.get("CUDA_PYTHON", "C:/anaconda/python.exe"))
    same = os.path.normcase(str(Path(sys.executable).resolve())) == os.path.normcase(str(interpreter.resolve()))
    if not same or not sys.flags.isolated or not sequential:
        return subprocess.run([str(interpreter), "-I", "-B", str(Path(__file__).resolve()), sys.argv[1]],
                              env=os.environ.copy(), check=False).returncode
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"src"))
    from multiagent_elbo.realizations.gaussian.source_adapted_parallel import run_source_adapted_continuation
    run_source_adapted_continuation(sys.argv[1], OUTPUT_ROOT, WORKERS)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
