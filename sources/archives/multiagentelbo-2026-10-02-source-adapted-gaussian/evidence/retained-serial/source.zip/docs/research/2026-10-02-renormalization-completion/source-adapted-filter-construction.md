# Source-adapted normalized hidden filtering

October 2, 2026. One bounded constructive round after the published particle replay. No implementation, test, simulation, GPU work, or Vault edit was performed for this record.

## Exact result and scope

A sequential decoder can condition its hidden message after each receiver label and still define an exactly normalized assignment predictor. Every receiver must predict a complete normalized categorical row before assimilating its label. Positive cubature supplies such a row when the same nodes and weights evaluate every supported label. Multiplying the conditional rows gives an order-dependent normalized refresh distribution. Mixing it with the original whole-network hold atom preserves same-assignment refreshes.

Gaussian hidden messages then give analytic configuration prediction and conditioning for the hold and refresh branches. Their mixture is a normalized joint predictor for the next assignment and retained configuration. An actual-law entropy budget below charges source quadrature, Gaussian projection, and subsequent compression. Its residuals have not been bounded numerically or asymptotically. Normalization and a smooth density decoder do not settle O1.

The supplied scientific model, activation, and intended path-law target are unchanged from [joint-filter-CONTRACT.md](joint-filter-CONTRACT.md). For every fixed finite N, positive temperature, finite supported source sets, positive supported prior entries, full-row-rank retained map P, positive-definite mobility M, finite time grid, and finite supplied structural schedule, the construction gives a normalized candidate on the same paths (R_t,J_t), where R_t=P X_t. The preceding study uses N=512 or 1024 and block size 16. The argument is not restricted to those sizes, but no constant is uniform in N or the small-parameter/horizon regimes of O1.

Introduced approximation choices are a fixed receiver order, positive cubature, a Gaussian or fixed-size Gaussian-mixture message, an optional product restriction across blocks, and optional positive covariance regularization. These are not assumptions about the native law. Exact equivalence means equality of complete retained joint path laws. Better finite predictive scores would be narrower evidence.

Sources read are Chapter 11, def:rg-regular-finite-filter and open:rg-pointwise-parent-dynamics (live c11_network_coarsegraining.tex, lines 1288-1346), thm:rg-memory-filter (lines 1426-1448), PIFB2 pifb2/09_section.tex, sections "The exact parent and its free energy" and "Gaussian summaries with different meanings," and the first sections of the wiki theme "Staged hierarchy formation and RG composability." They establish the disintegration target and covariance distinctions, not the new approximation's accuracy. The local code baseline read was 868cf239f9c2972ef66962e10ad33eda02d595e8. The research-loop skill was used in its single bounded derivation mode, and research-wiki for read-only continuity.

## Native joint model and hidden coordinates

Let x be in R^d, d=NK, with Lebesgue measure, and j in the finite product of receiver support sets, with counting measure. Condition on the supplied schedule, graph, comparison maps, priors, temperature, mobility and retention map. The source probabilities are

$$
\beta_{i,a,t}(x)=
\frac{\pi_{i,a,t}\exp[-D_{i,a,t}(x)/\tau]}
 {\sum_{b\in S_i}\pi_{i,b,t}\exp[-D_{i,b,t}(x)/\tau]},
\qquad
D_{i,a,t}(x)=\frac12(x_i-B_{i,a,t}x_{j(i,a)})^T
 H_i(x_i-B_{i,a,t}x_{j(i,a)}).
$$

Every supported beta is positive at finite x and every row sums to one. Put p=1-exp(-delta), and write A_{t,j}x+b_{t,j}=x-delta M g_{t,j}(x), with the full receiver and sender force g. With Q=2delta M, the native joint density is

$$
\phi_{\Sigma_0}(x_0-\mu_0)b_0(j_0)
 \prod_{t=0}^{H-1}
 \left[(1-p)\mathbf1_{\{j_{t+1}=j_t\}}
       +p\prod_i\beta_{i,j_{t+1,i},t}(x_t)\right]
 \phi_Q(x_{t+1}-A_{t,j_{t+1}}x_t-b_{t,j_{t+1}}).
\tag{1}
$$

The initial b_0 is independent of X_0. Summing labels and integrating Gaussian transitions recursively proves normalization. Introduce an unobserved Bernoulli variable C_t: C_t=0 holds every label; C_t=1 redraws every label independently conditional on X_t. Equality J_{t+1}=J_t does not reveal C_t.

Fix T=P^T(PP^T)^{-1} and orthonormal columns Z spanning ker P. Then x=Tr+Zz on the observed fiber, with z in R^k, k=d-rank P. Hidden densities use dz. The exact nu_t is the conditional hidden law given the complete retained history H_t. Its initialization is the activation conditional derived in the preceding contract. The message q_t is a density on these same coordinates, initially that exact conditional.

The target objective is

$$
D(P_{RJ}\Vert S)
=\mathbb E_{P_{RJ}}\sum_{t=0}^{H-1}
 \log\frac{p_t(J_{t+1},R_{t+1}\mid H_t)}
 {s_t(J_{t+1},R_{t+1}\mid H_t)}.
\tag{2}
$$

This is predictive relative entropy, not an ELBO optimization. Gaussian moment projection separately minimizes D(v||q) over Gaussian q when v has finite covariance and entropy. No fine conditional entropy is silently treated as constant under a different optimization block.

## Exact sequential source conditioning

Fix a receiver permutation sigma before prediction. For a candidate refresh assignment a in that order, define nu^[0]=nu_t and

$$
b_i(a_i\mid a_{<i})
=\int\beta_{\sigma(i),a_i,t}(Tr_t+Zz)\nu^{[i-1]}(dz),
\qquad
\nu^{[i]}(dz)=
\frac{\beta_{\sigma(i),a_i,t}(Tr_t+Zz)}
 {b_i(a_i\mid a_{<i})}\nu^{[i-1]}(dz).
\tag{3}
$$

The exact refresh probability is product_i b_i. Multiplying the ratios cancels intermediate normalizers, giving the integral of product_i beta_i against nu_t. Each b_i is normalized because beta is. The exact final posterior is independent of sigma; approximate updates generally lose that property.

Factorization alone is no remedy: applying (3) to an unchanged atomic support without a move or projection reproduces the original product reweighting. The new step changes the hidden representation after each label.

## Mechanism 1: a normalized assumed-density source decoder

Let q^[0]=q_t. At each prefix produce a positive normalized categorical row c_i(a|a_<i), and then update q^[i]=U_{i,a}(q^[i-1]). Define

$$
\widehat b_t(a)=\prod_{i=1}^N c_i(a_i\mid a_{<i}).
\tag{4}
$$

Summing from the final label backward proves sum_a widehat b_t(a)=1 even when U is approximate. Thus posterior adaptation preserves normalization if the categorical row is scored first. It changes the candidate model; the error is charged below.

For q=N(m,S), S positive definite, a concrete update uses local cubature and Gaussian regression. Let V have orthonormal columns spanning the hidden directions needed by all logits of receiver sigma(i). Then y=V^Tz has mean u=V^Tm and covariance C=V^TSV. Its dimension r depends on the complete receiver star, including every source in the softmax denominator. Using only the selected edge generally omits necessary variables. For r=0 beta is constant and there is no source update.

Choose positive weights lambda_l and fixed nodes xi_l satisfying

$$
\sum_l\lambda_l=1,\qquad
\sum_l\lambda_l\xi_l=0,\qquad
\sum_l\lambda_l\xi_l\xi_l^T=I_r.
$$

The 2r nodes plus/minus sqrt(r)e_j with weights 1/(2r) are one choice. With a declared Cholesky factor L of C, put y_l=u+Lxi_l and

$$
c_i(a)=\sum_l\lambda_l\beta_{\sigma(i),a,t}(y_l;r_t),
\qquad
v_{l,a}=
\frac{\lambda_l\beta_{\sigma(i),a,t}(y_l;r_t)}{c_i(a)}.
\tag{5}
$$

The notation beta(y;r_t) is the original likelihood expressed in sufficient local coordinates. Shared nodes across labels make sum_a c_i(a)=1 exactly in real arithmetic. This is deterministic quadrature, not a claim that a noisy whole-assignment normalizer defines a row.

For the candidate label a, compute

$$
u_a=\sum_l v_{l,a}y_l,\qquad
C_a=\sum_l v_{l,a}(y_l-u_a)(y_l-u_a)^T,\qquad
G=SV C^{-1},
$$

and update to the Gaussian with moments

$$
m_a=m+G(u_a-u),\qquad
S_a=S-GCG^T+GC_aG^T.
\tag{6}
$$

To derive (6), average the exact Gaussian conditional z|y, of mean m+G(y-u) and covariance S-GCG^T, over the label-weighted nodes. The resulting auxiliary mixture has the displayed moments. It may be singular because y takes finitely many values; no finite KL projection identity is claimed for that auxiliary measure. Its Gaussian moment fit is nevertheless well-defined. Omitting GC_aG^T would incorrectly treat the label as an exact observation of y.

All v are positive and the nodes affinely span R^r, so C_a is positive definite. If a nonzero w annihilated both positive-semidefinite terms in S_a, then G^Tw=0 and w^T(S-GCG^T)w=0, implying w^TSw=0, a contradiction. Hence S_a is positive definite.

Exact Gaussian integrals in place of cubature would give the exact moments of the source-tilted Gaussian, but still discard its non-Gaussian shape. That projection's self-residual is D(q tilted||q_G)=h(q_G)-h(q tilted). The actual-law residual is different, as derived below.

Receiver order, local bases, Cholesky convention and cubature are part of the approximation. Finite cubature need not be invariant under an arbitrary hidden-coordinate or gauge-frame change. A declared frame makes it definite; it does not establish gauge-independent error. This deterministic version has no random tape.

## Preserve the global mixture through configuration prediction

For each complete candidate j', the hold message is q_H=q_t unchanged and the refresh message is q_F(j')=q^[N]. Write their hidden Gaussian moments as (m_c,S_c), c=H,F, and fine moments as mu_c=Tr_t+Zm_c and V_c=ZS_cZ^T. Put

$$
\bar\mu_c=A_{t,j'}\mu_c+b_{t,j'},\qquad
W_c=A_{t,j'}V_cA_{t,j'}^T+Q,\qquad
D_c=PW_cP^T.
$$

Because Q is positive definite, D_c is positive definite. Let g_c(r'|j')=phi_{D_c}(r'-P bar mu_c). The complete row is

$$
s_t(j',r'\mid H_t)
=(1-p)\mathbf1_{\{j'=J_t\}}g_H(r'\mid j')
 +p\widehat b_t(j')g_F(r'\mid j').
\tag{7}
$$

Each Gaussian integrates to one, and (4) is normalized, so (7) is normalized. This proof does not require q_F to be the exact posterior of q_t or require enumerating all complete assignments in code.

When j'=J_t, both terms are required. Treating that observation as a certain hold drops same-assignment refresh. Applying the refresh-updated message to the hold term would instead assimilate information absent from that branch.

Score (7) before using r' to update the message. After observation, each branch has exact Gaussian conditional moments

$$
\mu_c^+=\bar\mu_c+W_cP^TD_c^{-1}(r'-P\bar\mu_c),\qquad
V_c^+=W_c-W_cP^TD_c^{-1}PW_c.
\tag{8}
$$

The branch weights are proportional to the two terms in (7). Thus the posterior of the candidate row is a two-component Gaussian mixture on the next fiber. The gain uses the full propagated W_c, including hidden uncertainty, not merely Q.

Keeping that mixture is possible. A single-Gaussian projection instead uses normalized weights omega_c and

$$
m^+=\sum_c\omega_cm_c^+,\qquad
S^+=\sum_c\omega_c
 [S_c^++(m_c^+-m^+)(m_c^+-m^+)^T],
\tag{9}
$$

where m_c^+=Z^T(mu_c^+-Tr') and S_c^+=Z^TV_c^+Z. The between-branch covariance term is required. Projection (9) affects subsequent rows, not the row already scored.

## Mechanism 2: a continuously decoded finite Gaussian mixture

A fixed L-component message sum_l w_l N(m_l,S_l), with positive weights and covariances, admits the same source adaptation. Compute each component's c_{i,l}(a) and moments by (5)-(6), then

$$
c_i(a)=\sum_lw_lc_{i,l}(a),\qquad
w_{l,a}=\frac{w_lc_{i,l}(a)}{c_i(a)}.
\tag{10}
$$

This is normalized and adapts component weights and moments. Each component has a hidden density, unlike an atomic particle decoder. Global branching gives up to 2L components. Fixed-budget compression is a further approximation; a discontinuous nearest-component merge cannot be called a continuous update. The simplest smooth fixed-budget case is L=1 with (9). A larger mixture requires its own smooth compression specification.

On the open domain of positive weights and positive-definite covariances, the mixture decoder is continuously Frechet differentiable into L1(dz). Differentiating a Gaussian gives a polynomial of degree at most two in z-m times its density. On each compact parameter neighborhood the means are bounded and covariance eigenvalues stay away from zero and infinity; an integrable polynomial-times-Gaussian envelope bounds these derivatives. Dominated convergence proves continuity of the L1 derivative. Finite mixtures preserve this property.

On fixed assignment/support strata, Cholesky, beta, positive finite sums, division by positive c_i, regression and moment merging are smooth. This addresses the atomic decoder's density defect. It does not establish an admitted time-homogeneous continuous-time realization or asymptotic accuracy.

## Actual-law error accounting

At one source stage let nu be the true prefix-conditioned density, q the approximate message, b_a=int nu beta_a, c_a the implemented row, nu_a=nu beta_a/b_a, and q_a its updated density. Assume the following expectations are finite. Define the signed residual

$$
\rho_a=\int\nu_a(z)
 \log\frac{q(z)\beta_a(z)}{c_aq_a(z)}dz.
$$

Expanding logarithms gives the exact identity

$$
D(b\Vert c)+\sum_a b_aD(\nu_a\Vert q_a)
=D(\nu\Vert q)+\sum_a b_a\rho_a.
\tag{11}
$$

Indeed the left side integrates nu beta_a log[nu beta_a/(c_aq_a)]; subtraction of D(nu||q) leaves the residual. Exact Bayes gives rho_a=0. If c_a=int q beta_a and only the density projection is approximate, let q_a^*=q beta_a/c_a. Then

$$
\rho_a=D(q_a^*\Vert q_a)
 +\int(\nu_a-q_a^*)\log(q_a^*/q_a).
\tag{12}
$$

The second term is the actual-law correction. It is not generally zero or nonnegative. If cubature also changes c_a, set bar c_a=int q beta_a and q_a^*=q beta_a/bar c_a; add log(bar c_a/c_a) to the right side of (12).

Apply (11) to the true refresh-prefix laws. Write d_t=D(nu_t||q_t), and let the source residual sum $\mathcal E_t$ be the sum of the true-prefix expectations of rho over the receiver stages, conditional on H_t and C_t=1. The assignment chain rule yields

$$
D(b_t^{\mathrm{refresh}}\Vert\widehat b_t)
+\mathbb E_{\mathrm{true\ refresh\ assignment}}
 D(\nu_t^{j'}\Vert q_F(j'))
=d_t+\mathcal E_t.
\tag{13}
$$

Individual residuals can have either sign, although the left side is nonnegative.

Applying the same normalized affine Gaussian transition to two hidden laws cannot increase relative entropy: augment with the common transition, whose log density cancels, then disintegrate. Keep the latent refresh coin first, with weights (1-p,p) on both sides, and then forget it, again using disintegration. Finally disintegrate over the retained next observation. If hat nu_{t+1} is the exact candidate posterior before final compression, this proves

$$
D(p_t\Vert s_t)
+\mathbb E_{p_t}D(\nu_{t+1}\Vert\widehat\nu_{t+1})
\leq d_t+p\mathcal E_t.
\tag{14}
$$

For the subsequently stored q_{t+1}, define

$$
\zeta_{t+1}
=\int\nu_{t+1}\log(\widehat\nu_{t+1}/q_{t+1}).
$$

Add this exact log-ratio identity to (14), average over true histories, and sum. The hidden divergences telescope:

$$
D(P_{RJ}\Vert S)+\mathbb E_Pd_H
\leq d_0+p\sum_{t=0}^{H-1}\mathbb E_P\mathcal E_t
       +\sum_{t=0}^{H-1}\mathbb E_P\zeta_{t+1}.
\tag{15}
$$

Both laws use the same initial retained law; exact hidden initialization gives d_0=0. Replacing each signed residual by its positive part gives a nonnegative upper budget. This is a finite-horizon bound conditional on controlling explicit actual-law residuals. No small value has been proved. Approximate-law projection entropies alone do not supply that control because of (12).

A nonnegative budget epsilon_H implies retained-path TV at most sqrt(epsilon_H/2). To see this without invoking an unmatched theorem, choose the measurable set attaining TV and apply binary coarse-graining to relative entropy. Binary KL as a function of the first probability a at fixed second probability b has second derivative 1/[a(1-a)]>=4 and zero value and derivative at a=b. Thus binary KL>=2(a-b)^2. The required O1 windows still need a proof that epsilon_H vanishes.

At a fixed finite history, all Gaussian messages have positive hidden densities and log beta has at most quadratic growth. The exact finite-grid posterior has finite polynomial moments, so the displayed local expressions are well-defined at finite positive-definite message parameters. Unconditional expected log loss additionally requires control of near-singular approximate covariances.

A sufficient explicit option for the single-Gaussian construction is adding eta S_ref after each source moment update and after covariance product projection, with eta>0 and fixed S_ref positive definite on hidden coordinates. This regularizes the message, not native noise; its error belongs in rho or zeta. Keep the initial activation conditional exact.

For fixed N,H, this gives a uniform positive covariance lower bound. Observation-conditioned propagated covariances are also bounded below by the hidden conditional covariance of Q, since their unconditioned W is at least Q. In coordinates this follows from W^{-1}<=Q^{-1} and conditional hidden covariance (Z^T W^{-1}Z)^{-1}. Mixture moment matching preserves that lower bound.

Upper covariance and mean bounds need not be deterministic: the between-branch term in (9) depends on the observation. They do have finite polynomial-growth bounds in the observed history. Finite cubature bounds weighted covariance and mean shifts by finite multiples of current covariance norms; regression inverses are bounded by the positive floor. Propagation is affine, observation covariance D is bounded below by P Q P^T, and conditional covariance is bounded above by W. Moment merging introduces at most quadratic mean-difference terms. Induction over the finite number of operations gives polynomial bounds. The finite native affine-sheet recursion has moments of every order. Consequently Gaussian log ratios and minus log c_i admit integrable polynomial envelopes, making (11)-(15) finite for this explicitly regularized finite Gaussian construction. Constants may grow with N,H, temperature and inverse eta. This is not a useful small-error rate. A general mixture compression requires its own analogous control.

## Economical old-prefix shortcut and its error bound

The following variant addresses the cost of processing every receiver on nearly every hold row. It changes the preceding reference deliberately before comparing a shortcut to it.

Define a sequential reference S^same using the complete source decoder (4), but using the hold Gaussian g_H and the same hold-posterior update whenever the complete next assignment equals the old one. This convention applies even on a latent refresh that redraws the old assignment. For changed assignments retain the source-adapted refresh Gaussian and update. In particular,

$$
s^{\mathrm{same}}(J_t,r'\mid H_t)
=[(1-p)+p\widehat b_t(J_t)]g_H(r'),
$$

whereas a changed j' has density p widehat b_t(j')g_F(r'|j'). Every conditional configuration density remains normalized, so the row is normalized. This is a new approximation to the two-branch source Bayes update in (7)-(9), not an exact fact about the native process. In the error budget it can be charged by replacing the final refresh message q_F(J_t) with q_t and including the corresponding actual-law log-density ratio after the source stages. No native-law error bound is inherited for free.

Fix 0<delta_cut<1. Follow the old assignment along the declared receiver order. Let M_i be its cumulative refresh prefix probability under the complete sequential reference. Find the first i_* for which M_i<=delta_cut, if it exists. Before that prefix, full and shortcut prediction and source-message updates are identical. At the unique prefix a_1:i_*=J_t,1:i_*, replace the remaining conditional decoder by a declared cheap normalized suffix. For example, freeze the current hidden mean at that prefix and use its native categorical beta rows for all remaining labels. For changed complete assignments under this suffix, freeze the prefix Gaussian for subsequent configuration prediction and conditioning as well. For unchanged complete assignments use the common hold Gaussian/update as already stipulated. Any replacement conditional suffix, configuration density and message update must be declared for every suffix, not only the observed one.

The decision uses only previous and just-assimilated prefix labels, never later labels or R_{t+1}. The complete prefix has probability M_i_* under both reference and shortcut refresh laws. Each replacement suffix has probability one conditional on that prefix. Therefore the shortcut is normalized, and the two refresh mechanisms differ only on one prefix cylinder of common probability M_i_*<=delta_cut. If the threshold is not reached, there is no replacement.

For a rigorous coupling, assume the two predictors currently have the same retained history and message. Draw the same Bernoulli refresh coin. On a hold, use the same Gaussian innovation and common update, so outputs and next messages agree. On a refresh, couple every prefix label identically until the designated prefix cylinder is reached; outside that cylinder the remaining computations are identical. Inside it allow arbitrary disagreement. Thus the joint law of the next retained observation and internal message has disagreement probability at most p delta_cut. This is stronger than comparing one-time rows because it preserves identical internal states whenever coupling succeeds.

Induction up to the first disagreement gives, for H steps and possibly varying declared p_t and delta_cut,t,

$$
\operatorname{TV}(S^{\mathrm{same}}_{0:H},
                 S^{\mathrm{cut}}_{0:H})
\leq 1-\prod_{t=0}^{H-1}(1-p_t\delta_{\mathrm{cut},t})
\leq\sum_{t=0}^{H-1}p_t\delta_{\mathrm{cut},t}.
\tag{16}
$$

The same upper bound follows by a union bound if only conditional per-step bounds are supplied. This comparison remains valid for shared deterministic coefficient updates depending on the common current state, as long as the two update rules coincide until disagreement. It is not a bound between either candidate and the native law.

There is also a useful held-row score bound. Both complete old-assignment probabilities lie between zero and delta_cut once a cutoff is triggered, since they share that prefix. Their difference is at most delta_cut. Their held configuration densities are identical and the full assignment mass is at least 1-p. The mean-value bound for log gives

$$
\left|\log s^{\mathrm{same}}(J_t,r')
      -\log s^{\mathrm{cut}}(J_t,r')\right|
\leq\frac{p\delta_{\mathrm{cut}}}{1-p}.
\tag{17}
$$

For p=1-exp(-1/64) and H=64, the path-TV upper bound in (16) is less than delta_cut. Neither small TV nor (17) controls log-score differences on changed assignments inside the modified cylinder; arbitrarily small density ratios can have large log penalties there. Empirical native-path risk comparisons must still be recorded honestly.

The computational benefit is specific: an observed unchanged assignment needs adaptation only until its old-matching prefix becomes sufficiently improbable, then cheap suffix rows and the common hold update. A changed assignment that leaves the old prefix earlier still requires the full source-adapted computation. This matches the low refresh frequency without classifying every unchanged observation as a certain native hold.

The hard cutoff can make prediction and refresh update maps discontinuous as message parameters cross the threshold. Consequently this economical variant does not inherit the smooth-update claim of the uncut deterministic Gaussian construction. It is a normalized finite-grid experimental candidate with the explicit approximation bound (16), not an admitted O1 regular filter. A smooth alternative needs a separate construction and is outside this one round.

## Minimal executable variant and unresolved obligation

The shortest uncut candidate is deterministic single-Gaussian source adaptation with fixed receiver order and positive local cubature. Score each label c_i before updating its Gaussian, form both global branches in (7), score their log-sum-exp at the actual next configuration, apply (8), then (9). All source probabilities use the native supported softmax. Label-order comparisons measure approximation dependence, not a change in the exact target.

Dense covariance makes each local rank update potentially O(k^2r); repeating it at every receiver for N=1024 is not a justified cheap next study. An explicit cheaper restriction is a product Gaussian across the hidden coordinates of declared blocks. After each source update, retain within-block covariance blocks and discard cross-block terms. Only blocks intersecting that receiver's star change. This projection's self-discrepancy for full Gaussian covariance S is

$$
D(\mathcal N(m,S)\Vert
 \mathcal N(m,\operatorname{blockdiag}S))
=\frac12[\log\det(\operatorname{blockdiag}S)-\log\det S].
\tag{18}
$$

The trace cancels because diagonal blocks match. Its actual-law contribution still uses (11)-(12), not merely (18). Preserve the full projected observation covariance D_c in (7); discarding its off-diagonal blocks is another predictive approximation.

For block size 16 and K=2, each block has 30 hidden coordinates. Block-covariance storage is linear in block count. The observation covariance is 64 by 64 for N=512 and 128 by 128 for N=1024. Sparse sheet multiplication, block covariance products and W_cP^T suffice to compute that exact covariance and the conditional within-block moments without materializing every entry of W_c. This specifies an executable direction, not a benchmark or favorable score.

The construction removes the unchanged-cloud global reweighting and atomic-decoder defects. It may still perform worse because projections lose correlations or depend strongly on label order. At fixed N its deterministic message has dimension independent of horizon and epsilon; storage growth with N alone is not a violation of the manuscript's stated bound. The finite-grid, externally scheduled evolution still lacks admission to the time-homogeneous continuous-time filter class.

The minimal unresolved mathematical obligation is control of (15)'s actual-law residual budget for a specified reduced family on the required windows, followed by an endogenous structural law and admitted continuous-time realization. A finite source-adapted replay can discriminate this approximation from the failed particles, but cannot alone close O1. O4 intrinsic recursive formation is unchanged.
