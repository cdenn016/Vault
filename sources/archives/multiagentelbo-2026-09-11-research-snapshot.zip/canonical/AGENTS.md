# Repository Instructions

## Current user directive: no tamper checks (2026-09-03)

The user prohibits invoking tamper checks in every session and repository. This
directive supersedes older tamper requirements below and in plans or runbooks.
Do not invoke deliberate artifact/file corruption, forgery, or malicious-packet
tests directly, through subagents, or inside bundled commands. The current
`test_phase13_pristine_relocated_and_tampered_packet` publication node includes
such checks and must not run unchanged. Separate any needed permitted checks
before execution; do not evade the prohibition by renaming the scenarios.
Record those checks as user-excluded/not run, never passed. Ordinary scientific
correctness and non-mutating integrity/provenance checks remain permitted.
Operator acceptance is distinct from an automated passing certificate: preserve
existing evidence and report incomplete checks honestly, without fabricating
JUnit, publication-control files, or an evidence envelope.

## Git completion requires canonical Desktop synchronization

For every authorized commit, push, merge, and fast-forward, completion requires
updating the actual canonical Desktop checkout at
`C:\Users\chris and christine\Desktop\MultiAgentELBO`, not merely an isolated
worktree or the local `main` ref. Fetch first; after the merge, verify that the
canonical checkout is on `main`, its checked-out `HEAD`, local `main`, and
`origin/main` resolve to the same commit, and its non-WIP tracked content is
current. A pointer-only `git branch -f main origin/main` is not completion.

Preserve every approved WIP byte-for-byte, report remaining differences, and do
not treat nonconflicting WIP as a reason to stop synchronization. The current
authorization includes retaining the colliding
`docs/change-logs/2026-08-30.md` bytes as a tracked local modification, the 16
tracked deletions, and all remaining untracked files. Request a specific
collision decision only when new authority is genuinely required. The historical
isolation rule protects WIP but does not prohibit this explicitly authorized
canonical-Desktop handoff.

## Phase 14 sector-quotient design approved; implementation not started (2026-09-03)

The user approved
`docs/superpowers/specs/2026-09-03-rg-v2-phase14-sector-quotient-design-gate.md`
and requested its task-level implementation plan. The executable planning
authority is
`docs/superpowers/plans/2026-09-03-rg-v2-phase14-sector-quotient-implementation.md`;
the older untracked 2026-08-31 Phase 14 design and plan remain preserved WIP,
not implementation authority. Approval authorizes the design boundary, but
the planning request does not itself start code, tests, or experiments. Begin
implementation only on a separate execution request, follow the plan's
admission-first order, and stop if the required cross-sector intertwiners or
structural-channel squares do not exist. Do not substitute a nonequivariant
relabeling. The no-tamper directive above applies throughout Phase 14.

## Phase 13 operator-accepted closeout (2026-09-03)

The user approved closing the private research milestone with the retained
results, excluded tamper checks, and explicitly incomplete relocated replay.
See `docs/verification/2026-09-03-phase13-operator-acceptance.md`. Phase 13 is
operator-accepted; automated publication certification remains incomplete.
This supersedes older envelope-only milestone gates.
Do not rerun the producer or the all-in-one publication node for this closeout.
The accepted handoff, Desktop synchronization, named-audit intake, and Phase 14
design gate are complete. Historical failure records and scientific/runtime
guards below remain intact, not reclassified as passes.

## RG v2 Phase 13 long-running verification (historical execution policy)

Before running any Phase 13 complete-carrier heavy node, read
`docs/superpowers/plans/2026-09-01-rg-v2-phase13-task6-targeted-rerun-runbook.md`
and the current Phase 13 implementation plan. Treat the runbook as the durable
execution authority for targeted reruns, evidence invalidation, runtime
selection, process limits, and crash handling.

- Protect a dirty Desktop checkout. Inspect it read-only and use an isolated
  worktree for edits and tests. Never stash, reset, restore, overwrite, or
  otherwise normalize the user's WIP. This does not prohibit an explicitly
  authorized canonical-Desktop synchronization that preserves approved WIP
  byte-for-byte under the Git-completion rule above.
- Do not run the four-hour combined acceptance packet as a routine regression
  check. Run cheap focused tests first, then only the affected heavy node. The
  one clean-HEAD Task 10 attempt at `ad13a7222236cb38d1c694a339dd6ef09c944c71`
  failed when one CPython 3.14.7 science worker access-violated and the parent
  raised `BrokenProcessPool`. It produced no packet, publication control, or
  evidence envelope. Do not run an ordinary retry or begin Phase 14
  implementation or unrelated audit remediation; another heavy run requires explicit approval
  and a new discriminating obligation.
- A failed or crashed heavy node is a stop condition. Preserve its JUnit when
  one exists, stdout/stderr, revision and source hashes, environment, Windows
  Error Reporting record, and a full dump when available. Diagnose before any
  retry. Never retry until green, combine successes from different revisions,
  discard a failure, or weaken a digest or scientific guard.
- The targeted pool node crashed in CPython 3.14.7 garbage collection before
  workers spawned. The bounded closure-only A/B is now complete: normal
  imports with GC disabled and minimal imports with GC enabled both produced
  both canonical closures and exited zero. Do not repeat either arm as an
  ordinary retry and do not call the cause resolved. ProcDump 12.01 is
  unsupported on this Windows 10 host and has itself crashed; do not use it as
  capture authority. WER LocalDumps, WinDbg, Citrix or Defender changes, and
  host tuning require evidence and explicit approval.
- The final Task 10 parent runs under the isolated CPython 3.14.7 runtime at
  `C:\tmp\rg-v2-phase13-py3147-runtime-20260901\python.exe` with explicit
  repository path injection. The publication harness must derive producer and
  oracle interpreters from the parent's `sys.executable`; never hardcode
  `C:\Python314\python.exe` inside the harness, because that silently splits
  the verified 3.14.7 parent from a 3.14.4 child.
  Authoritative producer and oracle commands must retain `-I` and explicitly
  pass `-X dev`; `-I` ignores `PYTHONMALLOC` and `PYTHONFAULTHANDLER`, so those
  environment variables alone do not activate the debug allocator or
  faulthandler. Isolated mode also ignores `PYTHONHASHSEED=0`; canonical
  artifact determinism must not depend on randomized object hashes.
- Use the Ryzen 9900X for exact CPU work: at most 12 science workers and at most
  14 live processes in the test tree. Confirm adequate free memory before a
  heavy node and leave unrelated processes alone. Under the user-approved
  2026-09-02 amendment, 300 seconds and every other elapsed value are
  reporting-only optimization targets. Elapsed excess never fails or kills an
  otherwise valid run.
- Python `int` and `Fraction` arithmetic is the scientific authority for this
  packet. CUDA cannot accelerate it without changing the arithmetic contract.
  Do not substitute CUDA, pytest-xdist, a second process pool, approximate
  arithmetic, or cached mutation outcomes unless an approved design amendment
  establishes the new contract and its verification.
- This host currently reports two 32-GB DIMMs configured at DDR5-6000, above
  AMD's published DDR5-5600 maximum for the Ryzen 9 9900X. Treat this as an
  unresolved stability confound, not a diagnosed cause. Never change memory
  speed, PBO, Curve Optimizer, Ryzen Master, firmware, or reboot the host
  without explicit user approval.
- Machine-readable JUnit XML is the authority for test totals, outcomes, and
  durations. Bind every result to the exact revision, source, fixture, command,
  runtime, environment, and JUnit hash that produced it.
- Historical elapsed values of 960 and 3,600 seconds for the producer, 720
  seconds for one replay, 2,400 seconds for aggregate tampers, 2,700 seconds
  for the producer target, and 4,800 seconds for publication are reporting
  only. Authoritative producer, oracle, and publication execution has no
  wall-clock deadline. Keep finite and internally consistent timing records,
  but never fail or terminate an otherwise valid certificate solely for
  elapsed time. Science visits, worker/process counts, exact arithmetic,
  packet size, source revision, and evidence integrity remain fail-closed.
  The exact-optimization closure-only run at commit
  `1cbe2f773c0ccd899e6789a2d78ff19a10b9bb1a` completed in `1643.088145`
  seconds with digest parity. On 2026-09-01 the user accepted that duration
  and approved the then-current 3,600-second amendment; the 2026-09-02
  no-deadline amendment supersedes that timing boundary. Do not rerun the
  closure discriminator or add timing probes without a concrete diagnostic
  need. The central producer estimate is `2989.088` seconds and the
  conservative estimate is `3415` seconds. The clean-revision Task 10 attempt
  failed before publication closure; preserve that failure and do not
  reinterpret the estimates as retry authority. Use at most 12 science workers
  and a live process tree of at most 14; CUDA remains non-authoritative for the
  exact `int`/`Fraction` certificate.
- A proven speedup candidate reuses binding-qualified positive receipts for
  the 1,023 shards untouched by each mutation and executes the sole incident
  shard under the approved Phase 13 amendment in
  `docs/superpowers/specs/2026-09-01-rg-v2-phase13-positive-receipt-reuse-amendment-design.md`.
  Derive incidence from the exact operation route, execute the incident shard
  freshly, keep logical visits and the reducer unchanged, report physical
  visits separately, and fail closed on provenance or incidence drift.
  Do not generalize receipts beyond this approved boundary.
- The approved lazy `multiagent_elbo.finite` import repair preserves its public
  exports while removing unused eager native-import surface from the exact Phase
  13 path. It does not identify the native-crash root corruptor or establish a
  cause for the historical `ad13a72` worker access violation.
- The approved cyclic-GC containment disables automatic cyclic collection for
  the full public Phase 13 runner and before spawned science/admission workers
  install context. It restores the caller's exact entry state in `finally`,
  leaves inline execution unchanged, and adds neither `gc.collect()` nor retry.
  This is containment for a repeated native crash class, not a root-cause claim.
- The complete Phase 13 prepublication pytest packet is an exact disjoint cover
  across three sequential fresh interpreters: composition alone, assessment
  alone, then the remaining eight files. Do not recombine the heavy fixtures in
  one long-lived pytest parent. Start every shard with pinned CPython 3.14.7 and
  `-I -B -X dev`, call `gc.disable()` before importing pytest or repository
  modules, inject the isolated worktree path explicitly, and run serially
  without xdist. Pytest 9.1.1's unraisable-exception plugin forces two
  `gc.collect()` calls at session teardown; retain its warning queue but pass a
  tiny `pytest_configure` plugin that sets its private
  `gc_collect_iterations_key` to zero. Recheck that seam after any pytest
  upgrade. Because `gc.disable()` only suspends automatic collection, no test
  in the exact packet may call either `gc.enable()` or `gc.collect()`; the
  packet owns a static AST regression for this rule plus an exact disjoint-
  cover regression. Both must run together as a cheap preflight before the
  long shards, and GC-state unit tests must use a fake collector. The exact
  commands are in the current implementation plan. The outer pytest process
  for the one-test publication workflow must use the same validated driver;
  do not revert to a simple `import pytest` wrapper, because pytest's forced
  teardown collection would reopen the contained failure boundary. The
  publication test itself contains no direct collector call. The targeted-
  rerun runbook records the rationale and failure policy. A
  clean-`987ae8d`
  packet that omitted the parent suspension produced one impossible
  back-to-back route-digest mismatch and later waited indefinitely for an
  unfinished science Future while all twelve workers were idle. The full dump
  proves the wait occurred in `as_completed`, not executor shutdown; it does
  not prove the worker-side cause. A later clean-`c42a3b0` packet used the
  parent wrapper but an earlier test explicitly ran `gc.collect()`. It
  therefore falsified automatic-GC suspension alone as sufficient; it did not
  test the strengthened no-enable/no-collect boundary. Do not weaken a
  validator, add a retry, or change low-level parent/inline GC semantics in
  response. A combined clean-`f5b7e1b` run produced one shared composition-
  fixture error, while that exact heavy node passed in a fresh interpreter.
  An isolated shard failure after the no-enable/no-collect preflight passes
  falsifies the strengthened containment and returns to the preserved-dump or
  fail-closed digest diagnostic path without retry.
- The `4c66992` publication attempt completed the exact producer and wrote a
  complete-looking diagnostic packet, but one fresh science worker then
  access-violated during interpreter-finalization GC. The archived minidump and
  matching CPython 3.14.7 symbols resolve the fault to `gc_collect_main`; they
  do not identify the underlying memory corruptor. Spawned Phase 13 workers now
  register a pinned-runtime `multiprocessing.util.Finalize` at priority `-1000`.
  Its callback disables GC, clears the module context, freezes the remaining
  tracked graph, and only then signs a shared PID attestation. The parent must
  snapshot every concrete executor process before graceful shutdown and accept
  the generation only when the PID inventory is complete, every exit code is
  exactly zero, every finalizer attestation is present, and the child baseline
  is restored. Do not replace this with `terminate_workers()`: CPython 3.14.7
  starts asynchronous executor shutdown before its termination loop, so normal
  worker finalization can win that race. These are private pinned-CPython seams;
  revalidate them before changing the runtime. Keep the `Finalize` import local
  to the worker initializer: a module-level binding enters the Phase 13 loaded-
  code authority and exposes live multiprocessing registry state.
- For the authorized final candidate, run the cheap isolated-runtime gates,
  then make one serial clean-`HEAD` Task 10 attempt. This approval is the sole
  exception to the preceding crash stop; it is not general retry authority. On
  a crash, preserve the JUnit, logs, revision/source hashes, environment, and
  WER record, then stop. The user has authorized UAC and a full dump if the
  contained run crashes again; a dump is not a prerequisite for the attempt.
  Build the evidence envelope only after a pass; never rerun a revision after it
  has a matching passing envelope. Automated publication certification is
  complete only for a revision with that matching envelope. The current
  operator-accepted closeout above separately permits the Phase 14 DESIGN
  GATE; it does not manufacture that automated certification.
