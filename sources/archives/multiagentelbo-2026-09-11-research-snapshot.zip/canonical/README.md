# MultiAgentELBO

Use [run_lab.py](run_lab.py) as the primary entry point and
[run_lab.cmd](run_lab.cmd) for Windows double-click execution. Choose PROFILE,
then edit its configuration through the [experiment catalog](experiments/README.md).
All 69 profiles select their scientific interpreter before imports.
RG implementations and fixtures are installed with the main package; legacy rg_v2 imports remain supported.
See [runtime and installation checks](environments/README.md) for the exact CPU, CUDA, and quick-check boundaries.
GPU experiments remain operator-run. All 55 RG studies and 13 foundation studies have configuration-only profiles. Shared execution and family-owned validators replace their repeated runner logic.

The active RG study is [RG v2](docs/rg-v2.md). The
[remaining RG theory and simulation-suite roadmap](docs/research-plans/2026-09-07-gauge-vfe-rg-completion-roadmap.md)
defines the proposed next milestones and readiness gates. Its
[current program](docs/research-plans/2026-09-06-rg-v2-post-audit-program.md)
and [L32 precision status](docs/reports/2026-09-07-rg-v2-e6-critical-sequence-l32-precision.md)
record the latest work. The [standalone RG v1 rescaling application](docs/deprecations/rg-v1.md)
is retired; the shared finite and Gaussian foundations below remain supported.

MultiAgentELBO is an exact, finite simulation laboratory for studying the
conditional identities and explicit counterexamples in the `gauge_vfe_rg`
theory. The repository contains shared foundational laboratories alongside
the current RG v2 study:

- a universal finite categorical core for measures, Markov coarse graining,
  VFE/KL decompositions, Fisher contraction, full Hoeffding interactions, and
  finite relabeling metamorphics;
- a typed multivariate-Gaussian realization for matrix-weighted interactions,
  hard-identification/Galerkin restriction, Schur-complement marginalization,
  and passive local-frame congruence checks;
- an exact finite marked-event attention laboratory for normalized
  `eta = alpha * beta`, associative joint-law coarsening, scalar gauge
  metamorphics, and beta-only negative controls; and
- a positive three-category exponential-family laboratory separating the
  analytic finite-support DQM derivation from finite-difference, remainder,
  conditional-score, and Fisher-loss implementation diagnostics;
- exact multi-agent network, independent theory-oracle, and finite
  counterexample laboratories for the frozen two-scale application;
- information-history and gauge-holonomy laboratories with typed scope and
  explicit negative controls; and
- exact scale-cocycle and preregistered Gaussian fixed-ray laboratories, with
  the CUDA-dependent fixed-ray claim left inconclusive until its operator gate
  and float64 sentinel prerequisites are satisfied.

The repository does not expose an application CLI. Experiment choices live in
plain configuration dictionaries under experiments/.

## Foundation and RG profiles

Select a profile in run_lab.py, edit its RUN, THEORY, NUMERICS and OUTPUT
settings plus any declared COMPUTE or SOURCE dictionary, then run run_lab.cmd.
CPU studies use the pinned CPython 3.14.7 runtime; neighborhood uses the
CUDA-capable Anaconda interpreter. The profile files contain configuration only.
The following profile names choose the corresponding studies:

- `experiments/finite.py` selects the exact finite laboratory.
- `experiments/gaussian.py` selects the Gaussian realization laboratory.
- `experiments/attention.py` selects the state-conditioned marked-event attention
  laboratory.
- `experiments/categorical_dqm.py` selects the positive categorical DQM/Fisher
  laboratory.
- `experiments/multiagent_network.py` selects the exact two-scale multi-agent cases.
- `experiments/theory_oracle.py` selects independent literal theory oracles.
- `experiments/finite_counterexample.py` selects the bounded counterexample catalog.
- `experiments/information_history.py` selects finite information histories.
- `experiments/gauge_holonomy.py` selects the finite graph-link holonomy scenarios.
- `experiments/scale_cocycle.py` selects the exact three-level scale cocycle.
- `experiments/gaussian_fixed_ray.py` selects the non-heavy CPU pilot; it does not
  opt into CUDA or the confirmatory sweep.
- `experiments/categorical_falsification.py` selects the finite categorical
  two-channel falsification sweep, deliberately not Gaussian.
- `experiments/rg_v2/gauge_matter.py` selects the exact Phase 5
  three-agent directed gauge-matter network with fixed external channel links;
  its public `compute.backend` resolves to `cpu`.
- `experiments/rg_v2/plaquette.py` selects the exact Phase 6
  shared-principal latent-link and two-plaquette laboratory; its compute
  configuration resolves implicitly to deterministic CPU/float64 execution.
- `experiments/rg_v2/gauge_blocking.py` selects the exact Phase 7
  gauge-aware hard-blocking laboratory for the fixed partition
  `A=(a,b), B=(c)`; its default is the non-flat lossless `S3` fixture and its
  public compute policy is CPU-only.
- `make_figures.py` replays figures from an already finalized run without
  rerunning the numerical experiment.

The launchers insert their adjacent `src/` directory themselves, so they also
run directly from a fresh checkout without an editable install once the three
runtime dependencies are present. They accept no command-line flags and do no
work merely by being imported.

The Phase 6 launcher exposes exactly the same four editable dictionaries:
`RUN`, `THEORY`, `NUMERICS`, and `OUTPUT`. It has no `COMPUTE` dictionary or
CLI-selected science; the validated default resolves to CPU, float64 metadata,
and deterministic execution, while the scientific path uses exact rational and
exact-log arithmetic.

## Configuration dictionaries

| Dictionary | Fields | Meaning |
|---|---|---|
| `RUN` | `name`, `seed` | Human-readable run identity and the root seed for four named RNG streams. |
| `THEORY` (`finite_exact`, `gaussian_realization`) | `experiment`, `retained_interaction_order` | Selects the foundation laboratory and the retained finite interaction order where applicable. |
| `THEORY` (`attention_marked_event`) | `experiment`, `fixture` | Selects the frozen `nested_nonuniform_v1` marked-event fixture. |
| `THEORY` (`categorical_dqm`) | `experiment`, `fixture`, `theta`, `finite_difference_step`, `dqm_step_sizes` | Selects the frozen positive categorical family, parameter, centered-difference step, and two-sided DQM diagnostic ladder. |
| `THEORY` (six-session buildout) | Experiment-specific fields frozen in `docs/superpowers/specs/2026-08-09-six-session-laboratory-contract.md` | Selects one of `multiagent_network`, `theory_oracle`, `finite_counterexample`, `information_history`, `gauge_holonomy`, `scale_cocycle`, or `gaussian_fixed_ray`. |
| `THEORY` (`categorical_falsification`) | `experiment`, `fixture`, `admitted_family`, `null_control_seeds`, `descent_restarts`, `arithmetic` | Selects the frozen `two_channel_z3_v1` six-agent system and the admitted parent family, which decides whether a nontrivial holonomy empties the fixed sector or leaves the distortion score finite. |
| `THEORY` (`renormalization_v2_gauge_plaquette`) | `experiment`, `fixture`, `arithmetic` | Selects one of the three frozen Phase 6 plaquette fixtures with `arithmetic="exact_rational"`. |
| `THEORY` (`renormalization_v2_gauge_blocking`) | `experiment`, `fixture`, `arithmetic` | Selects one of the flat or non-flat Phase 7 `S3` hard-blocking fixtures with `arithmetic="exact_rational"`. |
| `NUMERICS` | `dtype`, `atol`, `rtol`, `min_spd_rcond`, `max_frame_condition` | Declares floating-point precision, comparison tolerances, and explicit Gaussian conditioning gates. |
| `OUTPUT` | `root`, `collect_diagnostics`, `render_figures` | Selects the artifact root and independently toggles diagnostic arrays and post-finalization rendering. |
| `COMPUTE` (Session 6 only) | Frozen backend, dtype, device, determinism, worker, and heavy-sweep fields | Keeps ordinary CPU execution separate from the gated CUDA worker protocol. |

Configuration validation is strict: missing or unknown keys, unsupported
types, invalid tolerances, and incompatible experiment selections fail before
the RNG or filesystem is touched. Only `float64` is admitted in this first
release.

## Artifact contract

A numerical run is written to:

```text
<root>/<sanitized-run-name>/<config-sha256>-<seed>/
    config.json
    manifest.json
    metrics.json
    arrays.npz or one or more named numeric archives
    diagnostics.npz       # experiment-specific and optional
    additional JSON records declared by the experiment contract
```

The resolved configuration is content-addressed. Files are written through
same-directory temporary files and atomically replaced, the manifest becomes
complete only after its exact inventory is validated, and a complete run is
never silently overwritten. Rendering happens only after numerical
finalization and publishes to a sibling figure directory. A renderer failure
cannot change the numerical result or its bytes.

`render_figures=True` creates the requested PDF/300-DPI PNG pair automatically
where the launcher exposes inline rendering. For a later pure replay, edit
`REPLAY` in `make_figures.py` to point at a finalized run. Replays use only
saved `metrics.json` and the complete numeric archives listed in the manifest;
they do not recompute the experiment. The shared renderer supports the seven
new diagnostic figures `multiagent_network`, `theory_oracles`,
`finite_counterexamples`, `information_history`, `gauge_holonomy`,
`scale_cocycle`, and `gaussian_fixed_ray`.

## What is checked

The finite launcher exercises implementation checks for:

- evidence-mass preservation under a common Markov channel;
- the finite VFE channel chain rule, including structured support violations;
- the fixed-outside local-to-collective VFE difference;
- Fisher loss as conditional score covariance;
- exact full-interaction reconstruction and pairwise-retention counterexamples;
- coherent componentwise finite relabeling and a deliberately mismatched
  negative control.

The Gaussian launcher exercises implementation checks for:

- the distinction between Galerkin restriction and Schur marginalization;
- scalar and matrix-valued Schur-complement literal oracles;
- an unrestricted-Kron nonclosure witness;
- inverse-congruence energy, determinant, log-determinant, generalized-spectrum,
  eigenpair, and metric-orthogonality identities;
- the noninvariance of ordinary Laplacian eigenvalues under nonorthogonal local
  frame changes;
- SPD, reciprocal-condition, positive-orientation, and frame-condition gates.

The attention launcher exercises implementation checks for:

- exact marked-event factorization and normalization, including inactive-row
  representatives;
- direct-versus-staged state and node pushforward of `eta`, followed by
  disintegration into `alpha` and active-row `beta`;
- independently pinned rational values and reverse state bridges;
- coherent local `GL+(2)` recomputation and finite node relabeling; and
- broken-link, incoherent-relabeling, and beta-only controls that remain
  detectably separated from the exact construction.

The categorical DQM launcher exercises implementation checks for:

- probability normalization, score centering, and analytic-versus-centered-FD
  fine scores;
- the positive/negative normalized square-root likelihood remainder ladder;
- conditional-expectation coarse scores versus independently pushed FD scores;
- Fisher loss as expected conditional score covariance, including positive
  loss and PSD checks; and
- literal rational oracles plus an intentionally wrong unweighted-score
  control at the default parameter.

The six-session buildout additionally checks exact application tuples,
independent rational oracles, minimal finite counterexamples, Fisher-metric
history lengths and semiconjugacy defects, graph-link holonomy and operational
marked-event laws, exact nonautonomous scale composition, and a bounded
Gaussian fixed-ray CPU pilot. Each laboratory preserves separate
`theorem_status`, `verification_state`, and `claim_origin` fields. The fixed-ray
CUDA parity metric remains `INCONCLUSIVE`; no CPU result is presented as CUDA
evidence.

The Phase 7 launcher checks one fixed gauge-aware coarse-graining step. It
retains a lossless directed multigraph, five fixed root/tree presentations,
complete loop holonomies, distinct self/parallel/reciprocal coarse edges, and
an exact conditional structural wrapper around an ordinary 729-state,
64-observation two-parent marginal. The same deterministic channel pushes the
fine generative, recognition, and posterior laws; exact event rows and all 64
parent inference/update rows roundtrip. Each finalized run has nine semantic
artifacts, eleven files, 41 `CANDIDATE` metrics, 35 numeric arrays, and 19
acceptance counters. Independent artifact-only replay reconstructs these values
from the embedded raw Phase 7, Phase 6, and Phase 5 texts while production
science and publication seams raise.

The preregistered status and falsification rules for every named metric are in
`docs/hypotheses.md`. The foundation record remains in
`docs/results/2026-08-09-foundation-results.md`; the attention/DQM results and
current full-suite evidence are in
`docs/results/2026-08-09-attention-categorical-dqm-results.md`. The seven new
lane records and the serial-integration summary are indexed by
`docs/results/2026-08-10-six-session-integration-results.md`.

## Theory and evidence boundary

`Theory/` began as a byte-matched snapshot of the Research-vault
`manuscripts/gauge_vfe_rg` source used to type the implementation. It may also
receive explicitly authorized in-repository amendments; those amendments and
the original revision, dirty-source caveat, and aggregate digest are recorded
in `docs/theory-provenance.md`. For the 2026-08-22 Part II remediation,
`MultiAgentELBO/Theory` is the active authority and the Research vault was not
modified.

Passing tests establish that this code reproduces the declared deterministic
finite fixtures and metamorphic identities. The categorical family's DQM status
comes from its finite-support smooth-positive Taylor derivation; the remainder
ladder only corroborates that implementation numerically. These checks do not
establish DQM for an arbitrary family, infer parameter-independence of an
unexamined channel family, make beta-only coarsening associative, show that an
external system belongs to the Gaussian or marked-event fixtures, or establish
RG attraction/universality. The holonomy laboratory establishes only its
declared finite graph-link identities and operational fixture. Continuum
limits, continuum connections, empirical partition selection, and universality
studies remain later milestones.

Phase 7 is narrower still: its partition, roots, and trees are fixed inputs;
discarded fine vertex frames are not recovered, and chain order is not
causality. It adds no ELBO sector. It establishes no learned partition,
repeated RG flow, fixed point or fixed ray, continuum or topology result,
confinement, matter backreaction, active inference, parent autonomy, GPU
result, or Research-vault update. Phase 8 begins only as a separate adaptive-
partition design.

## Repository map

```text
src/multiagent_elbo/finite/                 exact finite probability layer
src/multiagent_elbo/geometry/               finite relabeling metamorphics
src/multiagent_elbo/realizations/gaussian/  Gaussian-only adapter
src/multiagent_elbo/figures.py              pure saved-artifact renderer
Theory/                                     versioned theory source and authorized amendments
tests/                                      literal, boundary, and integration checks
docs/                                       design, plan, hypotheses, results, evidence
```

Select the permitted focused tests named by the current task or runbook.
For exact RG v2 checks, use the pinned CPython 3.14.7 runtime and its
documented no-collection wrapper; the [deprecation audit](docs/audits/2026-09-07-deprecation-audit.md)
records this cleanup's focused packet. An unrestricted pytest invocation
collects historical producer/publication and user-excluded tamper tests,
so it is not a current regression command.

The test totals below are the historical post-reconciliation record,
not a current whole-repository pass. Retained evidence-tool checks may
require their declared CPU and hash-seed environment; isolated Python
ignores PYTHONHASHSEED, so those checks require their own documented driver.

The post-reconciliation integration JUnit record contains 698 collected tests: 696
passed, zero failed, zero errored, and two were skipped for the Windows symlink
privilege described below. CUDA parity and the heavy confirmatory sweep are not
part of this CPU count.

Two Windows-only symlink regressions are skipped when the current account lacks
the privilege needed to create test symlinks: one numerical-artifact ownership
case and one figure-publication escape case. The executed hard-link tests and
the static reparse-point checks still protect the ownership boundaries; both
skips are reported explicitly rather than counted as exercised evidence.
