# Renormalization v2 Roadmap

**Date:** 2026-08-22

**Status:** Approved architectural roadmap

**Scope:** Vertical graph renormalization in the fiber over one fixed contextual point \(c_*\)

**Current implementation baseline:** RG-v2 Phases 1–12 are merged. Phase 13 is
an **operator-accepted closeout; automated publication certification
incomplete**. The clean publication candidate is
`089b186f3a6dc97d909f9a09fda0f3ca5c456608`; a matching
`.verification/phase13/evidence-envelope.json` remains required only for
automated publication certification, not for the recorded operator acceptance.
The Phase 14 sector-quotient design is approved and its task-level
implementation plan is written; no Phase 14 implementation has begun.

## Goal

RG v2 is intended to construct and test the renormalization of a finite directed agent network above a fixed point \(c_*\in\mathcal C\). Each microscopic agent carries a belief law, a model law, and gauge-frame data. Directed interaction records carry statistical weights and gauge transport. Coarse graining must produce ordinary parent agents while retaining every statistical or gauge variable needed for exact recursion.

The target is not merely a hierarchy of stochastic channels. It is a hierarchy of normalized gauge–matter probability models whose graph structure, edge-event laws, transported matter, holonomy, partition variables, and retained boundary marks compose across scale.

This document fixes the dependency order. Each phase after Phase 6 requires its own approved design specification and implementation plan before code changes begin.

## Authority and present boundary

The corrected `Theory/` tree and `docs/STATUS.md` govern mathematical claims. The existing RG-v2 implementation remains the finite executable oracle:

| Completed phase | Established executable content | Explicit boundary |
|---|---|---|
| Phase 1 | Exact finite population law, inference, and one recognition-independent aggregate channel | The terminal aggregate is not yet a recursive parent agent |
| Phase 2 | Exact static reconstruction of two recursive parents with all-observation Bayesian updates | Blocks, parent order, channels, and access are declared rather than selected |
| Phase 3 | Exact direct-versus-staged conditional structured composition, including a commuting fixture and a typed obstruction | No adaptive membership, edge-event-law recursion, gauge/holonomy marks, autonomous flow, or fixed point |
| Phase 4 | Exact nonabelian finite-group/action, ordered-link, holonomy, and cross-bundle kinematics | One fixed principal link field; no directed gauge-matter event law or separate channel-link closure |
| Phase 5 | Exact three-agent directed gauge-matter population, fixed channel links, event-law disintegration, transported KL, and population VFE | Fixed external links and `composite_not_elbo` diagnostic; no random-link, plaquette, blocking, RG-flow, or continuum claim |
| Phase 6 | Exact six-link Gibbs-Haar plaquette sector, Phase 5 conditional matter coupling, collapsed evidence, and complete finite negative ELBO | Two declared faces only; no complete cycle basis, matter backreaction, blocking, RG flow, continuum, or GPU claim |

Phase 3 is therefore the composition harness that later phases will enrich. It is not the full RG state.

## Microscopic geometric declaration

Let \(\mathscr P_G\to\mathcal C\) be one principal bundle with compact gauge group \(G\). At fixed \(c_*\), the common-frame baseline assigns agent \(i\) one principal frame

\[
u_i\in (\mathscr P_G)_{c_*}.
\]

Belief and model matter live in two associated law bundles,

\[
\mathcal E_q=\mathscr P_G\times_{\widehat\rho_q}\mathcal B_q,
\qquad
\mathcal E_m=\mathscr P_G\times_{\widehat\rho_m}\mathcal B_m.
\]

The common frame is one shared choice of principal-bundle trivialization. It does **not** imply \(\rho_q=\rho_m\). Under one vertex gauge change \(g_i\in G\), the belief and model coordinates transform through their own actions,

\[
q_i\mapsto\widehat\rho_q(g_i)q_i,
\qquad
m_i\mapsto\widehat\rho_m(g_i)m_i.
\]

Thus one principal frame can induce different coordinate transformations in two different associated fibers. Equality or equivalence of \(\rho_q\) and \(\rho_m\) is a stronger optional control, not part of the common-frame definition.

The local gauge symmetry is the diagonal action of this single \(G\), not a \(G\times G\) symmetry. Separate belief/model representations, connections, or channel-link assignments do not create a second principal bundle: they remain structures associated with the same \(\mathscr P_G\).

The following assumptions remain independently typed throughout RG v2:

- common belief/model principal frame;
- equal or inequivalent belief/model representations;
- equal or distinct belief/model connections;
- one shared principal edge link or two separately declared channel links.

No phase may infer one of these assumptions from another.

## Cross-bundle maps

The general theory admits extra fiber-preserving maps

\[
\Phi_{qm}:\mathcal E_q\longrightarrow\mathcal E_m,
\qquad
\Phi_{mq}:\mathcal E_m\longrightarrow\mathcal E_q.
\]

For deterministic fiber maps \(\phi_{qm}\) and \(\phi_{mq}\), gauge compatibility is the intertwining condition

\[
\phi_{qm}\circ\widehat\rho_q(g)
=\widehat\rho_m(g)\circ\phi_{qm},
\qquad
\phi_{mq}\circ\widehat\rho_m(g)
=\widehat\rho_q(g)\circ\phi_{mq}.
\]

Calling these maps intertwiners is exact when they are deterministic linear or measurable equivariant fiber maps. For probability-law fibers, an equivariant Markov kernel is more general and is the preferred laboratory interface. The two cross maps are extra structure: they are not transports, are not automatically invertible, and are not assumed to be mutual inverses.

Only fiberwise and algebraic cross-scale defects are admitted in the fixed-\(c_*\) program. Horizontal-derivative defects require neighborhoods in \(\mathcal C\), chosen connections, and base tangent or curve data; those belong to the later sections-over-\(\mathcal C\) program.

## Target scale state

At RG depth \(\ell\), the target structural state is

\[
\mathsf Y_\ell=(Z_\ell,G_\ell),
\qquad
G_\ell=(\eta_\ell,\Omega_\ell^q,\Omega_\ell^m,\mathsf h_\ell).
\]

Here \(Z_\ell\) contains the normalized belief/model population presentation and its generative and recognition laws; \(\eta_\ell=(\eta_\ell^q,\eta_\ell^m)\) contains the directed edge-event laws; \(\Omega_\ell^q,\Omega_\ell^m\) are the channel transports induced by the declared principal links; and \(\mathsf h_\ell\) contains roots, based holonomies, loop provenance, and dressed boundary marks.

For receiver \(i\) and source \(j\), the recursive graph primitives are

\[
\alpha_i^{x,\ell}=\sum_j\eta_{ij}^{x,\ell},
\qquad
\beta_{ij}^{\ell}=\frac{\eta_{ij}^{q,\ell}}{\alpha_i^{q,\ell}},
\qquad
\gamma_{ij}^{\ell}=\frac{\eta_{ij}^{m,\ell}}{\alpha_i^{m,\ell}},
\]

on positive rows. The \(\beta\) and \(\gamma\) rows weight transported belief and model discrepancies. They are not group-valued links and are not sufficient recursive state: coarse graining pushes \(\eta\), then redisintegrates the normalized rows.

## Laboratory gauge-group ladder

RG v2 will use a nonabelian compact group as its flagship laboratory while retaining the current abelian setting as a control:

\[
Z_3\ \text{control}
\longrightarrow S_3
\longrightarrow D_4
\longrightarrow SU(2)
\longrightarrow SO(3)\ \text{quotient control}.
\]

### \(Z_3\): abelian regression control

The \(Z_3\) fixtures preserve exact-rational baselines and isolate failures unrelated to noncommutativity. They cannot test multiplication order, commutators, conjugacy-class retention, or genuinely nonabelian Wilson loops. RG v2 will no longer describe \(Z_3\) as its primary gauge laboratory.

### \(S_3\): first flagship nonabelian laboratory

\(S_3\) is the smallest nonabelian group. Its six elements, uniform counting Haar measure, exact multiplication and inversion tables, and three conjugacy classes permit complete exact enumeration while making path-order errors observable.

The first cross-bundle fixture will use the natural three-point \(S_3\)-set for belief matter and the six ordered pairs \((a,b)\), \(a\ne b\), for model matter. The belief-to-model kernel lifts \(a\) uniformly to the two pairs beginning with \(a\); the model-to-belief kernel projects \((a,b)\) back to \(a\). Projection after lift is the identity, while lift after projection is a conditional-uniform projector. This provides exact equivariant stochastic cross maps without falsely making them inverses.

The nonabelian graph fixture must contain at least two based loop generators with noncommuting holonomies. A single nonidentity plaquette is insufficient to test nonabelian composition.

### Later rungs

\(D_4\) adds central flux, faithful real two-dimensional matrices, and inequivalent vertex/edge actions. \(SU(2)\) is the first continuous compact target once finite-group semantics are stable. \(SO(3)\) then acts as the center-blind quotient control. \(Q_8\) may be used as an adversarial representation-type fixture, but it is not on the critical path.

## Dependency chain

\[
\begin{aligned}
&\text{normalized two-channel matter laws and shared principal frame}\\
&\quad\longrightarrow\text{cross maps and independent ordered graph links}\\
&\quad\longrightarrow\text{transported discrepancies, rooted holonomy, and }\eta\\
&\quad\longrightarrow\text{plaquette law and curvature action}\\
&\quad\longrightarrow\text{normalized partition and membership model}\\
&\quad\longrightarrow\text{quotient graph and complete parent datum}\\
&\quad\longrightarrow\text{augmented direct-versus-staged composition}\\
&\quad\longrightarrow\text{comparison/rescaling maps and typed invariant structures}.
\end{aligned}
\]

Later work must not attach plaquette, partition, or fixed-point claims directly to Phase 3's terminal labels. The state alphabet must first be enriched to \(\mathsf Y_\ell\).

## Phase 4 — Exact nonabelian gauge kinematics and cross-bundle maps

**Status.** Implementation-complete at reproducible science/code revision
`faca00e272cbf3c2d83ea550e25b02f6cf4cfb50`; the documentation closure and
release evidence are separate local work. A pre-existing Phase 3 checkout-byte
mismatch under `core.autocrlf=true` was corrected through the documented LF
attribute rule without changing a fixture blob, science file, or hash constant.
The subsequent focused and broad CPU gates passed. Phase 7 and later remain
open.
**Purpose.** Replace the cyclic-only gauge assumptions with an exact group-generic finite contract at fixed \(c_*\).

**Planning packet.** The source review, design specification, and implementation plan are recorded in:

- `docs/reviews/2026-08-22-rg-v2-phase4-theory-planning-review.md`;
- `docs/superpowers/specs/2026-08-22-rg-v2-phase4-exact-nonabelian-gauge-kinematics-design.md`; and
- `docs/superpowers/plans/2026-08-22-rg-v2-phase4-exact-nonabelian-gauge-kinematics.md`.

The binding design remains frozen at Git-blob SHA-256
`6617a82cc640823595f15f611e670c95caa8526c7b7998612d4aa5e648b98b6e`.
Its original planning status is historical; this roadmap records the completed
implementation without modifying that design artifact.

**Required construction.** Define finite-group multiplication, identity, inverse, conjugation, conjugacy classes, ordered path products, endpoint gauge transformations, based loop words, and group actions on belief and model law fibers. Distinguish each sample-space Markov kernel \(K_{qm},K_{mq}\) from its induced affine law map \(\Phi_{qm}(q)=qK_{qm}\), \(\Phi_{mq}(m)=mK_{mq}\). Add deterministic and stochastic equivariance contracts at both levels. Use a shared principal frame while testing both equal and inequivalent associated actions. The Phase 4 fixtures declare one shared principal link field explicitly; that declaration is not inferred from the common frame. Separately declared channel links remain a Phase 5 obligation.

The passive convention is normative:

\[
\Theta_e'=a_{t(e)}^{-1}\Theta_ea_{s(e)}.
\]

The active symbols are aliases through \(g_i=a_i^{-1}\). Phase 4 must declare one serialized traversal convention and independently reconstruct its endpoint covariance. Reverse orientation is represented by an explicit inverse edge in the same interaction orbit; an independent antiparallel interaction belongs to a different orbit and has its own inverse copy.

**Flagship fixtures.** Preserve a flat \(Z_3\) control. Add the exact \(S_3\) cross-kernel fixture above, a nontrivial equal-action flat pure-gauge \(S_3\) control, and an inequivalent-action non-flat fixture with two noncommuting based holonomies. The two cross kernels must exhibit the exact one-sided split \(K_{qm}K_{mq}=I_3\), \(J=K_{mq}K_{qm}\ne I_6\), and \(J^2=J\), together with explicit collision and non-surjectivity witnesses.

**Exit gate.** Group axioms and both associated action laws are exhaustively reconstructed. Exact path ordering, reverse-path inversion, endpoint covariance, interaction-orbit identity, simultaneous root conjugation, stochastic-kernel normalization and equivariance, induced-law equivariance, and the one-sided cross-map split are independently reconstructed from serialized primitive data. The raw ordered tuple of based holonomies and its loop provenance remain available modulo one simultaneous root conjugation; separate conjugacy-class labels do not replace that datum. The shared-link fixture assumption is explicit and creates no claim about the channel-specific-link closure deferred to Phase 5.

## Phase 5 — Full microscopic directed gauge–matter network

**Purpose.** Construct the normalized microscopic network on which RG will act.

**Status.** Scientific implementation completed at revision
`d029ade432e92b8857d723a9137c3d65a7060d8d`; release-gate-only LF and BLAS
stabilization prerequisites bring the final pre-documentation tree to
`31c2749bbfd413b232db120a5f59256665c1d164`. All three admitted fixtures
close their declared finite implementation checks with exact 729-state,
64-observation laws and exhaustive assignment counts `27, 216, 216`. The
publication boundary contains nine semantic artifacts, 21 ordered candidate
metrics, and eleven finalized files. This status does not implement Phase 6.

**Planning packet.** The approved specification and implementation plan are:

- `docs/superpowers/specs/2026-08-23-rg-v2-phase5-full-microscopic-directed-gauge-matter-network-design.md`; and
- `docs/superpowers/plans/2026-08-23-rg-v2-phase5-full-microscopic-directed-gauge-matter-network.md`.

The approved specification SHA-256 is
`60be88a0c881879b89b88ee39b06847eac1b8e843990d023ab4f895bbb6e69c6`.

**Required construction.** Keep the topologically ordered generative DAG separate from the generally bidirected interaction complex. Declare oriented edge copies, belief/model transports, transported divergences, edge-event laws \(\eta^q,\eta^m\), and their derived \(\alpha,\beta,\gamma\) rows. The common-frame flagship may initially use one principal link represented through \(\rho_q\) and \(\rho_m\), but a distinct-channel-link fixture is required before closure.

The phase must specify one normalized generative law and one normalized recognition law before decomposing the objective into self, edge, and record terms. Fixed links remain external structural inputs in this phase.

**Exit gate.** Completed for the declared \(Z_3\) and \(S_3\) fixtures:
full-law gauge covariance, whole-coupling selector equivariance, evidence and
transported-divergence invariance, exact link-independent event-law
disintegration, independent antiparallel semantic arcs, derived event-free
formal inverses, and the distinction between fixed channel links and event-law
weights all pass. The exact normalized population VFE remains separate from
the transported-KL diagnostic classified as `composite_not_elbo`. Artifact
replay is independently anchored to literal fixture text, while every
published metric remains `CANDIDATE`.

## Phase 6 — Plaquette sector and normalized random-link model

**Status.** Scientific implementation is complete at final pre-documentation
revision `673eb5e5d27fbb0c46088c82c5f9708b7d0d9cf0`. The Z3 control enumerates
729 link configurations; both S3 fixtures enumerate 46,656. Their exact
counting/Haar partitions are `(729,1)`, `(46656,1)`, and
`(156816,121/36)`. All three declared implementation checks report `pass`.
The publication boundary contains nine semantic artifacts, 23 ordered
`CANDIDATE` metrics, and eleven finalized files, with exact serial/two-/four-
worker parity and test-owned artifact-only replay.

**Planning packet.** The approved specification and implementation plan are:

- `docs/superpowers/specs/2026-08-24-rg-v2-phase6-latent-links-plaquette-action-design.md`; and
- `docs/superpowers/plans/2026-08-24-rg-v2-phase6-latent-links-plaquette-action.md`.

The approved specification committed-Git-blob SHA-256 is
`6146e196218798705135cf24c1793a0f12926d569fe7e79f7732fb94179bc3b8`;
the approved plan SHA-256 is
`1168a53ba8b39de99ae72b89d13874bbf4195abeaa9127590b53f09c2050433f`.

**Purpose.** Give graph curvature its own typed action without retrofitting an unnormalized penalty into the fixed-link ELBO.

For a declared oriented 2-cell \(p\), define the ordered holonomy

\[
H_p=\prod_{e\in\partial p}^{\longrightarrow}\Theta_e.
\]

Finite-group experiments will use positive rational weights on conjugacy classes and uniform counting Haar measure,

\[
P(\Theta)\propto\prod_p w_p([H_p]).
\]

This preserves exact arithmetic. The continuous-group tier may later use character/Wilson actions. The plaquette representation is declared separately from either matter representation.

Links become latent variables in a normalized Gibbs–Haar generative model. Its partition function, recognition law over links, and link-law entropy must be present before the plaquette action is classified as an exact negative-ELBO component. The fixed-link Wilson term remains an explicitly effective diagnostic branch.

**Exit gate.** Completed for the declared finite fixtures: exact S3
partition-function enumeration, local gauge covariance, conjugacy-class
invariance, identity and nonidentity controls, orientation reversal, Phase 5
conditional normalization, collapsed evidence, and the plaquette-action
contribution to the complete negative ELBO are reconstructed independently.
The two faces do not establish a complete graph-cycle basis or whole-graph
flatness.

## Phase 7 — Gauge-aware hard blocking and parent reconstruction

**Status.** Scientific implementation is complete at reviewed pre-documentation
revision `8e1a79d03f06a674b3a43d96f3dcc127e7b95654`. The exact fixed
partition is `A=(a,b), B=(c)`. Five fixed root/tree presentations retain the
complete loop bases and every directed self, parallel, reciprocal, and boundary
edge. The common deterministic channel reconstructs an ordinary 729-state,
64-observation parent marginal plus an exact conditional structural wrapper.
Both declared fixtures report `pass`; every one of the 41 published metrics
remains `CANDIDATE`.

**Planning packet.** The approved specification and implementation plan are:

- `docs/superpowers/specs/2026-08-24-rg-v2-phase7-gauge-aware-hard-blocking-parent-reconstruction-design.md`; and
- `docs/superpowers/plans/2026-08-24-rg-v2-phase7-gauge-aware-hard-blocking-parent-reconstruction.md`.

Their physical SHA-256 values are
`2d1892e9bd2f3936e8f407bf1c905ea647cca96cae4853b136690272e054047d`
and `e1748e2b93a247a19ed34c872884e8ad7963422c1f8fa30b3db08f5d78cc1e08`.

**Purpose.** Establish one complete gauge-aware RG step with a declared deterministic partition before learning the partition.

**Required construction.** Choose a root and spanning tree inside every block. Retain non-tree loop generators, their based holonomies, and the joint distribution of dressed boundary links. Push the raw event laws through the hard membership map, then recover parent \(\alpha,\beta,\gamma\). Reconstruct the parent belief/model law, evaluator, recognition interface, and update rule as ordinary agent data.

A non-flat family of boundary links must not be averaged into one coarse transport unless the resulting residual is explicitly retained. Parallel coarse edges and both directions of a reciprocal interaction remain distinct records.

**Exit gate.** Completed for the two declared finite `S3` fixtures. The flat
fixture has 36 orbit configurations, 6 structural marks, and 6 configurations
per mark; the non-flat fixture has 216, 36, and 6. Event mass is conserved,
internal holonomy and the lossless directed multigraph are retained, boundary
transports obey the parent gauge law, 7,776/46,656 configuration-assignment
checks close exactly, and the coarse parent passes all 64 inference/update
rows. Each publication contains nine semantic artifacts, eleven files, 35
numeric arrays, and 19 acceptance counters. Artifact-only replay is independent
of production science.

The partition, roots, and trees remain fixed. Discarded fine vertex frames are
not recovered, chain order is not causality, and Phase 7 adds no ELBO sector.
No learned partition, repeated flow, fixed point or ray, continuum, topology,
confinement, matter backreaction, active inference, parent autonomy, GPU
result, or Research-vault write is claimed.

## Phase 8 — Adaptive normalized partition and membership

**Purpose.** Promote the hierarchy from declared blocks to a normalized latent structural choice.

**Required construction.** Put the partition variable \(R_\ell\) inside both generative and recognition laws. Use a normalized membership kernel \(m_\ell(I\mid i,R_\ell)\), or a normalized joint endpoint kernel \(M_\ell(I,J\mid i,j,R_\ell)\) when assignments are correlated. Product endpoint membership is allowed only under a declared conditional-independence assumption.

The partition energy may combine transported matter mismatch, boundary event mass, and the plaquette sector established in Phase 6. A Gibbs partition free energy is classified as exact only when its normalized factor is part of the generative law. Hard blocking from Phase 7 remains the deterministic control.

**Exit gate.** Membership normalizes, edge-event mass pushes without replication, correlated endpoint assignments are distinguished from product assignments, the inferred partition is gauge invariant, and one persistent nested-partition fixture composes across two levels.

## Phase 9 — Full augmented structural composition

**Purpose.** Lift Phase 3's composition harness from bare declared channels to the complete decorated RG state.

The recognition-independent structural arrow is

\[
C^{\mathrm{struct},c_*}_{\ell+1\leftarrow\ell}:
\mathsf Y_\ell\rightsquigarrow
\mathsf R_\ell\times\mathsf Y_{\ell+1}.
\]

It is applied identically to the generative, posterior, and recognition laws. Direct and staged routes integrate the intermediate partition, event laws, roots, holonomies, dressed boundaries, and terminal presentations. Equality is tested up to the declared terminal gauge isomorphism and simultaneous conjugation, not by literal frame equality.

**Exit gate.** One commuting full-state fixture and a small family of single-seam obstructions identify the first failure among membership, event-law pushforward, link composition, holonomy retention, terminal presentation, recognition, evidence, posterior, update, and conditional-KL composition.

**Status.** Implemented and remediated through packet-producing commit `a4602d8026025a145bb5b1326e8bb963caac38d2`. The retained non-flat (S_3) fixture closes all ten ordered boundaries after the declared nonidentity `c012` terminal reframing. Ten typed single-seam controls localize to the corresponding first boundary. Artifact-only replay reconstructs the raw finite fixture, sparse direct and staged routes, gauge transport, Bayesian interfaces, conditional-KL diagnostics, packet DAG, metrics, and arrays without importing a Phase 9 production module. It reports `commuting`, ten zero boundary counts, and 14,052 executed operations; the ten mutation runs total 137,465 operations. The fast tier contains sixteen subsecond CPU tests and completes in 2.348 seconds. Fourteen nonoverlapping integration targets and nine named predecessor regressions pass; already-passing integration nodes were not repeated after the final fixture-only hardening edit. These results close only the declared finite implementation gate; the thirteen public metrics remain `CANDIDATE`.

## Phase 10 — Repeated scales, comparison maps, and invariant structures

**Purpose.** Turn a sequence of coarse arrows into a correctly typed RG system.

Reference identifications \(I_\ell\), unit conventions, field rescalings, and comparison measures must be declared before maps between different scale spaces are treated as endomorphisms of one common space. The resulting system is then classified as autonomous, periodic, stationary random, or a general cocycle.

Ordinary fixed points are sought only in a proved autonomous family. Periodic systems use monodromy; nonautonomous systems use invariant sections; fixed rays require a declared positive cone and projectivization. Ratio- or architecture-specific maps remain labeled by those dependencies.

**Exit gate.** At least three compatible RG depths, more than one graph size or topology, explicit identification maps, finite-size controls, and a mechanically demonstrated composition law precede any fixed-point, exponent, relevant-direction, universality, or continuum claim.

**Status.** The finite Phase 10 implementation and independent artifact oracle
are accepted and published through PR #35 merge
`60d6e516912e2799f14ae5d3f4ab6958b55150b0`; the definitive code revision is
`32a54a4165280ada3c0453e305a4ca0b3b46957d`. Five four-level controls span the
nonflat cycle and diamond families: three exact autonomous controls with unique
stationary-law certificates, one minimal period-two control with right-acting
monodromy and transported two-cycle, and one general control with only a
compatible finite section. A stationary-random request without its required
probability base, shift, and kernel map is rejected. Independent adjacent and
skip augmented kernels satisfy exact history-preserving composition and
separately derived marginal composition; the three law families push through
both routes. The matched cycle pair evaluates one shared affine finite-size
rule at initial counts 24 and 48 without an asymptotic claim.

The exact action boundary is
`abstract_parity_endpoint_holonomy_physical_without_tree_transport_covariance_v1`.
The four-state `S3` action factors through parity and certifies abstract
comparison/kernel naturality. Physical checks cover only
`rooted_coarse_links[chord_indices]`,
`dressed_boundary_links[chord_indices]`, and based holonomies. They do not
cover tree transports, tree-edge slots, tree-parent coordinates, or the full
Phase 9 payload. The definitive nine-file packet is 1,806,678 bytes, has
semantic digest
`af8ed49bc3a994fe19bc64cffb2d991498f1a9a37943e7fb7c66070897e82866`,
and uses 3,768 independent replay visits. All 17 metrics remain `CANDIDATE`.

The first final attempt at `c1cf253` correctly stopped after its 118-node fast
packet took 15.405 JUnit seconds, above the 12.0-second gate; the predecessor
packet was not run. Independent debugger and performance reviews agreed that
each negative provenance case unnecessarily paid the complete 17,616-visit
science cost. Commit `32a54a4` moved that rejection before fixture/science
work. On that code revision, Task 6 passed 10/10 in 11.567 seconds, Task 7
passed 8/8 in 17.028 seconds, the twelve-worker `--dist=worksteal` fast tier
passed its now-complete 118/118 selection in 11.758 seconds, and the bounded
predecessor packet passed 25/25 in 2.508 seconds. The narrow final runtime
review passed. Final static closure at `81ce0aa` also passed the corrected
26-path branch allowlist, 18-file Python parse, strict fixture/artifact,
protected-blob, action-scope, NPZ, import-boundary, and documentation gates.
The 36-commit feature tip `01d65156663ecc2eb8c88545d3eb0257a62642ba`
was pushed in full, merged by PR #35, and verified as an ancestor of remote
`main`. The canonical Desktop checkout was rehearsed and then fast-forwarded
to the merge commit with all 20 pre-existing WIP records and four untracked
PDF content hashes unchanged.

This phase does not establish automatic hierarchy formation, a canonical
comparison independent of fixture choices, arbitrary or infinite towers,
attraction, critical exponents, relevant directions, universality,
thermodynamic or continuum limits, scale as physical time, a fixed ray, or a
physical action on the complete decorated state.

## Phase 11 — Finite-depth cocycle stability

**Purpose.** Measure finite-word organization and total-variation contraction
for declared exact stochastic coarse-state kernels without importing an
infinite-depth claim.

**Status.** Implemented, remediated, and reviewed at production-code revision
`911ca07de2df69a2902b5ff145559c8524953a82`; remote publication remains a
separate post-documentation step. The exact four-state, six-step fixture
classifies `fds_autonomous_contracting` as autonomous and strictly
contractive, `fds_period2_contracting` as minimal period two and strictly
contractive, `fds_general_contracting` as general and strictly contractive,
and `fds_permutation_nonattracting` as autonomous and noncontractive. The
first three controls contract from the first prefix. The deterministic
permutation control retains Dobrushin coefficient one at every prefix and
receives no attracting-law claim.

All 60 independently declared direct products equal their staged products,
all 144 `S3` intertwining squares close, exact RREF checks certify the
admitted stationary law and two-phase cycle, and the general control publishes
only a seven-law finite section. The finalized nine-file packet is 302,410
bytes, has semantic SHA-256
`4ff2ec0147bf79ab05ea61fba5ed5ac93d07042f0d181b131d49f3096a4fa64e`,
and was independently replayed from both its original and relocated roots.
All five tamper controls were rejected. The final serial publication packet
passed 12/12 in 3.343 JUnit seconds, the twelve-worker fast packet passed
75/75 in 3.865 JUnit seconds, and the twelve-worker predecessor packet passed
20/20 in 2.750 JUnit seconds. All 13 Phase 11 metrics remain `CANDIDATE`.

The result is conditional on explicitly supplied stochastic broadening; those
kernels are not derived from Phase 10. Its scope is exactly
`finite_window_only=True`, `maximum_level_ordinal=6`, and
`infinite_depth_claim=False`. It establishes no persistence beyond the
fixture window, asymptotic attraction, universality, continuum limit,
automatic or learned hierarchy, or GPU result.

## Phase 12 — Full-state \(D_4\) covariance

**Purpose.** Exhaustively test exact covariance of the complete two-step
decorated RG state, sparse structural kernels, ordered histories, and three
probability-law families on one declared finite support sector.

**Status.** Implemented, remediated, reviewed, and locally evidence-closed at
clean implementation revision
`a952c0fd82fc185f30e9a6fe86a9688ecdd78a4a`. The admitted all-incident sector
has 512 states; it is one of eight invariant sectors of the excluded
4096-state full vertex-edge carrier. The complete action is \(D_4^3\) on all
three levels. The \(D_4^2\) and \(D_4\) actions are induced only on
parent/root-coordinate subcarriers and do not replace the complete action.
The exact complete catalogs contain 512, 1024, and 512 states.

The two controls are `fsc_d4_nonflat_center_sensitive` and
`fsc_d4_flat_pure_gauge`. Both use the literal branch law
\(P(A0)=1/3\), \(P(A1)=2/3\), enumerate all 512 local assignments, and retain
1024 ordered histories per control. The positive program executes exactly
9,018,432 primitive visits. The embedded falsification catalog contains
14 scientific mutations.

Whole-branch review found that the original exact-law construction bound the
\(D_4\)-ordered catalog directly to the authored incident-flag ordinals.
Remediation now decodes every ordered level-zero state through the authored
incident table and validates the complete \(8^3\) support permutation before
evaluating the generative, posterior, and recognition laws. The serial
assessment fallback also passes its immutable context explicitly, removing a
thread race without changing the scientific comparisons or visit accounting.

The click-to-run CPU laboratory exposes only `RUN`, `THEORY`, `NUMERICS`, and
`OUTPUT`; it has no `COMPUTE` dictionary. Production and independent replay
use at most 12 Windows-spawned workers, the focused xdist packet uses four,
and nested science resolves to one. The maximum publication process tree is
14. The hard limits are 120 seconds for the producer, 90 seconds for one full
oracle replay, 300 seconds for all packet tampers, 600 seconds for the serial
publication node, and 180 seconds for focused tests. The separate 180-second
release target is reporting-only.

The finalized nine-file, eleven-array packet is 13,992,677 bytes and has
semantic SHA-256
`80954a9d170cb8d0108152d4711603feb0788bb6eb685538958d46e1515bda31`.
All 22 public metrics remain `CANDIDATE`. The independent oracle accepted
the pristine packet and a byte-identical relocated packet and rejected
eight packet-tamper cases, for ten total oracle executions. The serial
publication node passed 1/1 in 313.272 JUnit seconds, with measured workflow
time
312.1545913000009 seconds and JUnit SHA-256
`fdb811e668bc88d4d7837f7c077d80f72eb8de07a416489a4dbb94e69fee6fe9`.
The measured producer, pristine-oracle, relocated-oracle, and eight-tamper
stages took 103.41072590000113, 67.9982663999981, 67.1039116000029, and
73.56757820000348 seconds, respectively. It correctly recorded
`release_target_seconds=180` and `release_target_met=False`. The focused
packet passed 446/446 in 117.613 seconds with JUnit SHA-256
`c554e8a1c06e4e8f45c07dcaad87fb265d0b167fe2a44d0265f4ced9c2d2ba9e`;
the oracle nonpublication packet passed 39/39 in 10.965 seconds with JUnit
SHA-256
`3427fc17c327ef7b1019d0f81578161b104a155ca4a0d2721d350aabaf8ac0fa`;
the assessment packet passed 68/68 in 121.557 seconds with JUnit SHA-256
`9b324795dec65c539c980f4631528defa401a1c5d6e1ece5e4322c1161590ee9`;
the predecessor packet passed 35/35 in 14.274 seconds with JUnit SHA-256
`1a6479f0775d149ec7e9522342635963685987903c861168ebb7cb548283f2fd`.

The exact verdict is CPU-authoritative. CUDA availability is not evidentiary
for Phase 12. This phase does not establish the excluded 4096-state carrier,
arbitrary belief-model support, nonincident sectors, independent belief and
model principal gauge groups, independent channel link fields, a cross-bundle
isomorphism, gauge fixing, flatness, holonomy blindness, learned partition
discovery, hierarchy persistence, dynamics, Phase 11 stability, fixed points,
universality, relevant directions, infinite depth, thermodynamic or continuum
limits, `SU(2)`, `SO(3)`, physical time, or Gaussian covariance-tensor
results.

## Phase 13 — Complete-carrier \(D_4\) covariance

**Purpose.** Extend the Phase 12 finite certificate to the complete
4096-state \((V\times E)^3\) carrier while preserving Phase 12 unchanged.

**Status.** The finite conditional \(D_4^3\) complete-carrier covariance
certificate and its exact publication protocol are implemented. The carrier
is the declared direct sum of eight 512-state sectors, with level catalog sizes
4096, 8192, and 4096. The exact program covers both controls,
sector-diagonal sparse structural support, all 56 cross-sector zero blocks,
ordered histories, direct-versus-staged composition, global
generative/posterior/recognition laws, the conditional relative-entropy
identity, and an exact `III` projection to Phase 12. Sector preservation is a
fixture support condition; it is not derived from covariance.

> **2026-09-03 operator-accepted closeout override.** Phase 13 status is
> **operator-accepted closeout; automated publication certification
> incomplete**. This is an acceptance decision, not a proof or a
> machine-certified closure. The exact prepublication packet closed 350 unique
> tests green at `e16b92761def828233c9a8b0944c50355b11d9df`; the clean
> publication candidate is `089b186f3a6dc97d909f9a09fda0f3ca5c456608`.
> Producer and pristine artifact-only replay completed, but relocated replay
> stopped before a final JUnit, publication control, or evidence envelope;
> no tamper case started. Those missing artifacts make automated publication
> certification incomplete; they are not reclassified as user-excluded tamper
> artifacts. The acceptance record is
> `docs/verification/2026-09-03-phase13-operator-acceptance.md`.

> The global no-tamper policy supersedes older execution text: no direct or
> bundled tamper scenario may run. The historical all-in-one publication
> command is therefore non-executable. The older clean-HEAD 26-source map
> differs after this documentation amendment and supplies neither a fresh
> certification nor authority to rerun it. Existing runtime guards, scientific
> scope, and revision-bound evidence remain unchanged. Phase 14 is authorized
> for the roadmap's **Phase 14 DESIGN GATE** only; no Phase 14 implementation
> is authorized.

The 72,202,414-visit positive certificate and its canonical reducer remain
unchanged. For the 22 science mutations, the approved positive-receipt path
certifies 127,327,264 logical visits using 4,936 freshly executed incident
visits and 127,322,328 receipt-certified visits across 22 fresh shards and
22,506 reused positive receipts.

The scientific authority is CPU Python `int` and `Fraction` arithmetic.
On the Ryzen 9900X, the science pool is limited to 12 workers and the live
process tree to 14. CUDA is available but is not authoritative for this
certificate. Under the user-approved 2026-09-02 amendment, the historical
300-, 960-, 3,600-, 720-, 2,400-, 2,700-, and 4,800-second values are
reporting-only optimization targets. Authoritative producer, oracle, and
publication execution has no wall-clock deadline. Exact science visits,
worker/process limits, arithmetic, source revision, evidence integrity, and
the 134,217,728-byte packet cap remain fail-closed.

The ten-file packet contract is `config.json`, `fixture_snapshot.json`,
`d4_action_catalog.json`, `carrier_sector_catalog.json`,
`complete_carrier_routes.json`, `covariance_assessment.json`,
`composition_law_assessment.json`, `metrics.json`, `arrays.npz`, and
`manifest.json`. Publication status is revision-bound. A passing
`.verification/phase13/evidence-envelope.json` must match the exact clean
revision, source inventory, runtime, closed JUnit, publication control, packet,
and independent replays. Without that matching envelope, automated publication
certification is not claimed. Historical failed attempts and their preserved evidence are
recorded in the targeted-rerun runbook.
The approved lazy `multiagent_elbo.finite` import repair preserves the public
finite API while removing unnecessary eager native-import surface from the
exact Phase 13 path. It does not identify the native-crash root corruptor or
establish a cause for the historical `ad13a72` access violation.

The 2026-09-02 containment also retires every spawned executor after one gate
map and disables automatic cyclic GC for the full public runner. A later dump
proved that the `1a169a9` worker crashed earlier, while Windows `spawn` was
unpickling the Process object and before the initializer could run. The current
candidate therefore suspends GC at the earliest repository-controlled child
import while `_inheriting` is true, before initializer-argument reconstruction,
and fails closed if a real child reaches the initializer with GC enabled.
Ordinary parent imports and inline execution preserve their incoming state.
This closes the demonstrated collection window without identifying the
corrupting writer; a subsequent crash falsifies the containment.

The pre-2026-09-03 machine-certification protocol remains historical evidence
only. It is superseded for current action by the operator-accepted closeout
override above and must not be resumed to seek a fresh envelope.

Phase 13 does not establish sector superselection or mixing, canonical sector
weights, sector irreducibility, symmetry-derived sector conservation, Phase
11 stability on the enlarged carrier, arbitrary graph, group, carrier, or
depth, fixed points, universality, infinite volume, continuum behavior,
physical time, `SU(2)`, `SO(3)`, or a GPU certificate.

## Post-v2 horizons

The core roadmap remains vertical over fixed \(c_*\). A later sections-over-\(\mathcal C\) program may add neighborhood families, gluing, connection-compatible bundle maps, horizontal derivatives of the cross morphisms, and base coarse maps. Temporal transitions, slow feedback, active inference, Hamiltonian link dynamics, thermodynamic limits, and continuum limits are separate extensions. None is inferred from completion of the finite vertical roadmap.

## Implementation and evidence policy

Each future phase will produce one approved written design, one task-level implementation plan, one click-to-run Python laboratory with editable configuration dictionaries, exact finite fixtures, artifact-only replay, focused mutation gates, and a concise changelog entry. Root-local `rg_v2` remains outside the installed package until a later promotion decision is approved.

Exact finite arithmetic is preferred through the \(S_3\) and \(D_4\) tiers. Continuous groups begin only after the finite contracts are stable. CPU tests use tiny enumerated systems; GPU work is not on the critical path for semantic closure.

Evidence work should be proportional to the change. Immutable fixture and artifact hashes are recorded at the final release boundary, not repeatedly narrated during construction. A passing suite is not rerun unless later edits invalidate it. Documentation-only changes receive static checks rather than code tests.

## Immediate next action

The user approved the
[Phase 14 sector-quotient design gate](docs/superpowers/specs/2026-09-03-rg-v2-phase14-sector-quotient-design-gate.md)
on 2026-09-03. Its current execution authority is the
[Phase 14 sector-quotient implementation plan](docs/superpowers/plans/2026-09-03-rg-v2-phase14-sector-quotient-implementation.md),
informed by the [requested audit intake](docs/audits/2026-09-03-renormalization-v2-audit-intake.md).
No Phase 14 code, test, or experiment has begun. On a separate implementation
request, execute the route and cross-sector admission tasks first. If an
equivariant intertwiner or structural-channel square fails, stop and report
the obstruction before composition, law, registry, launcher, or full-carrier
work. The older untracked Desktop drafts are not implementation authority.
Phase 13 remains operator-accepted with automated publication certification
incomplete; do not rerun its superseded publication workflow to manufacture
certification.

## Governing sources

- `Theory/02_geometry.tex`: one principal bundle, two associated representations, cross morphisms, graph links, and the common-frame specialization.
- `Theory/07c_full_graph_meta_agent_vfe.tex`: the fixed-\(c_*\) full graph state, edge-event laws, holonomy retention, normalized membership, and structural-channel composition.
- `Theory/PIFB2.tex`: non-flat links, plaquette holonomy, and Wilson-style action boundaries.
- `docs/STATUS.md`: compact-group correction and the conditional Gibbs–Haar/ELBO boundary.
- `rg_v2/README.md`: executable Phase 1–13 finite scope and current nonclaims.
- `docs/superpowers/specs/2026-08-22-rg-v2-conditional-structured-composition-design.md`: the Phase 3 composition harness to be lifted in Phase 9.
- Research wiki pages `[[Gauge-Theoretic Multi-Agent VFE Model]]`, `[[Lattice gauge theory]]`, and `[[Irreducible representation]]`: program context, link/plaquette semantics, and representation/intertwiner distinctions.
