# Gaussian bounds over the complete inference parameter interval

September 8, 2026. This implementation assesses already-selected Gaussian modal sets from the preceding [rate-aware calibration](2026-09-08-gaussian-rate-aware-selection.md). It neither changes the selected indexes nor ranks or regroups modes. Its output is a continuum upper bound for the fixed supplied modal parameters. It is distinct from sampling errors on a denser time grid.

## Fixed mathematical object

The inputs are finite binary64 eigenvalues \(\lambda_i>0\), finite binary64 information coordinates \(h_i\), and fixed selected indexes. Each supplied floating-point value is interpreted as an exact real number with that binary64 value. The bound concerns the analytic [modal representation](2026-09-08-gaussian-modal-compression.md) defined by those numbers. It does not certify the eigensolver, target whitening, reconstruction of the original covariance, or all rounding errors made by a runtime trajectory evaluator.

For \(a=e^{-t}\), the complete nonnegative inference parameter range corresponds to \(a\in(0,1]\), and \(a=0\) is the analytic target limit. The closed interval \([0,1]\) therefore includes the entire trajectory and both endpoints. Set

\[
k_i=\lambda_i-1,
 R=a(1-a),
 s_i=Rk_i^2,
 d_i=1+ak_i.
\]

The prior calibration derivation gives the exact state error as a sum over omitted modes and the squared fixed-target Fisher rate error as another such sum. Retained modes contribute zero. An omitted mode with \(\lambda_i=1\) also contributes identically zero for every \(h_i\); removing that zero term from arithmetic does not change the selected set.

## Positive rational state enclosure

For an omitted mode, the approximate variance is \(v_i=(1-a)+a/\lambda_i\). If \(r_i\) is its exact-minus-approximate variance divided by \(v_i\), then

\[
r_i=-\frac{s_i}{\lambda_i+s_i},
 1+r_i=\frac{\lambda_i}{\lambda_i+s_i}>0.
\]

The covariance contribution to the directed state error \(\operatorname{KL}(q_{\mathrm{exact}}\Vert q_{\mathrm{approx}})\) is \(\tfrac12[r_i-\log(1+r_i)]\). For \(x=-r_i\in[0,1)\),

\[
-x-\log(1-x)=\int_0^x\frac{u}{1-u}du
\leq\frac{x^2}{2(1-x)}.
\]

The integrand inequality uses \(1-u\geq1-x\), so it holds throughout the admitted range. Hence the covariance contribution has the positive rational upper bound

\[
\frac{s_i^2}{4\lambda_i(\lambda_i+s_i)}.
\]

The mean contribution can be rewritten exactly as

\[
\frac{h_i^2R^2k_i^2}{2d_i\lambda_i(\lambda_i+s_i)}.
\]

To verify the denominator, multiply \(d_i\) by \(a+(1-a)\lambda_i\); their product is \(\lambda_i+s_i\). Substituting this identity into the original squared mean error divided by the approximate variance gives the displayed expression.

The implementation encloses the sum of these two nonnegative rational expressions. It avoids logarithmic cancellation, but the covariance inequality is conservative even before interval arithmetic. A bound above a requested limit therefore does not establish a violation of that limit by the actual trajectory.

## Exact rational rate expression

The mean correction rate coefficient is

\[
\dot c_i=\frac{ak_i(2a-1+a^2k_i)}{d_i^2\lambda_i},
\]

and the covariance correction rate coefficient is \(-k_i\dot c_i\). Consequently the exact omitted contribution to the squared fixed-target Fisher rate error is

\[
\left(h_i^2+\frac12k_i^2\right)
\frac{a^2k_i^2(2a-1+a^2k_i)^2}{d_i^4\lambda_i^2}.
\]

The bound sums interval enclosures of these squared contributions before taking an outward-enclosed square root. It does not sum mode norms, change the covariance Fisher factor, or substitute a metric at the moving approximate law.

## Outward enclosure on a dyadic cover

`bound_gaussian` partitions \([0,1]\) into a declared power-of-two number of equal cells, defaulting to 256 and admitting up to 16,384. Their endpoints are exactly representable dyadic binary64 values. The cells include their endpoints and meet without gaps, so an enclosure on every cell gives a bound on the whole closed interval.

All rational expression arithmetic uses the existing `multiagent_elbo.rg_v2.e1_interval.Interval` implementation, read without modification. Its elementary operations enlarge bounds outward; its square root checks outward endpoint-square brackets. The new implementation contains no sampling substitution for those interval operations.

Two analytic range facts tighten the enclosure. First, the concave polynomial \(R=a(1-a)\) has its minimum at a cell endpoint and maximum at the vertex \(a=1/2\) when that vertex is present, otherwise at an endpoint. The endpoint values themselves are evaluated with outward arithmetic. Second, \(d_i=1+a(\lambda_i-1)\) lies between \(\min(1,\lambda_i)\) and \(\max(1,\lambda_i)\). Intersecting the computed interval with this known positive range prevents dependency-induced loss of denominator positivity. Nonnegative squared and KL expressions may likewise be intersected with their proved nonnegative ranges. These intersections use mathematical domain information; they do not change covariance values or floor eigenvalues.

The maximum of the retained cell upper bounds is the reported global upper bound. Floating overflow, a nonpositive interval denominator, or a failure to produce finite bounds remains an arithmetic failure. No retry, clipping, or replacement finite value is introduced. The admitted healthy modal fixture is separate from a claim that arbitrary ill-conditioned positive inputs can always be enclosed using this binary64 implementation.

## API and interpretation

`bound_gaussian(lambda_, h, selected_indexes, subdivisions=256)` returns `gaussian_kl_upper`, `gaussian_rate_upper`, and `cells`. Each cell records `a_left`, `a_right`, and both upper bounds. The result also preserves selected and omitted indexes, identifies the omitted non-unit eigenvalues that require arithmetic, records the subdivision count and method, and states the exact-input scope. The full selected set and identically zero omitted corrections return exact zero bounds over the same dyadic cover.

Under the prior fixed-target-whitening and full-row-rank parent construction, the fine directed KL dominates the parent KL by data processing, and the fine fixed-target Fisher rate norm dominates the corresponding parent norm. Those arguments are given in the rate-aware selection derivation. They transfer a valid fine continuum bound to each fixed parent map; they do not extend it to changing targets, changing maps, or a different rate metric.

A global upper bound below a declared limit establishes that limit for this fixed analytic modal problem. A larger upper bound is classified as not established. It is not a physical counterexample, an observed trajectory failure, or permission to alter the previously selected modes. The eigenbasis and floating-runtime qualifications remain visible even when the bound succeeds.

The supplied tests check exact dyadic coverage, analytically known one-mode extrema, independently evaluated exact-rational Gaussian moments with high-precision logarithms and square roots, zero omission, unit-eigenvalue corrections, refinement of the enclosure, and an initial rate missed by a single intermediate calibration time. Point evaluations are tests of the implementation, not the proof of continuum coverage. Test execution is reserved for the coordinating implementation's consolidated pass; this derivation records no passing result.
