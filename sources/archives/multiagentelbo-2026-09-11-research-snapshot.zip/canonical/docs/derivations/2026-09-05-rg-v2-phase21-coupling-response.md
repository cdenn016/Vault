# Phase 21 finite coupling-response derivation

This document derives the formulas implemented in the
[response model](../../rg_v2/complete_carrier_coupling_response_model.py)
from the finite definitions in the
[Phase 21 design](../superpowers/specs/2026-09-05-rg-v2-phase21-coupling-response-design.md).
It supplies the written R2 derivation. Its mathematical argument and the finite
recipe checks are separate evidence: execution does not independently adjudicate
an all-parameter theorem. No new evidence-ledger closure is asserted here.

## Fixed data and coordinates

Fix three nonempty finite signature sets, positive normalized reference masses
$p_l$, and nonnegative row-stochastic reverse matrices $Q_{lm}$ with
$p_m Q_{lm}=p_l$ and $Q_{02}=Q_{12}Q_{01}$. All these arrays are independent of
the coupling parameters. Let $E_l$ have linearly independent columns and a
left inverse $L_l$, with $L_lE_l=I$. Require saturated targets:
$E_mL_m=I$ on the entire signature space for $m=1,2$. Require that the original
four-column evaluations $B_l$ lie in the column span of $E_l$ and have a
leading constant-one column. Then $A_l=L_lB_l$ satisfies $E_lA_l=B_l$.
The represented constant is $e_l=L_l\mathbf 1$, with $E_le_l=\mathbf 1$.

The independent coefficient $g_l$ has dimension $r_l$; the original source
parameter $\eta$ has four coordinates labeled $(\mathrm{one},h_a,h_b,h_c)$.
At the source, $g_0=A_0\eta$. In the full retained family $r_l=(4,4,2)$ and
$A_0=I_4$. A dependent original family can have $r_0<4$, so replacing $A_0$
by an identity would change both the shape and meaning of the Fisher forms.

For arbitrary finite real $g$, define
$w_l(s;g)=\exp(-(E_lg)_s)$ and $w_m=Q_{lm}w_l$.
Every weight is strictly positive because each reverse row has total mass one.
Define $Z=p_lw_l=p_mw_m$, and
$p_l^w(s)=p_l(s)w_l(s)/Z$. These finite positive sums are smooth for every
finite $g$; differentiating them requires no interchange with an infinite sum.

The implementation evaluates these formulas only at positive rational centers.
There it verifies $w_0=d r_a^{h_a}r_b^{h_b}r_c^{h_c}$ on the original binary
source signatures. Thus $\eta=(-\log d,-\log r_a,-\log r_b,-\log r_c)$ exists
and $w_0=\exp(-E_0A_0\eta)$. Production arithmetic never computes these
logarithms or exponentiates fitted coefficients.

## First and second responses

Write $W_t=\sum_sQ(t,s)\exp(-(E_lg)_s)$ and $f_t=-\log W_t$.
Direct differentiation gives
$\partial_a W_t=-\sum_s Q(t,s)w_l(s)E_l(s,a)$ and
$\partial_{ab}W_t=\sum_s Q(t,s)w_l(s)E_l(s,a)E_l(s,b)$.
Consequently, with $Q^w(t,s)=Q(t,s)w_l(s)/W_t$,

$$
\partial_a f_t=\sum_sQ^w(t,s)E_l(s,a),
$$

and

$$
\partial_{ab}f_t
=-\sum_sQ^w(t,s)E_l(s,a)E_l(s,b)
+\left(\sum_sQ^w(t,s)E_l(s,a)\right)
 \left(\sum_sQ^w(t,s)E_l(s,b)\right).
$$

Since $T_{lm}(g)=L_mf(g)$ and $L_m$ is fixed, the exact response arrays are

$$
J_{lm}=L_mQ_{lm}^wE_l,\qquad
H_{lm}[i,a,b]=-\sum_tL_m[i,t]
 \operatorname{Cov}_{Q_{lm}^w(t,\cdot)}(E_l(\cdot,a),E_l(\cdot,b)).
$$

The Hessian indices are output coefficient, input coefficient, input
coefficient. Conditional covariance is positive semidefinite as a form in the
input indices, but the entries of $L_m$ can have either sign. There is no
coefficientwise sign assertion for $H_{lm}$.

## Normalization and the two compositions

Differentiating the finite partition sum gives
$\partial_a\log Z=-\mathbb E_{p_l^w}E_l(\cdot,a)$ and
$\partial_{ab}\log Z=\operatorname{Cov}_{p_l^w}(E_l(\cdot,a),E_l(\cdot,b))$.
For $N_{lm}=T_{lm}+\log(Z)e_m$, this proves

$$
J_{lm}^{N}[i,a]=J_{lm}[i,a]-e_m[i]\mathbb E_{p_l^w}E_l(\cdot,a),
$$

$$
H_{lm}^{N}[i,a,b]=H_{lm}[i,a,b]+e_m[i]
 \operatorname{Cov}_{p_l^w}(E_l(\cdot,a),E_l(\cdot,b)).
$$

Saturation gives $\exp(-E_1T_{01}(g))=Q_{01}\exp(-E_0g)$.
Applying $Q_{12}$ and using its composition with $Q_{01}$ proves
$T_{12}(T_{01}(g))=T_{02}(g)$. Differentiating this identity twice gives

$$
J_{02}=J_{12}J_{01},
$$

$$
H_{02}[i,a,b]
=\sum_jJ_{12}[i,j]H_{01}[j,a,b]
+\sum_{j,k}H_{12}[i,j,k]J_{01}[j,a]J_{01}[k,b].
$$

The first term accounts for curvature of the inner map and is present even
when a coarse retained value becomes scalar.

At the normalized middle coefficient $N_{01}(g)$, saturation instead gives
$\exp(-E_1N_{01}(g))=w_1/Z$. Its reference-weighted mass is exactly one.
The next partition factor is therefore one, and

$$
N_{12}(N_{01}(g))
=L_2[-\log(Q_{12}w_1/Z)]=N_{02}(g).
$$

The same first- and second-order chain rules apply to the normalized responses.
The second map is differentiated as a function on its whole coefficient
space, then evaluated at that normalized middle state. Its normalizer is not
discarded merely because it equals one at that point. Conversely the original
$\log Z$ is not added to the normalized middle state a second time.

Multiplying every weight by the same positive scalar leaves $p_l^w$ and
$Q_{lm}^w$ unchanged. All displayed derivative arrays are consequently unchanged.
For a coefficient shift $g+ce_l$, the raw response satisfies
$T_{lm}(g+ce_l)=T_{lm}(g)+ce_m$, whereas
$N_{lm}(g+ce_l)=N_{lm}(g)$. Differentiation gives
$J_{lm}e_l=e_m$, $J_{lm}^Ne_l=0$, and vanishing raw and normalized
Hessian contractions with the constant direction. It also explains why the
normalized derivatives at raw and normalized middle centers agree.

## Source Fisher forms and retention

The tilted level-$l$ score in independent coordinates is the negative
centered evaluation vector, so its local Fisher form is
$K_l=\operatorname{Cov}_{p_l^w}(E_l)$. Set
$D_0=A_0$, $D_1=J_{01}A_0$, and $D_2=J_{02}A_0$.
Pulling back the local score along the source parameter gives

$$
G_l=D_l^\mathsf{T}K_lD_l.
$$

For $l>0$, saturation shows
$E_lD_l=Q_{0l}^wE_0A_0=Q_{0l}^wB_0$.
At $l=0$, $E_0D_0=B_0$ directly. Thus $G_l$ is also the covariance of
the conditional expectation of the original source statistics. This supplies
a second finite calculation of each matrix, distinct from the matrix
multiplication used for the pullback.

Since $K_le_l=0$, replacing $J_{0l}$ by $J_{0l}^N$ leaves $G_l$ unchanged.
The source normalization itself also changes the derivative only by a
represented constant, so $G_0$ is unaffected. The constant original parameter
is a kernel direction in all three four-by-four forms.

The identity $p_m^w(t)Q_{lm}^w(t,s)=p_m(t)Q_{lm}(t,s)w_l(s)/Z$
defines a positive normalized joint with the indicated marginals. The finite
conditional-covariance identity therefore gives
$G_0-G_1\succeq0$ and $G_1-G_2\succeq0$ in the same original source
coordinates. The differences obey
$D_{02}^{\mathrm{loss}}=D_{01}^{\mathrm{loss}}+D_{12}^{\mathrm{loss}}$.
Here the loss symbol is distinct from the derivative $D_l$.

For each pair $(G_0,G_1)$, $(G_1,G_2)$, $(G_0,G_2)$, positivity implies that
the target form annihilates the source kernel. The existing Phase 17 solver
checks this, selects a basis of the source quotient, and calculates the
generalized retention pencil there. The constant kernel bounds the quotient
dimension by three. It retains exact rational roots or polynomial-isolating
intervals, including multiplicities and endpoint spaces. These are retained
information fractions, not eigenvalues of an identified common-space RG map.
The support dimensions differ, and
full_space_beta_status remains not_defined_support_nonisomorphic.

## Evidence boundary

The formulas follow above from the declared finite sums, fixed reference
kernels, target saturation, and source-coordinate lift. The eight recipes
supply finite-center execution checks only. The separate result report records
the actual comparisons and runtime artifacts. This implementation session
does not promote the derivation to a new independently adjudicated
EVIDENCE_VERIFIED theorem or repin the historical Phase 20 ledger.



The referenced verification skill was not found in the installed skill
locations. This is an explicit limit on independent theorem adjudication;
it does not turn finite-center execution into proof certification.
