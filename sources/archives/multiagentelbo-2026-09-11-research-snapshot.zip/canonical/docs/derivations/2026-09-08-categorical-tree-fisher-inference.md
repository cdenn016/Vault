# Categorical tree Fisher inference

This construction evolves the complete latent record recognition law at a fixed context. It does not change the prior, observation kernel, context, cover, connection, or coarse channel. The four categorical variables are record endpoints, each with four agent-label outcomes in the current experiment; they are not the four open agent domains. The implementation accepts one positive joint tensor with one axis per chain variable, without an implicit batch axis.

Write the recognition law as

$$
q(x)=r(x_0)\prod_{i=1}^{n-1}c_i(x_i\mid x_{i-1}),
$$

where the root vector and every conditional row are strictly positive and normalized. These parameters determine a unique joint and therefore consistent adjacent-pair and separator marginals. Updating normalized conditionals never requires fitting independently updated separator laws. Conversely, extracting these conditionals from an arbitrary joint and multiplying them reconstructs its adjacent-pair Markov extension. That reconstruction preserves adjacent-pair marginals but generally changes a non-Markov input. It is not asserted to minimize reverse KL to that input.

The target is the fixed, complete posterior law $p$. At fixed model evidence, minimizing VFE is equivalent to minimizing

$$
\mathcal K(q)=\sum_xq(x)\log\frac{q(x)}{p(x)}.
$$

The target need not belong to the chain family for the following gradient construction. Introduce root logits and one logit vector for every conditional row. Their scores are

$$
s_{0b}(x)=\mathbf1\{x_0=b\}-r(b),
$$

$$
s_{iab}(x)=\mathbf1\{x_{i-1}=a\}
\left(\mathbf1\{x_i=b\}-c_i(b\mid a)\right).
$$

Every conditional score has zero conditional mean given the preceding history. For an earlier score $s_j$, conditioning on the history immediately preceding $x_i$ gives $E_q[s_js_i]=0$. Different parent rows at the same level have disjoint support, and their centered covariance is also zero. Consequently the complete-joint Fisher matrix is block diagonal in these redundant logits, with blocks

$$
I_0=\operatorname{diag}(r)-rr^{\mathsf T},
$$

$$
I_{ia}=q_{i-1}(a)
\left(\operatorname{diag}(c_i(\cdot\mid a))
-c_i(\cdot\mid a)c_i(\cdot\mid a)^{\mathsf T}\right).
$$

The singular all-ones direction in each block represents the immaterial addition of a constant to a row of logits. Positivity makes the Fisher metric nondegenerate on the quotient by those constants.

Let $\ell(x)=\log q(x)-\log p(x)$. Differentiation of the complete-joint KL gives $\partial\mathcal K=E_q[\ell s]$, because $E_q[s]=0$. A centered solution of the Fisher equation is

$$
a_0(b)=E_q[\ell\mid x_0=b]-E_q[\ell],
$$

$$
a_i(a,b)=E_q[\ell\mid x_{i-1}=a,x_i=b]
-E_q[\ell\mid x_{i-1}=a].
$$

Indeed the gradient block is $q_{i-1}(a)c_i(b\mid a)a_i(a,b)$, and multiplication of the Fisher block by $a_i(a,\cdot)$ produces the same vector. The parent-occupancy factor cancels when solving that block; omitting occupancy from the Fisher matrix itself would give an incorrect complete-joint metric. The exact squared norm of the projected natural gradient is

$$
\|\operatorname{grad}\mathcal K\|_I^2
=\sum_b r(b)a_0(b)^2
+\sum_{i,a,b}q_{i-1,i}(a,b)a_i(a,b)^2.
$$

This norm is the magnitude of the projection onto the admitted chain tangent space. Its vanishing alone does not establish global optimality in the chain family or equality to a non-Markov target.

The numerical update subtracts $t a_0$ and $t a_i$ from the corresponding logits and applies a softmax to each row. Its initial KL derivative is minus the displayed squared norm. Backtracking accepts only candidates satisfying

$$
\mathcal K(q_{\mathrm{new}})
\leq\mathcal K(q)-\eta t\|\operatorname{grad}\mathcal K\|_I^2,
$$

with the configured Armijo constant $0<\eta<1$. Normalization holds by construction. A trial whose softmax underflows to a zero probability is rejected, without probability clipping or a modified target. Exhausting the finite backtracking budget returns the unchanged state and an explicit failed-step flag. The returned norm is evaluated at the entry state; backtracking count, accepted step size, and before/after objectives are separate outputs. At machine precision, objective resolution can stop a line search before the configured stationarity tolerance is attained, which is reported as a line-search termination rather than convergence.

A separate complete-simplex control integrates the reverse-KL natural flow exactly. For elapsed flow time $t\geq0$, set $a=\exp(-t)$ and

$$
q_t(x)=\frac{q_0(x)^a p(x)^{1-a}}
{\sum_yq_0(y)^a p(y)^{1-a}}.
$$

Differentiating its normalized log density gives

$$
\dot q_t(x)=-q_t(x)\left(\log\frac{q_t(x)}{p(x)}
-E_{q_t}\log\frac{q_t}{p}\right).
$$

Therefore $d\mathcal K/dt=-\operatorname{Var}_{q_t}(\log(q_t/p))$. This is an exact flow-time control, whereas the conditional-logit Armijo update is a finite numerical step. Equal scalar parameters do not make those two finite updates identical.

The present latent event posterior remains chain-Markov. The prior factors on adjacent endpoint pairs, and its Bernoulli likelihood multiplies only the first pair factor. The posterior is strictly positive and retains the same undirected chain factorization; orienting that chain gives normalized root and conditional parameters. Furthermore, when both initial recognition and target are positive chain laws, the geometric interpolation defining $q_t$ remains a product of chain clique potentials. The complete-simplex flow then remains in the chain family, and its instantaneous replicator velocity equals the projected chain natural velocity. There is consequently no categorical family approximation gap for the current event posterior. Any residual in a finite numerical run must still be distinguished from a proved optimization failure or a convergence certificate.

The focused tests enumerate every state of a tiny binary chain. They form the full log-density Jacobian, compute its score covariance independently, compare every occupancy-weighted Fisher block and its off-block zeros, solve the Fisher-gradient identity, and compare the directional KL derivative with finite differences. Further controls exercise positive normalization, marginal reconstruction, Armijo descent, categorical outcome relabeling, exact current-posterior membership, exact-flow composition, and the equality of projected and complete-simplex velocities when both endpoint laws are Markov. Categorical outcome relabeling is separate from the SO(2) gauge transformation of the Gaussian channels.

The implementation is in `src/multiagent_elbo/experiments/neighborhood/categorical_inference.py`; its focused controls are in `tests/rg_v2/test_neighborhood_categorical_inference.py`. The parent task records consolidated validation for this module.



## Near-target arithmetic repair

The first default CUDA execution retained a late categorical Armijo stall. Its saved law at context $(-0.45,0.2)$ had projected norm approximately $1.2028563\times10^{-8}$. Replaying that law on CPU with the original objective rejected every candidate in its finite backtracking budget. A half-step appeared to increase the original floating-point expression from $2.3897413\times10^{-16}$ to $5.0129816\times10^{-16}$. An independent 80-digit Decimal calculation of generalized relative entropy instead decreased from $7.2343160\times10^{-17}$ to $1.8085790\times10^{-17}$, whereas Armijo required a decrease of only $7.2343160\times10^{-21}$. This is retained numerical evidence for objective cancellation and total-mass rounding at the observed stall, not a convergence proof.

For normalized laws, the objective has the exactly equivalent form

$$
\mathcal K(q)=\sum_x\left(q(x)\log\frac{q(x)}{p(x)}-q(x)+p(x)\right).
$$

The subtracted total-mass term is mathematically zero. Computing the expression termwise removes the first-order normalization noise in finite precision. Near equality, put $r=(q-p)/p$ and evaluate each term as $p f(r)$, where

$$
f(r)=(1+r)\log(1+r)-r
=\frac{r^2}{2}-\frac{r^3}{6}
+\frac{r^4}{12}-\frac{r^5}{20}
+\frac{r^6}{30}+R_6(r).
$$

For $|r|\leq10^{-3}$, the absolutely bounded tail obeys

$$
|R_6(r)|\leq\frac{|r|^7}{42(1-|r|)}.
$$

Since $f(r)\geq r^2/(2(1+|r|))$, the relative truncation bound is less than $5\times10^{-17}$ away from $r=0$; the zero case is represented exactly. This is a bound on the series truncation, separate from floating-point evaluation error. The implementation uses the degree-six expression on this branch, without clamping the resulting objective.

The Fisher score uses $\log(1+r)$ near equality, and the root score is centered by its actual weighted-score expectation. Far from equality, separate logarithms remain in use: computing $r$ unconditionally can round a tiny positive ratio to $r=-1$, falsely introducing an infinite logarithm. The repair adds neither a probability floor nor a relaxed Armijo, stationarity, or CPU/CUDA comparison tolerance.

The saved-state comparison is in docs/verification/2026-09-08-neighborhood-inference/categorical-cancellation-diagnostic.json, bound to the original source hash. The new focused regression compares the repaired objective and accepted half-steps with 80-digit Decimal evaluations at small deviations, and checks a far-away positive probability whose subtraction rounds to the branch endpoint. Its execution is recorded in categorical-near-target.xml: one test passed. Broader affected checks and the subsequent CUDA execution belong to the parent task's consolidated validation.

