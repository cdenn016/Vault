# Geometry pressure and induced-experiment RG execution plan

The preceding finite normalized geometry lift is delivered and accepted at its stated scope. This task continues the active full RG goal; it does not start Git publication or a previous heavy producer. Work stays in C:/tmp/elbo-cover-20260908, preserving the canonical Desktop baseline and intentional WIP.

The frozen contract requires a retained finite label and common cell carrier. Construct every pressure, boundary and posterior-limit bridge explicitly. A strict score gap or supplied effective tie-ratio data is necessary for effective label selection. Arbitrary stationary recognition has a mathematical entropy rate but need not supply a computable rate oracle. Fixed block words and a volume limit are the admitted order of limits.

## Independent responsibilities

The theory author owns agents/pressure-construction.md and author-proposals.json, covering P01 through P14 with all load-bearing derivations and actual prior-interface hypotheses. The independent investigator first owns agents/independent-initial-construction.md and initial-proposals.json, reading this contract and named existing proof/source inputs before new counterpart constructions or discovery notes. After that initial pair is frozen, the investigator reconstructs the mature proof and eventual source/result correspondence. No agent assigns native states.

The finite arithmetic worker initially owns agents/implementation-intake.md only. It inspects literal interfaces and proposes the minimal additive API for unbounded rational directed logarithms, native free partitions, sensor transformation, pressure enclosures and finite geometry-gap certificates. After root reconciles the API with the author, its implementation ownership will be named explicitly. Root owns integration, any distinct complete coarse-pressure/scalar/VFE adapter, report/claim assembly and canonical delivery. All agents share the worktree and must preserve one another's files.

## Order and admitted execution

Persist the new independent initial construction before counterpart access. Reconstruct the complete coarse vacuum-pressure oracle and the actual-marginal positive-sensor posterior limit; a surface log-ratio bound by itself does not establish local convergence. Resolve all scalar representative and finite boundary conventions before source claims.

Use additive Python int/Fraction algorithms for the full directed-log approximation path. Preserve all existing guarded helper defaults. A capped call must report a resource outcome, and overlapping pressure intervals must report undetermined rather than infer a tie. No uniform practical runtime guarantee is claimed.

Implement the complete approved interfaces and matching tiny scientific controls, then root reads all changed source/tests/runner, the active run_lab.py profile and its loader/route. Run one new explicitly enumerated focused packet after source freeze and preflight. At most eight independently enumerated signs are allowed, sufficient for one 2-by-2 native square with an internal plaquette; no training-sized model or unbounded-accuracy request enters the packet. Isolated source-injected C:/anaconda/python.exe -I -B is the runtime. Exact standard-library arithmetic requires no CUDA. Do not import a full old suite or run old tests/producers, Phase13, held S1-S3, large laws, or user-excluded tamper/corruption/forgery checks.

Bind every actual command, config, source and raw JUnit outcome. Finite cases do not prove thermodynamic convergence. Root accepts current derivations/source identities and observed output after scoped independent reconstruction, then records native structure checks. Preserve failed checks; do not replay science after a passing packet without a changed scientific obligation. Preserve required Markdown metadata headers when replacing scaffold content.

Append the daily log and roadmap, then perform one guarded canonical file delivery preserving all prior baseline bytes and 18 absences. The current baseline is docs/verification/2026-09-09-normalized-geometry-vfe/delivery-state.json, SHA fda93a564cc5468ce54d15345222e81bc7c929ec5b984494373b76e23f5f0ad9, with 4990 entries excluding itself. No vault/memory write or remote Git lifecycle is included in this task.

## Remaining overall program

The full goal remains active beyond this contract. Criticality, continuum measures, unrestricted geometry dynamics, simultaneous uncontrolled volume/depth limits, self-consistent Fisher-curvature actions and physical identification are not silently supplied by a pressure or finite-control result.
