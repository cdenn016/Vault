<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e","target_digest":"81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e"} -->

# Complete constructive pressure for the canonical vacuum representative

This root construction is a candidate under the frozen geometry-pressure contract. It invokes the actual UC finite constrained specifications and UP vacuum shells at their admitted c<1/12 scope, then constructs the previously missing finite pressure algorithm. It does not invoke a scalar-free Walsh pressure or assume equality of pressures for different representatives. No source or scientific execution has occurred.

## VP01. Rational spatial comparison parameters

Fix rational 0<b<1, 0<c<1/12 and integer B>=1. Set q=(1+12c)/2, t=24c/(1+12c), C=16q/(1-q), rho=[b(1+c^2)+2c]/[1+c^2+2bc], and m=(1-rho)^2/4. These are positive rationals, with q,t,rho<1. They correspond to the allowed UC choice exp(theta)=1/t and q=12c exp(theta). The canonical vacuum representative in UP02 depends on the exact conditional law and fixed past convention, not on which admissible comparison theta proves its tail.

For the target cell zero, the finite whole-block volume Omega_R consists of all fine blocks anchored in [-R,R]^2. Its edge inventory has exactly 2 B^2 (2R+1)^2 fine signs and includes all retained paths whole. Prescribe every retained path in this anchor square except the two target paths to the specified exterior coarse pattern, and leave unused singleton blocks unconstrained. Complete all exterior fine signs by plus. The exact finite conditional law includes every edge factor of a free sign and every plaquette touching a free sign; it omits only factors constant in all free signs. The normalized restricted counting reference cancels from its conditional ratios.

UC09 through UC13 compare its target four-state row to the actual everywhere-defined coarse row with total variation at most delta_R=C B^2(R+1)t^(R+1), optionally capped at one. This comparison permits arbitrary fine exterior signs; they need not realize the imposed infinite coarse pattern. Each target atom, finite and infinite, is at least m by UC12's two successive unconstrained path bounds. Consequently every target log odds against (+,+) differs by at most 2 delta_R/m. This follows by integrating 1/u between two probabilities bounded below by m; it requires no guessed positive lower endpoint from an interval.

## VP02. The actual shell representative and its complete tails

Let e_r(sigma) be the UP02 negative conditional log odds at zero, with the past in radius r taken from sigma and every other exterior cell fixed to the vacuum. Phi_0=e_0 and Phi_r=e_r-e_(r-1) for r>=1 on the exact lexicographic past supports A_r. Translations of A_r containing zero number |A_r|, bounded by (2r+1)^2, and their diameter is at most 2r. With D=2 C B^2/m, the UC continuity estimate gives ||Phi_r||<=D r t^r for r>=1.

Therefore a valid unweighted per-cell tail after N is

T_N = D sum_{r>N} r(2r+1)^2 t^r,

and a valid complete first-moment bound is

Mbar = 2D sum_{r>=1} r^2(2r+1)^2 t^r.

Every sum is a convergent polynomial-weighted geometric series with rational t. It is an exact rational number computable by repeated application of t d/dt to t/(1-t); suffix sums can equivalently be obtained by expanding (N+1+j)^k and the full geometric moments. T_N decreases to zero. This direct unweighted estimate suffices for pressure even though the earlier stronger weighted norm proof is also available. No shell is silently deleted from the target interaction.

## VP03. Rational row approximants with exact exponentiation

For each r<=N and every assignment to A_r, compute the finite target row of VP01 at a common radius R>=N with precisely that truncated-past coarse exterior. Write v_r(sigma) for its target atom divided by its vacuum target atom, a positive rational. Define ehat_r=-log v_r exactly, Phihat_0=ehat_0 and Phihat_r=ehat_r-ehat_(r-1). These are logarithms of positive rationals, not rounded rational energies. Each is zero whenever the anchor state is the vacuum. They retain exactly the declared past support because all other oracle constraints are the vacuum.

The singleton sup error is at most 2 delta_R/m. Every retained nonzero shell sup error is at most 4 delta_R/m. Thus a bound on the full per-cell interaction discrepancy is

epsilon_(N,R) = T_N + (2 delta_R/m)[1+2 sum_{r=1}^N (2r+1)^2].

The omitted true shells contribute T_N, and the finite shell errors are charged to every translated support containing zero. This is a whole-interaction error, not a bound on a selected finite coefficient or marginal.

For any coarse configuration, exp(-Phihat_0)=v_0 and exp(-Phihat_r)=v_r/v_(r-1). Hence the finite free raw weight obtained by multiplying retained translated shell factors wholly inside Lambda_n is an exact positive rational. Its normalized-reference partition

Zhat_n=4^(-n^2) sum_{sigma in E^Lambda_n} product_{A subset Lambda_n} exp(-Phihat_A(sigma))

is computable by finite rational enumeration. No approximate exponential, factorization of a transcendental energy or scalar-free representative is required. The all-vacuum raw value is exactly one.

## VP04. Pressure interval and complete termination

For the true vacuum representative Phi, the all-touching norm bound gives |log Zhat_n-log Z_Phi,n|<=n^2 epsilon_(N,R). The restored tiling result gives |p(Phi)-n^(-2)log Z_Phi,n|<=4 Mbar/n. A rational directed-log interval [l,u] for Zhat_n therefore supplies

p(Phi) in [l/n^2-epsilon_(N,R)-4Mbar/n, u/n^2+epsilon_(N,R)+4Mbar/n].

For each rational requested radius epsilon>0, first choose N so T_N<epsilon/4. For this fixed N choose R>=N so its displayed row-error contribution is below epsilon/4; (R+1)t^(R+1) tends to zero, so finite sequential search terminates. Next choose n with 4Mbar/n<epsilon/4 and compute a log interval whose radius divided by n^2 is below epsilon/4. These finite choices prove an algorithm for arbitrary requested accuracy under sufficient finite arithmetic resources. The exact number of oracle signs and coarse states can be enormous. A practical budget must refuse before excessive work and cannot be interpreted as a false pressure result. A separate unbounded mathematical execution path must have no fixed stored-scalar guard.

At c=0 there is an elementary direct branch: the coarse law has independent edge mean b^B, the vacuum raw factor per cell is product_a (1+b^B s_a)/(1+b^B), and its pressure is -2log(1+b^B). This branch has no spatial tail or oracle-radius uncertainty. The native unanchored raw-factor pressure at c=0 is zero; confusing the two would discard a scalar density.

## VP05. Interface and scalar conventions

A finite completed pressure receipt must identify b,c,B, the exact vacuum/past/reference convention, N,R,n, all rational comparison constants, every finite oracle and shell row used, the exact positive rational partition, the directed-log enclosure, the full tail/row/boundary components and the resulting interval. A product closed form should identify its own elementary branch. Complete enumeration may be cached only by all of those mathematical inputs.

The pressure at B=1 computed here is the UP vacuum representative's pressure. It need not equal the original raw edge/plaquette pressure even though their normalized law agrees. An initial change from raw factors to the vacuum representative has its own scalar density. Identity factors inside an already vacuum-normalized word have zero scalar density by sigma_1=p(Phi)-p(Phi). A raw-to-vacuum representative conversion is not such an identity. The thermodynamic scalar formula must always name its incoming and outgoing representatives.

These candidate proofs require the independent reconstruction and source implementation correspondence before native acceptance. Numerical pressure estimates do not prove VP01 through VP05.


## VP06. Complete pressure through the vacuum cylinder

The theory author supplied a second route after VP01 through VP05 were persisted; this section discloses that shared origin. It gives the smaller executable pressure adapter while the preceding shell algorithm constructs the full coefficient approximation.

Let p_n be the actual coarse-law probability that every cell in an n-square equals (+,+). The canonical free Hamiltonian is exactly zero at that configuration, because every vacuum shell vanishes there. Its free probability is 4^(-n^2)/Z_Phi,n. The actual-marginal versus free comparison is at most 8Mbar n in log mass. Combining that comparison with the 4Mbar/n pressure estimate yields

|p(Phi)-[-log4-n^(-2)log p_n]| <= 12Mbar/n.

To compute p_n, use the unconstrained fine whole-block volume Omega_(Lambda_n)_R, whose anchor square has side n+2R, with fixed fine plus exterior and all touching plaquettes. No retained path is conditioned; the event is that every target path parity is plus. Its exact finite probability q_(n,R) is a rational numerator divided by a positive rational partition. Successive target path revelation gives both q_(n,R) and p_n at least m^(n^2). The UC target-set comparison gives |q_(n,R)-p_n|<=C n^2 B^2(R+1)t^(R+1). Therefore

|n^(-2)log q_(n,R)-n^(-2)log p_n|
 <= C B^2(R+1)t^(R+1)/m^(n^2).

Together with directed logarithm intervals for q and 4, these quantities give rational outward pressure endpoints for the exact vacuum representative. First choose n so 12Mbar/n is below a requested fraction of the tolerance; then choose R so the displayed oracle term is small, and finally choose logarithm precision. All choices terminate under sufficient finite resources. The event's exponentially small lower bound increases the required oracle margin but never makes it zero at finite n.

This route computes the complete target pressure from the full law and its established canonical moment bound. It does not recover an arbitrary representation's pressure from its normalized law: the vacuum condition is essential. At c=0 retain the elementary closed form in VP04 instead. The bounded finite control can use n=1 or2 with a small declared oracle margin; its wide resulting certificate remains valid and is not advertised as a small-error result.

## VP07. Centered embeddings for local limits

A sequence of inventory boxes {0,...,L-1}^2 leaves the origin at a corner and does not by itself support local convergence around the origin. For local-law and posterior limits, translate the coarse box by -floor(L/2) in each coordinate and its B-block fine inventory by -B floor(L/2). Every fixed cylinder then has a growing interior margin. Use the uncentered boxes only as finite enumeration coordinates and for pressure or stationary densities, which translation covariance leaves unchanged. The author identified this boundary requirement before the new target's native acceptance. No corner-boundary limit is asserted.
