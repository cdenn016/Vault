<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e","target_digest":"81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e"} -->

# Independent initial geometry-pressure construction

Date: 2026-09-09. This initial construction was written after reading only the new frozen contract and execution plan, together with the named prior admitted inputs described below. No old next-* discovery, current counterpart proposal, implementation intake or new source was read. The same model family, shared prior context and shared filesystem limit independence. These are derivations and proposed conditions, not native ledger decisions. No scientific module import, test, numerical study, GPU operation, old producer, publication, vault/memory write or user-excluded tamper check occurred.

The actual prior inputs used here are uniform-depth-gibbs-rg/agents/uniform-coupling-construction.md UC01-UC19 and uniform-potential-vfe.md UP01-UP10, read fully; coarse-gibbs-rg/agents/potential-vfe-construction.md CP01-CP10, read fully as an elementary boundary/entropy argument but not as an all-depth uniqueness premise; the previously fully read normalized geometry finite identities and SPEC; and the literal older coarse_gibbs.py and certified_logarithms.py, read without importing. The earlier basin root note's introductory metadata was read, but its method is not needed for the independent conditional-row oracle below. The all-depth law input is UC's c<1/12 column-coupling construction, never the obsolete c<1/(6B) domain. No new external theorem is imported or attributed to a primary source not opened in this lane.

## IP01. Exact carrier, boundaries, and a necessary placement condition

Use cell x in Z^2 with two outgoing signs z_(x,1),z_(x,2). A plaquette based at x uses edges (x,1),(x+e1,2),(x+e2,1),(x,2); its cell support is {x,x+e1,x+e2}. The four edge variables remain distinct. For Lambda_L={0,...,L-1}^2, the inventory Omega_L has 2L^2 signs, and a free plaquette is included exactly when its three cell bases lie inside Lambda_L. There are (L-1)^2 such plaquettes, including zero when L=1. Endpoints outside the square do not delete its declared outgoing edge variable. Normalized reference is 4^(-L^2), not unnormalized counting. Free r_L is the product of all 2L^2 edge factors and these internal plaquette factors. A fixed-exterior conditional instead includes every plaquette meeting Omega_L, with its exterior signs supplied. Entirely external factors cancel. Any further exterior-only or geometry-only scalar is a separate recorded raw factor.

The normalized dressed/frame bijection attaches independent normalized uniform frames. Summing those frame probabilities contributes one, not a volume factor. The finite reference and observation experiments therefore remain on the common four-symbol cell space.

There is a real placement issue in a literal reading of the target. The unshifted squares {0,...,L-1}^2 do not exhaust Z^2. Extending their finite laws by fixed plus exterior cannot converge on all fixed Z^2 cylinders to the positive infinite branch: a negative-coordinate edge is plus with probability one for every L, whereas UC nonnullness makes its minus probability positive under the branch. This is an exact counterexample to an unqualified full-lattice local-limit assertion, even in the c=0 control. No O(L) log bound repairs it.

A sufficient construction is to use the same square shapes and inventories but explicitly embed them in the bulk: translate by minus floor(L/2) in each coordinate before comparing fixed cylinders. Equivalently compare a cylinder A translated by centers x_L with dist(A+x_L,Lambda_L^c) tending to infinity. For an a-block comparison choose the fine translation a*x_L, so the channel grid and word remain aligned. These translations change neither partition sums nor stationary density limits. All local-limit statements below use this declared placement. If the contract instead requires local convergence at a permanently fixed unshifted corner, that demand is not proved and is false for the fixed-exterior extensions just described.

For fixed c<1/12, choose t=(1+12c)/(24c)>1, q=12ct=(1+12c)/2<1, r=1/t and C=16q/(1-q). UC08-UC13 give, for target coarse cells A and a whole-block oracle with margin R, TV <= C |A| B^2 (R+1) r^(R+1), capped at one. Source c=0 is handled by exact independence. For compact-uniform bounds replace c by c_plus and b by its relevant upper bound in the nonnullness constants. This restores a B-independent positive domain with an explicit fixed-B cost.

A free finite field is not itself an all-touching finite conditional at its outer boundary. However, conditioning it on the annulus around a target volume whose incident plaquettes remain wholly in the free inventory gives exactly the usual all-touching interior row. Compare that row with the admitted infinite Gibbs row uniformly over the annulus/exterior using UC, and integrate. The same argument works directly for arbitrary changing fixed exteriors. Hence bulk-placed finite prior cylinders converge to the unique branch law with the displayed interior-margin bound. The finite free family is not asserted projectively consistent.

## IP02. First moment, boundary comparison, and pressure

Take the native Hamiltonian H=-log r. The on-site term is minus the sum of two log edge factors; its sup norm is bounded by 2b/(1-b). A plaquette term has diameter one on its three-cell support and sup norm at most -log(1-c)<=c/(1-c). Exactly three translated plaquette supports contain any fixed cell. Thus

    K <= 2b/(1-b)+3c/(1-c),    M <= Mbar := 3c/(1-c).

This three-incidence count is at the cell level, not the four-edge plaquette count. Singletons contribute no first moment. The interaction is finite range here; for canonical coarse interactions use their complete first moments established in IP03.

For any translation-invariant potential with K=sum_(A contains0) norm(Phi_A,infinity) and M=sum_(A contains0) diam(A) norm(Phi_A,infinity)<infinity, let b_L be the sum of norms of supports meeting both Lambda_L and its complement. At a cell x of inner distance d, any such support has diameter at least d. Summing the incident tail over x overcounts only nonnegative terms. There are at most 4L cells at each inner distance; summing the diameter tails gives exactly M. Consequently b_L<=4ML. Fixed-exterior energy differs from free energy by at most b_L, and their log partitions by at most b_L. Normalizing adds a second b_L, so every mass log ratio is at most 2b_L<=8ML. Integrating an exterior distribution gives the same inequality for an actual Gibbs marginal versus the free mass. This is a logarithmic comparison, not a local-convergence argument.

Tile a large L-square into floor(L/n)^2 n-squares and a leftover set R. Deleting interactions crossing tile boundaries or touching R changes the Hamiltonian by at most 4M floor(L/n)^2 n+K|R|. Normalized counting on R has partition one. The same bound therefore compares log Z_L to floor(L/n)^2 log Z_n. At fixed n, limsup and liminf of p_L=L^(-2)log Z_L lie within 4M/n of p_n. Their difference is at most 8M/n for every n, hence zero. This constructs p and proves abs(p-p_n)<=4M/n. In particular abs(log Z_L-Vp)<=4ML for free partitions and <=8ML for fixed-exterior partitions, V=L^2. Normalized actual marginals do not introduce an infinite Z.

## IP03. A complete canonical vacuum-pressure oracle

At every fixed B, UC gives the actual positive everywhere coarse specification gamma^B. Let rho=[b(1+c^2)+2c]/[1+c^2+2bc] and m=(1-rho)^2/4>0. Each cell conditional atom, including the finite constrained-oracle row, is at least m. Fix the translation-invariant lexicographic order and vacuum *= (+,+). With past inside radius j and vacuum elsewhere, define e_(x,j)=-log[gamma_x(sigma_x|eta^(x,j))/gamma_x(*|eta^(x,j))]. Let A_(x,j) contain x and that truncated past. Define Phi_A0=e_0 and Phi_Aj=e_j-e_(j-1). These are the actual UP02 canonical representative, not a scalar-free Walsh interaction.

For j>=1, two consecutive exteriors agree through radius j-1. The UC atom/TV estimate and integral derivative bound for log give

    norm(Phi_Aj,infinity) <= D B^2 j r^j,    D=2C/m.

The singleton bound can use the rational conservative value 1/m. At most (2j+1)^2 translates of A_j contain the origin, and diam(A_j)<=2j. Thus rational computable bounds are

    Kbar_B = 1/m+D B^2 sum_(j>=1) j(2j+1)^2 r^j,
    Mbar_B = 2D B^2 sum_(j>=1) j^2(2j+1)^2 r^j.

Both series and their tails are rational for rational r: expand the polynomials and repeatedly apply r*d/dr to the geometric series, or bound a finite tail after its polynomial/geometric ratio drops below any fixed rational number less than one. No exponential constant must be numerically guessed. The norm tail after shells N is at most D B^2 sum_(j>N) j(2j+1)^2 r^j. Its explicit decay constructs a finite N for every prescribed positive norm error. These fixed-B constants are valid throughout c<1/12, not just 6Bc<1.

For each j<=N and every pattern on its finite support, approximate gamma_x(.|eta^(x,j)) by a finite whole-block constrained fine field on an anchor square of radius S>=j. Include both target paths whole and unconstrained; prescribe every other retained path parity in the square according to eta, keep unused singleton blocks free, and use an arbitrary fixed fine exterior. There are exactly 2B^2(2S+1)^2 fine signs before constraints. All four target states have positive mass. Complete finite enumeration with rational raw factors and exact conditional counting computes the entire row P_(j,S) rationally. UC bounds its atom error by tau_S=C B^2(S+1)r^(S+1). Since both finite and infinite probabilities are at least m, each log-odds error is <=2tau_S/m. This is a proved approximation to the actual infinite row, not an assertion that a finite window is exact.

There is a useful exact-arithmetic route that avoids exponentiating approximate real energy values. Retain ehat_j=-log[P_(j,S)(sigma_x)/P_(j,S)(*)] as a logarithm of an exact rational. Define the finite-shell potential by its differences. The exponential of minus each shell is a ratio of these rational row ratios. Hence the full finite free partition for this approximating potential is an EXACT rational finite sum over 4^(n^2) coarse states. It is not necessary to replace the log coefficients by rational values. Vacuum factors equal one exactly. This is a finite conditional-row approximation as allowed by the contract.

Let S_N=sum_(j=0)^N (2j+1)^2. Choose N with the true omitted norm tail <=epsilon/2, and choose the common fine oracle radius S sufficiently large that every ehat_j error <=epsilon/(4S_N). Each shell error is at most twice that amount, so complete incidence counting gives norm(Phi-Phihat,0)<=epsilon. This counts every translate, every local pattern and every retained shell. No omitted coefficient is presumed zero. The exact fine row enumeration has unbounded finite arithmetic cost; the old coarse_gibbs.py guarded implementation is not asserted to finish all these queries merely by raising max_edges.

For an n-square, the free energy discrepancy is bounded by n^2 epsilon; therefore abs(p_n(Phi)-p_n(Phihat))<=epsilon. Compute exact rational Zhat_n, and enclose log Zhat_n by the unbounded directed-log algorithm below to error at most n^2 eta. The interval for the desired canonical pressure has total error at most

    epsilon + eta + 4 Mbar_B/n.

Given any positive requested accuracy, choose the three budgets smaller than its thirds, then N,S,n and log precision by the explicit convergent bounds. All are finite and computable, uniformly on a supplied compact parameter box at fixed B. This constructs the requested pressure rather than assuming its value or modulus. A native free Z_n uses the simpler exact rational sum directly with Mbar from IP02. A shifted branch uses its shifted rational b and the same procedure. At c=0, the canonical product potential has only singleton factors and p_can,B=-2log(1+b^B), an independent elementary control.

For a positive rational x, find the integer k with x=2^k y and 1<=y<2 using exact integer comparisons. Set u=(y-1)/(y+1) in [0,1/3). The identity from integrating the geometric series is

    log y = 2 sum_(j=0)^(N-1) u^(2j+1)/(2j+1)+R_N,
    0<=R_N<=2u^(2N+1)/[(2N+1)(1-u^2)].

Use the same construction for log2 at u=1/3. Add k times that interval to the log y interval, reversing its endpoint roles when k<0. Choose each width at most requested_width/(abs(k)+1). Geometric decay terminates the search with finite Python int/Fraction arithmetic, without any fixed intermediate-size ceiling. Optional dyadic outward rounding uses floor/ceil and must receive its own error budget. The existing certified_logarithms.py explicitly guards inputs, powers, intermediate sums and outputs; increasing terms/bits inside that fixed guard is not this arbitrary-accuracy algorithm. No old guard is modified by this proof.

## IP04. Strict score selection and effective leakage

Let p_gamma be the native pressure for the declared raw representative, alpha_gamma the supplied logarithmic weight rate, and s_gamma=alpha_gamma+p_gamma. Set E_gamma(L)=U_gamma(L)+4M_gamma L for free partitions, or U_gamma(L)+8M_gamma L for fixed-exterior partitions. The supplied weight bound and IP02 give

    abs(log[a_gamma,L Z_gamma,L]-V s_gamma)<=E_gamma(L).

For a unique maximizing star and Delta_delta=s_star-s_delta>0, take the ratio to the star term in the full positive label normalizer. This proves

    1-W_star,L <= sum_(delta!=star) exp[-V Delta_delta+E_delta(L)+E_star(L)].

It is a full finite ratio estimate. No limiting normalization is substituted. Since native pressure is computable by IP03 and alpha has certified evaluations, a strictly positive rational lower gap can be found by refining disjoint score intervals whenever a true unique maximum exists. An overlapping interval is undetermined, not a tie.

A terminating leakage modulus follows explicitly. For each competitor choose a certified positive gap d<=Delta. Use the supplied U moduli to make both U_delta/V and U_star/V at most d/8. Require L>=16(M_delta+M_star)/d for free partitions, or32 times that sum/d for fixed boundaries. Then the total error is <=Vd/2. Choose an integer m with (|Gamma|-1)2^(-m)<=requested_leakage and L^2 d/2>=m for all competitors. Since exp(1)>2, exp(-x)<=2^(-floor(x)) for x>=0, so this threshold is certified without uncontrolled transcendental evaluation. The singleton catalog has leakage zero. Uniform selection over a parameter family additionally needs a uniform certified gap and uniform weight-growth data; pointwise unique maxima do not imply it.

## IP05. Exact tie ratios, subsequences, and limitations

Let S be the exact set of bulk-score maximizers. For gamma in S write t_gamma,L=log a_gamma,L-V alpha_gamma+log Z_gamma,L-V p_gamma. Every label outside S has a strictly positive gap because the catalog is finite, so its weight tends to zero. Define v_gamma,L=exp(t_gamma,L)/sum_(delta in S)exp(t_delta,L). Then W_gamma,L=(1-W_(S complement),L) v_gamma,L on S. Consequently the retained label weights converge if and only if this normalized vector v_L converges. Bulk-placed branch local convergence from IP01 then makes labeled cylinder convergence equivalent to weight convergence: necessity follows by the label event itself; sufficiency is a finite weighted sum of branch cylinders. Every subsequential limit is the corresponding mixture of the same branch laws with a subsequential limit of v_L.

An effective tied output requires certified exact equalities defining S, a certified complement gap when nonempty, and a supplied effective convergence modulus for v_L. Surface bounds and pressure intervals alone provide none of these equality/tie decisions.

For a concrete normalized native control, take two identical admitted branches, alpha=0, and a_2,L=1. Let a_1,L be2 for even L and1/2 for odd L. Exact label weights oscillate between2/3 and1/3 despite identical pressures, and the bounded log-weight remainder is o(V). Alternatively take a_1,L=2^L: one tied label wins with subextensive log growth L log2. Taking a_1,L=1/L instead makes its limiting weight zero subexponentially. All weights are positive rational and their logarithmic moduli are explicit; these examples work with primary positive c as well as the product control. Pressure-score equality never fixes the finite label mixture.

## IP06. Infinite hierarchy, compensation, and scalar conventions

The retained-label law P_h(gamma,dz)=w_gamma mu_gamma(dz) is a finite sum of admitted probability measures. Its normalization and countable additivity require no infinite partition. Finite free/fixed-exterior bulk approximations converge to it by IP01. An infinite normalized observation joint can be attached using independent uniform auxiliary coordinates to generate each binary sensor conditional on z and gamma; every finite observation marginal is the specified normalized product kernel.

For finite free branches, setting a_gamma,L=w_gamma/Z_gamma,L gives W_gamma,L=w_gamma exactly. The native Z is positive rational, so this is an exact computable finite counterterm. By contrast bulk-only a=w exp(-Vp_gamma) gives label weights proportional to w times exp(log Z_gamma,L-Vp_gamma). The surface bound permits those factors to oscillate, vanish relatively, or dominate; it cannot establish the desired weights.

An explicit allowed boundary-scalar control demonstrates the failure. Take identical native branches and multiply the first branch raw factor by the separately declared boundary-only scalar2^L. Its normalized state law and bulk pressure are unchanged, but its finite Z is multiplied by2^L. Bulk-only compensation then selects that branch, whereas exact compensation still gives w. This example explicitly changes a permitted boundary scalar; it is not presented as a calculation of an uncomputed surface free energy for two different bare native parameters. If a narrower statement bans all such additional scalar conventions, this particular counterexample does not establish failure inside that narrower bare-factor-only class. The general tie-ratio characterization above still applies.

For any absolutely summable representative Phi, define its vacuum energy density v_Phi=sum_(A contains0) |A|^(-1) Phi_A(*). Allocation and first moments bound its finite vacuum energy error by4ML. A canonical vacuum representative Psi of the same unique law has every term zero at vacuum. Compare both free masses to the common actual marginal, with log error <=8(M_Phi+M_Psi)L. At the common vacuum, normalized counting cancels and gives

    p(Psi)=p(Phi)+v_Phi.

Thus the initial scalar density converting Phi to the canonical vacuum convention is -v_Phi. It must be added to the raw geometry growth alpha to preserve alpha+p. It is computable from complete coefficient/function approximations and their summable tails, not merely from equality of normalized laws. For the native factors,

    v_native=-2log(1+b)-log(1+c),
    r_L(*)=(1+b)^(2L^2)(1+c)^((L-1)^2).

Its vacuum scalar includes the exact boundary correction -(2L-1)log(1+c) relative to the bulk rate. A scalar-free Walsh pressure cannot be substituted for canonical pressure without this conversion. A normalized reference change is equally part of the raw model, not an inferred constant.

## IP07. Normalized sensor and the actual-marginal posterior limit

For eta in(0,1), ell_eta(o|z)=(1+eta o z)/2 sums to one over o and lies strictly between zero and one. Direct multiplication proves

    (1+bz)ell_eta(+|z)=A(1+b_prime z),
    A=(1+b eta)/2,  b_prime=(b+eta)/(1+b eta).

There are exactly2V observed edges. Native free unnormalized selected mass has partition Z_obs,L=A^(2V)Z_L(b_prime,c). The finite posterior is exactly the free shifted-b family. For fixed exteriors the same identity holds with matching all-touching boundary partition conventions. b_prime is positive rational, less than one because (1-b)(1-eta)>0, and increasing in both inputs. The shifted upper endpoint (b_plus+eta_plus)/(1+b_plus eta_plus)<1 gives an admitted compact box with the same c_plus<1/12. No arbitrary likelihood-tilted uniqueness theorem is assumed. At eta=0 use b_prime=b,A=1/2 directly.

For an actual-marginal prior mu restricted to the window, the free identity is not exact. IP02's marginal/free ratio implies its evidence differs from free evidence by at most8ML in logarithm. Its posterior relative to the free shifted posterior has log ratio at most16ML, after the evidence normalization. These are sufficient surface bounds for densities but are not a local-limit proof.

For that proof, extend the finite posterior to the full lattice by tilting mu with the finite sensor product inside Omega_L. In any finite target neighborhood whose edges and incident plaquettes are within the observed window, conditioning on its complement leaves the original local Gibbs factors multiplied by precisely the sensor factors at its free edges. By the exact identity this is the shifted-family conditional row. The remaining observations and annulus contribute only an arbitrary exterior mixing law. UC's shifted-family every-exterior comparison then forces its bulk target marginal to the unique shifted law as the interior margin grows. This applies to actual marginal priors, free priors and fixed-exterior priors after the same conditioning argument. It requires the explicit bulk placement in IP01. It is a limit of positive finite-evidence preparations, never conditioning on an infinite all-positive event.


## IP08. Evidence pressures and the two posterior selection problems

Write p_obs,gamma=2 log A_gamma+p_gamma_prime and g_gamma=p_obs,gamma-p_gamma. For native free boundaries,

    abs(log e_gamma,L-V g_gamma)<=4(M_gamma+M_gamma_prime)L.

For matched fixed exteriors the corresponding bound is8(M_gamma+M_gamma_prime)L. For an actual-marginal prior, comparison to the free evidence adds8M_gamma L, so the sufficient total bound is(12M_gamma+4M_gamma_prime)L. Native M can be bounded independently of b, but this does not justify reusing the free-boundary constant in a different boundary convention. All these bounds follow by integrating a pointwise positive log-ratio bound; they do not establish local convergence.

The fixed hierarchy has evidence sum_gamma w_gamma e_gamma,L. A finite log-sum-exp sandwich gives its per-cell log evidence limit max_gamma g_gamma. Its posterior label weights are proportional to w_gamma e_gamma,L and are governed by the scores g_gamma. The globally normalized free factor family has evidence

    [sum_gamma a_gamma,L A_gamma^(2V) Z_gamma_prime,L]
    /[sum_gamma a_gamma,L Z_gamma,L].

Its evidence rate is max_gamma(alpha_gamma+p_obs,gamma)-max_gamma(alpha_gamma+p_gamma). Its posterior label scores are alpha_gamma+p_obs,gamma, not g_gamma alone. The same limits hold for specified matched fixed-exterior conventions with their own error envelopes. When native free Z sets the label weights but the state branches are replaced by actual marginals, the numerator differs from the free numerator only by the evidence comparison envelope; the sufficient error for its gamma term is U_gamma(L)+(8M_gamma+4M_gamma_prime)L. This is not an equality of the finite preparations.

IP04's gap search and leakage proof apply to each of these score families once its computable envelopes are supplied. IP05 applies separately to its actual subextensive remainders. Surface control alone does not identify tied posterior weights across free, fixed and actual-marginal preparations. The labeled local posterior limit exists when those posterior label weights converge, using the independent shifted-law local proof in IP07 for the branches.

The sensor selected evidence is at most((1+eta_gamma)/2)^(2V), hence g_gamma<=2 log((1+eta_gamma)/2)<0. The infinite all-positive event has probability zero in this primary regime: its probabilities on increasing observation sets tend to zero. The limiting posterior here is defined by finite preparations and the explicit bulk placement. No conditional probability on that zero-probability infinite event is invoked.

## IP09. Stationary entropy, energy and the two specific VFE limits

Let Q_gamma be any stationary probability on the four-state cell shift. It need not be ergodic, Gibbs or strictly positive. Entropies use0 log0=0. Finite entropy subadditivity over disjoint n-squares, with a remaining-strip entropy at most its number of cells times log4, gives

    s(Q_gamma)=lim_L H(Q_gamma,L)/L^2=inf_n H(Q_gamma,n)/n^2.

To see existence explicitly, the tiling inequality gives limsup_L H_L/L^2<=H_n/n^2 for every n. The infimum over n is at most every sequence element and therefore at most the liminf. These inequalities identify the limit. No ergodic theorem is needed.

For a translation-invariant summable potential Phi, allocate each term equally to its incident cells. The series

    e_Phi(Q)=sum_{A containing0} E_Q[Phi_A]/abs(A)

is absolutely convergent. Stationarity makes the expectation of the full allocation over Lambda_L equal V e_Phi(Q). The difference from its free internal energy is bounded in absolute value by the crossing inventory b_L<=4ML, because each crossing term is allocated with a coefficient between zero and one. Normalized counting then gives the exact finite identity

    D(Q_L||P_Phi,L^free)=-H(Q_L)+V log4+E_Q[H_Phi,L]+log Z_Phi,L.

It follows that the specific relative entropy is

    h_Phi(Q)=log4-s(Q)+e_Phi(Q)+p(Phi).

The actual-marginal comparison changes the finite relative entropy by at most8ML, so the same limit holds against the actual Gibbs marginals. Zero Q atoms cause no problem because the target Gibbs marginals are positive. This is a finite-window relative entropy limit, not an infinite relative entropy subtraction.

Define the bounded stationary selected log-likelihood average

    l_gamma(Q_gamma)=E_Q_gamma[sum_{i=1}^2 log((1+eta_gamma z_(0,i))/2)].

The expectation of the finite selected log likelihood is exactly V l_gamma by stationarity. For q=(q_gamma), a fixed probability on the finite labels, write F_L=D(q_gamma Q_gamma,L||P_L)-E_Q log ell_gamma(+|z). The hierarchy has

    lim_L F_L/V=sum_gamma q_gamma [h_gamma(Q_gamma)-l_gamma(Q_gamma)].

Its label entropy and finite q_gamma log(1/w_gamma) costs vanish after division by V. The factor family has

    lim_L F_L/V=sum_gamma q_gamma
      [h_gamma(Q_gamma)-l_gamma(Q_gamma)+s_star-s_gamma],
    s_gamma=alpha_gamma+p_gamma,  s_star=max_delta s_delta.

Indeed -log W_gamma,L/V tends to s_star-s_gamma by the finite log-sum-exp bound, even when tied label weights oscillate. These statements use the branch convention and comparison bounds already declared. They do not require convergence of the entire finite labeled law.

The exact sensor identity also yields

    h_gamma_prime(Q_gamma)=h_gamma(Q_gamma)-l_gamma(Q_gamma)+g_gamma.

This follows either from the finite posterior identity and its surface extension or by adding the shifted energy and pressure terms. An additive raw-energy constant changes e and p with opposite signs, so h stays fixed. Its contribution to the geometry competition alpha+p cannot be discarded without transferring the matching phase scalar. Although the entropy limit exists for every stationary Q, these arguments provide no computable entropy convergence modulus for an arbitrary presentation of Q. A numerical VFE oracle for arbitrary stationary recognition is not claimed.

## IP10. Label support and limits that cannot be interchanged

Suppose the finite labeled laws converge to weights W_gamma,infty and branch laws mu_gamma. If q_gamma>0 for a label with W_gamma,infty=0, the limiting joint assigns zero mass to the whole event {Gamma=gamma}. Relative entropy from q_gamma Q_gamma,L to that limiting joint is already infinite on every finite window. This is compatible with a finite limit of the finite-ensemble relative entropies divided by V.

For a concrete example with two identical primary-domain branches, take a_1,L=2^(-V), a_2,L=1, q_1=1 and Q_1=mu_1. The finite branch relative entropy density is zero and the finite label cost divided by V tends to log2. The limiting label1 mass is zero, so its limiting-joint relative entropy is infinite. The subextensive tied example a_1,L=1/L, a_2,L=1 instead has finite label cost log(L+1) and zero limiting label cost density, while the limiting-joint relative entropy remains infinite. For a_1,L=2 on even L and1/2 on odd L, a_2,L=1, the label law has no limit, but its relative entropy cost per cell still tends to zero. All three use exact rational weights and positive finite labels.

If q is supported entirely on labels with positive limiting weights, those labels have maximal bulk score. Their limiting-joint label cost is a finite constant independent of L, and the factor penalty s_star-s_gamma vanishes on that support. The limiting-joint specific relative entropy agrees with sum_gamma q_gamma h_gamma(Q_gamma), and the corresponding VFE with sum_gamma q_gamma(h_gamma-l_gamma). This is the required support-qualified agreement. Apply it separately to prior and posterior label preparations. It does not justify conditioning a limiting prior on the zero-probability all-positive observation event.

Keeping the finite label is part of the construction. The prior admitted geometry-erasure counterexamples show that a mixture of distinct branches need not inherit a local Gibbs description merely because each branch has one; even a small local-action neighborhood does not remove the global mixture obstruction. No unlabeled Gibbs or differentiable geometry closure follows from the finite-label pressure maximum.

## IP11. Fixed-word area, the raw anchor and the actual boundary comparison

Fix an integer block a and then take L to infinity. The fine square contains2(aL)^2 sign coordinates and the coarse square contains2L^2. Each coarse outgoing edge is the parity of its own straight length-a fine path. These paths are disjoint: same-orientation segments occupy disjoint consecutive blocks and the two orientations are different edge coordinates. Their union has2aL^2 coordinates, with all other fine edges still integrated. Consequently each coarse sign assignment has exactly

    2^[2a^2 L^2-2L^2]

fine preimages. The fine normalized counting reference pushes to the coarse normalized counting reference4^(-L^2). There is no extra unnormalized fiber volume. For a word the product B replaces a; a bulk recentering must use a fine translation a times the chosen coarse translation to preserve the anchored block grid.

Let tilde_r_a,L be the full raw pushforward, defined as the conditional average of the fine raw density under its normalized reference. Put zeta_a,L=tilde_r_a,L(vacuum), and hat_r_a,L=tilde_r_a,L/zeta_a,L. Positivity ensures zeta>0. Exact finite summation gives

    Z_Phi,aL=zeta_a,L Z_hat_r_a,L.

All unused variables and every coefficient of the raw density participate in this equality. The initial fine raw representative need not be vacuum anchored, but an identity-block canonical statement will require that premise explicitly.

Let Psi=R_a Phi denote the complete canonical vacuum representative of the actual pushed infinite law. The fine actual marginal and the fine free law have a pointwise log-density ratio bounded by8M(Phi)aL. Integrating on the fixed path fibers preserves the same bound. The pushed actual marginal equals the corresponding marginal of the pushed infinite law exactly, because all these paths lie inside the chosen fine window. Comparing this actual coarse marginal to the canonical coarse free law gives8M(Psi)L. Thus

    abs(log(P_fine_free,push(y)/P_Psi,coarse_free(y)))
      <=8[a M(Phi)+M(Psi)]L

for every coarse atom y. This is the necessary finite-to-infinite bridge; equality of the limiting law alone would not supply it. Both hat_r and the canonical coarse raw density equal one at the vacuum, and both use reference4^(-L^2). Evaluation of the last inequality at that atom gives

    abs(log Z_hat_r_a,L-log Z_Psi,L)
      <=8[a M(Phi)+M(Psi)]L.

Hence L^(-2)log Z_hat_r_a,L tends to p(Psi). A finite pushforward of a fine free law need not equal the canonical coarse free law. Only the stated comparison, its pressure consequence, and the separate bulk local limit have been established.


## IP12. Scalar composition, phase transport and an exact preference reversal

IP11 proves the scalar limit

    sigma_a(Phi)=lim_L log zeta_a,L/L^2
                =a^2 p(Phi)-p(R_a Phi).

On the actual canonical orbit, R_d(R_a Phi)=R_(ad)Phi. Therefore direct cancellation gives

    sigma_(ad)(Phi)=d^2 sigma_a(Phi)+sigma_d(R_a Phi).

These equalities hold for fixed a,d before the volume limit. For the canonical vacuum representative, the identity block leaves the raw density and its vacuum value unchanged, so sigma_1=0. A native or scalar-free Walsh representative requires the separate initial conversion from IP06. In particular the native vacuum value need not equal one. Calling a different representative the identity input does not make its omitted constant disappear.

For a finite word, sequential raw conditional averages with their actual intermediate anchor normalizations have an exact scalar product rule by finite summation. Those intermediate anchored raw functions need not be canonical free Hamiltonians. IP11 supplies the boundary comparison required to replace their partition densities by canonical ones. More explicitly, if two normalized finite laws have log ratio at most D L and both raw densities equal one at the same anchor, their raw log ratio is at most2D L. A fixed-channel raw average preserves that latter bound, so the logarithms of the next anchors differ by at most2D L. Thus the canonical replacement costs only a surface term for each member of a fixed finite word. This is not a uniform statement for a word whose length or block product grows with L.

The coarse phase rate must be

    alpha_gamma_prime=a^2 alpha_gamma+sigma_a(Phi_gamma).

Adding its coarse canonical pressure gives a^2(alpha_gamma+p(Phi_gamma)), preserving the bulk competition. The exact finite scalar sequence, not only its rate, remains necessary when tie weights depend on subextensive terms. A computable pressure oracle for Phi and R_a Phi yields an arbitrarily accurate scalar-density interval by ordinary interval subtraction with the a^2 factor. The hierarchy can instead keep w_gamma fixed and compensate exactly at every finite volume; it is a different normalized construction.

The separate c=0 product control gives an exact reversal if the anchor scalar is dropped. Take b_1=3/4,b_2=1/4, block a=2, native a_1,n=(9/8)^(n^2),a_2,n=1. Native Z_gamma,n=1, so the fine factor competition selects label1. Raw block pushforward is the product of(1+b_gamma^2 y). Its vacuum anchor is(1+b_gamma^2)^(2L^2), and its canonical coarse pressure is-2 log(1+b_gamma^2). Keeping the anchor gives coarse score difference4 log(9/8)>0. Dropping it instead gives

    4 log(9/8)-2 log(25/17)=2 log(1377/1600)<0.

The preferred label is then reversed. Every displayed inequality is an exact rational comparison inside a logarithm. This is explicitly the allowed product control, not a primary positive-c numerical witness. The calculation starts from the native raw product and records its coarse anchor; it does not silently assume the native initial density was already vacuum normalized.

## IP13. The induced observation experiment and the finite-fiber density loss

Retain the entire finite observation alphabet and the label. For each branch let T be the fixed fine-to-coarse path channel and e_gamma,L its selected evidence. The induced selected likelihood is

    ell_gamma,L_prime(o_plus|y)
       =e_gamma,L P_gamma,L,post,push(y)/P_gamma,L,prior,push(y).

This follows by summing P_prior(x)ell(o|x) on each fiber and dividing by the pushed prior. For the full observation alphabet, summing this induced kernel over o gives one. Every coarse atom has a nonempty path fiber and the prior is strictly positive, so the denominator is positive in this model. In more general finite input families this construction must preserve undefined prior-null fibers instead of inventing a conditional row; the prior normalized-geometry support theorem remains the authority there.

The induced experiment is not a fresh local sensor on the coarse edges. Already in the separate eta=0 control the probability of the selected fine observation is4^(-B^2 L^2), independent of y. A fresh eta=0 sensor on the coarse window would give4^(-L^2). These differ for B>1. Renaming the fine observation as a coarse one does not preserve the experiment or its evidence.

Let Q_B,gamma be the exact path pushforward of the stationary Q_gamma. It is stationary under coarse translations because those are fine translations by B. Its coarse Lambda_L marginal is the pushforward of the fine Lambda_(BL) marginal; all required paths lie inside that fine coordinate inventory. Let h_gamma,post,1(Q_gamma) denote specific relative entropy against the shifted fine posterior Gibbs law, and h_gamma,post,B(Q_B,gamma) the corresponding quantity for its complete canonical coarse pushforward. Both limits exist by IP09. IP07 and IP11 give a surface log comparison between the actual finite pushed posterior preparation and the actual coarse shifted-law marginals, so their relative entropy densities coincide. This use of surface comparison concerns entropy densities; their local limits still use the separate UC argument.

The exact finite coarse VFE is

    sum_gamma q_gamma log(q_gamma/W_gamma,BL)
    +sum_gamma q_gamma [D(Q_B,gamma,L||P_gamma,BL,post,push)
                         -log e_gamma,BL].

The hierarchy and factor cases therefore have the respective coarse per-cell limits

    f_coarse,h=sum_gamma q_gamma
      [h_gamma,post,B(Q_B,gamma)-B^2 g_gamma],

    f_coarse,f=sum_gamma q_gamma
      [h_gamma,post,B(Q_B,gamma)-B^2 g_gamma
       +B^2(s_star-s_gamma)].

The fine per-cell formulas are the same with B=1. The factor label term uses the actual fine window of area B^2 L^2. Its posterior label competition does not replace this prior-label term in the VFE definition; expressing the VFE through the total posterior and total evidence gives the same identity after cancellation.

Apply the finite KL chain rule to the full labeled posterior joint and the fixed T channel. It gives a nonnegative conditional-fiber contribution at every finite window. All displayed fine and coarse VFE density terms have separate limits, so their difference has a limit and

    B^2 f_fine=f_coarse+k_fiber,
    k_fiber=B^2 sum_gamma q_gamma h_gamma,post,1(Q_gamma)
             -sum_gamma q_gamma h_gamma,post,B(Q_B,gamma)>=0.

The evidence and label terms cancel exactly. This is the limit of the finite conditional relative entropy contributions; it is not a subtraction of undefined infinite relative entropies. For the identity block the fiber is a point and the loss is zero. As a counting check in the separate fair product control with deterministic stationary recognition, the entropy-capacity difference is(B^2-1)log4 per coarse cell. No interpretation of this loss as an optimal reduced-family gap or an autonomous inference closure is made.

All these conclusions hold for each fixed finite word B. Letting the word, its depth or the observation window convention vary with L would require uniform comparison and recognition-entropy bounds that are not supplied here.

## IP14. Constructive interfaces, explicit limits and the remaining placement condition

The mathematical computation is divided into finite objects with declared error obligations. Native or shifted native factors admit exact rational finite partition sums under normalized counting. The all-exterior UC construction supplies unique branch laws, conditional comparison bounds and a nonnullness margin. Exact finite constrained conditional rows approximate the complete canonical lexicographic log-odds potential; IP03 supplies the omitted-shell bounds and an explicit finite M bound, followed by a terminating pressure approximation. A rational directed logarithm series supplies a certified log for arbitrary positive rational arguments without importing the old fixed bit guard. Thus no finite Walsh truncation or finite cylinder marginal is substituted for the whole canonical pressure.

The weight interface provides certified log a, alpha intervals and a subextensive modulus. Combining these with pressure intervals gives certified score and strict-gap selection. A tied-weight interface needs certified equality and the additional subextensive normalization modulus; neither generic computable real equality nor tie convergence is decided from numerical overlap. The sensor interface retains the full observation kernel and records A,b_prime. The fixed-word interface records the product B, common counting references, the literal block phase, the shared vacuum anchor, the boundary convention and the B^2 area conversion. It transports alpha with the computed scalar density. Exact finite scalar compensation remains a separate operation when the hierarchy, rather than only its bulk phase rate, is to be preserved.

For VFE limits the recognition input is any stationary law Q. Their existence is proved in IP09 and IP13. A computable numerical VFE value additionally requires a presentation providing the needed entropy and energy approximations; no effective rate is invented for arbitrary stationary recognition. Similarly the mathematical pressure algorithm has finite work for each fixed positive tolerance and admitted compact input, but the sizes of its complete conditional and partition enumerations can be enormous. The old certified_logarithms source has a65536-bit guard and is not this unbounded arbitrary-accuracy logarithm algorithm. The existing coarse_gibbs exact finite routines also have resource admission and guarded Fraction arithmetic. They are prior finite interfaces, not evidence that this newly specified complete algorithm has been implemented or executed.

An explicitly extensive geometry action exp(-V A_gamma) shifts alpha_gamma to alpha_gamma-A_gamma. An order-one or surface-order scalar has zero bulk rate but may still change tie weights. A state-dependent extra action changes the branch specification and its pressure and must be checked against the hypothesis class; it cannot be added while silently retaining the same uniqueness or pressure oracle. Frame references remain normalized, and no extra frame count is attached to the common cell reference. The branch generating action, a connection or base curvature, and the statistical Fisher metric remain different specified objects. The pressure maximum and these scalar identities do not assert a differentiable geometry mixture or a new curvature theorem across a score tie.

The one literal boundary issue identified in the initial contract reading is the meaning of local convergence for Lambda_L={0,...,L-1}^2. These unshifted windows do not exhaust Z^2. IP01 gives an exact counterexample to full-lattice local convergence of their fixed-exterior extensions. The sufficient repair is explicit recentering or, equivalently for the pressure calculations, comparing cylinders translated into the bulk with distance to the boundary tending to infinity. The construction above uses that placement openly. If the frozen target insists on unshifted fixed-corner full-lattice convergence, that assertion remains false; a surface pressure estimate cannot repair it.

IP06's boundary-scalar counterexample is in the contract's stated boundary/counterterm scope. It does not independently prove that bulk compensation fails for a particular pair of distinct bare native free Hamiltonians when every additional boundary scalar is prohibited. The ratio criterion for those bare models is nevertheless exact. No stronger narrow-class counterexample is inferred from the generic O(L) surface bound.

This is an initial independent proposed construction, not a native evidence closure. No current counterpart proof, implementation candidate, current source or numerical packet has been read. No scientific import, test or experiment has been run by this lane. The shared model, inherited conversation and common filesystem limit independence. All mathematical ingredients used here are direct finite-sum/series/tiling arguments or the explicitly named prior admitted UC/UP results. No new external primary source has been opened; a claim of literature verification would require a separate current source read. The next stage may check current source-to-recurrence correspondence and counterpart hypotheses only after this initial pair is frozen and the parent authorizes access.


## Frozen initial input bindings

The contract and plan and the three listed prior proof files were read in full in this initial phase. Both listed old source files were read as text, not imported. SPEC was read in full earlier in the continuous lane and its unchanged hash is checked here. The older coarse pressure proof supplies only its elementary summability, boundary and entropy argument; its smaller fixed-B coupling domain is not substituted for the current UC domain. Eight introductory lines of the prior basin weighted-row note were also viewed, but no mathematical result from that note is used in this construction. The prior normalized-geometry support/erasure scope was read in the immediately preceding accepted phase; every finite identity needed here is rederived above. No current counterpart file was opened.

| Repo-relative input | SHA256 |
| --- | --- |
| Theory/SPEC.md | dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1 |
| docs/derivations/2026-09-09-geometry-pressure-rg/problem-contract.json | 41b61a4767f7c5b9ef350cb7696484d7f358cafe3ef1574b58baf3d13728786b |
| docs/derivations/2026-09-09-geometry-pressure-rg/execution-plan.md | 947a8cbe143acb63d73ce3a931d909ee97805e18e29fa7280ba20fd063f9d709 |
| docs/derivations/2026-09-09-uniform-depth-gibbs-rg/agents/uniform-coupling-construction.md | e09c831abae9432637659be974711c36ffd9d22fa90c7735737ca746a5cec67d |
| docs/derivations/2026-09-09-uniform-depth-gibbs-rg/agents/uniform-potential-vfe.md | 693e0ce9aa433f04f8785974fc5b852192571a9390ae9379413dec9de929eee3 |
| docs/derivations/2026-09-09-coarse-gibbs-rg/agents/potential-vfe-construction.md | 5f88d35b3017526faa0cf4b3c0af650634d1022032f743772eca45eb732d75f5 |
| src/multiagent_elbo/rg_v2/coarse_gibbs.py | 1957146b6f3e63f6e374855e8992b5caaae89f13b979e74728963508541cbdbd |
| src/multiagent_elbo/rg_v2/certified_logarithms.py | 1eb6db2b17d1ad4598e2e1bf69f89b44afa0501ef8b2cd8349298475b2dc639c |

Initial freeze records IP01 through IP14. The literal fixed-corner placement issue remains explicitly visible as a hypothesis/interpretation obligation. Finite source implementation and mechanical execution are outside this initial proof record.
