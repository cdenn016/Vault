<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e","target_digest":"81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e"} -->

# Author proposal-domain amendment

This amendment changes proposal bookkeeping, not the frozen derivation or any formula. The mature checker identified that GP38's separate c=0 product pressure cited the positive-c GP05 route, and that GP35's c=0 scalar-deletion control likewise inherited unnecessary positive-c premises. The product controls are proved directly by finite positive product factorization and require none of those dependencies.

The initial proposal bytes are retained verbatim in author-proposals-initial.json, SHA256 794e65fe49b7942eb96cae75a1a2adaf4c36ecc70dbb2fb7bd8403b480648baf. In author-proposals.json only GP35 and GP38 have changed: their dependency lists are empty, and their assumptions/derivation fields explicitly identify the c=0 product model and elementary finite calculation. GP35 compares the rational partitions at the stated b values; GP38 uses independent path parity mean b^B and the canonical two-edge vacuum normalization. Neither borrows a c>0-only claim. The amended proposal SHA256 is cd0cec8b483a09cea5d3515ba099773bf5149c1a8c4fd32f948d88318b4be5b2.

The frozen pressure-construction.md remains SHA256 ea08fefad3b5bb541632a1963d0c8281cddec87a0aaa9da4d7bdd421d8706783. No source, test, science or native state changed. This is author bookkeeping following the named domain objection, not a new proof or independent verification.
