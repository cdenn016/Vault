<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e","target_digest":"81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e"} -->

# Root vacuum-pressure and thermodynamic source correspondence

This is source-author correspondence before execution, under the frozen geometry-pressure contract. Root read GP01 through GP24 of pressure-construction.md at ea08fefad3b5bb541632a1963d0c8281cddec87a0aaa9da4d7bdd421d8706783, restored UC01 through UC19 and UP01 through UP10, and wrote the VP01 through VP07 candidate. No source import, test or numerical result is asserted in this document. Actual source completion remains conditional on exact input contracts and available finite resources.

## VT01. Rational complete moment bound

geometry_vacuum_pressure.vacuum_comparison uses q=(1+12c)/2, t=24c/(1+12c), C=16q/(1-q), the exact rational rho and m, and D=2CB^2/m. Its _moments recurrence follows from S_k=t sum_{j=0}^k binom(k,j) S_j, obtained by shifting the positive geometric series, isolating S_k. S_0=1/(1-t). The returned M=2D(4S_4+4S_3+S_2) is precisely VP02/GP05's complete first-moment bound. B appears as B^2 in D; no square root, approximate exponential or inherited scalar guard occurs. The zero-c branch is separate, as the positive-c contraction parametrization is not evaluated there.

## VT02. Whole-block cylinder and normalized factor inventory

The root _cylinder uses both outgoing axes at every fine basepoint in [-BR,B(n+R)-1]^2. This is the exact union of all fine blocks anchored in the coarse radius-R neighborhood of Lambda_n; its count is 2B^2(n+2R)^2. It invokes the actual uncapped geometric touching_plaquettes function and completes every required exterior edge by plus. The shared finite_factor_law returns all exact states, raw weights, normalized masses and physical partition. That helper is separately owned and its source must be frozen/read with this caller.

The target paths are straight_block_path((x,y,axis),B) for x,y in Lambda_n and both axes, indexed back into the full fine state. Summing precisely those masses whose complete path parities are plus gives the finite vacuum cylinder probability. No target parity is imposed on the generative law; every unused fine sign and every touching factor is retained. The helper's physical partition is not confused with this event probability.

## VT03. Outward canonical pressure at finite resolution

vacuum_pressure_at_resolution takes directed logarithms of the actual positive cylinder probability and 4. Their endpoints are combined with reversed signs to enclose -log4-log(q)/n^2. It adds the two explicit positive errors 12M/n and CB^2(R+1)t^(R+1)/m^(n^2). GP07/VP06 prove those quantities, using both finite and infinite cylinder lower masses m^(n^2). The complete receipt keeps input couplings, B,n,R, both log intervals, each error, the comparison constants and the actual full fine law. It identifies the UP02 vacuum representative.

At c=0, the exact independent cylinder probability is [(1+b^B)/2]^(2n^2). Its error terms are zero and no fine law is enumerated. The exact formula is still the canonical pressure -2log(1+b^B), not the native raw pressure zero. A caller's enumeration limit does not prohibit this nonenumerating elementary branch.

## VT04. Complete requested-accuracy algorithm and resource outcome

approximate_vacuum_pressure chooses n>=48M/epsilon, making the surface error at most epsilon/4. It increases R until the oracle error is at most epsilon/4. Positivity of m and t<1 prove finite termination at each fixed n. It asks each log for width epsilon/4 in final per-cell units; their combined interval width is at most epsilon/2. The total final width is therefore at most 3epsilon/2 and in particular at most 2epsilon, which the returned source checks.

The default eight-edge cap is inspected before allocation and at every candidate oracle margin. A stopped call returns VacuumPressureStop with B,n,R, required edges and the cap, and no pressure. Passing None gives the full finite search and exact arithmetic without a fixed size cap. It does not establish practical completion on every host. An invalid physical domain or negative resolution is refused; these are domain conditions, not mathematical counterexamples.

## VT05. Native scalar restoration and canonical RG density

geometry_thermodynamics.native_vacuum_pressure obtains directed log intervals for the exact native scalar density chi=2log(1+b)+log(1+c), then subtracts it from the source-bound native pressure interval. GP20 proves this initial conversion by common-law boundary comparison and both representatives' vacuum values. The record explicitly distinguishes an initial scalar conversion from identity blocking.

scalar_pressure_density requires identical b,c, coherent B_out=a B_in and the same representative descriptor, then computes a^2 p_in-p_out by outward interval arithmetic. Identity on the same canonical orbit is exactly zero, independently of finite enclosure width. compose_scalar_densities uses d^2 sigma_a+sigma_d. GP19-GP21 provide the finite boundary and complete scalar-cocycle premises. Distinct input intervals can widen a composed enclosure; that is retained uncertainty, not a failed exact composition.

## VT06. Sensor pressure and evidence

observation_pressure requires the shifted receipt to have the exact sensor b_prime and the unchanged c. It computes p_obs=2log A+p_shift with the actual rational A, then subtracts p_prior for branch evidence density. geometry_evidence_density takes the maximum branch evidence interval in the fixed-positive-weight hierarchy. With explicit alpha intervals it computes max(alpha+p_obs)-max(alpha+p_prior). These are GP12-GP14's full experiment formulas, not an extra unnormalized likelihood term.

The input prior and shifted pressure receipts name their actual b,c and raw representative. The sensor function retains all finite outputs in its public kernel. This interval adapter computes the selected finite-window preparation's asymptotic evidence; it does not condition on an infinite all-plus event.

## VT07. Specific VFE with explicit entropy inputs

specific_vfe_density takes an exact finite recognition-label probability q, certified finite intervals for the stationary branch specific relative entropies h and expected log likelihoods l, and optional prior score intervals s=alpha+p. It computes sum q(h-l), adding max(s)-sum q*s for a factor ensemble. This is GP17, with outward arithmetic for correlated unknown inputs still valid as interval overestimation. It does not compute arbitrary entropy rates. GP16 proves why stationarity and finite-cylinder queries alone cannot furnish that missing universal algorithm.

limiting_label_support checks separately whether q charges a zero limiting label weight. It returns infinite in that case even when the finite-ensemble density is finite or zero. Positive branch Gibbs masses make the label support criterion the relevant finite-window obstruction. This operation does not infer a limiting label vector from score overlap or a pressure result.

## VT08. The actual induced experiment and fiber rate

induced_vfe_density requires certified specific posterior KL intervals h_1(Q_gamma) and h_B(Q_gamma,B) for one stationary recognition family and its actual path push. The posterior scores and total evidence rate are per fine cell. Let R=max(s_post)-sum q*s_post. The code returns fine=sum q*h_1+R-evidence and coarse=sum q*h_B+B^2(R-evidence). Their fiber interval is B^2 sum q*h_1-sum q*h_B, with lower endpoint intersected with the proved nonnegative half-line. An upper endpoint below zero is rejected as inconsistent input.

GP13 and GP23 prove the posterior boundary comparison and all required specific limits; GP22 supplies the complete finite joint disintegration. No ordinary infinite KL is subtracted. The same formulas apply to hierarchy using posterior scores e_gamma and to factors using alpha+p_obs. Label and evidence rates cancel from the fiber density. A fresh coarse local sensor would supply different data and is not the stated experiment.

## VT09. Named finite controls, not results

The root vacuum test draft contains exact moment identities at t=1/2, a two-sign all-touching independent raw-product calculation, an eight-sign two-link path event, exact product-vacuum scalar controls, explicit budget outcomes and completed coarse bounds at a deliberately loose positive-c tolerance. No small-error result is inferred from the loose fixture. The thermodynamic draft uses native product pressure, exact sensor shifts, a scalar word with the required final area, a vanished-label support obstruction, and fair-product recognition with nonzero posterior fiber density. Their physical analytic formulas differ from simply copying the source interval arithmetic.

All tests are currently unrun. The planned single packet will include the worker's finite arithmetic tests and both root files after source/config review. It will not invoke old suites, heavy producers, GPU work, held experiments or user-excluded tamper/corruption/forgery checks.
