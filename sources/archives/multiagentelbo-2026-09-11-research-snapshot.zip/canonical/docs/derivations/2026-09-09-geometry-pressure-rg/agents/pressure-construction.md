<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e","target_digest":"81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e"} -->

# Labeled geometry pressure and actual induced-experiment RG: author construction

The actual frozen contract and execution plan were read first. The unchanged SPEC has SHA256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. This author constructed earlier spatial/finite-joint proofs and the discovery proposal. Discovery statements are not premises. The actual UC and UP proofs were read again. The root communicated its matching rational shell construction before this text was persisted; the shell and cylinder interfaces below therefore have shared-route provenance. This is an author proof, not independent verification. No new counterpart investigator file, source execution, tests, science or ledger state enters it.

## GP01. Common carrier, raw reference and finite inventories

**DEFINITION.** A fine cell x in Z^2 contains z_(x,1),z_(x,2), the outgoing horizontal and vertical signs. The plaquette at x has product z_(x,1)z_(x+e1,2)z_(x+e2,1)z_(x,2), so its cell support is {x,x+e1,x+e2}. Let Lambda_L={0,...,L-1}^2, V=L^2. Its free density relative to normalized counting 4^(-V) is the product of 1+bz over its 2V edges and of 1+cP over the (L-1)^2 internal plaquettes. Z_L is the finite reference average and nu_L the normalized law. All factors and Z_L are positive rationals for the admitted rational inputs. The fixed-exterior density instead includes all plaquettes whose cell support meets Lambda_L, completed by specified exterior dressed signs; exterior-only factors are excluded. Additional boundary scalars are distinct input.

**ESTABLISHED.** The native interaction has singleton energy -log[(1+bz_1)(1+bz_2)] and one plaquette energy -log(1+cP) per translated three-cell support. Integrating 1/(1-t) proves -log(1-t)<=t/(1-t), and therefore

    K <= 2b/(1-b)+3c/(1-c),    M <= Mbar:=3c/(1-c).                 (GP01.1)

Here K=sum_(A containing0)||Phi_A|| and M=sum_(A containing0)diam(A)||Phi_A||, in cell Chebyshev distance. Three plaquette incidences are counted at each cell; singleton diameter is zero. The admitted dressed/frame bijection transports normalized product counting to normalized product counting; independent normalized frame sums are one. Arbitrary fixed dressed boundaries are retained. Raw matter/link factorization under those boundaries is not assumed.

## GP02. Recentered local limits from actual finite conditionals

**ESTABLISHED.** Origin-based Lambda_L is bookkeeping, not an exhaustion of Z^2 around zero. For local laws translate it by -floor(L/2) in each coordinate before embedding in the full lattice. At final block B, translate the fine BL-square by -B floor(L/2) and the coarse L-square by -floor(L/2). Every fixed cylinder then has a diverging interior margin. Translation leaves the partition and stationary-recognition quantities unchanged. Without recentering or an equivalent bulk-cylinder convention, an arbitrary-boundary corner limit to the translation-invariant law is not asserted.

The admitted UC proof partitions edges into disjoint B-paths P_B(x,a)={(Bx+t e_a,a):0<=t<B} and unused singleton edges. Each anchor cell contains 2B^2 fine edges; no plaquette hits a retained path twice. UC03-09 give row Hamming cost at most 2c per changed incident plaquette and column incidence six. The finite coupled heat bath gives weighted contraction with 12c exp(theta)<1, including prescribed/absent parity patterns on whole blocks. This uses neither the old 6Bc domain nor a block-TV row sum.

For rational compact upper coupling c_+ in (0,1/12), choose

    t=24c_+/(1+12c_+), q=(1+12c_+)/2, C=16q/(1-q).                 (GP02.1)

Thus 0<t<1 and 12c_gamma/t<=q<1. UC08-10 imply that two conditional laws whose interior block patterns agree on the radius-R anchor neighborhood of a finite target A differ on that target by at most

    delta_(A,R)=C |A| B^2(R+1)t^(R+1).                             (GP02.2)

The boundary shell has at most 8|A|(R+1) cells and 2B^2 fine edges per cell. Integrating the uniform bound over boundary mixtures preserves it. A finite free volume has the same all-touching conditionals on an inner whole-block volume separated from its external boundary by a full plaquette layer. Apply the comparison there, then let its radius grow. Fixed-boundary finite laws, free laws and infinite branch marginals thus have the same recentered cylinder limits. UC supplies existence, consistent cylinder extension, DLR compatibility and uniqueness; this argument restores the required finite approximation to that law. At c=0 blocks are independent and boundary dependence is zero.

## GP03. Boundary and pressure without an infinite partition

**ESTABLISHED.** For any translation-invariant complete interaction with finite K,M, let b_L be its crossing norm. Put T(d)=sum_(A containing0,diam A>=d)||Phi_A||. A crossing support containing x has diameter at least dist(x,Lambda_L^c). At most 4L cells have each positive inner distance. Nonnegative overcounting gives

    b_L <= sum_(x in Lambda_L)T(dist(x,Lambda_L^c)) <=4LM.          (GP03.1)

An exterior changes the free Hamiltonian by at most b_L. An exponential sandwich bounds its partition log by b_L and normalized log-mass ratio by 2b_L. Integration over a Gibbs exterior gives the same latter bound for the actual marginal:

    |log(nu_L^boundary/nu_L^free)|<=8ML,
    |log(mu_L/nu_L^free)|<=8ML.                                   (GP03.2)

Tile a large L-square by floor(L/n)^2 n-squares with leftover set D. Terms touching D cost at most K|D| and tile crossings at most 4M floor(L/n)^2 n. Product normalized counting assigns partition one to D. The exponential sandwich confines both limiting upper and lower pressures to distance 4M/n from n^(-2)log Z_n. Their separation is at most 8M/n for every n and hence zero. Thus

    p(Phi)=lim_L L^(-2)log Z_L,    |p-n^(-2)log Z_n|<=4M/n.        (GP03.3)

A fixed-exterior partition log differs from L^2p by at most 8ML. These statements include M=0. They define pressure from finite sums, not an infinite unnormalized partition.

## GP04. Unbounded directed logarithms and the native oracle

**ESTABLISHED.** For positive rational x, integer comparisons find e with u=x/2^e in [1,2). Put v=(u-1)/(u+1), so 0<=v<1/3. Integrating the finite geometric identity gives

    S_N(v)=2 sum_(j=0..N-1) v^(2j+1)/(2j+1),
    0<=log u-S_N(v)<=2v^(2N+1)/[(2N+1)(1-v^2)].                  (GP04.1)

Use v=1/3 for log 2. Combine log x=e log 2+log u, reversing the log-2 endpoints for e<0. The remainder tends geometrically to zero. Choosing the two widths so their propagated sum is below a rational tolerance terminates with finite integer/Fraction arithmetic. An optional dyadic enclosure floors the lower and ceilings the upper endpoint and includes its rounding width. For a positive computable real, first find a certified positive rational lower endpoint, then use rational endpoint logs and continuity; positivity makes this search finite.

For native rational b,c, enumerate 4^(n^2) states and their rational raw products to obtain Z_n exactly. Choose n with 4Mbar/n below half the requested radius, evaluate log Z_n to the remaining scaled tolerance, and use GP03.3. This is a complete approximation algorithm, without a practical state-count guarantee. The inherited 65,536-bit guarded log helper cannot establish arbitrary-accuracy execution. The full algorithm uses unbounded finite arithmetic resources; an additive realization and a resource-capped adapter must report their respective domains. No old guard or default is changed.

## GP05. A rationally bounded canonical vacuum interaction

**ESTABLISHED.** For fixed B use the actual UC every-exterior coarse specification gamma_B on E, whose existence and uniqueness hold on c<1/12. With b_+ enlarged to include shifted sensor parameters below, set

    rho=[b_+(1+c_+^2)+2c_+]/[1+c_+^2+2b_+c_+],
    m=(1-rho)^2/4, A_B=4rho^B/(1-rho^2), D_B=2CB^2/m.            (GP05.1)

These are positive rational bounds. UC12 puts every free target cell probability at least m, under infinite exterior prescriptions, finite prescribed/absent patterns, and finite whole-block oracles. A target path consists of B independent signs after other fine signs are conditioned, with field magnitudes at most atanh(b_+)+2atanh(c_+). Revealing other paths preserves the parity bound rho^B. Revealing the two target paths successively gives m, without assuming them marginally independent.

Take *= (+,+), a translation-invariant lexicographic order, and eta^(x,r) equal to the state on y<x within radius r and to * elsewhere. Define e_(x,r)=-log[gamma_B(sigma_x|eta^(x,r))/gamma_B(*|eta^(x,r))]. Put A_(x,0)={x} and A_(x,r)={x} union {y<x:||y-x||<=r}. The UP interaction is e_(x,0) on A_(x,0), and e_(x,r)-e_(x,r-1) on A_(x,r), r>=1. Every term vanishes at the vacuum. Its full shell sum gives the full-past energy. UP04's finite-modification ratios followed by uniform exterior approximation identify exactly the full pushed law and every-exterior specification.

GP02 and log Lipschitz continuity on [m,1] give

    ||Phi_(x,0)||<=A_B,  ||Phi_(x,r)||<=D_B r t^r for r>=1.        (GP05.2)

At most (2r+1)^2 translates of each support contain zero; its diameter is at most 2r. Therefore

    K_B<=A_B+D_B sum_(r>=1)r(2r+1)^2t^r,
    M_B<=Mbar_B:=2D_B sum_(r>=1)r^2(2r+1)^2t^r,
    T_N:=D_B sum_(r>N)r(2r+1)^2t^r.                              (GP05.3)

All bounds are computable rationals. Put G_0(t)=1/(1-t), G_j(t)=(t d/dt)^jG_0(t), rational functions computed by finite differentiation. Nonnegative convergent series give

    sum_(r>N)r^j t^r=t^(N+1) sum_(i=0..j)binom(j,i)(N+1)^(j-i)G_i(t). (GP05.4)

This evaluates every required tail through j=4 and proves convergence. It restores first moments at arbitrary fixed B on the unchanged c<1/12 domain. Vacuum pressure is not identified with scalar-free Walsh pressure.

## GP06. Complete shell/row pressure algorithm

**ESTABLISHED.** To evaluate any e_(0,r) table with r<=N use Omega_([-R,R]^2), R>=N. Leave the two target paths unconstrained, prescribe every other retained path parity inside according to eta^(0,r), include all unused singletons, and fix exterior fine signs to +. Sum rational native factors on the allowed supports, retaining crossing plaquettes. The normalized restricted reference constant cancels in the row. Constraints are on disjoint whole paths with positive nonempty supports, so enumeration returns an exact positive rational four-state row g_(r,R).

Finite and infinite target atoms are at least m. UC's finite-oracle comparison gives delta_R=CB^2(R+1)t^(R+1) and

    |log[g_(r,R)(a)/g_(r,R)(*)]-log[gamma_B(a|eta_r)/gamma_B(*|eta_r)]|
      <=2delta_R/m.                                             (GP06.1)

Keep each approximate energy as the symbolic negative log of the rational ratio v_r(a)=g_(r,R)(a)/g_(r,R)(*), not a rational energy midpoint. The singleton raw factor is v_0 and each shell factor v_r/v_(r-1). Every truncated finite free weight and its normalized-reference partition Zhat_n are thus exact rationals. All vacuum factors equal one exactly.

With H_N=1+2 sum_(r=1..N)(2r+1)^2, the complete per-cell norm error is

    ||Phi_B-Phihat_(N,R)||_0 <=T_N+(2delta_R/m)H_N.                (GP06.2)

H_N counts both energy errors in a shell and one singleton error. Per-cell norm error epsilon changes the n-square free Hamiltonian by at most n^2 epsilon and its log partition by the same amount. Hence

    |p_B-n^(-2)log Zhat_n|<=T_N+(2delta_R/m)H_N+4Mbar_B/n.         (GP06.3)

Choose N for the tail, then R>=N for the row error, then n for the boundary, then directed-log precision. Each search and state inventory is finite. A capped request can stop without a pressure conclusion. This constructs all finite approximations for the canonical vacuum interaction without a Walsh scalar substitution.

## GP07. A separate all-vacuum-cylinder pressure algorithm

**ESTABLISHED.** Let p_n^+=mu_B(Y_Lambda_n=*), V=n^2. Every canonical free interaction vanishes at *, so its free vacuum atom is 4^(-V)/Z_B,n. GP03.2 gives

    |p_B-[-log4-V^(-1)log p_n^+]|<=12Mbar_B/n.                    (GP07.1)

The 12 is 8 from the actual-marginal/free comparison and 4 from the pressure approximation. Sequential path reveals give p_n^+>=m^V.

Take A=Lambda_n and Omega_(A_R), with every retained path unconstrained and any fixed fine exterior, including +. Enumerate its rational native law and sum the event that all 2V target paths have positive parity; call this probability q_(n,R). Sequential conditional positivity gives q_(n,R)>=m^V too. The finite whole-block comparison yields

    |q_(n,R)-p_n^+|<=C V B^2(R+1)t^(R+1),
    |p_B-[-log4-V^(-1)log q_(n,R)]|
      <=12Mbar_B/n+CB^2(R+1)t^(R+1)/m^V.                         (GP07.2)

For each requested error choose n, then R, then log precision. Each choice is finite. This oracle has no parity-prescribed exterior and gives the same pressure as GP06 by GP07.1. Its m^V cost can be severe. These are two mathematical constructions, not two mandatory science runs. At c=0 the separate product formula gives p_B=-2log(1+b^B), without positive-c contraction constants.

## GP08. Weight scores and finite strict-gap selection

**ESTABLISHED.** Write log a_gamma,L=V alpha_gamma+u_gamma,L with supplied computable |u_gamma,L|<=U_gamma(L) and its sublinear modulus. For free branches put E_gamma=U_gamma+4Mbar_gamma L; for fixed exteriors use 8Mbar_gamma L. Then log(a_gamma,L Z_gamma,L) differs from V s_gamma, s_gamma=alpha_gamma+p_gamma, by at most E_gamma. For a unique maximum gamma_* exact finite division gives

    1-W_gamma_*,L <= sum_(delta!=gamma_*)
      exp[-V(s_gamma_*-s_delta)+E_delta(L)+E_gamma_*(L)].           (GP08.1)

Refine the finitely many score intervals until one lower endpoint exceeds all other upper endpoints. A true strict gap makes this halt. Let d>0 be a rational certified lower gap. Use U_gamma(L)/L^2<=d/8 from the supplied modulus and L>=32Mbar_gamma/d for free boundaries, or 64Mbar_gamma/d for fixed exteriors. Then each E_gamma/V<=d/4 and leakage is at most (|Gamma|-1)exp(-dL^2/2). Choose j with (|Gamma|-1)2^(-j)<=epsilon and require dL^2/2>=j. Since e>=2 this is a sufficient integer/rational threshold. A singleton catalog has leakage zero without a gap search. Compact-uniform selection additionally needs a certified common positive gap and uniform growth moduli. Overlapping finite intervals mean undetermined; they establish neither a tie nor absence of a gap.

## GP09. Tied scores and the exact labeled limit criterion

**ESTABLISHED.** Let S be the mathematical maximal-score set and t_gamma,L=u_gamma,L+log Z_gamma,L-Vp_gamma. If its complement is nonempty there is a positive finite gap, so its weight tends to zero by GP08's ratio argument. Within S the normalized weights are exactly exp(t_gamma,L)/sum_(delta in S)exp(t_delta,L). Thus the full label vector converges if and only if this last vector converges. Combining with GP02's recentered branch limits, finite sums prove convergence of every labeled cylinder precisely under that criterion. Necessity follows by testing {gamma}. Tied labels may have zero limiting weight. Finite simplex compactness similarly characterizes subsequential limits.

Effective tied-limit output needs certified equality of the maximal scores, a separated complement when present, and a computable convergence modulus for the normalized t-vector. These are the stated additional data, not conclusions from pressure interval overlap. Arbitrary boundary sequences satisfy the pressure bound but need not supply convergent tied ratios.

## GP10. Subextensive counterexamples in the primary class

**ESTABLISHED.** Choose two labels with the same admitted positive native b,c, hence common Z_L,p and branch law. Set a_1,L=v_L/Z_L, a_2,L=1/Z_L. Then alpha_1=alpha_2=-p is computable by GP04. If v_L alternates 1 and 2, growth error is at most 4Mbar L+1 and W_1,L alternates 1/2 and 2/3. No labeled limit exists although both bulk scores are zero. Instead v_L=exp(L) or exp(-L) selects opposite labels with the same bulk scores and bound 4Mbar L+L. These positive computable inputs have explicit sublinear moduli; the alternating example even has rational weights. They lie inside the positive-c primary class.

A subextensive geometry or boundary scalar can therefore decide a tie. A bare O(L) estimate on an actual boundary free energy supplies neither its sign nor its limit. Its contribution must be computed in the model; it is not supplied by the example.

## GP11. Hierarchical laws and exact counterterms

**ESTABLISHED.** For fixed positive w summing to one, P_h({gamma} times A)=w_gamma mu_gamma(A) is a probability measure as a finite sum of branch probabilities. Conditional independent sensors can be constructed with independent uniform random variables per edge; their finite cylinders are normalized and compatible. Free/fixed-boundary hierarchies approach this joint locally by GP02. Their finite weights a_gamma,L=w_gamma/Z_gamma,L reproduce w exactly. Compensation is positive computable, and rational for native finite free partitions.

Adding per-cell raw energy d_gamma multiplies the partition by exp(-Vd_gamma), so it changes pressure by -d_gamma. A declared subextensive scalar enters u_gamma,L. Both cancel in branch-normalized hierarchy but affect global weights unless carried into a. Bulk-only compensation w_gamma exp(-Vp_gamma) leaves log Z_gamma,L-Vp_gamma; no estimate here says it vanishes. In the permitted explicit boundary-scalar class, multiply one of two identical native branch densities by exp(L). Both pressures remain p, but bulk-only compensation leaves label ratio exp(L), not the intended fixed ratio. This example explicitly includes that additional scalar; it is not an assertion about the sign of the native free surface correction. Approximating the full log Z with error tending to zero instead yields convergence to w by finite exponential ratios. No infinite Z is used.

## GP12. Exact sensor transformation and shifted compact box

**ESTABLISHED.** The values ell_eta(o|z)=(1+eta oz)/2 are positive and sum to one for 0<=eta<1. Their product over 2V observed edges is a normalized conditional observation law. For the all-positive observation,

    b'=(b+eta)/(1+b eta), A=(1+b eta)/2,
    (1+bz)ell_eta(+|z)=A(1+b'z).                                (GP12.1)

Multiplication and z^2=1 prove the identity. Plaquette factors are unchanged, so with the same free inventory

    Z_L^obs=A^(2V) Z_L(b',c), E_L=Z_L^obs/Z_L(b,c).               (GP12.2)

The fixed-exterior identity holds with all-touching partitions: only free-edge fields change. Its normalized posterior is precisely that free or fixed-boundary shifted law. The derivatives of b' in b and eta are (1-eta^2)/(1+b eta)^2 and (1-b^2)/(1+b eta)^2, both positive. The shifted upper endpoint (b_++eta_+)/(1+b_+eta_+)<1 and positive lower endpoint are rational. Coupling c remains below 1/12. These bounds give the common constants in GP02 and GP05. At eta=0, E_L=4^(-V); at c=0, Z_L=1 and E_L=A^(2V).

## GP13. Actual-marginal posterior local limit

**ESTABLISHED.** The actual-marginal posterior is not a free shifted law. Define a full-space reweighted probability by the finite density L_L(z)=product_(e in Lambda_L)ell_eta(+|z_e) relative to mu_(b,c), normalized by its positive expectation. Condition on the fine exterior of Lambda_L. The conditional is the original all-touching Gibbs density multiplied by L_L. GP12.1 identifies it exactly with the shifted (b',c) all-touching specification, with the same arbitrary exterior signs. This follows from finite conditional integrals, without conditioning on an infinite observation event.

For a fixed recentered cylinder with diverging margin, each shifted conditional is within GP02's vanishing bound of mu_(b',c). Integrating over the reweighted exterior proves local convergence of the actual-marginal posterior. A global exp(O(L)) ratio by itself would not prove this local statement.

A different bound serves density calculations. Let M,M' be native prior and shifted first moments, each bounded by 3c/(1-c). GP03.2 bounds the prior actual/free log ratio by 8ML. Multiplying by L_L and normalizing bounds the evidence log ratio by 8ML and posterior log ratio to the free shifted law by 16ML. That free shifted law differs from its actual shifted marginal by at most 8M'L. Hence

    |log(P_L^post,actual-prior / mu_(b',c),L)| <=(16M+8M')L.       (GP13.1)

Push preserves this bound. Free and fixed-boundary posterior variants have smaller corresponding surface bounds. GP13.1 is used for specific KL, not to replace the conditional-specification proof above.

## GP14. Evidence pressure and posterior geometry selection

**ESTABLISHED.** GP03 and GP12 give native-pressure identities

    p_gamma^obs=2log A_gamma+p_gamma(b_gamma',c_gamma),
    e_gamma:=lim_L V^(-1)log E_gamma,L=p_gamma^obs-p_gamma.        (GP14.1)

Actual-marginal evidence has the same limit by GP13's comparison. Errors have computable O(L) bounds plus directed-log errors. The maximum and the log sum of finitely many numbers differ by at most log|Gamma|. Total hierarchical evidence therefore has log density max e_gamma and posterior scores e_gamma. Global-factor evidence has log density

    max_gamma(alpha_gamma+p_gamma^obs)-max_gamma(alpha_gamma+p_gamma), (GP14.2)

and posterior scores alpha_gamma+p_gamma^obs. GP08-GP10 apply to these posterior scores and residual ratios. GP13 supplies branch local limits, so the posterior labeled-limit criterion follows from GP09. The infinite all-positive event has probability zero: its finite likelihoods are at most [(1+eta_+)/2]^(2V), tending to zero. None of these limits uses ordinary conditioning on that event.

## GP15. Stationary entropy, energy and specific relative entropy

**ESTABLISHED.** For stationary Q on E^(Z^2), tiling and entropy subadditivity, with leftover entropy at most |D|log4, show limsup_L H(Q_L)/L^2<=H(Q_n)/n^2 for each n. The infimum over n is no greater than liminf, giving

    s(Q)=lim_L H(Q_L)/L^2=inf_n H(Q_n)/n^2.                      (GP15.1)

Neither ergodicity nor positivity is used; 0log0 is zero. Allocate each complete interaction expectation equally among its sites. Absolute convergence and stationarity give e_Phi(Q)=sum_(A containing0)|A|^(-1)E_Q Phi_A. The expected free Hamiltonian differs from L^2e_Phi(Q) by crossing allocations, bounded by b_L. Finite KL to the free mass is exactly -H(Q_L)+L^2log4+E_Q H_L^free+log Z_L. Replacing the free law by the actual marginal changes it by at most 8ML. Divide and use GP03 to obtain

    h(Q||mu)=log4-s(Q)+e_Phi(Q)+p(Phi).                           (GP15.2)

Comparison laws are positive on finite cylinders, so zero recognition atoms introduce no undefined terms. This is specific relative entropy, not ordinary infinite-law KL.

## GP16. Recognition does not supply an effective entropy modulus

**ESTABLISHED.** Let Q_K be a uniformly random K-by-K four-symbol array repeated periodically on Z^2. Translations permute the uniform array, so the law is stationary. For n<=K its n-square occupies distinct residues and has exactly the fair independent marginal. But its full entropy is at most K^2log4, and its entropy density is zero. The fair infinite field has the same n-marginals for n<=K and entropy density log4.

No finite-cylinder query procedure can uniformly certify entropy density for all stationary laws at error below log4/2: if it terminates on the fair law, take K larger than the coordinate span of the union of all its finitely many queried sets. Q_K gives identical answers and therefore the same certificate for a different entropy density. Stationarity alone supplies no uniform computable modulus or universal finite-query VFE oracle. Particular recognition laws can supply extra entropy/local-expectation algorithms. This argument does not claim that every individual stationary law has noncomputable entropy.

## GP17. Retained-label specific VFE for both ensembles

**ESTABLISHED.** Fix q_gamma Q_gamma with q a label probability vector and Q_gamma stationary. Put l_gamma=E_Qgamma sum_(a=1,2)log ell_eta_gamma(+|z_(0,a)), which is finite. Hierarchical finite disintegration gives D(q||w) plus the q-weighted branch KLs. Dividing by V removes the finite label term, so

    f_h=sum_gamma q_gamma[h_gamma(Q_gamma)-l_gamma].             (GP17.1)

For global factors let s_gamma=alpha_gamma+p_gamma and s_*=max s_gamma. The supplied sublinear moduli and finite exponential bounds give -V^(-1)log W_gamma,L -> s_*-s_gamma. Therefore

    f_f=sum_gamma q_gamma[h_gamma(Q_gamma)-l_gamma+s_*-s_gamma].  (GP17.2)

These limits use one fixed recognition family. Free, fixed-exterior and explicitly compared actual-marginal variants have the same branch densities. An actual-marginal global variant must separately declare its finite geometry weights: an infinite-law marginal has no native unnormalized partition by default. The primary global ensemble uses its declared free or all-touching Z and matching branch law.

Let h_gamma^post be GP15 for the shifted branch and e_gamma its evidence density. The finite posterior identity and GP13 yield h_gamma-l_gamma=h_gamma^post-e_gamma. Thus hierarchy is sum q(h_gamma^post-e_gamma); global factors are sum q[h_gamma^post+s_*-alpha_gamma-p_gamma^obs]. This identifies the actual induced coarse experiment without a local coarse-likelihood assumption.

## GP18. Loss of label support and the erasure boundary

**ESTABLISHED.** If W_L converges with W_gamma,infinity=0 but q_gamma>0, the limiting labeled joint gives that label zero mass on every finite state window. Each such KL is infinite. GP17.2 can nevertheless be finite: the exp(-L) disappearing tied label in GP10 has zero label-rate penalty; a nonmaximal disappearing label has only its finite score-gap penalty. Finite-ensemble density is therefore not generally the specific VFE of the limiting joint.

If q is supported on positive limiting weights, its label KL to the limit is finite; those labels all have maximal scores, and the branch formula identifies the two values. GP10's alternating example also shows density existence without a joint limit. The already proved geometry-erasure obstruction for a mixture of distinct Bernoulli products rules out unconditional unlabelled Gibbs closure, even in a complete interaction class. This theorem does not treat a labeled mixture as a single admitted Gibbs branch.

## GP19. Finite block/reference transport and boundary comparison

**ESTABLISHED.** For fixed a the a-paths based at a times the coarse L-square lie in the fine aL-square and are edge-disjoint. Under normalized fine counting their two parities per cell are independent fair signs; all fibers have equal counts. Pushing the raw density gives r_tilde with total Z_fine,aL. At the positive vacuum set zeta_a,L=r_tilde(*) and r_hat=r_tilde/zeta_a,L. Then

    Z_fine,aL=zeta_a,L Z_hat,L.                                 (GP19.1)

Composition of finite channels, references and raw factors is associative; dividing at matching anchors gives the multiplicative scalar receipt. For words use the same final-centered embedding and its scale multiples at intermediate volumes, preserving exact path composition.

Let Phi and Phi'=R_a Phi be canonical vacuum representatives for the input and output laws, with first moments M,M'. Exact all-cylinder push identifies actual marginals. GP03.2 bounds fine free/actual log ratio by 8MaL. Stochastic push preserves multiplicative inequalities by nonnegative summation, and coarse actual/free costs 8M'L. Hence

    |log(P_fine-free,pushed(y)/P_coarse-free(y))|<=8(aM+M')L.      (GP19.2)

Both anchored raw factors equal one at the vacuum. Evaluating there gives |log Z_hat,L-log Z_coarse,L|<=8(aM+M')L. Their raw Hamiltonians then differ by at most 16(aM+M')L. This is a finite boundary comparison, not equality of the two free models.

## GP20. Scalar density, identity and initial native conversion

**ESTABLISHED.** Divide GP19.1 by coarse volume and use GP03 and GP19.2. For canonical input,

    sigma_a(Phi)=lim_L L^(-2)log zeta_a,L=a^2p(Phi)-p(R_a Phi),
    sigma_ad(Phi)=d^2sigma_a(Phi)+sigma_d(R_a Phi).                (GP20.1)

Insert the first formula into the second to check cancellation. This agrees with finite scalar multiplication: the first step has d^2 final coarse volumes. On the canonical orbit R_1 is identity and sigma_1=0 with the same anchor/reference.

Native raw factors are not vacuum-normalized. Their finite vacuum value and density are

    chi_L=(1+b)^(2L^2)(1+c)^((L-1)^2),
    chi=lim L^(-2)log chi_L=2log(1+b)+log(1+c).                   (GP20.2)

Dividing by chi_L gives a finite-range vacuum interaction Psi with the same Gibbs law. Psi and UP's canonical Phi_1 have finite first moments and zero vacuum energies. GP03.2 bounds their free normalized log ratio through their common actual marginal by 8(M_Psi+M_Phi1)L. Evaluation at the vacuum proves their pressures equal. Thus

    p(Phi_1)=p_native-chi,
    sigma_tilde_B(native)=B^2p_native-p(Phi_B)=B^2chi+sigma_B(Phi_1). (GP20.3)

For the direct native-to-B scalar, the proof of GP19.2 uses only the input free/actual comparison, not input vacuum normalization. Repeating it with the native first moment therefore proves that the literal finite native push has the sigma_tilde_B limit displayed in GP20.3. This is the explicit initial scalar receipt. Identity does not silently convert a raw or Walsh representative to canonical form. For other representatives pressure conversion requires an actual boundary comparison and scalar, not merely equality of infinite laws. GP06-GP07 avoid that conversion by constructing vacuum pressure directly.

## GP21. Geometry score transport and scalar-deletion control

**ESTABLISHED.** The native global exponent becomes, per final coarse cell,

    alpha_B'=B^2alpha+sigma_tilde_B,
    alpha_B'+p(Phi_B)=B^2(alpha+p_native).                       (GP21.1)

For canonical input use sigma. Exact finite scalar receipts define the weights before this limit. They preserve phase comparison under the full push and area factor. Counterterms follow the same receipt; scalar-free coefficients do not recover them.

For a rational product control choose c=0, b_1=1/4, b_2=1/3 and a_gamma,L=(1-b_gamma^2)^(-V). Native Z_L=1, and label 2 wins since 9/8>16/15. If identity anchor conversion divides the raw factor by (1+b_gamma)^(2V) but deletes the compensating geometry scalar, per-cell weighted partitions become 256/375 and 81/128. Since 256*128>81*375, label 1 wins instead. This permitted c=0 control proves that scalar deletion can reverse geometry selection, without asserting selection for the interacting primary box.

## GP22. Actual induced observation and finite VFE disintegration

**ESTABLISHED.** Fix the complete finite prior, positive sensor and channel word, retaining Gamma. With branch evidence E_gamma,L(o) and normalized prior/posterior pushes, finite summation gives

    ell_gamma,L'(o|y)=E_gamma,L(o)P_post,push(y)/P_prior,push(y).   (GP22.1)

Every target prior atom is positive for these parity maps. Summing the complete joint over all finite outputs proves normalization. The selected-pattern likelihood need not be local; its alphabet grows with the retained fine observation window. A new per-coarse-cell sensor changes the experiment.

For arbitrary finite recognition, augment by the same channel. Expanding the log ratio into output and fiber terms gives

    F_fine=F_coarse,induced+
      sum_(gamma,y)Q_push(gamma,y)D(Q(.|gamma,y)||P_post(.|gamma,y)). (GP22.2)

Channel-zero entries have zero joint weight. Strict finite posterior positivity makes supported terms finite. A zero recognition output has zero weight and requires no conditional there. Evidence is preserved, and repeated finite disintegration telescopes for staged words.

## GP23. Induced-experiment density and the area factor

**ESTABLISHED.** Let B be fixed, N=BL, and Q_gamma,B the infinite path push of stationary Q_gamma. It is coarse-stationary. Its L-square restriction is exactly the push of Q_gamma,N because the paths lie in that carrier. GP13.1 and its free/fixed-boundary variants bound the fine posterior discrepancy from the actual shifted marginal by O(N), uniformly in state. Push preserves this; its coarse KL discrepancy divided by L^2 tends to zero. GP15 then identifies the limiting state contribution as h_gamma,B^post(Q_gamma,B).

Write e_gamma=p_gamma^obs-p_gamma, s_gamma=alpha_gamma+p_gamma and s_*=max s_gamma. In hierarchy the posterior label rates per fine cell are max e-e_gamma and evidence rate max e. In global factors they are max(alpha+p^obs)-(alpha_gamma+p_gamma^obs) and max(alpha+p^obs)-s_*. These maxima cancel in F=D(Q||P_post)-log evidence. Consequently

    f_coarse,h^induced=sum_gamma q_gamma[h_gamma,B^post(Q_gamma,B)-B^2e_gamma],
    f_coarse,f^induced=sum_gamma q_gamma[h_gamma,B^post(Q_gamma,B)
                                      +B^2(s_*-alpha_gamma-p_gamma^obs)]. (GP23.1)

The fine formulas are GP17. Taking limits in the finite identity GP22.2 proves

    k_fiber=lim_L L^(-2)K_fiber,L
      =sum_gamma q_gamma[B^2h_gamma,1^post(Q_gamma)-h_gamma,B^post(Q_gamma,B)]>=0,
    B^2 f_fine=f_coarse^induced+k_fiber.                          (GP23.2)

The limit exists because both finite VFE density sequences converge; nonnegativity holds at every finite volume. Geometry and evidence rate terms cancel from the fiber difference. This does not subtract ordinary infinite-law KLs or require a limiting posterior label vector. GP18 governs further identification with a limiting joint. B^2 counts cells; two edge variables per cell add no further area factor.

## GP24. Constructive dependency map and geometric scope

**ESTABLISHED AT THE STATED INPUTS.** GP01-GP04 construct native pressure; GP05-GP07 construct every requested fixed-depth canonical vacuum pressure from actual finite native sums. GP08-GP11 construct label selection/limits with their gap, residual and counterterm data. GP12-GP14 construct the positive experiment, actual posterior limit and evidence. GP15-GP18 establish recognition-density/support distinctions. GP19-GP23 transport the full experiment and scalar density through fixed words. Compact constants are common across each finite catalog; compact-uniform selection additionally needs a common gap or uniform tied-vector data. Existing capped source functions are not invoked as universal algorithms.

A declared geometry-only exp(-A_gamma) has zero rate, whereas exp(-V A_gamma) shifts alpha by -A_gamma. This follows from the weight decomposition, not a curvature analogy. Plaquette holonomy is already in the normalized branch and is not counted again in a geometry scalar. A base-curvature action needs a specified contraction, measure, coefficient and common-cell scaling. A Fisher-curvature factor can be generative data from a separately specified regular family; deriving it from the same unknown reweighted infinite law is another existence problem. No automatic curvature penalty, pressure-derived Fisher tensor, criticality, continuum measure, uncontrolled simultaneous volume/depth limit, unrestricted geometry dynamics or physical clock is asserted.

## Bindings and author handoff

The frozen contract SHA256 is 41b61a4767f7c5b9ef350cb7696484d7f358cafe3ef1574b58baf3d13728786b and execution plan is 947a8cbe143acb63d73ce3a931d909ee97805e18e29fa7280ba20fd063f9d709. Restored UC proof: docs/derivations/2026-09-09-uniform-depth-gibbs-rg/agents/uniform-coupling-construction.md, SHA256 e09c831abae9432637659be974711c36ffd9d22fa90c7735737ca746a5cec67d. Restored UP proof: adjacent uniform-potential-vfe.md, SHA256 693e0ce9aa433f04f8785974fc5b852192571a9390ae9379413dec9de929eee3. Current finite author/erasure proofs were previously read at 3885a86c180d91f3b6741c5da7fd6a27bb6b1fcf97dcaa55895c6dc322c228a9 and 9626c4f7389be60d96dcf64eccef9031438767a2d02a4d4a5c59051150eb5446. No external theorem is imported. Recentered embedding, native initial scalar conversion and actual-marginal posterior conditionals are constructed here, not assumed desired outputs. A first documentation write was rejected by the Windows command-length limit before creating the file; the write was split, with no science execution involved. This file and atomic proposals are the only owned author outputs; no native state is assigned.
