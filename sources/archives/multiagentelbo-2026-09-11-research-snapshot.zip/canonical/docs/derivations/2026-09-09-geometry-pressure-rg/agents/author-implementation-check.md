<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e","target_digest":"81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e"} -->

# Author interface check: canonical pressure and thermodynamic adapters

This is a static source/interface check against the frozen GP construction, not independent reconstruction or a test result. The author wrote GP and shares the disclosed mathematical route with root. Both requested source files and both requested root notes were read in full; the actual imported finite-factor/log/sensor implementation and the named geometric helper bodies were also read. No independent initial/mature file, test source, source import, test, science or old producer was used. No native state is assigned.

The named cylinder, first-moment, pressure-error, scalar-sign and induced-VFE seams reconstruct from their actual source. No source correction is identified in this bounded read. One literal VT02 correspondence error was found and repaired by root: the returned law stores normalized-reference densities, not a separate raw-weight field. The repair and its exact current binding are recorded below.

## AIC01. Read bindings

The frozen author proof remains `agents/pressure-construction.md`, SHA256 `ea08fefad3b5bb541632a1963d0c8281cddec87a0aaa9da4d7bdd421d8706783`.

| Read artifact | SHA256 | Scope |
|---|---|---|
| src/multiagent_elbo/rg_v2/geometry_vacuum_pressure.py | 57029ed18712f1b8fc5a75f437c608f14052e97578a1d2104e4f6d4cc19b0169 | All 218 lines |
| src/multiagent_elbo/rg_v2/geometry_thermodynamics.py | 7f089a29d3583ad6647b37d9c5c3c636adb89d5ad5550d21c0f85de411906406 | All 222 lines |
| src/multiagent_elbo/rg_v2/geometry_pressure.py | 1beeed1b26b02da82dd010513ad6af41c72b35007f44a8be5f24c0d1f6814d0b | All 293 lines; imported finite_factor_law, directed_log and sensor_shift traced |
| src/multiagent_elbo/rg_v2/spatial_gauge.py | 1d5f51a19dbe05f03a41982d8755ca6035f8b09537ff675f19b0300b7cd349f1 | Named edge validation, plaquette, touching inventory, straight path and ExactSignLaw fields |
| agents/root-vacuum-pressure.md | 1ee87526f629993f8d5432e9b35e9b50fa719bde87ab25792b608ed28649a04c | Full VP01-VP07 |
| agents/implementation-vacuum-thermodynamics.md | 3d1352ed50b9d1bccafab9d23725eaa7e6914ea7d1110db9b24ae5822a3da316 | Original full VT01-VT09 read, then corrected VT02 read back |

The last note's initially read hash was `d44ab9ee79f47b821e9659ae5768c56f5ee33e3b468a4efcf01663dfa552399e`. Root reports preserving those bytes as implementation-vacuum-thermodynamics-initial.md. The four source hashes and root-vacuum-pressure.md were read back unchanged after the VT02 correction. This is source binding, not executed evidence.

## AIC02. Whole-block geometry and the actual finite law

In geometry_vacuum_pressure.py:120-130, the fine coordinate range is -BR through B(n+R)-1 in each axis, with both outgoing orientations. This is precisely Omega_(Lambda_n)_R and has 2B^2(n+2R)^2 free signs. Every target path uses the basepoint B(x,y) and B successive edges of the same orientation; all such edges occur in the positions table. Distinct target paths are edge-disjoint. Other free signs remain in the law and are integrated by the event sum; the source does not condition the generative law on the target event.

spatial_gauge.touching_plaquettes, lines 69-80, inserts the two actual plaquette anchors incident on each named edge, deduplicating only identical elementary plaquettes. A horizontal edge adds its own and the below anchor; a vertical edge adds its own and the left anchor. geometry_vacuum_pressure.py:124 supplies plus precisely on the required nonfree signs. finite_factor_law checks the exact required exterior set, canonical plaquette identities and free-edge intersection before multiplying every listed factor. Thus no external plaquette is lost merely because it is not wholly internal.

For a hand check, B=n=1,R=0 has two free signs x,y and three touching plaquettes. The complete raw weight is (1+bx)(1+by)(1+cx)(1+cy)(1+cxy). The free one-cell weight would lack those three c factors; that is not the caller used here. B=2,n=1,R=0 has eight free signs and four target-path signs, leaving four unused signs integrated. The first fixture's distinction is essential to the UC finite-oracle comparison.

finite_factor_law uses every state in {-1,+1}^edges, positive raw weights, partition=sum(weights)/2^edges, masses=weights/sum(weights), and densities=weights/partition. The target event probability is summed from those masses. UC/GP05's sequential path argument, including finite plus boundaries and prior path reveals, supplies q>=m^(n^2). Source checks positivity but does not independently prove that lower bound by enumeration; the certificate correctly depends on that mathematical premise.

## AIC03. Rational first moments and pressure uncertainty

The _moments recurrence at geometry_vacuum_pressure.py:66-72 is correct for k>=1: shifting the series gives S_k=t sum_(j=0..k)binom(k,j)S_j, and isolating S_k yields the implemented t/(1-t) recurrence, with S_0=1/(1-t). At t=1/2 the hand values are S_0=2,S_1=2,S_2=6,S_3=26,S_4=150. Thus 4S_4+4S_3+S_2=710; the implemented multiplier 2D counts exactly r^2(2r+1)^2 and the diameter factor. D already contains B^2. VP02 and GP05 agree.

The exact rational q,t,C,rho,m at lines 84-91 match GP05 with pointwise b,c; both m and 1-t are positive in the admitted domain. The source's c=0 branch avoids evaluating the positive-c comparison. Its cylinder probability [(1+b^B)/2]^(2n^2) gives vacuum pressure -2log(1+b^B), with both uncertainty terms zero. It is correctly distinct from native product pressure zero.

At resolution, the source negates upper log endpoints for the lower pressure endpoint and vice versa, then adds surface error 12M/n and oracle error CB^2(R+1)t^(R+1)/m^(n^2). These are GP07, not the smaller 4M/n bound for a different finite object. The imported directed_log constructs positive atanh remainders and reverses the log-2 multiplier when its range-reduction exponent is negative. It contains no inherited fixed intermediate-bit guard.

The requested-radius path chooses n>=48M/epsilon, hence surface error<=epsilon/4, and scans R until oracle error<=epsilon/4. Monotonicity at small R is not assumed; the eventually vanishing expression suffices. Each final logarithm has per-cell width at most epsilon/4. Their combined width is at most epsilon/2; adding both symmetric errors gives total width at most 3epsilon/2, within the enforced 2epsilon bound. The edge budget is checked before allocation and after each margin increment. A stop returns no pressure. Passing None removes that enumeration cap, not physical hardware limits. The c=0 nonenumerating branch deliberately ignores an otherwise too-small edge count after validating the budget's type/domain.

VP01-VP05 preserve the complete symbolic row-factor construction as a mathematical route. The actual source implements VP06/GP07's cylinder route, so it need not return shell tables or a truncated interaction partition. Its receipt instead retains the full fine law, event probability, logarithm intervals, constants, resolution and separate errors required for that route. This distinction is explicit in the root notes and is consistent with the target.

## AIC04. Native scalar and fixed-word area signs

geometry_thermodynamics.native_vacuum_pressure computes chi=2log(1+b)+log(1+c) and subtracts its enclosure from the native pressure enclosure. GP20 supplies the missing finite boundary proof: chi_L=(1+b)^(2L^2)(1+c)^((L-1)^2), followed by comparison of two vacuum representatives through their common actual marginal. The source does not call native pressure vacuum pressure without this subtraction.

scalar_pressure_density checks the same b,c, the same representative descriptor, and B_out=a B_in before forming a^2 p_in-p_out. The identity returns exactly zero on that same orbit, even when separately computed intervals have width. compose_scalar_densities multiplies the first scalar by the second factor squared before adding the second. This is the correct final-coarse-cell convention of GP20. Interval overestimation from separately supplied receipts does not alter the exact scalar cocycle. The native conversion record is explicitly a different type from a vacuum-orbit receipt; no identity-channel interpretation is made.

## AIC05. Evidence, specific-KL inputs and cancellation

observation_pressure verifies the exact rational shifted b and unchanged c, then forms p_obs=2log A+p_shift and e=p_obs-p_prior. geometry_evidence_density uses max e for fixed positive hierarchy weights, and max(alpha+p_obs)-max(alpha+p_prior) when alpha is supplied. Taking maximum lower and upper endpoints is a valid enclosure; independent interval arithmetic may overestimate shared uncertainty but cannot reverse the required signs.

specific_vfe_density accepts already certified stationary specific relative-entropy intervals h and expected log-likelihood intervals l. It computes sum q(h-l), with max(s)-sum q*s in the factor convention. Neither the argument name nor the code establishes those certificates; the docstring and VT07 state the exact external premise. This is GP17. It is not an entropy-rate solver for arbitrary stationary recognition. limiting_label_support handles an exact known rational limiting probability vector and flags any q-positive, limit-zero label. It neither finds that limit nor decides whether an arbitrary computable real weight is exactly zero from overlapping intervals.

In induced_vfe_density, h_fine and h_coarse are specific posterior KLs for one stationary fine recognition and its actual B-path push. The source sets R=max(s_post)-sum q*s_post, common=R-evidence, fine=sum q*h_fine+common and coarse=sum q*h_coarse+B^2 common. Its fiber is computed directly as B^2 sum q*h_fine-sum q*h_coarse. Hence the geometry/evidence terms cancel before interval subtraction, as in GP23. A negative upper endpoint is rejected as inconsistent input; intersecting a remaining fiber interval with [0,infinity) is justified by the finite channel inequality. No ordinary infinite KL subtraction is present.

These functions are conditional interval adapters. Their input quantities must refer to the same posterior, observation window, fine-cell score convention and pushed recognition family. The source does not construct such compatibility from arbitrary tuples, and the correspondence note does not claim it does. GP13's actual-marginal posterior conditional-specification proof, GP19's boundary comparison and recentered embeddings remain the mathematical bridge; an O(L) ratio alone is not used to infer the local posterior limit.

## AIC06. Corrected correspondence wording and proposal bookkeeping

The initial VT02 said finite_factor_law returns raw weights. ExactSignLaw actually returns states, masses, densities and normalizer; the raw weights are recoverable as density times normalizer. Root corrected only that wording and preserved its initial note. The corrected VT02 was read back at the current hash in AIC01. This required no source change or new execution.

Separately, the mature checker identified a proposal-domain dependency issue in the author's GP35 and GP38 c=0 controls. As requested, the initial author-proposals.json was preserved verbatim as author-proposals-initial.json, hash `794e65fe49b7942eb96cae75a1a2adaf4c36ecc70dbb2fb7bd8403b480648baf`. Only those two claims' dependencies/assumptions/derivation fields were amended to cite direct positive product factorization without positive-c prerequisites. The new proposal hash is `cd0cec8b483a09cea5d3515ba099773bf5149c1a8c4fd32f948d88318b4be5b2`; author-proposal-amendment.md records the reason and hashes. Frozen proof bytes remain unchanged. This bookkeeping correction is distinct from the source-interface check and makes no new scientific closure.

No further source correction is identified within the named risks. This statement is bounded static reconstruction, not an executed pass, proof of every caller, or a new acceptance state.
