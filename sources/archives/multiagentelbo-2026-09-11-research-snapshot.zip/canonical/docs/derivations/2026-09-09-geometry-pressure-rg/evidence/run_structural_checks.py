"""Record structure/hash checks after root proof adjudication, without science.

A passing validator establishes only schema, references, coverage and freshness.
The geometry pressure and induced VFE scope is the contract, not completion of the full RG goal.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys

RUN = Path(__file__).resolve().parent.parent
ROOT = RUN.parents[2]
SKILL = Path(r'C:/Users/chris and christine/.codex/skills/rigorous-theory-search/scripts')
sys.path.insert(0,str(SKILL))
from validate_run import validate_run

NAMES = ('problem-contract.json','approach-registry.json','claim-ledger.json','dependency-dag.json',
         'adversarial-report.json','release.json','counterexample-register.md',
         'construction-or-strongest-theorem.md','final-report.md')


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def current_bindings() -> None:
    intake = json.loads((RUN/'evidence/native-intake.json').read_text(encoding='utf-8'))
    scientific = json.loads((RUN/'evidence/scientific-record.json').read_text(encoding='utf-8'))
    assert intake['accepted_current_scoped_evidence'] is True
    assert all(sha(ROOT/p) == h for p,h in intake['read_artifact_sha256'].items())
    assert all(sha(ROOT/p) == h for field in ('source_sha256','raw_artifact_sha256')
               for p,h in scientific[field].items())


def check(mode: str) -> None:
    destination = RUN/'evidence'/('native-'+mode+'.json')
    assert not destination.exists(), 'do not overwrite an earlier gate result'
    current_bindings()
    before = {name:sha(RUN/name) for name in NAMES}
    errors = validate_run(RUN,mode=mode)
    data = dict(mode=mode,passed=not errors,errors=errors,validator_sha256=sha(SKILL/'validate_run.py'),
        input_sha256=before,inputs_unchanged=all(sha(RUN/name) == h for name,h in before.items()),
        timestamp_utc=datetime.now(timezone.utc).isoformat(),
        scope='Structural schema/hash/evidence/coverage validation only; explicit current proofs and retained exact output supply scientific evidence.')
    destination.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(data),flush=True)
    if errors or not data['inputs_unchanged']:
        raise SystemExit(1)
    current_bindings()


def main() -> None:
    check('checkpoint')
    release = json.loads((RUN/'release.json').read_text(encoding='utf-8'))
    release['terminal_status'] = 'COMPLETE_AFFIRMATIVE'
    release['checkpoint'] = 'Frozen geometry pressure and induced VFE supported by root-adjudicated current derivations, conditional source identities and retained finite evidence; structural checkpoint passed. The full RG goal remains active.'
    (RUN/'release.json').write_text(json.dumps(release,indent=2)+'\n',encoding='utf-8')
    check('release')


if __name__ == '__main__':
    main()