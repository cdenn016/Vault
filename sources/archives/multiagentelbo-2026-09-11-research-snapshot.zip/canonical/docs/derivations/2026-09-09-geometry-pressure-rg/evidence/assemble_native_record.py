"""Serialize root-adjudicated scoped proofs and the sole retained packet.
Administrative only; this helper neither decides mathematics nor runs science.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, xml.etree.ElementTree as ET

RUN = Path(__file__).resolve().parent.parent
ROOT = RUN.parents[2]
VERIFY = ROOT/'docs/verification/2026-09-09-geometry-pressure-rg'

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))

def dump(name: str, data: dict) -> None:
    (RUN/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

def main() -> None:
    assert not (RUN/'evidence/native-intake.json').exists()
    contract=read(RUN/'problem-contract.json')
    meta={k:contract[k] for k in ('schema_version','contract_id','target_digest')}
    selected=read(RUN/'agents/selected-final-proposals.json')
    coverage=read(RUN/'agents/independent-mature-coverage.json')
    rows=selected['claims']; ids=[r['id'] for r in rows]+['target']
    assert len(rows)==53 and len(set(ids))==54
    assert not coverage['pending'] and not coverage['mathematical_or_source_defects_pending']
    checked={r['claim_id']:r for r in coverage['claims']}
    assert set(checked)==set(ids) and len(coverage['claims'])==54
    deps={r['id']:r['dependencies'] for r in rows};deps['target']=selected['target_dependencies']
    assert all(set(checked[k]['dependencies'])==set(v) for k,v in deps.items())
    assert all(not r.get('pending') for r in checked.values())
    assert all(sha(ROOT/p)==h for p,h in coverage['bindings'].items())
    cmds=list(VERIFY.glob('*.command.json')); results=list(VERIFY.glob('*.result.json')); xmls=list(VERIFY.glob('*.xml'))
    assert len(cmds)==len(results)==len(xmls)==1
    command,result=read(cmds[0]),read(results[0])
    assert result['returncode']==0 and all(result[k] for k in ('source_unchanged','driver_unchanged','contract_unchanged'))
    assert all(sha(ROOT/p)==h for p,h in command['source_sha256'].items())
    assert len(command['source_sha256'])==40
    assert sha(cmds[0])==result['command_receipt_sha256']
    assert sha(xmls[0])==result['junit_sha256']
    log=xmls[0].with_suffix('.log');assert sha(log)==result['log_sha256']
    assert sha(VERIFY/'run_geometry_pressure_tests.py')==command['driver_sha256']
    assert sha(RUN/'problem-contract.json')==command['contract_sha256']
    cases=ET.parse(xmls[0]).getroot().findall('.//testcase')
    assert len(cases)==len({(x.get('classname'),x.get('name')) for x in cases})==49
    assert not any(x.find(k) is not None for x in cases for k in ('failure','error','skipped'))
    assert result['junit_suite_seconds']==0.307 and result['elapsed_seconds']==0.92014169995673
    context=read(RUN/'evidence/freeze-record.json')
    assert all(sha(ROOT/p)==h for p,h in context['existing_inputs_sha256'].items())
    bindings=set(coverage['bindings'])|set(command['source_sha256'])|set(context['existing_inputs_sha256'])
    bindings.update(p.relative_to(ROOT).as_posix() for p in (RUN/'agents').iterdir() if p.is_file())
    bindings.update((RUN/p).relative_to(ROOT).as_posix() for p in (
        'problem-contract.json','execution-plan.md','construction-or-strongest-theorem.md',
        'counterexample-register.md','final-report.md','evidence/freeze-record.json',
        'evidence/root-execution-preflight.json','evidence/root-result-readback.json',
        'evidence/worker-execution-preflight.json','evidence/assemble_native_record.py','evidence/run_structural_checks.py'))
    bindings.add('docs/reports/2026-09-09-geometry-pressure-rg.md')
    raw={p.relative_to(ROOT).as_posix():sha(p) for p in (cmds[0],results[0],xmls[0],log)}
    bindings.update(raw)
    science={**meta,'source_sha256':command['source_sha256'],'raw_artifact_sha256':raw,
        'execution_history':[dict(path=results[0].relative_to(ROOT).as_posix(),sha256=sha(results[0]),**result)],
        'latest_cases':dict(distinct=49,passed=49,failed=0,errors=0,skipped=0,execution_total=49),
        'runtime':command['runtime'],'config':command['config'],
        'scope':'Sole three-file <=8-sign packet; source-injected Python3.12.7. No infinite-volume claim from finite tests.',
        'user_excluded_not_run':['tamper/corruption/forgery checks']}
    intake={**meta,'timestamp_utc':datetime.now(timezone.utc).isoformat(),'accepted_current_scoped_evidence':True,
        'read_artifact_sha256':{p:sha(ROOT/p) for p in sorted(bindings)},
        'root_assessment':'Root accepts the current centered-window boundary/pressure, complete vacuum oracle, normalized sensor, strict-gap/tie/support, scalar-area and stationary induced-VFE derivations and conditional source recurrences after independent reconstruction. Numerical evidence is a separate finite leaf. The serializer and structural validator establish no mathematical truth.',
        'scope':'Only the frozen finite-catalog, fixed-word thermodynamic target. Full RG remains unfinished and work stops at the user-requested publication break.',
        'preserved_corrections':selected['preserved_corrections'],
        'independence_limit':'Shared model family, inherited context and filesystem; independently frozen initial proof and later source/output reconstruction do not confer proof by agreement.'}
    dump('evidence/native-intake.json',intake);dump('evidence/scientific-record.json',science)
    for p in (cmds[0],results[0],xmls[0],log):(RUN/'evidence'/p.name).write_bytes(p.read_bytes())
    evidence=[];claims=[];edges=[];attacks=[]
    def ev(eid: str,kind: str,path: str,statement: str,conditions: list[str]) -> str:
        evidence.append(dict(id=eid,kind=kind,supports=True,scope=statement,side_conditions=conditions,artifact_path=path,artifact_sha256=sha(RUN/path)))
        return eid
    for row in rows:
        cid=row['id'];numeric=row['kind']=='NUMERICAL_OBSERVATION'
        conditions=list(row['assumptions'])
        if numeric:
            eids=[ev('raw-'+cid,'NUMERICAL','evidence/scientific-record.json',row['statement'],conditions),
                  ev('junit-'+cid,'NUMERICAL','evidence/'+xmls[0].name,row['statement'],['Sole packet; no universal numerical inference.'])]
        else:
            eids=[ev('proof-'+cid,'DERIVATION',row['proof_artifact'],row['statement'],[row['proof_section'],*conditions]),
                  ev('independent-'+cid,'DERIVATION','agents/independent-mature-check.md',row['statement'],[checked[cid].get('scope','Exact stated premises only.')])]
            if row['kind']=='CODE':
                eids.append(ev('finite-'+cid,'NUMERICAL','evidence/scientific-record.json',row['statement'],['Tiny finite observations supplement the conditional source-to-formula proof.']))
        claims.append(dict(id=cid,kind='NUMERICAL_OBSERVATION' if numeric else 'MATHEMATICAL',statement=row['statement'],quantifiers=row['quantifiers'],target_digest=meta['target_digest'],state='EVIDENCE_VERIFIED',assumption_ids=[],explicit_assumptions=conditions,bridge_premise_ids=[],evidence_ids=eids,falsifier=row['falsifier']))
    t=contract['target']
    claims.append(dict(id='target',kind=t['kind'],statement=t['statement'],quantifiers=t['quantifiers'],target_digest=meta['target_digest'],state='EVIDENCE_VERIFIED',assumption_ids=[],bridge_premise_ids=[],evidence_ids=[ev('target-proof','DERIVATION','construction-or-strongest-theorem.md',t['statement'],['Centered windows; fixed finite catalog/word; admitted compact domain; declared effective and entropy input limits.'])],falsifier=t['falsification_criterion']))
    for cid in ids:
        edges.extend({'from':cid,'to':dep} for dep in deps[cid])
        attacks.append(dict(id='attack-'+cid,claim_ids=[cid],attack=checked[cid]['attack'],response=checked[cid].get('reconstruction',checked[cid].get('response',''))+' Scope: '+checked[cid].get('scope','Exact hypotheses only.'),disposition='REJECTED',artifact_path='agents/independent-mature-check.md',artifact_sha256=sha(RUN/'agents/independent-mature-check.md')))
    dump('claim-ledger.json',{**meta,'assumptions':[],'evidence':evidence,'claims':claims})
    dump('dependency-dag.json',{**meta,'edges':edges})
    reconstruction=dict(claim_ids=ids,method='Independent frozen initial construction, mature per-claim proof/source reconstruction, raw-result readback and root acceptance.',result='PASS',conclusion='The recorded reasoning discharges only the exact selected claims and target; no vote or structural validator supplies scientific evidence.',artifact_path='agents/independent-mature-check.md',artifact_sha256=sha(RUN/'agents/independent-mature-check.md'))
    dump('adversarial-report.json',{**meta,'attacks':attacks,'independent_reconstruction':reconstruction,'preserved_corrections':selected['preserved_corrections'],'resolved_initial_findings':coverage['resolved_findings'],'oracle_erasure':{**reconstruction,'method':'Remove search priors and finite output; retain explicit finite sums, restored UC/UP hypotheses, complete pressure approximation, tiling, entropy allocation and finite conditional KL. Removing raw output removes GPN01 only.','per_claim':{cid:checked[cid].get('oracle_erasure','Explicit derivation at stated assumptions; finite evidence cannot establish the theorem.') for cid in ids}}})
    dump('approach-registry.json',{**meta,'mechanism_families':[dict(family_id='pressure-scalar-induced-vfe',core_mechanism='Complete finite pressure approximation, boundary comparison and stationary finite-joint disintegration.',target_obligation_ids=ids[:-1],representation='Retained finite geometry label on a normalized common four-state cell carrier; fixed-word blocking.',invariant_or_obstruction='Actual normalized reference, carried raw scalar, positive finite observation, label support and B^2 area.',obligations=['P01-P14 with explicit centered local limits and resource/effective input hypotheses.'],bridge='Finite positive sums, all-exterior comparison, shell/cylinder tails, directed logarithms, tiling and specific-KL limits.',failure_test='A stated bound, scalar, support or area identity fails on an admitted input.',verified_results=ids[:-1],open_gaps=[],novelty_fingerprint='Direct construction; no novelty or physical universality claim.',disposition='Root accepts the frozen scoped construction; full RG remains open.')]})
    dump('release.json',{**meta,'checkpoint':'Root-adjudicated current proof/source/finite record; structural checkpoint pending.','target_claim':'target','terminal_status':None,'certificate_claim':'target','strongest_result':t['statement'],'unresolved_obligations':[],'limitations':['Full RG remains incomplete; user requested a publication break.','Finite common-carrier catalog, centered windows, fixed blocking word and positive compact domain.','No universal finite-query entropy oracle or score-tie decision.','Resource caps may stop before complete enumeration.','No smooth Fisher limit across ties, critical/continuum theory or self-consistent curvature dynamics.','One tiny packet; no prior replay or user-excluded tamper check.']})
    dump('evidence/native-adjudication.json',{**meta,'method':'Root acceptance of current explicit derivations and exact raw evidence; not a serializer or agent-vote inference.','claims':{c['id']:dict(state=c['state'],kind=c['kind'],evidence_ids=c['evidence_ids']) for c in claims},'counts':dict(claims=len(claims),evidence=len(evidence),edges=len(edges),attacks=len(attacks))})
    print(json.dumps(dict(claims=len(claims),evidence=len(evidence),bindings=len(bindings))),flush=True)

if __name__=='__main__':
    main()
