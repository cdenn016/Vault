<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e","target_digest":"81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e"} -->

# Geometry-pressure counterexamples and scope decisions

The proofs preserve the following obstructions. Each is a mathematical example or a restriction on a claim, not an executed corruption or tamper scenario.

GP02, IP01 and VP07 distinguish centered bulk windows from a permanently fixed corner. A negative-coordinate edge remains fixed plus outside every unshifted positive-quadrant square, whereas the admitted full-lattice Gibbs law has both signs with positive probability. Centering or translating tested cylinders into the bulk is therefore part of the actual local-limit construction.

GP09-GP10 and IP05 show that identical pressure scores can coexist with alternating normalized label weights, subextensive selection or subexponential loss of one label. Pressure interval overlap decides none of these cases. The exact maximal-set residual vector, and a supplied effective modulus when computation is claimed, remain required.

GP28 and IP06 show the failure of bulk-only compensation in the declared boundary-scalar class. Multiplying one raw branch by exp(L), or the independent rational choice 2^L, leaves its normalized state law and bulk pressure fixed but changes tied geometry weights. This example is not an uncomputed surface-free-energy calculation for two different bare native Hamiltonians.

GP16 gives a finite-query entropy obstruction. A uniformly random periodic array is stationary and has zero entropy density; for period exceeding all finitely queried coordinate spans its answers coincide with the fair product law. No universally terminating finite-cylinder-query entropy-density oracle follows from stationarity alone. This statement does not say every individually presented stationary law has noncomputable entropy.

GP18 and IP10 distinguish finite-ensemble density from KL to a limiting labeled joint. A recognition law charging a vanished label has infinite limiting-joint KL on every window, while finite-ensemble density may be positive and finite, zero, or convergent without any label-law limit. The positive-limit-label support hypothesis is essential.

GP35 and IP12 give separate exact c=0 product examples in which dropping the vacuum anchor reverses the selected geometry. Their direct finite product derivations require no positive-c coupling theorem. The initial author's unnecessary positive-c dependencies are preserved in author-proposals-initial.json and repaired in the current proposals, with an amendment note. No source or formula changed.

GP22 and IP13 show why a newly selected coarse local sensor is a different experiment: at eta=0 the actual fine selected evidence is 4^(-B^2 L^2), whereas a new coarse local sensor gives 4^(-L^2). Full joint push preserves the former and its fiber KL.

The implemented pressure cap is a resource condition. An eight-edge refusal is neither a pressure counterexample nor a convergence failure. The test packet uses complete two- and eight-sign cylinders and a deliberately loose successful positive-c radius. It makes no empirical claim of a small-error thermodynamic pressure calculation.

The source review corrected VT02's return-field wording: raw weights are density times normalizer, rather than a separate returned field. Initial note bytes are retained. A superscript display concern was withdrawn after explicit UTF-8/codepoint inspection established U+00B2 rather than replacement bytes. These are documented source-description issues, not scientific failures.

There is no automatic curvature-energy theorem here. A branch-dependent generative action requires an explicit contraction, reference and scaling; statistical Fisher curvature is not an interchangeable name for gauge or base curvature. Criticality, differentiability across phase ties and self-consistent Fisher actions remain outside this frozen target.
