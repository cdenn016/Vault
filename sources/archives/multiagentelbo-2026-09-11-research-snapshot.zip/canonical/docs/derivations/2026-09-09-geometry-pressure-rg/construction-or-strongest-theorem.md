<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e","target_digest":"81b5f927424d552eb48fc6a703814085d135368006429df9c96b5d6a2cdbfb1e"} -->

# Geometry pressure and the induced VFE limit

This construction concerns a retained finite geometry label on a common Z2 cell lattice. It extends the preceding normalized finite geometry model to explicit infinite-volume pressure and specific-VFE statements. The full renormalization goal remains active. This document assembles the scope and dependency map; the complete derivations are in agents/pressure-construction.md, agents/independent-initial-construction.md and agents/root-vacuum-pressure.md. Source correspondence is in agents/implementation.md and agents/implementation-vacuum-thermodynamics.md. Root acceptance is recorded separately with the current independent source check and sole retained 49-case packet; its exact raw outcomes are in evidence/root-result-readback.json.

## Carrier, normalization and the order of limits

Each lattice cell has two outgoing signs, with normalized four-state counting reference. A native L-square has exactly 2L^2 sign variables and (L-1)^2 fully internal plaquettes. All-touching fixed-exterior factors and actual infinite-law marginals are separate boundary conventions. They are compared by proved bounds rather than equated. Normalized independent gauge frames add no extra counting volume. Labels retain their explicit reference, raw factor, likelihood and geometry descriptors.

The primary compact domain is 0<b<1, 0<c<1/12 and 0<eta<1, bounded away from endpoints as stated in the frozen contract. The c=0 product and eta=0 sensor cases are separate controls. Every blocking word is finite and fixed before the volume tends to infinity. Its product B has area factor B^2. No simultaneous unrestricted volume/depth or continuum limit is inferred.

For local convergence, the specified square shapes are embedded with center tending into their interior. Translate a coarse L-square by minus floor(L/2) in both coordinates and its fine BL-square by B times that translation. Equivalently translate each tested cylinder into the bulk with diverging boundary distance. This specifies the construction left implicit by a list of unshifted square shapes; it does not assert that a fixed corner exhausts Z^2. An extension fixed to plus outside an unshifted positive-quadrant square leaves negative-coordinate edges deterministic forever and cannot have the positive full-lattice Gibbs law as its local limit. GP02 and IP01 prove the required centered convergence from actual conditional rows. Surface pressure bounds alone do not prove it.

## Pressure from finite computations

The actual UC/UP prior inputs supply unique all-exterior laws and complete canonical vacuum interactions at every fixed B. Their hypotheses are restored explicitly in GP02 and GP05 and in the independent IP01-IP03 reconstruction. The old shrinking 6Bc condition is never substituted for the current c<1/12 construction.

For a complete translation-invariant interaction with finite first moment M, GP03 proves crossing energy at most 4ML, normalized marginal/free log-mass discrepancy at most 8ML and pressure error at most 4M/L. Native M is bounded rationally by 3c/(1-c), from three diameter-one plaquette-cell incidences. Exact native finite partition sums plus an unbounded rational directed logarithm therefore construct native pressure, rather than assuming its value or a limit modulus.

Two complete canonical pressure constructions are available mathematically. GP06 and IP03 approximate every retained conditional log-odds shell, bound the full omitted norm tail and use rational ratios for all exponentiated finite factors. GP07 and VP06 give the simpler implemented route through the probability of an all-vacuum cylinder. With the actual finite cylinder q_(n,R), common nonnullness bound m per cell and restored whole-block constants C,t, the latter encloses

    p_vacuum = -log4 - log(q_(n,R))/n^2
               plus or minus [12M/n + C B^2(R+1)t^(R+1)/m^(n^2)],

with additional directed-log error. The 12M/n combines the actual/free vacuum-mass comparison and pressure tiling error. The finite oracle includes every touching plaquette, unused sign and required exterior sign. The event is summed under the full unconstrained finite law. Complete positive bounds make the radius search terminate for every fixed requested accuracy with adequate finite resources.

The additive implementation has no fixed arithmetic-bit ceiling and leaves the old guarded routines unchanged. Its default enumeration cap can return a resource stop with no pressure. Passing an adequate finite cap or None exposes the full finite algorithm, with no practical speed claim. In the product control p_native=0 and p_vacuum,B=-2log(1+b^B); confusing these representatives drops a real normalization scalar.

## Geometry selection and its obstructions

For declared positive global weights with certified growth log a_gamma,L=L^2 alpha_gamma+o(L^2), define s_gamma=alpha_gamma+p_gamma. GP08 proves strict-gap leakage using the actual finite error envelopes and supplied sublinear moduli. The executable finite interface takes certified score intervals and errors; it returns a winner only for strict interval separation. Interval overlap is undecided and does not establish a tie.

On the exact maximal-score set, GP09 identifies labeled convergence with convergence of the normalized subextensive exponentials. Pressure equality cannot decide those weights. The positive-c examples in GP10 and the independent rational examples in IP05 preserve oscillation, selection and subexponential loss. A finite hierarchy is constructed directly as sum w_gamma mu_gamma, without an infinite partition. Exact finite compensation a=w/Z reproduces its weights. Bulk-only compensation can fail in the explicitly declared subextensive boundary-scalar class; no uncomputed surface term for two different bare native Hamiltonians is claimed.

## Actual normalized observation and stationary VFE

The complete edge sensor is ell_eta(o|z)=(1+eta o z)/2. Its selected finite all-plus preparation gives A=(1+b eta)/2 and b_prime=(b+eta)/(1+b eta), retaining Z_obs=A^(2L^2)Z(b_prime,c). Actual-marginal priors require a separate surface comparison. Their local posterior limit is proved from the shifted conditional specification inside the observation window, followed by the uniform exterior bound. It is never inferred from an O(L) log ratio or defined by conditioning on the null infinite all-plus event.

Branch evidence density is e_gamma=2log A_gamma+p_gamma_prime-p_gamma. Hierarchical posterior scores are e_gamma; global posterior scores are alpha_gamma+p_obs,gamma. Total evidence rates are respectively max e_gamma and max(alpha+p_obs)-max(alpha+p). Tied posterior weights require their own subextensive data.

For every fixed stationary recognition law, entropy tiling and interaction allocation prove specific KL h=log4-s(Q)+e_Phi(Q)+p(Phi), including nonergodic laws and zero recognition atoms. The hierarchy specific VFE is sum q(h-l); the finite global ensemble adds sum q(s_star-s_gamma). Arbitrary stationary recognition entropy is not automatically computable from finitely many cylinder queries. The numerical adapter therefore requires actual enclosing entropy/energy inputs. GP16 gives the periodic-array obstruction to an unqualified finite-query algorithm.

A recognition label that has zero limiting target mass has infinite KL to that limiting labeled joint, even when the finite-ensemble VFE density is finite or zero. GP18 and IP10 retain this distinction. The existence of a density does not establish a labeled joint limit, and erasing the global label does not confer Gibbs closure on a mixture.

## Scalar transport and induced experiment

GP19 constructs the actual free-fine-push to canonical-coarse-free log comparison 8(aM+M_prime)L. Evaluating it at the common vacuum anchor identifies the coarse partition density. Consequently the scalar density is sigma_a=a^2p-p_Ra and its word law is sigma_ad=d^2 sigma_a+sigma_d. Identity factors have zero scalar on the same canonical orbit.

The initial native conversion is separate: chi=2log(1+b)+log(1+c), p_vacuum,1=p_native-chi and direct native-to-B scalar is B^2p_native-p_vacuum,B. Carrying alpha_B=B^2alpha+sigma preserves the full geometry score after area rescaling. Exact product controls independently show that dropping an anchor scalar can reverse the preferred label.

The actual induced likelihood comes from pushing the full observation joint:
ell_prime(o|y)=E(o)P_post,push(y)/P_prior,push(y). It differs from choosing a new local sensor on coarse edges. The finite VFE disintegrates into induced coarse VFE plus posterior-fiber KL. Taking separately established finite-density limits gives

    B^2 f_fine = f_coarse,induced + k_fiber,
    k_fiber = sum q_gamma[B^2 h_post,1(Q_gamma)-h_post,B(Q_gamma,B)] >= 0.

Evidence and geometry rates cancel from the fiber term. This calculation uses the actual stationary recognition and its path push, retains labels and uses finite quantities with separate limits; it does not subtract undefined infinite KLs.

## Curvature and remaining scope

The plaquette holonomy is the declared discrete gauge-action variable. A chosen base-curvature or other geometry factor changes the specified generative model. An order-one exp(-A_gamma) has zero bulk rate but can affect tie weights; an extensive exp(-L^2 A_gamma) shifts alpha_gamma by -A_gamma. A state-dependent action changes branch pressure and specification and requires fresh admission. Gauge curvature, base curvature and the Fisher geometry of a normalized statistical family remain distinct structures.

This pressure theorem does not assert differentiability across a geometry tie, a nonsingular limiting Fisher metric, a self-consistent action built from that same unknown metric, continuum geometry integration, critical universality or a physical clock. Those are separate remaining obligations in the active program.

## Constructive dependency map

P01-P02 are supplied by GP01-GP03 and GP25-GP26 with UC/UP hypotheses restored. P03 is GP04-GP07, GP27 and the separate product GP38. P04-P06 are GP08-GP11 and GP28. P07-P08 are GP12-GP14 and GP29-GP30. P09-P10 are GP15-GP18 and GP31-GP32. P11-P12 are GP19-GP21 and GP33-GP35. P13 is GP22-GP23 and GP36-GP37. P14 is the assembled typed interface and GP24. GPI01-GPI06 and VT01-VT08 separately state the conditional source identities. The sole finite packet, when recorded, supplements them and establishes no infinite-volume theorem.
