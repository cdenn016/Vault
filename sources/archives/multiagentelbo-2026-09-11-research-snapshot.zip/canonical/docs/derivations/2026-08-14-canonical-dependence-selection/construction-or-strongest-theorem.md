<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-8112f0083a554a4df3b5de3875174d0b0cbfeee36a7bc2ea20e78c8cf9da6b39","schema_version":"rigorous-theory-search/v1","target_digest":"8112f0083a554a4df3b5de3875174d0b0cbfeee36a7bc2ea20e78c8cf9da6b39"} -->
# Construction or strongest theorem

## Direct negative result

For the frozen finite marginal functor \(m_X:J(X)\to M(X)\), preparation kernels from singleton lists force every section natural under all coordinatewise finite Markov kernels with independently tensored randomness to be

\[
S_X(\mu_1,\ldots,\mu_n)=\bigotimes_i\mu_i.
\]

More strongly, a wide marginal-compatible category containing all those local kernels admits a natural section if and only if every added kernel preserves product laws; when it exists, the section is unique for that morphism class. Hence the product-preserving marginal-compatible kernels form the maximal such category.

For a fair source bit, the two explicitly admitted marginal-compatible split kernels \(R_{1/3}\) and \(R_{1/2}\) both produce fair/fair target marginals but require selected output laws with atom multisets

\[
\{1/3,1/3,1/6,1/6\}
\quad\text{and}\quad
\{3/8,3/8,1/8,1/8\}.
\]

These multisets remain distinct under every sample relabeling. The section axiom plus naturality under these two splits, without any local-kernel naturality assumption, forces one single-valued selector to equal both outputs. This is a direct scope-matched nonexistence proof for the frozen existential conjunction, independent of every positive replacement. The same binary family proves marginalization is noninjective, so no marginal section can also be faithful to every compatible full joint law.

The full proof is `evidence/natural-selector-no-go-proof.md`.

## Independently typed recovery boundaries

The three marginal-recovery predicates receive separate dispositions and proof paths.

* `RECOVERY-FULL-VFE-NOGO`: the product law and a positive correlated law have the same singleton marginals, while their KL values against the same positive product posterior are respectively zero and strictly positive.
* `RECOVERY-FULL-FISHER-NOGO`: the positive six-bit parity families with fixed \(\kappa=0\) and \(\kappa=1/2\) have the same singleton-marginal family map on \((0,1)^6\), while at the symmetric point their full-joint Fisher tensors are \(4I_6\) and \((65536/16383)I_6\).
* `RECOVERY-TYPED-INTERVENTION-NOGO`: **INCONCLUSIVE** for the frozen unconditional predicate because the ambient typed category and internal witness nonisomorphism are not formalized.
* `RECOVERY-TYPED-INTERVENTION-CONDITIONAL-NOGO`: conditional on the August 13 direct, latent, and null-extended BSC presentations being nonisomorphic objects in one declared typed-category forgetful fiber, universal two-sided recovery fails. A mere right-inverse section may still choose one conventional representative.

The proof, exact source dependencies, and strongest conditional replacements are in `evidence/recovery-factorization-no-go-proof.md`. None of the three claims depends on either of the other two.

## Strongest positive replacement

Given a declared finite reference \(p\), statistic \(T\), and target moment \(m\), a finite I-projection exists exactly when

\[
m\in\operatorname{conv}T(\operatorname{supp}p),
\]

and is then unique as a law relative to \((p,T,m)\). Its exact support is the inverse image in \(\operatorname{supp}p\) of the minimal face containing \(m\). After statistic minimalization it has a unique exponential multiplier; before minimalization, multipliers are unique only modulo affine redundancies. Every finite-KL feasible law satisfies the oriented identity

\[
D(q\|p)=D(q\|q_{p,m})+D(q_{p,m}\|p).
\]

The selected law is analytic on each fixed relative-interior face stratum. It is equivariant only when the reference and complete constraint diagram are transported coherently. For a positive reference and a full-support relative-interior singleton target, full-table higher-order log-linear interactions are inherited from \(p\); at a boundary target the statement is restricted to the minimal-face support and contrasts through zero atoms are undefined. A product reference yields the product law, whereas a feasible correlated reference selects itself.

For a deterministic coarse map \(f:X\to Y\), reference \(p\), and \(r\ll f_\#p\), the unique KL-minimizing completion relative to \((f,p,r)\) is

\[
L_f^p(r)(x)=
\begin{cases}
r(f(x))p(x)/(f_\#p)(f(x)),&(f_\#p)(f(x))>0,\\
0,&(f_\#p)(f(x))=0.
\end{cases}
\]

It composes strictly along nested deterministic coarse maps when every stage uses the pushed reference. With the retained posterior as reference and a feasible retained target \(m\in\operatorname{conv}T(\operatorname{supp}\pi)\), the finite optimizer satisfies \(q^*\ll\pi\), its deterministic completion is defined, and the retained optimizer and optimized VFE value descend under the August 13 retained-joint/conditioning equivalence. The retained envelope differential descends only for a positive \(C^1\) parameterized family with a common locally fixed feasible set and support stratum and a unique \(C^1\) optimizer. Presentation-specific auxiliary completions do not descend.

The full proof and boundary counterexamples are in `evidence/reference-relative-selection-proof.md`.

## Retained Fisher quotient and declared-block boundary

For every smooth retained-law map \(\rho:\Theta\to N\) and positive-semidefinite
target tensor \(g\), the pullback radical is exactly

\[
\operatorname{rad}(\rho^*g)=d\rho^{-1}(\operatorname{rad}g).
\]

It equals \(\ker d\rho\) if and only if
\(\operatorname{im}d\rho\cap\operatorname{rad}g=\{0\}\). Constant rank then
gives a smooth positive-definite vector-bundle quotient
\(T\Theta/\ker d\rho\cong\operatorname{im}d\rho\). A global quotient manifold
still requires a simple Hausdorff null-leaf quotient. For the specific
\(h=\rho^*g\), basicness is automatic once that connected-leaf quotient
exists, because \(\rho\) factors through it; basicness remains extra only
for arbitrary tensors and declared block projectors. The punctured-plane
projection \(\rho(x,y)=y\) gives a line with doubled origin, so constant rank
does not supply the required Hausdorff leaf space even though \(h=dy^2\) is
basic.

A familywise commuting presentation diagram
\(\rho_BF=J\rho_A\), with \(F\) a diffeomorphism and \(J\) a Fisher
isometric immersion, induces pointwise quotient-space isometries without a
constant-rank assumption. On constant-rank strata they assemble into a smooth
bundle isomorphism covering \(F\). For a surjective-submersion redundant
presentation, the bundle statement is \(Q_A\cong F^*Q_B\) over
\(\Theta_A\), not injectivity into the total space of \(Q_B\). The control
\(F(t)=t^2\) shows why a rank drop blocks either conclusion. Generic Markov
contraction or equality at one parameter is insufficient.

For a declared smooth splitting \(T\Theta=\bigoplus_aB_a\), the following are
equivalent on a constant-rank stratum: the quotient block images form a direct
sum, their retained images form a direct sum, the kernel splits blockwise, and
each quotient tangent has a unique linear block decomposition. Additive Fisher
energy additionally requires pairwise Fisher orthogonality. Locally, with
\(D_a=B_a+K\), block-distribution projectability is exactly
\([\Gamma(K),\Gamma(D_a)]\subseteq\Gamma(D_a)\), while an individual field
\(X\) is projectable exactly when \([Z,X]\in\Gamma(K)\) for every vertical
\(Z\). Invariance across disconnected components of one retained-law fiber
is an additional global requirement. Presentation invariance also requires
natural transport by a declared type-preserving permutation. A rotating-block
example violates the bracket condition and proves that pointwise smooth
directness and orthogonality do not imply projectability.

At the uniform seven-outcome law, permutation naturality would make any
law/Fisher-only decomposition into three rank-two blocks define
\(S_7\to S_3\). Its restriction to the perfect group \(A_7\) is trivial, while
every equivariant endomorphism of the six-dimensional sum-zero
representation extends by zero on the invariant \(\mathbb R\mathbf1\) line;
the resulting \(\mathbb R^7\) commutant calculation makes the endomorphism
scalar, proving irreducibility. Hence no such natural block decomposition
exists without typing
or other symmetry-breaking data. Finally, the promoted parity family
\((\theta,\kappa)\mapsto Q_{\theta,\kappa}\) has full-joint rank seven
everywhere, whereas singleton retention has rank six and kernel exactly
\(\operatorname{span}\{\partial_\kappa\}\). Identifiability is therefore
relative to the declared retained map.

The direct proofs are in `evidence/fisher-quotient-agentization-proof.md`.

## Current scope

The assembled run records `TARGET-ABSOLUTE-CANONICAL-SELECTOR` as `REFUTED` and releases the frozen target as `COMPLETE_NEGATIVE`. The VFE and Fisher recovery no-gos and the conditional intervention no-go are independently verified, while the unconditional intervention no-go is `INCONCLUSIVE` outside the target closure. The bounded positive replacements also have separate ledger entries; none is used as a premise of the target refutation. The release validator checks schema, revision-bound evidence, dependency closure, polarity, attack coverage, and oracle erasure. It is a structural certificate, not an additional mathematical proof beyond the contained derivations.

No result here derives autonomous agents, intervention structure, continuum dynamics, physical geometry, or dimensional units from marginal sections or Fisher geometry.
