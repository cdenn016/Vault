# All-time categorical interval bounds

This module bounds the already chosen categorical bin approximation on the entire parameter interval $a=e^{-t}\in[0,1]$. It does not choose a new partition, change an accuracy threshold, or retune a curve after observing an error. A bound exceeding the requested threshold means that threshold has not been established by this computation.

The arithmetic object being bounded must be distinguished from stored floating-point evaluation output. Each finite binary64 input is interpreted as its exact represented real number. The fine inputs are divided by their exact total masses, and every nonnegative channel row is divided by its exact positive row sum. These operations define normalized real laws $q,p$ and a common real channel $C$. Bin masses and conditional channel rows are then defined by exact sums and ratios of those normalized quantities. The interval calculation encloses these definitions. It does not certify rounding in the earlier Torch normalization, eigensystem, compiler, or runtime evaluator, and it does not treat rounded stored bin coefficients as exact versions of the normalized-real coefficients.

The module reuses the unchanged arithmetic in multiagent_elbo/rg_v2/e1_interval.py. Elementary array operations expand binary64 endpoints outward. Its logarithm and exponential implementations use their documented series remainder enclosures; exponentials are admitted only for arguments in $[-16,16]$. The numerical branch requires the enclosed fine and bin log ratios to lie strictly inside that range. Positive normalization intervals, finite bounds, and the stated domains are checked before accepting an enclosure.

For the normalized fine laws, let

$$
s(x)=\log\frac{q(x)}{p(x)},
r(x,a)=\frac{p(x)e^{as(x)}}{\sum_zp(z)e^{as(z)}}.
$$

With $\mu(a)=E_{r(a)}s$ and $v(a)=E_{r(a)}(s-\mu)^2$, differentiation gives

$$
r_a=r(s-\mu),
r_{aa}=r\left((s-\mu)^2-v\right).
$$

The same formulas hold for the bin law, with $q_B,p_B$ and $s_B=\log(q_B/p_B)$. The prepared approximate channel is

$$
R(a)=R_p+a(R_q-R_p).
$$

Write $\Delta R=R_q-R_p$. The approximate parent and its derivatives are

$$
\widehat q_Y=r_BR(a),
$$

$$
\widehat q_{Y,a}=r_{B,a}R(a)+r_B\Delta R,
$$

$$
\widehat q_{Y,aa}=r_{B,aa}R(a)+2r_{B,a}\Delta R.
$$

The exact parent derivatives are $rC,r_aC,r_{aa}C$. Define their differences by $E=\widehat q_Y-rC$, $E_a=\widehat q_{Y,a}-r_aC$, and $E_{aa}=\widehat q_{Y,aa}-r_{aa}C$. The desired errors are

$$
\operatorname{TV}(\widehat q_Y,rC)=\frac12\sum_y|E_y|,
$$

$$
\|\dot{\widehat q}_Y-\dot rC\|_1=\sum_y|-aE_{a,y}|.
$$

In particular, differentiating the error in physical time requires the factor $-a$. A bound on the derivative with respect to $a$ alone would address a different quantity.

The cover consists of a fixed dyadic subdivision of $[0,1]$. For a cell $I=[l,u]$, its midpoint $m$ and radius $h=(u-l)/2$ are exactly representable. Midpoint weights are enclosed as $p\exp(ms)$. Every cell weight is enclosed by multiplying those midpoint intervals by $\exp([-h,h]s)$. The latter expansion factors are shared across all equal-width cells. The same construction is used for bin weights. Outward sums, positive interval division, centered scores, and the derivative formulas then enclose $E(I)$, $E_a(I)$ and $E_{aa}(I)$.

The computation intersects the direct law enclosure with

$$
E(m)+[-h,h]E_a(I).
$$

For the time-rate error $D(a)=-aE_a(a)$, it intersects the direct enclosure $-I E_a(I)$ with

$$
-mE_a(m)+[-h,h]\left(-E_a(I)-I E_{aa}(I)\right).
$$

These are componentwise mean-value enclosures. Midpoint evaluations alone would not bound an interval; the interval derivative factors are what extend each enclosure over its entire cell. Taking outward sums of componentwise absolute upper endpoints yields a TV upper bound and a time-rate L1 upper bound for the cell. The global values are maxima over the complete cover. TV is also bounded by one because the two real laws are normalized. No analogous sampled-maximum substitution is used for the rate.

The admitted subdivision count is a power of two between one and 16,384, with 1,024 the default. Processing uses batches of at most 256 cells. Fine-state projection still uses the inherited explicit outward dot-product arithmetic, rather than ordinary NumPy matrix multiplication with an unproved rounding allowance. The finite number of cells is chosen before the run. The implementation does not refine until a threshold passes.

A singleton partition has an independent exact identity: $q_B,p_B$ are the fine laws, and both conditional channel rows equal the original channel row. Hence the approximate parent and its derivative agree with the exact parent for every $a$. This branch returns zero bounds with one identity cell covering $[0,1]$, after validating the positive fine weights, common channel, and singleton partition. It does not require exponential-range admission because it performs no interval exponential evaluation. The result records the requested subdivision count separately from the single actual identity cell.

The returned record includes the input interpretation, occupied-bin and state counts, the parent-domain mask, method, actual and requested subdivisions, and every cell's endpoints and two upper bounds. A wholly zero channel column remains an absent parent outcome. No uniform conditional completion or probability floor is introduced. The driver can therefore report a failed threshold as not established while retaining the actual enclosure.

Focused tests use tiny finite laws. Exact rational comparisons check normalization enclosures for frozen binary64 inputs. Independent 80-digit Decimal evaluations check law and rate containment at representative points, normalization, and endpoint identities. Those point comparisons are numerical controls on the implementation, not proofs of the all-time statements. Separate controls check the singleton identity, zero parent columns, domain rejection, and preservation of the input arrays. No test or experiment is run by this implementation lane; the coordinating task owns the consolidated execution.
