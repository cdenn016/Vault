# Conditional information in projected recognition inference

The current extension completes the previously tested full-family parent inference comparison with its hidden conditional state. It uses the same fixed-context local generative construction, observation posterior and probability channels as the preceding neighborhood milestone. Initial recognition laws come from local tree data; the existing full-Gaussian flow may subsequently leave that agent-tree family. This construction follows that full-family control, not the constrained tree solver.

## Projecting the fine score

Write the fixed channel as C(y|x). For finite events its rows sum to one; for a full-row-rank deterministic Gaussian map use invertible coordinates (Y,X_hidden) to express the same disintegration on a common fiber. The recognition and target joint laws are Q(x,y)=q(x)C(y|x) and P(x,y)=p(x)C(y|x). On their common support the channel factors cancel in the density ratio. Therefore

    log(q(x)/p(x)) = log(qY(y)/pY(y))
                     + log(Q(x|y)/P(x|y)).

Conditional expectation under Q gives a parent score equal to the parent log ratio plus d(y)=KL(Q(.|y)||P(.|y)). Its total expectation is the ordinary KL chain identity

    KL(q||p) = KL(qY||pY) + E_qY d(Y).

For the full positive simplex, the reverse-KL Fisher flow is q_dot=-q[log(q/p)-E_q log(q/p)]. Marginalization is a fixed linear operation. Passing this derivative through C and using the conditional expectation identity yields

    qY_dot(y) = -qY(y)[log(qY(y)/pY(y)) + d(y) - KL(q||p)].

The autonomous parent Fisher flow at the same current parent law omits

    correction(y) = -qY(y)[d(y)-E_qY d(Y)].

Thus lost conditional information and failure of parent autonomy are different quantities. The mean conditional KL can be positive while its centered field vanishes. In this finite positive support, the instantaneous correction vanishes exactly when d is constant on the positive parent support. This is a statement at the specified state; persistence requires that the constancy condition continue to hold during the augmented evolution.

For the admitted Gaussian family, the same normalized score is quadratic and the full flow stays Gaussian. Gaussian moment identities give the explicit parent mean/covariance rates in the [Gaussian derivation](2026-09-08-gaussian-conditional-completion.md). Conditional Gaussian KL is a quadratic polynomial in the parent coordinate. Its quadratic and linear coefficients supply the additional precision and mean-force terms. When hidden regressions agree, that polynomial is constant and the zero-correction condition persists under the exact conditional update, even with distinct hidden offsets or covariances.

## Exact finite evolution with retained conditionals

Let a=exp(-t). The existing full-family control has q_t proportional to q_0^a p^(1-a). The corresponding joint identity is

    Q_t(x,y) proportional Q_0(x,y)^a P(x,y)^(1-a)
                       = q_0(x)^a p(x)^(1-a) C(y|x).

Disintegrating this expression gives

    Z_a(y) = integral Q_0(x|y)^a P(x|y)^(1-a) dx,
    Q_t(x|y) = Q_0(x|y)^a P(x|y)^(1-a) / Z_a(y),
    qY_t(y) proportional qY_0(y)^a pY(y)^(1-a) Z_a(y).

The implementation updates these conditional and parent factors together. It computes the parent step from conditional overlaps, without calling the fine-flow oracle inside that step. Arbitrarily evolving the two factors independently would generally leave the subset of joint laws compatible with the fixed channel. The paired update stays within it because of the joint identity above. Successive exact increments compose by multiplication of their a coefficients, equivalently addition of their flow parameters.

The [categorical derivation](2026-09-08-categorical-conditional-completion.md) gives finite support and numerical details. The Gaussian overlap integral is evaluated analytically with a positive mixture of hidden covariances; its parent-dependent quadratic coefficients determine the updated parent precision and information vector. The constant part of log Z affects normalization but cancels from normalized parent moments. The Gaussian implementation carries no hidden conditional when the parent map is square and invertible.

## Domains, coordinates and numerical scope

The categorical implementation uses C=kron(K,K), matching the existing two-record convention K^T q K after flattening. It retains stochastic assignment as well as deterministic limiting channels. Structural zeros in a defined conditional row stay zero. Entirely undefined parent rows retain NaN conditionals with false domain masks and exactly zero joint/root mass. A positive-mass null label is defined. Positive arithmetic support is checked after composing channels and forming joint probabilities; underflow is not reclassified as a structural zero.

For Gaussian variables the split T=[F;N] is invertible, with orthonormal hidden rows N spanning ker(F). It is chosen once for each context/depth. Numerical rank admission can reject ill-conditioned maps. The construction does not supply a smooth QR basis across changing rank, and independently generated complements can differ by a hidden basis change. Gauge comparisons therefore use visible or reconstructed laws, conditional-information scalars and transformed polynomials, not raw hidden coordinate entries.

The study holds context, evidence, coarse channels and nonflat connections fixed. The connection tensors are retained as context data; no connection force or geometric objective is added. These are vertical statistical updates. Neither the prior connection-compatibility obstruction nor the general changing-support transport problem is removed by retaining hidden probability data.

## Implementation comparison and interpretation

At each declared flow parameter, the study evolves the completed state by the increment since the preceding stored parameter. It separately evaluates the published fine full-family flow from the original initial law, then pushes it through the unchanged Gaussian and event channels. It checks parent law agreement, reconstructed fine law agreement, KL chain decomposition, corrected instantaneous rates, the two-record channel convention, and direct/staged parent-law composition when both depths are selected. An independent autonomous-parent control targets the same pushed posterior with the same flow parameter.

Stored arrays contain visible moments, complete hidden Gaussian conditionals, complete finite conditional tables and masks, conditional-KL polynomials/fields, incremental overlap coefficients, parent rates, fine controls, and fixed model/geometry data. The state-size metadata explicitly reports how much hidden data is retained. Comparisons with a complete CPU float64 reference exclude arbitrary QR coordinate entries while retaining visible/fine laws, event conditionals, polynomial coefficients and scalar diagnostics.

This provides an exact augmented-state representation for the stated finite full-family controls. It does not reduce the state dimension or prove a minimal sufficient hidden representation. It is a control against which a later conditional approximation or memory model can be measured. Any such compression changes the problem and needs an explicit approximation and error criterion.

The source boundary remains [Theory/SPEC.md](../../Theory/SPEC.md), the repository Fisher geometry, and the [preceding inference comparison](2026-09-08-inference-coarse-comparison.md). The Research wiki's [Natural gradient](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Natural gradient.md>) constrained-ELBO discussion motivated checking tangent compatibility rather than inferring it from scalar objective equality. PIFB2 remains physical guidance; it does not select these conditional states or prove their closure. The identities here are derived for the implemented Gaussian/finite setting, with numerical checks reported separately from the derivation.
