# Moving-context evolution with explicit support reconciliation

The controller implements an ordered discrete evolution on a declared polygonal
context path. It carries an active Gaussian recognition law and a positive full
latent event law. The four endpoint-record labels in the latter are not the
currently active Gaussian agents: they retain the 256-state product space
throughout the path, as specified in
[the local tree cover construction](2026-09-08-local-tree-cover.md).
This distinction permits changing availability channels without inventing
conditional event distributions on absent receiver rows.

Let $(c_i,s_i)$ be the refined waypoints, where $s_i$ is the supplied increasing
path parameter. It is not assumed to be Euclidean arc length. Refinement linearly
interpolates both context coordinates and this parameter, preserves the original
waypoint coordinates exactly, and uses
$\Delta\tau_i=\rho(s_i-s_{i-1})$ for inference rate $\rho\geq0$.
Consequently the total allocated inference time is
$\rho(s_{\mathrm{last}}-s_0)$ for every refinement. The initial row is the actual
initial recognition law at $c_0$, with no inference time assigned to that row.

At every subsequent waypoint, the local generative model is rebuilt at the
arrival context. In particular, its Gaussian prior, posterior, latent event
posterior, observation evidence, and coarse maps belong to the arrival context.
The preceding context's target is not kept fixed across this move. The common
Gaussian agents form a sorted survivor set. Their marginal is transported by the
existing exact segment transport for the declared connection. The agent domains
and the context square in this cover are convex, so a common survivor's straight
segment is contained in its domain. A move without any common survivor is not
admitted.

Write the transported survivor law as $q_S^T$ and the new prior as $\pi_i$.
Departing variables are marginalized out, and entering variables $E$ receive the
new prior conditional:
$$
q_i^{\mathrm{arrival}}(z_S,z_E)
=q_S^T(z_S)\pi_i(z_E\mid z_S).
$$
This is a declared boundary policy, not an inferred matching principle. Its
Gaussian construction and the associated identity
$$
D_{\mathrm{KL}}(q_i^{\mathrm{arrival}}\Vert\pi_i)
=D_{\mathrm{KL}}(q_S^T\Vert\pi_{i,S})
$$
are given in the Gaussian boundary module. When nobody enters, only the survivor
marginal is transported; the prior does not replace it. The controller retains
the marginal-preservation, conditional-reconstruction, and KL-chain residuals
returned by that module. The full latent event law is unchanged during this
context move.

The second part of the step performs the existing exact full-family reverse-KL
Fisher evolution toward the arrival posterior for time $\Delta\tau_i$. In
Gaussian natural coordinates $J=\Sigma^{-1}$ and $h=J\mu$, with
$a_i=\exp(-\Delta\tau_i)$, this is
$$
J_i=a_iJ_i^{\mathrm{arrival}}+(1-a_i)J_i^\star,
h_i=a_ih_i^{\mathrm{arrival}}+(1-a_i)h_i^\star.
$$
For the positive latent event law it is
$$
q_i(x)=
\frac{q_i^{\mathrm{arrival}}(x)^{a_i}p_i(x)^{1-a_i}}
{\sum_{x'}q_i^{\mathrm{arrival}}(x')^{a_i}p_i(x')^{1-a_i}}.
$$
These operations use the full Gaussian and full categorical families. Evolved
Gaussian states need not preserve the original sparse tree precision. Therefore
the reported objective is the full posterior KL, summed across the Gaussian and
latent categorical factors, and the VFE is that sum minus the current log
evidence. The tree accounting routine is not used for evolved states.

The row's arrival and after-inference KL values refer to the same arrival
posterior. Descent is checked only within that row. No global VFE monotonicity
is asserted while context, evidence, dimension, and target vary. The algorithm
is the explicit splitting policy “transport and reconcile, then infer.” It is
not a claimed solution of a specified continuous coupled differential equation.
Differences between refinements are descriptive; refinement does not imply an
identity between resulting laws.

At each row, both parent depths are computed from the carried fine laws using
the current channels. Direct projection to depth two is compared with projection
through depth one for both Gaussian moments and categorical probabilities.
Only active Gaussian coordinates are stored, together with their agent labels.
The additional reference-frame moments use $\bar\mu=G^T\mu$ and
$\bar\Sigma=G^T\Sigma G$, allowing chart comparisons without conflating different
coordinate frames. They do not identify laws of different active dimensions.
There is no SPD claim for padded absent coordinates and no continuity claim for
an entire normalized Gaussian parent after that parent ceases to exist.

The visible event probabilities, joint endpoint occupancies $\eta$, and receiver
occupancies $\alpha$ keep their structural zeros. At a fixed carried latent law,
these measures inherit the smooth availability channel. Conditional attention
$\beta=\eta/\alpha$ is defined only where $\alpha>0$. A wholly undefined row is
NaN, accompanied by a full-shape Boolean mask, while structural-zero entries
within defined rows remain zero. The explicit null outcome can have positive
occupancy and is then defined. The existing cover's rejection of positive
availability underflow is retained; no epsilon, probability floor, or uniform
completion is introduced.

The supplied tiny tests cover an exact boundary and offsets of 0.01 on both
sides, entry and exit, carried latent-event preservation, conditional-attention
domains, reference-frame chart comparisons, the constant-context Fisher
semigroup under refinement, and zero inference rate. They are implementation
controls, not a continuum-limit argument. Earlier frozen-context compression
approximations and all-time interval bounds are not applied to this moving
target evolution.
