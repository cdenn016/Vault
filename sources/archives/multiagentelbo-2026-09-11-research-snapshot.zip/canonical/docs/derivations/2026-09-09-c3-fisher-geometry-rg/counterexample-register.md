<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753","target_digest":"aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753"} -->

# Counterexamples, sustained findings and scope boundaries

No counterexample to the current frozen target under its actual stated premises was found in the current construction/reconstruction. This statement is not a proof by failure to find one; the direct derivations provide the mathematical evidence.

The form exp(2v)du^2 has constant rank and vertical radical but is not the pullback of a metric on the u leaf space, because its coefficient changes along each leaf. [DG10](agents/density-geometry-construction.md) therefore refutes automatic quotient descent from constant rank. The present regular charts instead have a proved positive density floor and identifiable finite-marginal law coordinates.

A positive constant multiple a g of a nonflat metric has scalar curvature R/a. Sending a to zero need not give flatness. This explicit scaling calculation prevents an inference from all-depth vanishing Fisher density to vanishing curvature. The current fixed-B volume limit and finite-hierarchy neighborhoods do not imply a common unbounded-depth regular region.

A positive binary probability family has Fisher rank at most one in two parameters; erasure has rank zero. The exact public geometry evaluator refuses them before inversion. The sustained finding FG05-REGULAR-PATH was an omitted statement premise: the combined evaluator checks positive principal minors and computes the inverse before dg/ddg. Its documentation and atomic claim now require that admission and successful completion, while retaining the general algebraic identity on positive C3 families. Source, tests and receipts were unchanged, and the packet was not rerun.

The proof interface also replaced a named local-inversion step with explicit t(M,V),c(V,t) formulas and removed a prohibited spacing macro. These were proof-explication/style repairs rather than refutations of the determinant or chart conclusion. Both initial snapshots and the final current proof bindings are retained.

Fourth-cumulant summability is not inferred from pairwise covariance decay; HR02–06 prove joint group separation, cancellation and source counts. The actual C2 Fisher-density limit is not inferred by differentiating an old boundary estimate; DG03–05 include the moving full-law expectation and its shell weights. No open gap may be closed by replacing these arguments with finite curvature agreement.

No artifact/file corruption, forgery or malicious-packet scenario was executed. Those checks are user-excluded/not run. The mathematical counterexamples and legitimate positive/singular/resource-admission cases above are ordinary correctness arguments and do not alter or forge stored artifacts.


The mature independent record also contained an incorrect intermediate bound on the centered parity contrast: at B=1 and s=-1, a(s)=-1-b has magnitude greater than one. The required variance bound nevertheless follows from Var(E[z|Y])<=Var(z)=1-b^2<=1. Finding MC05-CONTRAST-BOUND preserves this counterexample and replaces the false premise with total variance. The author proof already used the correct variance argument; no target theorem, source, test or numerical receipt changes.
