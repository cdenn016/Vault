<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753","target_digest":"aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753"} -->

# Author check of the HR-to-density and geometry interface

Date: 2026-09-09. **DEFINITION.** This is an author-interface review, not independent reconstruction, source execution or ledger closure. The checker authored HR and its discovery route. The root's density-geometry-construction.md was read in full, the named constants and derivative passages were reconstructed against HR, and the corrected DG01/DG09 seams were read back. Only this supplementary file is written; no proof, claims, implementation, test or previous artifact is modified. The proof-section labels below are literal headings in the construction and need not coincide one-to-one with the root's later atomic proposal numbering.

The checked root proof revision is SHA256 c1cab7acfba197a1c4687639b8a02271a2e3d0c7273d70d2023129b526c0aa23. The current density-geometry-claims.json, including the added actual-law chart proposal DG17, has SHA256 f1a6caf4701491d62c639cead3b0a47962e53ae50d618282fa85c60f3e3e19f3. The initial interface review bound the earlier proof acc373910e44f315b87e577356857fb47553691e0d038567b6705f92fa98c8c7; the final DG06 paragraph and DG17 were read back separately before this revision. Its frozen author inputs are higher-response-construction.md SHA256 c4e38ff4475e813360fc332ba4419efcb351826988cb5cf3d43c4773f767b837 and higher-response-claims.json SHA256 c872d0c54dbabe9fad0ff79b0027671e67a173ce8330372fbf6bed46e8dc39af. This review checks their interface; it does not independently certify those HR premises.

## DG01: complete norm constants and small radii

**ESTABLISHED BY DIRECT INTERFACE ALGEBRA.** HR10's large-radius V_n bound has coefficient Z_n=N_n+2exp[tau/(2n)]S_n(1), and the value bound permits Z_0=2C. Replacing M_j by its uniform upper bound U_j in HR13 gives exactly DG01's P_1,P_2,P_3. For j<=n, B^(2j+2)<=B^(2n+2), the lower polynomial radius degree can be enlarged to 2n+1, and exp[-tau R/(2j)]<=exp[-tau R/(2n)]. Thus this replacement preserves each inequality, including mixed derivatives.

For r>=3, R=r-1>=2 and 4P_n supplies the shell's large-radius coefficient. At r=1,2, use the actual shell amplitude 2F_n<=8E_n B^(4n)rho^(B-n). Dividing by B^(2n+2) leaves B^(2n-2)rho^B. Its sum over positive integers is bounded by (2n-2)!/(1-rho)^(2n-1), including n=1, where 0!=1 and sum rho^B<=1/(1-rho). The remaining exp[tau/(2n)] in H_n dominates the radius-one case and cancels the exp[-tau/(2n)] factor at radius two, with the additional 2^(2n+1) only enlarging the bound. No missing small-radius term was found.

Taking the square root of the two valid shell bounds produces B^(n+1)r^(n+1/2)exp[-tau(r-1)/(4n)]sqrt(2F_nH_n). The diameter weight at lambda=tau/48 contributes exp(tau r/24). The resulting exponent is a_n=tau/(4n)-tau/24, positive for n=1,2,3; the smallest is tau/24 at n=3. The bound r^(n+1/2)<=r^(n+1) and translate count (2r+1)^2 give the displayed series. Its upper bound follows from (2r+1)^2<=9r^2 and sum_(r>=1)r^(n+3)x^r<=(n+3)!/(1-x)^(n+4). The depth prefactor is B^(3n+1)rho^((B-n)/2), as stated. The value argument also lies within UP's allowed lambda<tau/4 domain.

The uniform derivative tails are sufficient for the repeated Banach-space FTC used there. Finite orbit terms have finite alphabets and finite contributions to the weighted norm, while their translates remain part of the norm count. This identifies the derivative of the complete parameterized interaction; it does not assert an RG derivative on arbitrary interactions.

## DG02: differentiated row Fisher and its modulus

**ESTABLISHED BY DIRECT DIFFERENTIATION.** The second parameter derivative of the row Fisher integrand has ten expanded monomials. Their amplitude groups are one L_1^4 term, five L_1^2L_2 terms, two L_1L_3 terms and two L_2^2 terms. Thus E_B retains all probability-derivative contributions. There is no omission of the derivative of the row weight p.

For the comparison modulus, each monomial has p and at most four log-jet factors. Telescoping at most five factors, for ten monomials and four states, is bounded by 200H_B^4 times the largest input difference. The bracket V_0+2T_1+2T_2+2T_3 bounds that largest difference. The individual atom difference is at most V_0 by the two-step Bernoulli product bound. The 2E_B cap is independently valid. This establishes the particular nonoptimized omega_B used subsequently; it does not derive a derivative bound from a value-only modulus.

## DG03: polynomially weighted varying-expectation response

**ESTABLISHED UNDER THE FROZEN HR SOURCE-SUM PREMISES.** A local coarse observable on Q_N pulls back to fine blocks with the same anchor set, of size a_N=(2N+1)^2. An order-two expectation derivative has its local observable derivative, two possible first-source covariance terms, and one second-source cumulant sum. For repeated directions the covariance term has coefficient two; for mixed directions it is the sum of two distinct terms. Hence 1+2S_1(a_N)B^4+S_2(a_N)B^6 controls all derivatives of orders zero through two using the stated maximum norm of the observable jets.

From the explicit HR06 constants, S_r(a) is a polynomial in a of degree r+1, because it is a^r times a constant plus a linear expression in a. Thus W_B(N) has degree at most six in N. Combined with omega_B's degree-seven polynomial times exp(-tau N/6), the weighted shell sum converges. Both the parameter-dependent observable and the unconstrained full fine law vary in this calculation. Finite local response, uniform HR tuple tails and FTC justify the displayed formulas before shell summation. The finite sums are C2; convergence of their derivatives under the weighted majorant proves actual C2 of the expectation and permits the shell/source reordering. A formal pressure derivative is not used.

## DG04: the common-prefix argument

**ESTABLISHED BY THE SPECIFIED FUNCTIONAL EQUALITY.** S is a deterministic subset of the lexicographic past, and J_S is a function of the common full configuration y. If S and S' have the same intersection with Q_R, then their finite truncations prescribe exactly the same coordinates with the same y values for every N<=R. Therefore f_N^S and f_N^(S') agree as functions, not merely in distribution or expectation. Their shell differences through radius R cancel identically, including their actual parameter derivatives.

For later shells, both C2 norms are bounded by omega_B(N-1). Applying DG03 to the remaining two shell series yields exactly twice the weighted tail. The expectation throughout is the same unconstrained full-law expectation. Averaging a row under its own differently conditioned fine law instead would change the target. The future is absent in both predictive patterns, while the canonical interaction's future is fixed to the vacuum; DG04 does not substitute that other convention. The result applies to arbitrary finite revealed past shapes and the complete past, with no hidden regular-shape premise.

## DG05: actual finite-marginal C2 passage

**ESTABLISHED UNDER THE STATED ACTUAL-ROW IDENTITIES.** Every finite full-law coarse marginal is positive C3 by HR. Its ordered log score is the sum of actual predictive row scores. The later increment is centered conditionally on its entire finite past, so the matrix cross terms vanish. This gives the exact finite Fisher chain identity before differentiation. Each resulting expectation is C2 by DG03-DG04; differentiating a finite equality twice is valid and does not differentiate an information inequality.

For a radius-R bulk cell, the relative finite past and complete past have identical intersections with Q_R. DG04 therefore bounds its entrywise C2 difference by epsilon_B(R). At most 4RL cells are outside the bulk, and each difference of their expectation jets is bounded by 2Z_B. Division by L^2 gives epsilon_B(R)+8Z_BR/L. Taking L to infinity first, then R, proves the actual marginal C2 limit, with the varying-law and boundary-score derivatives included. Entrywise versus operator norms differ by a fixed dimension-dependent factor; the proof only claims entrywise bounds at this point and correctly uses norm equivalence for convergence.

## DG06: regular geometry and its finite-volume limit

**ESTABLISHED UNDER HR'S ACTUAL CONDITIONAL-SCORE FLOOR.** HR16 supplies a positive lower bound for the density on each fixed-B regular chart, and finite minima cover a prescribed finite hierarchy. Combined with DG05 this gives a C2 positive-definite density metric. Differentiating the inverse identity twice supplies its C2 inverse. The displayed Christoffel formula is then C1 and is the unique torsion-free metric-compatible connection by the usual cyclic algebra, which is stated in the proof.

The Riemann convention R^l_(kij)=partial_i Gamma^l_(jk)-partial_j Gamma^l_(ik)+Gamma^l_(im)Gamma^m_(jk)-Gamma^l_(jm)Gamma^m_(ik) has Ric_(kj)=sum_i R^i_(kij). On the radius-r sphere its commutator form is R(U,V)W=(<V,W>U-<U,W>V)/r^2, giving positive Ricci contraction and scalar 2/r^2 in dimension two. Thus DG06 and DG09 use the same sign.

The C2 convergence of the normalized finite matrices L^(-2)I_(B,Lambda_L), together with the density floor, makes them invertible for all sufficiently large L on a compact regular subchart. Continuity of matrix inversion and the displayed finite rational/product formulas gives convergence of connections and curvature there. The normalization L^(-2) is essential; curvature of the unnormalized finite Fisher matrix would carry a different scale factor. This is a fixed-B volume limit and does not establish an unbounded-depth inverse or curvature limit.

The final added DG06 paragraph also supplies local coordinates of the actual law. A positive finite Fisher matrix is the Gram matrix Dp^T diag(1/p)Dp, so its rank is the rank of Dp. Rank two selects two rows with a nonsingular minor. Normalize their map by its Jacobian at the point and translate the point and image to zero. Continuity gives a ball on which the derivative differs from Id by at most 1/2. Segment integration then gives both injectivity and an inverse Lipschitz constant of at most two. If the ball has radius r, each target with norm less than r/2 makes x -> x+y-F(x) a contraction mapping the closed ball to itself. Its iterates are Cauchy by the geometric contraction estimate, and their limit is the unique inverse point. To justify the differentiability implicit in the proof's last sentence, the inverse Lipschitz estimate and the first-order remainder of F give DG(y)=DF(G(y))^(-1). This is continuous; differentiating that identity twice using F in C3 gives G in C3. Thus the paragraph identifies a local actual finite-marginal family, and hence the full law, instead of merely furnishing a metric on a redundant parameter domain. Its atom pair and finite square may depend on the chart point and fixed B. Proposal DG17's dependencies DG08 and HR12 supply respectively the eventual finite positive floor and actual positive C3 marginal premise. No common choice over unbounded B is inferred.

## DG09: determinant and coordinate algebra by hand

**ESTABLISHED BY DIRECT ALGEBRA.** Put D=1+c t^4. Differentiation gives

\[
M_t=\frac{1+3ct^2-3ct^4-c^2t^6}{D^2},\quad
M_c=\frac{t^3(1-t^2)}{D^2},
\]

\[
V_t=\frac{2t(1+c)(1-ct^4)}{D^2},\quad
V_c=\frac{t^2(1-t^4)}{D^2}.
\]

The determinant numerator factors as t^2(1-t^2)^2(1+ct^2)D, yielding the stated denominator D^3. The Jacobian from (M,V) to (p_++,p_--) has determinant 1/4. The natural-coordinate map to (t,c) has determinant (1-t^2)(1-c^2), and the (b,c)-coordinate map has determinant (1-c^2)/(1-bc)^2. Both are positive in the stated fixture domain. The rational point maps to b=25/101 as claimed.

The four crossing-sign prescriptions are simultaneously realizable: put minus signs on the four outer edges parallel to the central square's corresponding edges, and plus signs on the other exterior edges. Each adjacent plaquette then has exterior product -1. This retains all five touching plaquettes rather than an isolated-square surrogate. Equal mixed-sign masses make the three-category collapse a fixed sufficient channel with fixed fair-coin recovery. The sphere-positive scalar 1/2 therefore has the stated finite source meaning; it does not certify the infinite-density rank or curvature by itself.

## Corrections raised and read back

**ESTABLISHED BY READBACK.** The initial read found a prohibited comma-spacing macro in DG01's norm display; the root removed it, and the checked revision contains none. The initial DG09 text invoked the inverse function theorem. To keep the local chart step directly explicit, this review supplied

\[
t=\frac{2M}{1+V+\sqrt{(1+V)^2-4M^2}},\qquad
c=\frac{V-t^2}{t^2(1-Vt^2)}.
\]

The root replaced the named-theorem sentence with these formulas and their discriminant/denominator conditions. Direct readback confirms M(1+t^2)=t(1+V), branch t<1, positive discriminant at an interior positive row, and positive denominator at the fixture. The smooth local inverse now gives the needed chart directly. This is a proof-explication correction, not a refutation of the earlier determinant or local-invertibility conclusion.

**NOT-CLAIMED.** No further concrete mathematical error was found in the scoped interfaces checked above. This is not an independent endorsement of HR, an implementation review, a numerical reproduction or a ledger adjudication. No tests or science ran. The higher-response premises, actual-density target, fixed-B regularity boundary and distinction among Fisher, gauge and base curvature remain explicit dependencies rather than inferred generalizations.
