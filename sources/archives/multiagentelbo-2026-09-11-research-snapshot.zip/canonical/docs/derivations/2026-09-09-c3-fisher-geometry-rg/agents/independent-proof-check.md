<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753","target_digest":"aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753"} -->

# Independent initial reconstruction: higher response and Fisher geometry

Date: 2026-09-09. Revision 1. Only the new frozen problem-contract.json was read before this reconstruction. Its file SHA256 is 44dfea8ab58cc9a99fe3105e61cb8a4921080733423426b928ef0ec88b35b6e4 and target digest is aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753. No current author, root, worker, source or intake draft, and no prior next-C3 discovery note, was read. The preceding admitted UC/UP/FR/FX/GX constructions and SPEC are inputs. Shared model family, prior context and filesystem limit independence. This document supplies a direct candidate construction with exact premises and attack conditions; it assigns no ledger state. No tests, source execution, numerical science, producer, Git, GPU, tamper, vault or memory operation was performed.

## IC301. Compact constants and a signed-J continuation

Fix a compact positive-h interval inside a slightly larger compact positive-h interval. Choose J_*>0 with 12 tanh J_*<1, and work temporarily on a rectangle with abs(J)<=J_* and bounded positive h, leaving an outer h margin. This auxiliary smooth extension uses the same finite factors: 1+tanh(J)chi stays positive. Its J>=0 restriction is the original law. It is not a changed positive-J program or a claim that the finite executable admits negative inputs.

The UC finite coupling proof extends directly. Flipping an exterior plaque sign changes a field from u+J to u-J, whose Bernoulli distance is at most tanh(abs(J)); same-parity Hamming cost is at most twice that. All incidence and weight estimates use c_*=tanh J_* regardless of J's sign. Positive finite supports, the six fine-edge column count, stationary heat-bath construction and exterior integration remain identical. They prove the same all-pattern comparison, uniqueness and limits on the auxiliary rectangle, including zero. Thus continuation is proved rather than inferred by substituting a vanishing q.

Choose 0<tau<log(1/(12c_*)); write q=12c_*exp(tau)<1, C=16q/(1-q), rho=tanh(h_*+2J_*)<1, d=1-rho and m=d^2/4. The admitted joint-cylinder estimate on a common whole-block radius-n neighborhood is

    TV <= C abs(A) B^2(n+1)exp[-tau(n+1)].

A counts target block anchors. All patterns and fine exterior signs are fixed under parameter differentiation. Every derivative includes free-edge fields and every touching/crossing plaque. Ordered source tuples may coincide, with no factorial divisor. There are 3B^2 combined local source types per anchor: two field orientations and one plaque base. A plaque source has at most four support anchors within distance one of its base. Ordinary positive-J compacts use an enlarged rectangle and the same constants. The signed strip is needed separately for the product-limit certificate.

## IC302. Group decoupling and counted cumulants

This step establishes higher clustering rather than inferring it from pairwise covariance. Let F have norm at most one and finite nonempty support-anchor set A. Let T_1,...,T_r be individual bounded field or completed plaque characters at anchors v_1,...,v_r, 1<=r<=3. Put D=max_j dist_infinity(v_j,A). Contract A to a root and take a minimum spanning tree on that root and the r labeled sources. Root distances are dist(v,A), other distances ordinary anchor distances. A root-to-farthest path has at most r edges and total length at least D. Its tree's largest edge ell therefore satisfies ell>=D/r. Removing a largest edge gives two groups with every cross edge at least ell: a shorter edge would replace it and lower the tree weight. This cut property does not require the contracted weights to be a metric. Coincident sources remain distinct zero-distance vertices.

For ell>=3 the groups' actual fine supports are separated by at least ell-2. Take the whole-block radius-(ell-3) neighborhood around one group's support anchors; it excludes the other group. Conditional on all exterior fine spins, the interior is the same normalized finite specification on identical interior parity supports. UC bounds the first group's joint-law variation over those boundaries. Integrating against the other group's observable and the first group's marginal gives joint-to-product TV at most

    C(abs(A)+4r)B^2(ell-2)exp[-tau(ell-2)].

No fine-spin conditioning inside a cut block is used: the neighborhood contains entire blocks and the other group is exterior measurable. The argument applies to finite laws and their DLR limits.

Define O_n=sum_pi abs(pi)! and K_n=sum_pi(abs(pi)-1)! over partitions of n labels. K_2=2,K_3=6,K_4=26 and O_2=3,O_3=13,O_4=75. The joint cumulant is

    kappa(X_0,...,X_r)=sum_pi (-1)^(abs(pi)-1)(abs(pi)-1)!
                       product_C E[product_(j in C)X_j].

Under an independent nonempty split this is zero: the logarithm of the finite moment-generating expansion is a sum of two group logarithms, so every mixed coefficient vanishes. Expanding that logarithm yields the displayed coefficients. TV epsilon changes each bounded product moment by at most 2epsilon; a partition product changes by at most 2abs(pi)epsilon. Therefore the original cumulant is bounded by 2O_(r+1)epsilon.

For all D, including small or zero tree edges, set

    beta_r=tau/(2r),
    L_r(A)=2O_(r+1)exp(2tau)[1+2C(abs(A)+4r)/tau].

Then

    abs(kappa(F,T_1,...,T_r)) <= L_r(A)B^2exp(-beta_r D).

For ell>=3 use t exp(-tau t)<=2exp(-tau t/2)/(e tau), t=ell-2. If ell<3, D<3r and the prefactor exceeds the trivial partition bound K_(r+1). Repeated anchors are therefore included. General F contributes a factor norm(F) by multilinearity. This proves decoupling for the actual constrained law before cumulant cancellation; it does not assume a tree-product bound.

## IC303. Source summability, actual C3 and spatial moduli

Write S_p(s)=sum_(n>=0)(2n+1)^p exp(-sn), finite for s>0. There are at most abs(A)(2n+1)^2 anchors within distance n of A. Ordered r-tuples whose maximum distance is exactly n are bounded in count by [3B^2 abs(A)(2n+1)^2]^r. This overcounts the shell but includes all repeated tuples. Since L_r(A)<=abs(A)L_r({0}), define

    M_r=3^r L_r({0})S_(2r)(beta_r).

The complete absolute cumulant sum is at most norm(F)M_r abs(A)^(r+1)B^(2r+2). The tail uses the same series restricted to n>N. All source multiplicities and B powers are retained, including finite crossing sources.

For a finite normalized exponential law, r natural derivatives of E F equal kappa(F,T_i1^total,...,T_ir^total). Finite differentiation of the normalized generating function proves this; multilinearity gives the ordered local sums. Repeated parameter indices do not remove coincident sites. For each fixed tuple, UC gives uniform joint target/source convergence, hence convergence of its finitely many moments and cumulant. The near tuple set is finite; both far tails have the stated bound. Every finite derivative through order three thus converges uniformly to a continuous limit. Pass finite coordinate FTC first for the means, then for their first derivatives, then for their second derivatives. Each integral error is bounded by segment length times the uniform derivative error. Continuity of the limit proves actual C3 everywhere on the enlarged interior. This is neither a Lipschitz substitute nor an almost-everywhere claim.

An explicit spatial modulus follows as well. If two patterns agree through R>=2 about one free target, put N=floor(R/2)-1. A near r-tuple and the target use at most 1+4r anchors inside Q_(N+1). Their radius-(R-N-1) neighborhood fits Q_R, so joint TV is at most C(1+4r)B^2(R-N)exp[-tau(R-N)]. Multiplying by 2O_(r+1) and the near count yields

    2O_(r+1)C(1+4r)3^r B^(2r+2)
       (2N+1)^(2r)(R-N)exp[-tau(R-N)].

Add twice the tail

    3^r L_r({0})B^(2r+2)
      sum_(n>N)(2n+1)^(2r)exp(-beta_r n).

The same comparison holds for an oracle containing Q_R, because every near completed source is interior. At R=0,1 use 2M_rB^(2r+2). Define nu_r=tau/(8r) and

    v_r=2O_(r+1)C(1+4r)3^r
       +2*3^r L_r({0})exp(beta_r/4)S_(2r)(beta_r/2)
       +2M_r exp(nu_r).

Extracting exp[-beta_r(N+1)/2] from the tail gives the all-radius bound

    derivative difference <= v_r B^(2r+2)(R+1)^(2r+1)exp(-nu_r R).

The slowest exponent is nu=tau/24. The zeroth mean comparison is at most 2CB^2(R+1)exp[-tau(R+1)]. Each order has its own exponent before taking a common smaller one. Remote patterns can change support outside the common interior; exterior conditioning and integration never couples incompatible interior fibers.


## IC304. Actual higher response decays with depth

Leave target P free. Given all other blocks, its B spins are independent with means bounded by rho. In a product of Y_P with at most r individual source characters, each source involves at most one target coordinate. At most r coordinates are canceled or supplied by those characters. The conditional moment has magnitude at most rho^(B-r); for B<r this loose bound exceeds one and remains valid. Repeated coordinates improve it. Every cumulant partition has exactly one moment containing Y_P and its other moments are bounded by one. Hence

    abs(kappa(Y_P,T_1,...,T_r)) <= K_(r+1)rho^(B-r).

Combine with IC302 by min(U,V)<=sqrt(UV), then sum ordered sources. For 1<=r<=3,

    abs(partial_i1...ir E Y_P) <= a_r B^(2r+1)rho^(B/2),
    a_r=3^r sqrt(K_(r+1)L_r({0}))rho^(-r/2)S_(2r)(beta_r/2).

The zeroth amplitude is rho^B. These are bounds on actual cumulant derivatives, not derivatives of an envelope. They make the finite-oracle jet convergence uniform over B: choose a large-B cutoff by the amplitude, then a common radius for the finitely many remaining B.

Every cell atom is the product of two successive Bernoulli parity probabilities, with the same first parity fixed in both compared patterns. Finite conditioning changes precisely that fiber. Leibniz gives positive C3 four-state rows, and further finite sequential products give every finite coarse conditional atom. The one-cell atom is at least m=(1-rho)^2/4. Null infinite exteriors use normalized limiting versions, not infinite-event ratios. Both vacuum-hybrid and absent-future predictive rows are covered as different fixed patterns.

## IC305. Complete common C3 interaction norm

The following explicit constants are conservative. Set A=max(1,a_1,a_2,a_3), U=8A^2, U0=max(1,U), M=max(1,M_1,M_2,M_3,A), V=max(2C,v_1,v_2,v_3). Positive-order atom jets through order three are bounded by U B^8rho^(B/2), and all atom jets by U0B^8. Spatial differences of those jets, including order zero, are bounded by

    Vq B^16(R+1)^7exp(-nu R), Vq=16MV, nu=tau/24.

The factor sixteen covers eight Leibniz subsets and two choices of differing Bernoulli factor.

For an rth log derivative, the partition formula has coefficients (-1)^(abs(pi)-1)(abs(pi)-1)! multiplying p^(-abs(pi)) times the atom derivatives over its partition blocks. For r<=3 there are at most three factors and the absolute coefficient sum is at most six. The value log-odds is at most 4rho^B/d. Therefore every target-versus-vacuum log-odds jet of orders zero through three is bounded by P B^24rho^(B/2), where

    P=max(4/d,12(1+U0/m)^3).

For spatial differences telescope each product and use

    abs(p^(-k)-p'^(-k)) <= k m^(-k-1)abs(p-p'), 1<=k<=3.

A valid common bound is Q B^40(R+1)^7exp(-nu R), with

    Q=72Vq(1+U0)^3(1+m^(-1))^4.

The B^40 factor includes the denominator change multiplied by three B^8 jets and the B^16 probability difference. The same constants work on the full enlarged compact rectangle.

Keep the unchanged (+,+), lexicographic canonical interaction and every shell. Successive truncations agree through r-1. Every interaction jet through order three has singleton amplitude P B^24rho^(B/2) and shell bound

    min(2P B^24rho^(B/2), Q B^40 r^7exp[-nu(r-1)]).

The support diameter is at most 2r; at most (2r+1)^2 translates contain the origin. At lambda=nu/8=tau/192, geometric interpolation and r^(7/2)<=r^4 yield the complete norm bound

    E_B=P B^24rho^(B/2)
       +sqrt(2PQ)exp(nu/2)B^32rho^(B/4)
          sum_(r>=1)(2r+1)^2 r^4 exp(-nu r/4).

The tail is the same series restricted to r>N. All series converge and both depth factors are polynomial times geometric, so E_B tends to zero compact-uniformly. Finite shell truncations are C3 in finite orbit-value spaces. Uniform tails at all four orders permit repeated interaction-valued FTC and prove actual C3 in this one common Banach norm. No shell, translate or mixed derivative is dropped. The claim concerns the exact parameterized orbit, not an RG Frechet derivative on arbitrary interactions.

## IC306. Varying-law expectation derivatives and quasilocal shells

For a local C2 observable F_g with fixed finite support A, finite differentiation and the cumulant limits give

    partial_i E F = E F_i + sum_a kappa(F,T_(i,a)),
    partial_ij E F = E F_ij
       +sum_a kappa(F_i,T_(j,a)) +sum_a kappa(F_j,T_(i,a))
       +sum_(a,b) kappa(F,T_(i,a),T_(j,b)).

The source sums include crossing factors and coincident pairs. In finite volume these are ordinary normalized derivatives; IC303's uniform summability and FTC give the actual infinite derivatives. If every jet of F through order two has norm at most F_*, these expectation jets are bounded by

    Cobs abs(A)^3B^6 F_*, Cobs=1+2M_1+M_2.

This is the polynomial support cost from orders zero, one and two, not an unweighted infinite source bound.

For an arbitrary predecessor set S, finite or infinite, let J_S(g,omega) be the cell Fisher row with exactly S prescribed and all other parities absent. It is C2 for fixed omega because probabilities are C3 and at least m. An entry is sum_a p_i p_j/p. Its second parameter derivative, written explicitly in IC311, has four two-factor terms over p, five three-factor terms over p^2, and one four-factor term with coefficient two over p^3. There are four atom values. Product and inverse telescoping give the safe componentwise bounds

    max_(abs(alpha)<=2) norm_entry(partial^alpha J_S) <= Jc B^32,
    Jc=100(1+U0)^4(1+m^(-1))^4,

and for matching radius-R patterns,

    max_(abs(alpha)<=2)norm_entry(partial^alpha[J_S-J_T])
      <= Jd B^48(R+1)^7exp(-nu R),
    Jd=1000Vq(1+U0)^4(1+m^(-1))^4.

Here norm_entry is maximum absolute matrix entry. The constants include all four atoms and the eleven weighted second-derivative terms. The B^48 denominator-change contribution is included.

Decompose J_S as J_empty plus J_(S intersect Q_r)-J_(S intersect Q_(r-1)), r>=1. A shell is local on at most (2r+1)^2 anchors and its jets are at most JdB^48exp(nu)r^7exp(-nu r). Set

    R_B(0)=Cobs Jc B^38,
    R_B(r)=Cobs Jd exp(nu)B^54(2r+1)^6 r^7exp(-nu r), r>=1,
    M_B=sum_(r>=0)R_B(r).

By the local expectation formula, every expected shell derivative through order two is bounded entrywise by R_B(r), including the varying law. The summable series proves actual C2 of E J_S uniformly over S and the compact rectangle. Repeated FTC passes both derivative interchanges. The probability law is not frozen while differentiating this expectation.

## IC307. Actual C2 marginal Fisher-density limit

Let P be the infinite lexicographic past. At a square cell x the revealed past is S_(x,L)=(Lambda_L-x) intersect P. The actual finite marginal score-chain identity is

    I(mu_(B,Lambda_L))=sum_(x in Lambda_L)E_muB J_(S_(x,L)).

The same full law is used in every expectation. Its parameter response is explicitly accounted for in IC306. Future variables are absent, unlike the canonical vacuum hybrid.

For a radius-R bulk cell, S_(x,L) and P agree in Q_R, so their shell decompositions agree exactly through R as functions of the same configuration. The difference of their expected derivatives through order two is at most 2sum_(r>R)R_B(r). At any other cell it is at most 2M_B. There are at most 4RL nonbulk cells when L>=2R. For every abs(alpha)<=2,

    norm_entry(partial^alpha[
      I(mu_(B,Lambda_L))/L^2-E_muB J_P])
      <=2sum_(r>R)R_B(r)+8M_BR/L.

This is an actual C2 error bound. Choose R from the explicit tail, then L from the boundary term, uniformly on the compact set for fixed B. IC306 makes E J_P a C2 function and GX identifies it with the existing C0 density, so no surrogate limit is introduced. In two dimensions an operator-norm version costs a factor two. Derivatives of a PSD inequality are not asserted PSD, and no boundary-score derivative is inferred from an O(boundary) log-density error.


## IC308. An actual-density product-control rank certificate

This lower certificate works for every B, including one, and does not infer a density floor from a bounded observation alone. At J=0 fine signs are iid with mean b=tanh h in (0,1); retained disjoint parities are independent with mean r=b^B and variance v=1-r^2. Define

    a=(1-b^2)b^(B-1)/(1-b^(2B))>0, U_e=Y_e-r.

Direct conditioning on parity gives E[z_e|Y_e]=b+a U_e for any fine edge in that path. At each cell use its two outgoing paths and observables F1_x=U_(x,1)+U_(x,2), F2_x=U_(x,1)U_(x,2). At the base point their covariance matrix is diag(2v,v^2). Different cells use disjoint outgoing paths, hence are independent at J=0. The test-observable centers are frozen at that parameter when taking score pairings.

The complete covariance-source formulas give

    partial_h E F1_x=2Bav, partial_J E F1_x=4B b^3av,
    partial_h E F2_x=0, partial_J E F2_x=b^2a^2v^2.

For F1, each path has B field sources and 2B incident plaques, each intersecting it once and contributing b^3av. For F2, a nonzero source must meet both outgoing paths. Exactly the lower-left-corner plaque at that vertex does so, with one edge in each; its other two signs integrate to b^2. All other sources leave a centered independent U and vanish. This remains true for B=1 and includes crossing plaques in the actual marginal response.

Sum both F statistics over a square. Their covariance is L^2 diag(2v,v^2), and their derivative pairings are L^2 times the displayed rows. Projection of the actual marginal score onto those statistics gives a PSD Gram lower bound. Divide by L^2 and take the actual density limit:

    mathcal I_B(h,0)>=L_B(b),
    L_B=2B^2a^2v [[1,2b^3],[2b^3,4b^6]]
             +b^4a^4v^2 [[0,0],[0,1]].

This is a lower bound, not a formula suppressing other orthogonal interaction terms. Put u=2B^2a^2v and w=b^4a^4v^2. Then det L_B=uw>0, and its least eigenvalue is at least uw/[u(1+4b^6)+w]. Extensive statistics and exact product-control independence make this an actual-density certificate.

For b in [b0,b1] inside (0,1), set a0=(1-b1^2)b0^(B-1), v0=1-b1^(2B), u0=2B^2a0^2v0 and w0=b0^4a0^4v0^2. The identity a=b^(B-1)/(1+b^2+...+b^(2B-2)) gives a<=1; also a>=a0 and v>=v0. Thus

    eta_B=u0w0/[2B^2(1+4b1^6)+1]>0

is an explicit uniform eigenvalue floor at J=0. It may degenerate with B; no unbounded-depth uniform floor is claimed.

## IC309. Positive-J regular neighborhoods and identifiable law charts

IC301-IC307 prove actual C2 continuation through zero. The first J derivative of the density has operator norm at most 2M_B. Choose delta_B=min(J_*/2,eta_B/(4M_B)) when M_B>0, or J_*/2 otherwise. The density increment is at most 2M_BJ, so 0<J<delta_B has eigenvalues at least eta_B/2. Enlarge the h interval when choosing constants to obtain an open strip around the requested compact interval. A prescribed finite hierarchy takes the minimum of its positive deltas and floors. This intersection is nonempty, with no claim for all unbounded depths.

Identifiable coordinates can be exhibited from the actual law:

    Phi_B(h,J)=(E Y_(0,1), Cov(Y_(0,1),Y_(0,2))).

At zero its Jacobian is upper triangular with positive diagonal B a v and b^2a^2v^2 by IC308. It is C3 as a function of actual finite marginals. Continuity on an outer compact strip gives a positive neighborhood where its first h derivative and determinant remain positive; their zero minima and compact derivative bounds from IC303 quantify this neighborhood. Intersect with the density-floor neighborhood.

For local injectivity, multiply the observable values by the inverse Jacobian at the chosen point. On a small convex ball its derivative differs from identity by less than 1/2. Segment integration gives a distance lower bound of one half. For a smaller value ball, x -> x+y-Phi(x) is a contraction mapping a closed ball into itself; its Cauchy Picard sequence provides a local inverse. Taylor remainder and repeated differentiation give that inverse through order three. Thus these are actual identifiable statistical coordinates, not a transverse slice of a non-descending semimetric.

A single injective strip around a compact h interval is also possible. Take an inner and larger outer h strip. At J=0 the first observable strictly increases with h, giving a positive value margin between outer endpoints and inner values. Small J, quantified by the first-derivative bound, preserves the margin. Each first-observable level from the inner strip then has a unique h for all intermediate J in the outer strip. Along this level curve the second observable has derivative det(D Phi)/partial_h Phi_1>0. Equal observable pairs at distinct parameters are impossible. Those positive margins and compact derivative bounds quantify a smaller strip. Finite hierarchies again take finite intersections; no regular leaf-space or quotient theorem is assumed.

## IC310. Continuous density curvature and sign convention

On certified charts g=mathcal I_B is C2 with a positive determinant floor on compact subsets, so its inverse is C2. Define

    Gamma^l_(ij)=0.5 g^(lm)(partial_i g_(mj)+partial_j g_(mi)-partial_m g_(ij)).

Use R(X,Y)Z=nabla_X nabla_Y Z-nabla_Y nabla_X Z-nabla_[X,Y]Z and

    R^l_(k i j)=partial_i Gamma^l_(jk)-partial_j Gamma^l_(ik)
               +Gamma^l_(im)Gamma^m_(jk)-Gamma^l_(jm)Gamma^m_(ik).

The sectional curvature is K=g_(1l)R^l_(2 1 2)/det(g); scalar curvature is 2K. This is sphere-positive: on the unit sphere R(X,Y)Z=<Z,Y>X-<Z,X>Y gives K=1 for an orthonormal pair. Gamma is C1 and curvature continuous. The identity partial g^(-1)=-g^(-1)(partial g)g^(-1) is used only after the floor.

These are statistical parameter curvatures, not gauge or base curvature. Density decay does not imply curvature decay, since inverses can grow. Information contraction and its a^2 volume factor imply neither PSD derivative inequalities nor curvature monotonicity. No scalar-curvature VFE term is added.

## IC311. Complete finite third jets and metric derivatives

For a fixed finite normalized natural exponential source put a_i=T_i-E T_i, g_ij=Cov(T_i,T_j), and let kappa_ijk be the third cumulant of its complete two statistics. All free fields and touching/crossing plaques are retained. Finite normalized differentiation gives

    p_i=p a_i,
    p_ij=p(a_i a_j-g_ij),
    p_ijk=p[a_i a_j a_k-g_ij a_k-g_ik a_j-g_jk a_i-kappa_ijk].

All positive-order sums vanish and derivative tensors are symmetric. Rational b,c yield rational masses, cumulants and natural jets even though atanh coordinates may be irrational. A fixed channel projects every jet by the same full sum, q_alpha(y)=sum_x K(y|x)p_alpha(x), on fixed reachable positive support.

For fixed positive selected likelihood set u_alpha=ell p_alpha and Z_alpha=sum_x u_alpha. Differentiating u=Zq gives

    q_0=u_0/Z_0,
    q_alpha=[u_alpha-sum_(0<beta<=alpha)
       binom(alpha,beta)Z_beta q_(alpha-beta)]/Z_0.

This retains every evidence derivative. Re-centering only the first score does not yield higher posterior jets. Moving channels and likelihoods require their own product-rule jets.

Let h1,h2,h3 denote successive b derivatives of atanh b, and J1,J2,J3 the analogous c derivatives. Then

    h1=1/(1-b^2), h2=2b/(1-b^2)^2,
    h3=2(1+3b^2)/(1-b^2)^3,
    p_bb=p_hh*h1^2+p_h*h2,
    p_bbb=p_hhh*h1^3+3p_hh*h1*h2+p_h*h3,
    p_bbc=p_hhJ*h1^2*J1+p_hJ*h2*J1.

The exchanged mixed identities complete the chain rule. A first Jacobian alone is insufficient for higher jets.

For an actual positive two-parameter third jet define N=p_i p_j, N_k=p_ik p_j+p_i p_jk and N_kl=p_ikl p_j+p_ik p_jl+p_il p_jk+p_i p_jkl. Then

    g_ij=sum_x N/p,
    partial_k g_ij=sum_x[N_k/p-Np_k/p^2],
    partial_kl g_ij=sum_x[N_kl/p
       -(N_kp_l+N_lp_k+Np_kl)/p^2+2Np_kp_l/p^3].

Only third mass derivatives are needed. The two-dimensional tests g_11>0 and det(g)>0 precede inversion. The declared IC310 formula then yields exact finite connection/curvature. Chart comparisons retain all higher chain terms.

A generic jet record requires positive masses, normalization, tensor symmetry and actual smooth-family realizability. If a normalized symmetric Taylor-polynomial family is intentionally admitted, its positive zeroth masses give positivity near the base point and zero derivative sums preserve normalization. That local family must be declared, not silently attributed to the spatial source.

No current source or primitive was inspected in this initial pass. Mature review must check suitable existing exact-engine reuse, complete factor/normalizer coverage, explicit larger enumeration access, and singular inverse rejection. A finite packet can check polynomial derivatives, fixed-channel towers, quotient jets and coordinate-consistent curvature, but cannot prove the infinite C3/C2 or density floor.

## IC312. Attacks and pending obligations

Pairwise decay without group decoupling does not prove fourth-cumulant summability. Source-anchor separation must pay support offsets and use whole blocks. Repeated tuples and crossing factors cannot be dropped. Actual cumulants and repeated FTC, not differentiated envelopes, establish higher response. Vacuum-future and absent-future rows differ. Varying-law expectations need the covariance and third-cumulant terms in IC306. A finite law's rank alone does not imply a density floor: IC308 instead uses extensive independent product-control statistics. Signed-J continuation is proved first. Finite-hierarchy minima do not imply a single positive-J chart for every depth. A semimetric is not inverted before a floor and does not automatically descend to a quotient.

This is a full candidate reconstruction with loose explicit constants. Its source counts, support conditions, cut argument, actual-density floor and curvature convention remain available for challenge. No counterexample within these premises was constructed. Remaining work is to compare mature author/root statements and implementation only after root authorizes access, and inspect real retained evidence when provided. No new draft/source access occurs before that authorization, and no ledger state is assigned.


## Mature independent reconstruction, revision 2

The preceding IC301-IC312 record was persisted before access to current author, root, worker or intake constructions. Its exact original Markdown and proposal JSON were then copied to initial-independent-proof-check.md and initial-proof-check-proposals.json before the authorized second-stage read. Their hashes remain d36e4a3314b2d4020c849aad3c85cbcd09cb762e066d0e5186913f99cb5daf1b and 4e97d2189c22248e96167fe96e84ff4f3909728903110d2778ceb3a1d11c11f2. This stage has read the full HR and DG constructions, their author-interface note, and the new finite source, tests and runner. It is a separate reconstruction by an agent sharing model family, inherited context and filesystem with the authors, not an independent institution, formal proof checker, numerical reproduction or ledger adjudication. No theorem here is inferred from agreement or test outcomes.

The original reconstruction gives its own larger constants and two-observable extensive covariance certificate. The author's sharper constants and conditional-past rank certificate need their own checks; numerical comparisons between those constants would not establish either proof. The checks below reproduce the load-bearing inequalities directly. No concrete mathematical defect remains identified in the checked mature constructions. This is conditional on the restored UC/UP/FR/GX inputs and all fixed support, reference, geometry and parameter hypotheses.

## MC01: HR01-HR08 group decoupling, tuple counts and actual C3

The root of the source graph is the entire target anchor set, with root-to-source edge weight the minimum distance to that set. Contracting this root need not create a metric. The argument instead follows the selected tree path from the root: the sum of its actual inter-source distances plus its initial root distance bounds the final source's distance to the target. At most r edges occur, so the longest selected edge is at least M/r. Minimality of a spanning tree ensures that deleting this edge leaves no shorter cross-cut edge, including a root edge. A plaquette source can enlarge an anchor support by one in either group; the separation after expansion is therefore at least M/r-2. For M>=4r the integer buffer floor(M/r)-3 is admissible. Coincident labeled sources remain in the graph and never license dividing ordered tuple counts by a factorial.

Conditioning on the actual exterior of a whole-block buffer gives the joint-versus-product comparison. Boundary sites inherited from an irregular original finite volume have identical fixed values in the compared kernels and contribute zero discrepancy. Newly exposed sites are at least the claimed buffer distance from the target. Thus the same UC estimate holds without requiring rectangular original finite volumes. The total-variation convention contributes factor two when bounding the change of a bounded expectation. For a partition with j blocks the moment product has j telescoping terms and cumulant coefficient (j-1)!, hence the bound 2 sum_pi j!. For two, three and four cumulant arguments these constants are 6,26,150; the corresponding absolute cumulant sums are 2,6,26. Independence of the two nonempty groups factors the multivariate generating function, so its mixed logarithmic coefficient vanishes. These facts establish HR03 directly, not by a pairwise-correlation surrogate.

For large M the buffer floor(M/r)-3 loses at most four units in the exponential and its polynomial factor is at most M+1. For M<4r the absolute cumulant bound is dominated by exp(4 tau) times exp(-tau M/r). Thus L_r(a)=exp(4 tau)[K_(r+1)+Q_(r+1)C(a+4r)] works in both cases. A fixed derivative direction has at most 2B^2 source choices per anchor, since h has two edge orientations and J has one plaquette basepoint. Anchors of distance at most M from a set of size a number at most a(2M+1)^2. The ordered r-tuple count is therefore at most (8a)^r B^(2r)(M+1)^(2r). Multiplication by the cumulant estimate gives the HR06 power 2r+1. The elementary bound sum_(m>=0)(m+1)^p x^m <= p!/(1-x)^(p+1), obtained by comparison with p! binomial(m+p,p), proves S_r(a), including its factorial and denominator exponents. Tail shifting uses (L+2+n) <= (L+2)(n+1), so its stated exponential and polynomial tail follow.

Finite normalized exponential differentiation gives the cumulant with the total statistic. Expanding that statistic gives precisely these ordered tuples, including repeated and crossing sources. For a fixed finite tuple, all-pattern joint laws converge by the restored constrained-law construction; the displayed summable majorant then permits truncating tuples uniformly before taking volume limits. Differentiating a moving cylinder adds the usual binomial choice of derivatives falling on that cylinder. Repeated coordinate fundamental theorems of calculus identify the uniform derivative limits with the derivatives of the limiting actual law. This proves C3, rather than assuming differentiability of a boundary-limit oracle. At J=0 the author's argument uses the uniform one-sided finite FTC on [0,J_*]. The independent signed-J route IC301 is an alternative sufficient continuation, not an extra hypothesis silently imposed on HR.

## MC02: HR09-HR13 actual depth decay and conditional log jets

Conditional on all other blocks, a free straight path has independent edge signs. Every touching plaquette contains at most one edge of that path, so its conditional mean is G=product_e tanh(h+J a_e), with abs(a_e)<=2. Each ordinary derivative of order n<=3 costs at most g_n B^n and can remove at most n powers of rho, giving abs(partial^n G)<=g_n B^n rho^(B-n), g_n=2^n n!. This remains an upper bound when B<n. G is supported in the fixed nine-anchor neighborhood, independently of B. Apply the moving-observable response formula to E G: the term with b derivatives on G and n-b sources is bounded using S_(n-b)(9). Its B exponent is b+2(n-b)+2 <=2n+2 and rho^(B-b)<=rho^(B-n). Summing the binomial choices gives exactly D_n and M_n=D_n B^(2n+2)rho^(B-n). This establishes actual derivative decay; it does not differentiate abs(EY)<=rho^B.

For the two-pattern spatial comparison split source tuples at distance L=floor(R/2)-1. Near tuples use the finite joint TV difference on the target plus source supports, producing N_n(2L+1)^(2n)(R-L)exp[-tau(R-L)]. Far tuples use the two HR06 tails. Since R-L>=R/2 and L+1>=R/2-1/2, the combined large-radius bound has coefficient N_n+2exp[tau/(2n)]S_n(1) and decay exp[-tau R/(2n)]. At R=0,1 the separate 2M_n cap is valid. This is the required uniform derivative modulus, including finite-oracle tails.

A Bernoulli conditional has mass (1+s m)/2 and denominator at least d=1-rho. Direct logarithmic differentiation gives m'/d, m''/d+(m')^2/d^2, and m'''/d+3m'm''/d^2+2(m')^3/d^3 as absolute bounds. A two-sign cell uses two successive conditionals, hence 2A_n for each log mass and 4A_n for log odds. Applying product and reciprocal telescoping gives T_1,T_2,T_3 with the displayed coefficients 2,3,6,6,6; each inverse-power difference contributes its power times the mean difference. Replacing M_j by the explicit finite U_j uses sum_(B>=1)B^(2j+2)rho^B <=(2j+2)!/(1-rho)^(2j+3). No lower-order term is omitted in a mixed derivative. Positivity of the successive rows proves positivity and C3 of every actual finite cylinder, uniformly over prescribed patterns.

## MC03: complete canonical interaction and DG01 norm

For every shell the differentiated canonical potential has both its amplitude bound 2F_n(B) and its spatial bound 4T_n(r-1). For r>=3, replacing each M_j by U_j and each V_j by its large-radius coefficient Z_j gives P_n after enlarging the smaller B powers, radius degrees and faster exponents to the order-n envelope. For r=1,2, divide 2F_n<=8E_n B^(4n)rho^(B-n) by B^(2n+2) and bound B^(2n-2)rho^B by its positive series, at most (2n-2)!/(1-rho)^(2n-1). The extra exp[tau/(2n)] in H_n covers r=1 and cancels the r=2 exponential. Thus small radii are not omitted from the infinite norm.

The geometric mean of the two valid bounds is sqrt(2F_nH_n) B^(n+1)r^(n+1/2)exp[-tau(r-1)/(4n)]. A support in Q_r has diameter at most 2r and at most (2r+1)^2 translates containing the origin. With the common lambda=tau/48 the remaining exponent is a_n=tau/(4n)-tau/24, strictly positive for n=1,2,3. Replacing r^(n+1/2) by r^(n+1), and (2r+1)^2 by 9r^2, yields the explicit series bound 9(n+3)!/(1-exp(-a_n))^(n+4). The amplitude is B^(3n+1)rho^((B-n)/2), which tends to zero for integer B tending to infinity. The value bound uses the prior complete UP construction with this smaller admitted lambda. All translates and all shells remain in the norm. Repeated Banach-space FTC therefore proves actual C3 of the full interaction and identifies all its derivatives. This is a statement about the actual canonical parameterized orbit, not a differentiable RG map on every arbitrary interaction.

## MC04: DG02-DG05 actual marginal Fisher-density derivatives

Write l_i, l_ij, l_ijk for the actual conditional log-mass jets. Differentiating p l_i l_j twice gives ten expanded monomials: one bounded by L_1^4, five by L_1^2 L_2, two by L_1 L_3, and two by L_2^2. This recovers E_B. Comparing two such expressions telescopes at most five factors in each of ten monomials across four cell states, so 200 H_B^4 times V_0+2T_1+2T_2+2T_3 is a valid modulus. The atom mass difference is bounded by V_0 by telescoping its two Bernoulli factors. The cap 2E_B is independent of that modulus. The probability weight p is differentiated in every expression; it is not held fixed.

For a parameter-dependent local observable f on Q_N, source differentiation gives partial_i E f = E partial_i f + sum cov(f,T_i), and partial_ij E f = E partial_ij f + sum cov(partial_i f,T_j)+sum cov(partial_j f,T_i)+sum kappa(f,T_i,T_j). The sums are absolutely bounded by HR06. Therefore W_B(N)=1+2S_1(a_N)B^4+S_2(a_N)B^6, a_N=(2N+1)^2, bounds all derivatives through order two. Its growth is polynomial in N, at most degree six, since S_r(a) has degree r+1. Multiplication by the spatial Fisher modulus, a degree-seven polynomial times an exponential, is summable.

For any fixed revealed past set S, expand J_S into differences of J_(S intersect Q_N). Two revealed sets agreeing on Q_R give exactly equal functions through shell R, with equal derivatives, because they use the same observed signs on the common full configuration. The expectations use the same unconstrained full law throughout. The C2 difference is bounded by epsilon_B(R)=2 sum_(N>R) W_B(N)omega_B(N-1). This handles the varying background law and arbitrary finite past shapes. It does not replace the missing future by the vacuum used in the canonical interaction.

For each finite square, the actual log score is the sum of its predictive conditional scores. A later score has zero conditional mean given its entire preceding finite past, so all matrix cross terms vanish before any differentiation. The resulting finite identity is C2 by the preceding weighted-shell argument. A radius-R bulk cell has the same revealed past as the infinite past inside Q_R. At most 4RL cells are outside the bulk, and each expectation-jet difference is at most 2Z_B. Thus every matrix entry and every derivative through order two has error at most epsilon_B(R)+8Z_B R/L. Taking L to infinity and then R proves actual compact-uniform C2 convergence of L^(-2) times the actual marginal Fisher. It includes source-response, conditional-row, finite-boundary and varying-law derivatives. It is not a limit of pressure Hessians or a derivative of an information inequality.


## MC05: HR14-HR16 and DG06 actual density rank and identifiable charts

The author uses a second rank certificate, distinct from the extensive-observable proof in IC308. At J=0 and a fixed full lexicographic past, the two outgoing target paths are unconstrained and independent. The centered contrast for one edge given its path parity s is a(s)=s b^(B-1)(1-b^2)/(1+s b^B). Its mean is zero and its variance is v_B=b^(2B-2)(1-b^2)^2/(1-b^(2B)). The h score of the target cell is B(a_1+a_2). Only one fine plaquette meets both outgoing target paths, at their common corner. Its other two edges belong to future blocks when B=1, or unused singleton blocks when B>1; they have mean b under the fixed past. Consequently its mixed contrast coefficient is b^2, independent of the past pattern. Every other incident plaquette meets at most one target path and contributes only a linear contrast. There are at most 2B such terms per path and each remaining conditional product has absolute value at most one. Thus s_J=b^2 a_1a_2+alpha_1 a_1+alpha_2 a_2 with abs(alpha_i)<=2B. Nonincident terms cancel in the centered target conditional score by independence, even when they depend on already constrained blocks.

The three centered functions a_1,a_2,a_1a_2 are pairwise orthogonal. Direct expansion gives g_hh=2B^2 v_B, g_hJ=Bv_B(alpha_1+alpha_2), and g_JJ=v_B(alpha_1^2+alpha_2^2)+b^4v_B^2. Its determinant equals B^2v_B^2(alpha_1-alpha_2)^2+2B^2b^4v_B^3. The total-variance decomposition gives v_B=Var(E[z|Y])<=Var(z)=1-b^2<=1; its trace is at most 11B^2v_B. Therefore its least eigenvalue is at least (2/11)b^4v_B^2. On a compact b interval [b_-,b_+], dropping the denominator 1-b^(2B) only lowers v_B, giving eta_(B,0)=(2/11)b_-^(4B)(1-b_+^2)^4. This bound holds for every full past pattern; averaging yields the actual density floor rather than a fixed-vacuum surrogate.

Each cell score vector has norm at most 2sqrt(2)A_1 and its J derivative at most 2sqrt(2)A_2. Differentiating p ss^T contributes at most 16A_1^3 from the row weight and 16A_1 A_2 from the two score factors. Hence Q_B=16(A_1^3+A_1 A_2) controls the operator derivative of the conditional Fisher row uniformly over patterns. The strip width min(J_*/2,eta_(B,0)/(2Q_B)) preserves at least half the floor by the one-sided FTC. Averaging at the new parameter uses that pointwise floor directly and needs no assumption that the law's expectation is fixed. Finite intersections over explicitly chosen depths remain open and have a positive common minimum. No infinite-depth intersection or common inverse bound follows.

The added DG17 paragraph is necessary to identify the actual law locally, rather than just installing a metric on a possibly redundant parameter domain. By C2 convergence and the positive density floor, a sufficiently large actual finite square marginal has positive Fisher at each point of the regular region. Its Fisher matrix is Dp^T diag(1/p)Dp, so its atom Jacobian has rank two. Choose two atoms with an invertible minor and normalize their C3 probability map so its derivative at the point is the identity. On a small closed ball, the derivative differs from the identity by at most one half. Segment integration gives injectivity and inverse Lipschitz constant at most two. For targets in the half-radius ball, x -> x+y-F(x) is a contraction into the original ball, whose geometric Cauchy sequence constructs the unique inverse. The inverse Lipschitz bound and the first-order remainder give DG(y)=DF(G(y))^(-1); differentiating this identity twice gives a C3 inverse. Thus these two actual atom probabilities are local coordinates of the full family. The atom pair, square and radius may depend on the point and B. This agrees with, and does not weaken, the independent observable-map chart route in IC309.

## MC06: DG06-DG10 curvature and actual crossing-source control

The density is C2 and strictly positive on each certified regular region. Differentiating g g^-1=Id gives the inverse in C2; the Christoffel formula is C1 and the displayed Riemann tensor continuous. Torsion-free metric compatibility follows by the cyclic connection algebra. With R^l_(kij)=partial_i Gamma^l_jk-partial_j Gamma^l_ik+Gamma^l_im Gamma^m_jk-Gamma^l_jm Gamma^m_ik, the constant-curvature tensor is K(delta_li g_jk-delta_lj g_ik). Contracting R^i_(kij) gives positive Ricci and scalar 2K in dimension two. This confirms the sphere-positive sign. Actual normalized finite metrics L^(-2) I_(B,Lambda_L) converge in C2 and eventually have positive eigenvalue floors on each compact regular subchart. Continuity of inverse and the finite rational tensor formulas proves convergence of their connections and curvature at fixed B. The same statement for unnormalized finite Fisher matrices would have the wrong curvature scaling.

For the spatial finite control, four central-square free edges have one central and four crossing plaquettes. Four distinct outer parallel exterior edges can be chosen negative and every other required exterior edge positive, making each crossing character the negative of its incident free edge simultaneously. The actual exponential representative is exp[(h-J)sum z+J product z]. Put t=tanh(h-J), c=tanh J and D=1+c t^4. Summing the two unobserved square edges gives p(z_1,z_2)=(1+t z_1)(1+t z_2)(1+c t^2 z_1 z_2)/(4D). Its moments are M=t(1+c t^2)/D and V=t^2(1+c)/D. Direct differentiation gives M_t=(1+3ct^2-3ct^4-c^2t^6)/D^2, M_c=t^3(1-t^2)/D^2, V_t=2t(1+c)(1-ct^4)/D^2 and V_c=t^2(1-t^4)/D^2. Subtraction factors the determinant numerator as t^2(1-t^2)^2(1+ct^2)D, proving the stated positive determinant divided by D^3. This checks the claimed identity by algebra, not a symbolic or numerical run.

The three distinct category masses are p_++, p_-- and p_+-+p_-+. The transformation from (M,V) to the first two masses has determinant 1/4. The equal mixed-sign split is a fixed fair coin, so it preserves Fisher geometry. The coordinate Jacobian to (t,c) is positive both from (h,J), where its determinant is (1-t^2)(1-c^2), and from (b,c), where it is (1-c^2)/(1-bc)^2. The explicit inverse follows from M(1+t^2)=t(1+V), using the root t<1 and then c=(V-t^2)/(t^2(1-Vt^2)); its denominators and discriminant are positive near the prescribed fixture. The point t=1/5,c=1/20 indeed gives b=25/101. The square-root map sends a full three-category Fisher chart isometrically to the positive octant of the radius-two sphere. Its scalar is therefore 1/2 in both admitted charts. This control belongs to the actual all-touching finite field; it is not an isolated-square replacement or evidence of infinite-density rank by itself.

Constant multiplication of a metric by a positive scalar leaves its connection and one-up-index curvature unchanged and divides its scalar curvature by that scalar. Thus a density metric tending to zero with depth need not become flat. The rank-one form exp(2v)du^2 has a smooth radical foliation but does not descend under (u,v)->u, since its value on the lifted u direction varies along each v fiber. These explicit obstructions survive the new regular-chart construction outside the certified region. The normalized-joint VFE identity adds no Fisher-curvature penalty by itself; gauge, Fisher and base curvature retain distinct index spaces and model assumptions.

## MC07: FG01-FG06 finite source correspondence

The complete new source, test file and runner were read without importing or running them. The immutable jet order is all ten ordinary two-parameter multi-indices through total degree three. Derivative rows are signed mass derivatives with higher-order row sums zero. For producer-valid smooth families, these are the required normalization constraints; the constructor does not certify an arbitrary hand-supplied array as a particular spatial family. A spatial wrapper preserves state order, law masses and the existing normalized-counting reference. Larger exact enumeration remains opt-in through max_edges, and no larger instance is implied by the six-edge packet.

spatial_probability_jet uses the existing natural scores T-E_(point)T as fixed statistics of a local exponential tilt. Freezing those subtracted constants is correct: it changes only a parameter-dependent scalar factor of the raw weights. _normalize solves A_alpha=sum_(beta<=alpha) binom(alpha,beta) Z_beta p_(alpha-beta) in increasing total degree. Every remainder has already been constructed, including beta=alpha, whose remainder is order zero. The positive order-zero total is checked. The auxiliary normalizer is explicitly distinct from the original raw field partition. This establishes FG01 under the unchanged spatial producer's complete factor and boundary premises.

_bc_rows includes h'=1/d, h''=2b/d^2 and h'''=2(1+3b^2)/d^3, and the coefficient 3h'h''=6b/d^3 of the second natural derivative in the third b derivative. The same table is applied independently to c, so all mixed terms and no spurious mixed coordinate derivatives occur. push_probability_jet applies the same fixed sparse channel to signed derivative rows; it never normalizes those rows as probability laws. Explicit unreachable columns remain zero at every order, and the complete target label order is retained. project_spatial_jet obtains the existing disjoint path channel and pushes all orders through it. Fixed channels compose by associativity of finite sums. This proves FG02-FG03 for the declared parameter-independent maps, not moving channels.

For each selected binary observation, selected_binary_posterior_jet multiplies every row by the same positive fixed likelihood and uses the complete normalization recurrence. The summed raw rows are the true evidence derivatives. Summing the two products Z_o p_o reconstructs the entire source jet with all binomial coefficients; only summing posterior derivatives alone would be wrong. Observation labels, aligned full carrier and both positive likelihoods are admitted explicitly. This establishes FG04, subject to the family-level fixed-likelihood premise that one table cannot mechanically verify.

fisher_geometry rejects any nonpositive mass before division and then checks symmetry, g00>0 and det(g)>0 before exact inversion. The score Gram is the actual Fisher since every first derivative row sums to zero. For A=p_i p_j, the implemented first derivative is A_a/p-A p_a/p^2. The second is A_ab/p-(A_a p_b+A_b p_a+A p_ab)/p^2+2A p_a p_b/p^3, with all four terms of A_ab present. The code's axes dg[a][i][j] and ddg[a][b][i][j] match these derivatives. Inverse differentiation, Gamma differentiation, Riemann[l][k][i][j], Ricci[k][j] and scalar contractions then match MC06 exactly. These are conditional finite algorithm identities FG05-FG06, not an inference from test agreement. No pseudoinverse, rank quotient, density-limit estimator or regularity-radius certificate is produced.

The 65536-bit claim applies to exact adapter inputs and stored/generated tensors, including the intermediate inverse and Gamma derivatives. It is not a bound on every arithmetic intermediate inside old Gram, channel and inverse primitives. A resource rejection is permitted and does not falsify the mathematical family. The source-injected interpreter route is a compatibility test of these files, not a claim that the unchanged project's Python>=3.14 requirement was altered.

## MC08: prepared packet distinctions and mature scope

The test source reconstructs full bivariate factor polynomials, differentiates coefficients, and uses set partitions for reciprocal-normalizer derivatives plus subset Leibniz. This differs from the production increasing-degree recurrence. Natural-chart comparison uses the inverse operator (1-b^2)D_b with its own higher derivatives. The suite checks all ten rows, complete touching/crossing geometry, fixed-channel zero columns and composition, full evidence reconstruction, exact simplex g/dg/ddg/inverse/Gamma/full Riemann/Ricci/scalar, an actual crossing-square sufficient collapse, and a flat product control. Binary and erasure models are legitimate rank-loss refusals. The exact resource input is a valid small-dimensional probability law beyond the scalar guard, not a corrupted artifact.

The runner selects only the new file, injects the two source paths and asserts the new module path, disables conftest/plugins/cache, and binds source, tests, command, runtime, environment, contract and raw artifacts. Its static prediction is not an observed test count. Later raw JUnit inspection will be recorded separately; no test or scientific routine was executed by this lane. A passing packet cannot replace any HR, DG, all-pattern, all-shell, actual-density or identifiable-chart derivation above.

The author-interface note is an author check of its own HR handoff, not another independent proof of HR. Its two reported explication repairs are preserved: removal of a prohibited spacing macro and replacement of a named local inverse theorem by the explicit crossing-square inverse. The root separately added DG17 after the initial independent record, making actual-law local coordinates explicit. Current readback includes that paragraph and its inverse-Lipschitz-to-C3 argument. No scientific source or test changed in those documentary repairs. There is no unqualified extension to arbitrary moving maps, boundary-dependent supports, unbounded-depth regularity, curvature monotonicity, gauge/base curvature identification, or an automatic curvature term in VFE.


## MC09: current FG05 repair and sole numerical artifact readback

Root reported the sustained FG05-REGULAR-PATH scope finding after the initial source-correspondence read. The original worker claim's positive-carrier premise alone did not describe the executable return path: fisher_geometry checks regular principal minors and computes the inverse before dg/ddg. A positive binary family is therefore refused before those arrays are returned, although the mathematical formulas still define its singular Fisher derivatives. The current worker claim and report now explicitly require regular admission and successful completion for the public return claim, while retaining the generally valid algebraic formulas. MC07's finite evaluator identity is read with that same regular-success premise. This documentation repair changes no code, test, formula or result and causes no rerun. Current worker report hash is 5c1e1f78d566dd86d7031c7578854dcb19d5fc1057de752b84dee75c716ab78b; current worker proposal hash is 3075afc0f3e73ad1e7c15c214494976aa6aa351f74b94b35b15e248b5ce3ed4c.

The sole retained packet is fisher-geometry-tests-20260909T142501326646Z under docs/verification/2026-09-09-c3-fisher-geometry. I read its raw XML, command receipt, result and log directly without executing the tests or scientific source. The XML contains 29 distinct (classname,name) cases and zero failure, error or skipped elements. The suite time is 1.955 seconds. The result's outer runner time is 2.6970090999966487 seconds and return code zero. The two durations measure different scopes and are not substituted for one another. The actual node list is only the new test file. All 23 source/input/test/project bindings match current bytes; the contract, new source and runner match their reported hashes. The command is the isolated, no-bytecode C:/anaconda/python.exe source-injected route with conftest, plugin autoload and pytest cache disabled. The runtime reports Python 3.12.7 on Windows 10. This is that bounded compatibility observation, not a package-support claim overriding the unchanged Python>=3.14 project requirement.

The raw artifact hashes are: command receipt 9ce8be9f261be96584f22f25613e3db71b472efc06cbc32fd640029bc5a0739e; result 591a857fe57dcb42c09c8cc9b8b853fd1b80a25d370a24ed06aa8d7ff0f5cbfe; XML 8d4526b8f12e54f014e93542a6329ef37aab8d6703cd45bdf6d75a53c4eebd8a; log 78a0223dd698707b1a2c3db9d1657f0a400eac9d32674a0abd01659d027a7553. Parsed CONFIG digest is 0df72b415167c5c3597e42c05dbf73bd522aa7a64944875adf48012bfe0cf9c0 and command-vector digest f72395309a15b07120fb11b02a8846b0b2ab75011a0e9af97f628f22021f953d. The new source, test and driver still have their frozen 95037e..., 6e6a3a... and 4d4d19... hashes recorded in the proposal bindings.

FGN01 is strictly a numerical observation at the recorded finite fixtures. No spatial law has more than six free edges. No second execution, longer field enumeration, GPU, older test, prior producer or prohibited tamper check was run by this lane. Parsing the raw receipts and checking current hashes are read-only provenance observations, not a reproduction of numerical science. HR and DG remain supported by the derivations; the finite algorithms remain conditional source-to-formula identities; the 29 cases remain a separate observation.


## MC10: final full-target interface and freeze

After the root replaced its scaffolds, I read the full current construction-or-strongest-theorem.md, final-report.md, counterexample-register.md and human report docs/reports/2026-09-09-c3-fisher-geometry-rg.md. They preserve the complete frozen target: actual C3 every-pattern and full-interaction response, a common exponentially weighted norm with depth decay, actual changing-law C2 square-marginal Fisher-density convergence, positive-J regular regions for each fixed B and finite hierarchy, and actual identifiable local law coordinates. The regular finite adapter and separate 29-case observation are not substituted for those infinite derivations. The terminal release decision is delegated to release.json rather than preassigned by this checker, and the full RG program remains active.

The reports retain the sphere-positive sign, fixed-B volume normalization, finite-hierarchy restriction, explicit FG05 regular-success return premise, zero-column preservation, unchanged package/runtime distinction, guard limits, and gauge/Fisher/base curvature distinction. The next-full-rg-operator note is linked only as a future proposal; it was not read or used as evidence for this target. No open-neighborhood operator, critical/continuum limit, universality, unbounded-depth inverse or curvature limit, physical clock, or new curvature penalty is claimed. The report's actual test totals and timings agree with the raw readback in MC09.

There is no remaining concrete mathematical, source-correspondence or final-interface finding in this lane. The qualified 42-claim mapping is in coverage-review.md and coverage-proposals.json, with literal proof sections, individual dependencies and falsifier responses. Initial snapshots remain byte-identical. Only the four owned mature reconstruction/coverage files were updated; no source, tests, other lane file, old artifact or ledger state was changed, and no tests or science were run. These records are frozen for the parent's independent evidence intake rather than assigning closure themselves.


## MC11: sustained contrast-bound finding and final correction

After reading the mature record, root identified MC05-CONTRAST-BOUND: the sentence claiming abs(a)<=1 was false for the centered contrast a(s)=E[z|Y=s]-b. At B=1 and s=-1, a(s)=-1-b has magnitude greater than one for b>0. This is an explicit counterexample to that intermediate pointwise claim. It is not a counterexample to the variance, determinant or eigenvalue bounds used by the construction.

The corrected MC05 argument uses v_B=Var(E[z|Y]). Expanding z-Ez=(z-E[z|Y])+(E[z|Y]-Ez) and taking squares, the cross term is zero by conditional centering. Hence Var(z)=E Var(z|Y)+Var(E[z|Y]) and v_B<=1-b^2<=1. This directly supplies the same trace upper bound 11B^2v_B. HR14 already used this correct total-variance argument. No HR/DG theorem, constant, scientific source, test or numerical receipt changes. The false mature sentence was replaced, while this counterexample and repair are preserved in the owned proposal/coverage records and the root's updated counterexample register. Initial independent snapshots remain unchanged. This final documentary correction required no further execution or proof investigation.
