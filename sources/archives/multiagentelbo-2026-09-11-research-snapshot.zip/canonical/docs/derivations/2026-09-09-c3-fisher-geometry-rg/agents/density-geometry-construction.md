<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753","target_digest":"aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753"} -->

# Complete higher interaction response and actual Fisher-density geometry

Date: 2026-09-09. This is the root's mathematical construction, not independent reconstruction or an execution claim. It uses the precise all-pattern, whole-block hypotheses and constants of [HR01–17](higher-response-construction.md), and the delivered UC/UP/FR/GX constructions under their actual parameter domains. It does not import an analyticity theorem from the literature. The governing source is the unchanged SPEC, SHA256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. Each assertion below is conditional on those explicitly cited premises and has a direct derivation.

## DG01. One norm for the complete interaction derivatives

Fix the enlarged compact natural-parameter rectangle and constants of HR01. In particular rho in (0,1), d=1-rho and tau>0 are fixed independently of B. The canonical support A_(x,r), potential Phi_[A_(x,r)], vacuum and lexicographic order are exactly UP02. Every site has two paths; the canonical exterior prescribes the revealed past and fixes the future to the vacuum. This is distinct from the future-absent predictive row used below.

For a multi-index alpha of order n=1,2,3, HR12 gives a singleton derivative bound
\[
F_n(B)=4A_n(B)\le 4E_n B^{4n}\rho^{B-n}.
\]
For r>=1 the actual derivative of the r-th shell is bounded by
\[
\min\{2F_n(B),4T_n(B,r-1)\}.
\]
Both functions being subtracted are actual C3 by HR08–12. Thus the expression is a derivative bound, not differentiation of an old variation inequality.

Here are explicit common constants if a simpler envelope is desired. For n=1,2,3 let
\[
Z_n=N_n+2e^{\tau/(2n)}S_n(1),\qquad Z_0=2C.
\]
Retain U_j from HR13. Define
\[
P_1=Z_1/d+U_1Z_0/d^2,
\]
\[
P_2=Z_2/d+(U_2Z_0+2U_1Z_1)/d^2+2U_1^2Z_0/d^3,
\]
\[
P_3=Z_3/d+(U_3Z_0+3U_2Z_1+3U_1Z_2)/d^2
 +(6U_2U_1Z_0+6U_1^2Z_1)/d^3+6U_1^3Z_0/d^4.
\]
For R>=2, HR10 and direct substitution in HR13 imply
\[
T_n(B,R)\le P_n B^{2n+2}(R+1)^{2n+1}e^{-\tau R/(2n)}.
\]
All lower-order factors are enlarged to the n-th order polynomial and exponent, which only increases the bound for B>=1 and R>=2. For n=1,2,3 choose
\[
H_n=4P_n+8E_n\rho^{-n}(2n-2)!/(1-\rho)^{2n-1}e^{\tau/(2n)}.
\]
The factorial term also covers n=1 with 0!=1. Since B^{2n-2}rho^B is at most its convergent sum and that sum is at most (2n-2)!/(1-rho)^{2n-1}, the small radii r=1,2 are covered by the 2F_n bound. Consequently at every r>=1,
\[
4T_n(B,r-1)\ \text{or its valid cap}\ \le
 H_n B^{2n+2}r^{2n+1}e^{-\tau(r-1)/(2n)}.
\]
For values n=0, UP01–02 apply with the current uniform comparison tau,C and m0=d^2/4:
\[
F_0(B)=A_0\rho^B,\quad A_0=4/(1-\rho^2),\quad
\|\Phi_{A_{x,r}}\|\le\min(2F_0(B),D_0B^2 r e^{-\tau r}),\quad D_0=2C/m_0.
\]

Set the single norm parameter lambda=tau/48. Counting at most (2r+1)^2 translates containing zero and using diam(A_(x,r))<=2r gives, for n>=1,
\[
\|\partial^\alpha\Phi^{(B)}\|_\lambda
\le F_n(B)+\sqrt{2F_n(B)H_n}B^{n+1}e^{\tau/(4n)}
 \sum_{r\ge1}(2r+1)^2 r^{n+1}e^{-a_n r},
\quad a_n=\tau/(4n)-2\lambda>0.
\]
The exponent r^{n+1} bounds r^{n+1/2}. The sum is explicit, finite and independent of B. For example, with x_n=e^{-a_n}, it is bounded by 9(n+3)!/(1-x_n)^{n+4}, since (2r+1)^2<=9r^2 for r>=1 and the geometric power-series coefficient estimate in HR06 applies. This bound decays as a compact-only constant times B^{3n+1}rho^{(B-n)/2}, plus F_n(B). The value bound follows identically with sqrt(2A0D0)B rho^(B/2) and the series sum (2r+1)^2r exp[-(tau/2-2lambda)r]. Thus orders zero through three decay to zero in the same exponential norm, uniformly on the original compact K and over all B.

The displayed positive tails after r>N are also uniform compact majorants. For any fixed B the finite-shell map is C3 into this normed interaction space, and its derivatives through order three converge uniformly by these tails. Apply coordinate FTC successively in this Banach space to the finite-shell maps and pass the uniformly convergent derivatives under each integral. This proves actual C3 of the complete canonical interaction, with exactly the displayed derivatives. No shell has been dropped, and no RG operator on an open neighborhood of arbitrary interactions has been constructed.

## DG02. C2 row-Fisher observables and a counted continuity modulus

Let S be any subset of the lexicographic past of zero, finite or infinite. For a full coarse configuration y, prescribe precisely y on S, leave all future paths absent, and define the four-state actual predictive row p_S(g,s;y). Let l=log p_S and l_i,l_ij,l_ijk be its actual natural derivatives. HR12 gives |l_(alpha)|<=2A_|alpha| for orders one through three, uniformly in S,y. Define the row Fisher observable
\[
J_{S,ij}(g,y)=\sum_{s\in\{-1,+1\}^2}p_S(g,s;y)l_i(g,s;y)l_j(g,s;y).
\]
It depends only on y restricted to S, although the prescribed law integrates the remaining fine and coarse coordinates. Actual C3 positivity makes it actual C2. Writing subscripts after a comma for differentiating the parameter-dependent observable while holding y fixed,
\[
J_{S,ij,k}=\sum_s p_S(l_k l_i l_j+l_{ik}l_j+l_i l_{jk}),
\]
\[
J_{S,ij,kt}=\sum_s p_S[
(l_{kt}+l_k l_t)l_i l_j+
l_k(l_{it}l_j+l_i l_{jt})+
l_t(l_{ik}l_j+l_i l_{jk})+
l_{ikt}l_j+l_{ik}l_{jt}+l_{it}l_{jk}+l_i l_{jkt}].
\]
These formulas explicitly differentiate the row probabilities. Put L_i=2A_i and
\[
E_B=\max\{L_1^2,L_1^3+2L_1L_2,
L_1^4+5L_1^2L_2+2L_1L_3+2L_2^2\}.
\]
Then every matrix entry and each of its derivatives through order two has absolute value at most E_B.

If two past prescriptions agree through Q_R, including which coordinates are absent, their four-state probabilities differ by at most V_0(B,R). Indeed reveal the two parities; each Bernoulli factor changes by at most V_0/2, and telescoping the product gives V_0. Their log jets of orders one through three differ by at most 2T_n. Define
\[
H_B=\max(1,L_1,L_2,L_3),\quad
\omega_B(R)=\min\{2E_B,200H_B^4[V_0(B,R)+2T_1(B,R)+2T_2(B,R)+2T_3(B,R)]\}.
\]
Every entrywise derivative difference of J through order two is bounded by omega_B(R). To check the coefficient, the longest displayed derivative has ten expanded monomials, each containing p and at most four log derivatives. Telescope at most five factors for each of four states. Every remaining factor is at most H_B, p<=1, giving at most 200H_B^4 times the largest input discrepancy, which the bracket bounds. Lower orders have fewer factors. The 2E_B cap is valid separately.

The exact positive expression omega_B is adequate as a tail certificate. For each fixed B it is bounded at large R by a finite explicit constant times (R+1)^7 exp(-tau R/6), using HR10/13. Products involving M_j are constants at fixed B. No assertion here differentiates a scalar continuity bound; the formulas start with the actual row jets.

## DG03. Varying-expectation response on polynomially weighted shells

Expectations in this section use the original, unconstrained full fine Gibbs law mu_g. A coarse observable is pulled back along the fixed B-path map before applying the source formulas. If f_N(g,y) depends on coarse cells in Q_N, this pullback uses blocks with anchors in Q_N, at most a_N=(2N+1)^2 anchors. Define
\[
\|f_N\|_{2,K}=\max_{|\alpha|\le2}\sup_{g\in K,y}|\partial^\alpha f_N(g,y)|,\qquad
W_B(N)=1+2S_1(a_N)B^4+S_2(a_N)B^6.
\]
For any local C2 f_N, HR06–08 and HR07 give
\[
\max_{|\alpha|\le2}\sup_K|\partial^\alpha E_{\mu_g}f_N(g)|\le W_B(N)\|f_N\|_{2,K}.
\]
For example, the actual first derivative is E f_i plus the complete source covariance sum. The second is E f_ij plus the sums of cov(f_i,T_j), cov(f_j,T_i), and kappa(f,T_i,T_j). The binomial coefficient is two for a repeated direction; all mixed source choices and crossing terms are retained. First prove these formulas in finite whole-block volumes, use the HR06 tails and HR08 local convergence to pass each term uniformly, then apply FTC. The parameter-dependent observable and the full law both vary. Since S_1(a) is a polynomial in a of degree at most two and S_2(a) one of degree at most three, W_B(N) is polynomial in N.

Now suppose f=sum_(N>=0)d_N, where every d_N is local on Q_N and C2, and
\[
\sum_{N\ge0}W_B(N)\|d_N\|_{2,K}<\infty.
\]
Both the ordinary observable series and its first two pointwise derivatives converge uniformly, because W>=1. For finite sums the preceding expectation response is proved. Their expectation derivatives through order two are uniformly Cauchy under the displayed weighted sum. Repeated coordinate FTC therefore gives actual C2 of E_mu f and equality with the termwise response series. Absolute convergence justifies reordering shell and source sums. This is a direct sufficient quasilocal response theorem; there is no appeal to a formal derivative of an infinite conditional density or pressure.

## DG04. Uniform finite-past versus full-past C2 expectation

For arbitrary S define S_N=S intersect Q_N and f_N^S=J_(S_N), entrywise. This is local on Q_N and actual C2, because its only configuration argument is the finite prescribed past S_N. Put d_0^S=f_0^S and d_N^S=f_N^S-f_(N-1)^S for N>=1. The two prescriptions agree in Q_(N-1), so
\[
\|d_0^S\|_{2,K}\le E_B,\qquad
\|d_N^S\|_{2,K}\le\omega_B(N-1).
\]
Their uniform sum equals J_S, including all derivatives through order two, by DG02. Thus the single finite bound
\[
Z_B=W_B(0)E_B+\sum_{N\ge1}W_B(N)\omega_B(N-1)<\infty
\]
controls every entrywise C2 derivative of E_mu J_S, uniformly in S. The counted polynomial W times the degree-seven exponential tail proves convergence, with no restriction on the distant shape of S.

If S and S' agree inside Q_R as subsets of the past, then f_N^S=f_N^(S') as functions of y for every N<=R. For N>R apply the two tail estimates. It follows that
\[
\|E_\mu J_S-E_\mu J_{S'}\|_{C^2(K),\mathrm{entry}}
\le \epsilon_B(R):=2\sum_{N>R}W_B(N)\omega_B(N-1),
\qquad \epsilon_B(R)\longrightarrow0.
\]
Agreement means the same subset is revealed with the same y coordinates; configurations remain the common variable of the expectation. The canonical vacuum-future pattern is never substituted. This common-prefix identity is the reason finite revealed pasts and the full past can be compared in the stronger response norm. A sup-norm comparison by itself would not have justified differentiating their expectations.

The infinite Fisher density already constructed in GX is I_B(g)=E_mu J_P(g), where P is the complete past. DG03–04 prove it is actual C2 on each compact K. This result uses a fixed full-law expectation throughout; it does not average under the S-conditioned measure after forming the row, which would change the target.

## DG05. Actual marginal Fisher matrices converge in C2

Let Lambda_L be a square of L^2 coarse cells, with its finite marginal inherited from the full law mu_B. Enumerate its cells in the fixed lexicographic order. The finite chain rule factors its positive C3 density into the actual predictive rows using S_(x,L)=Lambda_L intersect {y:y<x}. Their log scores add. Conditional centering makes distinct predictive score increments orthogonal: for the later increment, its conditional mean given all earlier cells is zero; the earlier increment is measurable there. Thus the exact finite Fisher identity is
\[
I_{B,\Lambda_L}(g)=\sum_{x\in\Lambda_L}E_{\mu_g}J_{S_{x,L}-x}(g,\mathrm{shift}_x y).
\]
Translation invariance removes the shift from the expectation. This is equality of actual C2 functions by DG03–04 and the finite C3 marginal. It is legitimate to differentiate this finite equality twice; no derivative of a PSD inequality is being used.

For L>=2R, all but at most 4RL cells are at least R from the square boundary. Their finite past and P have identical intersections with Q_R, so DG04 bounds each bulk entrywise C2 difference by epsilon_B(R). Both terms at any remaining boundary cell are bounded by Z_B. Therefore
\[
\|L^{-2}I_{B,\Lambda_L}-I_B\|_{C^2(K),\mathrm{entry}}
\le\epsilon_B(R)+8Z_B R/L.
\]
First send L to infinity at fixed R, then R to infinity. This proves precisely the actual square-marginal C2 limit in the original parameters, including the varying full-law expectation and all finite boundary score derivatives. Entrywise convergence implies any fixed two-dimensional tensor norm convergence. The estimates are for each fixed B and compact K; a uniform all-B curvature or inverse bound has not been introduced.

The finite fixed-channel identity and area factor from GX remain valid: I_(aB)<=a^2 I_B and I_B/B^2 contracts along integer divisibility. Differentiating these inequalities would not imply a positive-semidefinite first or second derivative. The present theorem supplies smoothness, not such an order assertion.

## DG06. Actual regular charts and continuous Levi-Civita curvature

HR14–16 reconstruct the actual full-past row scores at J=0, rather than differentiating a formula restricted to that boundary. For each fixed B and enlarged positive-h compact interval Iplus, the stated row floor eta_(0,B)>0 and continuation width delta_B>0 give
\[
I_B(h,J)\succeq \eta_{0,B}I/2,\qquad h\in Iplus,\quad 0<J<\delta_B.
\]
A prescribed finite list of depths takes finite positive minima of the widths and floors. On any compact subset of the corresponding open chart, DG05 gives a C2 positive-definite metric and a uniform inverse bound. This is an actual two-parameter chart in (h,J); no quotient or transverse slice is needed. A larger regular domain might exist, but is not required by or inferred from this construction.

Let g_ij=I_(B,ij) in this paragraph only. Its inverse is C2: differentiate gg^(-1)=Id to get partial_k g^(-1)=-g^(-1)(partial_k g)g^(-1), and differentiate once more using ordinary products. Define
\[
\Gamma^l_{jk}=\tfrac12 g^{lm}(\partial_jg_{mk}+\partial_kg_{mj}-\partial_mg_{jk}).
\]
These coefficients are C1. Substituting shows symmetry in j,k and partial_i g_jk=Gamma^m_ij g_mk+Gamma^m_ik g_jm, so the connection is torsion-free and metric compatible. Conversely those two equations, with the cyclic index permutations added and subtracted, solve uniquely to the displayed formula. This proves the Levi-Civita identification under the actual regularity assumptions.

Use the sphere-positive convention
\[
R^l{}_{kij}=\partial_i\Gamma^l_{jk}-\partial_j\Gamma^l_{ik}
+\Gamma^l_{im}\Gamma^m_{jk}-\Gamma^l_{jm}\Gamma^m_{ik},\quad
\mathrm{Ric}_{kj}=\sum_iR^i{}_{kij},\quad
\mathcal R=g^{kj}\mathrm{Ric}_{kj}.
\]
The commutator of the two covariant derivatives on a vector has exactly these coefficients, which establishes its tensorial character under coordinate change. Only derivatives through second order of g occur, so R, Ric and the scalar are continuous. The same formulas applied to L^(-2)I_(B,Lambda_L) are well-defined for all sufficiently large L on each compact regular subchart: DG05 makes the operator difference smaller than one half the density floor. Inverse and polynomial continuity then give compact-uniform convergence of their connections and curvature to these actual density objects. This is curvature convergence for each fixed B as the square grows, not as B tends to infinity.


The regular metric chart can also be identified with actual law coordinates. At any point in a certified density chart choose one sufficiently large finite square from the preceding positive-minor argument. For its positive probability vector, the finite Fisher matrix is Dp^T diag(1/p)Dp, so positive definiteness implies rank(Dp)=2. Two atom probabilities therefore have a nonsingular two-by-two Jacobian. Multiply those two observed probabilities by the inverse Jacobian at the point. On a sufficiently small convex parameter ball the transformed map has derivative within 1/2 of the identity. Segment integration then bounds its change below by one half the parameter distance, proving local injectivity. For nearby target values, the map x maps to x+y-F(x) is a contraction preserving a smaller closed ball; its convergent iteration supplies a local inverse. Differentiating F(F^(-1)(y))=y and using the continuous inverse Jacobian gives the inverse derivatives through order three. This exhibits a local C3 chart of the actual finite marginal and hence of the full law, without assuming a quotient of a constant-rank semimetric. The selected finite square and atom pair can depend on the chart point and B.

## DG07. Finite probability jets and normalization identities

For any positive C3 finite family with parameter-independent carrier, write p_alpha for its ordinary mass derivative with multi-index alpha, |alpha|<=3. The zero-order vector sums to one and every other vector sums to zero. If A=Zp is a positive unnormalized family, the ordinary multi-index product rule gives, inductively by total degree,
\[
p_\alpha=\frac{A_\alpha-
\sum_{0<\beta\le\alpha}\binom\alpha\beta Z_\beta p_{\alpha-\beta}}{Z_0}.
\]
The coefficient binom(alpha,beta) is the product of the two coordinate binomials. Positivity of Z0 justifies every division, and induction proves these are all the actual normalized derivatives.

For the finite spatial source in natural coordinates, use A_alpha(z)=A_0(z)T_h(z)^(alpha_1)T_J(z)^(alpha_2), where T_J includes every touching plaquette and its fixed exterior. A parameter-only cosh factor relates this exponential representative to the original factor product; it cancels in p. The representative's derivatives must not be described as derivatives of the old raw partition. For the (b,c) chart, h'=1/(1-b^2), h''=2b/(1-b^2)^2 and h'''=2(1+3b^2)/(1-b^2)^3, with the corresponding J(c) terms. The one-coordinate identities p_bb=p_hh(h')^2+p_h h'' and p_bbb=p_hhh(h')^3+3p_hh h'h''+p_h h''' give the pure derivatives; mixed derivatives follow by applying these independent one-coordinate operators in either order. This includes all nonlinear chart terms.

A parameter-independent channel acts linearly on each of the ten derivative vectors. A column which is identically zero remains explicitly zero at every order; geometry requiring division by positive mass must refuse that carrier until an active-support law is separately admitted. For fixed positive normalized likelihood ell(o|z), first multiply each source jet by ell, sum it to obtain the evidence jet Z_o, then apply the same quotient recurrence. Summing the product-rule identity Z_op_o over observations recovers the original jet at every order, because sum_o ell(o|z)=1. A parameter-dependent likelihood or channel needs its own jets and is outside this fixed-operation formula.

## DG08. Finite metric derivatives and coordinate-consistent curvature

For positive p, g_ij=sum_z p_i p_j/p. Its first and second derivatives are obtained from the ordinary product/reciprocal rules and need p only through degree three. Equivalently compute the log derivatives l_i=p_i/p, l_ij=p_ij/p-p_i p_j/p^2 and
\[
l_{ijk}=p_{ijk}/p-(p_{ij}p_k+p_{ik}p_j+p_{jk}p_i)/p^2+2p_i p_j p_k/p^3,
\]
then use DG02's formulas for g,dg,ddg. These equivalent derivations fix all multiplicities. Exact symmetry together with g00>0 and det(g)>0 admits a two-dimensional inverse and the DG06 connection/curvature formulas. Positive mass alone does not imply these minors; binary retention or erasure may give a singular matrix. This construction provides no pseudoinverse, rank cutoff or automatic quotient.

If the supplied jets are actual family derivatives and the minors are positive at the point, continuity gives some local regular neighborhood for that finite family. The spatial source and its fixed operations meet this actual-family premise by DG07. An arbitrary manually assembled jet record is only a conditional algebraic input; normalized arrays at one point alone do not establish an actual C3 family. These finite conditions do not certify the infinite density, whose separate proof is DG03–06.

## DG09. Independent positive-sphere and crossing-factor controls

For the affine three-category family p=(u,v,1-u-v)>0 the Fisher line element is sum_a (dp_a)^2/p_a. The map x_a=2sqrt(p_a) has differential dx_a=dp_a/sqrt(p_a), and sum x_a^2=4. It is an isometry onto the positive octant of the radius-two sphere. For tangent vectors U,V on a radius-r sphere, differentiating its unit normal x/r gives D_U n=U/r; splitting the flat ambient derivative into tangent and normal pieces in its zero commutator gives R(U,V)W=(<V,W>U-<U,W>V)/r^2 with the DG06 convention. Thus sectional curvature is 1/4 and the two-dimensional scalar is 2(1/4)=1/2. This is a direct finite derivation, independent of numerical curvature agreement.

A useful source-faithful finite control frees exactly four edges of one square, retains all five touching plaquettes, and fixes the three exterior factors of each crossing plaquette so its character is minus its incident free edge. Then its normalized source has exponential representative exp[(h-J)sum z+J product z]. Retaining the two outgoing lower-left edges z1,z2 and summing z3,z4 gives
\[
p(z_1,z_2)=\frac{(1+t z_1)(1+t z_2)(1+c t^2 z_1z_2)}{4(1+c t^4)},\qquad
t=\tanh(h-J)=\frac{b-c}{1-bc}.
\]
This follows by expanding the central factor and averaging the two omitted independent signs with mean t. The retained moments are M=(t+c t^3)/(1+c t^4) and V=t^2(1+c)/(1+c t^4). Direct quotient differentiation and expansion gives
\[
\det\frac{\partial(M,V)}{\partial(t,c)}
=\frac{t^2(1-t^2)^2(1+c t^2)}{(1+c t^4)^3}>0
\]
for t in (0,1), c in (0,1). The three category masses are p_++, p_-- and p_+-+p_-+; their derivatives with respect to (M,V) have a nonzero constant two-by-two determinant because p_++=(1+2M+V)/4 and p_--=(1-2M+V)/4. Mixed-sign masses are equal, so splitting that category by a fixed fair coin preserves the Fisher metric. Local invertibility is explicit: t=2M/[1+V+sqrt((1+V)^2-4M^2)] and c=(V-t^2)/[t^2(1-Vt^2)]. Indeed M(1+t^2)=t(1+V); the branch t<1 chooses the displayed root. At an interior positive row 1+V>2|M|, so the square root is positive, and t^2(1-Vt^2)>0 at the stated fixture. These smooth formulas persist on a neighborhood, giving a full three-category chart and scalar 1/2. The maps from natural and (b,c) coordinates to (t,c) are nonsingular here, so both must give the same scalar when all higher chart terms are retained. The concrete point t=1/5,c=1/20 has b=25/101. This proves the candidate exact fixture's mathematical value; the implementation still requires its own execution evidence.

## DG10. Limits and curvature/VFE distinctions

For a positive constant a, replacing a regular metric g by ag leaves its Christoffel symbols and Riemann tensor with one raised index unchanged, while its scalar curvature becomes R/a. Therefore metrics a_Bg with a_B tending to zero can have diverging scalar curvature. The established all-depth vanishing Fisher density is not a flatness result. No common positive-J regular chart or curvature limit for unbounded B follows from the finite-hierarchy construction.

Constant rank alone also does not identify a quotient metric. The smooth rank-one form exp(2v)du^2 has radical spanned by partial_v, but cannot descend through the leaf projection (u,v)mapsto u: its value on partial_u depends on v. A regular leaf space and a basic metric, or an explicitly identified law map with those properties, must be supplied before using a quotient. This counterexample is separate from the actual full-rank charts proved here.

Gauge curvature belongs to a connection over the structural base, with loop holonomy determined by that connection. Parameter Fisher curvature belongs to the C2 information metric of a specified statistical family. Base Riemannian curvature belongs to a chosen metric on the base. These have different inputs and index spaces in the admitted construction. A contraction such as Tr(F_mu nu F^mu nu) additionally needs an invariant fiber pairing and a base metric for raising indices, together with a measure/reference and coefficient in a normalized generative model. The existing lattice plaquette term is an admitted gauge-holonomy coupling; its exact finite summation generally generates complete nonlocal interactions. The present Fisher response calculation does not convert those interactions into a Fisher scalar term or into base scalar curvature.

The normalized-joint VFE remains E_q[log q-log p(observation,latent)] with the same reference. Curvature can enter it through an explicitly chosen generative prior/likelihood or a derived effective action, including its normalizer; it does not enter merely because a metric can now be differentiated. Neither Fisher contraction nor curvature smoothness establishes curvature monotonicity, Einstein/Yang–Mills equations, critical universality, continuum existence or a physical RG clock. Those are distinct later obligations, not conclusions suppressed by notation.
