<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753","target_digest":"aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753"} -->

# Higher response and regular conditional-score charts

Date: 2026-09-09. **DEFINITION.** This is the assigned mathematical author construction, HR01 onward, bound to the frozen C3 contract. The author previously wrote UC and FR and shared the discovery route with the root; this is not independent reconstruction. The only writes are this file and its atomic author proposals. No code, tests, science, old producer, GPU, tamper, Git or vault work is performed, and no ledger state is assigned. The root owns complete higher interaction-norm assembly, the quasilocal varying-expectation/C2 actual-density passage, and the curvature construction. All arguments below are direct finite derivations followed by specified uniform limits; no complex zero-free or truncated-correlation theorem is imported.

## HR01. Restored compact geometry and finite source

**HYPOTHESIS.** The family is the unchanged square-lattice dressed Z2 law with natural parameters g=(h,J), straight retained B-paths P_B(x,a)={(Bx+t e_a,a):0<=t<B}, and unused singleton blocks. A pattern prescribes each retained path to * or a parity sign, with unused singletons unconstrained. Finite free inventories are unions of whole blocks with parameter-independent fine exterior signs eta. Every touching plaquette, including a crossing plaquette, is retained. The normalized reference is the fixed product of uniform probability references on the admitted block fibers. Integer B>=1 is arbitrary.

**DEFINITION.** Choose a compact rectangle Khat, with finite positive h endpoints and 0<=J<=J_*, J_*<atanh(1/12). Its interior with J>0 contains any compact target rectangle after enlargement. The inclusion of J=0 is used only for the explicitly proved one-sided continuation. Let h_* be the upper h endpoint and set c_*=tanh J_*. Choose J_*>0 and tau>0 so q=12c_*exp(tau)<1. Put z=exp(-tau), C=16q/(1-q), rho=tanh(h_*+2J_*) in (0,1), and d=1-rho. These constants are independent of B, volume, pattern and exterior.

**ESTABLISHED.** Each anchor cell contains exactly 2B^2 fine edges and B^2 plaquette basepoints. Every plaquette meets four distinct blocks, at most one edge in each retained path. Fine-edge influence columns sum to six; incident anchors differ by at most one. These are the actual UC/FR hypotheses. The finite density is proportional to exp(hT_1+JT_2^eta), where T_1 sums all free edge signs and T_2^eta sums all touching plaquette characters. The support and reference do not vary with g. Every finite expectation is analytic for finite real parameters. At J=0 it is an independent product of the prescribed block-fiber laws. None of this invokes the old 6Bc uniqueness domain.

## HR02. Finite group decoupling from the constrained specification

**ESTABLISHED.** Let A be a finite nonempty anchor set. Let U be any finite vector of fine-block observables supported on A and V any finite vector supported outside A_R={x:dist_infinity(x,A)<=R}, R>=0 integer. In an arbitrary finite whole-block volume, the joint law satisfies

\[
\operatorname{TV}(\mathcal L(U,V),\mathcal L(U)\otimes\mathcal L(V))
\le\min\{1,C|A|B^2(R+1)e^{-\tau(R+1)}\}.
\label{eq:rg-hr-group-decoupling}
\]

Here fixed exterior signs in either observable are constants. To prove this, condition on all free blocks outside A_R. Compare two resulting conditional laws on the common interior free blocks. Their product-fiber supports agree. The coupled stationary heat-bath argument of UC gives weighted fine Hamming at most q/(1-q) times the exterior discrepancy-weight sum, with weights exp(-tau dist(anchor,A)). Differences can occur only on the newly conditioned boundary at anchor distance R+1. A boundary inherited from the original finite volume has identical fixed eta on both sides and contributes zero, even if it lies near A. Thus intersecting A_R with an irregular original whole-block volume does not add an uncounted near boundary.

There are at most 8|A|(R+1) shell anchors and 2B^2 fine edges per anchor. Their weighted sum is at most 16|A|B^2(R+1)exp[-tau(R+1)]. This bounds the TV of the full joint target block state, and therefore of U. Its conditional law given the entire exterior has diameter bounded by the displayed epsilon. Its unconditional law is a mixture of those conditionals, so its distance from each conditional is at most epsilon. Taking the joint with the exterior and then marginalizing to V proves the group decoupling inequality. This controls the joint distribution of groups; it is not an inference from pairwise covariances.

The same inequality holds in the infinite constrained law. For finite U,V, approximate both by finite whole-block volumes and pass their finite joint distributions to the UC limit; finite-alphabet TV is continuous. UC existence at J>0 and the exact product-fiber construction at J=0 give the required laws uniformly on Khat. The argument uses the actual fixed pattern at every stage, including infinite null prescriptions through normalized limits.

## HR03. Cumulants and their group-cancellation constant

**DEFINITION.** For bounded finite observables F_1,...,F_m, define

\[
\kappa(F_1,\ldots,F_m)=
\sum_{\pi\in\mathcal P_m}(-1)^{|\pi|-1}(|\pi|-1)!
\prod_{D\in\pi}E\prod_{i\in D}F_i.
\label{eq:rg-hr-cumulant}
\]

Define K_m=sum_pi(|pi|-1)! and Q_m=2sum_pi |pi|!. For m=2,3,4 these pairs are (2,6), (6,26), (26,150), respectively. The partition counts by number of blocks are (1,1), (1,3,1), and (1,7,6,1), which give these constants directly.

**ESTABLISHED.** The coefficient of t_1...t_m in log E exp(sum_i t_iF_i) is the displayed cumulant. Expand the exponential, then log(1+v)=sum_(k>=1)(-1)^(k-1)v^k/k near zero. The coefficient uses each index once; the k! orderings of a k-block partition give (k-1)!. The expansion converges near zero because the variables are bounded and the moment generating function equals one at zero. If the arguments split into two independent nonempty groups, the generating function factorizes and its logarithm is a sum with no mixed coefficient. The cumulant is therefore zero.

If two joint argument laws are at TV distance epsilon and ||F_i||_infinity<=M_i, each block moment changes by at most 2epsilon times its product of M_i. Telescoping a product of |pi| block moments gives at most 2|pi|epsilon product_i M_i. Hence the cumulants differ by at most Q_m epsilon product_i M_i. Their individual magnitude is at most K_m product_i M_i. Combining this with HR02 and the product-of-groups law proves a quantitative group-cancellation bound. A zero M_i makes the result zero directly; no normalization by zero is needed.

## HR04. The longest-tree-edge separation for source tuples

**ESTABLISHED.** Let f have fine-block support in a nonempty anchor set A with a=|A|. Let r in {1,2,3} source observables each be a fine edge sign or a plaquette character, with base anchors x_1,...,x_r. Sources may repeat. Put M=max_j dist_infinity(x_j,A). Construct a complete weighted graph with one root representing A and r labeled source vertices. A root edge has weight dist(x_j,A); other edges have weight |x_i-x_j|_infinity. Take a minimum-total-weight spanning tree. Any tree path from the root to a source at distance M has at most r edges, and its total weight is at least M by choosing the nearest point of A for its first edge and applying the ordinary distance triangle inequality along the remaining edges. Thus some tree edge has length at least M/r.

Remove a longest tree edge, of length ell. Every original graph edge crossing the resulting cut has weight at least ell, since a shorter crossing edge would replace it and shorten the tree. Consequently the source anchors in different groups are at least ell apart, and every source in the group without A is at least ell from A. Source plaquette fine supports enlarge their anchors by at most one step. The two fine-support groups are therefore separated by at least M/r-2. Repeated vertices or zero-length edges cause no problem; the argument concerns a far source only when M>0.

The group containing f has at most a+4r fine-support anchors. If M>=4r, choose R=floor(M/r)-3>=1. The other group's support lies outside its radius-R neighborhood. HR02-HR03 then give a cumulant bound using that finite group. If M<4r use the individual K_(r+1) bound instead. This restores the actual group-separation hypothesis needed for cumulant cancellation; no spanning-tree decay theorem is assumed.

## HR05. A uniform localized cumulant envelope

**DEFINITION.** For r=1,2,3 and integer a>=1 set

\[
L_r(a)=e^{4\tau}\bigl[K_{r+1}+Q_{r+1}C(a+4r)\bigr].
\label{eq:rg-hr-local-constant}
\]

**ESTABLISHED.** In every admitted finite or infinite constrained law,

\[
|\kappa(f,T_{1,s_1},\ldots,T_{r,s_r})|
\le L_r(a)B^2(M+1)e^{-\tau M/r}\|f\|_\infty.
\label{eq:rg-hr-local-cumulant-bound}
\]

Each T_(j,s_j) is the individual edge or plaquette source for the chosen j-th derivative direction; the subscript 1,...,r orders the tuple and is not an additional parameter. At M>=4r, HR04 gives R+1=floor(M/r)-2, between M/r-3 and M. Thus the group error is at most C(a+4r)B^2 M exp(3tau)exp(-tau M/r). Multiply by Q_(r+1). At M<4r, exp(4tau)exp(-tau M/r)>=1 and B^2(M+1)>=1, so the K_(r+1) term dominates. This proves the common envelope. The finite source list includes crossing plaquettes with their fixed exterior completion. A fully exterior source is absent, and a constant source has zero cumulant for r>=1; overcounting it by the envelope is harmless.

## HR06. Complete source-tuple sums and explicit tails

**DEFINITION.** Put

\[
S_r(a)=
\frac{(8a)^r L_r(a)(2r+1)!}
{(1-e^{-\tau/r})^{2r+2}},\qquad r=1,2,3.
\label{eq:rg-hr-source-sum-constant}
\]

**ESTABLISHED.** For any prescribed list of r derivative directions, summing over all ordered source tuples, including coincident sources, gives

\[
\sum_{s_1,\ldots,s_r}|\kappa(f,T_{1,s_1},\ldots,T_{r,s_r})|
\le S_r(a)B^{2r+2}\|f\|_\infty.
\label{eq:rg-hr-source-sum}
\]

The same sum restricted to M>L, for integer L>=0, is at most

\[
S_r(a)B^{2r+2}(L+2)^{2r+1}e^{-\tau(L+1)/r}\|f\|_\infty.
\label{eq:rg-hr-source-tail}
\]

Indeed the radius-M neighborhood of A has at most a(2M+1)^2 anchors. Each derivative source type has at most 2B^2 choices per anchor, so the number of ordered tuples of radius at most M is bounded by (8a)^rB^(2r)(M+1)^(2r). Using this cumulative count as an upper bound on the number at exact radius M only enlarges the sum. Multiply by HR05. For x=exp(-tau/r) and d_r=2r+1, sum_(M>=0)(M+1)^(d_r)x^M<=d_r!/(1-x)^(d_r+1): the coefficient bound follows from (M+1)^(d_r)<=d_r! binom(M+d_r,d_r), and the latter geometric derivative series sums to the stated rational function. For M=L+1+n, (M+1)^(d_r)<=(L+2)^(d_r)(n+1)^(d_r), proving the tail with the same S_r. All finite source lists are subsets of the counted lattice inventory; crossing sources and repeated tuples have not been dropped.

## HR07. Finite higher differentiation with moving local observables

**ESTABLISHED.** For a parameter-independent finite observable f, differentiating the finite normalized exponential law r times gives the sum of cumulants in HR06. One direct derivation differentiates log E_g exp(tf) with respect to t and the r natural parameter variables at zero source displacement. The shifted normalizer contributes a term independent of t and disappears. Its mixed coefficient is the cumulant of f and the r full statistics, which expands multilinearly into the ordered source sums. This includes mixed h,J derivatives with their actual multiplicities.

For a local observable f_g that itself varies with g, differentiating its cumulant additionally differentiates each observable argument. In particular, for a multi-index alpha of order n<=3,

\[
\partial^\alpha E_g f_g=
\sum_{\beta\le\alpha}\binom{\alpha}{\beta}
\sum_{\text{sources for }\alpha-\beta}
\kappa_g(\partial^\beta f_g,T_{1,s_1},\ldots,T_{n-|\beta|,s_{n-|\beta|}}).
\label{eq:rg-hr-moving-observable-response}
\]

For beta=alpha the inner expression is E_g partial^alpha f_g, with no source sum. The formula follows by repeated finite product differentiation or by the same generating function with a differentiable observable argument; the extra derivative of each argument is explicit. All natural source statistics are parameter-independent. Boundary signs and the reference are fixed, so neither introduces another derivative.

## HR08. Actual C3 of every constrained cylinder law

**ESTABLISHED.** Fix B, an anchor support A and a bounded parameter-independent cylinder f. For each fixed ordered source tuple, all its fine support lies inside a sufficiently large whole-block volume. UC uniform cylinder convergence on Khat gives convergence of every moment in its finite cumulant, hence convergence of that cumulant uniformly in g, pattern and fixed fine exterior. The finitely many source tuples inside radius L can therefore be passed to the limit uniformly. Both the finite and infinite far sums are bounded by HR06. First choose L to make those tails small, then the volume for the near tuple sum. This proves uniform convergence of finite expectation derivatives of orders one, two and three to their absolutely convergent infinite cumulant sums.

The limiting sums are continuous in g. Each fixed local moment is a uniform limit of finite analytic moments: use one fixed fine exterior and note that a finite oracle has only finitely many interior support patterns. Its finite family is equicontinuous on the compact set. The source tails are uniform, so the limiting cumulant sums are continuous, also uniformly in the pattern. Apply the finite FTC on coordinate segments and pass the uniform derivatives under each integral. Starting with means, then their first and second derivatives, this proves that the limiting sums are the actual derivatives through order three. Mixed derivatives agree because their finite counterparts agree and converge uniformly. Splitting multi-coordinate increments into coordinate segments supplies ordinary C3, not merely directional differentiability.

For segments starting at J=0 the same finite FTC and domination give right derivatives and continuous derivative limits through order three. At J=0 the limiting value law is the exact independent block-fiber product. Thus the construction gives actual one-sided C3 up to this boundary on positive-h compact intervals. No negative-J uniqueness theorem is needed. At strictly positive J this is the usual open-domain C3 theorem. No infinite-event probability or infinite partition function is differentiated.

The argument applies to every fixed fine cylinder indicator, including joint target/source indicators, not just parity means. An indicator forbidden by a fixed support is identically zero with zero derivatives. Uniformity refers to exhausting inventories containing the required full anchor neighborhoods; an inventory cutting a path violates the premise.

## HR09. Higher free-path product amplitudes

**ESTABLISHED.** For a free target path P anchored at zero, its conditional mean given the remaining fine blocks is G_g=product_(e in P)tanh(h+Ja_e), with |a_e|<=2. It and all its parameter derivatives depend only on blocks with anchors in Q_1, at most nine anchors. For n=0,1,2,3 define g_n=2^n n!. The derivatives of tanh of orders one through three have magnitude at most 1,2,6, respectively. Assigning the n labeled parameter differentiations to B factors gives at most B^n terms; the product of the coordinate factorials is at most n!, and each J differentiation contributes at most two. Therefore

\[
\|\partial^\beta G_g\|_\infty
\le g_n B^n\rho^{B-n},\qquad |\beta|=n\le3.
\label{eq:rg-hr-local-product-derivatives}
\]

For n=0 this is rho^B. The formula is also an upper bound at B<n, since the negative exponent only enlarges the right side and rho>0. Every intermediate local field remains bounded by h_*+2J_*.

Define for n=1,2,3

\[
D_n=g_n+\sum_{b=0}^{n-1}\binom nb g_b S_{n-b}(9),\qquad
M_n(B)=D_nB^{2n+2}\rho^{B-n},\qquad M_0(B)=\rho^B.
\label{eq:rg-hr-mean-amplitudes}
\]

Apply HR07-HR06 to G_g and use the finite identity E_gY_P=E_gG_g. The term with b differentiated product factors is bounded by g_b B^b rho^(B-b) times S_(n-b)(9)B^(2(n-b)+2), unless b=n when it is a plain expectation. Since B>=1, b<=n and rho<1, every such term is dominated by its coefficient times B^(2n+2)rho^(B-n). The multi-index binomial coefficients sum to binom(n,b) at fixed |beta|=b. Thus every finite free-path derivative of order n has magnitude at most M_n(B). Passing the actual derivatives via HR08 proves the same amplitude in infinite volume. The sharper FR first-order bound remains valid; this nonoptimized bound is sufficient for a common higher-order interface. Each M_n(B) tends to zero with B.

## HR10. Counted spatial moduli through order three

**ESTABLISHED.** Compare two patterns leaving target P free and agreeing on every block in Q_R. They may differ among *,+,- outside it. For n=1,2,3 and R>=2 put L=floor(R/2)-1 and

\[
N_n=2^nQ_{n+1}C(1+4n).
\]

The order-n target parity derivative difference is bounded by

\[
V_n(B,R)=B^{2n+2}\left[
N_n(2L+1)^{2n}(R-L)e^{-\tau(R-L)}
+2S_n(1)(L+2)^{2n+1}e^{-\tau(L+1)/n}
\right].
\label{eq:rg-hr-derivative-spatial-modulus}
\]

For a near source tuple with all anchors in Q_L, its joint support with P occupies at most 1+4n anchors in Q_(L+1). The radius R-L-1 neighborhood of that support lies in Q_R. UC therefore bounds its joint TV by C(1+4n)B^2(R-L)exp[-tau(R-L)]. HR03's Q_(n+1) gives the cumulant change. The number of near ordered tuples is at most [2B^2(2L+1)^2]^n. For each far sum use HR06 with a=1; adding the two tails gives the second term. This proves the bound without assuming the two remote supports can be directly coupled.

For R=0,1 set V_n(B,R)=2M_n(B). At all radii the bound can be capped by 2M_n(B). For values put V_0(B,R)=min(2rho^B,2CB^2(R+1)exp[-tau(R+1)]). For R>=2 the displayed higher-order modulus is at most

\[
\left[N_n+2e^{\tau/(2n)}S_n(1)\right]
B^{2n+2}(R+1)^{2n+1}e^{-\tau R/(2n)}.
\label{eq:rg-hr-spatial-envelope}
\]

Here L+1=floor(R/2)>=R/2-1/2. This retains the response-dependent exponent: order three gives tau/6, not the first-order exponent. The bound is summable after any fixed polynomial shell count and multiplication by exp(lambda R) for lambda<tau/(2n).

## HR11. Uniform higher finite-oracle comparison

**ESTABLISHED.** The same V_n(B,R) compares the derivative of a finite oracle containing every block anchored in Q_R against the infinite matching pattern, with arbitrary fixed fine exterior. Near tuples have their entire plaquette support inside Q_(L+1), so their sources are genuinely interior and their joint finite/infinite TV has the same UC bound. Remaining finite sources, including crossing ones, and remaining infinite sources each obey HR06. This gives precisely the same near count and two tails.

For a general fixed local f on anchor set A, the same construction uses its anchor neighborhoods and |A| source counts rather than replacing A by one cell. HR08 already provides uniform compact convergence for that general case. For the free-path interface, the caps 2M_n(B) and 2rho^B additionally make anchor-radius convergence uniform over all B: choose a large-B cutoff using their geometric decay, then choose one radius for the remaining finite list of B values. No fixed fine-volume size is asserted to contain arbitrarily long paths.

## HR12. Positive C3 finite coarse rows and explicit logarithmic calculus

**ESTABLISHED.** Each free-path sign probability is (1+s m)/2 with denominator factor 1+s m>=d. Reveal the two paths of a cell successively. Finite conditioning restricts exactly the first path fiber; UC uniqueness identifies the second mean with that fixed updated pattern. Hence every four-state cell atom is the product of two positive Bernoulli factors, lies between (1-rho^B)^2/4 and (1+rho^B)^2/4, and is actual C3 by HR08. Repeating this finite construction gives every finite-set coarse atom, preserving all dependencies, normalization and pointwise specification consistency. Every fixed partial-past or fully prescribed exterior pattern is included, with infinite null patterns defined through normalized limits. The finite product rule and HR11 give compact-uniform C3 oracle convergence.

For one Bernoulli log factor define the order-n amplitude bounds

\[
A_1=\frac{M_1}{d},\qquad
A_2=\frac{M_2}{d}+\frac{M_1^2}{d^2},\qquad
A_3=\frac{M_3}{d}+\frac{3M_2M_1}{d^2}+\frac{2M_1^3}{d^3}.
\label{eq:rg-hr-log-amplitudes}
\]

They follow from differentiating log(1+s m): the second derivative contains m_ij/(1+s m) and -m_i m_j/(1+s m)^2 with their signs, and the third contains m_ijk/(1+s m), three m_ij m_k terms with denominator squared, and two m_i m_j m_k terms with denominator cubed. Signs do not affect these absolute bounds. Each one-cell log-probability derivative has amplitude at most 2A_n; each reference-state log-odds derivative at most 4A_n.

Writing E_1=D_1/d, E_2=D_2/d+D_1^2/d^2, and E_3=D_3/d+3D_2D_1/d^2+2D_1^3/d^3 gives A_n<=E_n B^(4n)rho^(B-n), n=1,2,3. Thus all these complete local log derivatives decay in B with an explicit polynomial prefactor. Relative normalized-counting factors contribute only a parameter-independent constant and do not change the derivatives.

## HR13. Actual higher log-derivative spatial moduli

**ESTABLISHED.** Use the M_n,V_n above for two matching patterns. Direct subtraction of the derivative ratios, with |u^(-k)-v^(-k)|<=k|u-v|/d^(k+1), gives the following one-Bernoulli-log spatial bounds:

\[
T_1=\frac{V_1}{d}+\frac{M_1V_0}{d^2},
\]

\[
T_2=\frac{V_2}{d}+\frac{M_2V_0+2M_1V_1}{d^2}
+\frac{2M_1^2V_0}{d^3},
\]

\[
T_3=\frac{V_3}{d}+\frac{M_3V_0+3M_2V_1+3M_1V_2}{d^2}
+\frac{6M_2M_1V_0+6M_1^2V_1}{d^3}
+\frac{6M_1^3V_0}{d^4}.
\label{eq:rg-hr-log-spatial-moduli}
\]

One-cell log-probabilities use 2T_n and reference-state log odds use 4T_n. In the second path factor the same revealed first parity is prescribed in both patterns, preserving their interior agreement. The bounds may be capped by the corresponding two amplitudes, 4A_n for log probabilities and 8A_n for log odds. These are actual derivative estimates, not derivatives of a variation bound.

All M_j(B) are bounded over B by explicit constants: for d_j=2j+2 one may use U_j=D_j rho^(1-j)d_j!/(1-rho)^(d_j+1), because sum_(B>=1)B^(d_j)rho^B<=d_j!rho/(1-rho)^(d_j+1). Replace each M_j in the spatial formulas by U_j. HR10 then shows that each T_n has a compact-only constant times B^(2n+2)(R+1)^(2n+1)exp[-tau R/(2n)] for R>=2, with the finite small-radius amplitude bound. This gives a counted summable interface for the root's higher derivative-shell argument. The exact T_n formulas remain available; no optimized constant is claimed.

## HR14. Product-control conditional scores with their actual past geometry

**ESTABLISHED.** At J=0 fix the complete lexicographic past of a target coarse cell and leave its target and all future retained paths free. Unused singletons remain free. The conditioned fine law is the independent product of its block-fiber laws. Write b=tanh h in (0,1). Each free target B-path parity has mean b^B, independently of the other. For a fine edge of that path,

\[
a(s)=E[z_e\mid Y=s]-b
=\frac{s b^{B-1}(1-b^2)}{1+s b^B},\qquad
E a=0,\qquad
v_B=E a^2=\frac{b^{2B-2}(1-b^2)^2}{1-b^{2B}}>0.
\label{eq:ig-hr-product-contrast}
\]

To obtain the conditional expectation, weight a product sign law by (1+s product_e z_e)/2 and use E z_e=b and E[z_e product_e z_e]=b^(B-1). The displayed moments follow by summing the two parity outcomes. Also v_B<=Var(z_e)=1-b^2<=1, by expanding the variance into conditional variance plus the variance of the conditional mean.

The actual h row score is B(a_1+a_2). This follows from the finite normalized source score and conditioning on the two target parities: all fields in other independent blocks cancel on centering, and each target edge contributes a_i. The actual J row score has the form

\[
s_J=b^2a_1a_2+\alpha_1a_1+\alpha_2a_2,
\qquad |\alpha_i|\le2B.
\label{eq:ig-hr-product-J-score}
\]

Here is the full incidence argument. The plaquette based at the common starting vertex is the unique plaquette containing an edge from both outgoing target paths. When B=1 its other two edges are anchored at the two positive unit-coordinate cells, both in the future for the fixed lexicographic order. When B>1 they are unused singleton edges: their transverse fine coordinate is one, not a multiple of B. Thus both other edges are unconstrained and have mean b. Its conditional character is b^2(b+a_1)(b+a_2); centering leaves b^2a_1a_2+b^3(a_1+a_2).

Every other incident plaquette contains only one edge of one target path. Its remaining product has a conditional expectation k_p of magnitude at most one, independent of that free target block, so its centered contribution is k_p a_i. A target path has 2B incident plaquettes, one being the shared corner. Therefore alpha_i=b^3+sum_(2B-1 other incidences)k_p, whose magnitude is at most 2B. Nonincident plaquettes are independent of the target under the product of block fibers and contribute zero centered score. Prescribed past blocks may have internal correlations, but a plaquette contains at most one edge of each such block, and the preceding bound needs only the product's absolute value at most one.

These identities are first obtained in a finite whole-block oracle containing the target and its incident plaquettes. All more distant sources have zero target covariance at J=0. HR08's one-sided derivative limit and positive target probabilities identify these limiting expressions as the actual infinite conditional scores. They are not obtained by differentiating the J=0 value formula while holding J identically zero.

## HR15. Uniform-in-past positive product-control Fisher floor

**ESTABLISHED.** Under the target product row, a_1,a_2 are independent centered variables of variance v_B, and a_1a_2 is orthogonal to both linear contrasts. The exact conditional Fisher matrix therefore satisfies

\[
I_{hh}=2B^2v_B,\quad
I_{hJ}=Bv_B(\alpha_1+\alpha_2),\quad
I_{JJ}=v_B(\alpha_1^2+\alpha_2^2)+b^4v_B^2.
\]

Its determinant is B^2v_B^2(alpha_1-alpha_2)^2+2B^2b^4v_B^3, while its trace is at most 10B^2v_B+b^4v_B^2<=11B^2v_B. Since the matrix is positive semidefinite and the determinant is positive, its smaller eigenvalue is its determinant divided by its larger eigenvalue, which is at most the trace. Consequently

\[
\lambda_{\min}(I_{\rm cell}(h,0\mid\text{past}))
\ge\frac{2}{11}b^4v_B^2>0.
\label{eq:ig-hr-product-fisher-floor}
\]

This bound is uniform over every past prescription. On a compact positive-h interval with b in [b_-,b_+], an explicit common floor is

\[
\eta_{0,B}=\frac{2}{11}b_-^{4B}(1-b_+^2)^4>0.
\label{eq:ig-hr-compact-product-floor}
\]

Indeed v_B>=b_-^(2B-2)(1-b_+^2)^2, since its denominator is at most one. This is a lower bound for the actual conditional-score Fisher matrix, not just a finite-volume source Fisher determinant.

## HR16. Explicit continuation to regular positive-J neighborhoods

**ESTABLISHED.** Choose a larger positive-h compact interval Iplus whose interior contains the requested interval I, and a J_*>0 below the threshold. Use the preceding constants on Iplus times [0,J_*]. For each fixed B let A_1,A_2 be the uniform Bernoulli log-amplitude bounds in HR12 and put

\[
Q_B=16(A_1^3+A_1A_2),\qquad
\delta_B=\min\{J_*/2,\eta_{0,B}/(2Q_B)\}>0,
\label{eq:ig-hr-regular-neighborhood}
\]

where eta_(0,B) is computed with the endpoints of Iplus. These A_j are strictly positive finite upper bounds, so Q_B>0. The one-cell score vector has norm at most 2sqrt(2)A_1; its J derivative has norm at most 2sqrt(2)A_2. Differentiate its finite four-state Fisher sum. The term differentiating the probabilities has norm at most (2A_1)(8A_1^2)=16A_1^3, since partial_J p=p s_J. The two differentiated-score terms together have norm at most 16A_1A_2. Thus the actual conditional Fisher J derivative is bounded by Q_B, uniformly over every fixed past. HR08-HR12 ensure these actual derivatives extend continuously to J=0, so FTC gives a difference from the product-control matrix at most Q_B J.

For every h in Iplus and 0<=J<delta_B the conditional Fisher matrix is therefore bounded below by eta_(0,B)/2 times the identity. For J>0 the existing actual-density identity mathcal I_B=E_muB I_cell(fullpast) then gives the same density floor. This proves a nonempty open regular region interior(Iplus) times (0,delta_B), with an explicit floor on the stated compact h interval. It does not require differentiating that expectation or assuming the root's new C2-density conclusion.

For a prescribed finite list of depths, take the minimum of their finitely many positive delta_B and, if desired, of their positive floors. This gives one regular region for that finite hierarchy in the same original parameters. No positive lower bound on inf_(all B)delta_B is proved; both the floor and the permitted width may shrink with B. No common fixed-positive-J regular region for unbounded depth is inferred.

## HR17. Exact scope of the higher-response handoff

**ESTABLISHED.** The source-tuple formulas, free-path amplitudes and higher log moduli hold for every fixed signed-or-absent pattern, including finite revealed pasts, complete pasts with future absent, and the fixed-vacuum canonical interaction patterns. Those two past conventions are distinct but both admitted. At B=1 prescribed path supports are singletons and their constant observables have zero derivatives. Empty target sets have probability one and zero derivatives. All compatible finite target atoms are positive; infinite null patterns never enter a probability denominator. Translations and the parameter-independent dressed/raw-frame lift transport the finite laws and all their derivatives, and the uniform limits preserve this covariance.

**NOT-CLAIMED.** This author lane does not assemble the complete C3 interaction norm, differentiate the varying full-past Fisher expectation twice, or compute curvature; those are root responsibilities. It supplies the required actual C3, counted moduli and regular-chart floor for those steps. It does not extend the parameter domain to critical or hard-factor boundaries, assert an all-depth nondegenerate chart, invert a vanishing tensor, prove curvature monotonicity under information contraction, identify parameter Fisher with gauge/base curvature, or append a scalar-curvature VFE penalty. The regularity and reference distinctions of the governing SPEC remain unchanged.
