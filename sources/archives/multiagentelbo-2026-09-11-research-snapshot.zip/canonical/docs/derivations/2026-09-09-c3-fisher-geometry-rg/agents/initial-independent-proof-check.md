<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753","target_digest":"aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753"} -->

# Independent initial reconstruction: higher response and Fisher geometry

Date: 2026-09-09. Revision 1. Only the new frozen problem-contract.json was read before this reconstruction. Its file SHA256 is 44dfea8ab58cc9a99fe3105e61cb8a4921080733423426b928ef0ec88b35b6e4 and target digest is aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753. No current author, root, worker, source or intake draft, and no prior next-C3 discovery note, was read. The preceding admitted UC/UP/FR/FX/GX constructions and SPEC are inputs. Shared model family, prior context and filesystem limit independence. This document supplies a direct candidate construction with exact premises and attack conditions; it assigns no ledger state. No tests, source execution, numerical science, producer, Git, GPU, tamper, vault or memory operation was performed.

## IC301. Compact constants and a signed-J continuation

Fix a compact positive-h interval inside a slightly larger compact positive-h interval. Choose J_*>0 with 12 tanh J_*<1, and work temporarily on a rectangle with abs(J)<=J_* and bounded positive h, leaving an outer h margin. This auxiliary smooth extension uses the same finite factors: 1+tanh(J)chi stays positive. Its J>=0 restriction is the original law. It is not a changed positive-J program or a claim that the finite executable admits negative inputs.

The UC finite coupling proof extends directly. Flipping an exterior plaque sign changes a field from u+J to u-J, whose Bernoulli distance is at most tanh(abs(J)); same-parity Hamming cost is at most twice that. All incidence and weight estimates use c_*=tanh J_* regardless of J's sign. Positive finite supports, the six fine-edge column count, stationary heat-bath construction and exterior integration remain identical. They prove the same all-pattern comparison, uniqueness and limits on the auxiliary rectangle, including zero. Thus continuation is proved rather than inferred by substituting a vanishing q.

Choose 0<tau<log(1/(12c_*)); write q=12c_*exp(tau)<1, C=16q/(1-q), rho=tanh(h_*+2J_*)<1, d=1-rho and m=d^2/4. The admitted joint-cylinder estimate on a common whole-block radius-n neighborhood is

    TV <= C abs(A) B^2(n+1)exp[-tau(n+1)].

A counts target block anchors. All patterns and fine exterior signs are fixed under parameter differentiation. Every derivative includes free-edge fields and every touching/crossing plaque. Ordered source tuples may coincide, with no factorial divisor. There are 3B^2 combined local source types per anchor: two field orientations and one plaque base. A plaque source has at most four support anchors within distance one of its base. Ordinary positive-J compacts use an enlarged rectangle and the same constants. The signed strip is needed separately for the product-limit certificate.

## IC302. Group decoupling and counted cumulants

This step establishes higher clustering rather than inferring it from pairwise covariance. Let F have norm at most one and finite nonempty support-anchor set A. Let T_1,...,T_r be individual bounded field or completed plaque characters at anchors v_1,...,v_r, 1<=r<=3. Put D=max_j dist_infinity(v_j,A). Contract A to a root and take a minimum spanning tree on that root and the r labeled sources. Root distances are dist(v,A), other distances ordinary anchor distances. A root-to-farthest path has at most r edges and total length at least D. Its tree's largest edge ell therefore satisfies ell>=D/r. Removing a largest edge gives two groups with every cross edge at least ell: a shorter edge would replace it and lower the tree weight. This cut property does not require the contracted weights to be a metric. Coincident sources remain distinct zero-distance vertices.

For ell>=3 the groups' actual fine supports are separated by at least ell-2. Take the whole-block radius-(ell-3) neighborhood around one group's support anchors; it excludes the other group. Conditional on all exterior fine spins, the interior is the same normalized finite specification on identical interior parity supports. UC bounds the first group's joint-law variation over those boundaries. Integrating against the other group's observable and the first group's marginal gives joint-to-product TV at most

    C(abs(A)+4r)B^2(ell-2)exp[-tau(ell-2)].

No fine-spin conditioning inside a cut block is used: the neighborhood contains entire blocks and the other group is exterior measurable. The argument applies to finite laws and their DLR limits.

Define O_n=sum_pi abs(pi)! and K_n=sum_pi(abs(pi)-1)! over partitions of n labels. K_2=2,K_3=6,K_4=26 and O_2=3,O_3=13,O_4=75. The joint cumulant is

    kappa(X_0,...,X_r)=sum_pi (-1)^(abs(pi)-1)(abs(pi)-1)!
                       product_C E[product_(j in C)X_j].

Under an independent nonempty split this is zero: the logarithm of the finite moment-generating expansion is a sum of two group logarithms, so every mixed coefficient vanishes. Expanding that logarithm yields the displayed coefficients. TV epsilon changes each bounded product moment by at most 2epsilon; a partition product changes by at most 2abs(pi)epsilon. Therefore the original cumulant is bounded by 2O_(r+1)epsilon.

For all D, including small or zero tree edges, set

    beta_r=tau/(2r),
    L_r(A)=2O_(r+1)exp(2tau)[1+2C(abs(A)+4r)/tau].

Then

    abs(kappa(F,T_1,...,T_r)) <= L_r(A)B^2exp(-beta_r D).

For ell>=3 use t exp(-tau t)<=2exp(-tau t/2)/(e tau), t=ell-2. If ell<3, D<3r and the prefactor exceeds the trivial partition bound K_(r+1). Repeated anchors are therefore included. General F contributes a factor norm(F) by multilinearity. This proves decoupling for the actual constrained law before cumulant cancellation; it does not assume a tree-product bound.

## IC303. Source summability, actual C3 and spatial moduli

Write S_p(s)=sum_(n>=0)(2n+1)^p exp(-sn), finite for s>0. There are at most abs(A)(2n+1)^2 anchors within distance n of A. Ordered r-tuples whose maximum distance is exactly n are bounded in count by [3B^2 abs(A)(2n+1)^2]^r. This overcounts the shell but includes all repeated tuples. Since L_r(A)<=abs(A)L_r({0}), define

    M_r=3^r L_r({0})S_(2r)(beta_r).

The complete absolute cumulant sum is at most norm(F)M_r abs(A)^(r+1)B^(2r+2). The tail uses the same series restricted to n>N. All source multiplicities and B powers are retained, including finite crossing sources.

For a finite normalized exponential law, r natural derivatives of E F equal kappa(F,T_i1^total,...,T_ir^total). Finite differentiation of the normalized generating function proves this; multilinearity gives the ordered local sums. Repeated parameter indices do not remove coincident sites. For each fixed tuple, UC gives uniform joint target/source convergence, hence convergence of its finitely many moments and cumulant. The near tuple set is finite; both far tails have the stated bound. Every finite derivative through order three thus converges uniformly to a continuous limit. Pass finite coordinate FTC first for the means, then for their first derivatives, then for their second derivatives. Each integral error is bounded by segment length times the uniform derivative error. Continuity of the limit proves actual C3 everywhere on the enlarged interior. This is neither a Lipschitz substitute nor an almost-everywhere claim.

An explicit spatial modulus follows as well. If two patterns agree through R>=2 about one free target, put N=floor(R/2)-1. A near r-tuple and the target use at most 1+4r anchors inside Q_(N+1). Their radius-(R-N-1) neighborhood fits Q_R, so joint TV is at most C(1+4r)B^2(R-N)exp[-tau(R-N)]. Multiplying by 2O_(r+1) and the near count yields

    2O_(r+1)C(1+4r)3^r B^(2r+2)
       (2N+1)^(2r)(R-N)exp[-tau(R-N)].

Add twice the tail

    3^r L_r({0})B^(2r+2)
      sum_(n>N)(2n+1)^(2r)exp(-beta_r n).

The same comparison holds for an oracle containing Q_R, because every near completed source is interior. At R=0,1 use 2M_rB^(2r+2). Define nu_r=tau/(8r) and

    v_r=2O_(r+1)C(1+4r)3^r
       +2*3^r L_r({0})exp(beta_r/4)S_(2r)(beta_r/2)
       +2M_r exp(nu_r).

Extracting exp[-beta_r(N+1)/2] from the tail gives the all-radius bound

    derivative difference <= v_r B^(2r+2)(R+1)^(2r+1)exp(-nu_r R).

The slowest exponent is nu=tau/24. The zeroth mean comparison is at most 2CB^2(R+1)exp[-tau(R+1)]. Each order has its own exponent before taking a common smaller one. Remote patterns can change support outside the common interior; exterior conditioning and integration never couples incompatible interior fibers.


## IC304. Actual higher response decays with depth

Leave target P free. Given all other blocks, its B spins are independent with means bounded by rho. In a product of Y_P with at most r individual source characters, each source involves at most one target coordinate. At most r coordinates are canceled or supplied by those characters. The conditional moment has magnitude at most rho^(B-r); for B<r this loose bound exceeds one and remains valid. Repeated coordinates improve it. Every cumulant partition has exactly one moment containing Y_P and its other moments are bounded by one. Hence

    abs(kappa(Y_P,T_1,...,T_r)) <= K_(r+1)rho^(B-r).

Combine with IC302 by min(U,V)<=sqrt(UV), then sum ordered sources. For 1<=r<=3,

    abs(partial_i1...ir E Y_P) <= a_r B^(2r+1)rho^(B/2),
    a_r=3^r sqrt(K_(r+1)L_r({0}))rho^(-r/2)S_(2r)(beta_r/2).

The zeroth amplitude is rho^B. These are bounds on actual cumulant derivatives, not derivatives of an envelope. They make the finite-oracle jet convergence uniform over B: choose a large-B cutoff by the amplitude, then a common radius for the finitely many remaining B.

Every cell atom is the product of two successive Bernoulli parity probabilities, with the same first parity fixed in both compared patterns. Finite conditioning changes precisely that fiber. Leibniz gives positive C3 four-state rows, and further finite sequential products give every finite coarse conditional atom. The one-cell atom is at least m=(1-rho)^2/4. Null infinite exteriors use normalized limiting versions, not infinite-event ratios. Both vacuum-hybrid and absent-future predictive rows are covered as different fixed patterns.

## IC305. Complete common C3 interaction norm

The following explicit constants are conservative. Set A=max(1,a_1,a_2,a_3), U=8A^2, U0=max(1,U), M=max(1,M_1,M_2,M_3,A), V=max(2C,v_1,v_2,v_3). Positive-order atom jets through order three are bounded by U B^8rho^(B/2), and all atom jets by U0B^8. Spatial differences of those jets, including order zero, are bounded by

    Vq B^16(R+1)^7exp(-nu R), Vq=16MV, nu=tau/24.

The factor sixteen covers eight Leibniz subsets and two choices of differing Bernoulli factor.

For an rth log derivative, the partition formula has coefficients (-1)^(abs(pi)-1)(abs(pi)-1)! multiplying p^(-abs(pi)) times the atom derivatives over its partition blocks. For r<=3 there are at most three factors and the absolute coefficient sum is at most six. The value log-odds is at most 4rho^B/d. Therefore every target-versus-vacuum log-odds jet of orders zero through three is bounded by P B^24rho^(B/2), where

    P=max(4/d,12(1+U0/m)^3).

For spatial differences telescope each product and use

    abs(p^(-k)-p'^(-k)) <= k m^(-k-1)abs(p-p'), 1<=k<=3.

A valid common bound is Q B^40(R+1)^7exp(-nu R), with

    Q=72Vq(1+U0)^3(1+m^(-1))^4.

The B^40 factor includes the denominator change multiplied by three B^8 jets and the B^16 probability difference. The same constants work on the full enlarged compact rectangle.

Keep the unchanged (+,+), lexicographic canonical interaction and every shell. Successive truncations agree through r-1. Every interaction jet through order three has singleton amplitude P B^24rho^(B/2) and shell bound

    min(2P B^24rho^(B/2), Q B^40 r^7exp[-nu(r-1)]).

The support diameter is at most 2r; at most (2r+1)^2 translates contain the origin. At lambda=nu/8=tau/192, geometric interpolation and r^(7/2)<=r^4 yield the complete norm bound

    E_B=P B^24rho^(B/2)
       +sqrt(2PQ)exp(nu/2)B^32rho^(B/4)
          sum_(r>=1)(2r+1)^2 r^4 exp(-nu r/4).

The tail is the same series restricted to r>N. All series converge and both depth factors are polynomial times geometric, so E_B tends to zero compact-uniformly. Finite shell truncations are C3 in finite orbit-value spaces. Uniform tails at all four orders permit repeated interaction-valued FTC and prove actual C3 in this one common Banach norm. No shell, translate or mixed derivative is dropped. The claim concerns the exact parameterized orbit, not an RG Frechet derivative on arbitrary interactions.

## IC306. Varying-law expectation derivatives and quasilocal shells

For a local C2 observable F_g with fixed finite support A, finite differentiation and the cumulant limits give

    partial_i E F = E F_i + sum_a kappa(F,T_(i,a)),
    partial_ij E F = E F_ij
       +sum_a kappa(F_i,T_(j,a)) +sum_a kappa(F_j,T_(i,a))
       +sum_(a,b) kappa(F,T_(i,a),T_(j,b)).

The source sums include crossing factors and coincident pairs. In finite volume these are ordinary normalized derivatives; IC303's uniform summability and FTC give the actual infinite derivatives. If every jet of F through order two has norm at most F_*, these expectation jets are bounded by

    Cobs abs(A)^3B^6 F_*, Cobs=1+2M_1+M_2.

This is the polynomial support cost from orders zero, one and two, not an unweighted infinite source bound.

For an arbitrary predecessor set S, finite or infinite, let J_S(g,omega) be the cell Fisher row with exactly S prescribed and all other parities absent. It is C2 for fixed omega because probabilities are C3 and at least m. An entry is sum_a p_i p_j/p. Its second parameter derivative, written explicitly in IC311, has four two-factor terms over p, five three-factor terms over p^2, and one four-factor term with coefficient two over p^3. There are four atom values. Product and inverse telescoping give the safe componentwise bounds

    max_(abs(alpha)<=2) norm_entry(partial^alpha J_S) <= Jc B^32,
    Jc=100(1+U0)^4(1+m^(-1))^4,

and for matching radius-R patterns,

    max_(abs(alpha)<=2)norm_entry(partial^alpha[J_S-J_T])
      <= Jd B^48(R+1)^7exp(-nu R),
    Jd=1000Vq(1+U0)^4(1+m^(-1))^4.

Here norm_entry is maximum absolute matrix entry. The constants include all four atoms and the eleven weighted second-derivative terms. The B^48 denominator-change contribution is included.

Decompose J_S as J_empty plus J_(S intersect Q_r)-J_(S intersect Q_(r-1)), r>=1. A shell is local on at most (2r+1)^2 anchors and its jets are at most JdB^48exp(nu)r^7exp(-nu r). Set

    R_B(0)=Cobs Jc B^38,
    R_B(r)=Cobs Jd exp(nu)B^54(2r+1)^6 r^7exp(-nu r), r>=1,
    M_B=sum_(r>=0)R_B(r).

By the local expectation formula, every expected shell derivative through order two is bounded entrywise by R_B(r), including the varying law. The summable series proves actual C2 of E J_S uniformly over S and the compact rectangle. Repeated FTC passes both derivative interchanges. The probability law is not frozen while differentiating this expectation.

## IC307. Actual C2 marginal Fisher-density limit

Let P be the infinite lexicographic past. At a square cell x the revealed past is S_(x,L)=(Lambda_L-x) intersect P. The actual finite marginal score-chain identity is

    I(mu_(B,Lambda_L))=sum_(x in Lambda_L)E_muB J_(S_(x,L)).

The same full law is used in every expectation. Its parameter response is explicitly accounted for in IC306. Future variables are absent, unlike the canonical vacuum hybrid.

For a radius-R bulk cell, S_(x,L) and P agree in Q_R, so their shell decompositions agree exactly through R as functions of the same configuration. The difference of their expected derivatives through order two is at most 2sum_(r>R)R_B(r). At any other cell it is at most 2M_B. There are at most 4RL nonbulk cells when L>=2R. For every abs(alpha)<=2,

    norm_entry(partial^alpha[
      I(mu_(B,Lambda_L))/L^2-E_muB J_P])
      <=2sum_(r>R)R_B(r)+8M_BR/L.

This is an actual C2 error bound. Choose R from the explicit tail, then L from the boundary term, uniformly on the compact set for fixed B. IC306 makes E J_P a C2 function and GX identifies it with the existing C0 density, so no surrogate limit is introduced. In two dimensions an operator-norm version costs a factor two. Derivatives of a PSD inequality are not asserted PSD, and no boundary-score derivative is inferred from an O(boundary) log-density error.


## IC308. An actual-density product-control rank certificate

This lower certificate works for every B, including one, and does not infer a density floor from a bounded observation alone. At J=0 fine signs are iid with mean b=tanh h in (0,1); retained disjoint parities are independent with mean r=b^B and variance v=1-r^2. Define

    a=(1-b^2)b^(B-1)/(1-b^(2B))>0, U_e=Y_e-r.

Direct conditioning on parity gives E[z_e|Y_e]=b+a U_e for any fine edge in that path. At each cell use its two outgoing paths and observables F1_x=U_(x,1)+U_(x,2), F2_x=U_(x,1)U_(x,2). At the base point their covariance matrix is diag(2v,v^2). Different cells use disjoint outgoing paths, hence are independent at J=0. The test-observable centers are frozen at that parameter when taking score pairings.

The complete covariance-source formulas give

    partial_h E F1_x=2Bav, partial_J E F1_x=4B b^3av,
    partial_h E F2_x=0, partial_J E F2_x=b^2a^2v^2.

For F1, each path has B field sources and 2B incident plaques, each intersecting it once and contributing b^3av. For F2, a nonzero source must meet both outgoing paths. Exactly the lower-left-corner plaque at that vertex does so, with one edge in each; its other two signs integrate to b^2. All other sources leave a centered independent U and vanish. This remains true for B=1 and includes crossing plaques in the actual marginal response.

Sum both F statistics over a square. Their covariance is L^2 diag(2v,v^2), and their derivative pairings are L^2 times the displayed rows. Projection of the actual marginal score onto those statistics gives a PSD Gram lower bound. Divide by L^2 and take the actual density limit:

    mathcal I_B(h,0)>=L_B(b),
    L_B=2B^2a^2v [[1,2b^3],[2b^3,4b^6]]
             +b^4a^4v^2 [[0,0],[0,1]].

This is a lower bound, not a formula suppressing other orthogonal interaction terms. Put u=2B^2a^2v and w=b^4a^4v^2. Then det L_B=uw>0, and its least eigenvalue is at least uw/[u(1+4b^6)+w]. Extensive statistics and exact product-control independence make this an actual-density certificate.

For b in [b0,b1] inside (0,1), set a0=(1-b1^2)b0^(B-1), v0=1-b1^(2B), u0=2B^2a0^2v0 and w0=b0^4a0^4v0^2. The identity a=b^(B-1)/(1+b^2+...+b^(2B-2)) gives a<=1; also a>=a0 and v>=v0. Thus

    eta_B=u0w0/[2B^2(1+4b1^6)+1]>0

is an explicit uniform eigenvalue floor at J=0. It may degenerate with B; no unbounded-depth uniform floor is claimed.

## IC309. Positive-J regular neighborhoods and identifiable law charts

IC301-IC307 prove actual C2 continuation through zero. The first J derivative of the density has operator norm at most 2M_B. Choose delta_B=min(J_*/2,eta_B/(4M_B)) when M_B>0, or J_*/2 otherwise. The density increment is at most 2M_BJ, so 0<J<delta_B has eigenvalues at least eta_B/2. Enlarge the h interval when choosing constants to obtain an open strip around the requested compact interval. A prescribed finite hierarchy takes the minimum of its positive deltas and floors. This intersection is nonempty, with no claim for all unbounded depths.

Identifiable coordinates can be exhibited from the actual law:

    Phi_B(h,J)=(E Y_(0,1), Cov(Y_(0,1),Y_(0,2))).

At zero its Jacobian is upper triangular with positive diagonal B a v and b^2a^2v^2 by IC308. It is C3 as a function of actual finite marginals. Continuity on an outer compact strip gives a positive neighborhood where its first h derivative and determinant remain positive; their zero minima and compact derivative bounds from IC303 quantify this neighborhood. Intersect with the density-floor neighborhood.

For local injectivity, multiply the observable values by the inverse Jacobian at the chosen point. On a small convex ball its derivative differs from identity by less than 1/2. Segment integration gives a distance lower bound of one half. For a smaller value ball, x -> x+y-Phi(x) is a contraction mapping a closed ball into itself; its Cauchy Picard sequence provides a local inverse. Taylor remainder and repeated differentiation give that inverse through order three. Thus these are actual identifiable statistical coordinates, not a transverse slice of a non-descending semimetric.

A single injective strip around a compact h interval is also possible. Take an inner and larger outer h strip. At J=0 the first observable strictly increases with h, giving a positive value margin between outer endpoints and inner values. Small J, quantified by the first-derivative bound, preserves the margin. Each first-observable level from the inner strip then has a unique h for all intermediate J in the outer strip. Along this level curve the second observable has derivative det(D Phi)/partial_h Phi_1>0. Equal observable pairs at distinct parameters are impossible. Those positive margins and compact derivative bounds quantify a smaller strip. Finite hierarchies again take finite intersections; no regular leaf-space or quotient theorem is assumed.

## IC310. Continuous density curvature and sign convention

On certified charts g=mathcal I_B is C2 with a positive determinant floor on compact subsets, so its inverse is C2. Define

    Gamma^l_(ij)=0.5 g^(lm)(partial_i g_(mj)+partial_j g_(mi)-partial_m g_(ij)).

Use R(X,Y)Z=nabla_X nabla_Y Z-nabla_Y nabla_X Z-nabla_[X,Y]Z and

    R^l_(k i j)=partial_i Gamma^l_(jk)-partial_j Gamma^l_(ik)
               +Gamma^l_(im)Gamma^m_(jk)-Gamma^l_(jm)Gamma^m_(ik).

The sectional curvature is K=g_(1l)R^l_(2 1 2)/det(g); scalar curvature is 2K. This is sphere-positive: on the unit sphere R(X,Y)Z=<Z,Y>X-<Z,X>Y gives K=1 for an orthonormal pair. Gamma is C1 and curvature continuous. The identity partial g^(-1)=-g^(-1)(partial g)g^(-1) is used only after the floor.

These are statistical parameter curvatures, not gauge or base curvature. Density decay does not imply curvature decay, since inverses can grow. Information contraction and its a^2 volume factor imply neither PSD derivative inequalities nor curvature monotonicity. No scalar-curvature VFE term is added.

## IC311. Complete finite third jets and metric derivatives

For a fixed finite normalized natural exponential source put a_i=T_i-E T_i, g_ij=Cov(T_i,T_j), and let kappa_ijk be the third cumulant of its complete two statistics. All free fields and touching/crossing plaques are retained. Finite normalized differentiation gives

    p_i=p a_i,
    p_ij=p(a_i a_j-g_ij),
    p_ijk=p[a_i a_j a_k-g_ij a_k-g_ik a_j-g_jk a_i-kappa_ijk].

All positive-order sums vanish and derivative tensors are symmetric. Rational b,c yield rational masses, cumulants and natural jets even though atanh coordinates may be irrational. A fixed channel projects every jet by the same full sum, q_alpha(y)=sum_x K(y|x)p_alpha(x), on fixed reachable positive support.

For fixed positive selected likelihood set u_alpha=ell p_alpha and Z_alpha=sum_x u_alpha. Differentiating u=Zq gives

    q_0=u_0/Z_0,
    q_alpha=[u_alpha-sum_(0<beta<=alpha)
       binom(alpha,beta)Z_beta q_(alpha-beta)]/Z_0.

This retains every evidence derivative. Re-centering only the first score does not yield higher posterior jets. Moving channels and likelihoods require their own product-rule jets.

Let h1,h2,h3 denote successive b derivatives of atanh b, and J1,J2,J3 the analogous c derivatives. Then

    h1=1/(1-b^2), h2=2b/(1-b^2)^2,
    h3=2(1+3b^2)/(1-b^2)^3,
    p_bb=p_hh*h1^2+p_h*h2,
    p_bbb=p_hhh*h1^3+3p_hh*h1*h2+p_h*h3,
    p_bbc=p_hhJ*h1^2*J1+p_hJ*h2*J1.

The exchanged mixed identities complete the chain rule. A first Jacobian alone is insufficient for higher jets.

For an actual positive two-parameter third jet define N=p_i p_j, N_k=p_ik p_j+p_i p_jk and N_kl=p_ikl p_j+p_ik p_jl+p_il p_jk+p_i p_jkl. Then

    g_ij=sum_x N/p,
    partial_k g_ij=sum_x[N_k/p-Np_k/p^2],
    partial_kl g_ij=sum_x[N_kl/p
       -(N_kp_l+N_lp_k+Np_kl)/p^2+2Np_kp_l/p^3].

Only third mass derivatives are needed. The two-dimensional tests g_11>0 and det(g)>0 precede inversion. The declared IC310 formula then yields exact finite connection/curvature. Chart comparisons retain all higher chain terms.

A generic jet record requires positive masses, normalization, tensor symmetry and actual smooth-family realizability. If a normalized symmetric Taylor-polynomial family is intentionally admitted, its positive zeroth masses give positivity near the base point and zero derivative sums preserve normalization. That local family must be declared, not silently attributed to the spatial source.

No current source or primitive was inspected in this initial pass. Mature review must check suitable existing exact-engine reuse, complete factor/normalizer coverage, explicit larger enumeration access, and singular inverse rejection. A finite packet can check polynomial derivatives, fixed-channel towers, quotient jets and coordinate-consistent curvature, but cannot prove the infinite C3/C2 or density floor.

## IC312. Attacks and pending obligations

Pairwise decay without group decoupling does not prove fourth-cumulant summability. Source-anchor separation must pay support offsets and use whole blocks. Repeated tuples and crossing factors cannot be dropped. Actual cumulants and repeated FTC, not differentiated envelopes, establish higher response. Vacuum-future and absent-future rows differ. Varying-law expectations need the covariance and third-cumulant terms in IC306. A finite law's rank alone does not imply a density floor: IC308 instead uses extensive independent product-control statistics. Signed-J continuation is proved first. Finite-hierarchy minima do not imply a single positive-J chart for every depth. A semimetric is not inverted before a floor and does not automatically descend to a quotient.

This is a full candidate reconstruction with loose explicit constants. Its source counts, support conditions, cut argument, actual-density floor and curvature convention remain available for challenge. No counterexample within these premises was constructed. Remaining work is to compare mature author/root statements and implementation only after root authorizes access, and inspect real retained evidence when provided. No new draft/source access occurs before that authorization, and no ledger state is assigned.
