<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753","target_digest":"aff974a184ea29ffbf579af7ba4ac13dde78dea321dd07339db7a0bc7dfa8753"} -->

# Next full RG operator contract

Date: 2026-09-09. **OPEN: DISCOVERY ONLY, PROPOSED NEXT TARGET.** This note is excluded from the current C3 theorem evidence and makes no new closure assignment. Its author also authored HR and reviewed the root density interface. Only this note is written. The current SPEC is unchanged, SHA256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. The live completion roadmap was read, including R3 and R6-R8 and its subsequent spatial, uniform-depth and first-response updates. The present C3 contract and completed root construction supply the more recent geometry scope; historical open sentences about C3 in the roadmap must not be treated as current obstructions.

## The next load-bearing obligation

**DEFINITION.** The proposed next unit is an exact, continuously differentiable path-blocking operator on a small open Banach neighborhood of the fair-product interaction, together with an explicit linearization and a nonlinear remainder proving local attraction. Use a fixed integer factor a=2 first; admitting a=3 on a common smaller neighborhood gives the existing two/three/six scheme comparison. This moves R3's nonlinear-relevance and R6's common-endomorphism obligations forward. It does not replace the full RG goal by a finite-dimensional fit or a new memory refinement.

**ESTABLISHED INPUT SCOPE.** UP05 gives an exact integer action on the canonical orbit: R_a Phi^(B)=Phi^(aB), with complete interactions converging in a common exponential norm. HR/DG now give actual C3 every-pattern laws and interaction response, actual C2 marginal Fisher density, and locally identifiable regular law charts for each fixed B or prescribed finite hierarchy. Those derivatives vary the original two source parameters. They neither define the RG map for arbitrary perturbations of its input interaction nor bound its derivative in such directions. The just-proved geometry therefore leaves precisely the neighborhood obligation named by R3/R6. SPEC's declared reference-space identification and distinction between an autonomous map and a cocycle remain mandatory.

**NOT-CLAIMED.** The new local theorem would supply a stable high-noise basin for a specified channel and norm. It would not prove critical universality, a continuum field measure, all-scheme equivalence, a continuous beta function, or a physical clock. Other R7/R8 obligations remain separate; none is a prerequisite for the local operator theorem within this already admitted lattice model.

## A concrete space and representative

**HYPOTHESIS.** Keep the same square lattice of dressed signs z_e, with two outgoing edges per cell and the same straight, disjoint retained a-paths. Coarse coordinates are identified with the same oriented two-sign cell lattice by x -> ax; normalized counting is pushed to normalized counting. Retain independent uniform frames to lift every dressed interaction to the normalized raw gauge-covariant model. Allow arbitrary real translation-invariant coefficients, including many-body and long-range terms, inside the declared small ball. This is an infinite-dimensional neighborhood, not the positive two-parameter surface.

**DEFINITION.** Write a character as chi_S(z)=product_(e in S) z_e for a nonempty finite set of distinct edge copies. In finite volume use the energy convention H_J=-sum_S J_S chi_S, with every touching source and exterior reduction specified. Let diam(S) be the Chebyshev diameter of its edge anchors. A candidate source/target norm, using the same lattice identification at every step, is

\[
 \|J\|_{\kappa,\lambda}
 =\sup_e\sum_{S\ni e}|S|e^{\kappa|S|+\lambda\operatorname{diam}(S)}|J_S|,
 \qquad \kappa>0,\quad\lambda>0.
\]

The space is the complete translation-invariant weighted coefficient space, with nonempty supports only. Scalar energy constants are tracked separately with their partition-function shift. They do not change the normalized law or its VFE. This coefficient convention is a choice of interaction representative; it is unrelated to the physical vertex-frame gauge.

**ESTABLISHED DIRECT CHECK, NOT NEW TARGET EVIDENCE.** Absolutely summable consolidated Walsh coefficients have no residual null interaction. The conditional half-log-odds at edge e is sum_(S containing e) J_S chi_(S without e). Integrating it against each character under the independent fair exterior recovers that coefficient. If every conditional energy difference vanishes, each coefficient is zero. Thus this representative is injective at the specification level, modulo the omitted scalar. Extracting it from an arbitrary quasilocal specification with the proposed weighted absolute convergence is a further existence obligation, not a consequence of the formula.

**OPEN.** The current vacuum/lexicographic shell representative and this coefficient representative need a proved conversion on any shared domain. In particular, UP/DG's diameter-exponential norm does not imply the displayed cardinality-exponential norm. For translated square supports S_R with cardinality proportional to R^2, the single-character coefficient exp(-2lambda R)/|S_R| has old norm of order exp(-lambda R), whereas its new norm contains a factor of order |S_R|exp(kappa|S_R|-lambda R). This grows. A sequence of such terms can have finite old norm and infinite new norm. Consequently old all-depth C0 convergence does not establish eventual entry into this stronger ball. Small nonzero original h,J do belong to it and retain genuine matter-link and plaquette coupling. Extending entry to every previously admitted compact positive-h family requires an additional bound or a different norm; it must stay explicit in the next contract.

## The finite derivative that the operator must realize

**ESTABLISHED DIRECT FINITE CHECK, NOT NEW TARGET EVIDENCE.** On a finite collection of whole retained paths and unused edges, let nu be independent fair signs and C the deterministic parity channel. For a normalized exponential tilt p_t proportional to exp(tF)nu, its retained score at t=0 is

\[
 \left.\partial_t\log\frac{d(C_*p_t)}{d(C_*\nu)}\right|_{t=0}
 =\mathbb E_\nu[F\mid C]-\mathbb E_\nu F.
\]

This follows by differentiating both finite sums and their normalizer. Given all parities, the reference factors over the path blocks and the unused singletons. A nonempty proper subset of one path has zero character mean on either fixed-parity support: flip one included bit and one excluded bit. An unused fair bit also kills the expectation. A complete path contributes its declared parity. Therefore

\[
 \mathbb E_\nu[\chi_S\mid Y]
 =\begin{cases}
 \chi_T(Y),&S=\operatorname{lift}_a(T),\\
 0,&\text{otherwise},
 \end{cases}
 \qquad
 \operatorname{lift}_a(T)=\bigcup_{p\in T}p.
\]

The empty character is precisely the removed scalar. For an independently specified finite periodic geometry without edge-copy aliases, this yields the candidate infinite linear operator

\[
 (L_aJ)_T=J_{\operatorname{lift}_a(T)}.
\]

Translation invariance does not add an a^2 coefficient: the uniquely specified lifted set has one consolidated coefficient. Other translates that fail the union-of-complete-paths condition vanish. Density comparisons per original area still retain their separate a^2 factor. Passing this finite identity to the derivative of the infinite-volume operator requires the uniform derivative-limit proof below.

**ESTABLISHED DIRECT COEFFICIENT CHECK, NOT NEW TARGET EVIDENCE.** The paths are disjoint, so |lift_a(T)|=a|T|. Each lifted path contains its first edge at anchor ax, hence diam(lift_a(T))>=a diam(T). For T containing a designated coarse edge e, its lift contains the corresponding first fine edge. The lift is injective. Comparing the positive weighted sums gives

\[
 \|L_aJ\|_{\kappa,\lambda}
 \le\ell_a\|J\|_{\kappa,\lambda},
 \qquad
 \ell_a=a^{-1}e^{-\kappa(a-1)}<1\quad(a\ge2).
\]

The factor a^(-1) comes from the cardinality prefactor; the exponential uses |T|>=1. This is a bounded operator on the proposed coefficient space, whether or not the nonlinear RG has yet been constructed there. Its support rule also gives L_a L_d=L_(ad). Neither statement alone proves a nonlinear stability theorem.

## Required nonlinear construction and stopping criteria

**OPEN.** Freeze a positive radius epsilon and finite M_a, computed from kappa, lambda and the selected block factors. For every real J with norm less than epsilon, construct its unique fine Gibbs law, its exact path pushforward, an everywhere-defined coarse specification under every parity exterior, and its unique coefficient representative R_aJ in the same Banach space. Prove that R_a is Frechet C1 and, uniformly on the ball,

\[
 R_a0=0,\qquad DR_a(0)=L_a,\qquad
 \|R_aJ-L_aJ\|\le M_a\|J\|^2,
\]

\[
 \|DR_a(J)-L_a\|\le2M_a\|J\|.
\]

An alternative explicit derivative modulus is acceptable if it supplies the same local attraction. A map only into a successively weaker norm does not satisfy the proposed endomorphism contract. Its scale loss would instead require an explicitly typed Banach-scale result and a separate iteration theorem.

**OPEN.** A plausible direct route begins with finite constrained references nu_y: independent uniform fixed-parity path blocks and fair unused singletons. Expand log E_(nu_y)exp(sum J_S chi_S), and subtract the same normalizing scalar used in the exact pushed law. The finite moment-partition identity makes log coefficients connected cumulants. Independence is between reference blocks, so connectedness must use the graph in which source supports meet a common path or singleton block, not merely overlap as fine sets. Source tuples that repeat, all support sizes, and all crossing sources must be counted. An absolute rooted-tree or connected-collection majorant must bound the complete output Walsh coefficient sum in the displayed norm, uniformly over volumes and parity exteriors. It must also bound one and two interaction-direction insertions to prove the Frechet remainder, not just directional derivatives along h,J.

**OPEN.** The same bound must retain the gain from a|T| fine bits for an output character T and pay for connections through the length-a reference blocks and for coarse spatial rescaling. General small-interaction finite coupling can establish fine and constrained uniqueness, but uniqueness alone does not establish absolute Walsh norm closure or analyticity of the infinite log expansion. Finite derivatives, uniform summability, and repeated FTC can give the required actual C1 map if the counted majorants are proved. A named cluster theorem is an alternative only after its full primary statement, constrained reference, support norm, exterior uniformity and differentiability hypotheses are read and mapped. No such theorem is imported by this note.

**OPEN.** Once the estimates hold, choose epsilon smaller if necessary so ell_a+M_a epsilon<1. Then the ball maps into itself and iteration contracts radially toward zero at that explicit rate. This is the required nonlinear stability statement. Exact composition follows from the independently fixed geometric path composition, equality of pushed laws, and uniqueness of the coefficient representative. For factors two and three take one common positive radius; compositions must remain in it. Direct-six agreement is equality of the resulting full laws and representatives, not equality after an unrecorded interaction truncation. No spectral classification beyond the proved operator bound is required for this first contract.

## Hand falsifiers and the finite adapter

**ESTABLISHED DIRECT FINITE CHECKS, NOT NEW TARGET EVIDENCE.** A two-bit path with energy -t z_1z_2 has retained law proportional to exp(tY). Its coarse coefficient changes linearly, so the full derivative cannot be declared zero merely because the original field and elementary plaquette directions vanish under a>=2 blocking. By contrast, independent fields u z_1+v z_2 give coarse field atanh(tanh(u)tanh(v)); each first derivative at zero vanishes, while the mixed second derivative is one. The same mixed effect occurs with an unused bit w and source terms u z_1w+v z_2w. Thus discarding individually killed characters before nonlinear blocking loses generated interactions. With a=1, L_1 is the identity; retaining individual bits by decimation likewise preserves a field direction. Any claimed strict contraction that ignores the chosen parity channel is false.

**OPEN.** The smallest new adapter is a finite fixed-reference conditional-character transform, using the existing exact mass-jet/channel primitives. Inputs are an explicit inventory of disjoint retained paths and unused bit copies, a list of signed character supports, and exact source coefficient directions. Outputs are the normalized retained first and second mass/log-density jets, the complete Walsh coefficient tables including the separately recorded scalar, and an exact comparison with the union-of-paths rule. A three-bit case covers both killing and mixed regeneration; a six-bit single path split as two-by-three versus three-by-two covers the independent direct-six geometry. Enumerating at most six signs is sufficient for this adapter. Its complete finite transform is an implementation check, not evidence for the infinite norm bound or a spectral exponent. No adapter, tests or producer are executed in this discovery task.

**OPEN.** The prospective contract fails affirmatively if the weighted coefficient sum cannot be made invariant on any claimed radius, if the proposed majorant depends on volume or a selected exterior, if an actual derivative differs from the conditional-character operator, or if the normalization/representative conversion changes a finite conditional ratio. A result in a weaker norm, a divergent higher-body coefficient tail, or a missing entrance bridge is an explicitly remaining obligation. Numerical smallness along the old orbit cannot replace any of them.

## Geometry and normalized inference remain attached

**NOT-CLAIMED.** All admitted dressed interactions lift through the existing raw frame/reference construction; a path character is an open Wilson line dressed by endpoint matter, and closed path products retain holonomy information. This does not identify discrete gauge curvature with Fisher curvature or curvature on the contextual base. The current regular Fisher charts remain point-dependent and fixed-B constructions. At the fair-product limit a particular source parameterization can lose rank, so this operator theorem must not invert its vanishing Fisher density. A curvature-dependent prior or likelihood is a new normalized model with its own partition function and derivatives; a scalar curvature does not become an additional VFE penalty by declaration. A continuous scale, universal class, base coarse map or physical duration still needs its separately stated model and theorem.
