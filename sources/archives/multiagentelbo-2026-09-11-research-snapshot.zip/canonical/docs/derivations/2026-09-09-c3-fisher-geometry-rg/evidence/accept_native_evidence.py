"""Root intake of currently read mathematical/source evidence and one retained packet."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[4]
RUN=Path(__file__).resolve().parent.parent
VERIFY=ROOT/"docs/verification/2026-09-09-c3-fisher-geometry"
PROPOSALS=("higher-response-claims.json","density-geometry-claims.json","finite-geometry-claims.json")

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main() -> None:
    destination=RUN/"evidence/native-intake.json"
    assert not destination.exists()
    c=json.loads((RUN/"problem-contract.json").read_text(encoding="utf-8"))
    meta={k:c[k] for k in ("schema_version","contract_id","target_digest")}
    coverage=json.loads((RUN/"agents/coverage-proposals.json").read_text(encoding="utf-8"))
    proposals=[json.loads((RUN/"agents"/p).read_text(encoding="utf-8")) for p in PROPOSALS]
    ids=[x["id"] for p in proposals for x in p["claims"]]+["target"]
    assert len(ids)==len(set(ids))==42 and set(ids)=={x["claim_id"] for x in coverage["claims"]}
    assert not coverage["pending"]
    assert {"FG05-REGULAR-PATH","MC05-CONTRAST-BOUND"} <= {x.get("id") for x in coverage["resolved_findings"]}
    assert all(sha(ROOT/p)==h for p,h in coverage["bindings"].items())
    dep={x["id"]:x.get("dependencies",[]) for p in proposals for x in p["claims"]}
    dep["target"]=ids[:-1]
    assert all(set(x["dependencies"])==set(dep[x["claim_id"]]) for x in coverage["claims"])
    commands=list(VERIFY.glob("*.command.json"));results=list(VERIFY.glob("*.result.json"));xmls=list(VERIFY.glob("*.xml"))
    assert len(commands)==len(results)==len(xmls)==1
    command=json.loads(commands[0].read_text(encoding="utf-8"));result=json.loads(results[0].read_text(encoding="utf-8"))
    assert result["returncode"]==0 and all(result[k] for k in ("source_unchanged","driver_unchanged","contract_unchanged"))
    assert sha(commands[0])==result["command_receipt_sha256"] and sha(xmls[0])==result["junit_sha256"]
    assert sha(xmls[0].with_suffix(".log"))==result["log_sha256"]
    assert all(sha(ROOT/p)==h for p,h in command["source_sha256"].items())
    assert sha(VERIFY/"run_fisher_geometry_tests.py")==command["driver_sha256"]
    assert sha(RUN/"problem-contract.json")==command["contract_sha256"]
    assert hashlib.sha256(json.dumps(command["command"],sort_keys=True).encode()).hexdigest()==command["command_sha256"]
    assert hashlib.sha256(json.dumps(command["config"],sort_keys=True).encode()).hexdigest()==command["config_sha256"]
    assert command["config"]["nodes"]==["tests/rg_v2/test_spatial_fisher_geometry.py"]
    assert command["config"]["maximum_enumerated_free_edges"]==6
    cases=ET.parse(xmls[0]).getroot().findall(".//testcase")
    case_ids=[x.get("classname")+"::"+x.get("name") for x in cases]
    assert len(case_ids)==len(set(case_ids))==29
    assert not any(x.find(k) is not None for x in cases for k in ("failure","error","skipped"))
    assert sha(RUN/"agents/initial-independent-proof-check.md")=="d36e4a3314b2d4020c849aad3c85cbcd09cb762e066d0e5186913f99cb5daf1b"
    assert sha(RUN/"agents/initial-proof-check-proposals.json")=="4e97d2189c22248e96167fe96e84ff4f3909728903110d2778ceb3a1d11c11f2"
    context=json.loads((RUN/"evidence/source-record.json").read_text(encoding="utf-8"))
    assert all(sha(ROOT/p)==h for p,h in context["existing_inputs_sha256"].items())
    read=set(coverage["bindings"])|set(command["source_sha256"])|set(context["existing_inputs_sha256"])
    for p in (RUN/"agents").iterdir():
        if p.is_file() and not p.name.startswith("next-"):
            read.add(p.relative_to(ROOT).as_posix())
    for rel in ("evidence/primary-source-context.md","evidence/source-record.json",
                "evidence/root-execution-preflight.json","evidence/root-result-readback.json",
                "evidence/assemble_native_record.py","evidence/run_structural_checks.py","evidence/accept_native_evidence.py"):
        read.add((RUN/rel).relative_to(ROOT).as_posix())
    read.add("docs/superpowers/plans/2026-09-09-c3-fisher-geometry.md")
    read.add("docs/verification/2026-09-09-c3-fisher-geometry/deliver_to_desktop.py")
    data={**meta,"timestamp_utc":datetime.now(timezone.utc).isoformat(),"accepted_current_scoped_evidence":True,
          "read_artifact_sha256":{p:sha(ROOT/p) for p in sorted(read)},
          "read_scope":"Root read complete current author/root/independent/source/test/driver/coverage artifacts and the actual reused inverse and score/path seams. Ancestor hashing binds admitted prior inputs; it does not assert a new full-module audit.",
          "root_assessment":"Actual joint group decoupling and complete cumulant sums establish C3 by uniform limits and FTC. Complete shells give the common interaction norm. Polynomially weighted quasilocal response differentiates both the Fisher observable and its full-law expectation, yielding the actual marginal C2 limit. Actual conditional and extensive product controls give regular charts, and the finite rank/curvature formulas retain their genuine premises. The combined API's regular-path premise was repaired in FG05 without code or evidence changes.",
          "mathematical_basis":"Direct derivations with preserved initial independent source-counting, varying-law and extensive product-control reconstruction; no finite result is promoted to an infinite quantifier.",
          "numeric_basis":"One retained29-distinct-case packet, zero failures/errors/skips; suite1.955 seconds. Raw source/config/command/runtime/JUnit bindings were checked without replay.",
          "algorithm_interpretation":"FG01-FG06 are conditional source-to-finite-recurrence identities; FGN01 is the separate execution observation.",
          "limits":["Full RG remains active; only this frozen C3/C2 regular-geometry contract closes.",
                    "No open-neighborhood RG, critical/continuum or universal curvature limit is established.",
                    "Fixed-B and finite-hierarchy regular charts need not have a common unbounded-depth neighborhood.",
                    "Shared model family/context/filesystem limit independence; exact initial snapshots remain bound.",
                    "Python3.12 tiny source compatibility does not change package Python>=3.14.",
                    "Next-operator discovery is excluded from theorem evidence."],
          "user_excluded_not_run":["tamper/corruption/forgery checks"]}
    destination.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"accepted_read_artifacts":len(read),"coverage_claims":len(ids),"distinct_tests":len(case_ids),"intake_sha256":sha(destination)}))
if __name__=="__main__":
    main()
