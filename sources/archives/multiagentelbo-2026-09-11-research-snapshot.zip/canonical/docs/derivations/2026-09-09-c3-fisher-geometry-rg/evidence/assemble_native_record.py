"""Assemble root-accepted current derivations and one retained exact packet; no science replay."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[4]
RUN=Path(__file__).resolve().parent.parent
VERIFY=ROOT/"docs/verification/2026-09-09-c3-fisher-geometry"
ROUTES=(("higher-response-claims.json","higher-response-construction.md"),
        ("density-geometry-claims.json","density-geometry-construction.md"),
        ("finite-geometry-claims.json","finite-geometry-implementation.md"))

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def dump(name: str, value: object) -> None:
    (RUN/name).write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8")

def main() -> None:
    assert not (RUN/"evidence/native-adjudication.json").exists()
    contract=json.loads((RUN/"problem-contract.json").read_text(encoding="utf-8"))
    meta={k:contract[k] for k in ("schema_version","contract_id","target_digest")}
    intake=json.loads((RUN/"evidence/native-intake.json").read_text(encoding="utf-8"))
    assert intake["accepted_current_scoped_evidence"]
    assert all(sha(ROOT/p)==h for p,h in intake["read_artifact_sha256"].items())
    commands=list(VERIFY.glob("*.command.json"));results=list(VERIFY.glob("*.result.json"));xmls=list(VERIFY.glob("*.xml"))
    assert len(commands)==len(results)==len(xmls)==1
    command=json.loads(commands[0].read_text(encoding="utf-8"));result=json.loads(results[0].read_text(encoding="utf-8"))
    assert result["returncode"]==0 and all(result[k] for k in ("source_unchanged","driver_unchanged","contract_unchanged"))
    assert sha(commands[0])==result["command_receipt_sha256"] and sha(xmls[0])==result["junit_sha256"]
    assert sha(xmls[0].with_suffix(".log"))==result["log_sha256"]
    assert all(sha(ROOT/p)==h for p,h in command["source_sha256"].items())
    assert sha(VERIFY/"run_fisher_geometry_tests.py")==command["driver_sha256"]
    assert sha(RUN/"problem-contract.json")==command["contract_sha256"]
    tree=ET.parse(xmls[0]).getroot();cases=tree.findall(".//testcase")
    names=[c.get("classname")+"::"+c.get("name") for c in cases]
    assert len(names)==len(set(names))==29
    assert not any(c.find(tag) is not None for c in cases for tag in ("failure","error","skipped"))
    raw={p.relative_to(ROOT).as_posix():sha(p) for p in VERIFY.iterdir()
         if p.is_file() and not p.name.startswith(("deliver_","delivery"))}
    science={**meta,"source_sha256":command["source_sha256"],"raw_artifact_sha256":raw,
             "execution_history":[dict(path=results[0].relative_to(ROOT).as_posix(),sha256=sha(results[0]),**result)],
             "latest_cases":dict(distinct=29,passed=29,failed=0,errors=0,skipped=0,execution_total=29),
             "junit_cases":names,"junit_packet":dict(path=xmls[0].relative_to(ROOT).as_posix(),sha256=sha(xmls[0]),
             suites=[s.attrib for s in tree.findall(".//testsuite")]),
             "runtime":command["runtime"],"config":command["config"],
             "user_excluded":["tamper/corruption/forgery checks"],
             "unrun":["old tests/producers","held S1-S3","broad suite","spatial laws above six free edges","GPU science"],
             "scope":"One retained exact finite packet; infinite and universal claims require the separate direct derivations."}
    dump("evidence/scientific-record.json",science)
    for path in (commands[0],results[0],xmls[0]):
        (RUN/"evidence"/path.name).write_bytes(path.read_bytes())
    claims=[];evidence=[];edges=[];attacks=[]
    def ev(eid: str, kind: str, path: str, scope: str, conditions: list[str]) -> str:
        evidence.append(dict(id=eid,kind=kind,supports=True,scope=scope,side_conditions=conditions,
                             artifact_path=path,artifact_sha256=sha(RUN/path)))
        return eid
    def add(cid: str, statement: str, scope: str, kind: str, conditions: list[str],
            falsifier: str, eids: list[str], deps: list[str]) -> None:
        claims.append(dict(id=cid,statement=statement,quantifiers=scope,kind=kind,falsifier=falsifier,
                           target_digest=meta["target_digest"],state="EVIDENCE_VERIFIED",assumption_ids=[],
                           explicit_assumptions=conditions,evidence_ids=eids,bridge_premise_ids=[]))
        edges.extend({"from":cid,"to":dep} for dep in deps)
        attacks.append(dict(id="attack-"+cid,claim_ids=[cid],attack=falsifier,
            response="The individually indexed current coverage entry reconstructs this falsifier against its proof, actual source path and retained finite scope.",
            disposition="REJECTED",artifact_path="agents/coverage-review.md",artifact_sha256=sha(RUN/"agents/coverage-review.md")))
    for proposal,proof in ROUTES:
        author=json.loads((RUN/"agents"/proposal).read_text(encoding="utf-8"))
        for item in author["claims"]:
            cid=item["id"];conditions=list(item.get("assumptions",[]))
            scope=item.get("quantifiers","For the stated admitted finite inputs and successful completion of the documented exact path.")
            numeric=item["kind"]=="NUMERICAL_OBSERVATION"
            algorithm=item["kind"]=="CODE"
            if numeric:
                assert item.get("execution_status") not in ("NOT_RUN","PENDING")
                kind="NUMERICAL_OBSERVATION"
                eids=[ev("execution-"+cid,"NUMERICAL","evidence/scientific-record.json",item["statement"],conditions),
                      ev("junit-"+cid,"NUMERICAL","evidence/"+xmls[0].name,item["statement"],["Raw retained 29-case JUnit; not a replay."])]
            else:
                kind="MATHEMATICAL"
                if algorithm:
                    conditions.append("Conditional finite algorithm identity: actual-family/producer-valid input, the stated admission and completed exact arithmetic. Adapter input/stored-output guards do not instrument every old primitive operation.")
                eids=[ev("proof-"+cid,"DERIVATION","agents/"+proof,item["statement"],
                         [item.get("derivation",item.get("proof_section","")),*conditions]),
                      ev("check-"+cid,"DERIVATION","agents/independent-proof-check.md",item["statement"],
                         ["Persisted initial pre-access construction plus mature reconstruction; shared model family and filesystem disclosed."])]
                if algorithm:
                    eids.append(ev("execution-"+cid,"NUMERICAL","evidence/scientific-record.json",item["statement"],
                                   ["Finite exact checks supplement the source derivation and do not prove infinite quantifiers."]))
            add(cid,item["statement"],scope,kind,conditions,item["falsifier"],eids,list(dict.fromkeys(item.get("dependencies",[]))))
    target=contract["target"]
    add("target",target["statement"],target["quantifiers"],"MATHEMATICAL",[],target["falsification_criterion"],
        [ev("target-proof","DERIVATION","construction-or-strongest-theorem.md",target["statement"],
            ["Only the frozen C3/C2 regular Fisher geometry contract; the full RG goal remains active."])],
        [c["id"] for c in claims])
    ids=[c["id"] for c in claims]
    assert len(ids)==len(set(ids))==42 and all(e["from"] in ids and e["to"] in ids for e in edges)
    dump("claim-ledger.json",{**meta,"assumptions":[],"evidence":evidence,"claims":claims})
    dump("dependency-dag.json",{**meta,"edges":edges})
    reconstruction=dict(claim_ids=ids,method="Exact preserved initial independent construction, then mature per-claim proof/source/current-output comparison.",
        result="PASS",conclusion="The frozen actual C3, common norm, actual C2 density, regular chart and finite adapter obligations have current direct evidence at their stated scope.",
        artifact_path="agents/coverage-review.md",artifact_sha256=sha(RUN/"agents/coverage-review.md"))
    dump("adversarial-report.json",{**meta,"attacks":attacks,"independent_reconstruction":reconstruction,
        "oracle_erasure":{**reconstruction,"method":"Remove favorable expectations and finite successes; reconstruct group decoupling, counted cumulants, FTC and complete shells, varying-law response, actual marginal score/boundary passage, product-control density floors and normalized finite curvature algebra."}})
    families=[
        ("higher-constrained-response",[i for i in ids if i.startswith("HR")],
         "Group-decoupled cumulants, complete ordered source sums, actual C3 limits, higher amplitudes and conditional-score product rank."),
        ("actual-density-and-geometry",[i for i in ids if i.startswith("DG")],
         "Complete common interaction norm, polynomially weighted quasilocal response, actual marginal C2 limit, regular finite-atom law charts and continuous curvature."),
        ("exact-finite-jets",[i for i in ids if i.startswith("FG")],
         "Full finite normalized jets, fixed channel/evidence calculus, actual higher chart terms, exact admitted inverse and one bounded packet.")]
    dump("approach-registry.json",{**meta,"mechanism_families":[
        dict(family_id=fid,core_mechanism=mechanism,target_obligation_ids=cids,
             representation="The unchanged normalized spatial law, full generated interaction, actual marginal Fisher density and exact fixed-carrier jets.",
             invariant_or_obstruction="Every touching source, fixed support/reference, actual derivative limits, positive-minor/eigenvalue admission and separate curvature index spaces.",
             obligations=["Retain the explicit compact, boundary, fixed-B/finite-hierarchy and completed-exact-operation premises."],
             bridge="Direct derivation followed only by the specified uniform limits.",
             failure_test="A current binding discrepancy or an admitted counterexample to the stated derivative, rank, normalization or source recurrence.",
             verified_results=cids,open_gaps=[],novelty_fingerprint="Direct scoped construction; no novelty claim.",
             disposition="Established under the frozen contract premises.") for fid,cids,mechanism in families]})
    strongest="Actual C3 constrained laws and complete interactions, actual C2 square-marginal Fisher-density convergence, exhibited fixed-B and finite-hierarchy regular law charts, continuous curvature, and source-faithful finite third-order jets/geometry."
    limitations=["The full RG program remains active; no open-neighborhood RG operator, critical/continuum theory or universality theorem is claimed.",
                 "Regular regions and floors may depend on B; no common positive-J regular chart or curvature limit for unbounded depth.",
                 "One 29-case finite packet, at most six free edges; mathematical limits use direct derivations.",
                 "Gauge, Fisher and base curvature remain distinct; no automatic scalar-curvature VFE penalty.",
                 "Source-injected Python3.12 evidence does not change the package Python>=3.14 requirement."]
    dump("release.json",{**meta,"checkpoint":"Current proofs, conditional source identities and retained exact packet assembled.",
        "target_claim":"target","terminal_status":None,"certificate_claim":"target","strongest_result":strongest,
        "unresolved_obligations":[],"limitations":limitations})
    dump("evidence/native-adjudication.json",{**meta,
        "method":"Root reads and accepts direct proofs and exact output after separate reconstruction; neither a vote nor structural validation supplies the proof.",
        "totals":dict(claims=len(claims),mathematical=sum(c["kind"]=="MATHEMATICAL" for c in claims),
                      numerical=sum(c["kind"]=="NUMERICAL_OBSERVATION" for c in claims)),
        "algorithm_claim_interpretation":"Source-to-recurrence correspondence under admitted regular/actual-family premises; finite output is separately numerical.",
        "claims":{c["id"]:dict(state=c["state"],kind=c["kind"],evidence_ids=c["evidence_ids"]) for c in claims}})
    print(json.dumps(dict(claims=len(claims),evidence=len(evidence),edges=len(edges),attacks=len(attacks))))
if __name__=="__main__":
    main()
