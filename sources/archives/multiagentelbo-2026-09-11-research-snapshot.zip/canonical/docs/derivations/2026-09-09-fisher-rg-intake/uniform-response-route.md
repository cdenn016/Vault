<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Uniform parameter-response route

Date: 2026-09-09. **DISCOVERY INTAKE; NO THEOREM CLOSURE.** This note records the bounded route investigated before the parameter-response proof run. The metadata binds its handoff to the subsequently frozen fisher-response-rg contract, not a retrospective certification of this discovery. The author previously wrote the UC coupling argument and shares the root's mathematical interface; this is not independent corroboration. No source, test, experiment, producer, vault, Git or prior artifact is changed. The separate proof run must establish the following claims with their constants before reuse.

## What the previous limit does and does not supply

The delivered UC construction gives every signed-or-absent constrained path law, actual coarse conditional rows, their uniform positivity, and weighted spatial comparison for every integer B on 0<c<1/12. The UP argument constructs the complete exact interaction in a common exponentially weighted norm and proves its value converges to zero as B grows. Neither result establishes parameter derivatives merely by its value bound. For example, the positive binary row p_n(t)=1/2+sin(n^2 t)/(4n) converges uniformly to 1/2 while its derivative has magnitude n/4 at zero. Even uniform Lipschitz convergence need not give differentiability of the limit: sqrt(t^2+1/n^2) converges to |t|. Thus differentiating the existing interaction estimate is not an admissible response argument.

The unchanged model has natural parameters (h,J)=(atanh b,atanh c). Its finite constrained log density, relative to the parameter-independent restricted counting reference, is h times the sum of free edge signs plus J times the sum of every plaquette character touching a free edge, including crossing plaquettes completed by fixed fine exterior signs. A fixed-support finite expectation therefore has exact covariance derivatives. The question is whether those sums have uniform infinite-volume limits and whether derivatives retain sufficient spatial decay for the complete interaction.

## Finite real-parameter comparison

Work on a slightly enlarged compact rectangle contained in 0<h<infinity and 0<J<atanh(1/12). Let c_* be its maximum tanh J and choose tau>0 with q=12c_* exp(tau)<1. Set z=exp(-tau), rho=tanh(h_*+2J_*)<1, and

\[
W=1+\frac{8z}{(1-z)^2},\qquad
A_B=\rho^{B-1}\left[B+\frac{8c_*e^\tau W}{1-q}B^2\right].
\]

A single local coordinate-field change Delta has same-parity Hamming transport at most 2tanh(|Delta|/2)<=|Delta|: maximally couple the selected bit, then use the one-bit opposite-parity coupling for the remaining coordinates when needed. Conditional on a fine exterior, each path coordinate field is h+J a_e, a_e in {-2,0,2}. Consequently two parameter values give row forcing at most |block| times u=|dh|+2|dJ|. The old weighted stationary argument, retaining its fine-edge column count six and anchor weight transfer exp(tau), gives total weighted Hamming at most 2B^2 W u/(1-q).

For an unconstrained target path, its conditional parity mean is the product of its B local tanh fields. A plaquette never meets this straight path twice. The product has magnitude at most rho^B; its direct parameter change is at most B rho^(B-1)u. Changing exterior edge j changes it by at most 2c_* n_(P,j)rho^(B-1), where n_(P,j)<=2, and every such j has anchor distance at most one. Combining this oscillation with the coupled law comparison yields |dm_B|<=A_B u for actual finite-volume parity means. Hence their analytic derivatives satisfy |partial_h m_B|<=A_B and |partial_J m_B|<=2A_B. This argument controls derivatives through actual differences of the laws. It does not differentiate a value estimate.

## Localized response removes the derivative-limit obstruction

Center weights at the target path's anchor. Perturb one free edge field, keeping the rest of the law fixed. Its weighted forcing is at most |Delta| exp(-tau|anchor(e)|), so the finite covariance satisfies

\[
|\operatorname{Cov}(Y_P,z_e)|\le\frac{2}{1-q}e^{-\tau|\operatorname{anchor}(e)|}.
\]

Perturb one touching plaquette coefficient. It changes one coordinate in at most four free blocks. The corresponding bound is

\[
|\operatorname{Cov}(Y_P,\chi_p)|
\le\frac{2}{1-q}\sum_{i\cap p\ne\varnothing,\ i\ {\rm free}}w_i
\le\frac{8e^\tau}{1-q}e^{-\tau|\operatorname{anchor}(p)|}.
\]

There are exactly 2B^2 edge basepoints and B^2 plaquette basepoints per anchor cell. The tails outside radius L are therefore bounded respectively by 4B^2 T(L)/(1-q) and 8e^tau B^2 T(L)/(1-q), where

\[
T(L)=8\sum_{r=L+1}^{\infty}rz^r
=\frac{8z^{L+1}[(L+1)-Lz]}{(1-z)^2}.
\]

These bounds are uniform in volume, fixed fine exterior, all retained-path patterns and parameters in the compact set. Temporary single-coefficient perturbations need only finite positive laws: split the comparison using the homogeneous baseline row for the contraction, so no unproved infinite inhomogeneous theorem is assumed.

For each fixed source edge or plaquette, UC supplies uniform convergence of the joint cylinder containing it and the target. Its finite covariance therefore converges uniformly. Splitting into finitely many near sources and the displayed summable tail makes both derivative sums uniformly convergent. Each local limiting covariance is parameter-continuous, and so is the sum. Applying the ordinary fundamental theorem of calculus along coordinate segments, then passing the uniform limits under the finite integrals, would prove actual C1 of every target parity mean. This is the necessary extra argument beyond Lipschitz continuity. Arbitrary infinite prescribed parities remain limits of normalized finite laws; no null infinite conditioning event is divided by.

## Counted derivative spatial continuity

For patterns agreeing on all anchors through radius R>=2, put L=floor(R/2)-1. Each near source plaquette, together with the target, occupies at most five anchors inside radius L+1. With C=16q/(1-q), UC bounds their joint TV by 5CB^2(R-L)z^(R-L). For two sign observables a covariance changes by at most six times that joint TV. Counting near edges and plaquettes, and adding two far tails, gives the candidate bounds

\[
D_h=60CB^4(2L+1)^2(R-L)z^{R-L}
+\frac{8B^2}{1-q}T(L),
\]

\[
D_J=30CB^4(2L+1)^2(R-L)z^{R-L}
+\frac{16e^\tau B^2}{1-q}T(L).
\]

The B^4 and polynomial-R prefactors are retained. For R=0,1 use 2A_B and 4A_B. These are summable after any fixed polynomial shell counting and an exponential weight weaker than exp(tau R/2). The same near-source argument should give derivative convergence of a finite oracle containing the matching radius-R region, with arbitrary fine exterior, since its missing and crossing far sources obey the same tails.

For one four-state coarse cell, reveal the first path parity and then the second. Each atom is the product of two factors (1+s m)/2. Let d=1-rho. Its score components are bounded by 2A_B/d and 4A_B/d. A log odds against the fixed reference state uses twice those amplitudes. If

\[
V_B(R)=\min\{2\rho^B,2CB^2(R+1)z^{R+1}\},
\]

the corresponding derivative log-odds spatial variations are bounded by 4D_h/d+4A_B V_B/d^2 and 4D_J/d+8A_B V_B/d^2. This follows by subtracting the actual derivative ratios, not by differentiating a TV bound. These amplitudes and tails are the interface for the root's complete derivative-shell proof.

## Actual Fisher-density route and boundaries

The conditional one-cell Fisher matrix has operator norm at most 20A_B^2/d^2, from the sum of squared component bounds. For an actual finite marginal, its ordered score increments are centered conditional on the preceding cells, so cross terms vanish. This gives the same per-cell matrix bound without replacing the marginal by a free-boundary Gibbs density.

Existence of an actual density still needs the root's assembly: partial lexicographic-past rows are precisely patterns with the already revealed cells pinned and all others absent. For bulk cells those patterns match the full lexicographic-past pattern on any fixed radius as the observation square grows. Uniform C1 spatial continuity would make their conditional Fisher matrices converge uniformly. Translation invariance and a vanishing boundary fraction then identify the density with the expectation of the full-past conditional Fisher matrix. Its bound tends to zero because A_B is a polynomial times rho^(B-1). Neither a pressure Hessian nor a C0 boundary-energy estimate is substituted for this argument.

The finite source-score projection/Fisher-loss identity remains an immediate companion bridge, separately owned. A learned parameter-dependent channel contributes its own channel score and need not satisfy ordinary Fisher data processing. Rank loss under blocking can make Fisher singular; a binary one-path output has rank at most one, including a two-parameter six-edge fixture. A constant-rank identifiable chart is needed before inversion or a Levi-Civita/scalar-curvature calculation.

Already delivered finite curvature/base/holonomy/metric-quotient reports retain their exact scopes. Their lattice plaquettes are holonomy interactions, their finite normalized latent and random-base laws are constructed, and their quotient metrics require the propagated metric. This response route does not identify parameter Fisher with a base metric, a gauge connection, continuum curvature, a critical limit, or an automatic scalar-curvature VFE penalty. It claims no practical algorithm for large B. The full proof, atomic proposals and independent check belong to the new bound run; this intake alone closes none of those obligations.
