# Phase 25 finite forward-word identities

**Scope:** Implementation companion for the [approved Phase 25 design](../superpowers/specs/2026-09-05-rg-v2-phase25-finite-word-stability-design.md). These finite identities explain the computations and their boundaries. Execution status belongs to the result report and its actual input/source/JUnit bindings. This document does not adjudicate Phase 21's independent all-parameter claim.

## Positive finite measures and fixed maps

Let X_l be the complete Phase 24 carrier at depth l, including both marked event labels, and let T_lk be a fixed deterministic surjection. Each physical center R_l and reference mu_l is positive on its declared finite support. The retained word satisfies R_k=(T_lk)_*R_l and mu_k=(T_lk)_*mu_l. These are hypotheses checked against the saved tables. The class, likelihood and marked event labels are retained pointwise. The maps do not depend on a source coupling or recognition parameter.

For two laws, grouping each target fiber and applying the triangle inequality gives

$$
\sum_y\left|\sum_{x:T_{lk}x=y}(R_l(x)-S_l(x))\right|
\leq\sum_x|R_l(x)-S_l(x)|.
$$

Division by two gives the total-variation contraction used in the tables. The inequality can be strict on some laws even when the supremum contraction coefficient is one. For a nonconstant deterministic map, two source atoms with distinct target atoms have disjoint Dirac output laws, hence TV one. Every pair of probability laws has TV at most one. The stored witnesses attain that bound; there is no need to enumerate every row pair. Event identity alone supplies distinct output atoms even when the core map is constant.

## Conditional moments and the source Fisher tensor

For one physical center R_0, tilt by the four original source observables O=(F,B,M,C):

$$
R_0^u(x)=\frac{R_0(x)e^{u^T O(x)}}{Z_R(u)},
 Z_R(u)=\sum_x R_0(x)e^{u^T O(x)}.
$$

Finite positive support permits termwise differentiation. At u=0, the source score is s_0=O-E_R O. Differentiating the finite forward sum yields

$$
\partial_a\log R_l^u(y)\big|_{u=0}
=\frac{\sum_{x:T_{0l}x=y}R_0(x)[O_a(x)-E_R O_a]}{R_l(y)}.
$$

The engine carries the uncentered first-moment measure R_0 O and diagonal raw second-moment measures R_0 O_a^2. Division is by the complete augmented target mass, including the event pair. This is why conditioning on the parent core alone is insufficient once eliminated matter induces event correlations. Equal profile rows are merged only by exact rational equality.

Write s_l=E[s_0|X_l]. For nested maps, finite summation gives E[s_l|X_k]=s_k. Expanding the square and using this identity gives

$$
G_l-G_k=E[(s_l-s_k)(s_l-s_k)^T],
 G_l=E[s_l s_l^T].
$$

The right-hand side is positive semidefinite. Its entries are computed directly from the retained fibers and compared with the difference of the separately computed Fisher forms. Defects telescope across the word. Zero defect means that these local score directions are retained at this center. It is not by itself an inverse for the entire statistical experiment. This distinction agrees with [Pollard, Theorem 7](https://arxiv.org/pdf/1107.3797).

The original O tuple is visible at depths zero, one and two; those reductions remove only the added leaf matter. The source scores therefore remain pointwise functions of the retained variables at those levels. Depth three discards b's matter, and its conditional score loss must be computed. For the flat control F vanishes identically. Its zero source direction is retained as a recorded nullspace, not promoted to an informative coordinate.

Let B span a complement of ker G_0. Positive semidefiniteness implies ker G_0 is contained in ker G_l. On the quotient, B^T G_0 B is positive definite and

$$
0\preceq B^T G_l B\preceq B^T G_0 B.
$$

Consequently the roots of det(B^T G_l B-lambda B^T G_0 B) lie in [0,1]. The implementation records exact rational coefficients, principal minors, the chosen coordinate complement, and endpoint multiplicities. An empty quotient has no roots. This is a local information comparison in the original source coordinates; it does not identify the changing full action spaces.

## Action derivative, constants and finite composition

For a finite unnormalized action A relative to mu_l, its exact coarse action is

$$
\mathcal R_{lk}(A)(y)=-\log\frac{\sum_{x:T_{lk}x=y}\mu_l(x)e^{-A(x)}}{\mu_k(y)}.
$$

Differentiation at a positive physical center gives U_lk h=E_R_l[h|X_k]. Adding a constant to h adds the same constant to U_lk h. Choose an actual anchor atom and write h=c+g with g(anchor)=0. The new scalar is c+U_lk g(target anchor); the remaining coordinates are U_lk g(y)-U_lk g(target anchor). Thus constants can be kept explicitly while the nonconstant coordinates use the complete anchored point basis.

The tower property proves U_kr U_lk=U_lr. Subtracting the intermediate anchor merely subtracts a constant, which cancels at the final anchor. This proves the corresponding anchored derivative composition for all finite perturbations. The retained execution checks the original four observable perturbations and the class/event indicators. Tiny tests separately form complete matrices including the scalar column and compare finite differences of normalized actions. These are complementary executed checks; finite probe agreement alone is not the all-vector argument.

For a normalized perturbation, the action derivative additionally subtracts E_R h. The source log-weight score has the opposite sign from a centered positive-action perturbation. Fisher quadratic forms are unchanged by that common sign. Evidence is a separate scalar: for the prior and selected posterior centers derived from the same fixed sensor,

$$
\partial_u\log p_u(O=1)\big|_{u=0}=E_{\Pi_0}O-E_{P_0}O.
$$

The occupancy and conditional attention rows are disintegrations of the event measure on the actual current roots. Changing root aggregation can change these rows even when the full marked-event law is preserved.

Conditional expectation contracts both oscillation modulo constants and the centered L2 norm. A nonconstant target indicator, pulled back to the source, is unchanged by conditional expectation. Its oscillation is one and its centered squared norm is p(1-p) on both levels. Since positivity gives 0<p<1, this is an exact norm-one witness. This worst-case norm does not rule out a loss in the restricted four source directions.

## Two distinct comparison categories

For complete finite action spaces, a continuous linear isomorphism requires equal dimension. The retained augmented atom counts decrease at every step, so the complete anchored dimensions also decrease. This supplies the stated complete-family obstruction. It does not exclude a separately declared restricted statistical family.

For the restricted class control, let C(x) denote the conjugacy class of the retained H. The common object consists of mu_C, the class likelihood ell_1, and positive weight vectors with their scalar factors. Define

$$
R_l^w(x)=\mu_l(x)w(C(x))/Z_w,
 Z_w=\sum_c\mu_C(c)w(c).
$$

Because C is constant on each target fiber and the reference pushes forward,

$$
(T_{lk})_*R_l^w(y)=\mu_k(y)w(C(y))/Z_w=R_k^w(y).
$$

The inverse is w(c)=Z_w R_C(c)/mu_C(c). Multiplication by the retained likelihood gives the selected posterior, while the ratio of normalizers supplies its evidence. These inverse charts identify the restricted weight family across the finite word. They are not inverse maps between the complete decorated carriers.

A physical law belongs to this family exactly when its full density R_l/mu_l is constant on every class fiber. The reported class-matched reconstruction and exact TV residual test that condition. Equal holonomy marginals alone do not test it. Constant weights describe the reference sector; a one-class flat control has no normalized parameter freedom. Nonconstant full class weights retain loop dependence. Identity behavior on that deliberately retained family supplies neither generated matter interaction nor attraction of the physical laws to the family.

No physical blocking ratio, spatial rescaling or infinite graph continuation is declared here. The common class coordinates use unit action rescaling and depth labels 0,1,2,3. Ordinary RG relevance exponents and asymptotic stability are outside the finite result. [Polyanskiy and Wu, Section 1.1](https://arxiv.org/pdf/1405.3629) supplies background for the channel-contraction coefficient; it does not convert these local information diagnostics into physical scaling exponents.
