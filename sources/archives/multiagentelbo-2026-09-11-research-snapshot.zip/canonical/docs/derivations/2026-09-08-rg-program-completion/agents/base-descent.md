<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Nonidentity base descent with nonflat inherited geometry

Family ID: base-pullback-with-passive-frame. Kind: CONSTRUCTION and LEMMA, with separate OBSTRUCTION examples. Revision 1 is proposed for independent reconstruction. This file assigns no ledger closure. No scientific source, tests, experiments, GPU processes or vault files were changed by this lane. The earlier event-closure.md remains frozen.

The positive construction uses the noninjective submersion f:U times I -> U, f(x,y,z)=(x,y), with U=(-1.5,1.5)^2 and I=(-1,1). Source laws and connections are pullbacks of the existing two-dimensional family, expressed in a z-dependent passive frame. The forgotten coordinate is redundant invariant data. This is genuine base descent, including a nonflat target connection, but it does not average heterogeneous contexts or derive emergent physical space.

## B0. Types, conventions and source mapping

Both source and target have the same compact principal group G=SO(2); the group homomorphism is the identity. The target principal bundle is Pbar=U times SO(2), and the source is P=B times SO(2), B=U times I. One common principal bundle supports two separately prescribed principal connections omega_b and omega_m. Both associated real two-dimensional representations are the standard rotation representation; their types remain distinct. A population fiber is the corresponding direct sum of the active belief/model fibers, using the active labels already supplied by the cover. A parent has its own direct sum and declared domain. No map between inequivalent representations is assumed.

The inherited convention is D=d+A, as in Theory/SPEC.md and neighborhood `connections.py`/`model.py`. Under a passive coordinate change v_new=H v_old, A_new=H A_old H^(-1)-dH H^(-1). The target reference potentials are

    Abar_b=(kappa_b/2)(x dy-y dx)J,
    Abar_m=(kappa_m/2)(x dy-y dx)J,
    J=[[0,-1],[1,0]].

Their curvatures are kappa_b J dx wedge dy and kappa_m J dx wedge dy. These are actual nonflat connections when kappa is nonzero, on a topologically trivial bundle. `connections.py::reference_generator`, `connection_geometry` and `segment_transport` supply this family; `model.py::frame_geometry` supplies each agent/channel presentation G_i^a(c), giving Abar_i^a=G_i^a Abar_a(G_i^a)^(-1)-dG_i^a(G_i^a)^(-1). Distinct connection parameters are not inferred from the pointwise ELBO.

Choose a finite gamma!=0 and h(z)=exp(gamma z J). Let H_X(z) be the direct sum of h(z) in the typed latent coordinates of a target fiber X, and likewise H_Y for a parent fiber Y. This one group element is used in both channels and every repeated representation. It is not an additional physical interaction or a separately learned agent connection.

All sections below are smooth on their stated constant-support domains. For individual agents, pull U_i back to U_i times I. For active full Gaussian populations, use each fixed active-set stratum; do not regard padded absent coordinates as SPD. The event latent carrier remains the fixed 256-state set. No random law on the extra base coordinate is declared or needed.

## B1. Explicit principal and associated bundle maps

Define

    Pi((c,z),g)=(c,h(z)^(-1)g).

This is a smooth principal-bundle morphism covering f because Pi(p a)=Pi(p)a for every a in SO(2). It is surjective, and f is a submersion with one-dimensional fibers. The map is noninjective on the total bundle and on the base, even though its restriction between the corresponding group fibers is an isomorphism.

The associated source-to-target linear map is

    Psi_X((c,z),v_s)=(c,H_X(z)^(-1)v_s).

It preserves the separately typed belief/model spaces and is an invertible isometry within each corresponding fiber. The target associated bundle is given, not obtained by assuming a quotient of an arbitrary gauge action is smooth. The source is isomorphic to its pullback; Pi specifies that isomorphism in the chosen trivializations.

For either principal connection set omega_a=Pi^* omegabar_a. In local coordinates this means

    A_a=h f^*Abar_a h^(-1)-dh h^(-1).

To verify the sign rather than infer it from frame terminology, write the target connection form as g^(-1)Abar_a g+g^(-1)dg and substitute g_target=h^(-1)g_source. The result is g_source^(-1)[h f^*Abar_a h^(-1)-dh h^(-1)]g_source+g_source^(-1)dg_source. Thus the source connection is normalized on principal vertical vectors and has the required right equivariance, because it is the pullback through an equivariant group-fiber isomorphism.

In the reference SO(2) coordinates all generators commute, so explicitly

    A_a=(kappa_a/2)(x dy-y dx)J-gamma J dz,
    F_a=kappa_a J dx wedge dy.

The z component is a passive-frame term. It does not introduce mixed curvature. The source is nonflat whenever the target is nonflat. In arbitrary displayed agent/channel frames use G_i,s^a(c,z)=h(z)G_i^a(c); the same formula holds with the displayed target Abar_i^a. Therefore no new source connection needs to be fitted.

The associated compatibility square is exact. With Psi=H^(-1),

    dPsi+(f^*Abar)Psi-Psi A=0.

Substituting A=H(f^*Abar)H^(-1)-dH H^(-1) cancels the derivative terms. Consequently, whenever v_s is Psi-related to a target section vbar, its covariant first jet maps to the pullback of Dbar vbar. This is compatibility of base descent; it does not assert that every separate vertical RG map is parallel.

For any source path b(s)=(c(s),z(s)), source parallel transport is

    T_s(b_1,b_0)=H(z_1) Tbar(c path) H(z_0)^(-1).

Differentiation verifies its transport equation and initial identity, using the displayed connection formula. A path moving only in z has T_s=H(z_1)H(z_0)^(-1) while its descended target path is constant. The bundle map cancels that apparent source rotation. No physical duration or context distribution is inferred from this path calculation.

Target obligation: exact source/target group, bundle, connection and fiber map for coverage C18. Assumptions: the target bundle/connections are already supplied; h is smooth; the projection base is the specified product. Failure condition: use an unrelated source connection or an incompatible fiber map. Open gap: executable representation and independent reconstruction. Novelty fingerprint: explicit principal pullback with z-dependent frame and inherited nonzero curvature. Proposed disposition: candidate positive base-descent family.

## B2. Section and law descent theorem

General statement: let f:B->Bbar be a smooth surjective submersion and Ebar->Bbar a given smooth finite-dimensional bundle. Let E->B be equipped with a specified smooth bundle map Psi:E->Ebar over f. Let s be a smooth source section. Put r(b)=Psi(s(b)), viewed as a section of f^*Ebar. Then a target section sbar satisfying r=sbar composed with f exists and is unique if and only if r is constant on every complete f-fiber. It is the pushed value r that must be constant, not the raw source coordinate vector.

Necessity follows immediately by evaluating sbar at the same target point. For sufficiency choose any b with f(b)=c and define sbar(c)=r(b); fiber constancy makes this independent of the choice, and surjectivity gives uniqueness. Smoothness is local: a submersion has coordinates in which f is projection onto the first dim Bbar coordinates, so fixing the remaining coordinates gives a smooth local section j:V->B with f composed with j=id_V. On V, sbar=r composed with j. This is smooth; on overlaps the definitions agree by fiber constancy. This local coordinate argument states the needed hypothesis rather than assuming an arbitrary quotient has local sections.

For a Gaussian law section on fixed-dimensional fibers, apply this proof to its mean and covariance after the prescribed fiber map: mu_bar=Psi mu_s and Sigma_bar=Psi Sigma_s Psi^T. For categorical laws use the finite probability vector and its specified state relabeling/channel. For the invertible maps in B1, positivity/SPD and normalization are preserved. Smoothness is ordinary smoothness of finite probabilities or Gaussian moments on each admitted support stratum. This statement does not posit a probability law on random smooth sections.

The positive witness is

    q_s(c,z)=(H_X(z))_# qbar(c),
    mu_s=H_X mu_bar, Sigma_s=H_X Sigma_bar H_X^T.

Then (Psi_X)_# q_s=qbar(c) for every z. For an elementary explicit nonconstant-coordinate example in one standard two-dimensional fiber, take mu_bar=(1,0), Sigma_bar=diag(1,2), gamma=1 and kappa_b=0.7. Source means/covariances rotate with z, source curvature stays 0.7 J dx wedge dy, and every pushed law is exactly N((1,0),diag(1,2)). Thus raw coordinate dependence does not obstruct descent. The same formula applies simultaneously to every prior, recognition, posterior and reference law in the actual neighborhood family.

For the target finite cover {U_i}, preimages commute with unions and intersections. Hence {U_i times I} is a source cover, with the same nonempty pair/triple intersections and empty fourfold intersection. Fixed-child intersection parents and availability union parents retain their distinct domains. The full event law is pulled back unchanged, and masks for active Gaussian coordinates and defined conditional attention are pulled back too. Beta remains undefined where target occupancy is zero. No average over z or duplication of likelihood records is performed.

A metric qualification is necessary. Raw derivatives of the rotating coordinate density can have nonzero Fisher information in z. After comparison by Psi the law is independent of z, so its vertical score vanishes. Equivalently, for Gaussian moments, partial_z mu_s+A_z mu_s=0 and partial_z Sigma_s+A_z Sigma_s+Sigma_s A_z^T=0. Thus the covariant law jet is zero in the forgotten direction. Do not silently identify the Fisher metric of uncorrected coordinate densities with this connection-dependent pullback metric or infer a physical null direction without the declared comparison.

Target obligation: constructive local/global section and law descent, including the actual cover. Failure condition: pushed values differ at two points on one f-fiber, or regularity/local sections needed for smooth descent are unavailable. Open gap: no general quotient existence claim is made. Novelty fingerprint: coordinate-dependent law presentations with exactly constant descended data. Proposed disposition: admissible positive specialization after reconstruction.

### Local-section argument and imported premise

The only imported local analytic fact is the inverse function theorem, inspected in Ralph L. Cohen's author-hosted [Bundles, Homotopy, and Manifolds, Theorem 3.3, printed page 41](https://math.stanford.edu/~ralph/math215b/book.pdf#page=49). Its use here is confined to a smooth Euclidean map with an invertible derivative. In charts around b and f(b), choose n=dim Bbar source coordinate columns giving an invertible minor of Df, and write source coordinates(u,v). The augmented map F(u,v)=(f(u,v),v) has invertible derivative because its diagonal blocks are D_u f and the identity. The inverse function theorem gives a local smooth inverse; fixing v=v_0 yields j(c)=F^(-1)(c,v_0) with f(j(c))=c. In the actual projection witness j(c)=(c,0) is global and explicit, so even that existence step does not need an abstract quotient theorem. This is a local construction, not a novelty claim.

## B3. A connection needs form descent, not just coefficient agreement at samples

For a given smooth surjective submersion Pi:P->Pbar as in B1, a Lie-algebra-valued one-form omega on P descends to a unique smooth one-form omegabar on Pbar if and only if

    pr_1^*omega=pr_2^*omega on P times_(Pbar) P.

Here the fiber product consists of pairs(p_1,p_2) with Pi(p_1)=Pi(p_2), and a tangent pair(v_1,v_2) has dPi(v_1)=dPi(v_2). Necessity is immediate for omega=Pi^*omegabar. For sufficiency, choose a local smooth section j of Pi and set omegabar=j^*omega. For p over u and tangent v, the pair(v,dj dPi(v)) belongs to the fiber-product tangent space, so the equality gives omega_p(v)=omegabar_u(dPi(v)). Different local sections give the same form, hence they glue. Surjectivity of dPi gives uniqueness. The local sections exist by the preceding argument; the explicit product witness supplies them directly.

If omega is a principal connection, Pi is equivariant with identity group homomorphism and its group-fiber restriction is an isomorphism, this descended form is a principal connection. To check reproduction, lift the target fundamental vector at u to the corresponding source fundamental vector; omega returns its Lie-algebra generator. To check right equivariance, use Pi composed with R_a=R_a composed with Pi and source equivariance, then injectivity of pullback under a surjective submersion. This proof handles both separately prescribed connections.

The fiber-product condition includes annihilation of ker dPi and agreement across all components of every fiber. Merely differentiating along connected vertical curves would not compare disconnected components. For the explicit projection in source reference coordinates, undo the passive frame:

    B=h^(-1) A h+h^(-1)dh.

Descent says B=f^*Abar: it has no dz component and its dx,dy coefficients are independent of z. These two checks are sufficient on this product, with the target connection given by those coefficients. The constructed A satisfies them exactly, even though A itself has a nonzero dz component. Requiring A_z=0 before undoing the frame would reject a valid presentation.

Target obligation: connection existence/uniqueness/smoothness and its exact admission condition. Failure condition: a nonzero form on a ker dPi tangent, or inconsistent values for two lifts of the same target tangent. Open gap: general quotient bundles/connections are not constructed automatically. Novelty fingerprint: explicit form descent through a given principal submersion. Proposed disposition: use this criterion for the supplied family only.

## B4. Coarse kernels, observations, evaluators and exact actions

Let Kbar_c:X_c rightsquigarrow Y_c be any of the already supplied recognition-independent normalized coarse kernels, with its stated gauge covariance. Define the source kernel by conjugating input/output presentations:

    K_s((c,z);x_s,A_s)
      =Kbar_c(H_X(z)^(-1)x_s, H_Y(z)^(-1)A_s).

Equivalently, undo the input frame, apply Kbar, then restore the source output frame. Normalization follows because H_Y is a measurable bijection, and recognition independence is preserved. For every source law q_s at that base point, not only the chosen pullback section,

    (Psi_Y)_#(q_s K_s)=((Psi_X)_#q_s)Kbar_c.

Proof: both sides evaluate a target measurable set A as the integral of Kbar_c(H_X^(-1)x_s,A) against q_s. Smooth finite tables or explicitly parameterized Gaussian kernels retain their regularity under these smooth maps. Gauge covariance follows by transporting the given target diagram through the associated bundle maps. This does not supply nonexistent intertwiners for a different group/representation.

For a deterministic linear target parent map Fbar_c, the source is

    F_s=H_Y f^*Fbar H_X^(-1),
    Psi_Y F_s=(f^*Fbar)Psi_X.

Its covariant defect satisfies

    D_s F_s=H_Y f^*(Dbar Fbar) H_X^(-1).

Expand dF_s and insert the two source connection formulas: every dH term cancels, leaving the displayed target defect. Thus the existing weight-dependent vertical obstruction is retained, not removed by base descent. In this abelian repeated-representation fixture F_s can even equal Fbar as a raw matrix because common rotations commute with scalar block weights; the law and connection presentations still vary with z.

Existing stochastic event/availability maps have no SO(2) action on the finite labels, so H_event is the identity and K_s(c,z)=Kbar(c). Their joint eta, occupancy alpha and defined-row masks descend exactly. No unsupported conditional at zero occupancy is introduced.

For the complete generative law keep the observation fiber O unchanged and define

    P_s(c,z)=(H_X(z) times id_O)_# Pbar(c),
    L_s(o|x_s)=Lbar(o|H_X(z)^(-1)x_s),
    o_s(c,z)=obar(c).

Prior, recognition, selected posterior version and reference are all pushed by the same presentation map. Evidence Z_s(c,z)=Zbar(c), and every normalized evaluator descends by the same square on its separately typed belief/model coordinates. If a predeclared source evaluator is supplied instead, its compatibility must be checked; its name does not force this formula. Finite selected null versions are transported as declared versions, not inferred from an almost-sure law at an exceptional input.

KL is preserved under the invertible presentation map: in Gaussian coordinates the determinant is one and densities transform together; for general densities the common Jacobian cancels in their ratio. Thus fixed-observation VFE and ELBO descend with the same evidence. Because K_s is conjugate to Kbar and references/evidence measures are pushed together, every exact coarse measure pair and its density/action also descends. Conditional KL corrections and staged/direct identities are the existing finite core identities under this map; no new action compiler is required. On null reference support retain the existing measure/density convention rather than manufacture a conditional law.

Target obligation: full probabilistic/evaluator/coarse-arrow compatibility. Failure condition: observations or evaluators vary incompatibly along a base fiber; different maps are used for prior/recognition/posterior; or a reference is reset. Open gap: implementation binding to the chosen live interfaces. Novelty fingerprint: one exact base-presentation conjugacy across complete law/evaluator/Markov diagrams. Proposed disposition: thin integration layer over the current core.

## B5. Compositional descent through a tower

Take B_2=U, B_1=U times I_z and B_0=U times I_z times I_w with two open intervals I_z and I_w; J continues to denote the rotation generator. Let f_01(c,z,w)=(c,z), f_12(c,z)=c, and f_02=f_12 composed with f_01. Choose h_12(c,z)=exp(gamma_z z J) and h_01(c,z,w)=exp(gamma_w w J), and put

    h_02=h_01 (f_01^*h_12).

Principal maps are Pi_01(b,g)=(f_01(b),h_01(b)^(-1)g), and analogously Pi_12. Their composite is Pi_02 because h_02^(-1)=(f_01^*h_12)^(-1)h_01^(-1). The order is explicit; replacing it by addition of connections is unjustified even though these particular rotations commute.

Start with a target connection A_2 and form A_1 and A_0 successively using B1. Expanding the product derivative gives

    A_0=h_02 f_02^*A_2 h_02^(-1)-dh_02 h_02^(-1),
    omega_0=Pi_01^*Pi_12^*omega_2=Pi_02^*omega_2.

Source laws built as q_1=(H_12)_# f_12^*q_2 and q_0=(H_01)_# f_01^*q_1 obey q_0=(H_02)_# f_02^*q_2. Staged and direct descents agree, by cancellation of the inverse frame maps. The same applies to sections, complete generative/evidence laws, observations, evaluators and both connections.

For a sequence of vertical coarse kernels, conjugation at each level cancels the intermediate H. Hence K_s,01 K_s,12 is conjugate to Kbar_01 Kbar_12; its law push equals the direct conjugated channel. Base descent and vertical channel composition therefore form a commuting diagram when all maps are supplied by this construction. A general independently specified tower must check those compatibility equations; an arbitrary coarse map need not arise by this pullback recipe.

The proof uses only the composition of explicit functions, derivatives and Markov integrals. Target obligation: nonidentity base composition and compatibility with retained ordinary vertical recursion. Failure condition: noncomposing base maps, changed group homomorphisms or incompatible source frames/data. Open gap: no infinite-depth or continuous-scale limit follows. Novelty fingerprint: two noninjective base projections with an ordered principal/law conjugacy. Proposed disposition: minimal finite tower control.

## B6. Exact obstructions from invariant fiber variation

### B6a. A law invariant varies along one forgotten base fiber

Family ID: base-law-nondescending. Kind: COUNTEREXAMPLE/OBSTRUCTION. Keep B1's group, base map, connection and associated map. In a single two-dimensional source fiber let

    q_s(c,z)=N(H(z)(1+z/4,0)^T,I),
    p_s(c,z)=N(0,I), z in(-1,1).

Both laws are positive and smooth and transform correctly under passive SO(2) changes. Their target-coordinate images are N((1+z/4,0)^T,I) and N(0,I). The first varies with z, so B2 forbids a unique target recognition section. More invariantly,

    KL(q_s(c,z)||p_s(c,z))=(1/2)(1+z/4)^2

varies on every nontrivial z interval. This follows by expanding the two Gaussian log densities and averaging under q_s; covariance terms cancel. A common invertible isometry preserves that scalar, so no choice of passive SO(2) frame can turn both laws into constant data on the fiber. An uninformative normalized observation can be used so p_s is also its posterior and evidence is one; the VFE then has this same obstruction.

This refutes descent for the declared invertible base-presentation maps, not every possible information-destroying Markov map. A separately chosen terminal or sufficient-statistic map could discard varying law data, but it would be a different construction with its own loss/evaluator obligations. Failure condition for this counterexample is a constant pushed law or constant displayed invariant despite the given formula; neither holds. Open gap: none in the finite Gaussian calculation. Proposed disposition: a required negative admission witness, not a universal impossibility theorem.

### B6b. Mixed curvature cannot be removed by a passive frame

Family ID: base-curvature-nondescending. Kind: OBSTRUCTION. Modify one source reference potential by a genuine extra term, with lambda!=0:

    A_bad=(kappa/2)(x dy-y dx)J-gamma J dz+lambda z J dx.

SO(2) is abelian, so its curvature is

    F_bad=kappa J dx wedge dy+lambda J dz wedge dx.

The contraction with the vertical base vector partial_z is lambda J dx, which is nonzero. For every connection pulled back from U through f, including after any smooth passive frame, its curvature is a gauge conjugate of f^*Fbar and therefore annihilates partial_z: df(partial_z)=0. Conjugation cannot turn a nonzero contraction into zero. Consequently no target connection and no principal map covering this f with the declared structure group can produce A_bad as a compatible pullback connection.

This obstruction is stronger than noticing an A_z coefficient. B1 has A_z!=0 and still descends; the mixed curvature tests invariant geometry. Failure condition: the mixed contraction vanishes with lambda!=0. Open gap: none for this smooth explicit family. Proposed disposition: retain this separate geometry counterexample; a zero curvature-square at isolated points would not establish descent over a neighborhood.

### B6c. Averaging is a different probabilistic operation

If invariant data vary along a forgotten base fiber, choosing a probability nu_c(dz) and integrating (Psi_X)_#q_s(c,z) against it defines a coarse mixture. Its value depends on nu_c, which is additional model data. Gaussian mixtures are not generally Gaussian, so retaining only their first two moments adds another approximation/family condition. A complete base-space inference construction must declare a base prior/reference, a joint base/fiber generative law and the common base/fiber channel before forming its posterior/evidence. Averaging normalized posteriors while ignoring their observation evidence weights is not that construction.

No such measure is used in B1-B5. The present source direction is observationally redundant after the prescribed frame map. Its elimination is exact redundancy removal, not elimination of heterogeneous informative contexts. Neither result supplies a canonical base variable, scale or physical spacetime.

## B7. Smallest executable interface and integration recommendation

Reuse the existing two-dimensional `inference.build_context` or nonflat cover as the target factory. Add a narrow presentation layer for the supplied product base; do not rebuild the exact finite action or ordinary-parent stack.

A minimal typed record should retain: source point b=(x,y,z); target point f(b); Df; declared gamma and h(z); active labels and source/target fiber dimensions; Psi_X/H_X for each existing law level; both source/target connection one-forms and curvatures; the existing target model and its source-presented laws, observation/evaluator and coarse-map diagrams. The source connection has three base components, while the target has two. Store the extra derivative term explicitly; do not treat z as another latent agent or silently discard its connection component.

Suitable public operations are `base_projection(b)`, `source_frame(b, active_labels)`, `lift_law(target_law, H)`, `descend_law(source_law, H)`, `lift_connection(target_A, H, dH, Df)`, and `lift_coarse_map(target_F, H_child, H_parent)`. The finite event coordinates/readouts are passed through unchanged in this SO(2) specialization. A general arbitrary-source admission API should report the fiber-constancy or form-descent residual and refuse to silently average or repair incompatible data. Finite samples can check a declared formula but cannot certify fiber constancy for an arbitrary black-box section; structural pullback construction is the positive premise.

For this explicit h(z), the only new derivatives are d_z H=gamma J_X H and d_z Psi=-gamma Psi J_X. Source A_x,A_y are conjugates of the target components and A_z=-gamma J_X. Mixed curvature components vanish in the positive witness. The existing vertical coarse defect transforms by B4 and remains nonzero where its target value is nonzero. These formulas fit the current tensor geometry without an automatic differentiation or connection-fitting framework.

The smallest scientific controls would use multiple z values over the same admitted c and confirm complete law/evidence/evaluator equality after descent, the two principal/associated connection squares, nonzero inherited curvature with zero mixed curvature, unchanged event masks, and direct/staged coarse-map parity. A separate four-to-three-to-two base tower checks ordered frame and connection composition. The two explicit negative families check the diagnostic predicates on valid mathematical data; they are not deliberate file/artifact corruption scenarios. No controls were run by this lane, and their future execution remains root-owned.

Integration with the completed event closure is straightforward: its 39 microscopic event coordinates are constant along the new base fiber because the physical event labels carry the trivial SO(2) action. This does not change its target family or turn it into autonomous parent state. Integration with moving contexts is also typed: a source path projects to c(s), and its z motion cancels after connection-compatible descent. Existing Gaussian entry/exit policies must still use the projected actual cover domains; this construction creates no new boundary law.

Open implementation gap: write the small source/target presentation layer and its bounded artifact route after independent mathematical reconstruction. Exact finite laws/actions and current source profiles remain unchanged. Novelty fingerprint: explicit redundant-base extension of the actual cover and nonflat model, with complete law/evaluator/connection/channel squares and two independent obstructions. Proposed disposition: sufficient constructive closure of the adopted C18 example after verification, while informative base aggregation and universal quotient selection remain open.

## Cross-lane communication

**To Root:** B1-B5 supply the positive noninjective-base construction and tower; B6 gives independent law and curvature obstructions. The positive family removes a redundant base coordinate. A source law that varies only in the passive frame is valid; invariant variation is rejected under the declared descent map. Keep source connection dimension three explicit and preserve the existing nonzero vertical coarse defects.

**To Evolution:** a source path can vary in z while its target context remains fixed. The exact horizontal transport then cancels that frame motion after Psi. This is compatible base descent, distinct from the moving-context dynamics and its event schedule. Your hybrid boundary assumptions remain tied to the projected U domains.

**To Scale:** the complete reference/evidence/action recursion is reused through the conjugated channel squares. No fixed-object or length-scale interpretation is added by the redundant base quotient. In particular, the hierarchical Ising witness and this SO(2) smooth-base witness remain separately scoped models.

## Sources and evidence status

The live Theory/SPEC.md common-principal-bundle, base-descent and first-jet requirements supply the inherited types. The explicit source conventions are neighborhood `model.py::frame_geometry`, `connections.py`, `local_tree.py`, `nonflat.py`, `cover.py` and `inference.py`. Their earlier formulas and admissible domains are reused; source existence is not new numerical evidence. The sole imported local existence premise is the cited inverse function theorem; its hypothesis mapping and local-section construction are given above. Every other displayed positive/negative identity follows by the local algebra in this file. No universal smooth quotient, probability law on random sections, continuum physics, autonomous parent inference or novelty claim is made.
