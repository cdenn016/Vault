<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Independent positive-ladder mathematical and source verification

September 9, 2026. This lane independently reconstructed the admitted formulas from the live plan and implementation, then read the frozen construction in full. The parent supplied the candidate family and scope. Agents share the model, conversation context, and filesystem, so this is an independent derivation and challenge within that limitation, not independent invention. Only this note is owned. No test, scientific run, Torch import, GPU job, historical producer, tamper scenario, ledger update, or vault write was performed. Root owns executed evidence and the daily change log.

**The scoped positive finite-width construction is mathematically supported by the derivations below and by the readback of the construction note.** No unresolved mathematical defect was found in its normalization, raw gauge covariance, exact blocking, generated-action retention, or fixed-kernel thermodynamic and depth claims. A source-level binary64 cancellation defect was reported and repaired during review; its executed regression belongs to root. This note assigns no formal ledger closure state and does not claim completion of the ambient gauge/Fisher/base-curvature program.

## Reviewed inputs and binding

The worktree was `C:/tmp/elbo-cover-20260908`, with Git HEAD `409c61155ac16b21342bfe15c834fda7bb33fb67`. The following files, including uncommitted content, were read directly. Hashes identify the reviewed bytes and are diagnostic metadata, not mathematical evidence.

| Artifact | SHA256 at final source readback |
| :--- | :--- |
| `agents/positive-ladder-construction.md`, in this derivation directory | `a70e266eee411bf025424ffa503d8d161e07c52529d34b5498603e23f1faa7f7` |
| `src/multiagent_elbo/rg_v2/positive_ladder.py` | `72192dcf2d8cfde789239326ae61ca61ee8592720455a7b6285819e4f5895b6a` |
| `src/multiagent_elbo/rg_v2/positive_ladder_experiment.py` | `f9506aef3c64e99c89d8ca02dbb57cd3d092e0a2ffd172d8ba39324791f38960` |
| `experiments/rg_v2/positive_ladder.py` | `f9fee0ad32f9141b10d8d8a7e8d83a031cafedc3adafad6647b610ca377f9ebb` |
| `docs/research-plans/2026-09-09-positive-ladder-rg.md` | `2d58364eee8c142fb94539d917c198c00c73279a111fc86b6d03495cdf51737a` |

The active profile uses `(a,b,c)=(1/5,2/5,1/3)`, recognition biases `(1/7,1/5,1/4)`, observation bias `1/2`, and block lengths `1,2,3,4,6,8,12,16,32`. The runner validates these dictionaries, constructs both exact Fraction kernels, computes complete powers, evaluates two-cell observable laws and one common-observation VFE push, then separately evaluates Perron diagnostics. The routing test evidence was not independently executed here.

The Research wiki was consulted for the distinction between graph holonomy, Fisher geometry, and connection-relative base pullbacks: `wiki/concepts/Fisher information metric.md` and `wiki/concepts/Renormalization group flow.md`. Their background framing is not used to prove the new ladder theorem. A search located the authors' Markov-chain textbook, but its PDF could not be fetched; no theorem from that inaccessible PDF is used. The contraction proof below is elementary finite algebra.

## Normalization, quotient multiplicity, and exact actions

Write the invariant coordinates as `(r_i,x_i,y_i)` and the raw matter spins as `(t_i,b_i)`. For each invariant state and each of the `4^N` spin tuples, the formulas `w_i=t_i r_i b_i`, `u_i=t_i x_i t_(i+1)`, and `v_i=b_i y_i b_(i+1)` reconstruct exactly one raw link tuple. They invert the invariant map, so the raw normalized product reference pushes to the invariant normalized product reference with uniform, independent spin frames. In particular, the exact raw probability mass is `4^(-N)` times the invariant probability mass. No stabilizer correction is missing: fixing both matter-spin rows forces every vertex gauge to be the identity.

For the initial factor product, `product K=8^(-N) product[(1+a r_i)(1+b x_i)(1+b y_i)(1+c H_i)]`. Destination rungs occur exactly once. Summing the two rail signs gives `M(r,s)=(1+a s)(1+c b^2 r s)/2`; summing the remaining periodic rung indices gives `Z_N=tr(M^N)`. These are exactly the formulas implemented by `ladder_kernel`, `marginal_transfer`, `ring_partition`, `ring_weight`, and `ring_law`. The N=1 loop and N=2 parallel-edge conventions are indispensable and are retained in the indexing.

For B-cell blocking, each invariant coarse state has `8^(N-N/B)` reference preimages. The raw channel additionally forgets `4^(N-N/B)` frames. Thus both coarse references remain normalized product counting references. The density relative to that reference is

\[
W_{m,B}=\prod_{j=0}^{m-1}8K^{*B}(r_j,r_{j+1},X_j,Y_j),\qquad m=N/B,
\]

with partition `Z_N`. Therefore the exact effective action is `-sum_j log(8K^{*B})`; dropping the 8 or the common transfer amplitude would change the reference-relative action or pressure. The implementation retains the rational table and partition. It does not expose an independently symbolic logarithmic action object; the positive rational table determines that object exactly through this formula. Floating logs are numerical evaluations of it.

Internal vertex gauge factors telescope in a product of rail links, leaving the retained endpoints. Therefore `block_raw_state` commutes with restricting the fine gauge tuple to retained vertices. Direct six-cell blocking, two then three, and three then two retain identical coordinates and products at anchored origin zero. This is literal map equality, not an equality inferred from observables or hashes. Summing internal states in one block gives the implemented convolution; finite sums prove associativity. The complete table, law, action, and partition consequently compose exactly under the stated divisibility convention.

## Nonfactorization is stronger than the plotted covariance

The full raw matter-spin marginal is uniform, by the free vertex gauge action and invariant factor weight. Fix all raw links to +1. For N at least two, flipping one top spin changes its conditional weight relative to all-positive spins by

\[
\frac{1-a}{1+a}\left(\frac{1-b}{1+b}\right)^2.
\]

This differs from one whenever a or b is positive. Hence the conditional matter law is not its uniform marginal, proving nonfactorization of the entire raw spin/link law at the scientific point. At `a=b=0`, the factor product depends only on links, so raw matter and links are exactly independent. The construction note supplies this separate proof; it does not infer independence from a zero covariance.

For an independent direct reconstruction of the plotted N=2 observable, put `R=r_0 r_1`, `d=b^2`, `A=a^2`, and

\[
\eta=\frac{A+cd}{1+Acd}.
\]

Summing the second plaquette, the two free rail signs, and the remaining rung sign gives the complete normalized two-variable law

\[
\mathbb P(H=h,R=r)=
\frac{(1+\eta r)(1+ch)(1+drh)}{4(1+cd\eta)}.
\]

One way to verify the normalization is to begin with the unnormalized three-variable mass

\[
\frac{(1+Ar)(1+ch_0)(1+ch_1)(1+drh_0)(1+drh_1)}{8Z_2}
\]

and sum `h_1`, then the other signs. The resulting covariance is

\[
\operatorname{Cov}(H,R)=
\frac{d(1-c^2)(1-\eta^2)}{(1+cd\eta)^2}.
\]

It is positive for b positive throughout the admitted interior. It is already positive at c=0: this observable does not isolate the plaquette-action parameter. R contains rung links and is a dressed matter relation, not a matter-only observable. At N=1, R is identically one and the covariance vanishes. The construction note's general-N conditional formula gives the equivalent expression `b^2(1-c^2) Var(R)/(1-c^2 b^4)`. These qualifications are necessary when interpreting `field_matter_record`; they do not invalidate the separate raw-factorization proof.

## Generated terms are present in the complete carrier

An independent calculation of the implementation's determinant witness gives, with `d=b^2`,

\[
\sum_r K^{*2}(r,t,X,Y)=\frac{1+at}{4}
\left[(1+dX)(1+dY)+actdXY(1+X)(1+Y)\right].
\]

Its two-by-two determinant in X,Y is

\[
\frac{(1+at)^2actb^2(1-b^2)^2}{4},
\]

matching `ansatz_minor`. It is nonzero at the default point and t=+1; every original three-bias table has zero such determinant. This particular determinant witness excludes equality of literal tables up to a common scalar. The construction note supplies the stronger conditional-rail witness needed to exclude endpoint coboundaries as well.

I separately checked that stronger witness: with `d=cb^2`, the conditional first-rail means at the two equal-endpoint pairs differ by

\[
\frac{4ab^2(c-d)(1-cd)}{(1+d^2)^2-4a^2d^2}>0.
\]

An original ansatz conditional rail law depends on endpoints only through their product, so this difference must vanish there. Multiplication by an arbitrary endpoint factor cancels under the same conditioning. The proof therefore survives the admitted transfer-coordinate similarity equivalence. Neither witness says that all sixteen log-character coefficients are nonzero. Keeping all sixteen entries is an exact carrier choice that avoids any truncation claim.

## Perron normalization, contraction, and limits

For a positive two-by-two marginal matrix with entries A,B,C,D, the larger root of its characteristic polynomial is `lambda=(A+D+sqrt((A-D)^2+4BC))/2`. It exceeds both diagonal entries and the magnitude of the other eigenvalue. The positive eigenvectors in construction section 7 satisfy the characteristic equation exactly. This proves the needed spectral decomposition without an imported theorem.

Using a positive right eigenvector h, write `Q(r,s,g)=K(r,s,g) h_s/(lambda h_r)` and `P(r,s)=sum_g Q(r,s,g)`. The stationary rung law is `pi_r=l_r h_r/(l^T h)`. Introduce the eight-state chain `T((r,z),(s,w))=Q(r,s,z^(-1)w)`. Its stationary law is `nu(r,z)=pi_r/4`: summing incoming group coordinates is a bijective translation and reduces stationarity to `pi P=pi`.

For `epsilon=8 min T>0`, write `T=epsilon U+(1-epsilon)R`, with U uniform and R stochastic, unless epsilon=1, when T=U. The difference of two probability rows annihilates U; the triangle inequality proves that R contracts its L1 norm. Iterating against nu yields

\[
\|T^n(i,\cdot)-\nu\|_{\mathrm{TV}}\leq(1-\epsilon)^n.
\]

Telescoping eigenvector factors proves `Q^{*n}=K^{*n}h_s/(lambda^n h_r)=T^n((r,e),(s,g))`. Thus normalized transfers converge to `Q_*(r,s,g)=pi_s/4`. The bound is uniform over the finite indices at each fixed positive K. It gives no uniform result as the microscopic kernel approaches a boundary with a closing positivity gap.

For a k-edge window of an N-cell ring, N>k, the exact Doob-form probability is

\[
\frac{\prod_{i=0}^{k-1}Q(r_i,r_{i+1},g_i)
P^{N-k}(r_k,r_0)}{\operatorname{tr}(P^N)}.
\]

The return factor tends to `pi_(r_0)` and the denominator tends to one. This proves cylinder convergence to the stationary marked Markov law. The finite alphabet makes the product topology compact; finite-cylinder approximations to continuous functions then prove the stated weak convergence. The uniform frame lift is a local reconstruction and preserves that argument. The pressure is `log lambda` relative to the declared normalized reference. The explicit square root is analytic for positive entries, and the contraction bound gives exponential decay for separated bounded cylinder observables. These arguments support the construction's stated interior noncriticality, with fixed ladder width.

At fixed coarse ring size m, replacing Q by `Q^{*B}` makes every factor converge to `pi_s/4`. The whole finite law therefore converges in total variation to independent rung draws from pi and uniform group increments. I also checked the construction's quantitative bound: telescoping products bounds the unnormalized L1 difference by `4m rho^B`, where `rho=1-epsilon`; normalizing gives TV at most `4m rho^B/(1-4m rho^B)` when that denominator is positive.

The two iterated limits and the joint local limit use the correct coarse-coordinate comparison. For a k-edge coarse window with m>k, its return factor is `P^(B(m-k))` and denominator `tr(P^(Bm))`. Sending B to infinity and m to infinity makes both converge, as do the fixed number of edge factors. No growing-ring total-variation conclusion follows without a growth restriction, since the displayed finite-ring bound contains m. Increasing B changes each observable's microscopic support; this is not a limit at fixed microscopic separation or a continuum rescaling theorem.

If a strictly positive row-normalized Q obeys `Q^{*B}=Q` for any B at least two, the associated chain obeys `T^(B^n)=T`. Its established convergence then forces identical stationary rows, hence `Q=pi_s/4`. Direct convolution proves the converse. A finite power-blocking cycle reduces to the same equation. The construction therefore classifies the declared positive fixed objects, including scalar/diagonal transfer-coordinate equivalence after Doob normalization. It does not classify singular or signed kernels, increasing-width models, or different retained carriers. A nonuniform pi retains a local raw rung gauge-matter bias even though coarse cells are independent.

## Wilson sectors and curvature scope

Each rail Wilson product is conserved separately: `W_x=product x_i`, `W_y=product y_i`. Coarse plaquette products telescope to `W_x W_y`. Let `Z_N(g)=sum_r K^{*N}(r,r,g)` for the fixed pair of Wilson signs g. Then `sum_g Z_N(g)=tr(M^N)`. In contrast,

\[
\operatorname{tr}(T^N)=4\lambda^{-N}Z_N(e).
\]

The extra factor four is the number of accumulated-group origins. This verifies the construction's warning that the eight-state trace selects the trivial Wilson sector; it cannot replace the unrestricted ring normalizer.

For the unrestricted family, `Z_N(g)/Z_N` tends to 1/4 by the same contraction calculation. This is convergence of sector weights across the family as N increases. It is not dynamical transport between sectors: each finite blocking map preserves both Wilson signs. A separately sector-conditioned theory keeps its global constraint. Likewise the limit has plaquette probability 1/2 for each sign, although the dressed covariance vanishes. Curvature abundance and interaction decay are different quantities.

The model supplies discrete graph plaquette flux, not smooth base curvature. A smooth parameterization of its positive laws has the ordinary Fisher score covariance. For any of these parameter-independent block channels, differentiating the finite pushforward gives `score_coarse=E[score_fine|coarse]`; the law of total covariance yields `F_fine-F_coarse=E[Cov(score_fine|coarse)]`. This is a statistical information-loss identity. It neither constructs a base connection nor supplies a Riemann-curvature flow. A graph flux, Fisher tensor, and curvature of a smooth base metric have different types. The construction's explicit exclusions on those wider claims are necessary and sufficient for this note's favorable scoped verdict.

## VFE implementation and numerical finding

The live `vfe_record` uses the normalized likelihood `L(o|s)=(1+delta o W(s))/2`, where W is the global plaquette product. It preserves o and pushes both its joint observation slice and recognition law through the same deterministic two-to-one channel. Exact Fraction evidence normalizes both posterior slices. Since W is retained, the posterior conditional inside a coarse fiber equals the prior conditional there; no extra conditional matter normalizer enters the model.

Expanding `q=q_C q(.|z)` and `posterior=posterior_C posterior(.|z)` proves the finite KL chain. The code evaluates its discarded term directly from the conditional ratio, and the same evidence term gives the VFE chain. All probabilities and ratios are exact; the real logarithms and weighted sums are binary64. The `exact_ratio_factorization` flag is an algebraic consistency identity in these exact ratios; it is not an independent proof of logarithmic evaluation accuracy. The current VFE artifact covers the two-to-one map on N=2. The proof covers all admitted compositions; no executed three-block VFE record is asserted here. The raw interpretation additionally assumes the common uniform frame lift, as stated in construction section 6.

The original runner formed the right eigenvector `(bb,lambda-aa)`. For the admissible rational input `a=1-10^(-20), b=c=0`, exact aa is `1-5*10^(-21)`, exact lambda is one, and binary64 rounds both to one. Its second eigenvector coordinate therefore became zero despite exact positivity, causing division by zero in a Doob row. This was a source-level counterexample, not an executed failing process. Root retained the finding in `docs/verification/2026-09-09-positive-ladder/perron-source-finding.md`.

The inspected repair subtracts the smaller diagonal: when aa>=dd it uses right `(lambda-dd,cc)` and left `(lambda-dd,bb)`, with the original orientation for aa<dd. Both pairs satisfy the exact eigenvector equations; the smaller-diagonal choice avoids the identified cancellation. It also rejects nonpositive/nonfinite converted marginal entries and invalid vector pairings. At `a=1-10^(-400), b=c=0`, this rejects an unrepresentable binary64 marginal while leaving the exact Fraction domain intact. Source review supports that repair; root owns its execution evidence. These diagnostics remain uncertified binary64 evaluations, with no interval proof and no promise that arbitrary extreme fractions or unbounded block lengths are representable.

No additional code or mathematical repair is required for the active finite profile and the frozen theorem's declared scope. Future claims about the singular boundary, whole growing-ring total variation, a smooth base metric or connection, or universality beyond this fixed-width carrier would require new arguments. The favorable verdict here must not be extended to those claims.
