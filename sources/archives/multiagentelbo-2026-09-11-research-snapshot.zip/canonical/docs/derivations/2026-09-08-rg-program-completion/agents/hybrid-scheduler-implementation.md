<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Exact hybrid scheduler implementation

Revision 1 is frozen for root integration. This lane owns only the new `hybrid_schedule.py`, `test_neighborhood_hybrid_schedule.py`, and this Markdown. Root independently reconstructed H1; no dependent H2–H8 model or runtime is implemented here. No tests, test collection, or scientific imports ran. Only standard-library AST parsing was performed.

The API is `resolve_events(waypoints,path_times)->dict` plus `serialize_schedule(schedule)->dict`. The input admits finite decimal int/float/string scalars, parsed exactly through `Fraction(str(value))` after decimal validation; bools and nondecimal strings are rejected. Ordered finite parameters need not start at zero in this geometry-only helper. The existing experiment validator retains its separate zero-origin rule. Contexts must lie strictly in U and times must strictly increase.

The result has `waypoints`, `path_times`, `points`, `intervals`, `events`, and `boundary_intervals`. Coordinates and parameters are exact Fractions. Each point has `time`, `context`, `boundary`, `waypoint_indexes`, `incident_segments`, `left`, `exact`, `right`, `phase_order`, and `is_event`. A carrier is a dict with ordered tuples `fine`, `parent`, and `final`. Missing endpoint germs are None. `events` contains point indexes, preserving chronological order. Interior waypoints of a boundary-aligned interval are ordinary points with a boundary tag, rather than extra events. Its endpoints and isolated active/inactive contacts are events.

Each interval has adjacent point indexes `start`,`end`, its original `segment`, its exact midpoint `carrier`, and an optional `boundary` label. `boundary_intervals` merges consecutive boundary-aligned intervals and retains `start`,`end`,`boundary`,`segments`. All ordered collections are tuples in the exact result. Serialization recursively converts tuples to lists and Fractions to `{numerator,denominator}`, without float conversion or tolerance merging. The frozen source and tests are bound below; syntax parsing is not a scientific correctness claim.

## Construction and control handoff

Every original segment is cut at its exact rational roots and original endpoints. Segments and their cuts are traversed in chronological order, so the resulting interval list is exactly the adjacent partition intervals. A rational midpoint determines each open-interval carrier. The neighboring intervals determine point germs, while the strict inequalities at the point determine its exact carrier. Equal rational roots deduplicate shared vertices; incident segment indexes remain sorted and complete. Consecutive boundary-aligned intervals merge without hiding their original waypoint nodes. Geometric inactive-side contacts remain events even when their three carriers agree.

The source is pure stdlib and imports no model, cover module, torch, or numerical runtime. It repeats only the four rational strip intervals fixed by H1. It introduces no tolerance, rounding, side probe, profile, launcher, or inference update. Serialization retains all rational coordinates and parameters as integer numerator/denominator pairs and does not mutate the exact schedule. The helper remains independent of the pending H2–H8 construction.

Nine test functions were authored. Their controls cover the default eight-event table; all four roots in one segment with independently computed rational contexts; shared-vertex deduplication; active/inactive tangent contacts; a merged boundary interval with an ordinary interior waypoint; boundary starts/ends; a wholly boundary-aligned path and ordinary nonboundary waypoints; decimal precision finer than float resolution and exact JSON-compatible serialization; and malformed/nonfinite/unordered/out-of-domain scalar/shape admission. Parameterized cases are present, but no collected or passing test total is claimed because tests were not run.

| File | SHA256 | Static result |
|---|---|---|
| `src/multiagent_elbo/experiments/neighborhood/hybrid_schedule.py` | `2366413168607a28f922d7e37b7e05cf192edf557a93ba5f0fb718cdfb03a4b2` | AST parsed; 136 lines; module not imported |
| `tests/rg_v2/test_neighborhood_hybrid_schedule.py` | `6ba3f03d7c0384a26abe8e357dc7cb8400696fa3bda6861105b63bb6c67f29ef` | AST parsed; 155 lines; nine test functions; not run |

Root owns the first focused execution, any integration, and the daily consolidated change log. Prior proof files and all existing code remain unchanged by this assignment.
