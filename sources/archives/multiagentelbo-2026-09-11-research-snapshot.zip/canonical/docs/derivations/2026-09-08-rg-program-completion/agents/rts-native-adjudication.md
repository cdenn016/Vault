<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Native adjudication of the frozen 58 claims

The exact 58 claims are accepted on their stated finite, regular, conditional, or recorded-outcome scopes. This is an atomic evidence assessment, not a ledger mutation or a claim of broader program completion. There are 52 mathematical claims (including the target) and six numerical observations. Every atomic result below supplies its exact statement and quantifiers, direct proof or retained record, reconstructed reasoning, substantive attack and response, and semantic prior-erasure result.

The target has one open recording obligation: its frozen evidence_ids list is empty. Its mathematical conjunction is supported by the existing assembly, the whole-dependency reconstruction Sections 2-11, and the original proofs cited below. Root must attach an actual direct DERIVATION evidence record with the correct artifact hash before recording target closure. Adding that link supplies no new proof. The atomic recommendations do not certify completion of the separate RTS terminal audit and release inventory.

Exactly the 58 claim IDs present in the frozen input ledger. New positive-ladder and broader R6 claims are outside this adjudication.

Target acceptance combines the universal finite-sum construction, adopted conditional regular/reduced/hybrid theorems, one exact executable interacting normalized root-action witness, and the specifically retained implementation records. It establishes neither every possible floating input nor a current-tree full-suite result. Broader infinite-hierarchy or physical program completion remains outside this frozen target.

## Method and independence

Fresh task context, inherited GPT-6 model family, shared filesystem and parent communications. Exact serving alias is unknown. This is a separately performed logical reconstruction, not cross-model corroboration or independent scientific reproduction.

Read-only file and source inspection, SHA-256 recomputation, standard-library JSON and XML parsing, and primary-source browsing. No scientific module import, test, GPU query/run, numerical replay, historical producer, tamper check, disabled verification gate, activation marker, configuration edit, ledger edit or Git mutation.

Mathematical acceptance uses the displayed derivations and exact finite algebra, never investigator agreement, validator success, or numerical agreement as proof. No positive-answer preference is used as a premise. The per-claim prior-erasure paragraphs identify what remains after removing that preference; probabilistic model priors such as a specified field law remain mathematical input data. All inherited assumption_ids arrays are empty, but each exact quantifier and cited derivation retains its typed hypotheses.

No kernel-checked formal proof was performed. No scientific reproduction, current-tree full-suite run, or new runtime comparison was performed. Tamper checks are user-excluded and were not run. These omissions are not relabeled as passes.

## Input and execution-record binding

The JSON companion [rts-native-adjudication.json](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/rts-native-adjudication.json) contains the full bindings: every input evidence ID, its recorded and current SHA-256, all proof input hashes, raw XML outcomes, retained manifest artifact hashes, and recorded-versus-current source hashes. Hashes are provenance checks, not proof of the assertions in a document.

| Binding | SHA-256 |
| --- | --- |
| ledger_sha256 | fbaaad84fd7e4a8584f1aadb7e3094ad39bd42db4b37eda29732757cd1afa3c9 |
| contract_file_sha256 | 50db7529fc2c5cb7c032cd4e3b6517516a93800ba32db8c2c50c226ddb2a369e |
| canonical_target_sha256 | b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029 |
| dag_sha256 | aaec1fa976e7049e39998a764b0eadeea5cbec3a3ef6a70e9b1d1291850df06b |

All 95 direct input evidence hashes matched. Seventeen retained XML files were parsed without running their tests; these comprise the six numerical-claim records plus five supplemental finite-witness files. Seven retained manifests and their listed artifact hashes were read. Eleven manifest/source pairs differ from the source snapshot at this report readback, chiefly evolving routing and dispatch files. Those differences are preserved in the JSON, and historical outcomes are not promoted to claims about the current tree. The listed source bindings are not a claim that a complete transitive environment snapshot was independently reproduced.

The earlier base/curvature focused record includes one failed test; later corrected and regression executions remain separate. The holonomy native abort remains a failed parent attempt with no JUnit, unknown child exit and unknown case count. Later passing XML does not erase that attempt or diagnose its cause. CPU execution remains CPU execution even where the installed Torch build supports CUDA.

The retained scale witness includes twelve original focused passes and one later bridge-focused pass with the changed native case. Its exact rational/cubic-field calculation, source and manifest bindings support an executable interacting fixed root action. The fixed object is not the entire growing graph law, and the observation does not claim an infinite interacting physical limit.

## Citation and analytic-premise audit

whole-dependency-reconstruction.md Section 11 maps boundary-factorization to the boundary posterior/prior identity. The exact universal Gaussian parent-kernel equivalence is proved in evolution.md E4; the native atomic record uses that direct source. The mapping error does not falsify E4.

A smooth submersion has an invertible selected derivative minor. The augmented equal-dimensional map (f(u,v),v) meets the local inverse-function hypotheses, producing the local section used in B2. The explicit projection witness has a global section. Primary source: [Theorem 3.3, PDF page 49 / printed page 41](https://math.stanford.edu/~ralph/math215b/book.pdf).

The compact smooth closed Riemannian scalar Laplacian is the explicitly conditional analytic premise. Setting scalar potential Q=0 and using the (-t)^k expansion gives the +R/6 diagonal coefficient. Normalizing and taking its log are derived in S6; no active-open-base heat process is inferred. Primary source: [Sections 1-2, equations (11), (49)-(54), (105)](https://arxiv.org/pdf/hep-th/9704166).

## Atomic results

### 1. target

**Exact statement.** Construct a mathematically typed and executable renormalization theory for the admitted MultiAgentELBO finite and regular smooth tiers: normalized local-to-collective laws and exact ELBO accounting; compatible overlap, gauge, and coarse-map composition; retained-state inference across scale and changing agent domains; exact effective actions with every conditional correction; and explicit criteria or obstructions for reduced closure, continuum evolution, and interacting fixed points. Each implemented finite realization must match the corresponding proved construction, and every unclosed generalization must remain an explicit obligation.

**Exact quantifiers.** For every finite normalized model, declared observation, finite agent cover, and composable gauge-equivariant coarse kernel admitted by Theory/SPEC.md, construct its exact retained coarse law, action, ELBO correction, and composition rule. For each regular smooth or reduced-family extension adopted in this run, prove the stated hypotheses imply its claimed evolution or error control. Supply at least one executable interacting renormalization fixed-point realization or a precise obstruction for the searched class. No claim covers all physical systems or identifies a context/path parameter with physical time.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** base-connection-descent, base-curvature-obstruction, base-curvature-prior, base-law-obstruction, base-presentation-numerics, base-section-descent, base-tower, boundary-factorization, curvature-model-numerics, diamond-fixed, diamond-gauge, diamond-recursion, event-current-chain, event-driven, event-fisher, event-log-closure, finite-support-extension, finite-tower, fisher-no-selected-penalty, gauge-latent-elbo, gauge-prior, gaussian-curvature-marginal, heat-prior-expansion, holonomy-chart-covariance, holonomy-degenerate-controls, holonomy-gaussian-bayes, holonomy-inference-numerics, holonomy-normalized-joint, holonomy-normalized-vfe, holonomy-retained-coarse, hybrid-arithmetic-boundary, hybrid-evolution-numerics, hybrid-exact-schedule, hybrid-kernel, hybrid-parent-limits, hybrid-parent-nonautonomy, hybrid-primary-comparison, hybrid-resolved-consistency, hybrid-side-gaussians, hybrid-zero-clock, mixture-driven-bound, mixture-flow, mixture-metric, moving-derivatives, moving-reduction-numerics, normalized-conditional-cancellation, plaquette-nonclosure, projectability, quotient-connection-metric, quotient-curvature-numerics, quotient-metric-composition, quotient-projector-curvature, quotient-scalar-no-extra-curvature, regular-discretization, regular-evolution, small-loop-classical, stochastic-gap

**Direct input evidence.** No direct evidence IDs are attached in the frozen ledger; see the target recording obligation.

**Load-bearing proof or record sections.** construction-or-strongest-theorem.md: all construction sections; agents/whole-dependency-reconstruction.md: Sections 2-11; agents/finite-core.md: F1-F4; agents/finite-support-amendment.md; agents/scale.md: SCALE-DIAMOND-Z2/FIXED/GAUGE; original proofs listed per ancestor.

**Reconstruction.** The universal conjunct starts with an admitted normalized joint and applies the finite common-channel construction; it does not promise extension of arbitrary incompatible local marginals. The adopted smooth/reduced claims follow from their stated positivity, differentiability, fixed-family, finite-event and comparison hypotheses, separately reconstructed below. The diamond serial sum and parallel product produce the nonproduct cubic fixed root action, with an executable exact field representation and retained successful controls. The optional geometric and probabilistic models have their own complete types and normalizers. These constructions together discharge the frozen finite/regular conjunction.

**Strongest scoped attack.** A finite collection of examples might be promoted to universal RG, or source reports might substitute for the requirement of an executable interacting witness.

**Proof response.** Universal finite claims have finite-sum proofs, conditional smooth claims have explicit integral/jump proofs, and the existential clause has a single exact algebraic witness plus retained source-bound execution. Infinite-volume, physical, universal-exponent, generic nonflat and current-tree full-suite conclusions are excluded. The target currently has no direct evidence_ids; linking the existing assembly and this reconstructed implication is a recording correction, not an additional scientific proof.

**Prior erasure.** Deleting any preference for an affirmative answer leaves a conditional construction, explicit failure boundaries, and a cubic sign-change proof. No claim in this implication presumes a universal interacting limit.

**Open obligation.** The frozen target has an empty evidence_ids list. Before recording its closure, add a supporting direct DERIVATION record linking the current assembly and/or this report's target implication with its actual hash. Existing whole-dependency-reconstruction.md Sections 2-11 plus original per-claim proofs are also sufficient proof components. This missing link is recording work, not a mathematical obstruction. The 58 recommendations do not themselves edit the ledger or constitute a terminal release.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 2. finite-tower

**Exact statement.** Common-channel finite reference/evidence/recognition towers retain normalization, exact action density, direct/staged composition, and the additive conditional-KL decomposition.

**Exact quantifiers.** For every admitted finite common-channel tower with finite initial KL.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-finite-tower [agents/coverage.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/coverage.md); evidence-finite-core-reconstruction [agents/finite-core.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/finite-core.md); evidence-finite-core-independent-reconstruction [agents/finite-core-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/finite-core-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/finite-core.md: F1-F2 and F4; agents/finite-core-interface-amendment.md.

**Reconstruction.** Row sums preserve the joint evidence, recognition mass and reference mass. Disintegrating the pushed reference gives exp(-A_Y)=E_mu[exp(-A_X)|Y]. Associativity of finite sums proves every finite tower. For Q=qC and R=pC the common channel cancels in the joint log ratio, and marginal/conditional factorization gives the nonnegative conditional-KL identity.

**Strongest scoped attack.** Different q/p channels, omitted reference offsets, or a gauge arrow moving the observed slice can make the asserted equality false.

**Proof response.** The proof uses one recognition-independent channel and the same pushed reference throughout. A reference of mass M is normalized only with the explicit restored +log M action offset; moving observations compare corresponding slices. Finite initial KL excludes undefined infinite subtraction.

**Prior erasure.** Only normalization, common-channel finite sums and the log-ratio identity are used.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 3. mixture-metric

**Exact statement.** The positive disjoint conditional embedding Q_r(x)=r_g(x)rho_x is injective and pulls back the full simplex Fisher metric to the bin-simplex Fisher metric.

**Exact quantifiers.** For every positive normalized within-bin rho and positive bin law r.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-mixture-metric [agents/reduced-event.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/reduced-event.md); reconstruction-mixture-metric [agents/event-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/reduced-event.md: Exact finite statement and domains.

**Reconstruction.** Summing Q_r over a bin recovers r, proving injectivity. Its tangent is u_b rho_x; summing its squared Fisher score over the normalized conditional gives sum_b u_b^2/r_b on zero-sum tangents.

**Strongest scoped attack.** Overlapping bins or a rho that depends on r would add derivatives or destroy the inverse marginal map.

**Proof response.** The stipulated disjoint fixed partition and normalized positive rho eliminate those terms. No claim covers a refitted embedding.

**Prior erasure.** The conclusion follows from the displayed derivative and bin normalization only.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 4. mixture-flow

**Exact statement.** The restricted reverse-KL Fisher flow has optimum pi_b proportional exp E_rho_b log(p/rho), exact exponential-coordinate interpolation, and nonincreasing objective.

**Exact quantifiers.** For every strictly positive finite target and frozen disjoint conditional family and every finite nonnegative flow time.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** mixture-metric

**Direct input evidence.** evidence-mixture-flow [agents/reduced-event.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/reduced-event.md); reconstruction-mixture-flow [agents/event-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/reduced-event.md: Restricted objective and exact step.

**Reconstruction.** Expansion gives KL(Q_r||p)=KL(r||pi)-log Z with pi proportional to exp ell. The bin Fisher gradient centers log(r/pi), so log odds relax linearly and yield the normalized geometric interpolation. The objective derivative is minus the r-variance of log(r/pi); Gibbs inequality gives the unique optimum.

**Strongest scoped attack.** Using target bin masses p_B as the optimum silently deletes within-bin conditional mismatch.

**Proof response.** ell_b=log p_B(b)-KL(rho_b||p(.|b)); the stated pi retains this penalty. The family and target are frozen in the descent assertion.

**Prior erasure.** The objective expansion and ODE solution require no assumption that a reduced optimum equals the full posterior.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 5. mixture-driven-bound

**Exact statement.** The driven full and fixed-conditional trajectories initialized equally satisfy osc log(q_i/Q_i)<=H_i and every current stochastic readout has TV at most tanh(H_i/4), with the stated discounted forcing-span recurrence.

**Exact quantifiers.** For every finite sequence of positive targets, nonnegative finite step sizes, fixed conditional partition, and changing row-stochastic readouts.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** mixture-flow

**Direct input evidence.** evidence-mixture-driven-bound [agents/reduced-event.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/reduced-event.md); reconstruction-mixture-driven-bound [agents/event-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/reduced-event.md: Driven finite history and approximation bound.

**Reconstruction.** Subtracting full and restricted log updates gives e_i=a_i e_(i-1)+(1-a_i)delta_i plus a scalar. Oscillation yields H_i by induction from equal initialization. For likelihood ratio range [m,M], the chord bound and M/m=exp D yield TV <= (sqrt(M/m)-1)/(sqrt(M/m)+1)=tanh(D/4). A common stochastic readout contracts the l1 norm.

**Strongest scoped attack.** Changing rho/partition or measuring through different readouts can defeat the forcing recurrence; a floating bound is not an enclosure.

**Proof response.** The quantified claim fixes rho/g and applies the same current channel to both laws. It concerns exact-real values, excluding conditional attention at zero occupancy and arithmetic certification.

**Prior erasure.** The recurrence and extremal likelihood-ratio inequality are proved without assuming approximation success.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 6. diamond-recursion

**Exact statement.** The homogeneous diamond hierarchy closes exactly on A(1+t sigma tau), including A_next=4 A^4(1+t^4), t_next=2t^2/(1+t^4), and direct/staged finite elimination.

**Exact quantifiers.** For every finite hierarchy depth, A>0, and 0<=t<1.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-diamond-recursion [agents/scale.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/scale.md); reconstruction-diamond-recursion [agents/scale-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/scale-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/scale.md: SCALE-DIAMOND-Z2.

**Reconstruction.** A two-edge series sum is 2A^2(1+t^2 sigma tau). Multiplying two conditionally independent branches gives 4A^4[(1+t^4)+2t^2 sigma tau]. Each interior assignment appears exactly once; induction proves direct/staged elimination for all finite depths and retains A_next and the partition.

**Strongest scoped attack.** Sharing the two branch interiors or dropping amplitude would invalidate the finite recursion.

**Proof response.** The graph construction has disjoint interiors and identifies only the prescribed endpoints. The amplitude recurrence is explicit; only the normalized root action is compared across scales.

**Prior erasure.** The recursion is a four-weight algebraic identity and finite induction, with no assumed fixed point.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 7. diamond-fixed

**Exact statement.** The diamond interaction map has exactly one fixed t in (0,1), the isolated root of t^3+t^2+t-1, with nonproduct normalized root law and quotient derivative 2(1-t)/t in (4/3,2).

**Exact quantifiers.** Exactly one t in (0,1); the stated fixed law and derivative hold at that root.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** diamond-recursion

**Direct input evidence.** evidence-diamond-fixed [agents/scale.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/scale.md); reconstruction-diamond-fixed [agents/scale-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/scale-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/scale.md: SCALE-DIAMOND-FIXED; agents/scale-verification.md: SV04 and exact-field reconstruction.

**Reconstruction.** Factoring f(t)-t reduces the interior fixed equation to g(t)=t^3+t^2+t-1=0. Its derivative is positive, g(1/2)<0 and g(3/5)>0, proving one root. The normalized law has uniform marginals and correlation t>0, hence is nonproduct. Substitution of t^4=2t-1 into f' gives 2(1-t)/t in (4/3,2).

**Strongest scoped attack.** A root-law fixed point could be misreported as a fixed full growing-graph law, stable phase, rational parameter, or universal exponent.

**Proof response.** The comparison carrier is the ordered two-root law modulo its amplitude. Full amplitudes are retained, the homogeneous direction is repelling, and the exact implementation uses an irreducible cubic field. None of the stronger identifications is needed.

**Prior erasure.** Existence follows from explicit polynomial signs and monotonicity, not a presumed affirmative existence result.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 8. diamond-gauge

**Exact statement.** The same diamond interaction recursion is Z2-covariant on flat fixed link backgrounds, whereas opposite branch flux gives zero pair coupling with its distinct normalizer.

**Exact quantifiers.** For every endpoint/frame sign choice and both branch-product sectors in the finite cell; flat recursion iterates when all relevant cycles are flat.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** diamond-recursion

**Direct input evidence.** evidence-diamond-gauge [agents/scale.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/scale.md); reconstruction-diamond-gauge [agents/scale-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/scale-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/scale.md: SCALE-DIAMOND-GAUGE.

**Reconstruction.** Vertex signs cancel within each dressed edge and internal spin sum. Equal branch products give the original recursion with the coarse dressed link; flatness permits a spanning-tree trivialization. Opposite branch products multiply to a constant 4A^4(1-t^4), proving the distinct flux-sector response.

**Strongest scoped attack.** Holding edge data fixed while flipping only a root, or extending the scalar fixed point to opposite flux, breaks the claimed covariance.

**Proof response.** The gauge arrow transforms both spins and links. Iteration is explicitly restricted to flat relevant cycles; opposite flux is retained as a separate normalizer and zero coupling.

**Prior erasure.** Both sectors are evaluated algebraically rather than assuming all backgrounds support the same interaction.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 9. stochastic-gap

**Exact statement.** A feasible positive fine-law minimization with a fixed stochastic forward channel can have strictly larger KL than the unconstrained joint-lift coarse KL.

**Exact quantifiers.** There exists the explicit two-state positive example in the scale construction.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-stochastic-gap [agents/scale.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/scale.md); reconstruction-stochastic-gap [agents/scale-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/scale-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/scale.md: SCALE-STOCHASTIC-CONTRACTION.

**Reconstruction.** The displayed positive channel is invertible as a two-state affine marginal map and qC=(5/8,3/8) forces q=(3/4,1/4). Its KL gap from the coarse law is log(6912/3125)/8>0. The unrestricted reverse-conditional lift has forward probability 5/6 rather than the prescribed 3/4, so is infeasible in the constrained problem.

**Strongest scoped attack.** A posterior-conditional joint lift might be mistaken for an admissible fixed-forward-channel fine law.

**Proof response.** The explicit forward row and unique feasible q distinguish the feasible sets. This is a positive existence-of-gap theorem, not a refutation of common-channel KL decomposition.

**Prior erasure.** Uniqueness of the affine constraint and the integer inequality prove the claim without a chosen expected outcome.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 10. moving-reduction-numerics

**Exact statement.** The recorded 976-row CPU study and 92 selected tests pass their declared mechanical comparisons while fixed conditional bins retain material approximation and storage costs.

**Exact quantifiers.** Only the source/config/runtime-bound recorded study and JUnit cases.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: NUMERICAL_OBSERVATION.

**Direct dependencies.** None.

**Direct input evidence.** evidence-moving-reduction-numerics [evidence/moving-reduction-results.json](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/evidence/moving-reduction-results.json); evidence-recorded-numerics-reconstruction [agents/numerical-record-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/numerical-record-reconstruction.md)

**Load-bearing proof or record sections.** evidence/moving-reduction-results.json; agents/numerical-record-reconstruction.json: moving group and independent_record_readback.

**Reconstruction.** The raw retained XML has 20 focused plus 72 regression passing cases. The retained summary has 976 rows across four paths; its approximation maxima and storage records match the numerical reconstruction. Event storage remains 4112/4128/4160/6144 bytes for budgets 2/4/8/full, rather than a claimed total-memory saving.

**Strongest scoped attack.** Historical route changes or omitted storage could be hidden behind a combined current-tree pass.

**Proof response.** Accept only the source/config/runtime-bound recorded observations. Historical routes/dispatch and older regression bindings are preserved as drift; no new reproduction, current-tree suite, outward roundoff enclosure or speedup is inferred.

**Prior erasure.** The verdict is determined by retained rows and raw XML, including costs, without an expectation that reduction must succeed.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No scientific reproduction; no current-tree full-suite claim. Recorded source/config/runtime-bound observations only.

### 11. event-log-closure

**Exact statement.** Finite log-affine exponential families are invariant under full-simplex reverse-KL Fisher steps exactly when the positive target lies in the declared affine log span for a nonzero finite step.

**Exact quantifiers.** Every finite positive family with a fixed base density and identifiable fixed statistics; nonnegative finite step, with necessity requiring positive step.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-event-log-closure [agents/event-closure.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-closure.md); reconstruction-event-log-closure [agents/event-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/event-closure.md: Finite log-affine closure theorem.

**Reconstruction.** Taking a geometric Fisher step between h exp(theta.T) and h exp(eta.T) produces parameter a theta+(1-a)eta. Conversely, for 0<a<1, subtracting a log q_theta from an in-family output and dividing by 1-a forces log p into the same affine span.

**Strongest scoped attack.** The zero-time identity could be used to infer target membership, or moving statistics could be treated as fixed.

**Proof response.** Necessity is restricted to nonzero finite time, and h/T remain fixed. Positivity makes every logarithm finite.

**Prior erasure.** The equivalence follows by reversible affine-log algebra, without assuming model closure in advance.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 12. event-current-chain

**Exact statement.** The current four-label four-position event preparation and every posterior target belong to the identifiable 39-coordinate chain family.

**Exact quantifiers.** Every admitted context and finite nonnegative coupling under the fixed local_tree observation and latent-record construction.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** event-log-closure

**Direct input evidence.** evidence-event-current-chain [agents/event-closure.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-closure.md); reconstruction-event-current-chain [agents/event-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/event-closure.md: Source trace; A constant-free 39-coordinate basis.

**Reconstruction.** Anchored unary contrasts contribute 12 coordinates and three anchored pair tables contribute 27. Evaluation at zero, one changed node, and one changed adjacent pair proves independence modulo constants. The actual chain product divided by two separators has only these terms; its observed likelihood is a positive function on the existing (0,1) edge.

**Strongest scoped attack.** An added nonedge observation or a higher-order latent factor would leave the 39-coordinate family.

**Proof response.** The claim is explicitly tied to record_inputs/event_system and the fixed existing likelihood. The fixed 256-state latent carrier is retained even where Gaussian agents are absent.

**Prior erasure.** Membership is obtained by expanding actual local factors, not by presuming any source law is a tree.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 13. event-fisher

**Exact statement.** The exponential-family Fisher matrix is the statistic covariance and natural reverse-KL velocity toward an in-family target is eta minus theta.

**Exact quantifiers.** Every finite natural parameter in the positive identifiable finite family.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** event-log-closure

**Direct input evidence.** evidence-event-fisher [agents/event-closure.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-closure.md); reconstruction-event-fisher [agents/event-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/event-closure.md: Fisher pullback, objective and nondegeneracy.

**Reconstruction.** Finite differentiation gives dA=E T and d2A=Cov(T). Positivity and independence modulo constants make that covariance SPD. Differentiating KL(q_theta||q_eta) gives G(theta-eta), so the negative Fisher gradient is eta-theta.

**Strongest scoped attack.** Confusing an ordinary Euclidean update with natural gradient, or allowing redundant statistics, would invalidate cancellation.

**Proof response.** The score pullback explicitly identifies G as the Fisher metric and minimality makes it invertible. No uniform boundary conditioning is claimed.

**Prior erasure.** Metric and velocity are derived from normalized finite sums rather than selected for a desired update.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 14. event-driven

**Exact statement.** The driven natural-coordinate equation has the stated integral solution and endpoint-target discretization bound, with parent TV contraction.

**Exact quantifiers.** Finite interval; integrable nonnegative rate and integrable rate times target; uniform continuity for the modulus estimate.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** event-fisher

**Direct input evidence.** evidence-event-driven [agents/event-closure.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-closure.md); reconstruction-event-driven [agents/event-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/event-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/event-closure.md: Driven continuous evolution; agents/event-verification.md: E5.

**Reconstruction.** Multiplying theta'=lambda(eta-theta) by exp Lambda gives the integral solution; its difference equation proves uniqueness. Exact interval-clock endpoint updates integrate piecewise constant targets against the same nonnegative kernel. Uniform continuity bounds their difference by kernel mass times the target modulus; finite softmax derivatives and common channels control law/readout differences.

**Strongest scoped attack.** Endpoint samples of merely measurable targets or approximated clock increments would not obey the claimed bound.

**Proof response.** Existence uses integrability of lambda and lambda eta; the modulus estimate additionally uses uniform continuity and exact integrated increments. Moving targets do not imply globally decreasing KL.

**Prior erasure.** The solution and quadrature bound use linear forcing, with no assumed convergence from a refinement plot.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 15. regular-evolution

**Exact statement.** The prescribed Gaussian and positive-event covariant Fisher system has the explicit unique positive regular-stratum solution.

**Exact quantifiers.** The fixed-dimensional, compact-interval regularity and positivity hypotheses of evolution E1.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-regular-evolution [agents/evolution.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution.md); reconstruction-regular-evolution [agents/evolution-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/evolution.md: E1, Additional proof details.

**Reconstruction.** The Gaussian Fisher score calculation yields J'=A^T J+JA+gamma(J_p-J) and h'=A^T h+gamma(h_p-h). Phi'=-A Phi cancels transport in barred coordinates; integrating factors give unique solutions and convex averaging preserves an initial/target SPD floor. Positive categorical log odds obey the same scalar equation.

**Strongest scoped attack.** Singular targets, suppressed connection terms or an inferred physical clock would overstate this regular-stratum theorem.

**Proof response.** Bounded continuous coefficients, compact interval, fixed dimension and positive targets are hypotheses; Gaussian integral differentiation is dominated by polynomial Gaussian envelopes. The allocated clock can stall and is not physical time.

**Prior erasure.** The transport and integrating-factor constructions directly establish existence; positivity is proved, not presumed at changing rank.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 16. regular-discretization

**Exact statement.** Exact segment transport followed by arrival-target relaxation has the stated first-order or modulus coordinate bound.

**Exact quantifiers.** The exact transport, constant mobility and parallel-frame target regularity of evolution E2, away from dimension jumps. Read with evolution-amendment.md: common initial/target precision floor and time-uniform or integrably bounded Lipschitz coefficient.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** regular-evolution

**Direct input evidence.** evidence-regular-discretization [agents/evolution.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution.md); reconstruction-regular-discretization [agents/evolution-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution-verification.md); amendment-regular-discretization [agents/evolution-amendment.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution-amendment.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/evolution.md: E2; agents/evolution-amendment.md: common precision floor.

**Reconstruction.** The arrival-target defect is an integral of target variation, bounded by gamma L delta_s^2/2. The update contraction factor lies in [0,1], so summed errors are O(h_max), or a vanishing modulus for continuous forcing. Inverse precision conversion uses ||J^-1-K^-1|| <= j_common^-2 ||J-K||.

**Strongest scoped attack.** A target-only precision floor fails when J0 is smaller, and unresolved jumps defeat a regular-coordinate error norm.

**Proof response.** The explicit amendment uses min(j_initial,j_target). This theorem assumes exact segment transport and avoids dimension jumps; hybrid closure supplies its separate interface.

**Prior erasure.** The rate follows from local integral defects and stability, not observed numerical refinement.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 17. hybrid-kernel

**Exact statement.** A finite one-sided schedule with the declared Gaussian survivor transport and prior-conditional entry kernels defines the stated positive hybrid law process.

**Exact quantifiers.** The event-resolved one-sided regularity and full-state assumptions of evolution E3; not arbitrary accumulating events.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** regular-evolution

**Direct input evidence.** evidence-hybrid-kernel [agents/evolution.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution.md); reconstruction-hybrid-kernel [agents/evolution-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/evolution.md: E3.

**Reconstruction.** Marginalize departures, transport survivors invertibly, and attach the normalized new Gaussian reference conditional. The Schur complement is SPD; the augmented covariance is a triangular congruence of survivor covariance and conditional noise. Finitely many regular segments and fixed kernels recursively define a unique positive hybrid law.

**Strongest scoped attack.** Empty survivors, accumulating events or an unspecified order of conditional births leave the process undefined.

**Proof response.** E3 excludes empty survivors and accumulation and declares the event order, one-sided data and reference kernel. It does not compare old and new evidence without further hypotheses.

**Prior erasure.** The positive process is explicitly constructed from normalized kernels; no smooth SPD continuation through rank change is assumed.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 18. boundary-factorization

**Exact statement.** A universal parent kernel for an affine Gaussian jump exists exactly when the projected jump kills the old parent-map kernel.

**Exact quantifiers.** All positive Gaussian preparations and full-row-rank deterministic parent maps, under evolution E4.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-boundary-factorization [agents/evolution.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution.md); reconstruction-boundary-factorization [agents/evolution-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/evolution.md: E4 (not the boundary-posterior factorization).

**Reconstruction.** If ker F_minus lies in ker(F_plus M), a right inverse R_minus gives L=F_plus M R_minus and the parent affine Gaussian kernel reproduces every output. Necessity compares equal-covariance Gaussians whose means differ by v in ker F_minus; their identical old parent laws cannot map to different means F_plus Mv.

**Strongest scoped attack.** The whole-dependency coverage table's Section 5 locator mentions posterior/prior factorization instead of this universal parent-kernel criterion.

**Proof response.** Use the direct E4 proof, which establishes both necessity and sufficiency for all positive Gaussian preparations. Singular output noise is a valid Markov kernel; full-row-rank parent maps ensure the actual pushed SPD law.

**Prior erasure.** The two-preparation counterexample and right-inverse construction prove the equivalence without presuming parent autonomy.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 19. moving-derivatives

**Exact statement.** Moving Gaussian splits and finite stochastic readouts obey the stated connection and channel-derivative identities.

**Exact quantifiers.** Constant-rank regular strata and the differentiability hypotheses of evolution E5; conditionals only on occupied rows.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-moving-derivatives [agents/evolution.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution.md); reconstruction-moving-derivatives [agents/evolution-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/evolution.md: E5.

**Reconstruction.** Product differentiation gives D(Fmu)=F Dmu+(dF+A_Y F-F A)mu and both corresponding covariance-slot terms. For Q=qC, differentiation gives q'C+qC'. Conditional log-ratio disintegration produces E5.4 on occupied rows; quotient attention derivatives require positive occupancy.

**Strongest scoped attack.** Freezing the channel or completing a conditional at zero occupancy suppresses genuine terms.

**Proof response.** Constant-rank differentiability and occupied-row domains are explicit; retained augmentation reconstructs the fine law and hence the moving-channel contribution. No zero-padding SPD claim is made.

**Prior erasure.** The identities are product rules and conditional factorization, independent of an intended reduction.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 20. projectability

**Exact statement.** Exact reduced continuous evolution and hybrid jumps require the separate fiber-constancy and boundary-factorization conditions; controlled residuals obey the stated perturbation bound.

**Exact quantifiers.** The differentiability, local uniqueness and finite jump hypotheses in evolution E6. Read with evolution-amendment.md: common initial/target precision floor and time-uniform or integrably bounded Lipschitz coefficient.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-projectability [agents/evolution.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution.md); reconstruction-projectability [agents/evolution-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution-verification.md); amendment-projectability [agents/evolution-amendment.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/evolution-amendment.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/evolution.md: E6; agents/evolution-amendment.md: uniform/integrable Lipschitz.

**Reconstruction.** A universal reduced velocity must be constant on each retained fiber; when it is, the projected solution solves the reduced equation. An integrable state-Lipschitz coefficient proves uniqueness and the forced-error Gronwall bound by iterated integral expansion. Jumps separately require pi_plus B=Bbar pi_minus and propagate error by their finite Lipschitz constants.

**Strongest scoped attack.** Pointwise time-dependent spatial Lipschitz continuity can admit nonuniqueness; zero quotient curvature does not imply autonomous evolution.

**Proof response.** The amendment excludes the continuous example V(t,x)=2t clip(x/t^2,-1,1) through its nonintegrable 2/t coefficient. The rotating-projection counterexample retains the independent projectability and jump-square requirements.

**Prior erasure.** Closure is an explicit conditional criterion, with counterexamples to omitted hypotheses; the desired reduced dynamics is not a premise.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 21. base-section-descent

**Exact statement.** A fiber-valued section descends through a surjective submersion exactly when its declared target-fiber image is constant on each base-map fiber; the descended smooth section is unique.

**Exact quantifiers.** The bundle maps and smoothness hypotheses in base-descent B2.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-base-section-descent [agents/base-descent.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-descent.md); reconstruction-base-section-descent [agents/base-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/base-descent.md: B2 and Local-section argument.

**Reconstruction.** Fiber constancy makes sbar(c)=Psi(s(b)) independent of the chosen b over c and surjectivity makes it unique. Full rank supplies a local section via the augmented map (f(u,v),v) and the inverse function theorem, so sbar is locally smooth. Agreement on overlaps glues those local expressions.

**Strongest scoped attack.** Local vertical differentiation alone misses disconnected fiber components, and an arbitrary quotient need not have smooth local sections.

**Proof response.** The hypothesis is constancy on each complete fiber of a given smooth surjective submersion. The local invertible minor maps directly to the inverse function theorem; the explicit product witness has a global section.

**Prior erasure.** Existence is constructed from fiber values and local sections rather than assumed smooth descent.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 22. base-connection-descent

**Exact statement.** The explicit SO(2) pullback construction over (x,y,z) to (x,y) has compatible principal/associated connections and complete law/evaluator/channel descent.

**Exact quantifiers.** The declared redundant-base family B1-B4; this does not aggregate heterogeneous informative base data.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** base-section-descent

**Direct input evidence.** evidence-base-connection-descent [agents/base-descent.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-descent.md); reconstruction-base-connection-descent [agents/base-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/base-descent.md: B1-B4.

**Reconstruction.** For Pi((c,z),g)=(c,h^-1g), substituting into the principal connection form gives A=H f*Abar H^-1-dH H^-1. Psi=H^-1 then has zero covariant defect. Conjugating every law, evaluator, observation and channel by the same fiber maps proves the complete commuting squares and unchanged evidence.

**Strongest scoped attack.** A nonzero displayed A_z may be mistaken for a descent obstruction, or redundant z descent may be called informative aggregation.

**Proof response.** The passive term -gamma J dz cancels after comparison and curvature has no mixed component. Every invariant datum is independent of z by construction; no averaging or nonidentity informative reduction is asserted.

**Prior erasure.** The family is a declared pullback witness; it does not assume arbitrary source data descend.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 23. base-tower

**Exact statement.** The explicit two-stage noninjective base projection and its ordered frame, connection and law maps compose exactly.

**Exact quantifiers.** The finite pullback tower in base-descent B5.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** base-connection-descent

**Direct input evidence.** evidence-base-tower [agents/base-descent.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-descent.md); reconstruction-base-tower [agents/base-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/base-descent.md: B5.

**Reconstruction.** The ordered frame product h_02=h_01 f_01*h_12 has inverse in the reverse order, so principal maps compose. Product differentiation gives the same directly pulled-back connection, and pushforward/conjugacy cancellation proves composition of laws, evaluators and vertical channels.

**Strongest scoped attack.** Resetting an intermediate frame, reference or connection can destroy direct/staged equality.

**Proof response.** All intermediate data are inherited by the explicit pullback construction; their order is retained even though this SO(2) witness commutes.

**Prior erasure.** Composition is checked as equality of explicit maps rather than assumed from the word tower.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 24. base-law-obstruction

**Exact statement.** The smooth positive Gaussian family with varying mean norm cannot descend through the declared invertible frame map along the forgotten base coordinate.

**Exact quantifiers.** There exists the explicit z-dependent family in base-descent B6a.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-base-law-obstruction [agents/base-descent.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-descent.md); reconstruction-base-law-obstruction [agents/base-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/base-descent.md: B6a.

**Reconstruction.** Undoing H(z) leaves N((1+z/4,0),I), which varies on the forgotten z fiber. Its KL to N(0,I) is (1+z/4)^2/2 and varies as well. A common invertible frame comparison cannot remove that invariant difference.

**Strongest scoped attack.** One might substitute an information-destroying stochastic map and claim to defeat the obstruction.

**Proof response.** The theorem concerns the declared invertible comparison and simultaneous law data. A different terminal/stochastic map is a new construction with its own information loss.

**Prior erasure.** The obstruction is an explicit positive Gaussian family and scalar calculation, independent of search expectations.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 25. base-curvature-obstruction

**Exact statement.** A nonzero curvature contraction with a vertical base direction obstructs pullback connection descent through the declared base projection.

**Exact quantifiers.** The explicit nonzero mixed-curvature family in base-descent B6b.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-base-curvature-obstruction [agents/base-descent.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-descent.md); reconstruction-base-curvature-obstruction [agents/base-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/base-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/base-descent.md: B6b.

**Reconstruction.** The added term lambda z J dx yields curvature kappa J dx wedge dy+lambda J dz wedge dx. Its contraction with partial_z is nonzero. A curvature pulled back through f(x,y,z)=(x,y) annihilates every f-vertical tangent, and gauge conjugation preserves nonzeroness.

**Strongest scoped attack.** An extra dz connection coefficient alone is not an invariant obstruction.

**Proof response.** The proof uses mixed curvature, not a gauge-dependent coefficient; the positive base construction itself has a removable dz term.

**Prior erasure.** The nonzero contraction directly contradicts the necessary pullback identity.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 26. gauge-prior

**Exact statement.** The compact-link action defines a normalized gauge-invariant prior with exp(-2 sum kappa)<=Z<=1.

**Exact quantifiers.** Every finite graph, compact group, finite unitary representation, selected oriented faces and nonnegative finite couplings in G1.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-gauge-prior-derivation [agents/gauge-action.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/gauge-action.md); evidence-gauge-prior-reconstruction [agents/gauge-action-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/gauge-action-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/gauge-action.md: G1.

**Reconstruction.** Unitary eigenvalues give 0<=S<=2 sum kappa. Integrating exp(-S) against normalized product Haar bounds Z between exp(-2 sum kappa) and 1. Endpoint gauge actions preserve Haar, and loop products conjugate, preserving the trace action.

**Strongest scoped attack.** Noncompact groups, negative unbounded actions, or nonfaithful representations could invalidate stronger claims.

**Proof response.** The domain is compact and unitary with finite nonnegative couplings. Zero action implies rho(H)=I, not H=e absent faithfulness. No noncompact extension is used.

**Prior erasure.** The normalizer bounds and change of variables establish the prior without assuming it proper.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 27. gauge-latent-elbo

**Exact statement.** The declared latent-link/matter joint has VFE equal to expected matter VFE plus expected gauge action, Haar-relative entropy and log partition.

**Exact quantifiers.** Every admitted recognition disintegration with finite displayed terms for the normalized joint G2.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** gauge-prior

**Direct input evidence.** evidence-gauge-latent-elbo-derivation [agents/gauge-action.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/gauge-action.md); evidence-gauge-latent-elbo-reconstruction [agents/gauge-action-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/gauge-action-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/gauge-action.md: G2-G5.

**Reconstruction.** Normalize the conditional matter-observation law for each field, then integrate against the proper gauge prior. Substituting Q=R Q_Theta and the joint density gives E_R F_m+KL(R||Haar)+E_R S+log Z_g, with the posterior form obtained by dividing by observation evidence.

**Strongest scoped attack.** A prescribed background or a normalized conditional could acquire a spurious extra action by dropping the field normalizer.

**Proof response.** The field is a declared latent and all displayed terms are finite. Fixed-background constants cancel; a continuous Dirac recognition is excluded by finite KL. Reference/counting conversions retain their constants.

**Prior erasure.** The formula follows from the declared normalized joint, not from gauge symmetry selecting an energy.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 28. plaquette-nonclosure

**Exact statement.** Eliminating the displayed two-square spin factor generates a strictly positive exterior-loop logarithmic coefficient that cannot be represented by elementary face terms alone.

**Exact quantifiers.** For every 0<t<1 in the finite two-square factor model G16-G19.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-plaquette-nonclosure-derivation [agents/gauge-action.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/gauge-action.md); evidence-plaquette-nonclosure-reconstruction [agents/gauge-action-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/gauge-action-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/gauge-action.md: G16-G19.

**Reconstruction.** Uniform spin summation retains exactly the four even subgraphs of the two-square graph, giving 1+t^4(H1+H2)+t^6 H1H2. The cross-ratio numerator exceeds its denominator by 4(t^6-t^8)>0, so the mixed log coefficient is positive. The four binary Fourier functions are independent.

**Strongest scoped attack.** The generated term might disappear after a scalar normalization or be expressible as separate face terms.

**Proof response.** A scalar changes only the constant Fourier coefficient; H1H2 is independent of 1,H1,H2 on all four realized sectors.

**Prior erasure.** The finite expansion and positive integer-power difference prove nonclosure, without assuming generic operator generation.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 29. small-loop-classical

**Exact statement.** The stated unitary plaquette action converges with O(a) error to the signed curvature-squared Riemann sum on the fixed flat box.

**Exact quantifiers.** For smooth prescribed unitary transport with the uniform radial-gauge and mesh hypotheses and scaling in G8-G12; no probability-measure limit.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-small-loop-classical-derivation [agents/gauge-action.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/gauge-action.md); evidence-small-loop-classical-reconstruction [agents/gauge-action-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/gauge-action-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/gauge-action.md: G7-G12 and fixed-box mesh paragraph.

**Reconstruction.** Radial gauge expresses A through bounded Lipschitz curvature. Ordered-integral and logarithm tails yield log U=-a^2 F+O(a^3). Anti-Hermitian eigenphase Taylor expansion gives the positive action coefficient a^4||F||_F^2/(2n) with O(a^5) local error. Multiplying by a^(d-4), summing O(a^-d) cells and controlling quadrature gives O(a).

**Strongest scoped attack.** Wrong trace sign or promotion of a classical sampled action limit to a normalized random-field limit would overclaim.

**Proof response.** The convention is D=d+A with anti-Hermitian curvature, so -tr(F^2) is positive. Uniform radial-gauge/mesh bounds and fixed flat-box quadrature are explicit; no measure or partition limit is asserted.

**Prior erasure.** The limit follows from explicit analytic error bounds, not assumed continuum physics.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 30. fisher-no-selected-penalty

**Exact statement.** The same nonflat Fisher geometry admits zero or positive VFE under distinct normalized posteriors; natural-gradient conversion selects no scalar-curvature penalty.

**Exact quantifiers.** The explicit positive three-outcome example and the finite regular-family hypotheses in S2.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-fisher-no-selected-penalty-derivation [agents/statistical-base-curvature.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature.md); evidence-fisher-no-selected-penalty-reconstruction [agents/statistical-base-curvature-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/statistical-base-curvature.md: S2.

**Reconstruction.** On the three-outcome simplex the square-root embedding identifies Fisher geometry with a radius-two spherical patch. At the same q, posterior p0=q gives zero VFE while p1=(1/2,1/4,1/4) gives log(32/27)/3>0 under unit evidence. The metric and curvature are unchanged. Inverting the metric maps a supplied differential to a vector and adds no scalar.

**Strongest scoped attack.** A nonzero Fisher curvature might be used to justify adding a universal curvature penalty.

**Proof response.** The two normalized models have the same geometry and distinct objectives, directly defeating selection from geometry alone. The claim does not forbid a separately declared curvature-dependent prior.

**Prior erasure.** The result is a constructed comparison of normalized models, not a presumed interpretation of Fisher curvature.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 31. base-curvature-prior

**Exact statement.** The declared two-sphere curvature prior is proper and its VFE equals the stated binary KL including its log partition.

**Exact quantifiers.** For every finite real lambda and positive two-component recognition mass in S3.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-base-curvature-prior-derivation [agents/statistical-base-curvature.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature.md); evidence-base-curvature-prior-reconstruction [agents/statistical-base-curvature-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/statistical-base-curvature.md: S3.

**Reconstruction.** Sphere areas give reference weights (1/5,4/5), and scalar curvatures are (2,1/2). For any finite lambda the two positive exponentials have a finite positive sum. Integrating a recognition uniform within each component gives the stated binary KL with its exact log partition.

**Strongest scoped attack.** A curvature-dependent term held external or constant on one sphere would cancel rather than produce the proposed force.

**Proof response.** This is a random base component under a declared prior, with distinct curvatures. The single-sphere and conditioned-context cancellation controls are explicitly separate.

**Prior erasure.** Properness and VFE are direct two-component normalization; no universal coefficient is inferred.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 32. gaussian-curvature-marginal

**Exact statement.** Eliminating the declared unnormalized finite Gaussian factor adds positive half log determinant to the retained action with all constants preserved.

**Exact quantifiers.** Continuous finite-dimensional uniformly SPD H and continuous V on the compact retained probability-reference space in S5.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-gaussian-curvature-marginal-derivation [agents/statistical-base-curvature.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature.md); evidence-gaussian-curvature-marginal-reconstruction [agents/statistical-base-curvature-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/statistical-base-curvature.md: S5.

**Reconstruction.** Diagonalize SPD H in the unnormalized factor exp(-V-x^T Hx/2). Each scalar Gaussian integral contributes sqrt(2pi/lambda_i), yielding exp(-V)(2pi)^(r/2)det(H)^-1/2. Thus the negative log action is V+log det(H)/2-r log(2pi)/2. Compactness and uniform SPD bounds make the retained normalizer finite and positive.

**Strongest scoped attack.** A sign error or starting from an already normalized conditional reverses or cancels the purported determinant contribution.

**Proof response.** The claim is confined to the declared unnormalized Gaussian factor and preserves its Lebesgue normalizing constant.

**Prior erasure.** The determinant is obtained by direct integration, without invoking a quantum-loop analogy.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 33. normalized-conditional-cancellation

**Exact statement.** Eliminating an already normalized Gaussian conditional preserves the specified parent prior and generates no additional marginal determinant.

**Exact quantifiers.** Every normalized hierarchical Gaussian model in S5 with the stated probability references.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-normalized-conditional-cancellation-derivation [agents/statistical-base-curvature.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature.md); evidence-normalized-conditional-cancellation-reconstruction [agents/statistical-base-curvature-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/statistical-base-curvature.md: S5 cancellation control.

**Reconstruction.** The conditional N(0,H^-1) already contains det(H)^1/2/(2pi)^(r/2). Its integral is one pointwise, so integrating P0(du)N(dx|u) yields exactly P0; no extra marginal determinant remains.

**Strongest scoped attack.** Reusing the unnormalized-factor determinant in this hierarchical model would double count normalization.

**Proof response.** The two joint laws are distinct, and pointwise conditional normalization fixes which formula applies.

**Prior erasure.** The cancellation is a direct integral identity and supplies an explicit negative control for automatic curvature generation.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 34. heat-prior-expansion

**Exact statement.** The normalized compact heat-diagonal prior has the stated centered scalar-curvature first-order contribution to KL with uniform O(t^2) error.

**Exact quantifiers.** Conditional on the compact closed smooth scalar heat-kernel theorem and finite-KL recognition in S6; no implementation on the active open context base.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-heat-prior-expansion-derivation [agents/statistical-base-curvature.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature.md); evidence-heat-prior-expansion-reconstruction [agents/statistical-base-curvature-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/statistical-base-curvature.md: S6; agents/whole-dependency-reconstruction.md: Section 8.

**Reconstruction.** Under the explicitly imported compact closed scalar heat theorem, divide 1+tR/6+O(t^2) by its volume average. The normalized density is 1+t(R-E_nu R)/6+O(t^2) uniformly. Uniform logarithmic expansion and finite KL give the stated centered first-order correction after Q integration.

**Strongest scoped attack.** A diagonal heat value is not itself a normalized transition probability, and boundary/noncompact settings need additional terms.

**Proof response.** The statement is conditional on the named uniform compact heat theorem and defines a separately normalized diagonal prior. The active open base is not covered. The sign maps to scalar Q=0 in Avramidi's (-t)^k convention.

**Prior erasure.** The VFE consequence is derived by normalization from the explicit analytic premise; existence on the active open base is neither assumed nor concluded.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 35. base-presentation-numerics

**Exact statement.** The retained 20-presentation CPU study realizes the declared base/frame descent with its recorded identity residuals and exact attention-mask support.

**Exact quantifiers.** Only the executed configured studies with retained manifest, JUnit and source identities.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: NUMERICAL_OBSERVATION.

**Direct dependencies.** base-tower

**Direct input evidence.** evidence-base-presentation-numerics [evidence/base-and-curvature-results.json](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/evidence/base-and-curvature-results.json); evidence-recorded-numerics-reconstruction [agents/numerical-record-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/numerical-record-reconstruction.md)

**Load-bearing proof or record sections.** evidence/base-and-curvature-results.json; agents/numerical-record-reconstruction.json: base group and base_attention_support.

**Reconstruction.** The retained study has 20 presentations and identity residual 2.1094237467877974e-15. Its reconstruction reads 3160 arrays, 60 beta-domain masks and 360 undefined entries; defined-row normalization error is at most 2.220446049250313e-16. Raw XML retains the original 27-pass/one-failure packet and later corrected case.

**Strongest scoped attack.** An incorrect initial active-count expectation might be erased, or an attention mask could be mistaken for pairwise active support.

**Proof response.** The failure chronology is preserved. Beta is defined exactly when receiver alpha is positive; undefined entries remain NaN. Acceptance is for these recorded source-bound observations, with historical route drift retained.

**Prior erasure.** The verdict follows saved records and preserves the observed failure rather than requiring a successful narrative.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No scientific reproduction; no current-tree full-suite claim. Recorded source/config/runtime-bound observations only.

### 36. curvature-model-numerics

**Exact statement.** The retained two-model CPU study satisfies the exact finite probability controls and the recorded floating ELBO/Gaussian formula comparisons.

**Exact quantifiers.** Only the executed configured studies with retained manifest, JUnit and source identities.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: NUMERICAL_OBSERVATION.

**Direct dependencies.** base-curvature-prior, gauge-latent-elbo

**Direct input evidence.** evidence-curvature-model-numerics [evidence/base-and-curvature-results.json](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/evidence/base-and-curvature-results.json); evidence-recorded-numerics-reconstruction [agents/numerical-record-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/numerical-record-reconstruction.md)

**Load-bearing proof or record sections.** evidence/base-and-curvature-results.json; agents/numerical-record-reconstruction.json: curvature_control_records.

**Reconstruction.** The two recorded models retain rational probability controls and binary64 evaluations. The readback finds 14 true exact-control flags and maximum floating residual 4.440892098500626e-16, with manifests/configuration and raw XML identities checked.

**Strongest scoped attack.** Boolean control fields could be misrepresented as a new independent exact-arithmetic proof or a current-tree suite.

**Proof response.** These are accepted recorded outcomes, supported by their existing direct mathematical derivations but not used to prove those derivations. The original base test failure and historical source revisions remain visible.

**Prior erasure.** All control outcomes are read from the retained records; no curvature-selection assumption is used.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No scientific reproduction; no current-tree full-suite claim. Recorded source/config/runtime-bound observations only.

### 37. hybrid-exact-schedule

**Exact statement.** Every finite decimal piecewise-affine path in U has the stated exact finite strip partition, ordered existing side carriers, contacts and boundary intervals.

**Exact quantifiers.** All admitted finite decimal paths, including endpoint events and constant-boundary segments.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-hybrid-exact-schedule [agents/hybrid-interface.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/hybrid-interface.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/hybrid-interface.md: H1.

**Reconstruction.** Each affine segment crosses a strip boundary at the unique rational fraction (b-x0)/(x1-x0), if in [0,1]. Constant-boundary segments are intervals. A finite union of roots/endpoints and exact germ inequalities supplies every ordered left/exact/right carrier, with duplicates merged only at the same geometric event.

**Strongest scoped attack.** Floating epsilon probes could miss a contact or collapse distinct roots; a path with infinitely many crossings defeats finiteness.

**Proof response.** The claim uses finite decimal piecewise-affine paths, exact rational roots and declared contact order. It includes endpoint and boundary-interval cases, not arbitrary smooth paths.

**Prior erasure.** The partition is constructed by solving finitely many affine equations, without assuming events resolve themselves.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 38. hybrid-side-gaussians

**Exact statement.** The actual local Gaussian chains have positive finite one-sided prior/recognition/reference/posterior limits; zero observation columns make the birth posterior conditional equal its prior conditional.

**Exact quantifiers.** The declared finite local-tree family at all four strip boundaries, finite model parameters and supported sides.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** hybrid-exact-schedule

**Direct input evidence.** evidence-hybrid-side-gaussians [agents/hybrid-interface.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/hybrid-interface.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/hybrid-interface.md: H2.

**Reconstruction.** Triangular innovation factors have diagonals >=0.9 and correlations of magnitude <0.324. Their invertible finite chain map gives positive covariance with smooth side limits. Availability vanishes smoothly in observation columns, not covariance; at the boundary H_N=0, so the posterior factors into the survivor posterior times the prior conditional.

**Strongest scoped attack.** Vanishing availability could be confused with singular covariance, or birth might attach a prior conditional different from the limiting posterior conditional.

**Proof response.** The actual chain construction keeps its innovation covariance positive and removes only an observation column. Integrating that normalized conditional proves limiting evidence equality.

**Prior erasure.** One-sided positivity and conditional compatibility are proved from the actual factors rather than assumed to make the hybrid theorem work.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 39. hybrid-parent-limits

**Exact statement.** Supported normalized parent maps have finite one-sided limits and derivatives, including analytic singleton-parent selectors at zero parent occupancy.

**Exact quantifiers.** The stated pair-block hierarchy on each side carrier; absent exact-phase parents remain absent.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** hybrid-side-gaussians

**Direct input evidence.** evidence-hybrid-parent-limits [agents/hybrid-interface.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/hybrid-interface.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/hybrid-interface.md: H3-H4.

**Reconstruction.** A nonvanishing parent denominator gives a smooth normalized row. When the whole parent vanishes in this fixture, only one child exists on the occupied side, so the row is identically its selector and derivative zero. Disjoint normalized supports bound row Gram matrices below and preserve supported covariance rank.

**Strongest scoped attack.** Assigning the exact absent zero row to an occupied-side parent would create a singular false side law; simultaneous vanishing weights can lack a unique ratio.

**Proof response.** The proof uses the actual singleton birth/death pattern and retains absent exact-phase parents separately. No general simultaneous-birth ratio theorem or defined zero-occupancy attention follows.

**Prior erasure.** The selector cancellation and row-rank bounds give the limits directly, with no presumed regular quotient at rank loss.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 40. hybrid-zero-clock

**Exact statement.** Ordered departure and prior-conditional birth preserve event state and evidence, while posterior KL loses the discarded conditional KL and birth contributes zero.

**Exact quantifiers.** Each finite declared event, with full supported Gaussian state and the admitted limiting target/prior.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** hybrid-kernel, hybrid-parent-limits, hybrid-side-gaussians

**Direct input evidence.** evidence-hybrid-zero-clock [agents/hybrid-interface.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/hybrid-interface.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/hybrid-interface.md: H2 and H5.

**Reconstruction.** At a fixed event marginalization removes departures and the affine Gaussian birth kernel attaches the limiting prior conditional. H2 makes that conditional the limiting posterior conditional. KL disintegration therefore removes exactly the discarded conditional KL and adds zero at birth; normalized integration preserves evidence and the fixed latent event law is unchanged.

**Strongest scoped attack.** Nonzero disappearing observation columns, altered entry order or an unrelated reference would invalidate boundary VFE monotonicity.

**Proof response.** The actual zero-column factorization and declared departure-exact-entry order supply those premises. This says nothing about VFE descent between driven contexts.

**Prior erasure.** The event identity is derived from the normalized boundary kernel and target factorization, not from expected monotonicity.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 41. hybrid-resolved-consistency

**Exact statement.** The resolved arrival-side transport/Fisher scheme has first-order real-arithmetic error for the specified hybrid target under its uniform regularity/SPD hypotheses and finite event count.

**Exact quantifiers.** The stated finite-horizon regular/hybrid target and corresponding-side history lift; not unrestricted fixed-precision subdivision.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** hybrid-zero-clock, regular-discretization, regular-evolution

**Direct input evidence.** evidence-hybrid-resolved-consistency [agents/hybrid-interface-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/hybrid-interface-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/hybrid-interface.md: H6; agents/hybrid-interface-verification.md: Sections 6-7; agents/evolution-amendment.md.

**Reconstruction.** On each fixed carrier, arrival-target integral defects accumulate at first order using the common precision floor. Each event is a bounded affine moment map and identity on latent events. Finite induction multiplies earlier errors by finite jump constants. Matching phase carriers and piecewise frozen-target interpolation yield the stated history bound.

**Strongest scoped attack.** A sampled profile cannot prove an interval supremum; delayed jumps fail a raw-time supremum even if event times converge.

**Proof response.** The claim is the real-arithmetic resolved scheme with corresponding-side history lift, fixed finite event count and uniform bounds. The unchanged endpoint runner's saved records and unrestricted binary64 refinement are excluded.

**Prior erasure.** The convergence rate follows from analytical local defects and finite Lipschitz composition, not numerical agreement.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 42. hybrid-parent-nonautonomy

**Exact statement.** Two admitted fine preparations with equal old parent laws can yield different newborn parent laws under the correlated birth rule.

**Exact quantifiers.** The actual positive-coupling parent-birth witness at the stated boundary; a counterexample to unrestricted parent autonomy.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-hybrid-parent-nonautonomy [agents/hybrid-interface.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/hybrid-interface.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/hybrid-interface.md: H7; agents/evolution.md: E4.

**Reconstruction.** For old Y=aZ0+bZ1 choose mean displacement (bu,-au) with unchanged SPD covariance. Its old parent law is identical. The newborn singleton mean shifts by -a rho L2 L1^-1 u, nonzero for positive coupling and nonzero u. No common parent kernel can distinguish the identical old input laws.

**Strongest scoped attack.** A zero-coupling control or the final parent's zero newborn weight could be used to dismiss this witness.

**Proof response.** The statement concerns the actual positive-coupling depth-one newborn parent. Zero coupling and other coarse levels have separate scopes; retaining the distinguishing conditional removes the obstruction by changing the state.

**Prior erasure.** The explicit two-preparation witness establishes nonautonomy independently of a preference for full-state retention.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 43. hybrid-arithmetic-boundary

**Exact statement.** The flat positive bump near an open support boundary eventually underflows in every fixed finite floating format, so arbitrary refinement is not automatically executable.

**Exact quantifiers.** Interior approaches to the stated bump boundary in a fixed finite floating format.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-hybrid-arithmetic-boundary [agents/hybrid-interface.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/hybrid-interface.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/hybrid-interface.md: H8.

**Reconstruction.** The flat bump exp(1-1/t) tends to zero faster than each power as the positive boundary distance tends to zero. Every fixed finite floating format has a positive minimum representable magnitude, so sufficiently small true weights cannot be retained as positive values; arbitrary real refinements cannot all be represented.

**Strongest scoped attack.** Analytic evaluation at the boundary might be claimed to cure near-boundary finite-format underflow.

**Proof response.** An exact side limit fixes a different domain value and does not enlarge the interior floating range. Unbounded-range symbolic/logarithmic arithmetic would require a different contract.

**Prior erasure.** The obstruction follows from the limit and finite representable range, not a failed numerical run.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 44. hybrid-primary-comparison

**Exact statement.** Full latent-event TV together with fine mean and covariance norms distinguishes retained states; emitted-event distances alone need not do so.

**Exact quantifiers.** Equal supported phase carriers; the positive-unary unavailable-label pair gives a concrete readout-kernel witness.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-hybrid-primary-comparison [agents/hybrid-evolution-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/hybrid-evolution-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/hybrid-evolution-verification.md: HEV1; agents/hybrid-interface.md: H6.

**Reconstruction.** On a common supported carrier, equality of Gaussian mean/covariance fixes the Gaussian law and zero latent TV fixes the retained categorical law; their sum separates states. Positive unary laws differing only by opposite epsilon shifts between two unavailable labels have latent TV 2epsilon but identical emitted channels.

**Strongest scoped attack.** Depth-zero emitted TV could be used as a metric on the retained state.

**Proof response.** The corrected comparator explicitly includes fine reference moments and full latent TV. The analytic pair is a positive exact-chain witness to the emitted channel's kernel; sampled maxima remain distinct from continuous history norms.

**Prior erasure.** The metric property and channel-kernel counterexample are algebraic, not chosen because the revised implementation passed.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 45. hybrid-evolution-numerics

**Exact statement.** The retained CPU hybrid study satisfies the recorded interval/event, SPD, chart and composition checks and reports sampled primary/readout discrepancies.

**Exact quantifiers.** Only the executed profile/refinements/charts and their source/config/runtime/JUnit-bound records.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: NUMERICAL_OBSERVATION.

**Direct dependencies.** event-current-chain, hybrid-exact-schedule, hybrid-primary-comparison, hybrid-zero-clock

**Direct input evidence.** evidence-hybrid-evolution-numerics [evidence/hybrid-evolution-results.json](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/evidence/hybrid-evolution-results.json); evidence-recorded-numerics-reconstruction [agents/numerical-record-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/numerical-record-reconstruction.md)

**Load-bearing proof or record sections.** evidence/hybrid-evolution-results.json; agents/numerical-record-reconstruction.json: hybrid group.

**Reconstruction.** Retained raw XML contains 25 side, 14 evolution, 109 routing and three corrected-comparison passes: 151 executions, 149 latest distinct historical passes. The study has 124 phases, minimum saved covariance eigenvalue 0.44649990351401475, maximum mass error 3.3306690738754696e-16 and zero nonzero-clock event increments.

**Strongest scoped attack.** Tests at multiple source revisions could be counted as one current suite, or finite refinement discrepancies as an asymptotic convergence proof.

**Proof response.** The chronology and original source hashes remain explicit, including changed comparison source and later three-case packet. This accepts stored phase/readout comparisons only; historical routing drift and precision exclusions remain.

**Prior erasure.** The retained measurements determine the verdict; neither first-order convergence nor global descent is inferred from them.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No scientific reproduction; no current-tree full-suite claim. Recorded source/config/runtime-bound observations only.

### 46. quotient-connection-metric

**Exact statement.** The minimum-norm lift induces B=F(d+A)R and the exact projected nonmetricity identity; it is metric-compatible when the source is, without generally making F parallel.

**Exact quantifiers.** Fixed-rank smooth surjections, positive smooth fine metric, and stated connection/derivative regularity.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-quotient-connection-metric [agents/projected-connection.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/projected-connection.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/projected-connection.md: Sections 1-2 and 5.

**Reconstruction.** Full rank makes g=(F h^-1 F^T)^-1 positive and R=h^-1F^Tg its minimum-norm right inverse. FR=I gives a connection coefficient B=F(dR+AR). Differentiating R^T hR=g and substituting B yields dg-B^Tg-gB=R^T(dh-A^Th-hA)R.

**Strongest scoped attack.** Calling the selected minimum-norm lift a true parallel descent could erase dependence on discarded representatives.

**Proof response.** The connection is induced by a specified splitting. The defect dF+BF-FA remains unless separately zero; metric compatibility follows only when the source nonmetricity vanishes.

**Prior erasure.** The connection and metric identities are differentiated matrix identities, not assumed geometric closure.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 47. quotient-projector-curvature

**Exact statement.** The induced quotient curvature is F K_A R+F(D_A Pi wedge D_A Pi)R, with the transpose second-fundamental form under metric compatibility.

**Exact quantifiers.** The stated smooth fixed-rank metric quotient; no base metric or scalar action is inferred.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** quotient-connection-metric

**Direct input evidence.** evidence-quotient-projector-curvature [agents/projected-connection.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/projected-connection.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/projected-connection.md: Section 3; agents/projected-connection-verification.md: PCV2 and PCV4.

**Reconstruction.** Expand the square of Pi nabla on the image of Pi. Differentiating Pi^2=Pi makes Pi(DPi)Pi=0, so the discarded component contributes F(DPi wedge DPi)R besides F K_A R. In metric-orthonormal frames the retained block of ambient curvature is K_B-S^T wedge S, fixing the plus sign.

**Strongest scoped attack.** Compressing source curvature alone misses projection curvature; applying Euclidean transposes with a non-Euclidean metric gives the wrong formula.

**Proof response.** The projector expression is the general identity. The transpose second-fundamental display uses the declared orthonormal/Euclidean frame; a general h requires its metric adjoint (or an orthonormal frame), as PCV4 records. No scalar energy or parallelism is inferred.

**Prior erasure.** The curvature follows by squaring the explicit connection and checking its off-diagonal blocks, without assuming a positive curvature contribution.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 48. quotient-metric-composition

**Exact statement.** Metric-quotient lifts and projected connections compose exactly when the induced intermediate metric is propagated; resetting it can change the result.

**Exact quantifiers.** Every composable tower of the stated smooth surjections with a common inherited fine metric.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** quotient-connection-metric

**Direct input evidence.** evidence-quotient-metric-composition [agents/projected-connection.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/projected-connection.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/projected-connection.md: Section 6.

**Reconstruction.** Using the induced intermediate metric gives R_F R_G=h^-1 F^T G^T(GF h^-1 F^T G^T)^-1=R_GF. Product differentiation and FR_F=I give staged B=(GF)(d+A)(R_F R_G), identical to the direct connection. The displayed reset example yields -x/(1+x^2) versus -x/(4+x^2).

**Strongest scoped attack.** Stagewise Euclidean metric resets or independently reset source connections can masquerade as a functorial quotient construction.

**Proof response.** The theorem propagates the inherited metric and induced connection at each step. It does not assert composition for the legacy diagnostic candidates that reset those data.

**Prior erasure.** Composition is explicit multiplication and differentiation; the reset counterexample tests the essential premise.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 49. quotient-scalar-no-extra-curvature

**Exact statement.** For the common internal connection and scalar-weight block map, the induced correction is an exact scalar one-form and adds no curvature despite generally nonzero parallel-map defect.

**Exact quantifiers.** Each fixed supported stratum of the specified common-SO2 scalar-weight family.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** quotient-projector-curvature

**Direct input evidence.** evidence-quotient-scalar-no-extra-curvature [agents/projected-connection.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/projected-connection.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/projected-connection.md: Section 7.

**Reconstruction.** For scalar normalized blocks, R has weights lambda_i/sigma and B=A_star-(1/2)d log sigma I, sigma=sum lambda_i^2. The added one-form is scalar and exact, so its differential and wedge square vanish and mixed wedge terms cancel. Hence K_B=K_Astar.

**Strongest scoped attack.** Variation of the retained subspace might be assumed automatically to generate extra curvature or eliminate the first-order defect.

**Proof response.** The scalar commuting specialization has zero extra curvature even with varying weights. Making F parallel would require all d log lambda_i equal, and normalization would force constant weights; the defect generally remains.

**Prior erasure.** Direct substitution proves the cancellation rather than expecting curvature generation.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 50. quotient-curvature-numerics

**Exact statement.** Nine retained focused cases exercise the implemented fixed-rank jet formulas, analytic examples, general coordinate changes, composition and nonmetricity.

**Exact quantifiers.** Only the source-bound tiny CPU cases recorded in the retained JUnit; supplied curvature/derivative field consistency remains a caller obligation.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: NUMERICAL_OBSERVATION.

**Direct dependencies.** quotient-metric-composition, quotient-projector-curvature

**Direct input evidence.** evidence-quotient-curvature-numerics [evidence/quotient-connection-results.json](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/evidence/quotient-connection-results.json); evidence-recorded-numerics-reconstruction [agents/numerical-record-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/numerical-record-reconstruction.md)

**Load-bearing proof or record sections.** evidence/quotient-connection-results.json; agents/numerical-record-reconstruction.json: quotient group.

**Reconstruction.** Raw retained XML has exactly nine passing cases and matching source/command/result hashes. The cases exercise the tiny fixed-rank jet utility, analytic examples, coordinate changes, metric propagation and nonmetricity.

**Strongest scoped attack.** Passing supplied pointwise jets could be promoted to a theorem that all caller-supplied curvature/derivatives are coherent neighborhood fields.

**Proof response.** The record only covers the named cases; derivative/curvature-field consistency remains a caller premise. No new numerical execution or global geometric certification is claimed.

**Prior erasure.** The verdict follows the original XML and hash-bound record rather than an assumed correct geometry.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No scientific reproduction; no current-tree full-suite claim. Recorded source/config/runtime-bound observations only.

### 51. finite-support-extension

**Exact statement.** The common finite-channel action tower and KL/VFE additive chain extend to nonnegative laws at positive evidence with explicit null-reference/null-posterior conventions and no infinite subtraction.

**Exact quantifiers.** Every admitted finite observed slice, recognition, dominating finite reference and finite common Markov tower.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** finite-tower

**Direct input evidence.** evidence-finite-support-extension [agents/finite-support-amendment.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/finite-support-amendment.md); evidence-holonomy-support-reconstruction [agents/holonomy-and-support-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-and-support-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/finite-support-amendment.md; agents/holonomy-and-support-verification.md: Sections 1-2.

**Reconstruction.** Domination makes q and P zero on reference-null cells. On positive reference support the conditional action expectation allows zero density and +infinity action. If q_Y=0 its conditional contribution is zero without evaluation; if q_Y>0,p_Y=0 the coarse KL is already infinite and an explicit posterior probability extension leaves the additive identity valid. Other support failures give infinite conditional KL by direct grouping.

**Strongest scoped attack.** A zero-filled null conditional or an infinite diagnostic could be called a normalized probability, or an infinity-minus-infinity residual could be fabricated.

**Proof response.** The proof separates explicit probability extensions from labeled diagnostics and asserts only nonnegative extended addition. Telescoped differences and numerical residuals require finite terms.

**Prior erasure.** The full support case split establishes the extension directly; it does not presume finite divergence.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 52. holonomy-normalized-joint

**Exact statement.** The finite normalized field prior and Gaussian loop-observation kernel extend the existing normalized Gaussian/event joint while retaining its observations exactly once.

**Exact quantifiers.** All admitted finite positive field masses, finite declared actions and SPD loop noise on a closed probe loop within its domain.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** None.

**Direct input evidence.** evidence-holonomy-normalized-joint [agents/holonomy-inference-implementation.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-inference-implementation.md); evidence-holonomy-support-reconstruction [agents/holonomy-and-support-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-and-support-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/holonomy-inference-implementation.md: Normalization and exact Bayes construction.

**Reconstruction.** The finite field weights m_k exp(-S_k)/Z_f are positive and sum to one. For each k,z the SPD-noise Gaussian loop observation integrates to one. Multiplying it by the original normalized Gaussian/event/observation joint once and integrating successively proves normalization on the enlarged space.

**Strongest scoped attack.** Curvature could be appended as a penalty without a random field or the original likelihood could be counted twice.

**Proof response.** The finite label and new observation are explicit model data; m is categorical, not a measure over all connections. The old joint appears exactly once.

**Prior erasure.** The enlarged model is constructed from normalized factors, not inferred from holonomy alone.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 53. holonomy-gaussian-bayes

**Exact statement.** Sequential loop conditioning after the original observation and stacked conditioning from the original Gaussian prior give the same component posteriors, field weights and total evidence.

**Exact quantifiers.** Every admitted component and full normalized joint of holonomy-normalized-joint.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** holonomy-normalized-joint

**Direct input evidence.** evidence-holonomy-gaussian-bayes [agents/holonomy-inference-implementation.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-inference-implementation.md); evidence-holonomy-support-reconstruction [agents/holonomy-and-support-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-and-support-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/holonomy-inference-implementation.md: Normalization and exact Bayes construction; agents/holonomy-and-support-verification.md: Gaussian Bayes reconstruction.

**Reconstruction.** Completing the square after the original posterior gives ell_k=N(r;H_k mu0,R+H_k Sigma0 H_k^T), Z=Z0 sum pi_k ell_k and omega proportional to pi ell. Completing the square on the original prior with both likelihoods gives the same precision, precision-mean and scalar normalizer.

**Strongest scoped attack.** Sequential conditioning might omit original event evidence or fail to match the stacked scalar normalizer.

**Proof response.** The original event is independent of the new Gaussian likelihood and contributes once to Z0. Positive prior and observation covariance ensure valid component posterior and evidence.

**Prior erasure.** Equality follows from factor multiplication and Gaussian integration, without numerical equality as a premise.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 54. holonomy-chart-covariance

**Exact statement.** Passive orthogonal fine/probe chart changes preserve field evidence and posterior weights when the loop observation vector/noise transform coherently.

**Exact quantifiers.** Every declared chart with transformed sensor data and supported probe/fine Gaussian frames.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** holonomy-normalized-joint

**Direct input evidence.** evidence-holonomy-chart-covariance [agents/holonomy-inference-implementation.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-inference-implementation.md); evidence-holonomy-support-reconstruction [agents/holonomy-and-support-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-and-support-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/holonomy-inference-implementation.md: Chart covariance.

**Reconstruction.** With source Q and probe V, P'=VPQ^-1 and U'=VUV^-1 give H'=VHQ^-1. Transform r,R,mu,Sigma coherently. Orthogonal quadratic forms and determinants preserve each loop density, total evidence and field posterior masses.

**Strongest scoped attack.** Transforming only latent coordinates while freezing sensor components compares different observations.

**Proof response.** The builder's reference sensor/noise conversion supplies the same observation in the new chart. The theorem is passive orthogonal covariance, not field dynamics.

**Prior erasure.** The transformation square and determinant equality prove the scalar invariants independently of a favored chart.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 55. holonomy-normalized-vfe

**Exact statement.** The full retained-label VFE has equivalent posterior and generative decompositions, including field reference KL, expected curvature action and its log partition.

**Exact quantifiers.** Every admitted positive field recognition, compatible Gaussian component tuple and positive independent latent event recognition.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** holonomy-gaussian-bayes

**Direct input evidence.** evidence-holonomy-normalized-vfe [agents/holonomy-inference-implementation.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-inference-implementation.md); evidence-holonomy-support-reconstruction [agents/holonomy-and-support-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-and-support-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/holonomy-inference-implementation.md: Full retained VFE and curvature-prior accounting.

**Reconstruction.** Factoring the posterior in k,z,e expands joint KL into field KL, field-weighted component Gaussian KL and event KL, minus log evidence for VFE. Expanding the original normalized generative joint gives equivalent expected-likelihood terms. KL(a||pi)=KL(a||m)+E_a S+log Z_f retains all prior constants.

**Strongest scoped attack.** Discarding k and replacing its mixture by one Gaussian, or omitting log Z_f, invalidates the decomposition.

**Proof response.** The recognition explicitly retains a positive field mass and every Gaussian component, with an independent positive event factor. A constant action shift cancels as required.

**Prior erasure.** The formula is expansion of the declared joint log density, not a proposed curvature penalty.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 56. holonomy-retained-coarse

**Exact statement.** Keeping the finite field label and pushing each Gaussian/event law through the common coarse tower gives componentwise staged equality and independently evaluated telescoping conditional KL.

**Exact quantifiers.** Every recognition in holonomy-normalized-vfe and the declared supported common Gaussian/event tower.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** finite-support-extension, holonomy-normalized-vfe

**Direct input evidence.** evidence-holonomy-retained-coarse [agents/holonomy-inference-implementation.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-inference-implementation.md); evidence-holonomy-support-reconstruction [agents/holonomy-and-support-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-and-support-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/holonomy-inference-implementation.md: Retained-label coarse accounting; agents/holonomy-and-support-verification.md: conditional Gaussian/event derivation.

**Reconstruction.** Keeping k makes the common channel block diagonal by label. Full-row-rank Gaussian maps supply valid disintegrations and the finite event channel supplies its common joint lift. Componentwise KL chains, weighted by a_k, give the full correction and telescope under composed maps; depth-zero availability loss is included.

**Strongest scoped attack.** A weighted Gaussian KL would be wrong after label marginalization; law pushforward alone does not establish all geometric/evaluator arrows.

**Proof response.** The field label is retained, hidden conditional losses are evaluated from their disintegrations, and the statement is restricted to the declared supported statistical tower. It adds no missing geometric-arrow completion.

**Prior erasure.** The identity follows from actual joint/conditional factorization, without assuming a Gaussian mixture has Gaussian closure.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 57. holonomy-degenerate-controls

**Exact statement.** Zero enclosed area, zero curvature and repeated identical field components can leave the label posterior equal to its prior despite a normalized loop observation.

**Exact quantifiers.** The explicitly declared commuting constant-SO2 family and identical-observation component controls; not a general identifiability theorem.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: MATHEMATICAL.

**Direct dependencies.** holonomy-gaussian-bayes

**Direct input evidence.** evidence-holonomy-degenerate-controls [agents/holonomy-and-support-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-and-support-verification.md); evidence-holonomy-support-reconstruction [agents/holonomy-and-support-verification.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-and-support-verification.md); evidence-whole-mathematical-reconstruction [agents/whole-dependency-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/whole-dependency-reconstruction.md)

**Load-bearing proof or record sections.** agents/holonomy-and-support-verification.md: Section 7; agents/holonomy-inference-implementation.md: Scientific and implementation boundary.

**Reconstruction.** In the commuting constant-SO2 family, zero signed area or zero curvature gives U=I and H=0; loop likelihood then has no label dependence and omega=pi. Repeated identical components have equal likelihoods and preserve their mutual prior odds; if all components are identical, the whole label posterior equals its prior.

**Strongest scoped attack.** A duplicated subset could be said to preserve every posterior label mass, or zero area could imply trivial holonomy for arbitrary nonabelian fields.

**Proof response.** The existential 'can' claim is satisfied by all-identical components and the declared commuting family. Pair duplication alone preserves only pair odds, and no general nonabelian or identifiability theorem is asserted.

**Prior erasure.** The degeneracies follow by substituting the actual loop matrix and equal likelihoods, not from an assumption of identifiability.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No kernel-checked formalization; mathematical evidence is the explicit written derivation. Exactly the mathematical statement with its full cited hypotheses.

### 58. holonomy-inference-numerics

**Exact statement.** The retained three-chart CPU profile and latest focused/routing JUnit satisfy their scoped comparisons; the first native NumPy abort remains a failed attempt without JUnit.

**Exact quantifiers.** Only the recorded source/config/runtime-bound finite case and latest JUnit; no CUDA or continuum claim.

**Disposition.** ACCEPT; recommended RTS state EVIDENCE_VERIFIED only within the scope recorded here. Input ledger state: CANDIDATE. Kind: NUMERICAL_OBSERVATION.

**Direct dependencies.** holonomy-chart-covariance, holonomy-degenerate-controls, holonomy-retained-coarse

**Direct input evidence.** evidence-holonomy-inference-numerics [evidence/holonomy-inference-results.json](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/evidence/holonomy-inference-results.json); evidence-recorded-numerics-reconstruction [agents/numerical-record-reconstruction.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/numerical-record-reconstruction.md)

**Load-bearing proof or record sections.** evidence/holonomy-inference-results.json; agents/numerical-record-reconstruction.json: holonomy group and abort record.

**Reconstruction.** Latest raw XML has 21 focused plus 109 routing passing cases. The retained three-chart profile has 996 finite NPZ arrays and passing chart records. The original abort log and matching hash remain present, showing a native abort at NumPy eigvalsh with no JUnit for that attempt.

**Strongest scoped attack.** The abort might be erased or progress dots counted as passing tests, or CUDA-capable Torch mistaken for executed CUDA.

**Proof response.** The failed parent exit is retained, child exit/test count remain unknown, and only later source-bound XML supplies passing totals. Runtime records say CPU; this is recorded evidence, not a diagnosis or a replay.

**Prior erasure.** The verdict includes the failed attempt and unknowns instead of relying on an expectation of success.

**Open obligation.** No missing mathematical or retained-record evidence was identified for this exact statement. This recommendation does not replace root-owned ledger wiring and the terminal RTS release checks.

**Unperformed work and scope.** No scientific reproduction; no current-tree full-suite claim. Recorded source/config/runtime-bound observations only.

## Handoff

Root may use these atomwise proof assessments to update the frozen 58 claims after attaching direct target derivation evidence. Every new ladder claim, stronger R6 limit, universal physical interpretation, or later change to an exact claim requires its own evidence assessment. This report closes no such extension. It changes only the assigned Markdown and JSON reports; the ledger, proofs, source code, configurations, activation markers, and historical execution artifacts were not edited.
