<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# R5 next construction: local parent transitions on the retained incidence law

September 9, 2026. This bounded source inspection answers roadmap R5 at source HEAD `409c61155ac16b21342bfe15c834fda7bb33fb67` in `C:/tmp/elbo-cover-20260908`. Shared parent instructions, model, and filesystem are disclosed. This lane owns only this note. No code, tests, test collection, scientific imports, numerical experiments, producer execution, GPU work, ledger changes, or vault edits occurred. Historical outcomes below are attributed to their retained reports; they were not reproduced here. The formulas below are proposed constructions with derivations, not formal claim-ledger closures. S1-S3 and the full simulation suite remain on hold.

**The existing normalized incidence carrier can support R5 without changing its target. Its public Phase 27 transition API does not yet implement the proposed parent-sensitive hierarchy mechanism.** A separate exact operator can replace U while retaining D. The existing four-state E4a generator is a useful narrower precedent, but its conditioned carrier cannot establish hierarchy formation on the unchanged Phase 26/27 law.

## Existing carrier and operator seams

All paths in this section are relative to the source root recorded above; line numbers identify the inspected definitions.

| Required object | Existing source and precise seam | Scope |
|---|---|---|
| Ordered partition and assignment catalog | `src/multiagent_elbo/rg_v2/partition_parent_selection_model.py:25` `partitions`; `:89` `Feature`; `:99` `feature`; `:121` `feature_rows` | Eight interval partitions of four vertices and 54 root-bit assignments per fine state. Bits belong to actual retained roots. |
| Normalized model factors | Same file `:60` `partition_prior`; `:130`–`:186` `sensor`, `environment`, `group_likelihood`, `likelihood`, `factor` | Parent priors and shared-environment denominators remain present. |
| Actual decorated parent | `src/multiagent_elbo/rg_v2/partition_parent_selection_composition.py:15` `Parent`; `:43` `parent_from_payload`; `:54` `direct_parent`; `:103` `geometry_catalog` | Partition, root matter/bits, links, ports, path words, based holonomy, multiplicity and event declarations. A partition label is not this state. |
| Positive sparse incidence carrier | `src/multiagent_elbo/rg_v2/inference_persistence_model.py:59` `Fibers`; `:65` `build_fibers`; `:85` `admit_carrier` | Injective supported pairs `(z,h)` with `row_z`, `row_h`, `row_c`; no Cartesian completion. Admission compares saved parents with actual source coordinates. |
| Fixed posterior and starts | Same file `:116` `target_law`; `:128` `recognition_law`; `:137` `condition_partition` | Four targets, with theta=4, strength=4, kappa=2, rho=1, lambda=tau=3. Proposed first target: `d4_full:private_split`. |
| Existing transitions | Same file `:144` `conditionals`; `:150` `refresh`; `:157` `step`; `:164` `component_target` | `step` accepts only `alternating_parent_fine`, `frozen_parent`, `component_refresh`. These are U D, D, and component refresh. |
| Existing path diagnostics | `src/multiagent_elbo/rg_v2/inference_persistence_diagnostics.py:20` `masked`; `:24` `structure_paths`; `:55` `stationary_lags`; `:100` `parent_lumpability` | Useful formulas and controls, but the operator dispatch and lumpability shortcut are specialized to the old mechanism. |
| Retained packet admission | `src/multiagent_elbo/rg_v2/inference_persistence_experiment.py:72` `read_phase26_packet` | Reads hash-bound historical inputs; there is no producer fallback. The historical runner fixes three mechanisms and eight sweeps in `validate_config` at line 60. |

The row target is exactly

\[
p_i=\frac{P_{0,D}(z_i)\operatorname{factor}(i;4,4,2,1)\ell_{\rm private\_split}(a_i;3,3)}{Z_o}>0.
\]

The full marked target is `p_i eta_z(e)`. The existing compressed representation requires initial and target event profiles to agree pointwise. Retaining this representation means U-like moves hold z and its event law fixed, while D redraws the fine configuration and its event pair from the same admitted conditional. It does not replace the event joint by independent marginals.

The retained Phase 27 report `docs/reports/2026-09-06-rg-v2-phase27-inference-persistence-result.md:25` reports full/flat sizes of 27,648/3,456 incidences and 64/8 connected components. It also records 16,000/2,000 decorated parents. These are historical retained sizes, not counts executed in this lane.

## What already exists, and what remains new

`driven_reference_model.py:121` `_extract_carrier` selects the actual four-cycle `(z,h)=(0,0),(0,1),(1,1),(1,0)` from Phase 27 rows `(0,1,55,54)`. Its conditioned target is `(16,8,3,96)/123`, with conditioning mass `17353792512/27756513833177`. `generator` at line 224 implements rates `Q[i,i+1]=kappa(1+alpha)/p_i`, `Q[i,i-1]=kappa(1-alpha)/p_i` and the matching negative diagonal. Thus a target-preserving parent-sensitive finite transition already exists on this separately conditioned four-state problem. At alpha=0 its pair fluxes are symmetric; nonzero alpha introduces a circulation.

This is not an R5 hierarchy operator on the original target. Row order from `feature_rows` places both first parent assignments at partition 0, differing only in its root bit. Rows 54 and 55 repeat those assignments at the next fine state. The two selected parent objects therefore both have the whole-block partition. The four-cycle has no formation or loss of a nontrivial exact block. Conditioning onto those four incidences also replaces the original target by a conditional law. Do not rename its nonzero-alpha drive as inference persistence or attach its generator to the historical Phase 27 runner.

The hierarchy-decision document `docs/research-plans/2026-09-07-rg-v2-hierarchy-mechanism-decision.md:102` already derives the restricted D-endpoint kernel. I found no separate production helper for that kernel in the inspected Phase 27 path. R5 can reuse the mathematical restriction, while its new matrix helper must be explicitly implemented.

## Proposed exact local parent move

Retain all 54 assignments at each z. Connect two assignments if exactly one of the following occurs: flip one existing root bit; merge two adjacent blocks while keeping the left root's bit; or perform the inverse split, retaining the left root's bit and choosing the newly exposed right root's bit as either 0 or 1. All other root bits remain fixed. Reconstruct each destination by lookup in the already admitted `(source,partition,bits)` catalog and its saved `row_h` map. This is a stochastic transition on the original fine/incidence state, not a claim that a split can deterministically reconstruct discarded information from h alone.

The graph is undirected. For k blocks, there are k bit flips, k-1 merges, and `2(4-k)` splits, hence exactly seven distinct neighbors. A merge has two distinct possible inverse-source states, because the discarded right bit could have either value. Each individual edge nevertheless has one reverse edge and probability `1/14` in the following proposal. This explicit counting avoids silently assigning identical aggregate merge and split probabilities.

Set `Q_z(i,j)=1/14` on each neighbor, `Q_z(i,i)=1/2`, and zero otherwise. Define

\[
M_z(i,j)=\frac1{14}\min\{1,p_j/p_i\}\quad (i\sim j),\qquad
M_z(i,i)=1-\sum_{j\ne i}M_z(i,j).
\]

The proposal degree proof gives nonnegative diagonals at least 1/2. The global normalizer and fine prior cancel in `p_j/p_i` within a z fiber, but all parent, compatibility, and observation factors remain. For each edge,

\[
p_iM_z(i,j)=\frac1{14}\min(p_i,p_j)=p_jM_z(j,i).
\]

Summation proves target invariance without a numerical sign argument. All arithmetic is rational. The graph connects all 54 assignments: merge to one block, adjust its bit if needed, then split and assign the new roots' bits. Positivity of p makes every permitted edge have positive acceptance.

Let M act fiberwise and retain the old exact D refresh. The full step is `T=M D` on row laws. Both M and D preserve p; hence pT=p. Joint reversibility is not implied: the stationary reverse of this ordered sweep is `D M`. A self-loop and positive local connectivity permit paths following the old U-fiber connections over several sweeps, while D provides the old h-fiber connections. Consequently the communicating classes remain the admitted bipartite components, provided the seven-neighbor admission holds at every z. The relevant stationary comparison for a start q0 remains `q0(C)p(i|C)`.

For the complete marked state, lift M by leaving e unchanged and lift D by redrawing e from the admitted new-z profile. This preserves `p_i eta_z(e)` and the compressed family. No new holonomy, link, or component is introduced. Gauge covariance requires transporting the conditioned chart, target prior, observations, and parent payload together. The adjacency depends only on vertex labels, cuts, and root-bit operations; the bit operation is the existing central D4 half-turn. The scalar acceptance factors must transform with their actual source factors. Arbitrary permutations of parent indexes are only an indexing check.

This is a concrete candidate, not a prediction that it improves persistence. It changes the proposal graph and relative movement between parent configurations, while retaining one U-like attempt and one D refresh per sweep. The explicit 1/2 holding is an aperiodicity convention and must be held fixed across comparisons.

## Smallest exact hierarchy witness

Two parent states with a fixed positive stationary law have a single independent equilibrium conductance. Their target-preserving discrete kernels lie on one affine clock family, so they cannot separate a proposal-graph mechanism from whole-clock waiting. Three parent states are the smallest useful witness.

Choose one admitted fine state z and all-zero root bits. Let the three assignments have partition IDs 7, 6, and 2, in that order:

\[
R_0=\{a\}\{b\}\{c\}\{d\},\quad
R_1=\{a,b\}\{c\}\{d\},\quad
R_2=\{a,b\}\{c,d\}.
\]

Each is present by `feature_rows`. Their weights are the exact `factor * likelihood` values above, with the common prior of z removed. Normalize these three positive rational weights to `(a,b,c)`. This is a deliberately conditional arithmetic witness, not the unchanged full target and not a new empirical result. No coefficient was read or evaluated in this lane. Its exact symbolic matrix is already determined by these finite rational factors.

For a lazy path proposal on `0 <-> 1 <-> 2`, put

\[
u=\tfrac14\min(1,b/a),\quad v=\tfrac14\min(1,a/b),\quad
w=\tfrac14\min(1,c/b),\quad x=\tfrac14\min(1,b/c),
\]

\[
M_3=\begin{pmatrix}1-u&u&0\\v&1-v-w&w\\0&x&1-x\end{pmatrix}.
\]

Detailed balance follows from `a u=b v` and `b w=c x`. The exact block event `A={1,2}` has a formation transition and an internal transition preserving `{a,b}`. The missing 0-to-2 edge rules out equality with any nonzero whole-clock lazification of the positive full redraw matrix. The event is not strongly lumpable: its exit probabilities from states 1 and 2 are v and zero.

Starting at state 0, the first-formation mean is `1/u`. The killed inside matrix is `M_3[A,A]`. Solving its two rational equations gives exit means `t_1=(1+w/x)/v` and `t_2=t_1+1/x`. Conditional survival is `mu_A M_3[A,A]^n 1`, with the initial conditional distribution explicitly declared. These are closed symbolic identities; a future bounded implementation should independently extract the three weights and materialize the exact matrix.

The conditional witness supplies a tiny formula check. It cannot establish the full U-D mechanism, its original component target, or a useful formation/persistence tradeoff. Those require the closed-component oracle below.

## Lumpability, D preparation, and persistence definitions

For an arbitrary projection f of the actual incidence chain, strong lumpability requires `sum_{j:f(j)=b} T(i,j)` to depend only on f(i), for every destination b and all supported i. The old `parent_lumpability` shortcut compares U rows and is insufficient for a new M; compute these sums from the new exact operator or return a supported unequal-row witness.

After a full D refresh, the conditional fine law given h and the preceding parent history is `p(z|h)`. Thus the full decorated-parent process at D endpoints has

\[
L_M(h,h')=\sum_z p(z|h)M_z(h,h').
\]

This applies from time zero only for D-compatible preparation and otherwise from the first D endpoint. Summing the elementary detailed-balance identity shows `p_H(h)L_M(h,h')=p_H(h')L_M(h',h)` for this proposed reversible M. This restricted parent chain can be reversible even though the ordered full incidence sweep is not. A further partition/block projection still needs its own lumpability or memory statement. Exact block membership is retained by D, so endpoint and elementary-stage survival agree for that event with one parent move per sweep; this equivalence must not be extended to fine observables or changed schedules.

Freeze `A_ab={i:(0,1) is exactly a block of PARTITIONS[rows[i].partition]}`; equivalently the admitted partitions are 2 and 6. A merge adding c or d ends the event, a split of `{a,b}` ends it, and any later return is a new episode. Merging or splitting `{c,d}` preserves it. Freeze partition-6 residence as a separate stricter event. Overlap-based or nested-chain persistence requires separately declared thresholds and lineage rules; it is not inferred from exact membership.

For a row-stochastic T, first formation is `tau_A=inf{n>=1:X_n in A}` from a stated outside start. Conditional survival from an inside start is `Pr(tau_Ac>n)=mu_A T_AA^n 1`. Mean first exit is `mu_A(I-T_AA)^(-1)1` only when the inside killed chain is transient; otherwise report the actual infinite cases. Occupancy is `(q0 T^n)(A)`, and recurrent occupancy is component weighted. Whole-sweep waiting is exactly `T_wait=(1-lambda)I+lambda T_redraw`, compared separately from slowing only M or D. Record attempted parent proposals, acceptances, D refreshes, and sweeps so a scheduler change cannot be hidden in a clock label.

A fixed-target tradeoff is unavoidable for stationary entrance-defined episodes. In an irreducible component, let `J=sum_{i outside,j inside} pi_i T_ij`. The stationary entrance law satisfies `mu_entry=pi_A(I-T_AA)/J`. Hence its mean inside duration is `pi(A)/J`; the corresponding outside duration is `pi(Ac)/J`. Raising this particular residence mean at fixed equilibrium occupancy also raises the corresponding mean outside excursion. A useful mechanism claim must name a different preparation or a distributional/survival advantage and report its formation cost. A longer lifetime by itself is insufficient.

## Bounded next implementation and the remaining admission question

Add one standalone exact module, proposed name `src/multiagent_elbo/rg_v2/parent_sensitive_transition.py`, with a small API: construct the seven-neighbor assignment graph; apply the rational M to probability or subprobability row vectors; compose with the existing D; materialize a selected closed-component matrix; and return killed-matrix, stationary, and projection quantities. A proposed focused test file is `tests/rg_v2/test_parent_sensitive_transition.py`. Keep the frozen historical `MECHANISMS`, config, runner, artifact recipes, and existing results unchanged. Do not add a launcher or start S1-S3/S4 as part of this unit.

First implement the three-state symbolic witness and the 54-assignment graph. Then admit one component of `d4_full:private_split`, preferentially the lexicographically first component containing a fine state with nonidentity based holonomy. Selection must use actual payload coordinates. Expected size is eight fine states times 54 assignments, or 432 incidences; this is a proposed admission size, not a count executed here. The full/flat historical totals alone only supply an average and cannot certify a selected component's size.

The minimum unresolved admission question is: **Does the selected retained nonflat component contain exactly eight fine states and all 54 assignments at each, with no D fiber leaving it, and do all proposed neighbors resolve uniquely inside the same saved carrier while preserving its retained based holonomy?** Read the retained packet and answer this directly before materializing a 432-by-432 matrix. If the count differs, record its actual count and return for a bounded-size decision; do not delete states, renormalize an arbitrary subset, or replace the nonflat component to force 432. Restriction to an actual closed component uses `p(.|C)` and is an exact component analysis of the unchanged full transition, unlike the three-state conditional witness.

The source geometry explains why 432 is plausible: parent links and ports reconstruct original links by `g_ij=P_i^(-1) gbar_ij P_j`, the conditioned root is fixed, and the source has binary choices for b and the two leaves. The whole-block parent connects those matter choices at fixed link geometry. This reasoning is not a substitute for the retained-carrier admission just stated.

The first execution, when assigned by root, should answer only that admission, exact row normalization, elementary detailed balance, full target stationarity, communicating classes, the D-endpoint relation, and exact event entrance/exit calculations against redraw, frozen-parent, component-refresh, and a declared whole-clock waiting control. A conditional KL-gap equality from full Gibbs refresh must not be copied onto M: target invariance supplies KL contraction by the log-sum inequality, while the old exact conditional-gap formula generally does not apply. A useful persistence threshold should be frozen before the new event calculations, or the result explicitly labeled a mechanism characterization without a persistence acceptance claim.

This is a mathematical construction and small finite operator unit. It does not authorize the held simulation suite, old eight-sweep producer, a new grid, cross-component motion, physical-time interpretation, or broader hierarchy claims. Root owns any consolidated change log, verification workflow, integration, and subsequent execution decision.

The Research wiki page [Staged hierarchy formation and RG composability](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Staged hierarchy formation and RG composability.md>) was consulted for context only. Its historical tentative laboratory interpretations were not used as evidence for the new operator or its outcomes.
