<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Holonomy likelihood and finite-support reconstruction

Revision 2, frozen September 9, 2026. Family: holonomy-support-reconstruction. Kind: independent mathematical RECONSTRUCTION of the other authors' finite-support amendment and holonomy likelihood construction, with a read-only source correspondence check. The author previously wrote the statistical/base-curvature and quotient constructions and some other reconstructions; those earlier author roles, the shared model, inherited context, and shared filesystem are disclosed. This is cross-author reconstruction of the named new claims, not prior erasure or independent review of the author's own curvature work. No formal adjudication state is assigned. No tests, benchmarks, scientific imports, GPU checks, verifier tools, ledger edits, or implementation edits occurred. Only this Markdown is owned.

The finite-support extension and the retained-label holonomy construction survive the reconstruction below within their stated domains. No concrete mathematical defect or necessary source repair was identified in the inspected new path. Numerical execution remains root's separate responsibility. The conclusion does not extend the model to zero-support Fisher dynamics, latent continuous fields, arbitrary gauge groups, label identifiability, marginalized Gaussian-mixture KL, or autonomous coarse dynamics.

## 1. Inputs and scope

The mathematical inputs are finite-support-amendment.md, the existing finite-core.md and finite-core-interface-amendment.md, and the normalization, covariance, VFE, and retained-label sections of holonomy-inference-implementation.md. The separately authored holonomy-likelihood-intake.md is a source-level integration comparison, not a proof certificate. The new holonomy_inference.py was read together with the exact live transport, conditioning, local-tree likelihood, Gaussian hidden-conditional, event-channel, and supported-context seams it calls. The earlier D4/SU(2)/SO(3) literature and implementation families were not re-audited or replayed.

The following arguments use finite sums, explicit Gaussian densities and matrix identities, rather than importing a theorem on the authority of an earlier report. Repository source files are primary evidence for the source correspondence. No literature-priority claim or externally sourced mathematical premise is needed.

## 2. Zero-support action tower

Let \(P_o(x)\geq0\) on a finite nonempty \(X\), \(0<Z=\sum_xP_o(x)<\infty\), \(p=P_o/Z\), and \(q\) be any probability. Let \(C(y|x)\geq0\) have row sums one. Choose \(\mu\) dominating both laws with finite positive total \(M\); a strictly positive counting reference is available. Write \(w_x=P_o(x)/\mu(x)\) on \(\mu(x)>0\). Set \(w_x=0\) on a null reference coordinate only as an irrelevant extension. Then \(P_o(x)=\mu(x)w_x\) at every point.

For \(\mu_C(y)=\sum_x\mu(x)C(y|x)>0\), the weights
\[
r_\mu(x|y)=\frac{\mu(x)C(y|x)}{\mu_C(y)}
\]
sum to one, and direct substitution gives
\[
w_C(y)=\frac{\sum_x P_o(x)C(y|x)}{\mu_C(y)}
       =\sum_xr_\mu(x|y)w_x.
\]
No logarithm or support division occurs in this derivation. With \(e^{-\infty}=0\), \(A_C=-\log w_C\) is therefore a valid extended-real action wherever the coarse reference is positive. A zero coarse density gives \(+\infty\), while a zero coarse reference gives no defined density. The latter coordinate is inaccessible to \(P_oC\) and \(qC\) because of domination.

For a downstream \(D(z|y)\), both the reference and numerator have staged value
\[
\sum_{x,y}\mu(x)C(y|x)D(z|y),\qquad
\sum_{x,y}P_o(x)C(y|x)D(z|y),
\]
which are the direct values for \(CD\). Dividing these equal finite nonnegative sums on positive final reference support proves direct/staged density equality. Applying \(-\log\) then proves action equality, including the common \(+\infty\) value. This proof never uses an expression such as \(+\infty-(+\infty)\).

The executable action primitive admits a probability reference. Put \(\nu=\mu/M\). Then \(P_o/\nu=M(P_o/\mu)\) and
\[
A_\nu=A_\mu-\log M,\qquad A_\mu=A_\nu+\log M.
\]
Every pushed reference still has total \(M\), so the same finite offset applies throughout the tower. Adding that finite offset to an infinite action is well-defined. Changing the action reference in this way does not change \(P_o\), the evidence, the posterior, or a KL divergence.

Two exact support examples establish the boundary. For \(P_o=(1,0)\), counting \(\mu=(1,1)\), and a constant channel to one point, the pushed reference is \(2\), the pushed evidence is \(1\), and the coarse action is \(\log2\), even though the fine action contains \(+\infty\). For a target column that is identically zero, both pushed masses are zero and no density is defined there. An implementation may store a zero density and infinite action as sentinels, but those are not a computed value of \(0/0\).

The live scale_cocycle.py follows this distinction at the array interface: positive reference cells use the exact Fraction density; zero reference cells store the pair \((0,+\infty)\). Its density values are exact for representable rational inputs. Its floating logarithm is a separate representability operation, not an exact-real evaluator for arbitrarily large or small rational numbers. The amendment does not promise such a numerical extension. Infinite-action Möbius subtraction or differences of two infinite actions are not obtained by this action-tower proof.

## 3. Extended KL and VFE chain

Define common-channel joint probabilities
\[
Q(x,y)=q(x)C(y|x),\qquad \Pi(x,y)=p(x)C(y|x).
\]
For \(q(x)>0,p(x)>0,C(y|x)>0\), the joint log ratio is \(\log(q(x)/p(x))\). The row sum one then gives \(D(Q\|\Pi)=D(q\|p)\) in the finite case. If instead \(q(x)>0,p(x)=0\), at least one positive channel cell exists in that row, so the same support violation makes both divergences infinite. Thus this equality holds in nonnegative extended reals.

Suppose first that \(q_C\ll p_C\). Every \(q_C(y)>0\) has \(p_C(y)>0\), so the two conditional laws are normalized. If there is no within-fiber support violation, expanding
\[
\log\frac{Q(x,y)}{\Pi(x,y)}
=\log\frac{q_C(y)}{p_C(y)}
 +\log\frac{Q(x|y)}{\Pi(x|y)}
\]
and summing gives
\[
D(q\|p)=D(q_C\|p_C)+
 \sum_{y:q_C(y)>0}q_C(y)D(Q(\cdot|y)\|\Pi(\cdot|y)).
\]
If a within-fiber support violation exists, the conditional and fine divergences are both infinite, while the coarse divergence is finite on this finite carrier. The extended identity still holds. No conditional is evaluated where \(q_C(y)=0\); its contribution is defined as zero.

If \(q_C(y)>0,p_C(y)=0\) for some \(y\), the coarse and fine KLs are infinite. The posterior conditional there is undefined. Extend it by any explicitly chosen probability law, and the conditional sum is a member of \([0,\infty]\). Adding it to the already infinite coarse term preserves the equality. One may alternatively report an infinite diagnostic for this null-posterior column, provided it is not described as the KL of the zero-filled array against a normalized conditional. The amendment makes that qualification.

For example, take \(p=(1,0),q=(0,1)\). Under the constant channel, both coarse laws equal \(1\), so the coarse KL is zero and the legitimate hidden conditional KL is infinite. Under the identity channel, the coarse KL is already infinite; choosing the null posterior conditional at the second target to be \(\delta_2\) makes its conditional KL zero. Choosing \(\delta_1\) makes it infinite. Both satisfy the extended sum identity. Therefore a uniquely defined finite conditional diagnostic at a null posterior event is not a consequence of the theorem, and subtraction \(D_\mathrm{fine}-D_\mathrm{coarse}\) is not available in this case.

All conditional divergences are nonnegative. One direct finite proof is \(-\log t\geq1-t\), applied to \(t=p_i/q_i\) on positive \(q_i\), with any missing support yielding infinity. Summation gives \(D(q\|p)\geq1-\sum_{q_i>0}p_i\geq0\). This proves data processing from the additive chain. Subtract the finite \(\log Z\) from the appropriate KL terms to obtain
\[
\mathcal F_\mathrm{fine}
=\mathcal F_\mathrm{coarse}+\mathcal C.
\]
An arbitrary real finite shift of an infinite divergence stays infinite. Adjacent conditional corrections telescope as a finite difference only when those divergences are finite. In general the iterated extended additive identity remains valid, but an infinite-minus-infinite residual is undefined. The amendment does not infer an ordering between two arbitrary infinite VFEs.

The inspected vfe.py implements these branches: _kl_arrays returns infinity on positive-q/zero-p support; _conditional_kl skips zero recognition columns and gives the infinite diagnostic on a null posterior column; vfe_channel_decomposition returns residual=None for a nonfinite term and retains the offending fine-state label. The zero columns created by _reverse_conditional are computational placeholders. block_update_decomposition explicitly refuses nonfinite differences. These are the needed support conventions, not evidence of dynamics through a boundary of a Fisher manifold.

## 4. Normalized holonomy observation and exact field posterior

At one admitted context let the original normalized model be
\[
p_0(z,e,o_0)=p_G(z)p_E(e)L_G(o_G|z)L_E(o_E|e).
\]
The field reference is a positive finite categorical law \(m_k\). The declared action
\[
S_k=V(\lambda_b\kappa_{b,k}^2+\lambda_m\kappa_{m,k}^2)
\]
has \(V>0\) and nonnegative coefficients. For finite field values, \(0<Z_f=\sum_km_ke^{-S_k}\leq1\) and \(\pi_k=m_ke^{-S_k}/Z_f\) is normalized. These coefficients and the finite field family are model choices; no curvature energy is inferred merely from computing a connection.

Let \(P\) select the four probe coordinates. With the existing \(D=d+A\) convention, closed-polygon transport is
\[
U_k=G(c)\exp[-\operatorname{diag}(\kappa_{b,k}J,\kappa_{m,k}J)\mathcal A]G(c)^\top,
\quad H_k=(U_k-I)P,
\]
where \(\mathcal A=\frac12\sum_i(x_iy_{i+1}-y_ix_{i+1})\) is signed area. This follows by summing the actual segment integrals of \((x dy-y dx)/2\); all reference generators commute in this family, and adjacent endpoint frames cancel. The sign is negative because parallel transport solves \(\dot z=-A(\dot c)z\). The selected open strip and \(U=(-1.5,1.5)^2\) are convex. Interior vertices therefore keep each straight segment inside the same probe domain. The population outside that probe need not retain constant rank.

With \(R\) SPD, the augmented model is
\[
p(k,z,e,o_0,r)=\pi_kp_0(z,e,o_0)\mathcal N(r;H_kz,R).
\]
Integration in \(r\) gives one for every \(k,z\). The remaining finite sum and integrals reduce to those of the normalized original model. In particular the old Gaussian and event observations are not duplicated.

Write \(p_0(z|o_0)=\mathcal N(\mu_0,\Sigma_0)\), with old total evidence \(Z_0\). Completing the square in \(z\) gives
\[
V_k=R+H_k\Sigma_0H_k^\top,\quad
\ell_k=\mathcal N(r;H_k\mu_0,V_k),
\]
\[
\Sigma_k^{-1}=\Sigma_0^{-1}+H_k^\top R^{-1}H_k,\qquad
\mu_k=\Sigma_k(\Sigma_0^{-1}\mu_0+H_k^\top R^{-1}r).
\]
The displayed precision is positive definite because its first term is SPD and the second is positive semidefinite. Its inverse equals the covariance-subtraction conditioning formula used in model.condition by multiplying against that precision. This proves the conditional Gaussian is mathematically nondegenerate even if \(H_k\) is rank deficient.

The full evidence and posterior are
\[
Z=Z_0\sum_k\pi_k\ell_k,\qquad
\omega_k=\frac{\pi_k\ell_k}{\sum_j\pi_j\ell_j},\qquad
p(k,z,e|o_0,r)=\omega_k\mathcal N(z;\mu_k,\Sigma_k)p_E(e|o_E).
\]
All \(\ell_k\) are strictly positive mathematically. The added likelihood contains no \(e\), so the original event posterior is unchanged and remains independent. Conditioning the original prior on \([o_G;r]\), with observation matrix \([H_0;H_k]\) and block-diagonal noise, uses the same product of two likelihood densities. It therefore has the same posterior, while its log evidence is \(\log Z_{G0}+\log\ell_k\). Event evidence is then added once. This is a separate algebraic route, not a numerical fit to the sequential answer.

## 5. Covariance and full VFE accounting

For orthogonal old-to-new fine and probe coordinate maps \(Q,V\), the same physical observation requires
\[
P'=VPQ^{-1},\quad U_k'=VU_kV^{-1},\quad
r'=Vr,\quad R'=VRV^\top.
\]
Consequently \(H_k'=VH_kQ^{-1}\). With \(\mu'=Q\mu,\Sigma'=Q\Sigma Q^\top\), observation means and covariances transform by \(V\) and congruence. The quadratic exponent and determinant in the Gaussian density are unchanged because \(|\det V|=1\). Thus \(\ell_k,Z,\omega_k\) and KLs are invariant. Under a general non-volume-preserving GL observation reparameterization, the density would instead acquire its Jacobian factor; that broader scalar-evidence claim is not made here. Keeping a nonzero \(r\) or anisotropic \(R\) numerically fixed under a nontrivial chart change would describe a different sensor.

For a recognition law \(q(k,z,e)=a_kQ_k(z)q_E(e)\), factorization of the posterior gives directly
\[
\mathcal F=D(a\|\omega)+\sum_ka_kD(Q_k\|P_k)
 +D(q_E\|p_E(\cdot|o_E))-\log Z.
\]
Expanding \(\log q-\log p(k,z,e,o_0,r)\) instead gives
\[
\mathcal F=D(a\|\pi)+\sum_ka_kD(Q_k\|p_G)+D(q_E\|p_E)
-\sum_ka_k\mathbb E_{Q_k}\log L_G
-\mathbb E_{q_E}\log L_E
-\sum_ka_k\mathbb E_{Q_k}\log\mathcal N(r;H_kz,R).
\]
For each Gaussian \(Q=\mathcal N(\mu,\Sigma)\), the last expectation is
\[
-\frac12\left[d_r\log(2\pi)+\log\det R+
 (r-H\mu)^\top R^{-1}(r-H\mu)+
 \operatorname{tr}(R^{-1}H\Sigma H^\top)\right].
\]
Both the covariance trace and observation normalizer are indispensable. Finally \(\log\pi_k=\log m_k-S_k-\log Z_f\) implies
\[
D(a\|\pi)=D(a\|m)+\sum_ka_kS_k+\log Z_f.
\]
A constant action shift \(S_k\mapsto S_k+c\) changes \(\log Z_f\) by \(-c\), and cancels exactly. At the retained posterior all three posterior KL terms vanish, giving \(\mathcal F=-\log Z\). This proves a normalized curvature-prior contribution together with its required normalizer; it is not a free additive regularizer.

The conditional \(Q_k\) may be arbitrary full SPD Gaussians. No clique-factorized recognition assumption is used, and the code correctly calls dense gaussian_kl and Gaussian likelihood expectations instead of reusing the local-tree accounting identity outside its factorization domain.

## 6. Coarse common channels and conditional telescope

The channel at depth \(l\) preserves \(k\), sends \(z\) to \(F_lz\), and applies the existing event channel to both endpoint records. Because recognition and posterior use the same channel and the label is retained, their parent KL is
\[
D_l=D(a\|\omega)+\sum_ka_kD(F_l\#Q_k\|F_l\#P_k)
 +D(K_l\#q_E\|K_l\#p_E).
\]
This is a KL of a decorated label and Gaussian components. It is not a formula for the KL of a label-marginalized Gaussian mixture.

For a full-row-rank \(m\times n\) map \(F\), choose complement rows \(N\) so \(T=(F;N)\) is invertible. Set \((Y,X)=Tz\). Under each Gaussian, write \(X|Y\sim\mathcal N(b+B Y,C)\). With recognition and posterior parameters distinguished by \(q,p\), put
\[
\Delta B=B_q-B_p,\quad
\delta=b_q-b_p+\Delta B \mu_{Y,q}.
\]
Integrating the conditional Gaussian KL over \(Q_Y\) yields
\[
\frac12\left[
\operatorname{tr}\{C_p^{-1}(C_q+\Delta B \Sigma_{Y,q}\Delta B^\top)\}
+\delta^\top C_p^{-1}\delta-(n-m)
+\log\det C_p-\log\det C_q
\right].
\]
The extra covariance term follows by expanding the quadratic mean difference about \(\mu_{Y,q}\); its centered cross terms integrate to zero. The conditional covariances are SPD Schur complements. For \(m=n\) there is no hidden coordinate and the correction is zero. This independently reproduces local_tree.gaussian_discarded_kl.

For correlated event records with stochastic matrix \(K\) acting on each endpoint pair, the pushed table is \(q'=K^\top qK\). On common support the joint-lift KL identity gives the correction
\[
\sum_{i,j}q_{ij}\left[
\log(q_{ij}/p_{ij})
-\sum_{a,b}K_{ia}K_{jb}\log(q'_{ab}/p'_{ab})
\right].
\]
It follows by summing the four-index lift \(q_{ij}K_{ia}K_{jb}\); structural-zero destinations contribute nothing because their incoming products vanish. This is the formula in event_discarded_kl, not a conditional estimated by subtracting two floating KL values.

Weight the Gaussian correction by \(a_k\) and add the event correction to get \(D_\mathrm{fine}=D_l+\mathcal C_l\), hence the corresponding VFE identity with unchanged evidence. Products \(F_{12}F_{01}=F_{02}\) and normalized event-channel composition give componentwise direct/staged law equality. Applying the conditional identity to each adjacent pair proves
\[
\mathcal C_{0\to2}
=\mathcal C_{\mathrm{availability}}+\mathcal C_{0\to1}+\mathcal C_{1\to2},
\]
when the left side means correction from the full latent law. Depth zero has already emitted the availability channel, so its event correction need not vanish. The source code retains this term in conditional_telescope_residual.

## 7. Source correspondence, attempted falsifiers, and remaining boundary

The new builder calls inference.build_context with the intentional legacy defaults and then obtains supported source Gaussian/event laws and the old observation once. Field labels affect their actual path transports and new loop likelihoods, not the old source construction. The selector uses the active agent's four coordinate positions; the probe frame comes from the same basepoint geometry. Input r/R are converted from the common reference probe frame. Each conditioning call has an explicit component batch, matching model.condition's log-evidence shape contract. The separate stacked route starts from the original prior, and its evidence comparison includes event evidence once.

The accounting path uses every Gaussian component and field mass, with log-sum-exp for finite field normalization. It rejects nonfinite actions and underflowed positive masses through finite/positive admission. Mathematically positive SPD covariances are also checked in the floating outputs. This does not certify numerical accuracy over every extreme finite input; ordinary focused execution is still separate. The coarse path keeps the field labels, uses context.maps/event_channels for full-to-level pushes, obtains F12 from the actual supported family map, and computes its Gaussian and event conditional corrections by the formulas reconstructed above.

Potential falsifiers were checked at the mathematical and source level. A zero-area loop or zero curvature gives \(U=I,H=0\), so the loop density does not depend on z or the field label and \(\omega=\pi\); the observed vector r can still contribute a common evidence factor. Repeated field pairs have identical component likelihoods and conditional posteriors, so their posterior odds retain their prior odds. Reversing loop orientation changes the transport sign and need not give distinct likelihoods; neither construction claims identifiability. Label marginalization would invalidate the simple weighted-Gaussian KL, but this API retains the label. Failure to transform r/R would invalidate chart covariance, but the builder converts both. An omitted log partition would invalidate the prior decomposition, but the accounting returns it explicitly. None of these attempted scope attacks falsifies the stated model.

A prior over all continuous connections, iterative coupled label/Gaussian Fisher dynamics, a base-curvature term in this neighborhood model, or a parent-only autonomous evolution remains a different construction. The independent intake is therefore right at its narrow integration seam: a normalized likelihood adapter into this actual neighborhood joint is new, while gauge-sensitive observations and retained finite mixtures themselves already exist in other declared models. That source comparison supplies no novelty or universal-physics claim.

## 8. Freeze and disposition

This report records the mathematical reconstruction before root's numerical execution. The exact reviewed proof/source snapshot is bound below; any subsequent source change requires checking the affected correspondence before execution claims use this report. This report does not close the formal ledger, certify a runtime pass, or replace a whole-dependency prior-erasure pass. Reopen the affected argument if a frozen input changes or if an admitted input defeats one of the displayed equalities. No scientific repair is requested from the currently inspected implementation.



The binding identifies the exact reviewed proof and source snapshot, including the implementation note's Revision 1 proof/API text. Later test or implementation-freeze metadata is not a numerical result of this report. No test file or JUnit result is claimed as reconstructed or executed.

| Input | SHA-256 |
| --- | --- |
| [docs/derivations/2026-09-08-rg-program-completion/agents/finite-support-amendment.md](../../../../docs/derivations/2026-09-08-rg-program-completion/agents/finite-support-amendment.md) | 0b14956cc3b1086376b030ae3548cc010d8116564ef9f92ae979176beb0688b2 |
| [docs/derivations/2026-09-08-rg-program-completion/agents/finite-core.md](../../../../docs/derivations/2026-09-08-rg-program-completion/agents/finite-core.md) | 3fc9f64f8eb4d815c418873a1b0a1151f95aa890ed10ad930ae08300cd864718 |
| [docs/derivations/2026-09-08-rg-program-completion/agents/finite-core-interface-amendment.md](../../../../docs/derivations/2026-09-08-rg-program-completion/agents/finite-core-interface-amendment.md) | 852a746df81acf5d5314c80d5c65797984996fad6f3bd5a00e07afd1eb4ef5ef |
| [docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-inference-implementation.md](../../../../docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-inference-implementation.md) | 896f3c95c6db6e204e9218def4d20e827fe1e481ccb4dfb8d3d83ef0e41f0e81 |
| [docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-likelihood-intake.md](../../../../docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-likelihood-intake.md) | 9f0efa87ac0a11dcf03254913c7a0e3f393bc6dc4238f2f7a77c481fbb383bed |
| [src/multiagent_elbo/finite/vfe.py](../../../../src/multiagent_elbo/finite/vfe.py) | a6fe5aa7ca338178335e2e39b0fcc0666f16962af27328100a9edbbabf64cda1 |
| [src/multiagent_elbo/finite/scale_cocycle.py](../../../../src/multiagent_elbo/finite/scale_cocycle.py) | 2f3da104ccdd3259e0776bf2ae9806116ca074002241386cf79e021a7831700d |
| [src/multiagent_elbo/experiments/neighborhood/holonomy_inference.py](../../../../src/multiagent_elbo/experiments/neighborhood/holonomy_inference.py) | a2dfb82af0b5ea7bec9f38f8c91438e5b3a33fdbea283d3e6eb74fce53458960 |
| [src/multiagent_elbo/experiments/neighborhood/connections.py](../../../../src/multiagent_elbo/experiments/neighborhood/connections.py) | 53a497039842ad16efa1ac3b335d4a8c6c44abcb4ae4f9d237180a58e5452bb9 |
| [src/multiagent_elbo/experiments/neighborhood/model.py](../../../../src/multiagent_elbo/experiments/neighborhood/model.py) | 49af1bf02b9cd5030b8ee9d9fecf945d50cde0106f448efa51c2ae571562d94b |
| [src/multiagent_elbo/experiments/neighborhood/local_tree.py](../../../../src/multiagent_elbo/experiments/neighborhood/local_tree.py) | 6d9fcf0098be7ab44bb577eee6eee8909d30b0d35d0ce15b0f22521de93a5d2d |
| [src/multiagent_elbo/experiments/neighborhood/inference.py](../../../../src/multiagent_elbo/experiments/neighborhood/inference.py) | ade492121f2c261c06033955711199d4052602315acec8dac7be716692fc2251 |
| [src/multiagent_elbo/experiments/neighborhood/cover.py](../../../../src/multiagent_elbo/experiments/neighborhood/cover.py) | 0073e72aa3bca51a1cb27023ad223a91572c7be577bb296951ceaf4b70738e88 |
| [src/multiagent_elbo/experiments/neighborhood/categorical_inference.py](../../../../src/multiagent_elbo/experiments/neighborhood/categorical_inference.py) | 9cb467e29faf26774dd2cac914436af3fdc4a7ad977a5b622e271a2fd1d5d776 |
| [src/multiagent_elbo/experiments/neighborhood/gaussian_completion.py](../../../../src/multiagent_elbo/experiments/neighborhood/gaussian_completion.py) | a561bba6863719ec54fe5f865e5a40eeb5e50b74f680c2a856440ef3eac79ee2 |
