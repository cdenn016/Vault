<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Statistical and base curvature: normalized-action constructions

Revision 3, completed discovery derivation. This document proposes independently reconstructible mathematical results, not ledger closure. No code, tests, experiments, GPU operations, tamper checks, vault edits, or publication were performed. Primary heat-kernel sources were inspected; finite results below are reconstructed directly.

## S1. The invariant accounting rule

**DEFINITION.** At a fixed admitted context c and structural X, let P(dy,do|c,X) be a normalized generative joint and Q(dy) a normalized recognition law. For a positive finite evidence density p(o|c,X), posterior Pi(dy|o,c,X), absolute continuity Q<<Pi, and finite log integrals, the VFE is

\[
\mathcal F(Q;c,o,X)=\mathrm{KL}(Q\Vert\Pi)-\log p(o|c,X).
\label{eq:elbo-curvature-accounting}
\]

These are lemma-local probability symbols. A reference metric, a connection, or its curvature is not an additional term in this identity. Geometry can affect the identity's value through the actual normalized laws or their reference measures. A reference change must transform both densities; one must not count its Jacobian twice.

**ESTABLISHED, direct algebra.** Let nu be a probability reference and V a measurable potential with 0<Z_V=integral exp(-V)dnu<infinity. The declared normalized prior dP_V/dnu=exp(-V)/Z_V gives, for finite terms,

\[
\mathrm{KL}(Q\Vert P_V)=\mathrm{KL}(Q\Vert\nu)+\mathbb E_Q V+\log Z_V.
\label{eq:elbo-curvature-prior}
\]

Substitute the log density ratio. Thus a curvature potential has a precise probabilistic bridge if it is a prescribed function of a genuinely random variable, independent of the current recognition choice. The model choice is V; normalization is a theorem only after Z_V is finite. Adding a constant k to V multiplies Z by exp(-k), so the two added constants cancel exactly.

**ESTABLISHED, scoped obstruction.** If context c and its metric/connection are external and held fixed, adding a scalar V(c) uniformly to the latent action changes no normalized prior at that context. Its partition factor cancels. If one instead records it as an observation likelihood or a prior on random contexts, that is a different normalized model with a new evidence/entropy term. Recognition-dependent curvature potentials do not define the inherited fixed generative joint unless the law/configuration itself is explicitly promoted to a random latent with its own proper reference and recognition distribution.

## S2. Fisher metric does not select a curvature penalty

**HYPOTHESIS.** Let q_theta be a C3 positive regular family on a finite sample set, with identifiable tangent coordinates. Finite sums justify all differentiations. Its Fisher metric is G_ab=E_q[(partial_a log q)(partial_b log q)]. The smooth dominated extension separately needs differentiation under the integral and the stated square-integrable scores; differentiability in quadratic mean alone does not supply all higher derivatives or curvature tensors.

**ESTABLISHED, direct differentiation.** Normalization gives E_q partial_a log q=0 and E_q partial_ab log q=-G_ab. Taylor expansion of the second argument therefore gives

\[
\mathrm{KL}(q_\theta\Vert q_{\theta+v})=\tfrac12 G_{ab}(\theta)v^a v^b+O(\|v\|^3).
\label{eq:ig-curvature-local-kl}
\]

The Fisher metric is this quadratic local distinguishability. Its Levi-Civita curvature requires derivatives of G and is not the Hessian matrix itself. For a differentiable scalar VFE f, the natural-gradient vector is G^{-1}df. The differential df comes from the chosen normalized probability problem; G supplies its metric conversion. No scalar-curvature summand is obtained by this conversion.

**ESTABLISHED, finite counterexample.** On the positive three-outcome simplex take q=(1/3,1/3,1/3) and an uninformative normalized observation. Model 0 has posterior p0=q and model 1 has posterior p1=(1/2,1/4,1/4). The variational family, Fisher metric, and every curvature invariant at q are identical for both models, but their VFEs are respectively zero and (1/3)log(32/27)>0. Geometry alone therefore does not determine the VFE. Under u_i=2 sqrt(q_i), the Fisher metric sum_i dq_i^2/q_i becomes the Euclidean induced metric on the radius-two sphere in the positive orthant; its sectional curvature is 1/4 and its two-dimensional scalar curvature is 1/2. Nonzero statistical curvature is compatible with exactly zero VFE and zero natural-gradient velocity at p0=q. The explicit spherical metric calculation, rather than a qualitative analogy, supplies this example.

**ESTABLISHED, interface with event closure.** For the event lane's fixed minimal exponential family q_theta proportional to h exp(theta dot T), G=Hess A and f(theta)=KL(q_theta||q_eta) gives df=G(theta-eta). Hence the negative natural gradient is eta-theta. This exact update already includes the Fisher geometry. Adding R_F(theta) changes the variational objective and generally its trajectory; it is not a correction required to make the existing flow geometric. Affine natural coordinates and dual-flat statistical connections do not imply flatness of the Levi-Civita connection of G.

## S3. Exact compact base-curvature example

**DEFINITION.** Take the smooth compact two-dimensional base C to be the disjoint union of round spheres of radii 1 and 2, with their usual Riemannian metrics. This is a disconnected compact example, not a physical spacetime claim. Set nu_g=dvol_g/Vol_g(C). The two component masses are w=(1/5,4/5), and their scalar curvatures are R=(2,1/2). Promote c to a random latent. Let the observation consist of a single certain symbol and define the normalized curvature prior

\[
\frac{dP_\lambda}{d\nu_g}(c)=Z_\lambda^{-1}e^{-\lambda R_g(c)},\qquad
Z_\lambda=\frac{e^{-2\lambda}+4e^{-\lambda/2}}{5}.
\label{eq:prob-curvature-two-spheres}
\]

Every real lambda is admitted because C is compact and its curvature bounded. Lambda has the units needed to make lambda R dimensionless. This is declared model data, not a coefficient derived from VFE or gauge covariance.

**ESTABLISHED, direct finite reduction.** Let Q_a be uniform within each sphere with component masses (a,1-a), 0<a<1. Then

\[
\mathcal F(Q_a)=a\log\frac{a}{1/5}+(1-a)\log\frac{1-a}{4/5}
+\lambda\left(2a+\tfrac12(1-a)\right)+\log Z_\lambda.
\label{eq:elbo-curvature-two-spheres}
\]

Integration over each component proves this formula. It is exactly the binary KL to the prior component weights proportional to (exp(-2lambda),4exp(-lambda/2)). The unique minimizing a is the first normalized weight. Curvature contributes to this VFE because c is random under a declared curvature-weighted prior; the component-dependent density cannot be removed by a global normalization constant. If the base were a single round sphere, R_g would be constant and the entire lambda dependence would cancel. If c were conditioned on from the start, the base prior would likewise contribute no within-c recognition force.

## S4. Statistical holonomy and induced base tensors

**DEFINITION.** Statistical holonomy refers to parallel transport in the tangent bundle of a regular statistical manifold under a specified connection: the Fisher Levi-Civita connection or a declared alpha-connection. It is not the principal gauge-bundle holonomy of omega_b or omega_m over the context base. The two constructions have different tangent spaces and different loops. Even in an exponential family, flat exponential/mixture connections coexist with nonflat Fisher Levi-Civita geometry. A connection must be named before its curvature or holonomy is discussed.

**ESTABLISHED, obstruction.** A closed parameter loop ending at its initial law leaves any fixed-joint endpoint VFE unchanged. Parallel transport of a tangent vector around that loop can still be nontrivial. This follows because VFE evaluates the endpoint probability law, whereas holonomy evaluates a connection along an entire loop. One may declare a path-space prior or observation kernel involving that holonomy, but it adds a path random variable or a prescribed path-dependent factor. Endpoint VFE alone does not supply that factor. A flat connection with nontrivial global monodromy also shows why a local curvature scalar cannot encode every loop comparison.

**ESTABLISHED, exact type restriction.** The inherited smooth construction supplies h_q^omega=(D^omega q)^*g^F on the context tangent bundle. It is a semimetric unless D^omega q is injective. Riemannian scalar curvature R(h_q^omega) therefore is undefined at an unhandled rank defect. Constant rank gives a metric vector-bundle quotient; interpreting that quotient as a base manifold additionally needs an integrable null distribution, a regular leaf space, and a basic tensor. These are inherited restrictions, not solved by attaching an R symbol. Separate belief/model pullbacks require a declared joint-law metric or explicit channel weights before combination.

**ESTABLISHED, direct geometric distinction.** Even when a section is an immersion into one statistical manifold in a flat product presentation, the curvature of its induced metric is not simply the ambient Fisher scalar composed with the section. In a Euclidean ambient space a radius-two sphere has curved induced metric while the ambient curvature vanishes. More explicitly, the sphere's unit normal has derivative X/2 along a tangent X; projecting ambient derivatives to the tangent space gives R(X,Y)Z=(<Y,Z>X-<X,Z>Y)/4 in the positive sectional-curvature convention. Curvature of an induced metric therefore also depends on how the image bends. In a general associated bundle, h_q^omega is connection-relative as well; no immersion formula may be imported without its map and connection hypotheses.

**DEFINITION.** A genuine Fisher-curvature prior is possible on a separately random model parameter theta: choose a smooth regular statistical family, a compact parameter domain K with bounded continuous R_F, a proper reference nu_K (optionally normalized Fisher volume), and p_lambda(theta) proportional to exp(-lambda R_F(theta)). Formula S1 then gives its exact parameter-level VFE. The current recognition parameter is not silently that latent theta. Proper Fisher volume, compactness, and the prior coefficient are extra model choices; a statistical family need not possess a finite Jeffreys volume. This construction proves existence under the stated compact restriction and does not select a canonical curvature prior.

## S5. Exact Gaussian marginalization and its cancellation control

**HYPOTHESIS.** Let u belong to a nonempty compact retained parameter space with reference probability nu, V(u) continuous and real, and H(u) a continuous symmetric r-by-r matrix with H(u)>=a I for one a>0. Let x in R^r be a genuinely random auxiliary variable with Lebesgue reference dx. No infinite-dimensional field measure is being used.

**DEFINITION.** Declare the joint density with respect to nu(du)dx to be proportional to exp[-V(u)-x^T H(u)x/2]. Its finite positive partition function and its marginal can be computed by orthogonally diagonalizing H and using the one-dimensional Gaussian integral. 

**ESTABLISHED, direct Gaussian integration.** The result is:

\[
Z=(2\pi)^{r/2}\int e^{-V(u)}\det H(u)^{-1/2}\nu(du),\qquad
\frac{dP_U}{d\nu}(u)=\frac{e^{-V(u)}\det H(u)^{-1/2}}{\int e^{-V}\det H^{-1/2}d\nu}.
\label{eq:gauss-curvature-marginal}
\]

Compactness bounds V and H, and the positive lower spectral bound makes the integral finite and nonzero. The exact unnormalized effective action is V+(1/2)log det H-(r/2)log(2pi), with every normalizing constant retained when computing evidence. The negative half log determinant belongs to the integrated log density; the effective negative log density has the positive half sign.

**ESTABLISHED, cancellation control.** Start instead from a normalized hierarchical model P_0(du) N(dx;0,H(u)^{-1}). Its conditional Gaussian density already contains det H(u)^{1/2}/(2pi)^{r/2}; integrating x returns P_0 exactly. There is no new marginal log determinant. These two models have different u marginals and different joint densities. A determinant from marginalizing an unnormalized factor cannot be added again after a normalized conditional has already accounted for it.

**DEFINITION with exact consequence.** In the two-sphere example choose r>=1, m^2>0, xi>=0 and H(c)=(m^2+xi R_g(c))I_r in the first joint model. Both scalar curvatures are positive, so the precision is uniformly SPD. Its exact retained component weights are proportional to

\[
\left(\tfrac15 e^{-V_1}(m^2+2\xi)^{-r/2},\quad
\tfrac45 e^{-V_2}(m^2+\xi/2)^{-r/2}\right).
\label{eq:prob-curvature-determinant-witness}
\]

The curvature dependence was declared in the auxiliary precision. Its nonlinear determinant potential is derived by integration. This is a finite, normalized Bayesian construction; it uses no quantum-loop identification, infinite regulator, or assumption that all effective actions are quadratic. A scalar Fisher invariant can replace R_g only when u is the separately declared random statistical parameter and the analogous positivity bound holds.

**ESTABLISHED, exact ELBO correction.** Under finite KL and a fixed normalized likelihood (including the certain observation used above), pushing generative, posterior and recognition laws through (u,x)->u yields

\[
\mathcal F(Q_{U,X})=\mathcal F(Q_U)+\mathbb E_{Q_U}\mathrm{KL}\bigl(Q(dx|u)\Vert\Pi(dx|u,o)\bigr).
\label{eq:elbo-curvature-conditional-correction}
\]

Factor both joint density ratios into marginal and conditional ratios and integrate. Thus the marginal determinant does not eliminate the discarded recognition-versus-posterior correction. Equality holds exactly when those conditionals agree Q_U-almost surely. This is the same retained-law accounting used by the event and base-descent constructions.

## S6. Heat-kernel models with explicit normalization

**HYPOTHESIS and imported theorem scope.** Let (C,g) be a connected compact smooth Riemannian manifold without boundary, dimension d, and Delta_g=div_g grad_g (nonpositive spectrum). The scalar heat kernel k_t(c,c') of exp(t Delta_g), t>0, is a smooth positive transition density against dvol_g. We import its existence and local parametrix expansion in this scope. The original construction is [Minakshisundaram and Pleijel, 1949, Section 1](https://doi.org/10.4153/CJM-1949-021-5); compact smooth Laplace-type conventions and the coefficient readback are given by [Avramidi, 1997, Sections 1 and 2, equations (49)-(54) and (105)](https://arxiv.org/pdf/hep-th/9704166). These sources are used for the analytic heat theorem, not for a VFE claim.

**ESTABLISHED, normalization from the heat equation.** For fixed c the mass integral satisfies partial_t integral k_t(c,c')dvol(c')=integral Delta_(c')k_t dvol=0 on a closed manifold; its initial mass is one. Positivity follows from the maximum principle and connectedness. Hence the joint nu_g(dc)k_t(c,c')dvol_g(c') is a normalized Markov model. Its finite sequence product is also normalized by successive integration. The model's VFE uses the actual -log k_t in its action. A geodesic-distance-only approximation drops the heat kernel's geometric coefficients and generally its exact normalization.

**ESTABLISHED, imported local coefficient.** With the preceding sign convention,

\[
k_t(c,c)=(4\pi t)^{-d/2}\left[1+\tfrac{t}{6}R_g(c)+O(t^2)\right].
\label{eq:geo-curvature-heat-diagonal}
\]

The remainder is uniform on compact C. Avramidi's convention uses powers (-t)^k/k! and B_1=integral(Q-R/6), so setting the bundle potential Q=0 gives the plus R/6 coefficient. A positive constant mass may be added for his positive-operator Mellin construction, then removed by multiplying the heat kernel by exp(t m^2); no zero-mode determinant is inferred. This is a small-t asymptotic, not a globally convergent curvature series or a claim that the diagonal alone is a transition density.

**DEFINITION.** One particularly simple separate prior on random c is obtained by normalizing that diagonal:

\[
\frac{dP_t}{d\nu_g}(c)=\frac{\operatorname{Vol}_g(C) k_t(c,c)}{\operatorname{Tr}e^{t\Delta_g}},\qquad
\nu_g=\frac{d\operatorname{vol}_g}{\operatorname{Vol}_g(C)}.
\label{eq:prob-curvature-heat-prior}
\]

Its denominator is finite and positive at every t>0. This is a declared heat-diagonal prior. In a continuous state space, observing an exact return to the starting point is not an event of positive probability; such an operational claim would require a finite-resolution return detector and its own normalized likelihood. No such return-observation interpretation is used here.

**ESTABLISHED, derived normalized expansion.** Let Rbar=E_(nu_g)R_g. Divide the diagonal expansion by its integral to obtain dP_t/dnu_g=1+t(R_g-Rbar)/6+O(t^2), uniformly on C. Applying log(1+z)=z+O(z^2) and integrating under any fixed Q with finite KL(Q||nu_g) gives

\[
\mathrm{KL}(Q\Vert P_t)=\mathrm{KL}(Q\Vert\nu_g)-\tfrac{t}{6}\left(\mathbb E_Q R_g-Rbar\right)+O(t^2).
\label{eq:elbo-curvature-heat-normalized}
\]

This signed, centered scalar-curvature contribution is derived from the chosen heat-diagonal prior. It differs from the arbitrary-sign Gibbs prior S3 and therefore cannot be a universal curvature coefficient supplied by VFE. At Q=nu_g the linear term vanishes, as normalization requires.

**OPEN, excluded extension.** With boundary, one must choose boundary conditions and retain boundary coefficients; a Dirichlet heat kernel is a killed transition and needs a cemetery state or explicit survival normalization to define the claimed Markov model. Noncompact manifolds need separate conservativeness, heat-integrability and normalization hypotheses. A finite parameter region with reflecting boundary is another declared model. None follows from the current open context domain U, which has not been equipped with such a heat process. No heat-kernel profile is being added to the live implementation in this lane.

## S7. What a continuum determinant would require

**ESTABLISHED, finite proper-time identity.** For any SPD r-by-r matrix H and scalar mu^2>0,

\[
\log\det(H/\mu^2 I)=-\int_0^\infty\frac{\operatorname{tr}(e^{-tH})-r e^{-t\mu^2}}{t}dt.
\label{eq:gauss-curvature-finite-proper-time}
\]

For one eigenvalue a, the derivative in a of the right side is integral_0^infinity exp(-ta)dt=1/a and its value at a=mu^2 is zero. Summing proves the identity. At zero the subtracted numerator is O(t); at infinity positivity gives exponential decay. This converts the finite determinant S5 to a heat-trace expression without a field-theory assumption.

**DEFINITION, regulated extension.** One may separately choose a positive elliptic operator L=-Delta_g+m^2+xi R_g on a compact closed base, with m^2+xi R_g>=a>0, then a finite mode/mesh realization L_N and a specified coordinate measure. Each fixed N is a finite Gaussian construction S5. Identifications between mode spaces, reference Jacobians and a background measure must be declared if g itself varies. If g is held external, an additive integral depending only on g is constant for within-background recognition and is not a geometric force on g.

**OPEN, exact missing bridge.** Passing N to infinity does not supply an infinite-dimensional Lebesgue measure or a finite determinant. A proper-time cutoff defines a regularized number, while removing it requires a specified subtraction scheme, scale, counterterms, and proved convergence or an accepted asymptotic error statement. Spectral regularization of log det is not by itself construction of a probability law on sections or metrics. A field-theoretic or physical interpretation additionally needs the random configuration space, proper prior, observation model, gauge quotient when applicable, units, and the corresponding exact ELBO. Neither PIFB2's one-loop expression nor an imported quantum formula discharges these obligations for the present model.

**ESTABLISHED, conditional implication only.** If a finite realization's chosen operator and integration produce particular curvature invariants in its retained log density, those coefficients belong to that model's exact or explicitly approximated action. Symmetry alone says an invariant is allowed, not that its coefficient is nonzero. Even a determinant cannot imply that every allowed invariant is generated; cancellations, dimension identities, topology and additional symmetries can eliminate terms. No universal continuum curvature action is proved by this lane.

## S8. Independent invariants and mixed terms

**DEFINITION.** Keep three tensors separate: principal gauge curvature F^x on the base valued in the common adjoint bundle; Riemannian curvature Riem(g) of a declared nondegenerate base metric; and statistical curvature Riem(g_x^F) on vertical statistical tangents with a specified connection. Their scalar contractions use different metrics and different index spaces. Calling the Fisher matrix a curvature matrix in optimization does not identify it with any of these Riemann tensors.

**ESTABLISHED, type-level independence.** A constant law section over a curved prescribed base can have zero D^omega q and nonzero R_g. The positive categorical family has nonzero intrinsic Fisher curvature over a flat base. A trivial principal bundle can carry a nonflat chosen connection. These choices are independent data, and the constructions above do not equate them. Connection-compatible descent in base-descent.md transports the law and gauge geometry; it does not introduce a Riemannian base metric or identify the source metric with a nondegenerate pullback from a lower-dimensional base.

**DEFINITION, symmetry-allowed candidates only.** When all displayed tensors are smooth, nondegenerate where inverted, and evaluated at a gauge-equivariant section q, examples of well-typed scalar densities against dvol_g include R_g, R_g^2, ||Ric(g)||_g^2, ||Riem(g)||_g^2, R_F(q(c)), g^{mu nu}g^F(D_mu^omega q,D_nu^omega q), R_g R_F(q(c)), and Ric(g)^{mu nu}g^F(D_mu^omega q,D_nu^omega q). A target-curvature contraction can be written in a base orthonormal frame as sum_(a,b) g^F(R^F(D_a^omega q,D_b^omega q)D_b^omega q,D_a^omega q), using the convention of S4. Gauge-curvature squares require a declared positive invariant adjoint/fiber pairing as in the separate gauge lane. Multiplying such a scalar by R_g or R_F gives further allowed mixed terms. This list is not a basis and is not a claim of nonzero generation or positivity of every item.

**ESTABLISHED, typing obstruction.** There is no generic trace of a product between a principal-gauge curvature and a Fisher curvature operator: they act on different bundles. Such a cross contraction requires a declared representation/intertwiner or a common induced operator. Similarly, an ordinary local density on a finite graph does not possess a unique smooth scalar curvature without a separately declared geometric realization or discrete curvature definition. None of these missing structures is supplied by the word holonomy.

## S9. Requested historical-intuition readback and adopted scope

**NOT-CLAIMED.** This is an agent-note comparison requested by the brief, not a proposed insertion into Theory, whose governing SPEC excludes PIFB2 from its narrative. The inspected live Research manuscript separates its index base, optional induced metric, regulated consensus construction, normalized configuration Gibbs lift, and local fluctuation determinant. Its configuration Gibbs identity explicitly adds configuration entropy and requires a finite partition function; its one-loop expression is restricted to positive physical Hessian modes and a specified quotient measure. Those cautions agree with the bridges S1 and S5. They do not establish a curvature term in the present state-level joint.

**ESTABLISHED, scoped source clarification.** The live consensus-metric discussion says that in a gauge-flat regime every curvature invariant vanishes. Extending that sentence to all three geometries would be false: S2's categorical Fisher sphere remains curved with trivial gauge connection. Its applicable reading concerns invariants of the specified gauge curvature. The pullback and Fisher/base distinctions in the current Theory/SPEC.md and Research wiki govern this lane. The historical statement that elimination generally generates symmetry-allowed operators is a generic expectation, not a guarantee for each invariant; the normalized-conditional control S5 supplies an explicit cancellation mechanism.

**HYPOTHESIS, minimal implementation recommendation.** Preserve the existing prescribed connections and exact Fisher inference. If a curvature-cost example is desired, first add one separately declared finite context-mode prior corresponding exactly to S3, optionally the r-mode Gaussian extension S5. The record should retain reference masses, geometric labels/radii, the chosen curvature or precision potential, normalizer, posterior weights, and the complete VFE/conditional-KL accounting. This uses a normalized two-state model and existing finite pushforward logic. It does not require a curvature calculator, quantum loop machinery, continuum discretization, or modifications to the user's current config. A future implementation should include the constant-curvature cancellation control and the normalized-conditional cancellation control as mathematical model comparisons; neither is a tamper check.

**OPEN, adoption boundary.** This lane constructs optional probabilistic extensions; it does not establish that the active event/Gaussian model needs them. Adopting a random base, random statistical parameter, or random field changes the sample space. The root must keep these profiles separate and must not append their energy terms to the current ELBO without the associated normalized joint, entropy and evidence. Continuum section measures, autonomous field dynamics, quantum correspondence, physical time, Einstein equations, and coefficient selection remain unproved here.

## Sources, novelty boundary and cross-lane handoff

The only imported analytic construction is the cited compact heat-kernel theorem. [Amari's original natural-gradient article](https://doi.org/10.1162/089976698300017746) supports the distinction between a loss and its metric-defined steepest direction; S2 independently derives the finite-family formula. The primary heat source's local parametrix and Avramidi's sign/coefficient conventions were inspected on 2026-09-08. No literature-priority claim is made. Gaussian integration, normalized potentials, the two-sphere reduction, the categorical counterexample, and the finite proper-time identity are algebraic constructions proved here.

Read-only local context: Theory/SPEC.md in full; agents/event-closure.md; agents/base-descent.md; agents/curvature-user-steering.md; Research/wiki/concepts/Fisher information metric.md; Research/wiki/concepts/Physics from Fisher information.md; Research/manuscripts/PIFB2.tex at its base-manifold, consensus-metric, configuration-correlator and Gibbs-lift passages. Memory was used only to route the distinction between state and configuration sample spaces (MEMORY.md:902-903), and that distinction was checked against the live manuscript. Other agents' files and vault files were not changed.

To Root: S1-S3, S5 and the derived normalized expansion S6 supply candidate atomic claims. Keep the exact compact model and the conditional heat theorem separate. To Gauge: the finite unnormalized-Gaussian versus normalized-conditional distinction is a required determinant control; a cutoff heat coefficient is not a newly normalized prior by itself. To Base Descent: no scalar curvature exists for the bare base quotient until a metric or regular metric quotient has been declared, and noninjective base pullback is degenerate along forgotten directions. To Event/Evolution: the exact natural-coordinate Fisher update already uses its metric, and adding statistical curvature changes that objective; none of this lane changes its closure theorem or supplies physical time.

Failure conditions are an omitted normalizer or Jacobian, promoting external geometry to a random variable without a prior, using a recognition-dependent generative factor, undefined curvature at a rank defect, counting a normalized Gaussian determinant twice, treating an asymptotic heat expression as an exact Markov kernel, or asserting an unproved continuum measure. Independent reconstruction and root-owned source binding remain before any ledger closure. No code or tests were run by this lane.

