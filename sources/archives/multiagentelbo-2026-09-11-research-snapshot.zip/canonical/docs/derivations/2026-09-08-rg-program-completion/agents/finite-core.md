<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Common-channel finite action and ELBO tower

Family: finite-retained. Kind: CONSTRUCTION and LEMMA, with a local-gluing counterexample. Root reconstruction, submitted for a separate check. This proof uses only finite sums and elementary logarithm identities. It makes no literature-priority claim. Source interfaces are finite/scale_cocycle.py::ExactMarkovChannel and conditional_log_laplace_action, finite/measures.py::MeasurePair, finite/vfe.py::vfe_channel_decomposition, and the complete-carrier action modules named in coverage.md. Their exact-rational and numerical representations are distinct.

## F1: Normalized input and exact effective action

Let X,O be nonempty finite sets. Declare nonnegative masses P(x,o) with sum_(x,o)P=1. For an observation o with Z_o=sum_x P(x,o)>0 define the posterior p_o(x)=P(x,o)/Z_o. Let q be a probability with finite KL(q||p_o). Independently declare a finite reference measure mu(x)>=0, positive on the support of P(.,o); define w_o=P(.,o)/mu on mu>0, and A_o=-log w_o when w_o>0, with A_o=+infinity at w_o=0. Values on mu-null points are immaterial. Reference normalization is not required. One may instead use raw Gibbs weights and their total normalization to construct P, but that normalization must be declared before interpreting Z_o as an observation probability.

Let C(y|x) be one row-stochastic recognition-independent kernel from X to a finite Y. Define P_C(y,o)=sum_x P(x,o)C(y|x), mu_C(y)=sum_x mu(x)C(y|x), and q_C(y)=sum_x q(x)C(y|x). Finite summation and sum_y C=1 give normalization of P_C and q_C and the same evidence Z_o. The posterior is p_C=P_C/Z_o=p_o C. For mu_C(y)>0, define the reference conditional

    mu(x|y)=mu(x)C(y|x)/mu_C(y).

It is normalized. Therefore

    w_C(y)=P_C(y,o)/mu_C(y)
          =sum_x mu(x|y) exp(-A_o(x)),
    A_C(y)=-log sum_x mu(x|y) exp(-A_o(x)).

The formula includes every induced interaction and every scalar normalization term. It is a density relative to the pushed reference, not generally the negative log of a normalized posterior relative to counting measure. The latter equals A_C-log(mu_C)+log Z_o where its density is positive. At mu_C=0, P_C and q_C vanish, so no conditional action at that point is needed. A positive coarse reference can still have zero evidence density; the action is then infinite. No arbitrary zero denominator is filled with a probability law.

For a second channel D(z|y), finite sums give (mu C)D=mu(CD), (P C)D=P(CD), and (q C)D=q(CD). Consequently direct and staged effective densities and actions agree on positive coarse reference support. This remains true for every finite tower by induction. It does not require pairwise closure, an invertible channel, or an all-agent overlap region.

## F2: Exact objective and conditional correction

Define the microscopic ELBO for observed o by

    L_X(q)=sum_x q(x) log[P(x,o)/q(x)]
          =log Z_o-KL(q||p_o),
    F_X=-L_X.

All sums use the usual zero-mass convention; finite KL ensures there is no positive recognition mass at zero posterior density. Construct the two common-channel joints Q(x,y)=q(x)C(y|x) and R(x,y)=p_o(x)C(y|x). Wherever Q>0, log(Q/R)=log(q/p_o), so KL(Q||R)=KL(q||p_o). For q_C(y)>0, write Q=q_C Q(x|y) and R=p_C R(x|y). Expanding the logarithm and summing gives

    KL(q||p_o)=KL(q_C||p_C)
              +sum_y q_C(y) KL(Q(.|y)||R(.|y)).

Thus

    F_X=F_Y+conditional_KL,
    L_Y=L_X+conditional_KL.

The conditional term is nonnegative: for positive t, log t<=t-1, obtained by checking the derivative and minimum of t-1-log t. Applying this inequality to R/Q on Q-positive states gives KL(Q||R)>=0. Equality holds exactly when the conditionals agree on q_C-positive rows, including their zero-mass complements by normalization. Missing rows have zero weight, not an inferred defined attention law.

For a channel tower, apply this identity at each level and telescope. The sum of adjacent conditional KL losses equals KL(q_0||p_0)-KL(q_n||p_n). It is a cocycle of actual measure losses. It does not assert that arbitrary minimum-KL fine laws constrained by qC=Q attain the joint-lift value; scale.md supplies a strictly positive counterexample to that extra assertion. If the channel depends on the evolving recognition state, these fixed-channel identities still describe a specified frozen value but their derivatives need additional terms. That dependence is excluded from the channel authority here.

## F3: Why locally specified VFEs are not sufficient gluing data

A normalized generative joint and a coherent recognition joint determine the exact global objective. Local conditional VFEs can then be obtained by fixing the other variables in that same objective, or exact local accounting can be recovered from an admitted factorization. Scalar local VFEs alone do not determine those joints. Pairwise compatibility on overlap marginals also does not generally prove joint existence.

For a strictly positive finite counterexample, take three binary variables. On each of the three pairs specify probabilities 0.05 for 00 and 11 and 0.45 for 01 and 10. All three pair laws are normalized, strictly positive and share uniform one-variable marginals. If a joint existed, the expected number of disagreeing edges on the triangle would be 3*0.9=2.7. Every binary triple has either zero or two disagreeing edges, hence expectation at most two. Contradiction. The local family is outside the admitted global-joint class; it does not refute the finite tower theorem, which starts from a declared joint.

For a positive clique tree satisfying the running-intersection property and compatible separator marginals, the usual product of clique laws divided by separator laws does define a normalized joint with those clique marginals. A finite proof removes a leaf clique: variables exclusive to the leaf occur nowhere else by running intersection. Summing its clique factor over those variables returns its separator law and cancels the matching denominator. Induction proves normalization. To recover any chosen clique marginal, root the tree at that clique and repeat the same leaf removals. This is exactly why local_tree.py's admitted chain is constructible and why the triangle example cannot use that proof. A cyclic or higher-overlap family needs its own extension criterion or a supplied global joint. Coordinates of local VFE updates may repeat an incident factor; the global joint counts each factor and observed record once.

## F4: Equivariance and interaction bookkeeping

For finite group actions, suppose mu, P and q are pushed under the declared frame change and C intertwines the source/target actions. Relabeling the finite sum then gives (g_*q)C=g_*(qC), with the same identity for mu and P. Reference densities transform by the resulting permutation and KL/evidence are invariant. A sequence of compatible intertwiners composes by substitution. The law-level argument alone says nothing about smooth connections; those require their separately typed first-jet squares in base-descent.md and evolution.md.

The logarithm of a marginal sum need not preserve an original pairwise interaction family. The exact density formula in F1 is retained even when its action contains higher-order terms. A projection to a smaller interaction span needs a separate error statement. The Ising diamond witness closes because simultaneous spin reversal leaves only the scalar and two-terminal pair contrast; it does not establish pairwise closure for arbitrary coarse graphs or arbitrary observations.

## Proof obligations and failure conditions

The finite identities are derived above for all finite positive-evidence inputs and common channels with finite initial KL. Failure would require an error in a finite-sum identity under those hypotheses. Removing joint existence, changing channels between q and p, discarding the conditional KL term or the pushed reference, replacing an algebraic density with an unqualified floating log, or suppressing an induced interaction is outside the statement. The generic implementation should be reused through its current exact interface; a new parallel framework is not proposed. An integrated example linking that interface to the new scale module and independent source-bound execution remain the next code obligations. Infinite-volume limits, smooth global disintegration and arbitrary base quotients are separate claims.
