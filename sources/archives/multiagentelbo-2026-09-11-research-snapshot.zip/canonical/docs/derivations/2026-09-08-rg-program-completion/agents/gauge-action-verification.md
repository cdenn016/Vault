<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Independent reconstruction of the gauge-action submission

Revision 2 final reconstruction, 2026-09-08. The root narrowed the shared verification brief to the other author's agents/gauge-action.md and assigned this file. I previously authored statistical-base-curvature.md, share the same filesystem and model lineage, and exchanged high-level normalization constraints with the gauge author. I did not author gauge-action.md. This is a cross-author reconstruction, not a fresh isolated or blinded review. My own statistical/base submission remains frozen and is excluded from this review. No code, scientific tests, GPU operations, tamper checks, source edits, ledger changes, vault writes, or publication were performed.

The reviewed gauge input is revision 2 with SHA256 267ca1217b1168b09bbb8fcffd4b6558d956fd96dc3560ded85c2610a9c9c39f. The frozen problem-contract.json file hash is 50db7529fc2c5cb7c032cd4e3b6517516a93800ba32db8c2c50c226ddb2a369e; its target digest is the metadata digest above, which is a different hash domain. Theory/SPEC.md has SHA256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1.

## V1. Compact normalization and exact ELBO

Reconstruction verdict: the finite compact-link bridge G1-G5 is correct under its declared references, support and finiteness hypotheses. A represented unitary loop H has eigenvalues exp(i theta_j), so 0<=1-Re tr(H)/n<=2. Therefore exp(-2 sum kappa)<=Z_Haar<=1. Independent endpoint actions telescope around a loop to conjugation, and bi-invariance of compact normalized Haar preserves the product reference. A zero face cost means every cos(theta_j)=1 and hence represented H=I; principal H=identity additionally requires a faithful representation. This validates the precise zero-set claim, not a global flatness claim from a partial face list.

Factor recognition as r(Theta)q(y|Theta) and the joint as exp(-S(Theta))p(y,o|Theta)/Z. Their log ratio is log r+S+log Z+log q-log p. Taking the joint recognition expectation proves G3 exactly. Factoring p(y,o,Theta)=p(o)Pi(y,Theta|o) then proves G4. For finite G with g elements and e links, r=g^e q and Z_count=g^e Z_Haar, so the added e log g in the recognition log density cancels the opposite partition/reference conversion. G5 has the correct constants.

No mean-field condition was needed. The generative conditional must remain fixed independently of recognition. Gauge covariance requires transforming matter references, recognition and the declared observation slice coherently; the submission explicitly retains those restrictions. No ledger closure is assigned by this reconstruction.

## V2. External background, MAP and latent field

Reconstruction verdict: Section 2's distinctions and coupling derivative are correct. A scalar depending only on a conditioned background multiplies every conditional unnormalized mass by the same factor; its conditional partition changes by that factor, so it cancels. This does not remove background dependence already present in the normalized matter likelihood or its evidence. An independent parameter prior is needed to interpret a separate S(Theta) as MAP. A point mass is singular against a positive nonatomic Haar-density prior, so it cannot stand in for a finite latent-field KL.

For fixed Q and matter conditional, differentiating Z=sum or integral exp(-sum kappa_p f_p) gives partial_kappa log Z=-E_prior f_p. Thus partial_kappa F=E_R f_p-E_prior f_p. Differentiating log evidence directly gives partial_kappa[-log p(o)]=E_posterior f_p-E_prior f_p. This also shows why retaining just the raw curvature penalty produces the wrong learning derivative.

## V3. The finite flux witness

Reconstruction verdict: G13-G15 are correct, interpreting the binary observation carrier as {+1,-1}. Each flux has eight of the sixteen link configurations. At t=exp(-2kappa), prior flux masses are (1/(1+t),t/(1+t)); E f=2t/(1+t) and its kappa derivative is -4t/(1+t)^2, exactly minus the variance of f in {0,2}.

At t=1/2 and epsilon=1/2, the prior atom masses are 1/12 in positive flux and 1/24 in negative flux. The o=+1 likelihoods are 3/4 and 1/4. Joint observation-slice atom masses are therefore 1/16 and 1/96, and summing eight of each gives 7/12 evidence. Posterior atom masses are 3/28 and 1/56. Under uniform recognition 1/16, the ratios to the joint slice are 1 and 6, giving F=(1/2)log 6. The posterior ratios are 7/12 and 7/2, giving KL=(1/2)log(49/24). Adding -log(7/12) yields exactly the same F. These are hand-derived finite identities, not executed enumeration results.

## V4. Signed curvature contraction and variation

Reconstruction verdict: G6-G8 have the correct sign and factors for the explicitly chosen anti-Hermitian representation and Riemannian base. In a base orthonormal frame put the represented Frobenius norm squared equal to -Re tr(F_mu,nu^2). The squared two-form norm for the declared algebra pairing is

\[
\|F\|^2_{L^2(g,\rho)}=\frac{1}{2n}\int\sum_{\mu,\nu}\|F_{\mu\nu}\|_F^2 d\operatorname{vol}_g
=\frac{1}{n}\int\sum_{\mu<\nu}\|F_{\mu\nu}\|_F^2 d\operatorname{vol}_g.
\label{eq:geo-gauge-review-norm}
\]

Multiplying by kappa/2 yields exactly the -kappa/(4n) ordered trace contraction in G7. A Lie-algebra kernel in the representation gives a semidefinite form on the full abstract algebra, even though the represented matrix form is positive. Hermitian field conventions reverse the displayed sign after moving the factor of i. An indefinite Lorentzian contraction supplies no positive Boltzmann bound. These qualifications in the submission are necessary and retained.

Expand F(A+epsilon a)=F(A)+epsilon(da+A wedge a+a wedge A)+epsilon^2 a wedge a. The linear term is D_A a. Differentiating kappa||F||^2/2 gives kappa<F,D_Aa>; the definition of the formal adjoint gives kappa<D_A^*F,a> once the declared compact-support/boundary condition removes the boundary pairing. No Fisher metric on the law family was used, and this variation does not derive a physical clock or probabilistic field reference.

## V5. Reconstruction of every small-loop remainder

Reconstruction verdict: G9-G12 and the flat-mesh classical limit are correct with the submission's explicit radial-gauge Lipschitz and smallness conditions. Those conditions are pointwise deterministic hypotheses, not known properties of a fluctuating ensemble.

Start with x^j A_j=0. Differentiation gives A_i+x^j partial_i A_j=0. Also x^j[A_j,A_i]=0. Thus x^j F_ji=x^j partial_j A_i+A_i. Along a radial ray this equals the derivative of u A_i(ux), after multiplying the curvature at ux by u. Integrating from u=0 to 1 gives A_i(x)=integral_0^1 u x^j F_ji(ux)du, which is exactly G9 in the chosen plane. Smooth radial transport on a star-shaped patch yields this gauge; no topology or global gauge-fixing assertion is needed.

Use the square orientation bottom-right-top-left with its base at the origin. Along the bottom and left radial edges the tangential coefficient is zero. On the right edge A_2(a,t)=a F_12(0)/2+error; its error is bounded by

\[
a\int_0^1 u L\|u(a,t)\|du\le\frac{\sqrt2}{3}La^2.
\label{eq:geo-gauge-review-edge-error}
\]

The reversed top edge contributes the same leading a^2 F_12(0)/2 after integration and the same error bound. Hence ||integral_boundary A-a^2 F_12(0)||_F<=2sqrt(2)La^3/3. Each nonradial edge has integral norm at most M a^2/2, giving B=M a^2 for the whole loop. This checks both constants and the orientation sign.

For U'=-A U, the k-th Dyson term for k>=1 has norm at most B^k/k!, because Frobenius norm is submultiplicative and the ordered integration region has the factorial volume bound. Thus ||U-I+integral A||_F<=exp(B)-1-B<=B^2 exp(B)/2, and ||U-I||_F<=delta=exp(B)-1. There is no missing factor sqrt(n): the identity term is subtracted and every retained series term contains at least one A.

If delta<1, the logarithm series converges in Frobenius norm and also in operator norm. The anti-Hermitian transport preserves unitarity, so the resulting logarithm is the anti-Hermitian principal logarithm. Its tail satisfies sum_(k>=2)delta^k/k<=delta^2/[2(1-delta)]. Combining this tail with the preceding two errors gives exactly

\[
\|\log U+a^2F_{12}(0)\|_F\le
\frac{2\sqrt2}{3}La^3+\frac{M^2a^4 e^{Ma^2}}2+
\frac{(e^{Ma^2}-1)^2}{2(2-e^{Ma^2})}.
\label{eq:geo-gauge-review-log-error}
\]

The denominator is positive by the same delta<1 condition. For fixed finite M,L this is O(a^3). No claim is made for loops large enough to leave that logarithm neighborhood.

Write X=log U=-a^2 F_12(0)+R with ||R||_F<=epsilon(a). Its eigenvalues are i theta_j, and the real cosine Taylor bound gives |1-Re tr(U)/n-||X||_F^2/(2n)|<=||X||_F^4/(24n). Separately, | ||X||_F^2-a^4||F_12(0)||_F^2 |<=2a^2 M epsilon+epsilon^2. Substitution gives all three right-hand terms of G12 with their stated coefficients. The first term is O(a^5), the second O(a^6), and the cosine remainder O(a^8), so the claimed overall O(a^5) is justified. An O(a^6) claim would not follow from these assumptions.

There are O(a^(-d)) coordinate plaquettes on the fixed flat box. Multiplication by the declared kappa_a=kappa a^(d-4) turns the total local error into O(a). The leading sum is kappa/(2n) sum_(mu<nu,x) a^d ||F_mu,nu(x)||_F^2. The separately assumed Lipschitz integrand gives an O(a) Riemann-sum error and the limit is the action in V4. This establishes deterministic consistency for the specified mesh, not convergence of partitions, evidence, posterior laws, or a continuum field probability. Curved-base quadrature and random-field regularity remain explicitly open as in the submission.

## V6. Two-square nonclosure and finite Gaussian loops

Reconstruction verdict: G16-G21 and the finite elementary-plaquette nonclosure claim are correct. The negative certificate refutes closure of the displayed elementary-face family under this finite matter elimination. It is not a separate nonexistence proof for every continuum curvature-squared theory.

For the seven-edge, six-vertex two-square graph expand each spin-link factor as cosh J times (1+tau s_i Theta_e s_j). Uniform independent spin averaging retains exactly those edge subsets with even degree at every vertex. On this graph their four possibilities are empty, the first face, the second face and their symmetric difference. The symmetric difference removes the shared edge and is the exterior six-edge cycle. Consequently the integrated weight divided by cosh(J)^7 is 1+tau^4(H_1+H_2)+tau^6 H_1H_2. Each flux pair has nonempty link support, so the four flux functions must be compared on all four sign pairs.

Let A=1+2tau^4+tau^6, B=1-tau^6, and C=1-2tau^4+tau^6. These are the (++), mixed and (--) sector weights. Positivity of the original sum proves positivity; directly, for x=tau^2 in (0,1), C=(1-x)(1+x-x^2)>0. The binary Fourier coefficient of H_1H_2 in log Z_m is log(AC/B^2)/4. Now AC-B^2=4tau^6(1-tau^2)>0. Thus K_12 is strictly positive and the effective negative log weight contains -K_12 H_1H_2. Orthogonality of the four sign characters, or direct evaluation on four sectors, rules out writing this as a constant plus c_1 H_1+c_2 H_2. This reconstructs G18-G19 independently of any cited lattice intuition.

The normalized-joint distinction in G16 is essential: integrating a normalized matter conditional returns the original link prior, whereas integrating an unnormalized matter factor reweights it by Z_m(Theta). In the observed case the normalized matter mechanism can still reweight the link posterior by p(o|Theta). The submission keeps those different operations separate.

For the Gaussian example let lambda_j(Theta) be the real eigenvalues of symmetric B(Theta). The bound |t lambda_j|<=r<1 gives I-tB>0 uniformly, with determinant between (1-r)^D and (1+r)^D. The finite Gaussian integral is therefore finite uniformly over compact link configurations. The scalar series log(1-t lambda_j)=-sum_(k>=1)(t lambda_j)^k/k is absolutely convergent, so summing D eigenvalues gives G20. The tail obeys

\[
\frac12\sum_{k>N}\frac{D r^k}{k}
\le\frac{D r^{N+1}}{2(N+1)(1-r)},
\label{eq:gauss-gauge-review-loop-tail}
\]

which is G21. Expanding block matrix multiplication traces products along closed graph walks; only walks present in the chosen graph and nonzero chosen blocks contribute. This does not guarantee nonzero coefficients for every symmetry-allowed invariant.

If |S-S_N|<=delta, exponential comparison yields e^(-delta)Z_N<=Z<=e^delta Z_N. Combining the action and log-normalizer differences gives |log(p/p_N)|<=2delta. Expectation under any fixed Q with the required finite terms proves the 2delta difference bound on the corresponding normalized VFE objectives. This final comparison is for the same support/reference and fixed Q; it does not compare independently chosen observation models without their evidence terms.

## V7. Holonomy and noncompact obstructions

Reconstruction verdict: Section 7's algebraic obstructions are correct in the stated represented setting, with the shear arguments understood for K>=2. Pointwise comparisons U_i U_j^(-1) telescope; independent edge copies need not. On a circle a U(1) connection A=i alpha dtheta has zero two-form curvature, while its full-circle transport is exp(-2pi i alpha), which can be nonidentity. Thus neither smooth curvature square nor a contractible-face list detects all monodromy.

For GL^+(K), the candidate trace potential 1-tr(tI)/K=1-t is unbounded below along t>0, and Haar measure has infinite total mass. This invalidates the compact bounded-normalization proof; unboundedness along a curve alone is not being used as proof that every possible regulated integral diverges. For K>=2, conjugation by diag(a,a^(-1),1,...) sends E_12 to a^2 E_12 and the corresponding unipotent shear toward I as a decreases to zero. Continuity and conjugacy invariance force a class function with f(I)=0 to vanish on that shear. A positive Ad-invariant algebra norm would similarly require ||E_12||=a^2||E_12|| for every a>0, a contradiction.

For the proposed additional SPD frame metric, cyclic trace shows invariance under X'=hXh^(-1), M'=h^(-T)Mh^(-1). Positivity follows from tr(M^(-1)X^T M X)=||M^(1/2)X M^(-1/2)||_F^2. Holding M fixed restricts the invariance group. Putting a recognition-dependent M into the generative factor would change the fixed-joint problem; the author's structural/latent alternative correctly states an additional model declaration.

## V8. Primary-source check and excluded claims

The original [Wilson paper, Section III](https://harvest.aps.org/v2/journals/articles/10.1103/PhysRevD.10.2445/fulltext) was inspected on 2026-09-08. Equations (3.9)-(3.11) give the abelian classical comparison; the paragraph immediately afterward distinguishes it from the harder quantized limit. Equations (3.28)-(3.29) give the nonabelian transformation/action and compact group integration. These support the attribution in the submission. The quantitative Frobenius, logarithm and cosine bounds in V5 are reconstructed here; they are not imported as Wilson's theorem.

[Kanwar et al., arXiv:2003.06413](https://arxiv.org/pdf/2003.06413) was also inspected. Page 2 discusses Haar-invariant priors; page 3 equations (6)-(8) give the two-dimensional U(1) Wilson action and product-Haar expectation; page 4 describes KL training of q against exp(-S)/Z. Its action differs from G1 by a constant per face, which cancels after normalization. The source supports that explicit precedent, not an automatic derivation of curvature from arbitrary VFE.

No physical identification, continuum random-field reference, quantum limit, universal action coefficient, or numerical implementation result was certified. Section 9's executable source map was not re-audited here: this assignment reconstructs the mathematical gauge submission and makes no runtime claims. PIFB2 remains requested contextual intuition rather than proof authority. My statistical/base manuscript and the induced geometry of its event family were not self-reviewed in this artifact.

## V9. Final disposition and provenance

The scoped compact-link normalization/ELBO, background-versus-latent distinction, finite flux calculation, elementary-plaquette nonclosure witness, signed Riemannian curvature contraction, quantified deterministic small-loop bound, Gaussian loop tail and noncompact algebra obstructions survive this reconstruction. No formula correction is required for these scoped claims. The adoption conditions are the explicit probability reference and partition, the specified represented algebra metric and base metric, genuine smooth transports for the mesh theorem, its uniform radial-gauge bounds, and a fixed common reference/support for action-error comparisons. Omitting those conditions would overstate the result.

This is a derivation-backed cross-author verdict; no formal ledger closure is assigned. Independent evidence must not be counted as isolation from the prior discussion: I am a co-located sibling author of the separate statistical/base lane and exchanged the common normalization bridge before verification. Root separately owns its review of that other manuscript. The reviewed input hashes above must remain unchanged for this verdict to apply; re-read hashes were recorded immediately before freezing this final revision. No scientific execution or tests were performed.
