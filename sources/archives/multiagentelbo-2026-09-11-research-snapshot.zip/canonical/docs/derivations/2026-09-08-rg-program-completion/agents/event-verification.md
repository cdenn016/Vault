<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Independent event-family reconstruction

Revision 1, frozen 2026-09-08. The finite identities and driven estimates of both proposed event families are **derivation reconstructed** under the assumptions below. The 39-coordinate family has no unresolved mathematical step blocking an implementation within the stated admission boundary. Implementation parity, machine precision, minimum dimension for the particular parameterized fixture, and unrelated program obligations remain open.

## Independence and exact scope

The assignment names `contract.json`; the existing artifact is `problem-contract.json`, which I read. Its digest matches this metadata. I read both assigned proposals, `agents/event-closure.md` and `agents/reduced-event.md`, and independently derived their finite identities. I did not author those proposals. This lane inherited the root assignment, repository/user instructions, and the proposed representations; it is a separate reconstruction after reading the proofs, not blind discovery. No author agreement, prior closure status, numerical observation, or desired program conclusion is a mathematical premise. I ran no tests, scientific computation, GPU work, or prohibited checks. No broad literature pass is needed for these self-contained finite-sum derivations.

All claims concern finite positive normalized laws on a fixed carrier with counting measure. No changing Gaussian dimension, physical time, autonomous visible-parent law, or full program closure follows. Source statements below concern the displayed real-valued formulas and call path; they do not establish binary floating-point identity. Source basenames resolve beneath `src/multiagent_elbo/experiments/neighborhood/`.

## E1: Fixed log-affine closure and exact step

**Disposition: derivation reconstructed.** Let `h(x)>0` on finite nonempty `X` and let `T:X -> R^d` be linearly independent modulo constants. Define

$$
A(\theta)=\log\sum_x h(x)e^{\theta\cdot T(x)},\qquad
q_\theta(x)=h(x)e^{\theta\cdot T(x)-A(\theta)}.
$$

For finite initial `theta`, finite target `eta`, and finite elapsed inference time `t>=0`, put `a=exp(-t)`. The full positive-simplex reverse-KL Fisher flow has log-odds equation

`d/dt log(q_x/q_y)=-log(q_x/q_y)+log(p_x/p_y)`.

This follows by writing its simplex gradient as `q_x[log(q_x/p_x)-E_q log(q/p)]`. Solving the linear odds equations and normalizing gives `q_new proportional to q^a p^(1-a)`. In this family,

$$
q_\theta(x)^a q_\eta(x)^{1-a}
=h(x)e^{[a\theta+(1-a)\eta]\cdot T(x)}\times\text{constant}.
$$

Thus normalization gives exactly `theta_new=a theta+(1-a)eta`. This is full-flow tangency, not a projected approximation. Every finite sequence with arbitrary in-family targets is closed. For fixed target these updates compose because the retention factors multiply.

The converse is exact for `0<a<1`: if the starting and resulting laws belong to the family, solving `log q_new=a log q_theta+(1-a)log p+constant` for `log p` places it in `log h+span{1,T}`. At zero elapsed time, `a=1` and target membership is unconstrained. Zero-probability initial/target laws and a context-dependent baseline/statistic family are outside this theorem.

## E2: Fisher pullback and natural velocity

**Disposition: derivation reconstructed.** Finite differentiation gives `grad A=m_theta=E_q T` and `Hessian A=G_theta=Cov_q(T,T)`. For a parameter tangent `v`,

$$
dq_\theta[v](x)=q_\theta(x)v\cdot(T(x)-m_\theta).
$$

The ambient Fisher pairing therefore pulls back to `v^T G_theta w`. Zero variance of `v dot T` implies it is constant at every cell because every mass is positive, so independence modulo constants forces `v=0`. This proves positive definiteness for each finite parameter; no bound uniform over all parameters is implied.

For an in-family target,

$$
\operatorname{KL}(q_\theta\Vert q_\eta)
=(\theta-\eta)\cdot m_\theta-A(\theta)+A(\eta),
$$

whose parameter gradient is `G_theta(theta-eta)`. Hence the negative Fisher gradient is `eta-theta`. Substituting into `dq` gives exactly the full-simplex vector used in E1. No numerical metric inversion is required to implement this analytically simplified velocity. Replacing Fisher geometry by an arbitrary Euclidean potential coordinate descent would not establish the same identity.

## E3: The identifiable 39-coordinate chain

**Disposition: derivation reconstructed.** Set `X={0,1,2,3}^4`, `h=1`, and reference outcome zero. Use twelve node indicators `1[x_i=a]` for nonzero `a`, plus twenty-seven edge indicators `1[x_i=a,x_j=b]` for nonzero `a,b` and edges `(0,1),(1,2),(2,3)`. A constant linear combination has constant zero by evaluation at the all-zero state; singleton changes set each node coefficient to zero; adjacent two-position changes then set every edge coefficient to zero. Thus the dimension is `12+27=39` and E2 is nondegenerate.

For any positive normalized candidate, let `l=log q` and `l_0=l(0,0,0,0)`. The unique candidate coefficients are

`u_i(a)=l(x^{i:a})-l_0`,

`v_ij(a,b)=l(x^{i:a,j:b})-l(x^{i:a})-l(x^{j:b})+l_0`.

Membership is equivalent to the **complete** identity `l(x)=l_0+sum_i u_i(x_i)+sum_edges v_ij(x_i,x_j)` at every cell. Necessity is substitution. Sufficiency and normalization force `l_0=-A(theta)`. The forty anchors alone cannot certify membership because those equalities hold by construction for every candidate.

Every arbitrary finite pair log potential decomposes into its constant, row-zero node term, column-zero node term, and anchored pair interaction by these finite differences. Positive node/edge Gibbs laws are exactly positive chains: define backward messages `b_3=1` and `b_i(x_i)=sum_{x_{i+1}} exp(u_{i+1}+v_{i,i+1}) b_{i+1}`. All messages are finite and positive. The normalized root proportional to `exp(u_0)b_0` and transition rows `exp(u_{i+1}+v_{i,i+1})b_{i+1}/b_i` telescope to the original normalized density. Conversely, the log of a positive root/conditional chain is a sum of node/edge functions. This supplies an exact finite-sum decoder without a cyclic marginal-extension assumption.

## E4: Membership of the admitted source fixture

**Disposition: derivation reconstructed from the source formulas.** `local_tree.py:19` fixes precisely the three chain cliques. `junction_tree.py:55` orders coordinate labels `(0,1,2,3)` and `:59` gives separators `{1},{2}`. `local_tree.py:109` constructs

$$
M_i(a,b)=(1-r_i)u(a)u(b)+r_i u(a)1[a=b].
$$

The unary `u` is a positive softmax. Finite nonnegative coupling gives `0<=r_i<0.308` for the prior and `<0.209` for recognition. Each table is positive, normalized, and has unary marginal `u` on either side. The reference uses uniform independent pairs. `junction_tree.py:157` checks the table/separator conditions and `:187` forms

$$
q(x)=\frac{M_{01}(x_0,x_1)M_{12}(x_1,x_2)M_{23}(x_2,x_3)}{u(x_1)u(x_2)}.
$$

Successive end-variable summation proves normalization directly. Its log lies in E3's span.

At `local_tree.py:134`, sorted coordinate order is reshaped into a `16 by 16` matrix. The first index is `(x_0,x_1)`. At `:142`, the normalized Bernoulli success likelihood is `L_c(a,b)=sigmoid(0.25 cos(c_y)-0.1(a-b)^2)`, strictly between zero and one. The multiplication by `likelihood.flatten(1)[:, :, None]` at `:147` is precisely multiplication by `L_c(x_0,x_1)`. The evidence at `:145` is its positive prior expectation. Thus the posterior adds one existing edge potential and one normalization scalar. This conclusion does not assume that the original clique tables remain posterior marginals.

`local_tree.py:255` admits finite contexts in `(-1.5,1.5)^2` and finite nonnegative coupling. It saves unmasked latent event laws at `:347`. `nonflat.py:71` obtains those laws and changes only geometry through its return at `:129`. `inference.py:56` reads those latent event fields, separately from availability/coarse channels. `moving_context.py:110` rebuilds arrival targets and reconciles only the Gaussian during transport; `:130` applies `categorical.full_step` to the unchanged event carrier. That function evaluates the geometric update at `categorical_inference.py:206`, with no probability floor or family projection. E1 therefore applies inductively to all finite histories admitted by this full-event path.

The initial and target latent event laws are in one fixed 39-coordinate family. Their real-valued formulas are smooth at availability boundaries because availability never enters these latent tables. Source construction, exact step, and event-state preservation are the complete mathematical admission boundary for the proposed implementation.

## Immediate implementation obligations

**O1, open:** an implemented compiler, coordinate order, stable decoder, full residual admission for arbitrary dense inputs, and runner must be checked against these formulas. No implementation parity was executed by this lane. The generic full-simplex solver must remain generic. The event evidence remains a separate generative scalar. Dense reconstructed outputs and retained ContextModel objects count toward memory, so 39 evolving coordinates alone do not imply reduced total memory.

**O2, open:** 39 is the dimension of the full positive chain family, not proved to be the smallest affine span of this particular fixture's analytic target range. A smaller-family claim requires a new analytic span argument over every admitted context, not sampled rank estimates.

**O3, open and outside scope:** event closure does not settle Gaussian boundary dynamics, autonomous lossy parent dynamics, base descent, interacting RG fixed points, or the root program target.

## E5: Driven natural coordinates and moving-target KL

**Disposition: derivation reconstructed.** Let `lambda>=0` be integrable on finite `[0,T]`, let `eta` be measurable with `lambda eta` integrable componentwise, and let `theta_0` be finite. Put `Lambda(s)=integral_0^s lambda`. The expression

$$
\theta(s)=e^{-\Lambda(s)}\theta_0+
\int_0^s e^{-(\Lambda(s)-\Lambda(r))}\lambda(r)\eta(r)dr
$$

is finite and absolutely continuous; its derivative almost everywhere is `theta'=lambda(eta-theta)`. Subtracting two solutions and multiplying by `exp(Lambda)` proves uniqueness. The image of this absolutely continuous parameter curve is compact on a finite interval. Composition with the smooth finite exponential family is therefore absolutely continuous and solves the full Fisher equation almost everywhere by E2. Continuous `lambda,eta` give a classical `C1` solution.

For bounded `eta`, the nonnegative weights have total one and imply the stated convex-hull bound. A compact parameter trajectory gives a positive minimum Fisher eigenvalue by continuity, but no useful conditioning constant uniform over arbitrary histories follows. Smooth admitted context paths give smooth target coordinates through E3/E4; the event construction does not change at Gaussian availability boundaries.

If `eta` is absolutely continuous, finite differentiation of E2's KL identity gives

$$
\frac{d}{ds}\operatorname{KL}(q_\theta\Vert q_\eta)
=-\lambda(\theta-\eta)^T G_\theta(\theta-\eta)
+(m_\eta-m_\theta)\cdot\dot\eta
$$

almost everywhere. The first term vanishes at an instant precisely when the rate is zero or `theta=eta`; the forcing term has no fixed sign. A negative ELBO adds `-d log Z_event/ds`. No physical-time identification is used.

## E6: Endpoint-frozen forcing estimate

**Disposition: derivation reconstructed.** Let the maximum mesh interval width be `delta`. Set `eta^delta(s)=eta(t_i)` on `(t_{i-1},t_i]` and use exact interval rates `Delta Lambda_i=integral_{t_{i-1}}^{t_i}lambda`. E1's affine step is exactly E5's solution for this piecewise-constant target at the mesh points. If `eta` is uniformly continuous with modulus `omega_eta(delta)` in the chosen parameter norm, subtract the two solution formulas to get

$$
\|\theta^\delta(T)-\theta(T)\|
\leq\omega_\eta(\delta)
\int_0^T e^{-(\Lambda(T)-\Lambda(r))}\lambda(r)dr
=(1-e^{-\Lambda(T)})\omega_\eta(\delta).
$$

The same derivation holds at each mesh point. An `L`-Lipschitz target yields at most `(1-e^{-Lambda(T)})L delta <= L delta`. Constant targets and zero rates give exact zero discrepancy. Equality in the integral triangle bound requires a common supporting direction and saturation of the modulus wherever the weight is positive; the bound need not be sharp for a given path. Endpoint samples of a merely measurable target are not covered. Approximate interval rates need a separate error term. The inspected runner uses a constant configured rate and `rate*(s_i-s_{i-1})` at `moving_context.py:108`, so its rate increments match this premise.

## E7: Parameter error controls event TV

**Disposition: derivation reconstructed.** At any cell, at most four node and three edge statistics are one. Hence `||T(x)||_2<=sqrt(7)` and `||m_theta||_2<=sqrt(7)`. By E2, for parameter velocity `v`,

$$
\sum_x|dq_\theta[v](x)|
\leq\sum_x q_\theta(x)\|v\|_2\|T(x)-m_\theta\|_2
\leq 2\sqrt7\|v\|_2.
$$

Integrating along the straight parameter segment gives `||q_theta-q_phi||_1<=2sqrt(7)||theta-phi||_2` and `TV(q_theta,q_phi)<=sqrt(7)||theta-phi||_2`. This is a conservative valid constant, with no sharpness claim. E6 therefore implies event-law convergence, and a common stochastic readout contracts this bound by M6 below. This is exact-real convergence, not a roundoff certificate.

## E8: Event KL and ELBO bookkeeping

**Disposition: derivation reconstructed.** Every positive chain law has marginal factorization `q=q_01 q_12 q_23/(q_1 q_2)`, obtained by writing its root/conditional factorization and canceling the intermediate marginals. Subtracting log factorizations for two positive chain laws and averaging under `q` gives

$$
\operatorname{KL}(q\Vert p)
=\sum_{ij\in E}\operatorname{KL}(q_{ij}\Vert p_{ij})
-\sum_{i=1,2}\operatorname{KL}(q_i\Vert p_i).
$$

For the declared observation, `p_post=p_prior L/Z_event`. Direct substitution into KL gives `E_q log L-KL(q||p_prior)=log Z_event-KL(q||p_post)`. Thus evidence, likelihood, and entropy contributions remain present. The event tree identity does not justify tree accounting for an unrestricted Gaussian or a general visible hidden-chain marginal.

## E9: Channel motion and conditional observables

**Disposition: derivation reconstructed.** In row-vector notation, a differentiable common channel gives `y(s)=q(s)C(s)`, hence componentwise finite differentiation gives `dot y=dot q C+q dot C`. A conditional `beta=eta/alpha` admits the ordinary quotient derivative where `alpha>0`; uniform derivative/error control needs an interval lower bound `alpha>=alpha_min>0`. At zero occupancy this conditional is undefined. Pointwise readout TV contraction alone supplies neither conditional-attention control near zero occupancy nor rate-error bounds.

## M1: Fixed-conditional Fisher embedding

**Disposition: derivation reconstructed.** Let `g:X -> B` be a surjection of nonempty finite sets, `rho_x>0`, and `sum_{g(x)=b}rho_x=1`. For positive normalized `r`, set `Q_r(x)=r_{g(x)}rho_x`. Its bin marginal is exactly `r_b`, proving normalization and injectivity. For zero-sum bin tangents `u,v`, `dQ_r[u](x)=u_{g(x)}rho_x`, and therefore

$$
\sum_x\frac{dQ_r[u](x)dQ_r[v](x)}{Q_r(x)}
=\sum_b\frac{u_bv_b}{r_b}.
$$

This is exactly the bin-simplex Fisher metric, positive definite on its tangent space. The one-bin case has zero-dimensional tangent space and is valid vacuously.

## M2: Restricted objective, optimum, and equality cases

**Disposition: derivation reconstructed.** For positive normalized target `p`, define

$$
\ell_b=\sum_{g(x)=b}\rho_x\log(p_x/\rho_x),\qquad
Z=\sum_b e^{\ell_b},\qquad\pi_b=e^{\ell_b}/Z.
$$

Finite expansion gives

$$
\operatorname{KL}(Q_r\Vert p)
=\sum_b r_b(\log r_b-\ell_b)
=\operatorname{KL}(r\Vert\pi)-\log Z.
$$

For `p_B(b)=sum_{g(x)=b}p_x`, let `d_b=KL(rho_b||p(.|b))`. Then `ell_b=log p_B(b)-d_b` and `Z=sum_b p_B(b)exp(-d_b)<=1`. The finite Gibbs inequality follows directly from `log z<=z-1` with `z=p(x|b)/rho_x`; equality requires equality at every positive cell. Since every bin has positive target mass, `Z=1` exactly when all target conditionals equal `rho_b`. The same Gibbs inequality makes `r=pi` the unique optimum. The within-bin penalty is essential; target bin masses alone generally give the wrong minimizer.

## M3: Exact restricted flow and dissipation

**Disposition: derivation reconstructed.** Differentiating M2 in a zero-sum tangent gives `sum_b u_b log(r_b/pi_b)`. The Fisher gradient determined by M1 is

$$
(\operatorname{grad}^{F}F)_b
=r_b\left[\log(r_b/\pi_b)-\sum_c r_c\log(r_c/\pi_c)\right].
$$

Its negative flow gives `d/dt log(r_b/r_c)=-log(r_b/r_c)+log(pi_b/pi_c)`. Solving all these scalar linear equations and normalizing yields

$$
r_b(t)=\frac{r_b(0)^a\pi_b^{1-a}}{\sum_c r_c(0)^a\pi_c^{1-a}},\qquad a=e^{-t}.
$$

This proves positivity, normalization, existence, uniqueness, and the fixed-target semigroup property for every finite nonnegative time. Differentiating the objective along this curve gives minus the `r`-weighted variance of `log(r/pi)`. Because every `r_b>0`, the variance is zero exactly at `r=pi`. Positive elapsed time gives strict decrease unless initially optimal; zero elapsed time is the identity. Singleton bins give E1's complete-simplex formula. No claim about changing-target monotonicity follows.

## M4: Driven log-ratio recurrence

**Disposition: derivation reconstructed.** Keep `g,rho` fixed over the whole history and initialize `q_0=Q_{r_0}`. Both laws use target `p_i` and finite nonnegative elapsed time `h_i`; let `a_i=exp(-h_i)`. E1's full step gives

`log q_i = a_i log q_{i-1}+(1-a_i)log p_i+scalar_i`.

M3, with `log pi_i=ell_i-log Z_i`, gives

`log Q_{r_i}(x)=a_i log Q_{r_{i-1}}(x)+(1-a_i)(log rho_x+ell_{i,g(x)})+another_scalar_i`.

Subtracting proves

$$
e_i(x)=a_i e_{i-1}(x)+(1-a_i)\delta_i(x)+k_i,
$$

where `e_i=log(q_i/Q_{r_i})`, `delta_i=log(p_i/rho)-ell_{i,g}`, and `k_i` is independent of `x`. Oscillation ignores constants and is subadditive for these nonnegative coefficients. Hence, with `D_i=osc(delta_i)`,

$$
\operatorname{osc}(e_i)\leq H_i,\qquad
H_0=0,\qquad H_i=a_iH_{i-1}+(1-a_i)D_i.
$$

Equivalently, `H_n=sum_{i=1}^n (1-a_i)D_i product_{j=i+1}^n a_j`. This uses the carried full/restricted histories; neither is reset after a step.

If all target conditionals equal `rho`, then every `D_i=0` and the two laws agree. Conversely, if the laws agree immediately before and after a strictly positive-duration step, the displayed recurrence makes `delta_i` constant. Its `rho` average is zero in every bin, so this constant is zero; thus the target conditionals equal `rho`. Cancellation between successive spatial extrema can make the oscillation bound strict. Common maximizing and minimizing cells for all nonzero weighted terms make the subadditivity stage an equality. Changing or refitting `g` or `rho` invalidates this recurrence.

## M5: Sharp oscillation to total-variation inequality

**Disposition: derivation reconstructed.** For positive normalized `u,v`, put `L=u/v`, `m=min L`, `M=max L`, and `D=log(M/m)`. If `D=0`, normalization gives `u=v`. Otherwise `m<1<M` and `E_v L=1`. Convexity puts `|L-1|` below its endpoint chord, yielding

$$
\operatorname{TV}(u,v)=\tfrac12 E_v|L-1|
\leq\frac{(M-1)(1-m)}{M-m}.
$$

Let `R=M/m=e^D`. Substitution gives the right side as `(R+1-Rm-1/m)/(R-1)`. The elementary square inequality yields `Rm+1/m>=2sqrt R`, with equality at `m=1/sqrt R`. Consequently

$$
\operatorname{TV}(u,v)\leq\frac{\sqrt R-1}{\sqrt R+1}=\tanh(D/4).
$$

The bound is sharp: for `s>1`, take `v=(s/(s+1),1/(s+1))` and `u=(1/(s+1),s/(s+1))`. Then `L=(1/s,s)` and equality holds. For `D>0`, equality in the proof requires `L` to take only its two endpoint values, those endpoints to be reciprocal, and their aggregate `v` masses to satisfy `E_v L=1`. Intermediate ratios cause strict chord inequality. M4 therefore gives `TV(q_i,Q_{r_i})<=tanh(H_i/4)`.

## M6: Common stochastic readout contraction

**Disposition: derivation reconstructed.** If `C_i(x,y)>=0` and `sum_y C_i(x,y)=1`, then

$$
\tfrac12\sum_y\left|\sum_x(q_i(x)-Q_{r_i}(x))C_i(x,y)\right|
\leq\tfrac12\sum_x|q_i(x)-Q_{r_i}(x)|.
$$

The triangle inequality and row sums prove the contraction directly. Each step may use a different common channel and any structural zeros. Equality holds exactly when no output column receives both nonzero positive and negative contributions from the input difference. Comparing different channels on the two laws needs an additional channel-discrepancy term. This contraction is pointwise; E9's derivative and occupancy qualifications remain necessary.

## M7: Explicit conditional continuous-forcing extension

**Disposition: derivation reconstructed as an additional conditional result.** The finite bound alone does not establish a continuum limit. Let `lambda>=0` be integrable on `[0,T]`; let every `p_x(t)>0` be measurable and normalized almost everywhere; and assume `lambda(t)log p_x(t)` integrable for every cell. Keep fixed positive `rho`, fixed `g`, and equal initial laws. Finite linear combinations and maxima then make weighted `ell_b`, `delta_x`, and `D=osc(delta)` integrable.

Full log odds against a fixed reference cell solve `z'=lambda(log(p_x/p_ref)-z)`; restricted log odds against a fixed reference bin solve `w'=lambda(ell_b-ell_ref-w)`. Their integrating-factor solutions give finite absolutely continuous odds, hence positive absolutely continuous normalized laws. Subtracting the reconstructed cell logs and canceling their normalization scalars gives, for every pair `x,y`,

$$
e_x(t)-e_y(t)=\int_0^t e^{-(\Lambda(t)-\Lambda(s))}\lambda(s)
[\delta_x(s)-\delta_y(s)]ds.
$$

Taking maxima over the finite cell pairs yields

$$
\operatorname{osc}(e(t))\leq H(t):=
\int_0^t e^{-(\Lambda(t)-\Lambda(s))}\lambda(s)D(s)ds.
$$

Thus `TV(q(t),Q_{r(t)})<=tanh(H(t)/4)`, and M6 applies pointwise to a common measurable stochastic readout. Piecewise constant targets reduce this formula exactly to M4. A derivative of a merely measurable readout is not asserted. Endpoint approximation to arbitrary measurable forcing needs a separate convergence hypothesis. This extension is newly supplied mathematical evidence; no execution or numerical-certificate claim accompanies it.

## Boundary attacks and exact falsifiers

The following refuted counterclaims are stronger than the supplied proposals; they are not findings that either original proof makes those assertions.

**B1, refuted: the restricted optimum is always the target bin marginal.** Let two bins have two cells each with conditional `rho=(1/2,1/2)`. For `p=(9/20,1/20,1/4,1/4)`, both bin masses are `1/2`, but `exp ell=(3/10,1/2)`, `Z=4/5`, and `pi=(3/8,5/8)`. This exact example proves the conditional penalty in M2 is necessary.

**B2, refuted: the 39-coordinate chain is closed under every positive observation.** Start from the uniform law and use a likelihood proportional to `exp(J 1[x_0=1,x_2=1])`, with nonzero `J`. Scaling by a positive constant smaller than `exp(-max(0,J))` makes this a valid Bernoulli success probability. After any strictly positive finite full-flow time, the omitted nonadjacent-pair contrast is `(1-a)J`, so E3's full residual rejects it. Adding edge `(0,2)` supplies nine independent pair contrasts and yields a 48-dimensional fixed pairwise family, but a chain-only decoder no longer applies. A positive likelihood proportional to `exp(J 1[x_0=x_1=x_2=1])` has zero singleton and pair anchored contrasts but a nonzero triple contrast; no pairwise-only family can represent it. These examples are direct falsifiers if E4's source observation is later changed.

**B3, refuted: the positive-stratum flow extends unchanged to zero target masses.** For `q_0=(1/2,1/2)` and `p=(1,0)`, the geometric expression has zero second mass at every positive elapsed time, while the initial second mass is `1/2`. It cannot be a continuous positive-stratum solution at time zero. The positive-law hypotheses are essential.

**B4, refuted: a moving target guarantees nonincreasing KL.** In the binary family with statistic `1[x=1]`, use `lambda=1`, `theta_0=eta(0)=0`, and `eta(s)=s`. E5 gives `theta(s)=s-1+e^{-s}`. The initial KL is zero; for every `s>0` the laws differ and KL is positive. A nonincreasing-KL assertion is impossible. The moving-target term in E5 supplies the missing contribution.

**B5, refuted: visible velocity is always `dot q C`.** Let `q=(1/2,1/2)` be fixed and both rows of `C(s)` equal `(s,1-s)` on `0<s<1`. Then `y(s)=(s,1-s)` has derivative `(1,-1)`, while `dot q C=0`. The term `q dot C` is required.

**B6, refuted: small joint TV uniformly controls conditional attention at small occupancy.** With outcomes null, `(receiver,a)`, `(receiver,b)`, let `0<epsilon<1`, `0<d<1/2`, `u=(1-epsilon,epsilon(1-d),epsilon d)`, and `v=(1-epsilon,epsilon d,epsilon(1-d))`. Both laws are positive. Joint TV is `epsilon(1-2d)` but receiver-conditional TV is `1-2d`, which remains nonzero as `epsilon` tends to zero. At zero occupancy the conditional is undefined.

A genuine falsifier of the reconstructed original finite assertions would have to retain their finite positive normalized domains, fixed representations, common readouts, and stated rate assumptions while violating the displayed algebra. The source-specific falsifier is an admitted initial or target latent law with a nonzero omitted anchored interaction. Re-fitting `g/rho`, moving `h/T` without transport terms, comparing different channels, admitting zeros, or approximating integrated rates violates a premise and cannot be presented as a counterexample to the proved theorem.

## Input binding and proof dependence

The inspected checkout reported HEAD `409c61155ac16b21342bfe15c834fda7bb33fb67`. These SHA-256 values identify the read bytes as diagnostic provenance; hash equality is not mathematical evidence.

| Artifact | SHA-256 |
| --- | --- |
| `problem-contract.json` | `50db7529fc2c5cb7c032cd4e3b6517516a93800ba32db8c2c50c226ddb2a369e` |
| `agents/event-closure.md` | `ad68dc1f2f17fcfb58a627939d84cfce8e15824ed92bdd577c2a9a349cb5ee35` |
| `agents/reduced-event.md` | `b6c1677a335b0f4071a917717d67b4a0972bf37b90dbedb5b5990552d9f42dcd` |
| `local_tree.py` | `6d9fcf0098be7ab44bb577eee6eee8909d30b0d35d0ce15b0f22521de93a5d2d` |
| `junction_tree.py` | `8c079e8edde61e6ce8e414b0fa6fade837078d189e7f592de47e9cefef61a469` |
| `inference.py` | `ade492121f2c261c06033955711199d4052602315acec8dac7be716692fc2251` |
| `moving_context.py` | `4cab30c50c5e4e75a345f43ac63b991a7b62e287e1174300fb8145ec7dd9a9fa` |
| `categorical_inference.py` | `9cb467e29faf26774dd2cac914436af3fdc4a7ad977a5b622e271a2fd1d5d776` |
| `nonflat.py` | `627e2cc1694f264bf4584c3c88fdcb73b2793b8f41d25013d094c3c31fb35a24` |

E1 uses the directly derived full-simplex odds equation. E2 uses only finite differentiation. E3 uses finite anchored evaluations and positive message normalization. E4 depends on E3 and the explicitly traced source construction, and finite-history closure additionally uses E1. E5 depends on E1/E2 and the stated forcing hypotheses. E6 uses E5 plus uniform continuity and exact interval rates. E7 uses E2/E3. E8 uses E3 plus the declared positive Bayes law. E9 is finite product/quotient differentiation. M1 is direct embedding algebra; M2 uses M1 and the elementary log inequality; M3 uses M1/M2; M4 uses M3 and E1's complete-simplex flow; M5 is the independent likelihood-ratio chord derivation; M6 uses M4/M5 and stochasticity. M7 uses the stated additional integrability, the independently solved full/restricted odds equations, and M5/M6.

These dependencies are acyclic and use no assumed target conclusion. Removing any expectation of an affirmative answer changes no equation, support assumption, or inference in this report. That is an event-scope erasure check, not an erasure check for the entire root target. The Gaussian claims and boundary schedule appended to `event-closure.md` were not reconstructed here, and no event result is being reused to close them.

## Frozen reconstruction handoff

E1 through E9 and M1 through M6 are **derivation reconstructed** under their stated hypotheses. M7 is a newly reconstructed conditional continuous-forcing result. No original finite mathematical claim inspected here requires repair. B1 through B6 are **refuted** stronger counterclaims by explicit finite examples. O1, O2, and O3 remain **open** with the exact obligations already recorded.

Revision 1 is frozen for root adjudication. This supplies mathematical support for the scoped 39-coordinate implementation, not an implementation verification result, an automatic ledger closure, or general program completion. Only `agents/event-verification.md` was written by this lane.

