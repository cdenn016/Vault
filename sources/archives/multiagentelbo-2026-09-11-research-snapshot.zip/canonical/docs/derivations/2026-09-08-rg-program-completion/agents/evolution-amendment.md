<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Corrections to the regular-evolution bounds

Root amendment to the frozen evolution.md revision 3, prompted by evolution-verification.md revision 1. The original input remains unchanged so its reconstruction provenance is not erased. This amendment changes two hypotheses/constants and must be read with that input before any theorem closure or implementation relies on E2/E6.

For E2 let the continuous target precisions in the parallel frame obey J_p(s)>=j_target I and let the initial precision be J_0>=j_initial I, both positive. Define j_common=min(j_target,j_initial). The exact integral solution is a convex combination of J_0 and target precisions, so it is bounded below by j_common I. Every discrete endpoint-target update is also a convex combination and has the same floor. Hence

    ||J^-1-Jhat^-1|| <= j_common^-2 ||J-Jhat||.

A target-only j_target cannot replace this minimum when initialization has smaller precision. The order-one/modulus coordinate convergence estimate remains as stated; moment conversion uses j_common and the separately bounded frame and natural-mean factors. This correction is an explicit uniform-condition hypothesis, not an empirical eigenvalue estimate from the sampled path.

For E6 interpret local Lipschitz continuity of the reduced velocity uniformly on every relevant compact time/state neighborhood, or assume a measurable nonnegative time-dependent Lipschitz coefficient L(s) with finite integral on that interval. The difference inequality then iterates to the exponential of the integrated coefficient; the constant-L display is its special case. Existence of a projected fine solution is already supplied by its construction. This condition supplies uniqueness among reduced solutions in the admitted neighborhood.

The weaker pointwise-in-time spatial Lipschitz interpretation is insufficient even for a continuous velocity. For t>0 set V(t,x)=2t clip(x/t^2,-1,1), and V(0,x)=0. It is jointly continuous because |V(t,x)|<=2t near t=0 and it is spatially Lipschitz at each fixed t with constant 2/t; at t=0 it is the zero map. Every curve x_c(t)=c t^2 with |c|<=1 is a continuously differentiable solution with x_c(0)=0. Thus pointwise Lipschitz regularity alone does not give uniqueness. The nonintegrable coefficient explains precisely why the strengthened hypothesis excludes this example.

No correction supplies an event-resolved one-sided schedule, an across-boundary comparison topology, or a continuum convergence claim for the current endpoint-classifying runner. Those remain distinct implementation and analysis obligations. The Gaussian jump/factorization and moving derivative identities are unaffected by these two corrections.
