<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Event-resolved hybrid interface for the actual strip fixture

Revision 1 is a mathematical construction and source-level implementation handoff, submitted for independent reconstruction. Only this Markdown was edited. No code, test, scientific experiment, GPU job, artifact mutation, publication, or vault write was performed. The existing endpoint-classification runner remains an ordered discrete policy. This submission supplies its missing one-sided model and comparison interfaces, with an explicit floating-point limitation.

The one-sided fine Gaussian laws, their prior birth conditionals, and the correctly typed one-sided coarse maps are finite and nondegenerate in this fixture. Availability does not multiply the fine Gaussian covariance. A newly occupied parent has a finite singleton-map limit even when its total weight tends to zero; that limit differs from the exact-boundary zero row because the parent's domain ends there. Conditional attention has finite one-sided limits here but remains undefined at the zero-occupancy boundary. A separate obstruction survives: at two kinds of correlated parent birth, the old depth-one parent law does not determine the new parent law. Retaining the fine Gaussian, or an equivalent full conditional representation, supports an exact hybrid controller.

## Scope, types, and inherited evidence

The common assumption set H is a finite continuous piecewise-linear path `c:[0,T]->U`, `U=(-1.5,1.5)^2`, with finitely many strictly ordered waypoint parameters, finite nonnegative coupling, finite frame scale and channel curvatures, fixed passive chart in `{0,1,2}`, finite constant inference rate `r>=0`, and an initially SPD Gaussian on the initial active carrier plus a positive law on the fixed four-record categorical carrier `{0,1,2,3}^4`. Finite parameters may vary between runs; constants below are for the resulting fixed compact path and finite event schedule. Measures are Lebesgue on each active Gaussian space and counting measure on the fixed categorical carrier. No covariance on padded absent coordinates is declared SPD.

Use `evolution.md` E1–E3 with the corrections reconstructed in `evolution-verification.md`: precision estimates require a common lower bound for initial, exact, and approximate precisions; uniqueness requires a uniform or integrable spatial Lipschitz coefficient. The affine natural-coordinate solution and jump formulas are inherited derivations, not empirical evidence. The new statements below map their hypotheses to this fixture and address the schedule/interface portion of EV14. No stronger physical-clock, arbitrary-cover, or infinite-event theorem is asserted.

All source paths below are under `src/multiagent_elbo/experiments/neighborhood/`. `cover.py:28–45` declares the four open strips and availability; `local_tree.py:23–106` constructs local Gaussian inputs and active-chain assembly; `local_tree.py:134–156,251–303` constructs the positive categorical target, weighted observation, and posterior. `inference.py:37–69` selects the actual supported model. `connections.py:45–107` supplies smooth prescribed connections and exact segment transport. `gaussian_boundary.py:29–105` supplies the survivor/prior-conditional update. `moving_context.py:108–130` classifies arriving endpoints, reconciles there, then allocates the previous cell's inference increment at arrival. These are different roles.

## H1: Exact finite event schedule

**Family:** H1-strip-path-event-resolution. **Kind:** CONSTRUCTION and LEMMA. **Quantifier:** every path satisfying H. **Target:** all crossings, contacts, boundary intervals, and one-sided carriers, without probing nearby floating points.

The only strip boundaries inside U are `B={-0.8,-0.1,0.1,0.8}`. On a segment with endpoints `(x_j,y_j)` and `(x_{j+1},y_{j+1})`, each boundary b with `x_{j+1}!=x_j` has the unique possible crossing fraction

\[
\lambda_{j,b}=\frac{b-x_j}{x_{j+1}-x_j},\qquad
s_{j,b}=s_j+\lambda_{j,b}(s_{j+1}-s_j).
\]

Include it exactly when `0<=lambda<=1`, identify duplicate occurrences at shared vertices, and retain the boundary label. If both x endpoints equal b, retain the entire segment as a boundary interval and merge consecutive such intervals. If x is constant away from B, that segment has no event. Sort isolated roots and boundary-interval endpoints together with original vertices. This is finite, with at most four candidate roots per nonconstant segment. A continuous path cannot reach two different strip boundaries at the same parameter. Duplicate detections of the same boundary are one geometric event.

For an event e, define `I^-`, `I^0`, and `I^+` by the strict strip inequalities on the left germ, at `c(e)`, and on the right germ. The germ sign comes from the incident affine segment and direction, not a sampled `e±epsilon`. Along a boundary interval use `I^0` throughout. At the initial/final endpoint retain only the existing germ and declared endpoint state. The five open-stratum fine carriers are:

| x interval | Active fine agents |
|---|---|
| `(-1.5,-0.8)` | `(0,1)` |
| `(-0.8,-0.1)` | `(0,1,2)` |
| `(-0.1,0.1)` | `(1,2)` |
| `(0.1,0.8)` | `(1,2,3)` |
| `(0.8,1.5)` | `(2,3)` |

Exact carriers are `(0,1)` at `-0.8`, `(1,2)` at `-0.1` and `0.1`, and `(2,3)` at `0.8`. Parent carriers are the nonempty intersections with blocks `{0,1}` and `{2,3}`; the final parent always exists. At an isolated event at most one fine agent changes, and at least two fine agents survive.

The ordered zero-clock event policy is `I^- -> I^0 -> I^+`, omitting identity transitions. This determines departures before entries. It includes a contact from the active side: `I^-=I^+` can be larger than `I^0`, so departure and reentry both occur. A contact from the inactive side has no transition. A boundary interval receives its exact-boundary carrier, evolves on it for the interval's actual parameter length, then undergoes its outgoing transition. This retains the intended contact semantics of the existing explicit-boundary waypoint policy.

The frozen default forward/return path has eight events: `(s,x,operation)=(.15,-.8,birth 2),(.4,-.1,departure 0),(.6,.1,birth 3),(.85,.8,departure 1),(1.15,.8,birth 1),(1.4,.1,departure 3),(1.6,-.1,birth 0),(1.85,-.8,departure 2)`. It has no contact or boundary interval. This table follows from its declared waypoints and parameters; no experiment was executed.

**Failure:** discontinuous paths, infinitely many events, or unspecified contact semantics. **Open gap:** scheduler implementation and exact parameter serialization. **Novelty fingerprint:** finite affine roots plus germ masks and exact-contact phase ordering for the current open strips. **Disposition:** submit H1 for reconstruction.

## H2: Fine Gaussian and posterior boundary limits

**Family:** H2-chain-innovation-boundary-extension. **Kind:** LEMMA. **Quantifier:** every one-sided stratum closure along H, and each prior, declared initial recognition, reference, and posterior law. **Target:** finite positive one-sided data for E1/E3.

Write the unframed node factors as `L_i(c)`, means as `m_i(c)`, and prior correlation as

\[
\rho(c)=0.30\tanh(\mathrm{coupling})(1+0.08\sin x).
\]

The factors are lower triangular with diagonal at least 0.9; other entries and means are smooth and bounded on compact subsets of U. Recognition has factor multiplier 1.04 and correlation prefactor 0.22; reference has identity factors and zero correlation. In every case `0<=rho<0.324<1`. On a fixed connected active chain define

\[
Z_{i+1}=m_{i+1}+\rho L_{i+1}L_i^{-1}(Z_i-m_i)
+\sqrt{1-\rho^2}L_{i+1}\epsilon_{i+1},
\]

starting with `Z_a=m_a+L_a epsilon_a`, with independent standard Gaussian innovations. This has the exact node and adjacent-pair covariances assembled by the source. Its invertible triangular innovation map proves SPD. At the boundary the same map remains invertible; factors, inverses, correlations, means and finite products are smooth there. Each fixed active-chain covariance therefore has a smooth positive endpoint extension, with finite upper and positive lower eigenvalue bounds on its compact closure. Deleting an endpoint gives the shorter chain law, so adjacent active chains have compatible survivor marginals.

The changing agent's availability tends to zero to every derivative order. With `t=1-((x-a)/r_i)^2`, its weight is `exp(1-1/t)` inside the strip. Every derivative is this exponential times finite inverse powers of t and smooth bounded factors. The exponential-series term of degree m+1 proves `exp(-1/t)t^-m -> 0`. Its zero extension is smooth. Availability multiplies observation columns (`local_tree.py:283`), not the active Gaussian factors or covariance.

Observation noise is `R=.6 I_2`. On a fixed active carrier,

\[
J_p=J_\pi+H^TR^{-1}H,\qquad h_p=J_\pi m_\pi+H^TR^{-1}o.
\]

Thus J_p and its inverse remain smooth and SPD at the side endpoint. Gaussian evidence uses covariance `R+H Sigma_pi H^T`, bounded away from singularity by R. These are the existing pointwise Gaussian densities, so an observation-slice conditional version is specified.

At a crossing the changing agent's observation columns are exactly zero in the side limit. With endpoint agent N and survivor chain S, prior factorization and `H_N=0` give

\[
p_{S,N}(z_S,z_N\mid o)=p_S(z_S\mid o)\pi(z_N\mid z_S).
\]

Integrating the normalized prior conditional proves that the side evidence equals the exact-boundary model's evidence. Event evidence is independent of the Gaussian carrier, so total evidence has the same limit. The limiting posterior birth conditional is therefore the actual prior conditional, not an unrelated model choice.

**Failure:** covariance scaled to zero by availability, correlation reaching magnitude one, or incompatible shorter-chain factors. None occurs here. **Open gap:** a side-model constructor must use the germ's active mask at `c(e)`; ordinary `inference.build_context(c(e))` returns only `I^0`. **Novelty fingerprint:** chain marginal consistency and zero observation columns identify the actual posterior boundary conditional. **Disposition:** submit H2 without covariance epsilons.

## H3: Coarse maps have finite side limits, with a typed jump at parent birth

**Family:** H3-singleton-parent-limit. **Kind:** LEMMA and domain distinction. **Quantifier:** all three Gaussian scales on side closures in H. **Target:** full-row-rank limiting maps and positive parent laws.

In reference coordinates each depth-one parent row is

\[
W_{Bi}=\frac{1_{i\in B}w_i}{\sum_{j\in B}w_j}.
\]

If the denominator remains positive, W and its derivative extend smoothly, with each vanishing child coefficient and all its derivatives tending to zero. If the parent itself is born at `x=-.8`, its block `{2,3}` has only child 2 present on the adjacent active side. Throughout a one-sided neighborhood its normalized row is exactly the selector `(1,0)`, with derivative exactly zero. The corresponding death uses the same limit. At `x=.8` the disappearing/appearing block `{0,1}` analogously has row `(0,1)` on its occupied side. No `w'/w` singularity remains after this exact singleton cancellation.

The exact-boundary parent is absent in these cases, so the implementation's zero row there is correct for the boundary carrier. It is not the side limit on the larger carrier. The side constructor must return the selector for the occupied-side carrier and a separate absent row/mask for the exact carrier. Copying `_coarse_weights(c(e))` and labeling its absent parent active would create a spurious singular Gaussian.

Each active normalized row sums to one, has at most two entries, and is disjointly supported from other parent rows. Therefore `W W^T >= (1/2) I` on the active row carrier, including singleton limits. Orthogonal frames preserve singular values. The depth-two row again has at most two entries; the direct fine-to-final row has at most four, so its squared row norm is at least 1/4. Every active map has a finite positive row-rank margin. If fine covariance exceeds `sigma_* I`, the direct final covariance exceeds `(sigma_*/4) I`, with analogous bounds at the other stages. This applies to prior, posterior and evolving positive recognition laws. A Gaussian conditional obtained by an invertible endpoint split is finite and SPD in its actual hidden carrier; no dimension-preserving SPD continuation through a disappearing parent is claimed.

`connections.connection_geometry` is smooth for each fixed label set, including half-integer parent labels, and retains both independent finite channel curvatures. Its restrictions have finite side limits. Map derivatives are finite by the normalized-row calculation and smooth frame derivatives. The existing `dF+A_parent F-F A_child` defects therefore have finite limits, which need not vanish. The exact product `F12 F01=F02` extends on each side by limits of finite matrix products with that side's dimensions.

**Failure:** a different cover with direction-dependent ratios of vanishing weights, unbounded ratio derivatives, or lost row rank. The singleton argument excludes these only for this fixture. **Open gap:** implement analytic side selectors without numerical 0/0. **Novelty fingerprint:** a parent-domain change is distinguished from a singular probability law by an exact normalized singleton limit. **Disposition:** submit H3 and preserve exact-boundary masks.

## H4: Event masses and one-sided conditional attention

**Family:** H4-availability-cancellation-at-zero-occupancy. **Kind:** LEMMA. **Quantifier:** positive fixed-carrier categorical trajectories from E1 or the exact chain family on H. **Target:** valid event readout at every phase without redefining an undefined conditional.

The categorical prior, target, and initial law in `local_tree.py:109–156` are smooth and positive on the fixed 256-outcome carrier. E1's finite simplex solution has bounded log odds on the compact interval and hence a positive latent probability margin. Gaussian carrier changes do not reset this state or alter its labels. Availability channels and two-record pushforwards are finite polynomials in the smooth windows, so visible event masses have compatible finite limits. The latent categorical state is continuous across Gaussian jumps.

For either record, let `P_ij` be its latent endpoint-pair marginal, `m_i=sum_j P_ij>0`, and `a_i=w_i`. Its emitted receiver row is

\[
\eta_{ij}=a_i a_jP_{ij},\qquad
\eta_{i\varnothing}=a_i\sum_j(1-a_j)P_{ij},\qquad
\alpha_i=a_i m_i.
\]

On `a_i>0`, exact common-factor cancellation gives

\[
\beta_{ij}=a_jP_{ij}/m_i,\qquad
\beta_{i\varnothing}=\sum_j(1-a_j)P_{ij}/m_i.
\]

These have finite smooth one-sided limits even at receiver birth/departure. At `a_i=0`, occupancy is zero and conditional attention remains undefined. Its limit is additional germ data, not a definition on the empty event. Retain the current NaN and `beta_defined` convention.

A coarse receiver row sums fine receiver rows. If another child remains occupied its denominator stays positive. If the entire depth-one block is born/departs, only one child is present on the occupied-side neighborhood and the same cancellation applies. At least one of the four latent endpoint labels is absent at every context of this cover; its positive receiver marginal supplies positive null occupancy. Null rows therefore do not develop a zero denominator. This proves finite side beta limits for the actual parents, not arbitrary simultaneous-birth covers.

**Failure:** loss of latent positivity or simultaneous births with no unique weight ratio. **Open gap:** optional side-limit beta must be separate from exact-phase beta, never marking zero occupancy defined. **Novelty fingerprint:** exact cancellation resolves the apparent conditional singularity while retaining its measure-theoretic domain. **Disposition:** submit H4; use masses, not undefined beta, in the main convergence norm.

## H5: Actual Gaussian boundary kernel and target compatibility

**Family:** H5-endpoint-prior-conditional-hybrid. **Kind:** CONSTRUCTION and LEMMA. **Quantifier:** every H1 event and every SPD incoming Gaussian. **Target:** normalized, stable transitions matching the prior-conditional policy.

At a zero-clock event survivors are compared at the same context. Their transport is the identity in a fixed chart; an explicit chart change uses its orthogonal comparison. Marginalize departures first. For a birth, use the larger side prior from H2. Its unframed endpoint conditional is

\[
Z_N=m_N+B(Z_S-m_S)+\epsilon,\qquad
B=\rho L_NL_j^{-1}P_j,\qquad
C=\operatorname{Cov}(\epsilon)=(1-\rho^2)L_NL_N^T\succ0,
\]

where survivor neighbor j is selected by P_j. Birth 2 at `-.8` uses j=1; birth 3 at `.1` uses j=2; reverse birth 0 at `-.1` uses j=1; reverse birth 1 at `.8` uses j=2. The reverse endpoint formula follows from adjacent covariance `rho L_N L_j^T`. Actual frames conjugate B and C. The Schur complement in `gaussian_boundary.reconcile` is the same conditional and contains no availability division.

For survivor moments `(mu_S,Sigma_S)`, the new covariance is the triangular congruence of `diag(Sigma_S,C)` with lower block B. It is SPD and retains the complete survivor marginal. This normalized kernel is independent of recognition. It has affine moment form `mu^+=d+M mu^-`, `Sigma^+=Q+M Sigma^- M^T`, with difference constant `K=max(||M||,||M||^2)` in the moment norm below. Finitely many bounded jumps preserve the trajectory's positive margins.

H2 identifies the limiting posterior conditional with this prior conditional. Birth therefore adds zero conditional posterior KL. Departure removes exactly the nonnegative conditional posterior KL of the disappearing endpoint. At a contact, departure followed by reentry replaces that conditional by the prior/posterior conditional and has the same loss. Evidence has the same limit and the latent event law is unchanged. Thus total `VFE=KL(q||posterior)-log Z` cannot increase across these zero-clock transitions. Moving targets along open intervals can increase VFE; that behavior is outside this boundary monotonicity statement.

**Failure:** a nonlimiting arrival reference, a nonvanishing observation column on a removed coordinate, empty survivors, or changed event order. **Open gap:** wire the actual side prior into reconciliation at the event. **Novelty fingerprint:** endpoint conditioning and vanishing likelihood columns yield SPD admission and boundary ELBO accounting. **Disposition:** submit H5 with H1–H2 dependencies.

## H6: Convergence target and norm across dimension changes

**Family:** H6-phase-resolved-finite-hybrid-limit. **Kind:** CONSTRUCTION and conditional convergence LEMMA. **Quantifier:** each fixed H path and refinements of its exact H1 partition. **Target:** a named continuous/hybrid trajectory and a typed history comparison.

The target is E1's full Gaussian/categorical Fisher evolution on each open stratum or boundary-aligned interval, driven by the actual moving posterior and prescribed connection with `d tau=r ds`, followed by H5's zero-clock transitions at H1's phases. It is not a single ODE on one SPD manifold. Keep `(e,left)`, `(e,exact)`, and `(e,right)` as distinct ordered records when needed. A contact may have three different laws at one parameter; discarding its exact phase changes the policy.

Compare histories only on corresponding interval/phase carriers. In the common reference frame and ordered labels set

\[
d_A(q,\widehat q)=\|\mu_A-\widehat\mu_A\|_2
+\|\Sigma_A-\widehat\Sigma_A\|_F
+\tfrac12\|p_{\rm event}-\widehat p_{\rm event}\|_1.
\]

Take the maximum of interval suprema and all existing one-sided/exact phase distances. This is the primary history norm. A common orthogonal passive change preserves it. It does not subtract different-shaped SPD arrays. An optional coarse history norm is the corresponding maximum after the prescribed side maps/channels; bounded F and channel contraction bound it by a constant times the primary norm. Raw beta is excluded where its conditioning event is empty. Beta comparisons require corresponding defined domains and separate bounds or H4's canceled formulas.

Existence and uniqueness follow from E1 on each interval and H5 on the finite schedule. H2–H3 give smooth bounded one-sided target, connection and map data. E1 and H5 give common positive exact/discrete precision and covariance margins. In a parallel frame every natural coordinate obeys `xi'=r(xi_p-xi)`. Exact transport followed by a right-endpoint frozen-target step has local defect at most `r L (Delta s)^2/2`, with L the parallel-frame target's Lipschitz constant. The corrected E2 inverse-precision estimate converts this to a moment bound. At each jump multiply the incoming moment error by the finite H5 constant. Finite induction yields

\[
\|q_h-q\|_{\rm history}\leq C h_{\max},
\]

for this fixed schedule and real-arithmetic scheme. C depends on its positive margins, target derivatives, compact path, and finitely many jump constants. Piecewise exact frozen-target interpolation is included. An initial boundary point first carries its exact law and undergoes any outgoing zero-clock birth. A terminal boundary retains its incoming and exact phases with no postterminal interval.

The existing runner has no side records. Its mesh reaches exact populations at boundary waypoints but births newly present agents at the next sampled arrival, and allocates the last preboundary cell's inference using the arrival carrier. In a real-arithmetic extension these discrepancies are O(h): side models/references are Lipschitz, velocities remain bounded on the common positive neighborhood, and omitted/reordered flow lasts at most h. The finite jump estimate identifies the same phase-aligned hybrid limit after supplying missing side interpolations and aligning delayed births. A raw-time supremum on padded matrices need not converge: between a true birth and its delayed approximation the covariance jump has nonzero size. The current finite artifact and validator do not establish this asymptotic statement.

**Failure:** unaligned discontinuities, path changes without an error estimate, infinitely many events, or degenerating positive margins. **Open gap:** resolved execution and phase-comparison artifacts; existing float64 admission does not permit unrestricted h->0 execution. **Novelty fingerprint:** actual side models supply E1/E3's hypotheses and a phase-indexed norm. **Disposition:** submit H6 for independent reconstruction before making continuum claims for any runner.

## H7: Actual depth-one parent birth is not parent-autonomous

**Family:** H7-correlated-singleton-parent-birth-obstruction. **Kind:** COUNTEREXAMPLE and OBSTRUCTION. **Quantifier:** every strictly positive coupling and arbitrary SPD old preparations at `x=-.8` before birth 2. **Target:** prohibit an unsupported parent-only hybrid implementation.

Work in unframed coordinates; invertible frame comparisons cannot remove the obstruction. The old fine carrier is `(0,1)` and its sole depth-one parent is

\[
Y=aZ_0+bZ_1,\qquad a,b>0,\quad a+b=1.
\]

Both weights are positive at `x=-.8`. The postbirth parents include this old parent and the new singleton Z_2. Its new mean depends on the old preparation as `m_2+rho L_2 L_1^{-1}(E[Z_1]-m_1)`. For nonzero u, change the old mean by `v=(b u,-a u)` and keep the same SPD covariance. Both preparations have the same complete old parent Gaussian because `a b u-b a u=0`, but their new singleton-parent means differ by

\[
-a\rho L_2L_1^{-1}u\ne0.
\]

One recognition-independent parent kernel cannot send an identical old parent law to two distinct new parent laws. This is the actual E4 factorization failure. Reverse birth 1 at `x=.8` has the analogous failure through survivor neighbor 2 inside the old `(2,3)` parent. Zero coupling removes this particular conditional-mean obstruction; it does not establish autonomous later parent dynamics.

The direct final parent gives a just-born child zero weight at the event. H7 concerns the newly born depth-one parent, not every coarse level. Full fine state or its complete Gaussian conditional determines the missing survivor information. A compressed representation needs a separately proved sufficient statistic and jump square, or a jump-error bound.

**Failure of the counterexample:** preparation restrictions fixing the missing survivor mean, zero coupling, or retaining the distinguishing conditional. **Open gap:** independent reconstruction; none in the displayed two-preparation argument. **Novelty fingerprint:** the actual correlated birth reveals a survivor direction in the actual weighted parent's kernel. **Disposition:** use full Gaussian state for the first resolved hybrid controller.

## H8: Float64 admission and geometric regularity are different

**Family:** H8-representable-interior-obligation. **Kind:** OBSTRUCTION to unrestricted numerical refinement. **Quantifier:** refinements approaching an active strip endpoint in any fixed finite floating format. **Target:** prevent a real-arithmetic limit from being advertised as an executable infinite refinement.

`cover.py:40–43` rejects an active positive window that underflows to zero. At inward distance delta, `t=2 delta/r_i+O(delta^2)` and `log w=1-r_i/(2 delta)+O(1)`. Therefore w eventually falls below every fixed positive floating minimum as interior sample points approach the boundary. The current config admits refinements only 1 and 2 and does not certify a general asymptotic sequence.

Analytic side evaluation at the exact boundary removes parent 0/0 and supplies the correctly typed SPD side law. It does not prevent underflow arbitrarily close inside the strip. Preserve representability admission for interior samples, retain the actual mesh, and separate the proved real-arithmetic truncation estimate from floating residuals. No eps, clamp, nextafter probe, silent zero substitution, or default change follows from this construction. Log-domain, higher-precision or enclosure arithmetic would require a separate observable/error contract.

**Failure of this numerical obstruction:** a genuinely unbounded-range arithmetic representation, not merely an analytic endpoint value. **Open gap:** a numerical asymptotic contract beyond current float64 admission. **Novelty fingerprint:** exponential boundary decay separates geometric regularity from finite format range. **Disposition:** retain this numerical qualification without calling the normalized hybrid theorem singular.

## Minimal implementation interface, after H1–H6 reconstruction

Retain an ordered active Gaussian and a law on the fixed categorical carrier. The reconstructed exact 39-coordinate categorical chain can replace the latter through its exact decoder and moving-target update. No Gaussian compression closure is inferred. Four small functions suffice:

| Proposed function | Input and output contract |
|---|---|
| `resolve_events(waypoints,path_times)` | Ordered partition and records containing boundary label, exact crossing parameter, context, incident segments, left/exact/right fine and parent labels, and boundary-interval endpoints. Contacts come from incident germs. |
| `side_model(c,agents,side_tag,parameters)` | Evaluate H2 on a schedule-admitted carrier at the exact boundary, with actual priors/posteriors/evidence, connection, side-limited maps/derivatives, event channels, and separate phase/occupancy masks. Interior values agree with the existing model. |
| `apply_event(q,event_record,side_models,chart_comparison)` | Apply `left->exact->right` zero-clock marginal/conditional operations with the existing reconciliation kernel and correct side prior. Return all phases and boundary KL/evidence accounting. |
| `run_resolved_path(schedule,numerics)` | Exact segment transport plus exact arrival-target Fisher steps on each constant-carrier piece, then the zero-clock event operator at its exact parameter. Retain phase history, fine/coarse laws, checks, mesh, and precision scope. |

The scheduler can interpret configured scalar strings as exact decimal rationals. Python `Fraction` can construct/sort crossing parameters without an epsilon merge, retaining numerator/denominator provenance. Tensor coordinates are materialized only for model evaluation; the boundary tag supplies its declared x literal. If distinct rational parameters collapse to the same selected floating parameter, reject that numerical mesh rather than silently reorder events. This is a bounded stdlib geometry step, not a general symbolic solver.

`side_model` can reuse `local_tree.gaussian_inputs`, `assemble_active` with the proved germ mask, the observation formula and conditioning evaluator, `event_system`, and `connections.connection_geometry`. It must not append zero Gaussian coordinates to an ordinary exact-boundary model. At a zero-mass occupied-side parent, construct its singleton selector and zero derivative analytically; use ordinary normalized weights elsewhere. The phase carrier and occupancy mask are different data. An exact-boundary absent parent remains absent even when an occupied-side limit record exists.

Implementation order is the event partition and side-model constructor; their controls at a birth, departure, active-side contact and boundary interval; the zero-clock phase operator; then the piecewise runner and phase-indexed comparison. Focused controls should exercise H2's posterior/prior-conditional equality and evidence continuity; H3's singleton limits and inherited nonzero coarse defects; H4's undefined exact beta with finite side limit; H7's equal-old-parent/different-new-parent preparations; passive chart agreement; zero-rate transport; and an affine-in-parallel-natural-target oracle for the rate and error bound. These are proposed scientific controls and were not executed. Preserve the old endpoint runner/profile and identify any new profile as a resolved hybrid family.

## Cross-lane questions and disposition

For the evolution lane: H2 identifies compatible survivor targets and evidence because removed observation columns vanish; H3 gives full-row-rank side maps at singleton parent birth. H5 supplies actual E3 jump data and a boundary VFE identity. H6 proposes the phase norm and finite convergence target for EV14. Please reconstruct those fixture hypotheses separately from any floating implementation.

For root: H7 supplies the actual birth counterexample requiring full Gaussian state or its survivor conditional. The interfaces are specified, but the new submissions are not ledger closures. H8 remains a numerical limitation. No file outside this lane's owned Markdown changed.

## Source binding

These hashes bind the inspected source formulas and corrected proof dependencies, not an executed test. Module names below are relative to `src/multiagent_elbo/experiments/neighborhood/`; agent paths are relative to this completion run.

| File | SHA256 |
|---|---|
| `cover.py` | `0073e72aa3bca51a1cb27023ad223a91572c7be577bb296951ceaf4b70738e88` |
| `local_tree.py` | `6d9fcf0098be7ab44bb577eee6eee8909d30b0d35d0ce15b0f22521de93a5d2d` |
| `inference.py` | `ade492121f2c261c06033955711199d4052602315acec8dac7be716692fc2251` |
| `connections.py` | `53a497039842ad16efa1ac3b335d4a8c6c44abcb4ae4f9d237180a58e5452bb9` |
| `gaussian_boundary.py` | `ee9dfd4eba8a357c632a74887171a63417091b2d6f564859b68d4360fe39576a` |
| `moving_context.py` | `4cab30c50c5e4e75a345f43ac63b991a7b62e287e1174300fb8145ec7dd9a9fa` |
| `moving_context_config.py` | `568aa43ea6614e088c796f82a574a22d5fb3bcce90c2b8e359cd161560d8ebd8` |
| `nonflat.py` | `627e2cc1694f264bf4584c3c88fdcb73b2793b8f41d25013d094c3c31fb35a24` |
| `model.py` | `49af1bf02b9cd5030b8ee9d9fecf945d50cde0106f448efa51c2ae571562d94b` |
| `agents/evolution.md` | `6a5693a48438bb63f30e146a1ca9add96aba884e63d7e730fc86957b3e5a4d03` |
| `agents/evolution-verification.md` | `63a71eb797bb5be2b95707f6504a81d8d8cfa13c58ce0c4b59f3acd518d98bde` |
| `agents/event-closure.md` | `ad68dc1f2f17fcfb58a627939d84cfce8e15824ed92bdd577c2a9a349cb5ee35` |
