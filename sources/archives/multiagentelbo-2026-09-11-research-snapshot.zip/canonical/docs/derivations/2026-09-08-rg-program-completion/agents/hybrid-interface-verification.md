<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Cross-author reconstruction of the hybrid interface

Revision 2, September 8, 2026. This agent previously authored the separate statistical/base-curvature discovery report and finite curvature implementation. The reviewed hybrid-interface.md is another author's submission. Author and reconstructor share the project, filesystem, and model lineage; this is neither blind nor cross-model verification. Only this report was edited. No scientific execution, imports, tests, GPU work, tamper checks, ledger changes, vault writes, source changes, or changes to another author's submission occurred.

H1-H5, H7, and H8 reconstruct under the finite fixture assumptions. The resolved real-arithmetic O(h) construction in H6 also reconstructs. Its statement about the old runner requires an explicitly defined derived history: the existing records do not contain the left/exact/right phases needed to evaluate the proposed norm. Section 7 supplies such a lift and its error estimate. This preserves the strongest mathematical construction while excluding a convergence claim for the unchanged finite artifact.

The dispositions below describe reconstructed proofs. They do not assign ledger closure states, certify an implementation, or identify the path parameter with physical time. The local verification skill entry is disabled: verification/SKILL.md does not exist and only SKILL.md.disabled is present. This report follows the direct bounded reconstruction assignment and the primary-source/recomputation procedures of peer-review and literature-review; it does not reactivate that disabled workflow. The separate reconstruction brief explicitly records the shared-model and shared-filesystem limitation.

## 1. Scope, source checks, and precise disposition

Write H for the submission's assumptions: a finite continuous piecewise-affine path inside U, finitely many strictly ordered waypoint parameters, finite nonnegative coupling, finite frame and connection parameters, a fixed admitted passive chart, finite inference rate r>=0, and positive initial Gaussian and fixed-carrier categorical states. Constants below concern one fixed path and schedule. They are not uniform over growing event counts, changing paths, unbounded parameters, or covariance degeneration.

I read the formulas defining the cover, local Gaussian chain, observation, event target, supported ContextModel, nonflat connection, exact segment transport, boundary reconciliation, endpoint runner, and its admission. The inspected sources are bound at the end. The source construction, rather than comments alone, supplies the identities reconstructed here. In particular, inference.build_context selects nonflat.cover; nonflat.cover starts from local_tree.cover; that calls gaussian_inputs and assemble_active before applying the availability-weighted likelihood. The actual full Gaussian state is restricted to the active coordinate list. It is not the padded zero-atom covariance.

The directly inspected external source is Rasmussen and Williams, [Gaussian Processes for Machine Learning, Appendix A](https://gaussianprocess.org/gpml/chapters/RWA.pdf), accessed September 8, 2026. Equations A.5-A.6 give the conditional covariance and mean; A.14 gives inverse differentiation. Those support the algebraic ingredients only. The source does not assert this strip scheduler, hybrid convergence theorem, or parent-autonomy obstruction. Their arguments are reconstructed below. No jitter recommendation is adopted.

| Proposition | Reconstruction disposition | Scope retained |
| :--- | :--- | :--- |
| H1 | Complete | Exact finite roots and germ masks; prescribed departure/exact/entry ordering, including contacts and intervals. |
| H2 | Complete | Smooth positive one-sided active-chain models and matching limiting posterior birth conditional. |
| H3 | Complete | Full row rank on each actual phase carrier, including occupied-side singleton selectors. |
| H4 | Complete | Finite one-sided conditional-attention limits; undefined exact zero-occupancy rows remain undefined. |
| H5 | Complete | Normalized SPD boundary kernel and nonincreasing full VFE at the declared zero-clock event. |
| H6, resolved scheme | Complete | Fixed schedule, real arithmetic, positive margins, and the declared phase-indexed norm. |
| H6, old runner paragraph | Needs explicit comparison definition | The derived-history lift in Section 7 supplies the missing definition; it is additional data, not the raw artifact. |
| H7 | Complete counterexample | Arbitrary SPD old preparations and strictly positive coupling at the specified parent births. |
| H8 | Complete obstruction | Unrestricted refinement cannot be implemented in one fixed finite format with positive-window admission. |

## 2. H1: reconstructing events and all carrier phases

The source intervals are (-1.6,-0.1), (-1.6,0.8), (-0.8,1.6), and (0.1,1.6). Intersecting them with U leaves the four interior boundary values {-0.8,-0.1,0.1,0.8}. On any nonvertical affine segment, x(s)-b is an affine function with nonzero slope. It has at most one root, and solving it gives exactly the fraction displayed in H1. Testing its membership in [0,1] includes endpoint roots. Duplicate roots from two incident segments represent one geometric event, retaining both incident germs. A constant-x segment is either entirely on a boundary or never on one. There are finitely many segments and four labels, so this algorithm yields a finite partition, including any merged boundary intervals and the original vertices.

On each open cell of that partition, no strip inequality changes sign. The carrier is therefore constant. For a nonconstant germ incident at e, the sign of x(s)-x(e) is determined by its slope and the side of e; no epsilon evaluation is required. Two distinct boundary values cannot occur at one parameter because x(e) is single-valued. At a path endpoint only its existing germ is used.

Direct strict-inequality substitution gives open-stratum carriers (0,1), (0,1,2), (1,2), (1,2,3), and (2,3), in increasing x order. The exact carriers are (0,1) at -0.8, (1,2) at -0.1 and 0.1, and (2,3) at 0.8. Thus every elementary transition changes at most one endpoint of a connected chain and retains at least two nodes. A contact from the active side changes the carrier twice, even though its left and right germs agree. A contact from the inactive side changes it zero times. A boundary interval has the exact-boundary carrier throughout its positive duration. These are distinct policies, all explicitly resolved by I^- -> I^0 -> I^+.

The declared default waypoint file independently gives event parameters 0.15,0.4,0.6,0.85,1.15,1.4,1.6,1.85, with boundary operations birth 2, departure 0, birth 3, departure 1, birth 1, departure 3, birth 0, departure 2. That path has no contact or boundary interval. This verifies the example by reading the exact declared waypoint ordering and times; no path execution occurred.

Exact arithmetic here means exact arithmetic for the declared parameter representation. Reading decimal strings as rationals is one permissible representation for a future scheduler. It is not an automatic promise that independently rounded binary coordinates, times, and window boundaries share that representation. Distinct exact event parameters that collapse when materialized must be rejected or handled under a separately specified arithmetic contract, as the submission already requires.

## 3. H2: positive chain laws and posterior compatibility

For any fixed active chain, center and whiten each node by X_i=L_i^-1(Z_i-m_i). The proposed innovation law becomes X_a=epsilon_a and X_{i+1}=rho X_i+sqrt(1-rho^2)epsilon_{i+1}. Induction gives Cov(X_i)=I and Cov(X_i,X_{i+1})=rho I. Hence its node and neighboring pair moments are precisely those in gaussian_inputs. The full innovation map is triangular with invertible diagonal blocks L_a and sqrt(1-rho^2)L_i. Its covariance is SPD.

The joint density factors as the first node density times the successive normalized conditionals. Replacing each conditional by its pair density divided by the preceding node density gives the product of pair densities divided by internal-node densities. Expanding the Gaussian exponents yields the clique-minus-separator precision and information vector in junction_tree.assemble_gaussians. This identifies the source assembly with the innovation law, including its nonneighbor covariances, rather than only matching local blocks.

The source diagonal of L is at least 0.9; the recognition multiplier 1.04 and reference identity preserve positivity. The prior correlation obeys 0<=rho<0.30*1.08=0.324; recognition is smaller and reference is zero. All finite matrices, inverses, means, and correlations extend smoothly to the side closure. A compact closure and continuity then give finite upper and strictly positive lower covariance eigenvalue bounds. Marginalizing an endpoint of this Markov chain produces exactly the shorter assembled chain. This compatibility is available because every H1 change is an endpoint change.

The availability weight has the form exp(1-1/t) for t>0 and zero otherwise. Differentiation gives that exponential multiplied by finite sums of inverse powers of t and smooth factors. For integer k>=0, the exponential series bounds exp(-1/t)t^-k by a constant times t near zero. Every derivative therefore vanishes at the boundary. Availability and its zero extension are smooth. Inspection of local_tree.cover shows that availability scales the columns of H, while gaussian_inputs and assemble_active receive no availability covariance multiplier.

In active coordinates, multiplying the prior density by the positive likelihood N(o;Hz,R) gives precision J_pi+H^T R^-1 H and information vector J_pi m_pi+H^T R^-1 o. The source R=0.6I guarantees positive observation covariance and a smooth posterior on the side closure. At an event the changing node N has H_N=0. With survivors S, the limiting joint density factors as

\[
\pi_{S,N}(z_S,z_N)L(o|z_S)=\pi_S(z_S)L(o|z_S)\pi(z_N|z_S).
\]

Integrating the normalized conditional gives the exact-boundary evidence Z_S. Dividing by that same evidence gives p_{S,N}(z_S,z_N|o)=p_S(z_S|o)pi(z_N|z_S). This proves both survivor-posterior consistency and agreement of the limiting posterior birth conditional with the prior conditional. The event target and its evidence are built independently of the Gaussian carrier and have the same context limit. Total evidence therefore agrees across the event.

An ordinary build_context(c(e)) still constructs only I^0. A future side constructor must supply the admitted side carrier while retaining this likelihood limit. The mathematical extension does not mean that the current call already returns the larger side law.

## 4. H3-H4: coarse rank and attention domains

For any occupied depth-one block, its scalar normalized row has nonnegative entries summing to one and at most two nonzero entries. Different occupied rows have disjoint supports. Consequently the squared singular values are their row squared norms, each at least 1/2 by Cauchy-Schwarz. The coordinate lift repeats this result in the four agent coordinates. Orthogonal frame factors preserve singular values. The depth-two row has the analogous bound, while the direct fine-to-final scalar row has at most four entries and squared norm at least 1/4. Thus F Sigma F^T is bounded below by sigma_* F F^T on every actual active row carrier.

If a sibling survives, its positive limiting weight keeps the parent denominator positive; smoothness follows from quotient differentiation. At parent birth -0.8, only child 2 belongs to block {2,3} in a sufficiently small occupied-side neighborhood. Its normalized row is identically the selector for 2, even though its unnormalized weight vanishes to every derivative order. The row derivative is exactly zero. The parent near 0.8 similarly selects child 1 on its occupied side. This exact cancellation eliminates the formal ratio of two vanishing functions. It must be performed before endpoint evaluation.

At the exact event that entire parent is absent. The zero row on I^0 and the singleton row on the larger side have different row carriers; neither is a contradictory value on a common domain. Calling the zero row an active selector would be the error. Smooth prescribed frames and connections give finite one-sided map derivatives and finite dF+A_parent F-F A_child. Nothing in this argument makes that defect vanish. Matrix multiplication then extends F12 F01=F02 within each fixed side dimension.

For H4, the positive fixed-carrier categorical initial and target laws have bounded log odds on the compact interval. The affine log-odds Fisher solution preserves a positive probability margin. Taking a record's latent endpoint marginal P_ij and m_i=sum_j P_ij gives m_i>0. The normalized endpoint channel independently keeps an endpoint with probability a_i and otherwise emits null. Summing its normalized sender outcome yields alpha_i=a_i m_i. The real and null sender masses are exactly those in H4. On a_i>0, dividing by alpha_i cancels the receiver availability, giving a_j P_ij/m_i and sum_j(1-a_j)P_ij/m_i.

These expressions have finite smooth side limits on each smooth path piece, since m_i remains positive. At a_i=0 the emitted row is identically zero, so the original conditional is undefined. Its limiting value is side data. The source attention routine's NaN and defined mask retain this distinction. A coarse row sums fine rows; where another child survives its denominator has a positive limit, and at an entire-parent birth the singleton cancellation applies. At least one fine label is absent at every context of this cover. Its positive latent receiver marginal contributes to null occupancy, which therefore has a positive lower bound on the fixed path. Coarse endpoint maps preserve null. No general simultaneous-birth assertion is needed.

## 5. H5: normalized jumps and full VFE accounting

For an endpoint N with neighbor j, the whitened-chain conditional is X_N|X_j=N(rho X_j,(1-rho^2)I), in either direction. Unwhitening gives B=rho L_N L_j^-1 P_j and C=(1-rho^2)L_N L_N^T. Conditioning on the remaining survivor chain adds no variables to this endpoint conditional because of the chain factorization. This reproduces the full Schur-complement formula used by gaussian_boundary.reconcile, including reverse births.

After any departure, let the retained survivor law be Q_S. Birth draws N from the normalized prior conditional, giving Q_S pi(N|S). Its covariance is T diag(Sigma_S,C) T^T for T=[[I,0],[B,I]], with T invertible. It is SPD, retains Q_S exactly, and is recognition-independent as a Markov kernel. If Sigma_S>=aI and C>=bI, its minimum covariance eigenvalue is at least min(a,b)/||T^-1||^2. This supplies a useful explicit lower bound for the finite-jump positivity argument. Means and upper covariance bounds follow from the affine formulas.

For two preparations, the moment differences are M delta_mu and M delta_Sigma M^T. In the Euclidean-plus-Frobenius norm the bound is K=max(||M||,||M||^2). Here K>=1 because survivor selection/transport has norm one and the birth matrix contains the survivor identity block. The event-law distance is unchanged, so the same K controls the primary norm including that term. Products over finitely many jumps remain finite.

H2 gives the common limiting posterior P_SN=P_S pi(N|S). For arbitrary incoming Q_SN, direct density-ratio factorization gives

\[
\operatorname{KL}(Q_{SN}\Vert P_{SN})
=\operatorname{KL}(Q_S\Vert P_S)
+E_{Q_S}\operatorname{KL}(Q_{N|S}\Vert\pi_{N|S}).
\]

Departure removes the last nonnegative term. Birth using pi(N|S) makes that term zero. An active-side contact first removes it and then restores the matching conditional; it cannot restore the discarded KL. The Gaussian evidence has the common limit proved above, and the latent categorical law and evidence do not jump. Hence the full posterior-KL-minus-log-evidence VFE is nonincreasing at these zero-clock transitions. This argument does not assert monotonicity during external context motion or for a prior chosen at a different arrival point.

## 6. H6: the resolved scheme and its uniform phase estimate

Solve E1 on each fixed-carrier interval and compose with the H5 kernels at its finite ordered phases. Boundary-aligned intervals simply use the exact-boundary carrier. The affine natural-coordinate solutions give existence and uniqueness on each interval, and H5 provides the next positive initial law. No ODE on one fixed-dimensional SPD manifold is being asserted.

The norm compares means and covariances in corresponding ordered carriers and a common orthogonal reference frame, plus total variation of the fixed categorical law. Orthogonal frame changes preserve Euclidean and Frobenius norms, and fixed event labels do not transform. For coarse laws, mean error is bounded by ||F|| times fine mean error and covariance error by ||F||^2 times fine covariance error; normalized event channels contract total variation. F is bounded on each closed side. Thus a uniform fine estimate gives a uniform coarse estimate on the corresponding side maps. This says nothing about beta on an undefined row.

In a parallel frame each Gaussian natural coordinate and categorical log odd obeys xi'=r(xi_p-xi). The exact solution across a cell is the weighted integral of xi_p. Subtracting the endpoint-frozen solution gives

\[
R_i=\int_{s_i}^{s_{i+1}} r e^{-r(s_{i+1}-u)}
[\xi_p(u)-\xi_p(s_{i+1})]du,
\qquad \|R_i\|\leq rL(\Delta s_i)^2/2.
\]

The homogeneous multiplier exp(-r Delta s_i) is at most one. Summing the cell errors gives at most rLT h_max/2 on that interval. At r=0 this forcing defect is exactly zero. A frozen-target interpolant has the same within-cell bound.

Both exact and discrete precisions are convex combinations of their common starting precision and target precisions in the parallel frame. The required floor is the minimum of those two floors, not the target-only j_*. With J,K>=j_0 I, the identity J^-1-K^-1=J^-1(K-J)K^-1 gives inverse Lipschitz constant j_0^-2. Bounded information vectors give the corresponding mean bound. The categorical softmax derivative has l1 bound at most 2||delta_logit||_infinity, so it also converts natural error into the stated probability metric.

Across jumps, the explicit lower bound in Section 5 and uniform one-sided prior bounds give common exact/discrete covariance margins. Upper covariance and mean bounds likewise propagate. Induction over finitely many intervals therefore supplies one positive neighborhood with bounded conversions and Lipschitz velocities for all sufficiently fine admitted real-arithmetic meshes. If interval k has E_out<=L_k E_in+C_k h and jump k has E_next<=K_k E_out, finite substitution bounds the final and intermediate errors by a finite sum of the C_k times later L_j K_j factors. With the same initial law this is C h_max uniformly over all corresponding interval and phase records. Initial exact phases, outgoing births, and terminal incoming/exact phases fit the same finite recursion.

This reconstructs the resolved H6 theorem. It uses a fixed event schedule and the explicitly chosen interpolation. The estimate does not apply to a raw-time subtraction of unequal-dimensional arrays.

## 7. H6 runner clarification: an explicit derived-history lift

The old run_path stores endpoint-classified states, arrival states, and after-inference states. It has no occupied-side state at an exact birth parameter. Consequently its raw artifact is not an element of H6's history space. The phrase about the same phase-aligned hybrid limit is valid only after a precise completion such as the following. This is the needed correction to the proposition's scope, and supplies the missing proof interface without editing the runner.

Consider the source-admitted real-arithmetic refinement sequence: all crossed strip boundaries and all original vertices remain exact mesh points, the ordered finite path is fixed, and h_max tends to zero. Eventually distinct positive-duration event neighborhoods are disjoint. At a birth parameter e, let u>e be the first occupied-side mesh point. Denote the boundary survivor law by Q_e, survivor transport to u by T_S(e,u), the larger prior birth kernel at u by B_u, and full larger-carrier parallel transport by T_N(e,u). The actual pre-inference arrival law at u is

\[
A_u=\mathcal B_u(T_S(e,u)_\# Q_e).
\]

Define an additional right-phase law at e by

\[
\widetilde Q_h(e,+)=T_N(e,u)^{-1}{}_\# A_u.
\]

This is SPD and is evaluated on the larger occupied-side carrier at e. It uses no zero-row Gaussian padding. B_u has smooth bounded affine coefficients on the occupied side and T_N(e,u)=I+O(u-e) in a fixed chart. The expansion of M Sigma M^T on a bounded moment set therefore gives

\[
d(\widetilde Q_h(e,+),\mathcal B_e(Q_e))\leq C(u-e)\leq Ch_{\max}.
\]

Interpolate from that right-phase law to u using the exact parallel transport and the arrival-target frozen Fisher step in the larger carrier. At u this reproduces the old runner's actual after-inference Gaussian because its pre-inference transport is A_u and it allocates precisely r(u-e). The right-phase lift changes the location of the birth in the derived history and makes its error relative to the prescribed zero-clock birth explicit. It is additional postprocessed model data, not an observed state already in the artifact.

For a departure at e, let v<e be the last occupied-side mesh point. Define the added left-phase state and interpolation on [v,e] using the larger side target at e and the exact larger-carrier transport. At e keep the actual old runner's smaller after-inference state as its exact-phase record. The larger-side interpolation moves by O(e-v) from the transported incoming law; the actual smaller-carrier inference step does the same in its own carrier. Marginalization is bounded. Therefore the actual exact record differs by O(h_max) from marginalizing the added left-phase record. No commutation between marginalization and full Fisher flow is assumed; the bounded-velocity estimate suffices. Ordinary regular cells retain the usual frozen-target interpolation.

An active-side contact uses this left lift, the actual smaller exact record, and the outgoing birth lift, in that order. A boundary interval receives its positive-duration smaller-carrier interpolation, with the same incoming and outgoing constructions at its endpoints. An inactive-side contact makes no jump. The fixed categorical state needs only its ordinary endpoint-frozen interpolation because its carrier never changes. Initial and terminal boundary cases omit nonexistent incoming or outgoing pieces. The source validator ensures crossings are explicit waypoints, while preservation of original vertices retains contacts and interval endpoints.

Each inserted event mismatch has size O(h_max), every regular-cell defect has size O((Delta s)^2), and all inserted records have the same uniform positive margins proved above. The finite stability recurrence from Section 6 then yields O(h_max) for this derived, correctly typed history. This closes the mathematical delayed-event comparison for the source-admitted real-arithmetic extension, including contacts, once the lift is declared.

The unchanged finite artifact alone does not contain the side targets, additional phase states, or interpolation just defined. No such artifact or lift was produced or executed here. A raw-time comparison that embeds an absent newborn as zero can have a nonvanishing supremum discrepancy during every positive birth delay: the exact newborn covariance has a positive limiting eigenvalue. H8 also prevents interpreting the real-arithmetic sequence as an unrestricted sequence of existing float64 runs. The practical correction is to name and retain the derived-history map, or restrict the old-runner claim to this conditional mathematical statement.

## 8. H7: parent-only birth is impossible for the admitted preparations

At x=-0.8 both old children 0 and 1 have strictly positive weights. In unframed coordinates their sole old depth-one parent is Y=aZ_0+bZ_1 with a,b>0 and a+b=1. Choose any SPD old covariance, any old mean, and any nonzero four-vector u. Replacing that mean by its sum with (b u,-a u) leaves the complete old parent Gaussian unchanged. Keep the categorical law unchanged as well.

The new singleton parent at the occupied-side birth is Z_2, by H3. Its conditional mean under the actual birth kernel is m_2+rho L_2 L_1^-1(E Z_1-m_1). The two preparations therefore differ in the new parent mean by -a rho L_2 L_1^-1 u. The source gives rho>0 at this context for every finite strictly positive coupling; L_2 L_1^-1 is invertible. The difference is nonzero.

A recognition-independent Markov kernel applied to one identical old parent law must return one identical new law. It cannot reproduce these two outputs. This proves the stated autonomy obstruction, including arbitrary nonlinear candidate parent kernels. The analogous reversed endpoint argument applies to birth 1 at x=0.8 through the old survivor neighbor 2 inside parent (2,3). Orthogonal frame changes cannot remove a nonzero difference.

The final direct parent has zero coefficient for the newborn at the exact birth, so this witness concerns the newly occupied depth-one parent. Zero coupling removes this particular dependence; it does not establish the later reduced dynamics. Retaining the fine preparation or its complete relevant conditional distinguishes the two cases. The counterexample does not apply to a restricted preparation class that has already fixed the hidden survivor information.

## 9. H8: geometric limits do not give a finite-format refinement theorem

At inward distance delta from a strip endpoint with radius r_i, t=2delta/r_i+O(delta^2). Consequently log w=1-r_i/(2delta)+O(1) tends to minus infinity. The exact positive weight eventually falls below every fixed positive representable minimum as a real refinement approaches the endpoint. A finite coordinate format also cannot represent infinitely many distinct points approaching one boundary. These are arithmetic limitations, not a zero eigenvalue of the normalized active Gaussian.

The source explicitly rejects active weights rounded to zero. Its current config limits refinements to integers 1 and 2. An analytic endpoint selector fixes the endpoint ratio but cannot extend the representable range of nearby interior weights. Thus H8 correctly separates the real-arithmetic proof from executable refinement. The construction authorizes no clamp, covariance epsilon, silent support change, or replacement of undefined conditional attention. An alternative numeric representation would require its own observable and error contract.

## 10. Source binding and freeze

These are SHA256 hashes of read-only inputs, not test evidence. Agent paths below are relative to this completion run. Module names are relative to src/multiagent_elbo/experiments/neighborhood/. The source formulas agree with the bindings recorded by the author. The parent proof's optional 39-coordinate event implementation is not independently assessed here; the H1-H8 reconstruction uses the full fixed categorical carrier throughout.

| File | SHA256 |
| :--- | :--- |
| agents/hybrid-interface.md | 5bd5941a599321fed01c5c757c02e29262a366e23c2d6304dbae9c385955a2bd |
| agents/evolution.md | 6a5693a48438bb63f30e146a1ca9add96aba884e63d7e730fc86957b3e5a4d03 |
| agents/evolution-verification.md | 63a71eb797bb5be2b95707f6504a81d8d8cfa13c58ce0c4b59f3acd518d98bde |
| cover.py | 0073e72aa3bca51a1cb27023ad223a91572c7be577bb296951ceaf4b70738e88 |
| local_tree.py | 6d9fcf0098be7ab44bb577eee6eee8909d30b0d35d0ce15b0f22521de93a5d2d |
| junction_tree.py | 8c079e8edde61e6ce8e414b0fa6fade837078d189e7f592de47e9cefef61a469 |
| inference.py | ade492121f2c261c06033955711199d4052602315acec8dac7be716692fc2251 |
| connections.py | 53a497039842ad16efa1ac3b335d4a8c6c44abcb4ae4f9d237180a58e5452bb9 |
| gaussian_boundary.py | ee9dfd4eba8a357c632a74887171a63417091b2d6f564859b68d4360fe39576a |
| moving_context.py | 4cab30c50c5e4e75a345f43ac63b991a7b62e287e1174300fb8145ec7dd9a9fa |
| moving_context_config.py | 568aa43ea6614e088c796f82a574a22d5fb3bcce90c2b8e359cd161560d8ebd8 |
| nonflat.py | 627e2cc1694f264bf4584c3c88fdcb73b2793b8f41d25013d094c3c31fb35a24 |
| model.py | 49af1bf02b9cd5030b8ee9d9fecf945d50cde0106f448efa51c2ae571562d94b |
| experiments/rg_v2/neighborhood_moving_context.py | 7e3b047348065ab7684cfa7c9c0d3f8ad7a94283c262c2e5de4584db1f040e60 |

Revision 2 freezes the reconstructed H1-H8 argument and the explicit H6 runner-scope clarification. No existing scientific result was rerun or reclassified. Root owns any ledger adjudication, author revision, implementation of side constructors or history lifts, execution, integration, and canonical delivery.

