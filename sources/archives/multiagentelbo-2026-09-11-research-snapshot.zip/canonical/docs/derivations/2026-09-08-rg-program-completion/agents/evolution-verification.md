<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Independent evolution reconstruction

Revision 1 checkpoint, September 8, 2026. This is the independently reconstructed E1–E6 lane report, not a root ledger adjudication. The brief calls the input contract `contract.json`; the actual frozen input is `problem-contract.json`. This lane owns only this file. No code, tests, model execution, numerical verification, GPU work, historical producer, publication, or vault write was performed.

The mathematical E1 and E4 constructions reconstruct directly. E2 reconstructs after making its common precision floor explicit. E3 reconstructs for a finite, explicitly ordered, one-sided schedule; the runtime's endpoint population classification does not by itself provide that schedule or a proved cross-boundary comparison topology. E5's moving-coordinate and changing-channel product derivatives reconstruct. E6's projectability and perturbation estimates reconstruct when the Lipschitz bound is uniform on the relevant time/state neighborhood, or has an integrable time-dependent modulus. A merely pointwise-in-time spatial Lipschitz property does not imply uniqueness.

## Input provenance

The reviewed input is `agents/evolution.md`, revision 3, SHA-256 `6a5693a48438bb63f30e146a1ca9add96aba884e63d7e730fc86957b3e5a4d03`. The frozen contract file SHA-256 is `50db7529fc2c5cb7c032cd4e3b6517516a93800ba32db8c2c50c226ddb2a369e`. The assignment brief SHA-256 is `d611b531dd56f9880419f522ad97575b626d5d166f27006fafb4d0bbb4a4c428`. Repository HEAD at inspection was `409c61155ac16b21342bfe15c834fda7bb33fb67`; the derivation is a separately hashed working artifact, not presumed equal to its committed version. Hashes record inspected inputs only and are not mathematical evidence.

## Concrete correction and remaining obligations

E2 reuses `j_*` after E1 defined it as a target-only parallel precision floor. The common floor is instead `j_0*=min(lambda_min(J_0),j_*)`. Both comparison precisions must exceed that common floor before using the inverse bound with constant `(j_0*)^-2`. The order-one convergence claim survives this correction; the literal target-only constant need not hold near a lower-precision initialization.

E6 must interpret its reduced-velocity local Lipschitz condition uniformly on compact time/state neighborhoods, or replace it with an integrable time-dependent Lipschitz bound. The later displayed error theorem already specifies a common constant L. The full reconstruction below will give the counterexample to the weaker pointwise interpretation.

The Gaussian formulas in `local_tree.gaussian_inputs` do supply one-sided positive prior and posterior extensions in real arithmetic on each fixed active chain. That source admission does not establish convergence of the current endpoint-classifying runtime through all births, departures, contacts, or boundary-aligned intervals. The missing bridge is the chosen one-sided schedule, transition ordering, and a norm or aligned graph comparison between corresponding spaces. This is an implementation/convergence obligation, not evidence that the finite hybrid construction fails.

E7 is intentionally excluded from this lane's reconstruction and remains assigned to the separate event-family verification lane.

Further proof details and atomic dispositions will be added in revision 2.

## Revision 2: complete reconstruction and amendment review

Revision 2, September 8, 2026, supersedes the checkpoint's preliminary dispositions while retaining it as history. The original author input was not edited. This section independently reconstructs E1–E6 together with `agents/evolution-amendment.md`, SHA-256 `589eb22e3c5860062547031e791bbad7b11ad19bfe0c2a7436145c3110095eca`. These are lane dispositions, not root ledger adjudications. The complete revision includes every section from here through the final “Revision 2 outcome” section; intermediate writes are incomplete until that section is present.

The finite regular-stratum Fisher evolution, conditional Gaussian jumps, parent-boundary factorization criterion, and moving-coordinate/channel derivatives reconstruct. The arrival-target convergence estimate reconstructs with the amended common initial/target precision floor. Reduced uniqueness reconstructs with the amended time-uniform or integrable Lipschitz condition. The target-only inverse constant and the weaker pointwise-in-time Lipschitz interpretation have explicit counterexamples below. Current endpoint-classifying runtime convergence through changing Gaussian domains remains open. This does not undo the conditional finite hybrid theorem.

### Evidence method and additional source provenance

All proofs below use algebra, finite-dimensional probability, explicit integral equations, and scalar integral-inequality iteration. They do not depend on an affirmative desired outcome, author authority, numerical agreement, or external theorem citation. The GPML reference in the author input is not required for these reconstructed identities. No runtime execution was performed.

The following paths are relative to `src/multiagent_elbo/experiments/neighborhood/`. They were read, not run. Their hashes identify inspected formulas, not mathematical pass/fail conditions.

| Source | SHA-256 |
| --- | --- |
| `local_tree.py` | `6d9fcf0098be7ab44bb577eee6eee8909d30b0d35d0ce15b0f22521de93a5d2d` |
| `cover.py` | `0073e72aa3bca51a1cb27023ad223a91572c7be577bb296951ceaf4b70738e88` |
| `moving_context_config.py` | `568aa43ea6614e088c796f82a574a22d5fb3bcce90c2b8e359cd161560d8ebd8` |
| `moving_context.py` | `4cab30c50c5e4e75a345f43ac63b991a7b62e287e1174300fb8145ec7dd9a9fa` |
| `gaussian_boundary.py` | `ee9dfd4eba8a357c632a74887171a63417091b2d6f564859b68d4360fe39576a` |
| `connections.py` | `53a497039842ad16efa1ac3b335d4a8c6c44abcb4ae4f9d237180a58e5452bb9` |
| `junction_tree.py` | `8c079e8edde61e6ce8e414b0fa6fade837078d189e7f592de47e9cefef61a469` |
| `model.py` | `49af1bf02b9cd5030b8ee9d9fecf945d50cde0106f448efa51c2ae571562d94b` |
| `gaussian_inference.py` | `954c9b52c10d51b2dbc31a23e9788db983bcd9cd9d67e9cd0b931159aa304acc` |

### Atomic dispositions

Each reconstruction is conditional on its proof-section hypotheses.

| ID | Atomic claim | Disposition | Decisive falsifier or limitation |
| --- | --- | --- | --- |
| EV01 | Full Gaussian Fisher metric E1.2 | Derivation reconstructed | Wrong tangent symmetry, loss of SPD, or omitted factor 1/2 changes the metric. |
| EV02 | Gaussian and simplex KL Fisher velocities E1.1 | Derivation reconstructed | A restricted-family metric need not give these full-family velocities. |
| EV03 | Natural-coordinate linearization E1.3 | Derivation reconstructed | Reversing the connection sign without changing formulas breaks cancellation. |
| EV04 | Explicit positive Gaussian solution and uniqueness E1.4 | Derivation reconstructed | Singular initialization/target or absent compact bounds is outside scope. |
| EV05 | Positive simplex log-odds solution E1.5 | Derivation reconstructed | Target support loss removes bounded log odds. |
| EV06 | Passive-frame covariance and objective balance E1.6 | Derivation reconstructed | Recognition/target must transform together; target/evidence derivatives must exist. |
| EV07 | Arrival-target natural-coordinate error E2.2–E2.3 | Derivation reconstructed | Changing paths or using uncontrolled transports invalidates this defect estimate. |
| EV08 | Moment error with amended common floor | Derivation reconstructed | Both compared precisions must share that lower bound. |
| EV09 | Original target-only inverse constant | Refuted | The scalar affine-target example below violates it. |
| EV10 | Exact segment transport and subdivision | Derivation reconstructed | Noncommuting matrices or a changed path require new analysis. |
| EV11 | Conditional-entry kernel, positivity, KL identity E3.1–E3.3 | Derivation reconstructed | Empty survivors, singular covariance, or recognition-dependent entry is not covered. |
| EV12 | Finite hybrid solution and resolved-boundary O(h) convergence | Derivation reconstructed | Infinite events, missing limits, or unspecified order defeats induction. |
| EV13 | Current Gaussian one-sided target positivity | Derivation reconstructed from inspected formulas | Padded absent-coordinate covariances are not SPD. |
| EV14 | Continuum convergence of the endpoint-classifying runner through all admitted events | Open | Supply event semantics, correspondence of discrete events, and aligned comparison. |
| EV15 | Gaussian parent-boundary factorization iff E4.1 | Derivation reconstructed | Restricted preparations can evade necessity; this theorem covers all full Gaussians. |
| EV16 | Departure obstruction to universal parent-only evolution | Derivation reconstructed | Extra data distinguishing the two old laws removes this example. |
| EV17 | Moving completion and full-conditional augmentation E5.1 | Derivation reconstructed | Rank loss or partial conditional retention defeats reconstruction. |
| EV18 | Moving moment derivatives E5.2 | Derivation reconstructed | Suppressing nonzero D_s F changes the derivative. |
| EV19 | Moving-channel derivatives E5.3–E5.4 | Derivation reconstructed | Different q/p channels, missing C_s derivative, or undefined rows invalidates the corresponding formula. |
| EV20 | SPD/rank and occupied-conditional boundaries | Derivation reconstructed | Ratios have no inherited value or derivative bound at zero occupancy. |
| EV21 | Continuous fiberwise projectability | Derivation reconstructed | One retained fiber with unequal projected velocities prohibits closure. |
| EV22 | Uniqueness with amended uniform/integrable Lipschitz condition | Derivation reconstructed | Nonintegrable time-dependent growth is not covered. |
| EV23 | Uniqueness with only pointwise-in-time spatial Lipschitz continuity | Refuted | The clipped-field example below has infinitely many solutions from zero. |
| EV24 | Moving-map obstruction when hidden mean information is omitted | Derivation reconstructed | Storing the distinguishing conditional or hidden mean removes this obstruction. |
| EV25 | Residual and finite-jump error propagation E6.2 | Derivation reconstructed | Actual residual, jump error, and admissible margins must still be bounded. |

E7 and the author input's 39-coordinate event closure remain with the separate event-family verification. No EV claim identifies the path parameter, allocated inference clock, or hierarchical scale with physical time.

### E1: Fisher velocities and positive propagator

Fix a finite interval, fixed Gaussian dimension n, finite event carrier, strictly positive initial laws, and the declared product family. A covariance tangent U is symmetric. Let X=z-mu and J=Sigma^-1. The Gaussian directional score is

\[
S_{u,U}=u^TJX+\tfrac12(X^TJUJX-\operatorname{tr}(JU)).
\]

Differentiating exp(t^T Sigma t/2) at zero gives second moment Sigma and

\[
E[X_aX_bX_cX_d]=\Sigma_{ab}\Sigma_{cd}+\Sigma_{ac}\Sigma_{bd}+\Sigma_{ad}\Sigma_{bc}.
\]

The linear/quadratic cross term vanishes by zero cubic moments. The linear product is u^T Jv. The centered quadratic product is twice tr(JU JW) before its two factors 1/2. Thus

\[
g((u,U),(v,W))=u^TJv+\tfrac12\operatorname{tr}(JUJW).
\]

Gaussian KL against N(m,V), J_p=V^-1, has differential

\[
d\operatorname{KL}[u,U]=u^TJ_p(\mu-m)+\tfrac12\operatorname{tr}[(J_p-J)U].
\]

Metric pairing identifies gradient Sigma J_p(mu-m) in mean and Sigma J_p Sigma-Sigma in covariance. A simplex tangent u has zero sum, so its KL differential is sum_x u_x log(q_x/p_x). The tangent q_x[log(q_x/p_x)-KL(q||p)] pairs with u in the simplex Fisher metric to give that differential. This proves EV01–EV02, including centering and sign. Independence makes the product metric block diagonal and total KL additive. Smaller families need their own metric pullback.

Set h=Jmu with D_s mu=mu'+A mu and D_s Sigma=Sigma'+A Sigma+Sigma A^T. Inverse differentiation gives

\[
J'=-J\Sigma'J=A^TJ+JA+\gamma(J_p-J).
\]

In h'=J'mu+Jmu', the JA mu and J_p mu terms cancel, giving h'=A^T h+gamma(h_p-h). This proves EV03.

For EV04, bounded continuous A on each piece gives Phi'=-A Phi by its ordered-integral series, whose kth term is at most (MT)^k/k!. The series converges uniformly. Constructing Psi'=Psi A similarly gives (Psi Phi)'=0 and Psi=Phi^-1. Homogeneous-difference iteration bounds two solutions' difference by a finite supremum times (MT)^k/k!, proving uniqueness. The matrices have norm bounds exp(MT); finitely many pieces compose with finite bounds.

Jbar=Phi^T J Phi and hbar=Phi^T h obey xibar'=gamma(xibar_p-xibar). Multiplication by exp(Gamma), Gamma=integral gamma, gives E1.4. The initial weight exp(-Gamma) and source-kernel mass 1-exp(-Gamma) are nonnegative and sum to one. Compactness supplies j_target>0 and finite upper bounds for Jbar_p; the initial J_0 has j_initial>0. Hence

\[
\bar J(s)\succeq j_{\rm common}I,
\qquad j_{\rm common}=\min(j_{\rm initial},j_{\rm target})>0.
\]

Sigma=Phi Jbar^-1 Phi^T is SPD and mu=Phi Jbar^-1 hbar is finite throughout. The integral formula bounds hbar and upper precision too. It gives a unique positive trajectory, including admitted one-sided endpoints. These real-arithmetic bounds do not certify stable float64 evaluation arbitrarily near availability boundaries.

For EV05, subtracting log-density derivatives gives r_j'=gamma(r_j^p-r_j), r_j=log(q_j/q_K). The same scalar solution applies. Finite positive continuous targets and the initial law have bounded log odds on a compact interval. If |r_j|<=R, softmax with last logit zero has denominator at most K exp(R) and every numerator at least exp(-R). Each mass is at least exp(-2R)/K. Positivity, normalization, and uniqueness follow; a one-state carrier is constant mass one.

For EV06, transform recognition and target simultaneously by invertible G(s). Means transform by G and covariances by congruence. Differentiation gives Atilde=GAG^-1-G'G^-1. Vertical gradients transform because Sigma_tilde J_p_tilde=G Sigma J_p G^-1. No equality of separately declared belief/model connections follows. In the parallel frame,

\[
(\operatorname{KL}(q_s\Vert p_s))'=\int q_s'\log(q_s/p_s)-E_{q_s}[\partial_s\log p_s].
\]

The first term pairs the KL differential with its Fisher velocity, yielding -gamma times the squared Fisher norm. On each compact C1 piece, bounded means and upper/lower covariance bounds give an integrable Gaussian envelope times a polynomial for differentiated integrands, justifying interchange. Event expressions use finite sums. VFE adds -(log evidence)'. External terms need not be negative. Uniqueness proves two-parameter propagator composition; an autonomous one-parameter semigroup needs time-homogeneous data or an augmented driver. Mobility may vanish, so the allocated clock can stall.

### E2: endpoint consistency and precision amendment

Work in one common parallel frame along the same prescribed path. Exact transport removes the horizontal matrix evolution; freezing the target at arrival gives

\[
\xi_{i+1}=a_i\xi_i+(1-a_i)\xi_p(s_{i+1}),
\qquad a_i=e^{-\rho\Delta s_i}.
\]

Subtract the exact cell integral. The defect is the E2.2 integral with integrand rho exp[-rho(s_{i+1}-u)](xi_p(u)-xi_p(s_{i+1})). For an L-Lipschitz target, its norm is at most

\[
\rho L\int_{s_i}^{s_{i+1}}(s_{i+1}-u)du
=\tfrac12\rho L(\Delta s_i)^2.
\]

The error recurrence is e_{i+1}=a_i e_i-R_i. Since 0<=a_i<=1, iteration and sum_i(Delta s_i)^2<=T h_max prove E2.3. Continuous targets instead give the vanishing bound rho T omega(h_max), where omega is their uniform modulus. Exact variable-mobility clock increments permit the same argument with ||gamma||_infinity. Zero mobility gives zero forcing and error. This proves EV07.

The inverse identity is

\[
J^{-1}-K^{-1}=J^{-1}(K-J)K^{-1},
\quad
\|J^{-1}-K^{-1}\|\leq j_{\rm common}^{-2}\|J-K\|,
\]

when both compared matrices exceed j_common I in the same coordinates. If P bounds ||Phi|| and H bounds the information vectors, then

\[
\|\delta\Sigma\|\leq P^2j_{\rm common}^{-2}\|\delta\bar J\|,
\]
\[
\|\delta\mu\|\leq P\left(j_{\rm common}^{-1}\|\delta\bar h\|
+j_{\rm common}^{-2}H\|\delta\bar J\|\right).
\]

The softmax derivative sends v to q_x(v_x-E_qv), with l1 norm at most 2||v||_infinity. These estimates convert natural-coordinate error to moment/probability error. The same cell argument applies inside a frozen-target interpolation. This proves EV08 and reconstructs the precision amendment.

The original target-only constant has a counterexample inside this scalar scheme. Take A=0, rho=1, J_0=0.1, J_p(s)=1+s, and a short interval starting at zero. A valid target-only floor is j_*=1. The exact precision and one endpoint step are

\[
J(h)=h+0.1e^{-h},
\qquad
\widehat J(h)=1+h-(0.9+h)e^{-h}.
\]

Their difference is 1-(1+h)e^-h>0 for h>0. At sufficiently small h both are positive and below one. Therefore

\[
|J(h)^{-1}-\widehat J(h)^{-1}|
=\frac{|J(h)-\widehat J(h)|}{J(h)\widehat J(h)}
>|J(h)-\widehat J(h)|.
\]

This refutes EV09's target-only constant j_*^-2=1. The amended common floor 0.1 is valid. No numerical evaluation is used.

For EV10, the reference connection is Kbar(x dy-y dx)/2 with fixed Kbar. Its matrices commute along the path. On c(t)=c_0+t(c_1-c_0), x y'-y x'=det(c_0,c_1), so the integral is det(c_0,c_1)/2. Restoring endpoint frames gives G_1 exp[-Kbar det(c_0,c_1)/2]G_0^T, matching `connections.segment_transport`. Subdivision of this same segment adds scalar integrals and cancels intermediate orthogonal frames. Replacing a smooth path by chords needs a separate path-error estimate.

### E3: kernels, finite stability, and runtime boundary obligations

Take nonempty survivors S=I intersection J, invertible T_S, an SPD old Gaussian in old active coordinates, and SPD new reference pi_J. Set X_S=T_S P_S X_old and independently draw epsilon~N(0,C). Define X_N=b+B X_S+epsilon with B,b,C from E3.2. The kernel depends on the old value only through its survivor coordinates; it is normalized, recognition-independent, and preserves the entire transported survivor marginal.

Completing the reference quadratic form gives C=V_NN-V_NS V_SS^-1 V_SN. For nonzero v, the positive form of V evaluated at (-V_SS^-1 V_SN v,v) equals v^T C v>0. The output covariance is

\[
\begin{pmatrix}I&0\\B&I\end{pmatrix}
\begin{pmatrix}\Sigma_S&0\\0&C\end{pmatrix}
\begin{pmatrix}I&B^T\\0&I\end{pmatrix},
\]

so it is SPD. Its mean and cross covariance give E3.2. In the density ratio against pi_J, identical conditional factors cancel, leaving log[(T_S#q_S)/pi_S]. Integrating the normalized conditional proves E3.3. Gaussian moments give finite KL. Other density classes would need an explicit absolute-continuity/extended-value convention. This compares a new joint to its new reference, not old VFE or evidence. EV11 follows.

After restoring labels, mu^+=d+Mmu^- and Sigma^+=Q+M Sigma^- M^T. Differences are bounded exactly by ||M|| and ||M||^2. A finite ordered schedule allows recursive E1 solutions on each one-sided interval and positive jumps into the next initial law. This constructs a unique normalized hybrid trajectory in the disjoint union of correctly labeled spaces. Unequal SPD dimensions are never identified.

For resolved meshes, the explicit affine natural flow and positive conversion margins give a moment-flow Lipschitz bound on a common compact neighborhood. Write a stratum's endpoint bound as E_out<=L_flow E_in+C_flow h_max. For norm ||delta mu||+||delta Sigma||, a subsequent jump has E_next<=K_jump E_out with K_jump=max(||M||,||M||^2). Finite recursion yields a finite sum of O(h_max) defects times later constants, plus propagated initial error. This proves EV12 for corresponding one-sided states. The same recursion propagates a modulus bound. It supplies no uniform estimate over increasing event counts or degenerating covariance margins.

For delayed events, assume eventually fixed transition order, delays O(h_max), bounded moments and velocities, and one-sided Lipschitz M,d,Q. Expanding (M+delta M)Sigma(M+delta M)^T shows an O(h_max) jump discrepancy; the additional short flow has the same order. The finite estimate therefore applies after aligning corresponding events. Raw-time uniform convergence can fail: between an exact jump and its delayed counterpart one trajectory has jumped and the other has not, leaving supremum error at least the jump size at every mesh.

A contact needs explicit semantics. If an agent belongs to I^- and I^+ but not I^0, the two zero-clock kernels I^- to I^0 to I^+ can replace its old conditional. Start with N((0,delta),I_2), retain only the first coordinate at contact, then re-enter the second under an independent centered unit reference. The two-jump output is N((0,0),I_2); skipping contact preserves the original law. Equal populations on either side therefore do not determine the update. A boundary-aligned interval needs its exact-boundary population for its entire duration and separate entrance/exit rules.

#### Current Gaussian one-sided target admission

`local_tree.gaussian_inputs` uses triangular L_i with diagonal at least 0.9 and bounded lower entries. The prior correlation satisfies 0<=rho<0.30*1.08=0.324 for finite nonnegative coupling; recognition's bound is smaller and reference correlation is zero. On a fixed active chain define independent standard Gaussian innovations by

\[
Z_1=\mu_1+L_1\epsilon_1,
\]
\[
Z_{i+1}=\mu_{i+1}+\rho L_{i+1}L_i^{-1}(Z_i-\mu_i)
+\sqrt{1-\rho^2}L_{i+1}\epsilon_{i+1}.
\]

Induction yields Cov(Z_i)=L_i L_i^T and adjacent cross covariance rho L_i L_{i+1}^T, exactly the source pairs. The triangular innovation map has invertible diagonal blocks, proving a positive joint. Its density is one node density times adjacent normalized conditionals, equivalently adjacent pair-density products divided by internal node densities. Expanding those log Gaussians yields the inspected clique-minus-separator precision and information formulas in `junction_tree.assemble_gaussians`. Thus the source assembly is the innovation joint in real arithmetic.

This cover has finitely many fixed active chains with at most three nodes. Factors, inverses, and correlations extend smoothly to compact one-sided boundaries and stay nondegenerate. The innovation map stays invertible there. Every prior/initial active covariance therefore has positive continuous endpoint extensions and uniform eigenvalue bounds on each compact piece.

Observation noise is R=0.6 I_2. In active coordinates the posterior square gives J_post=J_prior+H^T R^-1 H and h_post=J_prior mu_prior+H^T R^-1 o, so its precision is SPD. These identities also follow from the inspected covariance-conditioning formula by multiplication with J_post. All observations, frames, factors, and H entries have finite one-sided extensions. Availability is exp(1-1/t) inside its domain and zero outside. Repeated derivatives are exp(-1/t) times finite inverse powers of t and bounded smooth factors. For every integer m, exp(-1/t)t^-m tends to zero as t decreases to zero: the exponential-series term of degree m+1 supplies a bound. Thus the zero extension is smooth, as is the weighted H. E1's solution then also supplies the recognition's finite positive one-sided limit. This proves EV13 in active coordinates without calling padded absent coordinates SPD.

#### What remains unsupplied

The inspected validator requires all strictly crossed strip boundaries -0.8,-0.1,0.1,0.8 to be original waypoints. `_points` preserves those vertices exactly. A claim that validated polygonal paths ignore all boundary locations would be false. `run_path` nevertheless rebuilds endpoint models, classifies exact endpoint populations, transports common endpoint survivors, reconciles with the arriving prior, and allocates the full cell's inference increment at arrival. It does not store both one-sided laws or an ordered event object. Validated refinements are only 1 and 2; `_points` admits larger numbers in direct calls but is not complete configuration admission. Availability also rejects floating underflow at interior active points.

These facts leave EV14 open, not refuted. Its closure needs left/exact/right population semantics; reference limits and contact/simultaneous-event ordering; boundary-aligned interval semantics; and a proof matching endpoint updates to that hybrid trajectory. Comparison must identify corresponding one-sided spaces or use a defined aligned graph metric. An unspecified matrix supremum across changing dimensions is not such a comparison. One-sided target positivity is now supplied; it is not the remaining Gaussian boundary-convergence proof. A finite-run error table or float64 refinement under an underflow guard cannot replace this bridge.

### E4: exact parent boundary factorization

Let F_- and F_+ have full row rank and use E3's fixed affine Gaussian boundary law. If F_+M=L F_-, the parent kernel

\[
Y_+=F_+d+LY_-+\epsilon,
\qquad\epsilon\sim N(0,F_+QF_+^T),
\]

with independent noise sends every old parent Gaussian to the parent of its full boundary output. Means and covariances match, proving equality of complete Gaussian laws. Singular noise is a normalized measure on a subspace, not a claimed full-dimensional density. The full output covariance is SPD and F_+ has full row rank, so the resulting parent covariance is SPD.

For necessity, take v in ker F_-. Two old positive Gaussians with means mu and mu+v and equal covariance have identical old parent laws, while their new parent means differ by F_+Mv. One fixed parent Markov kernel cannot output two different laws from identical input laws. Hence ker F_- is contained in ker(F_+M). A right inverse R_- exists; set L=F_+M R_-. Decomposing z=R_-F_-z+(I-R_-F_-)z, with the second summand in ker F_-, proves F_+M=L F_-. This proves EV15. Necessity does not assume the unknown kernel is affine.

For EV16 take F_-=(1/2,1/2), M=(1,0), F_+=(1). The laws N((0,0),I_2) and N((delta,-delta),I_2) both project to N(0,1/2). After departure of coordinate two, the output means are zero and delta and variances are both one. Nonzero delta prevents universal parent-only evolution. Restricted preparations or retained survivor marginals can evade the example. It is not a nonexistence proof for every reduced representation.

### E5: moving splits, channels, and singular boundaries

For C1 full-row-rank F(s), complete its rows at a point by constant N. The determinant of T(s)=[F(s);N] stays nonzero nearby by continuity. These neighborhoods have a finite subcover of each compact regular interval, and overlaps use invertible C1 maps T_b T_a^-1. This proves chart existence without asserting smoothness of any particular QR implementation.

A visible Gaussian Y and its complete hidden conditional X=b+B Y+epsilon reconstruct the joint using the covariance-block innovation formula. Inverting T reconstructs the original law. Differentiating Tz gives A_T=TAT^-1-T'T^-1, proving E5.1. Recognition and target acquire the same inverse absolute determinant; their KL ratio cancels it. Pushing a normalized generative law while keeping the observation fixed preserves evidence by change of variables. EV17 is exact, but it retains the full information dimension and all cross covariances.

For EV18 apply the ordinary product rule to mu_Y=Fmu and Sigma_Y=F Sigma F^T, then add the parent connection terms. Grouping the child terms as F D_s mu and F(D_s Sigma)F^T leaves exactly D_s F=F'+A_YF-FA and its transpose contributions in E5.2. Setting D_s F to zero is a separate connection-solvability constraint. Retaining the conditional does not enforce it. A general invertible split T is a coordinate representation of the retained joint, not automatically an element of the compact gauge group or an induced principal parent connection.

For EV19 use positive q_x,p_x and the same recognition-independent C1 row-stochastic channel C_s(y|x). The joint Q_s(x,y)=q_x C_s(y|x) differentiates to q_x' C_s+q_x C_s'. Summing x gives the direct parent derivative. On an occupied column, q_Y,p_Y are positive and the common channel cancels on nonzero cells:

\[
\log(q_x/p_x)=\log(q_Y/p_Y)+\log(q(x|y)/p(x|y)).
\]

Multiply by q(x|y), sum x, and substitute E1's simplex velocity. The result is -gamma q_Y[log(q_Y/p_Y)+d(y)-KL(q||p)], plus sum_x q_x C_s'(y|x) from product differentiation. This is E5.4 with the stated sign. Summing Q over y reconstructs q because channel rows sum to one. Frozen-channel evolution omits a real term if C_s' contributes.

Structural zeros do not obstruct the unnormalized product derivative. A zero column gives q_Y=p_Y=0, so its conditional equation is undefined while the product equation remains valid. Beta=eta/alpha has derivative eta'/alpha-eta alpha'/alpha^2 only for alpha>0. A compact occupied interval with alpha>=alpha_*>0 permits bounds; alpha tending to zero does not inherit them. For Sigma SPD,

\[
v^T F\Sigma F^T v=(F^Tv)^T\Sigma(F^Tv),
\]

which is positive for every nonzero v exactly when F has full row rank. Rank loss leaves this SPD stratum. These facts prove EV20 and distinguish smooth masses from undefined normalized conditionals.

### E6: projectability, uniqueness amendment, and residual bounds

For x'=V_s(x), z=pi_s(x), the chain rule gives

\[
z'=W_s(x)=\partial_s\pi_s(x)+D\pi_s(x)V_s(x).
\]

If a deterministic reduced velocity reproduces every fine preparation at that time, W_s must be constant on each pi_s fiber. Otherwise the same reduced state requires two velocities. Conversely fiber constancy defines Vbar_s on the image, and every projected fine trajectory solves its equation. This proves EV21. Necessity on an entire state space requires preparations allowed at the time in question; with just one fixed initial law it applies only to the reachable set.

Existence of a projected solution follows from the fine solution. For uniqueness require a time-uniform local Lipschitz constant on relevant compact neighborhoods, or an integrable nonnegative coefficient L(s). Two solutions agreeing initially obey e(t)<=integral L(u)e(u)du. Repeated substitution bounds e by M[integral L]^k/k!, with M a finite difference bound on the compact interval, hence e=0. The argument applies successively along admitted neighborhoods. This proves EV22 and reconstructs the amendment's strengthened condition.

The pointwise-in-time alternative EV23 is false. For t>0 set

\[
V(t,x)=2t\operatorname{clip}(x/t^2,-1,1),
\qquad V(0,x)=0.
\]

Each positive-time spatial map is Lipschitz with constant 2/t, and the zero-time map is constant. Joint continuity at zero follows from |V(t,x)|<=2t for every x; elsewhere it is immediate. Every x_c(t)=ct^2 with |c|<=1 solves the ODE, starts at zero, and has derivative zero there. Thus even joint continuity plus pointwise spatial Lipschitz continuity does not imply uniqueness. The coefficient 2/t is nonintegrable, so the amended condition excludes this example. This independently reconstructs the amendment's counterexample.

At jumps, continuous projectability supplies no missing law-map equality: pi_+ B=Bbar pi_- must also hold. E4 gives the exact criterion for its affine Gaussian and linear-parent setting. Conversely satisfying jump squares does not force fiberwise constancy of continuous projected velocities. These are independent interfaces.

For EV24 take p=N(0,I_2), F=(1,0), q_delta=N((0,delta),I_2). All old visible laws and their complete fixed-target visible Fisher trajectories equal N(0,1). A representation retaining that visible information but no hidden mean is identical for every delta. Changing the map to (0,1) reveals N(delta,1), so no function of identical retained states and the same new map returns every correct result. This proves the information-loss obstruction. A claim about a particular serialized modal object's extra diagnostic fields would need its own exact source trace; this lane does not assume every implementation object discards every hidden diagnostic. The result applies to the stated representation omitting the distinguishing information.

For EV25 let z solve the reduced ODE and zhat'=Vbar_s(zhat)+r_s, with ||r_s||<=epsilon_s. With an integrable Lipschitz coefficient,

\[
e(t)\leq e(s_0)+\int_{s_0}^tL(u)e(u)du+\int_{s_0}^t\varepsilon(u)du.
\]

Iteration of this Volterra inequality and summation of ordered-integral terms gives

\[
e(t)\leq\exp\left(\int_{s_0}^tL\right)e(s_0)
+\int_{s_0}^t\exp\left(\int_u^tL\right)\varepsilon(u)du.
\]

The remainder is bounded by a finite supremum times (integral L)^k/k! and vanishes. Constant L gives E6.2. For a K_j-Lipschitz exact jump and discrepancy delta_j, triangle inequality gives e^+<=K_j e^-+delta_j. Combining the interval estimate and this inequality over finitely many jumps proves the hybrid bound. Norms are declared on corresponding coordinate spaces; metric conversions need positive margins. A fixed-target modal remainder or calibration table does not bound the moving residual, which must include map, target-whitening, coefficient, and boundary changes.

### Revision 2 outcome

The corrected E1–E6 mathematics yields a positive regular-stratum propagator, a finite conditional-kernel hybrid construction, an exact Gaussian parent-boundary descent criterion, exact moving-coordinate/channel derivatives, and conditional reduced-error propagation. Both precision and Lipschitz amendments reconstruct. The two refuted weaker statements are excluded by those amendments and do not invalidate the corrected constructions.

Three obligations remain outside these conclusions. EV14 needs the concrete one-sided schedule and comparison structure connecting the actual endpoint-classifying runner to the conditional hybrid theorem. A genuinely smaller Gaussian state must satisfy continuous projectability and every required boundary factorization, or supply a residual/jump-error bound; full-conditional augmentation is exact without reducing retained information. A floating implementation also needs its admitted conditioning/support range before real-arithmetic estimates become numerical guarantees. Arbitrary-cover event accumulation, physical time, and interacting fixed-point claims do not follow from this lane.

Root owns evidence-ledger closure and cross-lane assembly. This report makes no program-wide terminal-status claim. The complete revision 2 reconstruction ends here.
