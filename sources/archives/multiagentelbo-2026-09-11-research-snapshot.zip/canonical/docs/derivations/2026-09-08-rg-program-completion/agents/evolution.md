<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->
# Evolution and boundary construction

Revision 3, September 8, 2026. This is a mathematical submission to the separate verification wave, not accepted closure. It concerns the complete Gaussian and finite-simplex families used by the moving-context controller. The separate conditional-tree Armijo solvers are outside these theorems. No source files or tests were changed or executed by this lane.

## Existing identities and source mapping

The starting authority is [moving-context evolution](../../2026-09-08-moving-context-evolution.md), with [Gaussian boundary reconciliation](../../2026-09-08-gaussian-boundary-reconciliation.md), [Gaussian completion](../../2026-09-08-gaussian-conditional-completion.md), and [categorical completion](../../2026-09-08-categorical-conditional-completion.md). Their exact fixed-target natural-coordinate flows and retained conditional identities are inputs whose relevant hypotheses are restated below; earlier numerical results are not proofs.

The live code uses \(D=d+A\); connections.segment_transport is exact straight-segment transport for its prescribed block SO(2) connections. The current global event variable is two edge records on four fixed endpoint labels, hence 256 latent states. Those labels do not disappear when a Gaussian agent leaves. Changing availability belongs to the observation/coarse channel on this fixed latent space.

[Gaussian Processes for Machine Learning, Appendix A](https://gaussianprocess.org/gpml/chapters/RWA.pdf), inspected in this run, supplies Gaussian conditioning in A.5–A.6, inverse differentiation in A.14, log-determinant differentiation in A.15, and Gaussian KL in A.23. Here conditioned covariance blocks are positive definite, both laws have the same dimension and Lebesgue coordinates, and the target covariance is invertible. No numerical jitter recommendation is adopted. Existence, convergence, and boundary compatibility below are derived here rather than imported from an uncited ODE or splitting theorem. There is no novelty or priority claim.

Theory/SPEC.md section 5e supplies the inherited typing: the context base is timeless, vertical Fisher metrics are declared, mixed motion depends on a chosen connection, and an inference orbit does not supply a physical clock. It does not prove the new assertions.

## E1: Regular-stratum mixed Fisher evolution

**Family:** E1-natural-coordinate-variation. **Kind:** CONSTRUCTION and LEMMA. **Target obligation:** positive evolution on a fixed statistical stratum. **Types and quantifiers:** every finite interval \([s_0,s_1]\), dimension \(n>0\), and finite event set with \(K>1\), with state
\[
(\mu,\Sigma,q)\in\mathbb R^n\times\operatorname{SPD}(n)\times\Delta_K^\circ.
\]
For \(K=1\), the event law is constant unit mass.

Assume a piecewise \(C^1\) context path \(c(s)\) stays in a fixed active-agent stratum. Pull the separately prescribed belief and model connections back to a continuous bounded block matrix \(A(s)\) on each smooth piece. The connection is model data independent of recognition. Let scalar mobility \(\gamma(s)\geq0\) be continuous and bounded. Let target \(p_s=\mathcal N(m_s,V_s)\) have continuous moments and SPD covariance on the closed interval, and let event target \(p_s^e\) be continuous and strictly positive there. All Gaussian data share active coordinates. The joint recognition family here is the declared product of its Gaussian and event factors, with product Fisher metric and sum of posterior KL terms. Each factor can be internally correlated.

The external clock is
\[
\tau(s)-\tau(s_0)=\int_{s_0}^s\gamma(u)\,du.
\]
It may stall. Neither \(\tau\) nor \(s\) is physical time or automatically a Fisher arc-length coordinate.

Write \(J=\Sigma^{-1}\), \(h=J\mu\), \(J_p=V^{-1}\), and \(h_p=J_pm\). Define
\[
\begin{aligned}
\mu'&=-A\mu-\gamma\Sigma J_p(\mu-m),\\
\Sigma'&=-A\Sigma-\Sigma A^T+\gamma(\Sigma-\Sigma J_p\Sigma),\\
q_x'&=-\gamma q_x\left[\log(q_x/p_x^e)-\sum_zq_z\log(q_z/p_z^e)\right].
\end{aligned} \tag{E1.1}
\]
Categorical horizontal action is identity on the fixed event labels; no continuous rotation of finite labels is assumed.

The Gaussian Fisher metric on mean/covariance tangents is
\[
g((u,U),(v,W))=u^TJv+\tfrac12\operatorname{tr}(JUJW). \tag{E1.2}
\]
To derive it, differentiate the log density:
\[
S_{u,U}(z)=u^TJ(z-\mu)+\tfrac12[(z-\mu)^TJUJ(z-\mu)-\operatorname{tr}(JU)].
\]
The expectation of two scores is (E1.2): odd centered moments vanish, and four derivatives of \(\exp(t^T\Sigma t/2)\) give the fourth moment. Gaussian KL has mean differential \(J_p(\mu-m)\) and covariance differential \((J_p-J)/2\). Its inverse-Fisher gradient yields the vertical terms in (E1.1). On the finite simplex, \(g_q(u,v)=\sum_xu_xv_x/q_x\) on zero-sum tangents. Pairing the proposed centered gradient with each tangent gives the KL differential. Thus both are full-law Fisher velocities.

Inverse differentiation gives linear Gaussian natural equations:
\[
J'=A^TJ+JA+\gamma(J_p-J),\qquad
h'=A^Th+\gamma(h_p-h). \tag{E1.3}
\]

### Explicit solution, positivity, and uniqueness

Let \(\Phi'=-A\Phi\), \(\Phi(s_0)=I\). For \(\|A\|\leq M\), its successive integral expansion has \(k\)-th ordered-integral term bounded by \(M^k|s-s_0|^k/k!\). Uniform convergence permits integration term by term and gives a solution. Construct \(\Psi'=\Psi A\), \(\Psi(s_0)=I\), in the same way; \((\Psi\Phi)'=0\) proves invertibility. Both \(\Phi,\Phi^{-1}\) have norm at most \(e^{M|s-s_0|}\). The difference of two solutions has bound \(\|D\|_\infty M^kT^k/k!\) for every \(k\), hence is zero. Finitely many smooth pieces are composed.

Set
\[
\bar J=\Phi^TJ\Phi,\quad\bar h=\Phi^Th,\quad
\bar J_p=\Phi^TJ_p\Phi,\quad\bar h_p=\Phi^Th_p.
\]
Then \(\bar J'=\gamma(\bar J_p-\bar J)\), \(\bar h'=\gamma(\bar h_p-\bar h)\). For \(\Gamma(s)=\int_{s_0}^s\gamma(u)\,du\), both have explicit solution
\[
\bar\xi(s)=e^{-\Gamma(s)}\xi_0+
\int_{s_0}^s e^{-[\Gamma(s)-\Gamma(u)]}\gamma(u)\bar\xi_p(u)\,du,
\quad \xi\in\{J,h\}. \tag{E1.4}
\]
Differentiation verifies the equation. Multiplying a difference by \(e^\Gamma\) proves uniqueness. The weights are nonnegative and sum to one, because the integral of the scalar kernel is \(1-e^{-\Gamma(s)}\).

Compactness and target positivity give \(j_*>0\) with \(\bar J_p(s)\succeq j_*I\). Therefore
\[
\bar J(s)\succeq\min\{\lambda_{\min}(J_0),j_*\}I.
\]
Upper bounds follow likewise. Recovering \(\Sigma=\Phi\bar J^{-1}\Phi^T\), \(\mu=\Phi\bar J^{-1}\bar h\) gives a unique finite positive Gaussian throughout the interval. This real-arithmetic statement does not certify arbitrary floating-point conditioning.

For events, let \(r_j=\log(q_j/q_K)\), \(r_j^p=\log(p_j^e/p_K^e)\). Subtracting the log-density equations cancels the centering:
\[
r_j'=\gamma(r_j^p-r_j). \tag{E1.5}
\]
Formula (E1.4), without a connection, solves these coordinates. Positive continuous targets have bounded log odds on the compact interval; convex averaging preserves such a bound. If \(|r_j|\leq R\), softmax with last logit zero has every entry at least \(e^{-2R}/K\). This proves positivity, normalization, and uniqueness.

This is a two-parameter propagator for prescribed changing data:
\(\mathcal E(s_2,s_1)\mathcal E(s_1,s_0)=\mathcal E(s_2,s_0)\).
A one-parameter autonomous semigroup needs fixed data or an augmented external driver state. At fixed context and constant \(\gamma\), it reduces to the existing full_step formulas.

### Gauge behavior and objective balance

For an invertible \(C^1\) passive frame \(G(s)\), push recognition and target laws forward and set
\[
\widetilde A=GAG^{-1}-G'G^{-1}.
\]
Substitution in (E1.1) proves covariance; equivalently
\(\widetilde\Phi(s,s_0)=G(s)\Phi(s,s_0)G(s_0)^{-1}\).
The current compact representations use orthogonal \(G\). This does not identify the independent belief/model connections.

When target parameters and log evidence are C1 on the smooth piece, the objective balance in a parallel frame is
\[
\frac{d}{ds}\operatorname{KL}(q_s\Vert p_s)
=-\gamma\|\operatorname{grad}^F\operatorname{KL}\|_F^2
-E_{q_s}[\partial_s\log p_s]. \tag{E1.6}
\]
It follows by differentiating the integral, using normalization, and inserting the Fisher velocity; Gaussian derivatives are integrable polynomials under the admitted laws. For VFE also subtract the derivative of log evidence. Driving terms have no fixed sign, so within-arrival-target descent does not imply global moving-context descent.

**Failure condition:** target singularity/support loss, unbounded endpoint coefficients, or undeclared metric/connection/mobility. **Open gap:** mapping hypotheses to each adopted model family over a whole path. **Novelty fingerprint:** connection pullback and explicit scalar-kernel natural-coordinate solution. **Proposed disposition:** submit as a construction under stated assumptions for independent reconstruction.

## E2: Arrival-target splitting and continuum limit

**Family:** E2-transported-quadrature. **Kind:** LEMMA. **Target obligation:** consistency and convergence of transport-then-infer on a regular stratum. **Assumptions:** E1, exact prescribed segment transport, constant \(\gamma=\rho\geq0\), and Lipschitz parallel-frame targets \(\bar J_p,\bar h_p,r^p\), with constants \(L_J,L_h,L_r\). Refine the same prescribed path with maximum parameter step \(h_{\max}\).

For any one target coordinate array, the current rule in a common parallel frame is
\[
\xi_{i+1}=a_i\xi_i+(1-a_i)\xi_p(s_{i+1}),\quad
a_i=e^{-\rho\Delta s_i}. \tag{E2.1}
\]
The exact integral has defect
\[
R_i=\int_{s_i}^{s_{i+1}}\rho e^{-\rho(s_{i+1}-u)}
[\xi_p(u)-\xi_p(s_{i+1})]\,du,
\quad
\|R_i\|\leq\tfrac12\rho L_\xi(\Delta s_i)^2. \tag{E2.2}
\]
For \(\rho=0\) it is zero. Since \(a_i\in[0,1]\), induction yields
\[
\|\xi_i-\xi(s_i)\|
\leq\|\xi_0-\xi(s_0)\|
+\tfrac12\rho L_\xi(s_1-s_0)h_{\max}. \tag{E2.3}
\]
This is an analytical first-order bound. For merely continuous targets replace the Lipschitz estimate by their uniform modulus of continuity, obtaining a vanishing bound \(\rho(s_1-s_0)\omega_\xi(h_{\max})\).

Discrete precisions are positive convex combinations, sharing E1's lower and upper bounds. Since
\[
J^{-1}-K^{-1}=J^{-1}(K-J)K^{-1},\quad
\|J^{-1}-K^{-1}\|\leq j_*^{-2}\|J-K\|,
\]
bounded information vectors and transports turn (E2.3) into moment error \(O(h_{\max})\). The bounded softmax Jacobian gives the probability error. A piecewise exact frozen-target interpolation gives the same uniform order on a regular stratum.

For the existing connection \(\bar A=\bar K(x\,dy-y\,dx)/2\), \(\bar K\) is fixed, so its matrices commute along the path. A straight segment has scalar integral \(\det(c_0,c_1)/2\), hence
\[
T=G(c_1)\exp[-\bar K\det(c_0,c_1)/2]G(c_0)^T.
\]
This is the actual segment_transport expression. Subdivision preserves both integral and transport in real arithmetic.

Variable mobility is covered if updates use exact
\(\Delta\tau_i=\int_{s_i}^{s_{i+1}}\gamma(u)\,du\), replacing \(\rho\) in the bound by \(\|\gamma\|_\infty\). Current inference_rate is constant; the extension is not an implemented capability.

**Failure condition:** changing the path while refining, unresolved support events, unbounded target variation, or uncontrolled approximate transports. **Open gap:** a literal infinite sequence of float64 runs is not the limit theorem; existing availability underflow rejection excludes sufficiently close interior points. **Novelty fingerprint:** exact transport removes the matrix part, leaving positive quadrature with an explicit defect. **Proposed disposition:** submit E2 with regular-stratum scope.

## E3: Finite hybrid boundary evolution

**Family:** E3-conditional-kernel-jumps. **Kind:** CONSTRUCTION and LEMMA. **Target obligation:** normalized evolution with changing active dimension.

For old/new label sets \(I,J\), put \(S=I\cap J\), \(N=J\setminus I\), \(D=I\setminus J\). Require \(S\ne\varnothing\), a positive new reference \(\pi_J\), and prescribed invertible survivor transport \(T_S\). The boundary kernel retains the transported survivor value and samples entrants from the reference conditional:
\[
\mathcal B(q_I)(s,n)=(T_S{}_\#q_S)(s)\pi_J(n\mid s). \tag{E3.1}
\]
It is recognition-independent, normalized, and preserves the complete transported survivor marginal. For Gaussian reference moments \(m,V\), set
\[
B=V_{NS}V_{SS}^{-1},\quad b=m_N-Bm_S,\quad
C=V_{NN}-BV_{SN}.
\]
The output, before restoring label order, is
\[
\mu^+=\binom{\mu_s}{b+B\mu_s},\qquad
\Sigma^+=
\begin{pmatrix}
\Sigma_s&\Sigma_sB^T\\
B\Sigma_s&C+B\Sigma_sB^T
\end{pmatrix}. \tag{E3.2}
\]
Evaluating the positive form of \(V\) at \((-V_{SS}^{-1}V_{SN}v,v)\) proves \(C\succ0\). Equation (E3.2) is a congruence of \(\operatorname{diag}(\Sigma_s,C)\) by \(\begin{pmatrix}I&0\\B&I\end{pmatrix}\), hence SPD. Conditional cancellation in the density ratio gives
\[
\operatorname{KL}(\mathcal B(q_I)\Vert\pi_J)
=\operatorname{KL}(T_S{}_\#q_S\Vert\pi_S). \tag{E3.3}
\]
This compares neither old-context VFE nor old evidence. With no births, only marginalization and transport act. Empty survivors need an additional reset policy, excluded by the current API.

Assume a finite declared schedule \(s_0<e_1<\cdots<e_M<s_1\), E1 data with positive continuous one-sided limits on each inter-event stratum, and prescribed boundary kernels. Solving E1 and applying E3 recursively defines one normalized hybrid evolution. Unequal dimensions are never identified as the same SPD manifold.

Each fixed jump is affine in moments. If \(P_S\) selects old survivors and \(R\) restores new label order, define
\[
M=R\binom{I}{B}T_SP_S,\quad d=R\binom{0}{b},\quad
Q=R\begin{pmatrix}0&0\\0&C\end{pmatrix}R^T.
\]
Then
\[
\mu^+=d+M\mu^-,\quad\Sigma^+=Q+M\Sigma^-M^T, \tag{E3.4}
\]
and for two preparations
\[
\|\delta\mu^+\|\leq\|M\|\|\delta\mu^-\|,\quad
\|\delta\Sigma^+\|\leq\|M\|^2\|\delta\Sigma^-\|. \tag{E3.5}
\]
Combining these explicit constants with E2 and bounded coordinate conversions gives, by finite induction, global \(O(h_{\max})\) error when all boundaries are resolved and states are compared on corresponding one-sided spaces. The constant is a finite sum of stratum defect constants times later flow/jump Lipschitz constants. Positivity is independently proved above.

An isolated contact can require two ordered zero-clock jumps \(I^-\to I^0\to I^+\): open domains may exclude an agent exactly at contact even if it exists on both sides. Simultaneous events need a declared intermediate population or a single joint kernel. Distinct conditional-entry orders are not presumed equal.

Endpoint-delayed crossings require extra hypotheses: isolated transverse crossings; eventually the same ordered transition types; one-sided Lipschitz reference, target, and transport data; and delay \(O(h_{\max})\). The crossing cell is then an \(O(h_{\max})\) perturbation of the prescribed affine jump. The same induction gives convergence after aligning event times. Uniform error in raw time generally does not vanish for nonzero jumps because one trajectory has jumped during the delay interval and the other has not.

The current polygonal cover has finitely many vertical strip boundaries and finitely many line segments, so intersections and boundary-aligned intervals are computable from its geometry. The config validator requires crossed boundaries to be explicit waypoints; run_path classifies those endpoint populations but does not construct one-sided boundary states. Preserved original vertices retain contacts at those declared vertices. Convexity of each strip proves that a common survivor remains in its domain along a straight segment. These facts do not imply finite crossings for arbitrary smooth paths or arbitrary covers.

**Failure condition:** unresolved infinitely many crossings, empty survivors, missing one-sided reference limits, or unspecified contact ordering. **Open gap:** an event-resolved runtime schedule and explicit comparison norm. **Novelty fingerprint:** conditional Markov kernels across dimensions plus affine moment stability, independent of E1's mechanism. **Proposed disposition:** submit the finite hybrid theorem and its runtime obligations.

## Cross-lane questions

To coverage: map the whole-stratum positivity and one-sided-limit hypotheses onto the concrete local-tree targets. Are they available symbolically or only admitted at sampled float64 contexts? Identify any event schedule API beyond endpoint classification.

To root/reduced-event: does the smaller event state retain enough information for every future availability/coarse channel in its declared schedule, and how is the moving-channel derivative evaluated? A fixed global event space and active Gaussian departures have distinct types.

To scale: a reduced state needs a commuting boundary square. Identify any retained conditional or boundary statistic that makes that square exact.


## E4: Exact boundary descent to a Gaussian parent

**Family:** E4-jump-factorization. **Kind:** LEMMA and COUNTEREXAMPLE. **Target obligation:** the interface a reduced moving parent must satisfy at support changes.

Fix a boundary (E3.4) and full-row-rank parent maps \(F_-:\mathbb R^{n_-}\to\mathbb R^{m_-}\), \(F_+:\mathbb R^{n_+}\to\mathbb R^{m_+}\). For every full Gaussian old preparation, a single recognition-independent parent Markov kernel reproduces its complete output parent law if and only if
\[
\ker F_-\subseteq\ker(F_+M),
\quad\text{equivalently}\quad F_+M=L F_- \text{ for some }L. \tag{E4.1}
\]
If the condition holds, the kernel is
\[
Y_+=F_+d+L Y_-+\epsilon,\qquad
\epsilon\sim\mathcal N(0,F_+QF_+^T),
\]
with independent noise. This noise can be singular and still defines a normalized probability kernel. The output law is SPD when the full post-jump law is SPD and \(F_+\) has full row rank. Direct pushforward of E3.4 proves sufficiency.

For necessity choose \(v\in\ker F_-\) and compare positive Gaussian preparations with equal covariance and means \(\mu,\mu+v\). Their old parent laws are identical, while new parent means differ by \(F_+Mv\). The same parent kernel cannot produce different outputs from identical inputs. Therefore \(F_+Mv=0\). Given a right inverse \(R_-\) of \(F_-\), let \(L=F_+MR_-\). The decomposition \(z=R_-F_-z+(z-R_-F_-z)\), with second term in the kernel, proves factorization.

A scalar-agent departure gives an explicit obstruction. Let \(F_-=(1/2,1/2)\), let only agent one survive, use identity survivor transport, and take \(F_+=(1)\). The old laws
\[
q^0=\mathcal N((0,0),I_2),\qquad
q^\delta=\mathcal N((\delta,-\delta),I_2)
\]
share parent \(\mathcal N(0,1/2)\). After departure the parent laws are \(\mathcal N(0,1)\) and \(\mathcal N(\delta,1)\). Thus no parent-only update handles all these preparations. Retaining a survivor marginal or adequate conditional information removes this example's obstruction; time-step refinement does not.

**Failure condition for the obstruction:** additional retained data that distinguish the preparations, or a restricted preparation class. **Open gap:** determine which configured reduced state makes every required boundary square commute. **Novelty fingerprint:** exact kernel factorization for affine Gaussian support jumps. **Proposed disposition:** submit the equivalence and scoped counterexample.

## E5: Moving retained conditionals and rank boundaries

**Family:** E5-moving-augmentation. **Kind:** CONSTRUCTION and OBSTRUCTION. **Target obligation:** exact retained evolution across a changing coarse map without omitted geometric derivatives.

On a fixed active stratum take a \(C^1\), full-row-rank \(F(s)\) of constant dimensions. At any \(s_*\), choose constant rows \(N\) such that \(T(s_*)=[F(s_*);N]\) is invertible. Continuity of the determinant makes \(T(s)=[F(s);N]\) an invertible \(C^1\) completion in a neighborhood. A compact regular interval needs only finitely many such charts and their invertible overlap changes. This elementary construction makes no smoothness claim for the complete QR used by the fixed-context implementation.

A visible Gaussian and its complete affine hidden conditional reconstruct the full Gaussian in \((Y,X)=T(s)z\), by the innovation representation. Under this coordinate change E1 has connection
\[
A_T=TAT^{-1}-T'T^{-1} \tag{E5.1}
\]
and pushed target. Therefore compose, evolve the full state, and decompose in the next split defines exact augmented evolution. It retains the full state dimension and all cross covariances. A fixed-context conditional finite step alone omits \(T'\) and target variation if used without these additional operations.

For a prescribed parent connection \(A_Y\), define
\[
D_sF=F'+A_YF-FA.
\]
Product differentiation gives
\[
D_s\mu_Y=F D_s\mu+(D_sF)\mu,
\]
\[
D_s\Sigma_Y=F(D_s\Sigma)F^T
+(D_sF)\Sigma F^T+F\Sigma(D_sF)^T. \tag{E5.2}
\]
A covariance covariant derivative means ordinary derivative plus its two connection terms. If \(D_sF=0\), the geometry terms vanish; existence of such \(A_Y\) is a separate solvability condition already measured by connections.parent_compatibility. Retaining the full conditional resolves information loss but does not force this connection condition.

For a \(C^1\) recognition-independent row-stochastic finite channel \(C_s(y\mid x)\), define \(Q_s(x,y)=q_s(x)C_s(y\mid x)\). Exact differentiation yields
\[
Q_s'(x,y)=q_s'(x)C_s(y\mid x)+q_s(x)C_s'(y\mid x). \tag{E5.3}
\]
On any defined parent row,
\[
\begin{aligned}
q_{Y,s}'(y)
={}&-\gamma q_{Y,s}(y)\left[
\log\frac{q_{Y,s}(y)}{p_{Y,s}(y)}
+d_s(y)-\operatorname{KL}(q_s\Vert p_s)\right]\\
&+\sum_x q_s(x)C_s'(y\mid x), \tag{E5.4}
\end{aligned}
\]
where \(d_s(y)=\operatorname{KL}(q_s(\cdot\mid y)\Vert p_s(\cdot\mid y))\), using the same channel for both conditionals. Substitution of E1 and the existing conditional log-ratio identity proves E5.4. Full augmentation reconstructs \(q_s\) by summing \(Q_s\), so it also determines the second term. Frozen-channel conditional interpolation alone does not propagate a changing channel.

The unnormalized masses \(Q,\eta,\alpha\) and the parent mass can be smooth through zero columns when \(q_s,C_s\) are smooth. A conditional \(\beta=\eta/\alpha\) exists only on \(\alpha>0\). Quotient derivatives have bounds on an occupied compact interval with \(\alpha\geq\alpha_*>0\), but no bound is inherited as \(\alpha\downarrow0\).

For \(\Sigma\succ0\), the covariance \(F\Sigma F^T\) is positive definite exactly when \(F\) has full row rank: its quadratic form is \((F^Tv)^T\Sigma(F^Tv)\). Rank loss therefore leaves the fixed-coordinate SPD manifold. Zero padding records a law on smaller support, not an SPD continuation. A changing support, its reference measure, and its transition policy require separate typing, as in E3.

**Failure condition:** rank loss, absent conditional rows, incompatible parent connection, or suppressing split/channel derivatives. **Open gap:** a moving-split runtime API with admitted charts and derivatives. **Novelty fingerprint:** moving completion and explicit channel derivative, rather than a frozen conditional overlap. **Proposed disposition:** submit E5 as an exact augmentation with its regularity boundaries.

## E6: Criteria and error control for a reduced moving state

**Family:** E6-projectability-and-error. **Kind:** LEMMA and OBSTRUCTION. **Target obligation:** precise closure conditions for a smaller retained state.

For fine evolution \(x'=V_s(x)\) and differentiable retained state \(z=\pi_s(x)\), a deterministic reduced velocity reproduces every fine preparation only if
\[
\partial_s\pi_s(x)+D\pi_s(x)V_s(x)
\]
is constant on every fiber of \(\pi_s\). If it is constant and the resulting reduced velocity \(\bar V_s(z)\) is locally Lipschitz, the projected fine solution is a reduced solution. Uniqueness follows directly: the difference of two solutions obeys \(e(t)\leq L\int_0^t e(u)\,du\), whose iteration gives \(\|e\|_\infty(Lt)^k/k!\to0\). The boundary condition is separate:
\[
\pi_+\mathcal B=\bar{\mathcal B}\pi_-. \tag{E6.1}
\]
For deterministic Gaussian parents, E4 supplies its exact criterion. Continuous projectability alone and boundary factorization alone do not imply one another.

Existing modal compression retains parent endpoints and selected modal arrays for fixed preparation, fixed target whitening, and fixed parent map. It is not a universal moving state. For example, let \(p=\mathcal N(0,I_2)\), \(F=(1,0)\), and \(q^\delta=\mathcal N((0,\delta),I_2)\). The zero-retained-mode representation is identical for all \(\delta\), while changing the map to \(F_+=(0,1)\) yields different visible means. No function of those identical stored states and the same new map reconstructs every result. This does not exclude sufficient statistics for a restricted future schedule.

An exact moving reduced interface must declare its retained family, sufficient statistics or conditionals, allowed targets and channel schedule, geometric derivatives or exact transports, and boundary kernels. It must prove continuous projectability and E6.1 for the allowed operations. Keeping all conditional information gives an exact sufficient state but not a memory reduction.

For approximation, fix a shared coordinate domain and norm. If \(\bar V_s\) is \(L\)-Lipschitz and a reconstructed trajectory obeys \(\widehat z'=\bar V_s(\widehat z)+r_s\) with \(\|r_s\|\leq\varepsilon_s\), then
\[
\|\widehat z(t)-z(t)\|
\leq e^{L(t-s_0)}\|\widehat z(s_0)-z(s_0)\|
+\int_{s_0}^t e^{L(t-u)}\varepsilon_u\,du. \tag{E6.2}
\]
To prove this, integrate the difference, substitute the resulting integral inequality repeatedly, and sum the exponential series. The remaining \(k\)-fold integral is bounded by a constant times \((LT)^k/k!\), which vanishes. With finitely many boundaries, use \(e^+\leq K_je^-+\delta_j\) for a \(K_j\)-Lipschitz jump and jump error \(\delta_j\), then recurse between copies of E6.2. Uniform SPD/support margins are needed for any metric or coordinate conversions entering these constants.

A fixed-target omitted-mode rate bound does not bound this residual with moving targets or maps. That requires derivatives of target whitening, retained coefficients and channels, plus recompilation and boundary errors. Calibration alone is not a uniform-time bound; an all-time bound for one fixed modal preparation does not cover an undeclared context family.

**Failure condition:** identical retained states with unequal projected velocities/jumps, or an uncontrolled approximation residual. **Open gap:** implement a chosen smaller family with its declared allowed operations and error obligation. **Novelty fingerprint:** separate continuous and hybrid projectability, plus an explicit perturbation estimate. **Proposed disposition:** submit criteria and scoped obstructions, not general reduced closure.

## E7: Continuous driven fixed-conditional event family

**Family:** E7-fixed-conditional-driven-bridge. **Kind:** LEMMA and CONSTRUCTION. **Parents:** E1 and the independent finite family in [reduced-event.md, Driven finite history and approximation bound](reduced-event.md#driven-finite-history-and-approximation-bound). **Target obligation:** its continuous-forcing counterpart and its moving-channel interface.

Fix the finite surjection \(g:X\to B\) and positive normalized within-bin conditionals \(\rho_x\). Let \(Q_r(x)=r_{g(x)}\rho_x\). Hold \(g,\rho\) fixed for the entire path. Assume \(p_s(x)>0\) is continuous on a compact interval, with nonnegative continuous bounded \(\gamma(s)\), and start the fine and restricted evolutions from \(q_0=Q_{r_0}\). The singleton case is included; a one-bin family has fixed \(r=1\).

Define
\[
v_s(x)=\log[p_s(x)/\rho_x],\quad
\ell_s(b)=\sum_{g(x)=b}\rho_xv_s(x),\quad
\delta_s(x)=v_s(x)-\ell_s(g(x)),\quad
D_s=\max_x\delta_s(x)-\min_x\delta_s(x).
\]
All are continuous; if \(p_s\) is Lipschitz and uniformly positive, they are Lipschitz. The restricted Fisher metric and KL decomposition derived in reduced-event.md imply that its log odds obey
\[
[\log(r_b/r_{b_*})]'=\gamma[
\ell_s(b)-\ell_s(b_*)-\log(r_b/r_{b_*})]. \tag{E7.1}
\]
E1.4 gives an explicit unique positive solution, just as for the fine event family.

Here is an independent reconstruction of the finite recurrence. A full step contributes
\[
\log q_i=a_i\log q_{i-1}+(1-a_i)\log p_i-\log Z_i^q.
\]
A restricted step, after adding \(\log\rho\), contributes
\[
\log Q_i=a_i\log Q_{i-1}
+(1-a_i)[\ell_i(g(x))+\log\rho_x]-\log Z_i^r,
\]
where the normalization of the restricted target is absorbed into the scalar. Their subtraction gives
\[
e_i(x)=a_i e_{i-1}(x)+(1-a_i)\delta_i(x)+k_i,\quad
e_i=\log(q_i/Q_i), \tag{E7.2}
\]
with \(k_i\) independent of \(x\). Thus the sign and weight of the forcing in the root's recurrence are correct.

Directly subtracting the continuous equations gives
\[
e_s'(x)=-\gamma e_s(x)+\gamma\delta_s(x)+k_s
\]
with a scalar \(k_s\), hence
\[
e_s(x)=e^{-\Gamma(s)}e_0(x)
+\int_{s_0}^s e^{-[\Gamma(s)-\Gamma(u)]}\gamma(u)\delta_u(x)\,du
+\kappa_s. \tag{E7.3}
\]
Oscillation removes \(\kappa_s\). Max-minus-min is subadditive and, for nonnegative kernels, its value on an integral is at most the integral of its value. Therefore
\[
\operatorname{osc}(e_s)\leq H_s,\qquad
H_s=e^{-\Gamma(s)}H_0+
\int_{s_0}^s e^{-[\Gamma(s)-\Gamma(u)]}\gamma(u)D_u\,du,
\quad H_0=0. \tag{E7.4}
\]
Equivalently \(H'=\gamma(D-H)\). An initial mismatch is also allowed if \(H_0\geq\operatorname{osc}(e_0)\).

For completeness, let \(L=q/Q\), \(m=\min L\), \(M=\max L\). Normalization gives \(E_QL=1\). Convexity of \(|L-1|\) bounds it by its chord over \([m,M]\), giving
\[
\operatorname{TV}(q,Q)\leq\frac{(M-1)(1-m)}{M-m}.
\]
For \(M/m=R=e^{\operatorname{osc}(e)}\), the right side is
\([R+1-Rm-1/m]/(R-1)\). Since \(Rm+1/m\geq2\sqrt R\), it is at most
\((\sqrt R-1)/(\sqrt R+1)\), with the case \(R=1\) obtained directly. Thus
\[
\operatorname{TV}(q_s,Q_{r_s})\leq\tanh(H_s/4). \tag{E7.5}
\]
For any common row-stochastic channel \(C_s\), even with structural zeros and without continuity in \(s\),
\[
\| (q_s-Q_{r_s})C_s\|_1
\leq\sum_x|q_s(x)-Q_{r_s}(x)|\sum_yC_s(y\mid x)
=\|q_s-Q_{r_s}\|_1. \tag{E7.6}
\]
So E7.5 bounds every current readout. Smooth readout/rate claims additionally require \(C_s'\) and E5.3. The law-error theorem itself does not need a derivative of the channel and gives no conditional-attention bound at zero occupancy.

With exact clock increments, finite arrival-target updates for the full log odds, restricted log odds, and \(H\) are all the scalar quadrature in E2. Therefore Lipschitz forcing proves first-order convergence to E7.1 and E7.4; continuity gives the corresponding modulus-of-continuity bound. This supplies the continuous limit without numerical refinement evidence.

At an on-family state \(q=Q_r\), the fine velocity minus the embedded restricted velocity is \(\gamma Q_r(x)\delta_s(x)\). Its Fisher norm squared is
\[
\gamma^2\sum_b r_b\sum_{g(x)=b}\rho_x\delta_s(x)^2. \tag{E7.7}
\]
Indeed each bin average of \(\delta_s\) is zero, so its score is orthogonal to every bin-mass tangent and the squared norm follows directly. This identifies the discarded within-bin score. The fixed family is invariant for all on-family preparations wherever \(\gamma>0\) precisely when every target conditional equals \(\rho\): then all \(\delta_s=0\), and conversely zero residual forces this equality by positive weights. Nonzero forcing gives an approximation controlled by E7.4, not exact parent autonomy.

**Failure condition:** changing \(g\) or \(\rho\), losing target positivity, comparing outputs through different channels, or interpreting TV as a rate/conditional-attention certificate. **Open gap:** the finite implementation and its source-bound tests remain root's responsibility; the floating evaluation of E7.4 is not an outward-rounded certificate. **Novelty fingerprint:** a hybrid of E1's exact forcing solution and the fixed-conditional mixture's log-ratio oscillation control, with a separate channel-contraction interface. **Proposed disposition:** submit E7 as the requested cross-lane bridge for independent reconstruction.

## Necessary executable seams and discriminating controls

The existing full_step functions are E2's local substeps and gaussian_boundary.reconcile is E3's jump. A theorem-backed moving controller needs an explicit schedule of one-sided population labels and exact-contact intermediate populations, entering references, and clock increments. Reports should distinguish resolved scheduling from endpoint classification.

Choose a moving target affine in parallel natural coordinates to obtain an analytic E1.4 oracle. Tiny controls should compare it with splitting and its actual first-order error constant, exercise zero-rate exact transport, passive chart changes, one resolved crossing, an exact contact, and a boundary-aligned interval. Compare E4's nonfactorizing departure with a factorizing case. Any moving split/channel control must have nonzero \(F'\) or \(C'\), so omitting E5's geometry changes the answer.

The reduced-event interface can answer arbitrary current readouts using the fixed stored \(\rho\) and evolving \(r\): form the induced row-stochastic bin channel
\[
\widehat C_s(y\mid b)=\sum_{g(x)=b}\rho_xC_s(y\mid x),\qquad
Q_{r_s}C_s=r_s\widehat C_s.
\]
This identity permits direct bin-state readout without storing a dynamic fine law. If differentiable,
\((r\widehat C)'=r'\widehat C+r\widehat C'\).
It does not remove the immutable fine-carrier data needed to construct \(\widehat C_s\) for arbitrary future channels. The smaller number of evolving coordinates is therefore distinct from total runtime or compiler storage.

## Cross-lane answers and remaining questions

Answer to [reduced-event.md, Failure tests and cross-lane questions](reduced-event.md#failure-tests-and-cross-lane-questions): E7 reconstructs the driven finite recurrence and supplies the continuous counterpart under positive continuous finite targets and bounded nonnegative continuous mobility; Lipschitz log-target forcing gives a first-order arrival-target limit. Changing channels require no temporal regularity for each-time TV contraction. Their rate formula requires their derivative, and occupied conditional rates additionally need an occupancy margin.

Answer to the initial evolution question about smaller event state: the fixed \(g,\rho\) family can evaluate any externally supplied current channel through \(\widehat C_s\), and E7.5 compares it with the full driven evolution. It is an exact restricted flow with a controlled approximation to the full flow, rather than a generally invariant subfamily. Gaussian support jumps retain their independent E4 obligation.

Coverage and scale questions in the earlier Cross-lane questions section remain pending.


## Source admission and final cross-lane readback

Revision 3 incorporates [event-closure.md, Readback to Evolution revision 1](event-closure.md#readback-to-evolution-revision-1), followed by inspection of the referenced local-tree and configuration formulas. It corrects the earlier incomplete route trace: moving_context_config.validate_config already requires every crossed strip boundary to be an original waypoint. It rejects a segment whose x interval strictly contains any of \(-0.8,-0.1,0.1,0.8\), and refinement preserves those vertices exactly. Its configured refinement set is bounded to 1 and 2. The convergence results concern the real-arithmetic scheme under their stated mesh hypotheses; they are not a claim that this bounded producer executes an arbitrary mesh sequence. Direct run_path calls do not by themselves create the stronger one-sided event schedule.

The current Gaussian one-sided positivity premise can be supplied analytically. In local_tree.gaussian_inputs each \(4\)-dimensional node factor \(L_i\) is lower triangular with diagonal \(1+0.1\cos(\cdot)\geq0.9\), bounded off-diagonal entries, and covariance \(L_iL_i^T\). The adjacent standardized correlation satisfies \(0\leq\rho<0.324\) for the prior and a smaller bound for initial recognition. On any active chain, the innovation construction
\[
z_{i+1}-\mu_{i+1}
=\rho L_{i+1}L_i^{-1}(z_i-\mu_i)
+\sqrt{1-\rho^2}\,L_{i+1}\epsilon_{i+1},
\qquad \epsilon_{i+1}\sim\mathcal N(0,I_4)
\]
with independent innovations reproduces all prescribed node and adjacent-pair laws. Its invertible triangular innovation map proves a positive joint. The junction-tree assembly uses those same factors and therefore yields that joint. Fixed active chains have at most three nodes; all matrix entries and inverses are smooth and bounded on compact context sets, including one-sided boundary limits.

Observation noise is \(R=0.6I_2\), so the posterior precision satisfies
\[
J_{\mathrm{post}}=J_{\mathrm{prior}}+H^TR^{-1}H\succ0.
\]
The context-dependent H, observation, and node factors have smooth finite one-sided limits. Availability windows extend smoothly by zero in real arithmetic: every derivative on the interior is an exponential \(\exp(-1/t)\) times a finite rational expression in the positive boundary-distance variable \(t\), and \(\exp(-1/t)t^{-m}\to0\) for every finite \(m\). The last limit follows by bounding the exponential series below with its \((m+1)\)-st term. Hence these targets satisfy E1/E3's positive one-sided-limit assumptions on each finite compact path piece. This supplies no SPD law on a padded absent coordinate.

The event positivity premise is likewise symbolic. The edge tables are positive mixtures of unary product laws and their diagonal coupling, with mixture weights below \(0.308\), and the unary law is a softmax of finite smooth logits. The observed Bernoulli likelihood is strictly positive and multiplies only the existing edge \((0,1)\). The finite normalized joint and its target are therefore smooth and strictly positive on every compact context path, independent of Gaussian availability. Floating underflow guards remain distinct from these real-arithmetic conclusions.

Answer to [event-closure.md, Cross-lane questions](event-closure.md#cross-lane-questions): its exact log-affine event family is compatible with E1 and is stronger for the current event model than E7's approximate fixed-conditional family. For \(q_\theta(x)\propto h(x)e^{\theta\cdot T(x)}\), an in-family target \(q_{\eta(s)}\) gives \(\theta'=\gamma(\eta-\theta)\). E1.4 applies componentwise. Its 39-coordinate chain statistics encode all node and existing-edge terms in the actual local event construction, including the observed edge likelihood. The affine span is therefore invariant under the full Fisher evolution. This exact reduction retains the microscopic event law and so supports every current or future externally supplied stochastic readout; it is not a claim of visible-parent autonomy. The stronger modulus bound in event-closure.md follows directly because the forcing-kernel mass over the whole interval is \(1-e^{-\Gamma}\), whereas E2 used a looser sum of local defects. The bounds are consistent.

E7 remains a distinct valid approximation for fixed within-bin conditionals and out-of-family driven targets. Its scope is not expanded by the exact 39-coordinate chain closure, and its extra immutable storage need not be adopted when the exact current-model family is available.

Answer to [coverage.md, Cross-lane questions](coverage.md#cross-lane-questions): E1-E3 concern motion through U and support changes along that motion, not a nonidentity RG base map. The proposed product-base descent \(U\times I\to U\) is a separately typed, compatible redundant-coordinate construction. With all data pulled back and independent of the discarded coordinate, the pulled-back connection evaluated on \((c'(s),z'(s))\) equals the original connection on \(c'(s)\); targets, activity and boundary data are the same. Thus E1-E3 descend along that base map by direct substitution. No informative context direction is eliminated by this witness.

Answer to [scale.md, Cross-lane questions](scale.md#cross-lane-questions): hierarchical scale \(n\log2\) is kept separate from both s and the allocated inference clock. E4 requires a retained boundary statistic or conditional if its Gaussian jump is to be composed with a lossy state. For the scale lane's finite Gibbs boundary table, exact interior elimination gives the retained endpoint law at a fixed scale; a future driven evolution or population-boundary rule must still be supplied before invoking E1-E6. No identification with fixed-forward-channel variational minimization is used here; actual joint conditional corrections remain present.

## Remaining obligations for this lane

The mathematical submissions E1-E7 await independent reconstruction. Their implementation seams are stated above. The current finite polygonal validator already resolves the locations of strip crossings, but a one-sided hybrid state representation is still needed for a theorem-backed continuum API. Any adopted arbitrary-cover or arbitrary-path extension must supply finite event admission or a separate accumulation construction. A compressed Gaussian moving state must satisfy E4/E6 or report its residual; the fixed-target interval certificate cannot be reused without its hypotheses. Full-conditional augmentation is exact and unreduced. The current event model has the separate exact 39-coordinate family identified by the event lane.

This lane does not claim a general continuum field theory, an interacting RG fixed point, nonflat gauge-matter universality, a physical time identification, or completed program closure. Those are separate typed obligations rather than consequences of the finite evolution formulas.


## Additional proof details for reconstruction

For E1.6, compact bounds on means and SPD covariance eigenvalues give a common integrable Gaussian envelope times a polynomial for the differentiated density and KL integrands on each \(C^1\) piece. This justifies differentiation under the Gaussian integral. All event calculations differentiate only finite sums.

The E3 boundary kernel is also gauge covariant. Under separate block-diagonal old/new passive frames \(G_-,G_+\), use \(T_S'=G_{+,S}T_SG_{-,S}^{-1}\). Reference conditioning gives \(B'=G_{+,N}BG_{+,S}^{-1}\), \(b'=G_{+,N}b\), \(C'=G_{+,N}CG_{+,N}^T\). After restoring label order, E3.4 therefore has
\[
M'=G_+MG_-^{-1},\qquad d'=G_+d,\qquad Q'=G_+QG_+^T.
\]
Substituting the transformed input moments proves that the output is precisely the new-frame pushforward. This is the same typed transformation law as the existing boundary function, not a choice of a connection from its input law.

In E5, \(T\) is a coordinate representation of the retained joint, and \(A_T\) represents the existing connection in those coordinates. A general completion matrix is not asserted to be a compact-group gauge transformation or a newly induced principal connection on the visible parent. Both recognition and target densities acquire the same inverse absolute determinant under this invertible coordinate map, so the Jacobian cancels in their KL ratio. Pushing the normalized generative law with the observation unchanged preserves evidence by change of variables. Conditional completion therefore preserves the posterior-KL form of VFE with the same declared evidence; no determinant term has been silently dropped from an individual transformed density.

