<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->
# Scale lane: exact retained actions and an interacting hierarchical witness

Revision 1 is complete for the independent verification wave. This file proposes derivations for independent verification; it assigns no ledger closure state. Only this Markdown file is owned. No scientific code, tests, experiments, GPU runs, or publication were executed.

## Existing results and source boundary

Theory/07_general_renormalization.tex, “Exact measure-pair arrows,” already proves $(\rho,m)\mapsto(\rho C,mC)$ composition, evidence preservation, and $\pi'=mC/M=\pi C$. Its scale-category section requires comparison maps before autonomy. Theory/SPEC.md retains that distinction. complete_carrier_effective_action_model.py implements rational reference/evidence pairs, common-channel pushes, reverse conditionals, action updates and Hessians; complete_carrier_effective_action_composition.py implements their towers. These are inputs, not missing theorems rediscovered.

The earlier docs/derivations/2026-08-12-elbo-to-effective-section-action/evidence/exact-contraction-proof.md concerns deterministic maps and posterior-conditional lifts. It does not assert the false stochastic constrained identity below. Existing critical_incidence_model.py and critical_blocking_model.py supply finite Ising images and boundary tensors. Their inspected interfaces do not establish the homogeneous autonomous hierarchy constructed here. Existing repeated_scale diamond catalogs are gauge-record fixtures, not this recursive Ising graph.

The Research concept “Renormalization group flow” and source note berker-1979-hierarchical-lattice-rg suggest hierarchical branching. Their broad narrative claims are not premises: arbitrary declared marginalizations compose on any finite substrate. Hierarchy here supplies closure in one fixed boundary-action family and a comparison between scales.

The primary article [Pinho, Haddad, and Salinas, 1997/1998](https://arxiv.org/pdf/cond-mat/9709303), equations (7)–(10), gives the diamond recursion in $x=\tanh K$, with uniform restriction $x'=2x^2/(1+x^4)$. We reproduce the finite sums, normalization, fixed-point proof, and stability below. [Berker and Ostlund, 1979](https://doi.org/10.1088/0022-3719/12/22/035) is historical context from the inspected wiki bibliography; its full text was inaccessible. No imported theorem replaces the derivations.

## Mechanism-diverse portfolio

SCALE-FINITE-BOUNDARY retains all interface variables in arbitrary positive finite factor graphs. It gives exact action recursion, not low-dimensional closure or a fixed point.

SCALE-DIAMOND-Z2 uses two serial edges in each of two parallel branches. Spin reversal closes the retained action on a constant plus one interaction. Recursive graph substitution supplies an autonomous nonzero fixed point.

SCALE-SERIES-ONLY has one two-edge branch. It closes but has no positive interacting fixed point, isolating the obstruction removed by branching.

SCALE-STOCHASTIC-CONTRACTION compares arbitrary joint lifts with fine-law optimization under a fixed forward stochastic channel. A feasible two-state example gives a strict gap.

These are different mechanisms, not Gaussian fixed rays or differently named finite catalog cycles. The sections below give each family's types, derivation, falsifier, unresolved gap, and proposed disposition.

## SCALE-FINITE-BOUNDARY: full finite actions

**Kind:** CONSTRUCTION/LEMMA. **Obligation:** exact action, normalization, retained interaction, and finite composition. **Quantifiers/types:** every nonempty finite product $X=\prod_{v\in V}X_v$, positive factor table $W(x)=\prod_a\psi_a(x_a)$, and recognition-independent row-stochastic $C:X\rightsquigarrow Y$, with nonempty finite $Y$ and counting measures. Then $Z=\sum_xW(x)>0$.

Set $W_C(y)=\sum_xW(x)C(y\mid x)$, $S_C(y)=-\log W_C(y)$ on positive atoms and $+\infty$ otherwise, and $P_C=W_C/Z$. Row normalization gives $\sum_yW_C(y)=Z$. For a composable channel $D$,
$$
W_{CD}(z)=\sum_{x,y}W(x)C(y\mid x)D(z\mid y)
=\sum_yW_C(y)D(z\mid y).
$$
Finite summation proves exact composition, with every additive constant retained. The normalized action is $-\log P_C=S_C+\log Z$.

For disjoint block interiors $I_B$, choose retained variables $R$ so every factor lies wholly in $R$ or in one $I_B$ together with its boundary $\partial B\subseteq R$. Assign every factor once. Then
$$
W(x)=\Psi_R(r)\prod_BW_B(x_{I_B},r_{\partial B}),
A_B(r_{\partial B})=\sum_{x_{I_B}}W_B(x_{I_B},r_{\partial B}),
$$
$$
S_R(r)=-\log\Psi_R(r)-\sum_B\log A_B(r_{\partial B}).
$$
Distributing finite sums over conditionally disjoint interiors proves the formula. Shared boundary variables remain once; their factors are not duplicated. Nested elimination agrees by associativity. A factor crossing proposed interiors requires larger retained boundaries or merged blocks; omission is not admitted.

**Failure condition:** nonnormalized or recognition-dependent channels treated as fixed, omitted factors, or discarded generated boundary functions. **Open gap:** efficient representation and restricted-family closure. **Novelty fingerprint:** explicit retained tables and factor ownership mapping inherited theory. **Disposition:** inherited theorem/interface mapping for independent verification.

## SCALE-DIAMOND-Z2: finite graph and exact recursion

**Kind:** CONSTRUCTION. **Obligation:** executable interacting RG witness. **Types:** $D_0$ is one edge with distinguished left/right endpoints. $D_{n+1}$ joins four disjoint copies of $D_n$ as two serial pairs whose outer endpoints are identified in parallel. No other vertices are identified. Spins are $\pm1$; finite graphs use counting measure. The edge count is $4^n$, vertex count is $2+(2/3)(4^n-1)$, and endpoint graph distance is $2^n$, by induction on graph substitution.

For $A>0$, $0\leq t<1$, let
$$
w_{A,t}(\sigma,\tau)=A(1+t\sigma\tau).
$$
It is a zero-field ferromagnetic Ising interaction with $K=\operatorname{atanh}t$, since $1+t\sigma\tau=e^{K\sigma\tau}/\cosh K$. $A=\cosh K$ gives the usual edge Boltzmann weight; $A=1$ is another explicit additive-action convention.

Let $W_n(\sigma_L,\sigma_R)$ sum all interior-spin weights of $D_n$ at fixed endpoints. For one two-edge branch,
$$
\sum_{s=\pm1}A(1+t\sigma_Ls)A(1+ts\sigma_R)
=2A^2(1+t^2\sigma_L\sigma_R).
$$
Multiplying the independent branch sums gives
$$
W'=4A^4(1+t^2\sigma_L\sigma_R)^2
=4A^4(1+t^4)\left(1+\frac{2t^2}{1+t^4}\sigma_L\sigma_R\right).
$$
Thus, including the additive normalization,
$$
A'=4A^4(1+t^4), t'=f(t)=\frac{2t^2}{1+t^4},
$$
$$
a'=4a+\log4+\log(1+t^4), a=\log A.
$$
Positivity is preserved: $f(t)\geq0$ and $1-f(t)=(1-t^2)^2/(1+t^4)>0$. The full endpoint partition and action are
$$
Z_n=4A_n, S_n(\sigma_L,\sigma_R)=-\log A_n-\log(1+t_n\sigma_L\sigma_R),
$$
$$
a_n=4^na_0+\sum_{j=0}^{n-1}4^{n-1-j}[\log4+\log(1+t_j^4)].
$$

**Direct versus staged proof.** Every $D_n$ copy has table $W_n$ by induction. Substituting four such tables and summing the two middle spins is exactly the sum over all interior assignments of $D_{n+1}$, each appearing once. Hence recursion and direct elimination agree at every finite depth, including $A_n$ and $Z_n$. Alternatively, eliminate the newest vertices of fixed $D_N$ one generation at a time: the remaining graph is $D_{N-1}$ with updated edge weights. Deterministic forgetting kernels compose and preserve the full partition and endpoint marginal.

Autonomy additionally identifies each coarse edge with the same two-spin edge template. The nonlinear map $f$ includes construction from four copies; it is not one fixed linear stochastic map on an isolated two-spin probability vector.

The ambient simultaneous-spin-reversal-invariant two-boundary-spin action space is exactly $S(\sigma,\tau)=c-K\sigma\tau$. Its quotient by constants is one-dimensional. This proves closure rather than assuming a truncated pairwise ansatz. It does not prove pairwise closure with more boundary spins or symmetry-breaking fields.

**Failure condition:** fields, extra edges, heterogeneous cells, or integrated links require their own boundary tables. **Open gap:** general geometries and nonflat gauge dynamics. **Novelty fingerprint:** classical hierarchy with full normalization and exact finite-law typing. **Disposition:** independent proof check, then bounded exact implementation.


## SCALE-DIAMOND-FIXED: existence, interaction, and stability

**Kind:** LEMMA with algebraic witness. **Obligation:** an interacting fixed point and its scoped stability. **Quantifier:** exactly one $t_*\in(0,1)$ solves $f(t_*)=t_*$, besides admitted $t=0$ and limiting $t=1$. Define $g(t)=t^3+t^2+t-1$. Factorization gives
$$
f(t)-t=\frac{t(1-t)g(t)}{1+t^4}.
$$
Since $g'(t)=3t^2+2t+1>0$ for $t\geq0$, $g(1/2)=-1/8$, and $g(3/5)=22/125>0$, the intermediate value theorem and monotonicity give a unique $t_*\in(1/2,3/5)$. This is an existence and uniqueness proof without a numerical root.

The normalized endpoint law is $P_t(\sigma,\tau)=(1+t\sigma\tau)/4$. Both marginals are uniform and $\mathbb E[\sigma\tau]=t$. Its mutual information is
$$
I_t=\frac{1+t}{2}\log(1+t)+\frac{1-t}{2}\log(1-t)>0(0<t<1),
$$
because $I_0=0$ and $I'_t=\operatorname{atanh}t>0$. Thus $P_{t_*}$ is not an independent product. Every finite-depth graph law is strictly positive and interacting, with this same two-root marginal. “Fixed” refers to the normalized root action class and homogeneous graph-replacement identification, not identical full laws on changing vertex catalogs.

At the root, $t_*^4=2t_*-1$, whence $A'=8t_*A^4$ and $a'=4a+\log(8t_*)$. One can retain the entire recursion or choose the fixed additive representative $a_*=-\log(8t_*)/3$. The additive eigenvalue four is a normalization redundancy, not another physical interaction instability. For $A_0=1$,
$$
A_n=(8t_*)^{(4^n-1)/3}, Z_n=4(8t_*)^{(4^n-1)/3}.
$$
The exponent is an integer, so this is an exact algebraic expression at each finite depth.

On the interaction quotient,
$$
f'(t)=\frac{4t(1-t^4)}{(1+t^4)^2},
\lambda_*=f'(t_*)=\frac{2(1-t_*)}{t_*}.
$$
The isolating interval gives $4/3<\lambda_*<2$: the fixed point repels homogeneous coupling perturbations. Below $t_*$, $0<f(t)<t$; monotone bounded iterates converge, and continuity forces their limit to the only fixed point below $t_*$, zero. Above $t_*$, iterates increase and converge to one. The latter is a singular zero-temperature boundary law, not a finite positive member.

The declared geometric scale is $b=2$ from endpoint graph distance; edge-count dilation is four, and the combinatorial dimension ratio is $\log4/\log2=2$. Linear perturbations scale as $\lambda_*^n$. Define the scheme's discrete eigen-scaling index $y_t=\log\lambda_*/\log2$. Identifying $1/y_t$ with a spatial correlation-length exponent needs a specified correlation length and a scaling theorem; neither is assumed. A $C^1$ invertible coupling-coordinate change conjugates the map, preserving its fixed-point derivative by the chain rule. Changing the graph replacement is a different scheme and is not covered. No continuous beta generator or Euclidean Ising universality is claimed.

**Failure condition:** fixed-root or derivative equations fail, or the endpoint law is a product. **Open gap:** nonhomogeneous spectrum, general universality, continuum limits, physical-scale interpretation. **Novelty fingerprint:** explicit cubic witness and finite-depth normalizer for the classical mechanism. **Disposition:** direct derivation verification; no general-program closure.

## SCALE-DIAMOND-GAUGE: flat background and flux obstruction

**Kind:** CONSTRUCTION and scoped COUNTEREXAMPLE. **Types:** compact group $G=\mathbb Z_2$, spins $\sigma_v=\pm1$, fixed graph links $u_{vw}=\pm1$, frame changes $\chi_v=\pm1$. Define
$$
\sigma_v'=\chi_v\sigma_v, u_{vw}'=\chi_vu_{vw}\chi_w,
w_{vw}=A(1+t\sigma_vu_{vw}\sigma_w).
$$
Every weight is invariant and counting measure is preserved. A two-edge branch sums to $2A^2(1+t^2h\sigma_L\sigma_R)$, where $h=u_{Ls}u_{sR}$ transforms as $h'=\chi_Lh\chi_R$.

If the two branch products agree, $h_1=h_2=u'$, the preceding diamond recursion holds with the dressed variable $\sigma_Lu'\sigma_R$. This is the zero-flux condition $h_1h_2=1$. If every cycle at every finite hierarchy has product one, the coarse path-product rule preserves flatness. On a connected graph a spanning tree constructs vertex signs taking all links to one: fix the root sign, propagate along unique tree paths, and use each cycle constraint for non-tree edges. Thus the fixed point is a gauge-covariant flat-background specialization. It can also be regarded as a common compact-group model over a point with global spin reversal. This does not construct the project's nonflat smooth context connection or identify graph links with a continuum gauge field.

If $h_2=-h_1$, the exact table is instead
$$
4A^4(1+t^2h_1\sigma_L\sigma_R)(1-t^2h_1\sigma_L\sigma_R)=4A^4(1-t^4).
$$
Its pair coupling vanishes. Hence the positive scalar fixed point cannot hold uniformly in both diamond flux sectors. Flux is a gauge-invariant background mark needed to select the update; forgetting it also loses the normalizer. Integrating links or adding plaquette actions requires a new retained-state construction.

**Obligation:** explicit gauge hypothesis and preservation. **Failure condition:** claiming the nonzero flat fixed point in the opposite-flux cell. **Open gap:** a nonflat interacting gauge-matter fixed point. **Novelty fingerprint:** flat $\mathbb Z_2$ covariance plus an exact one-cell flux obstruction. **Disposition:** certify only the specialization.

## SCALE-SERIES-ONLY: no interacting fixed point without branching

**Kind:** OBSTRUCTION with restricted nonexistence proof. **Types/quantifiers:** positive homogeneous zero-field Ising weights, $0\leq t<1$, and a replacement containing one branch of two serial edges. The exact branch sum gives $A'=2A^2$ and $t'=t^2$. The fixed equation forces $t\in\{0,1\}$; one is outside the strictly positive domain. For every $0<t<1$, $t_n=t_0^{2^n}\to0$.

This refutes only this class, not general RG existence. The parallel branch removes this named obstruction in the diamond construction. **Novelty fingerprint:** exact restricted nonexistence rather than unsuccessful search. **Disposition:** control family; no additional unresolved proof step.

## SCALE-STOCHASTIC-CONTRACTION: unrestricted lift versus fixed forward channel

**Kind:** LEMMA/COUNTEREXAMPLE. **Types:** finite $X,Y$, positive $p(x)$, fixed row-stochastic $C(y\mid x)$, $P(x,y)=p(x)C(y\mid x)$, and feasible positive coarse target $Q$ on its supported rows. For any $q$ with $qC=Q$, set $J_q(x,y)=q(x)C(y\mid x)$. Common nonzero channel factors cancel in the log ratio, and marginal/conditional factorization gives
$$
D(J_q\Vert P)=D(q\Vert p)
=D(Q\Vert pC)+\sum_yQ(y)D(J_q(x\mid y)\Vert P(x\mid y)).
$$
Zero-$Q$ terms vanish and those conditionals remain undefined. Equality with coarse KL requires an admissible $q$ having the reference reverse conditional on all positive-$Q$ rows. Minimization over fixed-channel lifts is therefore not automatically coarse KL.

Over all supported joint laws with $Y$ marginal $Q$, the chain rule does attain coarse KL at $J^*(x,y)=Q(y)P(x\mid y)$. Usually $J^*(y\mid x)\ne C(y\mid x)$, so this is infeasible for the first optimization.

For a fully positive, feasible example, take
$$
p=(1/2,1/2),
C=\begin{pmatrix}3/4&1/4\\1/4&3/4\end{pmatrix}, Q=(5/8,3/8).
$$
The equation $qC=Q$ uniquely forces $q=(3/4,1/4)$. Direct logarithmic evaluation yields
$$
D(q\Vert p)-D(Q\Vert pC)=\frac18\log\left(\frac{6912}{3125}\right)>0.
$$
Here $pC=p$. The unrestricted optimum has $J_X^*=(9/16,7/16)$ and $J^*(Y=0\mid X=0)=5/6\ne3/4$. This refutes universal fixed-channel contraction equality. Deterministic $C$ recovers the earlier theorem: the posterior-conditional lift stays in the deterministic fibers and is feasible.

**Obligation:** exact ELBO correction and feasible-set typing. **Failure condition:** omitting the fixed-channel restriction. **Open gap:** none for the counterexample; general constrained minimizers and equality conditions are separate. **Novelty fingerprint:** exact rational feasible example with a log-rational gap. **Disposition:** retain the joint conditional correction, reject the stronger identification.


## Proposed executable realization

Rational positive starting $(A,t)$ remain rational at every finite depth, providing ordinary Fraction recursion controls. The exact nontrivial fixed point is irrational: the cubic $g$ has no rational root, since its only rational-root candidates are $\pm1$. An irreducible cubic root must not be cast into the existing Fraction-only exact carrier classes.

Use $\mathbb Q[t]/(t^3+t^2+t-1)$ with its real embedding isolated by $(1/2,3/5)$. Store three rational coefficients and reduce $t^3=1-t-t^2$ after multiplication. At the fixed point $t^4=2t-1$ and $1+t^4=2t$, so fixed-ratio and normalizer identities reduce algebraically. The normalized root probabilities $(1\pm t)/4$ are positive by the isolating interval. $A_n=(8t)^{(4^n-1)/3}$ has an integer exponent. If further sign decisions are required, rational bisection of the monotonic $g$ refines its isolating interval; reduced-polynomial zero testing is exact. Decimal values are displays, not exact-law representations.

A minimum bounded implementation would expose two-terminal boundary tables, serial summation, parallel multiplication, diamond recursion retaining the additive factor, direct depth-one/two graph enumeration, the algebraic fixed witness, and an exact partition/evidence record. Depth one has four vertices; depth two has twelve, hence only 4096 full assignments or 1024 at fixed roots. These are proposed controls, not executed outcomes. No historical heavy producer or mutation suite is relevant.

For an ELBO interface, use the normalized full graph Gibbs law $P_n=W_n^{\mathrm{full}}/Z_n$ and a normalized observation model. A singleton observation gives evidence one and VFE $D(q\Vert P_n)$; any nontrivial likelihood table must be normalized as observation data and pushed with the reference/evidence pair. The fixed point belongs to the generative Gibbs family, not arbitrary recognition laws or autonomous Fisher flows.

## Cross-lane questions

To coverage/root: the stochastic counterexample flags a possible interface error, not a defect in the existing deterministic contraction proof. Does integration require fixed-channel variational minimization, or will it retain the exact joint conditional KL as current completion modules do?

To evolution: no moving-context or inference-duration meaning is attached to hierarchical scale $n\log2$. Keep the constructions distinct until a typed hybrid interface is stated.

To root: a Fraction-only backend cannot represent the nontrivial fixed law exactly. A small cubic-field type or symbolic polynomial certificate is necessary. Finite rational approximations alone are not exact fixed points.

## Scope and open obligations

This lane supplies derivations for retained finite action recursion, the homogeneous interacting hierarchical fixed point, its interaction stability, and flat-background covariance. It also supplies a series-only obstruction and a stochastic contraction counterexample. General universality, nonflat gauge-matter fixed points, continuum limits, and arbitrary projected-action errors remain independent open obligations. All proposed results await the separate verification wave.



## Cross-lane readback: fixed-conditional-mixture interface

The root's agents/reduced-event.md was inspected at revision 1. Its family is an injective embedding $r\mapsto Q_r(x)=r_{g(x)}\rho_x$ with fixed deterministic partition $g$ and fixed within-bin conditionals. It retains the conditional penalty in $\ell_b=\log p_B(b)-D(\rho_b\Vert p(\cdot\mid b))$ and optimizes the explicitly restricted objective. The changing stochastic $C_i$ is only a readout. Therefore the fixed-channel contraction counterexample above does not obstruct that construction: it is not minimizing over $\{q:qC_i=Q\}$ and not replacing its conditional penalty by zero. This is an interface classification, not a verification closure for that lane's evolution or TV bound.

No hybrid identifying hierarchical length scale with its driven inference parameter is proposed.
