<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029", "schema_version": "rigorous-theory-search/v1", "target_digest": "b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Positive ladder implementation handoff

This implements the new construction in `docs/research-plans/2026-09-09-positive-ladder-rg.md` using exact Python `Fraction` arithmetic. It does not extend the older frozen RG proof target or assign any verification state. The default model uses a=1/5, b=2/5, c=1/3; a=b=0 is the explicitly uncoupled control. Source and tests are written, but no test or scientific command was executed in this lane. Root owns profile/routing integration and the consolidated test pass.

## Public data contract

`Kernel` is a dictionary with all sixteen `(r,s,x,y)` keys, each sign in `SPINS=(1,-1)`, and exact Fraction values. `ladder_kernel(a,b,c)` requires Fraction inputs in [0,1), including the defaults. The directed reference factor 1/8 is retained. `convolve(left,right)` sums one internal rung and the two internal group coordinates, and `kernel_power(kernel,exponent)` uses exact binary powers. Exponent zero returns the matrix/group convolution identity. No projection, fit to three biases, or scalar renormalization occurs.

`marginal_transfer(kernel)` returns a two-by-two tuple in SPINS row/column order. `ring_partition(kernel,cells)` computes the exact matrix-power trace without enumerating states. `ring_weight(kernel,state)` returns the unnormalized probability mass, including all per-cell reference factors. `ring_law(kernel,cells)` divides those masses by the partition and deliberately restricts enumeration to N=1,2,3. N=1 retains its loop copies, and N=2 retains distinct parallel-edge copies.

A `LadderState` is `(r_tuple,x_tuple,y_tuple)`. `block_state(state,block_size)` requires an integer divisor of the cell count, retains each block's first rung, and multiplies its upper/lower invariant rail coordinates. `global_flux(state)` is the product of all plaquettes, equivalently the product of all upper and lower invariant rail coordinates. It is preserved by the admitted deterministic block maps.

A `RawLadderState` is `(top_spins,bottom_spins,rung_links,upper_links,lower_links)`. `lift_state(state,top,bottom)` reconstructs the unique raw links for any chosen pair of spin frames. `invariant_state(raw)` reverses that coordinate transformation. `gauge_transform(raw,top_gauge,bottom_gauge)` applies the explicit two-endpoint link rule. `block_raw_state(raw,block_size)` retains endpoint spins and rungs and multiplies the distinct raw link copies. Uniformly choosing the 4^N frames supplies the uniform lift; the implementation inserts no state-dependent matter normalization.

## Generated-term witness and acceptance coverage

`ansatz_minor(kernel,rung=1)` computes the determinant, indexed by upper/lower rail signs, of the two-by-two table obtained by summing the incoming rung. Every initial three-bias kernel has a zero determinant, including after multiplication by a common scalar. Algebraically, after two-cell convolution this determinant is

\[
\frac{(1+a t)^2 a c t b^2(1-b^2)^2}{4},
\]

where t is the retained output rung. This is positive at the default biases and t=1. The test records that exact expected expression; its execution remains pending. The full generated transfer therefore stays in the sixteen-entry carrier. This implementation note is not the independent proof; the mathematical lane owns its derivation and scope.

The pending focused tests independently enumerate the original joint factor product at N=1,2,3, compare exact normalization and complete laws, check pushforwards for blocks two and three, compare complete two-then-three/three-then-two/direct-six coefficients, retain the partition through block composition up to size 32, check raw endpoint gauge covariance and uniform-frame lifts, and compare the uncoupled control with its exact c-power family. They also test the declared Fraction/domain/block-size inputs and the explicit enumeration bound. These are ordinary scientific identities and parameter-contract checks; no tamper, forgery, corruption, GPU, historical producer, or benchmark scenario is included.

There is no floating-point logarithm, Perron/Doob approximation, or VFE evaluator in this module. Root can use the exact law, block map, global-flux observation, and unnormalized weights with the existing finite VFE machinery and label any numerical logarithms separately.

## Ownership and validation status

Owned changes are `src/multiagent_elbo/rg_v2/positive_ladder.py`, `tests/rg_v2/test_positive_ladder.py`, and this note. Other agents' files were not changed. Tests were authored first, then the implementation was written, without executing either stage because the assigned workflow batches integration before one focused pass. No passing result is asserted. Root should record the new files in the shared daily change log and inspect the active profile-to-runner-to-core path before running the consolidated checks.
