<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Finite-core cross-author reconstruction

Revision 2, September 8, 2026. The reviewed finite-core.md is root-authored. This reconstructor previously authored the separate statistical/base-curvature discovery lane and bounded implementation, neither of which is reviewed here. Author and reconstructor share model lineage, task context, and filesystem. This is cross-author reconstruction, not blind or cross-model verification. Only this Markdown was edited. No code, tests, scientific execution, imports, GPU work, tamper checks, other proof edits, ledger changes, or vault writes occurred.

F1-F4 reconstruct on the stated finite, positive-evidence, finite-KL, common-channel domain. They provide an exact law/action/ELBO foundation for the admitted finite RG theory. They do not construct a global joint from arbitrary locally supplied scalar VFEs, prove restricted interaction-family closure, or establish continuum dynamics. Two implementation/scope qualifications must remain visible: the named reference-measure interfaces require a probability reference, and same-observation gauge invariance requires that the observation slice be fixed. Neither qualification refutes the mathematical finite core.

## 1. Contract and source domain

I read problem-contract.json and Theory/SPEC.md in full. The contract universally quantifies over admitted finite normalized models and composable declared channels. It does not quantify over all locally presented marginal families as if they already had a joint. SPEC distinguishes the constructed generative joint, the selected correlated recognition coupling, and the posterior slice. It also requires retention of all marks on which a subsequent structural channel depends. F1's X can contain those marks, but their sufficiency must be declared before treating the next operation as D(z|y). A next operation that still depends on discarded x is not that channel tower.

The fine generative input is a probability P on X times O. O is unchanged by the F1 coarse operation. For one o with Z_o>0, p=P(.,o)/Z_o is a normalized posterior. All probabilities are finite real masses. Finite KL(q||p) is equivalent here to q being supported on supp p, and also guarantees that every displayed logarithmic expectation is finite. The nonnegative finite reference mu dominates that slice; it need not dominate every other observation slice. Its total M is finite and positive because the selected slice has positive mass. The action identities apply to that slice and its pushed reference.

This is a finite claim at a declared context/fiber and selected observation. It does not prove section gluing over a base, connection compatibility, or a base quotient. It does not need a common intersection of all agent domains once an admissible finite global model and its carrier have already been supplied. Conversely, an empty overlap or incompatible local family does not become admissible merely by applying finite sums to nonexistent joint data.

The inspected implementation interfaces are ExactMarkovChannel and conditional_log_laplace_action in finite/scale_cocycle.py, MeasurePair in finite/measures.py, and vfe_channel_decomposition plus its fixed-outside block identity in finite/vfe.py. Source inspection checks formula and type correspondence only. No runtime outcome is claimed.

The directly inspected mathematical reference is Csiszar and Shields, [Information Theory and Statistics: A Tutorial](https://www.renyi.hu/~csiszar/Publications/Information_Theory_and_Statistics:_A_Tutorial.pdf), Section 1, printed page 423, hosted by the author's institute. It gives finite relative entropy, its zero conventions, and the log-sum inequality with its equality condition. That reference uses logarithms base two; this report uses natural logarithms, which multiply all divergences by the positive constant log 2. All chain and gluing derivations are supplied below. Lauritzen and Spiegelhalter's 1988 [publisher record](https://academic.oup.com/jrsssb/issue/50/2) identifies the classical local-probability computation paper; attempted author-hosted full-text access failed, so no uninspected theorem from it is used. There is no novelty or priority claim.

## 2. F1: measures, density actions, and evidence

For any nonnegative finite measure a on X, define (aC)(y)=sum_x a(x)C(y|x). Nonnegative finite sums and row normalization give sum_y(aC)(y)=sum_x a(x). Applying this to each observation slice, and then summing over o, proves that P_C is a normalized joint with the same observation marginal. Applying it to q gives normalized q_C. Hence Z_o is unchanged and the exact posterior identity is p_C=pC. No observation is selected anew after coarse-graining.

If mu_C(y)=0, each nonnegative term mu(x)C(y|x) vanishes. Since P(x,o)>0 implies mu(x)>0 and q(x)>0 implies P(x,o)>0, both P_C(y,o) and q_C(y) must vanish. If q_C(y)>0, some q(x)C(y|x)>0, which forces p(x)C(y|x)>0 and therefore p_C(y)>0 and mu_C(y)>0. These implications prove that no positive recognition row requires a zero posterior or reference denominator.

On mu-positive fine atoms write w=P(.,o)/mu. At mu-null atoms set w=0 as a harmless representative. Then mu(x)w(x)=P(x,o) everywhere. For mu_C(y)>0 the reverse reference row r_mu(x|y)=mu(x)C(y|x)/mu_C(y) is normalized. Direct substitution gives

\[
\frac{P_C(y,o)}{\mu_C(y)}
=\sum_x r_\mu(x|y)w(x)
=\sum_x r_\mu(x|y)e^{-A_o(x)}.
\]

The effective action is the negative logarithm of that entire sum. If the sum is zero its action is +infinity; the row necessarily has q_C(y)=0. If the reference row itself is null, no conditional probability is defined there. A numerical placeholder at such a row is not a conditional law. This covers zero channel entries, unreachable targets, and evidence-zero atoms inside a positive reference support.

The action relative to mu_C and the negative log posterior mass relative to counting measure differ by the explicit reference and evidence terms:

\[
-\log p_C(y)=A_C(y)-\log\mu_C(y)+\log Z_o
\]

on p_C-positive atoms. Omitting either correction changes the objective. Equivalently, on the recognition support,

\[
F_X(q)=\sum_x q(x)\log\frac{q(x)}{\mu(x)}+E_q A_o.
\]

The first term need not be a nonnegative KL because mu need not be normalized. Their sum is precisely KL(q||p)-log Z_o. In this discrete normalized observation model 0<Z_o<=1, so F_X>=0; the broader measure-pair/continuous-density setting can have negative VFE and is a different evidence convention.

For a second normalized kernel D, (aC)D=a(CD) follows by rearranging the finite sum sum_(x,y) a(x)C(y|x)D(z|y). This proves direct/staged equality for the reference, slice measure, recognition law, posterior, and evidence. On positive final reference support both resulting effective densities are the same ratio of the same measures. Taking their logarithms gives identical actions, including +infinity when the common numerator is zero. Induction gives every finite tower. No cancellation of an undefined 0/0 or infinity-minus-infinity is used.

Reference rescaling is itself exact and must stay explicit. If rho=mu/M, then rho_C=mu_C/M, w_C^rho=M w_C^mu, and A_C^rho=A_C^mu-log M. The associated reference-entropy term increases by log M, so F is unchanged. This is a change in density convention, not an extra interaction or an evidence change.

## 3. F2: common-channel KL, conditional loss, and its cocycle

Let Q(x,y)=q(x)C(y|x) and R(x,y)=p(x)C(y|x). At every Q-positive atom R is positive and Q/R=q/p. Summing over y, using its row normalization, gives D(Q||R)=D(q||p). This equality uses the same C in the two joints. It would not follow if separate recognition and posterior channels were substituted.

For every q_C-positive row define Q_y(x)=Q(x,y)/q_C(y) and R_y(x)=R(x,y)/p_C(y). The support implications in Section 2 make these normalized and finite-KL conditionals. On supported atoms,

\[
\log\frac{Q(x,y)}{R(x,y)}
=\log\frac{q_C(y)}{p_C(y)}+\log\frac{Q_y(x)}{R_y(x)}.
\]

Multiplying by Q and summing proves

\[
D(q\Vert p)=D(q_C\Vert p_C)+\Delta_C(q,p),
\qquad
\Delta_C(q,p)=\sum_{y:q_C(y)>0}q_C(y)D(Q_y\Vert R_y).
\]

For normalized distributions a,b with a supported on b, apply -log t>=1-t to t=b/a on a-positive atoms. It gives D(a||b)>=1-sum_(a>0)b>=0. Equality requires both b=a on that support and no remaining b mass outside it, hence equality of complete distributions. Thus Delta_C>=0, with equality exactly for Q_y=R_y on q_C-positive rows. Conditions on q_C-zero rows have no role and cannot define an attention row there.

The normalized-joint ELBO follows by writing P(x,o)=Z_o p(x): L_X=log Z_o-D(q||p). The common observation evidence therefore gives F_X=F_Y+Delta_C and L_Y=L_X+Delta_C. These are finite differences under the explicit finite-KL hypothesis. If that hypothesis is removed, an additive extended-real chain rule may survive, but ordinary subtraction of two infinite KL/VFE values does not. F1-F2 do not need that extension and do not claim its finite subtraction.

For X to Y to Z, apply the formula first to C and then to D. The middle divergence cancels, giving

\[
\Delta_{CD}(q,p)=\Delta_C(q,p)+\Delta_D(qC,pC).
\]

The left side equals the difference between the same fine and final KL values by the direct composite-channel proof. This supplies the actual nonnegative cocycle, including stochastic channels. Repeated application gives all finite towers. A recognition-dependent channel may satisfy the frozen identity at a chosen q if it is used identically in both joints, but optimization and differentiation over q then change the channel and require extra terms. It is outside this fixed-channel authority.

## 4. Fixed forward-channel optimization and unrestricted joint lifts differ

Fix a requested coarse probability Q with Q supported on pC. On arbitrary joint lifts J(x,y) with marginal J_Y=Q, the chain identity gives

\[
D(J\Vert p(x)C(y|x))
=D(Q\Vert pC)+\sum_y Q(y)D(J_{X|y}\Vert R_{X|y}).
\]

It attains its unique finite minimum at J^*(x,y)=Q(y)R(x|y), on Q-positive rows and zero on the others. This minimizes over joint laws. The constrained fine-law problem only admits lifts J_q(x,y)=q(x)C(y|x), with qC=Q. The minimizing joint need not belong to this smaller set.

The displayed scale example reconstructs exactly. With p=(1/2,1/2), C rows (3/4,1/4) and (1/4,3/4), and Q=(5/8,3/8), the constraint is 1/4+q_0/2=5/8, so q=(3/4,1/4) is the unique feasible fine law. The coarse posterior is (1/2,1/2). Expanding the four logarithms gives

\[
D(q\Vert p)=\tfrac34\log3-\log2,
\quad
D(Q\Vert pC)=\tfrac58\log5+\tfrac38\log3-2\log2,
\]

and their difference is log(6912/3125)/8>0 because 6912>3125. This proves a strict feasible optimization gap without numerical evaluation. The unrestricted optimum is [[15,3],[5,9]]/32, whose first forward row has probability 5/6 of Y=0, instead of the prescribed 3/4. Its failure to preserve C is explicit.

The equality condition can also be stated directly. Let r(y)=Q(y)/(pC)(y) on positive posterior rows. For J^* to equal q(x)C(y|x), every edge with p(x)C(y|x)>0 must satisfy q(x)/p(x)=r(y). Thus r must be constant across the supported output neighbors of each p-positive x. This condition is also sufficient: define q(x)=sum_y J^*(x,y), then the edge equality gives J^*=qC and its Y marginal is Q. For a fully positive C all supported output ratios must be one common constant, forced to one by normalization, so exact attainment of the coarse KL requires Q=pC. For deterministic forgetting each fine x has only one output neighbor; the condition is automatic and the usual posterior-conditional fine lift works. This explains why the stochastic counterexample does not refute deterministic conditional completion.

## 5. F3: what local VFEs do and do not determine

A complete normalized generative joint and a chosen recognition joint determine the global VFE. A collection of scalar objectives evaluated only on local marginal laws does not determine those joints. For a direct positive witness, take two binary signs with uniform product posterior p=1/4 and one certain observation. Let q_t(x_1,x_2)=(1+t x_1x_2)/4, 0<t<1. Each singleton recognition marginal remains uniform, so both singleton marginal VFEs are zero for q_0 and q_t. The global VFE is D(q_t||p), strictly positive for q_t!=p by Section 3. Thus even globally compatible local marginals and their local scalar VFEs do not specify the correlated global objective. This assertion concerns marginal scalar data, not the full collection of exact conditional functionals over every joint preparation.

When the local objectives are restrictions of one declared joint objective, there is an exact local/global identity. Write the latent state as (A,B), hold the outside recognition marginal r(B) fixed, and let q(A,B)=r(B)q(A|B). The chain rule yields

\[
F(q)=D(r\Vert p_B)-\log Z_o
+\sum_b r(b)D(q_{A|b}\Vert p_{A|b}).
\]

Any finite admissible update of q(A|B) therefore changes the global objective by exactly the change in the outside-averaged conditional KL. This is the fixed-outside block identity inspected in finite/vfe.py. The support and fixed-outside conditions are load-bearing. Summing independent agent updates or arbitrary marginal VFEs without these conditions is not the same theorem.

For the triangle witness, every pair has equal-atom masses 1/20 and unequal-atom masses 9/20. Each is a positive normalized distribution with uniform endpoint marginals. If a global binary triple existed, each edge would disagree with probability 9/10, so the expected number of disagreeing edges would be 27/10. Every binary triple has either zero or two disagreeing edges. Its expectation is at most two, a contradiction. This refutes global existence for those locally compatible pair data, rather than merely showing that one gluing formula fails.

For the sufficient tree construction, assume nonempty finite coordinate sets, a finite tree of cliques covering the variables, the running-intersection property, strictly positive normalized clique laws, and agreement of the two clique marginals on every edge separator. Let

\[
P(x)=\frac{\prod_{C}P_C(x_C)}{\prod_{(C,D)}P_{C\cap D}(x_{C\cap D})}.
\]

All denominators are positive. If L is a leaf with neighbor N and separator S=L intersect N, running intersection implies that every variable in L minus S occurs nowhere in the remaining tree. Summing over those variables changes the leaf numerator P_L to its separator marginal P_S, canceling the one corresponding denominator. This leaves exactly the product formula on the smaller tree. Induction proves normalization. Rooting at any chosen clique and eliminating all other leaves proves that its marginal is exactly the prescribed clique law. A leaf with no exclusive variable has identical numerator and separator and causes no difficulty. An empty separator is the probability-one law on the empty coordinate tuple.

This proves existence of the positive clique-tree Markov extension. It does not prove uniqueness among all joint laws having the same clique marginals; the conditional-independence/factorization construction is itself additional structure. The strictly positive premise avoids every separator 0/0. A zero-support gluing extension would require explicit supported conditionals or another convention, and is not claimed by F3. An arbitrary cyclic family needs its own extension criterion or a supplied joint.

One direct generative construction, when declared, is a normalized prior times a product of normalized observation-record kernels that are conditionally independent given the latent state. Summing the observation variables then returns one. Each record appears once in that joint. Its incident log factor appears in each relevant coordinate-local objective because each such objective varies the corresponding coordinate; summing those local expressions would double count shared records. This distinction supports the original local-to-global motivation without pretending that arbitrary scalar local objectives are sufficient input.

## 6. F4: finite equivariance and interaction retention

Let g act by permutations sigma_g on X and tau_g on Y, leave O unchanged, and satisfy C(tau_g y|sigma_g x)=C(y|x). Define pushed q^g(sigma_g x)=q(x), mu^g(sigma_g x)=mu(x), and P^g(sigma_g x,o)=P(x,o). Substituting x'=sigma_g x in the finite sum gives (q^g C)(tau_g y)=(qC)(y), and the same equation for mu and each P slice. Thus p^g_C is the pushforward of p_C and the reference density is permuted without a Jacobian. Evidence is unchanged because the summed latent labels are merely relabeled. KL and the conditional correction are unchanged by the same substitutions. Two intertwining kernels compose into an intertwining kernel by summing the intermediate permutation variable.

If the declared action also transforms observations by omega_g, the correct statement is Z^g_(omega_g o)=Z_o, with the posterior and recognition slice transported consistently. Equality at the same fixed numerical o follows only for isotropy arrows fixing that slice and its selected law. For example, a one-state latent model with observation probabilities 1/3 and 2/3 has its evidence values exchanged by an observation-label swap. They are covariant under corresponding observations, not equal at the same old label. F1 leaves O unchanged, so F4 is valid in that domain; the wider interpretation needs this explicit correction, as SPEC requires.

A finite carrier has a permutation action. If it is obtained from a compact group, the represented image lies in a finite permutation group; this supplies no nontrivial smooth connection automatically. Coarse kernel equivariance and first-jet compatibility over a continuous base remain different assertions.

The action after marginalization is the full negative log of a finite sum. A chosen basis of local interactions need not contain that function. Exact tower closure therefore holds in the full retained function/law space, while a smaller interaction family requires a separate invariance or error theorem. In the two-terminal zero-field Ising example, simultaneous spin reversal leaves only two orbits of configurations, parallel and antiparallel. Their indicator span is exactly the span of one and sigma*tau, so that particular action closes on a constant plus one interaction. More terminal variables or symmetry-breaking observations have a larger invariant action space; the two-terminal argument supplies no pairwise closure there.

## 7. Current interfaces and the finite-reference qualification

ExactMarkovChannel enforces nonempty unique ordered labels, nonnegative exact rational entries, exact row sums of one, and the declared recognition-independent flag. Its composition checks exact intermediate label equality and performs rational matrix multiplication. Those are the finite tower hypotheses. Its pushforward method is an algebraic operation and does not independently certify normalization of arbitrary caller-supplied laws.

conditional_log_laplace_action requires a probability reference, nonnegative evidence masses, and support domination. Its reference/evidence pushforwards and their ratio use Fraction arithmetic; the final logarithms are floating evaluations. At null coarse reference it stores density zero and action infinity as representatives. That is consistent with F1 only when those entries are treated as undefined-support placeholders rather than conditional rows. The function accepts evidence submeasures as inputs but does not construct a complete normalized observation joint. The caller must supply that modeling bridge before interpreting their total as an observation probability.

MeasurePair likewise requires a ProbabilityMeasure reference. Its arrays and VFE routines use float64 with configured normalization tolerances; their numerical outputs are not exact rational identities. vfe_channel_decomposition implements the same two reverse-conditionals and retains an explicit undefined residual when any term is infinite. This is a source correspondence, not an execution certificate.

The theorem allows arbitrary finite mu, so the sentence about reusing the existing exact interface needs a reference-convention step. Put M=sum mu and call the probability-reference interface with rho=mu/M. The returned density/action is relative to rho_C, not mu_C. Recover A_C^mu=A_C^rho+log M, or explicitly retain rho_C as the declared reference everywhere. For mu=(1,1), an observation slice P(.,o)=(1/4,1/4), and the identity channel, the original action is log 4. The normalized-reference action is log 2; restoring log M=log 2 gives log 4. This proves that silent reference normalization loses a scalar term even when probabilities and all supports are harmless.

This is an interface scope qualification, not a defect in F1. The proof and implementation can use either reference convention coherently. No implementation edit is made or required by this reconstruction assignment.

## 8. Accepted mathematical scope and remaining independent obligations

The finite normalized core can honestly serve as the admitted exact RG foundation: it defines retained measures and actions, preserves the chosen observation evidence, gives exact common-channel ELBO accounting, retains every conditional correction, and composes through all finite declared towers. Its proof is valid for every input satisfying those hypotheses, including zeros admitted by support domination and finite KL. Positive clique trees provide one constructive class of local-to-global models, while the positive triangle refutes an unjustified universal gluing premise.

That foundation does not select the coarse kernel, canonical dependence, partition, representation, or scale identification. It does not guarantee that discarded information can be reconstructed from a smaller statistic, that a parameterized action family is invariant, or that independent reduced optimization follows the fine optimum. F2's stochastic gap prohibits one such inference. Infinite-volume consistency, thermodynamic convergence, smooth disintegration, base descent, connection-compatible evolution, and autonomous interacting fixed points are additional conjuncts of the broader program. They are neither established nor refuted by a finite-sum tower identity. Their separate constructions and obstructions must keep their own domains.

The only requested wording changes are the probability-reference convention in the source handoff and the observation-slice qualifier if F4 is stated for actions on O. No missing mathematical condition was found in F1-F4 within the fixed-observation finite-KL domain as stated. Root owns ledger adjudication and integration; this report records reconstructed derivations rather than closure states.

## 9. Input binding and freeze

The following SHA256 hashes bind the read-only inputs. Agent paths are relative to this completion run. The proof does not rely on prior numerical results, and no source/test execution is represented by these hashes.

| Input | SHA256 |
| :--- | :--- |
| agents/finite-core.md | 3fc9f64f8eb4d815c418873a1b0a1151f95aa890ed10ad930ae08300cd864718 |
| problem-contract.json | 50db7529fc2c5cb7c032cd4e3b6517516a93800ba32db8c2c50c226ddb2a369e |
| Theory/SPEC.md | dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1 |
| agents/scale.md | 7ed8f0cfbbb7849cdd9f45ad1f5cb9c1e65d29279ac7b28c5458bdddf691ae8d |
| agents/scale-verification.md | b3d0d026bee043e2a8a5a566933e295d762025adbdfebfee273b7b9d53020182 |
| src/multiagent_elbo/finite/scale_cocycle.py | 2f3da104ccdd3259e0776bf2ae9806116ca074002241386cf79e021a7831700d |
| src/multiagent_elbo/finite/measures.py | 6ca5373a4d20b975ea4e0e6e49098d0b7810b64a4cd656d55963f478e950059a |
| src/multiagent_elbo/finite/vfe.py | a6fe5aa7ca338178335e2e39b0fcc0666f16962af27328100a9edbbabf64cda1 |

Revision 2 freezes this bounded reconstruction after source readback. The root-authored input and source files remain unchanged by this lane. Root retains canonical delivery, execution authority, and any author amendment.
