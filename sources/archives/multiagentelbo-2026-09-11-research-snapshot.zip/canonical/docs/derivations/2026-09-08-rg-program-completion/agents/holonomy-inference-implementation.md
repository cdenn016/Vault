<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Neighborhood holonomy observation: proof and implementation contract

Revision 2 freezes the implementation and proposed tests after the proof and public API were recorded in revision 1 before implementation. The new optional model preserves the existing local Gaussian/event source and observation. A finite field label, a normalized curvature prior, and a Gaussian loop observation are additional declared model data. No iterative joint Fisher flow, universal curvature action, continuum field measure, or identifiability assertion is made. This lane owns only the new holonomy_inference.py, its named test file, and this note. Root owns independent reconstruction, execution, profile and artifacts. No tests are run by this lane.

## Public API

The module exports frozen `HolonomyModel` and `Recognition` dataclasses and these functions:

`build_holonomy_model(c, loop, kappa, reference_mass, observation_reference, noise_reference, action_volume=.09, lambda_b=.4, lambda_m=.3, coupling=.35, frame_scale=1., probe_agent=2, chart=0) -> HolonomyModel`.

The first six arguments are float64 tensors on one device. Shapes are c `(2,)`, closed polygon loop `(N,2)` with N>=3 and first/last point exactly equal to c, kappa `(K,2)` with K>=1, reference_mass `(K,)`, reference observation `(4,)`, and reference SPD noise `(4,4)`. Masses are strictly positive and normalized within the admitted floating tolerance; repeated field pairs are allowed. The selected agent must contain every loop vertex in its strict open strip. Coupling and lambdas are nonnegative; action_volume is positive; all scalar parameters are finite. Charts are 0,1,2. Geometry parameters in the legacy ContextModel are preserved as its existing defaults; its law, frame and coarse maps do not depend on them. Each actual loop uses its own declared kappa pair.

`source_recognition(model) -> Recognition` uses field prior masses, one clone of the existing source recognition Gaussian per label, and the source latent event law. `posterior_recognition(model) -> Recognition` uses the exact field posterior, every conditional posterior Gaussian, and the original event posterior. `Recognition(field_mass, gaussian, event)` also admits explicit positive normalized field masses, a tuple of K compatible Gaussian laws, and a positive normalized `(4,4,4,4)` latent event tensor.

`accounting(model,state) -> dict` returns tensor-valued posterior and generative-factor VFE expressions, component Gaussian prior/posterior KL, field reference/prior/posterior KL, expected field action and its log partition, old/loop/event expected log likelihoods, and equality residuals. `coarse_accounting(model,state) -> dict` returns three `levels` (depths 0,1,2) retaining field labels and component Gaussian/event laws, component KL and independently evaluated discarded conditional KL, total VFE and chain residual; plus `checks` for direct/staged laws, maps, event channels and telescoping conditional information. Depth zero already emits the availability channel, so its event correction need not vanish.

The model stores context, loop, kappa, reference_mass, action, log_field_partition, log_prior, prior_mass, log_posterior, posterior_mass, holonomy, selector, probe_frame, observation_reference, noise_reference, observation, noise, H_loop, component_posterior, component_log_evidence (incremental loop density), log_evidence (all observations), and sequential/stacked checks. Gaussian component tuples are retained exactly as components; no moment Gaussian substitutes for the mixture.

## Normalization and exact Bayes construction

Let the actual original normalized model be `p_0(z,e,o_0)=p_G(z)p_E(e)L_G(o_G|z)L_E(o_E|e)`. Its source prior is the existing locally assembled Gaussian/event joint. Let m be normalized positive finite reference masses and declare

\[
S_k=V(\lambda_b\kappa_{b,k}^2+\lambda_m\kappa_{m,k}^2),
\qquad Z_f=\sum_k m_k e^{-S_k},\qquad
\pi_k=m_ke^{-S_k}/Z_f.
\]

Finite inputs, V>0 and nonnegative lambdas give finite nonnegative actions in the mathematical model, and `0<Z_f<=1`. Floating arithmetic separately rejects nonfinite actions or underflowed positive masses. V and the coefficients are modeling postulates. m is a finite categorical reference, not Haar measure on all connections.

Let P select the probe agent's four represented coordinates at c. On a polygon contained in that agent domain, the existing path transport gives the based map U_k. Set `H_k=(U_k-I)P`. With declared SPD R and observed vector r, the new normalized joint is

\[
p(k,z,e,o_0,r)=\pi_k p_0(z,e,o_0)\mathcal N(r;H_kz,R).
\]

Integrating the new observation gives one for every k,z; summing pi and integrating the original joint proves normalization. The source observation and event likelihood occur once. All straight segments stay in the selected open strip because it is convex and every vertex is interior. The loop need not support the whole changing population; it transports only the selected four-dimensional probe fiber.

Write the original posterior Gaussian as `N(mu_0,Sigma_0)` and full original evidence as Z_0. Conditional Gaussian integration gives

\[
\ell_k=\mathcal N(r;H_k\mu_0,R+H_k\Sigma_0H_k^\top),
\quad Z=Z_0\sum_k\pi_k\ell_k,
\quad \omega_k=\pi_k\ell_k/\sum_j\pi_j\ell_j.
\]

Conditioning this Gaussian gives each `P_k=N(mu_k,Sigma_k)`. Equivalently condition the original Gaussian prior on the stacked observation `[o_G;r]`, matrix `[H_0;H_k]`, and block-diagonal noise. Multiplying Gaussian likelihoods proves that the stacked and sequential posterior and evidence agree. The original event posterior stays independent because the added likelihood does not contain e. SPD R and the original positive covariance imply positive observation covariance and positive conditional covariance mathematically; numerical outputs receive SPD admission.

## Chart covariance

For an old-to-new fine frame Q and probe frame V, use `P'=VPQ^-1`, `U_k'=VU_kV^-1`, `r'=Vr`, and `R'=VRV^T`. Then `H_k'=VH_kQ^-1`. The Gaussian prior/posterior transform by mean/covariance congruence, while each observation density and finite field mass is unchanged because the represented frames are orthogonal. The implementation accepts r/R in the common reference probe frame and converts both with the existing basepoint frame. The field action and reference masses are gauge scalars. This verifies a passive-coordinate property and does not claim a new gauge-field dynamic.

## Full retained VFE and curvature-prior accounting

For `q(k,z,e)=a_k Q_k(z)q_E(e)`, chain factorization of the posterior gives

\[
\mathcal F=\operatorname{KL}(a\|\omega)
 +\sum_k a_k\operatorname{KL}(Q_k\|P_k)
 +\operatorname{KL}(q_E\|p_E(\cdot|o_E))-\log Z.
\]

Expanding the normalized generative factors gives the independent expression

\[
\begin{split}
\mathcal F={}&\operatorname{KL}(a\|\pi)
 +\sum_k a_k\operatorname{KL}(Q_k\|p_G)+\operatorname{KL}(q_E\|p_E)\\
&-\sum_k a_k\mathbb E_{Q_k}\log L_G
 -\mathbb E_{q_E}\log L_E
 -\sum_k a_k\mathbb E_{Q_k}\log\mathcal N(r;H_kz,R).
\end{split}
\]

Every Gaussian expectation retains the covariance trace and density normalizer. The field prior term obeys the exact identity

\[
\operatorname{KL}(a\|\pi)
=\operatorname{KL}(a\|m)+\sum_k a_kS_k+\log Z_f.
\]

Thus the declared quadratic field action enters the VFE together with its reference entropy and normalizer. A constant action shift cancels. At the full posterior, all posterior KL terms vanish and `F=-log Z`. Arbitrary full Gaussian Q_k are evaluated directly rather than assumed to have a tree factorization.

## Retained-label coarse accounting

Use the unchanged common channel `C_l:(k,z,e)->(k,F_lz,K_le)`. The field label is preserved. Every conditional Gaussian pushes to a Gaussian and the event law pushes through its normalized availability/parent channel. The coarse posterior KL is

\[
D_l=\operatorname{KL}(a\|\omega)
 +\sum_k a_k\operatorname{KL}(F_l\#Q_k\|F_l\#P_k)
 +\operatorname{KL}(K_l\#q_E\|K_l\#p_E).
\]

The KL chain rule on the common augmented channel gives `D_fine=D_l+C_l`, where C_l is the a-weighted Gaussian hidden-conditional KL plus the independently computed event conditional KL. Full row rank supplies valid Gaussian disintegrations; event structural zeros remain explicit. The original evidence is retained at every depth, so the same identity holds for VFE. Products `F_12 F_01=F_02` and the existing event-channel compositions give direct/staged law equality componentwise. Applying the same conditional identity between adjacent levels proves telescoping corrections. Marginalizing k would create a different Gaussian-mixture KL problem and is outside this API.

## Scientific and implementation boundary

The four suggested field pairs and rectangle define a small finite posterior calculation, not identifiable curvature recovery. Zero area, zero field curvature, or repeated identical labels can make observation components identical. SO(2) periodicity and likelihood symmetries can also identify distinct labels observationally. These are controls, not grounds for silently changing the field prior or observation. No generic obstruction prevents the declared bridge. Root's independent reconstruction and focused execution remain required; the following implementation section will record the final source hashes without claiming an unrun pass.
## Frozen implementation and exact runner schema

The implementation preserves all prior neighborhood source files and declares a separate optional model. It uses `inference.build_context` for the source law, `connections.path_transport` only for the probe fiber, `model.condition` for sequential and independently stacked conditioning, `local_tree.gaussian_expected_log_likelihood` for normalized expected densities, and `local_tree.gaussian_discarded_kl` / `event_discarded_kl` for conditional information. No new training loop or mixture approximation is introduced. The positive finite mass support is checked after exponentiation; representational underflow is rejected rather than converted into an implicit zero-mass field model. The noise and each posterior covariance receive SPD admission. The loop's open strip and U are convex, so vertex admission proves segment admission.

`HolonomyModel.checks` contains floating absolute equality errors named `sequential_stacked_mean_residual`, `sequential_stacked_covariance_residual`, `sequential_stacked_log_evidence_residual`, `prior_normalization_residual`, and `posterior_normalization_residual`. The stacked route includes the original event evidence once when comparing full evidence. `component_log_evidence` stores log ell for numerical stability; `log_evidence` includes both original observations and the loop observation.

`accounting` returns the exact keys `field_reference_kl`, `field_prior_kl`, `field_posterior_kl`, `expected_field_action`, `log_field_partition`, `field_prior_decomposition_residual`, `gaussian_prior_kl`, `gaussian_posterior_kl`, `event_prior_kl`, `event_posterior_kl`, `old_gaussian_expected_log_likelihood`, `loop_expected_log_likelihood`, `event_expected_log_likelihood`, `posterior_kl`, `vfe`, `generative_vfe`, `elbo`, and `elbo_residual`. Gaussian KL and expected-likelihood values have K entries. All other accounting entries are scalar tensors. The two residual keys are absolute errors; VFE, ELBO, log partitions, and log densities can have either sign and must not receive a nonnegative-KL guard.

`coarse_accounting` returns `levels`, `stages`, and `checks`. Each of the three level dictionaries has `depth`, `field_mass`, `target_field_mass`, `gaussian`, `target_gaussian`, `event`, `target_event`, `gaussian_component_kl`, `field_posterior_kl`, `event_kl`, `gaussian_conditional_kl`, `event_conditional_kl`, `conditional_information`, `posterior_kl`, `vfe`, and `chain_residual`. Gaussian and target Gaussian are tuples of K unbatched supported laws. Both event laws are square visible-carrier tables, including structural zeros. Gaussian component and conditional KL arrays have K entries. The two adjacent `stages` dictionaries contain `from_depth`, `to_depth`, `gaussian_conditional_kl`, `event_conditional_kl`, `conditional_information`, and `chain_residual`.

The coarse checks are scalar absolute error tensors: `map_composition_residual`, `event_channel_composition_residual`, `staged_gaussian_0_residual`, `staged_gaussian_1_residual`, `staged_event_0_residual`, `staged_event_1_residual`, `stage_chain_0_residual`, `stage_chain_1_residual`, `conditional_telescope_residual`, and `full_coarse_chain_residual`. The telescope includes the latent-to-availability correction at depth zero. Recognition constructors clone source tensors and components; the frozen model is not updated by accounting.

## Proposed focused controls and execution status

The new test file defines tiny CPU controls with one Torch thread restored on exit. They compare the builder against an independent stacked precision update and `MultivariateNormal` evidence, check actual label reweighting under the declared nondegenerate observation, reconstruct source and posterior VFE without double counting, require posterior VFE equal minus full log evidence, check source-state persistence, compare every retained-label coarse chain and staged law, retain visible event structural zeros, and verify charts 1 and 2 by direct mean/covariance/observation/holonomy congruences. Zero-area, zero-curvature, and repeated-label controls preserve the field prior when their loop components are identical. Ordinary input-domain tests reject an unclosed loop, a segment vertex outside the probe domain, zero reference mass, and negative action strength. These are scientific admission tests, not artifact-corruption scenarios.

Only Python's standard-library AST parser was run on these two files; both parsed, and both contain LF line endings with zero CR bytes. No Torch import, test collection, test execution, GPU experiment, tamper scenario, source alteration outside this lane, or publication was performed. The controls are implemented but unexecuted. Independent mathematical reconstruction and focused execution belong to root and may invalidate this freeze if they expose a defect.

The frozen source SHA256 is `a2dfb82af0b5ea7bec9f38f8c91438e5b3a33fdbea283d3e6eb74fce53458960` for `src/multiagent_elbo/experiments/neighborhood/holonomy_inference.py`. The frozen test SHA256 is `eec6c085581120e31e8418b7683a0f23191b2cd2082466e890397e6d492c4d21` for `tests/rg_v2/test_neighborhood_holonomy_inference.py`. The Markdown hash is reported externally after this note is written, avoiding a self-referential digest.
