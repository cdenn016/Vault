<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Reconstruction of metric-projected quotient connections

Revision 1 is frozen against `agents/projected-connection.md`, SHA256 `dcac12ab952dc2a735e9b50cf7a01c8ee200562fb6a4a7f846686967d15e7951`. The requested identities reconstruct under the stated fixed-rank and metric assumptions. The calculations below supply the evidence; agreement between authors is not evidence. No mathematical correction to that frozen note is identified. Two extension boundaries are made explicit: a non-Euclidean source metric changes adjoints, and source nonmetricity adds a term to the second-fundamental/defect relation. Neither boundary is silently assumed away by the original note.

This is an independent derivation by a separate task lane, with shared model, inherited context, and filesystem. Author model: the inherited GPT-6 model. Reconstruction model: the same inherited GPT-6 model; an exact deployment identifier and a distinct cross-model run were not supplied. The peer-review skill's cross-model procedural status is therefore `INCONCLUSIVE_SAME_MODEL`, not a verification verdict. The explicit derivations remain assessable on their own. No ledger closure, source-code edits, tensor imports, tests, numerical experiments, GPU work, or Research-vault writes were performed. Only this report is owned.

The bounded reconstruction follows the peer-review skill's theory method. The existing coordination and ledger were consulted for scope; no previously closed claim is reopened. Every formula needed below is obtained by finite-dimensional matrix algebra, the differential product rule, or direct differentiation. No universal-connection existence theorem, convergence theorem, or uninspected external citation is imported. The contextual Schlafly attribution in the author note is outside this algebraic reconstruction and is not claimed as verified here.

| Family | Mathematical status in this report | Boundary |
|:--|:--|:--|
| PCV1 quotient metric and induced connection | Derived below | Smooth fixed-rank surjection; a declared positive metric |
| PCV2 defect sign, descent, and curvature | Derived below | Euclidean-skew source, or the explicitly metric-corrected version |
| PCV3 general flat 3-to-2 witness | Derived at every finite `(x,y)` | Mathematical example outside the code's even-dimension interface |
| PCV4 GL coordinates and nonmetricity | Derived below | The source metric transforms as a covariant tensor |
| PCV5 staged/direct equality and reset example | Derived below | Propagate the quotient metric and the induced intermediate connection |
| PCV6 scalar weights and common channel | Derived below | Scalar weights with the same internal source connection |
| PCV7 statistical interpretation and nonautonomy | Derived below | Selected mean-family Fisher identity; no automatic VFE action |

## PCV1: metric, lift, and connection

**Family:** PCV1-metric-quotient. **Kind:** CONSTRUCTION. **Target:** author equations (1)-(3). **Types and quantifiers:** at every point of a smooth base, F is an `m by n` C2 matrix of constant row rank m; h is a C2 positive symmetric `n by n` source metric; A is a C1 `n by n` one-form. The Euclidean case sets h=I. Products of matrix-valued forms use exterior products, and the vector connection is `d+A`.

Minimize `z^T h z` subject to `Fz=y`. The stationary equation gives `hz=F^T ell` for a multiplier ell, so `F h^-1 F^T ell=y`. The Gram matrix is positive definite: for nonzero a, `a^T F h^-1 F^T a>0` because F has full row rank. Define

\[
g=(Fh^{-1}F^\top)^{-1},\qquad R=h^{-1}F^\top g.
\]

The unique minimum-norm representative is `Ry`. Any other representative is `Ry+v`, with `Fv=0`; its cross term vanishes since `R^T h v=gFv=0`. Thus

\[
FR=I_m,\quad R^\top hR=g,\quad F=g^{-1}R^\top h,
\quad \|Ry+v\|_h^2=y^\top gy+v^\top hv.
\]

With `Pi=RF` and `N=I-Pi`, Pi is an h-orthogonal projector. Applying the source connection to `Ry` and then F gives

\[
F(d+A)(Ry)=dy+F(dR+AR)y.
\]

Consequently `B=F(dR+AR)` is a connection coefficient. Differentiating `FR=I` gives the alternative form `B=(FA-dF)R`. This construction chooses representatives using h; it does not yet assert representative-independent descent.

Set `Q_h=dh-A^T h-hA`. Differentiating `g=R^T hR` and using `gB=R^T h(dR+AR)` gives, without a compatibility assumption,

\[
dg-B^\top g-gB=R^\top Q_hR.
\]

Therefore the author's Euclidean result `dg=B^Tg+gB` follows when h=I and `A^T=-A`. The general compatible case follows when `Q_h=0`. The sign matches parallel-vector evolution `dy=-By`: differentiating `y^Tgy` along it gives zero.

For h=I, set `H=FF^T`, `T=H^-1/2`, and `U=F^T H^-1/2`. Then `U^T U=I`, `R=UT`, and

\[
B=T^{-1}U^\top(dU+AU)T+T^{-1}dT.
\]

The old-to-new coordinate transform `yhat=Ty` consequently gives

\[
\widehat B=TBT^{-1}-(dT)T^{-1}=U^\top(dU+AU).
\]

Its transpose is its negative because `d(U^T U)=0` and A is skew. This directly reconstructs equation (3), including its coordinate sign.

**Failure condition:** loss of row rank or positive definiteness invalidates the inverse and the minimum-norm construction. **Open gap:** none for the stated finite-dimensional identities. **Novelty fingerprint:** a metric-dependent induced connection is distinguished from exact descent. **Proposed disposition:** explicit derivation supplied; no formal closure assigned.

## PCV2: the defect sign and curvature

**Family:** PCV2-second-fundamental-sign. **Kind:** LEMMA. **Target:** author equations (4)-(8). Initially h=I and A is skew. Define

\[
S=N(dR+AR),\qquad \mathcal E=dF+BF-FA.
\]

Since `F(dR+AR)=B`, decomposition by Pi and N gives `dR+AR=RB+S`. Substitution of `B=(FA-dF)R` gives `E=(dF-FA)N` and `ER=0`.

The sign can be established without a projector-curvature formula. For any discarded section v with `Fv=0`, differentiating that equation yields `F(d+A)v=-E v`. Metric compatibility and the identity `<Ry,v>=0` give, for arbitrary y,

\[
0=\langle Sy,v\rangle+\langle Ry,(d+A)v\rangle
 =y^\top S^\top v-y^\top g\mathcal Ev.
\]

Both E and `S^T` vanish on the retained subspace. Their equality on discarded vectors therefore proves

\[
\mathcal E=g^{-1}S^\top.
\]

The sign is positive. Let `D_A Pi=dPi+A Pi-Pi A`. Differentiating `Pi^2=Pi` makes its diagonal projector blocks zero. Its coefficients are symmetric because Pi is symmetric and A is skew. From `Pi R=R`, covariant differentiation gives `(D_A Pi)R=S`. Therefore S vanishes exactly when both off-diagonal blocks of `D_A Pi` vanish. This proves the chain of equivalences between `E=0`, `S=0`, `D_A Pi=0`, and preservation of the discarded kernel. Preservation of the kernel implies preservation of its orthogonal complement here specifically because the source connection preserves the metric.

For curvature, first use a statement valid for any smooth right inverse. Expand `dB+B wedge B` with `B=F(dR+AR)`, use `ER=0`, and regroup to obtain

\[
K_B=FK_AR+\mathcal E\wedge S.
\]

For example, expansion of the second term as `E wedge(dR+AR)` cancels `-FA wedge AR` against the `FA wedge AR` part of `FK_AR`; the remaining terms are precisely `d[F(dR+AR)]+B wedge B`. This direct computation fixes the exterior-product order. In the metric-compatible Euclidean case it becomes

\[
K_B=FK_AR+g^{-1}S^\top\wedge S.
\]

Using `(D_A Pi)R=S` and symmetry identifies the same term as `F(D_A Pi wedge D_A Pi)R`. Multiplication by R and F reconstructs the author's source-projector version. An adapted orthonormal frame has off-diagonal blocks `-Shat^T` and Shat, so the ambient retained curvature is `K_Bhat-Shat^T wedge Shat`; solving for the induced curvature confirms the same plus sign independently.

The two-form coefficient `S_X^T S_Y-S_Y^T S_X` is skew. It is not a nonnegative scalar. For a real rank-one metric quotient this coefficient vanishes, and compression of a skew source curvature onto one vector also vanishes. Thus local scalar curvature is zero even when the connection has nontrivial first-order descent defect.

**Failure condition:** Euclidean transpose identities cannot be reused with a non-Euclidean h or an incompatible source connection. PCV4 gives the precise replacements. **Open gap:** none within the author's stated metric-compatible scope. **Novelty fingerprint:** the retained/discarded coupling supplies both the parallel-map defect and the additional curvature term, with a fixed sign. **Proposed disposition:** equations (4)-(8) reconstruct.

## PCV3: a direct general-coordinate curvature calculation

**Family:** PCV3-flat-three-to-two. **Kind:** CONSTRUCTION. **Target:** author equations (9)-(11). Let `F=[I_2,-v]`, with `v=(x,y)^T`, `s=1+x^2+y^2`, h=I and A=0. This has full row rank at every finite `(x,y)`.

The Sherman-Morrison identity here can be verified by multiplication: `(I+vv^T)(I-vv^T/s)=I`. Thus `g=I-vv^T/s`, `R=[g;-v^T/s]`, and `B=-dv v^T/s`. Its coordinate matrices are

\[
B_x=-\frac1s\begin{pmatrix}x&y\\0&0\end{pmatrix},\qquad
B_y=-\frac1s\begin{pmatrix}0&0\\x&y\end{pmatrix}.
\]

Differentiating these matrices gives

\[
\partial_x B_y-\partial_y B_x
=\frac1{s^2}\begin{pmatrix}
-2xy&s-2y^2\\-s+2x^2&2xy
\end{pmatrix},\qquad
[B_x,B_y]=\frac1{s^2}\begin{pmatrix}
xy&y^2\\-x^2&-xy
\end{pmatrix}.
\]

Hence the exact curvature coefficient is

\[
(K_B)_{xy}=\frac1{s^2}
\begin{pmatrix}-xy&1+x^2\\-(1+y^2)&xy\end{pmatrix}
=-\frac{Jg}{s}.
\]

This calculation uses no value-at-origin extrapolation. Multiplication by g gives `g(K_B)_xy=-J/s^2`, and at `(0,0)` the coefficient is `-J`.

There is a second direct check from the discarded normal. Put `n=(x,y,1)^T`, so `N=nn^T/s`. Since `n^T R=0`, differentiation gives `n^T dR=-dv^T g`, and

\[
S=-\frac ns dv^\top g,\qquad
S^\top\wedge S=\frac1s g(dv\wedge dv^\top)g
=-\frac J{s^2}dx\wedge dy.
\]

Multiplication by `g^-1` reproduces the matrix above. Both independent expansions reconstruct the general `(x,y)` formula and its sign.

**Failure condition:** this is not an instance of the current code's even-dimensional common-channel interface. It is a mathematical witness of projection curvature, with all bundles trivial over the stated base. **Open gap:** none for the exact formula; no runtime result is claimed. **Novelty fingerprint:** nonzero local curvature is generated from a flat source by the varying retained plane, without a topology or dynamics claim. **Proposed disposition:** equations (9)-(11) reconstruct.

## PCV4: GL coordinates, covariance, and nonmetricity

**Family:** PCV4-metric-coordinate-covariance. **Kind:** LEMMA and extension boundary. **Target:** author equations (12)-(14). Let `z'=Uz`, `y'=Ty` for arbitrary smooth invertible U,T. The same source metric and connection have components

\[
h'=U^{-\top}hU^{-1},\qquad
A'=UAU^{-1}-(dU)U^{-1},\qquad F'=TFU^{-1}.
\]

Substituting these into the metric lift formula gives `R'=URT^-1`, `g'=T^-TgT^-1`, and `Pi'=U Pi U^-1`. Differentiating `URT^-1` and canceling the dU terms gives

\[
B'=TBT^{-1}-(dT)T^{-1},\qquad K_B'=TK_BT^{-1}.
\]

Thus arbitrary GL source changes are valid when h travels with them. Keeping the numerical I after a nonorthogonal U is a different metric choice. In particular, a covariance and a covariant sample-space metric have opposite congruence laws: `Sigma'=U Sigma U^T` whereas `h'=U^-T hU^-1`. If a prior covariance is used to declare a sample metric, its precision `h=Sigma^-1` has the required tensor type. Taking its covariance matrix itself as h is not that same coordinate-invariant declaration. Already in one dimension, `U=2` sends covariance 1 to 4 but metric 1 to 1/4. The author does not make this incorrect substitution; the example records an implementation boundary for the phrase covariance-derived metric.

The nonmetricity identity in PCV1 holds for arbitrary A, and `Q_h'=U^-T Q_h U^-1`, so its right-hand side transforms correctly as a target metric-valued one-form. Source compatibility is sufficient, but not necessary, for quotient compatibility: the pullback can kill source nonmetricity in discarded directions. For instance, `F=(1,0)`, `h=diag(1,exp(2t))`, and A=0 have `Q_h` nonzero while the quotient metric is constant and B=0.

The corresponding generalization of the defect sign is useful for preventing a stronger, unsupported extension. Using `F=g^-1 R^T h` and `R^T hN=0` gives

\[
\mathcal E
=g^{-1}S^\top h+g^{-1}R^\top Q_hN.
\]

Therefore metric compatibility gives `E=g^-1 S^T h`, with the h-adjoint replacing the Euclidean transpose. Without compatibility, a second term remains. The algebraic curvature identity still reads `K_B=FK_AR+E wedge S`, so in the general incompatible case it becomes

\[
K_B=FK_AR+g^{-1}S^\top h\wedge S
 +g^{-1}R^\top Q_hN\wedge S.
\]

One must not transfer the Euclidean formula by simply relabeling h. This is an explicit assumption boundary, not an error in the note, whose transpose curvature formula is established with h=I and skew A and whose later nonmetricity identity retains the compatibility issue.

**Failure condition:** resetting h under GL changes, identifying covariance with precision without the inverse, or dropping the `Q_h` term invalidates the corresponding extensions. **Open gap:** none for equations (12)-(14); any new source-metric implementation must choose its metric and source compatibility explicitly. **Novelty fingerprint:** coordinate covariance, statistical covariance, and nonmetricity are separately typed. **Proposed disposition:** the stated coordinate and nonmetricity identities reconstruct.

## PCV5: composition and the metric reset counterexample

**Family:** PCV5-composed-minimum-norm-lifts. **Kind:** LEMMA and COUNTEREXAMPLE. **Target:** author equations (15)-(17). Take smooth surjections F and G of fixed ranks and a declared source h. Define `g_1=(Fh^-1F^T)^-1` and use precisely `g_1` as the source metric for G. Then

\[
R_FR_G
=h^{-1}F^\top g_1g_1^{-1}G^\top
 (Gg_1^{-1}G^\top)^{-1}
=h^{-1}(GF)^\top((GF)h^{-1}(GF)^\top)^{-1}
=R_{GF}.
\]

The final quotient metric also equals the direct one. With `B_1=F(dR_F+A_0R_F)` and `B_2=G(dR_G+B_1R_G)`, the product rule gives

\[
B_2=(GF)\big(d(R_FR_G)+A_0R_FR_G\big).
\]

The lift identity therefore proves equality of staged and direct connections. No assumption `DF=0` or `DG=0` was used. Source metric compatibility is needed for compatibility of the induced connections, not for this composition algebra. It is essential that the intermediate source connection for the second stage is the actual B_1, not a separately reset prescribed connection.

For arbitrary right inverses let `C=GF` and `Delta R=R_FR_G-R_C`. Since `C Delta R=0`, differentiation gives `C dDelta R=-dC Delta R`. Thus the connection difference is exactly `(CA_0-dC)Delta R`. The projected construction composes because its propagated metric makes `Delta R=0`; a coincidental vanishing of this final expression can also make a particular inconsistent choice agree, so metric propagation is sufficient rather than a necessary condition for every possible instance.

For the author's constant `F=[[2,0,0],[0,1,0]]`, `G=(1,x)`, and A_0=0, the true intermediate metric is `diag(1/4,1)`. Resetting it to I gives `R_G=(1,x)^T/(1+x^2)` and B_2=`-x dx/(1+x^2)`. Direct projection of `(2,x,0)` gives `-x dx/(4+x^2)`. At x=1 these are `-dx/2` and `-dx/5` in the same final coordinate. Propagating the metric instead gives `R_G=(4,x)^T/(4+x^2)` and restores the direct result. Both scalar curvature forms vanish, as they must; the counterexample concerns equality of the connection and metric in a fixed coordinate, not different scalar curvatures.

**Failure condition:** metric or intermediate-connection resets remove the stated composition hypothesis; changing rank removes the inverse construction. **Open gap:** none for the theorem or this counterexample. **Novelty fingerprint:** associative projection requires consistent splittings, while exact descent is a separate condition. **Proposed disposition:** equations (15)-(17) reconstruct.

## PCV6: scalar weights do not supply extra curvature

**Family:** PCV6-common-channel-scalar-weights. **Kind:** LEMMA. **Target:** author equations (18)-(19) and the current fixture interpretation. On a constant-support region let `L=(lambda_1 I_d,...,lambda_r I_d)`, with positive normalized scalar weights, and let the source connection repeat the same internal A_* on all children. Define `sigma=sum_i lambda_i^2`.

Since `L L^T=sigma I_d`, the metric lift is the block column with entries `lambda_i I_d/sigma`. Multiplication of `(L A-dL)R_L` gives

\[
B=A_*-\frac{\sum_i\lambda_i d\lambda_i}{\sigma}I_d
 =A_*-\frac12d\log\sigma I_d.
\]

Write the added scalar one-form as omega. Then `domega=0`, `omega wedge omega=0`, and `A_* wedge omega I+omega I wedge A_*=0`. Consequently `K_B=K_A*` even if A_* is non-Abelian and the scalar weights depend on several coordinates. In the present fixture each channel is SO(2), so this includes both independently configured common channel connections.

In quotient-orthonormal coordinates the lift blocks are `t_i I_d`, with `t_i=lambda_i/sqrt(sigma)` and `sum t_i^2=1`. Its induced connection is A_* because `sum t_i dt_i=0`. The second fundamental blocks are `dt_i I_d`, and their quadratic wedge contribution is `sum dt_i wedge dt_i I_d=0`. Thus a varying subspace can have a nonzero first-order defect while adding no curvature.

Descent would require `B=A_*-dlog(lambda_i)I_d` for every positive weight. Equality of these forms and `sum lambda_i=1` force every derivative to vanish. The no-descent result for varying normalized weights therefore survives the metric interpretation. Parent block separation and orthogonal agent/parent frame changes do not create another curvature term.

Read-only source inspection confirms the common-source hypothesis: `connections.reference_generator` repeats the same `(kappa_b,kappa_m)` pair across labels, and `connection_geometry` adds the corresponding common reference one-form. `parent_compatibility` returns the metric-projected candidate but measures skew compatibility against its declared Euclidean target coordinates. It neither propagates quotient metrics nor replaces the separately prescribed source connection at later levels. That existing diagnostic remains valid under its own contract. The inspected `connections.py` SHA256 is `53a497039842ad16efa1ac3b335d4a8c6c44abcb4ae4f9d237180a58e5452bb9`.

**Failure condition:** child-specific A_i, matrix-valued weights, metric resets, or arbitrary representation mixing are outside the scalar common-source lemma. An absent parent has no metric defined by this inverse. **Open gap:** no extra-curvature term exists in this fixture to implement from this mechanism alone. **Novelty fingerprint:** subspace variation and curvature generation are different conditions. **Proposed disposition:** the fixture specialization reconstructs and preserves the existing obstruction.

## PCV7: what the construction does not supply

**Family:** PCV7-statistical-scope-and-autonomy. **Kind:** CONSTRUCTION and COUNTEREXAMPLE. **Target:** author Section 8. For the expressly selected reference Gaussian `N(0,I_n)`, pushforward gives covariance `H=FF^T`. The mean-family score is `H^-1(y-m)`, so its score covariance is `H^-1 H H^-1=g`. This is a mean-parameter Fisher metric with H held fixed. It is not the full Gaussian Fisher metric, a base Fisher metric, or automatically the actual source prior metric. In general the full Gaussian family also has covariance tangent terms, and changing the base can change H as well as m.

Inverting metric compatibility gives `dH+BH+HB^T=0`, which proves parallelness of this selected reference covariance. For arbitrary fine moments, direct differentiation gives

\[
(d+B)(F\mu)=F(d+A)\mu+\mathcal E\mu,
\]

and

\[
d(F\Sigma F^\top)+B(F\Sigma F^\top)+(F\Sigma F^\top)B^\top
=F(d\Sigma+A\Sigma+\Sigma A^\top)F^\top
 +\mathcal E\Sigma F^\top+F\Sigma\mathcal E^\top.
\]

These discarded-state terms vanish for the isotropic reference because `E F^T=ERH=0`, but not for general means or covariances. A concrete autonomy counterexample already exists with flat source A=0 and `F(t)=(1,t)`. At t=0 the projected scalar connection is B=0. The constant fine Gaussians `N((0,0),I_2)` and `N((0,1),I_2)` have the same parent law `N(0,1)` at that point but different parent mean derivatives, 0 and 1. Thus the induced metric connection, zero projected curvature, and an equal present parent law do not determine an arbitrary pushed-forward trajectory. This is consistent with, not a refutation of, the author's stated distinction.

A GL coordinate change also does not create a VFE correction by itself. The transformed density has its Jacobian factor, covariance transforms as `H'=THT^T`, and precision as `g'=T^-TgT^-1`. Applying the same declared coordinate change and reference measure to recognition and generative laws preserves their KL. Adding a context-only scalar C to a latent action gives `Z'=exp(-C)Z` and leaves the normalized law unchanged. A latent-dependent curvature action would instead require new generative-model data and a finite normalizer; the connection identities alone do not provide them.

**Failure condition:** interpreting a sample-space quotient metric as the complete statistical geometry, interpreting a projected connection as autonomous descent, or adding an unnormalized curvature penalty exceeds the construction. **Open gap:** any such statistical or dynamical extension needs its own explicit model and proof. **Novelty fingerprint:** geometrical representative selection, statistical family geometry, and normalized VFE terms are distinct declarations. **Proposed disposition:** the author's probabilistic qualifications reconstruct.

## Final cross-lane answer

No algebraic sign, general-coordinate formula, coordinate convention, or staged/direct theorem correction is requested for the frozen author note. The additional h-adjoint and nonmetricity formulas above delimit extensions beyond its Euclidean curvature proof. All conclusions are conditional mathematical derivations, with no code or numerical acceptance claim. The common scalar-weight fixture supplies no new projection curvature; adopting an induced connection still does not admit a previously obstructed parallel coarse map or autonomous parent inference. Root owns any implementation choice, mechanical execution, and ledger handling.
