<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Holonomy likelihood intake for the neighborhood joint

Revision 1, frozen September 9, 2026. The proposed finite SO(2) curvature-label/Gaussian loop-observation bridge is new integration with the actual neighborhood local joint. Normalized gauge-dependent likelihoods, posterior link reweighting, retained Gaussian mixtures, operational transport readouts, and explicit curvature-dependent VFE models already exist elsewhere in the repository. Reimplementing those whole frameworks would duplicate existing work. What is missing in the inspected live paths is the small adapter that makes the neighborhood's prescribed connection parameters latent and couples their loop transport to its existing matter law through an additional normalized observation.

This is a bounded read-only source intake, not an execution result or an audit of all RG code. The inspected paths and formulas below are the authority. Searches across the named SU(2), SO(3), conditional-Gaussian, mixture, and curvature-model modules found no import or call to `neighborhood.inference.build_context` or `connections.path_transport`; their constructors instead build their own declared finite-graph or two-sphere models. No code, tests, GPU work, ledger changes, artifact modifications, or Research-vault writes were performed. Only this Markdown is owned. The exact bridge below is a proposed bounded model declaration and proof outline, not a claim that it is implemented or independently verified.

## What already exists

Paths in this table are relative to the repository root `C:/tmp/elbo-cover-20260908`; function names identify the executable seam.

| Live source and functions | What the code actually constructs | Relevance and limit |
|:--|:--|:--|
| `src/multiagent_elbo/geometry/discrete_holonomy.py`: `open_path_transport`, `cycle_holonomy`, `operational_record_law` (line 685) | Products of declared graph links; transported state sums; covector logits followed by an explicitly normalized softmax over marks | An operational transport-dependent conditional record law already exists. Its states and links are supplied deterministic inputs; it does not assemble the neighborhood matter prior or infer a latent continuous connection. Replacing the proposed Gaussian sensor with this softmax would lose conjugate Gaussian conditioning. |
| `src/multiagent_elbo/rg_v2/contextual_geometry_model.py`: `gaussian_density`, `mean_fisher`, `local_state`, `transport`; `contextual_holonomy_model.py`: `local_state`, `transport` | Fixed-covariance Gaussian mean sections on S1; prescribed SO(2) connections; the half-turn transport `g_to R((to-from)/2) g_from^T`; covariance-aware mean Fisher calculations | The inspected continuous SO(2) path is section/transport geometry. The mean and covariance are assigned separately from the connection coefficient. There is no likelihood or posterior over a latent connection parameter. Its one-dimensional base can have nontrivial loop holonomy while its curvature two-form vanishes, so it is not a constant-curvature planar likelihood implementation. |
| `src/multiagent_elbo/rg_v2/su2_loop_model.py`: `assemble_precision` (108), `gaussian_moments` (152), `condition_gaussian` (158); `su2_loop_experiment.py`: `evaluate_links` (198), `haar_links`, sampling loop (480) | A 32-dimensional normalized Gaussian conditional on four SU(2) graph links, with transported quadratic edge energies and mixed matter terms; unit-noise observation at site 3; exact Gaussian integration conditional on each link tuple | A continuous latent-link posterior already exists statistically. The runner samples Haar link tuples, weights the prior by `exp(beta*w)`, then reweights by the integrated Gaussian likelihood. The continuous link integrals and posterior observables are sampling estimates with stated qualifications, not exact finite mixtures or a neighborhood VFE evaluator. |
| `src/multiagent_elbo/rg_v2/so3_quotient_model.py`: `precision_quaternion`, `precision_rotation`, `_gaussian_view` (138), `evaluate_su2`, `evaluate_so3`, `make_primitives` (223) | A 24-dimensional Gaussian-matter conditional using adjoint SO(3) links; quaternion and rotation-matrix views; normalized observation likelihood; prior and posterior weights using the loop character | This already establishes the operational gauge-matter pattern and a quotient representation comparison. It uses its own four-edge graph, matter dimension, site observation, and common-sample statistical integrals. It does not join the neighborhood event/Gaussian law or its cover channels. |
| `src/multiagent_elbo/rg_v2/conditional_gaussian_model.py`: `precision_from_factors` (198), `observation_posterior` (209), `observation_evidence` (218), `build_source` (434), `contract_parent` (428) | Two fixed D4 link controls, a 32-coordinate Gaussian matter prior, normalized Gaussian observation, exact rational precision/Schur algebra and symbolic log evidence; geometry and posterior are retained under root selection | It is fixed-link conditioning, not inference over continuous curvature. The observation is a site-3 selector with unit noise; link dependence enters the matter prior precision. Its fixed dimensions, representations, Fraction arithmetic, and selectors are not an adapter for the neighborhood's smooth SO(2) maps. |
| `src/multiagent_elbo/rg_v2/link_mixture_model.py`: `MixtureEvidence`, `MixtureParent`, `posterior_token`, `contract_mixture`; `four_link_mixture_model.py`: `FourEvidence`, `FourParent`, `simplex_token`, `contract_four` | Finite retained Gaussian mixtures over two or four D4 link representatives, posterior component weights from component evidence, direct/staged component contraction, full mixture moments with between-component covariance | The finite latent-field-label pattern and retained-mixture composition already exist. These public schemas admit the frozen D4 controls, equal two-/four-way priors, and saved component packets. `link_mixture_experiment.validate_config` fixes those inputs and source identities. They should not be generalized or replayed merely to add the neighborhood bridge. |
| `src/multiagent_elbo/rg_v2/mixture_accuracy_model.py`: `certificate` (213) | Bounds for replacing a Gaussian mixture by its moment Gaussian, distinguishing decorated-label KL from marginalized-matter KL | Existing code already respects that a marginalized mixture is not a Gaussian. The bridge can avoid a new approximation problem by retaining the curvature label in its coarse carrier. |
| `src/multiagent_elbo/rg_v2/curvature_models.py`: `compact_link_record` (23) | Exact Fraction joint masses on 16 link states, 16 spin states, and two observations; normalized spin conditional and flux-dependent Bernoulli likelihood; exact posterior masses and floating VFE/conditional-KL evaluations | A normalized holonomy/flux likelihood, latent field posterior, and full/link/flux VFE chain already exist in this finite Z2 model. Curvature action, Haar reference entropy, and the log normalizer are all present. It is not the Gaussian neighborhood joint. |
| Same module: `base_curvature_record` (194) | A two-sphere latent component prior with scalar-curvature potential; a separately declared unnormalized Gaussian factor model with determinant correction; normalized-conditional and constant-curvature cancellation controls | Base curvature already enters a deliberately specified normalized model here. It does not introduce a base-curvature term into a fixed neighborhood context. The observation is one certain symbol and the two-sphere component is the random variable. |

The SU(2)/SO(3) observation is not literally `(U_loop-I)Pz`: their link-dependent Gaussian prior and gauge-invariant loop-weighted field prior produce the observation dependence after matter integration. The compact-link model uses a direct flux likelihood. These are existing normalized realizations of related mechanisms, not the proposed sensor on the neighborhood source law.

## The current neighborhood seam

The configured `experiments/rg_v2/neighborhood_inference.py` contains `kappa_b=.7`, `kappa_m=-.4`, the five contexts, and the existing local-tree Fisher family. `inference.build_context` (line 37) passes both curvature parameters to `nonflat.cover`. That function first calls `local_tree.cover(c,coupling,frame_scale,chart)` without either kappa. It then replaces the connection and curvature arrays and computes geometric defects. It does not replace the already constructed Gaussian/event priors, posterior laws, evidence, observations, or coarse maps.

`local_tree.cover` (251) constructs the Gaussian from compatible local node/pair blocks, forms its two-row weighted observation H, fixes noise `R=.6 I_2`, conditions with `model.condition`, and combines its evidence with `event_system`. The event likelihood and all local Gaussian source factors depend on c and coupling, not either curvature parameter. `inference.build_context` extracts those laws and the supported H/R/o, and its fixed-context inference compares Gaussian/event states to those frozen targets. Thus kappa has no likelihood or prior entry in that evidence problem. This is a code-path conclusion, not a numerical invariance claim from an unrun sweep.

`connections.connection_geometry` and `path_transport` do use the kappas. In moving-context execution they can alter the transported recognition trajectory and therefore the VFE of that trajectory against a moving target. That is an effect of the prescribed inference/transport dynamics; it is not a curvature energy in the frozen-context normalized joint and does not infer the kappas. The separate prescribed parameters remain intentionally valid model inputs.

Fisher geometry likewise currently defines exact or constrained natural inference updates and statistical diagnostics. A Fisher metric or its curvature does not appear automatically as a scalar energy in `inference.accounting`. Base curvature is absent from this fixed-c neighborhood law; its existing normalized example is the separate two-sphere model above. Gauge curvature, Fisher curvature, and base scalar curvature therefore need separate model statements rather than a shared unlabeled VFE term.

## Smallest compatible loop-observation model

Let c be a fixed admitted neighborhood context, with supported Gaussian matter z, latent event e, and existing observation o_0. Retain the actual local joint

\[
p_0(z,e,o_0)=p_G(z)p_E(e)L_G(o_G\mid z)L_E(o_E\mid e).
\]

Introduce a finite label k with declared positive masses `pi_k` summing to one. Each label denotes one constant pair `(kappa_b,kappa_m)` in the existing SO(2) connection family. This is a finite prior over a restricted family of prescribed fields, not a measure on all connections. Let P select the four belief/model coordinates of one agent present at c. Declare a closed polygon based at c and contained in that agent's open domain. The selected agent's loop transport is

\[
U_k=\operatorname{path\_transport}(\text{loop},[\text{agent}],\kappa_k),
\qquad H_k=(U_k-I_4)P.
\]

The new observation r has the normalized conditional law `N(r;H_k z,R_loop)`, with fixed positive-definite noise. The augmented joint is

\[
p(k,z,e,o_0,r)
 =\pi_k p_0(z,e,o_0)\mathcal N(r;H_kz,R_{\rm loop}).
\]

Every new factor is normalized in its own variable. Integrating k,z,e and all observations gives one. No prior-only deterministic curvature constant is added. The new likelihood genuinely couples the latent field label to matter and data; the original observation remains present and counted once.

The loop admission is new but small: require exact closure of the declared endpoints, basepoint c, at least a nondegenerate declared polygon if curvature sensitivity is wanted, and every vertex strictly inside the selected agent domain and U. Because these are convex strips, every straight polygon segment then remains inside the same agent domain. Other agents need not exist around the loop when P selects only this one agent. `path_transport` itself checks U but does not establish this agent-domain condition or require a closed loop, so the bridge must do so. It should use the selected-agent label rather than pretending an unequal-rank whole population is transported around the loop.

For this constant SO(2) family, a based closed polygon gives reference rotations with angles `-kappa_b*area` and `-kappa_m*area`, conjugated by the existing basepoint frame. Distinct curvature pairs can give identical loop transport modulo `2 pi/area`; an isotropic zero-mean matter marginal can also make positive and negative angles observationally indistinguishable. The bridge should report component likelihoods and posterior weights, not promise unique curvature recovery. A zero-area loop makes H_k zero and provides a null observation control.

Under passive chart changes let the fine law transform by Q and the probe coordinates by V. The same measurement has `P'=V P Q^-1`, `U_k'=V U_k V^-1`, `r'=Vr`, and `R_loop'=V R_loop V^T`. Then `H_k'=V H_k Q^-1`. These are the required observation-square and evidence-invariance identities. Keeping arbitrary nonisotropic noise or a nonzero observed vector numerically fixed while changing its coordinate chart would describe different observations. Isotropic noise is convenient, but it does not remove the need to transform r.

## Exact finite evidence, posterior, and VFE

Write the existing posterior given o_0 as `N(mu_0,Sigma_0)` times the existing event posterior, with evidence Z_0. For each label,

\[
S_k=R_{\rm loop}+H_k\Sigma_0H_k^\top,\qquad
\ell_k=\mathcal N(r;H_k\mu_0,S_k),
\qquad Z=Z_0\sum_k\pi_k\ell_k.
\]

`model.condition` computes the corresponding Gaussian conditional and log evidence, so it can condition the existing posterior with the added observation. Its current implementation expects batched observation tensors when assembling `log_Z`; the bridge should provide an explicit component batch or a leading singleton dimension. A second, stacked-observation calculation using `H_stack=[H_0;H_k]`, block-diagonal noise, and the original Gaussian prior supplies an independent evidence/conditioning identity. It must reproduce `log Z_G0+log ell_k`; event evidence is added once.

The exact posterior field masses and conditional matter laws are

\[
\omega_k=\frac{\pi_k\ell_k}{\sum_j\pi_j\ell_j},\qquad
z\mid k,o_0,r\sim\mathcal N(\mu_k,\Sigma_k).
\]

The event posterior is unchanged and independent of k,z because the added likelihood does not involve e. Finite sums plus the analytic Gaussian formulas are exact mathematical expressions; evaluation with arbitrary trigonometric kappas is floating arithmetic, not the older D4 Fraction certificate.

A retained recognition family `q(k,z,e)=a_k Q_k(z)q_E(e)`, with normalized positive a and Gaussian Q_k, has the computable full joint VFE

\[
\mathcal F
 =\operatorname{KL}(a\|\omega)
  +\sum_k a_k\operatorname{KL}(Q_k\|\mathcal N(\mu_k,\Sigma_k))
  +\operatorname{KL}(q_E\|p_E(\cdot\mid o_E))
  -\log Z.
\]

Its generative-factor evaluation is independently

\[
\begin{split}
\mathcal F={}&\operatorname{KL}(a\|\pi)
 +\sum_k a_k\operatorname{KL}(Q_k\|p_G)
 +\operatorname{KL}(q_E\|p_E)\\
&-\sum_k a_k\mathbb E_{Q_k}\log L_G
 -\mathbb E_{q_E}\log L_E
 -\sum_k a_k\mathbb E_{Q_k}\log\mathcal N(r;H_kz,R_{\rm loop}).
\end{split}
\]

`local_tree.gaussian_expected_log_likelihood` already supplies each Gaussian likelihood expectation, including covariance trace and normalization. The source model remains locally assembled, but arbitrary posterior Q_k need not lie in the local-tree recognition family. Therefore the existing `inference.accounting` clique-minus-separator reconstruction must not be reused as if it evaluated every full Gaussian component; use its dense prior-KL/likelihood ingredients instead. An exact Bayes posterior is already a complete bounded field-inference result. If iterative full-joint Fisher flow is subsequently requested, independently evolving field weights and conditional Gaussians is insufficient: the Gaussian power-overlap normalizers also reweight the components. That extra dynamic interface is unnecessary for the smallest bridge and should not be silently implied.

## Common coarse channels and the retained label

Use the actual neighborhood maps and event channels, and retain k unchanged:

\[
C_l:(k,z,e)\longmapsto(k,F_lz,K_le).
\]

These maps are common to recognition and posterior and independent of k in the current neighborhood construction. At every level the exact retained joint remains a finite label with Gaussian components and the pushed event law. Its KL is `KL(a||omega)+sum a_k KL(F_l#Q_k||F_l#P_k)` plus the event KL. The discarded correction is

\[
\sum_k a_k\mathbb E_{Q_k(Y)}
\operatorname{KL}(Q_k(X\mid Y)\|P_k(X\mid Y))
 +\text{event conditional KL}.
\]

`local_tree.gaussian_discarded_kl` already computes the Gaussian term independently from conditional means/covariances; `event_discarded_kl` supplies the common stochastic-channel term and preserves structural support. Alternatively, `gaussian_completion.make_split/decompose` can retain the actual conditional states when reconstruction is desired. The field-weight KL remains at every level because k is retained. Direct/staged Gaussian pushes and event-channel products give the existing composition identities component by component, and conditional corrections telescope.

Dropping k changes the problem. The parent matter law becomes a Gaussian mixture, and neither its log density nor its KL is generally a single Gaussian formula. `link_mixture_model` already labels moment-form Gaussian output as an approximation rather than the next exact parent. The shortest bridge should keep k and every component instead of adding an unnecessary marginalized-mixture integration or projection problem.

## Minimal proof and implementation obligations

| Dependency | Bounded obligation | Existing implementation to reuse |
|:--|:--|:--|
| Declared model | Specify finite curvature pairs and positive prior masses, one context, one probe agent/selector, closed admissible loop, observation and SPD noise; state the common reference measures | Existing neighborhood `ContextModel`, source Gaussian/event laws and independent geometry parameters |
| Observation covariance | Prove the chart square for H_k and transform r/R with the probe frame; prove loop support and closure | `connections.path_transport`, `model.frame_geometry`, supported coordinate selection in `inference.build_context` |
| Normalization and inference | Establish the augmented joint, sequential/stacked evidence identity, normalized omega, SPD conditional components, and unchanged event posterior | `model.condition`, `local_tree.gaussian_expected_log_likelihood`, `model.gaussian_kl`, stable finite log-sum-exp |
| Joint accounting | Evaluate both full VFE expressions and reach `F=-log Z` at the full posterior without moment-matching a mixture | Existing Gaussian and event KL primitives; a small retained-label wrapper is new |
| Coarse accounting | Retain k, push every component through the actual F_l/K_l, evaluate independent conditional corrections, and compare direct/staged results | `push_gaussian`, `gaussian_discarded_kl`, `event_discarded_kl`, optional complete conditional states |
| Scientific controls | Check zero-area/null sensor, repeated-identical field labels, passive-chart invariance, sequential/stacked conditioning, posterior normalization, and conditional-chain identities | Focused new controls are needed only after implementation; none ran here |

A minimal new module can expose a model builder for the loop observation, a retained-joint accounting function, and componentwise coarse accounting. It should wrap the existing neighborhood model rather than alter its default law, replace its prescribed kappas, generalize the frozen D4 artifact consumers, introduce a full lattice-gauge sampler, or add a new inference framework. A separate editable profile would make the new random curvature label and observation declaration reviewable. No implementation is claimed or performed by this intake.

## Source binding

The following hashes bind the load-bearing inspected seams. Related table entries were read for their narrower interface statements; no prior artifact was replayed or re-certified.

| Source | SHA256 |
|:--|:--|
| `experiments/neighborhood/connections.py` under `src/multiagent_elbo` | `53a497039842ad16efa1ac3b335d4a8c6c44abcb4ae4f9d237180a58e5452bb9` |
| `experiments/neighborhood/nonflat.py` | `627e2cc1694f264bf4584c3c88fdcb73b2793b8f41d25013d094c3c31fb35a24` |
| `experiments/neighborhood/local_tree.py` | `6d9fcf0098be7ab44bb577eee6eee8909d30b0d35d0ce15b0f22521de93a5d2d` |
| `experiments/neighborhood/model.py` | `49af1bf02b9cd5030b8ee9d9fecf945d50cde0106f448efa51c2ae571562d94b` |
| `experiments/neighborhood/inference.py` | `ade492121f2c261c06033955711199d4052602315acec8dac7be716692fc2251` |
| `experiments/neighborhood/gaussian_completion.py` | `a561bba6863719ec54fe5f865e5a40eeb5e50b74f680c2a856440ef3eac79ee2` |
| `geometry/discrete_holonomy.py` | `3a472a32bbee33f48ffe04894fdaae51994813625f7326de72eaf1f44aa5da5c` |
| `rg_v2/contextual_holonomy_model.py` | `451dd92108c02eed8f409e37b17e78b6ac676d961a5f46417329df9982a40845` |
| `rg_v2/conditional_gaussian_model.py` | `6d7c5089f77686c5a9afa0f1c6c51537b7ea82d21e0c08ef357364dc1e095ed8` |
| `rg_v2/link_mixture_model.py` | `602bf2a8d7e4a124357aa391f779fa04f50f444f4ac9b42a84d2a8b0a470c5fd` |
| `rg_v2/link_mixture_experiment.py` | `22645bc3384ecfbffe7ed5f97b2853d05c42478d43bfa602a61be41f2ddef99d` |
| `rg_v2/su2_loop_model.py` | `f3f73d77636486c103b8e208a5a116eeb75f84dccebd194ade8fc39e62e377f2` |
| `rg_v2/su2_loop_experiment.py` | `e9361c48c9ab8d226ad4530c8c58a6eca5cbcea636c91b6733b353960543b346` |
| `rg_v2/so3_quotient_model.py` | `7cc54db3810c0baafdb75289797487048eb814c09a4070a96c375fdff18c7c13` |
| `rg_v2/curvature_models.py` | `023e9152317f2745b60d8841860f38c5f966ab226400122b69743b9719248bc1` |

## Cross-lane answer

The missing work is a normalized observation adapter and retained-label joint for the neighborhood, not another general holonomy or mixture framework. Gauge curvature would enter this VFE through a declared likelihood and an inferred finite field label. Existing Fisher and base-curvature constructions remain separate: neither contributes an extra term solely because a connection or metric has been computed. Root can use the explicit obligations above to choose the next bounded implementation without repeating the existing finite-link, continuous-group, or curvature-model studies.
