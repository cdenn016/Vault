﻿<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Positive ladder gauge-matter construction and exact limiting obstruction

September 9, 2026. This is a direct reconstruction of the mechanism proposed by root and admitted in `docs/research-plans/2026-09-09-positive-ladder-rg.md`. Root supplied the candidate transfer and observable before this lane began. Shared context, model, and filesystem are disclosed; this is not an independent invention or a claim of prior erasure. The earlier SPEC reconstruction read all 1,032 lines of `Theory/SPEC.md`. Only this Markdown is owned. No scientific code, tests, numerical experiments, GPU jobs, ledger changes, or vault edits were performed. The arguments below use finite algebra and an elementary contraction proof; no Perron theorem is imported without proof. They assign no formal claim-ledger closure state.

**The proposed family works at fixed finite width and strictly positive transfer entries.** It supplies a normalized nonflat gauge-matter family, exact coarse channels, generated interactions beyond the initial ansatz, thermodynamic cylinder laws, and increasing-depth limits. Its positive normalized power fixed objects have independent coarse cells and uniform rail increments. A local rung bias can survive, so the obstruction concerns interacting critical behavior between cells, not every possible local gauge-matter interaction. None of these statements supplies a continuum connection measure, a two-dimensional width limit, or a result uniform at a closing positivity gap.

## 1. Raw variables, gauge action, and quotient multiplicity

Fix an integer `N >= 1`, with indices modulo N. At cell i write top and bottom matter spins as `sigma_i,tau_i in {−1,+1}`, the vertical rung link as `v_i`, and the upper/lower oriented rail links from i to i+1 as `u_i,l_i`. These are `5N` independently labeled binary coordinates before weighting. In particular, N=1 retains labeled self-loop links and N=2 retains distinct parallel edge copies. They are not silently converted into a simple graph.

A vertex gauge `(g_i,h_i)` acts by

\[
\sigma_i'=g_i\sigma_i,\quad \tau_i'=h_i\tau_i,\quad
v_i'=g_iv_ih_i,\quad
u_i'=g_iu_ig_{i+1},\quad
l_i'=h_il_ih_{i+1}.
\]

All group products are in Z2. The gauge-invariant coordinates are

\[
r_i=\sigma_iv_i\tau_i,\quad
x_i=\sigma_iu_i\sigma_{i+1},\quad
y_i=\tau_il_i\tau_{i+1}.
\]

The plaquette is

\[
H_i=v_i u_i v_{i+1}l_i=r_ir_{i+1}x_iy_i.
\]

For every `(r,x,y)` and every choice of the `2N` matter spins, the unique raw links are

\[
v_i=\sigma_ir_i\tau_i,\quad
u_i=\sigma_ix_i\sigma_{i+1},\quad
l_i=\tau_iy_i\tau_{i+1}.
\]

Thus the change of variables `(sigma,tau,v,u,l) <-> (sigma,tau,r,x,y)` is a bijection. Every invariant configuration has exactly `2^(2N)` raw preimages, and the gauge action is free because it acts freely on the matter-spin coordinates. Normalized product counting measure on raw variables pushes to normalized product counting measure on the `3N` invariant coordinates, with independent uniform matter-spin frames in the reverse construction.

These multiplicities are part of the law, not an untracked gauge-volume constant. The construction concerns one Z2 graph gauge group with independent vertex frame choices. Its rail names do not identify either rail with the manuscript's belief or model associated bundle, and graph flux is not a smooth curvature two-form.

## 2. One normalized interacting law

For `0 <= a,b,c < 1`, define the strictly positive density relative to the raw normalized product counting reference by

\[
W_N=\prod_{i=0}^{N-1}
(1+a r_i)(1+b x_i)(1+b y_i)(1+cH_i).
\]

Let `G=Z2 x Z2` and use `g=(x,y)` for its four elements. Define

\[
K(r,s,x,y)=\frac{(1+a s)(1+b x)(1+b y)(1+c rsxy)}{8}.
\]

The factors of 1/8 include the references for one destination rung and the two rail increments. The destination convention counts each rung term exactly once on a ring. Direct summation gives

\[
M(r,s)=\sum_{x,y}K(r,s,x,y)
=\frac{(1+a s)(1+c b^2rs)}{2}.
\]

Indeed the sum of `(1+b x)(1+b y)` is 4 and its `xy`-weighted sum is `4b^2`. Therefore

\[
Z_N=\int W_N d\nu_N
=\sum_{r_0,\ldots,r_{N-1}}\prod_iM(r_i,r_{i+1})
=\operatorname{tr}(M^N)>0.
\]

The invariant-coordinate probability mass and its raw lift are respectively

\[
p_N(r,x,y)=\frac{\prod_iK(r_i,r_{i+1},x_i,y_i)}{Z_N},
\qquad
p_N^{\rm raw}(\sigma,\tau,v,u,l)
=2^{-2N}p_N(r,x,y).
\]

Equivalently, the raw probability mass is `2^(−5N) W_N/Z_N`. This is the full jointly normalized factor model. There is no matter-conditional normalizer inside W. Conditionalizing the matter separately and then using the same Z would change the model.

All raw and invariant configurations have positive probability. For example, a plaquette with `H_i=−1` is admitted at every finite N. On the N=1 ring the formulas yield `Z_1=1+cb^2`, consistent with the labeled self-loop convention.

## 3. Actual coupling and its controlled observable

First distinguish a raw factorization claim from a covariance of named quantities. Gauge symmetry and a bijective change of link coordinates imply that the full matter-spin marginal is uniform: any prescribed spin tuple is carried to any other by a vertex gauge, while the corresponding link sum is unchanged.

For `N >= 2`, condition the links to all +1. The all-positive spin configuration and the configuration obtained by flipping one top spin have a factor-weight ratio

\[
\frac{1-a}{1+a}\left(\frac{1-b}{1+b}\right)^2.
\]

The two incident rail edge copies remain distinct when N=2. This ratio is strictly below one if `a>0` or `b>0`. Thus the spin law conditional on those links is not uniform. If the raw spin and link laws factored, that conditional spin law would equal the uniform marginal, a contradiction. This proves genuine raw gauge-field/matter nonfactorization in the scientific example. When `a=b=0`, W depends on the links through the plaquettes alone, and raw spins and links factor exactly. That is the stated uncoupled control at the same c.

Now let `B_i=r_i r_(i+1)`. The pair `(H_i,B_i)` is gauge invariant; B is a dressed matter relation and is not a bare gauge-free matter coordinate. Conditional on all rung values, the rail pairs of different cells are independent, and

\[
\mathbb P(x_i=x,y_i=y\mid r)
=\frac{(1+bx)(1+by)(1+cB_i xy)}{4(1+cb^2B_i)}.
\]

Consequently, with `d=b^2`,

\[
\mathbb E[H_i\mid B_i=B]=\frac{c+dB}{1+cdB}.
\]

For `p_+=P(B_i=+1)` the complete two-variable law is

\[
\mathbb P(B_i=B,H_i=H)
=\mathbb P(B_i=B)\frac{1+H(c+dB)/(1+cdB)}{2}.
\]

The rung probabilities themselves are given exactly by the ring transfer:

\[
\mathbb P(B_i=B)
=\frac{\sum_{r,s:rs=B}M(r,s)(M^{N-1})(s,r)}{\operatorname{tr}(M^N)}.
\]

These formulas yield

\[
\operatorname{Cov}(H_i,B_i)
=\frac{b^2(1-c^2)}{1-c^2b^4}\operatorname{Var}(B_i).
\]

For `N>=2`, full support gives positive probability to both values of B, so this covariance is strictly positive when `b>0`. It vanishes at `b=0`. At `a=b=0`, the stronger raw factorization above also holds; a vanishing covariance alone would not prove it. For N=1, `B_i=1` deterministically, so this candidate covariance cannot witness coupling. A code result claiming strictly positive covariance for every N>=1 would be wrong.

The factor c gives a preference between flux signs; no flatness constraint is imposed. Even after an RG limit removes intercell correlations, nontrivial flux need not disappear.

## 4. Exact blocking on raw configurations

Let `B>=1` divide N, and put `m=N/B`. The anchored block channel keeps the matter spins and rung link at sites Bj and the ordered products of the B upper and lower links between successive retained sites. It discards the remaining variables. This deterministic channel is recognition independent.

Internal gauge factors cancel in each rail-link product. The retained spin and rung variables transform under their original endpoint gauges. Therefore the channel is equivariant with respect to the restriction of a fine vertex gauge to the retained vertices, and internal gauge transformations act trivially on the coarse result.

In invariant coordinates it is exactly

\[
r'_j=r_{Bj},\qquad
X_j=\prod_{t=0}^{B-1}x_{Bj+t},\qquad
Y_j=\prod_{t=0}^{B-1}y_{Bj+t}.
\]

Its invariant-reference fiber has `2^(3(N−m))` elements: there are N−m discarded rung bits and N−m discarded product coordinates on each rail. Its raw-reference fiber has `2^(5(N−m))` elements, including the forgotten spin frames. Both normalized product references therefore push to their corresponding coarse normalized product reference. Uniform retained spin frames remain independent of the retained invariants.

For general transfer tables define matrix/group convolution by

\[
(K*L)(r,t,g)=\sum_{s\in\{\pm1\}}\sum_{h\in G}
K(r,s,h)L(s,t,h^{-1}g).
\]

Finite-sum associativity proves `(K*L)*J=K*(L*J)`. Conditioning on intermediate rung values and rail increments in one block proves that its exact transfer is `K_B=K^{*B}`. For the complete coarse invariant state,

\[
p_{m,B}(r,g)
=\frac{\prod_{j=0}^{m-1}K_B(r_j,r_{j+1},g_j)}{Z_N},
\qquad
\sum_gK_B(r,s,g)=(M^B)(r,s).
\]

Thus its normalizer remains `tr((M^B)^m)=Z_N`. The raw lift has mass `2^(−2m)` times this invariant mass.

With the block origin fixed at zero, direct 6, 2 then 3, and 3 then 2 retain identical raw endpoint variables and identical ordered products, for every N divisible by 6. The deterministic maps are equal before applying any probability law. Their complete retained laws and reference-relative actions are therefore equal. This is a two-scale comparison on one family, not a universality theorem for arbitrary blocking prescriptions or changing block origins.

## 5. Generated actions and failure of the three-parameter ansatz

The exact coarse density relative to its normalized invariant or raw reference is

\[
W_{m,B}=8^m\prod_jK_B(r_j,r_{j+1},g_j),
\qquad
S_{m,B}=-m\log8-\sum_j\log K_B(r_j,r_{j+1},g_j).
\]

It has partition Z_N. The 8 factors are necessary: K is a transfer of probability masses, not a density relative to the normalized three-bit reference. Equivalently, `W_(m,B)` is the conditional expectation of W_N under the reference disintegration of the deterministic block channel. This proves exact action composition without losing constants.

For arbitrary positive K, all 16 values of `log(8K)` have the exact character expansion

\[
\log(8K(r,s,x,y))
=\sum_{e\in\{0,1\}^4}J_e r^{e_1}s^{e_2}x^{e_3}y^{e_4},
\]

\[
J_e=\frac1{16}\sum_{r,s,x,y}
\log(8K(r,s,x,y))r^{e_1}s^{e_2}x^{e_3}y^{e_4}.
\]

This follows from character orthogonality on four binary coordinates. It is a complete finite action representation, not a truncated pair/plaquette approximation. In a ring, some potential coefficients have coboundary or constant redundancies, but storing the whole table does not discard their normalization contribution.

The initial three-parameter ansatz is not closed. Let `d=cb^2`, and define group Fourier matrices

\[
\widehat K_{pq}(r,s)=\sum_{x,y}x^py^qK(r,s,x,y).
\]

The first two are

\[
\widehat K_{00}=\frac{1+as}{2}(1+drs),\qquad
\widehat K_{10}=\widehat K_{01}=\frac{b(1+as)}{2}(1+crs).
\]

Convolution becomes matrix multiplication in each character. Directly summing the intermediate rung gives

\[
\widehat {K^{*2}}_{00}(r,s)
=\frac{1+as}{2}\{1+d^2rs+ad(r+s)\},
\]

\[
\widehat {K^{*2}}_{10}(r,s)
=\frac{b^2(1+as)}2\{1+c^2rs+ac(r+s)\}.
\]

Therefore

\[
\mathbb E_{K^{*2}}[X\mid r=s=\epsilon]
=b^2\frac{1+c^2+2ac\epsilon}{1+d^2+2ad\epsilon},
\]

and the + versus − difference is

\[
\frac{4ab^2(c-d)(1-cd)}{(1+d^2)^2-4a^2d^2}>0
\]

when `a,b,c>0` and all are below one. The denominator is positive because it is the product of two positive endpoint marginal factors. Any member of the original ansatz has the same conditional rail law at `(r,s)=(+,+)` and `(−,−)`, since that conditional law depends only on rs. Thus the blocked table cannot be another member of that ansatz. This witness survives multiplication by an overall positive amplitude or an endpoint coboundary `D(r)^(−1)D(s)`, since those cancel when conditioning the rail increments on r,s. It also survives allowing different initial rail biases: such a model still depends on endpoints only through rs in its conditional rail law.

The special equality between the two single-rail Fourier blocks is inherited by this symmetric initial example, but the algorithm may retain all 16 entries. No claim that every one of the 16 character coefficients is nonzero is needed.

## 6. Evidence, recognition, and full conditional corrections

Take the normalized raw prior above and any separately declared normalized observation channel `L(o|w)`, where w is a raw state. For an admitted observation with positive evidence, let p be its posterior and q any recognition law absolutely continuous with p. Keep o outside every block channel. The same channel sends the generative joint, p, and q to their coarse versions, preserves the evidence, and induces a normalized parent observation evaluator by finite conditional summation. A nonlocal observation can destroy nearest-neighbor transfer factorization of the posterior; the complete finite observed measure must then be retained instead of pretending that the old K alone represents it.

For a deterministic coarse state z, expanding `q(w)=q_C(z)q(w|z)` and its posterior counterpart proves

\[
D(q\Vert p)=D(q_C\Vert p_C)
+\sum_z q_C(z)D(q(\cdot|z)\Vert p(\cdot|z)).
\]

Adding the same `−log P(o)` gives the VFE identity. Its discarded conditional terms telescope under the literal 2/3/6 channel equalities. This is a common-observation comparison; it does not compare different models after forgetting their evidence constants. Structural zeros require the inherited support-aware extended-real convention, not subtraction of infinities.

If q is specified only on invariant coordinates and lifted with independent uniform spin frames, its raw KL against a likewise lifted target equals the invariant-coordinate KL because the uniform factors cancel. If q has a different conditional gauge-frame law, that relative-entropy term is part of the full raw KL and cannot be omitted. The invariant implementation consequently needs either the uniform-lift hypothesis or explicit extra frame-conditionals.

## 7. Perron and Doob construction by finite algebra

The remainder applies to every strictly positive 16-entry transfer table, not only the initial ansatz. Write its two-state marginal as

\[
M=\begin{pmatrix}A&B\\C&D\end{pmatrix},\qquad A,B,C,D>0.
\]

Set

\[
\Delta=\sqrt{(A-D)^2+4BC},\qquad
\lambda=\frac{A+D+\Delta}{2},\qquad
\lambda_- =\frac{A+D-\Delta}{2}.
\]

Then `lambda>max(A,D)>0` and `|lambda_-|<lambda`. The positive vectors

\[
h=(B,\lambda-A)^T,\qquad l=(C,\lambda-A)^T
\]

satisfy `Mh=lambda h` and `l^T M=lambda l^T`, by the characteristic equation `(lambda−A)(lambda−D)=BC`. Dividing l by `l^T h` if desired normalizes that pairing. This proves the needed simple positive eigenpair without importing a Perron theorem. The second eigenvalue is distinct, and

\[
M^n=\lambda^n\frac{hl^T}{l^Th}
+\lambda_-^n\left(I-\frac{hl^T}{l^Th}\right).
\]

In particular, `tr(M^N)=lambda^N+lambda_-^N` for N>=1.

The Doob transfer and its marginal are

\[
P(r,s,g)=\frac{K(r,s,g)h_s}{\lambda h_r},\qquad
\bar M(r,s)=\sum_gP(r,s,g).
\]

Their rows sum to one. The stationary rung law is

\[
\pi_r=\frac{l_rh_r}{l^Th}>0,
\]

as direct summation using the left-eigenvector equation verifies. Scaling K or applying a positive diagonal similarity changes lambda or h but leaves P unchanged: for `K'=alpha D^(−1)KD`, use `lambda'=alpha lambda` and `h'=D^(−1)h`. These are declared transfer-coordinate equivalences preserving normalized periodic ring laws, not physical vertex gauge transformations. The scalar amplitude must still be retained for action and pressure.

For the original ansatz, with d=cb^2, the formula becomes

\[
\lambda_{\pm}=
\frac{1+d\pm\sqrt{(1-d)^2+4a^2d}}2.
\]

All quantities are explicit algebraic functions of the declared parameters. A floating eigensolver is therefore only a numerical evaluation, not the proof of positivity, simplicity, or the gap.

## 8. Eight-state additive-chain contraction

Use states `(r,z)` with r a rung sign and `z in G` the accumulated rail product. Define

\[
T((r,z),(s,w))=P(r,s,z^{-1}w).
\]

This is an eight-state strictly positive stochastic matrix. The distribution `tilde pi(r,z)=pi_r/4` is stationary: sum over the incoming group coordinate to obtain `pi bar M`, and translation of G is a bijection.

Let `epsilon=min T_ij>0`, `delta=8 epsilon`, and `rho=1−delta<1`. When delta<1,

\[
T=\delta U+(1-\delta)R,
\]

where U has every row uniform on eight states and R is stochastic. A stochastic matrix contracts the L1 norm of signed rows, by the triangle inequality and its row sums. The difference of two probability rows annihilates U. Hence

\[
\|\mu T-\nu T\|_{\rm TV}
\leq\rho\|\mu-\nu\|_{\rm TV}.
\]

When delta=1, T=U and the same conclusion holds with rho=0. Iterating against the displayed stationary law proves uniqueness and

\[
\|T^n(i,\cdot)-\widetilde\pi\|_{\rm TV}\leq\rho^n.
\]

Telescoping h factors along a path gives the exact identity

\[
T^B((r,e),(s,g))
=P^{*B}(r,s,g)
=\frac{K^{*B}(r,s,g)h_s}{\lambda^B h_r}.
\]

Thus `P^{*B}(r,s,g) -> pi_s/4`, with row-L1 error at most `2 rho^B` and entrywise error at most `rho^B`. This is a uniform statement over the finite state indices for each fixed positive K. It is not uniform over all positive K approaching a zero entry.

The eight-state chain is an additive-path device. The physical periodic ladder closes the rung index only and sums every total rail-product sector. Its partition is `tr(M^N)`. Using `tr(T^N)` would additionally close the accumulated G coordinate and impose trivial total rail products. That is a different model and is not permitted here.

## 9. Thermodynamic law and pressure at fixed width

For a fixed k-edge invariant window with rungs `r_0,...,r_k` and increments `g_0,...,g_(k−1)`, its periodic N-cell probability, N>k, is

\[
\frac{\left[\prod_{i=0}^{k-1}K(r_i,r_{i+1},g_i)\right]
(M^{N-k})(r_k,r_0)}{\operatorname{tr}(M^N)}.
\]

Substituting the preceding exact spectral formula gives the limit

\[
\pi_{r_0}\prod_{i=0}^{k-1}P(r_i,r_{i+1},g_i).
\]

This defines the unique stationary marked Markov law with the displayed transition P. Its two-sided process can be constructed explicitly: sample r_0 from pi, generate the future with P, and independently generate the past conditional on r_0 with reverse probabilities `pi_r P(r,s,g)/pi_s`; their rows sum to one by stationarity. Independent countable uniform random choices implement those recursions. The resulting finite cylinder probabilities are the displayed expressions, and cylinders determine the law.

Equip the bi-infinite finite-alphabet sequence with the product topology, for example the metric formed by a summable weighted sum of coordinate-disagreement indicators. It is compact and metrizable. Embed each finite ring by periodic repetition with the declared origin. Every fixed cylinder converges as above. A continuous function on this compact product is uniformly approximable by a function of finitely many coordinates, so cylinder convergence proves weak convergence in this topology. Lifting with independent uniform spin frames and reconstructing each link from finitely many neighboring coordinates gives the same finite-cylinder and weak convergence statement for the raw gauge-covariant law.

The pressure relative to the stated normalized product reference is

\[
\lim_{N\to\infty}\frac1N\log Z_N=\log\lambda,
\]

since `Z_N=lambda^N[1+(lambda_-/lambda)^N]`. The reference convention is essential: an unnormalized counting reference shifts pressure by a constant per coordinate. The positive square-root formula makes this pressure real analytic in the strictly positive transfer entries. The finite contraction bound makes dependence of separated bounded cylinder observables decay exponentially, by conditioning on the intervening Markov state and applying the row-TV bound. Thus this fixed-width positive family has no interior singular pressure or infinite correlation length under these definitions of criticality. Parameters tending to a boundary where the positivity bound or spectral gap closes are excluded from this conclusion.

## 10. Increasing depth, both limits, and their topology

Write the original ring size as `N=mB`. For fixed m, the exactly blocked ring uses K_B. Under the Doob representative its mass is

\[
\mu_{m,B}(r,g)=
\frac{\prod_{j=0}^{m-1}P^{*B}(r_j,r_{j+1},g_j)}
{\operatorname{tr}(\bar M^{mB})}.
\]

Endpoint h factors cancel on the ring, and the omitted scalar is exactly `lambda^(mB)` in both numerator and partition. Therefore, as B tends to infinity through any admitted integer block sequence,

\[
\mu_{m,B}(r,g)\longrightarrow
\nu_m(r,g)=\prod_{j=0}^{m-1}\frac{\pi_{r_j}}4.
\]

This is total-variation convergence on the fixed `8^m` invariant ring states. It applies to B=2^ell, B=3^ell, or mixed powers. A quantitative bound follows without a new spectral theorem. Replace each factor `P^{*B}` in the unnormalized cyclic mass by `Q(r,s,g)=pi_s/4` and telescope. Each absolute-difference matrix has row sum at most `2 rho^B`; products of stochastic marginal matrices have row sum one, and a two-state trace is at most twice the maximal row sum. The total L1 difference of unnormalized cyclic masses is at most `Delta_m=4m rho^B`. Its normalizer differs from one by at most the same quantity. Whenever Delta_m<1,

\[
\|\mu_{m,B}-\nu_m\|_{\rm TV}
\leq\frac{4m\rho^B}{1-4m\rho^B}.
\]

For a thermodynamic limit at fixed B, the preceding window proof gives the stationary marked chain with transition `P^{*B}` and the same pi. Sending B to infinity then gives the infinite independent law `nu_infty` with rung law pi and independent uniform G increments.

The reverse iterated limit also exists in the declared coarse-index product topology. First send B to infinity with fixed m, obtaining the periodically repeated independent m-cell ring law nu_m. Then m tends to infinity: any fixed window eventually fits inside one period without repeated coordinates, and its law equals the corresponding independent cylinder. Hence both iterated limits give nu_infty.

A simultaneous statement can also be proved here. For any fixed k-edge coarse window, m>k, its law is

\[
\frac{\left[\prod_{i=0}^{k-1}P^{*B}(r_i,r_{i+1},g_i)\right]
\bar M^{B(m-k)}(r_k,r_0)}{\operatorname{tr}(\bar M^{Bm})}.
\]

If `m_j -> infinity` and `B_j -> infinity`, each edge factor tends to Q, the remainder tends to pi, and the denominator tends to one. The same holds whenever B tends to infinity and m is eventually larger than that fixed window. This proves joint convergence of coarse cylinders, and hence weak convergence when m also tends to infinity. It does not assert total-variation convergence uniformly on the entire growing ring; the displayed bound has an m factor.

These limits use the same fixed positive microscopic K, fixed cell width, anchored block convention, and the algebra of rung states and accumulated rail products at coarse integer sites. Increasing B changes the physical fine support of a coarse observable. The comparison is made through that declared identification, not by calling all observables measurements at the same microscopic distance. It is not a continuum limit of random sections or a claim about an expanding-width lattice.

## 11. Complete positive normalized power fixed objects

The full positive normalized transfer class consists of all 16-entry P>0 satisfying `sum_(s,g)P(r,s,g)=1` for each r. It is closed under convolution. Its marginal has right eigenvector one and Perron eigenvalue one, so no extra Doob choice is needed after normalization.

Suppose `P^{*B}=P` for one integer B>=2. Its eight-state matrix obeys `T^B=T`, hence `T^(B^n)=T` for every n. The contraction limit just proved forces every row of T to equal its stationary law. By group-translation structure,

\[
P(r,s,g)=\frac{\pi_s}{4},\qquad \pi_s>0,\quad \sum_s\pi_s=1.
\]

Conversely, direct convolution shows that every table of this form is fixed under every B. This classifies all strictly positive normalized fixed objects, including fixed objects modulo the declared scalar/positive-diagonal transfer equivalence. A finite cycle of power blocking would imply `P^{*(B^k)}=P` for some k and gives the same conclusion.

The invariant coarse process at a fixed object has independent rung variables and independent uniform rail increments. Intercell couplings and plaquette preference are absent. However, pi may be nonuniform: in the raw uniform-frame lift, the one-cell factor is `2 pi(r)`, a local rung gauge-matter bias. Calling these objects entirely noninteracting in every raw variable would overstate the result. They are not interacting critical fixed objects with persistent correlations between coarse cells.

At the limit `H_i=r_i r_(i+1)X_iY_i` is a fair sign, because the increments are independent uniform signs. Thus the nontrivial-plaquette probability tends to 1/2 rather than to zero, while its covariance with the dressed rung product tends to zero. Flux abundance and long-range interaction are distinct statements.

The scope of the obstruction is all strictly positive finite 16-entry ladder transfers with this power-blocking and coarse identification. It does not refute nonpositive/singular fixed objects, gap-closing sequences, infinite-width criticality, different retained carriers, non-Abelian continuum fields, or other RG schemes.

## 12. Implementation contract and remaining review obligations

An exact implementation can keep Fraction values for the initial K, convolutions, marginal transfers, ring partitions, and finite law pushes. Log action and VFE evaluations are separate numerical operations. The initial scientific point `a=1/5,b=2/5,c=1/3` lies in the strict domain of the nonfactorization and ansatz-leak proofs. Its uncoupled reference is `a=b=0` at the same c. Tiny direct enumeration may check the implementation, but no finite enumeration establishes the limit theorem.

The implementation must keep distinct edge copies at N=1/2, use `tr(M^N)` without fixing rail Wilson sectors, retain all 16 generated transfer entries, include the reference-density factor 8 per coarse cell, and preserve the same observation/evidence problem in any VFE chain. The positive fixed-object result must retain its local-bias qualification. Exact rational calculations and numerical Perron/Doob evaluations must be labeled separately.

This proof supplies a scoped finite-width R6 construction and a precisely delimited obstruction, with a stated two-index comparison. Its independence and numerical correspondence still require the separately assigned review and implementation evidence. It neither closes a formal ledger nor turns completion of this family into universal completion of the ambient RG program.

