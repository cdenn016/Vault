<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Exact retained event coordinates under driven inference

Family ID: fixed-log-affine-event. Kind: CONSTRUCTION and LEMMA. Revision 1, proposed for independent reconstruction; no ledger closure or numerical outcome is asserted. This lane read live source and derived finite identities; it ran no code, tests or experiments and changed no scientific source.

The present four-endpoint latent event law does lie in one fixed 39-dimensional positive chain exponential family at every admitted context. Both the initial recognition law and every driven posterior target belong to it. The observation multiplies an existing edge (0,1) factor, so it does not generate a missing edge or a higher-order interaction. Consequently full-simplex Fisher inference can be carried exactly by 39 identifiable natural coordinates. This is microscopic retained sufficient state; it is neither an approximation nor an autonomous state of the two visible parents.

## Source trace and quantifier boundary

`src/multiagent_elbo/experiments/neighborhood/local_tree.py:18` declares `RECORD_TREE` with cliques (0,1),(1,2),(2,3) and singleton separators 1,2. The four positions are latent endpoint-record variables. Each position has four outcomes 0,1,2,3; these outcomes name agents but are not the changing set of active Gaussian coordinates.

`local_tree.py::record_inputs` (line 109) constructs, for each prior/recognition/reference and each edge i,i+1, a 4x4 joint table

    M_i(a,b)=(1-r_i) u(a)u(b)+r_i u(a)1[a=b].

The unary u is a positive softmax of a finite context-dependent score. For the prior r_i=0.28 tanh(coupling)(1+0.05i); for initial recognition it is 0.19 tanh(coupling)(1+0.05i), i=0,1,2. Admitted coupling is finite and nonnegative, so 0<=r_i<0.308<1 (and recognition r_i<0.209). Every table is positive and normalized and both marginals equal u. The reference uses uniform u and r_i=0. Contexts are finite points inside U=(-1.5,1.5)^2; no availability mask is applied to these latent tables.

`junction_tree.py::assemble_tables` (line 187) verifies positive normalized clique tables and equal separators, then evaluates

    q(x0,x1,x2,x3)=M_01(x0,x1) M_12(x1,x2) M_23(x2,x3)/(u_1(x1)u_2(x2)).

Its log is the sum of three pair functions minus two unary functions. Thus it belongs to the chain family defined below. This argument uses the actual product/quotient construction, not the comment that the prior is a tree.

`local_tree.py::event_system` (line 134) constructs prior, q and reference by that assembler. The normalized Bernoulli kernel has success probability

    L_c(a,b)=sigmoid(0.25 cos(c_y)-0.1(a-b)^2),

and the observed event is success. Its evidence is Z_c=sum_ab M_01^prior(a,b)L_c(a,b)>0. Code multiplies the 16x16 prior by `likelihood.flatten(1)[:, :, None]` and divides by Z_c. Under the reshape to (4,4,4,4), its row index is (x0,x1), so this is exactly

    p_c(x)=p_c^prior(x)L_c(x0,x1)/Z_c.

Log L_c is a pair function on the already present edge (0,1). The other edges and separators remain functions on existing cliques. The likelihood is strictly between zero and one at every admitted context. No approximation, posterior refactorization or tree projection is being used.

`local_tree.py::cover` (line 251) stores these laws under `local_data[*_latent_event]`. `nonflat.py::cover` (line 62) changes prescribed connection/geometry fields but does not alter these latent event laws. `inference.py::build_context` (line 37, nested `event`) retrieves those unmasked latent fields and reshapes them to (4,4,4,4); it does not retrieve the availability-pushed visible law. The availability/coarse channels are stored separately. Chart, frame_scale, kappa_b and kappa_m do not modify these event probabilities. `moving_context.py::run_path` (line 85) carries the same latent 256-state law unchanged during context transport, then calls `categorical_inference.py::full_step` on the newly constructed posterior target. That full step interpolates log densities exactly.

Therefore the quantifier is: every admitted context history and finite nonnegative coupling under this fixed event construction, with the full event update and fixed latent outcome labels. It does not cover arbitrary observations, additional records or redefined event semantics. The Gaussian law is a separate product factor and may leave its original tree family; that fact does not change the event closure.

## Finite log-affine closure theorem

Let X be any nonempty finite set. Fix h:X->(0,infinity), statistics T:X->R^d whose components are linearly independent modulo constants, and

    A(theta)=log sum_x h(x) exp(theta dot T(x)),
    q_theta(x)=h(x) exp(theta dot T(x)-A(theta)), theta in R^d.

The family is an affine subspace of log densities modulo constants, not a linear subspace of probabilities. Every q_theta is positive and normalized. Write m_theta=E_(q_theta)T and G_theta=Cov_(q_theta)(T,T).

For initial q_theta and target p=q_eta in the same family, and finite elapsed time h_t>=0, put a=exp(-h_t). The full-simplex reverse-KL Fisher step is

    q_new(x) proportional to q_theta(x)^a q_eta(x)^(1-a).

Substituting the two log densities gives h(x)exp([a theta+(1-a)eta] dot T(x)) times a scalar. Normalization therefore gives exactly

    theta_new=a theta+(1-a)eta.

The family is invariant under every finite sequence of these steps with arbitrary in-family targets and nonnegative increments. No within-family optimization approximation or Euler discretization occurs. For one fixed target this map has the exact semigroup property because exp(-(s+t))=exp(-s)exp(-t).

There is also a precise necessity statement. If q_theta is in the family and 0<a<1, the geometric step toward a positive target p belongs to the family if and only if log p belongs to log h+span{1,T_1,...,T_d}. Indeed, subtract a log q_theta from the resulting in-family log density and divide by 1-a. The a=1 zero-time case supplies no target-membership condition. Infinitesimally, at positive inference rate the full Fisher vector is tangent exactly when its centered log p-log q_theta lies in the centered statistic span.

Target obligation: an exact carried event family replacing empirical fixed-bin approximation. Failure condition: an initial or target log density has a nonzero component outside the declared affine span. Open gap: source-bound implementation and independent reconstruction remain. Novelty fingerprint: fixed log-density span + exact full Fisher dynamics + moving targets, distinct from fixed within-bin conditionals. Proposed disposition: implement this admitted event family after the separate mathematical check; do not reinterpret the earlier bin error measurements as premises of this theorem.

## Fisher pullback, objective and nondegeneracy

Differentiating finite sums gives dA=m_theta and d^2 A=G_theta. For a natural-coordinate tangent v,

    d q_theta[v](x)=q_theta(x) v dot(T(x)-m_theta).

The full-simplex Fisher inner product of v,w pulls back exactly to v^T G_theta w. For v!=0, v^T G_theta v=Var_(q_theta)(v dot T)>0: positivity makes zero variance equivalent to v dot T constant on all X, excluded by independence modulo constants. Thus the metric is nondegenerate for every finite theta. Near a boundary where some probabilities vanish, its smallest eigenvalue can approach zero; no uniform conditioning claim follows without a compact coordinate bound.

For p=q_eta,

    F(theta;eta)=KL(q_theta||q_eta)
      =(theta-eta) dot m_theta-A(theta)+A(eta),
    grad_theta F=G_theta(theta-eta).

The Fisher natural gradient is theta-eta. Consequently negative natural-gradient evolution is dot theta=eta-theta. Multiplying the derivative of q_theta by that velocity reproduces the full-simplex vector

    dot q(x)=-q(x)[log(q(x)/p(x))-E_q log(q/p)].

This is why a 39-coordinate update can agree with all 256 probabilities: the full vector field is tangent. It is not raw Euclidean descent on arbitrary coordinates; the covariance metric cancels analytically. Computing a 39x39 inverse or storing that matrix at runtime is unnecessary for this exact flow.

## A constant-free 39-coordinate basis for this chain

Take X={0,1,2,3}^4, counting reference h=1 and reference outcome 0 at each position. For i=0,...,3 and a=1,2,3, use node statistics T_(i,a)(x)=1[x_i=a]. For edges E={(0,1),(1,2),(2,3)} and a,b=1,2,3, use edge statistics T_(ij,a,b)(x)=1[x_i=a,x_j=b]. There are 4*3+3*9=39 coordinates. Their interpretation is

    log q_theta(x)=sum_i u_i(x_i)+sum_(ij in E) v_ij(x_i,x_j)-A(theta),

with u_i(0)=0 and v_ij(0,b)=v_ij(a,0)=0. These constraints eliminate the arbitrary shifts between node/edge potentials and the additive constant. This is identifiability of log potentials, not a claim to fix the physical SO(2) gauge. In the current source the latter acts on the Gaussian channels and leaves latent event outcomes unchanged.

To prove statistic independence modulo constants, evaluate a putatively constant linear combination at the all-zero state: its constant is zero. Evaluate at one nonzero coordinate to set each node coefficient to zero. Evaluate at nonzero coordinates on each listed edge to set every edge coefficient to zero. Thus the 39-dimensional metric is SPD on the positive family. The full256-state probability vector has 255 independent coordinates; the retained family removes 216 directions exactly because the declared model/targets never use them.

For any strictly positive normalized candidate q, let l=log q, l_0=l(0,0,0,0), and let x^(i:a) denote a state with only position i changed to a. Extract

    u_i(a)=l(x^(i:a))-l_0,
    v_ij(a,b)=l(x^(i:a,j:b))-l(x^(i:a))-l(x^(j:b))+l_0.

Define l_hat(x)=l_0+sum_i u_i(x_i)+sum_(ij in E) v_ij(x_i,x_j). Then q is in the family if and only if l-l_hat is identically zero. Necessity is substitution into the anchored formulas. Sufficiency gives q=exp(l_0+theta dot T); normalization forces l_0=-A(theta). The extracted coordinates are unique. Any dense-law compiler must check the full residual rather than only the 40 anchor states, because the anchors define a projection for every law.

Equivalent admission starts from explicit node/edge log potentials, which is the current source construction. An arbitrary 4x4 edge function H(a,b) decomposes exactly into H(0,0), node terms H(a,0)-H(0,0) and H(0,b)-H(0,0), and interaction H(a,b)-H(a,0)-H(0,b)+H(0,0). Sum those terms across all three edges and the separator unary corrections. Apply the same operation to log L_c on edge (0,1). This supplies initial/target coordinates without storing or fitting a dense 256-entry law. One final log normalizer accounts for all constants.

Because the graph is a chain, reconstruction/normalization can use positive edge potentials and finite forward/backward sums. Alternatively, enumerating 256 states is an exact-real formula and a cheap diagnostic. A dense 39x256 statistic matrix is not needed: evaluate the node and edge lookups directly. Positive normalized chain laws are exactly this log-linear family. One direction follows from the factorized density; summing end variables gives a normalized root/conditional factorization. The reverse direction expands the log root plus three child-given-parent logs as node/edge functions. No unsupported cyclic marginal-extension theorem is invoked.

## Driven continuous evolution

Let s belong to[0,T], lambda(s)>=0 be integrable, eta(s) measurable, and lambda(s)eta(s) integrable componentwise. Let theta_0 be finite. Define Lambda(s)=integral_0^s lambda(r)dr. The unique absolutely continuous solution of

    dot theta(s)=lambda(s)[eta(s)-theta(s)]

is

    theta(s)=exp(-Lambda(s))theta_0
      +integral_0^s exp(-(Lambda(s)-Lambda(r)))lambda(r)eta(r)dr.

Differentiation almost everywhere verifies the equation; subtracting two solutions and multiplying by exp(Lambda) proves uniqueness. Since the coordinate space is finite-dimensional, theta(s) is finite and continuous. Composition with the smooth finite exponential family gives an absolutely continuous positive probability curve solving the full-simplex Fisher equation almost everywhere. If lambda and eta are continuous, it is a classical C1 solution. A continuous admitted context path c(s) with the present smooth event construction gives continuous eta(c(s)); C1 paths give C1 targets. Gaussian active-domain events do not change X, the event statistics or this target formula.

For bounded eta, theta stays in the convex hull of theta_0 and the target range: the nonnegative coefficients above have total one. On a finite interval this yields a compact natural-coordinate set, hence uniform positive probabilities and a strictly positive minimum eigenvalue of G by continuity. The latter is an existence bound, not a useful numerical conditioning estimate without evaluating constants. If lambda is merely integrable and lambda eta integrable, the integral formula still applies without claiming such a target convex-hull bound for an unbounded target set.

For lambda=1 and an absolutely continuous target eta, differentiating the KL gives

    d/ds KL(q_theta||q_eta)
      =-(theta-eta)^T G_theta(theta-eta)
        +(m_eta-m_theta) dot dot eta.

For general lambda, multiply the first term by lambda. The second term is the driving contribution. Therefore a varying target does not imply monotone KL, and adding changing log evidence introduces another derivative. Neither s nor its integrated inference rate is identified with physical time.

The current endpoint-frozen discrete update has an explicit consistency bound. Use exact integrated interval rates Delta Lambda_i and endpoint eta_i on intervals[t_(i-1),t_i]. The discrete result is the exact driven solution with piecewise-constant target eta_i. If eta is uniformly continuous and omega_eta(delta) bounds its variation over intervals of length at most delta, subtracting the two integral formulas yields

    norm(theta_discrete(T)-theta_exact(T))
      <=(1-exp(-Lambda(T)))omega_eta(delta).

The same bound applies at mesh points. If eta is L-Lipschitz, it is at most L delta. For the actual constant configured inference rate, Delta Lambda_i=rate*(t_i-t_(i-1)) matches the implementation. A general numerical quadrature for lambda would need its own error term; this theorem does not hide it.

For counting reference and this 0/1 statistic basis, ||T(x)||_2<=sqrt(7): at most four node and three edge statistics are nonzero. Along any straight segment in parameter space, integrate the density derivative to obtain

    ||q_theta-q_phi||_1 <=2 sqrt(7)||theta-phi||_2,
    TV(q_theta,q_phi)<=sqrt(7)||theta-phi||_2.

Indeed, ||T-m||_2<=2sqrt(7) bounds each score's absolute value. Thus the parameter consistency estimate implies a concrete probability convergence bound, and every current stochastic readout contracts that TV further. These exact-real bounds concern the event component; they do not prove Gaussian boundary convergence, control conditional attention at zero occupancy or certify binary64 roundoff.

For a differentiable context-dependent readout C(s), y(s)=q(s)C(s) has dot y=dot q C+q dot C. This additional channel-motion term cannot be omitted. On intervals where an occupancy alpha>0 is bounded away from zero, ordinary quotient differentiation handles beta=eta/alpha; at alpha=0 the conditional remains undefined.

## Admission, API and storage boundary

A minimal fixed-graph API can expose `encode_positive_chain(q)->theta`, `decode(theta)->q`, `target_coordinates(context_model)->eta`, `step(theta,eta,elapsed)->theta_new`, and optional `moments(theta)`/`fisher(theta)` for independent controls. The graph, category cardinality, reference category and coordinate ordering are schema data. Encode must reject nonfinite/nonpositive/unnormalized candidates and a nonzero omitted log-interaction residual. Floating implementation uses a declared residual tolerance; passing that tolerance is a numerical admission, not exact mathematical equality. It must report the residual and not silently project a rejected candidate.

For source-generated inputs, compile from the explicitly declared local tables and edge (0,1) likelihood so the family membership premise is structural. Preserve the dense residual check as a small independent implementation control. `step` takes finite 39-coordinate initial/target vectors and finite nonnegative elapsed time. It returns the convex combination with exp(-elapsed); it need not reconstruct probabilities to advance. Existing full256-state inference remains the comparison oracle. Generic `full_step` should not be changed to assume chain membership for every caller.

The mutable event state is 39 floating values. Computing a current target needs another 39 transient values; the full model construction already has its own target representation and is not counted as free storage. The immutable family needs the fixed graph, cardinality/reference labels and coordinate ordering; it needs neither the 256 immutable within-bin probabilities used by the previous mixture method nor a 9984-entry dense statistic table. A log normalizer or moments can be cached but are derived, not extra independent state. Dense 256-entry reconstructions and visible parent laws may still be materialized for diagnostics/output; state compression does not imply all artifact storage or every runner allocation is reduced. A runner that retains its entire original ContextModel may save evolving coordinates without reducing peak memory, and must say so.

For objective evaluation, KL(q_theta||q_eta)=(theta-eta) dot m_theta-A(theta)+A(eta) uses only the natural coordinates and moments. The event ELBO remains log Z_event-KL(q_theta||posterior); generative evidence is retained from the same normalized observation model, not absorbed into the coordinate gauge. Its exact tree representation also permits clique-minus-separator accounting. This does not restore the Gaussian tree accounting after unrestricted Gaussian evolution.

## What this family excludes

Marginalizing the latent chain through availability/coarse channels generally yields a hidden-chain law on visible outcomes, not another chain law on the visible variables. The exact 39-coordinate state therefore remains microscopic sufficient information used to reconstruct/push current parents. It is not a proof that parent probabilities determine their future, nor does it erase the known parent-autonomy obstruction.

An additional likelihood on nonadjacent variables 0,2 can create a missing pair interaction. For example, a positive factor exp(J 1[x0=1,x2=1]) with J!=0 has anchored residual J at the 0,2 state and lies outside the 39-coordinate chain. A normalized Bernoulli likelihood can realize the same factor up to a positive constant by choosing a constant small enough that the success probabilities are below one. Adding edge (0,2) yields a 48-dimensional positive pairwise exponential family; exact full-Fisher closure persists for initial/target logs in that enlarged fixed span, though chain-only reconstruction routines would no longer apply.

A factor exp(J 1[x0=1,x1=1,x2=1]) produces a genuine three-variable interaction: all relevant singleton/pair anchors vanish while the triple state has residual J. No pairwise family can represent it. The next admitted family must include that triple statistic, or the complete set of triple contrasts if arbitrary three-variable factors are allowed. In general the smallest exact driven family is the affine span modulo constants of the initial log law and the entire target-log range; finite samples of contexts do not identify that span without an analytic dependence argument. The 39-coordinate family is an explicit closed sufficient class, not a proof that 39 is the smallest span for this particular parameterized fixture.

Failure conditions are an out-of-family observation, changed latent carrier, context-dependent statistic/baseline family without added transport terms, unsupported zero probabilities, or silently projected admission residuals. The construction has no literature-priority claim: all identities follow from finite sums and explicit source factors. Novelty fingerprint: source-verified fixed chain log-span + full Fisher invariance + identifiable 39-coordinate state + continuous driven solution and endpoint-target consistency. Proposed disposition: independent mathematical reconstruction, then a new typed exact event-state interface; no code/experiment result is asserted here.

## Cross-lane questions and answers

**To Root:** the current observation is an edge (0,1) factor, so the proposed exact family is applicable without altering the generative model or targets. Keep this new state distinct from the existing conditional-tree Armijo solver: that solver uses local conditional coordinates and finite steps, whereas the proposed natural-coordinate step equals the exact full-simplex flow for this closed family. I have not run any tests or checked your current moving-reduction numerical record.

**To Evolution:** the event component admits the linear natural-coordinate driven equation and explicit mesh bound above on its fixed carrier. Context entry/exit only changes readout availability for these variables. This does not decide the Gaussian changing-dimensional boundary theorem or a genuine base quotient. The additional q dot C term must be retained if reporting visible rates.

**To Scale:** no hierarchical length-scale interpretation is attached to this event inference parameter, and no new fixed-channel variational-minimization claim is used. This construction evolves the actual microscopic law inside an invariant family, then applies the stochastic readout.

## Readback to Evolution revision 1

This responds to [evolution.md, Cross-lane questions](evolution.md). The event positivity and whole-context regularity are symbolic, not merely sampled admission. `record_inputs` uses finite smooth logits, a positive unary softmax, and mixtures with r_i<0.308<1; the normalized edge (0,1) likelihood is positive and smooth. On any compact context path, all 256 latent prior/recognition/target masses have positive minima by their explicit formulas and finite state count. The 39 extracted log coordinates are therefore smooth there. Availability underflow does not enter the latent event formulas, although it can prevent the encompassing runner from admitting a machine point.

For the Gaussian hypotheses already inspected during coverage: `local_tree.py::gaussian_inputs` gives lower-triangular L_i with diagonal 1+0.1 cos(...), hence diagonal at least 0.9 and determinant bounded away from zero on compact contexts. Adjacent cross covariances are r L_i L_(i+1)^T with |r|<0.324 for the prior (less for initial recognition). Each active chain can be generated recursively with regression r L_(i+1)L_i^(-1) and positive innovation(1-r^2)L_(i+1)L_(i+1)^T. This realizes its stated node/pair laws and gives a positive smooth joint for every fixed active set, including finite one-sided limits at boundaries. The fixed active sets have at most three nodes. `local_tree.py::cover` has observation noise R=0.6I and finite smooth availability-weighted H. Its exact posterior precision is J_prior+H^T R^(-1)H, hence SPD with smooth one-sided limits. These statements concern real arithmetic; the implementation's covariance subtraction and admission remain separate finite-precision controls. Frames in `model.py::frame_geometry` are trigonometric functions of finite polynomial/trigonometric angles, so their one-sided limits are also available.

There is an event-location admission beyond raw endpoint classification: `moving_context_config.py::validate_config` rejects any path segment whose x interval strictly contains one of(-0.8,-0.1,0.1,0.8), requiring such a boundary to be an explicit waypoint. `_points` preserves original waypoint coordinates exactly under refinement. This prevents skipped crossings in the configured path. It does not create explicit one-sided state records: `run_path` still determines active agents at the exact boundary and subsequent interior point. Open-domain entry therefore occurs at the first sampled interior point, and a touch can require an exit and later entry. The stronger event-resolved hybrid API you describe remains a separate obligation; the existing validator is useful input to it, not the complete schedule.

The exact 39-coordinate event state reconstructs the entire microscopic q, hence supplies every future availability/coarse readout without additional lost event information. For continuous visible rates, use dot q C+q dot C. Current exact endpoint laws need only qC; an implementation that reports rates must actually evaluate the second term. This distinction is independent of Gaussian boundary reconciliation.
