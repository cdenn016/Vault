<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->
# Independent reconstruction of the finite diamond hierarchy

Revision 1 is frozen for root adjudication. This verifier did not author the construction or implementation. The permitted verdicts below are **derivation reconstructed**, **refuted**, and **open**; none assigns a ledger closure state. All scientific results here follow from the displayed finite sums, polynomial calculations, or stated analytic arguments. No scientific module was imported, no enumeration or test was executed, and no GPU, tamper, publication, or vault operation was performed.

## Inputs, dependence, and source boundary

The assignment's `contract.json` is named `problem-contract.json` in the actual run. Its metadata matches this document. The reconstruction read that frozen contract, `agents/scale.md`, `agents/scale-implementation.md`, and `src/multiagent_elbo/rg_v2/hierarchical_ising.py`. Input SHA-256 values are:

| Input | SHA-256 |
| --- | --- |
| `agents/scale.md` | `7ed8f0cfbbb7849cdd9f45ad1f5cb9c1e65d29279ac7b28c5458bdddf691ae8d` |
| `agents/scale-implementation.md` | `d5f4ed236db6d3aa755842b695a429e47ca9d5891e001ec243f2e60a794e1cf4` |
| `src/multiagent_elbo/rg_v2/hierarchical_ising.py` | `ef41955e5cb8697ef1a9c17b98d06149f5c67f5fa87600db84583b8205061ae5` |

This is an independent reconstruction after exposure to the proposed conclusions, not a blind discovery pass. Agreement with the proposing lane supplies no evidence. Its finite sums were expanded again here; its fixed-point, field, and gap identities were independently reduced. No inference below uses the desired answer as a premise. Root retains responsibility for target-wide dependency coverage, oracle erasure, and ledger adjudication.

The current Research concept [Renormalization group flow](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Renormalization group flow.md>) was consulted for program context. Its distinction between a desired general RG interpretation and a proved scoped construction is retained. Its broad statement about exceptional composability is not a mathematical premise: declared finite Markov kernels always compose. The classical primary article [Pinho, Haddad, and Salinas, *Critical behavior of the Ising model on a hierarchical lattice with aperiodic interactions*](https://arxiv.org/pdf/cond-mat/9709303), inspected on 2026-09-08, equations (7)–(10), contains the homogeneous diamond recursion. That attribution is the only imported scientific claim used here. The finite recursion, normalization, and stability are proved below without invoking the article as a theorem. No novelty, continuum-universality, or correlation-length theorem is imported.

## SV01: finite retained actions compose with their normalizers

**Verdict: derivation reconstructed.** For nonempty finite sets and a positive fine weight table $W:X\to(0,\infty)$, define $Z=\sum_xW(x)$. Let $C(y\mid x)\geq0$ satisfy $\sum_yC(y\mid x)=1$ for each $x$. Then

$$
W_C(y)=\sum_xW(x)C(y\mid x),  \sum_yW_C(y)=\sum_xW(x)\sum_yC(y\mid x)=Z.
$$

Consequently $P_C=W_C/Z$ is normalized. Its unnormalized action is $S_C=-\log W_C$, with $S_C(y)=+\infty$ at zero coarse mass, while its normalized action is $S_C+\log Z$. Positivity of fine $W$ does not require positivity at a coarse atom with an identically zero incoming column.

For any second row-stochastic $D(z\mid y)$, expanding the finite sums gives

$$
W_{CD}(z)=\sum_xW(x)\sum_yC(y\mid x)D(z\mid y)=\sum_yW_C(y)D(z\mid y).
$$

No limit exchange or ansatz is involved. If retained variables $r$ separate disjoint block interiors $i_B$, and every factor is assigned exactly once, then

$$
\sum_{(i_B)}\Psi_R(r)\prod_BW_B(i_B,r_{\partial B})
=\Psi_R(r)\prod_B\left[\sum_{i_B}W_B(i_B,r_{\partial B})\right].
$$

Taking minus logarithms yields the proposed full boundary action. A factor crossing two eliminated interiors invalidates this factorization unless their blocks are merged or its variables are retained. Independence of the numerical kernel from recognition is needed when treating this as one fixed variational transformation; the finite sum identity itself is valid for each fixed chosen kernel regardless of how someone selected it.

**Falsifier:** a nonunit row sum changes $Z$, a duplicated factor changes the summand, or omitted cross-interior dependence prevents the product identity. **Remaining obligation:** none for the finite statement; efficient representation and closure in a smaller family require additional arguments. The exact module below realizes a strictly positive two-terminal specialization, not all zero-support coarse tables permitted by this theorem.

## SV02: graph construction and the exact diamond sum

**Verdict: derivation reconstructed.** Start with one edge and two fixed roots. Replace each edge by two distinct length-two paths, with new middle vertices unique to that edge. If $e_n,v_n,d_n$ are edge count, vertex count, and root graph distance, then

$$
e_{n+1}=4e_n,  v_{n+1}=v_n+2e_n,  d_{n+1}=2d_n.
$$

The distance recurrence follows because each new middle vertex has only the two old endpoints as neighbors: a root-to-root path projects to an old walk with one old edge per two new edges, and a shortest old path lifts to one of doubled length. Thus

$$
e_n=4^n,  v_n=2+\frac{2(4^n-1)}{3},  d_n=2^n.
$$

The module's `diamond_graph`, lines 221–233, implements this edge substitution and deliberately admits only $n=0,1,2$. In particular $v_2=12$: there are $2^{10}=1024$ assignments per fixed root pair and $4096$ full assignments. These counts are derived, not executed measurements.

For $A>0$ and $0\leq t<1$, all four entries $w(s,r)=A(1+tsr)$ are positive. Expanding one series path directly gives

$$
\sum_{m=\pm1}A^2[1+t(s+r)m+t^2sr m^2]=2A^2(1+t^2sr),
$$

because $\sum_m m=0$ and $\sum_m m^2=2$. For two distinct middle spins the sums multiply. Since $(sr)^2=1$,

$$
W'(s,r)=4A^4(1+t^2sr)^2=4A^4[(1+t^4)+2t^2sr].
$$

It follows that

$$
A'=4A^4(1+t^4),  t'=\frac{2t^2}{1+t^4}.
$$

The denominator is positive, and $1-t'=(1-t^2)^2/(1+t^4)>0$. The admitted positive ferromagnetic domain is preserved. This is exactly `series` at lines 181–184, pointwise `parallel` at lines 187–189, their `diamond` composition at lines 192–195, and `diamond_step` at lines 198–202. The row-major index $2i+k$ for the left table and $2k+j$ for the right table sums the same middle spin without an endpoint transposition.

Induction over graph replacement proves direct and staged elimination agree at every finite depth: interiors of the four subgraphs and the two new middle spins partition the complete set of variables being summed. Every spin assignment appears exactly once. `direct_table`, lines 236–257, separately traverses all interior assignments and multiplies every ordered edge factor once; the source-level loops express the same finite definition without calling the recursive table functions.

**Falsifier:** shared middle vertices, a missing/duplicated edge, an incorrect table index, or replacing the product of two independent middle-spin sums by a single middle-spin sum would change this recursion. **Remaining obligation:** executable behavior is untested in this lane; all-depth direct enumeration is intentionally outside the implementation's admitted control domain.

## SV03: normalization, action closure, and the precise fixed object

**Verdict: derivation reconstructed.** A simultaneous-spin-reversal-invariant positive two-terminal table has form $(u,v,v,u)$ with $u,v>0$. Defining $A=(u+v)/2$ and $t=(u-v)/(u+v)$ recovers it uniquely as $A(1+tsr)$ with $|t|<1$. Equivalently its real action has exactly the form $c-Ksr$, where

$$
K=\frac12\log(u/v),  c=-\frac12\log(uv).
$$

Thus the symmetry-invariant action space modulo constants is one-dimensional. This is full two-boundary closure, not a projection discarding higher interactions. The ferromagnetic scalar update uses $t\geq0$; `ising_coordinates`, lines 205–210, correctly returns signed $t$ for an arbitrary positive reversal-invariant table. Converting that signed contrast back through `ising_table` requires its sign to be carried by the separate link argument.

Summing $A_n(1+t_nsr)$ over all four root pairs cancels the $sr$ term, so

$$
Z_n=4A_n,  P_n^{\mathrm{root}}(s,r)=\frac{1+t_nsr}{4}.
$$

For $a_n=\log A_n$, the exact recursion and its solution are

$$
a_{n+1}=4a_n+\log4+\log(1+t_n^4),
$$

$$
a_n=4^na_0+\sum_{j=0}^{n-1}4^{n-1-j}[\log4+\log(1+t_j^4)].
$$

The scalar table retains the entire additive contribution. At a fixed interaction satisfying $1+t_*^4=2t_*$, one has $A_{n+1}=8t_*A_n^4$. For $A_0=1$ this gives

$$
A_n=(8t_*)^{(4^n-1)/3},  Z_n=4(8t_*)^{(4^n-1)/3}.
$$

The exponent is an integer because $4^n\equiv1\pmod3$. A real constant representative can instead be chosen by $a_*=-\log(8t_*)/3$, but the implementation does not claim that real logarithm or its exponential is a three-coefficient `Cubic` value. Its exact finite weights use $A_0=1$ and integer powers in the field.

The two notions of normalization must be kept separate. Eliminating variables from one already fixed finite graph preserves that graph's partition function. Constructing successively larger $D_n$ graphs changes both the sample space and $Z_n$. The fixed object is the normalized two-root action class after identifying each homogeneous coarse edge with the same two-root template. It is not a literal equality of full measures on the changing vertex catalogs. At $t_*$ the finite graph laws are compatible under the specified newest-vertex forgetting maps, but a claimed infinite-volume Gibbs interpretation still needs an explicit limiting state space, extension, interaction specification, and boundary interpretation. None is established by returning the four endpoint probabilities.

Also, `diamond` is polynomial of degree four in its input table: the map first constructs a four-copy graph and then marginalizes it. It is not one fixed linear Markov map on a single input two-spin probability vector.

**Falsifier:** claiming $Z_{n+1}=Z_n$ for graph construction, declaring the raw amplitude fixed at $A=1$, or identifying the nonlinear four-copy update with one fixed stochastic push on the two-spin simplex contradicts the displayed sums. **Remaining obligation:** physical/infinite-volume interpretation, closure with fields or more boundary spins, and general graph universality are open.

## SV04: interacting cubic fixed law and homogeneous stability

**Verdict: derivation reconstructed.** For $f(t)=2t^2/(1+t^4)$,

$$
f(t)-t=\frac{t(1-t)(t^3+t^2+t-1)}{1+t^4}.
$$

Let $g(t)=t^3+t^2+t-1$. Its derivative is

$$
g'(t)=3(t+1/3)^2+2/3>0,
$$

and $g(1/2)=-1/8$, $g(3/5)=22/125$. Continuity and strict monotonicity give exactly one real root in $(1/2,3/5)$ and exactly one interacting fixed point in $(0,1)$. The other roots of the fixed equation in $[0,1]$ are zero and the boundary value one. From $g(t_*)=0$,

$$
t_*^3=1-t_*-t_*^2,  t_*^4=2t_*-1,
$$

so the exact fixed equation follows without a decimal approximation.

Both endpoint marginals of $P_t=(1+tsr)/4$ are uniform, and its correlation is $t$ by direct summation. The only product of those marginals assigns $1/4$ to every pair, whereas $P_{t_*}(+,+)=(1+t_*)/4>1/4$. It is therefore interacting in the precise nonproduct sense. Its mutual information is

$$
I_t=\frac{1+t}{2}\log(1+t)+\frac{1-t}{2}\log(1-t).
$$

Since $I_0=0$ and $I'_t=\frac12\log[(1+t)/(1-t)]>0$ for $0<t<1$, the asserted strict positivity follows.

Differentiating the rational map gives

$$
f'(t)=\frac{4t(1-t^4)}{(1+t^4)^2},  f'(t_*)=\frac{2(1-t_*)}{t_*}.
$$

The isolating interval implies $4/3<f'(t_*)<2$. It is an unstable eigenvalue in the homogeneous interaction quotient. The additive coordinate derivative is four and disappears when quotienting constants. It is not a second retained physical interaction instability.

The sign of $f(t)-t$ equals that of $g(t)$ inside $(0,1)$. Iteration starting below $t_*$ strictly decreases and is bounded below; its limit is a fixed point below the initial value, hence zero. Iteration starting above $t_*$ strictly increases and is bounded above; its limit is the only fixed point above the initial value, hence one. These real-sequence limits use continuity only; the second lies outside the strictly positive finite-coupling family.

The distance scaling is $b=2$ and edge scaling is four. Defining $y_t=\log f'(t_*)/\log2$ is legitimate. Calling $1/y_t$ a correlation-length exponent requires a specified correlation-length observable and a scaling theorem. Smooth invertible changes of the one coupling coordinate preserve the fixed derivative by the chain rule, but changes of graph replacement or additions of coupling directions require their own analysis.

**Falsifier:** a zero cubic residual together with a nonzero fixed residual in exact arithmetic, a nonpositive endpoint correlation, or an eigenvalue outside the derived interval would falsify the corresponding implementation claim. **Remaining obligation:** no nonhomogeneous spectrum, attraction in other directions, universal exponents, or continuous beta generator is proved here.

## SV05: the algebraic scalar really is a field with a distinguished order

**Verdict: derivation reconstructed.** The cubic $g$ is irreducible over $\mathbb Q$. Indeed a rational root $a/b$ in lowest terms of this monic integer polynomial must have $b=1$, and its integer root must divide its constant term, so it would be $1$ or $-1$. But $g(1)=2$ and $g(-1)=-2$. A reducible cubic over a field has a linear factor, so absence of a rational root proves irreducibility.

Thus $F=\mathbb Q[T]/(g)$ is a field of degree three, represented uniquely by $a+bT+cT^2$. Evaluation at the isolated real root $t_*$ is injective: a nonzero polynomial of degree at most two cannot vanish there, since its greatest common divisor with the irreducible cubic is one. This proves both that coefficient-wise zero testing is sound and that the real embedding supplies a total field order. No equality tolerance is needed. It also proves the exact fixed law cannot be stored as ordinary rational probabilities: rationality of $(1+t_*)/4$ would force rationality of $t_*$.

**Falsifier:** a rational root of $g$, or a nonzero degree-at-most-two rational polynomial vanishing at the designated root, invalidates this representation. The explicit rational-root calculation rules both out. **Remaining obligation:** none for this field statement; arbitrary algebraic extensions are outside the scalar type.

## SV06: multiplication, inversion, powers, and ordering termination match that field

**Verdict: derivation reconstructed at source level; executable results remain open.** `Cubic` admits only exactly three `Fraction` coefficients. Addition and negation are componentwise. Multiplication first forms the coefficient convolution through degree four. Its downward reduction at degrees four and three uses

$$
T^k=T^{k-3}-T^{k-2}-T^{k-1} \quad (k=3,4).
$$

Applying degree four before degree three incorporates the induced degree-three term correctly. The stored degree-three/four coefficients need not be cleared because they are discarded only after all their contributions to lower degrees have been propagated. The returned three coefficients are the unique quotient remainder.

For a nonzero element $a$, multiplication $M_a:F\to F$ is injective because $F$ has no zero divisors, hence is invertible in dimension three. `inverse` forms the columns of this linear map on $1,T,T^2$ and solves $M_ax=1$ by rational Gauss–Jordan elimination. Nonsingularity guarantees an available pivot at every stage; the resulting coefficients are those of $a^{-1}$. Zero is explicitly rejected. The integer-power loop implements repeated squaring with exact products; negative exponents first invert. Exact arithmetic cost may grow, but this is not an arithmetic approximation or a termination failure for any finite exponent.

For ordering, let $h(T)=c_0+c_1T+c_2T^2$ be a nonzero canonical residue. `sign` first handles exact zero. At each later iteration the root lies in a rational interval $I_n\subset[1/2,3/5]$. Horner interval evaluation begins at $[c_2,c_2]$, multiplies by $I_n$, adds $c_1$, multiplies by $I_n$, and adds $c_0$. Four-corner interval multiplication encloses all possible products even if coefficients or intermediate intervals change sign. Hence the final interval always contains $h(t_*)$.

Bisection preserves the root bracket because $g$ is strictly increasing and its midpoint cannot be a rational root. Its width is $|I_n|=(1/10)2^{-n}$. The width of the degree-two Horner enclosure is at most

$$
\left(|c_1|+\frac65|c_2|\right)|I_n|.
$$

This follows by bounding the first affine enclosure's magnitude by $|c_1|+(3/5)|c_2|$ and multiplying once more by an interval of magnitude at most $3/5$. Therefore the enclosure converges to the nonzero number $h(t_*)$. Eventually both endpoints have its sign, so `sign` terminates. For a constant nonzero residue it terminates immediately. Comparing $a$ and $b$ by the sign of $a-b$ therefore implements the declared real order exactly.

All public exact weights are `Fraction` or `Cubic`; internal integer constants are coerced into rational field elements. The formulas introduce no floating-point conversion. Rational initial weights remain rational, and fixed-root weights with $A_0=1$ remain in $F$ at every finite depth. Serialization records rational coefficients, the defining polynomial, and the isolating interval, preserving which real root is meant. `scalar_record`'s docstring mentions integers, but its `_exact` guard admits only `Fraction` or `Cubic`; a public integer must first be wrapped as `Fraction`. This documentation mismatch does not change the proved arithmetic domain.

**Falsifier:** an incorrect quotient reduction, transposed multiplication matrix, nonenclosing interval multiplication, or an equality decision based on rounded display would break the proof-to-code mapping. The inspected source contains none of those operations. **Remaining obligation:** imports, runtime dispatch, and actual checks of outputs were not executed by this lane; root must retain that distinction when closing executable claims.

## SV07: graph-level gauge covariance and the flat/flux boundary

**Verdict: derivation reconstructed.** On a fixed finite graph take independent signs $\chi_v\in\mathbb Z_2$, spins $s_v$, and fixed background links $u_{vw}$. The passive transformation

$$
s'_v=\chi_vs_v,  u'_{vw}=\chi_vu_{vw}\chi_w
$$

preserves $s_vu_{vw}s_w$, because every $\chi_v$ occurs twice. It is a bijection of spin assignments and preserves counting measure. Forgetting interior spins is equivariant with respect to this full graph action and restriction of its vertex signs to retained vertices. This is a statement about a kernel on one fixed graph; the background links transform as part of the model data.

For one path, direct expansion as in SV02 gives $2A^2(1+t^2h sr)$ with $h=u_{Lm}u_{mR}$. Under the compatible edge transformations $h'=\chi_Lh\chi_R$ because the middle sign cancels. Let the two path products be $h_1,h_2$. Their cycle product $h_1h_2$ is invariant. For equal path products, $h_1=h_2=h$, the diamond formula is the same as SV02 with $sr$ replaced by $shr$. This proves the flat-background specialization and its dressed endpoint correlation $\mathbb E[s h r]=t_*$.

If every cycle in a connected finite graph has product one, choose a root frame and recursively choose $\chi$ along a spanning tree to send each tree link to one. Each non-tree link closes one tree cycle; its product constraint sends that link to one as well. Replacing flat paths by their products preserves all coarse cycle products. This proves gauge fixing to the all-positive background without identifying the discrete links with a smooth connection.

For opposite path products, $h_2=-h_1$, the exact product is instead

$$
4A^4(1+t^2h_1sr)(1-t^2h_1sr)=4A^4(1-t^4).
$$

This is strictly positive but has zero pair contrast. The two sectors have different amplitudes $4A^4(1+t^4)$ and $4A^4(1-t^4)$ as well as different interactions. A uniform nonzero fixed law in both sectors is therefore refuted by one cell. The pure graph-frame covariance is correct; nonflat dynamical gauge-matter fixed points and integration over gauge links are separate constructions.

**Falsifier:** a noncancelling interior frame sign, a flat cycle acquiring negative product under path contraction, or the opposite-flux table retaining nonzero contrast would invalidate the stated finite claim. **Remaining obligation:** no nonflat fixed point, plaquette dynamics, continuum gauge interpretation, or autonomous dynamics of an omitted flux variable is supplied.

## SV08: endpoint gauge permutations do not commute with blind homogeneous copying

**Verdict: refuted for the unqualified commutation assertion; no such assertion is required by SV07.** This explicit boundary prevents an invalid integration claim. Write $G$ for flipping only the left endpoint of a table, and $R=\texttt{diamond}$. Then $G w_{A,t}=w_{A,-t}$. Each serial path squares the signed contrast, so for $t>0$,

$$
R(Gw_{A,t})=w_{A',f(t)},  G(Rw_{A,t})=w_{A',-f(t)}.
$$

The two tables differ. Applying the same endpoint flip to all four copied tables does not implement compatible frame choices at their shared middle vertices: one occurrence of a middle vertex would inherit a right-end frame and the next a different left-end frame. Graph-level gauge covariance instead transforms the four edge/link tables with one consistent sign for each actual vertex. The `gauge` helper, lines 213–217, correctly permutes a finished boundary table; it does not make the unary four-copy map equivariant under that blind action.

**Falsifier of this refutation:** restricting to $t=0$ makes the example equal, or replacing the blind copying action by compatible graph-level transformations removes the claimed commutation problem. **Disposition:** retain SV07 with its graph-level action; do not advertise `diamond(gauge(table,...)) == gauge(diamond(table),...)` for independent endpoint flips. This is a scope condition, not a defect in the inspected finite forgetting kernel or an instruction to change code.

## SV09: series-only nonexistence within the stated class

**Verdict: derivation reconstructed.** A single two-edge branch gives $A'=2A^2$ and $t'=t^2$. A fixed contrast in $0\leq t<1$ must solve $t(t-1)=0$, hence is zero. Iteration gives $t_n=t_0^{2^n}\to0$ for $0<t_0<1$. This proves nonexistence only for the positive homogeneous zero-field series-only replacement class. It cannot refute all interacting RG fixed points, and SV04 supplies a branching counterexample to any such wider statement.

**Falsifier:** a series-only contrast satisfying $0<t<1$ and $t=t^2$, or changing the replacement to include parallel branches while retaining the nonexistence claim. **Remaining obligation:** none for this restricted obstruction.

## SV10: common stochastic channels retain a conditional KL penalty

**Verdict: derivation reconstructed; universal fixed-channel contraction equality is refuted.** Let finite $p(x)>0$, fixed row-stochastic $C(y\mid x)$, and $q$ satisfy $qC=Q$. Set $P(x,y)=p(x)C(y\mid x)$ and $J_q(x,y)=q(x)C(y\mid x)$. On supported joint atoms the channel factors cancel, and summing over $y$ gives

$$
D(J_q\Vert P)=\sum_xq(x)\log\frac{q(x)}{p(x)}=D(q\Vert p).
$$

Factor the same ratio into its marginal and conditional terms. For positive $Q(y)$ this yields

$$
D(q\Vert p)=D(Q\Vert pC)+\sum_yQ(y)D(J_q(\cdot\mid y)\Vert P(\cdot\mid y)).
$$

Zero-$Q$ terms contribute zero without requiring a conditional there. All reference conditionals used at positive $Q$ are defined because feasibility implies $(pC)(y)>0$. Nonnegativity follows, for example, from $-\log u\geq1-u$ applied termwise to the ratio of reference and compared probabilities; equality occurs only for equal normalized conditionals on each positive-$Q$ row. Thus one cannot discard the correction by citing marginalization alone.

Over unrestricted supported joint laws with $Y$ marginal $Q$, the table $J^*(x,y)=Q(y)P(x\mid y)$ attains the coarse KL exactly. It need not factor as $q(x)C(y\mid x)$. The two feasible sets differ.

For the proposed fully positive example,

$$
p=(1/2,1/2),  C=\begin{pmatrix}3/4&1/4\\1/4&3/4\end{pmatrix},  Q=(5/8,3/8),
$$

the first coarse coordinate is $1/4+q_0/2$, so $q_0=3/4$ is the unique feasible fine law. Also $pC=(1/2,1/2)$. Directly,

$$
D(q\Vert p)=\frac34\log3-\log2,
$$

$$
D(Q\Vert pC)=\frac58\log5+\frac38\log3-2\log2,
$$

and subtracting gives

$$
\inf_{q:qC=Q}D(q\Vert p)-D(Q\Vert pC)
=\frac18\log\frac{2^8 3^3}{5^5}
=\frac18\log\frac{6912}{3125}>0.
$$

The unrestricted optimum is

$$
J^*=\frac1{32}\begin{pmatrix}15&3\\5&9\end{pmatrix},
$$

with $X$ marginal $(9/16,7/16)$ and $J^*(Y=0\mid X=0)=5/6$, not $3/4$. This explicitly exhibits the violated fixed-channel restriction. For deterministic forgetting, the posterior-conditional joint lift remains in its deterministic fibers, so the deterministic contraction theorem is unaffected.

**Falsifier:** the displayed $q$ failing $qC=Q$, another feasible $q$ changing the infimum, or $6912\leq3125$. The explicit linear solution and integer inequality rule those out. **Remaining obligation:** none for this counterexample. A different reduced inference family with fixed within-bin conditionals and a stochastic readout is not the constrained problem refuted here; it must be checked against its own objective and retained conditional penalty.

## SV11: the endpoint observation helper preserves evidence and posterior distinctions

**Verdict: derivation reconstructed at source level; executable results remain open.** Write $W_i>0$ for the four retained endpoint weights and $L_{oi}>0$ for a complete observation catalog with $\sum_oL_{oi}=1$. The helper at lines 272–291 validates this equality exactly; despite its docstring's verb, it does not renormalize unnormalized inputs. It forms

$$
\widetilde W_{oi}=W_iL_{oi},  M_o=\sum_iW_iL_{oi},  p(o)=M_o/Z,  p(i\mid o)=W_iL_{oi}/M_o.
$$

Summing $p(o)$ gives one by column normalization. All denominators are positive. For any admitted normalized recognition vector $q$ on endpoints,

$$
\sum_iq_i\log\frac{W_iL_{oi}}{Zq_i}
=\log p(o)-D(q\Vert p(\cdot\mid o)).
$$

This is the endpoint ELBO identity with the generative reference normalized by $Z$. The code returns exact law, evidence, and unnormalized posterior weights, leaving logarithmic evaluation separate. It neither claims algebraic logarithms are rational field values nor handles observations on eliminated interiors. Such observations require pushing their complete reference/evidence pair and retaining the conditional correction from the full law.

**Falsifier:** accepting incomplete observation columns as normalized, dividing evidence by $M_o$ instead of $Z$, or normalizing a posterior by the original $Z$ instead of $M_o$. The inspected source uses the correct distinct denominators. **Remaining obligation:** scientific execution and integration with arbitrary interior observation slices were not established here.

## Reconstruction disposition

The finite retained-action theorem, exact diamond normalization, interacting cubic root, homogeneous instability, finite graph gauge covariance, opposite-flux obstruction, series-only obstruction, and stochastic-gap counterexample have direct reconstructed derivations above. The source arithmetic and table formulas match those derivations at the frozen module hash. This does not report executed implementation success.

The independent endpoint-permutation commutation assertion in SV08 is false and must not be substituted for compatible graph-level covariance. Fixed normalized root action does not mean fixed raw partition across growing graphs, one linear stochastic transform on root laws, general agent-family closure, or an infinite-volume/continuum universality theorem. Those stronger conclusions remain open unless separately typed and proved. No desired conclusion was used to select a root, assert irreducibility, erase a conditional penalty, or remove a flux sector; the exact formulas determine each outcome.
