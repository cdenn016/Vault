<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Fixed-conditional event evolution and a finite-path error bound

Family ID: fixed-conditional-mixture. Type: CONSTRUCTION and LEMMA, proposed for independent reconstruction; no ledger closure is asserted here.

## Exact finite statement and domains

Let X be a nonempty finite set with counting measure, g:X->B a surjection onto a finite set, and rho_x>0 with sum_{g(x)=b}rho_x=1 for each b. Let r be a strictly positive probability vector on B and define Q_r(x)=r_{g(x)}rho_x. All targets p_i(x) are strictly positive normalized probability vectors. All time increments h_i are finite and nonnegative. The partition and rho are fixed throughout the history. A chosen stochastic observation/availability/coarse channel C_i can change with i and may have structural zeros. This construction makes no assumption that X changes when Gaussian agents enter or leave their domains.

Every Q_r is positive and normalized. Conversely its bin marginal is exactly r, so the embedding is injective. For a tangent u with sum_b u_b=0, dQ_r[u](x)=u_{g(x)}rho_x and its Fisher norm squared is

$$
\sum_x \frac{(u_{g(x)}\rho_x)^2}{r_{g(x)}\rho_x}
=\sum_b \frac{u_b^2}{r_b}.
$$

Thus this family carries exactly the positive bin-simplex Fisher metric, not an arbitrary Euclidean metric.

## Restricted objective and exact step

Set ell_b=sum_{g(x)=b}rho_x log(p_x/rho_x), Z=sum_b exp(ell_b), and pi_b=exp(ell_b)/Z. All quantities are finite, and pi is positive and normalized. Direct expansion gives

$$
\operatorname{KL}(Q_r\Vert p)
=\sum_b r_b(\log r_b-\ell_b)
=\operatorname{KL}(r\Vert\pi)-\log Z.
$$

If p_B(b)=sum_{g(x)=b}p_x and p(x|b)=p_x/p_B(b), then ell_b=log p_B(b)-KL(rho_b||p(.|b)). Consequently Z<=1, with equality exactly when every conditional equals rho_b. The minimizing r is pi, uniquely because KL(r||pi)>=0 with equality only at r=pi. The full-family target bin marginal p_B generally is not the restricted optimum; the within-bin conditional penalty cannot be omitted.

The Fisher descent satisfies dot r_b=-r_b[log(r_b/pi_b)-sum_c r_c log(r_c/pi_c)]. Subtracting two log-coordinate equations gives d/dt log(r_b/r_c)=-log(r_b/r_c)+log(pi_b/pi_c). Its exact finite step is

$$
r_b(h)=\frac{r_b(0)^{e^{-h}}\pi_b^{1-e^{-h}}}
{\sum_c r_c(0)^{e^{-h}}\pi_c^{1-e^{-h}}}.
$$

Positivity and normalization follow directly. Differentiating the objective along this solution yields minus the r-weighted variance of log(r/pi), so it is nonincreasing and stationary exactly at pi. For singleton bins rho_x=1 and pi=p, recovering the full simplex evolution. These statements are exact-real finite mathematics; floating calculations are implementation controls.

## Driven finite history and approximation bound

Initialize the full law q_0=Q_{r_0}. At step i, evolve q_{i-1} by the full Fisher step toward p_i and r_{i-1} by the restricted step above for the same h_i. Put a_i=exp(-h_i), v_i(x)=log(p_i(x)/rho_x), delta_i(x)=v_i(x)-ell_{i,g(x)}, and D_i=osc(delta_i)=max delta_i-min delta_i. Let e_i(x)=log(q_i(x)/Q_{r_i}(x)). Expanding the two finite steps, canceling log rho, and collecting their scalar log-normalizers gives

$$
e_i(x)=a_i e_{i-1}(x)+(1-a_i)\delta_i(x)+k_i,
$$

where k_i is independent of x. Oscillation ignores k_i and is subadditive, so defining H_0=0 and H_i=a_i H_{i-1}+(1-a_i)D_i yields osc(e_i)<=H_i by induction. This is a history bound from the driven target sequence; it is not a fixed-target score-bin interpolation or a reset to a full reference at each step.

For any two positive normalized laws u,v with D=osc(log(u/v)), let m=min u/v and M=max u/v. Unless u=v, m<1<M, E_v[u/v]=1, and M/m=exp D. Convexity of |L-1| on [m,M] bounds it by the chord joining its endpoint values, giving TV(u,v)<=((M-1)(1-m))/(M-m). Holding M/m=R, the latter is [R+1-Rm-1/m]/(R-1), maximized at m=R^{-1/2} because Rm+1/m>=2 sqrt R. Therefore

$$
\operatorname{TV}(u,v)\leq\frac{\sqrt R-1}{\sqrt R+1}
=\tanh(D/4).
$$

It follows that TV(q_i,Q_{r_i})<=tanh(H_i/4). For any row-stochastic C_i, the triangle inequality and row normalization give TV(C_i#q_i,C_i#Q_{r_i})<=TV(q_i,Q_{r_i}); hence the same bound covers all current availability/parent laws even as those channels change. The bound does not control conditional attention at vanishing occupancy, instantaneous rate errors, Gaussian approximation, or derivatives of the context-dependent channels. Undefined conditional attention remains undefined.

## Executable state and limits

Compile g from only the initial score partition and rho from only q_0. Only r changes during inference. Reconstructing a fine law to evaluate diagnostics uses transient 256-entry output; immutable rho still stores 256 floating values, and g stores 256 integers. Report those costs separately from the B evolving masses, the exact Gaussian, and the full-event baseline. Fewer evolving coordinates is not a total-memory reduction claim. In this implementation, all saved histories and the full reference are diagnostic artifacts, not purported compact runtime state.

The positive finite construction handles availability boundaries by carrying r unchanged while replacing C_i. It is not a claim about boundary matching for changing latent sample spaces. A continuous forcing theorem can be obtained by proving convergence of the above sums under explicit regularity; that additional limit is not assumed here. The numeric H recurrence and tanh evaluation are not outward interval arithmetic, so output should say evaluated theorem bound, not floating-point certificate.

## Failure tests and cross-lane questions

Small controls should test the Fisher pullback, objective decomposition, projected rate by finite differences, semigroup with fixed target, singleton parity, two equal-bin-mass targets with different conditional penalties, and the discrete oscillation/TV bounds over changing targets and stochastic channels. A mathematical failure would be any positive finite example violating the algebra or oscillation recurrence under the fixed g/rho assumption. Re-fitting g or rho after each step is outside this proof.

Evolution lane: independently reconstruct the driven log-coordinate recurrence and identify what extra assumptions are sufficient for a continuous-forcing counterpart; do not infer it from a numerical refinement plot. Coverage lane: this is a restricted driven state, and should not be recorded as a general autonomous parent closure.

Novelty fingerprint: finite disjoint conditional mixture + exact simplex Fisher restriction + log-ratio oscillation recurrence + changing stochastic readout + positive fixed latent carrier + reduced moving-state error obligation. This is a program construction, without a literature-priority claim.
