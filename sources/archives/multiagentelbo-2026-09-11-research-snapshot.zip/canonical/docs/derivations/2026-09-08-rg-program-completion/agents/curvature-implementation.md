<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Finite curvature implementation handoff

Revision 2 frozen handoff, 2026-09-08. The authorized implementation batch creates only src/multiagent_elbo/rg_v2/curvature_models.py and tests/rg_v2/test_curvature_models.py plus this note. Discovery and reconstruction submissions remain unchanged. Other agents own integration, config, runner, route, artifacts and execution. No tests or code were run in this lane, and no runtime or passing-result claim is made.

## Implemented interfaces

compact_link_record(gauge_bias: Fraction, matter_t: Fraction, recognition_bias: Fraction, observation_bias: Fraction)->dict admits 0<=s,t<1, -1<u<1 and 0<delta<1. The order of each four-sign state is itertools.product((-1,1), repeat=4); cycle edges are (0,1),(1,2),(2,3),(3,0). Flux order is (-1,+1). Observation order is (0,1), with observation 0 likelihood (1+delta H)/2. A non-Fraction parameter is rejected. The returned schema_version is finite-curvature/v1.

All finite masses, counting/Haar partitions and polynomial nonclosure quantities are Fraction objects, with tuples/lists and string-key dictionaries only. Root should use its existing Fraction-aware serializer. The 16x16x2 joint table is normalized link prior times normalized spin conditional times normalized observation. Recognition is the specified link law times uniform spins. The record retains the spin counting partitions 16(1+t^4 H), both posterior tables/evidences, link/flux coarse posteriors, exact density-ratio factorization, full gauge pushforwards, and separate floating VFE/conditional-KL residuals. kappa is evaluated as log((1+s)/(1-s))/2 from exact rational numerator/denominator logs; Z_Haar=1/(1+s) is exact. The compact-link function does not import torch or any research runtime.

The integration_controls field contrasts the actual normalized spin marginal, which preserves the original prior, with the separate unnormalized factor model. Its normalizer against prior links times uniform spins is 1+s*t^4 and its field marginal is prior(Theta)*(1+t^4 H)/(1+s*t^4). The two_square field retains all four flux-sector factors, their normalized masses, the exact AC-B^2 quantity, and the floating logarithmic exterior-loop coefficient. At t=0 the nonclosure coefficient is zero; the separate nonclosure_at_positive_t flag is false and is not mislabeled as a failed exact identity.

base_curvature_record(lambda_base: float, mass_squared: float, xi: float, auxiliary_dimension: int, recognition_mass: float)->dict uses the two-sphere reference weights (1/5,4/5), radii (1,2), and scalar curvatures (2,1/2). It admits finite scalar values, mass_squared>0, xi>=0, an integer auxiliary_dimension>=1, and 0<recognition_mass<1. It evaluates normalized binary masses in log space and rejects a numeric regime whose reported positive masses or partitions underflow/overflow binary64. The exact_checks field covers only rational reference/geometric identities. All base masses, partitions, Gaussian integrals, VFE and residuals are explicitly binary64 formula evaluations, not exact rational probabilities.

base_prior records the original curvature potential, masses, partition, reference KL, VFE and independently assembled binary-KL expression. gaussian_factor_model records h_i=m^2+xi R_i, covariance 1/h_i, action shifts r log(h_i)/2, the raw Gaussian partition including (2pi)^(r/2), the induced binary marginal, and the expanded full joint VFE. Matched Gaussian recognition conditionals give the retained value. The distinct covariance-2/h control adds r(1-log 2)/2>0 conditional KL. normalized_gaussian_conditional_control preserves the original base prior; constant_curvature_control evaluates the cancellation when both labels have R=2. The sole base observation is certain, with exact evidence one.

## Integration-facing field summary

Both records expose exact_checks as named booleans and numerical_residuals as named floats. These are model outputs to be independently assessed by the root runner, not a test outcome. The compact record also exposes definitions, parameters, joint_masses, recognition_joint_masses, observations, gauge_bookkeeping, flux_response, integration_controls and two_square. Each observation contains observation, evidence, posterior_joint_masses, posterior_link_masses, posterior_flux_masses and vfe. The vfe map contains full, link, flux, discarded_spin_conditional_kl, posterior_kl and negative_log_evidence.

The base record exposes definitions, parameters, base_prior, gaussian_factor_model, normalized_gaussian_conditional_control and constant_curvature_control. Exact label values are Fraction; the inferred binary probabilities are floats. All schema field names are now available for root integration. There is no auto-dispatch, profile mutation, heat kernel, generic geometry engine, continuum field, or implicit connection learning.

## Added tests and unexecuted checks

The test file independently enumerates the 16 conditional spin sums and all joint observation probabilities; checks both exact evidences and flux posteriors; computes the discarded-spin KL from its analytic uniform-spin expectation; compares full VFE to direct atom sums; applies independent single-vertex gauge transformations; reconstructs the alternative unnormalized-factor marginal; enumerates six spins on four representative two-square link sectors; checks the decoupled and nonuniform-recognition control; and computes the two-sphere/Gaussian integrals directly. Input exclusion tests reject unsupported probability parameters and arithmetic types. They do not manipulate artifacts or corrupt files.

Root owns execution after integration. Suggested focused node: tests/rg_v2/test_curvature_models.py. No test was collected or executed, and no result count is claimed. Post-edit change-log integration also remains root-owned under the assignment's three-file ownership boundary.

## Freeze record

Static source/test readback is complete. The public API and schema above are frozen for root integration. No scientific code, import, test collection, or test execution was performed in this lane. Root must establish execution outcomes from its own current run; any subsequent source/test change invalidates the hashes below.

| Artifact | SHA256 |
| :--- | :--- |
| src/multiagent_elbo/rg_v2/curvature_models.py | 023e9152317f2745b60d8841860f38c5f966ab226400122b69743b9719248bc1 |
| tests/rg_v2/test_curvature_models.py | dddc34c64c3841424766c59cac874ee2846872c5ec93c263945622777e7fc495 |
| agents/curvature-implementation-brief.md | 74ca0dcd1e3bb688c41296e150bbbebc1005823f7e75deefa29894d4580e75d4 |
| agents/gauge-action.md | 267ca1217b1168b09bbb8fcffd4b6558d956fd96dc3560ded85c2610a9c9c39f |
| agents/statistical-base-curvature.md | 39beb9fc400533c34bef63c54c23f9bea85ea4c547542bbcd8103311c482667d |
| agents/gauge-action-verification.md | 427a5b34a9af4db0992915da05b6d889b649853a58c29a56bec1854ba27261bf |

The three discovery/reconstruction hashes agree with their preimplementation frozen revisions. This file records only the authorized three-file implementation and readback. Root retains runner/artifact wiring, execution, daily change-log integration, and final interpretation.

