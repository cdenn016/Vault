<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->
# Exact hierarchical Ising implementation

Revision 2: files frozen for the root's focused verification batch. Mathematical status remains unclosed. Owned files are hierarchical_ising.py, test_hierarchical_ising.py, and this file only.

The public scalar type is Fraction or Cubic, a three-Fraction coefficient vector in Q[t]/(t^3+t^2+t-1). FIXED_T is the distinguished root with rational isolating interval (1/2,3/5). No float is accepted as an exact scalar.

BoundaryTable(weights) stores four positive unnormalized weights in (++,+-,-+,--) order. Its partition and probabilities properties expose the retained normalizer and ordinary normalized boundary law separately. Public functions are ising_table(A,t,link=1), series(left,right), parallel(left,right), diamond(table), diamond_step(A,t), ising_coordinates(table), diamond_graph(depth), direct_table(A,t,depth=1,links=None), gauge(table,left,right), observe(table,likelihoods), fixed_witness(), and scalar_record(value). A two-terminal table need not be re-fit before composition. direct_table is explicitly guarded to depths 0,1,2.

diamond_step returns (new_A,new_t). ising_coordinates returns (A,signed_contrast) only on the exact spin-reversal-symmetric table; the signed contrast incorporates a negative link. diamond_graph returns (vertex_count,ordered_edges). direct_table enumerates all interior spin configurations independently of the recursive table map; optional fixed links align with its ordered edges. gauge permutes terminal coordinates. observe requires complete positive normalized observation rows and returns exact evidence and posterior-table records. It does not attach numerical log evaluations to exact-law claims.

fixed_witness returns an exact table and coefficient/isolating-interval/stability data; scalar_record encodes rationals or three rational coefficients for runner serialization. Decimal display belongs to the root runner, not the exact backend.

Cross-lane typing: reduced-event.md uses a fixed conditional embedding and stochastic readout, not fixed-channel constrained contraction. coverage.md is being consulted for the witness's boundary relative to the broader program. Scale is the declared diamond graph-distance factor 2, not the moving-context or inference parameter.


## Implementation notes and invariants

The module is now written. Cubic implements exact coefficient addition, polynomial reduction, multiplication-matrix inversion over Fraction, integer powers, and ordered sign decisions by rational interval isolation. Its comparison loop terminates for every nonzero residue: the irreducible degree-three polynomial cannot share a root with a nonzero degree-at-most-two residue, and rational bisection plus interval Horner evaluation converges to that nonzero value. Exact zero is decided from the canonical three coefficients first. This is a mathematical implementation argument, awaiting independent reconstruction; no numeric tolerance is used.

BoundaryTable supports arbitrary positive two-terminal tables for composition. The optional ising_coordinates extraction requires exact simultaneous-spin-reversal symmetry. It returns signed contrast, so a negative dressed link is represented without silently erasing its sign. No approximate projection to this family is implemented.

diamond_step updates the amplitude A as well as t. The scalar action offset is -log A and is not identified with the normalized-law action offset log Z-log A. The backend retains exact positive algebraic weights and normalizers; it does not pretend logarithms of algebraic numbers are Fractions. The root runner can produce separately labeled numerical log displays.

observe(table, likelihoods) returns a tuple of ObservationSlice objects with fields evidence and posterior_weights and a posterior property. Likelihood rows cover all observations and four endpoint states; every column must sum exactly to one. posterior_weights contains raw W*likelihood, evidence is its partition divided by the original partition, and posterior normalizes that table. This keeps evidence, raw weights, and posterior probabilities distinct. For simplicity this observation helper is on retained endpoint observations; arbitrary observations involving eliminated interiors belong to the existing complete reference/evidence table framework.

The tests contain eleven collected cases: three rational direct/staged comparisons (depths 0,1,2), asymmetric series/parallel composition, exact field/isolating arithmetic, interacting fixed-law and stability identities, algebraic depth-one direct enumeration plus depth-two normalization, series-only contraction, gauge/flux controls, complete positive observation bookkeeping with a separately labeled numerical log/ELBO identity, and ordinary exact-number/graph-size admission. The depth-two direct enumerator visits 4096 full spin assignments. No large graph is admitted.

## Cross-lane response to Coverage O4

The nontrivial arrow forgets the newest diamond interior spins on a fixed D_N, producing the law on D_(N-1) with updated edge weights. A homogeneous coarse-edge-template identification supplies the action-coordinate endomorphism. The fixed object is its normalized two-root action class. Raw A_n and Z_n are retained and generally grow under graph construction; they are not falsely claimed invariant across different D_n. For elimination of one already fixed finite graph, the complete partition is invariant. The generic action frameworks remain untouched, since this module's added interface is exact local table algebra and the cubic fixed-law witness, which the Fraction-only carrier cannot represent.

The observed shared-channel KL correction remains intact in reduced-event and completion modules; no constrained stochastic contraction identification has been introduced. Scale, context transport, and inference duration remain distinct.

## Execution status

No scientific module import, test, enumeration, or experiment has been executed by this lane. Source and test AST parsing passed, and all three owned files are UTF-8 with LF line endings. No scientific execution is inferred from these static checks. Mathematical claims remain unclosed for the separate verification wave. The root owns the daily change log and click-to-run profile/runner integration.

Source SHA256: ef41955e5cb8697ef1a9c17b98d06149f5c67f5fa87600db84583b8205061ae5. Test SHA256: f071b4eb3d35df5d27a404cd42d88156de481730be28322065bc5becc706a5a9.
