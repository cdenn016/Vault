<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Metric-projected quotient connections

Revision 2, frozen September 8, 2026. This is a bounded mathematical derivation on fixed-rank smooth bundles. The author previously wrote the statistical/base-curvature discovery lane and its finite implementation. This report shares their task context and filesystem; it is not independent verification of those submissions. Only this Markdown is owned. No code, tests, imports, numerical execution, GPU work, tamper checks, ledger edits, or vault writes were performed.

The proposed connection is exactly the candidate already derived in [the nonflat-parent note](../../2026-09-08-nonflat-parent-connections.md) and returned by parent_compatibility. Its additional interpretation is a metric-compatible connection on a quotient after choosing the fine metric and its orthogonal splitting. That interpretation does not make the coarse map parallel. The general projected connection can acquire curvature from a varying retained subspace even when the fine connection is flat. The current scalar-weight common-SO(2) fixture acquires no such curvature: its additional scalar derivative disappears in quotient-orthonormal coordinates. Propagating the quotient metric through a hierarchy makes this projection functorial; resetting the metric at an intermediate level can destroy that identity. None of these statements replaces the existing prescribed parent connection or establishes autonomous parent dynamics.

## 1. Exact domain and relation to existing theory

Let M be a smooth base, E a rank-n real vector bundle with a Euclidean fiber metric in the selected local frame, and Q a rank-m bundle. Work where a C2 bundle map F:E to Q is surjective, with m fixed. Let the source connection be \(\nabla=d+A\), where A is a C1 matrix one-form and \(A^\top=-A\). Transpose below acts on matrix coefficients without changing the order of differential forms. Matrix products between forms use exterior products. The curvature convention is \(K_A=dA+A\wedge A\), matching the existing note. No base Riemannian metric is needed to define this connection or its curvature two-form.

Define
\[
 H=FF^\top,\qquad g=H^{-1},\qquad
 R=F^\top g,\qquad \Pi=RF,\qquad N=I-\Pi.
\]
Full row rank makes H positive definite. Direct multiplication gives
\[
 FR=I,\qquad \Pi^2=\Pi=\Pi^\top,\qquad
 R^\top R=g,\qquad F=g^{-1}R^\top.
\]
The range of R is \((\ker F)^\perp\). For any y, all solutions of Fz=y have the form \(z=Ry+v\) with \(v\in\ker F\). Orthogonality gives
\[
 \|z\|^2=y^\top g y+\|v\|^2.
\]
Thus g is exactly the quotient norm, and Ry is its unique minimum-norm representative. Calling R a metric-horizontal lift refers to this fiberwise splitting. It does not assert that \(\nabla(Ry)=0\), or that R supplies a horizontal lift for an Ehresmann connection on the base.

Define the quotient connection by selecting that representative:
\[
 \nabla^Q y=F\nabla(Ry)=dy+B y,\qquad
 B=F(dR+A R)=(FA-dF)R.                                      \tag{1}
\]
The last equality follows from \(d(FR)=0\). This operator is a connection because the coefficient of dy is FR=I. Under the isomorphism \(R:Q\to\operatorname{range}\Pi\), it is the orthogonally projected connection \(\Pi\nabla\).

This is already the nonflat-parent note's candidate formula. That note asks the stronger question whether some target connection makes F parallel, and correctly rejects the candidate when its kernel obstruction is nonzero. Equation (1) asks a different, explicitly metric-dependent question: differentiate the minimum-norm representative and project back. The result is well-defined even if differentiating an arbitrary representative would depend on its discarded component.

The same distinction is present in [Theory/06_general_coarsegraining.tex](../../../../Theory/06_general_coarsegraining.tex), section “Galerkin operators and message passing.” There an injected subspace and reference form define a valid compressed operator \(H_c=CHP\), while exact propagation on every fine vector additionally requires \(CH(I-PC)=0\). Here a metric splitting defines a valid projected connection, while parallel descent additionally requires preservation of the discarded subbundle. The derivative of a varying lift in (1) is necessary and has no analogue in a constant algebraic injection. This is a connection specialization of existing projection geometry, with no novelty or priority claim.

For primary-source context, Schlafly's [Universal connections: the local problem](https://msp.org/pjm/1982/98-1/pjm-v98-n1-p15-s.pdf), Pacific Journal of Mathematics 98 (1982), section 2, printed pages 158–159, defines the canonical connection and curvature on the real, complex, and quaternionic Stiefel bundles. The orthonormal-frame specialization below is that standard projected construction. The proofs needed here are supplied directly; no universal-connection existence theorem is imported. The attempted Institute repository PDF of Narasimhan and Ramanan (1961) returned 404, so its uninspected contents are not evidence in this report.

## 2. Metric compatibility and the exact descent obstruction

Multiplying (1) by g on the left yields
\[
 gB=R^\top(dR+A R).
\]
Because A is skew,
\[
 B^\top g+gB
 =(dR)^\top R+R^\top dR
 =d(R^\top R)=dg.                                           \tag{2}
\]
This is the metric-compatibility equation for \(d+B\) and the variable metric g. B need not be skew in the original target coordinates. For example, \(F=sI_2\), s positive, and \(A=aJ\), with
\[
 J=\begin{pmatrix}0&-1\\1&0\end{pmatrix},
\]
give
\[
 g=s^{-2}I_2,\qquad B=aJ-d(\log s) I_2.
\]
The scalar term is compatible with this varying quotient metric, but not with the prescribed constant target Euclidean metric unless ds=0. This reinterprets, and does not contradict, the existing note's invertible scaling example. In particular, the code's Euclidean metric_obstruction is still correctly measuring the metric named by its existing contract.

A quotient-orthonormal coordinate system is
\[
 \widehat y=H^{-1/2}y,\qquad U=F^\top H^{-1/2},\qquad U^\top U=I.
\]
Writing \(T=H^{-1/2}\), the connection in those coordinates is
\[
 \widehat B=TBT^{-1}-(dT)T^{-1}
            =U^\top(dU+A U),\qquad \widehat B^\top=-\widehat B. \tag{3}
\]
Thus metric compatibility does not require projecting B to a skew matrix in the old coordinates; it requires using the correct metric or transforming coordinates and all associated objects.

Define the second fundamental form of the retained subbundle and the failure of F to be parallel by
\[
 S=N(dR+A R),\qquad
 \mathcal E=dF+BF-FA.
\]
Their exact algebraic forms are
\[
 \nabla R=R B+S,\qquad
 \mathcal E=(dF-FA)N,\qquad \mathcal E R=0.                    \tag{4}
\]
Set \(D_A\Pi=d\Pi+[A,\Pi]\). Differentiating \(\Pi^2=\Pi\) shows that \(D_A\Pi\) has only off-diagonal blocks relative to \(\Pi\oplus N\). Its coefficients are symmetric because A is skew and \(\Pi^\top=\Pi\). The covariant product rule gives
\[
 (D_A\Pi)R=S,\qquad
 \mathcal E=F(D_A\Pi)N=g^{-1}S^\top.                          \tag{5}
\]
For the second identity, use \(F=F\Pi\) to obtain
\[
 dF N=F(d\Pi)N,
\]
and then add the \(-FA N\) term. Symmetry of \(D_A\Pi\), together with \(F=g^{-1}R^\top\), proves the last equality.

Equations (4)–(5) give the equivalences
\[
 \mathcal E=0
 \quad\Longleftrightarrow\quad S=0
 \quad\Longleftrightarrow\quad D_A\Pi=0
 \quad\Longleftrightarrow\quad \ker F
       \text{ is preserved by }\nabla.                      \tag{6}
\]
For the last equivalence, preservation of a subbundle by a metric connection also preserves its orthogonal complement: differentiate their zero inner product. Thus the orthogonal projection removes the defect on the selected lift, but not on arbitrary fine vectors. If \(\mathcal E=0\), every choice of representative gives the same quotient derivative, and the source connection truly descends through F. If \(\mathcal E\ne0\), (1) remains an induced connection defined by the chosen splitting, not an admitted parallel coarse map.

## 3. Curvature, including the projector contribution

Let \(\nabla^\Pi=\Pi\nabla\) act on sections u with \(\Pi u=u\). Then
\[
 (\nabla^\Pi)^2u
   =\Pi K_Au+\Pi(D_A\Pi)\wedge(D_A\Pi)u.
\]
To verify this, expand \(\Pi\nabla(\Pi\nabla u)\). The product rule contributes \(\Pi(D_A\Pi)\wedge\nabla u\). Its component involving \(\Pi\nabla u\) vanishes because \(\Pi(D_A\Pi)\Pi=0\). Its remaining component uses
\[
 N\nabla u=(D_A\Pi)u.
\]
Transporting this identity to Q yields
\[
 \begin{split}
 R K_B F
   &=\Pi K_A\Pi+\Pi(D_A\Pi\wedge D_A\Pi)\Pi,\\
 K_B
   &=F K_A R+F(D_A\Pi\wedge D_A\Pi)R\\
   &=F K_A R+g^{-1}S^\top\wedge S
    =F K_A R+\mathcal E\wedge S.                             \tag{7}
 \end{split}
\]
The plus sign in the second fundamental term is fixed by our convention \(d+A\). As an independent sign check, in a local orthonormal frame adapted to the retained and discarded subbundles the ambient connection has blocks
\[
 \begin{pmatrix}
 \widehat B&-\widehat S^\top\\
 \widehat S&A_N
 \end{pmatrix}.
\]
Its upper-left curvature block is
\[
 K_{\widehat B}-\widehat S^\top\wedge\widehat S.
\]
Solving for the retained curvature gives the plus sign in (7). This calculation also makes clear why compressing \(K_A\) alone is insufficient when the retained subspace varies.

The coefficient of the extra term on two tangent vectors X,Y is
\[
 g^{-1}\big(S(X)^\top S(Y)-S(Y)^\top S(X)\big).                \tag{8}
\]
It is not a nonnegative scalar energy. It is a skew-adjoint curvature endomorphism relative to g. In particular, a rank-one real metric quotient has zero curvature locally: both the compressed skew form and (8) vanish. If \(D_A\Pi=0\), the second term vanishes and the exact descended curvature intertwines F. The converse is false; a zero curvature square does not prove the first-order descent equation, as the current fixture already demonstrates.

## 4. A flat-source example with nonzero projected curvature

Take \(M=\mathbb R^2\), \(A=0\), and the everywhere full-row-rank matrix
\[
 F(x,y)=
 \begin{pmatrix}
 1&0&-x\\
 0&1&-y
 \end{pmatrix}.
\]
Put \(v=(x,y)^\top\) and \(s=1+x^2+y^2\). The quotient metric and connection are
\[
 H=I_2+vv^\top,\qquad
 g=I_2-\frac{vv^\top}{s},\qquad
 B=-\frac{dvv^\top}{s}
   =-\frac1s
   \begin{pmatrix}
    xdx&ydx\\
    xdy&ydy
   \end{pmatrix}.                                           \tag{9}
\]
Indeed, the last row of R is \(-v^\top g=-v^\top/s\), while the last column of dF is \(-dv\), so \(B=-dF R\) gives (9).

At the origin \(B=0\), \(g=I_2\), and S has only its last row nonzero:
\[
 S(0)=
 \begin{pmatrix}
 0&0\\0&0\\-dx&-dy
 \end{pmatrix}.
\]
Consequently
\[
 K_B(0)=S(0)^\top\wedge S(0)
       =\begin{pmatrix}0&1\\-1&0\end{pmatrix}dx\wedge dy
       =-Jdx\wedge dy\ne0.                                \tag{10}
\]
One can check the curvature everywhere without taking a limit. Differentiating (9), with \(ds=2v^\top dv\), gives
\[
 \begin{split}
 dB+B\wedge B
 &=\frac{dv\wedge dv^\top}{s}
   -\frac{dv\wedge(v^\top dv)v^\top}{s^2}\\
 &=-\frac{Jg}{s}dx\wedge dy.                               \tag{11}
 \end{split}
\]
Since \(gJg=J/s\), equation (11) also gives
\[
 gK_B=-\frac{J}{s^2}dx\wedge dy,
\]
which is skew, as required by (2). Thus the nonzero curvature is exact, not a finite-difference or numerical claim. The retained plane is perpendicular to \((x,y,1)\), so changing the retained subspace is the source of the second fundamental term.

This example is a standard projected-subspace mechanism, not a new gauge-theory construction. It is outside the current common-SO(2) scalar-weight fixture; the named implementation also restricts input and output coordinate counts to positive even dimensions, so its three-dimensional source is a mathematical example and was not submitted to that interface. All bundles in this example are trivial over a contractible base. Nonzero local curvature does not prove nontrivial bundle topology, nontrivial characteristic numbers, a dynamical connection, or a VFE penalty.

## 5. Coordinate changes and the metric that must travel with them

For old-to-new source coordinates \(z'=Uz\) with U orthogonal and coarse coordinates \(y'=Ty\) with T any smooth invertible matrix, the same bundle data are represented by
\[
 F'=T F U^{-1},\qquad
 A'=U A U^{-1}-(dU)U^{-1}.
\]
Here U denotes a source chart change, distinct from the orthonormal lift used in (3). The metric construction gives
\[
 R'=U R T^{-1},\qquad
 g'=T^{-\top}gT^{-1}.
\]
Substitution in \(F'(d+A')R'\) gives the connection and curvature laws
\[
 B'=TBT^{-1}-(dT)T^{-1},\qquad K_B'=T K_B T^{-1}.              \tag{12}
\]
Thus arbitrary target coordinate changes are permitted if the target metric and statistical objects transform with them. These are the same old-to-new coordinate signs used by the existing nonflat-parent family.

For a nonorthogonal source chart change, retaining the numerical matrix I as the source metric changes the model. The coordinate-covariant general form starts from a declared positive-definite source metric h:
\[
 g=(Fh^{-1}F^\top)^{-1},\qquad
 R=h^{-1}F^\top g,\qquad \Pi=RF.                             \tag{13}
\]
The source compatibility condition is
\[
 dh=A^\top h+hA.
\]
Under an arbitrary invertible source coordinate change U one must transform
\[
 h'=U^{-\top}hU^{-1}.
\]
Equations (12)–(13) then remain valid. The proof of metric compatibility uses \(R^\top hR=g\) and \(F=g^{-1}R^\top h\). More generally, without assuming source compatibility, the exact nonmetricity identity is
\[
 dg-B^\top g-gB
 =R^\top(dh-A^\top h-hA)R.                                  \tag{14}
\]
Replacing the fine Euclidean metric by a Fisher-derived or covariance-derived form is therefore not a harmless substitution if the prescribed source connection does not preserve that form.

A g-compatible quotient connection belongs to the orthogonal frame bundle of (Q,g). Its representation as the project's prescribed common SO(2) connection is a separate requirement. For a general F, mixing different representations can produce a quotient of the wrong representation type or a connection with off-block components. Changing metrics or using arbitrary target GL coordinates does not establish an equivariant coarse map under the original principal bundle and represented channel inventory.

## 6. Staged and direct projection

Let \(F:E_0\to E_1\) and \(G:E_1\to E_2\) be smooth surjections of fixed ranks. Begin with metric I on \(E_0\), induce
\[
 g_1=(FF^\top)^{-1},
\]
and use that metric, rather than a newly reset Euclidean metric, to lift through G:
\[
 R_F=F^\top g_1,\qquad
 R_G=g_1^{-1}G^\top(Gg_1^{-1}G^\top)^{-1}.
\]
Then direct multiplication proves
\[
 \begin{split}
 R_F R_G
 &=F^\top G^\top(GFF^\top G^\top)^{-1}
   =R_{GF},\\
 g_2&=(Gg_1^{-1}G^\top)^{-1}
      =((GF)(GF)^\top)^{-1}.                               \tag{15}
 \end{split}
\]
Hence minimum-norm lifts and quotient metrics compose exactly. This is also clear from minimizing the original norm over all fine preimages of a final coordinate, but (15) supplies a direct proof.

Let \(B_1=F(d+A_0)R_F\), and let \(B_2=G(d+B_1)R_G\), with each expression interpreted as a connection coefficient as in (1). The product rule and \(FR_F=I\) give
\[
 \begin{split}
 B_2
 &=GdR_G+GF(dR_F+A_0R_F)R_G\\
 &=(GF)\big(d(R_FR_G)+A_0R_FR_G\big)\\
 &=B_{\mathrm{direct}}.                                    \tag{16}
 \end{split}
\]
The same proof works with an arbitrary initial h using (13). Source metric compatibility is needed for the resulting connections to be metric-compatible, but not for the algebraic equality (16). No vanishing of either parallel-map defect is required. Curvatures agree because the final connections agree.

For comparison, if arbitrary stagewise right inverses are chosen, put \(C=GF\) and \(\Delta R=R_FR_G-R_C\). Then \(C\Delta R=0\), and the exact discrepancy is
\[
 B_{\mathrm{staged}}-B_{\mathrm{direct}}
 =C(d+A_0)\Delta R
 =(CA_0-dC)\Delta R.                                       \tag{17}
\]
Thus compatible metric propagation is sufficient because it makes \(\Delta R=0\). Actual preservation of the final discarded kernel is another sufficient condition for the last expression to vanish. A candidate computed from inconsistent splittings has no general composition theorem.

A tiny reset-metric counterexample takes \(A_0=0\) and
\[
 F=\begin{pmatrix}2&0&0\\0&1&0\end{pmatrix},
 \qquad G(x)=\begin{pmatrix}1&x\end{pmatrix}.
\]
The true intermediate quotient metric is \(g_1=\operatorname{diag}(1/4,1)\), and \(B_1=0\). If that metric is discarded and G is lifted using I, then
\[
 B_{\mathrm{staged,reset}}
   =-\frac{x}{1+x^2}dx.
\]
The direct map is \(GF=(2,x,0)\), so
\[
 B_{\mathrm{direct}}
   =-\frac{x}{4+x^2}dx.
\]
They differ in the same final coordinate system. Their metrics differ as well: \(1/(1+x^2)\) versus \(1/(4+x^2)\). With the actual intermediate metric,
\[
 R_G=\frac{(4,x)^\top}{4+x^2},
\]
and the staged formula becomes exactly the direct one. This counterexample concerns connection and metric composition; both scalar curvatures vanish. It does not claim a rank-one curvature obstruction.

Equations (15)–(16) prove functoriality of this declared metric-quotient construction. They do not prove that pushing an arbitrary fine dynamical trajectory through F gives the parallel trajectory of \(B_1\). That stronger statement is controlled by (4)–(6), not by composition of splittings.

## 7. The current normalized-weight common-SO(2) fixture

On one constant-active-set stratum and for one parent/channel, write the reference coarse map as
\[
 L=(\lambda_1I_d,\ldots,\lambda_rI_d),\qquad
 \sum_i\lambda_i=1,\qquad \lambda_i>0.
\]
The source connection is the direct sum of one common internal connection \(A_*\). In the implemented two-dimensional channel \(A_*=aJ\); the two-channel version keeps the separately configured belief and model copies. Define
\[
 \sigma=\sum_i\lambda_i^2>0.
\]
The candidate (1) becomes
\[
 R_L=\frac{\operatorname{col}_i(\lambda_iI_d)}{\sigma},
 \qquad
 g=\sigma^{-1}I_d,\qquad
 B=A_*-\frac{\sum_i\lambda_id\lambda_i}{\sigma}I_d
   =A_*-\frac12d\log\sigmaI_d.                            \tag{18}
\]
This is precisely the formula already displayed in the existing nonflat-parent derivation.

The added one-form is a scalar exact derivative. It commutes with all coefficients of \(A_*\); its wedge square is zero, and its two mixed wedge terms with \(A_*\) cancel. Therefore
\[
 K_B=K_{A_*}.                                               \tag{19}
\]
This statement holds even when the real weights vary in several base directions. In quotient-orthonormal coordinates, the lift has blocks \(t_iI_d\), where \(t_i=\lambda_i/\sqrt{\sigma}\) and \(\sum_i t_i^2=1\). Hence
\[
 \sum_i t_idt_i=\tfrac12d\sum_i t_i^2=0,\qquad
 \widehat B=A_*.
\]
Equivalently, S has blocks \((dt_i)I_d\) in this frame, and \(\sum_i dt_i\wedge dt_i=0\) makes its curvature contribution vanish. A varying retained subspace alone is thus not sufficient for nonzero projected curvature; its second fundamental directions must give a nonzero antisymmetric product as in (8).

Disjoint parent blocks produce block-diagonal copies of (18)–(19). Restoring the code's orthogonal agent and parent frames gives
\[
 F=G_{\mathrm{parent}}L G_{\mathrm{child}}^\top,
\]
and transforms B and g by (12). It does not introduce another curvature contribution. The independently declared \(\kappa_b\) and \(\kappa_m\) remain independent, and their existing nonzero curvature is retained exactly.

The defect of the projected candidate is still generally nonzero. If its block equations made F parallel, every positive weight would require
\[
 B=A_*-d\log\lambda_iI_d.
\]
All \(d\log\lambda_i\) would then agree; normalization forces that common form to vanish. Thus varying normalized weights still obstruct even unrestricted GL descent. Equation (18) does not evade that proof. Nor does the equality of curvatures in (19) imply DF=0.

The current family assigns each level its separately declared common connection and calls parent_compatibility only to record candidate and obstruction diagnostics. It does not propagate candidate-induced quotient metrics into subsequent calls. Consequently (16) is an available theorem for an additional metric hierarchy, not a claim about the presently returned stagewise diagnostic candidates. Those diagnostics also use the separately prescribed intermediate source connection. Neither this report nor the reinterpretation of (18) changes that caller contract.

All formulas apply only to support-restricted full-rank maps. A sole-child supported parent has \(\lambda=1\), \(\sigma=1\), and no scalar derivative. An absent parent has no quotient metric or connection defined by this inverse formula. No extension through a vanished parent or change of the fine bundle rank is asserted.

## 8. What a probabilistic interpretation would require

The quotient metric g is induced by the declared fine sample-space metric. It is not automatically the Fisher metric of the program's statistical law family. There is a simple conditional realization: at a fixed base point, explicitly choose a fine reference Gaussian \(N(0,I_n)\) and push it through F. The resulting law is \(N(0,H)\), H positive definite. For its mean parameter m with H held fixed,
\[
 \log p(y\mid m)
 =-\frac{d_Q}{2}\log(2\pi)-\frac12\log\det H
  -\frac12(y-m)^\top H^{-1}(y-m),
\]
where \(d_Q\) denotes the target dimension, and
\[
 \partial_m\log p=H^{-1}(y-m),\qquad
 \mathbb E[(\partial_m\log p)(\partial_m\log p)^\top]=H^{-1}=g.
\]
The second identity follows by inserting the covariance H. This is an exact mean-family Fisher identification for that selected reference model. It does not identify g with the full Gaussian Fisher metric on both means and covariances, with Fisher information in the base coordinates, or with the actual fine prior in the neighborhood experiment.

Equation (2), inverted, gives
\[
 dH+B H+H B^\top=0.
\]
Thus the reference covariance H is parallel for the projected connection, just as the isotropic fine covariance is parallel for a skew source connection. This special reference consistency does not close the evolution of arbitrary fine laws. For a fine mean \(\mu\) and covariance \(\Sigma\), put \(\mu_Q=F\mu\) and \(\Sigma_Q=F\Sigma F^\top\). Direct differentiation gives
\[
 \nabla^Q\mu_Q=\mathcal E\mu+F\nabla\mu,
\]
and
\[
 \begin{split}
 d\Sigma_Q+B\Sigma_Q+\Sigma_Q B^\top
  &=F(d\Sigma+A\Sigma+\Sigma A^\top)F^\top\\
  &\quad+\mathcal E\Sigma F^\top+F\Sigma\mathcal E^\top.
 \end{split}
\]
The discarded-state terms remain when \(\mathcal E\ne0\). They vanish for the selected isotropic reference because \(\mathcal E F^\top=\mathcal E R H=0\), but that one reference does not establish autonomy for a general recognition or generative family.

Using the actual prior precision as h is another possible declaration, but it requires checking source compatibility in (14). A prescribed Euclidean-skew A need not preserve a nonconstant anisotropic prior precision. Neither a new metric nor a new source connection should be silently substituted to force that condition.

There are two distinct ways geometry could be used. It can define the geometry of an explicitly chosen inference update while leaving the normalized joint and VFE unchanged. Alternatively, it can enter a generative model through an explicitly chosen reference measure, likelihood, or latent-field prior. In the latter case one must identify the random variables, their reference measure \(\nu\), an action E, and a finite positive normalizer
\[
 Z=\int e^{-E}d\nu,\qquad p=Z^{-1}e^{-E}.
\]
Only then does the corresponding VFE contain the chosen energy and its normalization through \(\mathbb E_q[\log q-\log p]\), together with the chosen likelihood terms. A connection alone supplies none of these ingredients. For deterministic prescribed F and A at one fixed context, a curvature-only constant independent of the latent variables cancels against its normalization if it is inserted as an overall factor in an otherwise normalized prior.

Even to define a scalar norm of \(K_B\), one must declare a base metric and volume measure, along with a fiber trace or endomorphism pairing and coupling coefficient. If the connection or F becomes random, one must then construct a finite or properly regularized field model and prove its partition function finite. The two-form in (7) is not itself a scalar VFE contribution. No curvature action, base scalar-curvature prior, determinant correction, or parent inference dynamics follows from the metric-lift algebra alone.

## 9. Readback binding and remaining boundary

The following source contents were inspected without execution. Their SHA-256 values bind the comparison in this report to the current shared-worktree files, rather than to earlier task memory.

| Source | SHA-256 |
| --- | --- |
| docs/derivations/2026-09-08-nonflat-parent-connections.md | 2df38bb0bfccff3a4729b14f4cca60210887298c4af37100ccea68d959cd1059 |
| Theory/06_general_coarsegraining.tex | fa10620d2a1d0e51b5a50b88d0a7434afcde6a0112af062e74fed586e97d7166 |
| src/multiagent_elbo/experiments/neighborhood/connections.py | 53a497039842ad16efa1ac3b335d4a8c6c44abcb4ae4f9d237180a58e5452bb9 |
| src/multiagent_elbo/experiments/neighborhood/nonflat.py | 627e2cc1694f264bf4584c3c88fdcb73b2793b8f41d25013d094c3c31fb35a24 |
| src/multiagent_elbo/experiments/neighborhood/cover.py | 0073e72aa3bca51a1cb27023ad223a91572c7be577bb296951ceaf4b70738e88 |
| docs/derivations/2026-09-08-rg-program-completion/problem-contract.json | 50db7529fc2c5cb7c032cd4e3b6517516a93800ba32db8c2c50c226ddb2a369e |

The bounded mathematical result is the metric interpretation, curvature formula, analytic witness, coordinate-covariance requirement, and composition theorem proved above. It is conditional on fixed rank and the declared metrics. It adds no curvature to the current scalar-weight fixture, admits no previously obstructed parallel parent map, changes no normalized law, and closes no ledger entry. A future implementation or probabilistic extension would require its own explicit model and metric choices; none is authorized or claimed by this report.


