<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Separate readback of the ladder numerical record

Disposition: ACCEPT; recommended RTS state EVIDENCE_VERIFIED for ladder-recorded-numerics at its exact recorded scope. The three retained XML packets contain 138 executions and 137 distinct latest passing cases. No missing record evidence was identified for that statement. This report does not edit a ledger or assess the other ladder claims.

**Exact statement.** The retained ladder runs have 137 distinct latest passing cases and the stated exact transfer, common-observation and floating diagnostic outputs.

**Exact quantifiers.** Recorded current numerical-study source plus unchanged core/routing snapshots; no independent science replay or infinite-limit inference.

**Dependencies carried from the proposed claim.** ladder-exact-channels, ladder-generated-action, ladder-common-vfe, ladder-positive-contraction. These mathematical statements are not re-adjudicated in this bounded numerical readback.

## Method and independence

A separate readback by the same subagent context that assessed the old 58 claims. The root/producer and this reader share the filesystem, parent messages, and inherited GPT-6 model family; the exact serving alias is unknown. This is not cross-model corroboration or independent scientific reproduction.

Read-only JSON/XML/source inspection and standard-library SHA-256, identity deduplication, and record equality comparisons; only the two assigned readback reports are written.

No scientific calculation or test was rerun. The authority for case totals is the raw XML, not a progress line or the parent summary. Hashes bind the records to bytes; they do not establish an infinite-limit theorem. The input claim/adjudication document, results, contract, and the two old58 reports are bound in the JSON companion.

## Execution and source reconstruction

The three XML files contain 26, 109, and 3 testcase elements, with no failure, error, or skipped outcomes. Their SHA-256 values equal the retained results.json packet bindings; each command's result records returncode 0. Taking the latest occurrence of each (classname,name) in chronological packet order gives 138 executions, one repeated native-artifact identity, and 137 latest passing identities. The latest study has nine block lengths 1,2,3,4,6,8,12,16,32. Its first/last exact rational transfer records, both common-observation VFE rows, Perron values and maximum floating residual agree with the retained result summary. All five latest manifest source hashes and all five artifact hashes match current bytes. The earlier study is preserved with its own matching artifact hashes and an older diagnostic-runner hash.

| Retained XML packet | Executions | Passed | Failures/errors/skipped |
| --- | ---: | ---: | --- |
| [focused-20260909T063237361462Z.xml](C:/tmp/elbo-cover-20260908/docs/verification/2026-09-09-positive-ladder/focused-20260909T063237361462Z.xml) | 26 | 26 | 0/0/0 |
| [routing-20260909T063249542137Z.xml](C:/tmp/elbo-cover-20260908/docs/verification/2026-09-09-positive-ladder/routing-20260909T063249542137Z.xml) | 109 | 109 | 0/0/0 |
| [perron-20260909T063701619671Z.xml](C:/tmp/elbo-cover-20260908/docs/verification/2026-09-09-positive-ladder/perron-20260909T063701619671Z.xml) | 3 | 3 | 0/0/0 |

Chronological replacement of the repeated (classname, name) identity gives 137 latest passes. The sole repeat is tests.rg_v2.test_positive_ladder_experiment::test_positive_ladder_native_artifacts, passed in the original focused packet and again in the later Perron packet. The other two Perron identities are test_perron_vectors_avoid_near_boundary_subtraction and test_unrepresentable_positive_transfer_remains_exact_but_declines_float_diagnostic. Each packet has retained process returncode zero.

The latest [manifest](C:/tmp/elbo-cover-20260908/docs/verification/2026-09-09-positive-ladder/cpu/positive-ladder-20260909T063724129829Z/manifest.json) has SHA-256 bb427817c64e4511219f197c5fd79888cc652411d3d16e400705f6e367acbd84. Its five listed source hashes and five listed artifact hashes match current bytes. The current runner is f9506aef3c64e99c89d8ca02dbb57cd3d092e0a2ffd172d8ba39324791f38960. The original runner was e0b88ccfc1b48d171b4cccce4649b844083b0661a3b28dc34a2ee810e1e1d17f. The original focused packet also records the earlier experiment-test hash; the latest three-case packet matches the changed test file.

The historical focused/routing commands are not reclassified as executions under the latest runner. Their exact core, profile, routes and dispatch hashes remain unchanged, and the relevant core/routing test hashes still match. The original successful study is preserved under [its own manifest](C:/tmp/elbo-cover-20260908/docs/verification/2026-09-09-positive-ladder/cpu/positive-ladder-20260909T063336040373Z/manifest.json); all five of its artifact hashes match. These records support retained source-specific outcomes, not a single newly executed full suite or a complete transitive environment snapshot.

The retained runtime is C:/anaconda/python.exe, Python 3.12.7. Commands use OMP_NUM_THREADS=1 and MKL_NUM_THREADS=1 for CPU execution. No CUDA science is recorded. The study configuration is a=1/5, b=2/5, c=1/3, recognition biases 1/7, 1/5, 1/4, observation bias 1/2, and block lengths 1,2,3,4,6,8,12,16,32.

## Literal scientific-record comparison

The [results summary](C:/tmp/elbo-cover-20260908/docs/verification/2026-09-09-positive-ladder/results.json) agrees exactly as parsed JSON with the latest study first and last rows, both VFE rows, Perron eigenvalue, stationary rung mass, Doeblin epsilon and control residual. All six exact-check flags are recorded true. This readback inspects their stored values; it does not independently repeat the exact calculation.

At block 1 the saved transfer entry (1,1,1,1) is 49/125, the field-matter covariance is 112000512/802305625, and the negative-flux mass is 1851/5665. Full rational numerators/denominators for all 16 entries remain in study.json. Common-observation evidences are 12123/22660 and 10537/22660; both retained rows record exact_ratio_factorization=true and discarded_conditional_kl=0.08461825651859912.

The numerical Perron eigenvalue is 1.0022481820536482, stationary rung masses are [0.610741618340258, 0.3892583816597419], and Doeblin epsilon is 0.187310364789999. Saved row TV changes from 0.2924953669478552 at block 1 to 1.685596107137144e-13 at block 32; the evaluated block-32 bound is 0.0013109649176554184. Maximum saved numerical residual is 1.3322676295501878e-15. These are finite binary64 diagnostics, not interval bounds or a limiting proof.

## Substantive attack and response

**Attack.** The 138 aggregate executions might be counted as 138 distinct tests or treated as a single current-source suite despite a diagnostic repair; the small block-32 floating TV might then be promoted into an interacting infinite-limit result. A prior successful default run also did not expose the cancellation input near the positivity boundary.

**Response.** Only one identity repeats: tests.rg_v2.test_positive_ladder_experiment::test_positive_ladder_native_artifacts. Its latest observation belongs to the three-case Perron packet; two additional identities cover cancellation and representability. The earlier 25 core cases and 109 routing cases retain the older runner snapshot while their core/routing/test files are unchanged. The latest runner and modified experiment tests are bound to the targeted packet and study. The historical Perron issue is a source-level finding, not an observed failed run; the retained input a=1-10^-400 deliberately declines binary64 diagnostics while its Fraction kernel is checked by the recorded test. A finite sample of TV values and a binary64 evaluated bound do not prove convergence, rate uniformity as the positivity gap closes, critical universality, or physical interpretation. Those statements require separate proof.

The [preserved Perron source finding](C:/tmp/elbo-cover-20260908/docs/verification/2026-09-09-positive-ladder/perron-source-finding.md) describes cancellation at a=1-10^-20, b=c=0. No earlier failed process is invented: the finding followed a successful default run. The changed source subtracts the smaller diagonal and rejects unrepresentably positive float inputs; the latest targeted XML records the corresponding three tests as passing.

## Semantic prior erasure

Deleting any preference for an affirmative result leaves XML identities/outcomes, byte-bound commands and artifacts, and literal JSON equality checks. Acceptance survives because the claim is about what these retained records contain. If a packet had failed, a hash differed, or the summary differed from its artifact, the same readback would retain that discrepancy rather than count it as a pass. The prior successful default run is not used to dismiss the concrete Perron cancellation finding. No probabilistic or search prior supplies evidence for a scientific limiting theorem.

Result: PASS for the exact recorded scope. No open obligation was identified for the retained numerical statement. Stronger claims of new reproduction, an all-source current-suite pass, uniform convergence near vanishing positivity, critical gauge universality, continuum field measures, or physical time are unsupported by this readback.

## Limits and handoff

This task did not execute tests, import a scientific package, reconstruct the exact transfer calculation, reproduce the study, query/run CUDA, or execute a historical producer.

This confirms preserved execution records and listed source/artifact bindings, not a complete transitive environment snapshot or a newly executed current-tree full suite.

The original focused/routing records remain attached to the old diagnostic runner; only the numerical-study source and changed Perron cases were refreshed.

The source-level Perron finding is retained without inventing an earlier observed test failure.

The finite block-32 diagnostics are numerical observations; no infinite-limit, critical, continuum, or physical-time inference follows from them.

Tamper checks are user-excluded and were not run. No disabled verification gate or marker/configuration change was used.

The full [JSON readback](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-08-rg-program-completion/agents/positive-ladder-numerical-readback.json) retains the raw case identities, command/runtime and source records, artifact hashes, repeated identity, and checked summary equalities. Only this report and its JSON companion were written. The frozen old58 artifacts, existing ledger, derivations, source files, and execution records remain untouched.
