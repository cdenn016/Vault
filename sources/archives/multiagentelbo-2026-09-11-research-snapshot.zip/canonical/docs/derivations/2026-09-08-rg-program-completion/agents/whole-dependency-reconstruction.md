<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Whole-dependency mathematical reconstruction

Date: 2026-09-09. Scope: one bounded reconstruction of the frozen final construction, its adopted hypotheses, and its target dependency graph. Ownership is confined to this report.

The admitted mathematical construction closes at the level of an ordinary written proof: I found no missing constructor in the finite normalized core, the adopted regular and reduced theorems, the finite-event hybrid interface, or the existential interacting fixed normalized action. This statement does not close the formal ledger, establish all executable results, or certify all 58 candidates. I reconstructed the mathematical content of 51 non-target claims and the mathematical target implication. Six numerical-observation ancestors remain evidence records that I did not independently reproduce or validate. The formal adjudicator's reported schema/session failure is a procedural limitation, not a mathematical counterexample.

This pass began with a fresh initial context but shares the model and filesystem with the other work. It is therefore not model-independent replication. I read final statements, definitions, author proofs, selected executable interfaces, the contract, SPEC, and the claim/DAG statements. Search logs, the search tree, failed candidates, earlier discussion, and verifier endorsements were not consulted as premises. Where an author proof or assembly mentioned another agent's conclusion, the conclusion supplied no logical step below. The affirmative search-prior label is examined by removing it entirely from the arguments: the constructions still follow from displayed definitions and stated hypotheses.

## 1. Exact scope of the implication

The target has different quantifiers. Its finite conjunct is universal over an already normalized nonnegative finite joint law, a declared positive-evidence observation slice, a full recognition law, and admitted recognition-independent common channels. Its regular and reduced conjuncts are conditional on the hypotheses actually adopted. Its fixed-point conjunct is existential. It does not assert that every collection of local marginals extends to a joint, that every coarse statistic has autonomous dynamics, that every effective action belongs to a small parametric family, or that every gauge background has an interacting fixed point.

Consequently, a valid implication must first construct the complete retained law and exact accounting for arbitrary admitted finite inputs. It must then prove the claimed evolution on the stated regular domains and the actual one-sided boundary policy. Finally, one executable interacting fixed normalized action can discharge the existential clause. The optional curvature constructions are additional normalized models or geometric constructions; they need not be the mechanism of the diamond fixed point or introduce a physical clock. SPEC supplies the types and admissibility conditions, not the proof of these assertions.

## 2. Universal finite construction and support

Let E and O be finite, let P(x,o) be a nonnegative joint of total mass one, fix o with Z = sum_x P(x,o) > 0, and set p(x) = P(x,o)/Z. Let q be any probability on E. Choose a finite reference measure mu dominating P(.,o) and q; counting measure always works. For a row-stochastic channel C(y|x), define

\[
P_Y(y,o)=\sum_x P(x,o)C(y|x),\qquad
q_Y(y)=\sum_x q(x)C(y|x),\qquad
\mu_Y(y)=\sum_x\mu(x)C(y|x).
\]

All three are pushed through the same channel. The first preserves evidence, the second preserves recognition normalization, and the third fixes the action reference. For mu_Y(y)>0,

\[
e^{-A_Y(y)}
=\frac{P_Y(y,o)}{\mu_Y(y)}
=\sum_x\frac{\mu(x)C(y|x)}{\mu_Y(y)}e^{-A_X(x)}.
\]

Thus exact integration is conditional expectation relative to the pushed reference. A positive reference cell with zero P_Y has A_Y=+infinity. A zero-reference cell has no density value; domination already implies P_Y=q_Y=0 there. Finite associativity of sums gives direct/staged equality for every finite composition and retains all action interactions and constants. No integral interchange or regularity is needed.

For the ELBO identity, form Q(x,y)=q(x)C(y|x) and R(x,y)=p(x)C(y|x). Their joint relative entropy is D(q||p), since the identical channel cancels on its positive entries. Disintegration then gives

\[
D(q\Vert p)
=D(q_Y\Vert p_Y)
+\sum_y q_Y(y)D(Q(\cdot|y)\Vert R(\cdot|y)).
\]

This is equality in nonnegative extended addition. Null recognition fibers contribute zero. On q_Y>0 and p_Y>0 the conditionals are normalized and support failure gives an infinite conditional KL if appropriate. If q_Y>0 and p_Y=0, the coarse KL is already infinite; the posterior conditional requires an explicitly declared probability extension. An infinite diagnostic is not itself such a probability. These rules establish the identity even when fine or coarse KL is infinite, without subtracting infinities. With F=D(q||p)-log Z, the same identity gives the VFE correction. Iterating adds the nonnegative hidden conditional terms. Infinite residuals or differences are not defined.

The executable core uses probability references. If mu has total mass M and nu=mu/M, then A_nu=A_mu-log M. Restoring +log M recovers the counting-reference action, and the same offset persists under every channel because total reference mass is preserved. The rational measure bridge and its floating logarithmic displays therefore have different arithmetic roles; a displayed logarithm does not replace exact mass accounting.

The identity does not say that every joint lift of a coarse law is obtainable from a fine marginal and a fixed forward C. For example, let p=(1/2,1/2), let the rows of C be (3/4,1/4) and (1/4,3/4), and prescribe q_Y=(5/8,3/8). The fixed-channel constraint uniquely forces q=(3/4,1/4). Direct evaluation gives

\[
D(q\Vert p)-D(q_Y\Vert p_Y)
=\frac18\log(6912/3125)>0.
\]

Allowing an arbitrary posterior-conditional lift attains the smaller coarse KL. Confusing the two feasible sets would create a false variational closure claim; the final construction keeps them separate.

## 3. Local input, gauge, and structural qualifications

A normalized local generative specification can provide the required joint: a directed acyclic product normalizes by eliminating terminal conditionals, while compatible clique-tree marginals glue by multiplying clique factors and dividing separators. A leaf-separator induction proves both the desired clique marginals and normalization. With zero separator mass, the normalized conditional extension must be specified on the null fiber; the joint mass there remains zero. A recognition coupling must likewise be supplied.

Pairwise overlap agreement on a cyclic cover is insufficient. Three binary pair laws with uniform single-site marginals and disagreement probability 0.9 on each pair would require expected total disagreements 2.7. Every three-spin assignment has either zero or two disagreements. This is a normalized-local-data obstruction, not a counterexample to the universal theorem whose input is a normalized joint. Local scalar VFEs discard still more information and cannot determine that joint. A geometric cover and bundle cocycle do not manufacture probability compatibility.

On finite spaces, a declared gauge action is a bijection of sample labels. If C intertwines the fine and coarse actions, changing variables in the finite sum proves equivariance of pushed P, q and mu and invariance of corresponding KL and VFE values. If the observation moves, the equality is between the o slice and the transformed go slice. Same-slice invariance requires a fixed observation or its stabilizer. On a null finite fiber, a uniform conditional can provide an equivariant extension where the fiber action is by permutations.

Composition of statistical channels is automatic. Compatibility with every additional geometric arrow is an admission condition, not a consequence of stochasticity. Subsequent kernels must be functions of the retained state; retaining the complete needed state is always a finite solution, with no compression guarantee. A coarse evaluator that depends on discarded marks requires retaining those marks or supplying its own closure theorem.

The differential defect makes the same issue visible on a regular stratum:

\[
D(F\mu)=F D\mu+(dF+A_YF-FA_X)\mu.
\]

Covariance transport has the corresponding defect in each tensor slot. A changing discrete channel obeys (qC)'=q'C+qC'. Neither discarded-state dependence nor the moving-channel term can be dropped. Conditional attention remains undefined at zero receiver occupancy. These are explicit domains and structural qualifications of the final theorem, rather than omitted universal conclusions.

## 4. Regular and reduced inference

Write Gaussian natural coordinates as J=Sigma^{-1} and h=J mu. For a connection A and nonnegative inference rate gamma, the proposed covariant natural flow is

\[
J'=A^T J+JA+\gamma(J_p-J),\qquad
h'=A^T h+\gamma(h_p-h).
\]

Let Phi'=-A Phi and transform bar J=Phi^T J Phi and bar h=Phi^T h. The connection terms cancel, giving bar xi'=gamma(bar xi_p-bar xi) for both natural coordinates. The integrating-factor formula has nonnegative weights summing to one. It proves uniqueness and SPD preservation. On a compact interval the lower precision bound is the minimum of the initial and transported-target bounds; a target bound alone does not bound an arbitrarily smaller initial precision. The amendment supplies this qualification. Positive categorical log odds obey the same linear equation.

For a minimal positive exponential family q_theta proportional to h_0 exp(theta dot T), its Fisher metric is Cov_theta(T), positive definite by minimality, and the reverse-KL differential to an in-family target is G(theta-eta). Natural gradient therefore gives theta'=gamma(eta-theta). Finite positive steps remain in the family. The requirement that the target log density belong to the same affine span is load-bearing.

For the four-variable, four-state chain, there are 4 times 3 unary contrasts and 3 times 9 adjacent-pair contrasts, totaling 39. Evaluating a linear dependence at the reference configuration, at a single changed node, and at two changed adjacent nodes proves independence. The existing chain prior and recognition factor as three pair factors over two separator factors, and the likelihood lies on the first edge. Their logs therefore occupy the same 39-coordinate affine span. This is full microscopic-family closure; it does not make arbitrary visible parent marginals autonomous.

For a fixed partition g and fixed within-block conditional rho, write Q_r(x)=r_{g(x)}rho(x|g(x)). Pulling back the Fisher metric gives the simplex metric in r. Let ell_b=E_{rho_b} log(p/rho_b), let pi_b be proportional to exp ell_b, and let Z_r=sum_b exp ell_b. Direct substitution yields

\[
D(Q_r\Vert p)=D(r\Vert\pi)-\log Z_r.
\]

The reduced optimum and its residual differ from unrestricted posterior optimization. In the driven setting, log-ratio errors satisfy a linear forcing recurrence modulo an additive constant. Their oscillation is bounded by the corresponding weighted forcing oscillations. Normalizing a likelihood ratio whose log oscillation is at most H gives TV at most tanh(H/4), and every common channel contracts TV. The continuous bound follows from the same integrating factor. A moving partition or moving rho requires extra terms and is outside this fixed-conditional theorem.

For smooth target forcing with Lipschitz constant L, the exact arrival-target step has local natural-coordinate error at most gamma L times (delta s)^2/2. Stability of the linear flow and summation give O(h_max) on a compact interval. The common precision floor converts this to mean/covariance control. Uniform continuity gives a modulus-based convergence statement when a Lipschitz rate is unavailable. Reduced nonlinear evolution also needs a uniform or integrable state-Lipschitz bound; the evolution amendment supplies it. These hypotheses cannot be inferred merely from positive laws at individual points.


## 5. The actual one-sided hybrid interface

The hybrid source does not derive event behavior by extending a changing-rank regular chart through its singular point. The schedule first computes the exact rational roots of the piecewise-affine context path at the fixed domain boundaries -0.8, -0.1, 0.1 and 0.8. It declares left, exact and right carriers, including contacts and boundary intervals. There are finitely many events.

The Gaussian innovation construction extends to the larger-side boundary. Its lower-triangular innovation factors have diagonal entries at least 0.9, and the scalar inter-agent coupling is bounded below 0.324 in magnitude. The triangular chain map is invertible, so the limiting joint covariance is SPD. Domain availability enters disappearing observation columns through a smooth flat bump; it does not multiply the Gaussian covariance toward singularity. Thus the one-sided prior and posterior covariance limits are legitimate Gaussian laws.

At a disappearance, the vanishing observation column is zero at the larger-side limit. If S are survivors and N are entering or departing variables, this gives

\[
p_{S,N}(z_S,z_N|o)
=p_S(z_S|o)\pi(z_N|z_S)
\]

at that limit. Integrating the normalized conditional proves evidence continuity. The birth rule therefore attaches the prior conditional, which here equals the limiting posterior conditional; that equality is a proved feature of this observation construction, not a rule valid for arbitrary births.

The zero-clock event map first marginalizes departures and then attaches the declared conditional. For an affine Gaussian conditional with mean d+Mz and innovation covariance Q, the new mean and covariance follow the affine formula. The full augmented covariance is SPD by a triangular congruence of diag(Sigma_survivor,Q). Departure removes the corresponding conditional KL; conditional entry with the posterior conditional adds zero KL. No inference time is charged to this event map. The declared exact-phase contact order remains part of the construction.

Parent rows have one-sided limits even when the corresponding raw occupancy vanishes. A supported singleton parent has selector one and derivative zero. Disjoint supported parent rows give full row rank and hence SPD supported parent covariance. This analytic side extension is distinct from defining attention on an exact zero-occupancy receiver; the latter remains outside its conditional domain.

Within each constant-carrier interval, the executable interface transports the Gaussian and then applies the arrival-target natural step. It retains the full positive chain event law. At each event it uses the marginal/prior-conditional rule above. The mathematical comparison is made at matching exact phases and matching carriers, using reference-frame mean distance, covariance Frobenius distance, and full latent event TV. Each finite jump map is Lipschitz on the compact SPD domain. Composing the regular O(h_max) bounds with finitely many such maps gives the claimed global resolved-history bound in real arithmetic, with the specified interpolation. Comparing at raw times while delaying a jump is a different topology and does not inherit this result.

I read the source of hybrid_schedule.py, hybrid_side.py, hybrid_evolution.py and hybrid_evolution_config.py. Those files implement the stated schedule, larger-side construction, singleton-parent rule, transport-then-arrival update, zero-clock map, and primary comparison. This is static correspondence at the named interface. It is not a rerun of the recorded hybrid experiment or a review of every executable claim. The current runner admits its finite representable inputs and refinements 1 and 2. Floating-point underflow of a flat bump as distance to the boundary tends to zero precludes an unrestricted fixed-format limit; it does not refute the real-arithmetic one-sided theorem.

The same fixture supplies a reason not to replace the retained state by its old parent mean. If old weights are a and b, a hidden mean displacement proportional to (b u,-a u) is invisible to that parent. The newborn conditional mean can nevertheless change by a nonzero multiple of -a rho L_2 L_1^{-1}u. The retained microscopic state is therefore needed by the stated boundary policy. No autonomous old-parent dynamics is inferred.

## 6. Nonidentity base descent and quotient connections

For the declared redundant product base f(c,z)=c, let H(z)=exp(gamma z J_0), q_s=H_#q_t, and

\[
A_s=Hf^*A_tH^{-1}-dH H^{-1},\qquad \Psi=H^{-1}.
\]

Substitution gives dPsi+f^*A_t Psi-Psi A_s=0. Pushing laws through Psi removes the redundant frame and recovers q_t. Conjugating every observation, reference, evaluator and coarse map by the same comparison proves the statistical squares and preserves evidence. Product frame comparisons compose, so the explicit 4-to-3-to-2 base tower is nonidentity descent with complete data.

The general criterion is constancy of the compared object on each entire f-fiber. Local sections of a surjective submersion then make the descended object smooth. The product example has a global section. A varying gauge-invariant Gaussian mean norm prevents law descent; a nonzero contraction of curvature with a vertical direction prevents connection descent. These are separate necessary obstructions. The construction removes a redundant presentation coordinate and does not prove averaging of informative contexts or nondegeneracy of a pulled-back base metric.

A different construction starts with a smooth fixed-rank fiber surjection F and source metric h. Set

\[
R=h^{-1}F^T(Fh^{-1}F^T)^{-1},\quad
g=(Fh^{-1}F^T)^{-1},\quad
\Pi=RF,\quad
B=F(d+A)R.
\]

Then FR=I and R^T h R=g. Differentiating this identity and inserting B gives

\[
dg-B^Tg-gB=R^T(dh-A^Th-hA)R.
\]

Applying the induced derivative twice and resolving the identity into Pi and I-Pi gives

\[
K_B=F K_A R+F(D_A\Pi\wedge D_A\Pi)R.
\]

The second term is a projection contribution. It does not require F to be parallel and does not imply that it is parallel. When the intermediate metric is the induced one, the minimum-norm lift for a composite equals the product of the two lifts; substitution then proves composition of the induced connections. Resetting the intermediate metric changes the optimization defining the lift and need not compose.

For scalar block weights with a common orthogonal connection, the displayed formula reduces to the common connection plus an exact scalar derivative, -one-half d log(sum_i lambda_i^2) times identity. That scalar term contributes no additional curvature. The possible first-order coarse defect remains. Thus quotient curvature is a well-defined optional geometric output, not an automatic closure theorem for parent evolution or a new scalar VFE penalty.

## 7. The existential interacting fixed normalized action

This witness uses two distinct operations. First, on each particular finite hierarchical graph, summing internal spins is a deterministic common-channel contraction. The finite theorem from Section 2 gives its exact pushed measure, action and conditional corrections. Second, homogeneous replacement takes four copies of one edge interaction to define the next diamond cell. This is a nonlinear map on the family of root actions. It is not one fixed linear stochastic operator on an unchanged fine catalog.

Write an edge's unnormalized two-root weight as W(sigma,tau)=A(1+t sigma tau). Two edges in series give 2 A^2(1+t^2 sigma tau). Multiplying two parallel branches yields

\[
W'(\sigma,\tau)
=4A^4(1+t^4)(1+f(t)\sigma\tau),\qquad
f(t)=\frac{2t^2}{1+t^4}.
\]

Induction proves this contraction at every finite hierarchy depth. The amplitude recurrence A'=4A^4(1+t^4) is retained; neither the partition nor the whole growing-graph law is asserted to be fixed.

After identifying the ordered two-root comparison carrier, the normalized law is P_t(sigma,tau)=(1+t sigma tau)/4. The cubic c(t)=t^3+t^2+t-1 is strictly increasing on (0,1), negative at 1/2 and positive at 3/5. Its unique root t_* in that interval satisfies f(t_*)=t_*. The root law has fair marginals and correlation t_* nonzero, so it is nonproduct. Differentiation and the cubic relation give

\[
f'(t_*)=\frac{2(1-t_*)}{t_*}\in(4/3,2).
\]

It is therefore an interacting fixed normalized root action, repelling in the declared homogeneous coupling direction. Equality is equality of the complete normalized two-root law on the comparison carrier, not merely equality of one observable.

The exact code realizes rational arithmetic and the real cubic field defined by c. Irreducibility follows from the rational-root test: a monic cubic with integer constant -1 could have a rational root only at plus or minus one, and neither is a root. Consequently a nonzero reduced polynomial of degree at most two cannot vanish at t_*. Rational isolation determines its sign after finitely many refinements. This supports an executable exact witness without rounding t_* to a rational. The generic finite hierarchy bridge instead uses rational weights; it is a separate common-channel realization, not a cast of the algebraic fixed point into Fraction arithmetic. A singleton observation alphabet embeds the fixed-root model in the normalized ELBO setting.

Gauge compatibility is graph-level. A flat Z2 edge assignment transforms with vertex signs; internal sums cancel internal relabelings, and the root law transforms with its induced root comparison. Compatible transformed flat data therefore represent the same fixed normalized action. Arbitrarily relabeling just one root while holding all edge data and the positive-t chart fixed is not the same gauge arrow. Opposite branch flux gives the distinct constant boundary weight 4A^4(1-t^4), so this proof does not extend to arbitrary background flux.

These facts exactly meet the frozen existential requirement of an executable interacting fixed-point realization. They do not establish whole-law equality on successively larger catalogs, a single fixed common-channel eigenmeasure, an infinite-volume measure, a fixed amplitude, universal exponents, a nonflat gauge-matter fixed point, or physical time. None of those stronger statements is used to discharge the target.


## 8. What curvature constructions establish

Let the declared finite lattice have compact link variables and normalized product Haar measure m. For a bounded nonnegative plaquette action S, bounded above by 2 sum_p kappa_p, the normalizer Z_g=integral exp(-S) dm is finite and strictly positive. Thus pi_g=exp(-S)m/Z_g is a probability. Combining it with a normalized conditional matter model gives a normalized joint. For recognition R(dTheta)Q_Theta(dy), direct expansion gives

\[
F=E_R F_{\mathrm{matter}}(Q_\Theta)
+D(R\Vert m)+E_R S+\log Z_g.
\]

A field held fixed outside the probabilistic model does not acquire a recognition penalty from adding a field-only constant; that constant cancels on normalization. A Dirac recognition against continuous Haar is singular and has infinite KL. These distinctions prevent a gauge action from being inserted twice or invented from covariance alone.

Elementary plaquette interactions do not generally close under elimination. In the two-square spin construction, summing matter keeps the even subgraphs and yields a factor

\[
1+t^4(H_1+H_2)+t^6H_1H_2.
\]

The cross-ratio defining the mixed logarithmic coefficient has numerator minus denominator equal to 4(t^6-t^8), strictly positive for 0<t<1. A mixed plaquette interaction is therefore generated. Exact finite elimination remains valid; a truncation to separate elementary plaquettes requires an error account.

For a smooth unitary connection, the small-loop expansion gives log U=-a^2 F+O(a^3). Anti-Hermitian curvature has negative trace square, so the positive plaquette action tends to the corresponding negative-trace curvature contraction. With uniform derivative and remainder bounds on a compact region, the per-cell O(a^5) error, the action scaling a^{d-4}, and O(a^{-d}) cells give aggregate O(a). This is a deterministic classical approximation. It supplies neither a continuum random-field measure nor a renormalized probability limit.

Fisher curvature is a different object. The positive categorical simplex embeds by square roots as a sphere of radius two and has nonzero constant sectional curvature, while its VFE can be zero at the posterior with unit evidence. Hence curvature of the Fisher metric alone cannot select an additional VFE term. Natural-gradient conversion changes the metric representation of the derivative; it does not change the normalized generative log density.

A declared random-base prior can depend on scalar curvature. In the two-sphere example, areas and curvatures give prior component weights proportional to exp(-2 lambda) and 4 exp(-lambda/2). Their normalization and recognition KL define an exact finite model. An unnormalized auxiliary Gaussian factor with curvature-dependent precision integrates to a determinant factor and contributes one-half log determinant to its effective potential. An already normalized Gaussian conditional integrates to one and cancels that factor. The difference is the declared joint, not a choice of notation for the same probability.

The heat-diagonal construction imports a specific analytic theorem: on a compact smooth Riemannian manifold without boundary, the scalar heat diagonal has a uniform small-time expansion

\[
k_t(x,x)=(4\pi t)^{-d/2}(1+tR(x)/6+O(t^2)).
\]

Normalized against volume probability nu, it follows by dividing the expansion by its integral and then expanding the logarithm that

\[
D(Q\Vert\pi_t)
=D(Q\Vert\nu)-\frac t6(E_QR-E_\nu R)+O(t^2).
\]

Uniformity permits taking expectations without changing the order bound. For a finite expression, require Q absolutely continuous with finite D(Q||nu). On compactness the density ratio is bounded for sufficiently small t; singular Q gives infinite KL rather than a finite subtraction formula. The sign and normalization convention agree with Avramidi's scalar operator F=-Delta+Q and first integrated heat coefficient B_1=integral(Q-R/6), together with the (-t)^k/k! expansion. I inspected the corresponding primary-source statement in [Avramidi, Covariant techniques for computation of the heat kernel](https://arxiv.org/pdf/hep-th/9704166), equations 11, 49-54 and 105. This remains a conditional compact-manifold theorem, not an implemented prior on the present open context base.

None of these constructions selects universal coupling constants, identifies gauge and Fisher curvature, produces Einstein equations, establishes a quantum interpretation, or alters the existential scope of the diamond witness.

## 9. Optional retained-label holonomy model

Take a positive finite reference m_k, finite declared field actions S_k, and pi_k=m_k exp(-S_k)/Z_f. Let p_0(z,e,o_0) be the already normalized original Gaussian/event model, used once. For a closed probe loop within its domain define H_k=(U_k-I)P and a normalized Gaussian observation N(r;H_k z,R), with R SPD. Then

\[
p(k,z,e,o_0,r)=\pi_k p_0(z,e,o_0)N(r;H_kz,R)
\]

is normalized by successive integration. This establishes a declared stochastic role for the curvature label.

After the original observation, let its Gaussian posterior be N(mu_0,Sigma_0), with evidence Z_0. The component loop evidence is

\[
\ell_k=N(r;H_k\mu_0,R+H_k\Sigma_0H_k^T),\qquad
Z=Z_0\sum_k\pi_k\ell_k,\qquad
\omega_k=\frac{\pi_k\ell_k}{\sum_j\pi_j\ell_j}.
\]

Completing the Gaussian square produces the component mean and covariance. Multiplying the original likelihood and loop likelihood before completing the square gives the same precision, precision-mean, and scalar normalizer. Sequential and stacked conditioning therefore agree without using a numerical case as a proof.

Under passive orthogonal fine and probe chart changes, H, mu_0, Sigma_0, r and R must all transform coherently. Gaussian quadratic forms and determinants then prove invariance of ell_k, total evidence, and field weights. Transforming the latent chart while freezing sensor components would compare different observations and would not establish covariance.

For recognition a_k Q_k(z)q_E(e), the posterior factorization gives

\[
F=D(a\Vert\omega)+\sum_k a_kD(Q_k\Vert p_k)
+D(q_E\Vert p_E)-\log Z.
\]

Expanding the normalized joint gives the equivalent generative expression, including

\[
D(a\Vert\pi)=D(a\Vert m)+E_aS+\log Z_f.
\]

Retaining k and using a common Gaussian/event channel in each component gives a joint common-channel construction. The finite-label chain rule together with Gaussian disintegration proves staged equality and telescoping hidden conditional KL. Marginalizing k instead yields Gaussian mixtures and requires another closure analysis; a single Gaussian approximation is not silently substituted.

For the stated commuting constant-SO2 family, zero signed enclosed area or zero curvature gives U=I. If every component has the same observation model, all ell_k coincide and omega=pi. Repeated identical components preserve their prior weight ratio even if other distinct components change the overall posterior. These are exact nonidentifiability controls, not a universal identifiability theorem.

The optional model does not establish a new parallel geometric-arrow square. Its context object retains legacy geometry defaults, while the statistical laws, frames and maps used here are independent of those default curvature parameters. The actual U_k and H_k use the stored label k. The common-channel accounting asserts a retained-label statistical and VFE identity; it does not identify a single context.family['A'] with every latent component's connection. I inspected the final author proof of this extension, not the optional implementation module or its runtime result. Source hash information supplied for that module is not a substitute for such an inspection.

## 10. Counterexample attacks and removal of affirmative priors

An original attack separates induced quotient geometry from autonomous evolution. On an interval with coordinate s, take a flat source R^2, h=I, A=0, and F(s)=(cos s,sin s). Then R=F^T, g=1 and B=F dF^T=0. The quotient connection and curvature vanish, but dF=(-sin s,cos s) ds is nonzero. At s=0 the fine Gaussian laws N((0,0),I) and N((0,a),I) have the identical projected law N(0,1). Keeping each fine law constant gives projected mean derivatives zero and a. Therefore even an induced flat metric connection does not determine projected evolution from the current parent law. The final theorem retains the defect and microscopic state, so this is a counterexample to an unadopted strengthening, not to its target.

A second direct construction shows why emitted readouts cannot serve as the primary event metric. At context x=0, labels 0 and 3 of the chosen variable have the same unavailable readout. Let their four-state probabilities be p=(0.3,0.2,0.2,0.3) and q=(0.4,0.2,0.2,0.2), with the remaining event coordinates identically distributed and independent. These are positive chain-family laws. Their full latent TV is 0.1, but their emitted laws coincide because the changed masses occupy identical channel rows. This algebraic example needs no simulation. The final hybrid metric includes latent TV and hence does not suffer this identification.

Other attempted strengthenings fail for explicit reasons already derived here: a cyclic list of local marginals need not normalize jointly; a support-deficient posterior can produce infinite KL; a finite reference normalization changes action constants; a moving observation identifies different slices; a fixed forward channel restricts feasible lifts; an initial precision below its target defeats a target-only floor; discontinuous event timing defeats a raw-time uniform comparison; vertical law or curvature dependence obstructs base descent; and nonflat branch flux need not share the diamond recursion.

After removing the affirmative search-prior label, every positive implication still has an explicit premise and calculation. Existence of the fixed point follows from a cubic sign change and monotonicity, not from a presumed interacting phase. SPD side limits follow from invertible innovations, not an assumed nonsingular limit. The base example is deliberately redundant, and the proof says so instead of asserting arbitrary context reduction. Curvature terms arise from separately normalized generative factors with their constants retained. No negative example is used to discharge the independent existential clause. I found no unjustified affirmative prior functioning as a load-bearing mathematical premise.


## 11. Coverage against the current claim graph

The read-only graph traversal found 58 reachable claims from target: 52 mathematical claims including target and six numerical-observation claims. There were no unvisited IDs in the current ledger. This is a coverage inventory, not invocation of the formal validator or adjudicator. The ledger's empty assumption-ID arrays do not erase hypotheses carried by its quantifiers and final proofs. The table maps every non-target mathematical claim to its reconstructed argument. “Reconstructed” means a written derivation with the stated scope, not a formal ledger state or an executable test outcome.

| Claim ID | Reconstruction and scope |
| --- | --- |
| finite-tower | Section 2: common-channel finite sums, reference disintegration, KL chain rule and additive tower. |
| finite-support-extension | Section 2: domination, zero-density and zero-reference cells, explicit null-fiber extensions, extended nonnegative addition. |
| mixture-metric | Section 4: Fisher pullback for fixed conditional blocks. |
| mixture-flow | Section 4: exact reverse-KL block objective and its normalized exponential target. |
| mixture-driven-bound | Section 4: linear log-ratio forcing, oscillation bound, normalized TV bound and channel contraction. |
| diamond-recursion | Section 7: serial sum, parallel product and induction over finite depth, retaining amplitude. |
| diamond-fixed | Section 7: unique cubic root, nonproduct normalized two-root law and derivative interval; nonlinear replacement map. |
| diamond-gauge | Section 7: compatible graph-level flat link transformation and opposite-flux constant action. |
| stochastic-gap | Section 2: explicit positive constrained-lift gap. |
| event-log-closure | Section 4: fixed affine log span and minimal exponential-family Fisher formula. |
| event-current-chain | Section 4: independent 39-coordinate chain span and the actual factor/likelihood membership. |
| event-fisher | Section 4: covariance Fisher metric and exact linear natural flow to an in-family target. |
| event-driven | Section 4: varying in-family target gives linear forcing; it is a distinct driven problem. |
| regular-evolution | Section 4: parallel natural coordinates, integrating factor, uniqueness and initial/target SPD floor. |
| regular-discretization | Section 4: arrival-target local defect and compact stable accumulation with regularity hypotheses. |
| hybrid-kernel | Section 5: survivor marginal plus normalized affine prior-conditional entry; augmented SPD covariance. |
| boundary-factorization | Section 5: vanishing observation columns imply limiting posterior/prior conditional agreement and evidence continuity. |
| moving-derivatives | Section 3: both connection/coarse-map defect terms and moving-channel derivative. |
| projectability | Sections 3 and 10: projectability requires discarded-state independence; explicit rotating-projection obstruction. |
| base-section-descent | Section 6: fiberwise constancy after comparison and local-section smoothness. |
| base-connection-descent | Section 6: explicit parallel comparison and vertical-curvature obstruction. |
| base-tower | Section 6: coherent product-frame 4-to-3-to-2 composition for all declared maps. |
| base-law-obstruction | Section 6: varying invariant mean norm on an f-fiber prevents law descent. |
| base-curvature-obstruction | Section 6: nonzero vertical curvature contraction prevents connection descent. |
| gauge-prior | Section 8: bounded finite-lattice compact action and positive normalized Haar prior. |
| gauge-latent-elbo | Section 8: normalized joint expansion with field KL, expected action and log partition. |
| plaquette-nonclosure | Section 8: even-subgraph factor and strictly positive mixed logarithmic coefficient. |
| small-loop-classical | Section 8: local unitary holonomy expansion and uniformly controlled classical sum; no measure limit. |
| fisher-no-selected-penalty | Section 8: curved Fisher sphere at zero posterior VFE rules out curvature-selected penalty. |
| base-curvature-prior | Section 8: explicit two-sphere normalized weights and their exact KL. |
| gaussian-curvature-marginal | Section 8: unnormalized Gaussian integration generates the determinant potential. |
| normalized-conditional-cancellation | Section 8: integration of a normalized conditional gives one and cancels the determinant. |
| heat-prior-expansion | Section 8: mapped compact heat theorem, uniform normalization/log expansion and finite-KL qualification. |
| hybrid-exact-schedule | Section 5: finite rational roots and declared one-sided/exact contact carriers. |
| hybrid-side-gaussians | Section 5: uniformly invertible innovation map and larger-side SPD limits. |
| hybrid-parent-limits | Section 5: singleton selector limits, supported row rank, and exact zero-occupancy distinction. |
| hybrid-zero-clock | Section 5: ordered marginal/conditional jump with no inference-time increment and conditional KL accounting. |
| hybrid-resolved-consistency | Section 5: compact regular consistency plus finitely many Lipschitz jumps at matched phases. |
| hybrid-parent-nonautonomy | Section 5: invisible old-parent displacement changes newborn conditional; fine state is retained. |
| hybrid-arithmetic-boundary | Section 5: flat-bump underflow limits a fixed-format realization, not the real-arithmetic theorem. |
| hybrid-primary-comparison | Sections 5 and 10: primary full-state metric and a positive latent/readout counterexample. |
| quotient-connection-metric | Section 6: metric lift, induced connection and differentiated nonmetricity identity. |
| quotient-projector-curvature | Section 6: curvature with explicit projection contribution; no inferred parallelism. |
| quotient-metric-composition | Section 6: propagated minimum-norm metrics compose lifts and connections; reset need not. |
| quotient-scalar-no-extra-curvature | Section 6: scalar-weight term is exact and adds no curvature. |
| holonomy-normalized-joint | Section 9: finite field prior times the original joint and one normalized loop observation. |
| holonomy-gaussian-bayes | Section 9: Gaussian square completion proves sequential/stacked evidence and posterior equality. |
| holonomy-chart-covariance | Section 9: coherent latent/probe/sensor transformations preserve Gaussian evidence and field weights. |
| holonomy-normalized-vfe | Section 9: posterior and generative decompositions with all prior constants. |
| holonomy-retained-coarse | Section 9: retained-label common-channel law and conditional KL tower; no geometric-arrow completion inferred. |
| holonomy-degenerate-controls | Section 9: commuting flat-loop and identical-component controls with their precise scope. |

The six remaining ancestors are scoped evidence records. I read their statements and evidence locators, not the result files, XML outcomes, failure logs, or implementation modules underlying each numerical claim. I did not rerun them. This report neither promotes nor refutes those records.

| Numerical-observation ID | Declared evidence locator and unperformed obligation |
| --- | --- |
| moving-reduction-numerics | evidence/moving-reduction-results.json; finite moving-reduction outcomes and source/runtime binding were not independently checked. |
| base-presentation-numerics | evidence/base-and-curvature-results.json; recorded base-presentation comparisons were not reproduced. |
| curvature-model-numerics | evidence/base-and-curvature-results.json; recorded curvature-model comparisons were not reproduced. |
| hybrid-evolution-numerics | evidence/hybrid-evolution-results.json; finite phase/readout outcomes were not reproduced, notwithstanding the static interface reconstruction in Section 5. |
| quotient-curvature-numerics | evidence/quotient-connection-results.json; recorded finite jet cases and executable derivative inputs were not independently checked. |
| holonomy-inference-numerics | evidence/holonomy-inference-results.json; the latest recorded comparisons/JUnit and preserved earlier native failure were not adjudicated or rerun. |

For target, Sections 2 and 3 prove its universally quantified admitted finite construction. Sections 4 through 6 prove the adopted regular, reduced and finite-event statements with their explicit hypotheses and obstructions. Section 7 supplies the exact executable existential fixed-action witness. Sections 8 and 9 establish the separate optional constructions without upgrading them to universal curvature selection or geometric closure. The static source reads substantiate only the exact witness/finite bridge and named hybrid interfaces. Consequently, this pass supplies the mathematical target implication and covers the entire graph by either reconstruction or an explicit unperformed evidence obligation; it does not independently establish the target's entire executable-evidence conjunct.

## 12. Disposition and outstanding obligations

No mathematical counterexample within the admitted frozen target was found. The support and reference amendments are necessary and sufficient for the finite identity as used here. The regular/hybrid implications use actual one-sided limits and a declared boundary rule. The fixed-point witness is existential fixedness of a normalized action under homogeneous replacement, with compatible finite graph contraction and graph-level gauge data. The optional holonomy extension is a normalized retained-label statistical model and does not complete additional geometric arrows.

The six numerical records still require their existing source/runtime-bound evidence to be accepted through the responsible evidence workflow; they were outside this bounded rerun-free task. I have not source-audited every implementation implicated by them. The formal ledger remains in its recorded candidate states. A compatible formal validation/adjudication mechanism is a separate outstanding procedural obligation. Neither this report nor agent agreement changes a ledger state, and a schema/session rejection alone supplies no scientific refutation.

Stronger extensions remain unadopted: arbitrary smooth quotient/disintegration without a regularity/support theorem; informative base averaging without fiberwise compatibility; autonomous reduced dynamics or a Gaussian approximation after discarding the field label; unrestricted fixed-format mesh limits; infinite-volume or continuum probability measures; generic nonflat interacting fixed points; universal exponents; and identification with physical time or an ontology. Each would need an explicit target, hypotheses, and proof. Their absence does not negate the scoped finite construction, but none is silently marked complete.

No tests, experiments, Torch/GPU calls, deliberate corruption or tamper checks, ledger changes, vault edits, or Git commands were performed. Only this assigned Markdown file was written. Read-only source hashing and claim-coverage inventory are provenance checks, not numerical scientific evidence.

## 13. Input provenance

The source snapshot used for the reconstruction was hashed at 2026-09-09T05:42:20.2658284Z. The table below records SHA-256 of the final inputs, relative to C:/tmp/elbo-cover-20260908. This is a file snapshot, not a Git revision claim. Proof sources were read as mathematical inputs; their existence or authorship was never treated as authority for truth. The optional holonomy implementation source hash reported by the root was a2dfb82af0b5ea7bec9f38f8c91438e5b3a33fdbea283d3e6eb74fce53458960; that source was not independently inspected in this pass and is deliberately absent from the inspected-input table.

| Inspected input | SHA-256 |
| --- | --- |
| AGENTS.md | 41d2c6c7927390515173f07200db5b09161ffe3a745571ad8c8a73584093045b |
| Theory/SPEC.md | dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1 |
| docs/derivations/2026-09-08-rg-program-completion/problem-contract.json | 50db7529fc2c5cb7c032cd4e3b6517516a93800ba32db8c2c50c226ddb2a369e |
| docs/derivations/2026-09-08-rg-program-completion/claim-ledger.json | f551d57bfb7e3bbe3e51297a3e6891ad2dfdedbc573568d45b7dadc51bd30f95 |
| docs/derivations/2026-09-08-rg-program-completion/dependency-dag.json | aaec1fa976e7049e39998a764b0eadeea5cbec3a3ef6a70e9b1d1291850df06b |
| docs/derivations/2026-09-08-rg-program-completion/construction-or-strongest-theorem.md | 5253c4f9906c55b8ef0544d022c76a05adb8091bad831f95682459ec7e96ab7a |
| docs/derivations/2026-09-08-rg-program-completion/agents/spec-completion-update.md | 27520641faeb40e1d6d3832d59c60d2264e42996fd6269ec2a7023ee49a4d196 |
| docs/derivations/2026-09-08-rg-program-completion/agents/finite-core.md | 3fc9f64f8eb4d815c418873a1b0a1151f95aa890ed10ad930ae08300cd864718 |
| docs/derivations/2026-09-08-rg-program-completion/agents/finite-support-amendment.md | 0b14956cc3b1086376b030ae3548cc010d8116564ef9f92ae979176beb0688b2 |
| docs/derivations/2026-09-08-rg-program-completion/agents/finite-core-interface-amendment.md | 852a746df81acf5d5314c80d5c65797984996fad6f3bd5a00e07afd1eb4ef5ef |
| docs/derivations/2026-09-08-rg-program-completion/agents/scale.md | 7ed8f0cfbbb7849cdd9f45ad1f5cb9c1e65d29279ac7b28c5458bdddf691ae8d |
| docs/derivations/2026-09-08-rg-program-completion/agents/evolution.md | 6a5693a48438bb63f30e146a1ca9add96aba884e63d7e730fc86957b3e5a4d03 |
| docs/derivations/2026-09-08-rg-program-completion/agents/evolution-amendment.md | 589eb22e3c5860062547031e791bbad7b11ad19bfe0c2a7436145c3110095eca |
| docs/derivations/2026-09-08-rg-program-completion/agents/hybrid-interface.md | 5bd5941a599321fed01c5c757c02e29262a366e23c2d6304dbae9c385955a2bd |
| docs/derivations/2026-09-08-rg-program-completion/agents/event-closure.md | ad68dc1f2f17fcfb58a627939d84cfce8e15824ed92bdd577c2a9a349cb5ee35 |
| docs/derivations/2026-09-08-rg-program-completion/agents/reduced-event.md | b6c1677a335b0f4071a917717d67b4a0972bf37b90dbedb5b5990552d9f42dcd |
| docs/derivations/2026-09-08-rg-program-completion/agents/base-descent.md | 0645ead493a897afd4397ede8a28f2299e5fa54109e305d1f9bcfd5da0d6b171 |
| docs/derivations/2026-09-08-rg-program-completion/agents/gauge-action.md | 267ca1217b1168b09bbb8fcffd4b6558d956fd96dc3560ded85c2610a9c9c39f |
| docs/derivations/2026-09-08-rg-program-completion/agents/statistical-base-curvature.md | 39beb9fc400533c34bef63c54c23f9bea85ea4c547542bbcd8103311c482667d |
| docs/derivations/2026-09-08-rg-program-completion/agents/projected-connection.md | dcac12ab952dc2a735e9b50cf7a01c8ee200562fb6a4a7f846686967d15e7951 |
| docs/derivations/2026-09-08-rg-program-completion/agents/holonomy-inference-implementation.md | 896f3c95c6db6e204e9218def4d20e827fe1e481ccb4dfb8d3d83ef0e41f0e81 |
| src/multiagent_elbo/rg_v2/hierarchical_ising.py | ef41955e5cb8697ef1a9c17b98d06149f5c67f5fa87600db84583b8205061ae5 |
| src/multiagent_elbo/rg_v2/finite_hierarchy_bridge.py | f64cc06df737a43e351afdb27a158c8ef0a6d975b5c0168564281c1b8e29bf5c |
| src/multiagent_elbo/experiments/neighborhood/hybrid_schedule.py | 2366413168607a28f922d7e37b7e05cf192edf557a93ba5f0fb718cdfb03a4b2 |
| src/multiagent_elbo/experiments/neighborhood/hybrid_side.py | b434911ee2a1b466b3f347e2dc5118eca0d30534db5d9647f2e71c62aa22ea0e |
| src/multiagent_elbo/experiments/neighborhood/hybrid_evolution.py | febb6f0bff8639ae65364bd8f756934c1848518951fb8115ce3dbc5f3e5fd01b |
| src/multiagent_elbo/experiments/neighborhood/hybrid_evolution_config.py | a63fdaeaf0a41c5650fa8cf02b0aaa3febb3ec0ebd82863f172697892ba8ebd8 |
