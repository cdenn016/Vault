<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Resolved hybrid evolution integration review

Revision 3 is frozen against the source hashes below after root corrected HEV1 and announced its new source freeze. This is a source and mathematical-semantics review, not a test certificate. The assignment covers only `hybrid_evolution.py`, `hybrid_evolution_config.py`, their calls into the frozen scheduler/side layer, and the H1-H6 contract. No tests, tensor execution, scientific experiments, code changes, or ledger changes were performed.

The actual arrival-side flow and zero-clock phase order match the resolved construction. The corrected comparison now measures the retained latent event law as well as emitted readouts, resolving HEV1. The zero-duration identity branch resolves HEV2. No unresolved integration defect remains within this bounded source review; sampled phase discrepancies remain distinct from a continuous interval-supremum bound or an asymptotic convergence certificate.

| Inspected source | SHA256 |
|:--|:--|
| `src/multiagent_elbo/experiments/neighborhood/hybrid_evolution.py` | `febb6f0bff8639ae65364bd8f756934c1848518951fb8115ce3dbc5f3e5fd01b` |
| `src/multiagent_elbo/experiments/neighborhood/hybrid_evolution_config.py` | `a63fdaeaf0a41c5650fa8cf02b0aaa3febb3ec0ebd82863f172697892ba8ebd8` |
| `src/multiagent_elbo/experiments/neighborhood/hybrid_side.py` | `b434911ee2a1b466b3f347e2dc5118eca0d30534db5d9647f2e71c62aa22ea0e` |

The governing primary materials are the actual repository source, `agents/hybrid-interface.md`, H1-H6, and the separate reconstruction in `agents/hybrid-interface-verification.md`, Sections 2-7. Previously reconstructed mathematical assumptions are reused here without reopening their proofs. This is a shared-model, shared-filesystem integration view, not independent numerical corroboration.

## HEV1: latent primary-state comparison added

**Family:** HEV1-latent-versus-emitted-history. **Kind:** COUNTEREXAMPLE and corrective implementation readback. **Target:** H6's typed primary history comparison. **Location:** `hybrid_evolution.py:147-175`, with primary terms at lines 159-162 and maxima at line 173. **Types:** latent event law is a positive `(4,4,4,4)` tensor; `d0_event` is the `(25,25)` available-edge readout. **Quantifier:** legal positive exact-chain preparations at a corresponding phase. **Assumptions:** the declared availability channel and identical Gaussian preparations.

The preceding source snapshot `2ffc5df67708fcb98dafb1ae46d9a3c70b8cec877945d3b912147cf07dadd916` stored the full latent state as `tI_fine_event`, but its comparison read only `tI_dD_event` at every depth. Even depth zero therefore applied the availability channel before measuring total variation. Its `d0_sum_norm` was a distance between visible readouts rather than H6's primary state norm. That distinction remains relevant for interpreting the preserved emitted metrics.

A concrete kernel witness is available at `c=(-1.1,.2)`: agents 2 and 3 have zero availability, so rows 2 and 3 of `cover.endpoint_channel` both equal the null outcome. Let all four latent endpoint variables be independent. Give three of them the uniform distribution and the remaining one either

\[
v_+=(1/4,1/4,1/4+\epsilon,1/4-\epsilon),\qquad
v_-=(1/4,1/4,1/4-\epsilon,1/4+\epsilon),
\quad 0<\epsilon<1/4.
\]

These are strictly positive members of the implemented 39-coordinate family, with only unary potentials needed. Their full latent total variation is `2 epsilon`. The endpoint channel sends their difference entirely to zero, so the complete emitted laws, and every subsequent parent readout, coincide. Equal Gaussian moments then give all emitted `dD_sum_norm` values zero despite a nonzero primary distance. This is an analytic counterexample to interpreting those outputs as a metric on the retained state; it is not a claim that the configured run numerically realizes this precise pair.

The corrected source reads `fine_event` for `latent_event_tv` and the reference fine moments for `fine_mean_l2` and `fine_covariance_frobenius`. It adds those three terms as `primary_sum_norm`, includes each numeric term in the comparison maxima, and retains the existing emitted metrics separately. These are exactly the components of H6's primary distance at the common stored phases. The new scope explicitly says sampled and excludes an interval supremum or fitted convergence rate. The distinction between this finite sample maximum and the continuous history norm is therefore preserved.

The added test source at `tests/rg_v2/test_neighborhood_hybrid_evolution.py:138` constructs the above positive product laws with epsilon=.1, independently of the source recognition model, and admits them with `chain.encode`. It compares their saved readouts with the same Gaussian. Its assertions require latent TV and the primary sum to equal .2, every emitted sum to vanish within tolerance, and the primary maximum to retain .2. This directly exercises the named observation-kernel counterexample; it does not modify an artifact or constitute a tamper scenario. The inspected test-file SHA256 is `10d5b4f52dad0f4996c5229f81dc0968962ea46724b2187fa5c3395635b42b33`. Test execution is separately reported by root below.

**Failure condition:** deleting the new latent term or relabeling an emitted metric as the primary distance would reopen the obligation. **Open gap:** none for the sampled comparison in the assigned source; a continuous interval supremum and asymptotic numerical certificate remain outside its declared scope. **Novelty fingerprint:** latent-family state retention is distinguished from its lossy availability readout at depth zero. **Proposed disposition:** HEV1 resolved in the frozen source; no ledger state is assigned.

## HEV2: zero-duration numerical identity resolved

**Family:** HEV2-zero-duration-identity. **Kind:** implementation readback. **Target:** the initial exact law and inference-rate-zero transport control. **Location:** `hybrid_evolution.py:92-94`. **Types:** a supported SPD Gaussian and a nonnegative scalar inference increment. **Quantifier:** the initial point of every path and every cell when the declared rate is zero.

The interim snapshot unconditionally called `gaussian_inference.full_step`, whose inverse-covariance and inverse-coordinate operations introduce an unnecessary finite-precision round trip at zero duration. The frozen source now calls the Gaussian and natural-coordinate flow primitives only under `if dtau:`. When duration is zero it retains q and theta exactly. Re-decoding the unchanged theta does not reset its persistent state. This resolves the state-identity obligation without altering a frozen solver.

The dense categorical comparator still evaluates its own zero-duration softmax round trip. This can contribute roundoff to the oracle residual, but it is diagnostic only and cannot alter q, theta, or the persisted event law. No claim about its numerical residual size is made here. Actual support transitions continue to use only `side.apply_event`, without a Fisher step.

**Failure condition:** removal of the explicit zero-duration branch would reopen the obligation. **Open gap:** none for this source readback; mechanical controls remain root-owned. **Novelty fingerprint:** preserving state exactly at zero inference clock is distinct from the real-arithmetic identity of the Fisher formula. **Proposed disposition:** HEV2 resolved in the frozen source; no ledger state is assigned.

## HEV3: phase ordering and state persistence

**Family:** HEV3-resolved-flow-then-event. **Kind:** CONSTRUCTION readback. **Target:** H1, H2, H5, and the resolved H6 convention. **Types:** one full supported Gaussian on each ordered phase carrier, one persistent 39-coordinate event state, and exact rational schedule nodes. **Assumptions:** admitted side models, finite representable inputs, and the frozen side API.

At an ordinary point the arrival target is the exact model. At an interior event it is the incoming left model because the first existing phase is selected before transport or inference. `previous_model` and q leave each preceding node in its final phase, so the segment starts on the outgoing carrier and arrives on the incoming carrier. The explicit equality check between those agent tuples rejects an unresolved rank change inside that interval. The connection transport uses the same ordered labels at both endpoints. The update consumes `rate * float(s_next-s_previous)` once, before the event. Subsequent phase records have zero increment, and `side.apply_event` performs the ordered marginalization/conditional attachment without a Fisher step. Thus using the arrival-side target before the zero-clock event implements the reconstructed resolved convention.

The Gaussian is initialized from the source q only at the first node. Later source q values are constructed as model data but do not replace the evolving Gaussian. The natural event state is likewise initialized only once, then updated by `chain.step(theta, source.posterior, dtau)`. The target compiler uses the actual local source factors and the same declared likelihood, and the runner independently compares its decoded posterior and event evidence to the side model. At a geometric event the event law is unchanged by the side API; the runner's use of the outer decoded event in phase records is therefore consistent with that API. Theta persists into the next segment without encoding or projection.

For an initial boundary point the first existing phase is exact, its increment is zero, and the outgoing phase is then constructed. A terminal boundary point first receives the incoming flow and retains left and exact records without an outgoing interval. An active-side contact receives its incoming larger-carrier flow, marginalizes at exact, then attaches the prior conditional on the outgoing side. A boundary-aligned interval uses the exact smaller carrier for its positive-duration interior; the scheduler's ordinary internal waypoints create no artificial support transition. Its entry and exit endpoints retain the appropriate phase records. These cases follow from the exact scheduler ordering and the existing side call contract; no new execution evidence is claimed.

The within-point KL check compares arrival and after-flow laws against the same arrival-side target, which is the correct local descent comparison. It does not assert descent between different contexts. Boundary diagnostics compare the separately reconstructed zero-clock identities. The metadata explicitly excludes global moving-context VFE descent and parent autonomy.

**Failure condition:** a changed phase order, a reset from local source q after initialization, a target from the post-event carrier before the incoming flow, or a side API that changes the event law would invalidate this readback. **Open gap:** mechanical runtime tests are root-owned. **Novelty fingerprint:** one positive inference increment is assigned to each constant-carrier interval, and support changes are separate records at the same exact parameter. **Proposed disposition:** no phase-ordering or persistence defect found in this snapshot.

## HEV4: exact refinement and numerical materialization

**Family:** HEV4-exact-decimal-refinement. **Kind:** CONSTRUCTION readback. **Target:** H1's rational partition and H6's corresponding-phase comparison. **Types:** finite decimal inputs, Fraction-valued affine waypoints/parameters, and a separately admitted float64 materialization.

`refined_schedule` bisects the original declared decimal segments before resolving roots. Such vertices and times remain terminating decimals. For a reduced denominator `2^a 5^b`, `_decimal` uses `p=max(a,b)` and integer numerator multiplier `2^(p-a)5^(p-b)`, so its decimal string represents the rational exactly. It never converts a potentially nonterminating boundary-root time back into a decimal waypoint; root resolution happens afterward in Fraction arithmetic. Contacts, original vertices, and boundary interval endpoints are retained. A root that becomes a midpoint at refinement two has the same exact context, time, and event phases.

The comparison key contains the exact rational time and phase label rather than rounded display coordinates. Materialized times are required to remain finite and strictly ordered. Context materialization is checked by the side constructor against the exact-point carrier, and existing window admission rejects lost positive interior occupancy. The inference increment uses the exact rational difference before float conversion, avoiding cancellation from subtracting large rounded timestamps. Clock origin is the initial exact path parameter, so allowing a nonzero parameter origin is consistent.

These checks do not turn the tensor trajectory into exact rational science or admit unrestricted refinement toward an underflow boundary. The profile restricts numerical refinements to one and two, and the metadata states the positive-representable-window limitation. The stored schedule's waypoint and incident-segment indexes refer to the refined input passed to `resolve_events`; the original unrefined configuration must remain in the manifest if those indexes are to be related back to the user's original path.

**Failure condition:** nonterminating coordinates are passed through `_decimal`, exact root times are replaced by rounded lookup keys, or a floating carrier mismatch is silently admitted. None occurs in the inspected path. **Open gap:** source-bound artifact serialization and runtime checks are root-owned and not reviewed here. **Novelty fingerprint:** exact event geometry and finite tensor realization are distinct layers with an explicit admission boundary. **Proposed disposition:** no decimal-refinement defect found in this snapshot.

## Final cross-lane readback

The newly announced evolution-source hash and unchanged config hash were independently read back and match the files. HEV1 and HEV2 are resolved at this revision. The bounded changed-source review confirms the latent term, Gaussian reference-moment terms, primary sum, maxima, and sampled-only scope. The prior conclusions about arrival-side flow, zero-clock transitions, actual source targets, state persistence, typed boundary cases, and exact decimal refinement remain applicable. No further source change or test rerun is requested by this review.

Root separately reported 14 collected runner/native/config cases passing on the preceding source, with JUnit `evolution-20260909T044825785201Z.xml` and SHA256 `f9145b1b80865e1f8b7ca8ad2f154a3e099791fec1e034363dcf25249b3d4c5d`. After the comparison correction, root reported three affected scientific/comparison/native cases passing, with JUnit `comparison-20260909T045126071385Z.xml` and SHA256 `c2d83b26ba13c7607d082c4690f34bcc3688bea9a2d44a427d0933dbd0c49eee`. These are revision-specific parent-reported results, not a combined passing suite: this lane did not inspect either JUnit or execute the cases. The new test's source was read only for the bounded counterexample-to-assertion mapping. Source-bound artifact validation and the complete program's remaining obligations are root-owned and are not closed by this report.
