<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Fixed-rank quotient geometry implementation handoff

Revision 1, frozen September 9, 2026. This implementation follows the root assignment and the frozen projected-connection.md derivation, SHA-256 dcac12ab952dc2a735e9b50cf7a01c8ee200562fb6a4a7f846686967d15e7951. The same agent authored that derivation and this implementation; these are not independent scientific verification. Other agents share the worktree. Only the new utility, its new focused test file, and this handoff were edited. Existing geometry exports, prescribed connections, configs, routes, profiles, laws, proof files, other tests, and WIP were preserved.

## Frozen API and scope

The direct import is from multiagent_elbo.geometry.quotient_connection import quotient_geometry. No package export or existing caller was added. The exact signature is:

    quotient_geometry(
        F: torch.Tensor,
        dF: torch.Tensor,
        A: torch.Tensor,
        K: torch.Tensor,
        h: torch.Tensor,
        dh: torch.Tensor,
        atol: float = 1e-10,
    ) -> dict[str, torch.Tensor | bool]

The inputs describe one supported point of one constant-rank stratum. All six tensors must be finite torch.float64 values on one device. Their shapes are F:(m,n), dF:(d,m,n), A:(d,n,n), K:(d,d,n,n), h:(n,n), and dh:(d,n,n), with d>0 and 0<m<=n. Derivative axes come first. K[a,b] is the coefficient partial_a A_b-partial_b A_a+[A_a,A_b], with no factor of one half. h and dh are required symmetric within absolute atol, and K antisymmetric in its base axes within that tolerance. Cholesky admission requires positive h and positive F h^{-1} F^T. All inverses used in the formulas are evaluated by solves, without rank cutoffs, clamps, regularizers, metric symmetrization, or dtype conversion.

K is supplied data. Its antisymmetry is checked, but its equality to the curvature of a source field cannot be checked from the value of A alone at one point: dA is not in the API. Likewise, input dF and dh must be the derivatives of the declared smooth fields. The scientific tests construct these jets from explicit fields. Floating positive-definiteness admission is not an exact arithmetic rank certificate, and no conditioning guarantee is claimed.

The output dictionary has exactly the following fields. Tensor fields use the input float64 dtype and device; their graph is retained when the supplied tensors carry autograd dependence.

| Key | Type/shape | Meaning |
| --- | --- | --- |
| g | tensor (m,m) | Quotient metric (F h^{-1} F^T)^{-1} |
| R | tensor (n,m) | Metric right inverse h^{-1} F^T g |
| Pi | tensor (n,n) | h-orthogonal retained projector RF |
| dg | tensor (d,m,m) | Ordinary derivative of g |
| dR | tensor (d,n,m) | Ordinary derivative of R |
| D_Pi | tensor (d,n,n) | dPi+[A,Pi] |
| B | tensor (d,m,m) | Projected connection (FA-dF)R |
| D_F | tensor (d,m,n) | dF+BF-FA |
| S | tensor (d,n,m) | (I-Pi)(dR+AR) |
| K_B | tensor (d,d,m,m) | F K R+F[D_Pi[a],D_Pi[b]]R |
| source_nonmetricity | tensor (d,n,n) | dh-A^T h-hA |
| target_nonmetricity | tensor (d,m,m) | dg-B^T g-gB |
| nonmetricity_projection_residual | tensor (d,m,m) | target_nonmetricity-R^T source_nonmetricity R |
| source_metric_compatible | Python bool | max absolute source_nonmetricity<=atol at this point |

The implementation admits nonmetric source connections and always uses the projector curvature formula. The transpose second-fundamental expression g^{-1}(S[a]^T h S[b]-S[b]^T h S[a]) is justified only when the source connection preserves h at the point. It is not substituted for the projector formula. The compatibility flag is an absolute-tolerance point diagnostic; it proves neither compatibility on a neighborhood nor parallelness of F. There is no target metric chosen independently of the quotient metric.

## Derivative and curvature route

The utility first solves \(V=h^{-1}F^\top\), then forms \(H=FV\), \(g=H^{-1}\), and \(R=Vg\). Its ordinary derivatives are evaluated by differentiating these linear systems:
\[
 dV=h^{-1}(dF^\top-dh V),\qquad
 dH=dF V+F dV,\qquad
 dg=-g(dH)g,\qquad
 dR=(dV)g+Vdg.
\]
It then uses \(d\Pi=(dR)F+R(dF)\) and the frozen connection formula. The exact identity recorded as the returned projection residual is the nonmetricity identity
\[
 dg-B^\top g-gB=R^\top(dh-A^\top h-hA)R.
\]
It does not label DF itself a residual that should always vanish. DF is a potentially nonzero scientific output, including for the current varying scalar-weight map. The curvature formula is valid for the metric-selected projector even when source nonmetricity is nonzero.

No configured experiment reaches this utility yet. Its only added caller is the new focused test file. It computes geometric quantities only: no normalized VFE penalty, Fisher-metric substitution, stochastic field prior, principal-representation admission, parent autonomous dynamics, or replacement of the existing prescribed connections is implemented.

## Authored scientific checks, not executed

The focused file contains eight test functions and nine planned parametrized cases, counted from source rather than test collection. All test points and constants use CPU float64; all dimensions are at most four, with base dimension two. No model, training loop, GPU, subprocess, full suite, tamper scenario, or artifact mutation is included.

The flat-source 3-to-2 plane example is checked at the origin and (0.3,-0.4), including its analytic quotient metric, connection, curvature \(-Jg/(1+x^2+y^2)\), second-fundamental expression, and basic projection identities. A separate noncommuting source connection compares K_B against autograd derivatives of B plus its commutator, and compares dg and dR against independent differentiation of returned g and R.

A varying nonorthogonal GL source change and varying GL target change check transformed g, R, Pi, B, DF, D_Pi, S, and curvature, with the source metric transformed as required. The example has a source connection matrix that is not Euclidean-skew in its new coordinates while its transformed metric compatibility remains zero.

The staged/direct check passes the actual intermediate quotient metric, its derivative, projected connection, and curvature into the second stage and compares against direct composition. The separate reset-metric witness reproduces the different scalar connections \(-x dx/(1+x^2)\) and \(-x dx/(4+x^2)\). The common-SO(2) scalar-weight check retains the declared curvature while requiring nonzero DF. The variable-metric nonmetric-source example checks the projected nonmetricity identity and independently differentiates B to check curvature. Finally, a rank-deficient coarse matrix is required to fail positive-rank admission rather than be regularized. That is a mathematical domain check, not an artifact corruption or forgery test.

## Verification handoff and hashes

The only executed Python operation was AST parsing of the two source files with C:/Python314/python.exe, using the standard ast and pathlib modules. It imported neither torch nor either new file, and ran no tests or scientific calculations. Both files parsed successfully after the final source edit. Static readback checked the formula indices, return schema, explicit CPU test constructors, and dtype assumptions.

Root owns all test execution and integration. The focused target is tests/test_quotient_connection.py under the torch-equipped C:/anaconda/python.exe interpreter. This handoff contains no passing test claim, JUnit, runtime total, CUDA claim, or ledger closure.

| Frozen file | SHA-256 |
| --- | --- |
| src/multiagent_elbo/geometry/quotient_connection.py | 373b421ca706546777c6235bae92e5c74c8dcf061b8f761a23129e5a219ef759 |
| tests/test_quotient_connection.py | 85be45be82a2ffe0cbb8f5ed5d34ecfcee5bbec57b8c8e84cf2c7bb6e03ceb7e |
| agents/projected-connection.md, unchanged mathematical input | dcac12ab952dc2a735e9b50cf7a01c8ee200562fb6a4a7f846686967d15e7951 |


