<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->
# Parallel construction protocol

Root owns this coordination file, the contract/registry/ledger, integration, and implementation selection. Every agent owns one named Markdown file under agents/. Read the contract first. Communicate mathematical results in those files; tool messages only announce a file revision or a concrete dependency question. Do not rewrite another agent's file. Put questions to another lane in a Cross-lane questions section and answers in the recipient's own file, citing the source path and heading. No result is accepted merely because multiple agents agree.

Each return states family ID, LEMMA/CONSTRUCTION/COUNTEREXAMPLE/OBSTRUCTION, exact statement, types, quantifiers, assumptions, target obligation, derivation, failure condition, open gap, novelty fingerprint, and proposed disposition. Cite primary sources for imported theorems. Numerical controls are separately marked. Read existing derivations before proposing work already done; docs/STATUS.md is dated August 13 and must not be treated as current execution state. The canonical Research/manuscripts/verified-ledger.md path is absent; use current repository derivations and their source/evidence bindings. No tamper/corruption/forgery tests, no historical producer, no full suite, no GPU work while occupied, no Research-vault write, no Git publication. All lanes work in C:/tmp/elbo-cover-20260908 and preserve dirty WIP.

## Active lanes

Coverage: map the live SPEC and current rg_v2/neighborhood implementation into a dependency-ordered completeness matrix; do not re-audit settled results.

Evolution: construct regular-stratum moving-context evolution and changing-domain boundary compatibility, including exact retained conditional closure and explicit approximation/limit obligations.

Scale: construct exact recursive effective actions and a genuinely interacting fixed-point witness, with normalization, gauge/retained-boundary typing and reproducible equations.

Root advances the reduced-event-state implementation after its supporting finite-family derivation is exposed, and integrates only named, proved interfaces. The user requested persistence across the complete program; do not declare program completion after a single numerical milestone.

## Scale implementation handoff

The scale discovery return is complete. Its exact finite witness proceeds to bounded implementation under agents/scale-implementation-brief.md, while independent proof reconstruction remains outstanding. Root has implemented the fixed-conditional event family and its runtime tests; the separate theory status is still candidate.


## Construction and reconstruction checkpoint

Frozen discovery files now include coverage.md, scale.md, scale-implementation.md, event-closure.md, evolution.md and base-descent.md. Root added finite-core.md and reduced-event.md. Scale-verification.md is a separate frozen reconstruction and records the graph-action scope counterexample. Independent event, base and evolution reconstructions are active. Shared filesystem and reused-role history are disclosed; these views are derivations, not independent experimental corroboration or votes.

The exact scale module's eleven cases and its native artifact case passed. A subsequent thin generic-core bridge added the normalized 16-to-8-to-4-to-2 action/ELBO tower; only the changed native case was rerun and passed. Its configured study was rerun because the runner gained that bridge, preserving both runs. The current run has ten depth/family records and forty controls. The moving-bin run remains a retained snapshot; later route additions changed its catalog source hash, and readback reports that drift explicitly rather than silently rebinding its results.


## Curvature and base integration checkpoint

The two curvature discovery files and cross-author gauge reconstruction are frozen; root independently reconstructed the statistical/base file and its local heat coefficient. The optional finite compact-link and two-sphere/Gaussian examples are being implemented with full normalized laws. Base-presentation source is frozen and its native runner is integrated. Root owns the consolidated focused execution and delivery. The original neighborhood PROFILE and both connection choices are preserved.

The assigned generic verifier-adjudicator requires a different active-session schema and abstained without mathematical adjudication or ledger edits. Its report and matching input/output ledger hashes are retained. This incompatibility must not be relabeled a mathematical refutation or a passing certificate. The rigorous-theory-search checkpoint remains the active package's structural validation; overall terminal status remains unset.

The mature regular/hybrid theorem now has a dedicated actual-fixture interface lane. It must establish finite one-sided laws and SPD conditionals at occupancy boundaries before proposing a continuum implementation; it must not hide a singular birth by epsilon clipping.


## Resolved hybrid and quotient checkpoint

The side layer passed25 cases unchanged. The resolved runner passed14 initial focused/native cases,109 affected route cases, and three follow-up comparison cases after an independent latent-versus-emitted TV counterexample. Its source readback has no remaining bounded defect. The CPU study retained124 phases across four paths, exact event schedules and sampled primary norms. The optional fixed-rank quotient utility passed nine tiny CPU cases, with separate proof reconstruction and no active connection/VFE substitution.

Root has added14 scoped candidates and frozen proof/result bindings; all50 formal entries remain candidate, while structural checkpoint passes. A root metadata error used the claim kind for two numerical evidence records; it was corrected to the evidence kind and the failed checkpoint is retained. Mathematical source and scientific runs were unchanged. Current parallel lanes inspect existing holonomy-dependent likelihoods and update the final SPEC scope map before further implementation. A request for a fresh neutral reconstruction agent hit the platform thread limit even after interrupting an unused pending-init slot; no independent-prior-erasure pass is claimed from that failed dispatch. Existing reconstructions disclose shared-model/context limitations.

## September9 holonomy and whole-dependency checkpoint

The finite support amendment, normalized holonomy observation/field posterior, retained-label VFE and coarse corrections are implemented and separately reconstructed. Twenty-one focused and109 affected routing cases passed after one preserved NumPy native abort without JUnit. The CPU profile has three charts,996 arrays and max identity residual1.56e-15. No CUDA science ran; the most recent read-only GPU snapshot remained98 percent busy with31,989 MiB resident. Source/artifact readback and figure inspection are complete.

The fresh-context whole-dependency lane reconstructed51 mathematical subclaims and the mathematical target implication, mapped all58 IDs, and retained six unvalidated numerical records. Its original rotating-projection attack and prior-erasure analysis are frozen. A final bounded evidence lane is reading those existing numerical records, their JUnit and source/runtime bindings without rerunning science or changing claims. All58 ledger entries remain CANDIDATE. The compatible formal-adjudication gap is not a missing mathematical model.

The final standard-library evidence lane accepted all six recorded scopes after raw JUnit recount,27 study artifact hashes and selected NPZ readback. Its Markdown and JSON retain each historical/current source difference and the missing historical source/environment archives. No science replay ran, no old evidence was rebound, and all58 claims remain CANDIDATE. The final frozen batch is being delivered with the rolling canonical baseline.
