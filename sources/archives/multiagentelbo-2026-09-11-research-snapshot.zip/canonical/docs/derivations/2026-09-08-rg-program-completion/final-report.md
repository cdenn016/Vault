<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Rigorous theory search report

## Frozen contract

The unchanged contract b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029 asks for an exact finite normalized-law/common-channel RG construction, the hypothesis-bound regular and reduced extensions adopted in this run, and one executable interacting fixed-point realization or a scoped obstruction. It starts with an admitted normalized joint; arbitrary mutually incompatible local marginal proposals are not promised a joint extension. Every stated support, differentiability, positivity, boundary and comparison hypothesis remains part of the theorem.

## Terminal status

COMPLETE_AFFIRMATIVE for that frozen contract. This is a scoped written-proof and recorded-implementation release, not a declaration that the entire renormalization research program or every SPEC appendix obligation is complete. The terminal structural record is evidence/native-terminal-release.json; it validates schema, closure coverage and referenced file bytes, not mathematical truth.

## Certificate

The certificate is claim target. Its direct DERIVATION evidence is construction-or-strongest-theorem.md and agents/rts-native-adjudication.md, with their computed SHA-256 values in claim-ledger.json. Individual ancestors retain their original direct proofs and hypothesis mappings. The finite sum/disintegration identities apply universally to the admitted finite common-channel domain. The smooth, quotient, hybrid and reduced-family results apply only under their exact recorded assumptions. The diamond's exact cubic-field witness supplies the existential interacting root-action realization. The positive ladder is an additional fully specified R6 family, with exact gauge-equivariant blocking, complete transfer action and a proved fixed-width limit/fixed-object obstruction. Recorded numerical evidence is used for execution claims only.

## Strongest verified result

The construction connects a normalized collective model and exact VFE to common coarse channels, action/reference/evidence composition, conditional KL losses, overlap restrictions, occupied conditional attention, gauge covariance and changing-domain inference. Local scalar VFEs do not determine a global joint. Clique/separator compatibility or a supplied joint supplies that missing probability structure.

Gauge curvature can enter a declared normalized latent-field prior or holonomy likelihood, including its entropy and partition. Fisher geometry supplies the inference metric and does not select an extra universal curvature penalty. Base curvature requires a separately declared base metric and probabilistic model. Their tensors, connections and normalization terms are kept distinct.

The positive periodic Z2 ladder implements exact rational 16-entry transfer convolution, raw frame lifts, preserved Wilson products, block-two/block-three/direct-six composition and a common-observation VFE comparison. Its three-bias ansatz is not closed, so the full generated action is retained. Explicit Perron algebra and stochastic contraction prove its thermodynamic cylinder law, pressure, depth limits and strictly positive normalized fixed-kernel classification. The limiting kernel pi(s)/4 can retain local rung bias; it has no intercell critical interaction, while negative plaquette holonomy remains possible. Fixed positivity and width are essential.

## Dependency closure

The target reaches all 68 ancestors. The 69 total claims comprise 62 mathematical claims including the target and seven recorded numerical observations; all have EVIDENCE_VERIFIED dispositions at their exact scopes. There are no candidate ancestors. The final evidence/claim/DAG files, rather than this count alone, specify the closure. The original 58-claim inputs are archived under evidence/native-input, including the previous empty target evidence list. The corrected boundary-factorization locator is evolution.md E4.

## Independent reconstruction

agents/final-closure-coverage.md composes the actual native original-58 reconstruction, the separate new-ladder proof/source reconstruction, the root's direct derivation admission and the separate new numerical readback. It maps every claim to its proof or execution locator. This is not a third review or a vote. The workers share the filesystem and model family; exact serving aliases are unknown. No kernel-checked formalization or independent scientific replay is claimed. The native reader recounted retained XML and inspected source/artifact identities, preserving historical drift.

The new ladder record has 138 executions and 137 distinct latest passing cases: 25 unchanged core cases, 109 unchanged routing cases and three current artifact/Perron boundary cases. The initial successful study and older runner snapshots remain retained. The latest five source and five artifact hashes match. A source-level cancellation finding led to a guarded floating Perron calculation and two added boundary cases; it was not an earlier observed failed run.

## Oracle erasure

The same coverage artifact records substantive semantic checks for the target and every ancestor. Finite normalization, direct sums, exact cubic-root existence, conditional evolution estimates, geometric counterexamples and the ladder's explicit positive contraction remain supported without assuming the desired conclusion. Recorded output acceptance depends on XML identities and artifact bytes, not a preferred outcome. Removing the outcome preference therefore removes no premise. This establishes that the preference is unnecessary; it does not independently prove the theorems. Structural validation cannot detect every paraphrased dependence.

## Unresolved obligations

There is no unresolved obligation within the frozen release scope. The broader program remains active: R5 still needs the proposed target-preserving parent-sensitive transition, admission on the actual nonflat incidence component, exact stationary/endpoint/lifetime calculations and comparison with whole-clock waiting. agents/r5-next-construction.md records that bounded next task. The S1-S3 simulation suite remains on hold.

Critical singular-parameter or increasing-width limits, continuum field measures, general measurable/singular quotient constructions, scheme universality and physical identification remain separate open targets with additional proof or empirical requirements. The positive ladder does not close them by restriction. The retained native NumPy abort has no established root cause; this release makes no reliability claim resolving it.

## Scope and limitations

Written derivations establish the mathematical conclusions under their stated assumptions. The finite/Gaussian/compact-field choices are mathematical model declarations. An operational holonomy sensor is a declared record-law construction, not proof of physical geometry or unique field identification. No physical clock, universal curvature coefficient or arbitrary noncompact gauge measure is inferred.

The evidence is bound to individual proof bytes and recorded source/config/runtime snapshots. Eleven historical manifest/source pairs in the original readback differ from the later tree; their recorded and current hashes are retained, rather than relabeled as current tests. The new floating study is a finite diagnostic and not an interval enclosure or limiting proof. No current-tree full-suite certificate, CUDA science, historical heavy producer, tamper check, vault write or Git publication is claimed. The first integrated structural checkpoint rejected two root-authored evidence-kind labels; that exact input and output remain preserved, and the corrected checkpoint passed.
