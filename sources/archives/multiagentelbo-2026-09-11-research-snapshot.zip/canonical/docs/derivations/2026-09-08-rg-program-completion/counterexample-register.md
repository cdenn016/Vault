<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029","schema_version":"rigorous-theory-search/v1","target_digest":"b8af2656503d0aefaf920414581d56aa8525a2a7a607da5f1e49cff073a0a029"} -->

# Counterexamples and scoped obstructions

The finite-core.md F3 triangle has three strictly positive compatible pair marginals, each with disagreement probability 0.9. Any binary joint has at most two disagreeing edges, so their total expected disagreement 2.7 cannot occur. This refutes pairwise marginal compatibility as a general joint-existence criterion. It does not refute a supplied normalized joint or the clique-tree construction.

The scale.md stochastic-gap example, reconstructed in scale-verification.md SV10, has a unique feasible fine q under a fixed BSC forward channel. Its KL exceeds the coarse KL by log(6912/3125)/8. An unrestricted posterior-conditional joint lift changes the forward channel and is not a feasible substitute.

The scale-verification.md SV08 counterexample refutes blindly commuting the nonlinear homogeneous diamond copying operation with independent terminal permutations. Gauge covariance is instead a graph-level statement with compatible vertex transformations and transported edge links. Existing direct enumeration uses that compatible operation; this is a scope clarification rather than a reported code defect.

Evolution E4 exhibits identical old parent laws and unequal new parent laws after departure; its factorization criterion states when the obstruction disappears. E6 gives the analogous moving-readout obstruction for an insufficient fixed modal state. Retaining full conditional information or restricting allowed preparations may remove these counterexamples, at an explicit state cost.

Base-descent B6a varies the gauge-invariant Gaussian KL along a forgotten base fiber, defeating the declared invertible descent map. B6b supplies nonzero mixed curvature along a vertical base direction, defeating any compatible pullback connection for that base projection. These are valid smooth mathematical inputs, not artifact corruption checks. Averaging them would require new probability data and a different construction.

The fixed-conditional event study is a measured approximation limitation, not a counterexample to its proved restricted dynamics. The exact log-affine current-model family is a different mechanism. Arbitrary out-of-family edge/triple likelihoods in event-closure.md delimit that exact closure; passing sampled context checks alone does not prove an entire target-log range is contained in the span.

All counterexamples are retained with their exact scopes. Separate evolution and base reconstructions are recorded in their frozen reports. The native atomic reconstruction now checks these original claims at their stated scopes; the historical checkpoint remains archived.


The hybrid-integration review adds a positive unary pair whose unavailable latent labels differ by total variation0.2 while every emitted available-agent and parent law agrees. This refutes emitted TV as a metric on the full retained event state. The revised runner reports latent TV and primary sampled Gaussian/event norm separately; the counterexample test and affected artifact checks passed. The original output omission and its correction remain recorded in hybrid-evolution-verification.md.

The metric-projected connection report supplies a flat-source, rank-two quotient with nonzero curvature, and a different example where resetting the intermediate metric changes the projected connection. Those examples refute zero-curvature inheritance and stagewise Euclidean-metric reset as general principles. The current scalar-weight SO2 specialization still has no extra curvature, and none of the constructions repairs its nonparallel coarse-map obstruction. Independent reconstruction is projected-connection-verification.md.

The fresh-context whole-dependency reconstruction adds the rotating rank-one projection F(s)=(cos s,sin s) with flat source metric/connection. Its induced connection is zero, but two full positive Gaussians with identical current projected laws have different projected mean velocities. This separates metric projection from autonomous parent dynamics without contradicting the retained-defect construction. Section10 of whole-dependency-reconstruction.md also gives a separate positive latent-event/readout witness.


The positive-ladder derivation supplies two different R6 obstructions. The initial three-bias transfer form fails exact block-two closure, even after scalar or endpoint-coboundary changes; the implemented full 16-entry table retains the generated interaction. Separately, strict positivity gives a proved stochastic contraction and forces every normalized power-blocking fixed object to pi(s)/4. A local rung bias may remain, and neither singular boundaries nor growing width is covered. The auxiliary eight-state closed trace would impose trivial rail Wilson products, so it is explicitly excluded as a replacement for the physical partition tr(M^N).
