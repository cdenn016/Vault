# Gaussian rate-aware calibration selection

September 8, 2026. This module adds a calibration-only selector beside the existing [modal trajectory compression](2026-09-08-gaussian-modal-compression.md). It preserves the previous compiler, representation, curvature ranking, experiments, and configuration. The new selector ranks the same atomic eigenvalue groups using rate error and chooses the first ranked prefix meeting two declared tolerances at the configured selection times. It supplies no uniform-time bound, autonomous parent dynamics, semigroup, or globally optimal subset claim.

## Rate ranking on the existing spectrum

Use the previously prepared target-whitened spectrum \((\lambda,h)\), where the target covariance is the identity in whitened coordinates. For \(a=e^{-t}\), \(w=1-a\), and \(d_i=w+a\lambda_i\), the modal mean and covariance corrections to endpoint interpolation are

\[
c_i=\frac{aw(\lambda_i-1)}{d_i\lambda_i},
 v_i=-(\lambda_i-1)c_i.
\]

Their derivatives are

\[
\dot c_i=\frac{a(\lambda_i-1)[2a-1+a^2(\lambda_i-1)]}{d_i^2\lambda_i},
 \dot v_i=-(\lambda_i-1)\dot c_i.
\]

The new score for an existing atomic group \(G\) is

\[
\max_{t\in\mathcal T_{\mathrm{select}}}
\left[\sum_{i\in G}(h_i\dot c_i)^2+
\frac12\sum_{i\in G}\dot v_i^2\right]^{1/2}.
\]

This is the contribution of that group to the rate-error norm induced by the Gaussian Fisher quadratic form at the fixed target. The factor one half in the covariance term is retained. The former curvature ranking remains an explicit comparator. `rate_spectrum` uses `dataclasses.replace` to change only `order` and `group_scores`; the eigenvalues, information coordinates, whitening eigenvectors, atomic groups, and selection times remain the original prepared data.

The groups keep the previous relative-neighbor rule at \(10^{-10}\). No eigenvalue is averaged, and no candidate cuts a group. A repeated eigenspace is therefore kept or omitted as a whole. Scores are independent of the parent map and invariant in exact arithmetic under passive frame changes, subject to the same finite-precision clustering and ranking qualifications as the existing compiler.

## Exact fine-space calibration errors

For an omitted mode, its approximate variance in the whitened eigenbasis is \(b_i=w+a/\lambda_i\), whereas its exact variance is \(1/d_i=b_i+v_i\). Define \(r_i=v_i/b_i\), so \(-1<r_i\leq0\) for admitted positive eigenvalues. The exact directed state error is

\[
\operatorname{KL}(q_{\mathrm{exact}}(t)\Vert q_{\mathrm{approx}}(t))
=\frac12\sum_{i\notin K}\left[
r_i-\log(1+r_i)+\frac{(h_i c_i)^2}{b_i}\right].
\]

Both covariances are diagonal in the same whitened eigenbasis. Applying the Gaussian KL formula separately to each coordinate proves this identity, and the retained coordinates contribute zero. The implementation uses `log1p(r_i)`; it does not replace this directed KL with the opposite direction or a covariance-only surrogate.

The exact fine-space rate error measured using the Fisher form at the fixed target is

\[
E_{\mathrm{rate}}(t)=
\left[\sum_{i\notin K}(h_i\dot c_i)^2+
\frac12\sum_{i\notin K}\dot v_i^2\right]^{1/2}.
\]

Rates of the exact and approximate trajectories are compared in the common mean/covariance coordinates, using the Fisher quadratic form at the fixed target. This is a declared fixed-target comparison. It is not a claim about the Fisher norm at either moving recognition law or a parallel transport between those two laws.

## Why fine calibration controls fixed parent projections

For any fixed common linear parent map, the KL chain rule used by the [conditional-completion construction](2026-09-08-gaussian-conditional-completion.md) writes the fine KL as the parent KL plus a nonnegative expected conditional KL. Hence the directed parent state error is no greater than the fine error.

For the rate norm, let \(L\) be the fine target Cholesky factor and \(L_Y\) the Cholesky factor of its pushed covariance \(FLL^TF^T\). In the whitened eigenbasis, define \(M=L_Y^{-1}FLU\). Full row rank gives \(MM^T=I\). The mean-rate difference is mapped to \(M\delta\mu\), and the covariance-rate difference to \(M\delta\Sigma M^T\). Therefore

\[
\|M\delta\mu\|_2\leq\|\delta\mu\|_2,

\|M\delta\Sigma M^T\|_F\leq\|\delta\Sigma\|_F.
\]

Combining these inequalities with the one-half covariance factor proves contraction of the chosen fixed-target Fisher rate norm. The same fine selected set therefore controls both parent depths at each calibrated time. This proof requires fixed target whitening and fixed full-row-rank parent maps; it does not assert a bound for a changing target, a different rate metric, or uncalibrated times.

## Prefix selection and recorded output

`select_budget(spectrum, gaussian_kl_limit, gaussian_rate_limit)` considers zero modes, then the cumulative sizes of whole groups in `spectrum.order`. For every candidate it computes the exact fine state and rate errors at every `spectrum.selection_times` entry. It returns the first candidate whose maximum KL and maximum rate error satisfy the supplied limits using ordinary less-than-or-equal comparison. There is no tolerance relaxation. The full-mode candidate has an empty omitted set and exactly zero computed error.

This is the first passing ranked prefix, not a search over all admissible group subsets. No statement of global storage optimality follows from it. No parent map or held-out evaluation-time argument is accepted by the selector. The existing `Spectrum` may carry either the previous curvature ordering or the new rate ordering, making the comparator explicit.

The returned `Selection` contains `budget`, `selected_indexes`, `mode_count`, and `calibration`. The latter stores every candidate through the first passing one: selected and discarded counts, mode indexes, each calibration time's errors, both maxima, and the Boolean outcome. These are calibration diagnostics, not a uniform-time certificate. This selection object does not change the runtime representation or its previously stated storage accounting.

## A bounded distinction between curvature and rate selection

A two-dimensional diagonal example separates the rankings without any stochastic search. Set the target covariance to the identity, the initial precision eigenvalues to \(2\) and \(4\), and both means to zero. Calibrate at \(t=\log3\), so \(a=1/3\). The absolute covariance-curvature corrections are \(1/12\) and \(1/4\), respectively, so curvature ranks the eigenvalue-four mode first. Their derivative corrections are \(1/48\) and zero, so the rate ranking selects the eigenvalue-two mode first.

With KL limit \(0.1\) and rate limit \(10^{-4}\), retaining the eigenvalue-two mode passes at this calibration time while the corresponding first curvature-ranked prefix does not. This example does not predict the mode count chosen for the actual neighborhood fixture. It also exposes the scope boundary: if the eigenvalue-four mode is omitted, its initial-time rate error is \(9/(16\sqrt2)\), even though the initial law is exact. A calibrated intermediate-time pass is therefore not a uniform-time guarantee, and endpoint law accuracy does not imply endpoint rate accuracy.

The supplied small tests check this declared example, prefix minimality, exact and near-degenerate atomic groups, matrix-form KL and rate comparisons against the existing evaluator, initial law/rate separation, passive frame changes, parent-map independence, contraction under fixed projection, and exclusion of held-out times from selection. Tests are supplied for the coordinating implementation's consolidated execution; this derivation records no passing results.
