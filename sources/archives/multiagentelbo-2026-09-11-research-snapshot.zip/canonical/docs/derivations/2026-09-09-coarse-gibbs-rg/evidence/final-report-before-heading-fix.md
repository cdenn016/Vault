<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab", "schema_version": "rigorous-theory-search/v1", "target_digest": "15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab"} -->

# Exact coarse Gibbs and specific VFE proof record

## Frozen contract

[problem-contract.json](problem-contract.json) has target digest 15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab. The target is fixed-block exact coarse interaction regularity, its constrained finite oracle and stationary pressure/entropy/VFE limits. It does not replace the larger renormalization goal.

## Terminal status

The scientific result supports COMPLETE_AFFIRMATIVE for this frozen fixed-block contract at 0<c<1/(6B), conditional on the explicit admitted source-law and geometry premises. The separate native release record validates artifact structure and coverage; it cannot establish mathematical truth. The full RG goal remains active.

## Certificate

[constrained-gibbs-construction.md](agents/constrained-gibbs-construction.md) and [potential-vfe-construction.md](agents/potential-vfe-construction.md) provide the direct proofs. [coarse-implementation.md](agents/coarse-implementation.md) maps finite algorithm identities to the frozen source. The retained command/result and raw JUnit supply only their finite numerical scope. No result is closed by an agent vote.

## Strongest verified result

[The assembled theorem](construction-or-strongest-theorem.md) constructs an everywhere positive coarse specification, exact exponentially summable translation-invariant interaction, quantitative boundary/pressure approximation, and the stationary specific VFE formula for the full pushed law. The sufficient interval includes B2/3/6 simultaneously for c<1/36. It also implements exact full parity-fiber and finite-window conditional laws, with explicit references and resource budgets.

## Dependency closure

Every atomic fixed-block conclusion has its direct derivation or current finite execution, and the dependency graph points from claims to their premises. The coarse continuity proof is a prerequisite to the potential; the potential and boundary proof precede the thermodynamic objective. Source-correspondence claims are conditional finite algorithm identities, not universal runtime statements inferred from tests. The research proposal for all-depth regularity is outside this closure.

## Independent reconstruction

The checker froze a contract-only derivation before reading new author/root/source drafts, then compared all proof interfaces and source/record evidence. The [record](agents/independent-proof-check.md) discloses shared model/filesystem limits. It independently obtained the constrained-support tilt constant, shell multiplicity, arbitrary-exterior ratio passage and normalized pressure signs. The empty-support likelihood convention was made explicit before closure.

## Oracle erasure

Remove all preference for an affirmative result and all passing test outcomes. The explicit finite probabilities, support-preserving coupling, limit and conditional identities, counted shell series and finite KL algebra still establish the fixed-block mathematical statements. Numerical claims instead retain only actual source-bound JUnit/receipts. Neither agreement nor a favorable direction supplies a proof premise. The native coverage record checks the target and its complete dependency closure.

## Unresolved obligations

There is no admitted fixed-block obligation left without a proof or finite implementation within this contract. At the full-program level, fixed-positive-c all-depth interaction regularity remains open because alpha_B=6Bc grows with B. Critical behavior, universality, continuum connection/field measures and physical identification retain separate obligations. The [next-route intake](agents/next-uniform-action-obligation.md) is discovery material, not a theorem or a substitute target.

## Scope and limitations

One new exact packet ran: 28 distinct cases, all passed, zero failures/errors/skips, JUnit time 0.428 seconds and runner elapsed 1.0045453000348061 seconds. It used Python 3.12.7 at C:/anaconda/python.exe with isolated source imports and at most seven fine free edges. Larger exact enumeration is reachable by an explicit budget but unexecuted. Tiny finite equality is not an infinite-volume proof. The four-state reference is dressed coarse cells, not an undeclared raw-frame alphabet. Observations use a common strictly positive finite-range normalized kernel and homogeneous preparation; q is one stationary law. All tests excluded tamper/corruption/forgery scenarios as directed. No old producer, held S1-S3, full suite or GPU substitution ran. Existing finite curvature models are preserved, with no newly inferred Fisher/base curvature VFE penalty. WIP and canonical protected absences remain under the rolling handoff guard.
