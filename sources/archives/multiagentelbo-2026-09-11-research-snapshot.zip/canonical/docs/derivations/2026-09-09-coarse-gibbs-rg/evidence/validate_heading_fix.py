"""Validate the corrected report heading once, preserving the earlier failure."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
RUN=Path(__file__).resolve().parent.parent
SKILL=Path(r'C:/Users/chris and christine/.codex/skills/rigorous-theory-search/scripts')
sys.path.insert(0,str(SKILL))
from validate_run import validate_run
NAMES=('problem-contract.json','approach-registry.json','claim-ledger.json','dependency-dag.json','adversarial-report.json','release.json','counterexample-register.md','construction-or-strongest-theorem.md','final-report.md')
def sha(p: Path) -> str:return hashlib.sha256(p.read_bytes()).hexdigest()
def main() -> None:
 out=RUN/'evidence/native-release-heading-fix.json';assert not out.exists()
 original=json.loads((RUN/'evidence/native-release.json').read_text());assert original['errors']==['final-report.md: headings must exactly match the release contract']
 before={name:sha(RUN/name) for name in NAMES};errors=validate_run(RUN,mode='release')
 data=dict(mode='release',passed=not errors,errors=errors,validator_sha256=sha(SKILL/'validate_run.py'),input_sha256=before,inputs_unchanged=all(sha(RUN/p)==h for p,h in before.items()),timestamp_utc=datetime.now(timezone.utc).isoformat(),prior_failed_check='native-release.json',amendment_sha256=sha(RUN/'evidence/heading-format-amendment.json'),scope='One exact heading correction; structure and hashes only, no mathematical or test rerun.')
 out.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8');print(json.dumps(data),flush=True)
 if errors or not data['inputs_unchanged']:raise SystemExit(1)
if __name__=='__main__':main()
