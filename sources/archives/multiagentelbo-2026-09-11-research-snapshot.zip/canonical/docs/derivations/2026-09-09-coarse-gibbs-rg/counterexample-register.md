<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab", "schema_version": "rigorous-theory-search/v1", "target_digest": "15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab"} -->

# Scope attacks and resolved obligations

The same-support block influence estimate cannot be applied to two differently constrained target supports. CG03-CG08 instead compare common interiors and treat changed supports outside them as boundary forcing. Ordinary single-fine-edge updates would freeze a fixed-parity path and do not prove this theorem. The complete block partition is essential.

Small parity bias alone does not imply spatial continuity. CG07-CG15 supply the separate uniform comparison, every-exterior construction, finite-set consistency and actual pushed-law DLR identity. Infinite exterior patterns are not assumed to have positive probability.

A small potential shell is not enough for summability without counting all translates meeting one site. CP02 includes the quadratic support count. CP03 proves vacuum finite-modification ratios first and then explicitly passes to every exterior; omitting that passage would leave the Gibbs equality incomplete.

Normalized counting cannot be exchanged for unnormalized counting without shifting pressure. CP05 and CP08 start from the mass 4^(-|Lambda|)exp(-H)/Z_lambda and retain log4. CP09 states a separate finite-site convention for an empty observation support. Arbitrary nonstationary or volume-varying recognition preparations are not admitted.

A generic finite singleton constraint is valid finite conditioning but is not a coarse observation on an unused edge. The implementation note states the narrower spatial pattern; the tiny generic support matrix does not claim a coarse-window identity beyond it. The added B1/2/3 two-path tests exercise actual retained coarse parity ratios. B6 has only the admitted one-path fixture.

The interval 6Bc<1 is sufficient, not claimed sharp. Its failure at large B is not a counterexample to Gibbsian regularity. It leaves a precise all-depth obligation. Existing curvature inference and quotient geometry do not identify Fisher, gauge and base curvature, and the new lattice potential does not supply that identification. No deliberately corrupted record, artifact or packet was used to investigate any of these mathematical scope attacks.
