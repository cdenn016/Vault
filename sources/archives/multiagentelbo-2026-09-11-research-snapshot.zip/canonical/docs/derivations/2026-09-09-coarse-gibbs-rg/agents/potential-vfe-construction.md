<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab", "schema_version": "rigorous-theory-search/v1", "target_digest": "15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab"} -->

# Exact potential and stationary specific VFE: root derivation

## Interface and domain

Fix B>=1, 0<b<1 and 0<c<1/(6B). Put alpha=6Bc, rho=[b(1+c^2)+2c]/[1+c^2+2bc], kappa=(1-rho^B)/2 and m=kappa^2. The [constrained construction](constrained-gibbs-construction.md) must establish the following interface before the conclusions below can be admitted. The exact B-path pushed law mu_B on the four-symbol coarse cell alphabet E={-1,+1}^2 has a translation-covariant consistent specification gamma_A for every finite cell set A and every exterior configuration. It is proper, strictly positive and quasilocal, and mu_B satisfies its DLR equations. Every single-cell probability is at least m. If two exterior patterns agree through Chebyshev radius R about x, their one-cell rows differ in total variation by at most 2 alpha^(R+1). Consequently each log probability differs by at most 2 alpha^(R+1)/m, and each log odds against the reference symbol by at most 4 alpha^(R+1)/m. These constants come from constrained-block comparison and the straight-path conditional product bound, not numerical fitting.

This proof uses only that interface and elementary finite-alphabet sums. It never replaces a generated action by its plaquette coefficient. All logarithms are natural, all lattice distances below are Chebyshev distances, and all partition functions use normalized counting reference. An exact potential need not be unique; the convention below fixes one representative.

## CP01: local log-odds energies

Order Z^2 lexicographically, comparing the first coordinate and then the second. This is translation invariant; no first element of the infinite lattice is assumed. Fix the reference symbol *= (+1,+1). For a configuration sigma, define eta^{x,r} to equal sigma_y when y<x and ||y-x||<=r, and * at all other exterior sites. Let

    e_{x,r}(sigma) = -log[gamma_{x}(sigma_x | eta^{x,r}) / gamma_{x}(* | eta^{x,r})].

The r=0 function depends only on sigma_x. Replace the truncated past by the entire lexicographic past to define e_x; quasilocality gives this same limit uniformly in sigma. Since both row entries lie in [m,1], ||e_{x,0}||<=log(1/m). The difference between truncated and full exterior starts beyond radius r, so ||e_x-e_{x,r}||<=4 alpha^(r+1)/m. For r>=1, the two successive exteriors agree through radius r-1, and therefore

    ||e_{x,r}-e_{x,r-1}|| <= 4 alpha^r/m.

All these functions vanish whenever sigma_x=*. Translation covariance follows from the order, the reference and the specification. The log bound follows directly from |log u-log v|<=|u-v|/m on [m,1].

## CP02: explicit interaction and summability

Set A_{x,0}={x} and A_{x,r}={x} union {y<x:||y-x||<=r} for r>=1. Define Phi_{A_{x,0}}=e_{x,0}, Phi_{A_{x,r}}=e_{x,r}-e_{x,r-1}, and all other finite-set interactions to be zero. Each support has lexicographic maximum x, and for fixed x its sets strictly grow with r, so no two assignments collide. They depend only on the declared supports, even when a function happens to have smaller effective support. Each has diameter at most 2r and cardinality at most (2r+1)^2. At most (2r+1)^2 translates of the r-th support contain the origin: these translates are indexed by the site's location within that support. Thus

    K = sum_{A containing 0} ||Phi_A||
      <= log(1/m) + (4/m) sum_{r>=1}(2r+1)^2 alpha^r < infinity.

More strongly, for any lambda>0 with exp(2lambda) alpha<1,

    K_lambda = sum_{A containing 0} exp(lambda diam A)||Phi_A||
      <= log(1/m)+(4/m)sum_{r>=1}(2r+1)^2[exp(2lambda)alpha]^r < infinity.

The moment M=sum_{A containing 0}diam(A)||Phi_A|| is finite, with upper bound (8/m)sum_{r>=1}r(2r+1)^2 alpha^r. The tail from shells r>N is bounded by (4/m)sum_{r>N}(2r+1)^2 alpha^r, and the corresponding weighted tail replaces alpha by exp(2lambda)alpha. These explicit positive convergent series are quantitative bounds; no interaction truncation is used to define the law. For each x the shell series telescopes absolutely to e_x. The interaction is translation invariant and uses the declared vacuum normalization.

## CP03: exact finite-modification ratios

First let sigma differ from * on only a finite set S, and choose a finite volume Lambda containing S. List S in increasing lexicographic order and change its sites from * to sigma in that order. At the moment x changes, all earlier nonreference sites have their final values and all later sites still have *. Consistency and positivity of the finite specification give the ratio of the two Lambda-configuration probabilities as the corresponding one-site conditional ratio: this follows by conditioning that positive finite distribution on every other site in Lambda. Multiplying the finite list of ratios gives

    -log[gamma_Lambda(sigma_Lambda | *) / gamma_Lambda(*_Lambda | *)]
       = sum_{x in S} e_x(sigma).

For the potential, a term anchored at x vanishes whenever sigma_x=*. All nonzero energy differences against the vacuum therefore have anchors in the finite S, and their absolutely convergent shell sums equal the right-hand side. This proves equality of all plus-exterior finite-volume probability ratios for gamma and the Gibbs specification of Phi, and normalization proves equality of those finite probability distributions.

Next approximate an arbitrary exterior eta to a fixed finite Lambda by eta within increasing boxes and * outside. These are finite-support configurations, so the equality already proved also gives the conditional ratios with these exteriors: compare two finite-support configurations on a larger enclosing volume, use specification consistency, and cancel the common exterior factors. On the gamma side, quasilocality yields uniform convergence of the finite-volume rows and positivity preserves ratios. On the Phi side, only interactions meeting Lambda enter a finite-modification difference. Their total norms are at most |Lambda|K; the norms of those extending outside growing boxes tend to zero by absolute summability. Hence their energy differences and normalized finite rows converge uniformly. Equality passes to every eta. This proves gamma=gamma^Phi, including arbitrary exterior patterns, and mu_B is a Gibbs measure of this exact Phi. No infinite ordered product was used, and no almost-sure version was silently extended.

## CP04: boundary energy and marginal comparison

For a finite Lambda let H_Lambda^free=sum_{A subset Lambda}Phi_A and let

    b_Lambda = sum_{A meeting both Lambda and Lambda^c} ||Phi_A||.

The Gibbs conditional Hamiltonian is H_Lambda^free plus crossing terms of absolute value at most b_Lambda. Terms entirely outside Lambda cancel. Consequently its probability mass and the free Gibbs probability mass differ by a factor in [exp(-2b_Lambda),exp(2b_Lambda)]. Integration over the exterior under mu_B preserves both inequalities, so the same comparison holds for the actual marginal mu_{B,Lambda}. This is not an equality of the free and marginal boundary conventions.

For the square Lambda_L={0,...,L-1}^2, put T(d)=sum_{A containing 0,diam A>=d}||Phi_A||. Every crossing term containing x in Lambda has diameter at least dist(x,Lambda^c); counting it at such sites gives an upper bound. There are at most 4L sites at each positive inner boundary distance. Therefore

    b_Lambda <= sum_{x in Lambda} T(dist(x,Lambda^c))
             <= 4L sum_{d>=1}T(d) = 4LM.

The last identity follows by summing the integer diameter of each support; all summands are nonnegative. The formula also covers M=0. Thus the normalized marginal/free log-density discrepancy is at most 8M/L per cell. The first-moment estimate is sufficient; exponential summability supplied it.

## CP05: normalized-reference pressure

Write a=|E|=4 and Z_Lambda^lambda=a^(-|Lambda|)sum_sigma exp(-H_Lambda^free(sigma)). Its mass is a^(-|Lambda|)exp(-H_Lambda^free)/Z_Lambda^lambda. In particular |log Z_Lambda^lambda|<=|Lambda|K. For a large square of side L, tile its lower-left floor(L/n)n square by n-squares and let R be the remaining sites. Compare its free Hamiltonian to the sum of the complete tile Hamiltonians, assigning zero Hamiltonian to R. Every omitted term either touches R or crosses a tile boundary. The former norms total at most |R|K; the latter total at most the sum of tile boundary bounds, at most 4M floor(L/n)^2 n. Product normalized counting makes the comparison partition function exactly the product of tile partition functions; its R factor is one. The elementary bound |log Z(H)-log Z(G)|<=||H-G|| gives

    |p_L - floor(L/n)^2 n^2 p_n/L^2|
      <= 4M floor(L/n)^2 n/L^2 + K|R|/L^2,

where p_L=L^(-2)log Z_Lambda_L^lambda. Fix n and send L to infinity. Both limsup and liminf lie within 4M/n of p_n. Their separation is at most 8M/n for every n, so they agree. The pressure p_lambda exists and |p_lambda-p_n|<=4M/n. This direct first-moment proof also makes the normalized reference constant explicit.

## CP06: stationary entropy density

Let q be any stationary law on E^{Z^2}; ergodicity and positive q probabilities are unnecessary. Use 0log0=0. Finite entropy is nonnegative, at most |Lambda|log a, and subadditive over disjoint subsets, since their joint entropy equals a marginal entropy plus a conditional entropy no larger than the corresponding marginal entropy. Apply the same n-square tiling. Stationarity makes every full tile entropy equal H(q_Lambda_n), and the remainder entropy is at most |R|log a. Hence limsup_L H(q_Lambda_L)/L^2<=H(q_Lambda_n)/n^2 for every n. The infimum over n is no larger than the liminf of this sequence. Both agree and define s(q)=inf_n H(q_Lambda_n)/n^2. No independence, Gibbs hypothesis or claim about unrelated volume-dependent preparations enters this argument.

## CP07: stationary interaction energy density

Define e_Phi(q)=sum_{A containing 0}|A|^(-1) E_q Phi_A. Absolute convergence follows from K<infinity. Translation invariance of q and Phi makes this the expected energy allocated to each cell by giving each term equal weight among its sites. Summing these allocated terms over Lambda, terms wholly inside contribute exactly E_q H_Lambda^free; crossing terms contribute a fraction between zero and one of their expectation. Their absolute total is at most b_Lambda. Thus

    |E_q H_Lambda^free - |Lambda|e_Phi(q)| <= b_Lambda.

For squares the energy per cell converges, with error at most 4M/L, uniformly over stationary q. This allocation identity includes all generated interactions and has no fitted-coupling interpretation.

## CP08: specific relative entropy

The finite KL to the free Gibbs law is exactly

    D(q_Lambda || pi_Lambda^free)
      = -H(q_Lambda) + |Lambda|log a + E_q H_Lambda^free
        + log Z_Lambda^lambda.

It is finite even for singular q_Lambda because the comparison law is strictly positive. Replacing pi_Lambda^free by the actual mu_{B,Lambda} changes KL by at most 2b_Lambda, by CP04. Dividing by |Lambda| and using CP05-CP07 proves

    h(q || mu_B) = log 4 - s(q) + e_Phi(q) + p_lambda(Phi).

The plus sign on normalized-reference pressure and the log4 term are required by the finite probability mass formula. In the zero interaction case, p_lambda=0 and this reduces to log4-s(q). This identity establishes a density limit for every stationary q; it does not assign a finite ordinary KL to the two infinite-volume measures.

## CP09: common-likelihood specific VFE

Choose a nonempty finite observation alphabet O, a finite cell support D and a kernel ell(o|sigma_D)>0 with sum_o ell(o|sigma_D)=1 for every pattern. Fix one homogeneous observed value o_*. Include only translates x with x+D subset Lambda, using the same kernel at each site. If D is empty, instead use sites x in Lambda; this separate convention avoids an infinite empty-support inventory. For nonempty D the permitted translate count divided by |Lambda_L| tends to one. Their finite conditional observation law is the product of the normalized kernels, so multiplying it by mu_{B,Lambda} gives a normalized joint law. All log likelihoods are bounded on the finite input/output alphabets. The finite VFE is

    F_Lambda(q;o_*) = D(q_Lambda || mu_{B,Lambda})
                   - sum_{x:x+D subset Lambda} E_q log ell(o_*|sigma_{x+D}).

Stationarity gives the same expectation at every included site. Hence

    lim F_Lambda/|Lambda| = log4-s(q)+e_Phi(q)+p_lambda(Phi)
                            - E_q log ell(o_*|sigma_D).

The empty-support convention gives the same limit with its constant kernel. This is the density of an exact finite joint negative ELBO. It requires the common normalized likelihood, stationary q and stated observation preparation. No missing evidence constant, unrelated local objective or physical-time identification is appended.

## CP10: full interaction, depth and curvature scope

For each fixed B the admitted interval is nonzero, and B=2,3,6 share c<1/36. The specification and Phi describe the same full pushed law as the old exact channel; composing path maps does not require composing this particular potential representative. However alpha=6Bc cannot stay below one for fixed c>0 and unbounded B. These proofs therefore do not establish a fixed-c all-depth interaction norm limit. They do not refute one. The older cylinder limit and exact law composition remain valid in their separate domains.

The plaquette observable in the unchanged fine model is a Z2 loop holonomy, with log-factor coefficient atanh(c). Coarse blocking retains products around loops and the full generated interaction. This establishes neither a continuum Lie-algebra curvature F nor an identification of a particular Phi shell with Tr(F^2). Fisher geometry is geometry of a parameterized family of laws; base geometry requires a specified manifold, metric and connection. Any action involving those curvatures needs a separate typed construction and normalization or a declared modeling postulate. This paragraph records the user's requested next bridge, not an additional theorem derived from the present four-state lattice law.

## Primary context and limits of source use

Barbieri, Gomez, Marcus, Meyerovitch and Taati, [Gibbsian representations of continuous specifications](https://arxiv.org/abs/2001.03880), distinguish norm-summable and shift-invariant representations; their abstract reports that continuity alone need not give a shift-invariant norm-summable interaction. This motivates keeping the proved exponential modulus in CP02. Van Enter, Fernandez and Sokal, [Regularity Properties and Pathologies of Position-Space Renormalization-Group Transformations](https://arxiv.org/abs/hep-lat/9210032), report non-Gibbsian transformed measures in specified models. Those results motivate the conditional-specification obligation; they do not diagnose this positive constrained-block domain. Both primary abstracts were read in the current turn. No theorem from either is imported as evidence for CP01-CP09; their arguments above are explicit. There is no novelty assertion.
