<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab","target_digest":"15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab"} -->

# Constrained-block construction of the exact coarse specification

Date: 2026-09-09. This proof-author lane read the frozen contract first. Theory/SPEC.md retains SHA-256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1 from its earlier full read in this thread. The lane owns this construction and its atomic proposals only, executes no tests or science, and assigns no ledger closure. The author shares the model, instructions and filesystem with the parent and authored the preceding spatial measure proof; this is an explicit derivation, not independent certification of implementation. The root owns potential reconstruction and thermodynamic/objective limits. None of those conclusions is assumed here.

**DEFINITION.** Fix an integer B>=1, 0<b<1 and initially 0<c<1. The fine edge (v,a) runs from v to v+e_a, where v is in Z^2 and a is 1 or 2. Plaquettes are unit-square boundaries with their four distinct edge copies. Put h=atanh(b), J=atanh(c). The original factors are (1+b z_e) and (1+c product_(e in p) z_e). Only the explicitly stated block-contraction claims require the stronger condition 6Bc<1. The case c=0 is addressed separately at the end.

## CG01. The complete partition, cell inventory and graph distance

**ESTABLISHED.** For every coarse oriented edge (x,a), retain the fine path
P_B(x,a)={(Bx+t e_a,a):0<=t<B}. Distinct such paths have disjoint fine-edge supports. Different axes use distinct edge identities. On one axis the same transverse line is partitioned into successive intervals of length B; other transverse lines are disjoint. Complete these paths to a partition of every fine edge by making each unused edge its own singleton block. Denote the countable block inventory by I. Each block has size at most B and every fine edge belongs to exactly one block.

Assign a singleton with basepoint v the anchor floor(v/B), componentwise. All fine edge basepoints in P_B(x,a) have this same floor equal to x, so that path has anchor x. A coarse cell x contains the two retained paths P_B(x,1),P_B(x,2) and 2B(B-1) unused singleton blocks. Indeed its B-by-B array of fine edge basepoints contains 2B^2 oriented edges, of which 2B belong to its two paths. Thus it contains 2+2B(B-1) blocks and 2B^2 fine edges. A finite union of entire anchor cells is in particular a finite union of whole blocks.

No plaquette contains two edges of a single retained straight path. Its two horizontal edges lie on distinct horizontal lines and its two vertical edges lie on distinct vertical lines; an individual path occupies just one such line and axis. Hence the four edges of any plaquette belong to four different blocks. In particular an unconstrained path has no interaction between its own edges after the complement is fixed.

Let n_ij count plaquettes meeting both distinct blocks i,j, and set n_ii=0. Each edge of i has two incident plaquettes, each supplying three other block incidences, so
sum_j n_ij=6|i|<=6B. The inequality alone is used below. Declare i adjacent to j when n_ij>0. The basepoints of edges on a common plaquette differ by at most one in either fine coordinate. Their anchor coordinates consequently differ by at most one as well. Every block-graph step changes the anchor in l-infinity distance by at most one.

For a finite coarse-cell set W let Omega_W be all blocks anchored in W. If target blocks have anchors in A subset W, their block-graph distance to I minus Omega_W is at least
d_infinity(A,W^c)=min_{x in A,y outside W} ||x-y||_infinity. If W contains the radius-R l-infinity neighborhood of A, this distance is at least R+1. This counts coarse cells, not B times their distance.

## CG02. Exact restricted references and finite compatibility

**DEFINITION AND ESTABLISHED.** A constraint pattern sigma assigns each retained path either the symbol * for no constraint or one parity sign in {-1,+1}. The distinction is literal: an absent constraint does not mean parity +1. An unused singleton always has the symbol *. For each block i define its allowed state set S_i^sigma as all 2^|i| fine assignments for *, or the parity fiber with product of signs equal to sigma_i. A prescribed path fiber has exactly 2^(B-1) states, including one state when B=1. Every local support is nonempty.

For a finite block set Lambda, use the reference that is the product of uniform probability measures on S_i^sigma. It is exactly the original normalized counting reference conditioned on these disjoint parity constraints. For a fine exterior completion eta, define W_Lambda^eta by multiplying the edge factors on the free edges and every plaquette factor meeting any free edge, evaluated at the completed signs. Set Z to the reference average of W and set gamma_(Lambda,sigma)^eta to have density W/Z relative to that restricted reference. Thus its atom probability is W divided by the sum of W over the admitted product support. Every admitted atom is strictly positive; inadmissible atoms have probability zero. No uniform distribution on a nonexistent or discarded state is inserted.

The fixed exterior eta may be any fine sign assignment; a finite oracle does not require its values to satisfy distant parity prescriptions. An actual conditioning of a full constrained law of course uses exteriors in that law's support. Exterior factors and constraints that do not involve free variables are constant and do not enter the free normalizer.

For Delta subset Lambda, fixing the states in Lambda minus Delta cancels all factors not meeting Delta. The conditional reference is exactly the product of the supports on Delta. The resulting conditional is gamma_(Delta,sigma) with the completed fine boundary. This proves finite specification compatibility on unions of whole blocks, with all crossing plaquettes retained.

## CG03. The restricted-support single-plaquette TV estimate

**ESTABLISHED.** Fix one block's support S, any strictly positive baseline weights w(s) on S, and any sign character chi(s) in {-1,+1}. Compare the two normalized distributions proportional to w(s) exp(+J chi(s)) and w(s) exp(-J chi(s)). Conditional on chi, their distributions of s are identical. Their TV distance is therefore exactly the difference between their probabilities of chi=+1. If one character class is empty, both distributions coincide and the distance is zero. Otherwise write u=(1/2)log(sum_(chi=+1)w / sum_(chi=-1)w). The two plus probabilities are (1+tanh(u+J))/2 and (1+tanh(u-J))/2. Therefore

\[
\operatorname{TV}(p_+,p_-)
=\frac{\sinh(2J)}{\cosh(2u)+\cosh(2J)}
\le\tanh J=c.
\]

This proves the estimate on the actual restricted fiber. Neither the cardinality of S nor a lower probability of an individual fine state appears in this influence constant. For comparison, the oscillation of the unnormalized log-weight difference is at most 4J; the displayed calculation supplies its sharp Bernoulli tilt bound directly.

## CG04. The constrained block influence and nonzero domain

**ESTABLISHED.** Fix the constraints on block i and change the fine state of one different block j, keeping all other states fixed. Only plaquettes meeting both i and j can alter an i-dependent factor. Each altered external sign changes one factor exp(J chi_i) into exp(-J chi_i), with its other fixed signs absorbed into chi_i. Telescope these changes one plaquette at a time. Every intermediate positive weight uses the same support S_i^sigma, so CG03 applies whether or not the intermediate list is generated by a global exterior assignment. Hence the TV variation of the conditional row on i is at most C_ij=c n_ij.

The sum of this influence row is at most alpha_B=6Bc. This proves the candidate sufficient domain

\[
0<c<\frac{1}{6B}.
\]

It is nonempty for every fixed B and lies within the admitted source uniqueness domain. For B in {2,3,6} the common strict interval is 0<c<1/36. The bound does not deteriorate with the finite volume, the prescribed parity signs, or b in its stated interval. It does depend on B, and therefore establishes no fixed-positive-c all-depth interaction claim.

If several neighboring states differ, telescope over blocks; only finitely many can affect a given conditional. When two global constraint patterns differ, this estimate is applied only at blocks where the local allowed support agrees. Differently constrained exterior blocks enter as boundary forcing. Applying a same-support influence bound to two differently supported target rows would be invalid.

## CG05. Finite constrained heat-bath stationarity and uniqueness

**ESTABLISHED.** A block with s<=B free edges has at most 2s incident plaquettes. Its conditional exponential log weight has absolute value at most s(h+2J), up to constants independent of its state. Consequently every admitted conditional state has probability at least

\[
\xi_B=2^{-B}
\left(\frac{1-b}{1+b}\right)^B
\left(\frac{1-c}{1+c}\right)^{2B}>0.
\]

The support may be a singleton; the lower bound remains valid. This estimate is only a finite-chain existence tool, not the influence coefficient.

Updating one block from its actual conditional row preserves the finite constrained Gibbs law by finite conditional factorization. The random-coordinate heat bath on n blocks therefore has that law stationary. Given any initial and target admitted configurations, update the blocks once in a fixed order, assigning their target states. This path has probability at least (xi_B/n)^n. Thus every entry of the n-step kernel is at least delta=(xi_B/n)^n. If the admitted product support has M states, every row has common mass delta on each state, of total M delta<=1. Removing this common mass shows that TV contracts by at most 1-M delta<1, unless M delta=1 when the contraction is zero. Two stationary laws must coincide. The empty volume has its one-point law.

## CG06. A stationary finite coupling, including restricted supports

**ESTABLISHED.** Compare two finite laws on the same block volume and with the same interior support pattern, but arbitrary fine exterior assignments. Couple their heat baths by choosing the same update block and using a maximal coupling of its two conditional rows. Such a finite coupling exists explicitly: put mass min(p(s),q(s)) on equal state pairs and couple the remaining residual probabilities, whose supports are disjoint. Its probability of different states is exactly TV(p,q).

The pair chain has a stationary law. Take the Cesaro averages of the first T iterates of any pair law, pass to a convergent subsequence in the finite probability simplex, and observe that applying the pair kernel changes each average by (law after T steps minus initial law)/T. The limit is stationary. Its two marginals are the finite Gibbs laws by CG05. No uniqueness of the pair chain is required.

Let d_i be its probability of disagreement at block i. Canceling the unchanged-coordinate term in stationarity and applying CG04 gives

\[
d_i\le\sum_{j\in\Lambda}C_{ij}d_j+\beta_i,\qquad
\beta_i=\sum_{j\notin\Lambda}C_{ij}{\boldsymbol1}\{\eta_j\ne\zeta_j\}.
\]

The comparison permits exterior block states from different supports because no exterior update is being identified.

## CG07. Uniform first-exit comparison

**ESTABLISHED.** Assume alpha_B<1. Iterate CG06 m times. The remaining term C_Lambda^m d has every component at most alpha_B^m and tends to zero. The other terms sum weights of paths starting at i, staying inside Lambda until their last step, then first exiting at an exterior disagreement. Normalize each transition weight C_ij by alpha_B; the rows have sums at most one. Add a cemetery destination for missing row mass. The weights of the normalized first-exit paths are probabilities of disjoint first-exit events and sum to at most one. Each original path of length l has its normalized weight multiplied by alpha_B^l.

If D(i,Lambda^c) is the block-graph distance to the exterior, all contributing lengths are at least D. Thus d_i<=alpha_B^D. An unreachable exterior has D=infinity and alpha_B^infinity=0. A union bound over a finite target block set T yields

\[
\operatorname{TV}\big((\gamma_{\Lambda,\sigma}^{\eta})_T,
(\gamma_{\Lambda,\sigma}^{\zeta})_T\big)
\le \min\left(1,\sum_{i\in T}\alpha_B^{D(i,\Lambda^c)}\right).
\]

The same bound compares any two finite laws whose volumes contain a common interior Lambda and whose constraints agree on it: condition both on their fine exteriors to Lambda and integrate the uniform comparison against the product of their boundary mixing laws. No compatibility between those exterior assignments is needed. This is the comparison used when remote parity constraints differ or are absent.

## CG08. A unique infinite constrained law for every pattern

**ESTABLISHED.** Fix any entire constraint pattern sigma, allowing any mixture of prescribed signs and absent constraints. Exhaust the block inventory by Omega_W for increasing centered coarse squares W. Use any fixed fine exterior on each finite volume. By CG07 and the anchor distance in CG01, every finite block marginal is a Cauchy sequence uniformly in those boundary assignments. Its limit is a normalized law on its finite product support. Finite summation gives consistency between these limits; successive conditional lower bounds xi_B give positive mass to every locally admissible assignment. Forbidden local assignments retain mass zero.

Here is the required countable extension explicitly. Enumerate the blocks. To a finite prefix assign a half-open interval of length its limiting probability, and divide that interval into consecutive child intervals with the probabilities of its allowed next states. Consistency makes the child lengths sum to the parent length. Starting from [0,1), each point determines one nested sequence of block states. Cylinder preimages are finite unions of half-open intervals. The measurable pushforward of Lebesgue interval measure therefore gives a countably additive law nu^sigma with those marginals. Agreement on all cylinders determines the law: the class of agreement events is a lambda system containing the intersection-closed cylinder class. To justify the extension, take the smallest such lambda system, first fix a cylinder and extend closure of intersection with that cylinder by nested differences and disjoint unions, then fix an arbitrary member and repeat. This makes the smallest lambda system closed under intersections. Complements and decomposing countable unions into disjoint differences then make it a sigma algebra, so it contains the generated product sigma algebra.

The finite constrained update on any fixed block set maps a cylinder function to another cylinder function, since only finitely many neighboring blocks occur. Pass finite compatibility to the cylinder limit. The measures nu^sigma and its updated law agree on all cylinders and hence everywhere. The update leaves the exterior fixed; multiplying by any bounded exterior-measurable function proves the conditional-expectation DLR identity. Thus nu^sigma is genuinely a Gibbs law for the constrained block specification.

For any two such DLR laws, their target marginals are mixtures of finite constrained specifications. CG07 bounds their difference by the receding-boundary expression, which tends to zero. They agree on all cylinders and therefore coincide. This proves uniqueness for every prescribed pattern, without an invariance assumption on that pattern. The same argument compares nu^sigma and nu^tau whenever the patterns coincide on a finite interior Lambda, using exactly the bound in CG07. It also compares a finite oracle with the infinite law, uniformly in its fine boundary.

An infinite parity pattern is not assigned a positive probability under the original law and is not conditioned upon by division by that probability. Its constrained law is the explicit limit just constructed.

## CG09. Finite parity conditioning equals a support change

**ESTABLISHED.** Start with nu^sigma and select finitely many currently unconstrained path blocks. The event E prescribing their parities has positive probability: an admitted assignment with the requested parities has positive probability on those finitely many blocks. Condition nu^sigma on E. In the conditional law of any finite block set, split E into its inside and outside block factors. Its outside part is fixed under the conditioning; its inside part restricts exactly those local parity fibers. Finite normalization gives the specification with the updated support pattern sigma^E. Consequently nu^sigma(.|E) is DLR for sigma^E and equals nu^(sigma^E) by CG08.

With every path unconstrained, the original infinite fine Gibbs law satisfies this block specification by its finite-edge DLR law on unions of whole blocks. Hence it equals nu^* by CG08. Finite observed coarse parity conditionings of the original pushed law are therefore precisely the constrained laws with those finitely many fibers prescribed.

## CG10. The everywhere-defined coarse kernel

**DEFINITION AND ESTABLISHED.** A coarse cell x carries Y_x=(Y_(x,1),Y_(x,2)) in {-1,+1}^2, an alphabet of four states. Each component is the parity of its retained path. For a finite coarse cell set Delta and an exterior cell configuration y, define sigma^(Delta,y) by leaving both paths in Delta unconstrained, prescribing every other retained path its corresponding component of y, and leaving unused singletons unconstrained.

Let gamma'_Delta(y) be the distribution of Y_Delta under nu^(sigma^(Delta,y)), with the exterior coarse variables fixed to y. CG08 defines this kernel for every exterior pattern. It is normalized, uses the full parity marginal, and does not depend on the unused value of y inside Delta. The empty-set kernel keeps the entire configuration fixed. Measurability and continuity of its finite rows are established quantitatively in CG12; no almost-sure conditional version is assumed in its definition.

## CG11. Uniform coarse nonnullness from a free straight path

**ESTABLISHED.** Set

\[
\rho=\tanh(h+2J)
=\frac{b(1+c^2)+2c}{1+c^2+2bc}<1,\qquad
\kappa_B=\frac{1-\rho^B}{2}>0.
\]

Fix an unconstrained retained path and condition a constrained fine law on every other block state. CG01 shows that no plaquette contains two of its edges. Its conditional row is therefore a product of B Bernoulli signs, each with conditional field of absolute value at most h+2J. Its parity mean has absolute value at most rho^B. Each parity sign consequently has conditional probability at least kappa_B. The DLR identity and averaging give the same bound after conditioning on any information determined by the other blocks, including any previously revealed other path parities.

Reveal the 2|Delta| target path parities successively under nu^(sigma^(Delta,y)). All their fine supports are disjoint and the currently revealed path is unconstrained. Repeated conditional lower bounds give

\[
\gamma'_\Delta(Y_\Delta=a\mid y)\ge
\kappa_B^{2|\Delta|}
\]

for every target assignment and every exterior y. The one-cell lower bound is kappa_B^2 for each of its four states. It concerns unprescribed target paths, not a path whose parity was already fixed. The older, weaker constant (1-rho^ceil(B/7))/2 is also valid but is unnecessary here. This stronger straight-path argument changes no old artifact.

## CG12. Explicit coarse continuity and finite-oracle error

**ESTABLISHED.** Suppose two exterior coarse configurations y,z agree on W minus Delta, where Delta subset W. Their support patterns sigma^(Delta,y) and sigma^(Delta,z) agree at every block in Omega_W: target paths are free in both, other paths are identically prescribed, and singletons are free. Apply CG08/CG07 to the 2|Delta| target path blocks and then marginalize to their parities. With d=d_infinity(Delta,W^c),

\[
\operatorname{TV}\big(\gamma'_\Delta(\cdot\mid y),
\gamma'_\Delta(\cdot\mid z)\big)
\le\min(1,2|\Delta|\alpha_B^d).
\]

If the exteriors agree throughout a radius-R neighborhood of Delta, excluding Delta itself, one may take d>=R+1. The error tends to zero uniformly over every exterior, proving continuous finite conditional rows on the product topology and therefore measurability of the proper coarse kernels. More generally one may use the exact sum of block-distance powers from CG07.

For an executable finite conditional oracle, choose any finite union Lambda of whole blocks containing the target paths. Prescribe the desired exterior coarse parities on retained paths in Lambda outside Delta, leave target paths and unused singletons free, and use any fixed fine exterior eta. Its exact parity marginal differs from gamma'_Delta by at most the CG07 sum over target paths, provided its interior constraints match sigma^(Delta,y). In particular Lambda=Omega_W gives the preceding min(1,2|Delta|alpha_B^d) bound. Boundary parities outside the finite oracle need not be enumerated or imposed on eta. A finite volume missing part of a target or prescribed path does not meet this interface.

There are two distinct resource counts. Omega_W contains 2B^2|W| fine edges, whereas a tiny permitted oracle may use a much smaller arbitrary block union. The rectangular error theorem does not require enumerating a rectangular volume in the tiny test packet.

## CG13. Quantitative one-cell log continuity

**ESTABLISHED.** For a single target cell, CG11 gives every conditional probability at least kappa_B^2. If two exteriors agree through radius R, CG12 gives an absolute difference of any atom probability at most 2 alpha_B^(R+1). The elementary integral identity log p-log q=integral_q^p (1/t)dt therefore gives

\[
|\log\gamma'_{\{0\}}(a\mid y)
-\log\gamma'_{\{0\}}(a\mid z)|
\le \frac{2\alpha_B^{R+1}}{\kappa_B^2}.
\]

For two specified cell states a,a_0, the log conditional odds have variation at most 4 alpha_B^(R+1)/kappa_B^2 by the triangle inequality. The bounds also apply to log densities relative to uniform four-state reference, whose additive log 4 cancels. These are the local specification inputs available to the root potential construction. They do not themselves identify a potential or prove a thermodynamic limit.

## CG14. Coarse specification consistency on every exterior

**ESTABLISHED.** Take Delta subset Gamma and fix the coarse exterior y of Gamma. Under nu^(sigma^(Gamma,y)), condition on any assignment to Y_(Gamma minus Delta). It has positive probability by CG11. CG09 identifies the resulting law with nu^(sigma^(Delta,z)), where z combines that assignment and y. Thus the conditional distribution of Y_Delta inside gamma'_Gamma is exactly gamma'_Delta for the completed exterior, at every possible configuration.

Finite summation gives gamma'_Gamma gamma'_Delta=gamma'_Gamma, with the convention that kernels act on functions by conditional expectation. Properness also gives gamma'_Delta gamma'_Gamma=gamma'_Gamma: gamma'_Gamma f depends only on the exterior of Gamma, which a Delta update cannot change. Thus both orders have the required larger-volume conditional result. The identity is pointwise in the entire exterior, not merely an almost-sure statement inherited from the original pushed measure. This is the required consistent coarse specification.

## CG15. Equality with the full pushed law

**ESTABLISHED.** Let mu_B be the full pushforward of the original fine law under all retained paths. For a finite target Delta and an increasing finite set W of other coarse cells, all events Y_W=y_W have positive probability. By CG09, the ordinary finite conditional distribution
mu_B(Y_Delta=a | Y_W=y_W) is the parity marginal of the fine constrained law with exactly those W fibers prescribed. Its support pattern agrees with sigma^(Delta,y) on Omega_(W union Delta); CG07 therefore makes these conditional rows converge uniformly to gamma'_Delta as W fills the exterior with increasing spatial margins.

No conditional-probability limit theorem is needed to identify the kernel. If G is an exterior cylinder event supported in some fixed W_0, ordinary finite conditioning gives
E_muB[1_G 1_(Y_Delta=a)]=E_muB[1_G g_W(Y_W)]
for every larger W, where g_W is the finite conditional row. Uniform convergence permits passage to the right-hand limit E_muB[1_G gamma'_Delta(a|Y)]. Extend the equality from exterior cylinders to all exterior events by the same pi-lambda argument as in CG08. This proves the conditional-expectation DLR identity for mu_B with the everywhere-defined kernel gamma'_Delta. It is the whole pushed law and the whole finite-set specification, not a selected set of moments.

## CG16. Uniqueness of the coarse Gibbs law

**ESTABLISHED.** Let Delta be a large free coarse cell set and let A be a smaller target set. Compare gamma'_Delta under any two exterior configurations. Their fine support patterns agree on every block anchored in Delta, so CG07 gives target parity TV at most
min(1,2|A| alpha_B^d_infinity(A,Delta^c)). Any two coarse DLR laws are mixtures of these gamma'_Delta kernels. Average the uniform comparison against their two exterior laws and let Delta exhaust the coarse lattice. Their finite marginals agree, hence the laws agree. Since CG15 supplies one law, mu_B is the unique coarse Gibbs law for this explicit specification. This assertion does not presume or reconstruct a summable potential.

## CG17. Translation covariance and the raw frame boundary

**ESTABLISHED.** A coarse translation by v transports the entire fine block partition by Bv, its factors and its prescribed signs. Transporting nu^sigma gives a Gibbs law for the transported pattern and therefore, by CG08 uniqueness, that pattern's nu. Consequently gamma' is translation covariant on its four-state coarse cells, and mu_B is stationary.

The two cell signs here are dressed edge parities; no frame multiplicity is hidden in their four-state reference. The original independent uniform vertex frames remain independent under every finite parity conditioning, since the constraints use dressed signs only. For an infinite constrained pattern, attach the same independent uniform product frames to the constructed dressed law; this defines its canonical raw lift without conditioning on an infinite zero-probability event. Retaining the coarse vertices and reconstructing each raw link from its endpoints and dressed parity gives the same gauge-equivariant frame lift as the original channel. Local gauge transformations leave every constraint invariant. The coarse potential and entropy conventions in the root lane must state separately whether these independent frame coordinates are appended.

## CG18. The zero-plaquette-coupling control

**ESTABLISHED.** At c=0 the fine density factors over edges, and the restricted product reference factors over the disjoint blocks. Every constrained block law is independent of the other blocks; uniqueness and boundary independence follow directly without dividing by alpha_B=0. An unconstrained path has independent edge means b, so its parity mean is b^B. The exact coarse law is the product over oriented coarse edges of sign laws (1+b^B s)/2, or the product over cells of the corresponding two-sign laws. The conditional row is independent of the coarse exterior. This is a control of the same full channel and restricted-reference construction, not evidence for the nonzero-c contraction theorem.

## Scope and handoff

**ESTABLISHED AT THE STATED PREMISES.** The direct constrained argument supplies alpha_B=6Bc, the common B=2,3,6 interval c<1/36, all-pattern constrained laws, exact coarse specification consistency, one-cell nonnullness kappa_B^2, and exponential exterior/log-odds continuity with the displayed constants. Reference supports, graph distances and cell normalization are explicit.

**NOT CLAIMED HERE.** No potential reconstruction, summable interaction norm, pressure, entropy-density or infinite VFE formula is established in this lane. A fixed c>0 eventually leaves the proved 6Bc<1 domain as B grows. Neither small unconditional parity bias nor the new fixed-B regularity theorem resolves that all-depth gap. The plaquette factor is a lattice gauge-holonomy interaction. It is not identified here with a Fisher-curvature energy, an action for base geometry, or a continuous connection-curvature functional. Arbitrary nonstationary recognition sequences, criticality, continuum geometry and physical identification remain outside this proof. All implementation and execution claims require their separately owned evidence.
