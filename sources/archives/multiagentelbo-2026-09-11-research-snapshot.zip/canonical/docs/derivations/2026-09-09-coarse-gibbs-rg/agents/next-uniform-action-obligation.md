<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab","target_digest":"15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab"} -->

# A route toward uniform-in-block-size action regularity

**Status: PROPOSED NEXT TARGET; DISCOVERY ONLY.** Date: 2026-09-09. This intake does not amend the frozen contract or close a theorem. It reads the current constrained and potential constructions and the existing curvature reports linked below. No implementation, test, science producer, literature search or change to a frozen artifact was performed. The author shares the model and filesystem with the root and authored the constrained proof; this is a proposed research route, not an independent correctness certificate.

## The remaining action quantifier

The current result supplies the exact coarse specification, an explicit summable potential, and stationary specific-objective limits for each B satisfying 6Bc<1. The next target should retain one fixed positive c while B is unbounded. This concerns the full interaction and its tails. The earlier all-cylinder product limit, exact path composition and finite normalized-action bounds already address their own quantifiers and should not be presented as missing.

A concrete stronger target is as follows. Fix 0<b_-<=b<=b_+<1. Derive c_*(b_-,b_+)>0, independent of B, and positive constants C,eta,nu on a declared compact positive-c subdomain. For every B>=1 and every two coarse exteriors agreeing through radius R, prove that the one-cell log-odds variation is bounded by

\[
C e^{-\eta B}e^{-\nu R}.
\]

The theorem must cover every exterior, including rare parity patterns. Together with a matching one-cell reference-row bound, the root's explicit shell construction would have to give a fixed-convention interaction satisfying

\[
\sum_{A\ni0}e^{\lambda\operatorname{diam}(A)}
\|\Phi_A^{(B)}\|_\infty\le C' e^{-\eta' B}
\]

for some lambda>0 and eta'>0 independent of B. The next proof must justify this transfer, including the polynomial shell counts; the display is a target, not an established estimate. A weaker explicit B-decaying prefactor with summable spatial tails would also be useful if declared as the actual target before adjudication. Potential representatives, normalized references and the distinction between per cell and per edge must remain fixed.

## Proposed mechanism: expand after exact parity-fiber normalization

Replace the worst-case TV distance of an entire B-bit block by an expansion that retains how a coarse parity can respond. The crude row bound pays for all B separate fine-edge perturbations, even when most perturbations convey almost no information about their product. The proposed route integrates the c=0 biased edge product exactly on each parity fiber, then expands only the plaquette factors in c. Its local reference is a product over constrained paths and unused singleton edges, with the same supports as the current construction.

The first finite algebra obligation is to verify and retain, for a path P, a subset S of r path edges and parity y, the identity

\[
\mathbb E_{b}\left[\prod_{e\in S}z_e\mid\prod_{e\in P}z_e=y\right]
=\frac{b^r+y b^{B-r}}{1+y b^B}.
\]

This exposes information lost by replacing each constrained row with one undifferentiated TV influence. For fixed b<=b_+<1 the denominator has a uniform positive lower bound. A plaquette cluster contacting only a small fraction of the path leaves a long unused factor in the parity-sensitive part of the expression. A cluster contacting a large fraction must contain many plaquettes, because one elementary plaquette contacts at most one edge of that path. The proposed proof would trade the former case against powers of b and the latter against powers of c.

The hard obligation is to turn this contact accounting into an absolutely convergent expansion of normalized conditional log ratios, uniformly in B and all exterior signs. The activity of connected contributions must include their spatial support and their dependence on a target parity; the proof cannot estimate the numerator and an exponentially rare entire conditioning event separately. Disconnected fine plaquette sets may become linked through a single constrained path fiber. They therefore cannot be discarded by simply using the ordinary fine-lattice connected-cluster inventory. Their cumulants or equivalent resummation need an explicit bound, and the combinatorial constant must be independent of B. Otherwise the argument merely recreates 6Bc under another notation.

A viable theorem would combine fine-plaquette adjacency of bounded degree with the parity-sensitive contact weights, obtaining a positive domain such as a derived inequality involving b_+ and a constant times c. No such inequality or constant is assumed here. The c=0 product coarse law is an exact control. A separate b=0 two-dimensional flux computation could be informative if admitted and derived, but a boundary or torus-sector reduction must not be assumed from a remembered duality. Nonzero b and c remain essential to the target's gauge-matter coupling.

This route changes the estimated object, rather than making a smaller numerical estimate of the same block-TV row sum. An alternative weighted-disagreement proof would be acceptable only if it closes an observable-sensitive metric under updates and derives spatial decay; the already available uniformly small parity bias alone does not do so.

## Decisive obligations and failure interpretation

The next contract should require a finite-volume normalized expansion with every constrained reference factor retained, a uniform contact/connectedness estimate, and a spatial tail bound for conditional log ratios. It should then pass those ratios to every infinite exterior and bind the resulting specification to the unchanged pushed law before reconstructing the potential. Finite-volume coefficient comparisons can later check algebra, but cannot establish convergence or all-exterior regularity.

A concrete pair of coarse exteriors agreeing on arbitrarily large neighborhoods while their conditional rows remain separated would obstruct quasilocality at that parameter and block size. Failure of one proposed expansion criterion would only reject that route or its certified domain. A coefficient bound growing with B would fail the proposed uniform estimate, not refute every possible interaction representation. Conditional-sign cancellations, hard-constraint hidden phases and dependence on selected fine boundaries must remain explicit possibilities until the proof excludes them. No fitted plaquette truncation or sequence of small finite TVs resolves these obligations.

If a cluster or resummation theorem is imported, the later run must read its full primary statement and map restricted supports, sign-changing expansion coefficients, translation covariance, uniform activity norms and normalization of conditional ratios. No imported theorem is used by this intake.

## Curvature steering builds on delivered finite models

The existing [curvature/base report](../../../reports/2026-09-08-curvature-base-and-renormalization.md) already supplies normalized finite gauge-action and random-base-curvature models, including their entropy and partition terms, generated interactions under matter elimination, and a nonidentity base descent. The [holonomy-inference report](../../../reports/2026-09-09-holonomy-curvature-inference.md) supplies a latent curvature label learned through a normalized loop likelihood, preserving conditional Gaussian laws and the complete field VFE. The [metric-quotient report](../../../reports/2026-09-09-metric-quotient-curvature.md) supplies the metric-dependent quotient connection, its projector curvature term and composition when the quotient metric is propagated. These are existing inputs, not proposed missing implementations.

What is not supplied by the current uniform-action target is an identification among those geometries. The lattice plaquette term is a discrete gauge-holonomy interaction. Fisher curvature belongs to a specified statistical-family connection, and the existing curved-simplex control shows why it is not an automatic VFE penalty. The base-curvature examples use separately declared metrics and normalized probabilistic roles; the metric-quotient utility does not identify an arbitrary context cover with a nondegenerate base manifold.

A later curvature bridge could place one declared parameterized gauge/holonomy family through the uniform RG interaction map and control its parameter derivatives before defining a limiting Fisher-information density or curvature. It would require those derivative, identifiability, metric and connection hypotheses, not merely the existence of an interaction limit. The finite holonomy-inference and base/quotient constructions should be reused where their assumptions apply. This proposal does not erase their completed scope, create a universal three-curvature action, or claim a continuum or physical identification.
