<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab","schema_version":"rigorous-theory-search/v1","target_digest":"15cbf8c36c2609fa554cce75e6b1cd8fee72530af1387591efda30d134e6f5ab"} -->

# Independent coarse Gibbs reconstruction

## Revision 1: Contract-only derivation

The frozen contract and the previously admitted spatial construction are the starting points. This record was derived before opening any new root, author or implementation proof/source for the coarse-Gibbs task. Shared model, instructions and filesystem limit independence. Incoming preflight descriptions are not used as mathematical premises. No tests, field enumeration, scientific producer or ledger closure is performed by this lane.

The mechanisms are whole-block restricted-support comparison, an explicit lexicographic telescoping interaction, and elementary entropy/pressure tiling. Write h=atanh(b), J=atanh(c). The following sufficient interval is nonempty for every fixed B: 0<c<1/(6B). Its common domain for B=2,3,6 is 0<c<1/36. This is a fixed-block result, not a uniform all-depth interval at fixed positive c.

### ICG01. Block partition and local parity references

Partition all fine edges into each retained straight B-edge path and each unused singleton. No path edges repeat, so this is a genuine disjoint partition. A path block has either its full sign support (no constraint), or the half-support with product +1 or -1. A singleton may be unconstrained or fixed to a sign if such a local constraint is admitted. Every local support is nonempty, including B=1, where a prescribed parity makes a singleton support. An absent constraint and a prescribed parity are different objects.

Conditioning normalized fine counting on r independent prescribed path parities gives a normalized reference on the allowed fiber, with atoms 2^{-(n-r)}; the ambient probability of the fiber is 2^-r. The constrained Gibbs law is proportional to the original positive factor weight on this support. Conditional-reference normalizers alone cannot be compared between events with different numbers of imposed parities without retaining that ambient 2^-r. Ratios between complete assignments to the same target parities have the same reference factor, which cancels. A raw sum over fine weights with the appropriate indicator keeps the factor automatically.

Each fine edge belongs to at most two plaquettes. Assign each retained path block to its coarse starting cell, and each unused singleton to the coarse cell containing its fine anchor, using componentwise floor division by B. A path's fine anchors remain in that B-cell. Since plaquette edge anchors differ by at most one fine step, blocks sharing a plaquette have coarse cell coordinates at sup-norm distance at most one. There are finitely many blocks per coarse cell: two paths and 2B^2-2B unused singletons. Finite constrained volumes must contain whole blocks, including all those anchored in the chosen cell window; cutting a constrained path changes the model.

### ICG02. Oscillation bound without the extra factor two

Let p and q be positive probabilities on one COMMON finite support, with p(x)=q(x) exp(f(x))/E_q exp(f). If f has oscillation R=max f-min f, then TV(p,q)<=tanh(R/4). A direct proof sets W=exp(f), m<=W<=M, u=E_q W. The chord bound for |W-u| gives E_q|W-u|<=2(M-u)(u-m)/(M-m). Therefore TV<= (M-u)(u-m)/((M-m)u), maximized at u=sqrt(mM), where it equals (sqrt(M)-sqrt(m))/(sqrt(M)+sqrt(m))=tanh(log(M/m)/4).

When the exterior state of another block changes, each affected plaquette contributes a change of log weight equal to plus or minus 2J times a sign character of the updated block. Its oscillation over the updated block's restricted support is at most 4J, regardless of the parity restriction. Changing one plaquette contribution thus changes the conditional law by TV at most tanh J=c. Telescoping the affected factors gives at most c N_ij for a change in exterior block j, where N_ij counts plaquettes touching both blocks. The intermediate factor choices need only be positive on the same updated-block support; they need not arise from a single physical exterior configuration.

If block i has at most B edges, sum_j N_ij<=6|i|<=6B: each of its at most 2|i| incident plaquettes meets at most three other blocks. Duplicate counting only weakens this upper bound. Hence the whole-block influence matrix C_ij=c N_ij has row sum at most alpha=6Bc<1. The field b does not enter this variation estimate. A bound from twice the maximum absolute log-weight change without the oscillation/4 inequality can introduce an unnecessary factor two. Conversely using oscillation/2 as if it were oscillation/4 without proving the lemma can claim the wrong coefficient.

Different prescribed parities give different local supports and must not be coupled as if they were a common conditional alphabet. The comparison above updates blocks whose constraint is the SAME in both laws. Differing constraints are put outside the compared interior; their microscopic boundary disagreement is then bounded by one. This is sufficient for exterior regularity and avoids a false common-support claim.

### ICG03. Uniform constrained-field comparison and existence

For a fixed assignment of allowed local supports, every finite union of blocks has positive original factor weight on the product of those supports. Finite conditional compatibility follows by factor cancellation. The full-block heat bath has that finite constrained Gibbs law as its unique stationary distribution: successive block updates reach every allowed configuration with positive probability. A crude uniform conditional lower bound is 2^-B exp(-2B(h+2J)), since block fields/interactions involving its edges have total bounded oscillation; only positivity is needed for each fixed finite volume.

For two boundaries outside the same finite interior of blocks, with identical constraints inside, couple a common selected-block update maximally. A stationary finite coupled chain exists by Cesaro averages. Its marginals are the unique constrained finite Gibbs laws. At stationarity disagreements satisfy d<=C_inside d+beta, with beta from exterior disagreements. The previous spatial first-exit proof applies word for word to this block matrix: normalize by alpha, regard missing row mass as cemetery killing, and sum disjoint first-exit paths. It gives d_i<=alpha^{D(i,inside^c)} and cylinder TV at most the sum over its observed blocks.

Growing unions of whole blocks thus have unique boundary-independent cylinder limits for any complete assignment of parity supports. The countable interval-splitting construction extends those consistent finite laws, and finite-range factor cancellation passes to the limit to prove their DLR equations. Uniqueness follows by comparing any two DLR boundary mixtures. These statements remain valid when constraints vary arbitrarily with coarse position; translation invariance of the constrained field is not assumed. In the c=0 control the blocks are directly independent on their restricted supports, so no division by alpha=0 is needed.

### ICG04. Everywhere coarse kernels, positivity and consistency

For finite coarse cell set A and an arbitrary exterior parity pattern eta, constrain both path parities at every coarse cell outside A to eta, leave the target paths in A unconstrained, and leave unused singleton blocks unconstrained. Define Gamma_A^eta as the law of the target path parities in the unique constrained fine field from ICG03. This definition applies to EVERY eta, not an almost-sure conditional version.

The finite-energy bound on each original fine sign is epsilon_f=(1-tanh(h+2J))/2>0. Target path edges are unconstrained and disjoint from every exterior parity constraint. Conditioning on all other fine edges leaves their original finite positive law. A specified assignment of the 2B target fine edges at one coarse cell has probability at least epsilon_f^(2B), by successive conditional probabilities. Thus every four-state coarse-cell row has a uniform lower bound kappa=epsilon_f^(2B)>0. This is a deliberately conservative bound, valid even with arbitrary exterior parity constraints. Finite collections of coarse targets are likewise positive.

If Delta subset A, conditioning the A-constrained fine law on a prescribed target parity pattern in A minus Delta imposes only additional local block constraints. Direct finite conditional factor cancellation shows this conditioned law is DLR for the new support pattern. It equals that new constrained fine law by ICG03 uniqueness. Therefore conditioning Gamma_A on A minus Delta yields Gamma_Delta with the completed coarse exterior. This proves finite-set specification consistency, not only a collection of single-cell rows.

If two coarse exteriors agree in the cell cube Q_R around a target cell, their constrained fine specifications have identical supports in the block window anchored there. The block-cell graph changes sup-norm location by at most one per step. ICG03 and the two target path blocks consequently give the safe uniform variation bound TV(Gamma_i^eta,Gamma_i^xi)<=min(1,2 alpha^R). More generally a fixed finite target has twice its cell count as a prefactor, with its own distance to the window exterior. Arbitrary fine boundaries on that finite whole-block window give the same approximation error to the infinite constrained row, because the bound is uniform in microscopic exterior values. There is no numerical spatial-convergence premise.

To identify Gamma with the existing pushed law mu_B, first condition the fine source law on finitely many exterior coarse parities. The event is positive by the admitted finite-energy bound; its fine conditional law is DLR for those finitely constrained blocks, hence is the unique partially constrained field. Its target row differs from Gamma by the same uniform window error. For an exterior coarse cylinder test g, the ordinary conditional identity holds for all windows containing its support. Pass to the uniform limit; then extend from cylinder tests by bounded monotone limits. This proves the coarse DLR identity under mu_B without choosing a special exterior version or invoking an unverified martingale theorem.

### ICG05. Explicit translation-invariant telescoping potential

Use alphabet S={(-1,-1),(-1,+1),(+1,-1),(+1,+1)} on coarse cells, normalized counting reference of mass 1/4, and vacuum a0=(+1,+1). Fix the translation-invariant lexicographic order on Z^2. For a configuration omega define a hybrid outside i: keep omega_j at j>i, set every j<i to a0. Set

H_i(omega)=log[Gamma_i(a0 | hybrid)/Gamma_i(omega_i | hybrid)].

The uniform row lower bound kappa makes |H_i|<=log(1/kappa). Its variation when hybrid exteriors agree in Q_R(i) is at most 4 alpha^R/kappa: each of the two log probabilities changes by at most the row TV divided by kappa. Also H_i=0 whenever omega_i=a0.

Let H_i^r retain only future sites in Q_r(i) and set every other exterior sign to a0. H_i^0 depends only on omega_i. Put A_(i,r)={i} union {j>i:j in Q_r(i)}, define Phi_{A_(i,0)}=H_i^0 and, for r>=1,

Phi_{A_(i,r)}=H_i^r-H_i^(r-1).

Each term is a finite-cylinder function with vacuum value zero. The anchor is its lexicographically minimal site, so translated supports have unambiguous anchors. These supports grow strictly with r. Translation of the configuration translates the specification, order, vacuum and sets together, giving a translation-invariant interaction.

For r>=1, ||Phi_{A_(i,r)}||<=4 alpha^(r-1)/kappa. At most |A_(0,r)|<=(2r+1)^2 translated supports of this shape contain the origin. Therefore the interaction norm sum_{A contains 0}||Phi_A|| is at most log(1/kappa)+(4/kappa) sum_{r>=1}(2r+1)^2 alpha^(r-1), which is finite. Since diam_infinity A_(i,r)<=2r, an exponential norm with weight exp(a diam A) is finite for every 0<a<-(log alpha)/2. This states the multiplicity explicitly; bounding only one anchored term is not the per-site summability proof.

### ICG06. Exact Gibbs ratios, not merely an approximating potential

For a configuration omega differing from vacuum only on finite K, terms anchored outside K vanish because their central spin is a0. Thus the total interaction energy equals sum_{i in K} H_i(omega), by telescoping in r. Starting from vacuum and changing K in descending lexicographic order, the current outside at each change is precisely the hybrid used in H_i. Specification consistency gives the finite-flip identity

sum_A Phi_A(omega) = -log[Gamma_K(omega_K | vacuum)/Gamma_K(vacuum_K | vacuum)].

Take two such configurations differing only in Lambda. Their energy difference is the negative log ratio of Gamma_Lambda at the same exterior, by consistency. Now truncate an arbitrary pair with common exterior to vacuum outside a growing cube. Quasilocality of Gamma_Lambda passes the kernel ratio to its everywhere-defined limit. Absolute summability passes the interaction energy difference to its limit, dominated by 2 sum_{A intersects Lambda}||Phi_A||<infinity. The resulting equality is the exact finite-modification ratio for every exterior pattern.

Normalized finite Gibbs kernels of Phi are determined by these ratios and positivity. They therefore equal Gamma everywhere, and the constructed potential has the original full pushed law mu_B as a Gibbs law. No interaction fitting, selected-statistic equality, or unproved potential-reconstruction theorem is used. It is not necessary to assign a globally finite infinite-volume energy sum to every configuration.

### ICG07. Boundary estimates and normalized-reference pressure

Write N_Phi=sum_{A contains 0}||Phi_A||. In a finite cell square Lambda define the free Hamiltonian H_Lambda^0=sum_{A subset Lambda}Phi_A and Z_Lambda^0=E_{U_Lambda} exp(-H_Lambda^0). Let M_Lambda=sum_{A intersects Lambda,A not subset Lambda}||Phi_A||. Boundary-conditioned Hamiltonians differ from H_Lambda^0 by at most M_Lambda, uniformly in all configurations.

For a fixed range R, crossing interactions of diameter at most R touch the R-boundary layer. The remainder is bounded using the norm tail N_tail(R). Hence

M_Lambda/|Lambda| <= N_Phi |boundary_R Lambda|/|Lambda| + N_tail(R).

First enlarge squares and then send R to infinity. This proves M_Lambda=o(|Lambda|); exponential tails can give a stronger surface estimate, but the subextensive statement suffices.

For finite-range Phi, tile a large square by fixed side-l squares and a remainder. Removing interactions crossing tile boundaries and meeting the remainder changes the log partition by at most a constant times the R-boundary fraction plus the remainder fraction. The normalized reference factors over tiles, so the partition of the disconnected tiles is their product, without an extra 4^|Lambda|. As the large size tends to infinity and then l tends to infinity, limsup and liminf of |Lambda|^-1 log Z_Lambda^0 agree. Finite-range truncations converge uniformly in this normalized pressure because |log Z_Lambda(Phi)-log Z_Lambda(Phi^R)|<=|Lambda| N_tail(R). Thus the full pressure p_Phi exists. Any boundary-conditioned partition has the same limit by the M_Lambda bound.

A normalization control exposes the additive convention. At c=0, each coarse edge has independent mean m=b^B. One cell has density f(s)=(1+m s_1)(1+m s_2) relative to U_4. The vacuum-zero potential is Phi_i(s)=-log[f(s)/f(a0)], so its normalized-reference pressure is -log f(a0)=-2log(1+m), not zero. Its Gibbs density is still exactly f. A normalized marginal action and a vacuum-normalized unnormalized interaction have different normalizers; energy plus pressure preserves the correct law.

### ICG08. Stationary entropy and specific energy

For any single stationary recognition law q on S^{Z^2}, entropy of a large square is at most the sum of entropies of its disjoint side-l tiles plus |remainder| log 4. Stationarity identifies every tile entropy. Therefore limsup_N H(q_LambdaN)/|LambdaN|<=H(q_Lambdal)/|Lambdal| for every l. The infimum over l is a lower bound on every term of the sequence, proving existence of

h(q)=lim_N H(q_LambdaN)/|LambdaN|=inf_l H(q_Lambdal)/|Lambdal|.

No ergodicity or mixing of q is required. Absolute summability and stationarity give the specific interaction energy

e_Phi(q)=sum_{A contains 0}|A|^-1 E_q Phi_A.

Counting translates whose support fits inside Lambda and then applying dominated convergence proves |Lambda|^-1 E_q H_Lambda^0 -> e_Phi(q). In the anchored construction this also equals sum_r E_q Phi_{A_(0,r)}. The factor 1/|A| in the origin-containing representation is necessary to count each interaction once.

### ICG09. Specific relative entropy and finite-likelihood VFE

Because mu_B is DLR for Phi, its Lambda marginal is a mixture of the boundary-conditioned kernels. Their density ratio to the free kernel lies between exp(-2M_Lambda) and exp(2M_Lambda): one factor bounds the Hamiltonian correction and one bounds the partition correction. The same pointwise bound survives boundary mixing. Consequently

D(q_Lambda||mu_B,Lambda) = -H(q_Lambda)+|Lambda| log4+E_q H_Lambda^0+log Z_Lambda^0+O(M_Lambda),

with absolute error at most 2M_Lambda. Every finite marginal is positive, so this algebra is defined even when the infinite laws are mutually singular. Divide by volume and use ICG07-ICG08 to obtain

h(q||mu_B)=log4-h(q)+e_Phi(q)+p_Phi.

At q=mu_B, the finite KL is identically zero, so p_Phi=h(mu_B)-log4-e_Phi(mu_B). Nonnegativity for arbitrary stationary q also gives the associated stationary variational inequality. None of these formulas is the total infinite-law KL.

Let a fixed homogeneous finite-alphabet kernel ell(y|x_K)>0 be normalized in y and depend on finite cell support K. The observation value y0 is fixed at every center i with i+K inside Lambda. Appending the product of those conditional kernels gives a normalized finite observation joint. Its negative ELBO under q_Lambda is

F_Lambda(q)=D(q_Lambda||mu_B,Lambda)-sum_{i:i+K subset Lambda} E_q log ell(y0|X_(i+K)).

The finite alphabet and positivity bound the logarithm. Stationarity makes its expectation independent of i, and the retained-center fraction tends to one. Thus the per-cell VFE exists and equals h(q||mu_B)-E_q log ell(y0|X_K). This formula includes the likelihood normalization; it is not a posterior-KL formula with the log evidence silently dropped. Per-edge values divide the per-cell expression by two for the declared two-edge cell inventory. Raw-frame lifts require a separately declared alphabet/reference or recognition lift rather than silently changing log4 to log8.

### ICG10. Attacks, boundaries and remaining interface checks

A path parity is a hard support condition. Updating a single fine edge while freezing the other edges of its constrained path generally has no allowed flip; an unconstrained single-edge Dobrushin argument cannot be reused for that dynamics. Whole-block updates and unchanged interior supports remove this obstruction. Boundary cells that cut a B-path do not implement the declared block conditioning.

A log-potential increment of exponential size is not enough by itself: the number of translated supports touching one site must be included. The explicit (2r+1)^2 factor supplies that missing summability step. Equality of vacuum-relative energies only for finitely supported configurations is also insufficient until uniform conditional continuity and absolute energy-difference summability pass it to arbitrary exteriors. ICG06 supplies that passage.

Small conditional bias alone gives no spatial variation modulus. Here the independent constrained-block comparison supplies one. Coarse null or exceptional exterior patterns are not removed: every pattern defines a nonempty product of local supports and the uniform construction applies to it. The limiting row is continuous everywhere, while its identification as a conditional under mu_B remains the usual almost-sure identity.

Stationarity refers to one recognition law, not unrelated stationary preparations chosen separately at each volume. With no observations, alternating mu_B marginals and deterministic all-vacuum marginals can make normalized finite KL fail to converge: the first values are zero, while uniform nonnullness bounds the deterministic cylinder probability exponentially away from one. Such a sequence is outside the admitted q contract. An arbitrary nonhomogeneous observation pattern can also lack a limiting spatial average.

The current proofs provide a nonzero fixed-B interval and c<1/36 for the {2,3,6} gate. The factor alpha=6Bc deteriorates with B, so this is not an all-depth potential theorem at one fixed positive c. No novelty, continuum, physical-time or universal RG identification follows. The remaining checker work is source/author correspondence and final artifact interfaces after announcing this independent record. No favorable numerical outcome is used above.


## Revision 2: Subsequent author and source reconstruction

After revision 1 was durable and announced, this lane read the complete constrained-gibbs-construction.md (CG01-CG18), potential-vfe-construction.md (CP01-CP10), finite coarse source and implementation preflight. The draft hashes are recorded below. The authors and checker still share model and filesystem; this is a later correspondence check rather than a second contract-only derivation. No tests or scientific source were executed.

CG01-CG10 match the initial block/reference/variation/constrained-law construction. CG03 proves the one-factor bound by partitioning the restricted support according to its sign character and computing the exact two-class tilt TV; this is a different direct specialization of ICG02's oscillation/4 proof, with the same coefficient c. Empty character classes correctly give zero variation. CG04 restricts the update comparison to a common local support, with different exterior supports only in forcing. CG05's xi_B is exactly the exponential lower bound in ICG03 written in rational coupling ratios. CG06-CG08 apply maximal block coupling and disjoint first-exit weights to constrained product supports, with proper countable extension and DLR identification.

CG09 supplies the explicit finite-event split needed in ICG04: when finitely many currently free path parities are prescribed, the conditioning event factors into inside and outside block indicators in each conditional window. The outside indicator is constant there; the inside indicators restrict exactly the corresponding local supports. Positivity and uniqueness identify that conditional field with the new support-pattern law. This is not conditioning on an infinite event of positive probability. CG14 then establishes the nested finite-set kernel identity for every exterior. Its reverse composition follows from properness because the larger-volume update depends only on the exterior left fixed by the smaller update.

CG11 strengthens the conservative ICG04 nonnullness bound. A straight B-path has at most one edge in any plaquette, so the entire path is an independent set after the other fine blocks are fixed. Its unconstrained conditional parity mean is the product of B sign means, with magnitude at most rho^B. The per-parity lower bound is kappa_B=(1-rho^B)/2, and two sequential parities give the four-state cell lower bound m=kappa_B^2. CG12's block-anchor distance gives the sharper row variation 2 alpha_B^(R+1); dividing atom differences by m gives CG13's log-probability bound and twice that value for log odds. The initial weaker constants remain valid. These strengthened constants do not require altering any earlier spatial artifact.

CG15 identifies the entire original pushed law through finite parity conditionings and a uniform row limit, then extends the exterior cylinder-test identity. This independently agrees with ICG04. CG17 keeps the four-state dressed-cell reference separate from appended frame signs and proves translation covariance by transporting the entire constrained specification. CG18 handles c=0 directly, avoiding division by alpha_B=0.

### ICG11. Coarse Gibbs uniqueness from large free coarse sets

CG16 adds a useful conclusion not needed in the initial construction of a potential. Its proof can be reconstructed without trying to lift an arbitrary coarse law to fine variables. Let Delta be a large free coarse set, and A a fixed small target inside it. Under any two exterior coarse patterns, the defining constrained fine support patterns agree on every block anchored in Delta, because all its retained parities are free. The block comparison gives TV at A at most 2|A| alpha_B^d_infinity(A,Delta^c), capped at one. Any two DLR laws for the coarse specification are mixtures of those same Gamma_Delta kernels. Averaging the pairwise comparison and sending Delta outward makes every fixed marginal agree. Cylinder uniqueness identifies the laws. Since the original pushed law is already DLR, it is the unique coarse Gibbs law for this specification. No extra property of arbitrary fine conditional lifts is required.

### Potential exactness and quantitative thermodynamic checks

CP01 uses the full lexicographic PAST and CP03 flips sites in increasing order; ICG05 uses the future and flips in descending order. These are distinct but equally valid translation-invariant representatives. Both preserve the same normalized finite-modification ratios. CP02 uses the lexicographic maximum to identify each anchored support and explicitly counts at most (2r+1)^2 translations containing the origin. Its increment bound 4 alpha^r/m and exponential weighted norm follow from the sharper author continuity constants. CP03 first proves finite vacuum-relative ratios, then obtains finite-support nonvacuum exterior ratios by consistency and extends them uniformly to every exterior by quasilocality plus absolute summability. No infinite total ordering, unnormalized infinite product or almost-sure-to-everywhere leap is used.

### ICG12. First-moment surface and pressure estimates

The exponential norm implies a finite first diameter moment M=sum_{A contains 0}diam(A)||Phi_A||. Let T(d) be its origin-containing norm tail for diam(A)>=d. A crossing interaction touching a site x inside a square Lambda_L has diameter at least dist(x,Lambda_L^c). Summing tails at all such x overcounts each crossing term, which is legitimate for nonnegative norms. There are at most 4L sites at each positive inner distance, so

b_L <= sum_{x in Lambda_L}T(dist(x,Lambda_L^c)) <=4L sum_{d>=1}T(d)=4LM.

The equality uses integer diameters and a nonnegative series. The conditional/marginal versus free Hamiltonian comparison has two normalizing contributions, so its log-density error is at most 2b_L, not b_L. This verifies CP04's bound 8M/L per cell.

For CP05, tile the lower-left floor(L/n)n square by complete n-squares and call the remaining sites R. Dropping every interaction touching R costs at most |R|K. Dropping interactions crossing tile boundaries costs at most the sum of the tile boundary bounds, at most 4M floor(L/n)^2 n. Every omitted interaction is accounted for, possibly more than once. The reference on R has total mass one and no retained Hamiltonian, so the comparison partition is exactly the product of tile partitions. The elementary exponential sandwich |log Z(H)-log Z(G)|<=||H-G|| gives the displayed estimate. At fixed n, L tends to infinity with R/L^2 tending to zero and tiled area fraction tending to one. Thus both limsup and liminf pressure lie within 4M/n of p_n. Their separation is at most 8M/n for every n, proving existence and |p-p_n|<=4M/n.

For CP07, allocate an interaction's expectation equally to its |A| sites. Summing allocations over Lambda counts every contained interaction once and each crossing interaction with coefficient |A intersect Lambda|/|A| in [0,1]. Translation invariance identifies the allocation per site with e_Phi(q). The omitted allocation is bounded by b_L in absolute value even for signed interaction energies. Thus the uniform energy error is 4M/L. CP06's entropy tiling needs only a single stationary q, not ergodicity. CP08's finite mass formula gives the required signs log4-s(q)+e_Phi(q)+p_lambda; its comparison with the actual marginal costs 2b_L. This checks the full specific-relative-entropy formula, not an ordinary infinite-law KL.

CP09 states an empty-observation-support convention absent from ICG09's initial shorthand. For nonempty finite K, all centers with x+K inside Lambda form a finite inventory with asymptotic density one. For K empty, that condition alone would allow every lattice center, giving an infinite sum. The completed statement takes x in Lambda for empty K. With this explicit convention both cases give the same constant-kernel density formula. ICG09 should be read with this amendment. The finite observation alphabet, positive normalized kernel and stationary common q make the log likelihood bounded and homogeneous. CP10 is a scope/next-bridge statement, not an additional mathematical claim connecting lattice holonomy to Fisher, base or continuum curvature.

### Finite source preflight

The new coarse_gibbs.py source was read completely. geometric_block_partition classifies every horizontal edge on a row divisible by B and every vertical edge on a column divisible by B into its complete straight path; all other edges become singletons. Componentwise floor division handles negative planar coordinates, and periodic admission delegates canonical endpoints/path checks with divisibility and final side at least three. Every path must be wholly present; duplicate and incomplete partitions are rejected. The class also admits arbitrary complete disjoint finite block partitions for finite algebra, but a spatial conditional approximation requires the geometric partition and unused singletons left unconstrained. Constraining an unused singleton in a generic finite test is not an extra observed coarse path.

ParityBlockField stores the actual full FineDressedField, complete block inventory and explicit None/-1/+1 constraint tuple. The private finite loop enumerates candidate assignments, keeps exactly those satisfying the disjoint whole-block predicates, and evaluates the unchanged full raw density after filling other edges. With n enumerated edges and r independent constraints, its allowed-state count is 2^(n-r), conditional reference mass is 2^-(n-r), and ambient fiber probability is 2^-r. The normalizer is the average weight over that conditional reference. These are separate recorded fields rather than a replacement by an unconditioned full-cube ExactSignLaw.

For block_conditional, others must contain exactly the nonupdated free inventory with valid signs. A violation of a different prescribed block produces a null event and None. Otherwise only the updated block is enumerated, and only its own zero or one parity constraint enters r. Constants in the full raw density cancel. For parity_row, the complete constrained law is summed into the two target parity bins in order (-1,+1). A prescribed target correctly yields a delta row; an infinite exterior-conditional interpretation requires a free target and the separate distance/error premises. The finite algorithm does not purport to evaluate the infinite conditional exactly.

The inherited arithmetic guard and explicit max_edges budget remain. Returned values have the finite recurrence meaning only under valid producer objects, exact inputs and completed guarded work; no unbounded-resource completion claim is inferred. The source preflight found no definite defect in these paths. The first draft tests were read and stayed within seven free edges; source/test execution has not yet been observed by this lane. Root requested an additional two-retained-path spatial-window test before the single authorized packet, so its final test bytes and results remain to be read.

Snapshot hashes for this later read are:

- docs/derivations/2026-09-09-coarse-gibbs-rg/agents/constrained-gibbs-construction.md: 8c2ce9f535d76fef79873c7ae65b155d2d8a6a27f663bda840500ef03d5792fb
- docs/derivations/2026-09-09-coarse-gibbs-rg/agents/potential-vfe-construction.md: 5f88d35b3017526faa0cf4b3c0af650634d1022032f743772eca45eb732d75f5
- docs/derivations/2026-09-09-coarse-gibbs-rg/agents/coarse-implementation.md: 23d3903350f5feb9280aaf152080fd77e4a0659c1130c88776317ab169f86831
- src/multiagent_elbo/rg_v2/coarse_gibbs.py: 1957146b6f3e63f6e374855e8992b5caaae89f13b979e74728963508541cbdbd


## Revision 3: final claim, source and retained-packet interface

After revision 2, I read the final CG01-CG18 and CP01-CP09 proposals, the author's final cylinder-to-sigma-algebra passage, the added actual two-retained-path B=1,2,3 tests, and the complete frozen runner/command/result/raw JUnit. I then read the frozen CGI01-CGI06 source-to-recurrence arguments and CGN01 observation. The source did not change from the version already inspected. The full-W block normalizer includes fixed outside constants; only its normalized mass and density agree with a minimal incident-factor construction. That distinction is explicit in CGI04 and prevents an unsupported partition-function identity.

The raw XML has 28 distinct testcase identifiers, no failure/error/skipped children, and suite time 0.428 seconds. The result records exit zero and runner elapsed 1.0045453000348061 seconds. This lane performed a read-only XML recount and fifteen current source/driver/contract/receipt/JUnit/command/config digest comparisons, all matching. It did not run tests, scientific recurrences or producers. The packet's largest enumerated inventory is seven fine edges. Actual two-retained-path windows cover B=1,2,3, whereas B=6 has one retained path plus an unused singleton; periodic grids are geometry-only. The complete finite helper is shared with the test oracle, and this limits numerical independence.

I read the assembled theorem, final report, counterexample register and human report, and inspected the discovery-only next obligation for scope. The fixed target remains 0<c<1/(6B), with c<1/36 for B=2,3,6, every coarse exterior, an exact full interaction, normalized four-state counting and one stationary recognition law. The observation kernel is common, strictly positive, normalized and finite-range with one homogeneous observed value. Empty support counts x in the finite window. No fixed-positive-c all-depth, arbitrary-preparation, continuum or universal curvature identification has been smuggled into the conclusion. The proposed next expansion and curvature bridge are outside this check.

[native-closure-coverage.md](native-closure-coverage.md) contains an individual falsifier check for every CG01-CG18, CP01-CP09, CGI01-CGI06 and CGN01 statement, complete target dependency coverage, explicit oracle erasure and hashes of the final inspected texts and packet. The initial contract-only derivation and later author/source readback remain separate chronologically. No unresolved definite mathematical or source-contract defect remains within those recorded premises. No ledger state is assigned, and no agreement or finite test outcome replaces a derivation.
