# Gaussian conditional-tree Fisher inference

This construction performs inference at one fixed context on the active connected agent chain. Context, connection, prior, likelihood, parent maps, and observation stay fixed during an update. The inference parameter orders vertical recognition-law changes; it is not a base coordinate, physical time, or RG depth. The state is one root Gaussian and one normalized affine Gaussian conditional for every other agent. All statements below concern this admitted finite Gaussian family, not arbitrary local-law covers or interacting frame dynamics.

## Admissible law and local consistency

For equal-dimensional blocks indexed in chain order, declare

\[
q_\theta(z)=\mathcal N(z_0;\mu_0,C_0)
\prod_{i=1}^{n-1}\mathcal N(z_i;b_i+B_i z_{i-1},C_i),
\qquad C_i\succ0.
\]

Each conditional integrates to one for every parent value, so the product is a normalized positive joint law. Independent innovations give a lower triangular matrix with identity diagonal, denoted by \(T\), such that \(z=\mu+T\epsilon\) and \(\Sigma=T\operatorname{diag}(C_i)T^T\). Thus the assembled covariance stays positive definite whenever each innovation covariance does. The pair marginals are restrictions of this single law and therefore share their separator marginals exactly in real arithmetic. The implementation does not independently move overlapping clique parameters.

An existing tree Gaussian can be expressed in these coordinates by ordinary conditioning. In particular, \(B_i=\Sigma_{i,i-1}\Sigma_{i-1,i-1}^{-1}\), \(b_i=\mu_i-B_i\mu_{i-1}\), and \(C_i=\Sigma_{ii}-B_i\Sigma_{i-1,i}\). These are the Gaussian conditioning identities in Rasmussen and Williams, [Appendix A, equations A.5–A.6](https://gaussianprocess.org/gpml/chapters/RWA.pdf). For a dense law, adjacent conditionals need not reconstruct the original joint. The default extraction API rejects that mismatch. Explicit extraction with `require_tree=False` constructs a tree law with those adjacent marginals; it does not claim to solve reverse-KL variational inference.

## Exact joint Fisher metric

Let \(s_0\) be the root score and \(s_i\) the score of conditional \(i\). The normalized conditional identity gives \(\mathbb E[s_i\mid z_0,\ldots,z_{i-1}]=0\). A score from any earlier factor is measurable with respect to that history. The tower property therefore makes cross-factor score products vanish. This proves block orthogonality for the declared conditional coordinates. It does not justify adding arbitrary marginal Fisher metrics.

Within conditional \(i\), set \(x_i=(1,z_{i-1}^T)^T\), \(H_i=[b_i,B_i]\), and \(e_i=z_i-H_ix_i\). The residual is independent of its parent and has law \(\mathcal N(0,C_i)\). In a tangent direction \((\delta H_i,\delta C_i)\), its score is

\[
s_i=e_i^TC_i^{-1}\delta H_i x_i
+\frac12\left(e_i^TC_i^{-1}\delta C_i C_i^{-1}e_i
-\operatorname{tr}(C_i^{-1}\delta C_i)\right).
\]

The mixed regression/covariance score moment is zero because it contains an odd residual moment. Gaussian second and fourth moments give the metric

\[
g_i((U,V),(\widetilde U,\widetilde V))
=\operatorname{tr}(C_i^{-1}U M_i\widetilde U^T)
+\frac12\operatorname{tr}(C_i^{-1}V C_i^{-1}\widetilde V),
\]

where

\[
M_i=\mathbb E_q[x_i x_i^T]
=\begin{pmatrix}1&\mu_{i-1}^T\\
\mu_{i-1}&\Sigma_{i-1,i-1}+\mu_{i-1}\mu_{i-1}^T\end{pmatrix}.
\]

The parent covariance is positive definite, so its augmented moment matrix is positive definite by the Schur complement. The root contributes the standard Gaussian mean/covariance metric. Summing the resulting orthogonal conditional contributions is exactly the pullback of the assembled joint Fisher metric. Parent means and the resulting intercept/regression cross terms cannot be dropped.

## Natural direction and finite update

With fixed posterior \(p_*\), the objective is \(K(\theta)=\operatorname{KL}(q_\theta\Vert p_*)\). It differs from VFE by the fixed observation evidence constant. The posterior is retained as a full Gaussian even when its precision is not tridiagonal in agent blocks. Automatic differentiation computes the derivative of this exact assembled-law KL, including all effects that changing an upstream conditional has on downstream marginals.

Writing Euclidean covectors as \(G_H\), \(G_C\), and \(g_\mu\), inversion of the metric above gives the negative natural direction

\[
\dot H_i=-C_i G_{H_i}M_i^{-1},\qquad
\dot C_i=-2C_i\operatorname{sym}(G_{C_i})C_i,\qquad
\dot\mu_0=-C_0g_{\mu_0}.
\]

For every tangent \(v\), the defining identity is \(g(\dot\theta,v)=-dK[v]\), hence \(dK[\dot\theta]=-g(\dot\theta,\dot\theta)\). No score covariance is estimated by sampling, no marginal metric replaces the joint metric, and no raw gradient is applied to a Lie algebra.

The implemented finite update is the coordinate retraction \(\theta^+=\theta+\alpha\dot\theta\) on the open conditional SPD domain. Backtracking halves the proposed step until every conditional covariance has a successful Cholesky factorization and the exact objective satisfies an Armijo decrease inequality. A dtype-scaled roundoff allowance is recorded in the code; no eigenvalue clipping or covariance jitter modifies the family. Exhaustion raises a failure. A configured Fisher-norm stationarity threshold returns the unchanged state rather than attempting a numerically meaningless step. This is a local natural-gradient method, without a claim of convergence to the global constrained optimum.

For fixed invertible node frames \(z_i'=G_i z_i\), the coordinates transform by \(b_i'=G_ib_i\), \(B_i'=G_iB_iG_{i-1}^{-1}\), and \(C_i'=G_iC_iG_i^T\). The root transforms likewise. These coordinate transformations are linear, so both the natural tangent and this additive finite retraction commute with them in exact arithmetic. KL and positive definiteness are preserved, as is the Armijo decision away from floating-point decision boundaries. Tests exercise independent SO(2) node frames. This restricted gauge statement is not general finite-step invariance under arbitrary nonlinear statistical reparameterizations.

## Full-family control and interpretation

For the full Gaussian family, write \(J=\Sigma^{-1}\) and \(h=J\mu\). Its natural parameters are \((h,-J/2)\). The exponential-family expression for reverse KL gives \(\partial_\eta K=I(\eta)(\eta-\eta_*)\), hence the exact natural flow is

\[
J(t)=e^{-t}J(0)+(1-e^{-t})J_*,\qquad
h(t)=e^{-t}h(0)+(1-e^{-t})h_*.
\]

Positive definiteness follows from convexity of the SPD cone. This is a full-family control with a flow parameter distinct from the tree solver's accepted Euler step. It fixes the exact posterior and approaches it as the flow parameter grows. It is not a constrained tree flow when the target precision has off-tree blocks.

A nonzero precision block between nonadjacent nodes proves the target is outside the declared chain family. That witness separates a structural restriction from an optimization defect. It supplies neither an optimal variational gap nor proof that a finite inference endpoint minimizes reverse KL. The independently retained full posterior remains the control for all reported posterior KL values.

The implementation follows `Theory/SPEC.md` section 5e: an exact recognition-law lift, its full Fisher pullback, and a metric-selected vertical orbit must be declared separately. The Research wiki's [Natural gradient](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Natural gradient.md>) discussion was consulted for the distinction between invariant tangents and finite updates; that local vault link is contextual, not a portable literature citation. No Research vault files were changed. The primary Gaussian identities above were checked directly; the conditional Fisher and flow arguments are derived here for this implementation.

## Focused checks supplied

The test file supplies small controls for reconstruction of the current active local laws, determinant normalization, exact conditional score orthogonality using three-node Gaussian quadrature, equality with the full-joint Fisher pullback, finite-difference natural-direction duality, joint tangent differentiation, SPD-preserving sufficient decrease, SO(2) covariance of the accepted finite step, full-flow composition, stationarity, and a dense-posterior membership witness. Test execution is coordinated by the parent implementation task; this derivation itself records no passing result.
