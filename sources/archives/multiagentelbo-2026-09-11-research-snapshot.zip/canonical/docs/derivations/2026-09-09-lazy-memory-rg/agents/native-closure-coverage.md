<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-3c515a376a85dfc2b2147d55cc119edfd1e92d499bbbd8913d256bcf91cee46f","target_digest":"3c515a376a85dfc2b2147d55cc119edfd1e92d499bbbd8913d256bcf91cee46f"} -->

# Independent final interface coverage

This record covers the frozen lazy-memory contract only. Revisions 1-7 of independent-proof-check.md preserve the initial reconstruction before new author/source inspection, subsequent source correspondence, the failed first study, the separately admitted corrected study and the later saved-output arithmetic readback. The agents share a model and filesystem. This lane ran no tests, filtering, scientific study or readback script and assigns no ledger states.

## Mathematical and finite algorithm coverage

| Claim IDs | Independent derivation and interface check |
| --- | --- |
| LMR01-LMR02 | ILM01-ILM02 reconstruct initial-mask timing and the stationary requested row P(ca)/P(c). Unconditioned stationarity does not move a conditioned hidden boundary. |
| LMR03-LMR05 | ILM03-ILM04 prove positive current-context support, normalized consistent finite products and exact prefixes through k+1. |
| LMR06-LMR07 | ILM05 proves the invariant P_k context law and whole-family shift stationarity separately from right consistency. |
| LMR08-LMR09 | ILM03 and ILM06 prove P-positive implies Q-positive, with the 001-cycle counterexample to its converse. ILM02 checks the compiler domain k<H and the min(k,H-1) comparison for larger lazy orders. |
| LMR10-LMR11 | ILM06 reconstructs the exact stationary path-KL sum and transfer of previously admitted rate/duration bounds with unchanged premises. |
| LMR12 | Revision 2 checks bijective hidden/alphabet relabeling by conjugating masks, kernel and stationary row. |
| LMR13-LMR14 | ILM07 and revisions 2 and 6 separate sparse arithmetic, quadratic tuple copying, working reference storage, rational bit growth and fail-closed resource limits. |
| LMR15 | ILM06 and revision 2 retain the declared rho-weighted auxiliary trajectory objective; there is no identification with sensor VFE or physical time. |
| LMI01 | Revision 6 maps actual constructor predicates to exact admission and the three retained fields. |
| LMI02 | Revision 6 maps row validation and its sole helper delegation to the mask/transition recurrence in ILM01-ILM02, including empty and null contexts. |
| LMI03 | Revision 6 proves the rolling-context and product loop invariants, upfront whole-word validation, zero handling and accumulated-product guard. |
| LMI04 | Revision 6 maps actual fields, loops and live helper references to the separate slot, sparse-work and tuple-copy bounds. |
| LMS01 | ILM08 and revisions 4-5 prove that 40000 decimal digits per integer cover guarded probability components and ratios of two guarded probabilities: each component is below 2^131072<10^40000. |

The four LMI claims are conditional finite algorithm identities under the recorded immutable helper/guard implementations, ordinary public input contracts, exact Fraction semantics, no mutation bypass and completion within admitted arithmetic/runtime resources. Their source-to-recurrence derivations are the general argument. The tiny tests are separate finite mechanical evidence. These claims are neither a formal verification of Python nor a guarantee that every mathematically finite query completes on this machine. The guard controls reduced Fraction components rather than all intermediate allocation.

No definite mathematical gap or source-contract defect was found within those premises. Favorable retained numerical outcomes are unnecessary for the generic row, law, support, stationarity and KL identities; removing them leaves those derivations intact. Conversely, a theorem does not establish a particular execution's outcome.

## Retained execution and arithmetic coverage

| Claim | Inspected evidence and exact scope |
| --- | --- |
| LMN01 | Raw lazy-tests-20260909T105649090362Z.xml contains 24 distinct cases with no failure, error or skip. Source/test/command bindings were read. No tests were rerun by this lane. |
| LMN02 | Completed v2 receipt and source-bound result/summary record 333 requested rows and 96 selected order-word cases, including 309 saved-P4 row comparisons, 24 saved-P4 word comparisons and 16 exact-prefix comparisons. Selected words are not a whole-law TV computation or a necessary-memory estimate. |
| LMN03 | The separate readback source, result and note were read. Its single passed execution records 4,878 arithmetic/provenance assertions, not extra tests. It independently reconstructs 309 P4 conditional rows and 24 Q4 products from stored P4 data. It does not reproduce hidden filtering, the 24 longer prediction rows or the length-8/16/32 probabilities. Missing length-5/6/7 prefix rows are disclosed. Longer values remain inputs for ratio, equality and normalization checks. |
| LMN04 | V1 failed at Python's 4300-digit conversion limit in str(mass), with no completed output packet. V2 used a separately recorded local 40000-digit setting and distinct artifacts, completing with exit 0. The actual source diff, amendment and receipts preserve unchanged predictor, model, rational guard and query manifest. This is two retained attempts, not one uninterrupted pass. |

V1's partial partition progress is diagnostic and contributes no passing packet. V2 elapsed time is 18.835628199973144 seconds in its outer receipt. The arithmetic readback elapsed time is 0.14174560003448278 seconds. Work counts in the study are source-derived upper bounds, not measured machine-operation or total-cost claims. The readback author's prior filter/projection and current theorem authorship is disclosed; its scalar integration checks do not become an independent proof of that mathematics.

## Target and final interface

The target assembly combines the finite stationary construction, conditional source correspondence and separately bounded instance evidence without erasing their domains. The final theorem, human report and final report retain exact support direction, initial-emission timing, k+1 prefix length, compiler horizon translation, arithmetic completion limits, two-attempt chronology and partial readback. The broad RG program remains open. The proposed next-volume-uniform-obligation.md closes no present claim; this check does not certify its candidate finite-energy, influence, Fourier, spatial-limit or action-convergence arguments.

The following final text bytes were inspected. No change to these files was made by this lane.

| File, relative to the worktree | SHA256 |
| --- | --- |
| docs/derivations/2026-09-09-lazy-memory-rg/construction-or-strongest-theorem.md | 7b5825354519663bef5ee480126a9d1b452e85f408333903acbbb872d04a7aef |
| docs/derivations/2026-09-09-lazy-memory-rg/final-report.md | a6c22b75cf8bbf4434c2371e8701544fcbab5fae1e442cfbf2a1fc493ba605e7 |
| docs/reports/2026-09-09-lazy-memory-rg.md | cea8fcf03c7e97346de6fd92d1c2292c3010ab12d817811f66ad7d442874a27c |
| docs/derivations/2026-09-09-lazy-memory-rg/agents/next-volume-uniform-obligation.md | ecb88a83e3c5c4e3ca0023333fab511f45596a966266362657d0441052b5d148 |
| docs/derivations/2026-09-09-lazy-memory-rg/agents/next-full-rg-obligation-intake.md | 360759671ad9b556a0c8a3c9ff5c92eaba5caad02ddcd29e8d55f853cc32aa34 |
| docs/verification/2026-09-09-lazy-memory/independent-readback.md | 12f147cfb76c5c401c5c5cf2a749f05250e6b3ed22bdc1d192699b02ccfc49b7 |

The predictor hash is 03718fc8f7aeb50e3b1bf0533324ba9ad39af05eea2a18573f58f8cf4251bfee. Raw JUnit is 63141408565be4505b3ec6c27e3c248c493ebc15287acd43ab9c684bedfdd997. V2 results and summary are f111936806dfed11788ca918b11973eccd4f9bec1df58110612005014ea584bb and 2a8fdc8bb1f02010b2ce69e399f43fc547da060de63bb8d2e51128f0d08fc22f. The separate readback result is bf684635e10e1d5710ed055a24568ff159e5b6dc856e7c775603c2b38e665906. Earlier revision records bind the remaining source, proof, manifest and receipt hashes.

This covers LMR01-LMR15, LMI01-LMI04, LMS01, LMN01-LMN04 and the scoped target. No unresolved defect within that current interface is asserted. Root retains responsibility for claim intake, structural checks and any ledger decision.
