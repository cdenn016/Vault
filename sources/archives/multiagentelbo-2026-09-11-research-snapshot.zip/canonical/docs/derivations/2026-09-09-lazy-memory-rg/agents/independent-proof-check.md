<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-3c515a376a85dfc2b2147d55cc119edfd1e92d499bbbd8913d256bcf91cee46f","target_digest":"3c515a376a85dfc2b2147d55cc119edfd1e92d499bbbd8913d256bcf91cee46f"} -->

# Independent reconstruction of lazy finite memory

Date: 2026-09-09. This first derivation was made from the frozen contract and plan, with direct inspection of the existing observation_history.py and finite_memory_projection.py interfaces, before reading this run's author derivation or new implementation. Theory/SPEC.md was previously read in full in this continuous task; its current unchanged SHA-256 is dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. A lightweight memory lookup supplied only older repository-boundary context; it supplies no mathematical or current implementation premise. All claims below are derived from finite algebra and the current sources. No new external theorem is imported.

This lane owns this Markdown and proof-check-proposals.json, with later native-closure-coverage.md if assigned. Other files remain read-only. No tests, retained queries, producer, support propagation, GPU operation, source modification, Git command, vault write or ledger-state assignment was performed. Shared model, instructions and filesystem limit independence; initial reconstruction and subsequent comparisons are explicitly separated.

## ILM01. Timing and the finite stationary word law

Let K be a finite row-stochastic hidden kernel on n states, pi a positive invariant probability row, and f the deterministic observation map into the finite alphabet A. For symbol a let D_a be its diagonal indicator matrix. The current filter emits the state at its initial boundary, so for a nonempty word c=(c_0,...,c_{r-1}),

\[
P(c)=\pi D_{c_0}K D_{c_1}\cdots K D_{c_{r-1}}{\boldsymbol1},
\qquad P(\emptyset)=1.
\]

There are r-1 transitions between these r observations. The final unnormalized hidden row is v(c)=pi D_{c_0}K...K D_{c_{r-1}}. Its mass is P(c). The next-output prediction requires one additional transition when r>0.

The future-boundary convention used in the flag and hidden-conditioned-entropy constructions instead gives pi K D_{c_0}K...K D_{c_{r-1}}1. Since pi K=pi, its unconditional stationary word law equals P(c). A stationary shift of a context-and-next-symbol joint also has law P(ca), so the corresponding conditional ratio agrees when P(c)>0. This does not assert equality of hidden posteriors at different boundaries, nor permit shifting a conditional initial preparation.

A concrete timing falsifier outside stationarity is a two-state deterministic flip with distinct labels and initial mass at state zero. The initial-emission law assigns probability one to the first label zero, whereas the next-destination emission assigns probability zero. Both timing formulas are legitimate, but they are different preparations. The proposed lazy API must admit its stated stationary law rather than silently using this shift on arbitrary input.

## ILM02. Requested conditional rows and the existing filter

For memory k>=0 and time t>=0 let r=min(k,t). An admitted context c has exactly r symbols. Define

\[
R_t(a\mid c)=
\begin{cases}
P(a),&r=0,\\
P(ca)/P(c),&r>0,\ P(c)>0,
\end{cases}
\]

and leave the row undefined when the valid context has zero probability. For r>0 the numerator is v(c)K D_a1. For the empty context it is pi D_a1, without an unnecessary transition. Summing over the declared alphabet gives one in both cases because sum_a D_a=I and K1=1. All row components are nonnegative.

The current ExactObservationFilter.history(pi,c) builds exactly v(c). Its positive _result computes the next hidden row by applying K for a nonempty word and leaves it at pi for the empty word. Its prediction field therefore equals the complete R_t row in its sorted alphabet order. It returns prediction=None for a null word. No fabricated row is needed.

At a time t in an existing horizon-H finite projection with k<H, stationarity identifies its counted context joint P(Y_{t-r:t}=ca) with P(ca). Its stored normalization is consequently the same ratio. Thus the proposed lazy row equals FiniteMemoryProjection.row(t,c) for every admitted t<H and context. Equality includes None for valid null contexts. For H<=k the old constructor cannot take that k, but its order H-1 law is exact; this is a separate explicitly mapped comparison, not an admitted same-parameter API call.

Falsifiers are an incorrect alphabet ordering, a transition before the empty-context prediction, conditioning on the entire projected history instead of its context, assigning a probability to a null conditional, or accepting a wrong context length.

## ILM03. Positive projected prefixes retain supported contexts

Define Q(empty)=1. For a positive projected prefix w of length t, multiply its mass by R_t(a|c), with c its final min(k,t) symbols, to extend by a. Once a prefix mass is zero, every extension remains zero.

The necessary invariant is P(c)>0 for the current context of a positive Q prefix. It is not P(w)>0 for the full prefix. Initially c is empty and has probability one. If an extension remains Q-positive, its selected row component is positive, so P(ca)>0. When t<k the next context is ca itself. When t>=k>=1 the next context is the length-k suffix of ca. Its stationary marginal mass is at least this positive (k+1)-word mass, hence is positive. For k=0 the context is always empty. Induction proves that a positive Q prefix never reaches an undefined row.

This support induction uses no source-word table and does not assert that Q has no new long words. For example, take a deterministic three-state cycle with labels 0,0,1 and stationary uniform pi. Then P(0)=2/3, P(00)=1/3 and R^1(0|0)=1/2. Thus Q^1(000)=(2/3)(1/2)^2=1/6, while P(000)=0. Every current one-symbol context is nevertheless P-positive. A lazy implementation that filters the entire projected prefix and rejects 000 would implement the wrong model.

Unknown symbols remain input errors even after an earlier valid symbol made a word probability zero. Whole-word alphabet/type validation must therefore precede a zero shortcut. This is API admission rather than smoothing of impossible histories.

## ILM04. Normalized coherent finite products

For each N define Q_N(w) by the preceding product for words w of length N, interpreting extensions of zero prefixes as zero. The support invariant makes every factor used on a positive prefix well-defined. For every w of length N,

\[
\sum_a Q_{N+1}(wa)=Q_N(w).
\]

For a positive prefix this is row normalization; for a zero prefix both sides vanish. Induction from Q_0(empty)=1 gives sum_w Q_N(w)=1 for each finite N. Repeated summation gives right-projective consistency across all finite horizons. No context table or full-word enumeration is required to evaluate one member of this coherent family.

For N<=k+1, every row in the word product conditions on its entire earlier prefix. The finite probability chain rule therefore gives Q_N=P_N, including zero words by the support argument. For N>=k and positive factors the useful expression is

\[
Q_N(w)=P(w_{0:k-1})\prod_{t=k}^{N-1}
\frac{P(w_{t-k:t})}{P(w_{t-k:t-1})}.
\]

At k=0 the first factor is P(empty)=1 and every denominator is one. The product is interpreted sequentially rather than as a division by zero on impossible prefixes. This formula is exactly the old normalized finite-memory product, with the same initial prefix and order. For N>k it agrees with the existing horizon-N projection when that source law is available; for N<=k it is the exact prefix law.

No claim of a new infinite-measure theorem is needed here: the requested object is the explicit consistent family of finite normalized laws.

## ILM05. Stationary context law and shift consistency

For k>=1 write mu_k(c)=P(c) on supported k-contexts. The row sends c to suffix_k(ca) with probability P(ca)/P(c). For a k-context d, its incoming mass is

\[
\sum_b P(bd_0\cdots d_{k-2})
\frac{P(bd_0\cdots d_{k-1})}{P(bd_0\cdots d_{k-2})}
=\sum_b P(bd)=P(d).
\]

Terms with zero denominator have zero numerator and are omitted. The final equality is the stationary left marginal of P. Thus mu_k is invariant for the context transition kernel, and the first k observations under Q have precisely that law by ILM04. Every subsequent k-context has stationary law P_k. For k=0 the context is the single empty word, and Q is the iid process with marginal P_1.

One can prove left-projective consistency directly without any infinite-state construction. For a word w of length N>=k, summing Q_{N+1}(aw) over a sums its initial P_{k+1}(a,w_0,...,w_{k-1}) factor to P_k(w_0,...,w_{k-1}); all later context factors are independent of a. The result is Q_N(w). For N<k, both sides are exact P marginals. At k=0 the iid product gives the same statement. Hence the finite family is shift-stationary, not merely normalized in its first boundary convention.

Falsifiers are a noninvariant pi, initialization of the context chain with an unrelated distribution, or an implementation that advances an ever-growing hidden posterior instead of reconstructing the declared rolling context.

## ILM06. Support and unchanged stationary KL bounds

If P_N(w)>0, every consecutive context-and-next-symbol word occurring in w has positive stationary mass. Every selected row component is then positive, giving Q_N(w)>0. Therefore P_N is absolutely continuous with respect to Q_N and the finite forward KL is well-defined. The reverse inclusion is false, as the 000 example in ILM03 shows.

Let h_j=H_P(Y_j|Y_0,...,Y_{j-1}), including h_0=H_P(Y_0). For N>=k, the exact initial k-prefix and stationary context rows give

\[
-\mathbb E_P\log Q_N=H_P(Y_0,\ldots,Y_{k-1})+(N-k)h_k.
\]

Subtract H_P(Y_0,...,Y_{N-1}) and use the entropy chain rule:

\[
D(P_N\Vert Q_N^k)=
\sum_{j=k+1}^{N-1}(h_k-h_j).
\]

For N<=k+1 the exact-prefix result gives zero. Thus this representation changes neither the prior stationary path-KL identity nor its admitted entropy-rate and finite-duration upper bounds. In particular D<= (N-k-1)_+ (h_k-h_inf), followed by the same nats Pinsker bound, remains available. The finite-memory approximation order has not been optimized by changing its representation.

A separately varied recognition law rho still weights the auxiliary log ratio by rho. The stationary P-average is not promoted to that variational identity, the original sensor/generative VFE, or a physical-time evolution law. Earlier every-word hidden nonforgetting counterexamples remain compatible with these results.

## ILM07. Exact resource and implementation seams

Let E be the number of positive stored hidden edges and A the alphabet size. A row with r=min(k,t) symbols evaluates one history from pi. At most r sparse propagations are needed because the positive history result computes the prediction following each observed symbol; after a zero branch there may be fewer. Masking, summing, normalizing and validating the current vectors use O(n+A) work per stage, in addition to the sparse propagation. In the unit-cost rational model this is O((r+1)(E+n+A)); stochastic rows ensure E>=n and the deterministic alphabet has A<=n, so it can be written O((r+1)E).

That is not the complete Python cost. The existing helper concatenates previous.word+(symbol,) at every extension. Copying tuple references costs 1+...+r=O(r^2). Alphabet membership in a tuple costs O(A) per checked symbol, already covered by the displayed n/A term. Temporary history results do not retain all earlier result objects: their fields refer to the filter and current vectors, so row peak working storage is O(n+r+A), apart from immutable kernel storage and rational bit lengths. Adjacent old/new results during a step only change the constant.

A word product can keep a tuple of at most k symbols and recompute its row each time. Context slicing/updating copies O(k) references per symbol, while the repeated history calls contribute O(k^2). A safe worst-case expression for N observations is O(N((k+1)E+k^2)) unit-cost work, with O(n+k) auxiliary storage apart from the immutable kernel, alphabet and caller-owned input word. For N<k replace k in the growing per-step terms by the current prefix length; the worst-case upper bound remains valid. Upfront validation of the full input adds O(NA), which is included by E>=A.

The code must guard its accumulated word probability as well as the filter's exact message calculations. A rational product can exceed the inherited 65536-bit guard even when every local conditional row was admitted. Guard rejection is an executable resource boundary, not a zero probability or a failure of finite mathematical existence. No constant-time exact sliding filter, horizon-independent bit cost, precomputed alphabet-power table or unrestricted all-N runtime completion follows from the proposed API.

Coherent hidden/observed bijections transport K, pi and f, preserving these ratios and products by finite reindexing; returned row coordinates follow the transported alphabet. This is not a new gauge-arrow implementation.

## Initial independent return

The proposed lazy API has a coherent finite construction under its stationary premises. The important possible implementation failures are wrong first-emission timing, growing-prefix filtering instead of rolling-context filtering, a false assertion that Q-positive full words must be P-positive, implicit null rows, validation skipped after zero probability, unguarded accumulated products, and omission of tuple-copying cost. These are concrete falsifiers for the subsequent source check.

This revision predates reading the new author proof or worker implementation. Their final comparison, focused execution records, the single retained study and final reporting remain pending.


## Revision 2: Author reconstruction and source preflight

The final lazy-memory-construction.md and LMR01-LMR15 atomic proposals were read after the initial ILM01-ILM07 reconstruction was persisted. No definite mathematical gap was found under their stated finite stationary hypotheses. LMR01-LMR05 reproduce the independently derived timing, requested-row, supported-context, normalized-product and exact-prefix arguments. LMR06 proves more than a one-step normalization statement: the P_k context row is invariant, its context-plus-next-symbol law is P_{k+1}, and LMR07 initializes that context chain in the correct invariant law. This gives whole-family stationarity. The independent left-marginal proof in ILM05 is a separate finite construction of the same conclusion.

LMR08 retains only the correct one-way support inclusion and the explicit 001-cycle counterexample. LMR09 matches the existing compiler's domains: same k only when k<H, otherwise the comparison uses min(k,H-1); the lazy empty law is outside that compiler's constructor. LMR10 derives the same finite KL sum and obtains its fixed-k rate by averaging the convergent h_t sequence. LMR11's lower bound follows because each term with t>=m is at least h_k-h_m, while all earlier terms are nonnegative; its upper bound and any stronger imported certificate retain the same source, preparation and order premises.

LMR12 is direct bijective reindexing, including the permutation of a sorted alphabet. LMR13 counts both sparse arithmetic and the inherited quadratic tuple copying. Inspection of the existing apply helper shows another complete sparse-kernel validation on each call; it remains O(E) scalar/input work and does not violate the stated asymptotic bound. Its guard and Fraction bit costs remain additional. LMR14's storage conclusion holds because old results do not form a linked history chain. With common input denominators, finite products give its stated rational bit-growth bounds; an accumulated N-row product can exceed a guard even when each local row fits. LMR15 is the direct finite rho-weighted KL subtraction under its support condition. None of these claims needs irreducibility, mixing, a flag word or a new external theorem.

The new lazy_finite_memory.py source was read in full. Its frozen dataclass admits only the existing exact filter, a nonnegative integer order, and an aligned strictly positive exact stationary probability row. The constructor guards each stationary entry and checks the actual pi*K equality using the owning filter's canonical kernel. row validates integer time, alphabet/type and exactly min(k,t) context length before returning history(pi,context).prediction. This preserves the initial-mask and empty-context timing.

probability validates the whole input tuple before beginning, starts at mass one, and keeps only its rolling context. It obtains the next row from that context at the actual time, guards the product, returns zero after a zero factor, and updates at most k symbols after a positive factor. It does not filter the growing projected word. A None row reached from a positive prefix raises an internal contract error, which is unreachable under the proven admitted model and therefore is not a null-context fallback. k=0 retains the empty context. No horizon table or persistent cache is present. No source defect was found in these paths.

The new test source uses two- and three-state hidden path enumeration through length four for its substantive oracle comparisons. It also covers periodic and reducible kernels, valid null contexts, the entire-word validation rule, k=0, k larger than the queried horizon, coherent hidden/observed permutations, immutable state and accumulated-product guard rejection. The later-added 001-cycle case was present in the inspected frozen source and in the one passing packet. These are legitimate finite scientific/model-admission examples; they do not corrupt an artifact.

The recorded JUnit was parsed without test execution. It contains 24 distinct cases with zero failures, errors and skips; suite time is 0.088 seconds. The retained command names only the new test file under isolated Anaconda CPython 3.12.7, disables repository conftest/plugin autoload/cache use, and binds source, test, contract and driver hashes. Its exit-zero result records source_unchanged, driver_unchanged and contract_unchanged as true. This is bounded execution evidence, not proof of all finite cases.

## Revision 3: Fixed retained-study route before execution

The frozen query manifest, evaluate_lazy_memory.py and run_lazy_study.py were inspected read-only before the root's retained evaluation. The manifest lists the declared two maps, memories 0,1,2,3,4,8 and word lengths 4,8,16,32. It is bound to the saved P4 source and the current contract. The evaluator binds the exact kernel and stationary law, preserves original hidden ordering and sorted observed alphabets, and constructs the six lazy models from those actual inputs.

Every requested context has the required min(k,t) length, bounded by eight. Returned nonnull rows are checked for nonnegative exact mass and normalization. The expected rows are read from the predeclared saved-P4 manifest. Selected length-four words are compared to saved order-k products for k<4; for k>=4 their exact-prefix reference is the saved P4 source law. This is the correct finite-horizon mapping. The longer selected-word reference is explicitly the same existing hidden filter's exact word mass, not an independent hidden-path enumeration. Positive source words must remain positive under the projected product, and the exact-prefix equality is checked wherever N<=k+1.

The script computes only those selected rows and words. It does not call a full-law enumeration API, pair BFS or prior entropy producer. Its work fields sum requested context lengths, word-row context lengths, reference-word lengths and the six constructor stationarity checks. These are upper bounds on sparse updates; zero-probability shortcuts may reduce actual work. The source explicitly excludes kernel validation, Fraction bit costs and history-tuple copying from a total-runtime claim. The wrapper records input/source/driver hashes, a single subprocess command, exit status and retained output hashes without a retry.

No preflight defect was found in this route. This checker did not independently recompute manifest marginals or run any query. The single retained study and any separate saved-output arithmetic check remain pending evidence at this revision.

### Current bindings

| Artifact | SHA-256 |
|---|---|
| lazy-memory-construction.md | 7084d1617bf9373205dcfcd3a9c49ab4e45a5e2da744777b75c4059e849a2a53 |
| lazy-memory-claims.json | 84a024f84e85d34811893f831f64f11655cf4f3527bc22041ee324976610a971 |
| lazy_finite_memory.py | 03718fc8f7aeb50e3b1bf0533324ba9ad39af05eea2a18573f58f8cf4251bfee |
| test_lazy_finite_memory.py | dc3c00c52b32208daf21a5e1c30aa4001e64fd3c36b027c2002cec27921084ff |
| query-manifest.json | 59774f54860f69e4b6df7d2a2c9343eb2afbf87cf5733b166f09ef73ca5d025e |
| evaluate_lazy_memory.py | c6ffea647566dc5e79ded57ab1771c047b5c5d9da15b289c143e4ea7bdbc07a3 |
| run_lazy_study.py | fb4d454bf4690e30cfade96cfcf99fb2be8b50da0d2c9f8f64fe58cd6dc65b1c |
| lazy-tests-20260909T105649090362Z.xml | 63141408565be4505b3ec6c27e3c248c493ebc15287acd43ab9c684bedfdd997 |

These are source/artifact identities, not new execution outcomes. No source, test or producer was run or modified by this checker.


## Revision 4: Retained v1 serialization failure and bounded repair assessment

The first retained study failed. Its saved lazy-failure.json traceback identifies Python's 4,300-decimal-digit integer string-conversion limit at str(mass), after the exact model calculation returned a Fraction. The wrapper reports returncode=1, elapsed_seconds=14.055964699946344, unchanged source and driver, and an empty outputs mapping. This is not a complete passing packet, even if the log contains a completed partition subsection. It is not an observed row mismatch or a 65536-bit arithmetic-guard failure. The failure remains part of the evidence chronology.

The root proposed a separate v2 script and output set, retaining the original script, failure and receipts, with a local recorded integer-string conversion limit of 40,000 decimal digits. The exact bound is sufficient for every scalar serialized by this study. The existing guard admits reduced probability numerator and denominator bit lengths at most 65,536. Row probabilities, selected projected masses and exact reference masses pass this guard. A ratio of two nonzero such probabilities has, before reduction, products of at most two admitted integer factors in its numerator and denominator; each product is less than 2^131072, and reduction cannot enlarge it. A zero ratio needs fewer digits.

A conservative elementary decimal bound avoids floating logarithms. Since 131072=200*655+72, the integer inequalities 2^200<10^61 and 2^72<10^22 give

\[
2^{131072}=(2^{200})^{655}2^{72}
<10^{61\cdot655+22}=10^{39977}<10^{40000}.
\]

Thus each numerator or denominator requires at most 39,977 decimal digits under this deliberately loose bound. Python's configured conversion limit applies to each integer conversion rather than the combined fraction string, so 40,000 covers both parts separately. The emitted fraction text can contain both components and a slash; that does not change the integer-conversion bound.

The repair changes the separate execution's admitted text-conversion capacity, not K, pi, contexts, word patterns, row/product formulas, exact arithmetic guard or previous passing test source. Its configuration and runtime must record the setting; previous failure records must not be overwritten or reclassified. No v2 execution or outcome was observed at this revision, and this checker did not run either attempt. The new finite evaluation requires its own source/config/command/result binding.


## Revision 5: Actual v2 source and implementation-claim comparison

The actual v2 evaluator and runner were compared to their preserved v1 files with a read-only textual diff. The evaluator adds only the local sys.set_int_max_str_digits(40000), its configuration/result value and distinct lazy-v2 result/failure/summary filenames. The runner points to that evaluator, records a distinct study-v2 receipt prefix, recognizes only v2 outputs and describes the bounded revised attempt. The model code, input hashes, manifest, query loop, arithmetic formulas and scientific comparisons are unchanged.

The serialization-repair.md amendment was read. Its shorter exact argument also suffices: 2^33<10^10 and 131072<33*4000 imply 2^131072<10^40000. It explicitly retains the failed first attempt and permits only one revised serialization attempt, with any subsequent failure requiring its own diagnosis. The source tests are not invalidated by this change to a separate study serializer. No passing v2 result was presumed during this preflight.

The frozen implementation report and LMI01-LMI04/LMN01 proposals were then read. LMI01-LMI03 map directly to the source paths already reconstructed in revision 2. LMI04's temporary-slot and bit-limit distinctions match ILM07 and LMR13-LMR14. Its legitimate two-state iid resource example has a third-symbol denominator of 2^65538 and hence bit length 65539, exceeding the unchanged guard, as stated. LMN01 matches the observed raw 24-case JUnit and command/result receipts. No new code-contract discrepancy was found.

The v2 evaluator binding supplied at this preflight is 9fe0406b5387fdaf47f4ae560ac44f3fe906552122e8846c8778d0aceacb396c, and its runner binding is 52dea5580b666ca13e4283e5f89ea992ae975694ff56f7c7152a52343e31db7e. The frozen implementation report and proposals are respectively 2d97065adb1f4ae820b73ea6d9cbf430b35961cb43a696624f4b892d071414b0 and 48f5af8501cf4edd73eb2b50c91faf7635d0ab00572d4bb84f2a48f61af9ed92. Final binding must compare those identities with current bytes and the actual v2 receipt. This source/record inspection involved no test or scientific execution.


## Revision 6: Completed v2 evidence and finite algorithm premises

The distinct v2 study completed with returncode=0. Its receipt study-v2-20260909T110353137864Z records unchanged source and driver and elapsed_seconds=18.835628199973144. The result uses the unchanged kernel, stationary law, manifest and predictor, and records decimal_serialization_limit=40000. The result and summary hashes match the announced f111936806dfed11788ca918b11973eccd4f9bec1df58110612005014ea584bb and 2a8fdc8bb1f02010b2ce69e399f43fc547da060de63bb8d2e51128f0d08fc22f.

This is the successful revised attempt after the preserved failed v1 attempt. It is not one successful attempt in total, and no partial v1 subsection is used to complete it. The v2 command and result hashes are respectively 06770b7434916d990e9b3049729c5dc184fde32310dcb0a0112601a48908a811 and c2534260ca5d680d3643da8d0b2daa9f6a474f15da15a999989422094ce19584.

Read-only JSON inspection shows 290 partition and 43 block_ab row requests, including three null partition rows and no null block rows. The saved-P4 comparison counts are 272 and 37 row matches, with one expected null among them. Each map has eight selected words at six orders, giving 96 selected order/word cases in total. Each map reports 12 saved-P4 word comparisons and eight exact-prefix comparisons. The summaries report 24 and 40 selected cases unequal to their exact word references. These finite selected-word differences are not global TV calculations or necessary-memory estimates. The recorded sparse-edge-slot upper bounds remain algorithmic upper bounds with explicitly excluded extra work, not measured operations.

No query or Fraction calculation was rerun by this checker. The artifact readback confirms the source-bound inventory and recorded outcome. A separate arithmetic readback, if produced, must be inspected before attributing any independently recomputed row, product, normalization or comparison to it.

The root asked whether LMI01-LMI04 are supported as finite algorithm identities. The answer is yes under the following exact premises: the recorded immutable filter/helper/guard implementations are the executed implementations; the input objects obey their ordinary public constructor contracts and exact Fraction semantics; no mutation bypasses those interfaces; and the relevant row/product computations complete within their admitted arithmetic and runtime resources. These premises describe correctness of returned values and reachable code paths, not guaranteed completion on every physical machine or all finite mathematical requests.

For LMI01, the constructor's branch predicates enforce type/order/shape/positivity/unit-sum invariants and the actual apply(pi,K)=pi equality. Its only retained dataclass fields are the input filter, stationary row and order. This is a direct finite source invariant. For LMI02, validation gives the precise row domain, and the sole returned value is the helper prediction whose finite mask/transition recurrence is proved in ILM01-ILM02. The empty and null branches are inherited explicitly.

For LMI03, induction on the loop index proves that the context variable is exactly the final min(k,t) symbols before each multiplication. The current symbol selects the corresponding row component in the same alphabet. guard returns that reduced exact product or rejects it; hence every returned positive prefix has precisely the finite product mass. The support invariant proves the None/error branch cannot occur on an admitted positive path. Upfront full-tuple validation establishes the unknown-symbol behavior even after a mathematical zero. The counterexample prevents replacing this induction by full-source-prefix filtering.

For LMI04, inspection of the wrapper and helper fields shows no retained chain, table or row cache. A constant number of current vectors and old/new context tuples are live, giving the stated slot bound. Counting the sparse loops, per-state work and copied growing tuples gives the separate arithmetic and reference-copy bounds. Every loop product passes the unchanged bit guard. The guard controls reduced Fraction components, not every transient intermediate allocation or total runtime.

The recorded 24-case JUnit supplies separate mechanical execution evidence for these implementations. It is not the premise for quantifying the deterministic recurrences over all admitted finite inputs. The source correspondence above, together with the helper derivation and explicit arithmetic domain, is the general reasoning. This checker assigns no ledger states.


## Revision 7: Separate saved-output readback observed

The separate independent-readback.py and its completed independent-readback.json were inspected after the v2 result. Their hashes are respectively 173ec00d5d6e2847212d28a1d89887178b258c1d38053b6be2f7b1b41c331226 and bf684635e10e1d5710ed055a24568ff159e5b6dc856e7c775603c2b38e665906. The output records a passed single execution, elapsed_seconds=0.14174560003448278, 4,878 arithmetic/integrity assertions and the same 24 distinct JUnit cases. These assertions and study attempts are not additional tests. This checker did not execute the readback.

The script imports only standard-library modules. It reconstructs finite observed marginals from the saved P4 atom table, checks their stationary left/right window equality, and computes the 309 requested saved-P4 conditional rows by independent finite sums and ratios. It separately recomputes the 24 selected length-four products from those P4 counts and compares them with the saved projection and new output. These are genuine independent scalar integrations of the stored P4 law; they are not a new reproduction of the underlying hidden-law producer.

For the remaining 24 prediction rows, the readback checks normalization and source-window support consistency. It identifies all three returned None rows using a forbidden P4 subword, which is sufficient to prove those queried contexts impossible. A longer positive context having no forbidden P4 subword is only a necessary support condition; the script does not promote it to independent reproduction of that conditional row. The output explicitly labels the 18 partition and six block longer rows as not reproduced.

All length-8/16/32 probabilities and exact references remain retained inputs. The script checks their ranges, source-support implication, exact ratios, equality flags and declared exact-prefix equalities, but does not calculate those longer probabilities or multiply missing longer-context factors. In particular length-five/six/seven prefix rows needed by some order-eight products are not fabricated from the shorter query inventory. The source and output accurately retain this limit.

The script recomputes requested update-count bounds from the frozen inventory and sparse edge count, reads current source/input bindings and recounts raw JUnit. It preserves the v1 failure, v2 completion and unchanged predictor identity across both attempts and the passing tests. Its author also wrote the earlier filter/projection and current theorem, as disclosed. Shared model, context and filesystem remain limitations, and the readback is not an independent check of that authored mathematics.

No new scientific defect was found in the readback's stated scope. Final report/theorem coverage and current text hashes remain to be frozen separately.

## Revision 8: Final interface frozen

The current theorem, final report and human report were inspected against the preceding derivations and source/receipt reads. The separate saved-output arithmetic readback is observed, with its restrictions preserved. The newly proposed next-volume-uniform-obligation.md was read only for its explicit exclusion from current closure; no candidate future influence or finite-energy argument is certified here.

The concise final claim-family mapping, exact final text hashes and two-attempt/readback limits are in native-closure-coverage.md. It explicitly covers LMR01-LMR15, LMI01-LMI04, LMS01, LMN01-LMN04 and the finite lazy-memory target. No scientific computation, test or new source change was performed by this lane. The initial derivation and subsequent readbacks remain chronologically separate in revisions 1-7. No definite unresolved defect was found under the stated premises, and no ledger state is assigned.
