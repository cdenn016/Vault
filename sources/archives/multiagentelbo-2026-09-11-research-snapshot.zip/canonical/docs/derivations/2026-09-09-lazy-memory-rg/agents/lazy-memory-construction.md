<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-3c515a376a85dfc2b2147d55cc119edfd1e92d499bbbd8913d256bcf91cee46f","target_digest":"3c515a376a85dfc2b2147d55cc119edfd1e92d499bbbd8913d256bcf91cee46f"} -->

# Exact requested-context representation of a stationary memory projection

Date: 2026-09-09. This author derivation follows the frozen lazy-memory contract and plan. The current Theory/SPEC.md hash is `dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1`, unchanged after its previous complete read in this thread. The live ExactObservationFilter and FiniteMemoryProjection sources were read for timing, null handling and horizon conventions. The arguments below are finite algebra and probability proofs, with no new imported theorem or literature claim. No science or tests were executed. The author also wrote the existing generic filter, finite projection, and previous entropy/duration derivations, so shared authorship is explicit. A separate lane must reconstruct the proof and inspect the new implementation; this submission assigns no ledger closure.

## Model and API preflight

**DEFINITION.** Let K be a finite stochastic hidden kernel on S, with n states and E positive sparse entries, and let pi be a strictly positive invariant probability row. Let f:S->A be a deterministic state observation with alphabet A listed in the filter's sorted order; write A_0=|A|<=n. The local random hidden state X_t is distinct from the fixed structural variable X of the repository specification. Set Y_t=f(X_t). All finite laws use natural logarithms and exact rational probabilities, with 0 log 0=0. No irreducibility, mixing, reversible kernel or common-flag premise is required for this representation.

**DEFINITION.** P_m(c) is the stationary probability of the observed word c of length m, with P_0(empty)=1. For declared integer k>=0 and time t>=0, put ell=min(k,t). A requested context must be a tuple of exactly ell valid integer symbols. The intended API is LazyFiniteMemoryProjection(observation_filter,stationary,order), row(t,context), and probability(word). A row is undefined, represented by None, exactly when its valid context has zero P_ell mass. Unknown symbols, noninteger/negative time or order, a malformed tuple, or a wrong context length are invalid requests rather than null observations. For a word probability, all symbols must be validated before a zero-probability shortcut. The empty word has probability one. No horizon, full word enumeration or persistent context table is needed.

## LMR01. Filter timing and exact conditional prediction

**ESTABLISHED.** Let D_a be the diagonal mask 1{f(i)=a}. For nonempty c=(c_0,...,c_{ell-1}), the current filter's forward row is

\[
 a(c)=\pi D_{c_0} K D_{c_1}\cdots K D_{c_{\ell-1}},\qquad
 P_\ell(c)=a(c){\boldsymbol 1}.
 \label{eq:hist-lmr-filter-forward}
\]

Its first symbol masks pi without applying K. Every subsequent symbol masks the preceding propagated message. Induction over advance therefore proves the displayed hidden/observed joint law. Its supported prediction sums a(c)K over destinations with the next label and divides by P_ell(c). Consequently

\[
 \operatorname{history}(\pi,c).\operatorname{prediction}[y]
 =\frac{P_{\ell+1}(cy)}{P_\ell(c)}
 =P(Y_\ell=y\mid Y_{0:\ell-1}=c)
 \quad\text{when }P_\ell(c)>0.
 \label{eq:hist-lmr-filter-prediction}
\]

For ell=0, the current helper sets its next message to pi itself, giving sum_{i:f(i)=y}pi_i=P_1(y). A zero forward mass yields None for posterior and prediction and remains zero under every valid extension. These statements follow directly from the finite mask/product recursion and normalization, including valid null words. The helper may reject excessive rational sizes before completing the calculation; the equality describes completed admitted arithmetic, not unlimited machine resources.

## LMR02. Stationarity identifies the requested conditional row

**ESTABLISHED.** The invariant initial row makes every finite hidden block stationary: summing an initial hidden segment replaces pi by pi*K^s=pi, while the remaining path products are unchanged. Applying f gives stationary observed blocks. Thus for ell=min(k,t) and supported c,

\[
 R_t(y\mid c):=P(Y_t=y\mid Y_{t-\ell:t-1}=c)
 =\frac{P_{\ell+1}(cy)}{P_\ell(c)}.
 \label{eq:hist-lmr-requested-row}
\]

LMR01 computes this row exactly from only the requested ell symbols. For t>=k, its dependence on t disappears because ell=k. For k=0 every row is the stationary observed marginal. Under stationarity the unconditioned word law beginning with Y_0 equals the shifted future-output word law beginning with Y_1. This fact does not identify a prediction conditioned on X_0 with one conditioned on X_1: the initial-mask helper must retain its actual timing. No boundary-conditioned first transition is silently removed.

## LMR03. Positive projected prefixes cannot reach a null context

**ESTABLISHED.** Starting with the empty prefix, suppose a product of the specified rows is positive. Its next requested context has positive stationary source mass. Prove this inductively. At time zero the context is empty, of mass one. If the current positive context is c of length ell and a next factor R_t(y|c) is positive, then P_{ell+1}(cy)>0. When ell<k, the next context is cy itself; when ell=k>=1, the next context is its final k-symbol suffix, whose probability is at least the mass of the particular longer word cy. Both are positive. For k=0 the next context remains empty. This proves the induction.

A zero factor makes the product and every extension zero, so there is no need to define a conditional row on a null context. A None result reached while an accumulated product is positive would violate the premises or implementation contract; it is not an invitation to invent a fallback row. A caller can still directly request a valid null context and receive None. Strict positivity of pi does not make every observed word possible.

## LMR04. Normalized projectively coherent finite path laws

**DEFINITION.** Define Q_0^k(empty)=1. For a finite word w of length N, multiply the specified row probabilities along its prefixes, stopping at zero; denote the result Q_N^k(w). By LMR03 every row required by a positive prefix is defined. For any such prefix w,

\[
 \sum_{y\in A}Q_{N+1}^k(wy)
 =Q_N^k(w)\sum_{y\in A}R_N(y\mid\operatorname{suffix}_{\min(k,N)}w)
 =Q_N^k(w).
 \label{eq:hist-lmr-projective}
\]

For a zero prefix all extensions have zero mass, giving the same identity. Starting from Q_0=1 and summing the finite extension identity proves that Q_N^k is nonnegative and normalized for every finite N. It also proves all right-prefix marginal consistencies by iteration. These are finite-law statements and do not require materializing any alphabet-power table or appealing to an infinite-path extension theorem. A horizon-free probability method therefore represents the same coherent family at every word length.

## LMR05. Exact initial prefixes through k+1 observations

**ESTABLISHED.** For every integer 0<=N<=k+1,

\[
 Q_N^k=P_N.
 \label{eq:hist-lmr-exact-prefix}
\]

At each time t<N one has t<=k, so the retained context is the entire preceding word. The row is the exact source conditional on that prefix. Induction using the finite conditional probability chain rule gives equality, including zero prefixes because a zero source extension has zero conditional factor from a positive source prefix. N=0 is the empty law. In particular k=0 gives the exact one-symbol marginal. This result concerns the first k+1 observations, not only the initial k symbols.

## LMR06. The stationary context law and retained windows

**ESTABLISHED.** Suppose k>=1 and let C={c in A^k:P_k(c)>0}. Define the context transition from c to suffix_k(cy) with probability R(y|c). Distinct y give distinct next contexts. LMR03 proves that all positive transitions remain in C, and each row sums to one. The probability row m(c)=P_k(c) is invariant. For any d=(d_0,...,d_{k-1}) in C, its incoming mass is

\[
 \sum_{a\in A}P_k(a,d_0,\ldots,d_{k-2})
 R(d_{k-1}\mid a,d_0,\ldots,d_{k-2})
 =\sum_{a\in A}P_{k+1}(ad)=P_k(d).
 \label{eq:hist-lmr-context-invariant}
\]

Terms with a null predecessor contribute zero and use no undefined conditional. The final equality uses the stationary left marginal. For k=1 the intermediate d_0,...,d_{k-2} segment is empty, so the same formula is sum_a P_1(a)R(d_0|a)=P_1(d_0). The initial k-symbol distribution is m by LMR05. Hence all later k-context distributions are m. Their context-plus-next-symbol joint distribution is m(c)R(y|c)=P_{k+1}(cy), and its marginals reproduce every contiguous source window of length at most k+1.

## LMR07. The whole projected family is stationary

**ESTABLISHED.** For k>=1, initialize the finite context chain of LMR06 in m. Invariance of m and the time-independent context transition make its finite block laws stationary by the same path-product summation used in LMR02. Reading the first coordinate of each context gives an observed stationary finite-law family. Its first k coordinates have law P_k, and each subsequent symbol is generated by the row R given the preceding k symbols. Thus its finite observed products equal Q_N^k, including N<k as marginals of P_k. This proves stationarity of the entire projected family, not just stationarity of its k-block marginal. In particular its left and right word marginals coincide. For k=0 the product consists of independent draws from P_1 and is stationary directly. Reducibility and periodicity of either chain do not alter these finite identities.

## LMR08. Source support is dominated by projected support

**ESTABLISHED.** For every N,k, P_N is absolutely continuous with respect to Q_N^k on the finite word space. Indeed if P_N(w)>0, each context-and-next-symbol window of w has positive source probability, as does its conditioning context. Every row factor is therefore positive, so Q_N^k(w)>0. This also makes the finite forward KL well-defined and finite.

The converse need not hold at longer horizons. As a direct example, take the stationary uniform three-state deterministic cycle with observed labels 0,0,1 and k=1. The stationary source has P_1(0)=2/3 and R(0|0)=1/2, so Q_3^1(000)=1/6, while P_3(000)=0. This mathematical example uses no execution and shows why exact prefix equality must not be extended to all longer words. It also illustrates that valid null source contexts remain meaningful direct row queries for sufficiently large k.

## LMR09. Equality with the existing finite-horizon projection

**ESTABLISHED.** Let H>=1 and supply the exact stationary law P_H to the existing FiniteMemoryProjection, using the same alphabet order and 0<=k<H. Its count for row time t<H, context c of length ell=min(k,t), and next symbol y is the P_H marginal of that context-and-next-symbol window. By LMR02 it equals P_{ell+1}(cy); its context count is P_ell(c). Thus the compiled conditional row agrees exactly with the requested lazy row, including None on valid null contexts.

The compiled prefix product and the lazy product consequently agree for every length N<=H, by LMR03-LMR04, and their probability methods agree when N=H. Different declared alphabet orders require the corresponding component permutation rather than literal vector equality. If a lazy order k>=H is requested, the existing finite compiler does not admit that parameter. The valid comparison uses k'=min(k,H-1), which gives the same rows at all t<H and the same exact P_H law. The empty law H=0 is defined lazily; it is outside the finite compiler's nonempty-source-word constructor. These are interface domain distinctions, not exceptions to probability coherence.

## LMR10. Exact finite KL and relative entropy rate

**ESTABLISHED.** Put h_t=H_P(Y_t|Y_0:t-1). Stationarity and conditioning give h_{t+1}<=h_t: conditioning additionally on the earliest observation can only reduce entropy, and shifting the remaining t-symbol conditioning window recovers h_t. The sequence consists of finite nonnegative values and therefore decreases to h_inf. The entropy chain rule shows H(P_N)/N tends to h_inf by averaging this convergent sequence.

For the lazy family, the expected negative log of each positive row factor under P is its conditional entropy. It is h_t for t<k and h_k for t>=k, by stationarity. Subtracting H(P_N)=sum_{t=0}^{N-1}h_t gives

\[
 D(P_N\Vert Q_N^k)
 =\sum_{t=k}^{N-1}(h_k-h_t)
 =\sum_{t=k+1}^{N-1}(h_k-h_t).
 \label{eq:hist-lmr-exact-kl}
\]

The first sum includes a zero t=k term. Both are interpreted as empty when their lower limit exceeds N-1; for N<=k+1 the result is zero by LMR05 without needing an executable row or entropy at order k. LMR08 justifies every logarithm on P-positive words. For fixed k, dividing the finite identity by N and averaging h_t proves the relative entropy rate r_k=h_k-h_inf. There is no replacement of path KL by a one-step marginal KL.

## LMR11. Transfer of finite entropy and duration certificates

**ESTABLISHED.** Since the lazy family is the same stationary projection as in LMR09-LMR10, any established bound for that family's r_k or finite KL transfers with its original premises and observation count. In particular

\[
 D(P_N\Vert Q_N^k)\le (N-k-1)_+r_k\le N r_k,
 \qquad
 D(P_N\Vert Q_N^k)\ge (N-m)_+(h_k-h_m)\quad(m\ge k+1).
 \label{eq:hist-lmr-duration-bounds}
\]

The upper bound counts at most N-k-1 nonzero terms, each at most h_k-h_inf. For the lower bound, every term with t>=m is at least h_k-h_m because h_t is nonincreasing, and earlier terms are nonnegative. A certified r_k<=epsilon therefore gives finite Pinsker TV(P_N,Q_N^k)<=sqrt(N*epsilon/2), with zero error at the exact-prefix cap k=N-1. Existing hidden-conditioned entropy brackets, finite-state excess-entropy bounds, and quantitative common-flag bounds apply to this identical law only when their respective original hypotheses hold. The lazy representation adds neither irreducibility nor a flag premise and does not prove those inputs automatically. The fixed-model logarithmic order schedule transfers mathematically, while enormous selected k or exact fractions can remain beyond the executable guard. The representation does not establish a smallest adequate order or practical usefulness of worst-case constants.

## LMR12. Coherent relabeling

**ESTABLISHED.** Under a hidden-state bijection sigma and observed-symbol bijection tau, transport pi, K and f together: pi'_{sigma(i)}=pi_i, K'_{sigma(i),sigma(j)}=K_ij, and f'(sigma(i))=tau(f(i)). Reindexing the finite path sum gives P'_m(tau(c))=P_m(c). Hence every null context, conditional row, Q-word probability, finite KL and TV value is transported exactly. Prediction vectors must be compared after the permutation between sorted alphabet orders; sorting itself is not a substantive symmetry violation. The requested-row algorithm is compatible with a gauge interpretation only through the previously admitted normalized observation square. This finite relabeling argument constructs no new gauge arrow.

## LMR13. Rational operations and tuple-copy overhead

**ESTABLISHED.** For a requested context of length ell<=k, the current history helper begins with one empty result and then calls advance ell times. Each positive advance computes at most one sparse application of K, giving at most ell*E rational multiply/add pairs, together with O((ell+1)*n) scalar sums, divisions and grouping operations. Alphabet lookup and input validation add O((ell+1)*A_0) elementary comparisons within this finite-state bound. Thus an arithmetic-operation bound is O((ell+1)*n+ell*E), excluding the bit cost of Fraction operations and guards.

However each advance builds previous.word+(symbol,), copying its growing tuple of references. The result tuple lengths sum to 1+2+...+ell=ell*(ell+1)/2, giving quadratic reference copying apart from constant-size empty-tuple shortcuts. The current helper therefore incurs O(ell^2) tuple-reference copying in addition to sparse rational work; total Python runtime is not established as O(kE). Context slicing itself costs O(ell). No constant-time sliding update follows from using an exact posterior: dropping the first observation generally requires recomputing the retained-context conditional, and the proposed method is allowed to do so.

For a word of length N, let ell_t=min(k,t). Recomputing each requested row gives O(N*n+(n+E)*sum_t ell_t) rational operations and O(sum_t ell_t^2) tuple-reference copying, in addition to N guarded product multiplications and whole-input validation. These are bounded above by O(N*n+N*(n+E)*min(k,N)) arithmetic operations and O(N*min(k,N)^2) copied references. For k=0 each row uses only the initial observed marginal; these upper bounds remain valid. Reusing a cached marginal could reduce work, but is not a premise of the proof.

## LMR14. Working storage, bit costs and resource rejection

**ESTABLISHED.** Within one sequential history computation, an old result and its successor may coexist temporarily, each holding only a fixed number of n-entry vectors and a history tuple of length at most ell. Old results are not linked into a retained chain; _filter points to the immutable owning filter, not to a parent history. A row therefore needs O(n+ell) live working slots, and a sequential word product needs O(n+k) slots after excluding its caller-owned N-symbol tuple, immutable kernel/labels and stationary input. Taking the minimum with N gives the sharper O(n+min(k,N)) bound. One scalar accumulates the word product; there is no growing list of rows or persistent alphabet-power cache in the proposed representation.

Slot counts are not byte or bit-cost bounds. Under common input denominators D_pi,D_K with bit lengths B_pi,B_K, a context forward probability through ell observations has a common denominator dividing D_pi*D_K^{max(ell-1,0)}; its one-step predictive numerator has one additional K factor. The resulting exact conditional fractions have numerator and denominator bit lengths O(B_pi+(ell+1)*B_K). A product of N such row probabilities can require O(N*(B_pi+(k+1)*B_K)) bits before cancellation. These are finite mathematical estimates, not a promise that the fixed 65536-bit resource guard admits every input, intermediate or output. Guard checks also contribute runtime. Oversized exact arithmetic must be rejected as such; it must not be converted into a zero probability, a uniform row or an approximate theorem. The finite law exists for every mathematical k,N despite possible machine rejection. A precompiled context table would have a different memory contract and is outside this construction.

## LMR15. Auxiliary variational boundary

**ESTABLISHED.** For a separately chosen recognition law rho supported on P_N-positive words, LMR08 makes both auxiliary divergences finite and direct subtraction gives

\[
 D(\rho\Vert Q_N^k)-D(\rho\Vert P_N)
 =\mathbb E_\rho\log\frac{P_N}{Q_N^k}.
 \label{eq:hist-lmr-auxiliary-vfe}
\]

The stationary source-average identity of LMR10 is the case needed for the path approximation; it does not replace this rho-weighted expression when rho varies. If rho assigns mass outside P_N support, D(rho||P_N) can be infinite and the displayed finite subtraction is not admitted. No original sensor likelihood, generative joint, physical time, curvature action or continuum limit is supplied by this representation. Initial preparation remains the fixed invariant pi. No minimum-order claim, new science claim or whole-RG completion follows from the lazy evaluation API.
