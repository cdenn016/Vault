# Phase 23 finite action identities

**Scope:** The approved finite positive supports, fixed references and summaries, and one normalized coarse channel. These elementary identities guide the implementation and its finite checks. They do not assert all-parameter physical closure, projected recursion, or accumulated error control. This implementation task creates no new formal verification ledger.

## Reference-conditional action and constants

Let mu_0 be the positive fine reference and T the fixed map, with mu_1=T_*mu_0. For R_0=mu_0 r_0, finite summation gives

$$
\frac{(T_*R_0)(x)}{\mu_1(x)}
=\sum_{T(w)=x}\frac{\mu_0(w)}{\mu_1(x)}r_0(w).
$$

The coefficients on the right sum to one. This is a conditional expectation under the reference. If R_0 is normalized, the resulting density has unit partition. Multiplying the measure by its separately saved n_R multiplies both fine and coarse densities by n_R and shifts both actions by -log(n_R). The prior and posterior normalizers differ by the actual evidence probability; Q's partition is separately typed. This is the finite specialization of [Research 07b](<C:/Users/chris and christine/Desktop/Research/manuscripts/gauge_vfe_rg/07b_agent_network_rg.tex>), thm:rg-effective-action.

## Anchored assembly

On a finite product support, let P_j replace coordinate j by its anchor. These commuting idempotents obey

$$
I=\prod_j(P_j+(I-P_j))
=\sum_S\left(\prod_{j\in S}(I-P_j)\prod_{j\notin S}P_j\right).
$$

Applying this identity to A=-log(r) yields the anchored components. Exponentiating each component gives the signed corner product q_S in the design, with integer exponents. Reassembling all components gives r=product_S q_S, including q_empty=r(a). Each component vanishes when an included coordinate equals its anchor. Its nonanchor values therefore determine it in the indicator basis. The number of coordinates is

$$
\sum_S\prod_{j\in S}(n_j-1)=\prod_j n_j.
$$

A singleton factor has no nonconstant coordinate and creates no unsupported corner. No product measure or orthogonality claim is needed for this anchored identity; the support itself must permit all corners. Under coordinatewise bijections, transform both arguments and anchors: replacement commutes with those transformed bijections, so the same signed products relabel exactly. This is the finite specialization of the commuting-projection construction in [Kuo et al., Section 2](https://web.maths.unsw.edu.au/~fkuo/pubs/preprint/ksww09-decomp.pdf).

## Forward-KL bin projection

Fix a summary sigma with nonempty bins s. Write p_s=sum_s R and mu_s=sum_s mu. Every candidate in the specified positive family has the form Q(x)=mu(x)q_s/mu_s, where q_s>0 and sum_s q_s=1. Setting hat-R(x)=mu(x)p_s/mu_s gives

$$
D_{\mathrm{KL}}(R\Vert Q)
=D_{\mathrm{KL}}(R\Vert\widehat R)+\sum_s p_s\log(p_s/q_s).
$$

The final term is nonnegative: log(t) is at most t-1, applied to t=q_s/p_s and summed with p_s. Equality requires q_s=p_s for all s. Thus the displayed readout is the unique minimum over the declared family. It preserves bin masses and is idempotent. Membership holds exactly when R(x)/mu(x) is constant in each bin. These are statements about the fixed summary family, not four-parameter Gibbs closure.

## Generated event coupling

For each parent core y with positive mass, define C(y,e,f)=R_Y(y)R(e|y)R(f|y). It is positive and normalized, and its ratio with the actual parent joint is

$$
\frac{R(y,e,f)}{C(y,e,f)}
=\frac{R(e,f\mid y)}{R(e\mid y)R(f\mid y)}.
$$

Summing R times the logarithm gives I(E_b;E_m|Y) exactly. All two-by-two minors of a positive event table vanish precisely when it has rank one, equivalently when its normalized law factors. If one minor is nonzero, conditional independence fails. Fine conditional event independence follows from its given core-times-two-kernels factorization; summing out matter need not preserve it. For the fine action, every corner component involving both events cancels because each fine log kernel uses only one event coordinate.

## One-step observable discrepancy

Let delta=R-Q on one common finite support, so sum(delta)=0. Its positive and negative parts each have mass TV(R,Q). For f bounded between m and M, subtract m before summation and use 0 <= f-m <= M-m on both parts. Consequently

$$
|E_R f-E_Q f|\leq(M-m)\operatorname{TV}(R,Q).
$$

This bound is used only on each declared same-support comparator. It says nothing about iterated projection or about a later state space. Since the normalized action difference is -log(R/Q), its sup absolute value is log(max(max(R/Q),1/min(R/Q))). Exact positive ratios specify this expression without numerical logarithms.
