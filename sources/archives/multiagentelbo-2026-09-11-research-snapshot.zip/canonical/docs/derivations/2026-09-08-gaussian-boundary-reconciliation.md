# Gaussian reconciliation at changing agent boundaries

September 8, 2026. This module implements a declared boundary policy for the moving-context neighborhood study. It preserves the joint recognition law of agents present on both sides, transports that law using a supplied survivor transport, marginalizes departed agents, and supplies entering agents from a chosen new reference conditional. The reference and transport are inputs. The policy is not uniquely implied by VFE, a theorem of arbitrary overlap gluing, or a claim of smooth evolution through changing-dimensional SPD manifolds.

## Boundary data and preserved information

Let the old and new sorted agent sets be \(I\) and \(J\), with survivor set \(S=I\cap J\), entering set \(N=J\setminus I\), and leaving set \(D=I\setminus J\). Each agent has the same declared block dimension. The old recognition law \(q_I\) and new reference law \(p_J\) are positive joint Gaussians in their respective agent-major coordinates.

The survivor law is first obtained by marginalizing \(q_I\) to the complete block set \(S\). All cross covariances among survivors are retained. A supplied invertible transport \(T_S\) then produces

\[
q_S^+=\mathcal N(T_S\mu_S,T_S\Sigma_{SS}T_S^T).
\]

The caller is responsible for obtaining \(T_S\) from the chosen connection along the declared context path. This function creates no connection, performs no Lie optimization, and does not infer a transport from the old or new covariance. The block order of \(T_S\) must match the sorted survivor labels on each side.

At least one common survivor is required. When \(S\) is empty, this API rejects the transition. An entirely disjoint population would need an additional reset or linking policy, which is not invented here.

## Reference-conditioned births

Partition the new reference into survivor and entering coordinates. Its conditional distribution is

\[
p_{N|S=s}=\mathcal N(b+B s,C),
\]

where

\[
B=\Sigma^{p}_{NS}(\Sigma^{p}_{SS})^{-1},

b=\mu^{p}_N-B\mu^{p}_S,

C=\Sigma^{p}_{NN}-B\Sigma^{p}_{SN}.
\]

These are the Gaussian conditioning identities already used in the [conditional-completion construction](2026-09-08-gaussian-conditional-completion.md). Positivity of the new reference covariance makes the survivor block and Schur complement \(C\) positive definite.

The boundary policy declares

\[
q_J^+(s,n)=q_S^+(s)p_{N|S=s}(n).
\]

The reference conditional integrates to one for every survivor value, so the product is normalized and preserves the entire survivor marginal. If \(q_S^+=\mathcal N(\mu_s,\Sigma_s)\), the entering moments and joint cross covariance are

\[
\mu_n=\mu^{p}_N+B(\mu_s-\mu^{p}_S),
\]

\[
\Sigma_{ns}=B\Sigma_s,

\Sigma_{nn}=C+B\Sigma_sB^T.
\]

The implementation constructs this joint law in survivor-then-entering order and permutes it back to the supplied sorted new-agent order. Births may occur before, between, or after surviving labels. Multiple entering agents use their complete joint reference conditional; they are not independently initialized from their marginal reference laws.

Positive definiteness follows directly from the innovation representation: sample \(s\sim q_S^+\), sample an independent \(\epsilon\sim\mathcal N(0,C)\), and set \(n=b+Bs+\epsilon\). The resulting joint covariance is a congruence of \(\operatorname{diag}(\Sigma_s,C)\) by an invertible triangular map. Matrix solves and Cholesky checks implement this admitted positive-Gaussian construction without covariance clipping or jitter.

## Relative entropy and coordinate behavior

Because the same conditional appears in both \(q_J^+\) and \(p_J\), it cancels in their density ratio. The chain rule therefore yields

\[
\operatorname{KL}(q_J^+\Vert p_J)
=\operatorname{KL}(q_S^+\Vert p_S).
\]

This identity concerns the chosen new reference at the boundary. It does not compare the pre-boundary and post-boundary VFE, count an observation, or prove descent while the context and statistical dimension change.

Under independent passive endpoint frame changes, the old recognition law and new reference transform by their corresponding block-diagonal frame maps. The survivor transport must transform as \(T_S'=G_S^+T_S(G_S^-)^{-1}\). Marginalization, linear pushforward, and Gaussian conditioning commute with these coordinate changes. Hence the resulting law transforms by the new population's frame map. The supplied tests exercise this statement for independent SO(2) blocks, including births. No smooth frame field across an absent agent's domain is asserted.

Departed conditional information is intentionally discarded. If two old preparations have the same joint survivor marginal but different departed means or conditional information, marginalization produces the same survivor state. Given the same subsequent reference and transport, their reentered laws are therefore equal. An entering agent's prior departed mean is not restored unless information about it has survived in the retained law or an additional memory model is supplied. This forgetting behavior is part of the declared policy, not a discovered universal law of inference.

## API and diagnostics

`reconcile(q_old, reference_new, old_agents, new_agents, transport, block_dim=4)` accepts one unbatched Gaussian per law and returns `(law, diagnostics)`. It checks the sorted distinct labels, Gaussian block dimensions, shared dtype/device, a nonempty survivor set, and an invertible survivor transport. The output law follows `new_agents` exactly. With no births, it returns the transported survivor marginal; with identical populations and identity transport, recognition is preserved regardless of the supplied reference.

Diagnostics contain entering, leaving, and surviving labels; the residual between the returned survivor marginal and the transported input marginal; and a reference-conditional residual obtained by extracting the conditional from the returned law and comparing its intercept, regression, and covariance with the reference conditional. They also retain both relative entropies, the signed chain-rule difference, and its absolute residual. A birth-free transition has zero conditional-reference residual because there is no entering conditional to compare.

The implementation is a full-Gaussian boundary operation. It does not assert that an arbitrary result lies in the earlier restricted agent-chain inference family. Other parts of the controller must retain their own family and objective assumptions.

The supplied small tests check explicit conditional means and cross covariances, preservation of correlated survivor marginals, identity and departure transitions, endpoint gauge covariance, reference-conditioned reentry forgetting, and rejection of disjoint populations. Tests are supplied for the coordinating implementation's consolidated execution; this derivation records no passing outcome.
