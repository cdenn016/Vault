# Local block-law assembly, parent descent and collective ELBO

September 8, 2026. Conditional construction for the approved local-data milestone. The result uses compatible strictly positive tree-Markov data. It does not infer a unique coupling from arbitrary agent marginals.

## Tree assembly theorem

Let a finite tree have variable cliques C_a and edge separators S_ab=C_a intersect C_b, with the running-intersection property: cliques containing any one variable form a connected subtree. Supply normalized positive densities p_a on each clique against compatible product reference measures. Assume their separator marginals agree. The analogous assumptions apply separately to recognition q_a and reference r_a; they need not agree with p_a.

Define p(z)=product_a p_a(z_Ca) / product_(a,b) p_Sab(z_Sab). Root the tree. Each nonroot factor p_a/p_Sa is a normalized conditional density for the variables introduced at that child. Running intersection ensures these variables are new and appear in no other remaining branch except through descendants. Integrating leaves successively proves normalization and reproduces every clique marginal. It also proves the tree conditional-independence property. Conversely, this independence property and the supplied clique marginals give the same root-and-conditionals factorization. Thus the extension is unique within the specified tree-Markov class. Other non-Markov couplings can have the same clique marginals. The formula is root independent.

For Gaussian clique laws, positivity means SPD covariance. Expanding their log densities gives J=sum_a embed(Sigma_a^-1)-sum_e embed(Sigma_Se^-1) and h=sum_a embed(Sigma_a^-1 mu_a)-sum_e embed(Sigma_Se^-1 mu_Se). The normalized density just constructed is a nonsingular Gaussian, so J is positive definite, Sigma=J^-1 and mu=Sigma h. The implementation checks input symmetry, positive definiteness and common separator means/covariances. Categorical assembly evaluates the same product quotient on the finite joint carrier and checks normalization and separator equality. No preexisting joint is queried by either assembler.

This is a specialization of the classical junction-tree construction, not a new unrestricted gluing theorem. See Wainwright and Jordan, *Graphical Models, Exponential Families, and Variational Inference*, [section 2.5.2, equation 2.12 and Proposition 2.1](https://www.cs.columbia.edu/~blei/fogm/2018F/materials/WainwrightJordan2008.pdf), and Rasmussen and Williams, [Gaussian identities, Appendix A](https://gaussianprocess.org/gpml/chapters/RWA.pdf).

## Application to the context cover

Retain the four agent domains from the previous cover construction. The adjacent agent blocks 01,12,23 exist on U_0 intersect U_1, U_1 intersect U_2 and U_2 intersect U_3. These three domains cover U. At each c the present agent labels form a contiguous chain with two or three nodes. On the two triple intersections, the adjacent pair laws share one actual agent law. An edge's full 8-dimensional Gaussian law is supplied locally from two 4-dimensional node laws and a declared cross covariance; its separator is the common node. Only present pair blocks enter the assembler. No four-agent Gaussian joint is constructed and subsequently restricted to produce these inputs.

The generative and recognition node laws and pair couplings are independent declared inputs. Their separator consistency is built explicitly into this witness and checked by the public assembler. The reference uses its own compatible node and pair data. A node's formula may be evaluated as implementation extension data, but the published local datum exists only on the node's domain; inactive saved entries have a mask. The resulting active population law is smooth on a constant-support region. Across entry/exit boundaries, its restrictions to continuing agents agree because eliminating a leaf reproduces the adjacent subtree law. It does not turn the packed fine law into a fixed-rank SPD section.

The two directed interaction records have four categorical endpoint variables. Their probabilistic cliques are endpoint pairs 01,12,23, with compatible endpoint marginals and explicitly selected dependence. These endpoint-variable indices are distinct from agent-domain indices. Each endpoint's four outcomes name agents. These normalized local record kernels are structure over U; applying the previously defined availability channel sends unavailable agent outcomes to null. The record-pair joint is assembled from the local endpoint cliques before this channel. Its two records remain correlated. Continuous Gaussian state and the complete record joint are a declared product in this specialization.

## Observation and collective objective

Supply one normalized Gaussian observation kernel o_G|z ~ N(H_c z,R), R positive definite, and one Bernoulli observation likelihood L_E on the first endpoint pair. Each agent block of H_c is multiplied by its smooth availability window, so an entering or leaving leaf contributes smoothly to the retained observation. The observed event outcome is 1. Their joint observation is counted once. The Gaussian posterior follows conditioning of the assembled active prior; the event posterior is p_E L_E/Z_E. A Gaussian observation involving several nodes can destroy posterior tree factorization. The implementation retains that full posterior rather than replacing it by reassembled posterior marginals.

For two assembled tree-Markov laws Q and P on the same tree,

    KL(Q||P) = sum_a KL(Q_Ca||P_Ca) - sum_e KL(Q_Se||P_Se).

This follows by taking the Q expectation of the log product-quotient and using its proven marginals. Apply the identity separately to the Gaussian prior/recognition and categorical prior/recognition. Then

    ELBO_latent = E_Q log L_G + E_Q log L_E - KL(Q||P),
    F_latent = -ELBO_latent = KL(Q||P_o) - log Z.

Separator subtraction prevents duplicate counting of shared variables; neither clique ELBOs nor agent ELBOs are simply added. The Gaussian expected log likelihood includes the Q covariance trace term. Event expectation uses the recognition marginal of the observed endpoint pair. The implementation compares this local-block accounting against an independent evaluation using the assembled joint/posterior.

## Parent descent and information loss

Use exactly the availability and normalized Gaussian parent channels of the previous cover, with their stated domains. For any context restriction W subset V, assembly and parent formation commute with restriction: at each retained c the same local input values, tree and deterministic formula are evaluated. For a refinement of a context cover, refined presentations therefore agree with their originals and with each other on overlaps. The descent routine checks actual repeated parent law values and assembles one value per context point, independent of patch order or duplicate presentation. It never averages duplicate observations or rescales weights by the number of charts. This is invariance under context presentation of the same population and channel, not invariance under changing physical agent membership or the coarse operation. A chart change obeys the existing covariance square.

For a common normalized channel K, define lifted laws Q(dy)K(y,dz) and P_o(dy)K(y,dz). Their relative entropy equals KL(Q||P_o). Disintegration at z gives KL(Q||P_o)=KL(QK||P_oK)+E_QK KL(Q(dy|z)||P_o(dy|z)). Evidence stays Z when the original observation is retained. This applies first to the stochastic availability channel and then to each deterministic parent channel. The implementation evaluates the discarded conditional Gaussian and categorical losses separately, in addition to subtracting coarse KL values. Their sum must equal the independently computed total loss and be nonnegative within numerical tolerance.

For a deterministic full-row-rank Gaussian parent map on the active source and target, choose a coordinate complement d so y -> (z,d) is invertible. The conditional mean/covariance formulas give Q(d|z), P_o(d|z); integrate their Gaussian KL analytically under Q_z. An absent target row is excluded by its support mask. For finite events, sum Q(y)K(y,z) log[(Q(y)/P_o(y))/(QK(z)/P_oK(z))] on supported lifted cells. Common-channel zeros have no contribution. These expressions are conditional losses, not an inference-time descent result.

## Boundaries

A three-variable binary cycle with each pair disagreeing with probability 0.98 has consistent uniform singleton marginals but cannot have a joint: every deterministic triple has at most two disagreeing edges, whereas the specified expectations sum to 2.94. This scientific counterexample distinguishes separator consistency from unrestricted cyclic extension. The admitted implementation rejects non-tree or running-intersection-invalid schemas rather than quietly applying a tree formula.

Connections remain declared flat SO(2) connections with the retained generally nonzero coarse connection defect. Curved connections, cross-context random-section laws, interacting inference and limiting RG remain outside this milestone. The numerical GPU study measures precision and mesh sensitivity of these admitted families; it does not discharge the excluded general theories.
