# Categorical score-bin compression

This construction compiles a fixed pair of positive fine laws and a common stochastic channel into a smaller set of bin masses and endpoint channel rows. It defines a preparation-dependent curve through parent probability laws. The curve is not asserted to be an autonomous reduced Fisher flow, a semigroup on parent states, or an optimization algorithm for an unknown posterior. Its law and rate errors against the exact fine Fisher flow are measured by the coordinating experiment.

Let $q(x)>0$ and $p(x)>0$ be normalized fine recognition and target laws, and let $C(y\mid x)$ be a fixed finite row-stochastic channel. Declare a partition of fine states into occupied bins $b$. The same partition is used for every channel depth. Compile

$$
q_B(b)=\sum_{x\in b}q(x),
p_B(b)=\sum_{x\in b}p(x),
$$

$$
R_q(b,y)=\frac{\sum_{x\in b}q(x)C(y\mid x)}{q_B(b)},
R_p(b,y)=\frac{\sum_{x\in b}p(x)C(y\mid x)}{p_B(b)}.
$$

Each compiled channel row is normalized. Strict positivity of both fine laws gives the same structural support for $R_q$ and $R_p$. An output is absent exactly when its channel column is zero. A designated null outcome with positive mass remains an ordinary supported outcome.

For elapsed time $t\geq0$, put $a=e^{-t}$ and $w=1-a$. Evolve the bin mass and the prepared channel rows by

$$
r_B(b,t)=
\frac{q_B(b)^a p_B(b)^w}{\sum_j q_B(j)^a p_B(j)^w},
$$

$$
R_t(b,y)=aR_q(b,y)+wR_p(b,y).
$$

The evaluated parent law is $\widehat q_Y(t)=r_B(t)R_t$. It is positive on the declared output domain, normalized, and zero on absent outputs. Its initial and target endpoints are $qC$ and $pC$. The runtime evaluator accepts positive infinity as the explicit target endpoint and returns zero rate there; ordinary finite experiments use finite elapsed times.

The curve admits the following positive normalized fine realization, although that realization is not retained by the runtime representation:

$$
\widehat q_t(x)
=r_B(b(x),t)\left(
a\frac{q(x)}{q_B(b(x))}
+w\frac{p(x)}{p_B(b(x))}
\right).
$$

Summing the conditional mixture within each bin gives one, and pushing this fine law through $C$ gives exactly $r_B R_t$. Thus the approximation preserves compatibility with the same fixed stochastic channel. This is a law construction, not an assertion that the approximate fine curve follows the original fine natural-gradient vector field.

Define the bin score

$$
\ell_B(b,t)=\log\frac{r_B(b,t)}{p_B(b)}.
$$

The bin mass follows its own complete-simplex reverse-KL Fisher flow, and the channel rows have an explicitly prescribed time dependence:

$$
\dot r_B(b,t)=-r_B(b,t)
\left(\ell_B(b,t)-E_{r_B(t)}\ell_B\right),
$$

$$
\dot R_t=-a(R_q-R_p).
$$

Therefore the parent rate is

$$
\dot{\widehat q}_Y=\dot r_B R_t+r_B\dot R_t.
$$

Dropping the second term would compute a different curve. The evaluator always uses absolute elapsed time from the compiled preparation. Recompiling an intermediate law would change the preparation and is not claimed to preserve this curve.

For a singleton partition, both prepared channel rows equal the original row $C(\cdot\mid x)$. The channel is then time independent, the bin law is the exact fine Fisher flow, and both the evaluated parent law and its rate are exact. More generally, if $\log(p(x)/q(x))$ is constant within each bin, then the conditional fine distributions agree within that bin, so $R_q=R_p$. The geometric fine interpolation factors into the bin interpolation and that unchanged within-bin conditional law. The same exactness conclusion holds for such a partition.

With one bin, its normalized mass is identically one. The parent curve instead becomes the explicit endpoint mixture

$$
\widehat q_Y(t)=a(qC)+w(pC),
$$

with rate $a(pC-qC)$. This generally differs from autonomous parent Fisher interpolation. If every fine score is equal, normalization forces $p=q$; one bin is then exact and stationary.

If a second row-stochastic channel $K$ acts after the first, direct compilation using $CK$ and staged projection using $R_qK,R_pK$ agree under the common partition. Both law and rate commute with this projection by linearity. A separate partition at each depth would not provide this identity and is excluded from the coordinating design.

The finite-budget compiler partitions the fine log-likelihood-ratio score $\ell(x)=\log(p(x)/q(x))$ into $B$ uniform-width intervals between its minimum $m$ and maximum $M$, then removes empty bins. An exactly constant score or budget one yields one bin. The full option yields singletons. Occupied finite-bin labels follow increasing score intervals; under a fine-state permutation those assignments permute with the states. Singleton labels are arbitrary metadata and may relabel, while the partition, evaluated law, and rate remain equivariant.

For a nonconstant score and $B>1$, the floating-point assignment coordinate is

$$
u(x)=B\frac{\ell(x)-m}{M-m}.
$$

To make near-boundary assignment explicit, the compiler snaps $u$ to its nearest integer when the distance is at most

$$
\tau=64\epsilon B
\frac{\max(1,|m|,|M|)}{M-m},
$$

where $\epsilon$ is the dtype machine precision. It then floors the coordinate and caps the upper endpoint at $B-1$. A boundary is assigned to the interval on its right, except the global maximum, which belongs to the final interval. If $\tau\geq1/4$, the requested partition is rejected as numerically unresolved; the compiler does not silently alter probabilities or invent a bin assignment. The one-bin and singleton options remain available. This is a declared numerical assignment policy, not an a priori approximation-error bound.

The runtime representation contains only $q_B,p_B,R_q,R_p$ and the Boolean output-domain mask. It retains neither the original fine laws, the original channel, nor the fine-state assignment. Compilation and subsequent channel projection detach the retained arrays so an autograd graph cannot indirectly keep those fine inputs alive. The compiler is therefore a numerical preparation step, not a differentiable compiler. The actual retained floating scalar count is

$$
2B+2BY,
$$

with $B$ the number of occupied bins and $Y$ the number of output slots. The Boolean mask, compiler metadata, source laws retained separately for experiment reproduction, and temporary compilation matrices are separate from this runtime floating count. A full singleton representation can be larger than another exact representation; compression is assessed from actual retained counts and measured error.

The evaluator uses stable logarithms for bin interpolation and the bin score, and computes $w$ with $-\operatorname{expm1}(-t)$. Structural-zero entries remain zero. Positive-support underflow in weighted channel compilation, projected channel rows, bin interpolation, or the resulting parent law raises an arithmetic error rather than turning the lost mass into a new structural zero. No probability floor is used.

The implementation is categorical_compression.py, with focused controls in test_neighborhood_categorical_compression.py. These cover full-flow law and rate exactness, both endpoints, one-bin behavior, nonzero channel-rate contribution, centered finite differences, equal-score-bin exactness, stochastic and staged channel compatibility, state permutation equivariance, explicit boundary admission, absent outputs and positive null outcomes, actual detached runtime storage, and support-preserving arithmetic. Tests are left to the parent task's consolidated validation.
