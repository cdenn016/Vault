<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744", "schema_version": "rigorous-theory-search/v1", "target_digest": "4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744"} -->

# Rigorous theory search report

## Frozen contract

Construct and implement duration-dependent guarantees and obstructions for stationary finite-state observation memory, with retained R5 partition/block evidence. The frozen contract and its exact target digest govern this result; no uniform contraction is presumed.

## Terminal status

Native classification is COMPLETE_AFFIRMATIVE for the frozen finite-state duration target, supported by its current derivations and exact execution, subject to the accompanying structural release record passing. The broader renormalization goal remains active.

## Certificate

The target has the direct construction in construction-or-strongest-theorem.md, the DMR and DKO derivations, their independent reconstruction, and exact numerical instantiation. Stationary preparation, finite hidden support, irreducibility where used, and supported conditioning are explicit.

## Strongest verified result

Exact memory-rate and duration bounds, sufficient implemented memory selectors, fixed-order whole-path separation under irreducibility, and an actual arbitrary-preparation hidden-filter obstruction. Every-word contraction has an explicit strictly-positive-kernel sufficient theorem that is not asserted for the sparse R5 kernel.

## Dependency closure

The 34-entry record contains 28 mathematical entries including target and six numerical observations. Every mathematical dependency supplies a finite derivation. Numerical dependencies identify current finite source laws, intervals, support witnesses and raw test outcomes; numerical agreement does not establish a limit theorem.

## Independent reconstruction

A separate checker derived the principal rate and separation arguments before reading the constructions, then checked source contracts. A separate no-repository-import arithmetic readback checks retained values. Shared model/filesystem and author relationships are disclosed.

## Oracle erasure

Removing the favorable search direction changes no entropy inequality, conditional factorization, support zero or normalization. Actual positive rate and conditional obstructions are retained rather than selected away.

## Unresolved obligations

Actual stationary-reachable-history and next-observation uniform forgetting, sharper effective memory constants, general nested lineage, critical/continuum limits and physical identification remain open. The frozen target requires scoped guarantees and an explicit criterion or obstruction; it does not presume these stronger claims.

## Scope and limitations

N counts observations; an N-observation word contains N-1 transitions. The numerical entropy-rate brackets are not sharp limits, and the million-observation brackets are analytic evaluations without long-path simulation. Written proofs are not proof-assistant verification. The current implementation uses exact rational source paths under Anaconda Python3.12.7, without a project-wide compatibility claim. No held suite, producer, GPU, full suite or tamper checks ran. Auxiliary trajectory VFE and the three curvature constructions remain separate.
