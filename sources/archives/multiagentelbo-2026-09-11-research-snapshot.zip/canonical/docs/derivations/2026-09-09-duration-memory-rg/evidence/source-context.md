<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744", "schema_version": "rigorous-theory-search/v1", "target_digest": "4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744"} -->

# Bounded source context

The Research index, inference/filtering theme and Kemeny-Snell reference note were consulted for terminology and existing project boundaries. They are context pointers, not proof substitutes or new source-adjudicated claims.

A bounded primary-paper search on September 9, 2026 located [Travers, Exponential Bounds for Convergence of Entropy Rate Approximations in Hidden Markov Models Satisfying a Path-Mergeability Condition](https://arxiv.org/abs/1211.6181v2). The abstract explicitly imposes path mergeability. This result is a future route requiring its own hypothesis mapping, not an imported theorem in the present certificate. No priority claim or systematic-review completeness is asserted.

The author-hosted [Chigansky, Liptser and van Handel filter-stability survey](https://pavelchigansky.huji.ac.il/sites/default/files/pavelchigansky/files/handbook-v08drev8e.pdf), opening pages, distinguishes conditional filters and their stability with changed initial laws. It was used as a context check. All load-bearing bounds here have direct finite proofs, and no survey theorem is used as closure evidence.
