"""Bind the finite duration target to native derivations and retained execution."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[4]
RUN=Path(__file__).resolve().parent.parent
VERIFY=ROOT/'docs/verification/2026-09-09-duration-memory'

def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def dump(name: str, value: object) -> None:
    (RUN/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

def main() -> None:
    contract=json.loads((RUN/'problem-contract.json').read_text(encoding='utf-8'))
    meta={k:contract[k] for k in ('schema_version','contract_id','target_digest')}
    intake=json.loads((RUN/'evidence/native-intake.json').read_text(encoding='utf-8'))
    assert intake['accepted_current_scoped_evidence']
    assert all(sha(ROOT/p)==h for p,h in intake['read_artifact_sha256'].items())
    science=json.loads((RUN/'evidence/scientific-record.json').read_text(encoding='utf-8'))
    assert all(sha(ROOT/p)==h for field in ('source_sha256','raw_artifact_sha256') for p,h in science[field].items())
    assert science['latest_cases']==dict(distinct=37,passed=37,failed=0,errors=0,skipped=0,execution_total=37)
    for name in ('independent-readback.json','restricted-kernels.json','schedule-results.json'):
        (RUN/'evidence'/name).write_bytes((VERIFY/name).read_bytes())
    entropy=json.loads((RUN/'agents/entropy-claims.json').read_text(encoding='utf-8'))
    restricted=json.loads((RUN/'agents/restricted-claims.json').read_text(encoding='utf-8'))
    assert len(entropy['claims'])==17 and len(restricted['claims'])==10
    claims=[];evidence=[];edges=[];attacks=[]
    def ev(eid: str,kind: str,path: str,statement: str,conditions: list[str]) -> str:
        evidence.append(dict(id=eid,kind=kind,supports=True,scope=statement,side_conditions=conditions,
                             artifact_path=path,artifact_sha256=sha(RUN/path)))
        return eid
    def add(cid: str, statement: str,quantifiers: str,kind: str,falsifier: str,conditions: list[str],eids: list[str]) -> None:
        claims.append(dict(id=cid,statement=statement,quantifiers=quantifiers,kind=kind,falsifier=falsifier,
                           target_digest=meta['target_digest'],state='EVIDENCE_VERIFIED',assumption_ids=[],
                           explicit_assumptions=conditions,evidence_ids=eids,bridge_premise_ids=[]))
    def attack(cid: str,challenge: str,response: str,path: str) -> None:
        attacks.append(dict(id='attack-'+cid,claim_ids=[cid],attack=challenge,response=response,
                            disposition='REJECTED',artifact_path=path,artifact_sha256=sha(RUN/path)))
    for c in entropy['claims']+restricted['claims']:
        cid=c['id'];path='agents/entropy-rate-construction.md' if cid.startswith('DMR') else 'agents/restricted-kernel-construction.md'
        conditions=c['assumptions'];quantifiers=c.get('quantifiers','Under exactly these finite hypotheses: '+'; '.join(conditions))
        eids=[ev('proof-'+cid,'DERIVATION',path,c['statement'],[c['derivation'],*conditions]),
              ev('reconstruction-'+cid,'DERIVATION','agents/independent-proof-check.md',c['statement'],
                 ['Written independent reconstruction of '+cid,'Shared model and filesystem; no formal-proof-assistant or blinded-replication claim.'])]
        add(cid,c['statement'],quantifiers,'MATHEMATICAL',c['falsifier'],conditions,eids)
        edges.extend(dict(from_=cid,to=dep) for dep in c['dependencies'])
        attack(cid,c['falsifier'],'The separate reconstruction checks '+cid+' with these hypotheses retained: '+ '; '.join(conditions),
               'agents/independent-proof-check.md')
    for c in restricted['numerical_observations']:
        cid=c['id'];statement=c['statement'];scope='The one frozen exact restricted-kernel scan; its finite inventory is not an asymptotic theorem or a proof that other witnesses do not exist.'
        eids=[ev('scan-'+cid,'NUMERICAL','evidence/restricted-kernels.json',statement,[scope]),
              ev('binding-'+cid,'NUMERICAL','evidence/scientific-record.json',statement,['Current source, input and raw artifact binding.'])]
        falsifier='A discrepancy in the retained decoder, labels, exact kernel or bounded output inventory.'
        add(cid,statement,scope,'NUMERICAL_OBSERVATION',falsifier,[],eids)
        attack(cid,falsifier,'The source review checks the decoder, complete support traversal and preparation semantics; root binds the actual exit-zero output. No independent rescan is claimed.','agents/independent-proof-check.md')
    numbers=[
      ('DMN01','Thirty-seven distinct new tiny cases passed across separate 25-case duration and 12-case selector packets, each executed once.',
       'Raw JUnit supplies all totals; no failures, errors or skips. Prior source was unchanged when the selector was added.',[]),
      ('DMN02','The retained stationary R5 laws give six positive rate lower bounds, twenty-four analytic duration brackets and six exact distinguishing words, on an irreducible hidden support.',
       'Two fixed maps, orders zero through two, retained horizon four. Million-observation bounds are analytic evaluations, not simulated trajectories.',['DMR08','DMR09','DMR13']),
      ('DMN03','The conservative selectors give six sufficient memory orders from the retained certified hidden-entropy upper bound.',
       'Three rate tolerances and three observation durations at TV tolerance one tenth. No context model is constructed and no minimal-memory claim is made.',['DMR06','DMR10'])]
    for cid,statement,scope,deps in numbers:
        eids=[ev('execution-'+cid,'NUMERICAL','evidence/scientific-record.json',statement,[scope]),
              ev('readback-'+cid,'NUMERICAL','evidence/independent-readback.json',statement,[scope,'Independent arithmetic; theorem author relationship disclosed.'])]
        falsifier='A current exact input, arithmetic, source, raw JUnit or stated numerical-scope discrepancy.'
        add(cid,statement,scope,'NUMERICAL_OBSERVATION',falsifier,[],eids)
        edges.extend(dict(from_=cid,to=dep) for dep in deps)
        attack(cid,falsifier,'The independent readback reconstructs finite entropy/interval or selector arithmetic and recounts raw JUnit; limits of source-law replay are explicit.','agents/independent-numeric-check.md')
    target=contract['target'];ids=[c['id'] for c in claims]+['target']
    add('target',target['statement'],target['quantifiers'],'MATHEMATICAL',target['falsification_criterion'],[],
        [ev('target-derivation','DERIVATION','construction-or-strongest-theorem.md',target['statement'],
            ['Frozen finite-state duration contract only; every scope and preparation distinction retained.'])])
    edges.extend(dict(from_='target',to=cid) for cid in ids if cid!='target')
    attack('target','Rate decay, whole-path accuracy, arbitrary-preparation filtering, stationary-history prediction or physical VFE could be incorrectly identified.',
           'The direct assembly and independent check preserve the separate quantifiers, prove irreducible word-frequency separation, and retain the actual hidden-only obstruction. Stronger program claims remain open.',
           'agents/native-closure-coverage.md')
    assert len(claims)==34 and len(set(ids))==34
    edges=[{'from':x['from_'],'to':x['to']} for x in edges]
    assert all(x['to'] in ids and x['from'] in ids for x in edges)
    dump('claim-ledger.json',{**meta,'assumptions':[],'evidence':evidence,'claims':claims})
    dump('dependency-dag.json',{**meta,'edges':edges})
    reconstruction=dict(claim_ids=ids,method='Independent initial reconstruction followed by explicit source/target comparison and bounded arithmetic readback.',
        result='PASS',conclusion='All current scoped IDs retain written proof or current executed evidence; neither agent agreement nor finite simulation closes a limit claim.',
        artifact_path='agents/native-closure-coverage.md',artifact_sha256=sha(RUN/'agents/native-closure-coverage.md'))
    dump('adversarial-report.json',{**meta,'attacks':attacks,'independent_reconstruction':reconstruction,
        'oracle_erasure':{**reconstruction,'method':'Reconstruct all current finite identities and support statements after removing the favorable search direction.'}})
    families=[('stationary-information','Finite entropy identities, hidden-state excess bound and interval arithmetic.',[f'DMR{i:02d}' for i in range(1,11)]+['DMR15','DMR16','DMR17','DMN01','DMN02','DMN03']),
              ('word-frequency-separation','Finite irreducible context graphs and two independent word-frequency proofs.',['DMR11','DMR12','DMR13','DMR14']),
              ('conditional-support','Masked-row convex hull and closed killed-support preparation obstruction.',['DKO01','DKO02','DKO03','DKO04','DKO05','DKO06','DKO07','DKO08','DKN01','DKN02','DKN03']),
              ('conditional-backward-kernels','Explicit primitive counterexample and positive one-step conditional contraction.',['DKO09','DKO10'])]
    dump('approach-registry.json',{**meta,'mechanism_families':[dict(family_id=fid,core_mechanism=mechanism,target_obligation_ids=cids,
        representation='Finite stationary path laws and exactly normalized supported conditional kernels.',
        invariant_or_obstruction='Rate/path bounds, retained support or preparation-sensitive conditional diameter.',
        obligations=['Preserve finite stationarity, support, initial-prefix and observation-count hypotheses.'],
        bridge='The target explicitly combines the finite proof and its retained rational instantiation.',
        failure_test='A normalized admitted counterexample, changed bound input or quantifier mismatch.',verified_results=cids,
        open_gaps=[],novelty_fingerprint='Direct finite probability derivations; no priority claim.',disposition='established within frozen scoped target') for fid,mechanism,cids in families]})
    dump('release.json',{**meta,'checkpoint':'Current stationary duration proofs and exact evidence assembled.','target_claim':'target',
        'terminal_status':None,'certificate_claim':'target','strongest_result':'Implemented finite-state memory-rate and duration bounds with actual fixed-order path separation and scoped conditional-forgetting obstruction.',
        'unresolved_obligations':[],'limitations':['Frozen conditional duration target only; broader RG goal remains active.',
        'No sharp actual entropy rate or practical TV-separation duration.','No actual stationary-history or next-observation uniform forgetting conclusion.',
        'Nonconstructive sublinear schedule is not an effective guarantee for an arbitrary chosen schedule.',
        'No original generative-VFE replacement, curvature action or physical-time identification.']})
    dump('evidence/native-adjudication.json',{**meta,'method':'Root native classification from current written proofs and exact mechanical output after independent checking.',
        'totals':{'claims':34,'mathematical':28,'numerical':6},'claims':{c['id']:{'state':c['state'],'kind':c['kind'],'evidence_ids':c['evidence_ids']} for c in claims}})
    print(json.dumps({'claims':len(claims),'evidence':len(evidence),'edges':len(edges),'attacks':len(attacks)}))
if __name__=='__main__':main()
