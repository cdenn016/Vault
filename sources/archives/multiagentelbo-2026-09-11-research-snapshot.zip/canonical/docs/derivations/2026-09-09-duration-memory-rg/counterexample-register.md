<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744", "schema_version": "rigorous-theory-search/v1", "target_digest": "4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744"} -->

# Duration and conditioning counterexamples

Positive rate without whole-path TV tending to one is refuted by DMR14: a mixture of a deterministic three-cycle observed as 0,0,1 and an absorbing symbol-2 class. The exact limiting TV is the cycle mixture weight. This retains stationarity and finite hidden support while showing why the stronger separation theorem requires irreducibility.

The actual repeated-symbol R5 killed supports instantiate DKO02 via DKO05-DKO06. They retain hidden posterior TV one for arbitrary preparations at every finite duration. Their survival is positive and their labels are original parent labels. This is not an actual next-observation or stationary-history counterexample.

DKO07 gives a reversible irreducible four-state chain with positive holding, hidden separation and identical next-observation predictions. It refutes promotion of hidden separation to prediction separation.

DKO09 gives a primitive nonreversible four-state chain with i.i.d. stationary observations, but two fixed strictly positive preparations retain hidden TV1/3 and next-prediction TV1/6 on every constant-a word. It refutes a general uniform-forgetting inference from zero stationary rate, and refutes replacement of one-step positivity by positive powers in DKO10. It makes no reversible-subclass or almost-sure claim.

The scan's failure to find disjoint next-label intervals or stationary two-symbol eigenrow witnesses is retained as a bounded numerical outcome. Neither convergence nor nonexistence of other witnesses follows. No prohibited tamper scenario was executed.
