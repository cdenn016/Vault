<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744","schema_version":"rigorous-theory-search/v1","target_digest":"4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744"} -->
# Independent duration-memory proof check

Revision 1, September 9, 2026. This first derivation was written from the frozen contract after reading all 1,032 lines of Theory/SPEC.md. The construction agents' current files and root's new implementation were not inspected before this revision. Statements below are submissions for comparison and reconstruction, with explicit falsifiers; no ledger state or numerical outcome is assigned. This lane writes only this file and proof-check-proposals.json, and runs no tests or scientific producers.

## Types, support, and indexing

Let \(X_t\) be a stationary Markov chain on a nonempty finite set \(\mathcal X\), with row-stochastic matrix \(L\), invariant law \(\pi\), and deterministic finite observation \(Y_t=f(X_t)\). All logarithms are natural. Entropy uses \(0\log0=0\). Stationarity does not mean irreducibility. States outside \(\operatorname{supp}\pi\) have zero stationary probability and may be removed for stationary assertions: invariance and nonnegativity imply no transition from a positive-\(\pi\) state to a zero-\(\pi\) state.

Duration \(N\) means \(N\) transitions and \(N+1\) observations \(Y_0,\ldots,Y_N\). Define
\[
h_j=H(Y_j\mid Y_0,\ldots,Y_{j-1}),\quad j\geq0,\qquad
H_n=H(Y_0,\ldots,Y_{n-1})=\sum_{j=0}^{n-1}h_j,\quad H_0=0.
\]
Thus \(h_0=H(Y_0)\), and four-observation evidence determines \(h_0,h_1,h_2,h_3\). The hidden one-step conditional entropy of the observation is
\[
g=\sum_x\pi_x H(f_\#L(x,\cdot))=H(Y_1\mid X_0).
\]
All are finite real numbers, even when the transition has zeros.

A memory order \(k\geq1\) uses the exact initial \(k\)-observation law and stationary context row
\[
T_k(y\mid u)=
\frac{P(Y_0^{k}=uy)}{P(Y_0^{k-1}=u)}
\]
only when the denominator is positive. Shorter requested paths use the corresponding exact initial marginal. For \(k=0\), use the i.i.d. law with marginal \(P(Y_0)\); its initial single observation is therefore also exact. Call the resulting path law \(Q^{(k)}_N\) and the exact observation law \(P_N\).

The supported context chain preserves its initial \(k\)-block law: summing
\(P_k(u)T_k(y\mid u)=P_{k+1}(uy)\) over the deleted first symbol gives \(P_k\) of the shifted block by stationarity. Contexts of zero stationary mass are never reached. No mathematical conditional at such a context is needed. Equivalently one can leave these rows undefined; an arbitrary external completion changes no stationary law but must not be reported as a determined conditional.

The construction is normalized and consistent across durations by row normalization. Its invariant context law proves stationarity, including windows crossing the initial boundary. It agrees with the exact process on all windows of at most \(k+1\) observations. Every positive exact word has positive initial and local \((k+1)\)-subwords, hence \(P_N\ll Q_N^{(k)}\) and forward path KL is finite. The reverse support implication is false in general: locally allowed subwords may form a globally impossible exact word.

## IP1: Exact path-KL accumulation

**Kind:** LEMMA. **Quantifiers:** all stationary finite chains, deterministic finite observations, \(k,N\) as above. **Assumptions:** exactly the stationary prefix/context initialization and support conventions stated above.

For \(N<k\), the path laws agree and KL is zero. Otherwise factor the exact law using its full predictive conditionals and subtract the log of the memory law. Conditional expectation at each step gives
\[
D(P_N\Vert Q_N^{(k)})
=\sum_{t=k}^{N}(h_k-h_t). \tag{IP1.1}
\]
For \(k=0\), the sum starts at zero; that term is identically zero. For \(k\geq1\), the exact initial \(k\)-prefix cancels, and stationarity identifies the expected negative log memory predictor at time \(t\) with \(h_k\). The term at \(t=k\) also vanishes. In conditional-divergence form, each later term is
\[
E\,D\!\left(P(Y_t\mid Y_0^{t-1})\Vert
P(Y_t\mid Y_{t-k}^{t-1})\right)=h_k-h_t\geq0.
\]
Only supported histories enter this expectation, so no impossible-event conditional was introduced. This also proves monotonicity in duration.

**Falsifier:** an admitted finite stationary path whose explicit log-ratio sum differs from IP1.1. A different initialization instead creates an initial-prefix KL and generally destroys the stationary entropy formula; it is outside this identity. **Attack:** confusing transition count \(N\) with observation count creates an off-by-one error. The first possible mismatch is \(N=k+1\), not \(N=k\).

## IP2: Entropy rate and a computable universal memory-rate bound

Conditioning and stationarity give
\[
h_j-h_{j+1}
=I(Y_{j+1};Y_0\mid Y_1,\ldots,Y_j)\geq0.
\]
The sequence decreases to a finite \(h_\infty\geq0\). Cesaro averaging of a convergent scalar sequence proves \(H_n/n\to h_\infty\); no unproved exchange of infinite expectations is used. IP1 then gives
\[
\lim_{N\to\infty}\frac{D(P_N\Vert Q_N^{(k)})}{N+1}
=r_k:=h_k-h_\infty.
\tag{IP2.1}
\]

For completeness, the finite-hidden-state excess-entropy bound can be proved entirely at finite horizons. Take nonempty adjacent observation blocks
\(A=Y_0^{n-1}\), \(B=Y_n^{n+m-1}\). Markov conditional independence makes
\[
A\longrightarrow X_{n-1}\longrightarrow X_n\longrightarrow B
\]
a Markov diagram. Conditional-mutual-information chain rules give data processing, hence
\[
I(A;B)\leq I(X_{n-1};X_n)\leq H(\pi).
\tag{IP2.2}
\]
This assertion does not require reversibility or irreducibility. Explicitly,
\(I(A;B)\leq I(X_{n-1};B)\leq I(X_{n-1};X_n)\):
each inequality follows by adding the intervening variable to one argument and using its stated conditional independence.

Stationarity and the entropy chain rule give
\[
I(A;B)=H_n+H_m-H_{n+m}
=\sum_{j=0}^{n-1}(h_j-h_{m+j}).
\]
For fixed finite \(n\), let \(m\to\infty\) term by term. Thus
\[
E_n:=H_n-nh_\infty
=\sum_{j=0}^{n-1}(h_j-h_\infty)\leq C,
\quad C:=I(X_0;X_1)\leq H(\pi).
\tag{IP2.3}
\]
The increasing partial sums \(E_n\) are bounded, so their limit exists and is at most \(C\). Taking \(n=k+1\) and using monotonicity of \(h_j\) yields
\[
0\leq r_k\leq \frac{C}{k+1}\leq\frac{H(\pi)}{k+1}. \tag{IP2.4}
\]
The entropy-only version needed by the proposed implementation is therefore valid. The \(C\) version is an optional sharper bound if its additional hidden-transition information is actually computed; it is not required for acceptance of the \(H(\pi)\) bound.

The Markov property also gives
\[
h_t\geq H(Y_t\mid X_{t-1},Y_0^{t-1})
=H(Y_t\mid X_{t-1})=g,\quad t\geq1,
\]
so \(h_\infty\geq g\). For any available block length \(m\), IP2.3 gives
\(h_\infty\geq(H_m-H(\pi))/m\).
With \(h_0,\ldots,h_M\) known,
\[
\max\left\{0,g,\frac{\sum_{j=0}^{M}h_j-H(\pi)}{M+1}\right\}
\leq h_\infty\leq h_M.
\tag{IP2.5}
\]
One may maximize the block lower bound over all available shorter \(m\), but this is optional. For every \(M\geq k\),
\[
h_k-h_M\leq r_k
\leq\min\left\{h_k-g,\ 
h_k-\frac{H_{M+1}-H(\pi)}{M+1},\
\frac{H(\pi)}{k+1}\right\},
\tag{IP2.6}
\]
with nonnegativity included. Four-observation laws supply the rigorous lower bound \(r_k\geq h_k-h_3\) for \(k=0,1,2\).

**Falsifier:** a finite stationary hidden model violating IP2.3 or a bracket in IP2.5. **Attacks:** stationarity of the input is load-bearing; numerical entropy lists with no compatible process are not theorem inputs. These bounds neither establish a finite true memory order nor give a per-word forgetting modulus. Zero \(r_k\), if established exactly, does imply the stationary observation process is \(k\)-step Markov: monotonicity forces \(h_t=h_k\) for every \(t\geq k\), so each conditional KL in IP1 vanishes. A finite near-zero bound does not establish exact zero.

## IP3: Finite duration, whole-path TV, and interval directions

For \(N\geq k\), IP1 and IP2 imply
\[
D(P_N\Vert Q_N^{(k)})
=(N+1-k)r_k-(E_{N+1}-E_k),
\]
hence
\[
\max\{0,(N+1-k)r_k-H(\pi)\}
\leq D(P_N\Vert Q_N^{(k)})
\leq (N+1-k)r_k.
\tag{IP3.1}
\]
Dropping the zero \(t=k\) term sharpens the upper bound to
\(\max\{N-k,0\}r_k\). No uniform-in-duration small bound follows for fixed \(k\) when \(r_k>0\).

Available finite data give a more useful duration formula. For \(N\geq M\geq k\), put \(d_{k,M}=\sum_{t=k}^{M}(h_k-h_t)\), \(\ell_k=h_k-h_M\), and take any proved rate upper bound \(u_k\). Then
\[
d_{k,M}+(N-M)\ell_k
\leq D(P_N\Vert Q_N^{(k)})
\leq d_{k,M}+(N-M)u_k.
\tag{IP3.2}
\]
Indeed \(h_t\leq h_M\) and \(h_t\geq h_\infty\) for the tail. In particular an exactly positive four-observation gain \(h_k-h_3\) gives an all-duration linear lower bound starting from the exact \(N=3\) divergence. It does not determine the limiting rate precisely.

Pinsker's finite-space inequality gives
\[
\operatorname{TV}(P_N,Q_N^{(k)})
\leq\min\{1,\sqrt{D(P_N\Vert Q_N^{(k)})/2}\}.
\tag{IP3.3}
\]
A direct proof avoids an imported theorem: group the probabilities into
\(A=\{P_N\geq Q_N^{(k)}\}\) and its complement. Convexity of \(x\log x\) gives the log-sum inequality and lowers KL to the Bernoulli divergence \(d(u\Vert v)\), where \(u-v=\operatorname{TV}\). As a function of \(u\), its second derivative is \(1/[u(1-u)]\geq4\), with value and first derivative zero at \(u=v\). Twice integrating yields \(d(u\Vert v)\geq2(u-v)^2\); boundary cases follow by limits.

For outward interval inputs, all lower bounds must use entropy lower endpoints in positive terms and upper endpoints in subtracted terms. For example
\[
h_{\infty,\mathrm{low}}
=\max\left\{0,g_{\mathrm{low}},
\frac{\sum_j h_{j,\mathrm{low}}-H_{\mathrm{hidden,up}}}{M+1}\right\},
\quad h_{\infty,\mathrm{up}}=\min_j h_{j,\mathrm{up}}
\]
is valid if the inputs enclose one compatible stationary HMM. A rate lower endpoint is
\(\max(0,h_{k,\mathrm{low}}-h_{\infty,\mathrm{up}})\); an upper endpoint may be the minimum of
\(h_{k,\mathrm{up}}-h_{\infty,\mathrm{low}}\) and
\(H_{\mathrm{hidden,up}}/(k+1)\).
Tail bounds then use IP3.2. Interval intersections or nonnegativity do not repair inconsistent input evidence. Identical entropy terms at \(N=k\) should be canceled symbolically so the exact-zero initialization is not mistaken for a nonzero information loss.

**Falsifier:** a whole-path divergence outside these derived intervals. **Attacks:** KL growth is not itself a lower bound on TV; applying Pinsker backward is invalid. A prediction-rate upper bound controls TV of whole paths only after its duration factor has been included.

## IP4: Positive KL rate alone does not force whole-path TV to one

Take a hidden three-cycle \(a\to b\to c\to a\), with stationary mass \(1/3\) and observations \(f(a)=f(b)=0\), \(f(c)=1\). Its entropy rate is zero, while \(h_1=(2/3)\log2>0\). The first-order approximation has transitions \(0\to0,1\) with probabilities \(1/2,1/2\), and \(1\to0\) surely.

Adjoin an absorbing hidden state d emitting a disjoint symbol 2. Give the cyclic class total stationary weight \(\varepsilon\in(0,1)\) and d weight \(1-\varepsilon\). All stationary hidden masses are positive. At memory order one, both exact and approximate path laws keep this observed component label forever and share its initial mixture weight. Therefore
\[
r_1=\varepsilon(2/3)\log2>0,\qquad
\operatorname{TV}(P_N,Q_N^{(1)})
=\varepsilon\,\operatorname{TV}(P_N^{\mathrm{cycle}},Q_N^{\mathrm{cycle}})
\leq\varepsilon.
\]
There are at most three exact cyclic words at each duration. Their total approximate probability tends to zero because each contains a number of zero-to-next choices growing linearly in duration and each such transition costs a factor \(1/2\). Thus the latter TV tends to one and the mixed TV tends to \(\varepsilon\), not one.

**Scope:** stationary reducible finite HMMs. **Falsifier:** a claim using this example must preserve its exact first-order initialization and disjoint observed components. **Attack resolved:** strictly positive stationary masses do not imply irreducibility. A positive-rate whole-path separation theorem needs an extra ergodicity/irreducibility hypothesis or an explicit distinguishing event argument.

## IP5: Whole-path separation under finite hidden irreducibility

Assume the positive-stationary-support hidden chain is irreducible, and \(P\ne Q^{(k)}\) on some finite observed word w. Then
\[
\operatorname{TV}(P_N,Q_N^{(k)})\longrightarrow1.
\tag{IP5.1}
\]
No aperiodicity is required. Here is a finite-state proof.

First, for any finite irreducible stochastic matrix K, its right harmonic vectors are constant: choose a maximum of a harmonic vector, use equality in its convex average to propagate the maximum along every positive transition, and invoke irreducibility. Hence \(\ker(I-K)\) consists of constants and has dimension one. Since the invariant law \(\lambda\) satisfies \(\lambda(I-K)=0\), every \(\lambda\)-centered vector f is in the range of \(I-K\), by rank-nullity. Choose bounded g with \(f=(I-K)g\). Along the chain Z,
\[
\sum_{t=0}^{n-1}f(Z_t)
=g(Z_0)-g(Z_n)
+\sum_{t=0}^{n-1}[g(Z_{t+1})-(Kg)(Z_t)].
\]
The summands in the last sum are bounded martingale differences. Distinct summands have zero covariance by conditional expectation, so the variance of their sum is \(O(n)\). Dividing by n proves that empirical averages converge in probability to their stationary mean. This also proves the needed assertion without importing a general ergodic theorem.

Any supported fixed-length hidden-block chain is finite and irreducible: connect the endpoint of one supported hidden block to the start of another by an irreducible hidden path, then append the second block. Indicators of observed words are functions of these blocks, so under P their empirical frequencies converge to P(w).

The supported k-context chain of \(Q^{(k)}\) is irreducible for \(k\geq1\). Given two positive observed k-words, select supported hidden realizations and connect them by an irreducible hidden path. Every shifted observed k-context in that path is supported, providing the required context-graph path. For \(k=0\), the positive observed marginal gives an irreducible i.i.d. chain. Applying the same block argument gives empirical word frequencies under \(Q^{(k)}\) converging to \(Q^{(k)}(w)\).

Let the nonzero gap be \(\delta=|P(w)-Q^{(k)}(w)|\). The event that the empirical frequency of w lies within \(\delta/3\) of P(w) has P-probability tending to one and Q-probability tending to zero. The definition of TV therefore proves IP5.1. An exact positive memory-rate lower bound implies such a differing finite word by IP1, but the word itself is sufficient.

**Falsifier:** a finite irreducible example with unequal word laws but no frequency separation. **Scope:** a conditional theorem until R5 irreducibility on the actual positive stationary support is proved. No finite packet alone supplies an asymptotic frequency count; the proof above supplies it once the support hypothesis and differing word are exact.

## IP6: Uniform forgetting can fail even with zero stationary memory-rate error

Define four hidden states \(a_0,a_1,b,c\), observation map
\(f(a_0)=f(a_1)=a\), \(f(b)=b\), \(f(c)=c\), and transition
\[
L=
\begin{pmatrix}
1/2&0&1/2&0\\
0&1/2&0&1/2\\
1/4&1/4&1/4&1/4\\
1/4&1/4&1/4&1/4
\end{pmatrix}.
\tag{IP6.1}
\]
Its invariant law is uniform because every column sums to one. It is irreducible and aperiodic, and \(L^2\) is strictly positive: either of the first two rows reaches one of the uniform rows in one step, and either uniform row already reaches every state.

Under the uniform stationary preparation, the conditional hidden law on observation a is always \((1/2,1/2,0,0)\), whatever the preceding observed history. After b or c the next hidden law is uniform; after a, the two hidden a-states have equal weights and the next observed probabilities are \(1/2,1/4,1/4\). Induction therefore proves that the stationary observation process is i.i.d. with that marginal. All stationary rate errors \(r_k\) are exactly zero.

Now compare strictly positive preparations
\[
\mu=(2/5,1/5,1/5,1/5),\qquad
\nu=(1/5,2/5,1/5,1/5).
\]
The word \(a^{N+1}\) has probability \((3/5)2^{-N}>0\) under both preparations. Conditioning forbids transitions to b or c, so its terminal filters are respectively
\((2/3,1/3,0,0)\) and \((1/3,2/3,0,0)\), for every N. Their TV is \(1/3\). Their next-observation distributions are
\((1/2,1/3,1/6)\) and \((1/2,1/6,1/3)\), whose TV is \(1/6\). Thus even primitive hidden dynamics, positive preparations, and exact stationary zero-order prediction do not imply uniform forgetting over common supported observation words.

**Falsifier:** any algebraic entry in IP6.1 or the displayed conditional predictions is incorrect. **Quantifier warning:** this refutes uniformity over arbitrary positive preparations and every supported word. It does not refute almost-sure forgetting from the invariant preparation; the exceptional word probabilities shrink exponentially. Merely exhibiting different hidden filters is not always enough to prove different observed predictions; this example explicitly includes the latter difference.

## IP7: A sufficient every-word criterion under strict one-step positivity

For comparison, assume \(0<a\leq L_{ij}\leq b<\infty\) for all hidden i,j. For any observation word supported by both initial preparations, condition the hidden path on the entire word. Its conditional transitions have form
\[
K_t^w(i,j)=\frac{L_{ij}v_{t+1}(j)}
{\sum_\ell L_{i\ell}v_{t+1}(\ell)},
\]
where \(v_{t+1}\geq0\) includes the next observation indicator and all later observation likelihoods. It is not identically zero for a supported word. Thus each row satisfies
\[
K_t^w(i,j)\geq(a/b)\frac{v_{t+1}(j)}{\sum_\ell v_{t+1}(\ell)}.
\]
All rows share a common probability component of mass \(a/b\). Writing the kernel as that common component plus its nonnegative remainder proves TV contraction by \(1-a/b\) using the triangle inequality and row normalization. These conditional transitions depend on the fixed kernel and word, not on initial preparation; the preparations enter only their respective conditioned initial hidden distributions. Hence
\[
\operatorname{TV}(\operatorname{Filter}_N^\mu(w),
\operatorname{Filter}_N^\nu(w))
\leq(1-a/b)^N.
\tag{IP7.1}
\]
Prediction through the same next-observation channel contracts TV again.

This is a sufficient criterion, not a necessary characterization. Replacing one-step positivity by positivity of a power is invalid without checking the intermediate observation restrictions; IP6 is an exact counterexample to that replacement. General block-restricted criteria must inspect the actual masked word products and common support, rather than the unconditioned power alone.

## Pending source comparison and R5 obligations

The root construction files and new implementation remain unread at this first revision. Required comparison points are initialization/indexing, conditional entropy ordering, interval endpoint directions, duration-tail counts, path-support direction, actual irreducibility, and the quantifiers of restricted-kernel witnesses. R5-specific numerical quantities must come from the unchanged retained four-observation laws, invariant pi and transition L with source binding. No value, contraction constant, communicating-class claim or positive entropy gap for R5 is inferred here.

The auxiliary stationary path law remains fixed independently of subsequently varied recognition. Its step count is the declared duration parameter. These information identities neither identify it with the original generative sensor joint nor add terms to that joint's VFE, and they assert no physical clock.


## Revision 2: Root implementation and duration-count translation

The source comparison now covers stationary_memory_bounds.py, its focused test source, and the retained study_duration_bounds.py driver, read without execution. The root has explicitly fixed its API convention: its argument duration is the number n of observations, whereas the frozen duration postulate and IP1-IP7 above use N transition steps. The translation is
\[
n=N+1,\qquad N=\text{API duration}-1.
\]
The existing API is preserved. Its minimum duration=1 is the zero-transition case. Its displayed path sum from \(t=k+1\) to \(n-1\) is exactly IP1.1 after dropping the identically zero \(t=k\) term. A report interpreting API duration=1,000,000 must consequently call it one million observations or 999,999 transitions. No previous numerical result is relabeled as a new execution.

The arithmetic implementation agrees with IP2-IP3 under its explicit caller premise that all interval inputs enclose one compatible stationary finite HMM. The nonincreasing-sequence check rejects interval collections that have no such monotone realization; it does not purport to prove HMM realizability. The entropy lower endpoint takes the maximum over zero, the optional hidden-prediction lower endpoint, and every available block lower bound \((\sum_{j<n}h_{j,\mathrm{low}}-H_{\mathrm{hidden,up}})/n\). Its upper endpoint is the minimum of the supplied entropy upper endpoints. Every one of these directions is conservative for the stated process.

There is a subtle point in the finite-duration tail which is correct in the current source. The code reuses its rate_lower as a lower bound for each unseen prediction gap. This is justified by the particular formula
\[
\text{rate_lower}=\max(0,h_{k,\mathrm{low}}-\min_{0\leq j\leq M}h_{j,\mathrm{up}}),
\]
because every unseen \(h_t\) is at most \(h_M\), which is itself at most all the available upper endpoints. A generic asymptotic rate lower bound would not automatically be a lower bound on each finite-time gap. Any future strengthening of rate_lower must preserve this stronger finite-tail property or use a separate tail lower bound.

For a known gap, the code's upper endpoint is the minimum of its direct interval difference and the universal rate upper endpoint. This is valid because \(0\leq h_k-h_t\leq r_k\). It sums known terms from k+1 to the last available index and appends exactly \(\max(0,n-(M+1))\) tail terms, matching IP3.2. Empty prefixes and the \(n\leq k+1\) exact-law cases yield an empty sum and zero bound. The rational square-root routine takes the integer floor of the scaled square root and increments precisely when its square remains below the input, producing an outward upper endpoint for Pinsker.

The retained driver supplies h0..h3 from the already saved exact rational four-observation law, computes hidden entropy and hidden prediction entropy from the retained pi/L, checks pi L=pi exactly, and uses positive-word conditional ratios with interval logarithms. It binds the previous source artifacts by fixed SHA-256 values. Its support traversal uses nonzero entries; under the inherited nonnegative-kernel premise these are exactly the positive graph edges. All-source breadth-first reachability is the correct finite irreducibility criterion, and positive diagonal entries supply aperiodicity though IP5 does not require it.

The driver also extracts a differing finite word by comparing the unchanged exact short law with its corresponding memory projection. Under the fixed-prefix definition, this short approximate law is the same marginal as the all-duration stationary memory law. Thus an exact nonzero rational difference and exact irreducibility are the instance premises IP5 needs; approximate printed rates are unnecessary for that theorem. This lane has not rerun those checks or independently evaluated their output values. The current code trace supplies no new mathematical defect under the stated input-evidence and observation-count conventions.

### Reconstruction obligations for retained evidence

The root's reported irreducibility and positive rate intervals are execution claims whose exact output/source binding remains the retained evidence authority. Before applying IP5 to R5, the mathematical report must cite the exact support result and rational word gap, not merely decimal summary values. Before presenting million-duration bounds, it must give both the observation count used by the API and the corresponding transition count. Neither requirement asks for another producer run.


## R5 retained-instance readback without re-execution

The current retained results.json was read and its SHA-256 was checked non-mutatingly:
910df84f0f9f83989ac2bf76f2875d1c6d07d843e91629fd5a6a545b21ace2ad.
It records 250 states, exact support reachability from every state, maximum finite graph distance 7, and positive diagonal entries. Those are inherited execution results, not a new graph computation by this lane.

The same record contains positive exact rational P-minus-Q word differences for both observation maps and all three requested memory orders. The witnesses are \((6,6)\), \((6,6,6)\), and \((6,6,6,6)\) for partition orders 0,1,2, and the all-zero words of lengths 2,3,4 for block_ab. The exact strings are copied with their source binding into proof-check-proposals.json. Their numerators and denominators are positive integers, establishing that the stored differences are nonzero without using decimal output.

Conditional on the retained exact kernel/source-law provenance, these support and word facts instantiate IP5 for each of the six cases. Therefore their stationary exact observation paths and fixed-order memory paths become asymptotically completely distinguishable in whole-path TV. This conclusion uses irreducibility and differing finite words; it is not inferred by reversing Pinsker or by treating a positive displayed decimal as a proof. IP1-IP3 separately give the finite-duration information bounds. No rate of convergence of TV to one is supplied here, because that would require explicit finite-state frequency constants and word gaps to be propagated through the Poisson argument.


## Revision 3: Frozen author, implementation, and target-interface check

This readback checks the submitted arguments without assigning ledger states. The final entropy Markdown has SHA-256 d55251a8eeda939a7189e268d79cf2a51529e748415b883afb6fb8bced6afbef, and its revised proposal JSON has b6d20b524fdfe5d7d2a82e8ddc6e85f4899aa64cab2056df7fef0a804ba874b3. The restricted-kernel Markdown has ced1ac3f392c1530a7248ac912371fa92fa9c3168f9ceccdf5b9c2565ae73279, and its proposal JSON has 98b7bb0baf105967f517f701cdcc0137badee88edf6a37d8b35046c3918cedfd. Both final Markdown headers carry the same contract identity and target digest as this document. The final claim JSON statements and dependency lists were also read. No argument below uses investigator agreement as evidence.

Here and in the following source checks, n denotes the number of observations. Thus n=N+1 in IP1-IP7 when their N denotes transitions. In the entropy author and root API, their N is this n. The restricted author sometimes uses N transitions and words of length N+1; its contraction exponent becomes n-1 in the assembled theorem. The root's assembly makes this translation explicitly.

### Entropy construction: DMR01-DMR10

DMR01-DMR04 agree with IP1-IP2 after that translation. The exact stationary context law matters twice: its initial context law removes an initial KL penalty, and the induced context transition preserves that law. A P-positive full word has positive initial prefix and positive every conditional row it uses, so forward path KL is finite even though Q may assign mass to additional words. The factors through index k match exactly, leaving the sum from t=k+1 to n-1. Zero limiting rate forces every later conditional-entropy difference to vanish; the same exact KL identity then gives P_n=Q_n^k at every duration. A small positive upper bound is not an exact-zero conclusion.

DMR05-DMR07 agree with the finite-cut argument in IP2. The hidden state at the cut makes finite observed past and future conditionally independent. Therefore their mutual information is at most H(pi). First taking the future length to infinity for a fixed finite past length proves E_m<=H(pi), and then taking the increasing finite partial sums proves summability. No interchange of two unbounded sums is needed. The optional sharper I(X_0;X_1) bound in IP2 is a separately stated sufficient improvement; the author and implementation use the valid H(pi) bound. The grouped hidden-row entropy g is a lower bound on h_infinity because conditioning on X_0 removes the additional information carried by the finite observed history when predicting Y_1.

DMR08's interval substitutions are correctly directed: a lower endpoint for h_k minus an upper endpoint for h_infinity gives a rate lower bound, whereas an upper endpoint for h_k minus a lower endpoint for h_infinity gives an upper bound. Every block supplies (H_m-H(pi))/m as a lower bound on h_infinity. The author's optional finite-m upper bound h_k-h_m+H(pi)/(m+1) follows by adding the already proved bound on r_m. The root implementation can omit this optional improvement and remain conservative.

DMR09 includes a useful strengthening of the IP3 finite-size statement. Write r_j=h_j-h_infinity. For n>k,

\[
n r_k-D_n^k=k r_k+\sum_{j=k}^{n-1}r_j.
\]

Every term is nonnegative, and monotonicity gives k r_k<=sum_{j=0}^{k-1}r_j. Hence the displayed difference is at most E_n<=H(pi). If n<=k, D_n^k=0 and n r_k<=sum_{j=0}^{n-1}r_j<=H(pi). This proves the claimed finite correction for every n, including all exact-prefix cases. Dropping the zero t=k term also gives D_n^k<=(n-k-1)_+ r_k. Known-time differences and the finite-h_m tail lower bound have the directions already checked in Revision 2.

DMR10's TV upper bound follows from the finite binary grouping argument reconstructed in IP3. It is never used as a TV lower bound. With C>=H(pi), the sufficient whole-path criterion is

\[
D_n^k\leq C\frac{n-k-1}{k+1}\leq 2\delta^2
\quad\Longleftrightarrow\quad
k+1\geq\frac{Cn}{C+2\delta^2},
\]

for 0<=k<=n-1 and positive delta. This is sufficient and generally conservative; it does not identify the smallest successful order of the actual observation process.

### Irreducibility and separation: DMR11-DMR16

DMR11's supported context graph is irreducible because any two positive contexts have positive hidden realizations, and a positive hidden bridge connects the end of one realization to the start of the other. Every sliding observed context along that bridge is positive and each corresponding context transition is admitted. Null contexts play no role. At k=0, the iid output process is represented by its positive-symbol transition matrix.

DMR12 provides a mechanism different from the Poisson-equation proof in IP5. In finite dimension, subsequential limits of Cesaro transition matrices exist. Each limit has columns harmonic for the irreducible transition matrix, so each column is constant by the maximum principle. Stationarity determines the constants and makes the limit uniquely the stationary projection. For bounded L-block functions, the author writes the nonoverlapping covariance as a fixed row times the centered transition power times a fixed column. Its Cesaro average tends to zero. If C_j is the sum of covariances through lag j, then C_j=o(j), and

\[
\operatorname{Var}\left(n^{-1}\sum_{t=0}^{n-1}F_t\right)
=n^{-2}\left(n c_0+2\sum_{j=1}^{n-1}C_j\right)\longrightarrow0.
\]

The finite initial overlapping lags do not alter the limit. This proof allows periodic chains and does not assume convergence of individual transition powers.

DMR13 therefore reconstructs the IP5 conclusion with an independent frequency proof. A positive rate gives a finite differing word, and both stationary laws have empirical word frequencies converging to their respective probabilities. For a probability gap Delta, a threshold at the midpoint has error at most 4(V_P+V_Q)/Delta^2, yielding the displayed finite TV lower bound. This does not supply a numerical separation duration until those finite variances are bounded. DMR14's reducible mixture counterexample has TV equal to its binary-component TV multiplied by the cycle weight, establishing why the irreducibility premise cannot be silently dropped.

DMR15 uses bijections, not arbitrary coarse maps, to reindex the probability sums. The separate admitted observation square remains necessary for any gauge interpretation. DMR16 requires fixed normalized auxiliary targets and recognition support within P. On that support,

\[
D(\rho\Vert Q)-D(\rho\Vert P)=\mathbb E_\rho\log(P/Q).
\]

Choosing rho=P recovers the stationary path error; no bound for every other rho follows. A common fixed evidence constant cancels if the expression is called auxiliary VFE. Neither the original sensor joint nor a physical-time interpretation is changed by this identity.

### Growing-memory schedules: DMR17

The schedule statement is correct under the proved summability, but it is an existence result rather than a selector computable from the retained four-observation law. For nonnegative nonincreasing summable r_k,

\[
k r_k\leq 2\sum_{j=\lfloor k/2\rfloor}^{\infty}r_j\longrightarrow0.
\]

If k(n)>=alpha n for fixed alpha>0 and k(n)<=n-1, then D_n^{k(n)}<=n r_{k(n)}<=k(n)r_{k(n)}/alpha tends to zero. Pinsker then gives whole-path TV tending to zero. This is stronger than substituting the coarse bound C/(k+1), which by itself would only give a constant at such linear schedules.

For the author's sublinear diagonal construction, choose M_j so that k r_k<=j^{-3} for every k>=M_j, and recursively choose strictly increasing integer n_j>=max(j(M_j+1),2j^2). Such choices exist. On the segment with j=max{ell:n_ell<=n}, let k=floor(n/j). Then k>=M_j, k>=n/(2j), k>=2j-1, and k/n<=1/j. Consequently k tends to infinity, k/n tends to zero, k<=n-1, and

\[
n r_k\leq(n/k)j^{-3}\leq2j^{-2}\longrightarrow0.
\]

The finite exceptional initial durations can use k=n-1. The sequence n_j depends on the unknown full tail of the entropy series; no effective rate is supplied. Arbitrarily choosing a sublinear order does not inherit this guarantee. There is no contradiction with fixed-k TV separation because its quantifier keeps k constant.

### Conditional construction and exact support scan: DKO01-DKO10

DKO01 follows by writing each preparation-specific posterior as a convex combination of normalized nonzero masked-product rows. Point preparations attain the row-diameter endpoints. Applying the next-observation channel creates a separate, possibly smaller diameter. DKO02's two disjoint killed supports remain disjoint under every repeated-symbol update. Positive diagonal entries give a strictly positive likelihood for every finite repetition, so the conditionals are defined. The extension to strictly positive preparations concerns the supremum separately at each duration: mixing each endpoint preparation with epsilon times a positive law and then sending epsilon to zero is valid by continuity of normalization at a positive denominator. It does not automatically yield one fixed strictly positive pair that attains TV one at all durations.

DKO03's disjoint next-symbol row intervals give a prediction gap because each updated filter is a convex combination of rows within its own component. Overlapping intervals do not prove forgetting. DKO04 keeps the stronger stationary-history interface explicit: each eigenrow must first be realized by a positive stationary history. Once realized, beta S=lambda beta with lambda>0 makes every further normalization reproduce beta, and the common repeated suffix retains any differing predictions. Existence of an arbitrary component-supported preparation alone does not establish that entrance-history premise.

DKO05-DKO06 instantiate DKO02 using the recorded rational killed kernels and exact absence of cross-component edges. Parent delta preparations correspond to the declared fine lift nu J. An arbitrary unprepared fine law would instead have first-step law q M C and need not obey (q C)L. DKO07's reversible four-state example has disjoint hidden filters but identical next-label predictions, directly falsifying the inference from hidden to predictive separation.

DKO09 reproduces IP6's nonreversible primitive example with zero stationary memory rate and two fixed strictly positive preparations whose next-prediction TV is 1/6 on every constant-a word. DKO10 reproduces IP7 by conditioning on the entire word and constructing common future-conditioned transition rows. The lower row mass ell/u supplies a shared component and contracts TV at each of the n-1 transitions. The initial distribution after conditioning may depend on the preparation; its diameter is at most one. A positive power of the unconditioned matrix cannot replace strict one-step positivity, as DKO09 demonstrates. DKO08's physical/search-direction erasure leaves these finite claims unchanged; it supplies no additional quantitative theorem.

The restricted scan source was read in full without execution. Its SHA-256 is 7816452940b1a67b4205da181120f21e00339c0c5ba868a321779888176ec465; its retained output hash is 60236a0e6142384c17d6d025e7518997022fb3371ef1da75afe641a2bc8fc7c8. The decoder checks unique destinations, positive exact coefficients, row sums, positive pi, exact invariance and detailed balance. Detailed balance with positive pi makes the positive-support graph undirected, so the graph-component traversal used for each observation fiber is justified. The subsequent explicit assertion excludes every within-symbol edge leaving a reported component. Minimum diagonal entries are taken from the complete member set.

The same source calculates all component next-label intervals and tests exact constant survival rows. It computes each two-symbol stationary entrance by pi masked by its first symbol, then one exact transition and the second mask; the eigenrow test is the full coordinate identity for another killed step. These are finite sufficient criteria. The absence of their witnesses in the retained output cannot be promoted to absence of every longer-history witness. DKN01-DKN03 remain inherited execution results with their frozen source/output bindings; this lane does not rerun them or manufacture a second numerical record.

### Conservative selector source check

The bound source checked in Revision 2 has SHA-256 0e97b9c13fc45fd76d70541de4a612a008f9c5490eb42cb8c966ea08935b4b56. The new stationary_memory_orders.py source has f78cd5d845921e07ccc46bbed4724642e2d9de4b52b97ef08c58ffcee1de4094 and was read in full without execution. Its rate selector uses the exact rational ceiling of C/epsilon minus one, bounded below by zero. This is the smallest nonnegative integer satisfying that particular universal sufficient inequality, not necessarily the actual process's smallest acceptable order.

The path selector uses the exact rational ceiling of Cn/(C+2delta^2) minus one, bounded to 0 through n-1. The ceiling is exact integer arithmetic; clipping above n-1 cannot destroy sufficiency because that endpoint gives an exact path law. C=0 returns order zero, correctly using r_0=0. Delta>=1 returns zero using the universal TV<=1 bound. Positive delta, nonnegative C and integer n>=1 are validated, with bool excluded for n. No process, context law, entropy estimate or selected empirical model is constructed by these functions. Their output is conditional on a certified C>=H(pi), exact stationary-prefix semantics, and the stated auxiliary path law. Numerical selector examples and their test totals remain root-owned retained results, not new checks run by this lane.

### Target assembly, report, erasure, and remaining attacks

The target assembly and counterexample register were read after the author files. They preserve the observation-count convention, forward support, stationarity, the distinction between sufficient and minimal memory orders, the additional irreducibility needed for whole-path TV separation, and the separate interfaces for hidden filtering, next-observation predictions, and histories reachable from one stationary preparation. The updated human report has the same mathematical scope. Its final evidence paragraph distinguishes the 25 duration-bound cases and the separate 12 selector cases without claiming a rerun. Its added selector and schedule paragraphs correctly distinguish sufficient finite bounds from the nonconstructive sublinear existence result. The external literature route mentioned as a future direction is not an imported hypothesis or proof step in this reconstruction.

Erasing the R5 names, favorable search direction, physical interpretation and agent agreement leaves finite matrices, compatible stationary laws, normalized context kernels, exact support statements, finite entropy identities and explicitly stated conditional hypotheses. A one-state constant deterministic observation supplies a nonempty admitted example. The general proofs require no irreducibility until the separation theorem; the counterexamples deliberately retain or violate particular assumptions as stated. No curvature identification, new gauge arrow, autonomous reduced dynamics or physical clock is introduced.

The principal attacks have explicit outcomes. Removing stationary/exact-prefix assumptions changes the path-KL identity. Removing irreducibility defeats TV-to-one, as IP4 shows. Reversing Pinsker is invalid and is not used. Promoting the actual killed-support witness to prediction or fixed-stationary-history separation is unsupported, as IP6 and DKO07 separate those quantifiers. Replacing positive one-step entries by positive powers is refuted by IP6. Treating the diagonal schedule as an effective four-observation selector is unsupported. Treating interval monotonicity as proof of one compatible hidden realization is unsupported. Treating a stronger generic limiting-rate lower bound as a per-step lower bound would invalidate the present finite-tail interface unless separately justified.

No new mathematical defect was found in the frozen arguments or the two source modules under these premises. Actual R5 stationary-history predictive forgetting, a practical duration for near-complete path separation, and sharper effective sublinear selection remain open within this bounded return. This is a proof-check submission for the root's evidence process, with no ledger closure and no new test or scientific execution.

