<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744","schema_version":"rigorous-theory-search/v1","target_digest":"4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744"} -->
# Restricted-kernel investigation for duration and memory

This investigation establishes an all-duration obstruction to **uniform hidden-posterior forgetting over arbitrary initial preparations** for both retained R5 observation maps, conditional on the exact finite support facts recorded by the single scan below. It does **not** establish an all-duration obstruction for next-observation predictions or for pairs of observation histories generated from the one fixed stationary preparation. Those stronger conclusions remain open within this bounded investigation. The finite scan found no witness satisfying its declared sufficient prediction or stationary-history criteria.

This is an independent investigation lane, not a formal verifier or ledger adjudicator. The investigator shares the model family, conversation context, filesystem, and retained inputs with the other lanes; independence means a separate finite-sum construction and a standard-library decoder, not statistical or vendor independence. No author agreement supplies evidence. Only the two assigned construction/claim documents and the assigned scan/receipt/output/log were written. Theory/SPEC.md was read in full. This document is an executable-evidence investigation report, not an insertion of runtime details into the theory manuscript.

## Binding and execution boundary

The frozen target digest is 4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744. The contract file SHA256 is 434a0470166e9823f3bacbff7ebb608ecaeaed0fe38aa2546bac4cb798b94cd5, and Theory/SPEC.md SHA256 is dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1.

The retained component and kernel files are docs/verification/2026-09-09-parent-sensitive/component.json, SHA256 126b1a90cfedb69096f034bd72c30b4e0876df53669ae163780c5b68f1bd3f50, and kernels.json, SHA256 838cc121a54381700b9b2d33558f33b1c72e28b03894417636f89f0fb42f3c65. The earlier mapping source is docs/verification/2026-09-09-observation-history/study_history.py, SHA256 37bed44f682bec998044be8e81e0633177627f99a1b86b5f36c42c7f4bc39659. It defines partition as incidence feature row[1] and block_ab as its membership in {2,6}; the scan independently checks that the partition value is constant on every original parent label.

The one frozen scan is docs/verification/2026-09-09-duration-memory/inspect_restricted_kernels.py, SHA256 7816452940b1a67b4205da181120f21e00339c0c5ba868a321779888176ec465. Its embedded configuration SHA256 is a358c2bbb1271c55d42caf389ee9690cd3b70427573da0d5b81cfb14a56576eb. Before execution, the configuration fixed both maps, at most 250 states and eight symbols, all killed-support components and component pairs, row-probability intervals, constant-survival checks, and stationary two-symbol entrance eigenrow/support checks. It enumerated no matrix powers or longer words. Eigenrow testing is one exact multiplication of a two-symbol entrance row, not a search through longer trajectories.

The command was C:/anaconda/python.exe -I -B C:/tmp/elbo-cover-20260908/docs/verification/2026-09-09-duration-memory/inspect_restricted_kernels.py, run once from C:/tmp/elbo-cover-20260908. Runtime was Python 3.12.7 packaged by Anaconda, Windows 10 build 19045, with isolated=1 and bytecode writing disabled. The script reported 0.375571699929424 seconds and exited zero. No randomness was used, so no seed applies. No predecessor producer, tests, held suite, GPU computation, tamper check, or longer-word search ran. The script's existing-output guard prevents an implicit rerun.

The saved restricted-kernels.json SHA256 is 60236a0e6142384c17d6d025e7518997022fb3371ef1da75afe641a2bc8fc7c8; restricted-kernels.log SHA256 is 61c432cbbe5caf1bc7fe318bbe354dfc906f8f8cfa2370aaa42332a39b0b2574; restricted-kernels-command.json SHA256 is 450dc80d4919357e35d8406b9a564a650584f7505d95dcb07b7b09e8aece01e8. The command receipt was started before execution and completed afterward. No science result was reconstructed from a progress line.

## Finite constructions and claims

### DKO01: Exact row-diameter criterion separates hidden filtering from prediction

Assume a finite hidden set X, a stochastic row kernel K, and a deterministic map g:X→A. For a word w=(y0,...,y(n-1)), n≥1, let E_y be its diagonal mask and define B_w=E_y0 K E_y1 ... K E_y(n-1). The first observation masks the initial law without a transition. For any preparation alpha with alpha B_w 1>0, its final hidden posterior is f_w(alpha)=alpha B_w/(alpha B_w 1). Define r_i=(B_w 1)_i and u_i=(B_w)_(i,·)/r_i only for r_i>0. Direct expansion gives

f_w(alpha)=sum_(i:r_i>0) [alpha_i r_i/(sum_j alpha_j r_j)] u_i.

Thus every posterior is a convex combination of the same supported normalized rows. For any two mixtures, the triangle inequality gives TV(sum_i a_i u_i,sum_j b_j u_j)≤sum_(i,j) a_i b_j TV(u_i,u_j)≤max_(i,j)TV(u_i,u_j). Point preparations delta_i attain each row, so the supremum over supported preparation pairs is exactly that row diameter. Impossible words with every r_i=0 have no posterior and are excluded. This is ESTABLISHED by finite algebra.

Let R_(i,b)=sum_(j:g(j)=b)K_ij. The next-observation prediction is f_w(alpha)R. The same argument, now applied to u_i R, gives a separate exact prediction diameter max_(i,j)TV(u_i R,u_j R), bounded above by the hidden diameter because sum_b|sum_i d_i R_ib|≤sum_i|d_i|. Uniform forgetting over all preparations and positive common words means that the corresponding supremum over length-n words tends to zero. Hidden and prediction diameters are different quantities. This claim does not assert that enumerating finitely many words establishes either limit. The empty word uses a different prediction phase, alpha E_b 1, and is intentionally excluded.

Falsifier: a word/preparation with positive mass violating the displayed mixture identity, or a claimed posterior at a zero row sum.

### DKO02: Disjoint killed supports retain hidden information for every duration

Assume a symbol a and two disjoint nonempty sets C,D⊂g^(-1)(a) such that K(i,j)=0 whenever i∈C and j∈g^(-1)(a)\C, and likewise for D. Let S=K restricted to g^(-1)(a). Suppose every state in C∪D has a positive diagonal. For preparations alpha supported in C and beta supported in D, observing a^n gives

f_(a^n)(alpha)=alpha S^(n-1)/(alpha S^(n-1)1),  f_(a^n)(beta)=beta S^(n-1)/(beta S^(n-1)1).

A length-(n-1) path surviving the masks stays in its starting set by the zero-edge condition. Both denominators are positive: retaining one starting state i throughout contributes alpha_i K_ii^(n-1)>0. The posterior supports remain disjoint, so TV=1 for every n≥1. If d_C=min_(i∈C)K_ii>0, the first survival denominator is at least d_C^(n-1); the analogous bound holds for D. Equal survival probabilities, equal eigenvalues, stationarity, and reversibility are unnecessary. In a positive reversible chain, connected components of the restricted positive-support graph provide these closed killed sets because pi_i K_ij=pi_j K_ji makes the support symmetric. This is ESTABLISHED.

This is a counterexample to uniform forgetting over arbitrary preparations, including preparations absolutely continuous with respect to a strictly positive stationary law. It does not compare two histories under that one stationary preparation. For uniformity over all strictly positive preparations, approximate alpha and beta by (1-epsilon)alpha+epsilon pi and (1-epsilon)beta+epsilon pi. For each fixed n the denominators at epsilon=0 are positive, so the posterior ratios are continuous there and the TV distances approach one. Hence the supremum over strictly positive preparation pairs is also one at each n. The approximating pair may depend on n; no fixed strictly positive pair is asserted to stay separated.

Falsifier: a positive within-symbol edge leaving a proposed set, or a selected preparation whose repeated-symbol survival eventually vanishes.

### DKO03: A sufficient all-duration next-observation gap

Under DKO02, fix a next symbol b and write k_b(i)=sum_(j:g(j)=b)K_ij. If max_(i∈C)k_b(i)<min_(i∈D)k_b(i), set eta to the positive difference. Every conditional posterior supported in C predicts b at most the first endpoint, and every posterior supported in D predicts b at least the second. Therefore their next-observation TV distance is at least eta for every n≥1. The reversed interval order gives the same result. The claim is ESTABLISHED by averaging a bounded function over each supported posterior. It is a sufficient criterion only; overlapping intervals do not prove convergence or exclude another prediction witness.

Falsifier: a claimed positive gap whose exact row intervals overlap, or a conditional posterior leaving its proposed killed set.

### DKO04: Conditional eigenrows supply a separate stationary-history criterion

Assume two positive, equal-length words u and v under one fixed stationary preparation pi, both ending in a. Let beta_u,beta_v be their actual conditional hidden posteriors. If beta_u S=lambda_u beta_u and beta_v S=lambda_v beta_v with lambda_u,lambda_v>0, then after m additional a observations the word masses are P_pi(u)lambda_u^m and P_pi(v)lambda_v^m and the two normalized posteriors remain beta_u and beta_v. Unequal next-observation predictions beta_u R and beta_v R then give an all-duration gap on stationary reachable histories with an arbitrarily long common a suffix. The eigenvalues may be unequal. Distinct hidden eigenrows with equal predictions give only hidden separation. This is ESTABLISHED by multiplying the eigenrow identity m times and dividing by the explicitly positive mass.

A useful exact special case is a killed component C of a positive reversible kernel with constant within-symbol row sum lambda_C. Detailed balance and absence of within-symbol edges to other components give, for j∈C,

sum_(i∈C) pi_i K_ij=pi_j sum_(i∈C)K_ji=lambda_C pi_j.

Thus pi conditioned on C is a left eigenrow. This produces an arbitrary-preparation witness. It produces a stationary-history witness only after an actual positive history is shown to have that conditional posterior; the conditional pi|C cannot be declared reachable by choice. The scan explicitly checked the actual pi E_b K E_a entrance rows, not assumed stationary conditionals.

Falsifier: an asserted entrance has zero stationary mass, a nonzero eigenrow residual, or an unverified replacement of a history posterior by pi|C.

### DKO05: Instantiation on the retained partition kernel

The exact finite facts in DKN01–DKN02 instantiate DKO02. For partition symbol 1, choose C={252,253,254,255} and D={400,401,402,403}, using original parent labels. In their listed orders, the two diagonal blocks of the killed matrix are

S_C =
[[804185/1040928, 57/86744, 1/672, 0],
 [1/14, 19631/28728, 0, 1/42],
 [1/14, 0, 120803/173488, 151/21686],
 [0, 1/14, 151/3192, 677/1026]],

S_D =
[[107197/144774, 533/16086, 1/42, 0],
 [533/47488, 216221/284928, 0, 1/672],
 [1/14, 0, 103597/144774, 167/16086],
 [0, 1/14, 167/2968, 61153/94976]].

These are the entire restricted blocks, not selected edges. The saved scan checks every positive edge of every relevant source row and verifies that no omitted destination has partition 1 outside the listed block. The minimum diagonals are 677/1026 and 61153/94976. For alpha=delta_252 and beta=delta_400, every word 1^n is possible under each preparation and their final hidden TV distance is exactly one. The result is ESTABLISHED as an algebraic implication from those explicit rational blocks and the zero cross-block premises; the finite artifact identification is separately NUMERICAL. No matrix power was numerically sampled to infer the quantifier “every n.”

The full 250-state kernel has connected support, a positive stationary law, and positive diagonal, so this obstruction survives full-chain irreducibility and holding. Those properties do not imply that the conditioned, killed support connects. Stationary masses of C and D are respectively 995496480/78934297349 and 90623232/78934297349, so both sectors have positive stationary mass. Positive mass does not mean a pair of observed stationary histories isolates them.

Falsifier: a mismatch in one displayed coefficient or zero cross-block premise in the bound retained kernel, or a parent-to-partition labeling disagreement.

### DKO06: Instantiation on the exact-block map and the fine-preparation boundary

For block_ab=1, the two killed components in DKN02 are C={256,...,259,280,...,287,316,...,323} and D={340,...,343,352,...,359,376,...,383}. Each has twenty parents. Their complete restricted edge lists are stored in the result under maps.block_ab.symbols.1.components. Their minimum positive diagonals are 7375/11928 and 5825/9744. Consequently delta_256 and delta_340 give hidden posterior TV=1 on block word 1^n for every n≥1, by precisely DKO02. This is ESTABLISHED as an implication from the exact finite support premises, whose artifact identification is NUMERICAL.

The chain here is the D-endpoint parent chain L=JMC from the frozen parent-sensitive construction, with positive pi=pC and target-conditional lift J. Every parent preparation nu used above has an admitted fine prepared law nu J. Its D-endpoint parent history is governed by L. Because the fine reference is positive on the component, these supported preparations have finite discrete relative entropy; no continuous subspace-recognition claim is imported. An arbitrary unprepared fine law q instead has the initial parent transition qMC before the prepared parent evolution. The present examples need no claim equating that first step with (qC)L, and they establish neither a result about one fixed recognition law nor one fixed stationary history family.

Falsifier: failure of the original prepared-history intertwining or an incorrect claim that the examples use an arbitrary unprepared first transition.

### DKO07: Hidden separation alone cannot establish prediction separation

Take four hidden states (s,y) with s,y∈{0,1}, observe g(s,y)=y, and set K((s,y),(s,y))=1/2 and K((s,y),(s',1-y))=1/4 for each s'∈{0,1}; all other entries are zero. The rows sum to one; K is symmetric, so uniform pi is positive and stationary. Opposite-y edges connect all states and every state has a positive diagonal. For repeated y, the killed matrix is (1/2)I on the two hidden states carrying y. Preparations delta_(0,y) and delta_(1,y) retain hidden TV=1 at every duration. Yet every hidden state gives probability 1/2 to each next label, so every supported preparation/history has next-observation prediction (1/2,1/2). Starting from uniform pi, the observed process is iid fair by the successive conditional probabilities. This is an ESTABLISHED counterexample to the implication “hidden nonforgetting implies next-observation nonforgetting,” even under positive stationarity, reversibility, irreducibility, and positive holding.

Falsifier: a row violating normalization, symmetry, the stated killed restriction, or the constant observation probabilities. These checks are the displayed four-state arithmetic and need no imported theorem or execution.

### DKO08: Semantic and quantifier erasure

Remove the favorable search direction, the R5 interpretation, gauge terminology, and the word “duration.” DKO01–DKO04 remain finite identities for a stochastic matrix and a deterministic partition, and DKO05–DKO06 remain conditional consequences of two explicit closed supports with positive diagonals. The only ordering parameter is the number of transitions, n-1 for n observations. No physical clock, continuum limit, gauge dynamics, or causal model is inferred. The auxiliary path measure fixes pi and L before comparing preparations; it is not the original sensor-generative joint, nor is its trajectory relative entropy automatically the original recognition-dependent VFE. This is an ESTABLISHED scope implication: deleting the interpretive/search labels changes none of the equations or hypotheses used in the proofs.

Falsifier: a proof step that depends on the affirmative prior, identifies a transition count with physical time, varies the generative joint while treating it as fixed, or silently replaces arbitrary preparations by stationary histories.

## Numerical observations kept separate

### DKN01: Retained-input readback and controls

NUMERICAL. The scan independently decoded 2300 positive sparse entries for 250 parent states, aggregated pi from 432 incidence masses, and checked exact row normalization, positive pi, stationarity, detailed balance, positive diagonals, and connected full support. The checks use Python integer/Fraction arithmetic and the frozen input digests; they are finite executable evidence, not a proof of a limiting conditional statement. The unchanged full kernel is the control for the difference between unconditional connected support and the restricted supports. Both declared observation maps were scanned; no new stochastic or matched-rate control was run. No seed applies because the scan is deterministic.

### DKN02: Complete bounded killed-support inventory

NUMERICAL. The partition-map symbols 0,...,7 have respectively component-size lists (2), (4,4), (4,4), (8,8,8,8), (4,4), (8,8,8,8), (8,8,8,8), and (16,16,16,16,16,16,16,16). The exact-block symbols 0 and 1 have lists (210) and (20,20). Every component has a positive minimum diagonal. The retained output contains all component members and all within-symbol edges, so the displayed examples can be checked against complete local support data rather than a selected trajectory.

### DKN03: The scan's stronger witness tests found none

NUMERICAL. All 27 partition killed components and three block killed components have nonconstant survival rows. No component has a constant observed row. For every compared component pair, the next-label coordinate intervals overlap for every label; no DKO03 interval gap was found. The scan examined all 32 positive stationary two-symbol partition entrances and all four positive block entrances. None is a conditional eigenrow, and no pair of same-final-symbol entrances has disjoint component supports. Thus none of the declared DKO04 stationary witnesses was found. These are outcomes of the bounded criteria, not a proof of uniform prediction forgetting or stationary-history forgetting.

For example, the partition-1 survival intervals are [134403/173488,22367/28728] and [73281/94976,115441/144774], which overlap. Its positive stationary entrances (0,1), (1,1), (3,1), and (5,1) all have support in both components and all fail the exact eigenrow equation. The exact-block-1 survival intervals [10783/11928,9011/9324] and [8609/9744,36437/38976] also overlap. No favorable-duration search followed this outcome.

## Attacks and remaining obligations

The support/degeneracy attack is resolved only for the stated arbitrary-preparation theorem. The preparation may put zero mass on other parents, but remains absolutely continuous relative to positive pi, and a positive diagonal supplies an explicit surviving path at every finite duration. DKO02 also proves the supremum statement for strictly positive preparations through finite-ratio continuity. It does not strengthen that result into persistent separation for one fixed strictly positive pair.

The timing and normalization attack is resolved by B_w beginning with E_y0 and by the power n-1. Every claim conditions only on a positive-mass word. No normalization of a zero forward message or use of an empty-word prediction after a transition occurs. Different components need not have matching survival mass; their posteriors are each normalized by their own positive denominators.

The observation-versus-hidden attack succeeds against any attempted inference from DKO05 or DKO06 to persistent next-label discrepancy. DKO07 is an explicit normalized reversible counterexample to that general implication, and DKN03 supplies no actual next-label lower bound. Similarly, the stationary-quantifier attack succeeds against promoting arbitrarily selected delta preparations into two observation histories under pi. The actual stationary two-symbol entrance checks do not isolate the chosen components. Longer stationary histories were not enumerated.

The full-kernel mixing attack fails for the scoped hidden conclusion for an artifact-backed reason: the exact scan verifies connected full support while the same bound kernel has the displayed disjoint killed blocks. A path connecting those blocks must leave the observed fiber and is removed by conditioning on repeated observations. No stronger claim about the actual mixing rate was needed.

The source-scope attack is resolved by preserving the original parent labels and checking the observation descends on every incidence; the hidden parent states were not coarsened again or relabeled by a nonequivariant shortcut. Existing observation-label covariance applies only with its already admitted commuting square. The scan executed no new gauge action.

The result leaves OPEN the actual all-duration next-observation forgetting question, the actual stationary-reachable-history uniform forgetting question, and any fixed-positive-preparation asymptotic comparison. A proof could settle them by controlling normalized restricted products under their proper quantifiers or by exhibiting supported reachable histories with a uniform discrepancy. Failure of the finite sufficient criteria is not evidence for convergence. The separate entropy-rate lane may establish average stationary approximation bounds without resolving these conditional questions.

The report and claim JSON are the only derivation edits in this lane. The scan, result, log, and command receipt are the only verification artifacts added. No changes to source theory, runtime modules, existing artifacts, configuration toggles, or the research vault are part of this investigation.

## Additional independent checks requested before freezing

### DKO09: Zero stationary memory rate does not imply uniform prediction forgetting

This independently checks IP6 in agents/independent-proof-check.md. Use hidden order (a0,a1,b,c), observation map g(a0)=g(a1)=a, g(b)=b, g(c)=c, and

K=[[1/2,0,1/2,0],
   [0,1/2,0,1/2],
   [1/4,1/4,1/4,1/4],
   [1/4,1/4,1/4,1/4]].

Each row and column sums to one, so pi=(1/4,1/4,1/4,1/4) is stationary. Squaring gives first rows (3/8,1/8,3/8,1/8) and (1/8,3/8,1/8,3/8), while the last two remain uniform. Thus K² is strictly positive. This chain is nonreversible: K(a0,c)=0 but K(c,a0)=1/4. The result does not supply a counterexample inside a separately imposed reversible class.

Under pi, the initial observed probabilities are (1/2,1/4,1/4). A positive history ending in b or c pins the last hidden state to its corresponding singleton, whose next row is uniform. A positive history ending in a has hidden posterior (1/2,1/2,0,0): this holds initially, is preserved on extension by a because the a restriction is (1/2)I, and is restored on an a extension from either singleton because the two entering probabilities are equal. These three cases give the same next-observation probabilities (1/2,1/4,1/4) after every history. Induction therefore gives the product observation law and zero stationary memory-rate error at every order.

Now take the two fixed strictly positive preparations mu=(2/5,1/5,1/5,1/5) and nu=(1/5,2/5,1/5,1/5). For every N≥0, the N+1 observation word a^(N+1) has probability (3/5)2^(-N) under each preparation. Its hidden posteriors are (2/3,1/3,0,0) and (1/3,2/3,0,0), giving hidden TV=1/3. Applying the next-observation rows gives (1/2,1/3,1/6) and (1/2,1/6,1/3), giving prediction TV=1/6. Hence primitive hidden dynamics, strictly positive fixed preparations, and zero stationary memory-rate error do not imply uniform next-observation forgetting over common positive words. This is ESTABLISHED by the displayed finite calculation, independent of a sampled trajectory.

The conditioning events are positive at every finite N but their probabilities vanish exponentially. The conclusion concerns every-word uniformity; it is not a failure of almost-sure forgetting under pi and it is not an actual R5 prediction witness. It strengthens the general scope warning while leaving the actual R5 next-prediction obligation open.

Falsifier: a violated row/column sum, zero entry of the displayed K², failure of the equal-a-posterior induction, or an incorrect preparation-specific posterior/prediction ratio.

### DKO10: Strict one-step positivity yields a uniform every-word bound

This independently checks IP7 without importing a contraction theorem. Assume a finite stochastic K with constants 0<ell≤K_ij≤u for every pair i,j. For an N+1 observation word w=(y0,...,yN) that has positive mass under each of two preparations, put h_N(i)=1 and, backward for t<N, v_(t+1)(j)=1[g(j)=y_(t+1)]h_(t+1)(j), h_t(i)=sum_j K_ij v_(t+1)(j). Strict positivity and nonempty observed fibers imply v_(t+1) is nonzero and every h_t(i)>0. Define the common conditional transitions

T_t^w(i,j)=K_ij v_(t+1)(j)/h_t(i).

They are stochastic and depend on K and the whole word, not on the preparation. The preparation-dependent conditioned initial distribution is alpha_i 1[g(i)=y0]h_0(i)/P_alpha(w). Multiplying it by the T_t^w along a hidden path cancels each successive h_t denominator against the preceding v_t factor. The resulting path probability is exactly the original alpha path product, all observation indicators included, divided by P_alpha(w). Thus the terminal posterior is obtained by propagating the appropriate conditioned initial distribution through these same N conditional transitions.

Since h_t(i)≤u sum_j v_(t+1)(j), each T_t^w row dominates epsilon z_t with epsilon=ell/u and z_t(j)=v_(t+1)(j)/sum_l v_(t+1)(l). For epsilon<1, write T_t^w=epsilon 1 z_t+(1-epsilon)R_t with R_t stochastic. For any two row laws p,q, their difference annihilates the common term, while

sum_j |sum_i (p_i-q_i)R_t(i,j)|≤sum_i |p_i-q_i| sum_j R_t(i,j)=sum_i |p_i-q_i|.

Each step therefore contracts TV by at most 1-epsilon, so the terminal hidden TV is at most (1-ell/u)^N, uniformly over the two preparations and all common supported words. The next-observation channel contracts TV by the same elementary inequality and obeys that bound too. If epsilon=1, the conditional rows coincide and one transition makes TV zero; at N=0 the bound is one. No stationarity or reversibility premise is used. This is ESTABLISHED by the conditional-path factorization and finite triangle inequality.

Strict positivity of an unconditioned power K^m cannot replace strict one-step positivity in this proof: the intermediate masks are present in the conditional kernels, and DKO09 has K²>0 yet a constant-word prediction gap. General finite-block replacements require bounds on the masked products themselves. The actual R5 scan has 2300 positive entries among 250²=62500 entries, so it does not satisfy this sufficient condition. No positive ell for all actual R5 entries is asserted.

Falsifier: a zero actual kernel entry while claiming ell>0, a backward vector normalized at zero, preparation dependence left inside a supposed common conditional transition, or failure of the displayed conditional-path telescoping identity.
