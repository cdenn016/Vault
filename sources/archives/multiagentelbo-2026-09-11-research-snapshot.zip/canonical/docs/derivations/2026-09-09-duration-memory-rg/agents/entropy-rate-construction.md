<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744","target_digest":"4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744"} -->

# Stationary entropy rates and duration-dependent memory error

Date: 2026-09-09. Contract: `contract-sha256-4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744`. Target digest: `4ce1356b98f794463890bb29eb4fd0dc1602c23629d5dfc5bdc81d11c4c89744`. Author lane: `entropy_rate_construction`.

This derivation is submitted for independent mathematical reconstruction. It assigns no ledger closure and reports no execution or numerical outcome. The author read Theory/SPEC.md in full, the frozen contract, the previous finite-memory action construction and its atomic proposals, and the previous duration-uniform obligation. The author also wrote the earlier generic finite-memory projection; author and implementation lanes share model, instructions, and filesystem. Those facts limit author independence. The arguments below supply mathematical evidence to be checked, rather than additional evidence from agreement among authors. Visible Markdown status tags use the meanings in SPEC; equation labels identify statements for later assembly. No novelty or literature-priority claim is made.

## Definitions and stationary preparation

**DEFINITION.** Throughout this derivation, X_t is a lemma-local finite hidden-state random variable, not the fixed structural datum X of the ambient gauge theory. Let S and A be nonempty finite sets, K a row-stochastic matrix on S, pi a probability row satisfying pi K=pi, and f:S->A a deterministic observation map. The hidden finite path law is pi(x_0) times the product of the intervening K entries, and Y_t=f(X_t). Restrict hidden states to S_+=supp(pi) when discussing irreducibility. This set is closed: stationarity and nonnegativity imply K(x,z)=0 when pi(x)>0=pi(z). Observation symbols of zero stationary probability remain null symbols. Let P_N be the resulting observed law on A^N. All logarithms are natural; zero entropy terms are zero; conditional probabilities are defined only on positive conditioning events. Negative indices used below denote finite stationary windows obtained by shifting this same path formula, so an unproved infinite-past conditional is never needed.

**HYPOTHESIS.** Stationary initialization is adopted for the entropy-rate and duration theorems. It excludes arbitrary hidden preparations. Such preparations require the separate exact filtering law, and none of the stationary identities below is asserted for them. The discrete index and the number N of observations measure auxiliary transition count: an N-observation block contains N-1 transitions. They do not define physical time.

**DEFINITION.** Write H_0=0, H_n=H(Y_0,...,Y_{n-1}), and

\[
 h_0=H(Y_0),\qquad h_j=H(Y_j\mid Y_0,\ldots,Y_{j-1})\quad(j\ge1).
 \label{eq:hist-dmr-conditional-entropy}
\]

For a fixed integer k>=0, Q_N^k denotes the stationary k-memory projection. For N<=k its law is exactly P_N. For N>k and k>=1 it starts with the exact joint prefix P_k and appends symbols with

\[
 r^k(a\mid c)=\frac{P_{k+1}(c,a)}{P_k(c)}\quad\text{when }P_k(c)>0,
 \qquad Q_N^k(y)=P_k(y_{0:k-1})\prod_{t=k}^{N-1}r^k(y_t\mid y_{t-k:t-1}).
 \label{eq:hist-dmr-projection}
\]

For k=0 the initial empty prefix has mass one and every appended row is P_1. In every case, a zero prefix has only zero extensions, without querying a null conditional. Let D_N^k=D(P_N||Q_N^k). Empty sums below are zero, including when the upper index is smaller than the lower one.

## DMR01. Entropy rate exists without irreducibility

**ESTABLISHED.** The sequence h_j is nonnegative and nonincreasing, has a limit h_inf, and H_n/n tends to h_inf. The entropy chain rule gives H_n=sum_{j=0}^{n-1}h_j. To establish the conditioning inequality used here, conditional mutual information is the average, over positive conditioning events, of the finite KL between a joint conditional and the product of its marginals. Each such KL is nonnegative: applying -log u>=1-u on the positive support proves this directly, with infinity when a positive numerator has zero denominator. Expanding the finite logarithm sums gives H(U|W)-H(U|V,W)=I(U;V|W)>=0. Stationarity therefore gives

\[
 0\le h_{j+1}=H(Y_{j+1}\mid Y_0,\ldots,Y_j)
 \le H(Y_{j+1}\mid Y_1,\ldots,Y_j)=h_j.
 \label{eq:hist-dmr-monotonicity}
\]

A decreasing nonnegative real sequence converges to its infimum. Given epsilon>0, choose J with h_j-h_inf<=epsilon for j>=J. The average discrepancy H_n/n-h_inf is at most the fixed initial sum divided by n plus epsilon. This proves its limit without interchanging infinite sums or conditional laws. No irreducibility, aperiodicity, strictly positive matrix, or forgetting premise is used.

## DMR02. The projected family is stationary and has exact short prefixes

**ESTABLISHED.** The laws Q_N^k are normalized, prefix-consistent, and stationary; their windows of length at most k+1 agree with P, and Q_N^k=P_N whenever N<=k+1. For k>=1 let C be the set of positive k-symbol words, give c mass P_k(c), and transition from c to suffix_k(ca) with probability r^k(a|c). Its incoming mass at d is the sum of P_{k+1}(c,a) over these shifts, which is P(Y_1:k=d)=P_k(d). Thus P_k is invariant. A positive outgoing transition cannot enter a null context because its incoming mass is nonnegative and bounded by the target invariant mass. Starting with P_k therefore never queries a null row. Summing normalized rows gives normalized and consistent extensions. Emitting the first coordinate of each successive context gives a stationary process with exactly the law in the definition. Its initial k+1 coordinates have masses P_k(c)r^k(a|c)=P_{k+1}(c,a). All shorter windows follow by marginalization and stationarity. The case k=0 is the stationary independent product of P_1. This supplies the stationary specialization of FMA01-FMA06 directly, including the extra exact symbol beyond the initially supplied k-block.

## DMR03. Finite path KL accumulates conditional entropy gaps

**ESTABLISHED.** For every k>=0 and N>=1,

\[
 D_N^k=\sum_{t=k}^{N-1}(h_k-h_t),
 \qquad D_N^k=0\text{ if }N\le k+1.
 \label{eq:hist-dmr-kl-identity}
\]

Every P-positive word has a positive initial prefix and positive context-plus-symbol factors, hence is Q-positive. Forward KL is finite. For N>k, the expected negative log of Q_N^k is H_k+(N-k)h_k by stationarity of the windows used in its rows. Subtracting H_N=sum_{t=0}^{N-1}h_t gives the identity. For N<=k the laws are identical by definition and the sum is empty; at N=k+1 its only term is zero. The exact initialization is load-bearing: replacing the initial P_k by another positive law alpha adds D(P_k||alpha) when subsequent rows are unchanged. If alpha excludes a positive P_k word, the resulting KL is infinite. This initialization term is not silently discarded.

## DMR04. The per-observation projection rate and finite-block lower bounds

**ESTABLISHED.** For each fixed k,

\[
 r_k:=\lim_{N\to\infty}\frac{D_N^k}{N}=h_k-h_\infty,
 \qquad 0\le h_k-h_m\le r_k\quad(m\ge k).
 \label{eq:hist-dmr-rate}
\]

For N>k, divide H_k+(N-k)h_k-H_N by N and use DMR01. Monotonicity gives the second statement, and h_k-h_m increases to r_k as m increases. Also r_k is nonincreasing in k. If r_k=0, all h_t for t>=k equal h_k, so DMR03 gives P_N=Q_N^k for every N: equality follows from the finite KL equality condition, obtained from the same strict log inequality. If r_k>0, some finite m>k has h_k>h_m. These implications concern one consistent stationary family, not independently selected laws at separate horizons.

## DMR05. Finite hidden state bounds excess entropy

**ESTABLISHED.** Put C_X=H(X_0). Then

\[
 E_n:=H_n-nh_\infty=\sum_{j=0}^{n-1}(h_j-h_\infty)\le C_X,
 \qquad E:=\sum_{j=0}^{\infty}(h_j-h_\infty)\le C_X.
 \label{eq:hist-dmr-excess}
\]

To prove this, fix finite positive integers b,n, and set U=Y_{-b:-1}, V=Y_{0:n-1}. The Markov path product, split at X_0, factors the conditional past and future given every positive X_0 state. Thus I(U;V|X_0)=0, including the deterministic observation at time zero. The chain rule for finite mutual information and its nonnegativity give I(U;V)<=I(U;V,X_0)=I(U;X_0)<=H(X_0). On the other hand, the entropy chain rule and stationarity give

\[
 I(U;V)=H_n-\sum_{j=0}^{n-1}h_{b+j}\le C_X.
 \label{eq:hist-dmr-past-future}
\]

Take b to infinity with n fixed: only n convergent terms occur, so this gives E_n<=C_X. The E_n are nondecreasing nonnegative partial sums, hence have a finite limit at most C_X; this defines E. No infinite-past entropy, ergodic theorem, or exchange of two infinite limits was assumed. Finally C_X<=log|S_+| follows from the nonnegativity of KL(pi||uniform on S_+).

## DMR06. Universal memory-rate decay

**ESTABLISHED.** For every k>=0,

\[
 0\le r_k\le\frac{C_X}{k+1}\le\frac{\log|S_+|}{k+1}.
 \label{eq:hist-dmr-universal-rate}
\]

Indeed r_j>=r_k for 0<=j<=k, so (k+1)r_k<=sum_{j=0}^k r_j<=E<=C_X. The denominator is k+1, not k: h_0 belongs to the same excess-entropy series. A requested per-observation rate tolerance epsilon>0 is therefore ensured by k>=max(0,ceil(C_X/epsilon)-1). This is a sufficient bound for each compatible stationary realization and does not estimate its true minimum memory order.

## DMR07. A hidden-row entropy lower bound on h_inf

**ESTABLISHED.** Define the observed transition row B_x(a)=sum_{z:f(z)=a}K(x,z), and

\[
 g=H(Y_1\mid X_0)=\sum_{x\in S_+}\pi(x)H(B_x).
 \label{eq:hist-dmr-hidden-row}
\]

Then h_inf>=g. For every j>=1, conditioning on X_{j-1} can only reduce H(Y_j|Y_0:j-1), and the Markov factorization makes Y_j conditionally independent of Y_0:j-1 given X_{j-1}. The reduced entropy is H(Y_j|X_{j-1})=g by stationarity. Taking the decreasing limit proves the assertion. This quantity uses the grouped next-state row and its hidden-state average; it is not H(X_1|X_0), the entropy of the averaged row, or the entropy of an observation-filter posterior.

## DMR08. Bounds computable from finite observed blocks

**ESTABLISHED.** Suppose exact h_0,...,h_m are available, m>=k, and C_X and g are known. For every n>=1 whose block entropy H_n is available, DMR05 gives h_inf>=(H_n-C_X)/n. Consequently, for any nonempty finite set J of available positive block lengths, define

\[
 \ell=\max\left(0,g,\max_{n\in J}\frac{H_n-C_X}{n}\right),\qquad
 a_{k,m}=h_k-h_m,
\]
\[
 u_{k,m}=\min\left(h_k-\ell,\frac{C_X}{k+1},
 h_k-h_m+\frac{C_X}{m+1}\right).
 \label{eq:hist-dmr-finite-rate-bounds}
\]

Then ell<=h_inf<=h_m and 0<=a_{k,m}<=r_k<=u_{k,m}. The last upper bound uses r_k=h_k-h_m+r_m and DMR06. In particular, h_k-(H_n-C_X)/n is a valid rate upper bound, and h_k-g is another. The index m labels a conditional entropy while n labels the number of observations in a block: H_n=sum_{j=0}^{n-1}h_j. A four-observation law supplies h_0 through h_3 and H_1 through H_4, so it allows m=3 and J={1,2,3,4} without another observed path generation.

**ESTABLISHED.** Certified intervals propagate in the same direction. If L_j<=h_j<=U_j, C_X<=C_+, and g>=g_-, a safe entropy-rate lower bound and rate bracket are

\[
 \ell_-=\max\left(0,g_-,\max_{n\in J}\frac{\sum_{j=0}^{n-1}L_j-C_+}{n}\right),
 \quad a_- =\max(0,L_k-U_m),
\]
\[
 u_+=\min\left(U_k-\ell_-,\frac{C_+}{k+1},
 U_k-L_m+\frac{C_+}{m+1}\right),
 \qquad a_-\le r_k\le u_+.
 \label{eq:hist-dmr-certified-rate-bounds}
\]

Each inequality substitutes an endpoint with the required sign. These formulas are conditional on intervals enclosing quantities from one compatible stationary hidden realization. A generic collection of numbers or individually normalized tables does not establish that premise. Under that premise u_+ is nonnegative; an inverted bracket signals inconsistent inputs or incorrect arithmetic rather than an instruction to manufacture a probability law.

## DMR09. Explicit duration bounds and finite-rate correction

**ESTABLISHED.** Let a<=r_k<=u be any valid nonnegative bracket and m>=k. For all N>=1,

\[
 0\le r_k-\frac{D_N^k}{N}\le\frac{C_X}{N},
\]
\[
 \max\left(0,Na-C_X,(N-m)_+(h_k-h_m)\right)
 \le D_N^k\le (N-k-1)_+u.
 \label{eq:hist-dmr-duration-bounds}
\]

Here v_+=max(v,0). For N>k, DMR03 gives N r_k-D_N^k=k r_k+sum_{t=k}^{N-1}r_t. The first k excess terms are at least k r_k, so this nonnegative expression is at most E_N<=C_X. For N<=k, D_N^k=0 and N r_k<=C_X by DMR06. This proves the correction for every N, including k=0. Each summand with t>=m is at least h_k-h_m, proving the second lower bound. The t=k term is zero and every later summand is at most r_k<=u, proving the upper bound.

**ESTABLISHED.** Retaining the computed prefix improves the extrapolation. If h_0 through h_m are known, D_{m+1}^k is known from DMR03, and for N>=m+1,

\[
 D_{m+1}^k+(N-m-1)(h_k-h_m)
 \le D_N^k\le D_{m+1}^k+(N-m-1)u.
 \label{eq:hist-dmr-prefix-extrapolation}
\]

The omitted summands have t>=m+1 and lie between h_k-h_m and r_k. Durations N<=m+1 use their finite entropy sums directly. For certified intervals the same inequalities use lower endpoints in lower bounds, upper endpoints in upper bounds, and C_+ wherever C_X is subtracted. No mixing or filter-contraction rate is used in these duration statements.

## DMR10. A whole-path upper bound and its memory requirement

**ESTABLISHED.** For every finite duration,

\[
 \operatorname{TV}(P_N,Q_N^k)\le
 \min\left(1,\sqrt{D_N^k/2}\right)
 \le\min\left(1,\sqrt{(N-k-1)_+u/2}\right).
 \label{eq:hist-dmr-tv-upper}
\]

For completeness, take B={y:P_N(y)>=Q_N^k(y)}, so the difference of its probabilities is TV. Grouping the KL terms on B and its complement cannot increase KL: after dividing each group by its total, the difference is a nonnegative within-group KL. The resulting binary KL d(p||q) is at least 2(p-q)^2. For fixed 0<q<1, subtract 2(p-q)^2; the derivative at p=q is zero and its second derivative is 1/[p(1-p)]-4>=0, so its minimum is zero. Boundary cases follow by continuity or infinite KL. This proves the bound used here without importing Pinsker's inequality as an unchecked premise.

**ESTABLISHED.** For C_X>0, N>=1, and a desired TV tolerance delta>0, the universal upper bound ensures TV<=delta whenever

\[
 k+1\ge\frac{C_X N}{C_X+2\delta^2}
 \quad\text{and }0\le k\le N-1.
 \label{eq:hist-dmr-memory-duration}
\]

Substitute u=C_X/(k+1) and rearrange C_X(N-k-1)/(k+1)<=2 delta^2. If C_X=0, DMR06 and DMR03 give exact equality at every k,N. Choosing k>=N-1 also gives exact equality. This criterion is sufficient and may be conservative. A positive lower bound on KL is not inverted into a lower bound on TV; long-path separation requires the distinct argument below.

## DMR11. Hidden irreducibility induces context irreducibility

**HYPOTHESIS.** Only for DMR11-DMR13, assume K restricted to S_+ is irreducible: between every ordered pair of retained hidden states there is a finite positive-probability path. Periodicity is permitted. This excludes mixtures of disjoint recurrent classes; no actual retained kernel is declared irreducible by this derivation.

**ESTABLISHED.** Under this hypothesis every positive k-context transition graph of Q^k is irreducible. For k>=1 choose positive hidden paths realizing arbitrary positive observation words c,d of length k. Join the final hidden state of the first realization to the initial hidden state of the second by a positive hidden path. The concatenated path has positive stationary probability because its initial state lies in S_+. Every consecutive k+1 observation window therefore has positive P mass, and each corresponding context shift is an allowed Q^k transition. The shifts connect c to d. For k=0 the independent observation process can be represented by the one-symbol transition matrix with every row equal to P_1, restricted to its positive symbols; this graph is irreducible. Thus no separate aperiodicity premise is needed for the word-frequency argument.

## DMR12. A finite-chain word-frequency law in mean square

**ESTABLISHED.** Let Z_t be any stationary finite irreducible Markov chain with transition T and invariant probability nu. For any bounded real function F of L consecutive states, the empirical average of F(Z_t,...,Z_{t+L-1}) converges in mean square to its stationary mean. Here is an elementary proof that includes periodic T. Put A_n=(I+T+...+T^{n-1})/n. These stochastic matrices lie in a compact finite-dimensional set. Every subsequential limit B satisfies T B=B because T A_n-A_n=(T^n-I)/n tends entrywise to zero. Every real column v of B solves Tv=v and is constant: at a maximal component the stochastic average can equal its maximum only if all outgoing positive neighbors have the same maximum, and irreducibility propagates that equality to every component. Thus B has identical rows. Since nu A_n=nu, its common row must be nu. Every subsequential limit is therefore 1 nu, proving A_n->1 nu.

To pass from state averages to blocks, let F_t=F(Z_t,...,Z_{t+L-1}), let mu=E F_0, define a(x)=E[F_0 1{Z_{L-1}=x}], and b(x)=E[F_0|Z_0=x]. For s>=L, the Markov product gives

\[
 c_s:=\operatorname{Cov}(F_0,F_s)
 =a\left(T^{s-L+1}-\boldsymbol 1\nu\right)b.
 \label{eq:hist-dmr-block-covariance}
\]

Consequently (1/n)sum_{s=1}^n c_s tends to zero, because only finitely many overlapping blocks are omitted and the remaining matrix averages tend to 1 nu. Write C_j=sum_{s=1}^j c_s=o(j). For the average over n block positions, stationarity gives

\[
 \operatorname{Var}\left(\frac1n\sum_{t=0}^{n-1}F_t\right)
 =\frac{n c_0+2\sum_{s=1}^{n-1}(n-s)c_s}{n^2}
 =\frac{n c_0+2\sum_{j=1}^{n-1}C_j}{n^2}\longrightarrow0.
 \label{eq:hist-dmr-mean-square}
\]

Indeed, after a fixed initial segment, |C_j|<=epsilon j, so the normalized absolute sum is at most a vanishing initial contribution plus epsilon. This establishes the limit without a cited ergodic theorem, a spectral-gap assumption, or a claim that T^n itself converges. The particular case F=1{observed word w} supplies the word-frequency law for any deterministic observation of this chain.

## DMR13. Positive fixed-memory rate forces whole-path TV to one under irreducibility

**ESTABLISHED.** Under DMR11 and for fixed k, if r_k>0 then

\[
 \lim_{N\to\infty}\operatorname{TV}(P_N,Q_N^k)=1.
 \label{eq:hist-dmr-tv-separation}
\]

Choose a finite m>k with h_m<h_k. Then D_{m+1}^k>0 by DMR03, so the two laws disagree on at least one word w of length L=m+1. Write p=P_L(w), q=Q_L^k(w), and Delta=|p-q|>0. Interchange the names of the upper and lower means in the following event if necessary. Assume p>q and let B_N be the event that the empirical frequency of w among n=N-L+1 starting positions exceeds (p+q)/2. DMR12 applied to the hidden chain shows P_N(B_N)->1. Applied to the irreducible context chain from DMR11, it shows Q_N^k(B_N)->0. Hence TV is at least P_N(B_N)-Q_N^k(B_N), which tends to one.

The argument also gives an explicit finite-N inequality. If V_P(n),V_Q(n) are the variances of this same empirical frequency under the two stationary laws, then

\[
 \operatorname{TV}(P_N,Q_N^k)\ge
 \max\left(0,1-\frac{4(V_P(n)+V_Q(n))}{\Delta^2}\right).
 \label{eq:hist-dmr-tv-covariance-bound}
\]

On either classification error the absolute deviation from its mean is at least Delta/2, so integrating the squared deviation proves the probability bound used here. Each variance has the finite covariance-sum representation in DMR12. No numerical separation time is inferred without bounding or evaluating those sums. If r_k=0, DMR04 instead gives TV=0 at every duration. This dichotomy is for fixed k; it makes no assertion about a sequence k that increases with N. The scalar bounds of DMR09 alone would not prove it.

## DMR14. Reducibility prevents an unconditional TV-to-one conclusion

**ESTABLISHED.** Positive r_k alone does not force the preceding TV limit. Fix 0<alpha<1. Take a hidden chain that stays forever at one absorbing state with observation 2 and, on three other states, follows the deterministic cycle with observations 0,0,1. Give the absorbing state mass 1-alpha and each cycle state mass alpha/3. This is a stationary four-state model. For k=1 the observed first-order projection has two closed observation components. Its binary component has rows r(0|0)=r(1|0)=1/2 and r(0|1)=1; its symbol-2 component is constant. The actual observed entropy rate is zero: an entire word is determined by the initial hidden state, so H_N<=H(X_0) and H_N/N->0. Its one-step conditional entropy is h_1=alpha(2/3)log 2, so r_1>0.

Both path laws give mass 1-alpha to the identical all-2 path and mass alpha to their respective binary path laws, with disjoint supports between these components. Thus their total variation equals alpha times the binary-component total variation. The binary hidden three-cycle is irreducible, has positive first-order rate, and satisfies DMR13 even though it is periodic. Therefore the full TV limit is alpha<1. This disproves removal of the irreducibility hypothesis with the same stationary finite-HMM and fixed-memory quantifiers.

## DMR15. Relabeling and the admitted symmetry scope

**ESTABLISHED.** A bijection of observation labels applied to every coordinate transports all word laws, contexts, and conditional rows, commutes with the k-memory projection, and leaves H_n,h_j,h_inf,r_k,D_N^k,TV and all displayed scalar bounds invariant. Finite sums are merely reindexed, and suffix selection commutes with the coordinatewise bijection. A coherent hidden-state bijection transports K,pi,f together and also preserves C_X and g by reindexing. An already admitted gauge action yields the same conclusion only when its normalized hidden-law transport and observation square identify the corresponding observed laws, with the labels transported as declared. This statement does not supply a missing gauge square or identify an arbitrary partition change with a symmetry.

## DMR16. Auxiliary VFE and conditional-forgetting boundaries

**ESTABLISHED.** For fixed normalized auxiliary targets P_N,Q_N^k and a recognition law rho supported on supp(P_N), all relevant finite logarithms exist and

\[
 D(\rho\Vert Q_N^k)-D(\rho\Vert P_N)
 =E_\rho\log\frac{P_N}{Q_N^k}.
 \label{eq:hist-dmr-auxiliary-vfe}
\]

Direct subtraction of the two finite sums proves the identity; any common additive evidence constant cancels. The targets must remain fixed independently of the subsequently varied rho. Averaging at rho=P_N yields D_N^k, while another supported rho uses its own weights. Thus the stationary entropy-rate result controls that particular P-average and does not turn it into a uniform recognition-law bound.

**NOT-CLAIMED.** This derivation does not identify either auxiliary path target with the original sensor joint or sensor posterior, and it declines a physical-time, geometric-action, curvature-penalty, or completed RG interpretation. Such identifications require separately declared constructions and compatibility statements. The finite hidden-chain entropy bounds do not supply them.

**NOT-CLAIMED.** No uniform conditional-forgetting conclusion over all observation words or arbitrary initial preparations is asserted. All entropy averages above use the fixed stationary law. A null word has no conditional, and a positive but rare word can preserve preparation information without contradicting any average bound. A uniform statement requires an explicitly quantified supported filtering contraction or a proof excluding persistent preparation distinctions; that separate obligation belongs to the conditional-kernel investigation. Irreducibility of the unconditioned hidden chain alone is not used as a substitute for it.

## DMR17. Memory schedules that control the whole path

**ESTABLISHED.** The summability and monotonicity already proved imply k r_k->0. For k>=2, there are at least k/2 indices between floor(k/2) and k, and every corresponding r_j is at least r_k. Therefore

\[
 0\le k r_k\le2\sum_{j=\lfloor k/2\rfloor}^{\infty}r_j\longrightarrow0.
 \label{eq:hist-dmr-summable-rate}
\]

For any fixed 0<alpha<1 and integer schedule alpha N<=k(N)<=N-1 for all sufficiently large N, D_N^{k(N)}<=N r_{k(N)}<=k(N)r_{k(N)}/alpha tends to zero. DMR10 then gives TV(P_N,Q_N^{k(N)})->0. The universal C_X/(k+1) bound by itself would yield only a constant upper bound at linear memory; the stronger conclusion uses the finite hidden-state excess series, not an assumed filter-contraction rate.

**ESTABLISHED.** There also exists a schedule k(N)=o(N) with k(N)->infinity, k(N)<=N-1, and N r_{k(N)}->0, for this particular stationary process. To construct it without an effective rate claim, for each integer j>=2 choose M_j so that k r_k<=j^{-3} for every k>=M_j. Choose strictly increasing integer thresholds N_j>=max(j(M_j+1),2j^2). For N>=N_2, let j(N) be the largest j with N_j<=N, and set k(N)=floor(N/j(N)); define the finitely many earlier values by k(N)=N-1. On the j-th segment, k>=M_j and k>=N/(2j), so

\[
 \frac{k(N)}N\le\frac1{j(N)}\longrightarrow0,
 \qquad N r_{k(N)}\le\frac{2}{j(N)^2}\longrightarrow0.
 \label{eq:hist-dmr-sublinear-schedule}
\]

Also k>=2j-1 on that segment, so k tends to infinity. DMR10 again gives whole-path TV tending to zero. The thresholds depend on the uncomputed tail behavior of the full excess-entropy series. The existence proof supplies no computable schedule from four-observation data, no numerical constants for the retained model, and no success guarantee for an arbitrarily selected sublinear schedule. It does not conflict with DMR13, which holds k fixed.


