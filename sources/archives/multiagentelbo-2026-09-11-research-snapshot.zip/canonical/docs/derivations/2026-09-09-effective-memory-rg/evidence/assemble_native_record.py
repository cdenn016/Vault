"""Bind scoped proofs and retained execution without rerunning scientific code."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[4];RUN=Path(__file__).resolve().parent.parent
VERIFY=ROOT/'docs/verification/2026-09-09-effective-memory'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(name: str, value: object) -> None:
    (RUN/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def main() -> None:
    assert not (RUN/'evidence/native-adjudication.json').exists(),'no implicit reclassification'
    contract=json.loads((RUN/'problem-contract.json').read_text(encoding='utf-8'))
    meta={k:contract[k] for k in ('schema_version','contract_id','target_digest')}
    intake=json.loads((RUN/'evidence/native-intake.json').read_text(encoding='utf-8'))
    assert intake['accepted_current_scoped_evidence']
    assert all(sha(ROOT/p)==h for p,h in intake['read_artifact_sha256'].items())
    source={}
    raw={}
    for path in VERIFY.glob('*.command.json'):
        data=json.loads(path.read_text(encoding='utf-8'))
        for rel,h in data['source_sha256'].items():
            assert sha(ROOT/rel)==h;source[rel]=h
        raw[path.relative_to(ROOT).as_posix()]=sha(path)
    for path in VERIFY.glob('*.result.json'):
        data=json.loads(path.read_text(encoding='utf-8'))
        assert data['returncode']==0 and data['source_unchanged'] and data['driver_unchanged']
    pair=json.loads((VERIFY/'pair-support.json').read_text(encoding='utf-8'))
    for rel,h in [('src/multiagent_elbo/rg_v2/synchronized_pair_support.py',pair['module_sha256']),
                  ('tests/rg_v2/test_synchronized_pair_support.py',pair['test_source_sha256']),
                  ('docs/verification/2026-09-09-effective-memory/inspect_pair_support.py',pair['script_sha256'])]:
        assert sha(ROOT/rel)==h;source[rel]=h
    for name,h in pair['inputs'].items():
        rel='docs/verification/2026-09-09-parent-sensitive/'+name
        assert sha(ROOT/rel)==h;source[rel]=h
    cases=[]
    for path in VERIFY.glob('*.xml'):
        cases.extend(ET.parse(path).getroot().findall('.//testcase'))
    ids=[c.attrib['classname']+'::'+c.attrib['name'] for c in cases]
    assert len(cases)==len(set(ids))==36
    assert not any(c.find(t) is not None for c in cases for t in ('failure','error','skipped'))
    for path in VERIFY.iterdir():
        if path.is_file() and path.suffix in ('.json','.xml','.log','.py') and not path.name.startswith('delivery'):
            raw[path.relative_to(ROOT).as_posix()]=sha(path)
    science={**meta,'source_sha256':source,'raw_artifact_sha256':raw,
             'latest_cases':dict(distinct=36,passed=36,failed=0,errors=0,skipped=0,execution_total=36),
             'scientific_executions':{'entropy':1,'pair_support':1,'saved_output_readback':1},
             'scope':'Exact source-bound finite execution; saved-output readback does not repropagate g2..4 or repeat the pair scan.',
             'user_excluded':['tamper, corruption and forgery checks'],'unrun':['old producers','full suite','held S1-S3','GPU science'],
             'runtime':'Anaconda CPython 3.12.7 for bounded source paths, not project-wide compatibility.'}
    dump('evidence/scientific-record.json',science)
    for name in ('entropy-results.json','pair-support.json','independent-readback.json','primary-travers-note.md'):
        (RUN/'evidence'/name).write_bytes((VERIFY/name).read_bytes())
    authors=[json.loads((RUN/'agents'/name).read_text(encoding='utf-8')) for name in ('entropy-claims.json','pair-claims.json')]
    assert len(authors[0]['claims'])==13 and len(authors[1]['claims'])==9
    claims=[];evidence=[];edges=[];attacks=[]
    def ev(eid: str,kind: str,path: str,statement: str,conditions: list[str]) -> str:
        evidence.append(dict(id=eid,kind=kind,supports=True,scope=statement,side_conditions=conditions,
                             artifact_path=path,artifact_sha256=sha(RUN/path)))
        return eid
    def add(cid: str,statement: str,scope: str,kind: str,conditions: list[str],falsifier: str,eids: list[str],deps: list[str]) -> None:
        claims.append(dict(id=cid,statement=statement,quantifiers=scope,kind=kind,falsifier=falsifier,
                           target_digest=meta['target_digest'],state='EVIDENCE_VERIFIED',assumption_ids=[],
                           explicit_assumptions=conditions,evidence_ids=eids,bridge_premise_ids=[]))
        edges.extend({'from':cid,'to':dep} for dep in deps)
        attacks.append(dict(id='attack-'+cid,claim_ids=[cid],attack=falsifier,
                            response='The written independent/source check and current scoped evidence retain the stated conditions and numerical limits.',
                            disposition='REJECTED',artifact_path='agents/native-closure-coverage.md',
                            artifact_sha256=sha(RUN/'agents/native-closure-coverage.md')))
    for author in authors:
        for c in author['claims']:
            cid=c['id'];path='agents/entropy-bracket-construction.md' if cid.startswith('EBR') else 'agents/pair-support-construction.md'
            conditions=c['assumptions'];scope=c.get('quantifiers','Under exactly these finite hypotheses: '+'; '.join(conditions))
            eids=[ev('proof-'+cid,'DERIVATION',path,c['statement'],[c.get('derivation',c.get('proof_sketch','')), *conditions]),
                  ev('check-'+cid,'DERIVATION','agents/independent-proof-check.md',c['statement'],
                     ['Independent initial reconstruction followed by source/primary comparison; shared model and filesystem.'])]
            if cid=='SPM09':
                eids.append(ev('primary-'+cid,'APPLICABLE_THEOREM','evidence/primary-travers-note.md',c['statement'],
                               ['Travers1211.6181v2 Theorem2; finite irreducible stationary flag-block hypothesis, coprime period, explicit future-emission mapping.']))
            add(cid,c['statement'],scope,'MATHEMATICAL',conditions,c['falsifier'],eids,c['dependencies'])
    for c in authors[1]['numerical_observations']:
        cid=c['id'];scope=c.get('quantifiers','One retained exact finite pair-support packet; no asymptotic conclusion from simulation.')
        eids=[ev('scan-'+cid,'NUMERICAL','evidence/pair-support.json',c['statement'],[scope]),
              ev('execution-'+cid,'NUMERICAL','evidence/scientific-record.json',c['statement'],['Current source/input/raw JUnit binding.'])]
        add(cid,c['statement'],scope,'NUMERICAL_OBSERVATION',c.get('assumptions',[]),c.get('falsifier','A current source, support or raw-output discrepancy.'),eids,c.get('dependencies',[]))
    numbers=[
      ('EMN01','Fifteen new tiny entropy tests passed once, and the combined current entropy and pair packets contain 36 distinct passing cases.',
       'Raw JUnit supplies exact totals; no failures, errors or skips. Readback assertions are not test cases.',[]),
      ('EMN02','One retained R5 computation supplies g1 through g4 on both maps, reuses h0 through h3, and improves eight rate and 32 duration/Pinsker bounds.',
       'The fixed positive stationary kernel, four future transitions, two declared maps and configured durations only. Deeper endpoints were not independently repropagated.',['EBR02','EBR07','EBR08']),
      ('EMN03','Separate saved-output arithmetic confirms all 14 available-order decisions while preserving every null result.',
       'Sufficient certificate ordering among k=0..3 only; no true minimum or actual tolerance-failure claim.',['EBR10','EMN02'])]
    for cid,statement,scope,deps in numbers:
        eids=[ev('execution-'+cid,'NUMERICAL','evidence/scientific-record.json',statement,[scope]),
              ev('readback-'+cid,'NUMERICAL','evidence/independent-readback.json',statement,[scope])]
        if cid!='EMN01':eids.append(ev('endpoints-'+cid,'NUMERICAL','evidence/entropy-results.json',statement,[scope]))
        add(cid,statement,scope,'NUMERICAL_OBSERVATION',[],'A source, endpoint, arithmetic, JUnit or stated-scope discrepancy.',eids,deps)
    target=contract['target'];dependencies=[c['id'] for c in claims]
    add('target',target['statement'],target['quantifiers'],'MATHEMATICAL',[],target['falsification_criterion'],
        [ev('target-proof','DERIVATION','construction-or-strongest-theorem.md',target['statement'],['Frozen finite target; uncomputed constants and failed tolerance certificates remain explicit.'])],dependencies)
    ids=[c['id'] for c in claims]
    assert len(ids)==len(set(ids)) and all(e['from'] in ids and e['to'] in ids for e in edges)
    dump('claim-ledger.json',{**meta,'assumptions':[],'evidence':evidence,'claims':claims})
    dump('dependency-dag.json',{**meta,'edges':edges})
    recon=dict(claim_ids=ids,method='Independent reconstruction followed by explicit source, primary and retained-output comparison.',result='PASS',
               conclusion='Current scoped proof or executed evidence covers every ID; no agent vote closes a claim.',
               artifact_path='agents/native-closure-coverage.md',artifact_sha256=sha(RUN/'agents/native-closure-coverage.md'))
    dump('adversarial-report.json',{**meta,'attacks':attacks,'independent_reconstruction':recon,
                                   'oracle_erasure':{**recon,'method':'Erase favorable direction and reconstruct finite information/support identities with the same primary hypotheses.'}})
    families=[('boundary-information',[x for x in ids if x.startswith('EBR')], 'Finite entropy chain rules and supported conditional independence.'),
              ('synchronized-support',[x for x in ids if x.startswith('SPM') and x!='SPM09'],'Finite pair reachability, complete closed complement and constructive flag words.'),
              ('stationary-exponential',['SPM09'],'Checked primary flag-block theorem, with existence versus computed constants distinguished.'),
              ('finite-arithmetic',[x for x in ids if x.startswith(('EMN','SPN'))],'Source-bound exact finite computation and saved-output integration readback.')]
    dump('approach-registry.json',{**meta,'mechanism_families':[dict(family_id=fid,core_mechanism=mechanism,target_obligation_ids=cids,
          representation='Finite stationary rational kernels, output words, entropy intervals and synchronized pairs.',
          invariant_or_obstruction='Boundary-information gap or complete support certificate.',
          obligations=['Keep timing, stationary preparation, support and arithmetic limits explicit.'],
          bridge='Frozen target combines finite proofs with fixed retained observations.',failure_test='Admitted normalized counterexample or bound source mismatch.',
          verified_results=cids,open_gaps=[],novelty_fingerprint='Direct finite derivations and named primary theorem; no priority claim.',
          disposition='established within frozen scoped target') for fid,cids,mechanism in families]})
    dump('release.json',{**meta,'checkpoint':'Current finite proofs and exact evidence assembled.','target_claim':'target','terminal_status':None,
         'certificate_claim':'target','strongest_result':'Implemented two-sided finite entropy/memory brackets and pair-support certificates; admitted qualitative exponential entropy convergence on both unchanged R5 maps.',
         'unresolved_obligations':[],'limitations':['Finite effective-memory target only; broad RG goal remains active.',
         'No evaluated useful exponential prefactor/rate; no long-duration TV 0.1 certificate from tested orders.',
         'No every-word contraction, original sensor-VFE replacement, curvature-action change or physical-time identification.',
         'Depth-controlled exact evaluator with finite arithmetic guard; not an unlimited adaptive solver.']})
    dump('evidence/native-adjudication.json',{**meta,'method':'Root classification from read current proofs and exact recorded output after separate checking.',
         'totals':{'claims':len(claims),'mathematical':sum(c['kind']=='MATHEMATICAL' for c in claims),'numerical':sum(c['kind']=='NUMERICAL_OBSERVATION' for c in claims)},
         'claims':{c['id']:{'state':c['state'],'kind':c['kind'],'evidence_ids':c['evidence_ids']} for c in claims}})
    print(json.dumps({'claims':len(claims),'evidence':len(evidence),'edges':len(edges),'attacks':len(attacks)}))

if __name__=='__main__':main()
