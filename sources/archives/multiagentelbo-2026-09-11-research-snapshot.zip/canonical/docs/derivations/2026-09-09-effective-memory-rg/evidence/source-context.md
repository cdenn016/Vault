<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530", "schema_version": "rigorous-theory-search/v1", "target_digest": "744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530"} -->

# Source and interpretation boundary

The repository Theory/SPEC.md remains the governing fixed normalized generative/recognition and typed-RG boundary, with SHA256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. The prior duration-memory record provides the exact-prefix stationary path-KL identity and the separate arbitrary-preparation killed-support counterexamples. Current code and inputs were read directly; memory supplied orientation only.

Travers arXiv:1211.6181v2 was inspected in full at the relevant definitions, conversion, flag-state theorem, block construction and pair test. This is a bounded primary-theorem applicability check, not a systematic review or priority claim. Destination-state emission maps its edge time zero to this calculation's future observation Y1. The primary proof uses base-two logs; multiplying entropy by log(2) converts to nats without changing a limsup exponential root. The pair lane records the exact theorem and hypotheses in its separate primary note.

These theorem uses address averaged stationary observation entropy. They do not establish uniform filtering along every word, and do not alter the original generative joint or its curvature-action terms. Existing curvature and holonomy constructions remain in the wider program assembly.
