<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530", "schema_version": "rigorous-theory-search/v1", "target_digest": "744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530"} -->

# Rigorous theory search report

## Frozen contract

The [frozen contract](problem-contract.json) asks for finite two-sided stationary entropy brackets, a terminating synchronized-pair certificate, one exact retained calculation through four future transitions and one bounded support scan per observation map. It requires precise primary-theorem applicability and preserves all uncomputed constants and physical boundaries. The target digest is the metadata digest above.

## Terminal status

The finite effective-memory target is supported by the current derivations and recorded executions, subject to the native structural gates recorded separately. The broader complete renormalization goal remains active. A finite target does not close interacting critical/continuum, general geometric-section or physical-identification obligations.

## Certificate

The [assembled construction](construction-or-strongest-theorem.md) combines EBR01–EBR13 and SPM01–SPM09 with source-bound finite evidence. The native ledger gives one claim per entry, exact artifact links and dependencies. The mathematical sources are written proofs and one checked applicable primary theorem; the numerical sources are the actual executed outputs and raw JUnit. Agent agreement and record validation are not proof.

## Strongest verified result

For every finite stationary hidden Markov model with deterministic observations, the hidden-boundary entropy g_m increases to the entropy rate and the observed conditional entropy h_{m-1} decreases to it. Their gap is conditional boundary information, has sum at most H(X_0), and is at most H(X_0)/m. This supplies finite precision-aware entropy and memory certificates without mixing assumptions. Exact graph reachability supplies merging paths or a complete closed complement on every finite labeled support graph. For actual R5, both maps satisfy a flag-block sufficient condition for exponential stationary entropy convergence; the partition requires immediate incompatibility for its 1,024 nonmergeable pairs. No useful exponential constants were evaluated.

The retained g_1,...,g_4 improve rate upper bounds and preserve the failure to certify long-duration TV tolerance 0.1 with the available orders. All 36 new tiny tests passed once. The two scientific lanes each ran once; the separate saved-output readback performed 268 assertions without hidden or graph repropagation.

## Dependency closure

The proof applies to normalized finite stationary kernels and one compatible observation map. Current R5 kernel, pi, labels, stochasticity, stationarity, support and holding probabilities are recorded by the exact study/scan or retained immutable input. The earlier exact-prefix path-KL result remains scoped to the same auxiliary process. The Travers hypothesis mapping explicitly distinguishes block mergeability from partition mergeable-or-incompatible support and produces a common aperiodic flag block. The claim graph retains mathematical versus numerical dependency types; no unsupported universal or physical bridge is inserted.

## Independent reconstruction

The separate checker first reconstructed the entropy and pair arguments from the frozen contract, then read author proofs, source, retained outputs and theorem mapping. Its written counterexamples distinguish entropy convergence, mergeability and every-word contraction. The numerical readback separately reconstructs interval and selector arithmetic from saved endpoints and recounts raw JUnit; it is not independent g_2,...,g_4 or pair-scan reproduction. The author of that arithmetic check also wrote the entropy proof, and all lanes share model family and filesystem. The independence claims are limited accordingly.

## Oracle erasure

Removing the favorable search direction and the R5/physics names leaves finite conditional-entropy identities, a graph reachability equivalence, a terminating flag-word construction and a mapped primary theorem. The unchanged normalized auxiliary law and exact edge support determine every numerical calculation. No language-model vote or assumed positive outcome enters a certificate.

## Unresolved obligations

The requested bounded target preserves its declared unsuccessful tolerance certificates and unevaluated exponential coefficients. The [next obligation](agents/next-quantitative-memory-obligation.md) constructs quantitative flag-block constants and controls computational cost. It is outside this four-transition calculation. The complete RG program, physical action/clock identification, general geometric limits and interacting critical universality remain open.

## Scope and limitations

The implemented endpoint evaluation is finite-depth and uses a finite arithmetic guard. The mathematical arbitrary-accuracy construction is not a claim of efficient or unrestricted executable convergence. The first future observation follows a transition; duration N counts observations. Null conditional rows are never invented. Order three has no positive rate lower certificate here. No minimum-memory order, uniform conditional forgetting, computed exponential prefactor, original sensor-VFE replacement, new curvature term, GPU result, full-suite result or tamper-check pass is claimed. Historical artifacts and canonical WIP remain protected.
