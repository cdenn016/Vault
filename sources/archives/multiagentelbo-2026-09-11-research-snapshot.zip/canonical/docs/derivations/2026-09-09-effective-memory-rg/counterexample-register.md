<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530", "schema_version": "rigorous-theory-search/v1", "target_digest": "744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530"} -->

# Counterexamples and boundaries

The entropy author gives a reducible stationary constant-output example with zero entropy bracket and permanently distinct hidden point preparations. The independent checker gives a symmetric irreducible four-state example in which every state pair merges in one future step, but an all-zero word preserves hidden posterior TV one. These directly refute converting average entropy convergence or existential mergeability into every-word hidden contraction. The prior actual R5 killed-support witnesses are retained unchanged.

The partition's 1,024 nonmergeable pairs are a certificate that it is not path-mergeable on the full chosen hidden support. Their lack of a common first future symbol also proves immediate incompatibility, so they do not obstruct the weaker flag-block theorem. No next-prediction obstruction is inferred from hidden separation.

Finite brackets do not necessarily decide a tolerance exactly equal to the true rate. Conservative sufficient memory choices are not minimal orders. A zero lower rate endpoint for order three does not establish exact closure. Failure to certify TV 0.1 at the configured durations is not evidence that the true TV exceeds 0.1. No test modifies artifacts or simulates corruption; those checks remain user-excluded and unrun.
