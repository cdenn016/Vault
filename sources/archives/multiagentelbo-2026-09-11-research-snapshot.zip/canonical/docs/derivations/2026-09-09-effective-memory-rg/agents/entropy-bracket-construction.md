<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530","target_digest":"744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530"} -->

# Finite hidden-boundary entropy brackets

Date: 2026-09-09. This author contribution is bound to the frozen effective-memory contract and plan. Theory/SPEC.md was read in full earlier in this thread; its current SHA-256 is `dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1`. The stationary preparation, exact-prefix KL and scope statements in the preceding duration-memory derivation were inspected again. Only the two assigned author artifacts are written. No science, tests, numerical outcomes or ledger closures are supplied by this derivation. The author also wrote the preceding duration theorem and earlier generic projection; author and implementation lanes share model, instructions and filesystem, so this is a derivation for independent reconstruction rather than independent authorship evidence. The new evaluator and bound-interface source was inspected to check notation and timing; its execution belongs to the root lane.

## Fixed model and timing

**DEFINITION.** Let S and A be nonempty finite sets, K a row-stochastic matrix on S, pi a normalized nonnegative row with pi K=pi, and f:S->A a deterministic observation map. Write X_t for the lemma-local hidden random state and Y_t=f(X_t). This X_t is distinct from the fixed structural datum X of the ambient theory. States with pi_i=0 contribute zero to stationary averages and are omitted from conditional sums. The positive stationary support is closed, since stationarity forces K_ij=0 whenever pi_i>0=pi_j. All logarithms are natural, 0 log 0 is zero, and no conditional law is assigned at a null event. No irreducibility, aperiodicity, reversible-kernel, mergeability or forgetting assumption is imposed.

**DEFINITION.** The future starts after the hidden boundary state X_0. For a in A put

\[
 T^a_{ij}=K_{ij}{\bf1}\{f(j)=a\},\qquad
 \alpha_i(\emptyset)=e_i,\qquad
 \alpha_i(wa)=\alpha_i(w)T^a,\qquad
 b_i(w)=\alpha_i(w){\boldsymbol1}.
 \label{eq:hist-ebr-future-recursion}
\]

Thus b_i(w)=P(Y_1:|w|=w|X_0=i), and the first emission is preceded by K. The word of length m contains m future transitions from X_0. In contrast, a stationary block written Y_0,...,Y_{N-1} contains N observations and N-1 internal transitions. Stationarity identifies its observed law with that of Y_1,...,Y_N but does not remove the boundary transition from a calculation conditioned on X_0.

## EBR01. Supported future words define a normalized joint law

**ESTABLISHED.** Define J_m(i,w)=pi_i b_i(w) for |w|=m. Then J_m is a normalized joint law of the boundary hidden state and future word, has X_0 marginal pi, and is prefix-consistent. Since sum_a T^a=K and K 1=1, sum_a b_i(wa)=b_i(w). Starting with b_i(empty)=1 proves that each future-word level sums to one for each retained i. Multiplying by pi_i and summing i proves the joint assertion. Nonnegativity also implies that a zero-mass prefix has only zero-mass extensions, so such a branch is discarded without dividing by its mass. A symbol declared in A but absent from the stationary support simply has zero word mass; a symbol outside the declared alphabet is not an observed event in this model.

## EBR02. Finite formulas for both entropy endpoints

**DEFINITION.** For m>=1 and j>=0 define

\[
 g_m=H(Y_m\mid X_0,Y_1,\ldots,Y_{m-1}),\qquad
 h_j=H(Y_j\mid Y_0,\ldots,Y_{j-1}),
 \label{eq:hist-ebr-endpoints}
\]

where h_0=H(Y_0). The tuple entry numbered m-1 in a hidden-conditioned output array represents g_m; the entry numbered j in an observed-entropy array represents h_j.

**ESTABLISHED.** Every g_m is given by the finite supported sum

\[
 g_m=-\sum_{i:\pi_i>0}\sum_{w\in A^m:b_i(w)>0}
 \pi_i b_i(w)\log\frac{b_i(w)}{b_i(w_{1:m-1})}.
 \label{eq:hist-ebr-hidden-entropy}
\]

Every denominator in this sum is positive by EBR01. The corresponding observed entropy h_{m-1} is obtained by replacing the joint origin-conditioned masses by B(w)=sum_i pi_i b_i(w), using -sum_w B(w) log[B(w)/B(w_{1:m-1})]. This follows from the definition of conditional entropy and stationarity of Y_1:m. For m=1, the first formula reduces to sum_i pi_i H(sum_{j:f(j)=a}K_ij)=H(Y_1|X_0), the previous grouped-row lower bound. It does not equal H(Y_0|X_0), which is zero under deterministic observations. For example, a two-state kernel with both rows (1/2,1/2) and distinct observed labels has g_1=log 2 under its stationary law; masking the initial state before the first transition would incorrectly return zero.

## EBR03. The hidden-conditioned lower endpoints increase

**ESTABLISHED.** For every m>=1, g_{m+1}>=g_m. Adding X_1 to the conditioning can only decrease a finite conditional entropy, so

\[
 g_{m+1}\ge H(Y_{m+1}\mid X_0,X_1,Y_1,\ldots,Y_m)
 =H(Y_{m+1}\mid X_1,Y_2,\ldots,Y_m)=g_m.
 \label{eq:hist-ebr-lower-monotonicity}
\]

The first equality uses two specific facts. Given X_1, the future hidden path and its observations factor independently of X_0; and Y_1=f(X_1) supplies no additional conditioning beyond X_1. The last equality shifts the stationary law by one index. Conditioning reduces entropy because the entropy difference is a conditional mutual information, a weighted finite KL between a joint conditional and the product of its marginals. That KL is nonnegative by -log u>=1-u on positive entries. All uses of conditional factorization are restricted to positive conditioning events. This proof neither reverses the Markov transition nor requires irreducibility.

## EBR04. The paired bracket gap is conditional information about the boundary

**ESTABLISHED.** For every m>=1,

\[
 d_m:=h_{m-1}-g_m
 =I(X_0;Y_m\mid Y_1,\ldots,Y_{m-1})\ge0.
 \label{eq:hist-ebr-gap-information}
\]

Stationarity gives h_{m-1}=H(Y_m|Y_1:m-1); subtract the definition of g_m and expand the finite conditional mutual information. The observed entropies decrease: h_{j+1}<=H(Y_{j+1}|Y_1:j)=h_j, again by conditioning and stationarity. Combined with EBR03 this proves d_{m+1}<=d_m. Thus the two separate monotonicities, rather than a general claim that conditional mutual information decreases under extra conditioning, justify monotonicity of this particular information sequence.

## EBR05. The gaps are summable and have an explicit finite bound

**ESTABLISHED.** For every M>=1,

\[
 \sum_{m=1}^{M}d_m=I(X_0;Y_1,\ldots,Y_M)\le H(X_0)=:C_X,
 \qquad 0\le d_m\le\frac{C_X}{m}.
 \label{eq:hist-ebr-sum-gap}
\]

The equality is the finite mutual-information chain rule: subtract the chain rule for H(Y_1:M|X_0) from that for H(Y_1:M). The upper bound follows by writing the mutual information as H(X_0)-H(X_0|Y_1:M). Since d_j>=d_m for j<=m, m d_m<=sum_{j=1}^m d_j<=C_X. Nonnegative partial sums therefore converge, and d_m tends to zero. In fact m d_m tends to zero: for m>=2, m d_m is at most twice the tail sum starting at floor(m/2), which vanishes. The explicit computable bound C_X/m is the quantitative assertion here; the stronger little-o statement supplies no rate constant.

## EBR06. Both endpoints converge to the stationary entropy rate

**ESTABLISHED.** Let h_inf=lim_j h_j, which exists because the finite h_j are nonnegative and decreasing. Then

\[
 g_m\uparrow h_\infty,\qquad h_{m-1}\downarrow h_\infty,
 \qquad g_m\le h_\infty\le h_{m-1}.
 \label{eq:hist-ebr-entropy-bracket}
\]

Indeed, g_m=h_{m-1}-d_m and d_m tends to zero by EBR05, so both endpoints have the same limit. Their monotonicity bounds each finite endpoint on the appropriate side of that limit. The entropy chain rule also gives H(Y_0:n-1)/n=(1/n)sum_{j=0}^{n-1}h_j->h_inf: after a fixed initial segment every discrepancy is below any prescribed positive tolerance. Only limits of convergent real sequences occur; no infinite-history conditional, limit/sum interchange, ergodic theorem or uniform filter limit is assumed. Reducible stationary models satisfy the same argument.

## EBR07. Exact and certified memory-rate brackets

**ESTABLISHED.** For the stationary k-memory projection with exact initial prefix, put r_k=h_k-h_inf. When h_k and the matched depth-m endpoints are available,

\[
 \max(0,h_k-h_{m-1})\le r_k\le h_k-g_m.
 \label{eq:hist-ebr-exact-rate-bracket}
\]

For 0<=k<=m-1 the bracket width is exactly d_m. For k>m-1 its width is at most d_m. Both statements follow from EBR06 and monotonicity of h. In particular r_{m-1}<=d_m<=C_X/m, so the directly computed endpoint difference is a sufficient stationary memory-rate certificate at order m-1.

**ESTABLISHED.** Suppose H_j^-<=h_j<=H_j^+ and G_m^-<=g_m<=G_m^+ are finite enclosing intervals from one compatible stationary realization. Let J and M denote the numbers of available h and g entries, respectively, with J>=1 and M>=1. Define

\[
 L=\max_{1\le m\le M}G_m^-,\qquad
 U=\min_{0\le j<J}H_j^+,\qquad
 a_k=\max(0,H_k^- -U),\qquad b_k=H_k^+-L.
 \label{eq:hist-ebr-certified-rate-bracket}
\]

Then h_inf lies in [L,U] and, for 0<=k<J, r_k lies in [a_k,b_k]. This remains valid when M and J differ. The rate bracket width is at most (H_k^+-H_k^-)+(U-L). Taking maxima and minima over earlier entries preserves monotone tightening even if individual numerical endpoints are not themselves monotone. For a matched available depth m, the true d_m also lies between max(0,H_{m-1}^- -G_m^+) and min(H_{m-1}^+-G_m^-,C_+/m), where C_+>=C_X. Compatibility guarantees nonnegative ordered true brackets; input validation alone cannot certify that independently supplied numbers arise from one stationary model.

## EBR08. The brackets yield finite-duration guarantees

**DEFINITION.** Let P_N be the stationary observed law on N symbols. Its projection Q_N^k keeps the exact initial joint P_k when N>k, uses stationary positive k-context rows afterward, and equals P_N for N<=k. For k=0 it is the independent product of P_1. A null prefix has only zero extensions; no uniform row is invented. This is the unchanged normalized stationary projection of the preceding finite-memory and duration constructions.

**ESTABLISHED.** Every P-positive word is Q-positive, and its finite forward path KL satisfies

\[
 D_N^k:=D(P_N\Vert Q_N^k)=\sum_{t=k+1}^{N-1}(h_k-h_t).
 \label{eq:hist-ebr-duration-identity}
\]

To check the indexing directly, the Q cross-entropy is H(Y_0:k-1)+(N-k)h_k for N>k. Subtract sum_{t=0}^{N-1}h_t; the t=k term cancels. For N<=k the laws coincide, and N=k+1 also gives zero. Exact initial joint prefixes are required; an independently replaced initial law contributes its own initial-prefix KL and may exclude a positive source word.

**ESTABLISHED.** With certified endpoints from EBR07, let T={t:k+1<=t<min(N,J)} and q=max(0,N-J). Then

\[
 \sum_{t\in T}\max(0,H_k^- -H_t^+)+q a_k
 \le D_N^k\le
 \sum_{t\in T}\min(b_k,H_k^+-H_t^-)+q b_k.
 \label{eq:hist-ebr-certified-duration}
\]

For every known t, the summand lies within the displayed endpoints by entropy monotonicity and the common rate upper bound b_k. Every unknown t>=J has h_t<=h_{J-1}<=U, so its gap is at least a_k; it is at most r_k<=b_k. These observations prove the finite sums without predicting an uncomputed longer word law. In particular D_N^k<=(N-k-1)_+ b_k. The previous elementary finite Pinsker proof then gives TV(P_N,Q_N^k)<=min(1,sqrt(D_N^k/2)). Thus b_k<=2 delta^2/(N-k-1) is a sufficient whole-path TV condition when N>k+1; shorter durations are exact. The bound is sufficient, and a large upper endpoint does not establish failure of a requested tolerance.

## EBR09. Finite stopping for a requested entropy-bracket accuracy

**ESTABLISHED.** For rational model inputs and any rational epsilon>0, there is a finite algorithm returning an enclosing entropy-rate interval of width at most epsilon. Choose a finite certified C_+>=H(X_0) and

\[
 m\ge\max\left(1,\left\lceil\frac{2C_+}{\epsilon}\right\rceil\right).
 \label{eq:hist-ebr-finite-depth}
\]

Such a C_+ is available by enclosing the finite entropy of pi; even C_+=|S_+| is a crude rational upper bound because H(pi)<=log|S_+|<=|S_+|. Compute both matched endpoints at depth m and enclose each with interval width at most epsilon/4. Then

\[
 H_{m-1}^+-G_m^-
 \le d_m+\frac{\epsilon}{2}\le\epsilon.
 \label{eq:hist-ebr-certified-stop}
\]

The first inequality expands the difference into the true gap plus the two endpoint errors; the second uses EBR05 and the chosen depth. If the calculated interval is already narrower at a smaller depth, that earlier certificate is valid. Replacing C_+ by a sharper certified hidden-entropy upper bound affects the sufficient depth, not the proof.

For the finite entropy formulas, it is enough to enclose every positive logarithm with width at most epsilon/4: the nonnegative entropy weights sum to one, so each entropy interval then has that width or less. A direct certified logarithm is obtained by reducing a positive rational z to 2^e u with 1<=u<2, using log u=2 sum_{j>=0}s^{2j+1}/(2j+1), s=(u-1)/(u+1), and bounding its tail after T terms by 2 s^{2T+1}/((2T+1)(1-s^2)). The analogous log 2 interval is combined with sign-aware multiplication by e. The omitted series tail tends to zero, as does outward dyadic-rounding error when its bit count increases. Each finite positive ratio therefore admits the requested width after finitely many refinements. There are only finitely many ratios at the chosen m, so the entire procedure terminates.

**NOT-CLAIMED.** The finite-depth existence and stopping theorem does not authorize a deeper retained calculation in this run. The frozen numerical scope stops at four future transitions. If its intervals do not reach a requested tolerance, the retained answer is that certificate and its limitation; the theorem does not recast the unrun deeper calculation as completed work.

## EBR10. What a tolerance comparison can decide

**ESTABLISHED.** At any fixed k, finite brackets can enclose r_k to arbitrary prescribed accuracy. Choose matched m>k sufficiently large by EBR09 and refine h_k to arbitrary accuracy; EBR07 bounds the resulting rate width by the sum of those two errors. If r_k<tau or r_k>tau for a fixed tolerance tau>0, successively narrower valid brackets eventually certify that strict comparison. If r_k=tau, convergence alone supplies no finite stopping guarantee for deciding r_k<=tau. Thus an exact minimal-order search that waits for equality to be resolved is not justified by this construction. A sufficient rate order is still obtained without that comparison: choose m and endpoint accuracy so that a certified upper bound on d_m is at most tau, and use k=m-1. For a fixed finite N, k>=N-1 gives exact whole-path equality regardless of entropy bracket width. No claim of a smallest true memory order or an efficient representation follows.

## EBR11. Declared finite computational cost

**ESTABLISHED.** Let d=|S_+|, A_+=|f(S_+)| and E be the number of positive directed entries of K on S_+. A direct implementation that handles one initial hidden state at a time and retains nonzero sparse messages has worst-case rational-operation count

\[
 O\left(d E\sum_{t=0}^{m-1}A_+^t\right),
 \qquad\text{peak message storage }O(d A_+^m),
 \label{eq:hist-ebr-arithmetic-cost}
\]

plus logarithm evaluation. There are at most A_+^t distinct words of length t for each initial state. Expanding one prefix visits at most E positive edges; because f is deterministic, its symbol groups partition the destination states, so summing their masses visits at most d entries and d<=E. Completing the d initial-state passes gives the operation bound. One pass holds at most A_+^m messages, each of at most d entries, giving the storage bound. Only rational operations and stored scalar entries are counted; prefix-label handling and integer bit costs are additional. Computing the observed future law from the single initial row pi uses the same recursion with one pass if the needed observed block is not already retained. The number of positive logarithm terms through depth m is at most d sum_{t=1}^m A_+^t, with an additional single-pass contribution for the observed entropies.

If D is a common positive integer denominator of all rational entries of K and pi, then conditional message entries at depth t have denominators dividing D^t, and joint origin-weighted or observed word masses have denominators dividing D^{t+1}. Their reduced numerator and denominator bit lengths are bounded by O((t+1)log D+1), since these probabilities lie in [0,1]. Positive conditional ratios consequently have finite bit lengths of the same order, and a lower bound D^{-(m+1)} suffices at depths at most m when D>1. The rational logarithm enclosure has its separate series-term and dyadic-precision costs. For each fixed term count, the arithmetic remains finite; as accuracy is refined, those costs increase. The word count is exponentially large in m in the worst case when A_+>=2, while the certified sufficient depth can scale as C_+/epsilon. This is a finite effective construction and not an efficiency, useful constant, or small-model claim.

## EBR12. Reducible models and the limit's conditional scope

**ESTABLISHED.** None of EBR01-EBR11 requires an irreducible hidden chain. In particular, a two-state identity kernel with pi=(1/2,1/2) and the same constant observation at both states has h_j=g_m=d_m=0 for every index, while the hidden filters started from the two point masses remain different forever on the common all-constant observation word. Both point preparations assign probability one to that word. This is a normalized stationary counterexample to deriving uniform hidden-filter forgetting from a vanishing entropy bracket. The entropy formula itself is an average of conditional quantities weighted by their stationary event probabilities; it does not bound a single rare conditional contribution without its event weight. The prior restricted-kernel preparation obstructions therefore remain separate from the present stationary averaged convergence.

## EBR13. Relabeling and auxiliary-law scope

**ESTABLISHED.** Coherent bijections of hidden states and observed labels transport K, pi, f, every T^a, every word mass and both entropy sequences by finite reindexing. They preserve h_inf, d_m, C_X, the rate brackets and finite path-KL/TV guarantees. An inherited gauge statement requires the separately admitted normalized hidden-law transport and observation square; this entropy calculation supplies no missing square. The bound concerns the same fixed auxiliary stationary path target as the preceding duration construction. For a subsequently varied recognition law rho supported on P_N, subtraction of the two finite KL sums gives D(rho||Q_N^k)-D(rho||P_N)=E_rho log(P_N/Q_N^k); the entropy bounds concern the rho=P_N average and do not replace the weights by arbitrary recognition weights.

**NOT-CLAIMED.** No original sensor-VFE identity, physical clock, curvature action, efficient arbitrary-memory representation, every-word contraction, synchronized-path mergeability or effective exponential constant is asserted here. The pair-support construction and any checked primary exponential theorem have their own hypotheses and evidence. The present proofs require none of them and do not infer them from scalar bracket convergence.

