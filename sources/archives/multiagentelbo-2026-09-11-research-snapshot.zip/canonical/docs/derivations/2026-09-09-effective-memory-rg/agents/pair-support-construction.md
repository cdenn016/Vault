<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530","schema_version":"rigorous-theory-search/v1","target_digest":"744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530"} -->
# Synchronized pair-support construction

## Mathematical and API preflight

Theory/SPEC.md was previously read in full and its unchanged SHA256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1 was verified for this turn. The frozen contract fixes future-output timing: from hidden i a transition to j emits f(j). For a positive kernel entry, T^a_ij=K_ij 1[f(j)=a]. A zero-length future word starts and ends at the given hidden state and emits nothing. States with different current labels may merge on the same future word.

Proposed module interface: analyze_pair_support(support, labels) returns a frozen PairSupportResult. Input support is a nonempty immutable tuple of immutable destination-index tuples, with distinct valid integer destinations; empty outgoing rows are allowed for the general finite graph. Labels are aligned integers. Exact positivity is extracted by the caller from exact rational K; the graph module performs no floating comparison, probability inference, or stationary-law calculation. The result retains lexicographically ordered unordered pairs, shortest merge distances or None, an oriented next-state pair for each reached non-diagonal pair, and traversal cost counters. A witness(i,j) method returns None for an unmergeable pair, otherwise the common future word and two oriented hidden paths including their requested initial states and common endpoint.

The graph vertices are unordered pairs {i,j}, including diagonals. An edge {i,j}→{u,v} exists if K_iu>0, K_jv>0 and f(u)=f(v), with either orientation admitted. Exactly such an edge encodes two synchronized future-output transitions. A diagonal is a zero-length success. Any common-output hidden path pair ending in a common state induces a path to a diagonal; conversely, choose the edge orientation at each step to lift a pair-graph path into the two original hidden paths. Hence reachability to a diagonal is equivalent to path mergeability.

Initialize reverse BFS with all diagonals. On popping sorted successor (u,v), expand predecessors only if f(u)=f(v). Then enumerate i in incoming(u), j in incoming(v), canonicalize the predecessor as (min(i,j),max(i,j)), and store successor orientation (u,v) when i<=j and (v,u) otherwise. This preserved orientation is necessary: sorting the successor before storing it would lose which original path uses each edge. Diagonals seed distance zero; new predecessors receive successor distance plus one. The first discovery is shortest by BFS layers. A pair with different current labels can be discovered, but has no synchronized predecessor and must not expand backward.

There are n(n+1)/2 vertices. Each is queued at most once, so termination is finite without a word-length search. A shortest nontrivial merging path reaches a diagonal after at most n(n-1)/2 transitions, because any repeated off-diagonal pair could be removed. With m positive hidden edges, incoming lists cost O(n+m) space and work. The reverse Cartesian loops cost at most sum_(u<=v:f(u)=f(v)) indeg(u)indeg(v)<=m^2, and pair storage costs O(n^2). Thus core traversal uses O(n^2+m^2) elementary support operations and O(n^2+m) memory, excluding optional witness expansion. The finite-complement certificate is the complete set U of unreachable pairs: U excludes every diagonal and is closed under every synchronized successor. Otherwise a successor with finite distance would cause its predecessor to be reached. A forward scan of all U successors checks this certificate independently of discovery order.

The bounded retained scan will decode the unchanged L/pi and incidence-to-observation map, check exact stochasticity, positivity of pi, stationarity and irreducible support, then call this graph module once for each of partition and block_ab. It will save the entire BFS distance/orientation forest, every unreachable pair, a forward closure-check count, and one explicit longest witness. Every reached pair's reconstructed paths will be checked directly against positive exact K entries, common emitted labels and a common endpoint; exact path products are positive witness probabilities, not word probabilities unless there is only one such path. No powers or unconstrained longer-word enumeration are planned.

Tiny tests will cover zero-length diagonal timing, different-current-label future merging, an orientation reversal on a multistep witness, a closed nonmergeable synchronized cycle, a pair with no common next output, and an independent forward product-graph oracle on all pairs of tiny examples. Input-validation checks will target invalid indices/labels and duplicate support edges. No full or prior suite will run.

This is an investigation/implementation lane; no ledger state is assigned. The model family and filesystem are shared with the other lanes. The prior killed-kernel hidden nonforgetting examples remain valid because existential merging along one word does not require contraction along every word.


## Final mathematical claims

### SPM01: Future-output path sums determine support

ESTABLISHED. For a finite nonnegative kernel K with stochastic rows and deterministic f, the product T^a1 ... T^at has (i,j) entry equal to the sum of positive hidden path products from i to j whose destination labels are a1,...,at. Expand ordinary matrix multiplication inductively; each summand is a product of transition probabilities and destination-label indicators. Nonnegativity implies that an entry is positive exactly when at least one matching path exists. The empty product is the identity, so distinct states cannot merge on an empty word while a diagonal is already merged. This proof also applies to a bare finite support graph, without a stochastic or stationary premise, by reading each edge as an allowed transition.

Falsifier: negative coefficients permitting cancellation, a mismatch between edge/destination labels, or counting the starting-state label as a future output.

### SPM02: The unordered pair graph preserves oriented paths

ESTABLISHED. Form one vertex (i,j), i<=j, for every unordered pair. A synchronized pair edge represents oriented transitions i→u,j→v with f(u)=f(v), modulo simultaneous exchange of both coordinates. The quotient is sound because swapping both paths preserves existence, the emitted word, and a common endpoint. It is complete because every ordered pair path projects to the quotient. Conversely, lift a quotient path recursively: if the current ordered pair is the reverse of its canonical order, swap the stored successor orientation. This uses the edge leaving the actual left state for the left path, and likewise on the right. An arbitrary sorted successor without this orientation would not suffice.

The source stores (u,v) relative to sorted predecessor (i,j) when i<=j, otherwise stores (v,u); witness(i,j) reverses that stored pair if its requested current ordering is reversed. The test with paths 0→4→3 and 1→2→3 forces this seam, because the first successor has reversed numeric order. The two words are (7,8). A tiny independent ordered forward BFS checks all pair distances and the reconstructed paths.

Falsifier: a reconstructed edge not in the left or right support, unequal emitted labels, or a noncommon endpoint.

### SPM03: Reverse BFS returns exactly the shortest merging lengths

ESTABLISHED. Initially every diagonal has distance zero. Suppose all discovered vertices through distance d encode a path of the claimed length to a diagonal. Discovering a predecessor of a popped distance-d vertex appends one valid synchronized edge, giving a length-(d+1) path. Conversely, if a vertex has a shortest length-(d+1) path, its first successor has a path of length d and will be popped; the corresponding incoming Cartesian pair is enumerated, so the predecessor is discovered no later than that layer. BFS order prevents a longer first discovery. Induction proves exact minimal distances, with None exactly for nonmergeable pairs.

A popped successor (u,v) with unequal labels has no synchronized incoming edge and must not expand. Its own future merging distance may nevertheless be finite. In particular, no condition on f(i)=f(j) is imposed on an initial pair.

Falsifier: a missing legal incoming pair, expansion through unequal successor labels, or a shorter valid witness than a returned distance.

### SPM04: The complete unvisited set is a negative certificate

ESTABLISHED. Let U contain precisely the pairs not reached by reverse BFS. It contains no diagonal. If a synchronized successor of a pair in U were outside U, that successor's reverse expansion would discover the pair, a contradiction. Thus U is closed under every synchronized successor. Conversely, any diagonal-free synchronized-successor-closed set cannot reach a diagonal, by induction on path length. These two facts prove both directions of the certificate, including pairs with no synchronized successors at all. The scan independently enumerates all forward Cartesian successors of every U pair and checks this closure.

Falsifier: a diagonal in U or one synchronized edge from U to its complement.

### SPM05: Termination and cost are finite, without a word search

ESTABLISHED. The n(n+1)/2 pair vertices are each enqueued once. A shortest path to a diagonal has no repeated off-diagonal vertex, since deleting the intervening cycle would shorten it, so its length is at most n(n-1)/2. If m is the number of positive hidden support edges, incoming adjacency construction uses O(n+m) work and space. Reverse expansion performs at most sum_(u<=v:f(u)=f(v)) indeg(u)indeg(v)<=m² Cartesian iterations. Pair indexing, distance and orientation storage use O(n²) space. The core therefore takes O(n²+m²) support operations and O(n²+m) memory. The exact forward complement check takes at most m² additional Cartesian iterations. Reconstructing every witness has additional cost proportional to the sum of its path lengths; that output/checking cost is separately counted and is not hidden in the core bound.

The API accepts finite immutable adjacency tuples with distinct integer destinations and aligned integer labels, including sinks. Caller-side extraction from the exact rational kernel establishes positivity. Duplicate entries, out-of-range indices and Boolean pseudo-indices are rejected. No bit precision, probability tolerance, strict positivity, irreducibility or stationary assumption is built into the support algorithm.

Falsifier: an input-dependent unbounded loop, repeated enqueue, an unrecorded word enumeration, or omission of witness-expansion cost from a reported total.

### SPM06: Relabeling and existential scope

ESTABLISHED. A hidden-state bijection maps every positive edge and diagonal to its corresponding edge and diagonal; an observed-label bijection preserves equality of emitted symbols. Together these induce an isomorphism of the pair graphs, preserving reachability and shortest distance. Pushing the two oriented hidden paths and their output word therefore gives a valid witness. The specific lexicographically selected shortest witness may change because tie breaking is not invariant; existence and distance are invariant.

Mergeability is existential in the output word and endpoint. It supplies no every-word filter contraction. The frozen actual queries illustrate this separation: parents 252 and 400 merge on partition future word (0) via parent 250 with path probabilities 1/14 each, while the earlier repeated-partition-1 hidden separation remains valid. Parents 256 and 340 merge on block future word (0) via parent 250 with path probabilities 1/22 and 1/14, while repeated block 1 retains the earlier hidden-support distinction. These finite identifications are separately recorded as SPN02; the compatibility of the quantifiers follows directly from the two different words.

Falsifier: a claimed invariant tie-selected witness rather than invariant existence/distance, or an inference from one merging word to every-word contraction.

### SPM07: Mergeable-or-incompatible pairs construct a flag word

ESTABLISHED. Assume a finite stochastic labeled support graph. A pair is incompatible if there is a finite length m such that no output word of length m is possible from both states; longer common words are then impossible because their m-prefix would be common. Suppose every pair is mergeable or incompatible. A word w flags endpoint r when, from every initial state that can generate w, at least one w-path ends at r. The following terminating construction proves existence; it does not rely on the paper's remark without an argument.

Begin with w empty, r any state, and that starting state covered. A covered initial state is one known to admit a w-path ending at r; an eliminated state cannot generate w. Select an unprocessed start k. If it cannot generate w, eliminate it. Otherwise let A=delta_k(w), a nonempty finite endpoint set. If some j∈A is mergeable with r, append their common merging word u and replace r by its common endpoint. The chosen k is now covered by concatenating its w-path to j with the j-side u-path. Every previously covered start remains covered by following its w-path to the old r and the r-side u-path.

If no j∈A is mergeable with r, every j∈A is incompatible with r. Let m be the maximum of their finite incompatibility lengths and choose any length-m supported future path from r; such a path exists because each stochastic row has an outgoing edge. Let u be its word and r' its endpoint. No j∈A can generate u, so k cannot generate wu and is eliminated in its entirety. Every covered start can generate wu and end at r'. This step removes a whole starting-state obligation; it does not merely remove one endpoint while ignoring other branching endpoints. Previously eliminated states remain unable to generate any extension.

At least one previously unprocessed starting state is covered or eliminated each iteration, so after at most n-1 iterations every possible starting state for the final w reaches its distinguished endpoint. That is the flag property. If all merging witnesses have length at most D and all incompatibility lengths are at most M, the construction has |w|≤(n-1)max(D,M). Empty merging words simply cover a start without increasing length.

Falsifier: a selected start survives an elimination extension through another endpoint, an old covered start loses its distinguished path, or the construction fails to remove one whole starting-state obligation per iteration.

### SPM08: Irreducibility and holding produce one finite flag block

ESTABLISHED. Add irreducibility and a positive self-loop at every hidden state. From the distinguished endpoint r of SPM07, a simple directed path reaches every target j in at most n-1 transitions. Append its emitted word to w. Any start that can generate this concatenated word could generate w and therefore has a w-path ending at r; following the selected appended path reaches j. Thus each target has a flag word of length at most (n-1)max(D,M)+(n-1).

Choose a common positive integer b at least the maximum of these lengths, and append the target's self-loop output enough times to each flag word to reach b. Every start that generates the padded word can generate the original flag word, reach its target, and execute the positive self-loops. Hence every target has a length-b flag word. The b-step labeled block model is flag-state. Positive holding also makes the hidden period one, so b is coprime to that period. Irreducibility of K^b follows directly by padding any simple connecting path to a multiple of b with holding edges and observing the resulting sequence at b-step intervals. Its stationary law is pi because pi K=pi implies pi K^b=pi.

For the retained pair certificate, every unmergeable partition pair has no synchronized successor, so M=1; all other pairs merge in at most D=4. For block_ab every pair merges in at most four steps, so M=1 is a harmless unused bound. With n=250, the construction gives a positive common block length no larger than 249(4+1)=1245 for either map. This is a constructive upper bound proved from the finite support premises. The flag words or that large block alphabet were not enumerated. Partition is still not path-mergeable: the weaker criterion is what allows this construction.

Falsifier: failure of irreducibility or target holding, an unmergeable pair with a positive common word under the asserted M=1, or a padding argument that changes the final target.

### SPM09: Exponential existence remains separate from usable coefficients

ESTABLISHED as a conditional application of the primary result recorded in primary-travers-note.md, with its full assumptions supplied by SPM08 and the bound finite stationary input facts. Both retained maps therefore admit some rho<1 satisfying limsup_t e_t^(1/t)≤rho, where e_t is the stationary conditional entropy excess over the entropy rate at context length t. Shifting an index by one does not change this limsup. Changing the paper's logarithm base to natural logarithms multiplies all entropy errors by ln(2) and likewise does not change the root limit.

For any q with rho<q<1, the definition of limsup yields a finite t0 with e_t≤q^t for every t≥t0. The finite constant A=max(1,max_(0<=t<t0)e_t/q^t) then gives e_t≤A q^t at all nonnegative t. This deduction is a direct real-sequence argument. It establishes existence of finite A and q, not evaluated useful values. A computable finite graph bound for b is not the same object as an evaluated entropy prefactor. The primary theorem's flag probabilities, stationary ratios, block alphabet, rate and finite-prefix handling must be constructed or bounded before advertising a numerical exponential guarantee. This packet performs no such block-alphabet or coefficient calculation.

The theorem concerns the fixed stationary observed process. Arbitrary-preparation every-word filtering, finite true Markov order, a measured small error tolerance, physical time, or equality with the original generative sensor VFE is not implied. The prior repeated-symbol hidden-posterior obstructions are compatible with this stationary entropy statement.

Falsifier: a missing stationary/irreducible/flag-block premise, treating partition as fully path-mergeable, promoting limsup to a computed prefactor, or applying the stationary entropy conclusion to every conditional word.

## Numerical observations and frozen execution

### SPN01: Focused source tests

NUMERICAL_OBSERVATION. One run of tests/rg_v2/test_synchronized_pair_support.py used C:/anaconda/python.exe -B with an explicit driver injecting src and src/multiagent_elbo and calling pytest with --noconftest -q and the named JUnit path. The file contains only tiny finite graphs. JUnit pair-test-20260909T0952575584326Z.xml records 21 tests, zero failures, zero errors, zero skips, and suite time 0.033 seconds. The tests' oracle searches the tiny ordered product graph forward, separately from the module's unordered reverse traversal. The same file tests the orientation seam, future-output phase, incompatible/dead pairs, relabeling, and invalid graph/query types. No prior tests or full suite ran.

Module SHA256: a8f13e4a5290018ca4402881efdd5fb612cba014ff871ab41c7dc0e000c20ce6. Test source SHA256: d8a46f76b9e5e2b89fd05ba636f233617914fb28ec822c80b01b69e9577f763f. JUnit SHA256: e3f0d8da2e15eeee1ac4d226e0c0aee2ce95742014e54c51f58902bdc3414a93. The module and test source did not change after this pass. No randomness was used, so no seed applies.

### SPN02: One complete bounded retained pair scan

NUMERICAL_OBSERVATION. The single command was C:/anaconda/python.exe -B C:/tmp/elbo-cover-20260908/docs/verification/2026-09-09-effective-memory/inspect_pair_support.py. Its script SHA256 is 8648528899a801a8c23dcae60c1ac3358e107f2aadab88c15d6735d28723f647, frozen configuration SHA256 is 688eb876a2746dc69c1bb06c890c7791045bd6034bb30258d00f53fb5032e205, and result pair-support.json SHA256 is fed3127e2df48eea692fae46f4e5a9387aacff5908e6a6999c120f0d1abb7878. The retained pair-scan.log SHA256 is 432dee0598c3e9c7a959730e602eab64fce520b39f93475998269dbbf0f92c62. Runtime, exact command, source identity, pi, original parent labels and both observation maps are embedded in the result. The source guard confirms the intended module was imported, and an existing-output guard prevents an implicit repeat.

The unchanged component input SHA256 is 126b1a90cfedb69096f034bd72c30b4e0876df53669ae163780c5b68f1bd3f50 and kernel input SHA256 is 838cc121a54381700b9b2d33558f33b1c72e28b03894417636f89f0fb42f3c65. The scan independently decodes exact Fraction coefficients, aggregates pi from 432 incidences onto 250 original parent labels, checks the observations descend on every incidence, and checks 2300 positive kernel entries, stochastic rows, positive pi, stationarity, detailed balance, all-state directed reachability and positive holding.

For partition, 30,351 of 31,375 unordered pairs including diagonals merge; 1,024 do not. All 1,024 have zero synchronized successors and hence no common future word of length one. The saved table also has no unmergeable pair whose current partition labels agree. Counts at merging distances 0,1,2,3,4 are 250,4685,15368,9536,512. For block_ab, all 31,375 pairs merge, with distance counts 250,4685,16392,9536,512. Every reachable pair's reconstructed witness is checked directly against positive exact transition entries, matching output labels and a shared terminal state. The complete distance/orientation forest and complete unmergeable complement are saved. An individual path product is reported as a positive witness probability, not as the whole word likelihood or a conditional merging probability.

One longest partition witness is the word (3,1,0,0), with original-parent paths 288→260→252→250→250 and 492→464→402→251→250 and respective positive path probabilities 144685775/1504174484736 and 653883/234860057600. One longest block witness is (0,0,0,0), with paths 288→260→252→250→250 and 492→440→306→251→250 and probabilities 144685775/1504174484736 and 22041/9394402304. These examples illustrate the complete forest; no selected long trajectory supplied the all-pairs conclusion.

### SPN03: Measured finite cost and controls

NUMERICAL_OBSERVATION. The scan completed once with exit zero in 1.2307262000395 seconds. Partition expanded 30,351 pair vertices, performed 702,924 reverse predecessor products and 120,832 forward complement products; the latter found zero synchronized successor products. Block expanded all 31,375 vertices and performed 1,872,076 reverse predecessor products, with an empty complement. The script separately counts all witness-path edges checked. Exact conditional entropy, stationary rates, GPU work, producer work and old suites are outside this scan. The control is the same retained support under the two declared maps, plus the tiny independent forward oracle; no stochastic surrogate or new physical control was run. No seed applies.

## Attacks and semantic erasure

The empty-word/current-state attack fails for the stated future-output contract because diagonal paths have length zero and emit nothing, while even different-current-label pairs may merge after one transition. The dedicated test and SPM01 expose this boundary rather than relying on comments.

The orientation attack is addressed by SPM02 and by directly checking every retained reconstructed path. A quotient certificate alone without an oriented lift would be insufficient. The negative-certificate attack is addressed by the complete complement and its independent forward closure check; a cutoff on explored words is never interpreted as nonmergeability.

The stationary-versus-uniform attack succeeds against any proposed every-word conclusion. The two exact previous-sector queries merge on future output 0, whereas their repeated-output-1 killed supports stay disconnected. SPM09 is an entropy-average conclusion under stationary preparation; no conditional discrepancy is silently averaged away in a stronger claim.

The primary-source applicability attack requires the distinction between block_ab path mergeability and partition's 1,024 immediate incompatibilities. SPM07 handles the latter by eliminating an entire starting-state endpoint set only after testing every endpoint against the distinguished endpoint. Removing one incompatible endpoint while ignoring surviving alternatives would not be a proof. The positive holding and irreducibility hypotheses in SPM08 are explicit, and the absence of evaluated exponential coefficients remains explicit.

Erase the favorable search direction, the R5 terminology, and the physical interpretation: SPM01–SPM08 are finite support constructions and implications; SPM09 has exactly the named stationary primary-theorem hypotheses. The normalized auxiliary path law is fixed before any later recognition comparison. Transition count is not physical time, a principal-bundle structure, or a generative VFE term.

No formal ledger state is assigned. This lane's scientific independence is limited by its shared model family and filesystem; the forward oracle, exact decoding and checked proofs are the evidence, not agreement among agents. The support module, its tiny test file, this construction, pair-claims.json, the named scan/result/JUnit/log and primary-source note are the entire assigned edit scope. No previous artifacts or source modules were modified.
