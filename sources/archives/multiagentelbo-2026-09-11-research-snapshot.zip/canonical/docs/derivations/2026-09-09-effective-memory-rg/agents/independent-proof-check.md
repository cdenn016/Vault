<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530","schema_version":"rigorous-theory-search/v1","target_digest":"744d1b322442a4985b7be192069ba3c949033c6e2219bdf996734acaba0f4530"} -->
# Independent reconstruction of effective memory control

Revision 1, September 9, 2026. This derivation starts from the frozen contract and implementation plan, before reading either current author construction or either new implementation. The current Theory/SPEC.md has SHA-256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. It was read fully in the immediately preceding duration task; the current normalized-law, clock, auxiliary-target, observation-square and obstruction premises were rechecked. The completed duration construction is used only for the stated exact stationary memory-law identity. This lane assigns no ledger state and runs no test or scientific calculation.

## IP-E1. Timing, finite laws, and supported conditioning

Let S be a nonempty finite hidden set, K a row-stochastic matrix, pi a stationary probability row, and f:S->A a deterministic observation map with finite alphabet. Restrict entropy conditioning on X_0 to pi-positive states; zero-weight initial states contribute zero and receive no invented conditional law. The future emission matrices are

\[
T^a_{ij}=K_{ij}1\{f(j)=a\},\qquad
P(X_0=x,Y_{1:m}=w)=\pi_x(e_xT^{w_1}\cdots T^{w_m}\boldsymbol1).
\]

There is no observation of f(x) counted in the future word. Summing over the next symbol gives K, and summing over all words gives pi_x. Thus these are normalized consistent finite laws. Every conditional ratio below is used only when its conditioning mass is positive.

Write

\[
u_m=H(Y_m\mid Y_1,\ldots,Y_{m-1}),\qquad
g_m=H(Y_m\mid X_0,Y_1,\ldots,Y_{m-1}),\quad m\geq1.
\]

Stationarity identifies u_m with h_{m-1} in the completed duration construction. A depth-four future calculation therefore brackets h_infinity between g_4 and h_3; the previous stationary four-observation law supplies the needed h_3 despite having a different absolute starting index. Including an initial emission in the new depth count would make this interface off by one.

The pi-positive hidden support is closed: if pi_j=0 then stationarity implies sum_i pi_i K_ij=0, hence every positive-pi i has K_ij=0. The induced supported kernel is normalized. No irreducibility, reversibility or positive one-step matrix entries are required here.

Falsifier: a claimed evaluator counts Y_0 among m future transitions, normalizes at a zero conditioning mass, or uses a nonstationary preparation when substituting u_m=h_{m-1}.

## IP-E2. Monotone lower brackets and entropy-rate convergence

The conditional-entropy inequality immediately gives g_m<=u_m. For m>=2, conditioning additionally on X_1 gives

\[
g_m\geq H(Y_m\mid X_0,X_1,Y_1,\ldots,Y_{m-1})
=H(Y_m\mid X_1,Y_2,\ldots,Y_{m-1})=g_{m-1}.
\]

The middle equality uses the Markov conditional independence of the future from X_0 given X_1, and Y_1=f(X_1). The final equality is stationarity. Also u_m is nonincreasing by the same stationary conditioning argument used for h_j. Thus g_m increases to some g_star, while u_m decreases to h_infinity.

The chain rule supplies

\[
\sum_{j=1}^m(u_j-g_j)
=H(Y_{1:m})-H(Y_{1:m}\mid X_0)
=I(X_0;Y_{1:m})\leq H(\pi).
\]

Dividing by m, both sums have Cesaro limits, so h_infinity-g_star=0. Consequently

\[
g_m\uparrow h_\infty,\qquad
u_m=h_{m-1}\downarrow h_\infty.
\]

This proof uses finite conditional entropies and a bounded boundary information term; it requires no infinite conditional distribution, ergodic theorem or filter-forgetting theorem. Conditioning on a boundary state can remain sensitive along rare words while these stationary averages converge.

Falsifier: removal of stationarity. For example, from a fixed initial hidden state, make the first transition choose two equiprobable differently observed states, then send both to one absorbing state with a common observation. The nonstationary lower entropies are g_1=log 2 and g_2=0.

## IP-E3. Quantitative gap, certified stopping, and threshold boundary

Set Delta_m=u_m-g_m. Both bracket monotonicities make Delta_m nonnegative and nonincreasing. The chain-rule identity above gives

\[
\Delta_m=I(X_0;Y_m\mid Y_1,\ldots,Y_{m-1}),\qquad
\sum_{j=1}^m\Delta_j\leq H(\pi),\qquad
0\leq\Delta_m\leq H(\pi)/m.
\]

Thus every strictly positive requested entropy-bracket width has a finite sufficient depth, even without mergeability. A certified upper bound C>=H(pi) can replace H(pi).

For exact arithmetic with outward logarithm intervals, suppose the upper endpoint for u_m overshoots by at most eta and the lower endpoint for g_m undershoots by at most eta. The certified width is then at most C/m+2 eta. Choosing m>=max(1,ceil(2C/delta)) and eta<=delta/4 guarantees certified width at most delta. These conditions are sufficient, not necessarily minimal. Each entropy is a finite sum with nonnegative probability weights summing to one, so enclosing every logarithm to absolute error eta encloses the weighted sum to that error. A convergent rational logarithm construction therefore gives finite precision stopping for each fixed positive-mass finite law. No claim of low bit complexity follows.

For any fixed k, the bracket implies

\[
\max(0,h_k-u_m)\leq r_k\leq h_k-g_m,
\]

with the directions preserved by outward endpoints. These rate brackets converge to r_k. If a decision threshold epsilon differs from r_k, sufficiently tight finite brackets eventually decide on the appropriate strict side. If epsilon=r_k, convergence alone need not decide the non-strict acceptance condition at any finite depth. At the special order k=m-1,

\[
0\leq r_{m-1}\leq\Delta_m\leq C/m.
\]

Under the contract's execution cap m<=4, failure to reach a requested width or memory threshold must be reported as not established by the retained calculation. The unrestricted existence theorem is not authorization to continue enumerating deeper blocks.

Falsifiers: treating the asymptotic convergence alone as finite stopping at an equality threshold; ignoring logarithm enclosure width; or promoting the four-depth cap to a universal accuracy guarantee.

## IP-E4. Duration interface and declaration of computational cost

For the exact stationary k-memory approximation Q_N^k with N observations, the completed duration theorem gives

\[
D(P_N\Vert Q_N^k)
=\sum_{t=k+1}^{N-1}(h_k-h_t)
\leq (N-k-1)_+r_k.
\]

Accordingly a certified upper rate b_k yields

\[
D(P_N\Vert Q_N^k)\leq(N-k-1)_+b_k,\qquad
\operatorname{TV}(P_N,Q_N^k)
\leq\min(1,\sqrt{(N-k-1)_+b_k/2}).
\]

One can retain the exact known-time terms and apply b_k only to later terms, as the preceding implementation does. The finite lower-gap terms remain separate from a generic limiting-rate lower bound. A sharper g_m may improve this upper rate without changing the target or the memory-law definition.

The evaluation is finite but potentially exponential in m. For each positive-pi boundary state x, propagate an unnormalized hidden row e_x T^w for every supported future prefix w. If s=|S|, a=|A|, and e is the number of nonzero hidden edges, a straightforward sparse matrix-vector frontier requires at most s e sum_{r=0}^{m-1}a^r rational multiply-add contributions, plus vector/mask and entropy bookkeeping. Dense storage of all boundary-conditioned frontier vectors is at most s^2 a^m rational entries. A fully dense kernel gives s^3 sum a^r as a simple arithmetic-operation bound before bookkeeping. Streaming one boundary state at a time lowers retained frontier memory to at most s a^m entries while preserving the same arithmetic count. Unsupported words can be discarded exactly, but no polynomial-in-depth claim is justified in general.

Those are arithmetic-operation and scalar-storage bounds, not bit-complexity bounds. Numerators and denominators can grow with depth, and the cost of rigorous logarithm intervals depends on their arguments and requested precision. Producing a k-context model can itself require up to a^k rows; evaluating a sufficient k does not construct that model.

Falsifier: a cost claim hides the s boundary conditions, the a^m word frontier, rational operand size, or the separate size of the eventual memory model.

## IP-P1. Synchronized-pair graph and exact positive witnesses

For an arbitrary finite labeled support graph, use ordered pair vertices S times S. Draw an edge

\[
(i,j)\longrightarrow(u,v)
\quad\hbox{iff}\quad K_{iu}>0,\ K_{jv}>0,\ f(u)=f(v).
\]

The accepting set is the diagonal {(z,z)}. Initial labels f(i),f(j) need not agree because the task starts before the first future output. A synchronized path of length ell from (i,j) to (z,z) is exactly two positive hidden paths starting at i,j, emitting the same future word of length ell, and ending in the same hidden state. Each direction follows by reading the edges; for rational positive kernels the products of the displayed edge probabilities give exact positive probabilities for the particular two paths. The total common-word probabilities are at least those path probabilities.

Every diagonal pair accepts the empty word. A distinct pair accepts only by a nonempty path. A shortest accepting ordered-pair path has no repeated non-diagonal vertex, so its length is at most s^2-s. One may quotient by coordinate interchange and obtain at most s(s-1)/2 non-diagonal vertices. That optimization is valid because interchange is a labeled graph automorphism; reconstructing two individual hidden paths still requires retaining or recovering edge orientation when a successor pair is sorted.

Reverse graph traversal from the diagonal computes exactly the mergeable set R. Store for every newly reached non-diagonal pair a successor already reached and the two positive support edges. Following successors terminates because the stored distance strictly decreases, yielding a finite word and two aligned hidden paths. Existential reachability does not assign a positive lower bound to every observation word.

Falsifier: matching source emissions instead of destination emissions, requiring equal initial labels, accepting two different terminal states, using a zero edge, or losing coordinate orientation while reconstructing an unordered-pair witness.

## IP-P2. Closed obstructions, termination, and cost

The complement B=(S times S) minus R is disjoint from the diagonal and forward closed under synchronized edges. Otherwise an edge from B to R followed by an accepting path would put its source in R. Therefore an unmergeable pair is certified by its membership in a supplied B together with two finite checks: no diagonal lies in B, and every synchronized successor of every vertex of B is still in B.

Conversely, any set with those two properties contains only unmergeable pairs, because every path starting within it remains off the diagonal. The full reverse-reachability complement gives a complete obstruction, including pairs with no common future output at all. No separate long-word search is needed.

With e_a the number of support edges whose destination has label a, the ordered pair graph has at most s^2 vertices and sum_a e_a^2 synchronized edges. Building reverse adjacency and traversing it takes O(s^2+sum_a e_a^2) elementary graph operations and corresponding storage. This is at most O(s^2+e^2), with the dense worst case O(s^4). Implicit successor generation can trade storage for repeated work, but any different complexity statement must match the actual source. All-state mergeability is a statement about the chosen graph state set; applying a stationary theorem additionally requires declaring whether zero-pi states are removed. The actual retained pi is positive, so that distinction does not shrink its state set.

Falsifier: a negative certificate omits a synchronized successor, includes a diagonal, or claims exhaustive classification after traversing only a selected collection of word lengths.

## IP-P3. Mergeability does not imply every-word contraction

Consider four hidden states (s,y), with s,y in {0,1}, observed by f(s,y)=y. From (s,y), remain at that same state with probability 1/2, and move to each of (0,1-y),(1,1-y) with probability 1/4. The kernel is symmetric, irreducible, has positive diagonals, and has uniform stationary law.

Every distinct pair is mergeable in one future transition. For states with the same y, choose either state with opposite observation as the shared destination. For states with different y, choose the first state's own hidden state as the shared destination: the first has its holding edge and the second has an opposite-observation edge to it. Every path has positive probability and a matching destination emission.

Nevertheless, starting at (0,0) versus (1,0), conditioning on any all-zero future word forces both chains to use only their holding edges. Their terminal hidden laws remain the two distinct point masses, with TV exactly one at every depth. Thus even universal one-step existential pair mergeability does not imply uniform hidden-filter contraction along every word. Their next-observation predictions both remain fair Bernoulli, so hidden separation cannot be promoted to a prediction obstruction.

The primitive nonreversible example IP6 from the preceding duration check supplies a complementary boundary. Its two a-states have only the a-symbol as a common next output, and that output retains the same pair; hence their off-diagonal pair is closed and unmergeable, although its stationary observed process is iid. Failure of pair mergeability therefore does not refute entropy-rate bracket convergence or even immediate exact stationary observation-memory closure.

Falsifier: inferring a failed entropy theorem from a nonmergeable pair, or inferring every-word contraction from successful existential common-word paths.

## Independent return and later comparison boundary

The finite entropy proof needs stationarity and a finite hidden boundary entropy, but no mergeability. The pair graph needs finite support and a correctly timed label convention, but no stationarity for its reachability equivalence. Any Travers theorem is a separate imported conditional result whose exact irreducibility, presentation and emission assumptions must be mapped by the literature lane. No exponential constant, effective asymptotic rate, novelty claim or R5 mergeability outcome is inferred here before that mapping and the retained finite artifacts exist.

The fixed positive R5 law, observation maps and auxiliary memory construction remain unchanged. Relabeling hidden and observed states coherently reindexes all finite sums and graph paths. Gauge use retains the already admitted observation square. None of these statements identifies an inference transition with physical time or alters the original sensor/generative joint.

First-stage obligations for the later source check are the future-emission index, every conditional denominator, exact-rational mass propagation, interval directions and error budget, finite stopping versus a depth cap, complete reverse pair reachability, orientation of reconstructed witnesses, closed-complement completeness, and the scope of any imported exponential theorem. All author/source checks remain pending at this independent first revision.


## Revision 2: Source preflight before the retained calculations

The entropy evaluator was read in full at SHA-256 869cfe8232bfb85bae464df032a595091dbcb8a47fb17feb38cf86af09e68b68. Its initial message is e_i conditional on X_0=i, not pi and not a message conditioned on an initial observed symbol. Each recursion first applies K, groups by the destination label, and calculates word mass divided by the preceding prefix mass. Every stored mass is positive because the sparse rows contain only positive exact entries; pi-zero boundary states are skipped. Multiplying the conditional word contribution by pi_i yields exactly the finite-sum formula for g_m. Exact stationarity is validated before the recursion. The log interval signs and nonnegative entropy lower-endpoint clipping are valid.

The entropy-memory helper checks rational nonnegative intervals and compatibility with the required monotonicities, while explicitly leaving the existence of one compatible stationary realization to the caller. It sets the entropy-rate lower endpoint to max g_lower and the upper endpoint to min h_upper. Its rate and known-prefix KL endpoint directions match IP-E3 and the previous source check. The lower tail remains a bound on every unseen finite difference because it is formed from the available finite h upper endpoints. The tail count is max(0,N-len(h)), with N observations. No formula defect was found under the stated input premise.

The source's O(n A^depth) peak message count concerns rational probability entries. Because prefix keys are materialized tuples of length at most depth, a total-storage bound must additionally include O(depth A^depth) symbol references for the frontier, as well as dictionary overhead and rational operand storage. Root was notified of this bookkeeping distinction. It does not change the correctness of the finite evaluator or its stated rational arithmetic count.

The pair-support implementation and tiny tests were read without execution at source SHA-256 a8f13e4a5290018ca4402881efdd5fb612cba014ff871ab41c7dc0e000c20ce6. Its upper-triangle pair index matches lexicographic pair enumeration. Reverse BFS begins at every diagonal and expands a sorted successor only when its two destination labels agree. For a predecessor discovered as (i,j), storing (u,v) when i<=j and (v,u) otherwise preserves the correspondence of support edges relative to the sorted predecessor. During reconstruction, reversing this successor again when the current requested order is reversed restores the two original path orientations.

Although reverse expansion enumerates only incoming(u) times incoming(v) for sorted u<=v, this loses no unordered predecessor: the other orientation has the same unordered source and appears by interchanging the two incoming indices. The first BFS discovery is shortest and stores an edge to a strictly smaller distance, so witness reconstruction terminates at a diagonal. The complete unreachable set is the graph complement required by IP-P2. The implementation does not infer probabilities from support; the exact caller must provide positive edges and check path products. No preflight defect was found in this graph or witness interface.

The test source includes an independent ordered forward BFS oracle, including reversed requested pairs, timing, closed cycles and dead pairs. Reading those tests establishes their intended obligations, not that they passed. This lane ran none of them. Retained execution artifacts and the final author/primary-theorem mapping remain pending.


## Revision 3: Entropy-author and retained-study readback

The frozen entropy author Markdown and claim JSON were read in full. Their hashes are respectively 10c111aa83b18b6034a9766f6b72953a9f611e6dc912a134ae6d3c17800a116d and de85602cfad63ae29f52629107d20d8cf90c9cf2ba5d55cdce5683a537cb60f9. EBR01-EBR06 reproduce the IP-E1/IP-E2 construction by finite conditional sums and the vanishing gap, with the same future-output timing and null-state convention. EBR04 correctly derives gap monotonicity from the two endpoint monotonicities; generic conditional mutual information is not assumed monotone under further conditioning.

For EBR07, when k<=m-1, monotonicity gives h_k>=h_{m-1}, so the exact lower rate bound is h_k-h_{m-1}; subtracting it from h_k-g_m gives precisely Delta_m. When k>m-1, the lower bound is zero and the upper h_k-g_m is at most Delta_m. Its certified endpoint operations agree with the source. EBR08's known-prefix and tail formulas agree with the exact KL identity and the per-term lower-bound property checked above.

EBR09 supplies explicit margins, not merely convergence: the chosen depth makes the true gap at most half the requested width, and each of the two entropy enclosures consumes at most a quarter. The supported positive log ratios form a finite collection. Range reduction and the displayed convergent atanh-series remainder yield finite enclosures for an ideal algorithm whose precision may increase without a fixed resource ceiling. EBR10 correctly excludes finite stopping at equality of a threshold with r_k.

This ideal mathematical algorithm is distinct from the implemented evaluator, which accepts a declared finite depth and precision. Its reused logarithm implementation has a finite precision admission guard; this batch does not implement an arbitrary-accuracy adaptive driver. Failure of an explicit resource admission does not contradict EBR09, and EBR09 does not prove that this bounded executable completes for every epsilon.

EBR11 states its cost in rational operations and message entries. Its common-denominator claim follows by induction: conditional entries at depth t are sums of products of t transition fractions, hence have denominators dividing D^t. Multiplication by pi gives denominators dividing D^(t+1). Since each probability lies in [0,1], the reduced numerator is no larger than that denominator. Taking a ratio of two such masses preserves an O((t+1)log D+1) bit-length bound, and positive joint masses at depth at most m are bounded below by D^(-(m+1)). The entry-count bound excludes prefix-key bookkeeping, as the author states. EBR12's identity-kernel counterexample and EBR13's finite reindexing and auxiliary-law boundaries are correct; neither implies a predictive discrepancy or a new gauge square. No new mathematical defect was found in EBR01-EBR13.

The retained entropy study and its runner were read in full without execution. They reuse the prior h0..h3, compute exactly g1..g4 with the first transition included, and compare g1 against the preceding grouped-row result. Every requested order is among k=0,1,2,3; durations count observations. The decision routine returns the first configured available order whose certified bound meets the declared criterion, and returns null otherwise. It does not search uncomputed orders or change a failed tolerance. The square-root helper rounds its rational scaled square root upward before capping TV by one.

The entropy-results.json hash is 7c9d5c31fcb80dcf8f1d3af0fdb4b55161231681d5bb8a4dc6bcdb5ea06ed3c4. Its summary reports improved rate upper bounds and no available k<=3 that certifies TV<=0.1 at N=100 or the larger requested durations. These are inherited evaluated intervals, not independently repropagated g2..g4 values in this lane. The k=3 lower rate remains zero because the retained observed law supplies no h4/P5 witness. Therefore the preceding proof of whole-path TV tending to one for actual orders 0,1,2 must not be extended to k=3 on these data.

### Pair certificate and imported-theorem interface

The retained pair scan source was read in full at SHA-256 8648528899a801a8c23dcae60c1ac3358e107f2aadab88c15d6735d28723f647. It decodes positive exact edges, checks row normalization, pi positivity and invariance, detailed balance, all-source directed reachability, and positive diagonals. It checks every reached forest witness against the original positive rational edges and checks every synchronized successor of the full unreachable complement. Exact path products are labeled as individual path probabilities. They are not substituted for common-word probabilities or conditional flag probabilities.

The saved pair-support.json has SHA-256 fed3127e2df48eea692fae46f4e5a9387aacff5908e6a6999c120f0d1abb7878. It reports 31,375 unordered pairs per map, 30,351 reached for partition and all 31,375 reached for block_ab. Both maximal reached distances are four. The partition complement has 1,024 pairs and zero synchronized successor products in its complete forward closure scan. Thus each rejected pair has disjoint next-output support, a stronger concrete fact than merely failing to merge. Both words and their orientation forest remain part of the retained certificate.

The earlier killed-sector query preparations themselves have merging witnesses on a different output: partition parents 252 and 400 both reach 250 on output 0 with individual path probabilities 1/14; block parents 256 and 340 reach 250 on output 0 with probabilities 1/22 and 1/14. This directly preserves the difference between the constant-word killed-support obstruction and existential common-word merging. Those recorded rational witnesses are readback evidence, not another graph execution.

Primary text checked: [Travers v2](https://arxiv.org/html/1211.6181v2), Sections 2.2.1-2.2.3, Lemma 5, Theorem 2 with Remark 3, and Proposition 1. The literature lane's final hypothesis mapping remains to be compared. No numerical exponential constant or finite-duration prefactor is produced by this readback; minimal probabilities of separately chosen pair paths are not the flag-block quantities required by that construction.


## Revision 4: Final flag extension and integration check

### IP-P4. Whole-start elimination and common flag blocks

The following reconstruction was communicated to root before reading the author's final extension. Maintain a current word w, a distinguished endpoint r, covered initial states that can reach r on w, and eliminated states that cannot generate w. Initially w is empty and its chosen starting state is covered. For an unresolved start k, compute its entire current endpoint set A=delta_k(w). If A is empty, eliminate k. Otherwise, if any j in A is mergeable with r, append a merging word for that pair and choose its common endpoint as the new distinguished state. The selected start becomes covered, and all previously covered starts follow their existing path to r and then the same r-side continuation.

If no j in A merges with r and every pair is mergeable or incompatible, choose a common incompatibility length M for the finitely many pairs (r,j). Any supported length-M future word from r is impossible from every j in A. Appending that word eliminates the whole start k, while preserving covered starts through the chosen r-path. Previously impossible starts remain impossible under extension. Each iteration resolves at least one initial state, so at most s-1 iterations suffice. The terminal word flags its distinguished endpoint from every start that can generate it. This construction cannot replace the entire endpoint-set check by the removal of one chosen incompatible endpoint.

If all merging lengths are bounded by D and all incompatibility lengths by M, the initial flag word has length at most (s-1)max(D,M). Under irreducibility, append a simple path to each desired target, costing at most s-1 further steps. Positive self-loops at every target pad these words to one common length while preserving their endpoints and flag property. The same holding edges let any connecting path be padded to a multiple of that length, proving irreducibility of the blocked hidden kernel directly. Its invariant pi is unchanged by taking a kernel power.

SPM07-SPM08 match this reconstruction. The actual retained D=4, M=1 and s=250 give a sufficient common positive block length at most 1245. This bound does not assert that those flag words or their block alphabet were constructed in the retained execution. Their construction is the separate next obligation. Empty initial flags and singleton models cause no problem: one may always choose a positive common block length and pad with holding edges.

SPM01-SPM06 match IP-P1-IP-P3 and the source checks above. SPM09 keeps its imported asymptotic premise separate from its elementary prefactor-existence deduction. For the latter, choose a positive integer t0 after which the error is bounded by q^t, and set A to the maximum of one and the finitely many earlier ratios. Then A q^t bounds every index. This is an existence deduction with no evaluated A or q. The primary note's mapping was checked against the source locations already listed; no missing input or timing hypothesis was found.

The final pair Markdown has SHA-256 bc6782881e8a5945f9ee389b58e4302cd58f5925b5864bb9be93aa3f1549bff1, and its primary-source note has 6227beb862d7dc0e61d490a091844740ad5db48dce3a3fc4456f6bbafa698dd9. Both tested source hashes remain those in Revision 2. The root entropy summary has cc198e9de95e5a1902539e34568ea727d2defff2e750cb50d301ee566b5743f1. No numerical propagation, test or scientific execution was performed for this readback.

### Target, human report, and next-obligation boundaries

The completed target assembly, counterexample register, human report and next-quantitative-memory obligation were read. They distinguish the elementary entropy bracket valid without irreducibility from the separate flag construction and imported theorem. They report partition as mergeable-or-immediately-incompatible and block_ab as fully mergeable. The report's finite enclosures and available-order decisions do not infer actual TV failure from a failed certificate and do not extend the previous positive-rate separation claim to k=3.

The implementation is correctly described as a finite-depth, user-controlled evaluator with an inherited arithmetic guard. The ideal finite-accuracy theorem is not presented as an already implemented unlimited adaptive solver. Message probability entries, prefix tuple storage, rational bit growth, witness expansion, and unconstructed context/flag alphabets retain their separate cost obligations. The next task is explicitly bounded before any new execution and preserves all existing scientific outputs.

The erasure check removes the application names, favorable search direction, physical vocabulary, and agreement among agents without changing any finite-matrix proof. A one-state constant stationary model demonstrates that the universal entropy domain is nonempty; the synchronized graph also admits finite graphs with dead pairs because its support statement is independently typed. Gauge inheritance continues to require the existing observation square. The auxiliary path comparison supplies no original sensor-VFE identification, physical clock, new curvature term or continuum construction.

No new mathematical defect was found under the stated hypotheses. The concrete attacks remain live scope guards: wrong emission timing, null normalization, a nonstationary preparation, an incomplete pair complement, misoriented witness paths, elimination of only one branching endpoint, an equality-threshold stopping claim, an uncomputed finite prefactor, and every-word claims from an existential word would each invalidate the corresponding stronger statement. This submission does not assign ledger states or rerun numerical evidence.


The final pair proposal JSON was also read at SHA-256 190fd451f2cf67ab211e9782a49f95b08bad8c2702dca2226e47e13ce95030fa. Its SPM01-SPM09 statements match the checked Markdown and explicitly qualify the common-block numerical bound when that expression is positive.
