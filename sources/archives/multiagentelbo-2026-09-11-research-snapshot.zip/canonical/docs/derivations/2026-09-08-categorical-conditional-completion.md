# Categorical conditional completion of parent inference

This construction retains a parent recognition law together with its complete hidden conditional law at one fixed context. The augmented state reconstructs the fine law, so its exact evolution is not a dimension reduction, a minimal-memory description, or an autonomous parent-only closure. The target, stochastic channel, observations, context, and geometric data are held fixed. The exact flow considered here is the complete-simplex reverse-KL Fisher flow. Its finite-time formula is distinct from a finite conditional-logit Armijo update in the existing tree solver.

Let $q(x)$ and $p(x)$ be strictly positive normalized fine laws on the same finite state set. Let $C(y\mid x)\geq0$ be a fixed row-stochastic matrix. Structural zeros in this matrix are admitted. Define

$$
Q(x,y)=q(x)C(y\mid x),
P(x,y)=p(x)C(y\mid x).
$$

Both joint laws have the same support. A parent outcome is defined precisely when some channel entry in its column is positive. On such a column,

$$
q_Y(y)=\sum_xq(x)C(y\mid x),
q(x\mid y)=\frac{q(x)C(y\mid x)}{q_Y(y)},
$$

and similarly for $p$. The root arrays have shape $(Y)$; conditional and structural-support arrays have shape $(Y,X)$, while the channel retains shape $(X,Y)$. Individual structural-zero conditional entries remain zero. An entirely undefined parent row stores NaN conditional values and a false domain mask; its parent and joint masses remain zero. A designated null outcome with positive probability is a defined parent row and has an ordinary conditional law.

On the common joint support,

$$
\log\frac{q(x)}{p(x)}
=\log\frac{Q(x,y)}{P(x,y)}
=\log\frac{q_Y(y)}{p_Y(y)}
+\log\frac{q(x\mid y)}{p(x\mid y)}.
$$

Consequently, with $d(y)=\mathrm{KL}(q(\cdot\mid y)\|p(\cdot\mid y))$,

$$
E_Q\left[\left.\log\frac{q(X)}{p(X)}\right|Y=y\right]
=\log\frac{q_Y(y)}{p_Y(y)}+d(y),
$$

and averaging over the parent gives the exact chain rule

$$
\mathrm{KL}(q\|p)
=\mathrm{KL}(q_Y\|p_Y)+E_{q_Y}d(Y).
$$

The equality between fine and joint KL uses the same channel in both joint laws. It would not follow from two separately chosen channels.

Write $\ell(x)=\log(q(x)/p(x))$. The complete-simplex Fisher flow satisfies

$$
\dot q(x)=-q(x)\left(\ell(x)-\mathrm{KL}(q\|p)\right).
$$

Differentiating the parent mass through the fixed channel and applying the conditional-score identity yields

$$
\dot q_Y(y)
=-q_Y(y)\left(\log\frac{q_Y(y)}{p_Y(y)}
+d(y)-\mathrm{KL}(q\|p)\right).
$$

The autonomous parent Fisher velocity omits the centered conditional contribution. Their difference is

$$
\dot q_Y(y)-\dot q_Y^{\mathrm{autonomous}}(y)
=-q_Y(y)\left(d(y)-E_{q_Y}d(Y)\right).
$$

A positive conditional KL does not by itself force this correction to be nonzero. For example, if every channel row equals a common parent distribution, the parent is independent of the fine state. Then both parent laws equal that distribution and $d(y)=\mathrm{KL}(q\|p)$ is constant on its domain. The correction and parent velocity vanish while hidden conditional inference can continue. This control separates hidden information from the parent effect of its variation across outcomes.

For elapsed flow time $t\geq0$, set $a=e^{-t}$ and $w=1-a$. Define the conditional overlap on each defined row by

$$
Z_a(y)=\sum_xq(x\mid y)^a p(x\mid y)^w,
$$

where the sum includes only the common structural support. The completed finite step is

$$
q_t(x\mid y)=\frac{q(x\mid y)^a p(x\mid y)^w}{Z_a(y)},
$$

$$
q_{Y,t}(y)=
\frac{q_Y(y)^a p_Y(y)^w Z_a(y)}
{\sum_zq_Y(z)^a p_Y(z)^w Z_a(z)}.
$$

Multiplication cancels the conditional normalization and gives

$$
q_{Y,t}(y)q_t(x\mid y)
=\frac{Q(x,y)^aP(x,y)^w}
{\sum_{u,z}Q(u,z)^aP(u,z)^w}
=\frac{q(x)^ap(x)^wC(y\mid x)}
{\sum_uq(u)^ap(u)^w}.
$$

The second equality holds because $a+w=1$ and every channel row sums to one. Thus the reconstructed joint remains exactly in the fixed-channel family, and its fine marginal is the existing complete-simplex flow. It also proves the semigroup property for repeated completion against the same target: the interpolation exponents multiply as $e^{-t}e^{-s}=e^{-(t+s)}$. Evolving root and conditional independently with arbitrary update rules would not provide this compatibility.

The numerical finite step evaluates conditional overlaps with log-sum-exp over declared positive support. It uses $w=-\operatorname{expm1}(-t)$ and returns the identical state at $t=0$, with zero log overlap on defined rows. Undefined overlap values remain NaN. Forbidden entries are replaced only inside logarithm evaluation and are restored as exact zeros in the resulting law; no mass is assigned to them. Positive-support underflow in joint construction, conditional exponentiation, or parent normalization raises an arithmetic error. If a channel is itself constructed by floating-point multiplication, its caller must also ensure that multiplication did not erase intended positive support before calling this module.

The current complete event law has 256 latent states. For the existing single-record channel $K$ of shape $(16,4)$, the complete two-record channel is $C=K\otimes K$, with shape $(256,16)$. Row-major flattening agrees with the existing matrix push: the reshaped vector $qC$ equals $K^{\mathsf T}qK$. This construction applies equally to a genuinely stochastic channel and a deterministic coarse map.

Diagnostics retain fine KL, parent KL, conditional KL with its domain mask, its parent expectation, conditional score expectation, both parent velocities, and the centered correction. They independently compare the reconstructed joint with the recovered fine marginal times the declared channel and measure the KL and score identities. The scalar KL calculations reuse the published cancellation-resistant normalized-law implementation. Numerical residuals are measurements of this finite computation, not claims of formal proof certification.

The implementation is in src/multiagent_elbo/experiments/neighborhood/categorical_completion.py. Its focused tests in tests/rg_v2/test_neighborhood_categorical_completion.py use tiny stochastic matrices to check disintegration, structural zeros, positive null outcomes, undefined columns, chain-rule and score identities, pushed fine velocities, a finite-difference velocity control, full-flow equivalence, fixed-channel reconstruction, semigroup composition, and constant positive hidden KL with zero parent correction. An ordinary probability-underflow control verifies that lost positive support is not silently reclassified as an absent outcome. Test execution is left to the parent task's consolidated validation pass.

