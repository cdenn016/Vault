# Normalized finite-memory path actions

Date: 2026-09-09. Contract: `contract-sha256-57878ccad3991f057ccb4d97142086f191bc7c27e4f2f9d80cc66a8e64586099`. Target digest: `57878ccad3991f057ccb4d97142086f191bc7c27e4f2f9d80cc66a8e64586099`. Source HEAD: `409c61155ac16b21342bfe15c834fda7bb33fb67`.

This is a self-contained finite derivation submitted for independent reconstruction. It assigns no ledger closure and reports no executed experiment. The author and implementation lanes share model, instructions, and filesystem; agreement among them is not additional mathematical evidence. Every statement below concerns the frozen finite-law target. Real probabilities support the mathematical construction; rational probabilities support exact finite arithmetic and rational logarithm enclosures. No external theorem is imported without proof.

## Model, notation, and null-event convention

Let A be a nonempty finite alphabet, N a positive integer, and P a probability mass function on A^N. Set 0 log 0 = 0 in entropy sums. An expression p log(p/q) is zero when p=0, finite when p,q>0, and positive infinity when p>0=q. Let Y_t denote coordinate t for 0≤t<N. P_t denotes the marginal law on the first t coordinates; P_0 assigns mass one to the empty word. Fix an integer k with 0≤k≤N−1 and define

\[
 C_t^k=(Y_{\max(0,t-k)},\ldots,Y_{t-1}),
 \mu_t^k(c)=P(C_t^k=c),
 w_t^k(c,a)=P(C_t^k=c,Y_t=a).                 \tag{1}
\]

The empty context at t=0, or at every t when k=0, has mass one. For μ_t^k(c)>0 define

\[
 p_t^k(a\mid c)=w_t^k(c,a)/\mu_t^k(c).       \tag{2}
\]

For μ_t^k(c)=0 the row is undefined. Its absence is substantive: there is no conditional law on that P-null event. We never manufacture a physical prediction there.

Define Q_0^k(empty)=1 recursively. Given a prefix u of length t, let c_t(u) be its suffix of length min(k,t). If Q_t^k(u)>0, use

\[
 Q_{t+1}^k(ua)=Q_t^k(u)p_t^k(a\mid c_t(u)).  \tag{3}
\]

If Q_t^k(u)=0, set every extension mass to zero without accessing a conditional row. The proof below establishes that every row actually accessed in (3) is defined. Write Q^k=Q_N^k. A positive path action is S_P(y)=−log P(y); outside support, its action is positive infinity. This convention does not authorize subtracting two infinite actions.

## FMA01. Supported rows are normalized conditional laws

For every t and c with μ_t^k(c)>0, equation (2) gives a nonnegative probability row. Indeed, summing w_t^k(c,a) over a gives μ_t^k(c). When μ_t^k(c)=0, every w_t^k(c,a)=0 by nonnegativity, so zero-over-zero cannot select a conditional row. All entries in (1) and every defined row in (2) are rational if P is rational.

## FMA02. The causal construction is well-defined and normalized

The induction invariant at time t is that Q_t^k is normalized and its context marginal equals μ_t^k. At t=0 both assertions hold. If Q_t^k(u)>0, its context has positive Q_t^k mass, hence positive μ_t^k mass, so (3) accesses a defined row. Summing over all extensions first sums each normalized row, proving total mass remains one. Moreover,

\[
 \sum_{u:c_t(u)=c}Q_{t+1}^k(ua)
 =\mu_t^k(c)p_t^k(a\mid c)=w_t^k(c,a).     \tag{4}
\]

For a null context both sides are zero and the equality follows from the zero-prefix convention. The next context is a deterministic suffix of (c,a), including the empty suffix for k=0. Summing (4) over the appropriate preimages therefore gives μ_{t+1}^k when t+1<N. This closes the induction. In particular, every P-null context is unreachable under Q^k at its specified time. No choice on an undefined row affects this construction.

## FMA03. Every retained window matches, and projection is idempotent

Equation (4) proves the exact equality

\[
 Q^k(C_t^k=c,Y_t=a)=P(C_t^k=c,Y_t=a)       \tag{5}
\]

for every t,c,a. Later steps cannot alter an earlier prefix marginal because they are normalized. Thus all time-positioned consecutive windows of length at most k+1 match P, including shorter initial windows. Applying the same k-memory construction to Q^k recovers exactly the same defined rows and null contexts by (5). The resulting law is again Q^k, proving idempotence. This does not assert that longer windows match.

## FMA04. Prefix restriction commutes with projection

For 1≤n≤N, let P_n be the prefix restriction and set k_n=min(k,n−1). Then

\[
 (Q^k)_n=\Pi_{k_n}(P_n),                 \tag{6}
\]

where Π denotes construction (1)–(3). For every t<n, the context size min(k,t) equals min(k_n,t), and every table used at t is computed from the same marginal P_{t+1}, whether starting from P or P_n. The recursions through time n are identical, while summing later normalized rows gives Q_n^k. In particular, Q_n^k=P_n when n≤k+1 because every row encountered then conditions on the entire preceding prefix. Equation (6) compares the same declared memory order, clipped only when the shorter horizon cannot contain that many preceding coordinates; independently selecting a different approximation order is a different operation.

## FMA05. A consistent stationary input gives a homogeneous stationary specialization

Assume now an entire consistent stationary finite-dimensional path family P, rather than one arbitrary finite-horizon law. Fix k≥1. For t≥k the quantities μ_t^k and p_t^k no longer depend on t, by stationarity. Let π(c)=P(Y_0,...,Y_{k−1}=c), and let r(a|c)=P(Y_k=a|Y_0,...,Y_{k−1}=c) on positive contexts. The length-k context shifts from c=(c_1,...,c_k) to (c_2,...,c_k,a) with probability r(a|c). For a proposed new context d, its incoming stationary mass is

\[
 \sum_{c,a:\operatorname{suffix}_k(ca)=d}\pi(c)r(a\mid c)
 =P((Y_1,\ldots,Y_k)=d)=\pi(d).           \tag{7}
\]

The first equality includes only positive contexts; null ones have zero mass. Hence a chain initialized at π remains on positive contexts with invariant context law π. Its coordinate process has the same path construction as Q^k, because its first k coordinates have law P_k and subsequent rows are r. This yields stationarity of every finite coordinate block: shifting a block amounts to starting the invariant context chain at a later time. Prefix consistency follows from the normalized recursion, so the specialization is consistent across every finite horizon. Horizons at most k are the corresponding marginals of π. For k=0 the construction is the independent coordinate product of the stationary one-symbol marginal, which is also stationary and consistent. This establishes a consistent family of finite-dimensional distributions; no continuum-time or other physical-time claim is being made.

## FMA06. P is absolutely continuous with respect to Q^k

Take any y with P(y)>0. Every prefix and each context-plus-symbol event occurring along y then has positive P mass. Each factor p_t^k(y_t|c_t(y)) is strictly positive. Induction in (3) gives Q^k(y)>0 and

\[
 Q^k(y)=\prod_{t=0}^{N-1}p_t^k(y_t\mid c_t(y)).           \tag{8}
\]

Therefore P≪Q^k. The forward KL D(P||Q^k) is a finite real number because it is a finite sum of logarithms of positive ratios over P's support. Q^k can nevertheless assign positive mass to paths that P excludes. Rational inputs give exact rational probabilities in (3) and (8), including exact support comparisons.

## FMA07. Forward KL projection has a rowwise excess-risk identity

For use here and below, finite normalized laws α,β satisfy D(α||β)≥0. If β vanishes at a positive α entry the assertion is immediate. Otherwise −log u≥1−u follows by differentiating u−1−log u, whose unique minimum is zero at u=1. Applied at u=β_i/α_i on positive α entries, it gives D(α||β)≥1−Σ_{α_i>0}β_i≥0. Equality requires both that β has no mass outside α's support and that all positive ratios equal one. Thus equality holds exactly when α=β.

Let R be any law formed from arbitrary normalized time-dependent rows r_t(a|c_t), including arbitrary initial short-prefix rows. Rows on every context can be specified for the mathematical competitor, whether or not R reaches them. Then

\[
 D(P\Vert R)=D(P\Vert Q^k)
 +\sum_{t=0}^{N-1}\sum_{c:\mu_t^k(c)>0}
     \mu_t^k(c)D(p_t^k(\cdot\mid c)\Vert r_t(\cdot\mid c)).       \tag{9}
\]

If R is positive on P's support, subtract its log-product action from (8), take the P average, and regroup by (C_t^k,Y_t); this is (9). If some P-positive path has R(y)=0, at least one factor r_t(y_t|c_t)=0 at a positive w_t^k(c_t,y_t). The corresponding row KL is infinity, and both sides of (9) equal infinity; there is no infinity-minus-infinity operation because D(P||Q^k) is finite. Equation (9) proves optimality of Q^k.

Equality in (9) forces every P-positive-context row of R to equal the corresponding row of Q^k. Starting from the empty word, induction then makes their reachable prefixes identical; the null contexts of P cannot newly be reached. Hence Q^k is the unique minimizing path law, although irrelevant row completions need not be unique. An arbitrary completion of Q^k's undefined rows would represent the same law; it is a mathematical representation only, not an assigned physical conditional.

Equivalently, write a competitor with an arbitrary joint initial k-symbol law α and arbitrary subsequent k-context rows. Then the first k terms in (9) combine by direct log-product expansion into D(P_k||α); the remaining terms run from t=k onward. For k=0 that initial term is zero. Thus preserving the exact initial short prefix in the optimizer does not assume it away in the comparison class.

## FMA08. The loss equals discarded conditional information

For each positive P-prefix u of length t, let p_t(a|u)=P_{t+1}(ua)/P_t(u). Multiplying these full-prefix rows reconstructs P(y) on its support by telescoping. Let B_t^k be the older portion (Y_0,...,Y_{t−k−1}) when t>k and the empty tuple otherwise. Then

\[
 D(P\Vert Q^k)
 =\sum_{t=0}^{N-1}E_P\log\frac{p_t(Y_t\mid Y_{<t})}{p_t^k(Y_t\mid C_t^k)}
 =\sum_{t=0}^{N-1}I_P(Y_t;B_t^k\mid C_t^k).              \tag{10}
\]

Here conditional mutual information is defined, with no external theorem, by the finite sum

\[
 I_P(A;B\mid C)=
 \sum_{c:P(c)>0}P(c)\sum_{a,b:P(a,b\mid c)>0}
 P(a,b\mid c)\log\frac{P(a,b\mid c)}{P(a\mid c)P(b\mid c)}.     \tag{11}
\]

Each denominator in (11) is positive on its numerator's support. For a fixed c this is KL between the joint conditional law and the product of its conditional marginals, so nonnegativity follows from the finite proof in FMA07. Replacing the ratio in (11) by P(a|b,c)/P(a|c) on positive terms gives (10). Expanding finite conditional entropies also yields

\[
 D(P\Vert Q^k)=\sum_t H_P(Y_t\mid C_t^k)-H_P(Y_0,\ldots,Y_{N-1}).       \tag{12}
\]

Equations (10) and (12) are two exact rearrangements of the finite log sums, not independence assumptions.

## FMA09. The loss decreases with memory and becomes exact at the endpoint

For 0≤k≤N−2, subtract equation (12) at k+1 from its value at k. At t≤k both rows already condition on the full prefix. At later times the newly retained coordinate is Y_{t−k−1}. Expanding definition (11) gives

\[
 D(P\Vert Q^k)-D(P\Vert Q^{k+1})
 =\sum_{t=k+1}^{N-1}I_P(Y_t;Y_{t-k-1}\mid Y_{t-k},\ldots,Y_{t-1})\geq0.       \tag{13}
\]

For k=N−1 every conditional uses the entire available past, so Q^{N−1}=P by the same telescoping that reconstructs P in FMA08. More generally D(P||Q^k)=0 if and only if Q^k=P by the equality criterion in FMA07. Equivalently, for each time t the full-prefix next-symbol law agrees P-almost surely with the k-context row, as follows from the vanishing nonnegative conditional KL terms in (10). This is a property at the declared finite horizon. It proves neither a minimal memory order for an infinite process nor uniform-in-horizon approximation error.

## FMA10. Actions are normalized path actions with a signed difference

Equations (3) and (8) define a normalized action by Q^k(y)=exp(−S_{Q^k}(y)); its partition sum is one. For y in P's support,

\[
 S_{Q^k}(y)-S_P(y)=\log\frac{P(y)}{Q^k(y)},
 E_P[S_{Q^k}-S_P]=D(P\Vert Q^k).                       \tag{14}
\]

The difference is a signed function, even though its P-average is nonnegative. For example, take N=2, k=0, A={0,1}, with P(00)=P(11)=2/5 and P(01)=P(10)=1/10. The two one-symbol marginals are uniform, so Q^0 assigns 1/4 to every word. The difference in (14) is log(8/5)>0 on 00,11 and log(2/5)<0 on 01,10. At a Q-positive, P-zero word, S_P is infinite; equation (14) is asserted on P's support and its finite expectation there, not as an unrestricted subtraction of extended actions.

## FMA11. Exact total variation controls bounded observables and obeys Pinsker's bound

For any finite normalized P,Q, put δ(y)=P(y)−Q(y), A_+={y:δ(y)≥0}, and

\[
 d_{\rm TV}(P,Q)=\frac12\sum_y|\delta(y)|
 =\sum_{y\in A_+}\delta(y)=P(A_+)-Q(A_+).                \tag{15}
\]

The equality follows because Σδ=0, so total positive and negative variations agree. Any event difference lies between minus and plus this common mass. Likewise, for real f with finite range [m,M], split the signed expectation according to δ's sign, or subtract m and bound 0≤f−m≤M−m. This gives

\[
 |E_P f-E_Q f|\leq(M-m)d_{\rm TV}(P,Q).                 \tag{16}
\]

Here is a finite proof of the entropy bound. For nonnegative arrays a_i,b_i with totals a,b>0, normalization and FMA07 give the log-sum inequality

\[
 \sum_i a_i\log(a_i/b_i)
 =a\log(a/b)+aD((a_i/a)_i\Vert(b_i/b)_i)\geq a\log(a/b).       \tag{17}
\]

The expression is interpreted by the zero conventions; zero-total groups contribute their limiting value. Apply (17) separately on A_+ and its complement. If D(P||Q) is infinite there is nothing to prove. Otherwise it is at least the Bernoulli KL d(p||q), where p=P(A_+), q=Q(A_+) and p−q=d_TV. For q in (0,1), define g(x)=x log(x/q)+(1−x)log((1−x)/(1−q)). On (0,1), g(q)=g'(q)=0 and g''(x)=1/[x(1−x)]≥4. Integrating this bound twice between q and p gives g(p)≥2(p−q)^2; endpoints follow by continuity. If q is zero or one, finiteness forces p=q and the result is immediate. Therefore

\[
 2d_{\rm TV}(P,Q)^2\leq D(P\Vert Q).                    \tag{18}
\]

For Q=Q^k, the exact support leakage ℓ=Q^k({P=0}) is at most d_TV, by the event bound. Rational inputs make (15) and ℓ exact rational numbers. Equations (16)–(18) address finite bounded-observable errors; they do not bound arbitrary unbounded log-density changes.

## FMA12. Arbitrarily small forward loss can coexist with infinite reverse loss

On a finite space, D(Q||P) is infinite if and only if Q assigns positive mass to {P=0}; if it does not, every nonzero term is a finite logarithm. The following admitted example realizes this obstruction for the actual projection, rather than an unrelated Q. Let N=3, k=1, A={0,1}, and 0<ε<1/4. Define

\[
 P_\varepsilon(000)=a=1-3\varepsilon,
 P_\varepsilon(011)=P_\varepsilon(101)=P_\varepsilon(110)=\varepsilon,       \tag{19}
\]

with all other masses zero. Every coordinate has P(Y_t=0)=b=1−2ε. Both adjacent-pair tables, ordered 00,01,10,11, are (a,ε,ε,ε). Consequently the one-memory projection is P(Y_0,Y_1)P(Y_1,Y_2)/P(Y_1), and in particular

\[
 Q^1_\varepsilon(001)=\frac{a\varepsilon}{b}>0,
 Q^1_\varepsilon(000)=\frac{a^2}{b},
 Q^1_\varepsilon(011)=Q^1_\varepsilon(110)=\frac{\varepsilon}{2},
 Q^1_\varepsilon(101)=\frac{\varepsilon^2}{b}.               \tag{20}
\]

The forbidden word 001 makes D(Q^1_ε||P_ε)=infinity for every ε in this interval. Direct substitution on P's four positive words gives

\[
 D(P_\varepsilon\Vert Q^1_\varepsilon)
 =a\log(b/a)+\varepsilon\log(4b/\varepsilon)\longrightarrow0.       \tag{21}
\]

To verify the limit without an imported asymptotic result, use log u≤u−1 to bound 0≤a log(b/a)≤ε. Also ε log(4b/ε)≤ε log4+ε log(1/ε), and ε log(1/ε)=2ε log(ε^{−1/2})≤2√ε−2ε. The right side tends to zero. Choosing rational ε tending to zero keeps the counterexample within the rational implementation domain. Thus no finite upper bound tending to zero with forward loss can control reverse KL throughout this admitted class.

## FMA13. Recognition-specific VFE differences require density-ratio control

Fix normalized path targets P,Q independently of a subsequently varied recognition law ρ. For ρ≪P≪Q, define the auxiliary normalized-target VFE

\[
 \mathcal F_P(\rho)=\sum_y\rho(y)\log\frac{\rho(y)}{P(y)}.       \tag{22}
\]

Both VFEs are finite and cancellation of the same recognition entropy gives

\[
 \mathcal F_Q(\rho)-\mathcal F_P(\rho)
 =E_\rho\log(P/Q).                                        \tag{23}
\]

Let L_min and L_max be the minimum and maximum of log(P(y)/Q(y)) over the finite positive support of P. Equation (23), being an average, belongs to [L_min,L_max], and its absolute value is at most max(|L_min|,|L_max|). These extrema are attained by point-mass recognitions on minimizing or maximizing words. This is an exact support-specific bound, not a claim that each action difference is positive.

For the family (19), take ρ_ε to be the point mass on 101, which is P_ε-supported. By (20), its VFE difference is log(b/ε), tending to positive infinity, while (21) tends to zero. Thus arbitrarily small forward projection KL supplies no uniform bound on VFE change over all supported recognitions. If ρ places mass outside P's support, the P-target VFE is already infinite and the finite cancellation (23) is not asserted. If the models being compared include different unnormalized evidence constants, those constants must be added explicitly; equation (22) has fixed normalized path targets and partition sum one.

## FMA14. Observed-label bijections commute with the construction

Let ψ:A→A' be a bijection and let P'=ψ_*P denote coordinatewise pushforward. Every word, context and context-plus-symbol event is carried bijectively to its primed version, so μ'_t(ψc)=μ_t(c), w'_t(ψc,ψa)=w_t(c,a), and every defined conditional row is correspondingly equal. Null contexts map precisely to null contexts. Substituting these identities in recursion (3) proves

\[
 \Pi_k(\psi_*P)=\psi_*\Pi_k(P).                             \tag{24}
\]

Reindexing finite sums then preserves forward and reverse KL, total variation, support leakage, conditional-information loss, and the supported log-ratio extrema. Actions pull back along the same word bijection. A previously proved hidden-state/gauge observation square can supply this observed-label bijection, including the identity action for gauge-invariant labels. Equation (24) does not infer such a square for observations for which none has been defined.

## FMA15. Rational logarithm intervals have an explicit remainder and rounding proof

Let x>0 be rational. Choose the unique integer m with 2^m≤x<2^{m+1}, and put r=x/2^m in [1,2). Let t=(r−1)/(r+1) in [0,1/3). For any integer n≥1 define

\[
 A_n(t)=2\sum_{j=0}^{n-1}\frac{t^{2j+1}}{2j+1},
 B_n(t)=\frac{2t^{2n+1}}{(2n+1)(1-t^2)}.                    \tag{25}
\]

The identity log((1+t)/(1−t))=2∫_0^t(1−s^2)^{−1}ds follows by differentiating both sides and matching zero at t=0. The finite geometric identity (1−s^2)^{−1}=Σ_{j=0}^{n−1}s^{2j}+s^{2n}/(1−s^2) gives

\[
 \log r=A_n(t)+2\int_0^t\frac{s^{2n}}{1-s^2} ds
 \in[A_n(t),A_n(t)+B_n(t)].                              \tag{26}
\]

The remainder is nonnegative, and replacing its denominator by 1−t^2 proves the upper bound in (25). The same proof is valid at t=1/3, supplying rational endpoints [a_2,b_2] for log2 by using r=2 only for this constant. Let [a_r,b_r] denote the interval for log r. Since log x=m log2+log r, an enclosing interval is

\[
 [L,U]=\begin{cases}
 [m a_2+a_r,m b_2+b_r],&m\geq0,\\
 [m b_2+a_r,m a_2+b_r],&m<0.
 \end{cases}                                           \tag{27}
\]

The reversed endpoints in the negative-m case are necessary. Every endpoint so far is exact rational arithmetic. For a nonnegative integer B, outward dyadic rounding

\[
 L_B=2^{-B}\lfloor2^B L\rfloor,
 U_B=2^{-B}\lceil2^B U\rceil                              \tag{28}
\]

preserves L_B≤log x≤U_B, including when either endpoint is negative. If (28) is applied once after (27), the interval width is at most (|m|+1)B_n(1/3)+2^{1−B}: each series remainder is bounded by B_n(1/3), and rounding increases width by less than 2^{1−B}. If an implementation instead rounds at intermediate additions or multiplications, each outward step remains valid, but its width must include every such rounding enlargement rather than reuse this single-rounding width bound. The settings n=24 and B=80 satisfy the hypotheses. This proof establishes enclosure for every positive rational x; it does not assume that these settings give disjoint intervals in every later comparison.

## FMA16. Signed interval arithmetic certifies finite KL and density-ratio reports

For rational finite probabilities P,Q with P≪Q, evaluate each positive ratio x_y=P(y)/Q(y) by FMA15, giving rational endpoints l_y≤log x_y≤u_y. Multiplying by nonnegative P(y) and summing yields

\[
 \sum_{y:P(y)>0}P(y)l_y\leq D(P\Vert Q)
 \leq\sum_{y:P(y)>0}P(y)u_y.                              \tag{29}
\]

Individual log ratios and weighted summands can be negative. The proof uses their signed endpoints; replacing negative summands by zero would generally break the claimed enclosure. For normalized laws, the final interval may be intersected with [0,infinity) using FMA07, after the entire signed sum is formed. Additional outward dyadic rounding of the final or intermediate sums preserves enclosure with its own rounding error. If Q is zero at any positive P entry, support accounting returns infinity instead and no logarithm of zero is evaluated. Swapping P,Q gives the same rule for finite reverse KL, and FMA12 identifies its support obstruction exactly.

The minimum supported log ratio is enclosed by [min_y l_y,min_y u_y], and the maximum by [max_y l_y,max_y u_y]: each endpoint inequality follows by taking the corresponding minimum or maximum of the pointwise bounds. These intervals give certified versions of FMA13's recognition bounds. Entropy or conditional-information expressions derived from finite signed log sums can be enclosed by the same sign-aware interval operations; rational coefficients of either sign require reversing the endpoints when negative. A claimed ordering between two uncertain quantities requires an endpoint separation that implies the ordering, or a separate exact mathematical identity. Overlap of intervals alone proves neither equality nor a numerical ordering. In particular, FMA09 establishes exact monotonicity even if a fixed-precision numerical comparison cannot resolve it.

## Scope carried into the RG program

The parent chain and exact observation filter provide a normalized stationary observed path law to which the preceding construction applies. The finite-memory order is a declared approximation class; it does not select a physical clock, establish an infinite-time memory bound, or prove conditional forgetting on arbitrarily rare histories. Hidden-chain mixing alone has not been used as such a theorem. For retained R5 partition/block maps, the previously admitted observation square supplies the invariant-label case of FMA14; there is no new gauge-arrow computation in this derivation.

The action here is the negative logarithm of a normalized auxiliary inference-trajectory law. Its VFE in (22) is not identified with the original sensor/generative VFE. Adding an independent Tr F² term would alter that target and require its own measure, normalization and modeling justification. Gauge curvature, Fisher curvature and base-manifold curvature remain distinct mathematical objects; this finite-memory construction neither equates them nor inserts one as a surrogate for another. The admitted task is to expose the exact memory action and the costs and limits of its finite-memory projection. A favorable small-horizon result would not discharge the unresolved critical, continuum, growing-width or physical-identification obligations.
