# Independent reconstruction: finite-memory path actions

Date: September 9, 2026. Worktree: C:/tmp/elbo-cover-20260908. Contract digest: 57878ccad3991f057ccb4d97142086f191bc7c27e4f2f9d80cc66a8e64586099. Source HEAD: 409c61155ac16b21342bfe15c834fda7bb33fb67. Frozen proof SHA-256: 155783d42f547fef1423e0ce15371ba9470c6acc96dc124b8b0f32a3ad4ef0c1. Frozen proposals SHA-256: aeccf6f209e70d3b675e723b3e8327717aa3a3e80592421e8ca4a8b257c5a2bf.

All sixteen mathematical claims reconstruct on their stated finite domains. The current projection and logarithm source implements the corresponding formulas. No additional substantive correction was identified. The preserved warm-cache float-input defect is real and has a source-level repair: typed cache keys prevent an invalid equal-valued numeric type from receiving an earlier valid Fraction result before validation. The original failed execution remains a failure.

This lane shares the model, instructions, author text, and filesystem with the root and siblings. Independent reconstruction is not blinded or external replication; agreement cannot close a claim. Only this report and agents/proof-check-proposals.json were written. No tests, producer, actual study, trajectory extension, held suite, tamper check, GPU operation, source edit, ledger edit, Git edit, or vault edit was performed. Existing source, XML, and evidence records were read. Actual R5 fractions and study claims require the separate arithmetic checker. All mathematical steps below use finite sums, elementary calculus, or exact rational inequalities.

## Definitions and domain

Fix a nonempty finite alphabet A, positive integer N, normalized nonnegative P on A^N, and 0<=k<=N-1. At time t, C_t^k is the suffix of the past of length min(k,t), mu_t(c)=P(C_t^k=c), and w_t(c,a)=P(C_t^k=c,Y_t=a). On mu_t(c)>0 define p_t^k(a|c)=w_t(c,a)/mu_t(c). Null-context rows are undefined. Q_0(empty)=1; positive Q prefixes extend by the appropriate defined row; zero prefixes have zero extensions without consulting a row. Times and short initial prefixes are part of this construction.

Forward KL uses 0 log0=0 and positive-over-zero equals infinity. The projection has P<<Q, but may have Q mass on P-null full words. Fixed normalized auxiliary targets are distinguished from recognition-dependent generative targets. The rational implementation is a specialization of the real-valued finite theorem, not a claim that rational probabilities have rational logarithms.

## Claim-by-claim reconstruction

### FMA01 — Supported conditional rows

Scope: every finite P,N,k,t and context c with mu_t(c)>0. Each w_t(c,a) is nonnegative and sum_a w_t(c,a)=mu_t(c). Dividing therefore gives a normalized nonnegative row. If mu_t(c)=0, every joint coefficient is zero and the row cannot be defined by a ratio. Finite sums and positive division preserve rationality.

Verdict: RECONSTRUCTED. No independent completion of null rows is a conditional law of P. A nonnormalized supported row would contradict the exact context marginal sum. Unused alphabet symbols can have zero row probability without being removed from A.

### FMA02 — Reachability and causal normalization

Scope: the causal recursion for every finite P,N,k. Induct simultaneously that Q_t is normalized and its current-context marginal is mu_t. Both hold at t=0. A positive Q prefix has positive context mass, hence mu_t(c)>0, so its required row exists. Summing its children sums that row to one. Grouping extensions by context c and next a gives
sum_{u:c_t(u)=c}Q_(t+1)(ua)=mu_t(c)p_t^k(a|c)=w_t(c,a).
Taking the appropriate deterministic suffix of (c,a) gives the next context marginal mu_(t+1), closing the induction.

Verdict: RECONSTRUCTED. This is the necessary proof that null contexts are unreachable; row normalization alone would not establish it. Q can reach a P-null full prefix while retaining a P-positive short context. That does not violate the induction. k=0 has one empty context at every time and the argument reduces to independent time-specific one-symbol factors.

### FMA03 — Window matching and idempotence

Scope: every finite projection and time-positioned consecutive window of length at most k+1. The grouped equality in FMA02 matches (C_t,Y_t). Later stochastic rows preserve each earlier prefix marginal. Every shorter consecutive window ending at t is a marginal of (C_t,Y_t), giving its equality too. These same joint and context marginals compile precisely the same defined conditional rows from Q as from P, including which contexts are null. Reapplying the recursion therefore returns Q.

Verdict: RECONSTRUCTED. Idempotence concerns the projected path law and its supported tables. It does not imply equality of longer windows, equality of the full supports, or finite-order truth of the original process beyond the given horizon.

### FMA04 — Prefix restriction and exact short prefixes

Scope: every 1<=n<=N with clipped order k_n=min(k,n-1). For each t<n, min(k,t)=min(k_n,t). Both routes compute the time-t context row from the same marginal P_(t+1), so their recursions agree through time n. Marginalizing later normalized rows from Q_N leaves Q_n. Thus (Pi_k P)_n=Pi_(k_n)(P_n). If n<=k+1, every row conditions on the entire available past, and the product telescopes to P_n.

Verdict: RECONSTRUCTED. This compares the same order clipped only by the shorter horizon. Rechoosing a different approximation order at each horizon is not asserted to commute with restriction.

### FMA05 — Stationary projective specialization

Scope: an entire consistent stationary input family and one fixed finite k, not one isolated arbitrary P_N. For k>=1 let pi(c)=P(Y0:k-1=c) and r(a|c)=P(Yk=a|Y0:k-1=c). Stationarity makes the later conditional tables independent of absolute time. The incoming mass of shifted context d is
sum_{c,a:suffix_k(ca)=d}pi(c)r(a|c)=P(Y1:k=d)=pi(d).
Null contexts have zero stationary mass and cannot be reached from positive contexts with positive probability. Initializing with pi and appending these rows therefore gives the same causal projected family. Shifting any finite output block starts from the same invariant context distribution and the same subsequent rows, proving stationarity. Prefix consistency follows by summing normalized suffix rows. For k=0 the law is the iid product of the stationary one-symbol marginal.

Verdict: RECONSTRUCTED. No irreducibility or infinite-dimensional extension theorem is needed for these finite-dimensional statements. One finite N=4 law does not itself prove a stationary family at all horizons; the R5 application inherits one from its declared stationary hidden chain.

### FMA06 — Forward support and finite KL

Scope: every P-positive full word y. Each context-plus-symbol event encountered along y contains this positive atom, so its joint and context masses are positive. Every causal factor p_t^k(y_t|c_t(y)) is positive, giving Q(y)>0. Hence P<<Q and D(P||Q) is a finite sum of finite logarithms. Rational P gives rational projected probabilities and exact support comparisons.

Verdict: RECONSTRUCTED. The converse Q<<P does not follow. Leakage onto P-null full words can coexist with exact short-window matching and null-context unreachability. FMA12 supplies a concrete witness rather than treating this distinction as a verbal caveat.

### FMA07 — Forward projection and uniqueness

Scope: all time-dependent k-context competitors R formed from normalized rows r_t, including arbitrary initial short-prefix rows. When R is positive on P support, subtract the two causal log products and average under P. Regrouping by (C_t,Y_t) yields
D(P||R)=D(P||Q)+sum_{t,c:mu_t(c)>0}mu_t(c)D(p_t^k(.|c)||r_t(.|c)).
If R vanishes on a P-positive word, one zero R factor occurs at a positive w_t(c,a), making the corresponding row KL and the full D(P||R) infinite. D(P||Q) is finite, so this is a legitimate extended-real identity without subtracting infinities.

The elementary inequality -log u>=1-u proves each normalized row KL is nonnegative, with equality only for equal rows including their zero entries. Equality of the objective forces all P-positive-context rows to match. Induction from the empty prefix then gives the same reachable prefixes as Q and cannot introduce a null context. Thus the minimizing path law is unique, although unused row completions are not. Equivalently an arbitrary initial k-block law contributes D(P_k||alpha), so the exact initial prefix was not excluded from optimization.

Verdict: RECONSTRUCTED. Arbitrary completions represent unused mathematical rows, not physical P conditionals.

### FMA08 — Conditional-information loss

Scope: every finite P,N,k using full-prefix conditionals only at positive prefixes. Their product telescopes to P(y) on P support. Dividing by Q's product and averaging gives sum_t E_P log[p_t(Y_t|Y_<t)/p_t^k(Y_t|C_t)]. Write the full past as older B_t plus C_t. In the finite definition of conditional mutual information, the joint/product ratio equals P(Y_t|B_t,C_t)/P(Y_t|C_t) on supported atoms. Thus each term is I(Y_t;B_t|C_t). This is a KL of a conditional joint against its marginal product and is nonnegative by the preceding finite log inequality. Expanding the same logs gives sum_t H(Y_t|C_t)-H(Y0:N-1).

Verdict: RECONSTRUCTED. This is a finite regrouping, not an independence or stationarity assumption. Empty older blocks contribute zero. All marginal-product denominators are positive on joint-positive atoms.

### FMA09 — Monotone order and exact endpoint

Scope: adjacent orders 0<=k<=N-2 in the same finite law. Subtract the conditional-entropy expressions at k and k+1. The newly retained variable at time t>=k+1 is Y_(t-k-1), so the difference is
sum_{t=k+1}^{N-1}I(Y_t;Y_(t-k-1)|Y_(t-k):t-1)>=0.
For k=N-1, every causal factor uses the full available past and its product telescopes exactly to P. Zero loss at any k implies P=Q by finite KL equality; equivalently every discarded conditional-information term vanishes, making the full-prefix row equal the k-context row P-almost surely.

Verdict: RECONSTRUCTED. This is monotonicity of forward KL, not of TV, reverse KL, or every pointwise action ratio. Exactness at k=N-1 is a finite-horizon control and proves no infinite-process memory order.

### FMA10 — Signed action difference

Scope: positive P words, on which Q is also positive. Since Q is normalized, S_Q=-log Q has partition sum sum_y exp(-S_Q(y))=1, interpreting zero Q mass as infinite action. On P support, S_Q-S_P=log(P/Q), and its P average is D(P||Q).

The displayed binary two-symbol law has P00=P11=2/5 and P01=P10=1/10, with uniform one-symbol marginals. Its k=0 projection is 1/4 on all four words. The ratios are 8/5 on equal symbols and 2/5 on unequal symbols, so the action difference takes both signs.

Verdict: RECONSTRUCTED. Nonnegative expected loss is not pointwise nonnegative action difference. Differences of infinite actions outside the common positive support are not asserted.

### FMA11 — TV, observables, and finite Pinsker proof

Scope: any finite normalized P,Q and finite-range observable f. Since sum(P-Q)=0, total positive and negative differences agree and each equals TV=(1/2)sum|P-Q|. The event of nonnegative differences attains that value, and no event difference can exceed it. Subtracting min f and separating positive/negative differences gives |E_P f-E_Q f|<=range(f) TV. Leakage Q({P=0}) is one such event error and is at most TV.

For the KL bound, normalize within each of the positive-difference event and its complement. The finite KL inequality gives the log-sum inequality on each group, reducing D(P||Q) to Bernoulli KL d(p||q), with p-q=TV. For 0<q<1, its second derivative in p is 1/[p(1-p)]>=4, while its value and first derivative vanish at p=q. Integrating twice gives d(p||q)>=2(p-q)^2. Endpoints follow by continuity; if q=0 or 1, finite divergence forces p=q. Infinite divergence is trivial.

Verdict: RECONSTRUCTED. No external Pinsker theorem is imported. This controls finite bounded observables and does not supply uniform bounds on log-density ratios or reverse divergence.

### FMA12 — Small forward KL and infinite reverse KL

Scope: the explicit N=3,k=1 binary law with P000=a=1-3epsilon and P011=P101=P110=epsilon, 0<epsilon<1/4. Both adjacent-pair tables are (a,epsilon,epsilon,epsilon), and each zero-symbol marginal is b=1-2epsilon. Hence Q(y0y1y2)=P(y0y1)P(y1y2)/P(y1). Directly:
Q001=a epsilon/b>0; Q000=a^2/b; Q011=Q110=epsilon/2; Q101=epsilon^2/b.
The positive forbidden 001 atom makes reverse KL infinite. Substitution at the four P-positive atoms gives D(P||Q)=a log(b/a)+epsilon log(4b/epsilon).

The first term is between zero and epsilon by log u<=u-1. The second is at most epsilon log4+epsilon log(1/epsilon), and epsilon log(1/epsilon)<=2 sqrt(epsilon)-2epsilon by the same inequality applied to epsilon^(-1/2). Therefore forward KL tends to zero. Rational epsilon gives rational examples throughout.

Verdict: RECONSTRUCTED. This is a counterexample inside the projection class itself, not an arbitrarily chosen unrelated Q. No finite bound based only on small forward loss controls reverse KL in this class.

### FMA13 — Supported recognition VFE

Scope: normalized targets P,Q fixed independently of recognition rho, with rho<<P<<Q. On this finite common support both normalized-target VFEs are finite. Subtracting cancels the identical recognition entropy and gives F_Q(rho)-F_P(rho)=E_rho log(P/Q). This average lies between the supported minimum and maximum log ratio, and point-mass recognitions attain both extremes. The worst absolute change is the larger absolute endpoint.

For FMA12's family, rho concentrated at 101 is P-supported and gives log(b/epsilon), tending to infinity while forward projection KL tends to zero. Thus small forward KL provides no uniform supported-recognition VFE guarantee.

Verdict: RECONSTRUCTED. If rho charges P-null words, F_P is infinite and the finite difference formula does not apply. Different evidence constants must be retained explicitly. These are auxiliary normalized path targets, not a redefinition of the unchanged original sensor/generative VFE.

### FMA14 — Label-bijection covariance

Scope: any bijective alphabet map psi pushed coordinatewise through P, contexts, and symbols. Each context event and joint context/symbol event is paired bijectively, so their masses and ratios match. Null contexts map to null contexts. Induction on the causal recursion gives Pi_k(psi_*P)=psi_*Pi_k(P). Reindexing the same finite sums preserves KL in either direction, TV, leakage, conditional information, and supported ratio extrema; actions are the corresponding pullbacks.

Verdict: RECONSTRUCTED. A nonbijective coarsening would merge distinct events and is not this theorem. A gauge application requires the inherited observation square. Partition/block history labels use its admitted invariant-label case and do not create a new gauge-arrow execution.

### FMA15 — Certified rational logarithms

Scope: every positive rational x, integer n>=1, and dyadic precision B>=0 for the mathematical single-final-rounding formula. Write x=2^m r with 1<=r<2 and t=(r-1)/(r+1). Differentiation and zero at t=0 give log r=2 integral_0^t 1/(1-s^2) ds. Insert the finite geometric identity to obtain the first n atanh terms plus positive remainder 2 integral_0^t s^(2n)/(1-s^2) ds. Since 1-s^2>=1-t^2, the remainder is at most 2t^(2n+1)/[(2n+1)(1-t^2)]. The same proof at t=1/3 encloses log2.

For m>=0, multiply log2's lower and upper endpoints by m in the same order; for m<0 reverse them. Add the log r interval. Exact floor(2^B L)/2^B and ceil(2^B U)/2^B round outward even at negative endpoints. Each series tail is at most its t=1/3 value, and the final two rounding errors total less than 2^(1-B), giving the stated width bound (|m|+1)B_n(1/3)+2^(1-B).

Verdict: RECONSTRUCTED. Intermediate rounding would require its own accumulated error, whereas the current log implementation rounds once at the end. The theorem permits B=0; the public code's declared API is narrower, bits>=1, and actual n=24,bits=80 is inside both scopes. Resource failures do not imply approximate returns or disjoint comparison intervals.

### FMA16 — Signed KL and extremum enclosures

Scope: finite rational normalized P,Q with support dispatched before logs, and valid interval endpoints l_y<=log(P_y/Q_y)<=u_y. On P<<Q, multiplication by nonnegative P_y and finite summation preserves the bounds on KL. Individual summands may be negative and must stay signed. For normalized laws only the completed lower bound may be intersected with zero by the KL theorem. Positive P over zero Q returns infinity; zero P terms contribute zero without log evaluation.

Taking minima of all lower endpoints and all upper endpoints encloses the minimum actual log ratio: every upper endpoint is at least the global minimum, and the lower endpoint at a minimizer bounds it below. The maximum case is analogous. Arbitrary signed linear combinations, such as entropy rearrangements, reverse interval endpoints for negative coefficients. Outward rounding preserves enclosure with its stated additional width.

Verdict: RECONSTRUCTED. Interval overlap establishes neither equality nor strict ordering. Monotonicity in k is a separate exact theorem even when fixed-precision enclosures cannot numerically separate the losses.

## Source contracts and actual range reduction

Current source hashes are f174f586bcf62c5b44da4340daed775ea63620925637c9f05d9be60462163f13 for src/multiagent_elbo/rg_v2/finite_memory_projection.py and 1eb6db2b17d1ad4598e2e1bf69f89b44afa0501ef8b2cd8349298475b2dc639c for certified_logarithms.py.

FiniteMemoryProjection validates a distinct nonempty integer alphabet, common positive word horizon, normalized nonnegative exact Fraction masses, and integer 0<=order<horizon. It copies positive atoms into an immutable mapping. Lines 54-65 accumulate context-plus-symbol counts from source atoms and divide only their positive totals, implementing FMA01. Rows and context masses are immutable mappings; row(t,c) returns None for a valid null context and rejects malformed context lengths. prefix_probability validates the entire prefix, starts at mass one, multiplies time-specific rows, and returns immediately on a zero factor. Thus an undefined context is accessed only with a positive current prefix, which FMA02 proves impossible for consistent compiled data. Its ArithmeticError is not a fallback conditional. law() alone enumerates A^N; compilation itself visits supplied source atoms. Missing source words denote zero mass. The projection module performs exact Fraction arithmetic without the logarithm module's separate bit guard.

For log_bounds, positive exact Fraction input and positive integer terms/bits are checked. If x=1 the exact result is [0,0]. Otherwise let a,b be the bit lengths of numerator and denominator. The initial r=x/2^(a-b) lies strictly between 1/2 and 2, because the positive integers lie in their defining binary intervals. Therefore one correction when r<1 places r in [1,2); the additional r>=2 branch is safe but unnecessary under those exact initial bounds. Negative integer powers of Fraction(2) stay exact. The series variable power starts at t and is multiplied by t^2 after each included term, so after n terms it is precisely t^(2n+1), the tail numerator required by FMA15. Sign-aware multiplication by m is implemented in separate branches. Floor division of negative Python integers is downward, and -floor(-x) is ceiling, so both dyadic rounding formulas are correct across zero.

The inherited guard checks numerator/denominator bit lengths against 65,536 on log inputs and guarded intermediates. Extremely large exact data or precision may raise instead of returning an approximate result; the theorem itself is not limited to machine-resource-admitted x. The actual default 24 terms/80 fractional bits satisfies the strict positive-control API. kl_bounds validates exact normalized probabilities, dispatches support infinity before logarithms, accumulates signed weighted endpoints, and clips only the final lower endpoint. It does not zero negative log contributions. This is a source trace, not a fresh numeric run.

## Cache-type defect and its repair

The archived source in evidence/cache-type-fix/certified_logarithms.py used @lru_cache(maxsize=4096) without typed=True. Because cache lookup precedes the function body, equal-valued numeric keys of different types could return a cached value without executing the positive-Fraction check. The preserved first JUnit was read: 37 cases, one failure, zero errors, zero skips. Its failing case is test_log_requires_positive_exact_input[1.0], with “DID NOT RAISE ValueError.” The recorded cause says an earlier Fraction(1) call primed that cache. This remains a historical failure.

Current line 38 uses typed=True. The local primary runtime source C:/anaconda/Lib/functools.py:483-485 explicitly guarantees separate caching for different argument types; its key construction at lines 469-472 appends the type of each immediate positional and keyword argument. All relevant arguments here are direct scalars. Therefore Fraction(1), float 1.0, int 1, and bool True cannot share a typed key; float/bool integer controls likewise cannot reuse an accepted int-control key. They reach the body, where the x Fraction check and type(terms/bits) is int checks reject them. Valid repeated exact calls may bypass revalidation only for the already validated same-type values. This repairs the named bypass without changing the series mathematics.

The retained affected-run JUnit was read separately: 13 cases, zero failures/errors/skips, with its command selecting only test_certified_logarithms.py and binding the current source hash. It does not erase the initial 37-case failure. The projection module source was unchanged by this fix; no claim here merges the original suite into an invented all-pass execution.

The tests compare intervals to 100-digit Decimal evaluations at selected inputs. That is a numerical cross-check, not the certified proof: Decimal.log values and even decimal conversion of rational endpoints are finite-precision outputs. The enclosure authority is the rational remainder, range-reduction, sign, and directed-rounding argument in FMA15 plus its source implementation. This distinction also applies to binary floating displays of study results.

## Independent proof families and explicit attacks

The causal-window family starts with joint marginal counts, establishes the current-context induction, and derives normalization, matching, idempotence, and prefix restriction. It does not presume null rows can be normalized. A null full word and null short context are distinct; FMA12 creates the former under Q without ever reaching the latter. Degenerate one-symbol alphabets, deterministic source laws, N=1,k=0, and missing zero atoms all remain within the same finite induction.

The log-product family starts with arbitrary normalized competitor rows and expands the P-average action. It proves both the extended-real rowwise excess and uniqueness of the minimizing law. Finite full-prefix telescoping then gives the discarded conditional-information sum and the order decrement. Neither proof assumes stationary inputs or freezes the initial distribution of competitors in advance. Stationarity enters only the separate consistent-family result FMA05.

The support/action family uses the explicit parity law and exact two-symbol sign example. The parity construction has forbidden-word leakage, reverse infinity, and forward loss tending to zero; concentrating recognition on 101 makes its supported VFE change diverge. These are direct counterexamples to reverse-KL control and uniform recognition guarantees from small forward KL. The signed two-symbol action example refutes pointwise positivity. Pinsker gives a distinct bounded-observable bound and does not repair either missing guarantee.

The logarithm family reconstructs the atanh remainder by finite geometric expansion under an integral, then handles m<0 and dyadic rounding explicitly. For x=1/2, the log2 enclosure [a,b] must become [-b,-a]; using [-a,-b] reverses the interval. For any negative non-dyadic lower endpoint, truncation toward zero would move it upward and fail outwardness; integer floor gives the required direction. Signed KL cancellation prevents clipping individual negative terms. These exact algebraic examples are the reasons the scoped implementation survives the attacks, not a declaration that an unrecorded search failed.

A single fixed horizon cannot supply an all-horizon stationary or finite-memory theorem. The homogeneous specialization requires the consistent stationary input family, and the code deliberately retains time-indexed rows for arbitrary P. Prior hidden-chain mixing is not used to prove conditional forgetting on rare histories. Gauge use remains conditional on the inherited observed-label square, and the auxiliary action is not the original sensor/generative model or a new curvature term.

## Search-prior erasure and target scope

Deleting SEARCH_PRIOR_AFFIRMATIVE leaves every normalization sum, KL decomposition, counterexample, and enclosure unchanged. The finite target does not require favorable approximation error. A large forward error, reverse infinity, support leakage, or unresolved interval ordering remains a result; none licenses changing the source law, horizon, or criterion.

The mathematical target is covered by FMA01-FMA06 for causal laws, windows, support and the stationary specialization; FMA07-FMA09 for optimality and conditional-information loss; FMA10-FMA14 for signed actions, error metrics, recognition limitations and label covariance; and FMA15-FMA16 for certified rational numerical reporting. Actual stationary R5 input alignment and all N=4 numerical quantities require the separate source-bound study and independent arithmetic evidence. This lane does not recalculate that data or assign a formal ledger state.

The completed construction-or-strongest-theorem.md and docs/reports/2026-09-09-finite-memory-action-rg.md were subsequently read for target scope. They correctly derive the stationary input family from the stationary R5 hidden path law rather than from the N=4 table alone, preserve signed action and recognition bounds, separate auxiliary from original generative VFE, retain the logarithm resource guard and Decimal-check distinction, and exclude all-horizon memory or physical claims. The human report distinguishes 36 initial passes plus one failure from the 13 affected passes after repair, and the 24 unchanged projection cases. Numerical values and their enclosures remain obligations for the independent arithmetic lane, not results reproduced here. One wording cleanup was requested and then inspected as repaired: the assembly now calls the failing initial37-case execution a 'test run', preserving its failure instead of implying a passing execution. This changes no mathematical or source conclusion.
