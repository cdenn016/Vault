# Bounded independent numerical readback

The single authorized readback completed with exit code 0 in 2.396499599912204 seconds under `C:/anaconda/python.exe`, CPython 3.12.7. The script is `docs/verification/2026-09-09-finite-memory-action/independent_readback.py`, and the adjacent `independent-readback.json` retains its actual argument vector, runtime, environment, script hash, input hashes, comparison values, execution outcome, and elapsed time. It was invoked with `-I -B` and imported only standard-library modules. Its source and all bound inputs remained unchanged during execution.

This agent authored the generic finite-memory projection module. The present check therefore does not supply an independent review of that source. It checks root-produced retained scientific results through separately written Fraction arithmetic, without importing the projection, filter, adapter, root logarithm routine, study helpers, or an earlier readback. A different proof checker owns source/theory assessment. The result here is finite numerical agreement on the named artifacts, not a proof of a universal theorem or a ledger-state assignment.

## Bound artifacts and preserved test history

The independently checked results hash is `091e7c5c1c0cfb54f6fe2eac04ae328ab79b726cb2b240532cf67a739b8cdde5`, and the summary hash is `4233524857256c5b7ac8144f572cf3738d0dd0c33582dcb544456cbe2e3f2836`. Both match the supplied pins and the study execution record. The source, fixture, driver, and output bindings in the retained command/result records match the actual files, except that the initial logarithm source is correctly resolved to its preserved pre-fix archive rather than to the changed current file. The scientific study's first recorded execution returned zero in 4.897161000058986 seconds; this readback did not rerun it.

The initial JUnit packet records 37 executions: 36 passes and one failure, with no errors or skips. The failure is `tests.rg_v2.test_certified_logarithms::test_log_requires_positive_exact_input[1.0]`. All 24 projection cases passed in that packet. The affected rerun contains exactly the same 13 logarithm testcase IDs and all passed, again with no errors or skips. Aggregating by testcase identity and taking the latest recorded outcome yields 37 distinct latest passes. Aggregating actual executions yields 50 executions, 49 passes and one retained failure. The initial packet is not reclassified as green.

The cache-fix record attributes the initial failure to an equal-valued float reusing a previously populated untyped exact-number cache entry before input validation ran. The archived source has `@lru_cache(maxsize=4096)`; the current source has `@lru_cache(maxsize=4096, typed=True)`. The readback checks the old and current source hashes, verifies that replacing this decorator reproduces the current source, and binds the affected test/study records to the corrected source. It does not rerun the historical failed case. The projection source and its test file remain bound to the unchanged initial passing packet.

## Reconstructed finite probability laws

For each observation map, the independent code decodes the retained positive-atom source law, constructs context and context-plus-next-symbol marginals directly from its atoms, and multiplies their exact ratios to generate each order-zero through order-three law. This uses a separate whole-law marginal representation rather than the projection module's compiled row interface. Every reconstructed projected atom matches the saved law, with exact unit total.

| Map | Source positive words | Order 0 | Order 1 | Order 2 | Order 3 |
| --- | ---: | ---: | ---: | ---: | ---: |
| Partition | 512 | 4096 | 512 | 512 | 512 |
| Exact block {a,b} | 16 | 16 | 16 | 16 | 16 |

For all eight laws, the readback independently checks every retained time-window marginal, all shorter prefix probabilities against full-law marginals, child-prefix mass sums, and null-context counts. It recomputes exact total variation, mass outside the original support, inclusion of source support in projected support, and the minimum/maximum supported density ratios. Both each extremal value and its saved witness word agree. The order-three laws recover their source laws exactly, with zero total variation, zero support leakage, and zero forward/reverse KL.

The order-zero partition law assigns positive mass to words absent from the exact source and consequently has infinite reverse KL. That support failure is preserved. Every other retained reverse KL is finite on the actual source/projected supports. These statements concern these finite horizon-four laws; they do not establish a minimal memory order or an approximation guarantee at other horizons.

## Source-law checks against the actual hidden chain

The source laws are not accepted solely because they can be loaded. The readback independently decodes the original 250-parent sparse kernel and reconstructs pi from the 432 incidence target masses. It checks original parent ordering, the saved stationary parent vector, and the parent partition/exact-block observation maps against actual parent payloads.

It then directly propagates nine distinct partition words and seven distinct exact-block words of length four. These cover constant zero, both alternating zero/one words, and every retained minimum/maximum ratio witness word after deduplication. Their hidden-path masses agree exactly with the saved observed source laws. In addition, both source laws' complete length-two marginals equal the preceding observation-history artifact's stationary length-two law. The prior artifact is separately pinned by its existing results hash. This is representative hidden-path readback plus an entire shorter marginal check; it is not an independent reconstruction of the whole source-word producer.

## Independent logarithm and KL enclosures

The new logarithm code uses 32 terms and outward rounding to 96 binary fractional bits. For x = 2^e m with 1 <= m < 2, it computes log(m) using z = (m-1)/(m+1) and the first 32 terms of twice the odd-power series. The positive remainder is bounded by `2 z^65 / (65 (1-z^2))`. A negative exponent e reverses the endpoints when multiplying the log(2) enclosure. Only after combining the range-reduction terms does the routine round its lower endpoint down and upper endpoint up to denominator 2^96. All arithmetic is rational; no floating-point logarithm or imported root logarithm code is used.

Using these independent bounds, all eight forward-KL intervals and all seven finite reverse-KL intervals are contained in their primary certified intervals. No comparison needed the weaker intersection-only outcome; zero intervals coincide exactly. The remaining reverse-KL comparison agrees on infinity from explicit support leakage. All eight independent forward-KL intervals are also contained in the saved conditional-information-sum intervals. This last comparison checks numerical compatibility with that retained entropy accounting; the readback does not replace its general mathematical proof.

The machine-readable record preserves every primary/independent interval pair, its widths, and the containment relation, as well as the reconstructed TV, support leakage, ratio extrema, representative path masses, and independent law digests. There were 1,254 distinct positive logarithm ratios in this bounded calculation.

## Limits and unchanged work

Only this readback script, its JSON output, and this note were changed by this lane. No pytest run, full scientific study, old producer, GPU work, gauge-arrow evaluation, tamper check, held S1-S3 work, Git operation, or vault write occurred. Historical failures remain failures, and no ledger state is assigned here. The computation concerns the retained finite trajectory laws; it does not identify their actions or VFE with the original sensor/generative model or establish a continuum or infinite-memory limit.
