"""Certified rational logarithm and relative-entropy enclosures."""
from __future__ import annotations
from fractions import Fraction as F
from functools import lru_cache
from typing import Literal
from rg_v2.inference_persistence_model import guard
from rg_v2.recursive_parent_model import require

Bounds = tuple[F, F]
KLBounds = Bounds | Literal['infinite']


def _round_outward(lo: F, hi: F, bits: int) -> Bounds:
    """Round lower down and upper up to multiples of 2**(-bits)."""
    scale = 1 << bits
    lower = (lo.numerator*scale)//lo.denominator
    upper = -((-hi.numerator*scale)//hi.denominator)
    return guard(F(lower,scale)), guard(F(upper,scale))


def _series(r: F, terms: int) -> Bounds:
    r"""Bound log(r) for 1<=r<=2 by its positive atanh series and tail.

    With t=(r-1)/(r+1), the omitted tail after n terms is at most
    2*t**(2*n+1)/((2*n+1)*(1-t*t)). Every operation is rational.
    """
    t = guard((r-1)/(r+1))
    square = guard(t*t)
    power = t
    total = F(0)
    for j in range(terms):
        total = guard(total+2*power/(2*j+1))
        power = guard(power*square)
    tail = guard(2*power/((2*terms+1)*(1-square)))
    return total, guard(total+tail)


@lru_cache(maxsize=4096)
def log_bounds(x: F, terms: int = 24, bits: int = 80) -> Bounds:
    r"""Enclose log(x) by range reduction and directed dyadic rounding.

    Write x=2**m*r with 1<=r<2. Both log(r) and log(2) have positive
    atanh-series bounds. Multiplication by negative m swaps endpoint roles.
    The inherited exact arithmetic-size guard fails rather than approximates
    if an input/intermediate exceeds the admitted computational resource bound.
    """
    require(isinstance(x,F) and x>0,'log input must be a positive exact fraction')
    require(type(terms) is int and terms>=1 and type(bits) is int and bits>=1,
            'series terms and fractional bits must be positive integers')
    guard(x)
    if x==1:
        return F(0),F(0)
    m = x.numerator.bit_length()-x.denominator.bit_length()
    r = guard(x/(F(2)**m))
    if r<1:
        m-=1
        r=guard(2*r)
    elif r>=2:
        m+=1
        r=guard(r/2)
    lo,hi = _series(r,terms)
    two_lo,two_hi = _series(F(2),terms)
    if m>=0:
        lo,hi=guard(lo+m*two_lo),guard(hi+m*two_hi)
    else:
        lo,hi=guard(lo+m*two_hi),guard(hi+m*two_lo)
    return _round_outward(lo,hi,bits)


def kl_bounds(p: tuple[F,...], q: tuple[F,...], terms: int = 24, bits: int = 80) -> KLBounds:
    r"""Enclose KL(p||q)=sum_i p_i log(p_i/q_i), or return 'infinite'.

    Inputs are aligned normalized exact nonnegative rows. Zero p terms vanish;
    positive p against zero q has infinite divergence. Individual terms can be
    negative. Only the final lower bound may be intersected with KL>=0.
    """
    require(bool(p) and len(p)==len(q),'probability supports must be aligned and nonempty')
    require(all(isinstance(w,F) and w>=0 for w in (*p,*q)) and sum(p)==sum(q)==1,
            'KL inputs must be normalized nonnegative exact laws')
    require(type(terms) is int and terms>=1 and type(bits) is int and bits>=1,
            'series terms and fractional bits must be positive integers')
    lower=upper=F(0)
    for a,b in zip(p,q,strict=True):
        if not a:
            continue
        if not b:
            return 'infinite'
        lo,hi=log_bounds(guard(a/b),terms,bits)
        lower=guard(lower+a*lo)
        upper=guard(upper+a*hi)
    return max(F(0),lower),upper
