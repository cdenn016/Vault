"""Bind native finite claims to their current derivations and executed evidence."""
from pathlib import Path
import hashlib, json
ROOT=Path(__file__).resolve().parents[4]
RUN=Path(__file__).resolve().parent.parent
VERIFY=ROOT/'docs/verification/2026-09-09-finite-memory-action'
def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(name: str, data: object) -> None:
    (RUN/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
def main() -> None:
    contract=json.loads((RUN/'problem-contract.json').read_text(encoding='utf-8'))
    meta={k:contract[k] for k in ('schema_version','contract_id','target_digest')}
    intake=json.loads((RUN/'evidence/native-intake.json').read_text(encoding='utf-8'))
    assert intake['accepted_current_scoped_evidence']
    assert all(sha(ROOT/p)==h for p,h in intake['read_artifact_sha256'].items())
    science=json.loads((RUN/'evidence/scientific-record.json').read_text(encoding='utf-8'))
    assert all(sha(ROOT/p)==h for field in ('source_sha256','raw_artifact_sha256') for p,h in science[field].items())
    assert science['latest_cases']==dict(distinct=37,passed=37,failed=0,errors=0,skipped=0,execution_total=50,historical_failures=1)
    (RUN/'evidence/independent-readback.json').write_bytes((VERIFY/'independent-readback.json').read_bytes())
    original=json.loads((RUN/'agents/claim-proposals.json').read_text(encoding='utf-8'))
    assert len(original['claims'])==16
    claims=[]; evidence=[]; edges=[]; attacks=[]
    def ev(eid: str, kind: str, path: str, statement: str, conditions: list[str]) -> str:
        evidence.append(dict(id=eid,kind=kind,supports=True,scope=statement,side_conditions=conditions,
                             artifact_path=path,artifact_sha256=sha(RUN/path)))
        return eid
    def claim(cid: str, statement: str, quantifiers: str, kind: str, falsifier: str, eids: list[str], assumptions: list[str]) -> None:
        claims.append(dict(id=cid,statement=statement,quantifiers=quantifiers,kind=kind,falsifier=falsifier,
                           target_digest=meta['target_digest'],state='EVIDENCE_VERIFIED',assumption_ids=[],
                           explicit_assumptions=assumptions,evidence_ids=eids,bridge_premise_ids=[]))
    def attack(cid: str, challenge: str, response: str, path: str) -> None:
        attacks.append(dict(id='attack-'+cid,claim_ids=[cid],attack=challenge,response=response,disposition='REJECTED',
                            artifact_path=path,artifact_sha256=sha(RUN/path)))
    for c in original['claims']:
        cid=c['id']
        eids=[ev('proof-'+cid,'DERIVATION','agents/memory-action-construction.md',c['statement'],[c['derivation'],*c['assumptions']]),
              ev('reconstruction-'+cid,'DERIVATION','agents/independent-proof-check.md',c['statement'],
                 ['Written finite reconstruction of '+cid,'Shared model/filesystem; no blinded or formal-proof-assistant claim.'])]
        claim(cid,c['statement'],c['quantifiers'],c['kind'],c['falsifier'],eids,c['assumptions'])
        edges.extend({'from':cid,'to':dep} for dep in c['dependencies'])
        attack(cid,c['falsifier'],'The separate written reconstruction of '+cid+' retains these assumptions: '+
               '; '.join(c['assumptions'])+'. It addresses support, timing, preparation and quantifiers explicitly.',
               'agents/independent-proof-check.md')
    numbers=[
      ('FMN01','The current distinct37 tiny cases pass across50 executions, with one initial invalid-input failure preserved and repaired.',
       '24 unchanged projection cases passed initially; all13 affected logarithm cases passed on the typed-cache source. Initial run is not relabeled all-passing.'),
      ('FMN02','The stationary four-observation R5 realization yields eight normalized finite-memory projections with exact retained windows, stationary rows and2392 prefix comparisons.',
       'Two fixed observation maps, horizon4 and orders0..3. Original source-bound execution plus bounded independent reconstruction; no original producer rerun.'),
      ('FMN03','The eight actual comparisons retain certified forward/reverse KL, exact TV and support leakage; successive forward losses strictly decrease through the exact order-three endpoint.',
       'Current finite rational laws and24-term/80-bit enclosing log arithmetic. Partition orderzero has infinite reverseKL and positive outside-support mass.'),
      ('FMN04','The actual supported log-density extrema and their path witnesses distinguish average forward prediction loss from recognition-specific VFE bounds.',
       'The finite P-positive word carrier only; sharp supported bounds for the auxiliary normalized path targets, not original sensor/generative VFE.')]
    for cid,statement,scope in numbers:
        eids=[ev('execution-'+cid,'NUMERICAL','evidence/scientific-record.json',statement,[scope,'Current source and raw artifact binding.']),
              ev('readback-'+cid,'NUMERICAL','evidence/independent-readback.json',statement,[scope,'Bounded readback, not full scientific duplication.'])]
        falsifier='A current exact source, input, raw JUnit, witness or preparation discrepancy within this recorded scope.'
        claim(cid,statement,scope,'NUMERICAL_OBSERVATION',falsifier,eids,[])
        attack(cid,falsifier,scope+' Separate arithmetic reconstructs exact positive probabilities and the timing/preparation seams; current bindings and raw JUnit are recounted.','agents/independent-numeric-check.md')
    all_ids=[c['id'] for c in claims]+['target']
    target=contract['target']
    claim('target',target['statement'],target['quantifiers'],'MATHEMATICAL',target['falsification_criterion'],
          [ev('target-derivation','DERIVATION','construction-or-strongest-theorem.md',target['statement'],
              ['Frozen finite target only; rational implementation instance has separate numerical dependencies.'])],[])
    edges.extend({'from':'target','to':cid} for cid in all_ids if cid!='target')
    attack('target','Finite-horizon projection accuracy could be overstated as uniform filtering, reverse-KL control, original generative VFE or complete RG theory.',
           'The direct construction discharges only the finite contract and preserves every support, timing, preparation and observation hypothesis. Stronger program claims remain open.',
           'agents/native-closure-coverage.md')
    dump('claim-ledger.json',{**meta,'assumptions':[],'evidence':evidence,'claims':claims})
    dump('dependency-dag.json',{**meta,'edges':edges})
    reconstruction=dict(claim_ids=all_ids,method='Native written finite reconstruction, separate plain-Fraction readback and explicit target implication.',
        result='PASS',conclusion='Every current scoped ID has derivation or bound exact output; shared-model and partial-readback limits are explicit.',
        artifact_path='agents/native-closure-coverage.md',artifact_sha256=sha(RUN/'agents/native-closure-coverage.md'))
    dump('adversarial-report.json',{**meta,'attacks':attacks,'independent_reconstruction':reconstruction,
         'oracle_erasure':{**reconstruction,'method':'Reconstruct all21 IDs from finite definitions and current artifacts without using a favorable search direction as a premise.'}})
    families=[('causal-law','Sliding-context induction, occupied rows and consistent stationary context chains.',['FMA01','FMA02','FMA03','FMA04','FMA05','FMA06','FMN02']),
              ('information-projection','Rowwise forward-KL excess risk, discarded information and signed actions.',['FMA07','FMA08','FMA09','FMA10']),
              ('support-vfe','Exact TV, parity support obstruction and supported recognition log ratios.',['FMA11','FMA12','FMA13','FMA14','FMN04']),
              ('certified-arithmetic','Rational range reduction, proved remainder and signed dyadic interval accounting.',['FMA15','FMA16','FMN01','FMN03'])]
    dump('approach-registry.json',{**meta,'mechanism_families':[dict(family_id=fid,core_mechanism=mechanism,target_obligation_ids=ids,
        representation='Finite kernels, probability/subprobability messages and supported conditional laws.',
        invariant_or_obstruction='Normalized path law, exact filter or named preparation/memory obstruction.',
        obligations=['Retain finite support, phase, preparation and observation assumptions.'],
        bridge='The target combines this derivation family with the current rational realization.',
        failure_test='An admitted finite counterexample, violated premise or changed scientific input.',verified_results=ids,
        open_gaps=[],novelty_fingerprint='Elementary finite probability construction; no novelty claim.',
        disposition='established within the frozen finite target') for fid,mechanism,ids in families]})
    dump('release.json',{**meta,'checkpoint':'Current finite observation-history proofs and exact evidence assembled.',
        'target_claim':'target','terminal_status':None,'certificate_claim':'target',
        'strongest_result':'Normalized optimal finite-memory path actions, exact information-loss and support/VFE boundaries, with certified retained R5 approximation errors.',
        'unresolved_obligations':[],
        'limitations':['Finite contract; broader goal remains active.','No minimal infinite-process memory order or duration-uniform approximation bound.',
                      'No auxiliary recognition-dependent joint substituted for original VFE.','No new gauge execution or critical/continuum/physical claim.',
                      'Bounded readback, shared model and written rather than machine-formal proof.']})
    dump('evidence/native-adjudication.json',{**meta,'method':'Root native classification after reading finite proof reconstruction and bounded exact readback.',
         'totals':{'claims':21,'mathematical':17,'numerical':4},
         'claims':{c['id']:{'state':c['state'],'kind':c['kind'],'evidence_ids':c['evidence_ids']} for c in claims},
         'scope':'Only the frozen finite contract; structural validation is separate.'})
    print(json.dumps(dict(claims=len(claims),evidence=len(evidence),edges=len(edges),attacks=len(attacks))))
if __name__=='__main__':
    main()
