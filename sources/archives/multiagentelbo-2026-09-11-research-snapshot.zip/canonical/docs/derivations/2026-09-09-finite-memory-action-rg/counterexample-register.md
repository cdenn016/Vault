<!-- rigorous-theory-search-metadata {"contract_id": "contract-sha256-57878ccad3991f057ccb4d97142086f191bc7c27e4f2f9d80cc66a8e64586099", "schema_version": "rigorous-theory-search/v1", "target_digest": "57878ccad3991f057ccb4d97142086f191bc7c27e4f2f9d80cc66a8e64586099"} -->

# Explicit finite obstructions

FMA10 gives a positive binary two-time law whose order-zero action difference has both signs. It refutes interpreting the pointwise memory correction as a nonnegative penalty.

FMA12 uses the supported words000,011,101,110 with masses1-3epsilon,epsilon,epsilon,epsilon. Its order-one projection assigns positive mass to forbidden001. Forward KL tends to zero as epsilon tends to zero while reverse KL is infinite. FMA13 uses the supported point recognition at101 to show unbounded VFE change in that same limit. These refute uniform reverse/VFE control from forward KL alone.

The actual four-time partition order-zero projection assigns about0.687557 mass outside exact support and has infinite reverse KL. The k1/k2 examples have small average forward error but larger supported log-ratio extrema. None refutes the finite projection theorem; these are retained outcomes within it.

The initial cache validation defect is a separate real implementation failure, preserved in evidence/cache-type-fix.json with the prior source and raw JUnit. It was repaired with typed keys and only the affected logarithm cases rerun. No mathematical scope or scientific target was changed.
