# Gaussian modal trajectory compression

September 8, 2026. This construction compresses the fixed-preparation, fixed-target full-Gaussian trajectory used by the conditional-completion control. It retains exact initial and target parent laws plus selected spectral corrections to their interpolation. The object is a preparation-dependent trajectory representation. It is not an autonomous parent vector field, a Markov closure, a semigroup on parent laws, or a closure of the separate conditional-tree solver. Context, frames, connections, target, and parent maps remain fixed throughout evaluation.

## Spectral representation of the full trajectory

Let the initial and target laws be \(q=\mathcal N(\mu_q,\Sigma_q)\) and \(p=\mathcal N(\mu_p,\Sigma_p)\), with positive definite covariances. Write \(\Sigma_p=LL^T\) and diagonalize the precision in target-whitened coordinates:

\[
A=L^T\Sigma_q^{-1}L=U\operatorname{diag}(\lambda_i)U^T,

h=U^TL^T\Sigma_q^{-1}(\mu_q-\mu_p).
\]

Every eigenvalue is positive. For a fixed full-row-rank map \(F\), define \(u_i=FLUe_i\), \(a=e^{-t}\), \(w=1-a\), and \(d_i=w+a\lambda_i\). The previous [full-Gaussian natural-flow derivation](2026-09-08-gaussian-tree-fisher-inference.md) gives linear interpolation of fine precision and information vectors. In the whitened eigenbasis this means precision \(\operatorname{diag}(d_i)\) and centered information vector \(ah\). Consequently the exact parent moments are

\[
\mu_Y(t)=F\mu_p+\sum_i u_i\frac{ah_i}{d_i},

\Sigma_Y(t)=\sum_i\frac{u_i u_i^T}{d_i}.
\]

This is another representation of the full-family control already reconstructed in the [conditional-completion derivation](2026-09-08-gaussian-conditional-completion.md). It does not require the initial law or the evolving law to remain Markov on the agent chain.

## Endpoint-preserving truncation

Let \(K\) be the retained set of modes. Start from the affine interpolation of the parent moments, \(a\mu_{q,Y}+w\mu_{p,Y}\) and \(a\Sigma_{q,Y}+w\Sigma_{p,Y}\). Replace the interpolation of each selected mode with its exact rational trajectory:

\[
\widehat\mu_Y(t)=a\mu_{q,Y}+w\mu_{p,Y}
+\sum_{i\in K}u_i h_i\left(\frac{a}{d_i}-\frac{a}{\lambda_i}\right),
\]

\[
\widehat\Sigma_Y(t)=a\Sigma_{q,Y}+w\Sigma_{p,Y}
+\sum_{i\in K}u_i u_i^T\left(\frac{1}{d_i}-w-\frac{a}{\lambda_i}\right).
\]

Every omitted covariance mode retains weight \(w+a/\lambda_i>0\), while each selected covariance mode has weight \(1/d_i>0\). Since \(FLU\) has full row rank, their sum is positive definite in exact arithmetic for every finite nonnegative flow parameter. Both endpoints are exact, regardless of the budget. With no retained modes the trajectory is moment interpolation; with all modes retained it is the exact pushed full-Gaussian trajectory.

For stable evaluation, put \(k_i=\lambda_i-1\). The mean correction coefficient and covariance correction coefficient become

\[
c_i=\frac{aw k_i}{d_i\lambda_i},
 v_i=-k_i c_i.
\]

These equivalent expressions avoid subtracting nearly equal values at the endpoints or at \(\lambda_i=1\). The implementation computes \(w=-\operatorname{expm1}(-t)\) and \(d_i=w+a\lambda_i\). It returns the stored initial law exactly at \(t=0\), and accepts positive infinity as the analytic target endpoint with zero rate. It neither floors eigenvalues nor clips a covariance; a failed Cholesky check at an interior evaluation remains a numerical failure. The mathematical SPD statement is not a certificate for arbitrarily ill-conditioned floating-point inputs.

Differentiation with respect to the trajectory parameter gives the baseline rates \(-a(\mu_{q,Y}-\mu_{p,Y})\) and \(-a(\Sigma_{q,Y}-\Sigma_{p,Y})\). The modal correction rates are

\[
r_i=-\frac{a}{d_i^2}+\frac{a}{\lambda_i}
=\frac{ak_i(2a-1+a^2k_i)}{d_i^2\lambda_i},

s_i=-k_i r_i.
\]

The returned mean rate adds \(\sum_{i\in K}u_i h_i r_i\), and the covariance rate adds \(\sum_{i\in K}u_i u_i^T s_i\). These are derivatives of the prepared approximation, not values of a vector field reconstructed from its current parent law alone.

## Common mode selection and coordinate behavior

One spectral decomposition is prepared for each fine initial/target pair and reused for every parent depth. Selection never uses \(F\). Sorted neighboring eigenvalues are connected when their gap is at most \(10^{-10}\) times the larger absolute value. The resulting connected clusters are retained atomically; no eigenvalue is averaged or changed. Transitive adjacency can make a cluster's overall span exceed a single adjacent-gap tolerance.

For each cluster \(G\), its score is the maximum over the explicitly configured selection times of

\[
\left(\sum_{i\in G}(h_i c_i)^2\right)^{1/2}
+\left(\sum_{i\in G}v_i^2\right)^{1/2}.
\]

These are the Euclidean mean-curvature norm and Frobenius covariance-curvature norm in target-whitened coordinates. The score is a declared heuristic. It is not a certified error bound, a solution of a parent-specific approximation problem, or a guarantee about times outside the configured selection set.

Clusters are ranked by decreasing score, with spectral order breaking exact ties. A nonnegative integer budget counts modes, not clusters. Ranked clusters that fit the remaining budget are retained in full, and oversized clusters are skipped; unused capacity is possible. The string `full` retains every mode. The same spectrum and budget therefore yield the same selected indexes at both parent depths.

For exactly repeated eigenvalues, both cluster score terms are invariant under orthogonal changes of basis inside the repeated eigenspace. Keeping or dropping its complete cluster avoids selecting a basis-dependent part of that eigenspace. Under passive fine and parent frame changes, whitening changes by an orthogonal map, so the represented physical laws transform covariantly in exact arithmetic. Numerical rank, cluster boundaries, and nearly tied scores remain finite-precision decisions; no claim of uniform stability at those decision boundaries is made. Tests compare evaluated laws and rates, rather than eigenvector entries.

A further fixed parent projection \(S\) sends every stored endpoint through \(S\) and every retained vector \(u_i\) to \(Su_i\). With the same selected mode set, evaluating then projecting equals compiling for \(SF\) and evaluating, in exact arithmetic. This is compatibility with linear projection of one prepared trajectory. It does not imply a semigroup or an autonomous coarse inference law.

## API, retained state, and limits

`prepare(q, p, times)` returns `Spectrum(lambda_, h, U_L, groups, order, group_scores, selection_times)`, where `U_L` means \(LU\). `compile_parent(F, q, p, spectrum, budget)` requires the same fine initial/target pair used during preparation. It returns `Representation(initial, target, u, lambda_, h, selected_indexes)`, retaining only the parent endpoints and selected projected spectral data. `evaluate(rep, time)` returns the represented Gaussian and an existing `Gaussian` container holding its mean and covariance rates. The rate container is a tangent, not a probability law with positive covariance.

Preparation and compilation are offline, nondifferentiable operations. All runtime tensors are detached and cloned, including selected views, so an autograd graph or a slice of a full spectral allocation does not silently retain the fine preparation. The compiler spectrum and the fine law are not fields of the runtime representation. Scientific experiments may separately retain them as oracle and provenance inputs; their presence in the experiment controller must not be attributed to the smaller runtime object.

For visible dimension \(m\) and \(k\) retained modes, `storage(rep)` counts

\[
2m+2m^2+mk+2k
\]

floating scalars: two parent means, two parent covariances, the selected projected vectors, eigenvalues, and information coordinates. Integer selected-mode indexes and Python object metadata are excluded. This is an actual tensor-element count of the representation, not peak memory, allocator usage, temporary workspace, or compilation cost. The initial full eigendecomposition and oracle experiments still require fine-dimensional work.

The supplied small tests compare full retention with the independent full-Gaussian flow and its analytic rate, verify finite-difference rates under several budgets, preserve both endpoints and SPD at zero retention, avoid cutting repeated or nearly repeated eigenspaces, check passive frame changes with degeneracy, and compare direct versus staged projection. A storage test counts the object's floating tensors and checks that differentiable fine inputs leave no retained runtime gradient graph. Test execution is reserved for the coordinating implementation's consolidated pass; this derivation records no passing outcome.
