# Declared nonflat connections and parent compatibility

September 8, 2026. This is a bounded vector-bundle construction for the existing two-dimensional overlap cover. Its algebra is derived below. It does not infer a connection from attention, assert a general connection on a merely measurable law fiber, or make a limiting RG claim. The implementation authority is the user-approved nonflat-connection milestone. The earlier local-tree ELBO and statistical coupling assumptions remain in force.

## Convention and independently declared data

Keep U=(-1.5,1.5)^2, the existing four agent domains, one trivial SO(2) principal bundle, and the standard two-dimensional belief and model representations. Choose two principal connections on that common bundle. The choices are independent across the belief and model channels, not across individual agent copies. In a common reference frame, with c=(x,y) and J=[[0,-1],[1,0]], declare

    a^b = (kappa_b/2)(x dy-y dx),
    a^m = (kappa_m/2)(x dy-y dx),
    A_bar^b = a^b J,  A_bar^m = a^m J.

The finite constants kappa_b and kappa_m are independent configuration values. Nonzero values give an explicitly nonflat family. Every agent and every availability parent uses the same reference connection in each channel. Different local agent and chart frames do not create different physical connections or distinct principal topology classes.

The existing code uses sample coordinates z=G(c) z_bar and D=d+A. Therefore

    A = G A_bar G^T - (dG)G^T.

A further old-to-new coordinate change S gives A'=S A S^T-(dS)S^T and z'=Sz. This agrees with the manuscript's local-frame convention after identifying its old-to-new associated-coordinate map as S=rho(a)^(-1). The opposite signs in a principal-frame formula are not a different physical convention. The agent-major direct sum has coordinates (belief_x,belief_y,model_x,model_y) for each agent and curvature coefficient K_bar=diag_i(kappa_b J,kappa_m J).

Since each channel is Abelian, A_bar wedge A_bar=0 and dA_bar=kappa J dx wedge dy. Thus

    K = dA + A wedge A = G K_bar G^T dx wedge dy.

Here and in the implementation, a returned matrix called K is the coefficient of dx wedge dy. Curvature is declared connection data, not a curvature of the information metric or evidence of nontrivial bundle topology. This construction lives on a contractible base and a trivial principal bundle.

## Exact path transport and channel morphisms

Parallel vectors satisfy dz/dt=-A(gamma_dot)z. For a straight segment from c_0 to c_1, direct substitution into the one-form gives

    integral a^x = (kappa_x/2) det(c_0,c_1).

For a polygonal path with successive vertices c_0,...,c_N, sum those segment integrals. Therefore the exact reference transport in channel x is the rotation

    T_bar^x = exp[-J (kappa_x/2) sum_j det(c_j,c_(j+1))],

and the represented transport is

    T^x = G_end^x T_bar^x (G_start^x)^T.

There is no numerical integration or path ordering approximation: all reference connection values commute. For a closed polygon the half determinant sum is its signed area, so a counterclockwise loop has holonomy exp(-kappa_x J area). Reversal changes the sign, concatenation adds integrals, and inserting any valid intermediate chart introduces mutually canceling endpoint frame factors. This is base-path transport. Same-point agent frame comparisons and arbitrary graph cycles do not become such paths without separately declared endpoint contexts and base curves.

Retain the existing reference identity cross-channel map only as an explicitly chosen vector-map example. Its local representation is Phi=G_m G_b^T, and differentiation gives

    D Phi = dPhi + A_m Phi - Phi A_b
          = G_m [(a^m-a^b)J] G_b^T.

For unequal channel connections it is generally nonparallel. Its curvature square is G_m[(kappa_m-kappa_b)J]G_b^T. This result concerns the chosen identity reference map; it neither identifies that map with the statistical belief-given-model evaluator nor proves a no-go result for every possible nonlinear cross-channel map. Equality of channel connections restores parallelness for this particular map.

## General full-row-rank parent criterion

Work on one open region with constant active source and target ranks. Let F(c) be a smooth m by n matrix with rank m, and let A_child be a declared source connection. Ask whether any GL(m) target connection can make F parallel. Define the matrix-valued one-form

    B = F A_child - dF.

The desired equation is A_parent F=B. Choose any smooth right inverse R of F, so FR=I_m. A solution exists if and only if

    B(I_n-RF)=0.

If a solution exists, it is unique and equals A_parent=BR. Necessity follows by multiplying A_parent F=B on the right by I_n-RF. For sufficiency, the condition gives BRF=B. Uniqueness follows by multiplying (A_parent-A_parent')F=0 by R. Thus the existence criterion is intrinsic even though a chosen candidate away from compatibility can depend on the auxiliary splitting. In the existing orthogonal coordinates choose

    R=F^T(FF^T)^(-1).

Full row rank makes FF^T positive definite. The code solves this system without a pseudoinverse cutoff or numerical rank truncation. It returns BR as a candidate, never as an admitted parent connection merely because it was computed. The kernel obstruction is B-BRF; the actual defect of that candidate is its negative.

The criterion is equivalently preservation of ker F by the source connection. Indeed, if v is a section of ker F, differentiation of Fv=0 gives F dv=-(dF)v, hence F nabla_child v=Bv. Thus precisely the directions discarded by F must form a parallel subbundle. A smooth surjective statistical coarse map need not satisfy that additional geometric condition.

Even if the kernel obstruction vanishes, the unique GL(m) candidate need not lie in the allowed target connection class. In the represented Euclidean metric, metric compatibility requires BR+(BR)^T=0. A product of standard SO(2) copies further requires each adjacent two-dimensional block to be a scalar multiple of J and all off-block entries to vanish. Projection to this block Lie algebra is a diagnostic, not permission to replace an incompatible target connection. The implementation returns both the projected matrix and its full defect. This block class permits separate coefficients per copy and is broader than the project's one common reference connection per channel. Agreement with the declared common connection is an additional check made by the family caller.

For an explicit separation of the two obstructions, let F=s(c)I_2 with s>0 and A_child=aJ. It is invertible, so its kernel obstruction is zero and its unique GL(2) parent connection is aJ-d(log s)I_2. Unless ds=0 this connection fails metric compatibility and is not an SO(2) connection. This is an isolated diagnostic example; it does not change the normalized availability-parent map.

## Normalized weighted parents have an unavoidable obstruction

Consider one channel of one parent with positive weights lambda_i summing to one on a constant-membership region, reference map L=[lambda_1 I_2 ... lambda_r I_2], and source block connections a_i J. The block equations for a putative parent connection are

    lambda_i A_parent = lambda_i a_i J - d(lambda_i) I_2.

For every positive lambda_i they require

    A_parent = a_i J - d(log lambda_i) I_2.

The matrices I_2 and J are linearly independent. Therefore all contributing a_i must agree and all d(log lambda_i) must coincide. Writing that common one-form as t, normalization implies 0=sum_i d(lambda_i)=t sum_i lambda_i=t. Hence all d(lambda_i)=0. This proves that varying normalized weights obstruct even a general GL(2) parent connection for these blockwise SO(2) sources. They are not repaired by allowing a radial term in the target or by projecting a pseudoinverse candidate. The statement is local: vanishing derivatives at an isolated point are not proof of a parallel map on a neighborhood.

For the implemented common reference connection a_i=a, the candidate can be written explicitly as

    A_candidate = aJ - [sum_i lambda_i d(lambda_i) / sum_i lambda_i^2] I_2.

Its radial term cancels only the derivative component along the weight vector. The remaining kernel obstruction vanishes exactly when d(lambda) is proportional to lambda; normalization then forces d(lambda)=0. A fixed normalized weighted mean with constant coefficients is compatible, including a sole-child parent with coefficient one on an open region. The current smooth bump-normalized parents generally have nonzero derivatives, so their declared common parent connection is retained with a measured defect.

For the full two-channel map F=G_parent L G_child^T with L=W tensor I_4, the same common-channel choices yield

    D F = G_parent (dL) G_child^T.

The old flat case is recovered by kappa_b=kappa_m=0, but the same weight defect survives at nonzero curvature. The new connections add path dependence without silently altering the statistical parent recipe, the full laws, or the existing evidence identities.

## Curvature, path and staged defects

Let E=DF. The induced Hom-bundle covariant derivative of the one-form E gives

    D E = dE + A_parent wedge E + E wedge A_child
        = K_parent F - F K_child.

In components, the left side is partial_x E_y-partial_y E_x+A_parent,x E_y-A_parent,y E_x+E_x A_child,y-E_y A_child,x. This follows by expanding E and canceling the mixed first derivatives. Consequently a parallel F must intertwine curvature. The converse does not hold: with the implemented common per-channel curvature and scalar weights, K_parent F-F K_child=0 identically even while dW and DF are nonzero. A passing curvature square alone cannot admit a compatible parent connection.

For two stages F_1 and F_2 with the chosen intermediate connection, the ordinary product rule gives

    D(F_2 F_1) = (D F_2) F_1 + F_2 (D F_1).

The curvature-square defects obey the corresponding identity

    K_2 F_2 F_1 - F_2 F_1 K_0
      = (K_2 F_2-F_2 K_1)F_1 + F_2(K_1 F_1-F_1 K_0).

For a path admitted in one fixed-rank domain, define its transport-square defect as

    E_gamma = F_end T_child - T_parent F_start.

Differentiating T_parent(1,t) F(gamma(t)) T_child(t,0) and integrating yields

    E_gamma = integral T_parent(1,t) [DF(gamma_dot)] T_child(t,0) dt.

This formula is an identity, not a claim that the implemented quadrature evaluates it. For the common Abelian family it simplifies exactly to G_parent,end (L_end-L_start) T_bar,child (G_child,start)^T. Thus changing weights produces a finite path defect even when both curvature squares vanish. For two stages the exact endpoint composition is

    E_gamma,20 = F_2,end E_gamma,10 + E_gamma,21 F_1,start.

Neither differential nor path defect is asserted to be a scalar energy penalty. Selecting a connection-dependent VFE term or an inference equation remains a separate modeling decision.

## Domains, occupancy and executable admission

Agent domains and parent domains keep their earlier meanings. Fixed-child parent domains are intersections; availability-parent domains are unions equipped with the explicitly chosen normalized-window recipe. An absent parent has no asserted connection-compatible map. Its packed zero storage row is not a full-row-rank matrix and is never submitted to the criterion. For a supported matrix, select both the active target coordinate rows and active source coordinate columns before solving. The resulting target Gram matrix is positive definite because the nonzero normalized block rows have disjoint child supports.

On any constant-active-set open stratum the fine law fiber is a fixed-rank vector bundle and all differential criteria above apply directly. A child's bump and all its derivatives vanish at its boundary, so an availability parent with another positive child has a smooth ambient-coordinate formula there. This does not identify the changing-rank fine statistical support with a single smooth vector bundle. A parent whose own total occupancy vanishes is absent; its normalized row and conditional attention remain undefined. Numeric zero/NaN storage conventions and their masks retain their earlier scope.

The declared common vector bundle exists on all U, so its connection can be transported along any polygon inside U. Attaching an individual agent law to such a path additionally requires the agent's domain along the path. In particular, transported initial laws must not be silently compared as though they were the actual endpoint section or the endpoint's changed support. The final availability parent has fixed rank on all U and can be transported across intermediate-parent and child occupancy boundaries. Its endpoint law will generally differ from transport of its starting law because a section can have nonzero covariant vertical variation.

The executable split is therefore: direct algebra on constant-active supports; valid chart changes along a declared path; parent transport over its own domain; and explicit masks where a fine or intermediate statistical object ceases to exist. Auxiliary ambient-coordinate transport is labeled as such and does not manufacture missing agent laws. No cross-context law on random sections is introduced.

## Implementation contract and source relationship

The bounded implementation lives in `src/multiagent_elbo/experiments/neighborhood/connections.py`. `connection_geometry` returns the existing frames, the two declared nonflat connections and curvature coefficients. `segment_transport` and `path_transport` evaluate the analytic formulas. `parent_compatibility` accepts support-restricted full-row-rank matrices and returns `candidate_connection`, `kernel_obstruction`, `metric_obstruction`, `so2_connection`, and the full `so2_obstruction=DF` for the projected candidate. The family caller retains the separately declared parent connection and its defect rather than substituting the candidate.

The geometric authority and notation are [Theory/SPEC.md](../../Theory/SPEC.md), especially its common principal bundle, two chosen connections, base-path transport and cross-map distinctions. The current Research manuscript's `manuscripts/gauge_vfe_rg/02_geometry.tex`, section "Chosen connections, parallel transport, and covariant defects," states the conventions reproduced here and cites Kobayashi and Nomizu (1963) and Nakahara (2003) for the standard connection laws. The parent criterion, explicit normalized-weight obstruction, symmetric-gauge example and endpoint calculations are the present direct derivations. The construction extends [the cover derivation](2026-09-08-neighborhood-cover.md) and [the local-tree derivation](2026-09-08-local-tree-cover.md). PIFB2 provides program-level intuition; it is not invoked as a proof or as an implementation specification for these formulas.

The implementation milestone does not add interacting inference, a connection optimized by an action, adaptive memberships, changed base maps, non-Abelian transport, topologically nontrivial bundles, or a continuum RG limit. Numerical tests can check the executable specialization and its signs; the algebra above supplies the stated finite construction rather than a grid-based proof claim.
