<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Primary-source context

The bounded lookup on September 9, 2026 consulted David Pollard's [A note on insufficiency and the preservation of Fisher information](https://arxiv.org/abs/1107.3797), version 2, and its [primary PDF](https://arxiv.org/pdf/1107.3797). The abstract and pages 0 through 5 were read, including Theorem 7 and its qualifications; the proof section was not yet read. The paper distinguishes local preservation of Fisher information from statistical sufficiency and describes the score after applying a fixed statistic through conditional expectation. Here the finite identities are proved directly. No general DQM theorem or sufficiency conclusion is imported.

The earlier run's bounded reading of Rebeschini and van Handel's [Comparison Theorems for Gibbs Measures](https://arxiv.org/abs/1308.4117) remains context for comparison methods. The present infinite-volume derivative argument uses the repository's explicitly counted whole-block coupling, localized finite covariance differentiation and uniform summable limits; it does not cite a comparison theorem in place of checking its hypotheses.

No novelty claim is made. The frozen contract, current SPEC, preceding admitted UC/UP derivations and current source signatures determine the mathematical scope. Numerical checks establish finite examples only.
