"""Accept current root-read proof interfaces and the single retained finite packet."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[4];RUN=Path(__file__).resolve().parent.parent
VERIFY=ROOT/'docs/verification/2026-09-09-fisher-response'
PROPOSALS=('parameter-response-claims.json','finite-score-claims.json','interaction-fisher-claims.json','implementation-claims.json')

def sha(p: Path) -> str:
 return hashlib.sha256(p.read_bytes()).hexdigest()

def main() -> None:
 destination=RUN/'evidence/native-intake.json';assert not destination.exists()
 c=json.loads((RUN/'problem-contract.json').read_text());meta={k:c[k] for k in ('schema_version','contract_id','target_digest')}
 coverage=json.loads((RUN/'agents/coverage-proposals.json').read_text())
 proposals=[json.loads((RUN/'agents'/p).read_text()) for p in PROPOSALS]
 ids=[x['id'] for p in proposals for x in p['claims']]+['target']
 assert len(ids)==len(set(ids))==52 and set(ids)=={x['claim_id'] for x in coverage['claims']}
 assert not coverage['pending']
 assert {x['id'] for x in coverage['resolved_findings']}=={'FINITE-C1-JOINT','ROW-SUPPORT'}
 assert all(sha(ROOT/p)==h for p,h in coverage['bindings'].items())
 dep={x['id']:x['dependencies'] for p in proposals for x in p['claims']};dep['target']=ids[:-1]
 assert all(set(x['dependencies'])==set(dep[x['claim_id']]) for x in coverage['claims'])
 commands=list(VERIFY.glob('*.command.json'));results=list(VERIFY.glob('*.result.json'));xmls=list(VERIFY.glob('*.xml'))
 assert len(commands)==len(results)==len(xmls)==1
 command=json.loads(commands[0].read_text());result=json.loads(results[0].read_text())
 assert result['returncode']==0 and all(result[k] for k in ('source_unchanged','driver_unchanged','contract_unchanged'))
 assert sha(commands[0])==result['command_receipt_sha256'] and sha(xmls[0])==result['junit_sha256']
 assert sha(xmls[0].with_suffix('.log'))==result['log_sha256']
 assert all(sha(ROOT/p)==h for p,h in command['source_sha256'].items())
 assert sha(VERIFY/'run_fisher_checks.py')==command['driver_sha256'] and sha(RUN/'problem-contract.json')==command['contract_sha256']
 assert hashlib.sha256(json.dumps(command['command'],sort_keys=True).encode()).hexdigest()==command['command_sha256']
 assert hashlib.sha256(json.dumps(command['config'],sort_keys=True).encode()).hexdigest()==command['config_sha256']
 assert command['config']['nodes']==['tests/rg_v2/test_spatial_fisher.py']
 assert command['config']['maximum_enumerated_free_edges']==6
 cases=ET.parse(xmls[0]).getroot().findall('.//testcase');case_ids=[x.get('classname')+'::'+x.get('name') for x in cases]
 assert len(case_ids)==len(set(case_ids))==35 and not any(x.find(k) is not None for x in cases for k in ('failure','error','skipped'))
 assert sha(RUN/'agents/initial-independent-proof-check.md')=='7bda93b3cf7f34b2795c05c314bac4071849ad842b40583ef4fd9fabc52c4fad'
 assert sha(RUN/'agents/initial-proof-check-proposals.json')=='a5225c3e23d7082ef989f39b3154c31fb7b70dd5a739affb297c9b522f1efa11'
 context=json.loads((RUN/'evidence/source-record.json').read_text())
 assert all(sha(ROOT/p)==h for p,h in context['existing_inputs_sha256'].items())
 read=set(coverage['bindings'])|set(command['source_sha256'])|set(context['existing_inputs_sha256'])
 for p in (RUN/'agents').iterdir():
  if p.is_file() and not p.name.startswith('next-'):read.add(p.relative_to(ROOT).as_posix())
 for rel in ('evidence/source-context.md','evidence/source-record.json','evidence/root-execution-preflight.json','evidence/assemble_native_record.py','evidence/run_structural_checks.py','evidence/accept_native_evidence.py'):
  read.add((RUN/rel).relative_to(ROOT).as_posix())
 read.add('docs/superpowers/plans/2026-09-09-fisher-response-rg.md')
 read.add('docs/verification/2026-09-09-fisher-response/deliver_to_desktop.py')
 data={**meta,'timestamp_utc':datetime.now(timezone.utc).isoformat(),'accepted_current_scoped_evidence':True,
  'read_artifact_sha256':{p:sha(ROOT/p) for p in sorted(read)},
  'read_scope':'Root read complete current proof/source/test/driver/coverage artifacts and the cited reused code seams; dependency hashing does not claim a new full-module audit of every reused dependency.',
  'root_assessment':'Actual localized covariance limits and FTC, counted derivative tails and complete shell norm, marginal-score orthogonality and actual density limit, finite normalized score/posterior algebra, current source recurrence and raw packet support the frozen target under its stated premises. The two explicit finite-hypothesis omissions were repaired and read back before acceptance.',
  'mathematical_basis':'Direct derivations, including a separately persisted initial conditional-covariance amplitude reconstruction; no numerical promotion to infinite quantifiers.',
  'numeric_basis':'One retained 35-case packet; zero failures/errors/skips; suite0.616 seconds and runner1.3338581999996677 seconds. Current source, driver, contract, configuration and raw receipts match; no rerun.',
  'algorithm_interpretation':'SFI01-SFI05 are conditional finite source-to-recurrence identities with producer-valid inputs and completed admitted exact operations; SFN01 is the separate execution observation.',
  'limits':['Full RG remains active; only the frozen first-order response contract closes.','Next C3/geometry discovery note is excluded from current theorem evidence.','Shared model family and filesystem limit independence; the exact initial pre-access snapshots are preserved.','No metric inverse, higher Fisher curvature, critical/continuum theory or open-neighborhood RG theorem.','Python3.12 tiny-source execution does not change the project Python>=3.14 requirement.'],
  'user_excluded_not_run':['tamper, corruption and forgery checks']}
 destination.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'accepted_read_artifacts':len(read),'coverage_claims':len(ids),'distinct_tests':len(case_ids),'intake_sha256':sha(destination)}))
if __name__=='__main__':main()
