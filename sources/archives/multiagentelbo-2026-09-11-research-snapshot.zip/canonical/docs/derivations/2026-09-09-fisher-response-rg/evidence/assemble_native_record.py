"""Assemble current response/density proofs and one retained exact spatial Fisher packet."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[4];RUN=Path(__file__).resolve().parent.parent
VERIFY=ROOT/'docs/verification/2026-09-09-fisher-response'

def sha(p: Path) -> str:
 return hashlib.sha256(p.read_bytes()).hexdigest()

def dump(name: str,data: object) -> None:
 (RUN/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

def main() -> None:
 assert not (RUN/'evidence/native-adjudication.json').exists()
 contract=json.loads((RUN/'problem-contract.json').read_text(encoding='utf-8'));meta={k:contract[k] for k in ('schema_version','contract_id','target_digest')}
 intake=json.loads((RUN/'evidence/native-intake.json').read_text(encoding='utf-8'));assert intake['accepted_current_scoped_evidence']
 assert all(sha(ROOT/p)==h for p,h in intake['read_artifact_sha256'].items())
 commands=list(VERIFY.glob('*.command.json'));results=list(VERIFY.glob('*.result.json'));xmls=list(VERIFY.glob('*.xml'))
 assert len(commands)==len(results)==len(xmls)==1
 command=json.loads(commands[0].read_text());result=json.loads(results[0].read_text())
 assert result['returncode']==0 and all(result[k] for k in ('source_unchanged','driver_unchanged','contract_unchanged'))
 assert sha(commands[0])==result['command_receipt_sha256'] and sha(xmls[0])==result['junit_sha256']
 assert sha(VERIFY/'run_fisher_checks.py')==command['driver_sha256'] and sha(RUN/'problem-contract.json')==command['contract_sha256']
 assert all(sha(ROOT/p)==h for p,h in command['source_sha256'].items())
 assert sha(xmls[0].with_suffix('.log'))==result['log_sha256']
 tree=ET.parse(xmls[0]).getroot();cases=tree.findall('.//testcase');ids=[x.attrib['classname']+'::'+x.attrib['name'] for x in cases]
 assert len(ids)==len(set(ids))==35 and not any(x.find(t) is not None for x in cases for t in ('failure','error','skipped'))
 raw={p.relative_to(ROOT).as_posix():sha(p) for p in VERIFY.iterdir() if p.is_file() and not p.name.startswith(('deliver_','delivery'))}
 science={**meta,'source_sha256':command['source_sha256'],'raw_artifact_sha256':raw,'execution_history':[dict(path=results[0].relative_to(ROOT).as_posix(),sha256=sha(results[0]),**result)],
  'latest_cases':dict(distinct=35,passed=35,failed=0,errors=0,skipped=0,execution_total=35),'junit_cases':ids,
  'junit_packet':dict(path=xmls[0].relative_to(ROOT).as_posix(),sha256=sha(xmls[0]),suites=[x.attrib for x in tree.findall('.//testsuite')]),
  'runtime':command['runtime'],'config':command['config'],'user_excluded':['tamper, corruption and forgery checks'],
  'unrun':['spatial laws above six free edges','previous producers/tests','held S1-S3','broad suite','GPU science'],
  'scope':'One finite source/test packet; mathematical conclusions require the direct derivations.'}
 dump('evidence/scientific-record.json',science)
 for path in [xmls[0],commands[0],results[0]]:(RUN/'evidence'/path.name).write_bytes(path.read_bytes())
 claims=[];evidence=[];edges=[];attacks=[]
 def ev(eid: str,kind: str,path: str,statement: str,conditions: list[str]) -> str:
  evidence.append(dict(id=eid,kind=kind,supports=True,scope=statement,side_conditions=conditions,artifact_path=path,artifact_sha256=sha(RUN/path)));return eid
 def add(cid: str,statement: str,scope: str,kind: str,conditions: list[str],falsifier: str,eids: list[str],deps: list[str]) -> None:
  claims.append(dict(id=cid,statement=statement,quantifiers=scope,kind=kind,falsifier=falsifier,target_digest=meta['target_digest'],state='EVIDENCE_VERIFIED',assumption_ids=[],explicit_assumptions=conditions,evidence_ids=eids,bridge_premise_ids=[]))
  edges.extend(dict(**{'from':cid,'to':dep}) for dep in deps)
  attacks.append(dict(id='attack-'+cid,claim_ids=[cid],attack=falsifier,response='The individual claim entry in the current bound coverage record reconstructs this falsifier against its proof, source and recorded finite scope.',disposition='REJECTED',artifact_path='agents/native-closure-coverage.md',artifact_sha256=sha(RUN/'agents/native-closure-coverage.md')))
 routes=[('parameter-response-claims.json','parameter-response-construction.md'),('finite-score-claims.json','finite-score-posterior.md'),('interaction-fisher-claims.json','interaction-fisher-density.md'),('implementation-claims.json','spatial-fisher-implementation.md')]
 for proposal,proof in routes:
  author=json.loads((RUN/'agents'/proposal).read_text(encoding='utf-8'))
  for item in author['claims']:
   cid=item['id'];conditions=list(item.get('assumptions',[]));scope=item.get('quantifiers','For the stated admitted finite inputs.');deps=list(item.get('dependencies',[]))
   numeric=item['kind']=='NUMERICAL_OBSERVATION'
   algorithm=proposal=='implementation-claims.json' and not numeric
   if numeric:
    kind='NUMERICAL_OBSERVATION';eids=[ev('execution-'+cid,'NUMERICAL','evidence/scientific-record.json',item['statement'],conditions),ev('junit-'+cid,'NUMERICAL','evidence/'+xmls[0].name,item['statement'],['Raw current 35-case JUnit, not a new execution.'])]
   else:
    kind='MATHEMATICAL'
    if algorithm:
     conditions.append('Conditional finite algorithm identity derived from the frozen source, admitted producer input, completed exact arithmetic and adapter input/output guards; old generic internals are not guarded per operation, and tests do not establish universal runtime behavior.')
    eids=[ev('proof-'+cid,'DERIVATION','agents/'+proof,item['statement'],[item.get('derivation',item.get('proof_section','')),*conditions]),ev('check-'+cid,'DERIVATION','agents/independent-proof-check.md',item['statement'],['Exact initial pre-access calculations and later mature author/root/source comparison; shared model family and filesystem disclosed.'])]
    if algorithm:eids.append(ev('execution-'+cid,'NUMERICAL','evidence/scientific-record.json',item['statement'],['Finite test comparisons supplement the source derivation.']))
   add(cid,item['statement'],scope,kind,conditions,item['falsifier'],eids,list(dict.fromkeys(deps)))
 target=contract['target'];add('target',target['statement'],target['quantifiers'],'MATHEMATICAL',[],target['falsification_criterion'],[ev('target-proof','DERIVATION','construction-or-strongest-theorem.md',target['statement'],['Only this frozen first-order response and actual marginal Fisher-density contract; the full RG goal remains active.'])],[c['id'] for c in claims])
 ids=[c['id'] for c in claims];assert len(ids)==len(set(ids)) and all(e['from'] in ids and e['to'] in ids for e in edges)
 dump('claim-ledger.json',{**meta,'assumptions':[],'evidence':evidence,'claims':claims});dump('dependency-dag.json',{**meta,'edges':edges})
 recon=dict(claim_ids=ids,method='Exact persisted initial pre-access reconstruction, then mature per-claim author/root/source and retained-output comparison.',result='PASS',conclusion='The frozen first-order response, complete derivative norm and actual marginal Fisher density have direct derivations; finite identities and one current tiny packet retain their distinct scope.',artifact_path='agents/native-closure-coverage.md',artifact_sha256=sha(RUN/'agents/native-closure-coverage.md'))
 dump('adversarial-report.json',{**meta,'attacks':attacks,'independent_reconstruction':recon,'oracle_erasure':{**recon,'method':'Remove favorable expectations and numerical outcomes; reconstruct finite covariance differentiation, weighted forcing, summable derivative limits/FTC, complete shell interpolation, actual marginal score-chain and bulk/boundary limit, finite score/evidence algebra.'}})
 families=[('localized-response',[i for i in ids if i.startswith('FR')],'Localized weighted forcing, complete covariance source sums, actual C1 limits and counted derivative continuity.'),('interaction-and-marginal-density',[i for i in ids if i.startswith('GX')],'Complete derivative shells, norm FTC, actual conditional-score orthogonality, bulk/boundary density and integer area scaling.'),('finite-information',[i for i in ids if i.startswith('FX')],'Normalized scores, conditional expectations, mixed loss, local KL, evidence, channel support and rank formulas.'),('spatial-score-adapter',[i for i in ids if i.startswith(('SFI','SFN'))],'Current full finite source factors, existing exact reverse/Gram/loss machinery, posterior normalization and one tiny packet.')]
 dump('approach-registry.json',{**meta,'mechanism_families':[dict(family_id=fid,core_mechanism=mechanism,target_obligation_ids=cids,representation='Full normalized finite or constrained infinite spatial laws, fixed parameter-independent paths, original natural parameters.',invariant_or_obstruction='Complete source factors, fixed support/reference, actual parameter derivatives and positive conditional normalization.',obligations=['Retain the cited finite, compact, boundary, coordinate and exact arithmetic hypotheses.'],bridge='Direct derivatives and normalized conditional identities followed only by proved uniform limits.',failure_test='A counted derivative, source or current evidence discrepancy, or an admitted mathematical counterexample.',verified_results=cids,open_gaps=[],novelty_fingerprint='Direct scoped construction with no novelty assertion.',disposition='Established at the frozen first-order response premises.') for fid,cids,mechanism in families]})
 dump('release.json',{**meta,'checkpoint':'Current response/density proofs and finite evidence assembled.','target_claim':'target','terminal_status':None,'certificate_claim':'target','strongest_result':'Actual compact-uniform C1 full-law response and complete interaction derivatives, an actual continuous marginal Fisher density with quantified depth decay and area-scaled integer composition, and source-faithful finite scores/posteriors.','unresolved_obligations':[],'limitations':['Full RG remains active; higher smoothness, identifiable Fisher geometry, critical/continuum and open-neighborhood RG obligations remain open.','Only 35 tiny finite cases, no spatial law beyond six free edges executed.','Fixed support/reference, every touching plaquette, parameter-independent paths and original natural coordinates are explicit.','No inverse or curvature-limit claim follows from a positive-semidefinite density tending to zero.','Python3.12 isolated source validation does not supersede the package Python>=3.14 declaration.']})
 dump('evidence/native-adjudication.json',{**meta,'method':'Root reads and accepts current direct proofs and finite evidence after separate reconstruction; no vote or tool-return proof.',
  'totals':dict(claims=len(claims),mathematical=sum(c['kind']=='MATHEMATICAL' for c in claims),numerical=sum(c['kind']=='NUMERICAL_OBSERVATION' for c in claims)),
  'algorithm_claim_interpretation':'Finite algorithm identities from source correspondence; tiny execution remains separate evidence.',
  'claims':{c['id']:dict(state=c['state'],kind=c['kind'],evidence_ids=c['evidence_ids']) for c in claims}})
 print(json.dumps(dict(claims=len(claims),evidence=len(evidence),edges=len(edges),attacks=len(attacks))))
if __name__=='__main__':main()
