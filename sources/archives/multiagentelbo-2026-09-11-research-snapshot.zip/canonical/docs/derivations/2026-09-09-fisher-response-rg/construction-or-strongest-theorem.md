<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Constructed parameter-response and Fisher-density theorem

The frozen target concerns the unchanged positive spatial Z2 gauge-matter law in natural coordinates (h,J), strictly inside 0<h<infinity and 0<J<atanh(1/12). For every compact rectangle K choose an enlarged Khat inside that domain. All quantities below use Khat's upper h_*,J_*, c_*=tanh J_*, and a fixed 0<tau<log[1/(12c_*)]. Define

    q=12c_*exp(tau)<1, rho=tanh(h_*+2J_*)<1, d=1-rho,
    W=1+8exp(-tau)/(1-exp(-tau))^2,
    D=8c_*exp(tau)W/(1-q),
    A_B=rho^(B-1)(B+D B^2), H_B=20A_B^2/d^2.

The [parameter-response derivation](agents/parameter-response-construction.md) proves actual C1 coarse conditional rows for every integer B>=1 and every fixed signed-or-absent path pattern. Each finite response differentiates all free fields and all touching plaquettes, including crossing factors. A single local perturbation has an explicitly counted weighted Hamming forcing; stationary comparison converts it into a covariance tail. Finite joint-cylinder convergence, uniform summability of those tails and FTC justify the infinite-volume derivatives at every parameter. A separate near/far source split proves spatial continuity of the actual derivatives with its B^4 and polynomial-radius factors. The finite-oracle convergence holds for whole-block inventories with the declared anchor margin and arbitrary fixed fine exteriors.

For the [complete canonical interaction](agents/interaction-fisher-density.md), fix the same vacuum, lexicographic order and normalized four-state counting as the preceding full-law theorem. Every exact shell is retained. Combining the derivative amplitude with the actual spatial derivative tail and counting every translate gives, at lambda=tau/16,

    ||partial_u Phi^(B)||_lambda
      <=G0 B^2rho^B+Q B^3rho^(B/2) S(exp(-tau/8)),
    S(w)=w(9+55w+31w^2+w^3)/(1-w)^5, u in {h,J}.

The explicitly defined G0,Q in FD02-FD04 depend only on Khat. Uniform derivative tails and the interaction-valued FTC prove a C1 map into this common Banach space. Both its value and first-derivative norm tend to zero as B tends to infinity, uniformly on K. This is a derivative theorem for the unchanged two-parameter exact orbit, not a Frechet-linearized RG operator on an open set of arbitrary interactions.

For every nonempty finite marginal, the true score factors into centered conditional-cell increments. Their cross expectations vanish by conditioning on the later past. Each row Fisher matrix is bounded by H_B Id, so the actual marginal Fisher per cell has the same bound. The actual square-marginal limit is proved, rather than assumed:

    mathcal I_B=lim_(L->infinity)I(mu_(B,Lambda_L))/L^2
              =E_muB J_full-lexicographic-past,
    0<=mathcal I_B<=H_B Id,
    ||I(mu_(B,Lambda_L))/L^2-mathcal I_B||
       <=delta_B(R)+8H_B R/L, L>=2R.

Here delta_B(R) is the explicit actual-score spatial modulus from FD07 and tends to zero compact-uniformly. The boundary has at most 4RL cells. The limit is continuous in the original parameters and H_B tends to zero with B. It never replaces marginal scores with free-boundary Hamiltonian scores or differentiates an O(boundary) log-density error.

Exact integer path composition uses the same original parameters and a source square of side aL. Thus

    mathcal I_(aB)<=a^2 mathcal I_B,
    mathcal I_(aB)/(aB)^2<=mathcal I_B/B^2.

The normalized finite loss converges to the corresponding positive-semidefinite difference. The volume factor belongs to this theorem; a per-coarse-cell contraction with it removed is not supplied.

The [finite score and posterior derivation](agents/finite-score-posterior.md) separately proves exact full-law score projection, complete mixed Fisher loss, its direction-wise equality condition, composition, finite local quadratic KL, evidence-centered posterior scores and the normalized VFE chain identity. Fixed-support parameter-dependent channels have an additional channel score. A finite C2 nonlinear effective Hamiltonian has I_ij=partial_ij log Z+E[partial_ij H]; the second term cannot silently be dropped.

The [source correspondence](agents/spatial-fisher-implementation.md) proves the conditional finite algorithm identities for spatial_fisher.py using existing exact law, reverse, channel, Gram and conditional-loss primitives. Its source entry point retains every finite factor, both parameter charts, complete generated marginals and selected positive binary evidence. Its producer-valid records and exact input/output guard boundary are explicit. The [raw execution](evidence/scientific-record.json) records one 35-case packet, zero failures/errors/skips, at most six free edges, isolated Anaconda Python 3.12.7. Those finite observations do not prove the infinite-volume statements; the derivations above do.

The [initial reconstruction](agents/initial-independent-proof-check.md) was persisted before mature author/root/source access. Its small-response route uses localized covariance plus conditional-source amplitudes, giving different conservative constants from the author's global parameter-coupling route. The [mature check](agents/independent-proof-check.md) and [per-claim coverage](agents/native-closure-coverage.md) reconstruct the final interfaces and retain the repaired finite C1 and channel-support hypotheses. Shared model family and filesystem remain limitations; agreement and structural validation do not establish a theorem.

Gauge holonomy, Fisher curvature and base curvature retain distinct roles. The previous normalized gauge/base/latent-curvature constructions remain intact. This result supplies a first-order information tensor density; it does not provide its inverse, a regular quotient, higher parameter derivatives, Fisher curvature, critical universality, continuum Yang-Mills theory or a complete RG operator on an open interaction neighborhood. The full RG goal remains active.
