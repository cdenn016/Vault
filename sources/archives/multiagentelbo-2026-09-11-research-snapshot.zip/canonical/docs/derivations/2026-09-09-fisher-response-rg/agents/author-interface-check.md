<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Author check of the FR-to-FD/FS interface

Date: 2026-09-09. **DEFINITION.** This is an author-interface check, not independent reconstruction or a ledger closure. The checker authored FR and earlier UC material and received the root's route before this pass. Only this supplementary document is written. No tests, science, implementation or numerical producer is executed; the frozen FR files are unchanged. This pass read both new root proof files in full, checked the named constants and normalization algebra directly, and read the previous UP02-UP03 definitions to distinguish the canonical vacuum shell convention from the full-past conditional law used for Fisher density.

The checked root revisions are interaction-fisher-density.md SHA256 0f1e9f9966d836d14f3eeb037be45a1ec21f4ccfb01cf4061c2501488e40b17d and finite-score-posterior.md SHA256 efaee6ef4eada6348e1a82c846e486c67d93dec90ce030172ea1564b847c9409. The unchanged author dependencies are parameter-response-construction.md SHA256 e9ec9be21ac31253b9f70452c263ad719f2f51050ac4786bbed1a364e87c3a46 and parameter-response-claims.json SHA256 0a5fe8c18deb20565b387b9802aec035ea00e499106a85295cbb7c289fab48c0. This record applies to those bytes. Any later FS wording correction requires a short readback recorded separately below before rebinding this note.

**ESTABLISHED BY THIS INTERFACE CALCULATION.** The requested FD constants, series, half-factor, actual-marginal expectation and volume factor agree with FR. The posterior evidence subtraction is correct. Two explicit hypothesis/support wording corrections are requested in FS06 and FS08 below; neither requires changing the displayed identities or the FR interface.

## FD02: K0 and the compact constants

The roles agree: FR13's D_h,D_J bound actual free-path parity-mean derivative differences, while FR17's H_h,H_J bound actual cell log-odds derivative differences. In FD01, A_B<=aB^2rho^(B-1)<=aB^2 follows from B<=B^2 and a=1+D.

For R>=2 and L=floor(R/2)-1, L+1>=R/2-1/2 and [(L+1)-Lz]<=L+1<=R+1. Therefore the exact FR tail satisfies T(L)<=8exp(tau/2)(R+1)exp(-tau R/2)/(1-z)^2. FR13's larger plaquette tail coefficient is 16exp(tau)B^2/(1-q), giving the 128exp(3tau/2)/[(1-q)(1-z)^2] contribution to M. Its larger near-source coefficient is 60C. Replacing B^2 by B^4 and the remaining linear radius factor by (R+1)^3 only enlarges the bound. Thus each D_u is bounded by M B^4(R+1)^3exp(-tau R/2).

FR17's larger product coefficient is 8A_B V_B/d^2. Substituting A_B<=aB^2 and V_B<=2CB^2(R+1)exp(-tau R/2) yields 16aC/d^2 in K0. For R=0, the last term 16a exp(tau/2)/d dominates the amplitude cap after multiplication by B^4. For R=1, its exp(tau/2) cancels the exp(-tau/2) radius factor and (R+1)^3=8, again dominating 16aB^2/d. Hence FD02's K0 is valid for both coordinates and every radius. No coefficient silently depends on B or the pattern.

## FD03-FD05: shells and the derivative norm series

FD03 uses the same UP02 interaction: the exterior has the retained actual configuration on the truncated lexicographic past and the fixed vacuum (+,+) elsewhere. The target remains free when computing its row. This is covered by FR's arbitrary fixed patterns. It is distinct from the absent-future full-past conditional in FD08, and the two uses need not coincide. Successive vacuum-past truncations agree through radius r-1, producing the shifted bound K0 B^4 r^3exp[-tau(r-1)/2]. The amplitude coefficient G0=8a/(d rho) follows from 8A_B/d<=G0B^2rho^B, with rho>0 supplied by the strict compact domain.

Taking the square root of the two shell bounds gives sqrt(2G0K0) B^3rho^(B/2) r^(3/2)exp[-tau(r-1)/4]. The norm weight for diameter at most 2r is exp(tau r/8), because lambda=tau/16. The remaining exponential is exp(tau/4)exp(-tau r/8), exactly FD04's Q and w. Using r^(3/2)<=r^2 and the translate count (2r+1)^2 gives its stated series.

Direct expansion verifies its numerator. The weighted polynomial is 4r^4+4r^3+r^2. Combining the geometric derivative formulas over the denominator (1-w)^5 produces coefficients 9,55,31,1, so

\[
\sum_{r\ge1}r^2(2r+1)^2w^r
=\frac{w(9+55w+31w^2+w^3)}{(1-w)^5}.
\]

Thus FD04 retains all required B powers and spatial factors. UP03 admits any value-norm exponent less than tau/4, so the value convergence is valid in this same smaller lambda space. FD05's interaction-valued FTC has the needed uniform value and derivative tails from these bounds; finite shell supports have finite alphabets and each orbit has a finite translate contribution to the norm. This verifies the stated C1 map for the parameter family, without asserting a derivative of an RG operator on arbitrary interactions.

## FD07: the factor one-half

FR17 separately proves the log-probability derivative bound 2D_u/d+2a_uV_B/d^2 and the log-odds derivative bound H_u=4D_u/d+4a_uV_B/d^2. It is that first explicit bound which equals H_u/2. No general assertion that score differences equal half log-odds differences is needed. If the optional amplitude caps are used, the same half-cap is separately valid: the h score difference is at most 4A_B/d and the J score difference at most 8A_B/d, half the respective log-odds caps.

For the four-state row, sequentially couple its first parity and then its second parity when the first agrees. Each Bernoulli discrepancy probability is at most V_B/2, so total row TV is at most min(1,V_B). With S_B=sqrt(20)A_B/d and H_B=S_B^2, the sum of absolute probability differences is twice TV. Consequently the probability-change contribution to the conditional Fisher difference is bounded by 2H_B TV. The score-product contribution obeys ||ss^T-s's'^T||<=2S_B||s-s'|| and ||s-s'||<=0.5sqrt(H_h^2+H_J^2). FD07's L_B and delta_B therefore have the correct factors.

## FD08: actual marginal and full-past expectation

The finite revealed-past row is the actual conditional distribution under the full pushed law, by the finite-conditioning identity for a signed-or-absent pattern. The infinite full-past row has all earlier cells prescribed and the future absent. FR and UC give a uniformly convergent version on every fixed past; integrating the finite conditioning identity against past cylinders proves it is a version of the actual full-past conditional. Differentiation here holds the realized pattern fixed. FD08 does not differentiate an expectation with a parameter-dependent random past.

The ordered finite marginal score decomposition in FD06 has exactly centered increments, hence vanishing matrix cross terms. Its expectation is under the same full law as the full-past comparison. For a radius-R bulk cell, the two patterns agree on the entire radius-R anchor neighborhood. Translation covariance makes the expectation of the full-past conditional Fisher matrix independent of the cell. There are at most 4RL non-bulk cells when L>=2R; the safe operator difference bound 2H_B then gives 8H_BR/L after division by L^2. This proves the displayed error bound and the limit by first sending L to infinity at fixed R, then R to infinity.

All constants are common on the enlarged compact parameter rectangle, so these choices can be made uniformly on K. Continuity follows from the resulting uniform limit of the continuous actual finite-marginal Fisher matrices. No ergodic sample-average theorem, free-boundary surrogate, pressure Hessian or squared boundary-score estimate is being substituted for the actual marginal. FD09's decay bound then follows directly from A_B.

## FD10: the a^2 volume factor

For target anchor x in {0,...,L-1}^2, the constituent B-coarse edge anchors ax+t e_i, 0<=t<a, lie in {0,...,aL-1}^2. Thus the complete aB-target marginal is a fixed deterministic channel image of the actual B-level source marginal on that square. Fine path concatenation is exact; no outside source variable is needed. The finite Fisher inequality at the same original parameters therefore compares I_(aB,L) to I_(B,aL).

Dividing both sides by L^2 leaves a^2 multiplying the source density because the source has (aL)^2 cells. Consequently the limit is I_density(aB)<=a^2 I_density(B), and division by (aB)^2 gives the stated per-original-fine-cell inequality. The two normalized finite Fisher matrices converge separately by FD08, so their nonnegative difference also converges to a^2 I_density(B)-I_density(aB). There is no missing extra factor of two from the two oriented links: both densities were defined per four-state cell.

## FS01-FS07: complete score and posterior normalization

FS01's cosh-normalizer terms cancel exactly upon centering; its (b,c) score transformation divides the natural columns by 1-b^2 and 1-c^2. FS02-FS04 use the same complete joint and fixed channel. FS05's finite C1 positive-family KL expansion is sufficient for its second-order coefficient: the probability increment is linear plus o(||u||), the first-order mass sum vanishes exactly, and the quadratic remainder is o(||u||^2). A C2 assumption is not needed for that finite statement.

In FS06, the selected-slice score a_i(x,o) is centered under the posterior only after subtracting partial_i log z_t(o). Summing the resulting posterior derivative gives zero exactly. A stochastic latent channel retaining o preserves evidence because its rows sum to one; the posterior pushforward has the same z_t(o), so its centered score obeys FS02 and the Fisher-loss identity. With a fixed likelihood, a_i is the prior score evaluated at x, whose posterior mean is generally nonzero and is precisely the evidence derivative. A parameter-dependent likelihood needs its own log derivative before this centering, as stated. FS07 keeps the single evidence constant -log z_t(o) and the full residual conditional KL; the augmented stochastic construction preserves the x-marginal VFE before disintegration.

**CORRECTION REQUEST, FS06.** Its opening sentence should explicitly require j_t to be C1 on an open parameter set, in addition to positivity and normalization on a fixed carrier. The finite differentiation and posterior-score claims need this premise. It is part of the intended smooth-family contract but is not stated in that local theorem. Suggested replacement: “Let j_t(x,o)>0 be a C1 normalized finite generative joint on a fixed carrier, for t in an open parameter set.” No formula changes.

## FS08: channel-score support convention

The centered channel-score identity and added channel Fisher term are correct on fixed per-row positive supports. The one-state-source Bernoulli counterexample then proves the failure of ordinary source-only Fisher contraction for parameter-dependent channels.

**CORRECTION REQUEST, FS08.** “Fixed reachable support” should distinguish a reachable output alphabet from positive transition support. The expression partial_i log K_t(y|x) is undefined at zero entries. State that each row has a fixed positive support on the open parameter set; define k_i there and extend it by zero on structurally zero transitions, which carry zero joint mass. Row normalization then gives E[k_i|X]=0 without any log(0). A fixed reachable output alphabet alone does not state that convention or establish a fixed channel fiber. This clarification preserves the intended positive/fixed-support theorem and does not assert that every possible changing-support first-order identity is false.

## Scope of the result

**NOT-CLAIMED.** This check does not independently reconstruct FR, inspect or execute the implementation, establish higher parameter regularity, or certify a ledger state. No new discrepancy was found in the requested FD arithmetic or posterior normalization. The two local FS hypothesis clarifications above remain the specific requested edits at the checked source revision. Gauge, base and Fisher curvature remain distinct, and rank loss remains an obstruction to inversion under the same stated scope.

## Checked resolution of FS06 and FS08

**ESTABLISHED BY READBACK.** The root applied both requested prose corrections. The updated finite-score-posterior.md has SHA256 4716d666a9176f074e675d2ad83d1f9389577b854e8035fe624eacfe11c86ad9. Its FS06 now explicitly states that the normalized positive finite joint is C1 on an open parameter set. Its FS08 now requires fixed positive transition support in each row, defines the channel log score on those positive entries, and extends it by zero on structurally zero entries; it also explicitly distinguishes this from a fixed reachable output alphabet. The two changed sections were read back directly, and that hash was recomputed from their containing file. The previous findings remain above as the record of the earlier revision. Both requested interface corrections are resolved at the updated revision; no formula or frozen FR file changed in this pass.

No test result is certified by this author-interface readback. The prose changes required no mathematical producer or test reexecution in this lane. No further correction was identified in the scoped FD/FS interface review.
