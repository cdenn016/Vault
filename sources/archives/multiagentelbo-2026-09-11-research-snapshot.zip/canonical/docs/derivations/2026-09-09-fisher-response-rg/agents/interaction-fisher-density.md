<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Complete interaction derivatives and actual marginal Fisher density

This construction uses the explicit FR response interface in [parameter-response-construction.md](parameter-response-construction.md) and the admitted UC/UP complete-law construction. It keeps the common four-state dressed lattice, normalized counting, reference *=(+,+), translation-invariant lexicographic order and every shell of the fixed canonical interaction. A first derivative of a value bound is never used as a substitute for a bound on the represented derivative.

## FD01. Restored compact response interface

Fix a compact rectangle K strictly inside 0<h<infinity, 0<J<atanh(1/12), and an enlarged compact Khat whose interior contains K. Use the FR constants c_*,tau,q,z,C,rho,d,W, with q=12c_*exp(tau)<1, z=exp(-tau), rho=tanh(h_*+2J_*)<1 and d=1-rho. Put

    D=8c_*exp(tau)W/(1-q), a=1+D,
    A_B=rho^(B-1)[B+D B^2] <= a B^2 rho^(B-1).

The actual C1 free-path means have h derivative at most A_B and J derivative at most 2A_B, uniformly over every fixed signed-or-absent remote pattern and finite-volume approximation. Each cell row is a sequential product of two positive parity rows, with the second path conditioned on the first. Its log-score amplitudes are at most 2A_B/d and 4A_B/d. Every cell probability is at least m0=d^2/4. For two patterns agreeing through anchor radius R, their mean differences are bounded by V_B(R), derivative differences by D_h(B,R),D_J(B,R), and log-odds derivative differences by H_h(B,R),H_J(B,R), with their exact definitions in FR13-FR17. These are actual derivatives obtained from summable covariance limits and FTC.

The same statements hold for a fully specified exterior, a finite revealed past, or the entire lexicographic past with all other retained paths absent. The latter two are conditional rows of the actual full pushed law. Finite conditioning is UC11. For the full past, approximate it by finite past neighborhoods; C0 continuity is uniform, so multiplying the finite conditional-expectation identity by any past cylinder indicator and passing to the limit gives the full-past identity. Extending from cylinders to their generated sigma algebra follows by bounded monotone limits. No infinite null event is divided by.

## FD02. A single counted derivative modulus

The exact FR tails imply a useful common upper bound without suppressing their B powers. Define

    M=60C+128exp(3tau/2)/[(1-q)(1-z)^2],
    K0=4M/d+16aC/d^2+16a exp(tau/2)/d.

Then for u=h or J and every R>=0,

    H_u(B,R) <= K0 B^4(R+1)^3 exp(-tau R/2).

For R>=2 the FR split uses L=floor(R/2)-1. Here 2L+1<=R+1, R-L<=R+1, R-L>=R/2 and L+1>=R/2-1/2. The exact tail satisfies

    T(L)<=8exp(tau/2)(R+1)exp(-tau R/2)/(1-z)^2.

Substitution in FR13 bounds each D_u by M B^4(R+1)^3 exp(-tau R/2). Also A_B<=a B^2 and V_B(R)<=2C B^2(R+1)exp(-tau R/2). In FR17 the larger coefficient of A_B V_B is 8/d^2; these two estimates produce 4M/d+16aC/d^2. For R=0,1 cap the log-odds derivative difference by 16A_B/d<=16aB^2/d. The last term in K0 dominates that cap at both radii, even if tau is large. This proves the displayed bound for all radii and all B.

The larger constants are deliberate upper bounds. The exact FR tails remain available for sharper finite-radius estimates. Compact endpoints determine all constants, and none depends on B, an exterior or a finite volume.

## FD03. Complete canonical derivative shells

For the existing canonical interaction let e_(x,r)(sigma) be minus the target-state log odds against * with the actual lexicographic past inside radius r and * elsewhere. Put Phi_[A_(x,0)]=e_(x,0), Phi_[A_(x,r)]=e_(x,r)-e_(x,r-1) for r>=1. These are the full existing UP shells, not a new gauge choice. They depend on their declared finite support and are C1 by FR15. Their diameters are at most 2r, and at most (2r+1)^2 translates contain the origin.

Let G0=8a/(d rho). The derivative of any e_(x,r) in either coordinate has amplitude at most 8A_B/d<=G0 B^2 rho^B. Thus the singleton derivative has that bound. For r>=1, two exteriors in the shell difference agree through radius r-1, so FD02 and the amplitude give simultaneously

    ||partial_u Phi_[A_(x,r)]||_infinity
       <=min(2G0 B^2 rho^B, K0 B^4 r^3 exp[-tau(r-1)/2]).

Every derivative shell is retained. The factor r is the correct shifted radius from the agreement of successive past truncations.

## FD04. One common exponential norm with derivative decay

Use ||Psi||_lambda=sum_(A containing 0)exp(lambda diam A)||Psi_A||_infinity and fix lambda=tau/16. For positive U,V, min(U,V)<=sqrt(UV). Applying this to FD03, including the diameter weight and translate count, gives

    ||partial_u Phi^(B)||_lambda
       <= G0 B^2 rho^B + Q B^3 rho^(B/2) S(w) =: E'_B,
    Q=sqrt(2G0 K0)exp(tau/4), w=exp(-tau/8),
    S(w)=sum_(r>=1)r^2(2r+1)^2 w^r
        =w(9+55w+31w^2+w^3)/(1-w)^5.

Indeed the square root has spatial factor r^(3/2)exp[-tau(r-1)/4]; multiplying exp(2lambda r) leaves exp(tau/4)exp(-tau r/8), and r^(3/2)<=r^2. Expanding r^2(2r+1)^2 into 4r^4+4r^3+r^2 and differentiating the geometric series gives the displayed rational sum. It converges for 0<w<1.

Both polynomial times geometric B factors tend to zero because 0<rho<1. The bound is uniform on K, for u=h,J and every B>=1. The prior UP value norm also converges to zero in this same lambda space: its general weighted argument holds whenever lambda<tau/4. Thus the complete exact potentials and their first parameter derivatives converge to zero in one fixed Banach norm. The bounds need not be small at modest B near a compact-domain boundary.

## FD05. Actual C1 in the interaction norm

Finite shell truncations are C1 functions into the interaction space: each translation orbit has a finite alphabet, finitely many values, and its fixed translate multiplicity is finite. FD03-FD04 bound the derivative tail after radius N by

    Q B^3 rho^(B/2) sum_(r>N)r^2(2r+1)^2 w^r,

uniformly on K. The analogous UP value tail also tends uniformly to zero. For fixed B, the derivative series therefore defines a continuous interaction-valued function: finite truncations are continuous and the tails are uniform. Apply the finite-truncation FTC on coordinate segments in Khat. The norm of the omitted integral is bounded by segment length times the uniform derivative tail. Passing to the limit proves the interaction-valued FTC; continuity of the limiting derivative yields differentiability by the usual integral remainder estimate. Two coordinate segments give C1 in both natural parameters.

In fact the displayed tails are uniform over all B as well, since sup_B B^3 rho^(B/2)<infinity. This is a parameter-family C1 statement along the admitted exact orbit. It does not construct a Frechet derivative of an RG operator on an open neighborhood of arbitrary interactions, a continuous-scale beta function or a critical stability spectrum.

## FD06. Conditional-score orthogonality for actual marginals

For any nonempty finite coarse set Delta, its actual full-law marginal is C1 by FR15 and the absent-pattern construction. List the cells in lexicographic order x_1,...,x_n and factor the joint probability into the actual conditional rows given earlier cells. At fixed configuration its joint score is s_Delta=sum_k s_k, where s_k depends only on the first k cells. Each score has conditional mean zero given the first k-1 cells by differentiating that row's finite normalization.

For k<l, condition s_k s_l^T on the past of l. The earlier score is measurable there and E[s_l|past_l]=0, so its cross expectation vanishes; the transpose does as well. Hence the exact matrix chain identity is

    I(mu_(B,Delta))=sum_(x in Delta) E_muB J_(x,Delta-past),
    J_(x,pattern)=sum_(a in E) p(a|pattern)s(a|pattern)s(a|pattern)^T.

The row-score vector has norm at most S_B=sqrt(20)A_B/d. Thus 0<=J<=H_B Id with H_B=S_B^2=20A_B^2/d^2, and I(mu_(B,Delta))<=|Delta|H_B Id. These are actual marginal scores in the original h,J coordinates, not the scores of a free-boundary Gibbs surrogate.

## FD07. Spatial continuity of the conditional Fisher matrix

For patterns agreeing through radius R, the two sequential Bernoulli mean bounds give TV(p,p')<=min(1,V_B(R)): couple the first parity, then the second conditional on agreement; each step costs at most V_B/2. Define

    L_B(R)=0.5 sqrt[H_h(B,R)^2+H_J(B,R)^2],
    delta_B(R)=2H_B min(1,V_B(R))+2S_B L_B(R).

FR17 gives ||s(a)-s'(a)||<=L_B(R) for each of the four cell states; its log-probability bound is exactly half its stated log-odds upper bound. Since ||s||,||s'||<=S_B, expand

    p ss^T-p' s's'^T=(p-p')ss^T+p'(ss^T-s's'^T).

The first sum has operator norm at most 2H_B TV(p,p'). The second has norm at most 2S_B L_B(R), by ss^T-s's'^T=(s-s')s^T+s'(s-s')^T. Therefore ||J-J'||<=delta_B(R). It tends to zero for each B, uniformly on K and every pattern. These are actual score derivatives; a C0 marginal comparison alone would not supply this estimate.

## FD08. Existence and continuity of the Fisher density

Let Lambda_L={0,...,L-1}^2. Define J_fullpast at the origin using the infinite lexicographic past, holding that exterior fixed when differentiating. Its bounded row functions are measurable, and FD01 identifies its probabilities as actual full-past conditional versions. Translation covariance makes E_muB J_(x,fullpast) independent of x. For a cell x whose radius-R neighborhood lies inside Lambda_L, the finite revealed-past pattern and full-past pattern agree through R. FD07 bounds their Fisher-row difference by delta_B(R).

If L>=2R, the number of remaining boundary cells is L^2-(L-2R)^2<=4RL. Each difference there is at most 2H_B in operator norm. Applying FD06 and dividing by L^2 gives

    ||I(mu_(B,Lambda_L))/L^2-E_muB J_fullpast||
       <=delta_B(R)+8H_B R/L.

First take L to infinity at fixed R, then R to infinity. This proves the actual limit

    mathcal I_B(h,J)=lim_(L->infinity) I(mu_(B,Lambda_L))/L^2
                   =E_muB J_fullpast,
    0<=mathcal I_B<=H_B Id.

The estimate is uniform on K, so the convergence is compact-uniform. Each finite marginal Fisher matrix is continuous in h,J, by its finite positive C1 probabilities. Its uniform limit is continuous. No ergodicity, pressure Hessian, boundary-score approximation or unspecified exchange of limits is required.

## FD09. Quantified depth decay

The bound H_B=20rho^(2B-2)[B+D B^2]^2/d^2 tends to zero and is uniform on K. Consequently mathcal I_B tends to the zero matrix as B tends to infinity. More strongly the same upper bound holds for the Fisher per cell of every finite nonempty marginal, independently of its size or shape. This establishes a first-order statistical response loss of the complete pushed family on this high-noise domain.

It does not imply that the finite-B Fisher matrix is nonsingular, that its inverse converges, or that a curvature scalar tends to zero. Fisher curvature needs further derivatives and a regular rank/quotient construction. The fair-product limiting law still allows negative plaquette holonomy; its gauge field is not asserted flat.

## FD10. Integer composition and the volume factor

For integers a,B>=1, every retained a-path of the B-coarse variables based in Lambda_L uses only coarse edges anchored in Lambda_(aL): the starting anchor is ax and the a offsets are 0,...,a-1 in its orientation. The channel from that source square marginal to the target is fixed, deterministic and parameter-independent. Exact disjoint-path composition gives C_a C_B=C_(aB), so its target is precisely mu_(aB,Lambda_L). Apply FS02-FS03 at the same original parameter (h,J):

    I(mu_(aB,Lambda_L))<=I(mu_(B,Lambda_(aL))).

Divide by L^2 and use FD08 for both sides. The result is

    mathcal I_(aB)<=a^2 mathcal I_B,
    mathcal I_(aB)/(aB)^2<=mathcal I_B/B^2.

Thus information per original fine cell is monotone along integer divisibility. Per coarse cell a factor a^2 remains; dropping it is unjustified. The corresponding normalized finite Fisher-loss matrices converge to a^2 mathcal I_B-mathcal I_(aB), which is positive semidefinite. Further fixed channels obey the finite tower/loss identities before taking this limit. A smooth common parameter chart changes both sides by the same Jacobian congruence. No different fitted couplings or depth-dependent coordinates are silently compared.

## FD11. Curvature and the continuing obligation

The new theorem controls the first parameter response of the same normalized full gauge-matter law and its full exact RG orbit. Gauge curvature enters that law through the already declared plaquette/holonomy action. Base geometry and any metric used to contract gauge curvature must be supplied by the admitted base model. The Fisher tensor is computed from the resulting parameterized probability law, so these choices can affect it without making the tensors identical.

The existing finite latent-holonomy inference and metric-quotient curvature constructions retain their own hypotheses. An iterative spatial Fisher-curvature theory still needs higher parameter regularity, identifiable directions or a rigorously defined rank quotient, and a justified bridge to the chosen gauge/base fields. None is manufactured by inverting the vanishing density. The full renormalization goal therefore remains active even if this response contract closes.
