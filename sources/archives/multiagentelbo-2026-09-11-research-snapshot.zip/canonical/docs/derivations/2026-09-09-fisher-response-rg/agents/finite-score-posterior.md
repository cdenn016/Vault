<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Finite scores, full-law projection and normalized posterior

These direct finite arguments fix the distinction between statistical parameter response, gauge curvature and base geometry. Their first-order hypotheses do not imply a nonsingular Fisher metric or a curvature tensor.

## FS01. The complete normalized score

Let X be a fixed finite set, let nu_x>0 be a fixed reference probability, and let w_t(x)>0 be C1 on an open parameter set in R^d. Define Z_t=sum_x nu_x w_t(x), p_t(x)=nu_x w_t(x)/Z_t, a_i=partial_i log w_t and s_i=partial_i log p_t. Finite differentiation gives partial_i Z_t/Z_t=E_p a_i and s_i=a_i-E_p a_i. In particular E_p s_i=0 and partial_i p_t=p_t s_i. This applies equally to a positive smooth family of masses without a chosen unnormalized representation.

For the finite spatial source, w_(b,c)=product_free_edges(1+b z_e) product_touching_plaquettes(1+c W_p), and h=atanh b, J=atanh c. The identity 1+tanh(h)z=exp(hz)/cosh h holds for z in {-1,+1}. Therefore a_h=sum_free z_e-N_edges b and a_J=sum_touching W_p-N_plaquettes c. The constants disappear on centering: the natural scores are the centered two complete sufficient statistics. Crossing plaquettes use their fixed exterior completion. In the (b,c) chart the score columns divide by 1-b^2 and 1-c^2. Omitting a touching plaquette, treating a generated interaction as absent, or omitting the derivative of Z changes this source family.

## FS02. Exact projected scores

Let K(y|x) be one parameter-independent stochastic matrix, and retain only its fixed reachable support Y. Positivity of p gives q_t(y)=sum_x p_t(x)K(y|x)>0 there. Define R_t(x|y)=p_t(x)K(y|x)/q_t(y). Finite differentiation yields

    partial_i q_t(y)=sum_x p_t(x)K(y|x)s_i(x),
    s_i^Y(y)=E_R[s_i(X)|y].

Thus the score is projected through the full joint pK. It is not obtained by fitting coarse couplings or substituting the coarse sufficient statistic of an unrelated model. Zero entries of K are allowed when this fixed-support formulation holds.

## FS03. Full mixed Fisher loss and equality direction

Define I_X(i,j)=E_p[s_i s_j] and I_Y analogously. Conditional expectation and centering give the exact matrix identity

    I_X-I_Y=E_q Cov_R(s_X|Y).

For every real vector v its quadratic form is E[(v dot s_X-E[v dot s_X|Y])^2], hence nonnegative. Equality in that direction holds precisely when v dot s_X is constant on every positive reverse fiber. This is a statement at the given parameter. It does not establish global sufficiency of Y for the entire parameter family. Off-diagonal entries must be retained; checking only scalar diagonals does not recover the full matrix identity.

## FS04. Composition and loss addition

For fixed channels K_01 and K_12 use their ordinary stochastic composition K_02 and the joint p_0 K_01 K_12. Bayes' formula gives R_02(x|z)=sum_y R_01(x|y)R_12(y|z) on its positive support. Applying finite sums twice proves s_2=E[s_1|2]=E[s_0|2]. Consequently I_0-I_2=(I_0-I_1)+(I_1-I_2), with each term positive semidefinite. The same initial parameter coordinates and the same full intermediate law are necessary. Recomputing a fitted intermediate law changes the assertion.

## FS05. Finite KL quadratic response

At an interior parameter t and small vector u, C1 positivity on a finite carrier gives p_(t+u)=p_t+Dp_t u+o(||u||), uniformly over its finitely many atoms. Set delta=p_(t+u)-p_t. The scalar expansion (p+delta)log(1+delta/p)=delta+delta^2/(2p)+O(|delta|^3), with min_x p_t(x)>0 and sum delta=0, yields

    D(p_(t+u)||p_t)=0.5 u^T I_X(t)u+o(||u||^2).

For the same fixed channel, exact finite KL chain decomposition on pK gives D(p' ||p)-D(q'||q)=sum_y q'(y)D(R'_y||R_y). Its quadratic coefficient is I_X-I_Y by the two expansions. Thus discarded conditional KL and Fisher loss are related within the same normalized family. This does not turn a Hessian in unrelated recognition coordinates into the generative Fisher tensor.

## FS06. Selected evidence and posterior score

Let j_t(x,o)>0 be a normalized finite generative joint on a fixed carrier, C1 on an open parameter set. Fix o with evidence z_t(o)=sum_x j_t(x,o)>0. Set a_i(x,o)=partial_i log j_t(x,o). Finite differentiation gives

    partial_i log z_t(o)=E_[p_t(x|o)] a_i(x,o),
    partial_i log p_t(x|o)=a_i(x,o)-partial_i log z_t(o).

The selected joint score need not be centered until its evidence derivative is subtracted. A fixed latent channel K that retains o preserves z_t(o). Its selected posterior is the full posterior pushforward, so FS02-FS04 apply to these centered posterior scores. For j_t=p_t(x)ell(o|x) with a fixed positive normalized likelihood, a_i=s_i^prior and the posterior evidence derivative is its posterior expectation. The adapter implements this fixed binary-likelihood case. A parameter-dependent likelihood adds its own log derivative before centering.

## FS07. Normalized posterior VFE under a retained observation

For an arbitrary recognition mass r(x) and the same selected joint, define F(r;o)=sum_x r(x)log[r(x)/j_t(x,o)]. Then F=D(r||p_t(.|o))-log z_t(o). For a fixed deterministic retained map y=T(x), exact conditional KL splitting gives

    F(r;o)=D(r_Y||p_t(Y|o))-log z_t(o)
             +sum_y r_Y(y)D(r(.|y)||p_t(.|y,o)).

All terms refer to one joint and one evidence probability. A general stochastic K gives the same KL splitting on augmented recognition r(x)K(y|x) and augmented posterior p_t(x|o)K(y|x), so its x-marginal VFE is unchanged before splitting. Omitting the final conditional term is an approximation unless it vanishes. A spatial prior Fisher density and a recognition Fisher metric are distinct families unless an explicit identification is supplied.

## FS08. Parameter-dependent channels

If K_t is itself C1 with fixed positive transition support in each row, put k_i=partial_i log K_t on those positive entries and extend k_i by zero on structurally zero entries. A fixed reachable output alphabet alone does not impose this per-row support hypothesis. Row normalization gives E[k_i|X]=0. The joint score of p_t K_t is s_X+k, and its Fisher is I_X+E_X I_(K_t(.|X)), because both cross expectations vanish. Projection bounds the output Fisher by this joint Fisher. In general it is not bounded by I_X. A one-state source has I_X=0; the channel with output probability t in (0,1) has Fisher 1/[t(1-t)]>0. This explicit counterexample forbids using ordinary data processing for a learned channel while silently dropping its parameter response.

## FS09. Rank, coordinates and curvature

An erasure channel has zero Fisher. For a binary output with probability q_t in (0,1), the matrix is (grad q_t)(grad q_t)^T/[q_t(1-q_t)], with rank at most one even when the input has several identifiable directions. Under a smooth chart t=t(v), scores transform by the transpose Jacobian and I_v=Dt(v)^T I_t Dt(v). These facts require no matrix inversion. Calling I a Riemannian metric requires constant full rank on the chosen chart. Its Levi-Civita curvature requires further regularity; the present C1 probability family supplies continuous first-order Fisher data only. Collapse of I toward zero is not a flatness or curvature-limit theorem.

Gauge frame changes act on fields and observations through their declared representation, while this Jacobian acts on statistical parameter coordinates. A metric on the base controls a different geometric object. A normalized gauge-curvature action, such as an admitted positive contraction of F with itself, can change the weights w_t and thereby the score; it does not identify the three curvatures.

## FS10. Pressure Hessians for nonlinear effective actions

For a finite C2 family p_t proportional to exp[-H_t] relative to a fixed reference, two finite differentiations give

    partial_ij log Z_t=Cov_p(partial_i H_t,partial_j H_t)
                        -E_p partial_ij H_t,
    I_ij=partial_ij log Z_t+E_p partial_ij H_t.

The correction disappears for an affine Hamiltonian in the chosen natural coordinates. Generated coarse effective actions are generally nonlinear in the original fine parameters. A formula that simply equates their pressure Hessian to Fisher omits this term. An infinite-volume formula would additionally require the relevant derivative and volume interchanges; the spatial density argument below uses actual marginal score chains instead.
