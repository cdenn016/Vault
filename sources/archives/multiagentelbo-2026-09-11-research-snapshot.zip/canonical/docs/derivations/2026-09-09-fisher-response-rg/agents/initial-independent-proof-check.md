<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","schema_version":"rigorous-theory-search/v1","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->
# Independent response and marginal Fisher-density reconstruction

Revision 1, 2026-09-09. Only the new frozen problem-contract.json was opened before this initial record. Its file SHA256 is be3bafac3ea8a6f230e4b2c5804834027ca37213c91520b4737445ad2b4d63f8 and its canonical target digest was independently recomputed as 5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec. No new intake, author, root or worker draft, proposed mechanism or source was read. The preceding admitted UC/UP definitions and proofs and SPEC are retained inputs from this continuous task. The same model family and filesystem limit independence; the complete calculations below, not agreement or procedural labels, carry the proposed argument. No new external theorem is imported, no scientific code/test is run, and no ledger state is assigned.

The construction below uses actual finite covariance identities and uniform derivative convergence. It does not differentiate a C0 bound. The Fisher-density existence argument uses actual marginal conditional-score chains, not a pressure Hessian or an unproved squared boundary-score estimate.

## IFR01. Compact constants and the finite localized perturbation

Write the parameter vector as u=(h,J). Fix the contract's compact rectangle K. Choose a larger closed rectangle K1 inside 0<h<infinity, 0<J<atanh(1/12), with K in its interior and a positive margin for a neighborhood of K. Let h_1,J_1 be its upper endpoints. Define

    cbar=tanh(J_1), rho=tanh(h_1+2J_1)<1,
    s=(1/2)log(1/(12cbar))>0,
    q=12cbar exp(s)=sqrt(12cbar)<1,
    t=exp(-s), C_U=16q/(1-q),
    G_s=1+8t/(1-t)^2,
    m=(1-rho)^2/4>0.

All constants below depend on K1, not B, a volume or an exterior pattern. Work first with finite unions V of whole path/singleton blocks, fixed allowed supports and parameter-independent fine exteriors. Natural-coordinate densities are proportional to exp(h T_h+J T_J), where T_h sums every free edge sign and T_J sums every plaquette sign whose factor touches a free edge. The factors 1+bz and 1+c tau differ from these exponentials only by parameter-dependent scalar cosh factors; centering removes them from normalized scores. Boundary-crossing plaquettes must remain in T_J.

The UC finite conditional product coupling extends to heterogeneous local fields and plaquette couplings bounded by h_1,J_1. This extension requires no homogeneity: a conditional whole path still has one independent sign factor per edge before its own parity restriction; a differing exterior edge changes a plaquette tilt of magnitude at most J_1; the six-column incidence and spatial weight proof use cbar. Finite positivity and the paired stationary construction remain valid. This observation is needed to localize a perturbation rather than applying a homogeneous-only theorem to a different family without explanation.

Perturb just one edge field by delta. The affected bit's conditional log odds change by 2delta, so its TV changes by at most |delta|/2: the derivative of (1+tanh v)/2 has absolute value at most 1/2. On a fixed parity fiber the expected fine-Hamming coupling cost is at most |delta|, by the UC one-bit opposite-parity remainder construction. An absent parity costs no more, and a prescribed singleton costs zero. This creates an additive forcing of at most |delta| at the one block containing that edge.

Perturb just one plaquette coefficient by delta. It adds a single-coordinate field of magnitude delta to at most four different conditional block rows. The same argument gives forcing at most |delta| at each of those blocks. Couple the two perturbed finite heat baths with the same block update index. Their stationary weighted cost S obeys

    S <= q S + |delta| sum_(blocks hit by the local source) w_i.

The source term is not multiplied by a volume or by B. The usual 1/n update factor cancels on both sides; q is the old-disagreement propagation, while the displayed new forcing is added separately. Take delta sufficiently small within the margin provided by K1. This derives the localized perturbation bound from the finite chain and does not assert smoothness of an infinite field in advance.

## IFR02. Covariance localization and global source counts

Let f be a bounded observable with |f|<=1 supported on a target coarse anchor cell, including its retained fine paths. Use weights w_i=exp[-s dist(anchor(i),{0})]. The expected difference of f is at most 2S. Divide the finite perturbation inequality by |delta| and use the exact derivative of a finite normalized positive exponential family:

    partial_a E_V f = Cov_V(f,T_a),

where T_a is one edge sign or one plaquette sign. A source edge at anchor x contributes one weight exp(-s||x||). A source plaquette anchored at x contributes at most four block weights, each bounded by exp(s)exp(-s||x||). Hence both source types obey

    |Cov_V(f,T_a)| <= M exp[-s||anchor(a)||],
    M=8exp(s)/(1-q).

The plaquette anchor is the floor of its fine lower-left basepoint divided by B; all its block anchors lie within one of it. These constants also bound covariances when f is a coarse-state indicator. Outside finite volumes, extend fixed fine exteriors to full configurations. An all-exterior source is constant and has covariance zero. A crossing plaquette source retains precisely its actual factor, so every finite response can be written using the same entire-lattice source index set with zero covariance for irrelevant sources.

Each coarse anchor contains exactly 2B^2 edge sources and B^2 plaquette sources. Thus at most 3B^2 sources have a given anchor, and

    sum_a |Cov_V(f,T_a)| <= 3M B^2 G_s.

This bounds the l1 norm of the pair of homogeneous derivatives (partial_h,partial_J), since its two components are the separate edge and plaquette sums. The geometric identity G_s=sum_(x in Z^2)exp(-s||x||) follows from 8r sites on shell r>=1. The same source count holds for the actual finite field with crossing plaquettes, because it is a subset of this common entire-lattice inventory.

For any r>=0 define the explicit tail

    T_s(r)=8t^(r+1)[(r+1)/(1-t)+t/(1-t)^2].

Then the absolute response from anchors outside Q_r is at most 3M B^2 T_s(r). No derivative of an infinite normalization is taken.

## IFR03. Actual C1 limits and an explicit derivative spatial modulus

Consider two finite or infinite candidate constrained laws whose patterns and fine free interior agree throughout the whole-block inventory anchored in Q_R around the target. For a local source with anchor in Q_r, its fine support uses at most four anchors within Q_(r+1). Along with the target, at most five anchor cells are needed. Put L=R-r-1>=0. The UC joint-target comparison on one common stationary coupling bounds the relevant joint TV by

    5 C_U B^2 (L+1)exp[-s(L+1)].

For |f|,|T_a|<=1, a difference of these covariances is at most six times the joint TV: one product expectation costs 2TV and the difference of the product of the two expectations costs at most 4TV. There are at most 3B^2(2r+1)^2 near sources. The difference of the two far covariance tails costs at most 6M B^2 T_s(r). Therefore the l1 difference of the two response vectors is bounded by

    Xi_B(R;r)=90 C_U B^4 (2r+1)^2(L+1)exp[-s(L+1)]
              +6M B^2 T_s(r).

For R>=1 take r=floor((R-1)/2) and L=R-r-1. For R=0 use the valid bound 6M B^2 G_s. One convenient uniform envelope, valid for all integer R>=0, is

    Xi_B(R) <= C_X B^4(R+1)^3 exp(-sR/2),
    C_X=90C_U+48M/(1-t)^2+6M G_s.

Indeed both r+1 and L+1 are at least R/2; 2r+1<=R and L+1<=R+1. The far-tail expression is at most 8(R+1)exp(-sR/2)/(1-t)^2. The final term in C_X also covers R=0. Constants are deliberately conservative but counted.

To establish derivatives rather than assume them, first apply the preceding bounds to finite-volume covariances only. The UC finite joint-cylinder limits make each fixed-source covariance converge uniformly on K, in exterior patterns and fine boundary choices with receding common interiors. Uniform summable tails then make the entire finite homogeneous derivative vectors converge uniformly. The bound Xi_B controls the difference after passing to the limit and also the finite-volume approximation error when the target's radius-R whole-block interior is present.

Every finite normalized row is smooth on a neighborhood of K. Its values and first derivatives now converge uniformly. Along each coordinate segment contained in that neighborhood, write the finite fundamental-theorem-of-calculus identity and pass the uniform limit under its ordinary one-dimensional integral. The limit has the stated partial derivative, and that derivative is continuous as a uniform limit of finite continuous derivatives. This gives actual C1 rows on an open neighborhood of K at every parameter, not merely almost-everywhere differentiability or a Lipschitz envelope. The construction is uniform over every fixed signed-or-absent pattern and fixed fine exterior; it includes infinite null patterns through the already constructed normalized limits.

The extension to finite target sets uses their finite anchor inventory and the same covariance counts with its explicit size/geometry. For the one-cell conditional and the partial-past kernels used below, the displayed constants suffice. Parameter-dependent exterior values, carriers or constraints are not part of this argument.

## IFR04. A small first derivative from conditional covariance, not differentiation of rho^B

Let Y be one whole free target path parity and let R denote all other fine block states. Given R, the target path has B independent signs with means m_e(R), each of absolute value at most rho. Thus g(R)=E[Y|R] has |g|<=rho^B. For a source statistic T_a not meeting that path, it is R-measurable and

    Cov(Y,T_a)=Cov(g(R),T_a),
    |Cov(Y,T_a)|<=2rho^B.

For an edge or plaquette source meeting the path, no plaquette meets it twice. Write T_a=A(R)z_e, where |A|=1. Conditional covariance is

    Cov(Y,T_a|R)=A(R)(1-m_e(R)^2) product_(f!=e)m_f(R),

so its absolute value is at most rho^(B-1). The covariance of the two conditional means is at most 2rho^B. There are B edge and 2B plaquette sources meeting the path. Consequently their total contribution to the l1 homogeneous response is at most 9B rho^(B-1).

For all other sources combine the preceding amplitude with IFR02's localization using min(a,b)<=sqrt(ab). Sum at most 3B^2 sources per anchor. Uniformly in every permitted pattern, exterior and finite response volume,

    ||grad_u E Y||_1 <= D_B
       :=9B rho^(B-1)+3sqrt(2M) G_(s/2) B^2 rho^(B/2)
       <= C_D B^2 rho^(B/2),
    C_D=9/rho+3sqrt(2M)G_(s/2).

This is a bound on the exact covariance derivative. It is not obtained by differentiating the inequality |E Y|<=rho^B. The apparent rho^-1 is harmless for the fixed compact constants, where rho>0.

The derivative of either target sign probability is at most D_B/2 in l1 norm. A four-state cell atom factors as its first path probability times its second path probability conditional on the first. The additional finite parity conditioning is another fixed admitted pattern, so both derivative bounds apply. Product differentiation gives l1 derivative at most D_B for each four-state atom. The same reasoning applies to all-pattern rows, partially observed rows and finite-volume approximations with the whole target paths free. Every atom is at least m=(1-rho)^2/4. Thus each row score has norm at most D_B/m and each vacuum-relative log-odds derivative has norm at most 2D_B/m.

## IFR05. Counted C1 interaction norm and uniform depth decay

Let Omega_B(R)=min(1,C_U B^2(R+1)exp[-s(R+1)]) be the C0 one-cell comparison bound. For two rows p,pbar whose exterior patterns agree through radius R, IFR03 and IFR04 give

    ||grad p_x-grad pbar_x||_1<=Xi_B(R),
    ||grad log p_x-grad log pbar_x||_1
       <=Xi_B(R)/m+D_B Omega_B(R)/m^2.

Subtract two log probabilities for the vacuum odds. A sufficient envelope is

    L'_B(R)=C_L B^4(R+1)^3exp(-sR/2),
    C_L=2C_X/m+2C_D C_U/m^2.

The same quantity is also at most 4D_B/m by the two score-amplitude bounds. This minimum can be used to make the row derivative approximation uniform over B as well as compact parameters: its geometric-mean envelope has a polynomial B prefactor times rho^(B/4), whose supremum over all B is finite. The C0 approximation is similarly bounded by the minimum of its spatial tail and its exponentially small row amplitude. Thus no unbounded B factor is silently treated as a uniform constant.

Use the existing fixed (+,+) vacuum and lexicographic-past convention. The base energy e_(x,0) and every truncated-past energy e_(x,r) are C1 by IFR03. For shell r>=1, their derivative increment obeys both bounds

    ||grad Phi_(A_xr)||_1 <=4D_B/m,
    ||grad Phi_(A_xr)||_1 <= C_L exp(s/2) B^4 r^3 exp(-sr/2).

The latter applies the radius-(r-1) derivative modulus, preserving its index. Geometric-mean interpolation gives

    ||grad Phi_(A_xr)||_1
       <=C_P B^3 rho^(B/4) r^(3/2)exp(-sr/4),
    C_P=sqrt[(4C_D/m) C_L exp(s/2)].

Choose the one common exponential norm with lambda=s/16. Each support has diameter at most 2r, and at most (2r+1)^2 translates contain zero. Since r^(3/2)<=r^2 for r>=1,

    sum_(A containing0) exp(lambda diam A)||grad Phi_A^(B)||_1
       <= E'_B
       :=(2C_D/m)B^2rho^(B/2)+C_P S_4 B^3rho^(B/4),
    S_4=sum_(r>=1)(2r+1)^2 r^2 exp(-sr/8)<infinity.

This explicit positive series is a polynomial times geometric sum and provides an equally explicit spatial tail by restricting r>N. Every factor is independent of B and volume. A pure exponential-in-B envelope follows with v=rho^(1/8), using the convergent sums sum_n n^2 v^n and sum_n n^3 v^n to bound the polynomial factors: E'_B<=C_K rho^(B/8) for a finite displayed-series constant C_K. No infinite shell is deleted.

The value norm at this lambda is controlled by the preceding UP theorem, uniformly on the present compact since all its constants can use cbar,rho and s. Its hypotheses are satisfied because lambda is smaller than the available value-norm exponent. Uniform summation of the termwise first derivatives and the coordinate FTC identity prove that u maps to the complete fixed-convention Phi^(B)(u) as an actual C1 map into this common normed interaction space. The derivative norm tends to zero compact-uniformly with B, and so does the original value norm. This is not inferred from C0 convergence alone.

## IFR06. Partial-past kernels and actual finite marginal scores

For the Fisher-density construction a full-exterior Gibbs row is not the desired predictive row. For a finite set S of preceding coarse cells, define k_(x,S)(a|y_S) as the actual conditional law under mu_B of the cell at x given Y_S=y_S. Finite support is positive. By the admitted finite parity-conditioning identity it equals the target row of the constrained fine law with exactly those S path parities prescribed and every other retained path unprescribed. This is one of the signed-or-absent patterns covered by IFR03-IFR04, so its actual parameter derivative has the same bounds.

For the infinite lexicographic past P_x={y:y<x}, prescribe all its path parities and leave the future unprescribed. Finite-past conditioning windows exhaust P_x. Their values and first derivatives converge uniformly by the same every-pattern comparison. This constructs an everywhere C1 predictive row k_(x,infinity), distinct from the vacuum-future hybrid used to define the canonical potential. Testing against finite past-cylinder events and passing the uniform limit identifies it as a version of the actual conditional distribution given the whole past. No infinite past event is divided by its probability.

For a square Lambda_L, enumerate cells in increasing lexicographic order. Its actual marginal factors into the finite predictive rows with S equal to preceding cells inside the square. Differentiating this finite identity gives

    score_(Lambda_L)=sum_(x in Lambda_L) s_(x,L),
    s_(x,L)=grad log k_(x,preceding Lambda_L)(Y_x|Y_preceding).

Each increment has conditional mean zero because sum_a grad k(a|history)=0. If x precedes y, s_x is measurable with respect to y's finite preceding history, so E[s_x s_y^T]=0 by conditioning. Therefore the actual finite Fisher matrix is exactly

    I_(B,L)=sum_(x in Lambda_L) E_muB J_(x,L),
    J_(x,L)=sum_a [grad k_a grad k_a^T]/k_a.

This is an identity for the true full-law marginal, not a surrogate free-boundary Hamiltonian and not a sum of spatially independent scores. It requires only the actual C1 finite marginals just proved and fixed positive carriers.

## IFR07. Existence and decay of the marginal Fisher matrix per coarse cell

Every predictive atom is at least m and its gradient l1 norm is at most D_B. Hence its local Fisher matrix is positive semidefinite with operator norm at most

    F_B=4D_B^2/m <= (4C_D^2/m) B^4rho^B.

For two predictive rows agreeing on the radius-R observed past, the exact difference of vv^T/p and ww^T/pbar is bounded by

    (||v||+||w||)||v-w||/m+||w||^2|p-pbar|/m^2.

Sum their four atoms to obtain the explicit local Fisher modulus

    T_B(R)=8D_B Xi_B(R)/m+4D_B^2 Omega_B(R)/m^2
       <= C_F B^6rho^(B/2)(R+1)^3exp(-sR/2),
    C_F=8C_D C_X/m+4C_D^2 C_U/m^2.

The two rows may be a finite-prefix predictor and the infinite-past predictor. Coarse translation covariance makes E_muB J_(x,infinity) independent of x. Define the matrix

    I_B(u)=E_muB J_(0,infinity).

This expectation is finite, positive semidefinite and bounded in operator norm by F_B. To prove it is the actual density limit, take all cells of Lambda_L at least R from its boundary. Their finite preceding set contains the entire radius-R lexicographic past, so their Fisher matrices differ from the infinite-past one by at most T_B(R). The remaining cell fraction is at most 4R/L for R<L/2. Their two matrices are each bounded by F_B. Thus

    ||I_(B,L)/L^2-I_B|| <= T_B(R)+8R F_B/L.

First fix R and send L to infinity, then send R to infinity. This proves a limit, not merely a limsup, for every compact parameter and every B. An explicit simultaneous choice such as R=floor(sqrt(L)) for sufficiently large L also gives a quantitative error. The error is compact-uniform. Since the suprema of B^6rho^(B/2) and B^4rho^B are finite, the displayed bound is even uniform over all integer B; those suprema can be bounded by their convergent positive geometric-power sums.

The actual per-cell marginal Fisher matrix satisfies

    0 <= I_B(u) <= F_B Identity_2,
    sup_(u in K)||I_B(u)|| <= (4C_D^2/m)B^4rho^B ->0.

The C1 predictive kernel and its compact-uniform spatial approximations also make I_B(u) continuous: approximate J_(0,infinity) uniformly by finite-past continuous cylinder functions, whose expectations are continuous through the finite marginal response theorem. No second derivative of pressure is needed. This establishes the stated Fisher tensor density, without asserting it has rank two or an inverse.

## IFR08. Rank, chart covariance and integer composition factors

The matrix is positive semidefinite by its score-square representation. It can be singular. For example a finite spatial law with one free edge has T_h=z and T_J=A z plus any constant, so the two centered natural scores are linearly dependent and its two-parameter Fisher matrix has rank at most one; an empty variable law has rank zero. A finite positive score tensor is not automatically an identifiable Riemannian chart, and decay to zero supplies no stable inverse or curvature limit. A separate proof of regular local identifiability and the necessary higher smoothness is required before constructing Fisher curvature.

For a differentiable parameter chart u=u(v), scores satisfy S_v=(D_v u)^T S_u and Fisher transforms as I_v=(D_v u)^T I_u(D_v u). In particular natural to bounded coordinates has D_(b,c)(h,J)=diag((1-b^2)^(-1),(1-c^2)^(-1)). The Jacobian is controlled on each compact but can diverge at its excluded boundary. A parameter chart change is not a gauge change or a base metric.

For fixed geometric C_a, the retained a-block square of side L depends only on the source B-law square of side aL, when cells contain their two positively oriented outgoing edges. All B-law cells used by those a-paths have anchors in that aL square. Finite fixed-channel Fisher contraction therefore gives

    I_(aB,L) <= I_(B,aL).

The actual density limits just proved imply

    I_(aB) <= a^2 I_B.

There is no per-coarse-cell contraction inequality with that a^2 deleted. Per-original-fine-cell information obeys I_(aB)/(aB)^2 <= I_B/B^2. Composition is in the same natural coordinates unless the stated Jacobians are applied. The integer path channel itself remains parameter-independent and its exact composition precedes differentiation.

## IFR09. Exact finite scores and channel loss

On a fixed finite carrier with positive C1 masses p_u(x), define S(x)=grad log p_u(x), with E S=0. A fixed stochastic kernel K(y|x) has q_u(y)=sum_x p_u(x)K(y|x). On its fixed reachable support,

    grad log q_u(y)=E[S(X)|Y=y].

This follows by differentiating a finite sum, including every source state and channel weight. The finite Fisher identity is the conditional second-moment decomposition

    I_X-I_Y=E[Cov(S(X)|Y)] >=0.

Equality means the score is Y-measurable at this parameter; it need not imply statistical sufficiency of the channel for an entire family. For instance a conditional family that varies only quadratically in one parameter can have zero lost score at a point while changing nearby. If all parameter derivatives of the conditional law vanish throughout a connected regular parameter domain, the stronger parameter-independence conclusion needs that extra all-parameter premise.

For fixed X->Y->Z kernels, the tower property gives the direct pushed score E[S_X|Z] and exact additive Fisher loss (I_X-I_Y)+(I_Y-I_Z). Support is the actual reachable support, and zero-probability rows must not be normalized by an invented default. If the kernel depends on u, the correct projected score includes the kernel score:

    S_Y=E[S_X+grad log K_u(Y|X)|Y],

on positive joint transitions, or equivalently the direct derivative term sum_x p_u(x) grad K_u(y|x). The fixed-channel loss identity comparing only S_X generally fails for moving kernels. Parameter-dependent deterministic carrier changes need their own differentiability/support construction and are not included.

## IFR10. Source-faithful finite spatial adapter and posterior normalization

For a positive finite spatial field on n free signs with every touching plaquette included, enumerate the exact normalized mass p. Compute integer sufficient statistics T_h=sum_free z and T_J=sum_touching plaquettes tau. Natural scores are

    S_h=T_h-E_p T_h, S_J=T_J-E_p T_J.

At rational b,c, both masses and centered scores are rational although h,J themselves need not be rational numbers. The raw product representation contributes constants -n b and -N_p c to the unnormalized natural derivatives; normalization cancels them. Crossing plaquettes cannot be dropped. Any fixed finite set of tangent directions in these two parameters is a declared linear combination of these two score columns; the existing finite primitive's admitted direction count and carrier limits must be checked when source is opened. No duplicate generic Fisher engine is proposed here.

For a normalized finite observation likelihood ell_u(o|x), the generative joint score is S_joint=S_prior+grad log ell. At a selected observation with positive evidence, the evidence score is E[S_joint|o] and the posterior score is

    S_post=S_joint-E[S_joint|o].

The retained joint under a fixed channel has the conditional expectation of the joint score; the retained posterior similarly projects the centered posterior score, with the evidence term kept. These are separate distributions and normalizers. A recognition family has its own score and cannot use the generative score as a substitute.

For a fixed recognition law Q, the exact finite negative ELBO satisfies F(Q;o)=D(Q||p(.|o))-log p(o), and its generative-parameter derivative is -E_Q S_joint. If Q=Q_u also changes, differentiation adds E_Q[S_Q log(Q/p_joint)]; E_Q S_Q=0 removes only the derivative of Q's normalization, not this term. No curvature scalar is created by these identities.

## IFR11. Quadratic KL, nonlinear pressure correction and nonclaims

For a finite strictly positive C1 family on a fixed carrier, p_(u+delta)=p_u+D p_u delta+o(||delta||). The finite mass-coordinate Taylor expansion of KL around p_u has zero linear term on the normalized tangent space and Hessian diag(1/p_u). Thus the local quadratic KL term is (1/2)delta^T I_u delta+o(||delta||^2). This finite interpretation does not justify a uniform infinite-carrier KL Taylor limit, which is not asserted here.

If an additionally C2 finite Hamiltonian family has p_u proportional to exp(-H_u) relative to a fixed reference, then

    I_ij=Cov(partial_i H,partial_j H),
    partial_ij log Z=I_ij-E[partial_ij H],
    I_ij=partial_ij log Z+E[partial_ij H].

The centered score is -partial H+E partial H. A linear fine natural-parameter Hamiltonian has zero second-Hamiltonian derivative. The generated coarse canonical Hamiltonian need not be linear, so the correction cannot be omitted. The present infinite C1 proof does not itself give C2 pressure or authorize commuting its Hessian with a volume limit. The actual Fisher-density proof in IFR06-IFR07 bypasses that unavailable step.

A small log-density boundary error does not control a derivative or a squared boundary score. Even a scalar family epsilon_n sin(theta/epsilon_n) converges uniformly in value and has order-one derivative, so differentiating a value envelope is invalid. Likewise local score measurability does not establish a globally sufficient statistic, and a vanishing positive semidefinite matrix does not have a limiting Riemannian inverse. Gauge holonomy, information geometry and base curvature retain different roles.

## Initial conclusion and next access boundary

The preceding direct route appears to satisfy the frozen target's mathematical response and actual Fisher-density quantifiers on each compact K, with explicit conservative constants, complete source/boundary counts, actual C1 interchanges and a lexicographic marginal-score limit. The key amplitude derivative comes from conditional covariance of a free path, not from differentiating rho^B. Every use of finite comparison outside homogeneity was explicitly reconstructed for the localized-source perturbation. Rank-two identifiability, moving channels and higher-curvature limits remain excluded unless separately proved.

This is the initial independent proposal, not adjudicated closure. No new author/root/source interface has yet been read. The next step, only after the root authorizes access to mature interfaces, is to compare their actual constructions, finite source contracts and retained evidence with these obligations. Only the two owned proof records were written.
