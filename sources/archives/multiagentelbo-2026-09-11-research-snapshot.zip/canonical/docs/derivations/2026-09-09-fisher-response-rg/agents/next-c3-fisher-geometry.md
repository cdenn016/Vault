<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Next C3 response and Fisher-geometry contract

Date: 2026-09-09. **DISCOVERY / OPEN. Excluded from current theorem evidence.** This is the assigned next-obligation intake, not a proof proposal for closure in the current contract. It shares the FR author's existing coupling and response route and is not independent verification. The current FR/FD C1 response, common interaction derivative norm and actual Fisher-density conclusions are its admitted starting point; this note does not re-certify them. Only this discovery document is written. No code, tests, simulation, producer, GPU, Git, vault or prior artifact is changed.

## Smallest next target that supplies actual curvature

**OPEN, PROPOSED CONTRACT.** For the unchanged dressed gauge-matter law and every fixed integer B>=1, prove actual coarse conditional probabilities are C3 in the original natural parameters on compact sets inside 0<h<infinity, 0<J<atanh(1/12), uniformly over fixed signed-or-absent patterns and whole-block finite-volume approximations with parameter-independent fine exteriors. Prove first, second and third response spatial moduli with counted B powers and summable radius tails. Then prove the actual normalized finite-marginal Fisher matrices converge in C2 on compact sets to the existing density mathcal I_B. Exhibit a nonempty regular two-parameter region for each fixed B near the product control, or provide a precise rank obstruction. On a compact subset of such a region, prove an eigenvalue floor eta_B>0 and construct its continuous Levi-Civita curvature from the actual C2 density. For any prescribed finite hierarchy, intersect its finitely many regular neighborhoods. No common positive-J neighborhood for all unbounded B is presumed.

This is stronger than computing finite Fisher curvature or defining Christoffel symbols from an unverified inverse. It also leaves the full RG goal active: the current density collapses with depth, so a fixed-positive-c all-depth regular chart and an asymptotic curvature comparison remain separate obligations. The proposed next contract does not replace that full goal with a finite example.

For a fixed positive finite probability row p, the Fisher entries sum (partial_i p)(partial_j p)/p. C3 probabilities suffice for C2 Fisher entries, because two derivatives of this expression involve probability derivatives through order three. A C2 positive-definite metric suffices for a continuous curvature tensor. It does not supply higher curvature derivatives. For the infinite density, the expectation over the full-past law also varies with the parameters, so C3 conditional rows alone are insufficient: that expectation and the actual finite-marginal derivative limits must be controlled separately.

## Direct higher-response mechanism to investigate

**OPEN, CANDIDATE LEMMA FAMILY.** On each finite fixed support, natural-parameter differentiation is cumulant differentiation. A derivative of order r of a fixed local expectation involves the joint cumulant of that observable and r copies of the full field/plaquette source sums. Thus r<=3 requires cumulants through order four. All free fields and all touching plaquettes, including crossing factors, remain in those sums. A compact enlargement and a parameter-independent boundary are still needed. A third derivative cannot be obtained by differentiating the current first-derivative upper bound.

A direct route may avoid assuming a complex zero-free region. UC gives conditional-cylinder comparison for any finite target anchor set A against arbitrary fine exterior states beyond a buffer. This should first be written as a quantitative decoupling bound for two separated groups of bounded local observables. A joint cumulant vanishes when its arguments split into independent nonempty groups. Its finite moment formula is a sum over partitions pi with coefficient (|pi|-1)! and sign (-1)^(|pi|-1). Comparing the actual joint distribution to the product of two group marginals therefore costs at most 2 sum_pi (|pi|-1)!|pi| times their joint-TV error, for arguments bounded by one. This coefficient and the exact decoupling premise must be derived, not replaced by an invocation of “clustering.”

For r source anchors and a target at zero, let M be the greatest source radius. A minimum spanning tree of these at most r+1 anchors has an edge of length at least M/r. Removing a longest edge separates the two anchor groups by at least that edge length; otherwise the tree could be shortened. Local plaquette or conditional-product supports enlarge the groups by at most one anchor step. For M sufficiently large, a buffer such as floor(M/r)-3 would then give a cumulant bound with a polynomial prefactor and exp[-tau M/r]. Small M uses the finite cumulant coefficient bound. Repeated or coincident source locations must be included in the near count; they do not invalidate the distant cut when M is large.

There are at most 2B^2 source choices per anchor for a fixed field/plaquette derivative. Counting r source locations in an anchor ball gives a polynomial in M and B. For each fixed r<=3, polynomial times exp[-tau M/r] is summable. This is weaker than a full product-of-tree-edges bound but may suffice for the required finite response order. The proof must justify the group factorization comparison for the actual constrained law, including target/source joint indicators, rather than simply multiply pairwise covariance bounds; pairwise small correlations alone do not control higher cumulants.

The free-path conditional product supplies possible depth decay. Write its local product as G_g. Parameter derivatives of G_g through order three have norms bounded by explicit constants times powers of B and rho^(B-r), with the small-B cases handled directly. G_g and those derivatives depend only on the target and neighboring anchor cells, despite containing O(B) fine coordinates. Differentiate E_g G_g by the finite cumulant product rule: each term is a cumulant of a derivative of G_g and the remaining source sums. The proposed summable cumulant estimates could therefore give nonoptimized bounds of the form C_r B^(d_r)rho^(B-r), with d_r derived from the actual counts. Neither d_r=2r nor any sharper prefactor is assumed here.

For each fixed source tuple, UC cylinder convergence would give convergence of its finite cumulant. A near-tuple/far-tuple split with the uniform summable bound would pass all derivative sums to the infinite law. Repeated ordinary FTC, starting with finite analytic laws, must establish actual C3 and mixed-derivative compatibility. Comparing patterns agreeing through radius R uses the same split: near tuples are compared by joint-cylinder TV, while far tuples use the cumulant tail. Exponents weaken with the response order, so the old first-derivative radius exponent cannot be copied unchanged. All of these are proposed proof obligations, not established higher-response estimates.

## The density requires its own two derivatives

**OPEN, PROPOSED PASSAGE.** Let J_g(y_past) be the full-past conditional Fisher matrix used in FD08. C3 row probabilities and their spatial moduli would make J_g, partial_i J_g and partial_ij J_g bounded quasilocal observables with explicit summable tails. The missing expectation identities have the finite-volume forms

\[
\partial_i E_gJ_g=E_g\partial_iJ_g+
\sum_s\operatorname{Cov}_g(J_g,T_{i,s}),
\]

\[
\partial_{ij}E_gJ_g=E_g\partial_{ij}J_g+
\sum_s\operatorname{Cov}_g(\partial_iJ_g,T_{j,s})+
\sum_s\operatorname{Cov}_g(\partial_jJ_g,T_{i,s})+
\sum_{s,t}\kappa_g(J_g,T_{i,s},T_{j,t}).
\]

These expressions are entrywise matrix identities when their finite terms are defined; they are only candidate infinite-volume formulas until the sums and limits are proved. The statistics are affine natural sources, so there is no derivative of T itself. A finite-shell decomposition of the quasilocal J_g must be combined with the localized cumulant bounds. The relevant domination has to survive both the shell sum and the source sums.

Finally apply this response argument uniformly to every finite revealed-past pattern in the actual marginal score chain. Bulk patterns approximate the full past; their first two Fisher-response differences need quantitative moduli. Boundary cells need uniform bounds on those same responses, not merely on their energies or values. This would prove convergence of the actual marginal Fisher matrices and their first two derivatives after volume normalization. Differentiating the already proved C0 density limit, or substituting a pressure Hessian for a nonlinear effective action, would leave the central gap unpaid.

## Candidate regularity certificate near J=0

**OPEN, CANDIDATE RANK ARGUMENT.** Extend the finite/infinite response construction continuously and one-sidedly to J=0 before using it. The exact zero-c law has independent constrained blocks. At a target cell its two free B-path parities are independent with mean b^B, b=tanh h in (0,1). For either path and any one of its fine edges, the centered conditional edge mean is

\[
a(s)=E[z_e\mid Y=s]-b
=\frac{s b^{B-1}(1-b^2)}{1+s b^B},\qquad
v_B=E[a(Y)^2]=\frac{b^{2B-2}(1-b^2)^2}{1-b^{2B}}>0.
\]

The h row score is B(a_1+a_2). There is one start-corner plaquette containing one edge of each of the two target paths. Its other two edges have mean b: for B=1 they are in future cells under the translation-invariant lexicographic order, and for B>1 they are unused unconstrained singleton edges. That distinction must be verified in the adopted orientation and conditional past. Its J contribution includes b^2 a_1a_2. Every other incident plaquette meets only one of the two target paths and contributes a linear term. The candidate exact form is therefore

\[
s_J=b^2a_1a_2+\alpha_1a_1+\alpha_2a_2,\qquad |\alpha_i|\le2B.
\]

The coefficients depend on the prescribed past. Their bound counts the 2B plaquettes incident to each target path, including the linear part of the shared corner term. At J=0, nonincident plaquettes are independent of the target block after conditioning on that past and contribute zero centered response. The proof must retain the normalization subtraction and justify this cancellation through the finite response formula and its limit.

Under the product target row, a_1,a_2 have mean zero and variance v_B, and a_1a_2 is orthogonal to both linear contrasts. This suggests, uniformly in the past,

\[
\det J_{\rm cell}\ge2B^2b^4v_B^3,\qquad
\operatorname{tr}J_{\rm cell}\le10B^2v_B+b^4v_B^2,
\qquad
\lambda_{\min}(J_{\rm cell})\ge\frac{2b^4v_B^2}{11}.
\]

For the last inequality use v_B<=1 and B>=1. A proved uniform continuation of row scores from J=0 would transfer a positive floor to a neighborhood with J>0 for each fixed B and compact positive-h interval, and then to its expectation mathcal I_B. This is a concrete possible way to exhibit actual regular density charts rather than assuming them. The floor decays with B; the neighborhood in J can also shrink. A finite hierarchy can use the minimum of its finitely many neighborhood widths. An infinite intersection may have no positive width, so this mechanism does not certify a common fixed-positive-J chart at unbounded depth.

A more general alternative is a finite-past score certificate: two output score vectors separated from collinearity, with FR/higher-response oracle errors small enough to preserve that separation for every exterior extending the finite past. The positive probability of that past cylinder then supplies an actual density eigenvalue floor. Positivity of one arbitrary finite-volume Fisher matrix alone does not supply this inference.

## A tiny source-faithful curvature fixture

**OPEN, PROPOSED FINITE REALIZATION.** Use the four free edges of one square at B=1, with the full touching-plaquette inventory: one central plaquette and its four adjacent crossing plaquettes. Choose fixed exterior signs so the product of the three exterior signs in each adjacent plaquette is -1; the four outer parallel edges can carry those negative signs and the other exterior signs can be positive. The normalized source is then proportional to exp[(h-J)sum_e z_e+J product_e z_e]. This retains the crossing factors instead of silently replacing the specification by an isolated-plaquette model.

Retain the two outgoing B=1 edges at the lower-left target cell, and marginalize the other two free edges. Put t=tanh(h-J), c=tanh J. The candidate exact four-state output, suitable for independent algebraic checking in the next task, is

\[
p(z_1,z_2)=\frac{(1+t z_1)(1+t z_2)(1+c t^2z_1z_2)}{4(1+c t^4)}.
\]

Its two moment coordinates are M=(t+c t^3)/(1+c t^4) and V=t^2(1+c)/(1+c t^4). Direct algebra suggests the rank certificate

\[
\det\frac{\partial(M,V)}{\partial(t,c)}
=\frac{t^2(1-t^2)^2(1+c t^2)}{(1+c t^4)^3}>0
\quad(0<t<1,\ 0<c<1/12).
\]

For example t=1/5,c=1/20 corresponds to original b=25/101 and c=1/20, all rational factor parameters. The equal mixed-sign masses define a three-category family after a fixed sufficient collapse. A verified rank certificate would make this locally the already known two-dimensional categorical Fisher geometry, whose scalar curvature is 1/2 in the convention where a radius-two sphere has scalar curvature 1/2. This supplies a source/jet/curvature consistency fixture, not a new proof that finite Fisher curvature exists and not an infinite-density rank certificate. The finite positive-simplex curvature example is already established in the earlier report.

The smallest software seam is exact probability/source jets through order three passed through the existing fixed channel, followed by the metric and its first two derivatives on a certified regular chart. Reuse the existing finite law/channel/Fisher primitives. The metric-quotient connection utility is not automatically a parameter-Fisher Levi-Civita evaluator. A binary single-path fixture remains a rank-at-most-one rejection control; it cannot demonstrate a nondegenerate two-parameter curvature.

## Falsifiers and geometric boundaries

**OPEN, FAILURE CONDITIONS.** The response route fails if the required cumulant decoupling is asserted from pairwise covariance alone, if source-tuple tails are not summable after their full anchor counts, if a boundary/support term enters differentiation, or if finite higher derivatives fail uniform convergence. The rank route fails if another corner term cancels the quadratic contrast, if the supposed future edges are conditioned by the chosen past, if the coefficient bounds miss incidences, or if continuity is not uniform in that past. The curvature stage fails without an actual eigenvalue floor or a genuine quotient metric.

Constant rank alone does not make a semimetric descend: exp(2v)du^2 has radical span(partial_v) but varies along its null leaves. A local quotient needs an integrable constant-rank radical, a regular local leaf space and basicness, or an explicit identifiable law map through which the tensor pulls back. A chosen transverse slice is a different, section-dependent construction. A rank-one quotient has no nonzero intrinsic Riemann curvature. These obligations are distinct from the already delivered fixed-rank metric coarse-quotient connection theorem.

Even C2 convergence of metrics to zero gives no curvature limit. For g_epsilon=epsilon g_* with parameter-independent positive epsilon, the scalar curvature is R(g_*)/epsilon. Thus vanishing information can coexist with diverging scalar curvature. Any proposed depth rescaling, changing parameter chart or quotient must be declared, and its inverse/derivative control proved; none is selected automatically by the current norm limit.

The existing curvature/base, holonomy-inference and metric-quotient reports were read for this intake. They already contain normalized gauge action and random-base models, a latent holonomy likelihood with complete posterior/evidence bookkeeping, and metric-compatible quotient connection/curvature identities with their stated hypotheses. This next work concerns the parameter Fisher geometry of the same exact spatial RG law. It does not identify that geometry with the principal-bundle connection or a base metric, establish continuum/critical physics, infer geometric parallelness, or add a scalar Fisher-curvature term to VFE. Those bridges remain separately typed obligations in the continuing full RG program.
