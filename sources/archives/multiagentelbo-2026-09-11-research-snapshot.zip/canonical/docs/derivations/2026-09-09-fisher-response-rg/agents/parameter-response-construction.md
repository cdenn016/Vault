<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Parameter response of the exact constrained path law

Date: 2026-09-09. **DEFINITION.** This is the assigned mathematical author lane under the frozen fisher-response-rg contract. Its atomic proposals are FR01 onward. The author previously constructed UC and shares the root's finite-response interface; this is not independent verification. The discovery intake was frozen before this proof. The current Theory/SPEC.md has SHA256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. The only mathematical dependencies imported from the preceding run are its actual UC constrained-law construction and weighted comparison, with their hypotheses restored below. No unchecked response or complex-analytic theorem is imported. The root owns complete derivative-interaction reconstruction and actual Fisher-density assembly. No tests, implementation, science, old producers, Git, vault or tamper work is performed, and this document assigns no ledger closure.

## FR01. Common compact constants and geometric inventory

**HYPOTHESIS.** Fix a compact rectangle K contained in D={(h,J):0<h<infinity,0<J<atanh(1/12)}. Choose a compact rectangle Khat with K in its interior and Khat contained in D. All constants below use Khat, so every parameter in K has an open neighborhood on which they hold. Fine exterior signs and the parity pattern are independent of the parameters. Integer B>=1 is arbitrary. Coordinates h,J are the natural parameters of the existing positive dressed Z2 law, not new couplings fitted after blocking.

**DEFINITION.** Write h_*,J_* for the upper endpoints of Khat and set

\[
c_* = \tanh J_*,\quad
0<\tau<\log\frac1{12c_*},\quad
q=12c_*e^\tau<1,\quad z=e^{-\tau},\quad
C=\frac{16q}{1-q},\quad
\rho=\tanh(h_*+2J_*)<1,\quad d=1-\rho>0.
\label{eq:rg-fr-constants}
\]

Here tau is a spatial weight, not a model parameter. For an anchor set A, put w_i=exp(-tau dist_infinity(anchor(i),A)). For a single target anchor translated to zero, write Q_R={x:|x|_infinity<=R}. The summed anchor weight is

\[
W=\sum_{x\in\mathbb Z^2}z^{|x|_\infty}
=1+\frac{8z}{(1-z)^2}.
\label{eq:rg-fr-weight-sum}
\]

**ESTABLISHED.** Retained paths are P_B(x,a)={(Bx+t e_a,a):0<=t<B}, a=1,2; all unused fine edges are singleton blocks. Disjoint same-line intervals and different orientations/lines give a partition. Every edge of a retained path has anchor x; a singleton based at v has anchor floor(v/B). Each anchor has exactly 2B^2 fine edges and B^2 plaquette lower-left basepoints. A plaquette contains at most one edge of a given straight path, since its parallel edges lie on different lines; its four edges therefore lie in distinct blocks. If n_(i,j) counts plaquettes meeting block i and containing exterior fine edge j, then sum_i n_(i,j)=6: each fine edge belongs to two plaquettes, each with three other blocks. Restricted sums are at most six, and n_(P,j)<=2. Nonzero incidence connects anchors at distance at most one. These are UC01's actual fine-edge columns, restored here; a block-TV row sum can grow with B and is not used. Formula for W follows from the 8r anchors at radius r>=1 and the differentiated finite geometric series followed by its limit.

## FR02. Finite normalized source and covariance differentiation

**DEFINITION.** A fixed pattern sigma assigns every retained path either * or a sign. Unused singleton blocks are always unconstrained. On a finite union Lambda of whole blocks, use the product of uniform probability references on each allowed full support or prescribed parity fiber. Let E_Lambda be its free fine edges and P_Lambda all plaquettes meeting E_Lambda. For fixed fine exterior eta, define

\[
T_1=\sum_{e\in E_\Lambda}z_e,\qquad
T_2^\eta=\sum_{p\in P_\Lambda}\chi_p^\eta,\qquad
\nu_{g,\Lambda}^{\sigma,\eta}(dz)
=\frac{\exp(hT_1+JT_2^\eta)}{Z_{g,\Lambda}^{\sigma,\eta}}\lambda_\Lambda^\sigma(dz).
\label{eq:rg-fr-finite-law}
\]

The product form with factors 1+b z_e and 1+c chi_p has exactly this normalized law: the cosh factors are independent of z and cancel. All crossing plaquettes are in T_2^eta. A fully exterior plaquette is absent, and a parameter-dependent exterior would be a different problem.

**ESTABLISHED.** Every allowed finite atom is positive. The support and reference do not depend on g=(h,J), so its finite normalizer and each probability are analytic for real finite h,J. For any parameter-independent finite observable f, direct differentiation of the numerator and denominator gives

\[
\partial_h\nu f=\sum_{e\in E_\Lambda}\operatorname{Cov}_\nu(f,z_e),\qquad
\partial_J\nu f=\sum_{p\in P_\Lambda}\operatorname{Cov}_\nu(f,\chi_p^\eta).
\label{eq:rg-fr-finite-response}
\]

These identities count every free field and every touching plaquette once. Restricted-reference normalization changes neither statistic. The empty volume has its one-point law and zero derivatives; target statements below assume their whole target paths lie inside Lambda.

## FR03. Arbitrary single-field tilt on a fixed product fiber

**ESTABLISHED.** A block conditional is a positive product of coordinate fields, possibly conditioned on one total parity. Change one coordinate field by Delta while keeping the same support. Conditional on its sign, the law of the remaining coordinates is unchanged. If both signs are allowed, their probabilities differ by at most tanh(|Delta|/2): after writing the two fields symmetrically about their midpoint, the difference equals sinh(|Delta|)/(cosh(2u)+cosh(|Delta|)), maximized at u=0. If only one sign is allowed it is zero.

Maximally couple the selected sign. When it agrees, use identical remaining coordinates. When it differs on a fixed parity fiber, the remaining product laws have opposite parities and can be coupled at exactly one further discrepancy. For completeness, this opposite-parity assertion follows by induction: couple the last-bit marginals of the two conditioned products; differing last bits require identical prefix parity, while agreeing last bits require opposite prefix parity and use the induction coupling. The one-bit base case is deterministic opposite signs. Conditioning the prefixes on each last-bit pair gives the correct marginal prefixes in every branch, so mixing preserves both full marginals. Thus a parity-fiber tilt has expected Hamming cost at most 2tanh(|Delta|/2)<=|Delta|. An unconstrained block has cost at most tanh(|Delta|/2); a prescribed one-bit block has cost zero. The weaker common bound |Delta| will be used. Gluing successive finite couplings through their positive intermediate marginals proves the triangle bound for several coordinate tilts.

## FR04. Forced weighted stationary comparison

**ESTABLISHED.** Consider two finite positive specifications with the same interior supports and fixed fine exterior. Suppose, at identical outside coordinates, their block-i rows have a coupling of Hamming cost F_i. Split a comparison of rows at different configurations through the unperturbed row at the second configuration. The baseline conditional-product calculation gives cost at most 2c_* sum_j n_(i,j)1{x_j!=y_j}; FR03 supplies the additional F_i. This baseline splitting permits the second law to contain a finite inhomogeneous perturbation without assigning it an infinite-volume uniqueness theorem.

Use the same randomly selected block in both heat baths and these conditional couplings. Each finite marginal heat bath has the declared law as its unique stationary law: every admitted atom can be reached by a fixed sweep with a uniformly positive probability, since all finite conditional atoms are positive. Subtracting the resulting common positive minorization of that finite-step kernel contracts TV and proves uniqueness. The finite pair chain has a stationary law by a subsequential limit of its Cesaro averages; its marginals must be the two declared laws. If D_i is its expected block Hamming cost, stationarity of the i-coordinate cancels the common update probability 1/number_of_blocks and gives D_i<=2c_* sum_j n_(i,j)d_j+F_i, with d_j its fine discrepancy probability. Multiplying by w_i and using the six-column count and w_i<=e^tau w_(block(j)) yields

\[
S:=\sum_i w_iD_i
\le qS+\sum_iw_iF_i,\qquad
S\le\frac{\sum_iw_iF_i}{1-q}.
\label{eq:rg-fr-forced-comparison}
\]

With different fixed fine exteriors there is additionally q sum_(j in exterior boundary)w_(block(j))1{eta_j!=eta'_j} in the first inequality. This is the UC boundary term; arbitrary remote constraint changes are handled by conditioning outside a common interior and then integrating. There is no extra B factor or surviving update-rate factor in this calculation.

## FR05. Global parameter coupling in a finite volume

**ESTABLISHED.** Conditional on fixed exterior signs, each free coordinate's field is h+J a_e, with a_e the sum of its two incident exterior plaquette products and |a_e|<=2. Along a parameter change g to g' in Khat its field changes by at most u=|h-h'|+2|J-J'|. A block of |i| edges consequently has forcing F_i<=|i|u by FR03. For weights centered on one target anchor, FR01 gives sum_iw_i|i|<=2B^2 W, for any finite volume. Equation (FR04) therefore gives an actual coupling of the two finite laws with

\[
S\le\frac{2B^2W}{1-q}\bigl(|h-h'|+2|J-J'|\bigr).
\label{eq:rg-fr-global-parameter-cost}
\]

The same fixed fine exterior and same pattern are used at both parameter values. No total unweighted infinite-volume Hamming distance is asserted.

## FR06. Conditional path product and its oscillations

**ESTABLISHED.** Leave the target path P unconstrained and write Y_P=product_(e in P)z_e. Its conditional mean given all other blocks is exactly

\[
G_g=\prod_{e\in P}\tanh(h+Ja_e),\qquad |G_g|\le\rho^B.
\label{eq:rg-fr-path-product}
\]

This uses the straight-path one-edge-per-plaquette fact, including boundary plaquettes. Every factor along the compact parameter segment has magnitude at most rho and derivative of tanh at most one. Telescoping the product gives |G_g-G_g'|<=B rho^(B-1)u for the same exterior.

Flipping one exterior fine edge j flips at most n_(P,j) incident plaquette signs. A single such flip changes one local mean by at most 2c_*: it replaces a field u+J by u-J and the tanh difference is at most 2tanh J. Intermediate lists of changed plaquette signs still give fields with magnitude at most h_*+2J_*, even if they do not arise from a global configuration. Telescoping therefore gives

\[
\operatorname{osc}_jG_g\le2c_*n_{P,j}\rho^{B-1}.
\label{eq:rg-fr-path-oscillation}
\]

Because n_(P,j)<=2 and incident exterior anchors have distance at most one from P, any coupling satisfies |E G_g(X)-E G_g(Y)|<=4c_*e^tau rho^(B-1)S. This remains valid if P touches the finite boundary, whose fixed signs are identical in the parameter comparison.

## FR07. Actual exponentially small finite response

**ESTABLISHED.** Let m_(g,Lambda)^(sigma,eta)=nu_(g,Lambda)^(sigma,eta)Y_P for a free target P anchored at zero. Combine its conditional-product representation, FR05 and FR06 to obtain

\[
|m_g-m_{g'}|\le A_B\bigl(|h-h'|+2|J-J'|\bigr),\qquad
A_B=\rho^{B-1}\left[B+\frac{8c_*e^\tau W}{1-q}B^2\right].
\label{eq:rg-fr-response-amplitude}
\]

Taking difference quotients of these analytic finite expectations yields |partial_h m|<=A_B and |partial_J m|<=2A_B. The bounds are uniform over all finite whole-block volumes containing P, their fine exteriors and fixed patterns with P free. They are bounds on actual derivatives. Differentiating the separate value estimate |m|<=rho^B would not prove them. Since 0<rho<1, A_B tends to zero and is bounded over all positive integers B.

## FR08. Localized edge covariance bound

**ESTABLISHED.** Change only one free edge field h_e by Delta. Its sole owner block has F_i<=|Delta|, and all other rows have zero direct forcing. Centering weights at the target anchor gives S<=|Delta|w_(block(e))/(1-q). The target parity changes by at most twice its Hamming cost, hence |E Y_P differences|<=2S. Differentiate the finite perturbed expectation at Delta=0, using the same numerator/denominator calculation as FR02. Then

\[
|\operatorname{Cov}_\nu(Y_P,z_e)|
\le\frac{2}{1-q}z^{|\operatorname{anchor}(e)|_\infty}.
\label{eq:rg-fr-edge-covariance}
\]

If the field belongs to a pinned singleton, it is constant on the support and its covariance is zero. A field on a wholly exterior edge does not occur in the finite global derivative. A temporary local tilt is only a finite source used to derive this covariance estimate.

## FR09. Localized touching-plaquette covariance bound

**ESTABLISHED.** Change one plaquette coefficient J_p by Delta, with p meeting the free inventory. It affects one coordinate field, by magnitude |Delta|, in each of at most four free blocks. For crossing p only its free incidences contribute forcing. FR04 and the parity oscillation used in FR08 give

\[
|\operatorname{Cov}_\nu(Y_P,\chi_p^\eta)|
\le\frac{2}{1-q}\sum_{i\cap p\ne\varnothing,\ i\ {\rm free}}w_i
\le\frac{8e^\tau}{1-q}z^{|\operatorname{anchor}(p)|_\infty}.
\label{eq:rg-fr-plaquette-covariance}
\]

The plaquette anchor is its lower-left basepoint divided componentwise by B and rounded down. Every incident edge anchor differs by at most one, accounting for e^tau. A fully exterior plaquette is absent rather than an omitted derivative. This count permits arbitrary fixed fine boundaries and does not replace crossing factors with periodic or free-boundary factors.

## FR10. Uniform summable derivative tails

**DEFINITION.** For integer L>=0 put

\[
T(L)=\sum_{|x|_\infty>L}z^{|x|_\infty}
=\frac{8z^{L+1}[(L+1)-Lz]}{(1-z)^2}.
\label{eq:rg-fr-tail-sum}
\]

**ESTABLISHED.** Summing FR08 and FR09 with the exact 2B^2 edge and B^2 plaquette counts per anchor yields

\[
\sum_{e:\ |\operatorname{anchor}(e)|>L}|\operatorname{Cov}(Y_P,z_e)|
\le\frac{4B^2}{1-q}T(L),\qquad
\sum_{p:\ |\operatorname{anchor}(p)|>L}|\operatorname{Cov}(Y_P,\chi_p^\eta)|
\le\frac{8e^\tau B^2}{1-q}T(L).
\label{eq:rg-fr-covariance-tails}
\]

In a finite law the sums only include its actual sources. They remain bounded by these complete lattice counts, including any crossing plaquettes whose base anchors lie outside the free anchor set. The constants are uniform in all admissible finite volumes, patterns, boundaries and g in Khat. Formula for T(L) follows by summing 8rz^r from r=L+1; it tends to zero exponentially with the stated linear prefactor.

## FR11. Uniform convergence and continuity of each local covariance

**ESTABLISHED.** The hypotheses of the delivered UC construction hold uniformly on Khat: positivity, fixed product-fiber supports, the column bound, and q<1. For a finite set A of target anchors and a common interior A_n, its finite stationary boundary comparison and shell count give joint-cylinder TV at most C|A|B^2(n+1)z^(n+1). The count is 8|A|(n+1) shell anchors times 2B^2 edges, multiplied by q/(1-q). The constrained law nu_g^sigma is the unique limit of these finite normalized laws, independent of the fixed fine boundaries, and has the same comparison with any larger finite volume containing the common interior. This is UC08-UC10 with a common compact constant, not a new use of the obsolete 6Bc criterion.

For a fixed source edge or plaquette, take A containing its fine support anchors and the target. The joint-cylinder TV estimate controls every indicator of the target path state or parity together with that source edge or plaquette support. In particular it controls the joint sign-pair indicators and all three moments defining their covariance. Eventually its entire support is free in an exhausting volume, so its completed plaquette character is the original local character. For sign observables f,v, a change of their joint law by TV epsilon changes their covariance by at most 6epsilon: E(fv) changes by at most 2epsilon, and (Ef)(Ev) changes by at most 2epsilon+2epsilon. Thus each finite covariance converges uniformly in g, sigma and eta to Cov_(nu_g^sigma)(Y_P,z_e) or Cov_(nu_g^sigma)(Y_P,chi_p).

Each limiting covariance is continuous in g. Indeed choose a finite oracle with one fixed parameter-independent fine exterior; it has finitely many possible interior support patterns, each a finite analytic law. Its cylinder expectations approximate all infinite-pattern expectations uniformly on Khat. The uniform limit of these parameter-continuous functions is continuous for each fixed pattern. This also proves uniform parameter equicontinuity over patterns by first choosing a common oracle and then using its finite family of continuous functions. Passing the fixed-source bounds to these limits preserves FR08-FR10 in infinite volume.

## FR12. Actual C1 by uniform derivative sums and FTC

**ESTABLISHED.** For each fixed B and free target P, split the finite derivative sums in FR02 at source anchor radius L. For sufficiently large whole-block volumes, all near sources are present with their entire support. Their finitely many covariance terms converge uniformly by FR11. Both finite and infinite far sums have the common bounds FR10. First choose L to make those tails small and then the volume to make the finite sum small. This proves uniform convergence of the actual finite derivatives to the absolutely convergent sums

\[
D_hm_g^\sigma=\sum_{e\in E(\mathbb Z^2)}\operatorname{Cov}_{\nu_g^\sigma}(Y_P,z_e),\qquad
D_Jm_g^\sigma=\sum_{p\in P(\mathbb Z^2)}\operatorname{Cov}_{\nu_g^\sigma}(Y_P,\chi_p).
\label{eq:rg-fr-infinite-response}
\]

At this stage D denotes the candidate derivative sum. The convergence of the finite derivative sums and the tail domination are uniform on the entire enlarged compact rectangle Khat; the following coordinate-segment argument proves actual differentiability on its interior, which contains K. It is continuous in g because its finite near sums are continuous and its tails converge uniformly. The underlying means converge uniformly by UC. Along any coordinate segment contained in the interior of Khat, the finite fundamental theorem of calculus expresses the finite mean increment as the integral of its finite derivative. Uniform derivative convergence lets that integral converge: its error is bounded by segment length times the uniform derivative error. Passing the means gives the same identity for m_g^sigma and Dm. Continuity of D then shows that the difference quotient of the integral tends to D at every g on the segment. Hence D is the actual partial derivative. Continuous partial derivatives imply C1 by splitting a two-coordinate increment into two coordinate segments and using continuity to control the remainder.

Consequently every free target parity mean is genuinely C1 on D, with convergence of its finite means and first derivatives uniform on K, over all patterns and arbitrary fixed fine boundaries. Its actual derivative bounds remain |partial_h m|<=A_B and |partial_J m|<=2A_B by FR07. No infinite partition function is differentiated, no infinite-event probability is divided by, and no C0 or Lipschitz theorem is substituted for this derivative-limit proof.

## FR13. Counted spatial continuity of the actual derivatives

**ESTABLISHED.** Suppose two fixed patterns sigma and sigma' both leave target P free and agree on all blocks anchored in Q_R. They may differ between *,+,- outside Q_R. For R>=2 put L=floor(R/2)-1 and n=R-L-1. A source edge anchored in Q_L and target P occupy at most two anchors. A source plaquette anchored in Q_L and P occupy at most five anchors, all in Q_(L+1). Their radius-n neighborhood lies in Q_R. FR11 therefore bounds their joint-cylinder TV by 5CB^2(R-L)z^(R-L). This comparison is valid for different remote supports: condition both laws outside that common interior, compare their finite rows, and integrate. No coupling of incompatible interior fibers is asserted.

Each near covariance changes by at most 30CB^2(R-L)z^(R-L). There are 2B^2(2L+1)^2 near edges and B^2(2L+1)^2 near plaquettes. Add the two far tails of FR10 to obtain

\[
D_h(B,R)=60CB^4(2L+1)^2(R-L)z^{R-L}
+\frac{8B^2}{1-q}T(L),
\label{eq:rg-fr-h-spatial-tail}
\]

\[
D_J(B,R)=30CB^4(2L+1)^2(R-L)z^{R-L}
+\frac{16e^\tau B^2}{1-q}T(L).
\label{eq:rg-fr-J-spatial-tail}
\]

These bound the respective absolute derivative differences. For R=0,1 define D_h(B,R)=2A_B and D_J(B,R)=4A_B instead. For every R the respective bounds may be replaced by min(D_h,2A_B) and min(D_J,4A_B). Both B^4 and the polynomial-radius factors are retained. Since L grows as R/2 and R-L grows as R/2, any fixed polynomial multiple of D_h or D_J is summable against exp(lambda R) when 0<lambda<tau/2. This follows directly from the ratio test applied to the displayed polynomial times geometric terms; no B-independent prefactor is inferred from it.

## FR14. Quantified first-derivative finite-oracle convergence

**ESTABLISHED.** The same D_h(B,R),D_J(B,R) compare a finite whole-block oracle containing Omega_(Q_R), with matching interior pattern and arbitrary fixed fine exterior eta, against the infinite law. For each near source in FR13 its complete plaquette support lies in Q_(L+1), so it is genuinely an interior source in the oracle; use the finite/infinite joint-cylinder comparison of FR11. Remaining finite sources, including crossing plaquettes, and the remaining infinite sources each obey FR10. The identical near count and two-tail sum prove the assertion. A larger or irregular whole-block volume is allowed if it contains Omega_(Q_R). Constants do not depend on its exterior signs.

For target means, the value difference is also bounded by V_B(R)=min(2rho^B,2CB^2(R+1)z^(R+1)). For derivatives use the minima described after FR13. These comparisons converge to zero uniformly over B as well as patterns, boundaries and K: first choose B_0 so that the amplitude bounds 2A_B,4A_B and 2rho^B are small for B>B_0; the remaining finite list of B values has a common radius from the explicit spatial tails. This is an anchor-radius oracle statement. A fine volume that cuts paths or has no fixed anchor margin does not satisfy its premise.

## FR15. C1 full finite coarse rows on every exterior

**ESTABLISHED.** A free path's parity probability is (1+s m)/2. Since |m|<=rho^B, both signs have probability at least (1-rho^B)/2. For a cell, reveal its first path parity a, then the second b. Finite conditioning on the first free path restricts exactly that fiber; by UC11 uniqueness it produces the pattern with the first path prescribed. Thus, for every exterior or signed-or-absent pattern away from the target,

\[
p_g(a,b)=\frac{1+a m_1(g)}2\frac{1+b m_2^a(g)}2,
\qquad
\frac{(1-\rho^B)^2}{4}\le p_g(a,b)\le\frac{(1+\rho^B)^2}{4}.
\label{eq:rg-fr-cell-row}
\]

Both means are actual C1 functions by FR12. This proves C1 of the complete positive four-state row. Repeating the same finite sequential conditioning for 2|Delta| target paths proves C1 of every finite-set conditional atom, with lower bound [(1-rho^B)/2]^(2|Delta|), without discarding dependencies between target paths. Normalization and pointwise consistency are those of the existing full constrained specifications; taking these actual derivatives preserves the finite normalization and consistency equations by the ordinary finite product rule. Uniform finite-oracle C1 convergence follows by the same product rule and FR14. The construction applies to arbitrary infinite exterior patterns, even those null under the original pushed law.

## FR16. One-cell score and log-odds amplitudes

**ESTABLISHED.** A Bernoulli factor's derivative log is s partial_u m/(1+s m). Its denominator is at least d=1-rho, uniformly in B and all prescribed preceding paths. Equation (FR15) therefore gives

\[
|\partial_h\log p_g(a,b)|\le\frac{2A_B}{d},\qquad
|\partial_J\log p_g(a,b)|\le\frac{4A_B}{d}.
\label{eq:ig-fr-score-amplitudes}
\]

For log odds ell_g(a,b)=log p_g(a,b)-log p_g(+,+), the bounds are respectively 4A_B/d and 8A_B/d. The same statements hold for densities relative to normalized four-state counting, since their additional log 4 is parameter-independent. Direction v=(v_h,v_J) has |D_v log p|<=2A_B(|v_h|+2|v_J|)/d. These are first derivatives only; smooth invertible Fisher geometry is not inferred.

## FR17. Spatial continuity of the actual score and log-odds derivatives

**ESTABLISHED.** Take two patterns agreeing through radius R, with both paths of the target cell free. In the second Bernoulli factor, prescribe the same revealed first parity in both patterns, so their radius-R agreement is retained. The corresponding means differ by at most

\[
V_B(R)=\min\{2\rho^B,2CB^2(R+1)z^{R+1}\}.
\label{eq:rg-fr-value-spatial-tail}
\]

For real numbers m,m' in [-rho^B,rho^B], and their actual derivatives a,a', subtract the ratios exactly to obtain
|a/(1+s m)-a'/(1+s m')|<=|a-a'|/d+|a'| |m-m'|/d^2.
Use FR13 and the amplitude a_h=A_B,a_J=2A_B. The derivative of one log probability consequently has variation at most 2D_u/d+2a_u V_B/d^2, and the log-odds derivative has variation at most

\[
H_h(B,R)=\frac{4D_h(B,R)}d+\frac{4A_BV_B(R)}{d^2},\qquad
H_J(B,R)=\frac{4D_J(B,R)}d+\frac{8A_BV_B(R)}{d^2}.
\label{eq:rg-fr-log-derivative-tail}
\]

The minima from FR13 may be used inside these formulas. The entire bounds may also be capped respectively by 8A_B/d and 16A_B/d, the difference of two log-odds derivative amplitudes. This supplies actual derivative continuity with explicit B and radius factors. For fixed B the tails are summable with every polynomial shell count and exp(lambda R) for lambda<tau/2. The same estimates apply to finite/infinite oracle comparisons by FR14. They do not follow by differentiating a TV bound; the exact derivative ratios and the proved covariance sums are the load-bearing inputs.

## FR18. Finite actual-marginal Fisher bound supplied to the density lane

**ESTABLISHED.** For any of these four-state conditional rows, the score is centered by differentiating its finite normalization. Its Fisher matrix is the expectation of ss^T in the natural (h,J) coordinates, hence is positive semidefinite. Equation (FR16) gives the operator bound

\[
0\preceq I_{\rm cell}\preceq\frac{20A_B^2}{d^2}\operatorname{Id}_2.
\label{eq:ig-fr-conditional-fisher-bound}
\]

Indeed its trace is at most (2A_B/d)^2+(4A_B/d)^2 and every eigenvalue of a positive semidefinite matrix is at most its trace. For an actual finite full-law coarse marginal, order its cells. Conditional on preceding cells, each next row is the corresponding fixed finite parity pattern with all unobserved paths absent, by UC11. The finite marginal score is the sum of these row scores. For two distinct ordered increments, condition on the past of the later increment; its conditional mean is zero and the earlier increment is measurable there, so their matrix cross expectation is zero. Summing the conditional Fisher matrices gives

\[
0\preceq\frac{I(\mu_{B,\Delta})}{|\Delta|}
\preceq\frac{20A_B^2}{d^2}\operatorname{Id}_2,
\qquad 0<|\Delta|<\infty.
\label{eq:ig-fr-marginal-fisher-bound}
\]

This bound uses the actual marginal, not a chosen finite-volume Gibbs approximation. The right side tends to zero with B. Existence of the actual square-marginal Fisher-density limit and the derivative norm of the complete interaction are separate root-owned assemblies using FR17; the finite bound by itself is not a density existence proof.

## Boundary, zero, symmetry and scope ledger

**ESTABLISHED.** At B=1 an unconstrained path is one bit and a prescribed path is deterministic; the remaining-coordinate coupling in FR03 is used only for at least two coordinates. All formulas above are valid at B=1. Finite zero covariances or zero parameter increments create no division. No finite permitted atom has zero mass; forbidden atoms lie outside the fixed support. Infinite null patterns are defined by UC limits. A prescribed target parity itself is constant and has zero derivative; the exponentially small free-target statements are only for targets left unconstrained. The empty coarse set has probability one and zero score.

**ESTABLISHED.** In the separate exact J=0 control, constrained blocks are independent product-fiber laws and a free target mean is (tanh h)^B. Its h derivative is B(tanh h)^(B-1)sech^2 h. This does not assert that its transverse J derivative is zero; a perturbation can induce correlations. The present compact-uniform theorem is stated strictly inside D and does not infer differentiability at h=infinity, J=atanh(1/12), hard zero factors or moving supports. A zero-c spatial-bound formula need not be recovered by setting q=0 in a chosen tau expression.

**ESTABLISHED.** Translating by a coarse lattice vector transports fine edges by B times that vector, their reference and the fixed pattern. Finite laws and their derivatives transport exactly; uniqueness and uniform limits preserve this covariance. Dressed observables and the existing independent uniform raw-frame lift remain gauge compatible because the lift and path channel are parameter-independent. These parameter derivatives do not introduce a Fisher connection on the structural base.

**NOT-CLAIMED.** No higher derivative, pressure-Hessian identity, inverse Fisher metric, scalar Fisher-curvature limit, continuum or critical theorem is supplied here. A parameter-dependent learned channel adds its channel score and is outside ordinary fixed-channel information contraction. Rank may be lost under blocking: a binary output has at most one independent score direction at a point. A Riemannian metric or inverse requires an identifiable regular chart and further smoothness. Existing finite curvature, base, holonomy inference and metric-quotient constructions keep their separate scopes. No curvature scalar is appended automatically to the normalized VFE. No practical complexity guarantee follows from these estimates, and no numerical evidence is substituted for their quantifiers.
