<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","schema_version":"rigorous-theory-search/v1","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->
# Independent response and marginal Fisher-density reconstruction

Revision 1, 2026-09-09. Only the new frozen problem-contract.json was opened before this initial record. Its file SHA256 is be3bafac3ea8a6f230e4b2c5804834027ca37213c91520b4737445ad2b4d63f8 and its canonical target digest was independently recomputed as 5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec. No new intake, author, root or worker draft, proposed mechanism or source was read. The preceding admitted UC/UP definitions and proofs and SPEC are retained inputs from this continuous task. The same model family and filesystem limit independence; the complete calculations below, not agreement or procedural labels, carry the proposed argument. No new external theorem is imported, no scientific code/test is run, and no ledger state is assigned.

The construction below uses actual finite covariance identities and uniform derivative convergence. It does not differentiate a C0 bound. The Fisher-density existence argument uses actual marginal conditional-score chains, not a pressure Hessian or an unproved squared boundary-score estimate.

## IFR01. Compact constants and the finite localized perturbation

Write the parameter vector as u=(h,J). Fix the contract's compact rectangle K. Choose a larger closed rectangle K1 inside 0<h<infinity, 0<J<atanh(1/12), with K in its interior and a positive margin for a neighborhood of K. Let h_1,J_1 be its upper endpoints. Define

    cbar=tanh(J_1), rho=tanh(h_1+2J_1)<1,
    s=(1/2)log(1/(12cbar))>0,
    q=12cbar exp(s)=sqrt(12cbar)<1,
    t=exp(-s), C_U=16q/(1-q),
    G_s=1+8t/(1-t)^2,
    m=(1-rho)^2/4>0.

All constants below depend on K1, not B, a volume or an exterior pattern. Work first with finite unions V of whole path/singleton blocks, fixed allowed supports and parameter-independent fine exteriors. Natural-coordinate densities are proportional to exp(h T_h+J T_J), where T_h sums every free edge sign and T_J sums every plaquette sign whose factor touches a free edge. The factors 1+bz and 1+c tau differ from these exponentials only by parameter-dependent scalar cosh factors; centering removes them from normalized scores. Boundary-crossing plaquettes must remain in T_J.

The UC finite conditional product coupling extends to heterogeneous local fields and plaquette couplings bounded by h_1,J_1. This extension requires no homogeneity: a conditional whole path still has one independent sign factor per edge before its own parity restriction; a differing exterior edge changes a plaquette tilt of magnitude at most J_1; the six-column incidence and spatial weight proof use cbar. Finite positivity and the paired stationary construction remain valid. This observation is needed to localize a perturbation rather than applying a homogeneous-only theorem to a different family without explanation.

Perturb just one edge field by delta. The affected bit's conditional log odds change by 2delta, so its TV changes by at most |delta|/2: the derivative of (1+tanh v)/2 has absolute value at most 1/2. On a fixed parity fiber the expected fine-Hamming coupling cost is at most |delta|, by the UC one-bit opposite-parity remainder construction. An absent parity costs no more, and a prescribed singleton costs zero. This creates an additive forcing of at most |delta| at the one block containing that edge.

Perturb just one plaquette coefficient by delta. It adds a single-coordinate field of magnitude delta to at most four different conditional block rows. The same argument gives forcing at most |delta| at each of those blocks. Couple the two perturbed finite heat baths with the same block update index. Their stationary weighted cost S obeys

    S <= q S + |delta| sum_(blocks hit by the local source) w_i.

The source term is not multiplied by a volume or by B. The usual 1/n update factor cancels on both sides; q is the old-disagreement propagation, while the displayed new forcing is added separately. Take delta sufficiently small within the margin provided by K1. This derives the localized perturbation bound from the finite chain and does not assert smoothness of an infinite field in advance.

## IFR02. Covariance localization and global source counts

Let f be a bounded observable with |f|<=1 supported on a target coarse anchor cell, including its retained fine paths. Use weights w_i=exp[-s dist(anchor(i),{0})]. The expected difference of f is at most 2S. Divide the finite perturbation inequality by |delta| and use the exact derivative of a finite normalized positive exponential family:

    partial_a E_V f = Cov_V(f,T_a),

where T_a is one edge sign or one plaquette sign. A source edge at anchor x contributes one weight exp(-s||x||). A source plaquette anchored at x contributes at most four block weights, each bounded by exp(s)exp(-s||x||). Hence both source types obey

    |Cov_V(f,T_a)| <= M exp[-s||anchor(a)||],
    M=8exp(s)/(1-q).

The plaquette anchor is the floor of its fine lower-left basepoint divided by B; all its block anchors lie within one of it. These constants also bound covariances when f is a coarse-state indicator. Outside finite volumes, extend fixed fine exteriors to full configurations. An all-exterior source is constant and has covariance zero. A crossing plaquette source retains precisely its actual factor, so every finite response can be written using the same entire-lattice source index set with zero covariance for irrelevant sources.

Each coarse anchor contains exactly 2B^2 edge sources and B^2 plaquette sources. Thus at most 3B^2 sources have a given anchor, and

    sum_a |Cov_V(f,T_a)| <= 3M B^2 G_s.

This bounds the l1 norm of the pair of homogeneous derivatives (partial_h,partial_J), since its two components are the separate edge and plaquette sums. The geometric identity G_s=sum_(x in Z^2)exp(-s||x||) follows from 8r sites on shell r>=1. The same source count holds for the actual finite field with crossing plaquettes, because it is a subset of this common entire-lattice inventory.

For any r>=0 define the explicit tail

    T_s(r)=8t^(r+1)[(r+1)/(1-t)+t/(1-t)^2].

Then the absolute response from anchors outside Q_r is at most 3M B^2 T_s(r). No derivative of an infinite normalization is taken.

## IFR03. Actual C1 limits and an explicit derivative spatial modulus

Consider two finite or infinite candidate constrained laws whose patterns and fine free interior agree throughout the whole-block inventory anchored in Q_R around the target. For a local source with anchor in Q_r, its fine support uses at most four anchors within Q_(r+1). Along with the target, at most five anchor cells are needed. Put L=R-r-1>=0. The UC joint-target comparison on one common stationary coupling bounds the relevant joint TV by

    5 C_U B^2 (L+1)exp[-s(L+1)].

For |f|,|T_a|<=1, a difference of these covariances is at most six times the joint TV: one product expectation costs 2TV and the difference of the product of the two expectations costs at most 4TV. There are at most 3B^2(2r+1)^2 near sources. The difference of the two far covariance tails costs at most 6M B^2 T_s(r). Therefore the l1 difference of the two response vectors is bounded by

    Xi_B(R;r)=90 C_U B^4 (2r+1)^2(L+1)exp[-s(L+1)]
              +6M B^2 T_s(r).

For R>=1 take r=floor((R-1)/2) and L=R-r-1. For R=0 use the valid bound 6M B^2 G_s. One convenient uniform envelope, valid for all integer R>=0, is

    Xi_B(R) <= C_X B^4(R+1)^3 exp(-sR/2),
    C_X=90C_U+48M/(1-t)^2+6M G_s.

Indeed both r+1 and L+1 are at least R/2; 2r+1<=R and L+1<=R+1. The far-tail expression is at most 8(R+1)exp(-sR/2)/(1-t)^2. The final term in C_X also covers R=0. Constants are deliberately conservative but counted.

To establish derivatives rather than assume them, first apply the preceding bounds to finite-volume covariances only. The UC finite joint-cylinder limits make each fixed-source covariance converge uniformly on K, in exterior patterns and fine boundary choices with receding common interiors. Uniform summable tails then make the entire finite homogeneous derivative vectors converge uniformly. The bound Xi_B controls the difference after passing to the limit and also the finite-volume approximation error when the target's radius-R whole-block interior is present.

Every finite normalized row is smooth on a neighborhood of K. Its values and first derivatives now converge uniformly. Along each coordinate segment contained in that neighborhood, write the finite fundamental-theorem-of-calculus identity and pass the uniform limit under its ordinary one-dimensional integral. The limit has the stated partial derivative, and that derivative is continuous as a uniform limit of finite continuous derivatives. This gives actual C1 rows on an open neighborhood of K at every parameter, not merely almost-everywhere differentiability or a Lipschitz envelope. The construction is uniform over every fixed signed-or-absent pattern and fixed fine exterior; it includes infinite null patterns through the already constructed normalized limits.

The extension to finite target sets uses their finite anchor inventory and the same covariance counts with its explicit size/geometry. For the one-cell conditional and the partial-past kernels used below, the displayed constants suffice. Parameter-dependent exterior values, carriers or constraints are not part of this argument.

## IFR04. A small first derivative from conditional covariance, not differentiation of rho^B

Let Y be one whole free target path parity and let R denote all other fine block states. Given R, the target path has B independent signs with means m_e(R), each of absolute value at most rho. Thus g(R)=E[Y|R] has |g|<=rho^B. For a source statistic T_a not meeting that path, it is R-measurable and

    Cov(Y,T_a)=Cov(g(R),T_a),
    |Cov(Y,T_a)|<=2rho^B.

For an edge or plaquette source meeting the path, no plaquette meets it twice. Write T_a=A(R)z_e, where |A|=1. Conditional covariance is

    Cov(Y,T_a|R)=A(R)(1-m_e(R)^2) product_(f!=e)m_f(R),

so its absolute value is at most rho^(B-1). The covariance of the two conditional means is at most 2rho^B. There are B edge and 2B plaquette sources meeting the path. Consequently their total contribution to the l1 homogeneous response is at most 9B rho^(B-1).

For all other sources combine the preceding amplitude with IFR02's localization using min(a,b)<=sqrt(ab). Sum at most 3B^2 sources per anchor. Uniformly in every permitted pattern, exterior and finite response volume,

    ||grad_u E Y||_1 <= D_B
       :=9B rho^(B-1)+3sqrt(2M) G_(s/2) B^2 rho^(B/2)
       <= C_D B^2 rho^(B/2),
    C_D=9/rho+3sqrt(2M)G_(s/2).

This is a bound on the exact covariance derivative. It is not obtained by differentiating the inequality |E Y|<=rho^B. The apparent rho^-1 is harmless for the fixed compact constants, where rho>0.

The derivative of either target sign probability is at most D_B/2 in l1 norm. A four-state cell atom factors as its first path probability times its second path probability conditional on the first. The additional finite parity conditioning is another fixed admitted pattern, so both derivative bounds apply. Product differentiation gives l1 derivative at most D_B for each four-state atom. The same reasoning applies to all-pattern rows, partially observed rows and finite-volume approximations with the whole target paths free. Every atom is at least m=(1-rho)^2/4. Thus each row score has norm at most D_B/m and each vacuum-relative log-odds derivative has norm at most 2D_B/m.

## IFR05. Counted C1 interaction norm and uniform depth decay

Let Omega_B(R)=min(1,C_U B^2(R+1)exp[-s(R+1)]) be the C0 one-cell comparison bound. For two rows p,pbar whose exterior patterns agree through radius R, IFR03 and IFR04 give

    ||grad p_x-grad pbar_x||_1<=Xi_B(R),
    ||grad log p_x-grad log pbar_x||_1
       <=Xi_B(R)/m+D_B Omega_B(R)/m^2.

Subtract two log probabilities for the vacuum odds. A sufficient envelope is

    L'_B(R)=C_L B^4(R+1)^3exp(-sR/2),
    C_L=2C_X/m+2C_D C_U/m^2.

The same quantity is also at most 4D_B/m by the two score-amplitude bounds. This minimum can be used to make the row derivative approximation uniform over B as well as compact parameters: its geometric-mean envelope has a polynomial B prefactor times rho^(B/4), whose supremum over all B is finite. The C0 approximation is similarly bounded by the minimum of its spatial tail and its exponentially small row amplitude. Thus no unbounded B factor is silently treated as a uniform constant.

Use the existing fixed (+,+) vacuum and lexicographic-past convention. The base energy e_(x,0) and every truncated-past energy e_(x,r) are C1 by IFR03. For shell r>=1, their derivative increment obeys both bounds

    ||grad Phi_(A_xr)||_1 <=4D_B/m,
    ||grad Phi_(A_xr)||_1 <= C_L exp(s/2) B^4 r^3 exp(-sr/2).

The latter applies the radius-(r-1) derivative modulus, preserving its index. Geometric-mean interpolation gives

    ||grad Phi_(A_xr)||_1
       <=C_P B^3 rho^(B/4) r^(3/2)exp(-sr/4),
    C_P=sqrt[(4C_D/m) C_L exp(s/2)].

Choose the one common exponential norm with lambda=s/16. Each support has diameter at most 2r, and at most (2r+1)^2 translates contain zero. Since r^(3/2)<=r^2 for r>=1,

    sum_(A containing0) exp(lambda diam A)||grad Phi_A^(B)||_1
       <= E'_B
       :=(2C_D/m)B^2rho^(B/2)+C_P S_4 B^3rho^(B/4),
    S_4=sum_(r>=1)(2r+1)^2 r^2 exp(-sr/8)<infinity.

This explicit positive series is a polynomial times geometric sum and provides an equally explicit spatial tail by restricting r>N. Every factor is independent of B and volume. A pure exponential-in-B envelope follows with v=rho^(1/8), using the convergent sums sum_n n^2 v^n and sum_n n^3 v^n to bound the polynomial factors: E'_B<=C_K rho^(B/8) for a finite displayed-series constant C_K. No infinite shell is deleted.

The value norm at this lambda is controlled by the preceding UP theorem, uniformly on the present compact since all its constants can use cbar,rho and s. Its hypotheses are satisfied because lambda is smaller than the available value-norm exponent. Uniform summation of the termwise first derivatives and the coordinate FTC identity prove that u maps to the complete fixed-convention Phi^(B)(u) as an actual C1 map into this common normed interaction space. The derivative norm tends to zero compact-uniformly with B, and so does the original value norm. This is not inferred from C0 convergence alone.

## IFR06. Partial-past kernels and actual finite marginal scores

For the Fisher-density construction a full-exterior Gibbs row is not the desired predictive row. For a finite set S of preceding coarse cells, define k_(x,S)(a|y_S) as the actual conditional law under mu_B of the cell at x given Y_S=y_S. Finite support is positive. By the admitted finite parity-conditioning identity it equals the target row of the constrained fine law with exactly those S path parities prescribed and every other retained path unprescribed. This is one of the signed-or-absent patterns covered by IFR03-IFR04, so its actual parameter derivative has the same bounds.

For the infinite lexicographic past P_x={y:y<x}, prescribe all its path parities and leave the future unprescribed. Finite-past conditioning windows exhaust P_x. Their values and first derivatives converge uniformly by the same every-pattern comparison. This constructs an everywhere C1 predictive row k_(x,infinity), distinct from the vacuum-future hybrid used to define the canonical potential. Testing against finite past-cylinder events and passing the uniform limit identifies it as a version of the actual conditional distribution given the whole past. No infinite past event is divided by its probability.

For a square Lambda_L, enumerate cells in increasing lexicographic order. Its actual marginal factors into the finite predictive rows with S equal to preceding cells inside the square. Differentiating this finite identity gives

    score_(Lambda_L)=sum_(x in Lambda_L) s_(x,L),
    s_(x,L)=grad log k_(x,preceding Lambda_L)(Y_x|Y_preceding).

Each increment has conditional mean zero because sum_a grad k(a|history)=0. If x precedes y, s_x is measurable with respect to y's finite preceding history, so E[s_x s_y^T]=0 by conditioning. Therefore the actual finite Fisher matrix is exactly

    I_(B,L)=sum_(x in Lambda_L) E_muB J_(x,L),
    J_(x,L)=sum_a [grad k_a grad k_a^T]/k_a.

This is an identity for the true full-law marginal, not a surrogate free-boundary Hamiltonian and not a sum of spatially independent scores. It requires only the actual C1 finite marginals just proved and fixed positive carriers.

## IFR07. Existence and decay of the marginal Fisher matrix per coarse cell

Every predictive atom is at least m and its gradient l1 norm is at most D_B. Hence its local Fisher matrix is positive semidefinite with operator norm at most

    F_B=4D_B^2/m <= (4C_D^2/m) B^4rho^B.

For two predictive rows agreeing on the radius-R observed past, the exact difference of vv^T/p and ww^T/pbar is bounded by

    (||v||+||w||)||v-w||/m+||w||^2|p-pbar|/m^2.

Sum their four atoms to obtain the explicit local Fisher modulus

    T_B(R)=8D_B Xi_B(R)/m+4D_B^2 Omega_B(R)/m^2
       <= C_F B^6rho^(B/2)(R+1)^3exp(-sR/2),
    C_F=8C_D C_X/m+4C_D^2 C_U/m^2.

The two rows may be a finite-prefix predictor and the infinite-past predictor. Coarse translation covariance makes E_muB J_(x,infinity) independent of x. Define the matrix

    I_B(u)=E_muB J_(0,infinity).

This expectation is finite, positive semidefinite and bounded in operator norm by F_B. To prove it is the actual density limit, take all cells of Lambda_L at least R from its boundary. Their finite preceding set contains the entire radius-R lexicographic past, so their Fisher matrices differ from the infinite-past one by at most T_B(R). The remaining cell fraction is at most 4R/L for R<L/2. Their two matrices are each bounded by F_B. Thus

    ||I_(B,L)/L^2-I_B|| <= T_B(R)+8R F_B/L.

First fix R and send L to infinity, then send R to infinity. This proves a limit, not merely a limsup, for every compact parameter and every B. An explicit simultaneous choice such as R=floor(sqrt(L)) for sufficiently large L also gives a quantitative error. The error is compact-uniform. Since the suprema of B^6rho^(B/2) and B^4rho^B are finite, the displayed bound is even uniform over all integer B; those suprema can be bounded by their convergent positive geometric-power sums.

The actual per-cell marginal Fisher matrix satisfies

    0 <= I_B(u) <= F_B Identity_2,
    sup_(u in K)||I_B(u)|| <= (4C_D^2/m)B^4rho^B ->0.

The C1 predictive kernel and its compact-uniform spatial approximations also make I_B(u) continuous: approximate J_(0,infinity) uniformly by finite-past continuous cylinder functions, whose expectations are continuous through the finite marginal response theorem. No second derivative of pressure is needed. This establishes the stated Fisher tensor density, without asserting it has rank two or an inverse.

## IFR08. Rank, chart covariance and integer composition factors

The matrix is positive semidefinite by its score-square representation. It can be singular. For example a finite spatial law with one free edge has T_h=z and T_J=A z plus any constant, so the two centered natural scores are linearly dependent and its two-parameter Fisher matrix has rank at most one; an empty variable law has rank zero. A finite positive score tensor is not automatically an identifiable Riemannian chart, and decay to zero supplies no stable inverse or curvature limit. A separate proof of regular local identifiability and the necessary higher smoothness is required before constructing Fisher curvature.

For a differentiable parameter chart u=u(v), scores satisfy S_v=(D_v u)^T S_u and Fisher transforms as I_v=(D_v u)^T I_u(D_v u). In particular natural to bounded coordinates has D_(b,c)(h,J)=diag((1-b^2)^(-1),(1-c^2)^(-1)). The Jacobian is controlled on each compact but can diverge at its excluded boundary. A parameter chart change is not a gauge change or a base metric.

For fixed geometric C_a, the retained a-block square of side L depends only on the source B-law square of side aL, when cells contain their two positively oriented outgoing edges. All B-law cells used by those a-paths have anchors in that aL square. Finite fixed-channel Fisher contraction therefore gives

    I_(aB,L) <= I_(B,aL).

The actual density limits just proved imply

    I_(aB) <= a^2 I_B.

There is no per-coarse-cell contraction inequality with that a^2 deleted. Per-original-fine-cell information obeys I_(aB)/(aB)^2 <= I_B/B^2. Composition is in the same natural coordinates unless the stated Jacobians are applied. The integer path channel itself remains parameter-independent and its exact composition precedes differentiation.

## IFR09. Exact finite scores and channel loss

On a fixed finite carrier with positive C1 masses p_u(x), define S(x)=grad log p_u(x), with E S=0. A fixed stochastic kernel K(y|x) has q_u(y)=sum_x p_u(x)K(y|x). On its fixed reachable support,

    grad log q_u(y)=E[S(X)|Y=y].

This follows by differentiating a finite sum, including every source state and channel weight. The finite Fisher identity is the conditional second-moment decomposition

    I_X-I_Y=E[Cov(S(X)|Y)] >=0.

Equality means the score is Y-measurable at this parameter; it need not imply statistical sufficiency of the channel for an entire family. For instance a conditional family that varies only quadratically in one parameter can have zero lost score at a point while changing nearby. If all parameter derivatives of the conditional law vanish throughout a connected regular parameter domain, the stronger parameter-independence conclusion needs that extra all-parameter premise.

For fixed X->Y->Z kernels, the tower property gives the direct pushed score E[S_X|Z] and exact additive Fisher loss (I_X-I_Y)+(I_Y-I_Z). Support is the actual reachable support, and zero-probability rows must not be normalized by an invented default. If the kernel depends on u, the correct projected score includes the kernel score:

    S_Y=E[S_X+grad log K_u(Y|X)|Y],

on positive joint transitions, or equivalently the direct derivative term sum_x p_u(x) grad K_u(y|x). The fixed-channel loss identity comparing only S_X generally fails for moving kernels. Parameter-dependent deterministic carrier changes need their own differentiability/support construction and are not included.

## IFR10. Source-faithful finite spatial adapter and posterior normalization

For a positive finite spatial field on n free signs with every touching plaquette included, enumerate the exact normalized mass p. Compute integer sufficient statistics T_h=sum_free z and T_J=sum_touching plaquettes tau. Natural scores are

    S_h=T_h-E_p T_h, S_J=T_J-E_p T_J.

At rational b,c, both masses and centered scores are rational although h,J themselves need not be rational numbers. The raw product representation contributes constants -n b and -N_p c to the unnormalized natural derivatives; normalization cancels them. Crossing plaquettes cannot be dropped. Any fixed finite set of tangent directions in these two parameters is a declared linear combination of these two score columns; the existing finite primitive's admitted direction count and carrier limits must be checked when source is opened. No duplicate generic Fisher engine is proposed here.

For a normalized finite observation likelihood ell_u(o|x), the generative joint score is S_joint=S_prior+grad log ell. At a selected observation with positive evidence, the evidence score is E[S_joint|o] and the posterior score is

    S_post=S_joint-E[S_joint|o].

The retained joint under a fixed channel has the conditional expectation of the joint score; the retained posterior similarly projects the centered posterior score, with the evidence term kept. These are separate distributions and normalizers. A recognition family has its own score and cannot use the generative score as a substitute.

For a fixed recognition law Q, the exact finite negative ELBO satisfies F(Q;o)=D(Q||p(.|o))-log p(o), and its generative-parameter derivative is -E_Q S_joint. If Q=Q_u also changes, differentiation adds E_Q[S_Q log(Q/p_joint)]; E_Q S_Q=0 removes only the derivative of Q's normalization, not this term. No curvature scalar is created by these identities.

## IFR11. Quadratic KL, nonlinear pressure correction and nonclaims

For a finite strictly positive C1 family on a fixed carrier, p_(u+delta)=p_u+D p_u delta+o(||delta||). The finite mass-coordinate Taylor expansion of KL around p_u has zero linear term on the normalized tangent space and Hessian diag(1/p_u). Thus the local quadratic KL term is (1/2)delta^T I_u delta+o(||delta||^2). This finite interpretation does not justify a uniform infinite-carrier KL Taylor limit, which is not asserted here.

If an additionally C2 finite Hamiltonian family has p_u proportional to exp(-H_u) relative to a fixed reference, then

    I_ij=Cov(partial_i H,partial_j H),
    partial_ij log Z=I_ij-E[partial_ij H],
    I_ij=partial_ij log Z+E[partial_ij H].

The centered score is -partial H+E partial H. A linear fine natural-parameter Hamiltonian has zero second-Hamiltonian derivative. The generated coarse canonical Hamiltonian need not be linear, so the correction cannot be omitted. The present infinite C1 proof does not itself give C2 pressure or authorize commuting its Hessian with a volume limit. The actual Fisher-density proof in IFR06-IFR07 bypasses that unavailable step.

A small log-density boundary error does not control a derivative or a squared boundary score. Even a scalar family epsilon_n sin(theta/epsilon_n) converges uniformly in value and has order-one derivative, so differentiating a value envelope is invalid. Likewise local score measurability does not establish a globally sufficient statistic, and a vanishing positive semidefinite matrix does not have a limiting Riemannian inverse. Gauge holonomy, information geometry and base curvature retain different roles.

## Initial conclusion and next access boundary

The preceding direct route appears to satisfy the frozen target's mathematical response and actual Fisher-density quantifiers on each compact K, with explicit conservative constants, complete source/boundary counts, actual C1 interchanges and a lexicographic marginal-score limit. The key amplitude derivative comes from conditional covariance of a free path, not from differentiating rho^B. Every use of finite comparison outside homogeneity was explicitly reconstructed for the localized-source perturbation. Rank-two identifiability, moving channels and higher-curvature limits remain excluded unless separately proved.

This is the initial independent proposal, not adjudicated closure. No new author/root/source interface has yet been read. The next step, only after the root authorizes access to mature interfaces, is to compare their actual constructions, finite source contracts and retained evidence with these obligations. Only the two owned proof records were written.


## Revision 2: authorized mature-interface reconstruction

The original revision is preserved byte-for-byte as agents/initial-independent-proof-check.md, SHA256 7bda93b3cf7f34b2795c05c314bac4071849ad842b40583ef4fd9fabc52c4fad, and agents/initial-proof-check-proposals.json, SHA256 a5225c3e23d7082ef989f39b3154c31fb7b70dd5a739affb297c9b522f1efa11. Root explicitly authorized access only after receiving those original hashes. The present continuation reads the full FR author construction/atomic proposals, root FS and FD constructions, the source adapter, its new tests, and the worker's source-to-recurrence report. The initial derivation and its chronology above are unchanged. Shared model, prior admitted proofs and filesystem remain independence limits; the second-stage comparison is not blind. No source, test or scientific procedure was executed by this lane. No ledger closure is assigned.

### MR01. FR01-FR05: support, inventory and forced comparison

The author uses a sharper response amplitude than IFR04. It is legitimate because it bounds actual parameter increments of a conditional expectation rather than differentiating a value bound. Reconstruct its preliminary constants as follows. There are 2B^2 fine edges and B^2 lower-left plaquette bases per coarse anchor. Distinct parallel edges of a plaquette lie on different lines, so no straight path appears twice in that plaquette. Each exterior fine edge belongs to exactly two plaquettes; each contributes three other blocks, giving the six-column count. Thus 2c_* per changed incidence becomes q=12c_* exp(tau) after the one-anchor displacement. A block-TV row count proportional to B is not substituted for that column count.

For a fixed-parity product law, changing one local field by Delta changes that bit's Bernoulli probability by at most tanh(|Delta|/2). Conditional on its value, the remainder law is unchanged. A maximal bit coupling followed by one-discrepancy opposite-prefix coupling gives Hamming cost at most twice that Bernoulli difference, hence at most |Delta|. The deterministic one-bit fiber has zero cost; it is not sent into an empty negative-parity recursion. Glue finite couplings through their intermediate marginals for several field changes. These arguments apply to the exact positive, same-support finite laws of FR02.

In the stationary pair heat bath, updating block i subtracts its current expected discrepancy and replaces it by the coupled row cost. Cancellation of the positive common update probability gives D_i at most 2c_* times its fine-discrepancy incidence sum plus F_i. Summing weighted fine Hamming over blocks, not block mismatch indicators, gives (1-q)S at most sum_i w_i F_i. The perturbation is additive forcing, not an unproved infinite-volume heterogeneous uniqueness assumption. Local covariance derivatives need only finite perturbed laws. For a global natural-parameter change, each coordinate field shifts by at most |dh|+2|dJ|, including both crossing plaquettes. Therefore sum_i w_i F_i is at most 2B^2 W(|dh|+2|dJ|). The FR05 coefficient and its lack of an extra update-rate or B factor survive this reconstruction.

Falsifiers considered: overlapping or cut path supports, a omitted boundary plaquette, a different local support in the common interior, a moving fine exterior, or omission of the field normalizer derivative would invalidate the statement. Each is excluded by the current hypotheses. The same-support requirement is substantive; incompatible remote fibers are handled later by conditioning outside a common interior.

### MR02. FR06-FR10: actual response amplitude and covariance tails

For a free target P, conditioning on all other blocks gives G_g=product_e tanh(h+J a_e), with each |a_e|<=2. For fixed exterior the direct parameter difference is at most B rho^(B-1)(|dh|+2|dJ|). Flipping one exterior edge j changes at most n_(P,j) local field terms by 2J; the corresponding local-mean change is at most 2c_*. Telescoping the product gives 2c_* n_(P,j) rho^(B-1). Since n_(P,j)<=2 and all those exterior edge anchors are within one of the target, a coupled expectation difference is at most 4c_* exp(tau) rho^(B-1) S. Substitute MR01's global S and add the direct term. This gives exactly the author's

    A_B = rho^(B-1)[B + 8c_* exp(tau)W B^2/(1-q)].

Finite analyticity makes difference quotients actual derivatives, with bounds A_B and 2A_B. This mechanism is materially different from the initial conditional-covariance amplitude proof IFR04 and yields a sharper decay; both control the same derivative.

An edge-field source produces forcing at one owner block. Its target parity oscillation is at most twice target Hamming, giving 2w_owner/(1-q). A touching plaquette source perturbs at most four free owner rows, yielding 2 sum_i w_i/(1-q), bounded by 8exp(tau) z^radius/(1-q). Only free incidences enter a crossing plaquette's forcing; its completed local character still enters the global J statistic once. With 2B^2 edge sources and B^2 plaquette sources per anchor, the far coefficients are respectively 4B^2/(1-q) and 8exp(tau)B^2/(1-q). Summing 8r z^r over r>L gives 8z^(L+1)[(L+1)-Lz]/(1-z)^2. This checks FR08-FR10 without numerical agreement or an imported differentiability theorem.

Falsifiers considered: a local perturbation affecting an uncounted row; a missing factor two between TV and sign expectations; a plaque basepoint treated as its edge anchor without exp(tau); or inferring a derivative from |m|<=rho^B. The displayed route retains all of these distinctions.

### MR03. FR11-FR14: actual C1 limits and spatial derivative counts

The covariance comparison uses the joint target/source law. TV epsilon controls its product moment by 2epsilon and the product of the two means by 4epsilon, so covariance differences are at most 6epsilon. This is not a comparison of separate marginal moments without their joint law. For a fixed source, sufficiently large whole-block volumes contain its completed support, so the limiting source is the actual infinite edge or plaquette character. Uniform near-cylinder convergence plus both absolute far-source tails proves uniform convergence of finite derivatives, first at each fixed B. Their limiting sums are continuous: approximate uniformly by a finite sum of uniformly continuous finite-pattern oracles, then use the tail. On the enlarged compact rectangle, finite coordinate FTC passes to the uniform derivative limit. Continuity of that limit proves actual partial differentiability everywhere in its interior; two coordinate increments prove C1. No derivative of an infinite partition function or exchange based only on C0 convergence is used.

For FR13's R>=2, set L=floor(R/2)-1. A near plaquette and the target use at most five anchors inside Q_(L+1); their radius R-L-1 neighborhood fits Q_R. UC gives joint TV at most 5CB^2(R-L)z^(R-L). Multiplication by the covariance factor six and the near counts 2B^2(2L+1)^2 or B^2(2L+1)^2 produces 60C and 30C, respectively. Adding two FR10 tails gives 8B^2 T(L)/(1-q) and 16exp(tau)B^2 T(L)/(1-q). The R=0,1 amplitude caps are necessary because the near-radius expression is otherwise invalid there. A finite oracle containing Q_R has every near source interior, while its remaining crossing terms obey the same absolute tail. Thus the finite/infinite comparison is the same counted argument, rather than an assertion that its source sets already coincide globally.

Uniformity over B follows by the separate amplitude split: sufficiently large B have small 2A_B,4A_B and 2rho^B; the finitely many remaining B share a finite radius. Uniformity does not follow from dropping the B^4 prefactor in the spatial bound. Remote patterns may be null and change support outside Q_R; conditioning on the exterior of that common interior compares identical interior supports and then integrates. No coupling between incompatible interior parity fibers is needed. These arguments discharge the claimed derivative passage under exactly the fixed-pattern, whole-block and compact-interior hypotheses.

### MR04. FR15-FR18: complete cell rows, score ratios and marginal increments

A cell atom is the product of two successive free-path probabilities. In the second factor, the first revealed parity is imposed as a fixed fiber in both compared patterns. Finite conditioning and the admitted constrained-law uniqueness identify this as the actual conditional law. Each denominator 1+s m is at least d=1-rho; hence cell probability is at least d^2/4, h log-score is at most 2A_B/d and J log-score at most 4A_B/d. Reference-state log odds doubles these amplitudes. Normalized four-state counting contributes log 4 to a log density, whose parameter derivative is zero.

For derivative ratios, subtract exactly a/(1+s m)-a'/(1+s m'). The two terms have bounds |a-a'|/d and |a'| |m-m'|/d^2. Two Bernoulli factors and then the reference-state subtraction give H_h=4D_h/d+4A_B V_B/d^2 and H_J=4D_J/d+8A_B V_B/d^2. The variation of the log probability itself is half these bounds. If using an amplitude cap, half the capped bound remains valid for the log probability because its own amplitude is half the log-odds amplitude. Thus FD07's later factor 1/2 is justified, including the capped case.

The actual finite marginal factors into these same rows with earlier paths prescribed and all unobserved paths absent. Derivatives of normalized rows are centered under their own conditioning. Earlier score increments are measurable in the later increment's past, so conditional expectation kills each off-diagonal increment product. The resulting matrix sum is not an independence assumption about cells. The vector score bound sqrt(20)A_B/d gives 20A_B^2/d^2 times the identity as a positive-semidefinite upper bound per actual coarse cell. The full-past predictive kernel must leave the future unprescribed; substituting the canonical vacuum-future hybrid would change the object. The current constructions keep them separate.

### MR05. FD01-FD05: complete derivative interaction and counted norm

The FD response interface retains the original compact constants and a=1+8c_* exp(tau)W/(1-q), so A_B<=a B^2 rho^(B-1). In FD02, L+1>=R/2-1/2 bounds the exact tail by 8exp(tau/2)(R+1)exp(-tau R/2)/(1-z)^2. Its J multiplier 16exp(tau)/(1-q) gives the larger 128exp(3tau/2) coefficient; the near multiplier is at most 60C. This reconstructs M. The larger H coefficient multiplies A_B V_B by 8/d^2, and V_B<=2CB^2(R+1)exp(-tau R/2), giving the stated 16aC/d^2. At R=0,1, the extra 16aexp(tau/2)/d term in K0 dominates the actual 16A_B/d cap. No small-radius exception is lost.

The fixed UP interaction shells compare successive lexicographic past truncations, so their patterns agree through radius r-1. Their derivative bounds are the minimum of the two-amplitude bound 2G0 B^2 rho^B and K0 B^4 r^3 exp[-tau(r-1)/2], with G0=8a/(d rho). Taking their geometric mean gives sqrt(2G0 K0)B^3 rho^(B/2)r^(3/2)exp[-tau(r-1)/4]. The support diameter is at most 2r and at most (2r+1)^2 translates contain the origin. At lambda=tau/16 the remaining exponential is exp(tau/4)exp(-tau r/8); replace r^(3/2) by r^2 only for integer r>=1. This recovers every factor in E'_B.

The rational series is checked algebraically: r^2(2r+1)^2=4r^4+4r^3+r^2. Putting the three differentiated geometric sums over (1-w)^5 yields w(9+55w+31w^2+w^3)/(1-w)^5. Each translation orbit and all shells remain present. The singleton is separately bounded. Finite shell truncations are C1 in the finite collection of orbit values. Uniform derivative tails and the earlier value tails let interaction-valued FTC pass in the same norm, proving actual Banach-space C1 of the complete canonical family. The tails are uniform in B because sup_B B^3 rho^(B/2) is finite. Both norm bounds decay on the compact rectangle. This is a derivative of the parameterized canonical orbit, not an RG Frechet derivative on a neighborhood of arbitrary interactions or a beta function.

### MR06. FD06-FD10: actual marginal Fisher density and volume

Finite-past predictive rows are those of the actual pushed marginal by finite conditioning. Infinite-past rows are uniform limits of those conditional versions, with all future variables absent. Multiplying finite conditional identities by a past cylinder indicator and passing the uniform value limit, followed by bounded monotone extension, identifies the full-past version without division by a null infinite event. Their parameter derivatives are the already constructed fixed-pattern derivatives, not a differentiation of an almost-sure conditional identity with a moving version.

Let S_B=sqrt(20)A_B/d and H_B=S_B^2. Two sequential Bernoulli couplings bound cell-row TV by min(1,V_B). Expanding pss^T-p's's'^T bounds the mass-change contribution by 2H_B TV. The outer-product change has norm at most 2S_B times the score-vector change, and FR17 bounds the latter by L_B=0.5 sqrt(H_h^2+H_J^2). Thus delta_B=2H_B min(1,V_B)+2S_B L_B is valid. It tends uniformly to zero on the compact set at each B.

For the square Lambda_L, radius-R interior cells have finite-past and full-past patterns agreeing through R. Translation covariance makes the expectation of the full-past Fisher row independent of the cell. At most 4RL cells remain near the boundary, and the norm difference of two bounded rows is at most 2H_B. Applying the exact finite score-chain decomposition gives

    ||I(mu_(B,Lambda_L))/L^2 - E_muB J_fullpast||
       <= delta_B(R) + 8H_B R/L.

Fix R and send L to infinity, then send R to infinity. This proves the actual limit, not merely a limsup. Uniformity on the compact set follows from common constants; continuous finite-marginal Fisher matrices then give continuity of the density. The upper bound H_B tends to zero with B and already bounds every finite marginal per cell. No ergodicity, pressure differentiation or log-boundary-error derivative is imported.

For composition, a retained a-path based in Lambda_L uses only B-coarse edges anchored in Lambda_(aL). Its map is fixed in the original h,J coordinates. Finite DPI therefore compares target I_(aB,L) with source I_(B,aL). Division by L^2 and the two actual density limits gives I_(aB)<=a^2 I_B, and only after division by fine-cell area is I_B/B^2 monotone along integer divisibility. A common parameter Jacobian acts by congruence on both sides. Changing fitted couplings or dropping a^2 would falsify this claim, and neither occurs in the current proof.

### MR07. FS01-FS10: finite identity and scope reconstruction

FS01 differentiates the full finite normalizer relative to fixed probability reference. Natural statistics are all free signs and all touching plaquette characters; the raw cosh constants disappear only after centering. The b,c Jacobian is diag((1-b^2)^-1,(1-c^2)^-1). FS02 differentiates the fixed stochastic pushforward and divides by its positive reachable mass, giving the posterior reverse expectation of the source score. FS03 follows by expanding the conditional residual covariance, including mixed entries. A null residual in a direction is score measurability on positive fibers at that parameter, not global sufficiency. FS04 is the same conditional-expectation tower on one Markov joint and unchanged coordinates; the loss addition is an exact matrix difference identity.

For FS05, the finite positive C1 mass expansion is enough: normalized first-order mass increments have zero sum, and their scalar KL expansion begins with one half their squared increment over the reference mass. The o(norm parameter increment) mass remainder contributes only o(norm parameter increment squared) after cancellation. No C2 probability premise is necessary for that finite quadratic KL statement. A selected joint need not be centered at fixed observation; differentiating its evidence centers the posterior as FS06 states. FS07's normalized posterior VFE retains one evidence term and the exact discarded conditional KL, with a stochastic channel handled on the augmented joint. Recognition and generative parameter families remain distinct.

For FS08 a moving channel contributes its own row score; conditional mean zero kills cross terms with the source score. Output Fisher is bounded by the joint Fisher including that extra term, not by the source Fisher alone. The one-state source with a parameterized Bernoulli channel is an explicit falsifier of the omitted-term assertion. FS09 correctly permits singular binary and erased outputs and only a common Jacobian congruence, without inverse or curvature claim. For FS10, under its additional finite C2 premise, differentiating log Z twice gives Cov(H_i,H_j)-E H_ij, while the score covariance is Cov(H_i,H_j). Thus the sign of the expected-Hessian correction is plus when solving for Fisher. Generated nonlinear H does not justify deleting that term or taking an infinite pressure Hessian under merely C1 control.

### MR08. SFI01-SFI05: finite source-to-algorithm correspondence

The inspected spatial_fisher.py is a two-coordinate adapter, within the unchanged centered_fisher_gram requirement of one to four immutable Fraction functions on the entire catalog. FiniteDressedField.law preserves the caller's free-edge/state order, counts every touching plaquette, includes fixed exterior completions, and enumerates the complete cube within an explicit max_edges. spatial_score_law sums the same state signs and same field.plaquettes, takes exact mass-weighted means, and divides by the two chart factors only in the b,c chart. _record requires centering and calls the old Gram, whose two exact formulas implement centered covariance. It neither fits an effective two-coupling model nor introduces a new rank engine.

pushforward_law admits nonempty pairwise disjoint free-edge paths, which preserve normalized counting and make every sign output reachable; the empty inventory is the erasure unit. project_spatial_scores evaluates those identical path products on each source state, checks its sparse channel's push equals the complete target mass, constructs the reverse using the current source law, and aligns reverse expectations by target ordinals. The old conditional_fisher_loss checks those transported target functions, then sums the full residual outer products against the actual reverse joint. Passing a returned target back through the adapter retains the same parameter labels and current law, so the finite tower proof matches the route. General admitted path groupings have the finite algebra; the spatial interpretation separately requires straight_block_path, used in the new tests.

selected_binary_posterior admits a complete strict-positive Fraction likelihood and its complement. Multiplying normalized source mass by the chosen likelihood and dividing by the full sum gives the evidence and posterior. The evidence log-score is the posterior expectation of the source score, which is subtracted from each score entry. The posterior reference stays uniform on the same complete state set; its recorded normalizer is the evidence because its raw weight convention is input normalized density times likelihood. This is a declared change of raw-weight convention, not replacement of the source field partition. Selecting after projecting with a fixed coarse likelihood commutes only when that likelihood is coarse measurable; the record and test use that condition. Otherwise a conditional averaged likelihood could be parameter-dependent and is outside that commute claim.

The source API fixes parameter independence of geometry, boundary, path map and likelihood as family-level premises; a numeric record alone cannot validate them. SpatialScoreLaw and ExactSignLaw must be producer-valid. _admit is not a proof that arbitrary hand-assembled records represent a probability family; the implementation says so. The old Fraction guard limits adapter-admitted and stored rational values to 65536 bits, not every old generic intermediate. The defaults permit six source edges and forward explicit larger limits to the same exact enumeration. No changed runtime path or permanent small-size cap was found. Source positivity, ordered support, unchanged references, fixed parameter families and successful guard admission are the conditions for these finite algorithm identities.

The inspected tests use at most six edges and independently differentiate complete polynomial products and their normalizer in each chart. The two retained opposite-edge square is explicitly nonproduct, and its derivative is summed over the complete fine fiber. Geometric direct/staged 6 paths, all mixed losses, evidence/posterior recentering, binary rank, erasure, identity and zero controls are exercised in the proposed packet. This paragraph is source inspection of test design, not an execution result; no pass count is asserted here.

### MR09. Current outcome and unobserved interfaces

No concrete mathematical counterexample within the frozen premises, missing counted constant, or new finite source recurrence defect was found in this mature pass. This is supported by the direct reconstructions above and the distinct initial IFR route, not by agreement among authors. The possible falsifiers are explicit in MR01-MR08 and the initial record: missing source terms, moving supports or channels, incorrect derivative interchange, vacuum-future substitution for actual predictive rows, omitted shell multiplicities, pressure-Hessian substitution, dropped volume factors and unsupported inverse/curvature interpretation. The inspected texts retain the conditions that block each attack.

At this revision there is no executed packet readback and no inspection of root's forthcoming atomic FS/FD proposals, assembled theorem or human report. Those interfaces remain pending rather than implicitly covered. The scientific source hashes below bind this pre-execution source correspondence only. A subsequent observed packet is separate numerical evidence and cannot prove the infinite theorem. No tamper/corruption/forgery, old producer, GPU, Git or vault operation occurred.

Mature-interface snapshot at this read: parameter-response-construction.md e9ec9be21ac31253b9f70452c263ad719f2f51050ac4786bbed1a364e87c3a46; parameter-response-claims.json 0a5fe8c18deb20565b387b9802aec035ea00e499106a85295cbb7c289fab48c0; finite-score-posterior.md efaee6ef4eada6348e1a82c846e486c67d93dec90ce030172ea1564b847c9409; interaction-fisher-density.md 0f1e9f9966d836d14f3eeb037be45a1ec21f4ccfb01cf4061c2501488e40b17d; spatial-fisher-implementation.md cb351711f86a67f4bebb3cace8eda27249cdcaa4859262ecb02fe32d59da0423; src/multiagent_elbo/rg_v2/spatial_fisher.py 6bcd1b6b088f1d5b367b534817d09a130585718ca0e8f9d111bd9952069d8766; tests/rg_v2/test_spatial_fisher.py c022a1fa57a71e758bd2c5f2aeb99e1d57e01bf6254cc0bdf7d69e6b77f7a942.


### MR10. Observed finite repairs and retained execution

After revision 2's source snapshot, the separate author-interface lane identified that FS06 did not explicitly say the normalized joint was C1 on an open parameter set and that FS08's fixed reachable alphabet was insufficient to license log scores on changing transition entries. Root repaired both clauses. The current finite-score-posterior.md, SHA256 4716d666a9176f074e675d2ad83d1f9389577b854e8035fe624eacfe11c86ad9, now states the open-set C1 premise and fixed positive transition support for each row, with log scores defined only on positive entries and extended by zero on structural zeros. I read the changed sections and reconstructed the differentiated normalization under those premises. My initial and mature derivations assumed smooth fixed families, but this lane did not independently flag the two omitted explicit clauses; their discovery and repair remain attributed correctly.

I subsequently read the exact FR01-FR18, FX01-FX14, GX01-GX13 and SFI01-SFI05 proposals. Their statements/dependencies match the direct MR reconstructions; the final coverage maps each literal proof section separately rather than confusing root section labels FS/FD with atomic claim IDs FX/GX. SFI proposals are labeled CODE by their author and are supported here only as conditional finite algorithm identities with the explicit source/helper/family premises. They are not universal runtime claims inferred from tiny tests.

The actual retained raw XML fisher-tests-20260909T133346523866Z.xml has 35 testcase elements and 35 distinct classname/name pairs, with zero failure, error or skip elements; suite time is 0.616 s. The result records exit zero and runner elapsed 1.3338581999996677 s. The command vector and CONFIG canonical JSON hashes, driver hash, contract hash and 19 source/test/dependency hashes match the current bytes. Source and tests match the revision-2 snapshot. The runner's isolated Python is Anaconda 3.12.7; the project still declares Python >=3.14. This observes only direct tiny-source compatibility under that interpreter and no package-installation or unrun runtime result. The full packet scope has at most six free edges, and the larger max_edges path is tested on the same six-edge source. No new mathematical or scientific calculation, test, producer or filtering execution was performed here; only the saved XML/JSON/log and current source hashes were read.

At the first final-interface read, the root assembled theorem and final report remained scaffolds, the counterexample register remained its scaffold, and the human report was absent. The supplied 51 constituent claims and raw numerical observation can be mapped now; target and final report binding remain pending until those actual texts exist. This is an interface timing condition, not a mathematical counterexample.


### MR11. Final assembled target and report interface

Root then supplied the actual theorem, native final report, counterexample register and human report. I read all four in full, together with author-interface-check.md's preserved original findings and actual checked-resolution paragraphs. Their final statements retain the same compact-interior natural coordinates, arbitrary fixed signed-or-absent patterns, complete canonical shells and normalized four-state reference. The theorem supplies actual C1 rows and interaction-valued derivatives, and the actual square-marginal Fisher limit with delta_B(R)+8H_BR/L error. It keeps the source-square a^2 factor and compares one original parameter chart. H_B is a bound on a continuous PSD information tensor density, with no unsupported rank, inverse or curvature claim. The human report's compact-subset wording is covered by an enclosing compact rectangle inside this rectangular open parameter domain.

The exact target can be reconstructed from the frozen contract plus the admitted UC/UP premises without using the desired conclusion, author agreement or tiny numerical outcomes: MR01-MR04 prove the actual response, MR05 supplies the complete C1 potential, MR06 supplies the actual marginal Fisher-density limit and depth/composition estimates, MR07 supplies the finite score/evidence/VFE identities, and MR08 plus the preserved exact source bindings supplies the conditional algorithm correspondence. MR10 separately records the actual finite packet. All 52 requested IDs, including lowercase target, are now mapped in the final coverage. The separate raw evidence remains the authority for SFN01 even if root subsequently derives a scientific-record wrapper during its own native intake.

The counterexample register correctly retains that smooth value convergence and even common Lipschitz bounds do not imply the requested C1 convergence, that a moving channel can create information, that positive finite laws can have singular Fisher, that a small boundary log-density error does not bound its derivative, and that nonlinear actions require the expected-Hessian correction. Its two explicit finite support/smoothness repairs have the correct discovery and readback chronology. The package/runtime, exact input/output guard, six-edge numerical scope and unrun old/GPU/tamper boundaries are preserved. The broader higher-regularity, identifiable-quotient, Fisher-curvature, critical and continuum obligations remain open outside this target. No concrete unresolved target or report overclaim was found within the inspected frozen premises.

Final interface hashes: construction-or-strongest-theorem.md 8bacc7f4df92b099f5405c7dcf4e505934b6c2949dc397e7a9054cda9f8917a7; final-report.md 9da2a6aea0be472b111843d307313522419eca2e3d9b60d8607c377e2ba98ff7; counterexample-register.md 40ff8eea4742a6b2373e71b6ce19ca79fde79ee0eedcd4a2ef58fad081b9d7e1; docs/reports/2026-09-09-fisher-response-rg.md fdbd9c7951d1c8ad8a7870dc33651dd388fdaf02a3903fafdb2be9971df5e4e8; agents/author-interface-check.md 0d68e21f77e6c2339b6f0e80b62d1ebf4e99fbadf63f9eee2c56282f361e8975. These are the actual final texts read after the scaffold observation recorded in MR10. This lane assigns no ledger or release state.
