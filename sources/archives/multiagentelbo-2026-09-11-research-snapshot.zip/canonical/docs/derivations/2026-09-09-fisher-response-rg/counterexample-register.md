<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Counterexamples, resolved attacks and retained boundaries

## Value convergence does not imply response convergence

The positive binary rows p_n(t)=1/2+sin(n^2 t)/(4n) converge uniformly to 1/2, while p'_n(0)=n/4. The smooth functions sqrt(t^2+1/n^2) converge to the nondifferentiable |t| despite a common Lipschitz bound. These controls refute attempts to infer the present actual C1 limit from value convergence or a Lipschitz bound. FR08-FR14 instead prove summable derivative limits and FTC.

## A learned channel can create information about its own parameter

For a one-state source, I_X=0. A channel producing a Bernoulli observation with probability t in (0,1) has I_Y=1/[t(1-t)]>0. Ordinary fixed-channel contraction fails because the channel depends on t. FS08 retains its own score and fixed positive transition support in each row. Structurally zero entries have zero extension; a fixed reachable output alphabet alone is insufficient to state its log-score formula.

## A positive finite law need not have an invertible Fisher matrix

A binary output's Fisher is (grad p)(grad p)^T/[p(1-p)], of rank at most one regardless of how many input parameters were identifiable. Erasure gives rank zero. The retained exact square/binary/erasure test realizes ranks 2,1,0 in two parameter directions. This is finite evidence for that example, with the general rank formula proved directly. A vanishing density is not a vanishing-curvature theorem.

## Actual marginal density and nonlinear action safeguards

The derivative of a small boundary log-density error can be large, as the oscillatory example shows. The density argument uses actual marginal conditional-score orthogonality and a separate score-continuity estimate. It never infers squared boundary-score control from the previous value estimate. Two finite derivatives of a nonlinear Hamiltonian give partial_ij log Z=I_ij-E[partial_ij H]; pressure curvature alone omits the latter term. Integer path composition changes the source area by a^2 and therefore requires that factor before dividing by cells.

## Resolved finite hypothesis findings

The author-interface check found that FS06 originally omitted an explicit C1 hypothesis for the positive normalized joint. The final text states C1 on an open parameter set. It also found that FS08's original phrase about fixed reachable support was insufficiently precise for a channel log score. The final text requires fixed positive transition support in each row, defines the log score there and extends it by zero on structural zero entries. These are retained pre-release findings and repairs; they did not require a code change or scientific rerun.

## Unrun work and scope

Tamper, corruption and forgery checks are user-excluded and were not run. No old packet, held S1-S3, Phase13 producer, broad suite, large spatial enumeration, GPU science, Git publication, vault or memory mutation was performed. The 35-case result is tied to isolated Python 3.12.7 and its exact current source; pyproject still requires Python>=3.14. Existing generic exact internals are not described as per-operation 65536-bit guarded. No counterexample to the frozen response target was found in the recorded derivations and finite checks; broader critical, continuum and higher-curvature targets remain unproved.
