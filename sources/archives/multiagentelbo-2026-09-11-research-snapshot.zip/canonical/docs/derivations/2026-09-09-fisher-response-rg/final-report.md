<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec","target_digest":"5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec"} -->

# Rigorous theory search report

## Frozen contract

This report addresses [the frozen parameter-response contract](problem-contract.json), target digest 5da2a3c8e5bf5b9ece7a01467cef71834599e94ad86c095a3e539179b38ccfec. The original full RG goal remains active.

## Terminal status

The scoped result is presented for current proof/evidence acceptance and structural release validation. Its final status is recorded in [release.json](release.json); no global completion follows from that scoped status.

## Certificate

The [direct construction](construction-or-strongest-theorem.md), [claim ledger](claim-ledger.json), [dependency DAG](dependency-dag.json), [counterexample register](counterexample-register.md) and [scientific record](evidence/scientific-record.json) retain distinct mathematical and finite execution evidence.

## Strongest verified result

On every compact rectangle strictly inside 0<h<infinity,0<J<atanh(1/12), all integer depths have actual C1 every-pattern coarse rows, a C1 complete canonical interaction in one common exponential norm, and an actual continuous marginal Fisher density. The first-derivative norm and the bound H_B=20rho^(2B-2)(B+D B^2)^2/(1-rho)^2 tend to zero with B. Per original fine cell, Fisher contracts along fixed integer path composition with its explicit a^2 area factor. The finite adapter retains full scores, mixed loss and posterior evidence.

## Dependency closure

FR01-FR18 derive the response interface from current UC/UP premises and explicit compact constants. FX01-FX14 prove the finite score, KL, evidence, rank, chart and nonlinear-action identities. GX01-GX13 construct the complete derivative norm and actual marginal density. SFI01-SFI05 are conditional finite algorithm identities from current source correspondence; SFN01 is the separate one-packet numerical observation. Current per-claim coverage and all evidence bindings are checked before release.

## Independent reconstruction

The [initial independent record](agents/initial-independent-proof-check.md) and its exact proposal snapshot were saved before mature draft access. Its conditional-covariance amplitude argument reconstructs the response/depth mechanism separately from the author's global parameter-coupling bound. The later [mature reconstruction](agents/independent-proof-check.md) and [coverage](agents/native-closure-coverage.md) check the final author/root/source and raw evidence. Shared model family and filesystem limit independence.

## Oracle erasure

Removing favorable expectations and all test outcomes leaves finite covariance differentiation, counted stationary coupling, summable derivative limits and FTC, shell interpolation, actual marginal score orthogonality and bulk/boundary limits. The one-packet output supplements source correspondence and does not establish those infinite quantifiers. Structural validation checks record shape and freshness, not mathematical truth.

## Unresolved obligations

No unresolved obligation may be hidden by narrowing this target to Lipschitz response or a density limsup. The broader program still needs higher parameter regularity, identifiable Fisher directions or a proved quotient, justified curvature constructions, a wider RG operator and critical/continuum bridges. These are outside this fixed first-order contract and remain open.

## Scope and limitations

One exact 35-case packet passed with zero failures/errors/skips; suite time 0.616 seconds, runner 1.3338581999996677 seconds, at most six free spatial edges. It used isolated Anaconda Python3.12.7 and current source hashes, while pyproject's Python>=3.14 declaration remains unchanged. The adapter's old generic arithmetic has no claimed per-operation guard. Tamper checks are user-excluded/not run; old packets, large enumeration and GPU science were not run. No inverse Fisher tensor or equality of Fisher, gauge and base curvature is asserted.
