# Phase 21 coupling response for every finite real coupling

Date: September 7, 2026. Author: Codex GPT-6, independent investigator view. Separate verifier: pending at creation of this document. Scope: item 2 of the [post-audit program](../research-plans/2026-09-06-rg-v2-post-audit-program.md), bound to repository revision `256370de20b458b1dbfdf88089318aaa3fb185ba` and the source hashes below.

The Phase 21 response, composition, normalization, and source-coordinate Fisher-contraction assertions follow for every finite real coupling under the stated fixed finite reference, fixed reverse-channel, independent-coordinate, and saturated-target hypotheses. The September 5 derivation needs one literal correction: its joint probability is nonnegative and normalized, with strictly positive marginals, but need not be strictly positive on every pair because the admitted reverse matrices can contain zeros. This correction does not weaken the covariance argument. The proof below is independent of the eight retained centers and does not promote their arithmetic checks into a proof of an uncountable quantifier.

This is a standalone mathematical derivation and a source-to-hypothesis inspection. It does not report a new production run, a recheck of every retained packet, or a change to any historical ledger. The former verification skill is disabled under the current global instructions; direct proof and separate review supply the evidence for this task.

## 1. Exact statement and conventions

For levels `l=0,1,2`, let `S_l` be a nonempty finite set of size `n_l`. Reference masses `p_l` are row vectors satisfying `p_l(s)>0` and `p_l 1=1`. Matrices `Q_lm` have shape `n_m` by `n_l`, act on column vectors of weights, and satisfy

$$
Q_{lm}(t,s)\geq 0,\qquad Q_{lm}\mathbf 1=\mathbf 1,\qquad p_m Q_{lm}=p_l,\qquad Q_{02}=Q_{12}Q_{01}.
$$

These masses, matrices, finite sets, and their orderings are fixed independently of every coupling and perturbation considered below. They are reference reverse matrices. Their tilted versions will depend on the coupling; that dependence is part of the response calculation.

Let `E_l` be an `n_l` by `r_l` real matrix and `L_l` an `r_l` by `n_l` real matrix, both fixed, with

$$
L_lE_l=I_{r_l}.
$$

Thus `E_l` has independent columns. At each target `m=1,2`, assume the stronger identity

$$
E_mL_m=I_{n_m}.
$$

Under both identities, target saturation means `r_m=n_m` and `L_m=E_m^{-1}`. It is sufficient exact image closure for every target action, not a low-dimensional approximate fit. No source saturation is required.

For the four original labels, let `B_l` have shape `n_l` by four, first column equal to one, and columns in the image of `E_l`. Define

$$
A_l=L_lB_l,\qquad E_lA_l=B_l,\qquad e_l=L_l\mathbf 1,\qquad E_le_l=\mathbf 1.
$$

The first column of `A_l` is `e_l`. The theorem on response maps needs the represented constant, while the four-coordinate Fisher claim additionally needs the displayed `B_0,A_0` relation. The retained constructor chooses `E_l` from independent columns of `B_l`; consequently their images coincide there. The abstract response theorem does not require this extra equality of images.

For any `g` in `R^{r_l}`, define the vector `w_l(g)=exp(-E_l g)` entrywise and

$$
W_{lm}(g)=Q_{lm}w_l(g),\qquad Z_l(g)=p_lw_l(g),
$$

$$
T_{lm}(g)=L_m[-\log W_{lm}(g)],\qquad
N_{lm}(g)=T_{lm}(g)+\log Z_l(g)e_m.
$$

The logarithm is also entrywise. Write `J_lm=DT_lm`, `H_lm=D^2T_lm`, and similarly `J_lm^N,H_lm^N` for `N_lm`. A Hessian has indices output coefficient, input coefficient, input coefficient. For every finite real input, all these maps exist and are smooth. They obey the derivative formulas in section 3, the raw and normalized compositions in section 4, and the source Fisher statements in sections 5 and 6. The word finite excludes infinite-coupling boundary limits and their possible loss of support. It does not restrict `g` to integers, rational numbers, sampled centers, a small neighborhood, or one sign.

## 2. Positivity, reference preservation, and the tilted joint

For each finite real `g`, the finitely many entries of `w_l(g)` are finite and strictly positive. Every row of `Q_lm` contains a positive entry because its nonnegative entries sum to one. Therefore every entry of `W_lm` is finite and strictly positive even when some entries of `Q_lm` vanish. Also `0<Z_l(g)<infinity`, and

$$
p_mW_{lm}=p_mQ_{lm}w_l=p_lw_l=Z_l.
$$

Every exponential and logarithm in the definition is consequently smooth on its whole real coefficient domain. Differentiation is of finite sums. No asymptotic limit or interchange with an infinite sum is used.

For an arrow at a given input, write `w_m=W_lm`, `Z=Z_l`, and

$$
\pi_l(s)=\frac{p_l(s)w_l(s)}{Z},\qquad
\pi_m(t)=\frac{p_m(t)w_m(t)}{Z},\qquad
Q_{lm}^w(t,s)=\frac{Q_{lm}(t,s)w_l(s)}{w_m(t)}.
$$

The two `pi` vectors are strictly positive normalized masses, and `Q_lm^w` has nonnegative normalized rows. The equality

$$
\gamma_{lm}(s,t)=\pi_m(t)Q_{lm}^w(t,s)
=\frac{p_m(t)Q_{lm}(t,s)w_l(s)}{Z}
$$

defines a nonnegative normalized joint with marginals `pi_l,pi_m`. Its zero entries agree exactly with the zero entries of `Q_lm`. Strict positivity on the Cartesian product is not an assumption and is not a conclusion.

A fixed forward channel can be recovered for the purpose of the proof:

$$
R_{lm}(s,t)=\frac{p_m(t)Q_{lm}(t,s)}{p_l(s)}.
$$

Its rows sum to one by the reference marginal identity, its entries are nonnegative, and it is parameter independent. Direct multiplication gives `pi_l R_lm=pi_m`, `gamma_lm(s,t)=pi_l(s)R_lm(s,t)`, and `R_01 R_12=R_02`. Thus `Q_lm^w` is the coupling-dependent posterior reverse of a fixed forward statistical channel. There is no assumption that the tilted reverse itself is parameter independent. The implementation does not need to take `R` as an input; this construction shows why its reference hypotheses are sufficient for information contraction.

## 3. First and second derivatives

Fix an arrow and target row `t`. Set `f_t=-log W_t`. Finite differentiation gives

$$
\partial_a W_t=-\sum_sQ(t,s)w_l(s)E_l(s,a),\qquad
\partial_{ab}W_t=\sum_sQ(t,s)w_l(s)E_l(s,a)E_l(s,b).
$$

Dividing by `W_t>0` yields

$$
\partial_af_t=\sum_sQ^w(t,s)E_l(s,a),
$$

$$
\partial_{ab}f_t=-\sum_sQ^w(t,s)E_l(s,a)E_l(s,b)
+\left(\sum_sQ^w(t,s)E_l(s,a)\right)
 \left(\sum_sQ^w(t,s)E_l(s,b)\right).
$$

Applying the fixed linear map `L_m` proves

$$
J_{lm}=L_mQ_{lm}^wE_l,\qquad
H_{lm}[i,a,b]=-\sum_tL_m[i,t]\operatorname{Cov}_{Q_{lm}^w(t,\cdot)}(E_l(\cdot,a),E_l(\cdot,b)).
$$

The row-action Hessian `D^2 f_t` is negative semidefinite. After multiplication by a general `L_m`, neither a coefficientwise sign nor a sign for each output Hessian follows. The implemented sign and output/input/input ordering agree with these formulas.

The same finite calculation for the partition function gives

$$
\partial_a\log Z_l=-\mu_l(a),\qquad
\partial_{ab}\log Z_l=K_l(a,b),\qquad
\mu_l=\mathbb E_{\pi_l}E_l,\qquad K_l=\operatorname{Cov}_{\pi_l}(E_l).
$$

Here the expectation of row evaluations is a row vector. Therefore

$$
J_{lm}^N[i,a]=J_{lm}[i,a]-e_m[i]\mu_l(a),\qquad
H_{lm}^N[i,a,b]=H_{lm}[i,a,b]+e_m[i]K_l(a,b).
$$

These identities hold at every finite real input for each of the three arrows. The local derivative calculation itself needs neither target saturation nor a third level. Those hypotheses enter the exact representation and composition statements.

For any real `c`, the represented constant gives `w_l(g+ce_l)=exp(-c)w_l(g)`. The conditional weights, normalized masses, `J,H,J^N,H^N` are therefore unchanged by this shift. In particular,

$$
T_{lm}(g+ce_l)=T_{lm}(g)+ce_m,\qquad
N_{lm}(g+ce_l)=N_{lm}(g),
$$

$$
J_{lm}e_l=e_m,\qquad J_{lm}^Ne_l=0,\qquad
H_{lm}[u,e_l]=H_{lm}^N[u,e_l]=0
$$

for every input direction `u`. The mixed Hessian identities follow by differentiating the constant directional derivative; symmetry gives the other slot.

## 4. Raw composition and normalized composition

Take an arbitrary finite real source coefficient `g_0`. Set `w_0=exp(-E_0g_0)`, `w_1=Q_01 w_0`, `w_2=Q_12w_1=Q_02w_0`, and `Z=p_0w_0`. All three levels have the same partition factor `Z`. Middle saturation gives

$$
E_1T_{01}(g_0)=-\log w_1,\qquad
\exp(-E_1T_{01}(g_0))=w_1.
$$

Hence, using the same target interpolation on both routes,

$$
T_{12}(T_{01}(g_0))
=L_2[-\log(Q_{12}w_1)]
=L_2[-\log(Q_{02}w_0)]
=T_{02}(g_0).
$$

This is an identity of smooth maps on the entire `R^{r_0}`. Differentiating it once and then differentiating the product with respect to a second source coordinate gives, with the outer derivatives evaluated at `g_1=T_01(g_0)`,

$$
J_{02}(g_0)=J_{12}(g_1)J_{01}(g_0),
$$

$$
H_{02}[i,a,b]
=\sum_jJ_{12}[i,j]H_{01}[j,a,b]
+\sum_{j,k}H_{12}[i,j,k]J_{01}[j,a]J_{01}[k,b].
$$

The first term comes from differentiating the inner Jacobian. The second comes from differentiating the outer Jacobian through the inner map. Both terms are required for a scalar output as well as a vector output. The formula has no rank-based exception.

For normalization set `g_1^N=N_01(g_0)=g_1+log(Z)e_1`. Then

$$
\exp(-E_1g_1^N)=w_1/Z,\qquad
Z_1(g_1^N)=p_1w_1/Z=1.
$$

The next normalization, evaluated at this input, contributes `log(1)e_2=0`. Directly,

$$
N_{12}(N_{01}(g_0))
=L_2[-\log(Q_{12}w_1/Z)]
=L_2[-\log w_2]+\log(Z)e_2
=N_{02}(g_0).
$$

Thus the normalized derivatives obey

$$
J_{02}^N(g_0)=J_{12}^N(g_1^N)J_{01}^N(g_0),
$$

$$
H_{02}^N[i,a,b]
=\sum_jJ_{12}^N[i,j]H_{01}^N[j,a,b]
+\sum_{j,k}H_{12}^N[i,j,k]J_{01}^N[j,a]J_{01}^N[k,b].
$$

The outer normalized map is defined and differentiated on its whole coefficient domain before evaluation at `g_1^N`. A value `Z_1(g_1^N)=1` does not imply that the ambient first or second derivatives of `Z_1` vanish. Constant-shift invariance proved above gives `J_12^N(g_1^N)=J_12^N(g_1)` and `H_12^N(g_1^N)=H_12^N(g_1)`. This justifies computing the outer normalized arrays from the raw propagated middle weights in the implementation. It does not justify discarding the outer normalizer during differentiation or adding the original `log Z` twice.

The tilted reverses also compose. Expanding the product and cancelling the middle weight gives

$$
\sum_yQ_{12}^w(z,y)Q_{01}^w(y,x)
=\sum_y\frac{Q_{12}(z,y)w_1(y)}{w_2(z)}
\frac{Q_{01}(y,x)w_0(x)}{w_1(y)}
=Q_{02}^w(z,x).
$$

All denominators used here are positive for every finite real `g_0`.

## 5. Fisher pullback in the original four source coordinates

The original parameterization is `g_0=A_0 eta` for `eta` in `R^4`, so `E_0g_0=B_0 eta`. This relation must be retained when `r_0<4`; an identity in place of `A_0` would have the wrong dimensions or describe different directions. To state the result at every arbitrary base `g_0` even without assuming `image E_0=image B_0`, one can use the affine local family `g_0(eta)=g_0+A_0 eta` and evaluate at `eta=0`. The derivative remains `A_0`. The retained constructor chooses `E_0` from `B_0`, so every independent source coefficient there also has an original-coordinate representative.

For the raw propagated coefficients set

$$
D_0=A_0,\qquad D_1=J_{01}A_0,\qquad D_2=J_{02}A_0.
$$

The local coefficient score for `p_l(s)exp(-(E_l g_l)_s)/Z_l(g_l)` is

$$
\nabla_{g_l}\log\pi_l(s)
=-\big(E_l(s,\cdot)-\mu_l\big)^{\mathsf T}.
$$

Pulling back by `D_l` therefore gives the actual source-parameter Fisher matrix

$$
G_l=D_l^{\mathsf T}K_lD_l.
$$

There is no missing second derivative of `g_l(eta)` in this score-covariance definition of Fisher information. For direct verification of the observable meaning, saturation at target `l>0` gives

$$
E_lD_l=E_lL_lQ_{0l}^wE_0A_0=Q_{0l}^wB_0.
$$

Define row-vector statistics `M_0=B_0`, `M_1=Q_01^w B_0`, and `M_2=Q_02^w B_0`. At all levels `G_l=Cov_{pi_l}(M_l)`. Their means are equal because `pi_l Q_0l^w=pi_0`. Thus the coarse source score is the negative centered conditional expectation of the original source statistic. This is a finite proof of the conditional-score identity; [Pollard, Theorem 7](https://arxiv.org/pdf/1107.3797v2) states its general differentiability-in-quadratic-mean form. The reference is contextual support, not a replacement for the finite calculation.

Since `E_l e_l=1`, each local form satisfies `K_l e_l=0`. Replacing `J_0l` by `J_0l^N` changes `D_l` by an outer product whose image is in `span(e_l)`, so it leaves `D_l^T K_l D_l` unchanged. The same observation applies if the source family is represented in its normalized gauge: its derivative differs from `A_0` only in the constant direction. The first original label contributes no score, and all `G_l` annihilate the first standard basis vector in `R^4`.

Independent evaluation columns do not imply a positive-definite local Fisher matrix: the represented constant makes it singular. In fact positivity of `pi_l` and injectivity of `E_l` give `ker K_l=span(e_l)`, because a direction has zero variance precisely when its evaluation is constant. Additional kernel directions of `G_l` can arise after the source derivative `D_l` is applied.

## 6. Contraction, loss decomposition, and retention

To establish both losses in common source coordinates, define a three-level joint law

$$
\Gamma(x,y,z)=\frac{p_2(z)Q_{12}(z,y)Q_{01}(y,x)w_0(x)}{Z}.
$$

It is nonnegative and normalized. Summing explicitly gives the marginal pairs in section 2, `X|Y` with reverse `Q_01^w`, and `Y|Z` with reverse `Q_12^w`. In particular `M_1(y)=E[B_0(X)|Y=y]` and the tilted composition gives

$$
M_2(z)=\sum_yQ_{12}^w(z,y)M_1(y).
$$

For any row-vector random variable `V` on a finite joint law, expanding `V-EV=(V-E[V|Y])+(E[V|Y]-EV)` makes the two cross terms zero after conditioning. Consequently

$$
\operatorname{Cov}(V)
=\mathbb E\big[\operatorname{Cov}(V\mid Y)\big]
+\operatorname{Cov}\big(\mathbb E[V\mid Y]\big).
$$

Applying this identity first to `B_0(X)` conditioned on `Y`, and then to `M_1(Y)` conditioned on `Z`, proves

$$
G_0-G_1=\sum_y\pi_1(y)\operatorname{Cov}_{Q_{01}^w(y,\cdot)}(B_0)\succeq0,
$$

$$
G_1-G_2=\sum_z\pi_2(z)\operatorname{Cov}_{Q_{12}^w(z,\cdot)}(M_1)\succeq0.
$$

This explicitly proves the second contraction; comparing separate pairs of local-coordinate Fisher matrices would not suffice when their coordinates differ. With loss notation `Delta_lm=G_l-G_m`, direct algebra gives

$$
\Delta_{02}=\Delta_{01}+\Delta_{12}.
$$

In a source direction `v`, equality for an arrow is equivalent to the scalar statistic `M_l v` having zero conditional variance in every target row. Because every target mass is positive, it must be constant on the positive support of each such row. This is a directional local information statement. No experiment-wide recovery or common-space RG dynamics is inferred from one equality.

For a source-target pair write `G=G_l` and `H=G_m`. The inequalities `0<=H<=G` imply that `H` annihilates `ker G`: if `Gv=0`, then `0<=v^T Hv<=v^T Gv=0`, and positive semidefiniteness gives `Hv=0`. Both forms descend to `R^4/ker G`, where `G` is positive definite. On any complement of that kernel, the symmetric matrix `G^{-1/2}HG^{-1/2}` has spectrum in `[0,1]`; these are the generalized retention values. The constant direction bounds the quotient dimension by three, including the possibility of an empty quotient.

These bounds hold for all finite real couplings. They do not imply that arbitrary real-coupling matrices have rational coefficients, rational roots, or roots isolatable by the exact rational solver. Those are arithmetic properties of the retained rational-weight centers. They also supply no common-state-space RG linearization, scaling factor, or relevance exponent. The retained `full_space_beta_status=not_defined_support_nonisomorphic` boundary is unchanged.

## 7. Hypotheses that cannot be silently removed

The proof uses fixed reference masses and fixed reverse matrices. If either depends on the differentiated parameter, extra derivative terms enter the partition, raw action, and score. A family of separately normalized posterior kernels is insufficient unless the claimed parameter dependence is accounted for. The construction of the fixed forward `R_lm` above is specific to the declared fixed reference pair.

Intermediate exact representation is essential to the composition argument. Saturation is a sufficient premise, not claimed to be necessary for every restricted family. A weaker replacement would require proof that every intermediate action `-log(Q_01 exp(-E_0 g))` and its normalization lie in `image E_1` throughout the claimed parameter domain. A finite list of admitted centers does not establish that replacement.

For a concrete mathematical failure without middle saturation, take `S_0=S_1=S_2` with two elements, uniform positive references, `Q_01=Q_12=Q_02=I_2`, `E_0=E_2=I_2`, `L_0=L_2=I_2`, and

$$
E_1=\begin{pmatrix}1\\1\end{pmatrix},\qquad
L_1=\begin{pmatrix}1&0\end{pmatrix}.
$$

All matrices are fixed, every reverse identity holds, every evaluation has independent columns and a represented constant, and `L_1E_1=1`; but `E_1L_1` is not identity. For `g_0=(0,a)^T` with `a!=0`, `T_01(g_0)=0` and `T_12(T_01(g_0))=(0,0)^T`, whereas `T_02(g_0)=(0,a)^T`. The coefficient interpolation erased the second action entry. This analytic example delimits a mathematical assumption; it is not an artifact mutation or a test of a publication packet.

Target saturation at level 2 also justifies the source-score identity `E_2D_2=Q_02^wB_0`. The raw composition alone uses only exact middle representation because the final `L_2` is applied on both routes. It would be incorrect to treat this observation as permission to drop level-2 saturation from the complete Fisher-pullback theorem without supplying the missing representation premise.

The actual source recipe `d r_a^{h_a} r_b^{h_b} r_c^{h_c}` is a finite-center encoding with positive rational recipe entries and binary original source statistics. It equals `exp(-B_0 eta)` for `eta=(-log d,-log r_a,-log r_b,-log r_c)`. Neither binary statistics nor rational recipe values are required by the all-real finite-sum theorem. They are additional implementation restrictions. The all-real result applies to the fixed admitted tower; it does not admit arbitrary new towers, enlarged signatures, unsaturated coordinates, or an infinite-volume limit.

## 8. Correspondence to the inspected source and remaining boundary

The inspected `_validate_source` in `rg_v2/complete_carrier_coupling_response_model.py` requires positive normalized reference masses, positive actual weights, independent-coordinate inverse identities, saturated targets, a represented original constant, exact recipe membership, common evidence, normalized nonnegative reverse rows, the reverse marginal identities, actual weight propagation, and `Q_02=Q_12 Q_01`. `construct_signature_coupling_response` computes the conditional covariance formulas, both Hessian chain terms, normalized-middle mass and reverse checks, and the `A_0` source pullback. Its `_chain_hessian` includes the inner-Hessian term. Its normalized outer arrays are evaluated from the raw middle weights, which section 4 proves equivalent to evaluation at the normalized middle coefficient.

The predecessor `complete_carrier_signature_recursion_model.py` constructs evaluation columns from the independent original columns, verifies the left inverse, requires target saturation, and forms an independently checked reverse composition. This inspection establishes correspondence between the written hypotheses and the current validators and consumers; no producer or retained-data integration was rerun in this proof task.

The September 5 derivation's displayed formulas require no sign change or missing Hessian correction. Its wording `positive normalized joint` should read `nonnegative normalized joint with strictly positive marginals`. Its restriction to independent coordinates and saturated targets should remain explicit whenever the result is cited. Exact rational root isolation remains a retained-center statement. The proof above discharges the all-finite-real-coupling mathematical obligation subject to its explicit hypotheses; a separate verifier must assess this investigator proof before the parent task records independent closure. No new numerical evidence is needed to address the arbitrary-real quantifier.

Research context was read from the [Research vault Coarse Graining page](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Coarse Graining.md>), especially its distinction among local Fisher preservation, distributional closure, and experiment comparison. The vault was not modified. For external context the primary source [Pollard, *A note on insufficiency and the preservation of Fisher information*, arXiv:1107.3797v2, Theorem 7](https://arxiv.org/pdf/1107.3797v2) was accessed September 7, 2026. The present proof derives its finite assertions directly and does not import the general theorem's extra regularity machinery.

## 9. Source binding and execution record

The following SHA-256 values identify the inspected on-disk bytes at the start of this derivation. They bind the mathematical target and its source correspondence; they are not a claim that later unrelated worktree edits preserve the entire repository tree.

| Relative source path | SHA-256 |
|---|---|
| `docs/derivations/2026-09-05-rg-v2-phase21-coupling-response.md` | `50012a9f849e42e1a26d5539c4153c284252e8dc8ccf9b83fa73da008ceb7842` |
| `docs/superpowers/specs/2026-09-05-rg-v2-phase21-coupling-response-design.md` | `bc408b7d541682bfcce7ed7b3b5e45374e2c0c3a2c2143303353153beb98fa79` |
| `rg_v2/complete_carrier_coupling_response_model.py` | `5b54a6ad5bd9a82cc0f3b08b28041033d588f6bf0bfdf03c0a83cad29289e824` |
| `rg_v2/complete_carrier_signature_recursion_model.py` | `04bf29461f3a6367a3e7d78848affd3acc9eda05e11fde62f6a95c0aa8fb1915` |
| `docs/research-plans/2026-09-06-rg-v2-post-audit-program.md` | `c8e919f74b407ad24cfc50b4430d8c81f6bcfd2349635fbaf641f2fa43f54702` |

Executed actions were read-only source inspection, `git rev-parse HEAD`, SHA-256 calculation, primary-source retrieval, and creation/readback of this new derivation. No pytest tests, finite-center replay, full suite, producer, worker pool, GPU, or deliberate corruption/forgery/tamper check was run. There is no test total or experimental pass claim in this document. The new file is the only task-owned repository edit by this investigator; the coordinating task owns the daily change log and follow-up plan status.