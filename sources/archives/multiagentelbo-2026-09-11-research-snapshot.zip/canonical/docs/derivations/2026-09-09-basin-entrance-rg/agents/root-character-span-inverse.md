<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537","target_digest":"e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537"} -->

# Exact inversion in the local character span

Date: 2026-09-09. **ROOT DERIVATION PROPOSAL; INDEPENDENT RECONSTRUCTION PENDING.** This additive lemma supplies an exact implementation of RB03's permitted finite algebraic inverse. It does not change any basin constant, norm, model or error. The frozen initial root and author derivations remain unchanged. No scientific execution occurred.

## R15. Finite character-span inverse

Let V be a finite inventory of typed fine and coarse signs; a fine edge and a coarse label with the same coordinate are different variables. Identify a character support with a vector of F_2^V, using symmetric difference for vector addition. Suppose three rational Walsh polynomials f,a,d are given, and the actual conditional function is

    F = (f + f a + d)/(1 + a + f d).

Here a=y_p g_0 and d=y_p g_1 in RB03. The denominator is positive at every raw sign assignment by that section's norm gate. Let W be the linear span of the supports occurring in f,a,d, and choose any linearly independent basis w_1,...,w_r of W. Constants use the empty support. The map

    Phi(x) = (chi_(w_1)(x),...,chi_(w_r)(x))

from the raw sign cube onto the r-sign cube is surjective. Indeed, writing signs as powers of minus one turns Phi into the linear map with independent rows w_j over F_2. Row reduction gives rank r, so for every r-bit right-hand side there is a solution. This is a statement about a finite character group, not independence of the fine Gibbs signs.

Every support v in W has a unique basis mask m(v), and chi_v is the pullback of the basis-cube character chi_(m(v)). Therefore f,a,d are pullbacks of rational polynomials on that cube. Their complete pointwise evaluation and the displayed normalized quotient give a rational function F_tilde on every basis assignment. Positivity on the raw cube implies positivity of its denominator on every basis assignment by surjectivity.

Take all 2^r Walsh coefficients of F_tilde by finite Fourier inversion. Lift the coefficient at mask I to the literal typed support XOR_(j in I) w_j. The lift is injective because the w_j are independent, so distinct masks produce distinct supports. Fourier inversion proves that the resulting finite literal polynomial equals F pointwise on the entire raw cube.

No other raw character coefficient is missing. One proof is uniqueness of Fourier inversion on the full raw cube. Explicitly, F is constant on fibers of Phi. For a raw character outside W, there is an element of ker(Phi) on which that character is minus one: the orthogonal complement of ker(Phi) is the row span W, as follows directly from row rank and dimension. Pairing points of each fiber by that kernel element makes its Fourier coefficient zero. For a character in W, all fibers have the same size by the group homomorphism property, so its raw Fourier coefficient equals the lifted basis coefficient. Thus this algorithm computes exactly the full raw-coordinate Walsh table, including its scalar term.

The existing Banach-algebra norm bound applies to the literal lifted polynomial, with actual fine/coarse support cardinalities and actual spatial coordinates. It is not replaced by a weight based on the number of basis generators. The geometric inverse in RB03 and this finite transform are the same function and hence the same unique finite polynomial. No additional truncation error or probabilistic approximation is introduced.

## Deterministic finite algorithm and resource scope

Build a row-echelon basis by exact symmetric-difference elimination of the finite typed supports, using a fixed literal-variable order for pivots. Distinct leading pivots prove linear independence. Reduce every input support against the completed basis to obtain its unique mask. Full Walsh-Hadamard transforms can evaluate each polynomial on the basis cube and then invert the quotient table. A butterfly step uses only rational addition and subtraction. With the conventional sign assignment x_j=(-1)^bit_j, applying the same transform twice gives 2^r times the input table, so division by 2^r gives the exact inverse. Lift every nonzero coefficient through its basis mask; a zero coefficient is omitted only after exact cancellation.

The declared budget checks the finite rank/cube inventory before allocating 2^r entries and charges support elimination, full transform butterflies, quotient arithmetic and literal lifts under caller-increasable work and integer-bit limits. It is sufficient to bound these stated operations and guarded values; this is not an assertion about every machine allocation. For a fixed finite row all those quantities are finite. Increasing permitted rank, work, term inventory and arithmetic limits eventually permits its exact computation. A stopped basis construction or incomplete transform cannot supply a local inverse certificate or a successful whole oracle result.

## Rank bound for the actual strip row

The B-path strip polynomial is the endpoint character times a product of B-2 functions, each supported on the four characters 1,u_j,v_j,u_j v_j. Consequently every monomial in g_p is the endpoint character plus a combination of the 2(B-2) plaquette-neighbor characters. In a decomposition g_p=g_0+z_e g_1, removing z_e from the latter part adds at most the one character e. Multiplication by the observed coarse sign can be absorbed into the common endpoint character. Thus the supports in y_p g_0 and y_p g_1 lie in a span of dimension at most

    1 + 2(B-2) + 1 = 2B-2.

The original row f_e uses two three-neighbor characters, adding at most two dimensions. The quotient therefore has r<=2B. If no observed strip touches e, the row uses at most two independent characters. In particular B=3 requires at most six basis signs, even when its raw local support contains many more fine edges. This is an upper bound; relations among the actual characters can reduce the rank further.

This rank statement does not replace the full strip law by a six-sign independent probability model. It bounds the finite function algebra needed to evaluate a conditional row. Tiny probability controls remain separately limited to their actual sign carriers. The global stationarity polynomial still includes all fine supports, observed labels, updates and cancellations reached at each retained order.
