<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537","target_digest":"e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537"} -->

# Author comparison of the basin row and oracle interfaces

Date: 2026-09-09. **AUTHOR INTERFACE RECONSTRUCTION, NOT INDEPENDENT VERIFICATION OR NATIVE CLOSURE.** The initial author construction and proposals were persisted before reading the current root draft. Their SHA256 values remain f11a6b0d81189f8dd388fc285f3ab4fd00586fc0ff4d89588b3e69f51b9b21c7 and b662f13ad3647bfaea969413e644ae18dc7dd2b824524b3284a9d88423f67c3f. This separate note compares RB01–RB07 in root-weighted-row-construction.md, SHA256 b11ee101c8c9e5f5373bc1b4f3f40fbf4df77e3106a7d9789c9026ad239b9936, against that initial derivation. It also reads, without execution, the unchanged finite_amplitude_rg.py admission and word interfaces. No worker draft or basin implementation is reviewed here. No test, experiment, source import or resource execution occurred.

## BI01. The sharper compact activity is valid

**RECONSTRUCTED.** RB01's exact four-point coefficients agree with BE02. For t=2c/(1+c^2), the derivative of the unweighted coefficient sum in b is

\[
 \partial_b R(b,t)=1-\frac{2bt(1-t^2)}{(1-b^2t^2)^2}
 \ge 1-\frac{2t}{1-t^2}>0.
 \label{eq:rg-bi-compact-monotonicity}
\]

The inequality uses b/(1-b^2t^2)^2<=1/(1-t^2)^2. The derivative in t of t/(1-b^2t^2) is positive, and c to t is increasing for c<1. Hence evaluating R at the compact upper endpoints supplies a valid sharper uniform value R_*. The previously derived rational slack makes Delta=1-R_* positive throughout the specified c_max<1/12 domain. The root choice sigma=R_*/(1-Delta/4) is valid because exp(6alpha)<=1/(1-Delta/4). It is sharper than my initial sigma=1-3Delta/4; neither convention changes the admitted parameter domain. The endpoint weight is retained in G_B. The support description and disjointness require B>=3 and Euclidean residues for negative coordinates, as both constructions explicitly state.

## BI02. Prescribed weights and the exact local inverse

**RECONSTRUCTED.** Root RB02 uses zeta=2lambda/B in fine coordinates; my BE04 uses the slightly stronger scaled radius exponent 2lambda+1. Both are Banach coefficient algebras because XOR reduces cardinality and rooted radius of a union is at most the sum of its radii. An original fine update reaches anchors at distance at most one. A strip update at any member of S_p reaches anchors in S_p and its coarse label at fine distance at most B. This includes the local row's original neighbors. Thus the local estimates sigma exp(2lambda/B) and A_beta A_2lambda G_B have the asserted radius costs. There is no multiplication of every original update by exp(2lambda), which would obstruct arbitrary prescribed lambda.

Write g_p=g_0+z_e g_1. Direct normalization of the two tilted probabilities gives exactly

\[
 F_e=f_e+\frac{y_p(1-f_e^2)g_1}
                    {1+y_p(g_0+f_e g_1)}.
 \label{eq:rg-bi-row}
\]

The local weighted norms of y_p g_0 and y_p g_1 are each bounded by H_B. Removing e from g_1 improves the fine cardinality weight and cannot worsen its rooted radius. With the base row norm bounded by p, the denominator perturbation has norm at most (1+p)H_B. The first RB03 gate makes its geometric inverse norm at most two. The numerator has norm at most (1+p^2)H_B. The second gate consequently gives ||F_e-f_e||<=(1-p)/2, and ||F_e||<=r=(1+p)/2<1. These estimates retain all terms of the normalized observation factor, including its even log contribution. They do not assume fine-coordinate independence.

For rational parameters, evaluating the displayed finite rational function over its entire sign cube gives rational values with a positive denominator. Its full Walsh transform is the unique finite coefficient polynomial of that function. Absolute convergence of the geometric inverse identifies its coefficient expansion with this polynomial: powers can repeat characters, but their XOR supports remain inside the same finite variable inventory, and coefficients may be combined absolutely. This proves compatibility of an exact finite truth table or a complete exact algebraic inverse with the norm proof. It does not license truncation of that local inverse without charging a separate error. The target strip must be absent from every local row used to calculate its own conditional mean.

## BI03. Stationarity and the all-exterior passage

**RECONSTRUCTED WITH THE FINITE-KERNEL STEP MADE EXPLICIT.** The factor 1/|S| in RB04 is necessary. Each summand replaces one fine bit by its conditional mean, removes one fine-cardinality weight and incurs only its local radius cost. Averaging gives ||A(1-Pi)||<=exp(-alpha)r<=r; no support-size factor remains. Gibbs stationarity first applies to normalized real finite-volume laws. The Pi terms are absorbed once, and the unabsorbed remainder has absolute expectation bounded by its coefficient norm. This establishes the series as the actual expectation before Fourier identification.

At fixed B and substitution order, the reached variables and observed labels are finite. Any sufficiently large fine volume containing their whole local supports has identical coefficients through that order, regardless of its exterior. Fixed exterior substitution reduces the norm. Crossing observation factors and plaquette factors must still be included in the finite Gibbs weight; deleting crossing factors would be a different intermediate specification. The geometric remainder is uniform, so finite-volume limits exist and are boundary independent. Positivity, normalization and consistency of finite-cylinder probabilities pass to these limits. A countable cylinder extension gives a law, and finite local DLR identities pass to the limit. Conversely, the same stationary series fixes every character expectation of any law with these local rows, giving uniqueness for each partial or full coarse observation pattern.

For a finite coarse set A, construct the fine tilted law observing the complement of A and define its finite coarse conditional density by

\[
 \gamma_A(x_A\mid y_{A^c})=
 E_{\mu^{y,A^c}}\prod_{e\in A}(1+x_e g_e),
 \label{eq:rg-bi-finite-kernel}
\]

relative to fair counting on A. The fair average is one, and the density lies between (1-G_B)^|A| and (1+G_B)^|A|. Increasing finite observed subsets of A^c gives this expression uniformly in every exterior because each fixed substitution history sees only finitely many observed labels. Finite Bayes identities therefore pass to the limit, including consistency under nested conditional sets. Finite-cylinder conditioning of the actual channel law gives the same kernels; uniform convergence implies its DLR identities. This is the direct bridge behind RB04–RB05, rather than conditioning on an infinite event or choosing an almost-sure version.

## BI04. Canonical odds coefficients and the factor four

**RECONSTRUCTED.** Positivity and consistency of gamma_{e,f} imply that both sides of RB05's square identity equal one half of the logarithm of its two-by-two cross ratio. Absolute coefficient convergence permits taking the Walsh coefficient in all remaining variables. The resulting equality identifies the coefficient marked at e with the coefficient marked at f, for each finite support containing both. Thus J_T is independent of its marked edge. Its absolutely summable single-site odds equal the constructed odds everywhere. For a fixed finite A and exterior, these single-site ratios determine a positive joint probability uniquely along the connected sign cube, proving equality of the full conditional specifications. Translation covariance supplies one canonical orbit representative by the actual first edge, retaining its orientation and negative relative coordinates.

For exact consistent rows, my BE08–BE09 directly bound the norm at a chosen incident edge. Approximate row polynomials generally do not satisfy the square identity, so the stronger orbit-incidence accounting in both oracle proofs is necessary. For an orbit of size n, its contribution to the norm at a fixed orientation is n_i(T)n exp(kappa n+lambda diam T)|J_T|, where n_i(T)<=n. Independently checking RB05's improvement gives

\[
 n^2 e^{-(n-1)}\le\sup_{x\ge1}x^2e^{-(x-1)}
 =4/e<2.
 \label{eq:rg-bi-incidence}
\]

The derivative of the logarithm is 2/x-1, so the supremum occurs at x=2. Therefore n^2 exp(kappa n)<=2 exp(kappa) exp(beta(n-1)). Also diam T is at most twice its radius from the included root. Summing the two actual first-edge orientations yields exactly the safe factor 4 A_kappa. My initial factor 8 E_kappa is valid but unnecessarily larger. The sharper root factor may be used without changing the preserved initial proof. This argument applies to all omitted coefficients as well as to returned coefficients. Translating every noncanonical row term into a canonical support and accumulating it would instead overcount; canonical emission must retain only terms whose literal first edge is the root.

## BI05. The complete oracle tail

**RECONSTRUCTED.** If m_K includes absorbed orders zero through K, its first omitted order is K+1. RB06's d_K=A_2lambda G_B r^K/(1-r) is conservative and valid for every nonnegative K; the sharper exponent K+1 is unnecessary. Absolute summation also bounds both m and the included polynomial m_K by M_B. For two elements u,v of this algebra with norms at most M_B, telescoping each odd power gives

\[
 \|\operatorname{atanh}u-\operatorname{atanh}v\|
 \le\frac{\|u-v\|}{1-M_B^2}.
 \label{eq:rg-bi-atanh}
\]

Truncation after powers 1,...,2L-1, L>=1, has remaining norm at most M_B^(2L+1)/[(2L+1)(1-M_B^2)]. The sum of these two bounds is therefore an error in the same prescribed rooted norm, not merely a pointwise error. Canonical extraction and BI04 imply full interaction error at most 4 A_kappa delta_u, including every support absent from the output table. Exact local inverses, every reached source, and all nonzero coefficients must be retained before this bound applies. Scalar absorbed terms of the mean remain part of the one-edge field after attaching the target; they are not an ignorable action constant.

For finite K and L, local rows depend on finitely many fine variables and one coarse label; only finitely many row substitutions and polynomial products are needed. Exact rational truth tables and arithmetic are finite even when expensive. Increasing K and L makes the certified errors tend to zero. This is a terminating unbounded-resource oracle argument, not a claim that a particular resource budget or truth-table carrier is small. An incomplete local inventory, arithmetic guard or interrupted substitution supplies no successful full-norm certificate.

## BI06. Monotone gates and the old admission interface

**RECONSTRUCTED AGAINST THE READ SOURCE.** Every prescribed positive kappa and lambda enters finite rational exponential upper constants. The base gate sigma/(1-2lambda/B)<=p becomes valid eventually. On its domain G_B and H_B decrease in B; r is fixed. Hence the inverse gate, M_B<=1/2 and E_B<epsilon_0/16 all hold monotonically after some finite integer. Their strict limiting slack proves termination of the rational B search uniformly over the compact parameter box. No smaller output weight replaces the prescribed pair.

For the unchanged finite_amplitude_rg.py positive exponential enclosure, write its degree-m upper endpoint as U_m=S_m+t_{m+1}/(1-a), where a=x/(m+2). With b=x/(m+3), direct subtraction gives

\[
 U_m-U_{m+1}=t_{m+1}
 \frac{a(a-b)}{(1-a)(1-b)}\ge0.
 \label{eq:rg-bi-exp-monotonicity}
\]

The denominators must first be positive. Positive lower endpoints increase. For a negative exponent, the upper endpoint is the reciprocal of a positive lower endpoint and thus decreases. The old code's K upper endpoint and M upper endpoint consequently decrease; its ell upper endpoint decreases; and each positive epsilon candidate 1/(2K) and (1-ell)/(2M) increases once the constants are valid. The minimum epsilon_lower is nondecreasing.

The first successful zero-input admission on the uncapped doubling sequence therefore supplies epsilon_0>0. With sufficiently large allowed precision, a nonzero finite table cannot be admitted at an earlier doubling degree than that zero input: valid constants would already admit zero. At later degrees its epsilon_lower is at least epsilon_0. Norm upper enclosures of the fixed finite table converge to its norm, so a table with norm below epsilon_0/8 is eventually admitted. The returned radius is (norm_upper+epsilon_lower)/2 and hence at least epsilon_0/2. A capped final non-doubling degree can change this numerical lower comparison; the wrapper's explicit check E_B<returned radius is consequently still required for every actual successful result. The termination argument may choose sufficiently large resources on the ordinary doubling sequence and is unaffected by that finite-cap seam.

## BI07. Common-ball uncertain-input comparison

**RECONSTRUCTED.** RB07 can retain its present source-compatible admission argument. Its essential mathematical step is a comparison of two exact trajectories in one ball. If the true basin input J and its finite oracle output Jhat both lie in the returned radius, the admitted map sends both exact trajectories into that ball. The straight segment between the two inputs at every step stays in the convex ball, so the recorded derivative bound gives

\[
 \|R_{a_j}\cdots R_{a_1}J-
       R_{a_j}\cdots R_{a_1}\widehat J\|
 \le\delta\prod_{i=1}^j L_i.
 \label{eq:rg-bi-trajectory}
\]

The old evaluator separately bounds its staged polynomial against the exact trajectory starting at Jhat by e_old. The triangle inequality gives e_old+delta product_i L_i. It pays the input uncertainty once, and does not reinterpret the old exact-input certificate. With oracle delta<t/2 and old tolerance t/2, the total is strictly below t because L_i<1. The empty word uses an empty product equal to one. Root RB07's E_B<epsilon_0/16 and delta<epsilon_0/16 imply both starting inputs lie in the radius established in BI06. The wrapper must inspect the actual returned radius and Lipschitz values and fail closed if that evidence is absent. An incomplete old result cannot be promoted using the abstract existence argument.

Exact channel composition and the unique canonical coefficient representative then identify the true trajectory with the actual B times product-of-factors path push. The output polynomial is not asserted to equal that infinite interaction, nor to equal an independently truncated direct polynomial.

## Findings and scope

**AUTHOR FINDING.** No mathematical discrepancy requiring a change to RB01–RB07 was found in this interface reconstruction. The root factor 4 A_kappa is sharper than the author's preserved factor 8. BI03 explicitly supplies the finite conditional-kernel passage underlying the all-exterior statement, and BI06 distinguishes the sufficient-resource doubling argument from a capped final precision step. These are proof-interface clarifications, not execution evidence or independent adjudication. Actual source completeness, guards and numerical packet outcomes require their separately owned source and execution records. The interaction is a representative of the fixed normalized model; this comparison adds no curvature penalty, source normalizer, physical clock or continuum claim.
