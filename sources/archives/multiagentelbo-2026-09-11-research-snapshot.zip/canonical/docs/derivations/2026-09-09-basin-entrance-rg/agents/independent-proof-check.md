<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537","target_digest":"e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537"} -->


# Independent mature basin proof reconstruction

Date: 2026-09-09. Root authorized mature access after the initial Markdown and proposals were frozen at ef340e91e72fc4764cd97336d8858a09c6152260493391868fcb9521635413d9 and e06bcd5af15aabdb3593bd5fba82219e66f9dd3b573e72874a720c89ffa8e729. Both remain unchanged. I read the full root weighted-row proof and R01-R14 proposals, the author's initial basin construction and full interface proof, then the root character-span inverse and R15 proposal. I also reread the unchanged finite_amplitude_rg.py exponential, constant and admission routines; its complete source had been checked in the prior admitted run. No new basin implementation source or numerical evidence was available for this stage, and none is implied. No scientific import, test or producer was run by this lane.

The new absorbing character-stationarity argument supplies the missing mechanism in initial IB09. It bounds all generated coarse-character orders by a contracting weighted fine-character substitution, rather than inferring their sum from real mixing or inverting a volume-sized marginal density. The initial counterexamples remain valid and are bypassed, not withdrawn. The reconstruction below supports the mathematical claims conditionally on the declared prior law/operator premises; it assigns no ledger state. Shared model family, context and filesystem limit independence. The direct identities, counts and inequalities, not agreement among lanes, are the evidence.

## MC01. R01-R02: disjoint strips and the compact activity

Initial IB01-IB03 independently established the simultaneous B-2 interior channel and exact local normalization. The mature proof refines the remaining inventory: a horizontal strip contains its two retained endpoint edges, 2(B-2) horizontal neighboring edges and 2(B-1) vertical neighboring edges, totaling 4B-4. It has anchor diameter at most B-1 and radius at most B from its own coarse anchor or any strip member.

The claimed disjointness is stronger than mere disjoint interiors and is valid. Horizontal edges appearing in horizontal-strip side contributions have x residue 1,...,B-2 and y residue 1 or B-1. Horizontal edges in a vertical strip have x residue 0 or B-1 and y residue 1,...,B-1. The x classes do not intersect. Retained horizontal endpoints have y residue zero and belong to their own horizontal path only. Within one strip orientation, the transverse side residue picks a unique adjacent retained grid line for B>=3, and the longitudinal coordinate picks a unique segment. The rotated argument covers vertical edges. This also handles negative coordinates with Euclidean residues. At B=2 the side residues collide, which is why B>=3 is a real hypothesis.

The four-value calculation for f(u,v)=tanh(h+J(u+v)) uses f(+,+)=(b+t)/(1+bt), f(-,-)=(b-t)/(1-bt), f(+,-)=f(-,+)=b, t=2c/(1+c^2). It gives the stated a0,a1,a12, with a0>=0,a1>=0,a12<=0, and

 R(b,t)=a0+2a1-a12=b+t(1-b^2)/(1-b^2t^2).

Differentiation yields dR/db=1-2bt(1-t^2)/(1-b^2t^2)^2>=1-2t/(1-t^2)>0 for t<=24/145. The t derivative is positive. Thus the upper compact endpoints give R_*. Since R(1,t)=1, integrating the lower derivative bound gives 1-R_* >=(13489/20449)(1-b_max)>0. The numerical integers follow exactly from 2(24/145)/(1-(24/145)^2)=6960/20449. These are rational inequalities, not approximate evaluation.

With Delta=1-R_*, alpha=Delta/24, the fine coefficient norm has ||f_e||_alpha<=exp(6alpha)R_*<=R_*/(1-Delta/4)=sigma<1. The two endpoint signs cost exp(2alpha)<=1/(1-2alpha), so G_B=sigma^(B-2)/(1-2alpha) bounds the complete strip polynomial. Overlapping neighbor characters inside one strip can cancel under XOR but cannot increase the submultiplicative bound. Every scalar term is included in these function norms.

The actual finite parity density is E_mu product_p(1+y_p g_p). Here mu may be the full original fine law because each g_p ignores all integrated interiors; it is the same expectation as under its W marginal. The observed auxiliary fine tilt is not being identified with the original fine posterior conditioned on the hard parities. It has the correct W marginal and therefore the correct target g expectation. Its full factors and normalizer are indispensable; this avoids a possible support/type confusion.

## MC02. R03-R04: prescribed weights and complete conditional rows

The root algebra keeps fine characters and coarse external labels as different typed coordinates. Its weight is exp(alpha|S|+beta|T|+zeta D), with beta=kappa+1 and zeta=2lambda/B. The root-centered radius includes the original marked fine anchor even for an empty support. XOR decreases both cardinalities, and the radius of a union is at most the sum of its rooted radii. This proves submultiplicativity.

For a substitution at e in S, let U,V be a local conditional-row term. The output fine support is (S without e) symmetric_difference U and the coarse support is T symmetric_difference V. Its weight is at most the input weight times exp(-alpha) times the local weight of U,V centered at e. The radius inequality follows by measuring each new anchor from e and then e from the original root. This establishes the actual replacement bound even when labels repeat or cancel. An unrooted diameter shortcut would not prove it.

Original fine row neighbors lie within one fine unit, so their local norm is at most sigma exp(2lambda/B). The rational gate sigma/(1-2lambda/B)<=p=(1+sigma)/2 pays any fixed positive lambda at sufficiently large B. An observed strip term has radius at most B from e, including its coarse label at its own scaled anchor. Thus H_B=A_beta A_2lambda G_B is a valid local norm bound for both y_p g0 and y_p g1 after writing g_p=g0+z_e g1. Deleting e from g1 only improves its fine-cardinality weight.

Direct normalization of the two positive probabilities, with original mean f_e, gives

 F_e=[f_e+y_p(f_e g0+g1)]/[1+y_p(g0+f_e g1)]
    =f_e+y_p(1-f_e^2)g1/[1+y_p(g0+f_e g1)].

No term of the even observation tilt is discarded. Pairwise strip disjointness means at most one factor changes a given row. If that strip is the omitted target or is not observed, the row remains f_e. All inversion arguments occur in a local finite-variable function algebra, not the exterior-sized marginal denominator from initial IB06.

The denominator perturbation norm is at most (1+p)H_B<=1/2. Its geometric inverse norm is at most two. The added numerator norm is at most (1+p^2)H_B, so the second gate yields ||F_e-f_e||<=(1-p)/2. Consequently ||F_e||<=r=(1+p)/2<1 uniformly over the compact box, all observed inventories and every fine/coarse sign assignment. Setting boundary signs to constants cannot increase the coefficient norm. The positivity of the actual row is separately guaranteed by its normalized positive factors; the algebra inverse supplies a coefficient bound, not a complex probability assumption.

## MC03. R05-R06: absorbing stationarity and full boundary limits

For a nonempty fine character S, stationarity of each conditional bit gives E[chi_S y_T]=E[chi_(S without e)y_T F_e] for every e in S. Averaging over e yields A with the exact 1/|S| factor. The replacement inequality from MC02 gives ||A(1-Pi)||<=exp(-alpha)r<=r. Without this average, a support-size factor would break the claimed contraction. Pi is coefficient projection onto empty fine support, and N=(1-Pi)A is contractive as well. A is zero on absorbed terms, which prevents reinverting the constant mode.

For a finite positive normalized observed tilt, write E F=Pi F+E(1-Pi)F and repeatedly substitute stationarity on its unabsorbed part. This yields the displayed sum Pi F+sum_(k>=1)Pi A N^(k-1)(1-Pi)F. The omitted expectation tends to zero in uniform real norm because sign values have modulus one and the unabsorbed coefficient norm decreases geometrically. Each absorbed term has coefficient norm at most r^k||F||, so the series also converges in the weighted coarse coefficient algebra. Equality with the actual normalized expectation is proved pointwise before any Fourier identification; no boundedness of an unproved Gibbs-to-Walsh map is assumed.

Every exact local row is a finite rational function of a finite fine inventory and at most one coarse label. Its unique full Walsh polynomial therefore has finite support even though the norm proof used an infinite inverse series. A fixed number of substitutions visits a finite inventory. Fine volumes containing that inventory and every touching local factor have identical coefficients through that order, independently of their exterior. Reducing fixed boundary signs is contractive. The remaining uniform geometric tail proves boundary independence of the limit. Finite observation inventories similarly stabilize once they include every reached label; the omission of the target remains fixed.

The full finite-kernel passage in the author's interface is necessary and valid. For finite free coarse A, observe its complement and take the limit auxiliary fine tilted law. Define its A-density by E product_(e in A)(1+x_e g_e), relative to fair counting. Fair averaging is exactly one. Since |g_e|<=G_B<1, the density lies between (1-G_B)^|A| and (1+G_B)^|A|. Finite Bayes identities give the corresponding conditional kernels before the limit; uniform convergence passes positivity, normalization, nested consistency and exterior continuity to every exterior. Finite-cylinder conditioning of the actual path push has the same finite identities, so its limiting DLR kernels agree. Infinite-event conditioning is not used. The countable finite-state cylinder extension and cylinder-determination argument are the admitted/direct measure construction, not a conclusion from numerical stabilization.

This closes the initial IB09 summability mechanism. Applying the same root construction with lambda replaced by lambda+1, if needed, gives the spare distance weight in the particular sufficient lemma stated there. The fine alpha can remain small because coarse beta and the scaled radius independently pay the prescribed output weights. It neither weakens kappa/lambda nor invokes the false covariance-tree estimate from IB08.

## MC04. R07-R08: marked consistency, all incidences and the factor four

Starting from g_p0 gives rooted norm at most A_2lambda G_B. The absorbed sum has norm at most M_B=A_2lambda G_B/(1-r). Under M_B<=1/2 the odd series converges absolutely and bounds the half log odds by U_B=M_B/(1-M_B^2). The coefficient with no exterior label is a one-edge field after attaching the target; it is not a disposable scalar action term.

The positive two-edge conditional kernel gives the four-corner equality of discrete differences of the two half log odds. Absolute coefficient convergence permits fair coefficient extraction term by term. The coefficients marked at either edge of a support agree. Translation covariance preserves the exact canonical nonempty interaction. Its absolutely convergent one-edge odds match the actual odds everywhere. In a finite target, equal one-flip probability ratios determine every joint atom ratio along the connected cube, and normalization forces equality of the complete kernel. This supplies every-exterior identification, not just equality of a few observables.

For a canonical support T of size n, there are exactly n_i(T) translates incident to a fixed orientation-i edge, and n_i(T)<=n. Its norm contribution is therefore at most n^2 exp(kappa n+lambda diam(T))|J_T|. Since the maximum of x^2 exp(-(x-1)) for x>=1 is 4/e<2, one has n^2 exp(kappa n)<=2 exp(kappa)exp(beta(n-1)). The row has n-1 other coarse labels. Its rooted radius D is B times their maximum coarse distance from the included target, while diam(T) is at most twice that maximum. Thus exp(lambda diam(T))<=exp(zeta D). Summing the two canonical first-edge orientations gives the valid complete bound E_B=4 A_kappa U_B.

This incidence argument also applies to approximate row errors. The finite row polynomials need not obey exact square identities. Retaining only terms whose literal first edge is the chosen root defines one honest finite orbit table. Translating all other row terms to that root and adding them would overcount. The factor four pays both orientation sums and the n^2 incidence/cardinality count; there is no additional root/tree multiplier.


## MC05. R09-R11: complete finite oracle and its omission bound

For rational b,c each local F_e is a rational function of finitely many signs. The denominator is positive on every raw sign assignment by the inverse-domain gate. A complete normalized-counting Walsh transform is therefore a finite exact rational polynomial, including its constant coefficient. The convergent geometric inverse in MC02 proves a coefficient-norm bound for this same unique polynomial; it does not instruct the implementation to omit an uncharged inverse-series remainder. The exact finite algebra and the norm proof describe the same function.

Write

 m_K = Pi g + sum_{k=1}^K Pi A N^(k-1)(1-Pi)g.

The full series and each finite partial sum have rooted norm at most M_B=A_2lambda G_B/(1-r). The remaining sum is bounded conservatively by

 d_K = A_2lambda G_B r^K/(1-r).

The first omitted substitution is actually K+1 in this convention; the stated r^K bound is larger and valid, including K=0. For two algebra elements of norm at most M_B<1, telescoping each odd power gives

 norm(atanh(u)-atanh(v)) <= norm(u-v)/(1-M_B^2).

Indeed the difference of the n-th powers is the sum of n products with one u-v factor, each bounded by M_B^(n-1) norm(u-v). After division by n and summation over odd n, the scalar series is sum_{j>=0} M_B^(2j)=1/(1-M_B^2). With an odd polynomial containing powers 1,3,...,2L-1, L>=1, the omitted atanh tail is at most

 M_B^(2L+1)/((2L+1)(1-M_B^2)).

Consequently the two canonical-root rows define a finite rational orbit table whose complete prescribed-norm error is bounded by

 4 A_kappa [d_K/(1-M_B^2) + M_B^(2L+1)/((2L+1)(1-M_B^2))].

This is a sum over the entire interaction family, including coefficients and supports absent from the finite table. The first term includes every later stationarity substitution and every effect it could have on the full atanh. The second term bounds all later odd powers of the finite polynomial. It would be invalid to discard a reached monomial merely because its present support is fine-constant, presently cancels, has zero current output, or appears too large before a subsequent XOR. The absorbing operator intentionally separates and records its fine-constant part; that is not an arbitrary pruning rule.

The oracle existence claim is mathematical finite-resource existence. Fixed K and L give a finite variable inventory: each local substitution has finite range and a complete finite table, and the starting strip has finite support. Finite products and sums of these finite tables remain finite. Each coefficient calculation has finite rational numerator and denominator. Since r<1 and M_B<=1/2, one can choose finite K,L making the displayed error less than any prescribed positive rational tolerance, then choose finite work, inventory and arithmetic budgets exceeding the resulting finite operation sequence. This proves existence of a sufficiently resourced completion. It does not assert that the currently selected budget, machine memory or time is sufficient, and it does not validate an implementation that imposes a non-increasable ceiling. An interrupted row, substitution stage, transform or odd product must remain incomplete; a partial table cannot inherit the complete error bound.

## MC06. R12-R14: uniform depth, actual-radius uncertainty and exact words

All quantities in the depth gates admit rational outer bounds. In particular, sigma<1, r=(1+p)/2<1 and the prescribed A_beta and A_2lambda are fixed after the compact box and kappa,lambda are fixed. The base local-radius gate sigma exp(2lambda/B)<=p holds eventually, for example through the rational sufficient bound sigma/(1-2lambda/B)<=p with B>2lambda. G_B decreases geometrically with B. Hence H_B, M_B and E_B=4 A_kappa M_B/(1-M_B^2) decrease after the same fixed definitions, and every displayed strict gate eventually holds and remains valid for all larger integers. A sequential rational search therefore returns a finite B0 for every prescribed positive rational kappa,lambda. No smallness condition on those prescribed weights has been substituted for the contract.

The connection to the old evaluator needs more than the mathematical local radius. The author's interface argument and the unchanged old _exp, _constants and _admit routines supply the implementation-specific margin. Let epsilon_0 be the positive lower-radius value at the first successful zero-input admission on the uncapped doubling sequence of exponential degrees. Such a degree exists because the rational exponential enclosures converge and the limiting local radius is positive. The upper exponential enclosure decreases at successive valid degrees. If a=x/(m+2) and b=x/(m+3), its remainder terms obey

 U_m-U_(m+1) = t_(m+1) a(a-b)/((1-a)(1-b)) >= 0,

with the usual positive Taylor term t_(m+1) and valid denominators. Positive exponential lower bounds increase, so their reciprocal negative-exponential upper bounds decrease. The resulting upper K, M and ell bounds decrease; the local epsilon lower bound is nondecreasing on these valid degrees. A nonzero input cannot first pass at an earlier doubling degree than zero input because zero meets the input-norm inequality whenever any finite input does. With enough permitted degree for that ordinary sequence, its actual word radius is at least epsilon_0/2. This explicitly uses the source's radius convention.

A capped final degree that is not on the doubling sequence must not be silently included in that comparison. It may be the first successful input admission despite a different sequence history. The interface proof states this limitation and the wrapper checks the actual returned radius independently. That actual-radius check remains mandatory even when the existence proof uses an uncapped sequence with sufficiently large resources. This is the resolution of initial IB10's early-admission precision issue; the initial warning was valid and is not erased.

Choose B0 to give E_B<epsilon_0/16 for all B>=B0. Compute a finite table P with norm(J^(B)-P)<=eta<min(tolerance/2,epsilon_0/16). Then norm(P)<epsilon_0/8 and the old evaluator can admit it with sufficiently large finite resources. Its ordinary exact-input execution supplies a finite polynomial output, an error e_old, a radius r_actual, and step Lipschitz upper bounds L_j. The wrapper must check E_B<r_actual. The admitted P is already inside that same actual ball. The convex segment between P and the true J^(B) lies inside it, and the exact maps preserve the common ball by the admitted local theorem. The Banach-space mean-value integral therefore gives, successively,

 norm(R_word J^(B)-R_word P) <= eta product_j L_j.

Adding the old evaluator's exact-input error gives e_total=e_old+eta product_j L_j. The old polynomial is never falsely treated as an uncertain-input certificate by itself. A finite word has finitely many finite constants; refining eta and requesting a sufficiently small old output tolerance produces e_total below any positive requested tolerance under sufficiently large resources. The empty word has product one. Actual radius failure is an incomplete interface result, not a license to enlarge or ignore the old certified radius.

For exact laws, geometric consecutive straight-path products have the literal identity T_a T_B=T_(aB), including floor phases and orientation. Every-exterior odds identify the unique canonical scalar-free interaction. Thus the actual exact RG image of J^(B) is J^(aB), and finite words compose to their exact total block factor under admission. The finite approximations inherit the preceding error bounds, not exact coefficient equality. Neither this word identity nor the scalar-free table manufactures a partition-function offset, likelihood term, observation-dependent VFE, continuum limit or additional Fisher/gauge dynamics.

## MC07. R15: full character-span inversion

The root's additional finite-algebra optimization preserves the local row exactly. Let V be the finite set of typed raw fine and coarse signs, and regard every character support as a vector in F_2^V. Let W be the span of all support vectors appearing in f,a,d, where a=y g0 and d=y g1. Then the row is the function

 F = (f+f a+d)/(1+a+f d).

Choose independent support vectors w1,...,wr spanning W. The map from raw sign assignments x to the r signs chi_wj(x) is surjective: in bit coordinates its matrix has independent rows and rank r, hence image dimension r. Each fiber has cardinality 2^(|V|-r). This is a statement about normalized counting and finite linear algebra. It does not assert that these basis characters are independent under the interacting Gibbs law.

Every input support has a unique basis mask, so evaluating all 2^r basis-sign assignments evaluates the exact local rational function on its entire range. Surjectivity transfers the raw positive-denominator premise to every basis assignment. The complete basis-cube Walsh transform has exact inverse because H_r H_r^T=2^r I; butterfly updates followed by division by 2^r compute that transform without approximation. Lifting a mask means taking the literal XOR of its selected w_j. Independence makes this lifting injective on masks. The lifted coefficient is exactly the raw normalized-counting Walsh coefficient because every basis assignment has the same number of raw preimages.

There are no omitted raw coefficients outside W. For a support v outside W, the rank identity W=(ker Phi)^perp gives a fiber-preserving raw flip on which chi_v changes sign. Pairing raw assignments by that flip cancels the coefficient of any function of the basis signs. Thus the transformed table, including zero and constant entries before exact cancellation, is the complete unique raw Walsh table. Norms and spatial weights must subsequently be evaluated on the lifted typed literal supports, not on the count of basis bits.

The rank bound is also a support bound rather than a claim about physical volume. A strip polynomial is generated by its common endpoint character and the two neighbor characters for each of its B-2 eliminated interiors. Incorporating the coarse observed sign into the common endpoint character and separating g0 from z_e g1 requires at most one additional generator associated with deletion of e. This gives at most 2B-2 generators for y g0 and y g1 together. The two base neighboring characters in f increase the span dimension to at most 2B. An unobserved row uses at most two. At B=3, therefore, a rank-six algebraic cube can represent a row that originally depends on more physical fine signs. It is not a replacement six-sign physical probability model.

The mathematical optimization fails if the basis is dependent, the coordinate map misses a support, only selected basis atoms are evaluated, the full inverse is replaced by an uncontrolled series truncation, or literal positions/types are discarded after lifting. Those are concrete implementation obligations for the later source check. Exhausting a transform budget gives no completed inverse. No current implementation execution is implied here.

## MC08. R16: explicit whole-norm spatial tail

This additional bridge makes the contract's spatial-tail wording explicit. It depends on R05, R08 and R10. Each full local row depends only on neighbors within fine radius one or on one complete strip and its coarse label within fine radius B of the updated edge. The initial target g has fine radius at most B from its coarse root. Induction on substitutions therefore bounds every fine anchor and scaled coarse anchor reached after k substitutions by (k+1)B. In particular m_K uses only coarse labels within coarse radius K+1 of the root.

The function atanh(m_K) is defined by an infinite power series, but m_K has a finite coarse-variable inventory and algebra norm at most M_B<1. Every power uses that same inventory: multiplication only XORs existing supports. The convergent function on this finite cube has one full finite Walsh expansion, and pairing over any sign absent from the inventory shows that all coefficients using that sign vanish. Therefore, after the root is attached, every support in the full atanh(m_K) row has diameter at most 2(K+1). Its coefficients need not be rational; this comparison function is used for a tail proof, not claimed to be the executed finite oracle.

The previous telescoping bound yields

 norm(atanh(m)-atanh(m_K)) <= d_K/(1-M_B^2).

The literal canonical-root extraction cannot create a coordinate outside that inventory. The incidence argument in MC04 now gives the explicit complete spatial-tail estimate

 sup_e sum_{S containing e, diam(S)>2(K+1)} |S| exp(kappa|S|+lambda diam(S)) |J_S|
 <= 4 A_kappa d_K/(1-M_B^2).

Both orientations and all translated incidences are already included in the factor four. For any integer R>=2, choose K=floor(R/2)-1. Then 2(K+1)<=R and the same right-hand side bounds the stricter tail diam(S)>R. For R<2 the complete bound E_B is available. This is a rational, uniform, geometric-in-K upper tail once the rational norm gates hold. It bounds the actual entire omitted interaction family, not just a finite list of sampled coefficients or a pointwise probability error.

The proof would fail if one substitution could access a strip farther than B from its updated fine edge, if the response cutoff were confused with the odd-polynomial cutoff, if multiplication introduced new labels, or if the diameter/root-radius conversion lost its factor two. Each is excluded by the explicit literal locality induction and finite-character algebra above. Implementing the finite odd polynomial still requires its separate power-tail term from MC05; R16 does not remove that error charge.

## MC09. Falsifier disposition and scope

The original general objections are retained. Real one-edge bias or continuity alone does not bound a sum of all high-order Walsh coefficients; a fixed-parity product can violate covariance-product cumulant estimates; arbitrary prior weaker norms do not imply entry in this norm; and numerical agreement cannot establish all-exterior identification. The mature proof does not use those implications. It supplies a complete joint-algebra contraction, exact normalized conditional rows, locality at each algebraic order and absolute full-family bounds. The small auxiliary fine weight alpha and the prescribed coarse weights are distinct; only the fine interaction uses the auxiliary smallness.

I found no unresolved mathematical failure in R01-R15 under the explicitly admitted fine-law/local-RG premises, and MC08 supplies R16. This is a reconstruction outcome rather than a ledger state. Erasing numerical data, code comments and all other agents' judgments leaves the proofs in MC01-MC08: exact finite identities, rational inequalities, contraction and limits, coefficient uniqueness, and the stated prior admitted theorems. The finite-source correspondence and any numerical outcomes remain separate obligations. In particular, the word-interface existence discussion uses an explicit source correspondence to the unchanged prior evaluator and requires the actual-radius check; no new wrapper is certified before its source is read.

The new construction resolves the initial missing IB09 mechanism; it does not retroactively change the initial record into a complete proof. The mathematical finite-resource quantifier remains existential for sufficiently large caller-increasable inventories and exact-arithmetic budgets. It is not a practical complexity promise. No current basin science, source import, test, execution receipt or native acceptance has been inspected or asserted by this lane at this stage.

## Read and immutable initial bindings

All paths below are repository-relative. These are read bindings, not claims that files outside this lane are immutable forever. An announced later revision requires a separate scope check. The initial two artifacts are preserved byte for byte.

| Artifact | SHA256 |
| --- | --- |
| Theory/SPEC.md | dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1 |
| docs/derivations/2026-09-09-basin-entrance-rg/problem-contract.json | b2c5ed364adfd5787d5a3f524168f4607cc0ce40bdbd8a12c33ed8921b5bfa8d |
| docs/derivations/2026-09-09-basin-entrance-rg/agents/independent-initial-reconstruction.md | ef340e91e72fc4764cd97336d8858a09c6152260493391868fcb9521635413d9 |
| docs/derivations/2026-09-09-basin-entrance-rg/agents/initial-proposals.json | e06bcd5af15aabdb3593bd5fba82219e66f9dd3b573e72874a720c89ffa8e729 |
| docs/derivations/2026-09-09-basin-entrance-rg/agents/root-weighted-row-construction.md | b11ee101c8c9e5f5373bc1b4f3f40fbf4df77e3106a7d9789c9026ad239b9936 |
| docs/derivations/2026-09-09-basin-entrance-rg/agents/root-claims.json | 3ad491ad1a3cda47b0f7b455fa1094236c4f6be67f0c8457fc7c4c2a88435d04 |
| docs/derivations/2026-09-09-basin-entrance-rg/agents/basin-construction.md | f11a6b0d81189f8dd388fc285f3ab4fd00586fc0ff4d89588b3e69f51b9b21c7 |
| docs/derivations/2026-09-09-basin-entrance-rg/agents/interface-proof.md | 39821360464d144d88adeb4a3fc4cd1d4f578216872384341e8595dbf343455a |
| docs/derivations/2026-09-09-basin-entrance-rg/agents/root-character-span-inverse.md | 0dc02bac52f2a54820fd2c14f8e5b07cd3515f0a598d175b4a8ae083e5fd6cd8 |
| docs/derivations/2026-09-09-basin-entrance-rg/agents/root-inverse-claims.json | 24bfd530f6da026286753398a1197d58a88428569c19a63004d09465829da5e2 |
| docs/derivations/2026-09-09-uniform-depth-gibbs-rg/agents/uniform-coupling-construction.md | e09c831abae9432637659be974711c36ffd9d22fa90c7735737ca746a5cec67d |
| docs/derivations/2026-09-09-open-neighborhood-rg/release.json | 13641c198dde60d1a4bd693df31e177a97c603ce129ff9e2e108892606fe93fa |
| docs/derivations/2026-09-09-finite-amplitude-rg/release.json | 4f517971b9fa7f8197db09e2c322832a9cea08af7e985bc714f980f17798d688 |
| src/multiagent_elbo/rg_v2/finite_amplitude_rg.py | 966eb44fe1c502914a166edc1c652c20a3cb6a98125d5974430611a793fdb4cf |
