<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537","target_digest":"e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537","role":"discovery-only; excluded from current basin target certificate"} -->

# Next normalized geometry-indexed RG lift

Date: 2026-09-09. **DISCOVERY/PROPOSED NEXT TARGET.** This note is excluded from the current basin theorem and its evidence. It supplies finite derivations for a proposed next contract, not native theorem closure or implementation. The author shares the current research context and wrote prior normalization and RG notes. Only this new Markdown is changed. No scientific imports, tests, producers, source edits or external theorem invocation occurred. The prior next-curvature-program-map.md was read in full and its relevant callable seams were read back from current source. The fixed-joint distinction also agrees with the earlier normalized-VFE context; the formulas below are derived from the current finite model rather than an older execution record.

The smallest useful next unit is a finite geometry-label wrapper around a complete normalized observation model, retaining the label during exact blocking. It must expose the choice of joint normalization and preserve scalar information separately from the scalar-free interaction representative. It should not introduce another curvature calculator or silently turn marginalization of a geometry label into an operation inside the already admitted spatial Gibbs class.

## 1. Geometric types and finite model data

**DEFINITION.** Let Gamma be a finite set of declared geometry labels. A label can index a gauge connection or finite link/holonomy assignment A_gamma, a base metric/volume datum g_gamma, and a branch generative model. These are distinct from the Fisher metric of a parameterized probability family. A gauge-holonomy action needs a specified representation, invariant pairing and reference; a base-curvature action needs its base metric, volume and scalar convention. A Fisher curvature is derived only on an identifiable regular statistical chart. Its use as an energy requires a separately declared model. None is inferred from the name of another curvature.

For each gamma let X_gamma be a finite carrier, nu_gamma a strictly positive probability reference on that carrier, and r_gamma(x)=exp[-H_gamma(x)] a positive finite raw factor. Let m_gamma>0 sum to one, let a_gamma=m_gamma exp[-A_gamma]>0, and define

\[
 Z_\gamma=\sum_x\nu_\gamma(x)r_\gamma(x),\qquad
 p_\gamma(x)=\nu_\gamma(x)r_\gamma(x)/Z_\gamma.
 \label{eq:rg-ngl-branch}
\]

The observation alphabet O is finite and ell_gamma(o|x) is a normalized nonnegative row. The coarse alphabet Y_gamma is finite and T_gamma(y|x) is a normalized stochastic row, initially parameter independent and observation independent. The complete latent carrier is the disjoint union of pairs (gamma,x); equal string labels in different branches do not identify states. The minimal spatial realization uses a common finite graph, declared dressed exterior and disjoint path channels. Different geometry labels may change branch factors or likelihoods only by an explicit model map. Merely supplying a base metric does not create such a map.

## 2. Two normalized joints, with different geometry priors

**FINITE PROPOSITION NGL01; DIRECT DERIVATION.** The normalized hierarchical joint and the globally normalized factor joint are respectively

\[
 P^{\rm h}(\gamma,x,o)=w_\gamma p_\gamma(x)\ell_\gamma(o|x),
 \qquad w_\gamma=a_\gamma/Z_g,\quad Z_g=\sum_\eta a_\eta,
\]
\[
 P^{\rm f}(\gamma,x,o)=
 \frac{a_\gamma\nu_\gamma(x)r_\gamma(x)\ell_\gamma(o|x)}{Z_{\rm all}},
 \qquad Z_{\rm all}=\sum_\eta a_\eta Z_\eta.
 \label{eq:rg-ngl-two-joints}
\]

Summing the normalized observation rows and then the state masses proves joint normalization. The factor model's geometry weights are w_tilde_gamma=a_gamma Z_gamma/Z_all. Thus the joints agree for fixed a precisely when all Z_gamma are equal. They can instead be made equal by changing the factor-model geometry weights to a_gamma/Z_gamma; that is an explicit model choice with its own parameter derivatives. Adding a branch-dependent constant d_gamma to H_gamma leaves every hierarchical branch and fixed geometry weight unchanged, but multiplies the factor-model geometry weight by exp(-d_gamma). Adding the same constant to every geometry action cancels after joint normalization. These are algebraic cancellations, not new VFE penalties.

A two-state control makes the distinction exact. Take equal a_gamma, uniform references, raw branch weights (1,1) and (1,3), and likelihood P(o=1|x)=(1/4,3/4). Then Z=(1,2), geometry masses are (1/2,1/2) versus (1/3,2/3), selected evidence is 9/16 versus 7/12, and posterior mass of the second geometry is 5/9 versus 5/7. The two normalizations yield different observable predictions.

## 3. Push the joint and derive its likelihood and fibers

**FINITE PROPOSITION NGL02; DIRECT DERIVATION.** Use w to denote whichever geometry prior the chosen joint actually has. Define p'_gamma(y)=sum_x p_gamma(x)T_gamma(y|x). On a positive target atom its prior reverse fiber and induced likelihood are

\[
 B_\gamma(x|y)=\frac{p_\gamma(x)T_\gamma(y|x)}{p'_\gamma(y)},
 \qquad
 \ell'_\gamma(o|y)=\sum_x B_\gamma(x|y)\ell_\gamma(o|x).
 \label{eq:rg-ngl-likelihood}
\]

Summing over x proves normalization of B; summing over o proves normalization of ell'. Direct substitution gives the full pushed joint

\[
 P'(\gamma,y,o)=\sum_xP(\gamma,x,o)T_\gamma(y|x)
              =w_\gamma p'_\gamma(y)\ell'_\gamma(o|y).
 \label{eq:rg-ngl-push}
\]

Its selected evidence E_o=sum_gamma,y P'(gamma,y,o) equals the original evidence because T has unit row sums. For E_o>0 its posterior is P'(gamma,y,o)/E_o. On positive selected atoms the posterior fine fiber is B_gamma(x|y)ell_gamma(o|x)/ell'_gamma(o|y). It differs from the prior fiber unless the observation is conditionally uninformative there. Replacing B by a recognition conditional changes the generative likelihood. Reusing the original likelihood on y is justified only by the exact factorization ell_gamma(o|x)=ell_bar_gamma(o|y) on every positive channel incidence.

For a second channel U_gamma(z|y), finite distributivity gives the direct channel TU, the same pushed joint and the same evidence. Bayes fibers and induced likelihoods agree on positive states under direct or staged construction. A null target has zero reference, prior and joint mass and an undefined conditional row; retain that classification rather than invent a uniform row. Zero evidence makes the selected posterior undefined. Unknown symbols remain a validation error distinct from valid zero mass.

## 4. Reference densities and the scalar cocycle

**FINITE PROPOSITION NGL03; DIRECT DERIVATION.** Push the reference as well: nu'_gamma(y)=sum_x nu_gamma(x)T_gamma(y|x). On its support let

\[
 r'_\gamma(y)=
 \frac{\sum_x\nu_\gamma(x)r_\gamma(x)T_\gamma(y|x)}{\nu'_\gamma(y)},
 \qquad H'_\gamma(y)=-\log r'_\gamma(y).
 \label{eq:rg-ngl-raw-push}
\]

Then sum_y nu'_gamma(y)r'_gamma(y)=Z_gamma exactly. This reference-conditional average preserves the original finite branch partition; it is not the prior reverse fiber in NGL02. Their weighting laws differ. Reference tower conditioning proves that direct and staged raw pushes coincide.

Suppose a prescribed canonical representative splits H'=Hhat'+s_gamma, where s_gamma is constant in the state but may depend on geometry, parameters, volume and boundary. Then Z_gamma=exp(-s_gamma)Zhat'_gamma. Inside a normalized branch this scalar cancels. In the globally normalized joint it must instead be retained in the geometry action A'_gamma=A_gamma+s_gamma, since exp(-A')exp(-Hhat')=exp(-A)exp(-H'). A changed representative with a forgotten s_gamma can therefore preserve every branch law while changing the full joint and its evidence.

If the reference is pushed consistently and the representative rule is translation-by-constants equivariant, raw push commutes with adding a constant. For consecutive maps C,D, uniqueness of the canonical representative gives

\[
 s_{DC}(H)=s_C(H)+s_D(R_C^{\rm can}H).
 \label{eq:rg-ngl-cocycle}
\]

This follows by substituting H_C=R_C^can H+s_C into the second raw push and comparing the resulting constant with the direct canonical split. An arbitrary reset of the reference or scalar convention breaks this formula. Store either the exact multiplicative scalar exp(-s) when rational or a certified log enclosure; never label the normalized push's normalizer value one as the original raw Z. The present scalar-free infinite RG evaluator does not compute these finite raw constants.

## 5. Exact VFE and KL behavior

**FINITE PROPOSITION NGL04; DIRECT DERIVATION.** Fix o with E_o>0 and let Q be one normalized recognition law on (gamma,x). For Q supported on the selected joint, define F_o(Q)=sum Q log[Q/P(gamma,x,o)]. Then substitution of P_o=P(gamma,x,o)/E_o gives F_o(Q)=D(Q||P_o)-log E_o. It also gives, in the hierarchical model,

\[
 F_o(Q)=D(Q_\Gamma\|m)+E_Q A_\Gamma+\log Z_g
 +\sum_\gamma Q_\Gamma(\gamma)
   [D(Q_{X|\gamma}\|\nu_\gamma)+E_{Q_{X|\gamma}}H_\gamma+\log Z_\gamma]
 -E_Q\log\ell_\Gamma(o|X).
 \label{eq:rg-ngl-vfe-factors}
\]

For the factor model replace log Z_g+E_Q log Z_gamma by log Z_all. This exposes exactly where branch normalizers belong. There is one joint recognition entropy, decomposed by its actual conditional laws; no separate correlation entropy is added.

Lift both Q and P_o by the same T. Their joint density ratio on (gamma,x,y) equals Q/P_o wherever T>0, so their KL equals the original KL. Factor both augmented laws into their (gamma,y) marginal and x conditional, split the log ratio and sum. This proves

\[
 F_o(Q)=F'_o(Q')+
 E_{Q'}D(Q(X|\Gamma,Y)\|P_o(X|\Gamma,Y)).
 \label{eq:rg-ngl-vfe-chain}
\]

The term is nonnegative and vanishes precisely when the conditional fibers agree Q'-almost surely. Applying the same split at consecutive channels yields telescoping discarded conditional KL. For support violations the corresponding divergences are positive infinity; the chain is interpreted as equality of nonnegative extended KL terms before subtracting the finite log evidence, never by evaluating infinity minus infinity. Recognition may be a general correlated joint; a mean-field restriction is an optional approximation with a separately reported gap.

## 6. What remains after forgetting geometry

**FINITE PROPOSITION NGL05; DIRECT DERIVATION.** If all Y_gamma have a declared common comparison carrier, marginalizing Gamma gives bar P(y,o)=sum_gamma P'(gamma,y,o), with unchanged evidence. Its prior and likelihood are

\[
 \bar p(y)=\sum_\gamma w_\gamma p'_\gamma(y),\qquad
 \bar\ell(o|y)=\sum_\gamma
 \frac{w_\gamma p'_\gamma(y)}{\bar p(y)}\ell'_\gamma(o|y).
 \label{eq:rg-ngl-mixture-likelihood}
\]

The prior conditional geometry weights, not w alone and not the posterior weights, enter the likelihood. The posterior weights then incorporate ell'. A second KL split gives F'_o(Q')=bar F_o(bar Q)+E_barQ D(Q(Gamma|Y)||P(Gamma|Y,o)). Thus probabilities, evidence, composition and the finite VFE chain survive. Individual geometry values, conditional identification information and a unique interpretation of an averaged connection or metric generally do not. Averaging branch Fisher tensors also omits the geometry-score term when weights depend on parameters.

**DIRECT OBSTRUCTION TO A STRONGER INFINITE CLAIM.** Even two independent Bernoulli product branches with 0<p_1<p_2<1 and positive geometry weights can lose quasilocality after mixing. Fix any finite exterior cylinder around the target site; both branches assign it positive mass. Conditioning additionally on n distant ones multiplies the second-to-first branch odds by (p_2/p_1)^n and makes target prediction tend to p_2. Conditioning on n distant zeros multiplies them by [(1-p_2)/(1-p_1)]^n and makes prediction tend to p_1. If an everywhere continuous target conditional version existed, continuity at any exterior would force all its values on some sufficiently large matching cylinder into an arbitrarily short interval. The conditional expectations on both distant events would lie in that interval, contradicting the two different limits. All these cylinder events have positive probability, so changing a null version does not fix the contradiction. Each branch separately is a positive unique product Gibbs law. Retaining Gamma avoids this obstruction; eliminating it is not automatically an RG operation in the admitted quasilocal class.

## 7. Parameter dependence and statistical geometry

**FINITE PROPOSITION NGL06; DIRECT DERIVATION.** Take an open parameter set, fixed finite supports and fixed positive references. Let a_gamma(theta), H_gamma(theta,x) and positive likelihoods be C^r. Finite sums, products and positive quotients make every normalized joint, evidence, posterior and fixed-channel push C^r. For the hierarchy the full joint score is

\[
 s(\gamma,x,o)=\partial\log w_\gamma
 -\partial H_\gamma(x)+E_{p_\gamma}\partial H_\gamma
 +\partial\log\ell_\gamma(o|x),
 \quad
 \partial\log w_\gamma=\partial\log a_\gamma-E_w\partial\log a.
 \label{eq:rg-ngl-score}
\]

For the factor model the pre-likelihood score is partial log a_gamma-partial H_gamma(x)-partial log Z_all. Its geometry score contains partial log Z_gamma=-E_pgamma partial H_gamma. Parameter-dependent references add their log scores. Differentiating selected normalization gives partial log E_o=E_Po s and posterior score s-partial log E_o.

For a fixed channel, differentiating the finite pushed sum proves s'=E[s|Gamma,Y,O]. Subtracting second moments gives I_full-I_push=E Cov(s|Gamma,Y,O), a positive semidefinite Fisher loss. If T depends on theta, the differentiated integrand contains the additional channel score partial log T on its fixed positive support; ordinary I_push<=I_full need not hold. An input law constant in theta and a theta-dependent Bernoulli channel already refutes it. Induced ell' may depend on theta even when the original ell and T do not, because the prior reverse fiber does.

Retaining labels gives I_(Gamma,X)=I_w+sum_gamma w_gamma I_pgamma: the mixed score term vanishes by conditional score centering. These are tensors of the actual statistical family, distinct from A_gamma or g_gamma. Blocking can reduce their rank; binary outputs support rank at most one. A Levi-Civita or scalar-curvature calculation requires a fixed identifiable regular chart and sufficient actual probability jets, with no pseudoinverse substitution. A Fisher-curvature-dependent prior is permissible only after declaring which independent regular family supplies that scalar and normalizing the new prior. If the scalar is defined from the very unknown joint that it weights, existence and uniqueness of that self-consistent model are an additional obligation, not a consequence of the formulas above.

Coherent gauge/chart relabeling is proved by finite changes of variables: transform references, factors, likelihoods and channels by the same bijections and commuting channel square, then all masses, evidence and scalar cocycles transform accordingly and KL is invariant. A curvature label alone does not verify that commuting square. Gauge-equivalent labels cannot be merged without pushing their reference masses as well.

## 8. The finite-window approximation bridge and infinite limits

**FINITE PROPOSITION NGL07; DIRECT DERIVATION.** Suppose two complete interactions in the same prescribed norm differ by at most epsilon and define Hamiltonians in one chosen finite free-edge window Lambda with the same dressed exterior and every touching interaction included. The stronger cardinality/exponential weights imply

\[
 \sup_x|H_\Lambda(x)-\widehat H_\Lambda(x)|
 \le\sum_{T:T\cap\Lambda\ne\varnothing}|J_T-\widehat J_T|
 \le |\Lambda|\epsilon=:d.
 \label{eq:rg-ngl-window}
\]

Every touching term is counted at least once in the sum over incident free edges. For the same reference this implies |log Z-log Zhat|<=d by termwise comparison of exp(-H). The normalized mass ratio lies in [exp(-2d),exp(2d)]. With the same geometry weights, likelihood and channel, use max_gamma d_gamma for the whole hierarchical joint, its pushed joint and selected evidence. Their log ratios have absolute value at most 2d; the selected posterior log ratio is at most 4d. For the same recognition Q, |F_o(Q)-Fhat_o(Q)|<=2d follows directly from the selected joint log ratio. These bounds include volume dependence; they do not assert a volume-uniform finite KL error. Additional action, reference or likelihood errors require their own uniform log-ratio bounds.

The bound cannot recover an unknown original raw scalar from a scalar-free coefficient certificate. For the globally normalized factor model, branch scalar errors must be supplied explicitly or included in the Hamiltonian error. A uniform bound on canonical coefficients alone leaves branch reweighting arbitrary. Also, evaluating a finite-window Gibbs conditional under one exterior is not evaluating the infinite law's unconditional window marginal. A separate finite-to-infinite comparison or boundary integration must bridge that distinction.

**OPEN LIMIT OBLIGATIONS.** If branch infinite-volume probability laws mu_gamma are already supplied, the fixed-weight joint w_gamma mu_gamma and a bounded normalized local observation kernel are well-defined directly. Finite Gamma and local probability integration give finite evidence without any infinite-volume partition. Branchwise exact path push then gives an infinite geometry-retaining joint; each branch must actually satisfy the admitted RG premises. A finite collection of admitted branches permits a maximum of their valid entry depths. Arbitrary geometry-induced interactions, anisotropies or altered carriers do not inherit the current isotropic basin theorem merely by attaching a label.

In contrast, finite factor-model weights a_gamma Z_gamma,Lambda require a separate volume-limit construction. Distinct limiting pressures can select one branch; equal pressures leave boundary and subextensive terms relevant. A prescribed volume-dependent counterterm changes the model and must be stated. No symbol Z_gamma,infinity is introduced as a finite normalizer. Full-law KL/VFE limits additionally require a specified recognition law, domination/integrability and an entropy-limit proof. Specific VFE needs the admitted stationarity, boundary and common-likelihood hypotheses; the present finite proof is not that limit. Uniform derivatives of infinite branch evidence need derivative-limit bounds for the actual parameterized family. C0 interaction accuracy cannot supply them, and the earlier C3 spatial theorem applies only on its own family and regularity domain.

## 9. Smallest additive implementation contract

**PROPOSED, NOT IMPLEMENTED.** Add one finite module taking an ordered finite geometry catalog, exact reference laws, positive rational raw weights or complete normalized branch laws, normalized observation rows and complete fixed branch channels. Use separate constructors for the hierarchical and globally normalized factor joints so the choice is reviewable. A typed geometry record should distinguish gauge holonomy/action data, base metric/action data and a statistical-family identifier; it must not silently convert a curvature invariant into a weight. The computational core operates on the explicit joint table. It returns the joint prior, complete observation joint, pushed references and raw factors when supplied, selected evidence/posterior, prior and posterior reverse fibers, induced likelihoods, and cumulative scalar receipts. Zeros remain on the declared carrier.

Reuse ExactProbabilityLaw and ExactSubmeasure from contracts.py and CompleteCarrierTargetChannel for exact sparse normalized pushes. The existing complete-carrier reverse-kernel seam used by project_spatial_scores supplies active fibers; keep its null-target classification. FiniteDressedField.law and pushforward_law provide finite spatial branches and disjoint parity channels, retaining their actual normalizer semantics. compact_link_record and base_curvature_record already implement the two normalization choices as concrete controls, while build_holonomy_model/accounting/coarse_accounting demonstrate label-retaining normalized Gaussian inference. They need no replacement. finite.vfe supplies a floating diagnostic chain and explicit infinity handling; exact rational density-ratio identities plus the existing certified logarithm machinery should carry any newly requested certified scalar outputs. Do not relabel the older binary64 VFE diagnostics as exact logarithms.

For parameter-aware use, construct the full joint probability jet by the finite product rule and joint normalization, then reuse push_probability_jet and fisher_geometry when their two-parameter, order-three and positive-rank contracts hold. selected_binary_posterior_jet supports a fixed positive binary likelihood only; a parameter-dependent likelihood requires its derivative rows in the product, not an unchanged call to that helper. The new joint's normalizer jets must be retained separately from spatial_probability_jet's auxiliary centered-tilt normalization. No general curvature engine or coupled geometric evolution is needed for this first adapter.

The pure exact path is reachable with retained geometry labels, complete rational carriers, fixed declared channels, exact fibers and an explicit sufficient enumeration budget; constant curvature, zero action strength, zero plaquette coupling and uninformative likelihood are distinct controls. The finite approximation path may consume the existing full-norm interaction oracle only with its reported error and the chosen finite-window bridge. It must return incomplete on resource exhaustion rather than moment-match a mixture or drop a branch.

Meaningful tiny controls are the explicit two-geometry normalization example above; branchwise scalar rescaling and its compensated geometry-action control; four fine bits pushed through two disjoint parities and then their product, checking the direct/staged raw scalar cocycle; a recognition law with nonzero discarded fiber KL and a matched-fiber equality control; unreachable target columns and zero-evidence classification; coherent gauge relabeling; and a two-parameter normalized score control that retains normalizer derivatives and rejects a singular binary Fisher inverse. These are proposed checks, not executed results. They can all use tiny complete carriers. The next frozen contract should first deliver this full finite normalized lift and its uncertainty interface. It should leave continuum measures, metric dynamics, all-depth regular curvature, unrestricted recognition thermodynamics and physical-clock identification as explicit separate obligations.

## Current read bindings

The following bindings record a source read, not execution evidence. The prior map is contextual discovery and is not promoted to a premise.

| Read file | SHA256 |
| --- | --- |
| [next-curvature-program-map.md](C:/tmp/elbo-cover-20260908/docs/derivations/2026-09-09-finite-amplitude-rg/agents/next-curvature-program-map.md) | 83e68a94cf24ab0f95edb5b185823c124fbe752d73933037646fd48358716529 |
| [curvature_models.py](C:/tmp/elbo-cover-20260908/src/multiagent_elbo/rg_v2/curvature_models.py) | 023e9152317f2745b60d8841860f38c5f966ab226400122b69743b9719248bc1 |
| [holonomy_inference.py](C:/tmp/elbo-cover-20260908/src/multiagent_elbo/experiments/neighborhood/holonomy_inference.py) | a2dfb82af0b5ea7bec9f38f8c91438e5b3a33fdbea283d3e6eb74fce53458960 |
| [spatial_gauge.py](C:/tmp/elbo-cover-20260908/src/multiagent_elbo/rg_v2/spatial_gauge.py) | 1d5f51a19dbe05f03a41982d8755ca6035f8b09537ff675f19b0300b7cd349f1 |
| [spatial_fisher.py](C:/tmp/elbo-cover-20260908/src/multiagent_elbo/rg_v2/spatial_fisher.py) | 6bcd1b6b088f1d5b367b534817d09a130585718ca0e8f9d111bd9952069d8766 |
| [spatial_fisher_geometry.py](C:/tmp/elbo-cover-20260908/src/multiagent_elbo/rg_v2/spatial_fisher_geometry.py) | 95037ecac670732c6b3a8345b26d7bb856e3eaf9401f9c65999b82bd55d55713 |
| [contracts.py](C:/tmp/elbo-cover-20260908/src/multiagent_elbo/rg_v2/contracts.py) | 3b67e9dada9dd67c4be8a8ff62de81d8da1cac42b2b7a5e7df1bdfff4a01ae6b |
| [complete_carrier_sector_quotient_composition.py](C:/tmp/elbo-cover-20260908/src/multiagent_elbo/rg_v2/complete_carrier_sector_quotient_composition.py) | dd1f94bc07b3113b695fa4642718fd1ba2e39e19714262e11dd89c3687a7223a |
| [measures.py](C:/tmp/elbo-cover-20260908/src/multiagent_elbo/finite/measures.py) | 6ca5373a4d20b975ea4e0e6e49098d0b7810b64a4cd656d55963f478e950059a |
| [vfe.py](C:/tmp/elbo-cover-20260908/src/multiagent_elbo/finite/vfe.py) | a6fe5aa7ca338178335e2e39b0fcc0666f16962af27328100a9edbbabf64cda1 |
