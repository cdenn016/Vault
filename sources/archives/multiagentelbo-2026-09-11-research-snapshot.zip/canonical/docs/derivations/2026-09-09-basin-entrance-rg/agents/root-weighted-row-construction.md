<!-- rigorous-theory-search-metadata {"schema_version": "rigorous-theory-search/v1", "contract_id": "contract-sha256-e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537", "target_digest": "e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537"} -->

# Root construction: prescribed weights, conditional rows and a finite oracle

Date: 2026-09-09. **PROPOSAL PENDING INDEPENDENT RECONSTRUCTION.** Root read the previous author discovery before this contract, but has not read any current author/checker/worker draft before writing this construction. The new mechanism uses conditional rows directly and a root-centered spatial weight. It avoids the previous restriction to small prescribed output weights and avoids integrating a continuously interpolated log-partition. No current theorem is closed by this note. Existing law and local-RG premises are exactly those frozen in the contract.

## RB01. Interior channel and strict weighted activity

For a retained B-path, B>=3, integrate all but its first and last fine edges. Every eliminated edge meets two plaquettes, and no plaquette meets two eliminated edges. The other three edges in either such plaquette are outside every retained path. Thus the interiors are conditionally independent given the remaining fine variables. For a horizontal root p=(0,0,0),

\[
 g_p=z_{(0,0,0)}z_{(B-1,0,0)}
 \prod_{r=1}^{B-2}f(u_r,v_r),
 \qquad f(u,v)=\tanh(h+J(u+v)).
\]

The supporting strip has 4B-4 edges: the endpoints, horizontal edges (r,+/-1,0) for 1<=r<=B-2, and vertical edges (r,0,1),(r,-1,1) for 1<=r<=B-1. Its fine-coordinate diameter and its distance from the root anchor are at most B. The rotated strips have the same property. These strips are pairwise disjoint. For horizontal fine edges, horizontal-strip interior membership has x residues1,...,B-2 and y residues1,B-1; vertical-strip membership has x residues0,B-1 and y residues1,...,B-1. These x classes are disjoint; the side residue fixes the unique adjacent grid line because B>=3. Retained endpoint edges belong only to their own path. Rotate for vertical edges. Negative positions use Euclidean residues/floor division.

Put t=2c/(1+c^2). The exact Walsh coefficients of f are a0,a1,a1,a12, with a0>=0,a1>=0,a12<=0 and

\[
 a_0-a_{12}=b,\quad
 2a_1=\frac{t(1-b^2)}{1-b^2t^2},\quad
 a_{12}=-\frac{b t^2(1-b^2)}{2(1-b^2t^2)}.
\]

Consequently R(b,t)=||f||_0=b+t(1-b^2)/(1-b^2t^2). It increases in t. Its b derivative is at least 1-2t/(1-t^2)>0 for t<=24/145. The latter follows by bounding b/(1-b^2t^2)^2 by 1/(1-t^2)^2. Therefore the rational value R_* at b_max and c_max bounds the whole compact box. Moreover 1-R_*>=(13489/20449)(1-b_max)>0, from t<=24/145 and 2t/(1-t^2)<=6960/20449.

Set Delta=1-R_*, alpha=Delta/24, and sigma=R_*/(1-Delta/4)<1. All are rational and alpha>0. The fine Walsh norm includes scalar terms and weights each fine support S by exp(alpha|S|). It is submultiplicative under symmetric difference. As u,v are three-edge characters,

\[
 \|f\|_\alpha\le e^{6\alpha}R_*
 \le \sigma,\qquad
 \|g_p\|_\alpha\le
 G_B:=\frac{\sigma^{B-2}}{1-2\alpha}.
\]

The endpoint cost is included. Here exp(x)<=1/(1-x) for0<=x<1 gives both rational upper bounds. This sharper sigma, rather than only a slack bound near one, matters for a finite implementation. The transformation t=2c/(1+c^2) is exact; J has not been replaced by c.

For finite observed path set P the actual marginal density is

\[
 p_P(y)=\mathbb E_\mu\prod_{p\in P}(1+y_p g_p),
\]

where mu is the original fine Gibbs law, not an independent reference. This follows from conditional independence of the eliminated interiors. Fair averaging over all y gives one. All original normalizers are therefore retained. For a target p0 outside P, its conditional parity mean is the expectation of g_p0 under the normalized fine tilt by that product.

## RB02. Root-centered algebra for arbitrary prescribed output weights

Fix the prescribed kappa,lambda>0. Choose beta=kappa+1 and zeta=2lambda/B. For a fixed coarse root p0 with fine anchor a0=B anchor(p0), define

\[
 D_{p_0}(S,T)=\max\{\|x-a_0\|_\infty:x\text{ anchors a fine edge in }S
 \text{ or }x=Bq,\ q\text{ anchors a coarse edge in }T\},
\]

with empty maximum zero. On finite joint Walsh polynomials use

\[
 \|F\|_{p_0}
 =\sum_{S,T}|F_{S,T}|
 e^{\alpha|S|+\beta|T|+\zeta D_{p_0}(S,T)}.
\]

Its completion is a Banach algebra: cardinalities and the rooted radius of a product are bounded by the sums of the corresponding quantities. Coarse signs y are parameter labels, distinct from all fine signs. For an update at fine edge e, use the analogous local norm centered at its fine anchor. Replacing e in a character by a local polynomial can increase the rooted radius by at most that polynomial's local radius, and reduces the original fine-cardinality weight by exp(-alpha).

The original f_e depends only on six plaquette neighbors at fine distance at most one from e. Thus its local norm is at most sigma exp(2lambda/B). Put p=(1+sigma)/2 and choose B large enough that 2lambda/B<1 and

\[
 \frac{\sigma}{1-2\lambda/B}\le p<1.
\]

This is an explicit rational gate and holds for all sufficiently large B. It preserves any fixed lambda, however large, because the weight measures fine displacement in coarse units. It does not impose a small-lambda condition.

Let A_beta and A_2lambda be finite rational upper bounds for exp(beta) and exp(2lambda). A strip has local radius at most B from any of its members and from its own root. Therefore every observed-channel factor has local weighted activity controlled by

\[
 H_B=A_\beta A_{2\lambda}G_B.
\]

The arbitrary beta only changes a finite prefactor. Its cost is overcome as B increases.

## RB03. Exact conditional update including the entire observation factor

Because the strips are disjoint, a fine edge e belongs to at most one observed strip. If it belongs to no observed strip, its fine conditional mean is f_e. Otherwise decompose that strip's complete polynomial as g_p=g_0+z_e g_1, with g0,g1 independent of z_e. The original conditional probabilities of z_e are (1+/-f_e)/2. Multiplying by the two actual factors1+y_p(g0+/-g1), then normalizing the two-point row, gives

\[
 F_e=
 \frac{f_e+y_p(f_e g_0+g_1)}
 {1+y_p(g_0+f_e g_1)}
 =f_e+\frac{y_p(1-f_e^2)g_1}
 {1+y_p(g_0+f_e g_1)}.
\]

This retains both the even and odd parts of log(1+y_p g_p); no scalar background tilt is dropped. If p is the omitted target p0, use f_e instead. This is essential when computing its conditional mean.

Dropping the favorable exp(-alpha) after removing e gives local norms of y_p g0,y_p g1 at most H_B. Hence the denominator perturbation has norm at most (1+p)H_B. If

\[
 H_B\le
 \min\left\{\frac1{2(1+p)},\frac{1-p}{4(1+p^2)}\right\},
\]

its inverse is a convergent geometric series in the actual coefficient algebra. The added conditional mean has norm at most2(1+p^2)H_B<=(1-p)/2. Thus

\[
 \|F_e\|_{\mathrm{local}}\le r:=(1+p)/2<1.
\]

Every gate is uniform over the compact source box, every finite observed set, all coarse sign choices and all fixed fine exteriors. All gates hold eventually because G_B decays exponentially. No complex probability measure or inference from real mixing is used.

For rational b,c each F_e is also exactly computable as a finite rational Walsh polynomial. It depends on a finite strip, the six original neighbors and at most one coarse label. The displayed denominator is strictly positive on all real sign assignments, by the norm gate. Evaluating that finite rational function on its full sign cube and taking the finite Walsh transform gives all its coefficients exactly. The geometric argument bounds that unique polynomial even if the executable uses a truth table to obtain it. A finite implementation may instead use a proved algebraic inverse; a partial table cannot be called complete. This is a local conditional-function calculation, not a replacement of the fine Gibbs law by independent signs.

## RB04. Absorbing stationarity expansion

Let Pi retain the terms with empty fine support. For nonempty S set

\[
 A(\chi_S y_T)=
 \frac1{|S|}\sum_{e\in S}\chi_{S\setminus\{e\}}y_T F_e,
\]

and set A=0 on fine-constant terms. Put N=(1-Pi)A. The average over S is part of the operator; it prevents a spurious factor |S|. RB02-RB03 imply ||A(1-Pi)||<=exp(-alpha)r<=r in the root-centered algebra. Dropping fine-constant coefficients is contractive.

For every finite observed set P, the normalized tilted actual Gibbs law has precisely these conditional rows. Hence E(chi_S y_T)=E A(chi_S y_T). Iteration gives

\[
 \mathbb E F=
 \Pi F+\sum_{k\ge1}\Pi A N^{k-1}(1-\Pi)F.
\]

The remainder after finitely many substitutions is bounded by a geometric series in the same coefficient norm. The expectation identity is first proved for actual real y using normalized laws; coefficient convergence then identifies the whole resulting continuous parameter function. For every fine exterior, fixing a sign only decreases the norm. Finite-volume rows retain all crossing factors.

A fixed finite number of substitutions reaches only a finite fine region and finitely many coarse labels. Every strip has fixed finite size at fixed B. Therefore the finite-volume coefficients and finite-observed-set coefficients stabilize at each fixed substitution order once their inventories contain that region. Their remaining orders have a uniform geometric bound. This proves boundary-independent local limits and uniform continuous every-exterior conditional means, without conditioning on an infinite event.

## RB05. Uniform half-log-odds and complete coefficient interaction

For target p0, start from g_p0 and omit that path from the observed set. Its rooted norm is at most A_2lambda G_B. The absorbed limit m_p0(y) is the actual target conditional mean. The preceding geometric series gives

\[
 \|m_{p_0}\|_{p_0}\le
 M_B:=\frac{A_{2\lambda}G_B}{1-r}.
\]

Choose B large enough that M_B<=1/2. Its half-log-odds u_p0=atanh(m_p0) is a norm-convergent odd-power series and obeys

\[
 \|u_{p_0}\|_{p_0}\le
 U_B:=\frac{M_B}{1-M_B^2}.
\]

The term with no other coarse labels is the retained one-edge field; it is not a discarded scalar.

Finite joint conditional odds satisfy the two-edge square identity. Passing their uniform limits gives

\[
 u_e(y^{f,+})-u_e(y^{f,-})
 =u_f(y^{e,+})-u_f(y^{e,-}).
\]

The norm-convergent Walsh series justify coefficient extraction term by term. For a nonempty support T and any e in T, define J_T as the coefficient of chi_(T without e) in u_e. The square identity equates this definition for any two choices of marked edge. Translation covariance of the original law and the paths gives translation invariance. The resulting absolutely summable interaction reproduces every row, hence the actual pushed law's finite conditional ratios.

To bound the required global interaction norm, keep only canonical supports whose actual first edge is the root (0,0,i), for each of the two orientations. A support of size n has at most n translates incident to a fixed orientation root, contributing at most n^2 exp(kappa n+lambda diam T)|J_T|. Its row has n-1 labels, and

\[
 n^2 e^{\kappa n}
 \le2e^\kappa e^{\beta(n-1)},\qquad
 e^{\lambda\operatorname{diam}T}
 \le e^{(2\lambda/B)D_{p_0}(\varnothing,T\setminus\{p_0\})}.
\]

The first inequality follows from max_(x>=1)x^2 exp(-(x-1))=4/e<2. The second uses that p0 is included in T. If A_kappa>=exp(kappa), summing the two canonical root rows yields

\[
 \boxed{\|J^{(B)}\|_{\kappa,\lambda}
 \le E_B:=4A_\kappa U_B.}
\]

This counts all translated incidences and support sizes through the row weight, with no additional root/tree multiplicity. It also bounds every omitted row tail after canonical extraction. E_B is a rational computable exponential bound for the prescribed kappa,lambda, not only for a smaller topology.

The full every-exterior version follows from the uniform conditional construction. Alternatively the constructed interaction and the known continuous coarse specification represent the same full-support pushed law, so their continuous versions agree everywhere. Once E_B<epsilon, the inherited local theorem gives uniqueness. All scalar normalizers stay in the normalized fine tilts; this argument does not compute an original discarded partition or VFE.

## RB06. An exact finite rational interaction oracle

Fix rational b,c and B satisfying the gates. At each of the two root orientations compute the complete finite substitution polynomial

\[
 m_K=\Pi g+\sum_{k=1}^{K}\Pi A N^{k-1}(1-\Pi)g.
\]

Every source/support/label reached at those orders is retained, including terms later absorbed or canceled. Obtain each required local rational F_e completely, caching it only by its actual omitted target, B, parameters and literal edge. The uncomputed substitution tail is at most

\[
 d_K=\frac{A_{2\lambda}G_B r^K}{1-r}.
\]

This is deliberately conservative relative to the first omitted order. Both m and the sum of the included absorbed terms have norm at most M_B. The algebraic telescoping identity for powers therefore bounds the atanh difference by d_K/(1-M_B^2). Truncate atanh(m_K) after odd powers1,...,2L-1. The remaining odd powers have norm at most

\[
 \frac{M_B^{2L+1}}{(2L+1)(1-M_B^2)}.
\]

Let delta_u be the sum of these two bounds. Include every term of the two finite polynomials, attach the target edge, and retain only supports whose literal first edge is that root. Their consolidated orbit table Jhat is rational and finite. The RB05 incidence argument gives the entire error

\[
 \|\widehat J-J^{(B)}\|_{\kappa,\lambda}
 \le4A_\kappa\delta_u.
\]

This includes coefficients absent from the returned finite table. Approximate rows need not obey the exact square identities; canonical selection defines one honest interaction, and the norm estimate compares it to the consistent exact coefficients. No inconsistent-row equality is asserted.

For any positive rational requested error, K and L can be chosen finitely by the displayed geometric bounds. Every finite substitution inventory, exact rational conditional Walsh transform and finite polynomial product uses finitely many exact operations and finite integers. Sufficient finite resources therefore finish. A resource cap must return incomplete without the requested table/error certificate. The source must charge attempted products, local truth-table inventories, repeated updates and guarded arithmetic according to its stated resource scope; no bound on every machine allocation is inferred.

## RB07. Explicit B0 and uncertain-input RG words

All exponential constants above admit rational upper enclosures by the unchanged certified exponential construction. The rational gates in B are eventually true and monotone after the fixed base-mean gate, because G_B decreases. Refine prior K_a/ell_a enclosures until they supply some fixed epsilon_0>0 below the admitted epsilon. Increase B0 until all gates and E_B<epsilon_0/16 hold for all B>=B0. A rational finite search is sufficient; the exponential convergence proves termination uniformly over the compact box.

For integration with the unchanged finite_amplitude_rg API, take epsilon_0 from its first successful zero-input admission on the uncapped doubling precision sequence. Its positive exponential upper endpoints are nonincreasing with degree once their geometric denominators are valid: if a=x/(m+2), b=x/(m+3), the difference between successive upper bounds is the first omitted term times a(a-b)/[(1-a)(1-b)]>=0. Negative-exponential upper endpoints also decrease because they are reciprocals of increasing positive lower sums. Hence subsequent prior constant enclosures have epsilon_lower>=epsilon_0.

Given requested final tolerance t, produce an oracle table with delta<min(t/2,epsilon_0/16). Call the old finite-word evaluator on that exact finite table at tolerance t/2. Its eventual admission radius is at least epsilon_0/2, while the true J^(B) norm is below epsilon_0/16. The approximate table is also strictly in the admitted ball. The old source's norm enclosures eventually admit it with sufficient resources.

Read the actual returned radius and step Lipschitz constants; explicitly check that E_B is inside that radius. If the returned polynomial error is e_old, the final true-orbit error is

\[
 e_{\mathrm{total}}
 =e_{\mathrm{old}}+\delta\prod_j L_j<t,
\]

because each exact and approximate orbit starts and remains in the same certified ball, and every L_j<1. The empty word has product one. A failed domain check or incomplete old result yields no final certificate. This wrapper preserves the old source and its original exact-finite-input contract. It does not pretend that the basin oracle output was the exact infinite interaction.

The geometric identity of direct and staged path channels and uniqueness of the coefficient representative imply R_a J^(B)=J^(aB) once the basin gates hold. Thus the word result approximates the actual physical path push, not an unrelated artificial interaction trajectory. Raw gauge-frame lifting remains the prior normalized construction.

## Remaining scrutiny and scope

Every displayed step is a proof proposal for this frozen target. Independent reconstruction must check the disjoint strips, signs and monotonic compact bound, the rooted operator inequality, finite-observed-set stabilization, conditional square identity, n^2 incidence factor, exact local inverse/finite oracle and old-admission monotonicity. An implementation must realize the entire oracle and uncertainty propagation, not only return the upper constants or a zero-table demonstration. Tiny finite checks remain separate from these universal arguments.

The stronger output weights are paid by beta=kappa+1 and fine distance zeta=2lambda/B; neither is silently reset to an easier prescribed norm. No geometry label, Fisher inverse, curvature action, changed likelihood, critical limit, continuum measure or physical clock is assumed. The separate geometry-indexed normalization task remains on the full program.
