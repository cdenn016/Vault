<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537","target_digest":"e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537"} -->


# Independent initial basin reconstruction and remaining obligation

Date: 2026-09-09. This initial record uses only the new frozen contract, unchanged SPEC and admitted prior results. The contract and SPEC were read first; targeted middle/overlap reads completed the truncated large SPEC output, whose hash remains unchanged from the earlier full read. I then read prior uniform-coupling sections UC01 and UC08-UC16 and the prior local-operator and finite-amplitude releases. No previous next-* discovery note or current author, root or worker construction/source was opened. Prior context includes the existence of open basin notes, not their derivations. Shared model family, prior context and filesystem limit independence. No ledger state is assigned and no scientific import, test or study was run.

The complete target is not yet reconstructed here. I derive an exact normalized coarse channel with exponentially small means, consistent canonical coefficients and an individual-coefficient oracle. I prove the downstream full-norm oracle and uncertain-word statements conditional on one explicit finite normalized-response estimate in IB09. That estimate is not proved for the full positive parameter box. Two exact counterexamples defeat shortcuts, not the actual basin target.

## IB01. A simultaneous independent interior inventory

Write e=(v,i), v in Z^2, i in {0,1}. For B>=3 and coarse edge a=(x,i), let P_a={(Bx+r unit_i,i):0<=r<B} and I_a contain r=1,...,B-2. Put I=union_a I_a and W=E without I. Both endpoint edges of each path and every unused fine edge belong to W. This inventory preserves both axes, negative coordinates and coarse translation covariance.

No plaquette contains two I edges. Its two horizontal sides lie on adjacent rows, whereas retained horizontal rows have second coordinate divisible by B; both cannot be retained. The vertical argument is identical. A selected horizontal edge has endpoint first coordinates Bx_0+r and Bx_0+r+1 with 1<=r<=B-2, neither divisible by B. Neither adjoining vertical side can therefore be a retained vertical edge. These cases exhaust every pair of sides. All B-2 interiors per path can be selected simultaneously, without an assumed independent-set density bound.

Conditional on W, each I edge occurs alone in its edge factor and its two touching plaquettes. Every plaquette of the original two-dimensional model is retained. This is not an independent-plaquette replacement.

## IB02. Exact factor elimination and the normalized channel

For e in I, let a_e(w),d_e(w) be the products of the other three signs in its two plaquettes. They depend only on W. Its local factor is

 f_e(z;w)=(1+bz)(1+c a_e z)(1+c d_e z).

Fair counting gives the exact normalization and first-moment numerator

 A_e=1+bc(a_e+d_e)+c^2 a_e d_e,
 N_e=b+c(a_e+d_e)+bc^2 a_e d_e.

The two f_e values are positive, so A_e>0 and t_e=N_e/A_e lies in (-1,1). The normalized conditional probability is (1+t_e z)/2. Equivalently t_e=tanh(h+J(a_e+d_e)), but the displayed rational formula avoids transcendental arithmetic at rational b,c.

In a finite whole-block free volume, factor the full all-touching weight as C_0(w) product_e f_e. Here C_0 retains all W-edge factors and every touching plaquette with no free I edge, after substituting the declared exterior. Its W marginal has unnormalized weight C_0 product_e A_e and its own actual normalizer under fair W counting. Conditional I-edge probabilities multiply. No scalar factor is discarded by this elimination.

For the infinite fine law, its DLR equation on any finite F subset I gives this same product conditional given the full complement of F. That product depends only on W. Taking conditional expectation given W proves every finite I marginal is the corresponding product given W. Consistent finite products define a measurable kernel on the countable sign product, since every cylinder probability is a finite product of local measurable functions. This is a disintegration of the admitted normalized law, not a formal infinite weight product.

Let u_a(w) be the product of the two endpoint signs of P_a. Then, conditional on W, the path parities are independent and have means

 m_a(w)=u_a(w) product_(e in I_a) t_e(w).

Thus the exact coarse channel is the product of normalized sign kernels (1+m_a(w)y_a)/2. The W marginal remains fully correlated. Each m_a depends on at most 6(B-2)+2 W edges, allowing duplicates in this upper count.

Uniformly on the compact box define

 rho=[b_max(1+c_max^2)+2c_max]/[1+c_max^2+2b_max c_max],
 eps_B=rho^(B-2).

The field inequality abs(h+J(a+d))<=h_max+2J_max gives abs(t_e)<=rho<1 and hence abs(m_a)<=eps_B. These constants are rational and explicit. This simultaneous product channel is separate from the stronger admitted single-free-path bound rho^B, which conditions on all other path blocks and does not simultaneously make all path outputs independent.

## IB03. Actual finite conditional ratios and amplitude

Let nu be the actual W marginal. For finite Lambda the coarse density relative to fair counting is

 f_Lambda(y)=E_nu product_(a in Lambda)(1+m_a y_a).

It is positive and normalized: fair-summing each y factor gives one before taking the nu expectation. For a free marked edge e outside Lambda define

 D_Lambda=E_nu product_(a in Lambda)(1+m_a y_a),
 N_(e,Lambda)=E_nu[m_e product_(a in Lambda)(1+m_a y_a)],
 u_(e,Lambda)=N_(e,Lambda)/D_Lambda.

The denominator is a positive normalized tilt. The ratio is a posterior mean of m_e, so abs(u)<=eps_B for every finite pattern, including rare ones. The probabilities are (1+/-u)/2 and the half log odds are H_(e,Lambda)=atanh(u). Thus abs(H)<=atanh(eps_B). The target parity must be free, not already prescribed.

The admitted UC10-UC15 theorem supplies uniform convergence of these finite conditional rows to continuous all-exterior kernels. Passing the bounds through that limit gives the same amplitude estimate at every coarse exterior. No infinite event probability is divided. This gives exponential real bias control, not an absolute cardinality-weighted coefficient sum.

## IB04. Consistent canonical coefficients from the actual odds

Let H_e be the everywhere continuous half log odds, independent of its own coordinate. For finite S containing e define

 j_(S;e)=E_fair[H_e(Y) chi_(S without e)(Y)],

where fair product counting on all other coarse signs is a coefficient-extraction reference, not the Gibbs law. Boundedness gives the integral. Compatibility of the positive two-edge conditional kernel gives the four-corner identity

 H_e(y_f=+1)-H_e(y_f=-1)
 =H_f(y_e=+1)-H_f(y_e=-1).

Each side is half the logarithm of p(++)p(--)/[p(+-)p(-+)]. Multiply by the character on S without {e,f}, average the remaining fair coordinates, and divide by two. It follows that j_(S;e)=j_(S;f). Hence one canonical coefficient J_S exists independently of the mark. Arbitrarily chosen unrelated conditional rows would not satisfy this integrability identity.

Coarse translation covariance of the specification transfers to these coefficients. Use the first actual support-edge origin as representative, consolidating integer translations only. There is no area or root multiplier. Any absolutely summable interaction producing the same odds has these same coefficients by fair orthogonality, establishing uniqueness in the desired convention.

This coefficient array is not yet proved absolutely summable. Fair conditional expectation of continuous H_e onto an increasing finite coordinate set has its finite Walsh polynomial and converges uniformly: its error is bounded by the uniform variation over the omitted coordinates. Thus the complete array determines H_e, without asserting that its absolute Walsh series converges.

## IB05. A computable individual-coefficient oracle

The admitted UC08-UC15 modulus becomes rational uniformly on the box by setting

 q=(1+12c_max)/2,
 t=24c_max/(1+12c_max),
 C=16q/(1-q),
 k_0=(1-rho)/2.

All q,t lie in (0,1). These are exp(theta)=1/t and the worst influence q from the prior theorem. For a target anchor cell with a matching R-cell whole-block interior, its TV error against the infinite constrained law is at most C B^2(R+1)t^(R+1), uniformly over arbitrary fixed fine exterior signs. Prescribe the other path in the target cell when a one-edge row is needed. The same local support is used on both sides, as required by the comparison. The admitted free-path argument gives each target sign probability at least k_0 for every B>=1.

For H(p)=one half log[p/(1-p)], H'(p)=1/[2p(1-p)]<=1/(2k_0^2) on [k_0,1-k_0]. The resulting uniform half-log-odds error for a whole-block radius-L oracle is therefore

 eta_(B,L)=C B^2(L+1)t^(L+1)/(2k_0^2).

That oracle keeps the target path free, prescribes every other retained path in the finite anchor square and includes all unused blocks there. It retains every touching plaquette with its actual fine boundary substitution. Every pattern has positive mass. At rational b,c, full finite summation gives exact rational target probabilities using the original factors; the half logarithm can be enclosed to any rational accuracy by range reduction and the positive atanh series. Mathematical arbitrary precision requires increasing resources; an old routine with a fixed bit ceiling cannot itself promise arbitrary-accuracy completion.

Fix S and choose L containing its anchors. For every finite exterior parity assignment, compute the oracle row and log enclosure, then fair-average against chi_(S without e). A normalized fair average has norm one, so uniform error eta_(B,L)+xi gives that same coefficient error, without multiplying by the number of averaged patterns. Increasing L and precision computes J_S. This calculation may require enormous but finite enumeration and is not an efficiency or execution claim. No large carrier was run.

This proves individual coefficient computability. A finite table's total weighted error must count all its coefficients, and a whole-norm oracle still needs a bound on the omitted infinite array. Those are separate obligations.


## IB06. Marked Walsh algebra and the finite inversion obstruction

For a marked edge e and finite T not containing e define

 w_(alpha,beta,e)(T)=exp(alpha|T|+beta diam({e} union T)),
 norm_A(g)=sum_T w(T) abs(g_hat(T)).

The diameter of the union of two sets sharing e is at most the sum of their diameters, and |T symmetric_difference U|<=|T|+|U|. Thus w(T symmetric_difference U)<=w(T)w(U). Walsh multiplication is submultiplicative and the unit has norm one. The shared mark is essential to this diameter argument.

If norm_A(u)<=r<1, the odd atanh series converges absolutely in the algebra and gives norm_A(atanh u)<=atanh(r). Its sum equals the real half log odds because this norm dominates the uniform norm. No complex-inversion theorem is imported.

IB03 gives abs(D_hat(S))<=eps_B^|S| and abs(N_hat(S))<=eps_B^(|S|+1). For M exterior edges whose union with e has diameter at most d, therefore

 norm_A(D-1)<=exp(beta d)[(1+exp(alpha)eps_B)^M-1]=d_bar,
 norm_A(N)<=eps_B(1+d_bar).

If d_bar<1 the geometric inverse proves norm_A(N/D)<=eps_B(1+d_bar)/(1-d_bar). For every fixed B this d_bar diverges as M grows. It cannot prove an infinite-volume inverse. Sending B to infinity after fixing M only gives a fixed-cylinder result. The needed cancellation belongs to the normalized marked response N/D, uniformly in exterior size and spatial coefficient weights, not to a uniformly small unnormalized global density.

## IB07. Small conditional bias and real continuity are insufficient

On M signs take the positive fair density 1+epsilon chi_all, 0<epsilon<1. Every one-sign conditional mean has magnitude epsilon. Its sole nonempty interaction coefficient is atanh(epsilon) on the M-set, so its incident norm is M exp(kappa M+lambda diam)atanh(epsilon). Arbitrarily small real conditional bias thus permits arbitrarily large exponential-cardinality interaction norm. For example epsilon_B=exp(-B) with M_B of order B^2 has this behavior. This is a finite counterexample to an implication, not a realization of the stipulated two-dimensional family.

Likewise a diameter-only bound on a dense radius-R support does not control exp(kappa|S|), since such a support can have order R^2 signs. A uniform real continuity estimate of order (R+1)t^R cannot by itself pay for extracting all Walsh coefficients on that many signs. The prior old-norm embedding obstruction is therefore relevant to the method, but does not refute basin entry of this particular family.

## IB08. A fixed-parity cumulant defeats covariance-only tree control

Take n>=3 independent signs with mean b in (0,1/4], conditioned on their product being +1. For a subset A of size k,

 E[chi_A]=(b^k+b^(n-k))/(1+b^n),
 Cov(X_i,X_j)=b^(n-2)(1-b^2)^2/(1+b^n)^2 for i!=j.

The first identity follows by multiplying the original law by (1+chi_all)/2 and normalizing by (1+b^n)/2; subtraction gives the second. With independent fields h_i the conditional log partition is the sum of log cosh terms plus log(1+product_i tanh(h_i)) and a constant. Its mixed derivative in all n distinct fields has no contribution from the first sum. Expanding the remaining log gives

 cum(X_1,...,X_n)=(1-b^2)^n sum_(r>=1)(-1)^(r-1) r^(n-1)b^(n(r-1)).

This scalar series and the required finite derivatives converge absolutely because b^n<1. For r>=2,

 r b^(r-1)<=2b(3b/2)^(r-2),

since each successive ratio is b(1+1/r)<=3b/2. Hence the sum of absolute terms after r=1 is at most

 (2b)^n/[2(1-(3b/2)^n)]<1/2.

The full cumulant is at least one half of (1-b^2)^n. A product of n-1 pair covariances instead contains b^((n-2)(n-1)). Multiplying by any fixed C(b)^n, a factorial and all n^(n-2) labeled trees still leaves a negative quadratic term in its logarithm, whereas the cumulant lower bound decays only exponentially. No such uniform covariance-product tree bound holds for these biased fixed-parity product references.

This is a normalized auxiliary reference calculation. It rules out that specific cumulant estimate if a proof expands around these references; it does not rule out full-block-mark bounds, another representation, or the actual c>0 basin theorem.

## IB09. The precise open response lemma and its sufficient consequences

A sufficient remaining lemma is the following finite statement. For the fixed compact box and prescribed kappa,lambda, put alpha=kappa+1 and beta=lambda+1. Prove computable B_*, C_*>0, nonnegative integer p and 0<s<1 such that, for every B>=B_*, finite exterior inventory Lambda and marked edge e,

 sum_(T subset Lambda) exp(alpha|T|+beta diam({e} union T))
 abs(Fourier_T[N_(e,Lambda)/D_Lambda])
 <=r_B=C_* B^p s^B,

uniformly over all real parameters in the box. N,D are the actual normalized-law quantities fixed in IB03, not a replacement reference. An alternative computable exponentially decreasing eventual envelope would also suffice. This estimate is not proved in this initial record. IB06 proves a finite bound that fails uniformly in Lambda, and IB08 refutes one tempting covariance-only substitute.

Here are the complete consequences if the lemma is supplied. The admitted uniform real limit makes every fixed coefficient converge. Fatou's inequality for countable nonnegative coefficient sums preserves the weighted bound in the limiting u_e. Its absolutely summable Walsh expansion converges uniformly and, by uniqueness of all fair coefficients, equals the actual continuous u_e. For r_B<1 the algebra estimate gives norm_A(H_e)<=atanh(r_B). With T=S without e, (|T|+1)<=exp(|T|) therefore yields

 norm_(kappa,lambda)(J^(B))<=exp(kappa)atanh(r_B)=E_B.

IB04 makes this the consistent complete coefficient representative. Its uniformly absolutely convergent energy differences reproduce the actual singleton odds. Two positive finite-target kernels with the same single-flip odds have equal ratios along each hypercube path; they differ by one common factor, and normalization makes them equal. Thus this interaction represents every exterior kernel and the actual pushed law, not just almost-sure conditionals.

The spare spatial weight also gives a whole incident tail bound: deleting every support of diameter greater than R costs at most E_B exp(-R). The factor |S| was paid by the spare cardinality weight, while exp(-R) uses the separate spare spatial weight. Neither count is erased.

An explicit eventual B0 follows from the supplied constants. Let a=-log(s)>0. For B>=2p/a the ratio of consecutive B^p s^B values is at most exp(-a/2), by log(1+1/B)<=1/B. Rational enclosures of these constants, exp(kappa) and the admitted epsilon can select a monotone tail index and search until r_B<1/2 and 2 exp(kappa)r_B<epsilon. Since atanh(r)<=r/(1-r^2)<=2r for r<=1/2, entry holds for every larger integer B, not a subsequence. The constants may depend on the prescribed weights and compact box. Choosing easier weights would not satisfy the target.

For a rational whole-norm oracle, choose R with E_B exp(-R)<tolerance/2. Every support of diameter at most R through a fixed oriented edge lies in at most M_R=2(2R+1)^2 coarse edges. A bound on the sum of its retained coefficient-error weights is

 W_R=2^(M_R-1) M_R exp(kappa M_R+lambda R).

Enumerate all canonical supports of diameter at most R, preserving axes, and apply IB05 to approximate each coefficient within delta<tolerance/(2W_R). Rational midpoints give a finite library whose retained error is at most W_R delta and whose omitted error is at most E_B exp(-R). Incidence counts all literal translates through a root; no additional area multiplier is justified. Every selected enumeration and precision is finite, possibly extremely expensive. Mathematical termination requires increasing resources; a bounded stop gives no final certificate.

Thus normalization, coefficient consistency and individual computability are proved separately. The missing bridge is the displayed uniformly weighted finite normalized-response estimate, which fixes its actual numerator, denominator, observable, reference and weights for direct proof or attack. It cannot be replaced by a claim that real mixing implies cardinality summability.

## IB10. Uncertain-input words and a precision trap to avoid

Suppose a basin oracle certifies norm(J-P)<=eta_0 for finite rational P and exact target J. A conditional simple wrapper is valid if the old evaluator returns radius r with input norm upper nu_0 satisfying nu_0+eta_0<r. Both exact and approximate trajectories then lie in the same convex ball, and the correct recurrence starts with e_0=eta_0:

 e_(j+1)<=L_j e_j+tau_j.

However, sufficient-resource termination of that simple wrapper does not follow merely by increasing the old maximum precision. The old admission stops at the first precision proving its finite input strict. Its returned radius might have a gap comparable to, or smaller than, the oracle uncertainty even when the true target is strictly inside epsilon. More allowed precision need not force this successful early admission to refine. A new wrapper must explicitly address its uncertain domain, not assume it follows from exact-input success.

A complete conditional construction avoids this trap without modifying the old source. First choose a sufficiently accurate basin approximation with eta_0<tolerance/4 and establish norm(P)+eta_0<epsilon using refined input norm and constant enclosures. Call the old exact-input word evaluator with a strict tolerance share, for example tolerance/4, obtaining its completed radius r_old and all tails tau_j. Next refine new enclosures until their epsilon_L exceeds both r_old and a certified U+eta_0. This is possible because both true quantities are strictly below epsilon. Set

 r_new=(max(r_old,U+eta_0)+epsilon_L)/2.

Then every old approximate state lies inside r_old<r_new, and both exact trajectories start inside r_new and stay there by radial contraction. Compute new constants L_j=ell_(j,U)+2M_(j,U)r_new<1 with these same refined constants. Propagate e_0=eta_0 and e_next=L_j e+tau_j using the already certified old local tails. Their validity at each old approximate input is unchanged; the new L_j bound the actual comparison segments in the larger common ball. Since every L_j<1, e_final<=eta_0+sum_j tau_j. The old source's local tolerance allocation makes that sum strictly smaller than its requested share; alternatively verify the finite sum directly before returning a new certificate.

A sharper final decomposition is also valid: the old final error plus eta_0 times the product of the new L_j bounds the difference from the exact uncertain target, by comparing the two exact trajectories first. This does not authorize reusing the old smaller radius without the new admission.

With sufficiently accurate basin approximations, the true strict margin is positive. Refined finite enclosures resolve both strict comparisons, all old Taylor steps terminate with sufficiently large resources, and the new finite arithmetic therefore terminates. Failed new admission, an unfinished old word or a final excessive bound remains incomplete for the uncertain target. Completed prefix records cannot erase uncertainty. Empty words return P with error eta_0. No executable wrapper has been inspected or written by this lane.

## IB11. Actual path composition and initial scope conclusion

Deterministic parity blocking satisfies T_a T_B=T_(aB). In the staged path the fine locations are B(ax+r unit_i)+s unit_i, with 0<=r<a and 0<=s<B, which enumerate the aB consecutive fine edges once. Once the basin representative and its norm admission exist, the admitted local operator applied to J^(B) and the independently defined J^(aB) therefore give the same actual pushed law and every-exterior odds. IB04 makes their complete nonempty coefficients equal. Finite approximations are compared by their certified target errors rather than equality of truncated tables.

The exact normalized channel retains the original scalar factors. Selecting only nonempty coefficients later does not recover the discarded fine partition, evidence or a VFE value. Any finite probabilistic control retains its own actual normalizer and counting reference. The full parameter box, every exterior, both orientations and prescribed kappa/lambda remain load-bearing. No physical clock, critical limit or identification of gauge, Fisher and base curvature is added.

The initial construction is incomplete exactly at IB09. It supplies direct normalization, odds/mark consistency, individual coefficient computation, a conditional full-norm oracle theorem, and a domain-qualified uncertain-word bridge. It does not prove the uniformly weighted response estimate for this two-dimensional family. No counterexample to the frozen target was found. IB07 and IB08 refute specified shortcuts only. These initial bytes are preserved before mature counterpart access; any later resolution must identify the new proof that supplies the missing estimate.


## Read bindings

`docs/derivations/2026-09-09-basin-entrance-rg/problem-contract.json`: `b2c5ed364adfd5787d5a3f524168f4607cc0ce40bdbd8a12c33ed8921b5bfa8d`.

`Theory/SPEC.md`: `dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1`.

`docs/derivations/2026-09-09-uniform-depth-gibbs-rg/agents/uniform-coupling-construction.md`: `e09c831abae9432637659be974711c36ffd9d22fa90c7735737ca746a5cec67d`.

`docs/derivations/2026-09-09-open-neighborhood-rg/release.json`: `13641c198dde60d1a4bd693df31e177a97c603ce129ff9e2e108892606fe93fa`.

`docs/derivations/2026-09-09-finite-amplitude-rg/release.json`: `4f517971b9fa7f8197db09e2c322832a9cea08af7e985bc714f980f17798d688`.

