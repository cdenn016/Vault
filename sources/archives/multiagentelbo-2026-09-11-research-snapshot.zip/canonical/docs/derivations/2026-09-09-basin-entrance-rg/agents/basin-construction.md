<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537","target_digest":"e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537"} -->

# Basin construction with prescribed coefficient weights

Date: 2026-09-09. **DEFINITION OF EVIDENCE SCOPE.** This initial author construction was persisted before reading any new root, worker or checker draft in this run. The author wrote the preceding discovery notes and shares that context, including the suggestion to recover coefficients from conditional odds; those notes are not used as admitted premises. Every new identity and bound needed here is derived below. The frozen contract SHA256 is b2c5ed364adfd5787d5a3f524168f4607cc0ce40bdbd8a12c33ed8921b5bfa8d. Theory/SPEC.md was read in full and has unchanged SHA256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. These are author proposals, not ledger closure assignments or execution evidence.

## BE01. The exact interior channel

**ESTABLISHED BY FINITE CONDITIONING.** Fix the contract's compact rational box and the prescribed positive rational kappa,lambda. Write h=atanh(b), J=atanh(c), and B>=3. On every retained straight B-path keep its first and last fine edges and integrate its B-2 interior edges. No elementary plaquette contains two integrated edges: two perpendicular retained edges in one plaquette must both be at grid-corner endpoints, while parallel retained paths have separation B. Given the remaining fine variables, the integrated bits are independent. For a horizontal path p with fine origin (0,0), its conditional parity mean is

\[
 g_p=z_{(0,0,0)}z_{(B-1,0,0)}
 \prod_{r=1}^{B-2}\tanh\bigl(h+J(u_r+v_r)\bigr),
 \label{eq:rg-be-channel}
\]

where u_r,v_r are the products of the other three edges in its upper and lower plaquettes. Every touching plaquette is retained, including its reduction against any fixed fine exterior. The vertical formula is the rotation of this expression.

The exact remaining support S_p consists of the two endpoints; horizontal edges (r,1,0),(r,-1,0), 1<=r<=B-2; and vertical edges (r,0,1),(r,-1,1), 1<=r<=B-1. It has 4B-4 edges. These supports are pairwise disjoint. For horizontal remaining edges, horizontal-strip membership requires x mod B in {1,...,B-2}, whereas vertical-strip membership requires x mod B in {0,B-1}; the other coordinate determines the unique neighboring segment. Retained endpoints belong only to their own strip. Rotating proves the vertical-edge case. The B>=3 condition distinguishes residues 1 and B-1. Each S_p has fine anchor diameter at most B-1 and lies within scaled distance one of p's coarse anchor, where a fine anchor x is represented by x/B.

For any finite observed path set P, the exact marginal density relative to fair coarse counting is

\[
 p_P(y)=E_\mu\prod_{p\in P}(1+y_p g_p),
 \label{eq:rg-be-finite-density}
\]

with mu the actual original fine law. This follows by integrating the chosen interiors; the functions g_p ignore every integrated interior, so the expectation may equivalently use their remaining-variable marginal. Fairly averaging every y_p gives one. No reference replacement, lost normalizer or source-order approximation enters this identity.

## BE02. Uniform weighted activity

**ESTABLISHED BY FOUR-POINT WALSH ALGEBRA.** Put rho=b_max and t=tanh(2J)=2c/(1+c^2). The function f(u,v)=tanh(h+J(u+v)) has expansion a_0+a_1(u+v)+a_12 uv, where a_0>=0,a_1>=0,a_12<=0 and

\[
 a_0-a_{12}=b,\qquad
 2a_1=\frac{t(1-b^2)}{1-b^2t^2},\qquad
 a_{12}=-\frac{b t^2(1-b^2)}{2(1-b^2t^2)}.
 \label{eq:rg-be-fine-walsh}
\]

These identities follow by substituting (b+/-t)/(1+/-bt) at u=v=+/-1 and b at u=-v. Since c<1/12 implies t<24/145, the coefficient l1 norm R_0=a_0+2a_1+|a_12| obeys

\[
 1-R_0\ge\frac{13489}{20449}(1-b).
 \label{eq:rg-be-slack}
\]

Indeed R_0=b+t(1-b^2)/(1-b^2t^2), and t(1+b)/(1-b^2t^2)<=2t/(1-t^2)<=6960/20449.

Define the positive rationals

\[
 \Delta=\frac{13489}{20449}(1-\rho),\qquad
 \alpha=\Delta/24,\qquad \sigma=1-3\Delta/4.
 \label{eq:rg-be-alpha}
\]

For a fine Walsh function use ||F||_alpha=sum_S |F_S| exp(alpha|S|), including constants. Symmetric-difference cardinality proves submultiplicativity. Each u or v in the original fine heat-bath mean uses three neighbors, hence

\[
 \|f_e\|_\alpha\le e^{6\alpha}(1-\Delta)\le\sigma<1,
 \qquad
 \|g_p\|_\alpha\le G_B:=\frac{\sigma^{B-2}}{1-2\alpha}.
 \label{eq:rg-be-G}
\]

Here exp(x)<=1/(1-x) for 0<=x<1 follows by comparing its positive series to the geometric series, and (1-Delta)/(1-Delta/4)<=1-3Delta/4. The two endpoints cost exp(2alpha). The compact's lower endpoints are not needed for this bound; their strict positivity remains part of the admitted model.

## BE03. The normalized fine tilt

**ESTABLISHED BY A POINTWISE IDENTITY.** Once G_B<1 define u_p=(1/2)log(1-g_p^2) and v_p=atanh(g_p). Their convergent coefficient-algebra series satisfy

\[
 \log(1+y_p g_p)=u_p+y_p v_p,\qquad
 \|u_p\|_\alpha\le U_B:=\frac{G_B^2}{2(1-G_B^2)},\qquad
 \|v_p\|_\alpha\le V_B:=\frac{G_B}{1-G_B^2}.
 \label{eq:rg-be-uv}
\]

Thus observing P with values y tilts the fine law by the positive normalized factor product_(p in P)(1+y_p g_p), retaining both u_p and y_p v_p in its log weight. Each fine edge belongs to at most one S_p. For the target row at e, omit p=e from the observed inventory. The coarse conditional mean is the expectation of g_e under this tilted fine law. This also defines the correct finite-pattern and partial-pattern constructions, not merely the fully observed exterior.

## BE04. Arbitrary coarse weights in one algebra

**DEFINITION.** Set beta=kappa+1 and omega=2lambda+1. For any positive rational x write E_x=3^ceil(x), a rational upper bound for exp(x), since exp(1)<3 by its series. For fine supports S, coarse parameter supports T and a fixed coarse anchor o, let

\[
 R_o(S,T)=\max\left(\{\|x/B-o\|_\infty:x\in S\}
                  \cup\{\|z-o\|_\infty:z\in T\}\cup\{0\}\right),
\]
\[
 \|F\|_o=\sum_{S,T}|F_{S,T}|
       e^{\alpha|S|+\beta|T|+\omega R_o(S,T)}.
 \label{eq:rg-be-radius-norm}
\]

Coordinates in S and T mean edge anchors; orientations remain part of each character label. The completion of finite coefficient inventories in this l1 norm is a Banach algebra: the radius of a union is at most the sum of the two radii, while XOR can only remove labels. Also use the same norm with the radius factor omitted, denoted ||.||_(alpha,beta).

## BE05. Exact row perturbation bound

**ESTABLISHED BY BANACH-ALGEBRA INVERSION.** The added conditional field H_f at a fine edge f from the observation factors has joint cardinality norm at most

\[
 \eta_B:=U_B+E_\beta V_B.
 \label{eq:rg-be-eta}
\]

Deleting f from each incident character only reduces the favorable factor exp(alpha); ignoring that reduction gives this bound. Disjoint S_p prevent an additional sum over observed paths. For eta_B<1/3, the geometric inverse in tanh(H)=(exp(2H)-1)/(2+exp(2H)-1) gives

\[
 \|\tanh H_f\|_{\alpha,\beta}\le
 W_B:=\frac{\eta_B}{1-3\eta_B}.
 \label{eq:rg-be-W}
\]

To see the rational bound, ||exp(2H)-1||<=2eta_B/(1-2eta_B); substitute this into A/(2+A). If sigma W_B<1, the tanh addition identity for the perturbed conditional mean F_f gives

\[
 \|F_f-f_f\|_{\alpha,\beta}\le
 D_B:=\frac{(1+\sigma^2)W_B}{1-\sigma W_B}.
 \label{eq:rg-be-D}
\]

This is a bound for the difference, rather than the entire row. All algebraic inverse series converge absolutely in the displayed norms. The corresponding real row is the conditional mean of the normalized positive tilted law.

## BE06. Weighted stationarity contraction

**ESTABLISHED BY CHARACTER SUBSTITUTION.** On a character with nonempty fine support define

\[
 A(\chi_S y_T)=|S|^{-1}\sum_{f\in S}\chi_{S\setminus\{f\}}y_T F_f,
 \qquad A(y_T)=0.
 \label{eq:rg-be-A}
\]

An original row term f_f introduces neighbors at fine distance at most one from f, increasing R_o by at most 1/B. A difference term F_f-f_f introduces only the original neighbors, variables in the one strip containing f, and that strip's coarse label. The diameter of S_p is at most B-1 and its coarse anchor is within scaled distance one of f, so this increases R_o by at most one. Deleting the updated fine character costs exp(-alpha). Summing absolute coefficients and averaging over |S| therefore gives, for B>omega,

\[
 \|A\|_o\le e^{-\alpha}
       [\sigma e^{\omega/B}+D_B e^\omega]
 \le q_B:=\frac{\sigma}{1-\omega/B}+E_\omega D_B.
 \label{eq:rg-be-q}
\]

This distinguishes fine steps from strip steps. Multiplying every original update by exp(2lambda) would fail for arbitrary prescribed lambda; the factor exp(omega/B) is the required scale dependence. The possibly large beta and omega enter fixed constants and a B threshold, not a restriction on the requested norm.

Let q_*=(1+sigma)/2. Since q_B tends to sigma, q_B<=q_*<1 holds eventually. Projection Pi onto fine-constant characters has norm at most one. With N=(1-Pi)A, Gibbs stationarity for each updated fine bit yields

\[
 E[F]=\Pi F+\sum_{j\ge1}\Pi A N^{j-1}(1-\Pi)F.
 \label{eq:rg-be-expectation}
\]

The term using j substitutions has norm at most q_*^j||F||_o. For each real exterior y, the remaining expectation after truncation is bounded by the same norm tail, because signs have absolute value one. Hence the coefficient series equals the actual normalized expectation. Fine constants are absorbed and never updated, so the zero mode of the Markov generator is not inverted.

## BE07. Every fine boundary and coarse pattern

**ESTABLISHED BY LOCAL STABILIZATION.** All row functions are finite local functions for each fixed B, uniformly bounded by the preceding estimates. A fixed number of substitutions visits a finite fine neighborhood. A finite fine volume containing that neighborhood uses the same rows; exterior reduction is just substitution of fixed signs and cannot increase the coefficient norm. The remaining series is uniformly geometric. This proves boundary-independent convergence of every finite-character expectation. Positive finite-volume laws exist by their finite normalizers. The limiting cylinder probabilities are nonnegative, normalized and consistent; a countable cylinder extension supplies the law. Conditional identities pass to the limit by the same local convergence. Two infinite Gibbs laws must have the same character expectations by the series, proving uniqueness of the tilted fine law for every partial or full coarse pattern.

For increasing finite observed sets, each fixed substitution history depends on only finitely many labels. Their values stabilize, and the geometric remainder is uniform over all other values and absent labels. This proves uniform convergence in the product topology to every exterior, rather than an almost-sure choice. The construction of a finite coarse conditional set A uses the tilted law observing the complement of A and the density E product_(e in A)(1+x_e g_e). Its fair average is one and its values lie between (1-G_B)^|A| and (1+G_B)^|A|. Finite conditional identities pass through the uniform limit, giving an everywhere-defined consistent positive coarse specification gamma_A. By finite Bayes conditioning and the original channel identity, the actual pushed fine law satisfies this specification.

## BE08. Full weighted conditional odds

**ESTABLISHED BY THE CONVERGENT ROW SERIES.** For a coarse target e at anchor o, use the fine law observing every other coarse path and set m_e(y)=E[g_e]. The initial radius of S_e is at most one, so

\[
 \|m_e\|_{\beta,\omega;o}\le
 M_B:=\frac{E_\omega G_B}{1-q_*},
 \label{eq:rg-be-M}
\]

where the left norm contains only coarse characters after absorption. Take B large enough that M_B<1/4. The conditional half-log-odds is L_e=atanh(m_e), and

\[
 \|L_e\|_{\beta,\omega;o}\le\frac{M_B}{1-M_B^2}.
 \label{eq:rg-be-L}
\]

The logarithm is the real log of a positive row; its algebra series converges absolutely. For S not containing e, with s=|S|, use (s+1)<=exp(s) and diam({e} union S)<=2R_o(S). This yields

\[
 \sum_S(s+1)e^{\kappa(s+1)+\lambda\operatorname{diam}(\{e\}\cup S)}
       |\widehat L_e(S)|
 \le E_B:=E_\kappa\frac{M_B}{1-M_B^2}.
 \label{eq:rg-be-E}
\]

The bound is uniform over orientations, compact parameters and all B satisfying the gates. It tends to zero exponentially in B in the prescribed kappa,lambda norm.

## BE09. Canonical interaction and consistency

**ESTABLISHED BY CONDITIONAL SQUARES.** For a nonempty coarse support T and any e in T, define J_T^(B)=the Walsh coefficient of L_e at T without e. This does not depend on the marked edge. To prove it, fix distinct e,f and the other coarse signs. Positivity and consistency of gamma_(e,f) imply

\[
 L_e(y_f=+1)-L_e(y_f=-1)
 =L_f(y_e=+1)-L_f(y_e=-1).
 \label{eq:rg-be-square}
\]

Both sides equal half the log of the same conditional two-by-two cross ratio. Taking a Walsh coefficient of the remaining exterior identifies twice the respective coefficients for a support containing e and f. The coefficient series are absolutely summable, so these integrals and discrete differences are justified. The equality holds for every exterior by BE07, not just almost surely.

Consequently BE08 bounds exactly ||J^(B)||_(kappa,lambda), and its absolutely convergent Gibbs single-site odds equal L_e. For a fixed exterior and finite A, positive single-site ratios determine the finite probability on its connected sign cube uniquely; hence the entire Gibbs specification agrees with gamma_A. Coarse translations preserve the path geometry and fine law, giving translation invariance. Taking the first edge in lexicographic order and subtracting its anchor chooses one scalar-free translation representative, with orientation and negative relative coordinates retained. The actual pushed law is Gibbs for this interaction at every exterior. Once its norm is in the admitted common ball, prior uniqueness also identifies it as the unique law there. No vacuum-potential norm conversion is assumed.

## BE10. A computable uniform B threshold

**ESTABLISHED BY MONOTONE RATIONAL GATES.** For a in {2,3,6}, choose safe rational bounds

\[
 \overline K_a=\frac{8a E_{\lambda(1-1/a)}}{\kappa(1-1/a)},\qquad
 \overline\ell_a=1/a,\qquad \overline M_a=11\overline K_a/a,
\]
\[
 \epsilon_L=\min_a\left\{1/48,1/(2\overline K_a),
                 (1-\overline\ell_a)/(2\overline M_a)\right\}>0.
 \label{eq:rg-be-epsilon}
\]

These dominate the prior constants in the safe directions and give epsilon_L<=epsilon. Starting with integer B>=3 and B>omega, check G_B<1, eta_B<1/3, sigma W_B<1, q_B<=q_*, M_B<1/4 and E_B<epsilon_L/4. All are rational tests. Increase B until they hold. Every gate holds eventually. On this domain G_B,eta_B,W_B,D_B,q_B,M_B,E_B are nonincreasing in B, so the first accepted integer is a valid B0 for every larger B. This is a finite algorithm, not an asymptotic definition of B0. Its resource cost may be large; no efficiency bound is asserted.

## BE11. A finite rational conditional-row oracle

**ESTABLISHED BY EXACT LOCAL ARITHMETIC.** Suppose b,c are rational and B>=B0. The functions g_p are rational on every fine sign configuration. The original row f_f is rational as well; it may be evaluated directly from factors 1+b z_f and the two touching factors 1+c chi_p. For the target row e, a fine edge f either belongs to no observed strip, in which case F_f=f_f, or belongs to one observed strip p. Put w_+=1+y_p g_p(z_f=+1) and w_-=1+y_p g_p(z_f=-1). Its exact tilted mean is

\[
 F_f=\frac{(1+f_f)w_+-(1-f_f)w_-}
           {(1+f_f)w_++(1-f_f)w_-}.
 \label{eq:rg-be-rational-row}
\]

The denominator is positive for every sign configuration. Thus complete local Walsh tables for F_f follow from a finite sum of rational values over its finite fine neighborhood and its at most one coarse label. This computes the same row bounded by the u/v argument, without evaluating logarithms, atanh parameters or an interpolation integral. No independence among its arguments is required for Walsh algebra.

Compute the expectation series for g_e through K substitutions, keeping complete finite coefficient dictionaries and projecting fine constants as in BE06. Each step has finitely many current supports and finitely many local row coefficients, with the exact 1/|S| factor. The result m_e^[K] is a rational coarse polynomial and obeys

\[
 \|m_e-m_e^{[K]}\|_{\beta,\omega;o}
 \le M_B q_*^{K+1},\qquad
 \|m_e^{[K]}\|_{\beta,\omega;o}\le M_B.
 \label{eq:rg-be-mean-tail}
\]

No source is pruned by a small coefficient or projected to a pairwise family. Fine and coarse repetitions are combined by exact XOR.

## BE12. Rational odds approximation and whole-interaction error

**ESTABLISHED BY POSITIVE POWER-SERIES TAILS.** For integer D>=0 put

\[
 L_e^{[K,D]}=\sum_{j=0}^D\frac{(m_e^{[K]})^{2j+1}}{2j+1}.
\]
\[
 \|L_e-L_e^{[K,D]}\|_{\beta,\omega;o}
 \le\delta_{K,D}:=
 \frac{M_B q_*^{K+1}+M_B^{2D+3}/(2D+3)}{1-M_B^2}.
 \label{eq:rg-be-odds-tail}
\]

For the first term telescope each power in atanh and sum its derivative majorant 1/(1-M_B^2); for the second sum the omitted odd powers using denominator at least 2D+3. All returned coefficients and the bound are rational.

Compute these polynomials for e=(0,0,0) and e=(0,0,1). Emit a coefficient for T=S union {e} only when its actual lexicographically first edge is e. This yields one finite orbit library. Approximate rows need not obey exact conditional squares, so its full-norm error must pay orbit incidence separately. An orbit has at most |T| translates incident to any prescribed fine-orientation copy of a coarse edge. Summing the two canonical-row errors and using (s+1)^2<=4 exp(s) gives

\[
 \|\widehat J^{(B;K,D)}-J^{(B)}\|_{\kappa,\lambda}
 \le 8E_\kappa\delta_{K,D}.
 \label{eq:rg-be-oracle-error}
\]

This factor includes the norm's cardinality and the incident-translate count; there is no unproved consistency of the approximate rows. The exact rows' consistency was established separately in BE09. Both exponents in delta_(K,D) tend to zero. Hence for every positive rational tolerance a finite K,D exists and can be found by increasing integer values and rational comparison.

Every finite K uses only finitely many fine variables within a finite neighborhood of radius at most B(K+2), up to the fixed initial strip convention, and finitely many coarse labels within K+1 of the target anchor. Taking products for L does not enlarge that label inventory. Exact finite Walsh enumeration, substitution and convolution therefore terminate with sufficiently large finite resources. A declared budget must count its actual finite inventories and arithmetic and return incomplete if they are not finished; no six-sign cap is imposed on the mathematical oracle merely because independent test controls have that cap.

## BE13. Uncertain-input finite words

**ESTABLISHED BY THE PRIOR MAP BOUNDS AND THE ORACLE ERROR.** Let r=epsilon_L/2 and let m be the length of a finite factor word. Choose an oracle error delta_0 strictly below both epsilon_L/4 and tolerance/[2(m+1)]. Then the true input has norm below r/2, and the finite approximation has certified norm bound nu_0=E_B+delta_0<r. Set e_0=delta_0. For each factor a use

\[
 L_a=\overline\ell_a+2\overline M_a r<1,\qquad
 q_a=\overline\ell_a+\overline M_a r<1,
\]
\[
 \nu_{j+1}=q_a\nu_j+\tau_j,\qquad
 e_{j+1}=L_a e_j+\tau_j.
 \label{eq:rg-be-word}
\]

The first inequality controls the approximate state; the second compares it with the exact RG image. The segment between the true and approximate inputs remains in the convex ball of radius r. The admitted derivative bound therefore pays the input uncertainty once, and the complete Taylor omission pays tau_j once.

Choose each positive tail tau_j below both tolerance/[2(m+1)] and (1-max_a q_a)r/2. Then every nu_j<r and e_m<tolerance. Since overline K_a r<=1/4, the complete finite-input Taylor tail decreases to zero with order. The admitted evaluator supplies each finite rational polynomial with sufficiently large resources, and BE12 supplies the initial finite rational library. A stopped oracle or an incomplete Taylor degree cannot furnish a successful final certificate. The empty word returns the oracle table with its input error. Exact path composition identifies the infinite target with the B times product-of-factors path push; approximate direct and staged libraries are compared only through their certified errors.

## Scope and initial handoff

**NOT-CLAIMED.** This author construction makes no execution, runtime, novelty or native closure claim. Its initial status is a supplied derivation for independent reconstruction against the frozen universal target. It adds no curvature factor to the fixed normalized model and identifies neither an RG depth nor an information clock with physical time. Gauge holonomy, Fisher geometry and contextual-base curvature retain their separate types. All proposed coefficient manipulations concern the complete character family, not a fitted two-parameter action, and no scalar-free table is used to invent a normalizer or VFE value.
