<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537","target_digest":"e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537"} -->

# Basin entrance in the complete path-RG interaction norm

Date: 2026-09-09. The claim here is the frozen high-temperature basin bridge, conditional on the unchanged prior spatial-law and local-RG releases. It is not completion of the full renormalization program. The proof is assembled from the explicit normalized-row construction, its finite character-span implementation lemma and the independently reconstructed finite-kernel and spatial-tail arguments. Current finite source controls supply separate executable evidence.

## Theorem and assumptions

For every compact rational box 0<b_min<=b<=b_max<1 and 0<c_min<=c<=c_max<1/12, and every prescribed positive rational kappa,lambda, there is a computable integer B0 such that the actual straight B-path push of the admitted two-dimensional dressed gauge-matter law has one canonical translation-invariant scalar-free Walsh interaction J^(B) for every B>=B0. It represents the pushed law at every coarse exterior. In the original prescribed norm

    ||J||_(kappa,lambda) = sup_e sum_(S contains e) |S| exp(kappa|S|+lambda diam(S)) |J_S|,

the explicit uniform bound is

    ||J^(B)||_(kappa,lambda) <= E_B
    = 4 A_kappa M_B/(1-M_B^2),
    M_B = A_2lambda G_B/(1-r),
    G_B = sigma^(B-2)/(1-2alpha).

The compact-dependent rational alpha>0 and sigma<1, fixed r<1 and rational exponential upper bounds are exactly RB01–RB03. The finite rational gate search guarantees E_B<epsilon0/16, below a positive lower bound for the prior common RG radius. E_B decreases exponentially in B. The fine coefficient weight alpha is auxiliary; kappa and lambda are never weakened.

For rational b,c in the box and every positive rational requested error, the algorithm supplies a finite rational canonical orbit table with that error in the entire norm under sufficiently large finite caller-selected resources. Every bounded stop is explicitly incomplete. The same statement holds for every finite word in factors 2,3,6 after adding the oracle's input uncertainty to the prior evaluator's truncation error and checking the actual common domain. No default-budget or machine-complexity assertion is included.

## Proof mechanism and actual law

Eliminating the B-2 path interiors leaves pairwise disjoint strips of 4B-4 signs. Conditional independence of those interiors gives the exact finite parity density E_mu product_p(1+y_p g_p), with all original factors and normalizers retained. The auxiliary fine law tilted by this product has the correct remaining-sign marginal for parity inference; it is not falsely equated to the hard-parity posterior on all fine signs.

The four-value Walsh expansion of the original fine conditional mean supplies a compact-uniform coefficient slack. With beta=kappa+1 and fine distance weight 2lambda/B, each original fine update costs only one fine step, while a small observed-strip correction costs at most B steps. Direct two-point normalization gives the full rational observed mean

    F_e = [f_e+y_p(f_e g0+g1)]/[1+y_p(g0+f_e g1)].

Its local coefficient norm is at most r<1 under the stated gates. The denominator and its even/scalar contribution are retained, and the target strip is omitted when its own mean is calculated.

Average the conditional substitution over the current nonempty fine support S with factor 1/|S|. The resulting operator A contracts in the rooted joint fine/coarse character algebra. Projection Pi absorbs empty fine supports once; N=(1-Pi)A updates the rest. The convergent series Pi g+sum_(k>=1)Pi A N^(k-1)(1-Pi)g equals the actual normalized target mean by finite stationarity. Each fixed order has a finite stabilized inventory, and its uniform geometric remainder proves the every-exterior limit. Positive finite conditional kernels, their Bayes consistency and the actual pushed-law DLR identity pass through this uniform limit.

The atanh series gives complete half-log-odds. The positive two-edge conditional square identity equates coefficients marked at different members of a support. These consistent coefficients reproduce every finite conditional kernel. For a size-n orbit, n_i(S)n<=n^2 and n^2 exp(kappa n)<=2 exp(kappa)exp((kappa+1)(n-1)); summing two canonical root orientations gives the factor 4 above. This same incidence bound applies to approximate-row errors without assuming those finite rows themselves satisfy the square identity.

The detailed derivations are agents/root-weighted-row-construction.md RB01–RB07, agents/interface-proof.md BI01–BI07 and agents/independent-proof-check.md MC01–MC06. The independent initial file retains its genuine missing weighted-response obligation and its counterexamples to real-bias and covariance-tree shortcuts. Those counterexamples remain valid; the contracting normalized local-row mechanism supplies the previously missing estimate.

## Complete finite oracle, spatial tail and word error

The code computes each local inverse completely on a GF(2) basis for its typed character span, then lifts every coefficient to its literal fine/coarse support. The independent basis map is surjective; outside-span coefficients vanish on its fibers. Full Walsh-Hadamard inversion is therefore the entire raw-coordinate inverse, not an independence approximation. Its rank is at most 2B, so B=3 uses at most six basis signs. The actual support cardinality and spatial coordinates, never generator count, determine the norm. See agents/root-character-span-inverse.md and MC07.

Retaining K absorbed substitutions and odd powers 1,...,2L-1 gives the exact finite rational table with whole error

    delta <= 4 A_kappa [
        d_K/(1-M_B^2)
        + M_B^(2L+1)/((2L+1)(1-M_B^2)) ],
    d_K = M_B r^K.

This bounds every unreturned support and coefficient. All earlier unabsorbed frontiers survive; the final update may compute Pi A directly because there is no later consumer of N^K. Every final source, update and row coefficient is still processed. Finite local inventories and geometric tails establish sufficiently-large-resource termination.

The complete prescribed-norm tail over supports with diameter>2(K+1) is at most 4 A_kappa d_K/(1-M_B^2). After K substitutions all labels lie within coarse radius K+1; the full atanh of that finite-variable function cannot introduce a new label. Comparing it with the exact odds proves this spatial tail, as derived in MC08. The executable finite odd polynomial still pays its separate power tail.

For a completed old word with error e_old and actual Lipschitz constants L_j, the final true-orbit error is e_old+delta product_j L_j. The wrapper computes epsilon0 using the same capped precision sequence as its actual old call and verifies E_B<the returned radius. Both exact trajectories lie in that ball. The empty word keeps delta. Literal path composition and canonical coefficient uniqueness identify the exact target with the B times product-of-factors path push.

## Source and executed scope

The additive module is src/multiagent_elbo/rg_v2/basin_entrance.py. The unchanged finite_amplitude_rg.py supplies its old exact-input word evaluator. The active run_lab.py PROFILE remains neighborhood; the new API is reached by the explicit dedicated source-injected runner. No existing experiment configuration is changed.

The sole packet basin-entrance-tests-20260909T172621824543Z has 41 distinct passing cases, zero failures/errors/skips and JUnit 0.847 seconds. It includes a complete nonzero positive-c B=3,K=2,L=1 oracle at b=c=10^-9, prescribed weights, exact normalized local controls and finite uncertain words. Twenty-nine source/config/proof/test bindings were current on raw readback. This is isolated Anaconda Python3.12.7 source compatibility; pyproject>=3.14 is unchanged. Finite tests do not measure the infinite norm error or prove the universal theorem.

No original raw partition, scalar VFE offset, curvature action, critical/continuum limit, dynamical metric or physical clock is inferred from this scalar-free interaction. The future geometry-indexed normalized-joint proposal is discovery only and excluded from this certificate. The no-tamper directive remains in force; those checks are user-excluded/not run.
