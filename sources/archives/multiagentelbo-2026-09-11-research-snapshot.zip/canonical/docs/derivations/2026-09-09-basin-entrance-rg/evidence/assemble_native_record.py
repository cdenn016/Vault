"""Assemble the current basin proof/source/finite-result record without scientific replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[4]
RUN = Path(__file__).resolve().parent.parent
VERIFY = ROOT / 'docs/verification/2026-09-09-basin-entrance-rg'

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))

def dump(name: str, value: object) -> None:
    (RUN/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')

def main() -> None:
    assert not (RUN/'evidence/native-intake.json').exists()
    contract = read(RUN/'problem-contract.json')
    meta = {k:contract[k] for k in ('schema_version','contract_id','target_digest')}
    selected = read(RUN/'agents/selected-final-proposals.json')
    rows = selected['claims']
    ids = [r['id'] for r in rows]+['target']
    assert len(ids)==len(set(ids))==24
    deps = {r['id']:r['dependencies'] for r in rows}
    deps['target'] = selected['target_dependencies']
    coverage = read(RUN/'agents/coverage-proposals.json')
    assert not coverage['pending']
    assert set(ids)=={r['claim_id'] for r in coverage['claims']}
    assert all(set(r['dependencies'])==set(deps[r['claim_id']]) for r in coverage['claims'])
    assert all(sha(ROOT/p)==h for p,h in coverage['bindings'].items())
    commands=list(VERIFY.glob('*.command.json'))
    results=list(VERIFY.glob('*.result.json'))
    xmls=list(VERIFY.glob('*.xml'))
    assert len(commands)==len(results)==len(xmls)==1
    command,result=read(commands[0]),read(results[0])
    assert result['returncode']==0
    assert all(result[k] for k in ('source_unchanged','driver_unchanged','contract_unchanged'))
    assert len(command['source_sha256'])==29
    assert all(sha(ROOT/p)==h for p,h in command['source_sha256'].items())
    assert sha(commands[0])==result['command_receipt_sha256']
    assert sha(xmls[0])==result['junit_sha256']
    assert sha(xmls[0].with_suffix('.log'))==result['log_sha256']
    assert sha(VERIFY/'run_basin_entrance_tests.py')==command['driver_sha256']
    assert sha(RUN/'problem-contract.json')==command['contract_sha256']
    for key in ('command','config'):
        assert hashlib.sha256(json.dumps(command[key],sort_keys=True).encode()).hexdigest()==command[key+'_sha256']
    assert command['config']['nodes']==['tests/rg_v2/test_basin_entrance.py']
    assert command['config']['maximum_independently_enumerated_signs']==6
    cases=ET.parse(xmls[0]).getroot().findall('.//testcase')
    names=[x.get('classname')+'::'+x.get('name') for x in cases]
    assert len(names)==len(set(names))==41
    assert not any(x.find(t) is not None for x in cases for t in ('failure','error','skipped'))
    assert {k:result[k] for k in ('tests','distinct_tests','failures','errors','skipped')}==dict(tests=41,distinct_tests=41,failures=0,errors=0,skipped=0)
    frozen={
        'independent-initial-reconstruction.md':'ef340e91e72fc4764cd97336d8858a09c6152260493391868fcb9521635413d9',
        'initial-proposals.json':'e06bcd5af15aabdb3593bd5fba82219e66f9dd3b573e72874a720c89ffa8e729',
        'basin-construction.md':'f11a6b0d81189f8dd388fc285f3ab4fd00586fc0ff4d89588b3e69f51b9b21c7',
        'author-claims.json':'b662f13ad3647bfaea969413e644ae18dc7dd2b824524b3284a9d88423f67c3f',
        'root-weighted-row-construction.md':'b11ee101c8c9e5f5373bc1b4f3f40fbf4df77e3106a7d9789c9026ad239b9936',
        'implementation-claims.json':'c554929f860198ef01f0a560e0723da3a4b6c259d9c2474df45842cdb695883f',
    }
    assert all(sha(RUN/'agents'/p)==h for p,h in frozen.items())
    context=read(RUN/'evidence/freeze-record.json')
    assert all(sha(ROOT/p)==h for p,h in context['existing_inputs_sha256'].items())
    bindings=set(coverage['bindings'])|set(command['source_sha256'])|set(context['existing_inputs_sha256'])
    bindings.update(p.relative_to(ROOT).as_posix() for p in (RUN/'agents').iterdir() if p.is_file() and not p.name.startswith('next-'))
    bindings.update((RUN/p).relative_to(ROOT).as_posix() for p in (
        'execution-plan.md','counterexample-register.md',
        'evidence/freeze-record.json','evidence/root-execution-preflight.json',
        'evidence/root-result-readback.json','evidence/assemble_native_record.py','evidence/run_structural_checks.py'))
    bindings.update(('docs/reports/2026-09-09-basin-entrance-rg.md',
                     'docs/verification/2026-09-09-basin-entrance-rg/deliver_to_desktop.py'))
    intake={**meta,'timestamp_utc':datetime.now(timezone.utc).isoformat(),
        'accepted_current_scoped_evidence':True,
        'read_artifact_sha256':{p:sha(ROOT/p) for p in sorted(bindings)},
        'root_assessment':'Root reconstructed normalized local rows, weighted stationarity, uniform finite kernels, canonical incidence, complete character-span inverse and whole error/word domain; read all source/test/driver and retained raw output. Mathematical claims close on those derivations, not on the finite packet.',
        'independence_limit':'Distinct initial snapshots followed by mature reconstruction; shared model family, context and filesystem. Agent agreement and a structural validator are not mathematical evidence.',
        'scope':'Frozen basin-entry target only; all prescribed weights and full admitted compact boxes. Future geometry-joint discovery is excluded, and the full RG goal remains active.',
        'finite_evidence':'One retained 41-distinct-case packet, zero failure/error/skip, JUnit0.847 seconds,29 current source/config/proof/test bindings; no replay.',
        'user_excluded_not_run':['tamper/corruption/forgery checks']}
    dump('evidence/native-intake.json',intake)
    raw={p.relative_to(ROOT).as_posix():sha(p) for p in VERIFY.iterdir()
         if p.is_file() and not p.name.startswith(('deliver_','delivery'))}
    science={**meta,'source_sha256':command['source_sha256'],'raw_artifact_sha256':raw,
        'execution_history':[dict(path=results[0].relative_to(ROOT).as_posix(),sha256=sha(results[0]),**result)],
        'latest_cases':dict(distinct=41,passed=41,failed=0,errors=0,skipped=0,execution_total=41),
        'junit_cases':names,'runtime':command['runtime'],'config':command['config'],
        'user_excluded':['tamper/corruption/forgery checks'],
        'unrun':['old tests/producers','broad suite','Phase13','held S1-S3','large law','GPU science'],
        'scope':'Finite source controls and certificate arithmetic. Complete nonzero positive-c oracle and uncertain words exercised; infinite norm discrepancy not measured. Universal whole-norm and all-exterior claims rest on proof.'}
    dump('evidence/scientific-record.json',science)
    for p in (commands[0],results[0],xmls[0]):
        (RUN/'evidence'/p.name).write_bytes(p.read_bytes())
    evidence,claims,edges,attacks=[],[],[],[]
    def ev(eid: str, kind: str, path: str, statement: str, conditions: list[str]) -> str:
        evidence.append(dict(id=eid,kind=kind,supports=True,scope=statement,side_conditions=conditions,
            artifact_path=path,artifact_sha256=sha(RUN/path)))
        return eid
    for row in rows:
        cid=row['id'];conditions=list(row.get('assumptions',[]))
        numeric=row['kind']=='NUMERICAL_OBSERVATION'
        if numeric:
            eids=[ev('raw-'+cid,'NUMERICAL','evidence/scientific-record.json',row['statement'],conditions),
                  ev('junit-'+cid,'NUMERICAL','evidence/'+xmls[0].name,row['statement'],['Sole retained packet; no replay.'])]
        else:
            if row['kind']=='CODE':
                conditions.append('Source-to-algorithm identity under declared guarded-operation scope, not a claim about every host allocation or all runtimes.')
            eids=[ev('proof-'+cid,'DERIVATION',row['proof_artifact'],row['statement'],[row['proof_section'],*conditions]),
                  ev('independent-'+cid,'DERIVATION','agents/coverage-review.md',row['statement'],['Current per-claim reconstruction with preserved independent initial evidence.'])]
            if row['kind']=='CODE':
                eids.append(ev('finite-'+cid,'NUMERICAL','evidence/scientific-record.json',row['statement'],['Finite controls supplement the source identity.']))
        claims.append(dict(id=cid,kind='NUMERICAL_OBSERVATION' if numeric else 'MATHEMATICAL',
            statement=row['statement'],quantifiers=row['quantifiers'],target_digest=meta['target_digest'],
            state='EVIDENCE_VERIFIED',assumption_ids=[],explicit_assumptions=conditions,evidence_ids=eids,
            bridge_premise_ids=[],falsifier=row['falsifier']))
    target=contract['target']
    claims.append(dict(id='target',kind=target['kind'],statement=target['statement'],quantifiers=target['quantifiers'],
        target_digest=meta['target_digest'],state='EVIDENCE_VERIFIED',assumption_ids=[],bridge_premise_ids=[],
        evidence_ids=[ev('target-proof','DERIVATION','construction-or-strongest-theorem.md',target['statement'],
                        ['Only the frozen basin target and its explicit prior law/local-RG premises. Full goal remains active.'])],
        falsifier=target['falsification_criterion']))
    for claim in claims:
        cid=claim['id']
        edges.extend({'from':cid,'to':dep} for dep in deps[cid])
        attacks.append(dict(id='attack-'+cid,claim_ids=[cid],attack=claim['falsifier'],
            response='The current per-claim coverage reconstructs this exact failure condition using direct proof, literal source or retained finite output, with all scope conditions explicit.',
            disposition='REJECTED',artifact_path='agents/coverage-review.md',artifact_sha256=sha(RUN/'agents/coverage-review.md')))
    dump('claim-ledger.json',{**meta,'assumptions':[],'evidence':evidence,'claims':claims})
    dump('dependency-dag.json',{**meta,'edges':edges})
    reconstruction=dict(claim_ids=ids,method='Preserved contract-first channel/odds construction with explicit open response, followed by complete mature theorem/source/raw-output reconstruction.',
        result='PASS',conclusion='Each frozen-target dependency has a current scope-matched derivation or finite observation.',
        artifact_path='agents/coverage-review.md',artifact_sha256=sha(RUN/'agents/coverage-review.md'))
    dump('adversarial-report.json',{**meta,'attacks':attacks,'independent_reconstruction':reconstruction,
        'oracle_erasure':{**reconstruction,'method':'Erase favorable expectations and numerical data; derive exact normalization, local inverse, weighted absorption, uniform kernels, mark consistency, full oracle and actual-domain word error from explicit premises.'}})
    families=[
        ('normalized-row-absorption',[f'R{i:02d}' for i in range(1,9)],'Exact disjoint-interior channel, full local conditional inverse and rooted character-stationarity contraction.'),
        ('independent-response-obligation',['R01','R06','R07','R08','R13'],'Initial normalized channel and odds construction, explicit failed global-response inverse and shortcut counterexamples; mature direct resolution of the missing weighted-response and uncertain-radius bridges.'),
        ('finite-character-oracle',[f'R{i:02d}' for i in (9,10,11,15,16)],'Full finite character-span inversion, finite absorbed polynomials, complete odd-series and spatial tails with literal canonical incidence.'),
        ('uniform-basin-word',['R12','R13','R14'],'Monotone rational depth gates and actual-domain exact-trajectory comparison under geometric path composition.'),
        ('implemented-finite-controls',[f'BAI{i:02d}' for i in range(1,7)]+['BAN01'],'Current source-to-recurrence correspondence and a single tiny normalized exact-control packet.')]
    dump('approach-registry.json',{**meta,'mechanism_families':[
        dict(family_id=fid,core_mechanism=mechanism,target_obligation_ids=cids,
            representation='Actual positive square-lattice path law and complete scalar-free translation-orbit interaction in prescribed weights.',
            invariant_or_obstruction='Full normalization, all character orders, every exterior, literal supports, full omitted norm and true common domain.',
            obligations=['Every universal and sufficiently-large-resource conjunct in the frozen contract.'],
            bridge='Direct local-row contraction, consistent canonical odds and complete finite inverse/oracle.',
            failure_test='Missing normalization or support, inward bound, invalid exterior limit, false radius or false bounded certificate.',
            verified_results=cids,open_gaps=[],novelty_fingerprint=mechanism+' No novelty claim.',
            disposition='Established at the stated frozen scope; failed shortcut implications remain recorded.') for fid,cids,mechanism in families]})
    dump('release.json',{**meta,'checkpoint':'Current proofs/source/retained finite output accepted; structural checkpoint pending.',
        'target_claim':'target','terminal_status':None,'certificate_claim':'target',
        'strongest_result':'Complete prescribed-weight basin entrance for every compact admitted positive gauge-matter box, with exact rational full-norm approximation and uncertainty-qualified finite words.',
        'unresolved_obligations':[],'limitations':['Full RG goal remains active.','High-temperature family and prior local-operator scope only.',
            'Default finite budgets are not universally sufficient.','Finite tests do not measure the infinite norm error.',
            'Scalar-free output supplies no original partition or VFE.','Geometry-indexed joint, critical/continuum and physical identification remain separate.']})
    dump('evidence/native-adjudication.json',{**meta,
        'method':'Root accepts current derivations and retained mechanical output after independent reconstruction; no vote or validator-based mathematical inference.',
        'claims':{c['id']:dict(state=c['state'],kind=c['kind'],evidence_ids=c['evidence_ids']) for c in claims},
        'counts':dict(claims=len(claims),evidence=len(evidence),edges=len(edges),attacks=len(attacks))})
    print(json.dumps(dict(accepted_artifacts=len(bindings),claims=len(claims),evidence=len(evidence),
        edges=len(edges),attacks=len(attacks),intake_sha256=sha(RUN/'evidence/native-intake.json'))),flush=True)

if __name__=='__main__':
    main()
