"""Record structure/hash checks; these do not establish mathematical truth."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
RUN=Path(__file__).resolve().parent.parent
SKILL=Path(r'C:/Users/chris and christine/.codex/skills/rigorous-theory-search/scripts')
sys.path.insert(0,str(SKILL))
from validate_run import validate_run
NAMES=('problem-contract.json','approach-registry.json','claim-ledger.json','dependency-dag.json','adversarial-report.json','release.json','counterexample-register.md','construction-or-strongest-theorem.md','final-report.md')
def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()
def check(mode: str) -> None:
    destination=RUN/'evidence'/('native-'+mode+'.json')
    assert not destination.exists(),'do not overwrite an earlier gate result'
    before={name:sha(RUN/name) for name in NAMES}
    errors=validate_run(RUN,mode=mode)
    data=dict(mode=mode,passed=not errors,errors=errors,validator_sha256=sha(SKILL/'validate_run.py'),
              input_sha256=before,inputs_unchanged=all(sha(RUN/name)==h for name,h in before.items()),
              timestamp_utc=datetime.now(timezone.utc).isoformat(),
              scope='Structural schema/hash/evidence/coverage validation only; proofs and exact output supply scientific evidence.')
    destination.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(data),flush=True)
    if errors or not data['inputs_unchanged']:raise SystemExit(1)
def main() -> None:
    check('checkpoint')
    release=json.loads((RUN/'release.json').read_text(encoding='utf-8'))
    release['terminal_status']='COMPLETE_AFFIRMATIVE'
    release['checkpoint']='Frozen prescribed-weight basin-entry theorem and implementation supported by current direct proofs, source correspondence and retained finite evidence; structural checkpoint passed.'
    (RUN/'release.json').write_text(json.dumps(release,indent=2)+'\n',encoding='utf-8')
    check('release')
if __name__=='__main__':
    main()
