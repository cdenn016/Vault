<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537","target_digest":"e6fc8e7ff27fcaa8553a80e01c69b848367e197cebb7da43437828edd12c7537"} -->

# Counterexamples and retained construction attacks

The frozen target was not refuted. The initial independent reconstruction preserves two exact counterexamples to tempting intermediate implications and a precision-interface obstruction. Their formulas and derivations are in agents/independent-initial-reconstruction.md, which was frozen before mature candidate access. None is reclassified as a counterexample to the stipulated positive two-dimensional family.

## Small real conditional bias does not control the coefficient norm

Initial IB07 uses the positive finite density 1+epsilon chi_all on M signs. Every singleton conditional mean has magnitude epsilon, while the interaction has one coefficient atanh(epsilon) on the full support. Its prescribed norm is M exp(kappa M+lambda diam)atanh(epsilon). Small real bias, even accompanied by finite-cylinder continuity, does not imply the required exponential-cardinality coefficient summability. The existing diameter-only norm obstruction is retained for the same reason. The successful construction supplies a stronger normalized coefficient-algebra contraction directly; it never invokes either false embedding.

## Pair covariance products do not control all fixed-parity cumulants

Initial IB08 computes biased independent signs conditioned on their complete product. Its exact n-point cumulant is bounded below by a constant times (1-b^2)^n, whereas a product of n-1 pair covariances contains b^((n-2)(n-1)). Fixed exponential, factorial and labeled-tree prefactors cannot repair that quadratic-exponent mismatch for arbitrarily large n. This refutes the stated covariance-product bound on that auxiliary parity reference. It is neither a c>0 physical-family counterexample nor a reason to discard normalization. The mature construction uses no such bound.

## A successful exact-input radius need not contain an uncertain input

Initial IB10 correctly identifies that increasing a maximum precision does not force an already successful early old admission to refine. In addition, a capped terminal degree can differ from an uncapped doubling sequence. The implemented wrapper derives epsilon0 with the same cap as its actual old call, retains the strict basin margin, explicitly checks the returned radius against the true input bound, and adds the oracle error times the actual Lipschitz product. The initial objection remains valid against a wrapper lacking these steps.

## Weighted-response obligation and mature resolution

The independent initial IB09 left the uniform normalized-response coefficient estimate unproved. It was an open bridge, not an obstruction theorem. MC02–MC03 in agents/independent-proof-check.md reconstruct the new full local-row contraction, the 1/|S| average, absorption, finite-order locality and uniform finite-kernel limit. These supply the missing bound for the actual law at the prescribed weights. MC04–MC08 then verify mark consistency, incidence, the full rational oracle, the actual common domain and the explicit spatial tail.

The R01–R16 and BAI01–BAI06 falsifiers are checked individually in agents/coverage-review.md and the native adversarial record. The sole finite packet contains ordinary scientific/domain/resource controls only. No deliberate artifact corruption, forgery, malicious-packet scenario or tamper test was invoked; these remain user-excluded/not run.
