# Gaussian conditional completion of parent inference

September 8, 2026. This implementation extends the fixed-context full-Gaussian control from the preceding inference milestone. The prior, likelihood, posterior target, coarse map, context, and chosen connections remain fixed. The flow parameter orders recognition-law changes; it is not physical time or an additional base coordinate. The new state retains the entire hidden conditional law. It is an exact augmented representation of the existing full-family flow, without a claim of dimension reduction, minimal memory, autonomous parent closure, or closure of the separate conditional-tree Euler solver.

## Fixed coordinates and admitted laws

Let \(F:\mathbb R^n\to\mathbb R^m\) have full row rank, with \(0<m\leq n\). Choose rows \(N\) forming an orthonormal basis of \(\ker F\), and fix

\[
\begin{pmatrix}Y\\X\end{pmatrix}=Tz,
\qquad T=\begin{pmatrix}F\\N\end{pmatrix}.
\]

The rows of \(F\) span the orthogonal complement of \(\ker F\), so \(T\) is invertible. Numerical admission uses the dtype-dependent rank criterion in `torch.linalg.matrix_rank`; an ill-conditioned map may therefore be rejected. The complete QR factorization supplies a basis at this fixed context. No claim of smooth dependence of that QR basis across contexts is needed or made.

A positive full Gaussian is represented as

\[
q_Y=\mathcal N(\mu,V),\qquad
q_{X|Y=y}=\mathcal N(b_q+B_qy,C_q),
\]

with a fixed target described by \((\nu,V_p,b_p,B_p,C_p)\) in the same coordinates. Both \(V\) and \(C_q\) are positive definite. Standard Gaussian conditioning obtains this representation: \(B_q=\Sigma_{XY}\Sigma_{YY}^{-1}\), \(b_q=\mu_X-B_q\mu_Y\), and \(C_q=\Sigma_{XX}-B_q\Sigma_{YX}\). Reconstruction retains the cross covariance \(VB_q^T\) and hidden covariance \(C_q+B_qVB_q^T\), then applies \(T^{-1}\). These conditioning identities are given by Rasmussen and Williams, [Appendix A, equations A.5–A.6](https://gaussianprocess.org/gpml/chapters/RWA.pdf).

When \(n=m\), the coarse map is invertible. The implementation uses `conditional=None`, every hidden-information polynomial is zero, and the update reduces to the ordinary full-Gaussian flow in the visible coordinates. It does not construct or invert a zero-dimensional covariance.

## Conditional information and the parent velocity

Set \(\delta b=b_q-b_p\), \(\delta B=B_q-B_p\), and \(J_p=C_p^{-1}\). The conditional divergence is the quadratic field

\[
d(y)=\operatorname{KL}(q_{X|y}\Vert p_{X|y})
=d_0+\ell^Ty+\frac12y^TDy,
\]

where

\[
D=\delta B^TJ_p\delta B,\qquad
\ell=\delta B^TJ_p\delta b,
\]

\[
d_0=\frac12\left[
\operatorname{tr}(J_pC_q)-(n-m)
+\log\frac{\det C_p}{\det C_q}
+\delta b^TJ_p\delta b\right].
\]

The determinant, trace, and mean terms follow from the Gaussian KL identity; the same primary appendix gives that identity in equation A.23. Integrating the polynomial gives

\[
E_{q_Y}d=d_0+\ell^T\mu
+\frac12\left[\mu^TD\mu+\operatorname{tr}(DV)\right],
\]

which is the hidden contribution in the exact KL chain rule. Its positive mean alone does not establish a failure of autonomous parent inference.

For the full-law reverse-KL Fisher flow, the log-density velocity is the negative centered log ratio. Marginalizing this identity over \(X\) gives

\[
\partial_t q_Y(y)=-q_Y(y)\left[
\log\frac{q_Y(y)}{p_Y(y)}+d(y)
-E_{q_Y}\left(\log\frac{q_Y}{p_Y}+d\right)\right].
\]

Writing \(r=y-\mu\), the additional centered field is

\[
d(y)-E_{q_Y}d=(D\mu+\ell)^Tr
+\frac12\left[r^TDr-\operatorname{tr}(DV)\right].
\]

Gaussian second, third, and fourth centered moments now give the exact visible rates

\[
\dot\mu=-V\left[V_p^{-1}(\mu-\nu)+D\mu+\ell\right],
\qquad
\dot V=V-V(V_p^{-1}+D)V.
\]

The regression/intercept cross term \(\ell\) is retained. A constant conditional divergence contributes no correction. In this positive Gaussian family, \(D=0\) is equivalent to \(\delta B=0\), since \(J_p\) is positive definite. Thus matching regressions remove the correction even with differing offsets or conditional covariances and positive hidden KL. Their equality persists under the conditional flow: when \(B_q=B_p=B\), the interpolated affine information is the interpolated conditional precision times \(B\).

## Exact finite step

For a nonnegative flow parameter \(t\), put \(a=e^{-t}\) and \(w=1-a\). The full flow satisfies \(q_t\propto q_0^a p^w\). Factoring it into its parent and hidden conditional gives

\[
q_{Y,t}(y)\propto q_{Y,0}(y)^a p_Y(y)^w Z_a(y),
\qquad
Z_a(y)=\int q_{X|y}(x)^a p_{X|y}(x)^wdx.
\]

Define \(S_a=wC_q+aC_p\). Direct integration of the conditional Gaussian product yields the stable expression

\[
\log Z_a(y)=\frac12\left[
w\log\det C_q+a\log\det C_p-\log\det S_a\right]
-\frac12aw(\delta b+\delta By)^TS_a^{-1}(\delta b+\delta By).
\]

This formula does not require commuting covariance matrices. To see the matrix identity behind it, let \(J_q=C_q^{-1}\) and \(J_a=aJ_q+wJ_p\). Then \(J_pS_aJ_q=J_a\), hence \(J_qJ_a^{-1}J_p=S_a^{-1}\), which is symmetric positive definite. Completing the square produces the displayed quadratic and the determinant identity produces its constant. This form avoids subtracting two large mean-energy quadratics and makes the zero correction for matching regressions explicit.

Write \(\log Z_a(y)=z_0+z_\ell^Ty+\tfrac12y^Tz_Dy\). The visible precision and information vector update as

\[
J_Y^+=aV^{-1}+wV_p^{-1}-z_D,
\qquad
h_Y^+=aV^{-1}\mu+wV_p^{-1}\nu+z_\ell.
\]

Here \(-z_D=aw\delta B^TS_a^{-1}\delta B\) is positive semidefinite, so the visible precision stays positive definite. The overlap constant is retained for diagnostics even though normalization removes it from the visible mean and covariance.

The hidden conditional precision and affine information update by

\[
J_X^+=aC_q^{-1}+wC_p^{-1},
\qquad
u_X^+=aC_q^{-1}b_q+wC_p^{-1}b_p,
\qquad
W_X^+=aC_q^{-1}B_q+wC_p^{-1}B_p.
\]

Solving gives \(C_q^+=(J_X^+)^{-1}\), \(b_q^+=C_q^+\nu_X^+\), and \(B_q^+=C_q^+W_X^+\). Reconstructing these updated factors exactly reproduces the full-joint Gaussian natural-parameter interpolation in real arithmetic. Repeated steps therefore have the same semigroup property as that full flow. This statement concerns the full Gaussian family, which can leave the original agent-chain Markov family.

## Implementation contract and checks

`gaussian_completion.py` exposes `Split(T, visible_dim)`, `Conditional(b, B, C)`, and `State(parent, conditional)`. The public functions are `make_split`, `decompose`, `compose`, `conditional_kl_polynomial`, `parent_rate`, `overlap_polynomial`, and `completed_step`. Both polynomial APIs use constant plus linear transpose times the visible coordinate plus one half of its quadratic form. `parent_rate` returns an existing `Gaussian` container holding mean and covariance velocities, not a probability law with positive covariance.

Every API operates on one unbatched context and retains the input dtype and device. Matrix solves and Cholesky factorizations implement the admitted SPD formulas without jitter, eigenvalue clipping, probability floors, or retries. `completed_step` returns its input state unchanged at \(t=0\), and otherwise computes \(w=-\operatorname{expm1}(-t)\) to retain small increments accurately. This numerical implementation is intended for the bounded, well-conditioned float64 neighborhood fixture; it does not certify arbitrary ill-conditioned matrix calculations.

Passive frame changes can lead the complete QR factorization to choose another hidden basis. Gauge checks consequently compare visible laws and reconstructed fine laws rather than QR entries. A separate hidden-basis rotation leaves visible rates and finite results unchanged. These are fixed-context coordinate statements, with no connection derivative or curvature evolution in this objective.

The supplied tiny tests compare the completed flow with the existing independent full-joint oracle, reconstruct the original law, evaluate conditional KL directly at Gaussian quadrature nodes, check the full KL chain identity, compare overlap with independent completion of the square, and compare visible rates with both pushed full-law rates and finite-step derivatives. They include semigroup composition, frame covariance, hidden-basis changes, the invertible-map case, matching regressions with positive hidden KL, and identical visible preparations with different hidden conditionals. The latter two distinguish a centered information field from the mere presence of discarded information. Tests are supplied for the coordinating implementation's consolidated execution; this derivation itself records no passing result.
