# E1 numerical-evaluation gate

This implements the numerical obligation in the approved
[E1/E2 accuracy design](../superpowers/specs/2026-09-07-rg-v2-e1-e2-accuracy-design.md).
The present unit supplies an evaluator and statistical reduction, tiny checks
and a bounded evaluation of saved tuples. It draws no new tuples and does not
append a sampling registry contract. Future sampling must consume this route
and retain its per-tuple endpoints, with the frozen family, budgets and seeds.

## Representation and arithmetic assumptions

A stored binary64 link vector u denotes its exact real normalization
q=u/sqrt(sum u_j^2). Each tuple has four such links. The admitted stored format
has finite coordinates and maximum absolute coordinate between 1/4 and 2;
old normalized tuples and the planned stored normalized draws meet this range.
This bounded representation avoids norm overflow or underflow. Small individual
coordinates may be subnormal. IEEE binary64 gradual underflow and correctly
rounded basic addition, subtraction, multiplication and division are assumed.
Every elementary result is expanded by one adjacent representable value.
Matrix reductions explicitly accumulate those enclosing products and sums;
BLAS results are candidates whose residuals are enclosed separately. NaN,
infinity, reversed or empty intervals cannot yield an accepted primitive.

Square-root candidates are bracketed by actual endpoint-square inequalities,
using outward products. A candidate is accepted only when its lower endpoint
squared is at most the input lower endpoint and its upper endpoint squared is
at least the input upper endpoint. Zero is handled exactly. No accuracy claim
about an unverified library square root is needed.

For exp(x), |x|<=16, put t=|x|/32. Enclose the positive Taylor polynomial
through degree 32. The omitted positive tail is at most
(1/2)^33/[33! (1-1/68)] < 10^-40. Add that tail outward and square five
times. Reciprocation handles negative x; monotonic endpoint evaluation handles
an interval. For log(x), exact binary exponent extraction reduces to 1<=v<2.
With z=(v-1)/(v+1), use twice the sum of z^(2k+1)/(2k+1), k=0,...,47.
Its positive remainder is at most
2 (1/3)^97/[97 (1-1/9)] < 10^-44. The same formula encloses log(2).
The basic-operation rounding error is carried through both polynomials.

These are deterministic floating-point enclosures under the stated IEEE
arithmetic contract. They do not establish that a finite PRNG sequence is
literally independent Haar sampling. That separate ideal-sampling qualification
from the design remains unchanged.

## Gaussian solve and likelihood bounds

The original fixed alpha=kappa=gamma=1 energy is a sum of a unit onsite
quadratic form, edge squared norms with exactly orthogonal representations,
and mixed squared norms. Hence its exact precision J is symmetric and J>=I.
The interval assembly follows the original site-major block convention, with
diagonal four, mixed block minus identity and edge blocks minus R and minus
R transpose. Fundamental and adjoint families retain distinct dimensions and
observation vectors.

For each column of a numerical candidate X for J^-1 H transpose, enclose
r=Jx-h using the full interval precision. Since the spectral norm of J^-1
is at most one, the Euclidean error of x is at most the Euclidean residual
bound. Thus every observed covariance entry is enclosed by the candidate
entry plus or minus its column error. Add identity to obtain V; intersect
with the transposed enclosure because exact V is symmetric. H selects
coordinates, so I<=V<=2I.

Let L be a computed Cholesky factor of the interval midpoint. Its binary64
entries denote an exact real matrix; strictly positive diagonal makes
D=L L transpose positive definite. Enclose E=D-V by outward matrix products
and let eta bound its infinity norm. Both D and exact V are symmetric, so
the spectral norm of E is at most eta. Since V>=I, the eigenvalues of
V^(-1/2) E V^(-1/2) lie in [-eta,eta]. Require eta<1. Therefore

$$
\log\det V \in
[2\sum_i\log L_{ii}-m\log(1+\eta),
 2\sum_i\log L_{ii}-m\log(1-\eta)].
$$

For a candidate z solving Vz=y, similarly enclose r=Vz-y. The inverse
spectral norm of V is at most one. Cauchy-Schwarz bounds the quadratic error
by norm(y) norm(r). Enclose y transpose z, add this signed error interval,
and combine with the log determinant in the normalized evidence expression

$$
s=\exp[-(\log\det V+y^\mathsf{T}V^{-1}y)/2].
$$

All sums, norms, products, logs and exponentials on this route are outward.
The exact normalized link products also enclose f, then a=exp(f-1),
b=as and h=a(s-c0)(f-mu0). Intersections use only the analytic ranges in the
approved design. For each h and b midpoint candidate m, the maximum distance
to both stored endpoints must be at most 10^-10. Admission is checked for
every future tuple; a solver or input that fails it stops the run. Passing
a finite fixture set is not a claim that every possible stored tuple will
be accepted by the numerical solver.

## Statistical reduction and implementation plan

Store exact Fraction sums and squares of binary64 midpoint values, their count,
and the exact maximum midpoint-to-endpoint displacement. This avoids a
floating summation or cancellation assumption when computing sample variance.
Enclose its square root, pad it by sqrt(n/(n-1)) epsilon, and compute the fixed
four-mean empirical-Bernstein radius with outward log(1600). Enlarge the mean
interval by epsilon and that radius. Preserve the strictly positive analytic
denominator lower bound in the interval intersection.

Compute mu0-mu from the original rational prior endpoints before binary64
conversion. Propagate the resulting correction (mu0-mu)(1-c0 A/B) through
the same denominator interval; never silently replace it by zero. Ranges,
delta, centers and thresholds are fixed by the approved design.

Implement the interval primitives and model/reducer first, then run one
focused tiny packet covering signed arithmetic, rational quaternion fixtures,
Gaussian evidence with an independent exact-rational reference, exact
midpoint accumulation, SD padding and nonzero prior correction. Inspect the
unchanged legacy launcher dictionaries and their actual model routes. After
those controls, evaluate a fixed prefix of each of the eight old beta=1
N=16384 cases. Use 64 tuples per file (256 per family), retain all endpoint
outputs and source/input bindings, and report the maximum widths and errors.
This is an evaluation gate using existing tuples, not a confidence result.
New fixed-sample launchers, registry contracts and execution are the next
unit after this numerical obligation is met.
