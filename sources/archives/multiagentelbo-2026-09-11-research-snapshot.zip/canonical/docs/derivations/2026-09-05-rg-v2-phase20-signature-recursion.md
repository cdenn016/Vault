# Phase 20 conditional closure and exact finite signature recursion

This document supplies the finite derivation required by C4 of the
[approved design](../superpowers/specs/2026-09-05-rg-v2-phase20-signature-recursion-design.md).
Its claim is conditional on the explicitly stated finite premises. The retained
integration checks those premises on four particular control/observation towers;
eight rational evaluations per tower are separate executable examples. The
proof does not infer a statement about real parameters from those samples.

## Objects and hypotheses

Fix one control and one observation. At each of three levels let X_l be the
finite positive support of a reference posterior pi_l. Each pi_l is a
probability vector strictly positive on X_l. Let R_lm(z,x) be the fixed
posterior reverse from X_m to X_l, with nonnegative entries, row sums one,
pi_m R_lm=pi_l, and R_02=R_12 R_01. These are parameter-independent reference
kernels; none is recomputed from the action parameters below.

Let B_l be the four named unperturbed basis columns (1,h_a^l,h_b^l,h_c^l).
The tuple of their values defines sigma_l:X_l -> S_l, where S_l contains
exactly the realized signatures. Assume the reverse signature histogram

\[
\sum_{\{x:\sigma_l(x)=s\}}R_{lm}(z,x)
\]

has the same value at every z with the same signature t=sigma_m(z).
Denote that value Q_lm(t,s). This is a statement about full histograms,
stronger than equality of their coordinate expectations. Assume the two target
evaluation spaces are saturated: independent columns of B_1 and B_2 span
every real function on S_1 and S_2, respectively. No source saturation
assumption is made.

Write E_l for the matrix evaluating the independent columns on S_l. It has
full column rank. Let L_l be the left inverse chosen by independent-row
interpolation, so L_l E_l=I. Target saturation gives E_m L_m=I for m=1,2.
The source space is V_0=range(E_0), and target spaces are V_m=R^{S_m}.

For the retained tower the source signatures are the eight triples of binary
bits (with a leading constant coordinate); E_0 has four columns and
H_0=k+g_a a+g_b b+g_c c. The middle and terminal sizes are four and two,
respectively. The proof also applies to smaller finite subsets satisfying
the same rank and factorization premises. Constants are included throughout.

## Quotient kernels and reference masses

Define pbar_l(s) by summing pi_l over the signature fiber s. These masses are
strictly positive and sum to one. Nonnegativity and normalization of R give
nonnegative Q entries and row sums one. For any function v on S_l, grouping
the finite sum by source signature gives the exact carrier identity

\[
\sum_x R_{lm}(z,x)v(\sigma_l(x))
  =(Q_{lm}v)(\sigma_m(z)).
\]

Apply the identity to each signature indicator and average using pi_m.
The marginal identity for R then gives pbar_m Q_lm=pbar_l.

To verify composition, choose any z in the terminal signature t and sum
R_02(z,x) over a source fiber s. Substituting R_02=R_12 R_01 and rearranging
finite sums yields

\[
\begin{aligned}
Q_{02}(t,s)
 &=\sum_y R_{12}(z,y)\sum_{x:\sigma_0(x)=s}R_{01}(y,x)\\
 &=\sum_u\left[\sum_{y:\sigma_1(y)=u}R_{12}(z,y)\right]Q_{01}(u,s)\\
 &=\sum_u Q_{12}(t,u)Q_{01}(u,s).
\end{aligned}
\]

Thus Q_02=Q_12 Q_01. Factorization is used in both grouping steps. Selecting
one representative without first proving equal histograms would not justify
either step.

## Claim and proof of typed nonlinear closure

For every finite real coefficient vector g in the independent coordinates of
V_l, define componentwise

\[
w=\exp(-E_lg),\qquad
T_{lm}(g)=L_m[-\log(Q_{lm}w)].
\]

All entries of w are positive and finite. Every row of Q is a probability
vector, hence its weighted average lies between the finite positive minimum
and maximum of w. Therefore the logarithm is finite for every parameter,
without a local small-tilt premise.

Target saturation implies

\[
E_m T_{lm}(g)=-\log(Q_{lm}\exp(-E_lg)).
\]

This proves exact image membership in the target space for every parameter.
It also proves supported carrier reconstruction by composing with sigma_m
in the preceding carrier identity. This is a closure statement between the
declared level spaces; source saturation and a posterior product law are
unnecessary.

In particular, let w0=exp(-E_0g). The exact middle reconstruction gives

\[
\exp[-E_1T_{01}(g)]=Q_{01}w_0.
\]

Substitute it into the second coupling map and use the independently typed
matrix composition:

\[
\begin{aligned}
T_{12}(T_{01}(g))
 &=L_2[-\log(Q_{12}Q_{01}w_0)]\\
 &=L_2[-\log(Q_{02}w_0)]
 =T_{02}(g).
\end{aligned}
\]

This completes the conditional all-parameter derivation. The conclusion
does not require either arrow to be invertible and does not identify different
coefficient spaces.

## Normalization and rational implementation

For a propagated positive weight define Z_l=pbar_l dot w_l. From the quotient
marginal identities,

\[
Z_m=pbar_m Q_{lm}w_l=pbar_lw_l=Z_l.
\]

Call the common positive value Z. The tilted signature posterior is
pbar_l(s)w_l(s)/Z; its mass is one. Its action increment relative to pbar_l
is -log(w_l)+log(Z). The offset is constant, already represented by the
constant basis column, and the same along direct and staged routes.
If e_l is the coefficient vector representing the constant one, then
Q exp[-E_l(g+c e_l)]=exp(-c) Q exp(-E_lg), so the raw map shifts by c e_m.
Consequently intermediate normalization only contributes a constant; the
terminal normalized action agrees along both routes. Scaling every source
weight by d scales Z by d and leaves normalized posteriors unchanged.

Positive rational weights are sufficient for the executable examples, not
for the proof's real-parameter domain. Rational Q preserves rational weights.
Writing their logarithms as canonical prime-log expressions and applying
rational L gives exact action coordinates at those points. An arbitrary
rational combination of prime logs may exponentiate to an irrational value;
the implementation therefore propagates weights, never exponentiated
interpolated coefficients. Formula arrays Q,E,L describe the real maps even
where the rational evaluator does not execute them.

## Scope and sources

The retained implementation checks the finite premises and evaluates the
specified recipes. It does not prove closure for other basis choices, unsaturated
target spaces, different controls, different towers, or parameter-dependent
channels. The prescribed hidden-bit reduced basis supplies a concrete
generated-interaction example; adding the actual missing interaction repairs
that tiny family only.

Coefficient dimensions including constants are 4,4,2 in the retained tower.
There is no common isomorphically identified coefficient space for an autonomous
beta subtraction. No fixed point, relevance exponent, universality, physical
time, arbitrary-depth extension, or continuum conclusion follows.

This is a finite application of the conditional action map and exact-image
criterion in [Theory/07b_agent_network_rg.tex](../../Theory/07b_agent_network_rg.tex),
eq:rg-local-action-map, eq:rg-normalized-perturbation-action, and
eq:rg-interaction-exact-image-invariance. The separate comparison requirement
is eq:rg-interaction-trivialization. The mathematical scope is also fixed by
[Theory/SPEC.md](../../Theory/SPEC.md). No novelty claim is made.
