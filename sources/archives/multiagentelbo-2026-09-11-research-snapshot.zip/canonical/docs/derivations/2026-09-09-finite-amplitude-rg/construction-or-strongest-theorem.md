<!-- rigorous-theory-search-metadata {"schema_version": "rigorous-theory-search/v1", "contract_id": "contract-sha256-2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c", "target_digest": "2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c"} -->

# Certified finite-amplitude construction

**ESTABLISHED WITHIN THE FROZEN CONTRACT BY THE LINKED DERIVATIONS AND SOURCE CORRESPONDENCE.** Fix the admitted exact high-noise path RG from the prior release and any positive rational kappa,lambda. Every finite rational translation-orbit interaction strictly inside its common epsilon ball admits a complete rational Taylor approximation to arbitrary positive rational full-norm tolerance. Every finite factor word admits a sequence of such approximations whose actual accumulated error is below the requested tolerance and whose computed intermediate states stay inside an explicitly certified working ball. The construction terminates with sufficiently large finite resources. The mathematical assertion does not say a particular bounded execution completed.

The [author construction](agents/finite-amplitude-construction.md) gives exact first-edge representatives, floor-division reference owners, complete all-plus moments and the labeled-subset cumulant recurrence. The finite radius catalog contains every connected contribution. Multiplying each literal-source multiset's integer cumulant by its source coefficient product and dividing by the factorials of its literal multiplicities equals the complete ordered Taylor formula. Canonical output filtering selects one coefficient per translation orbit before accumulation. The [connected-growth supplement](agents/interface-proof.md) proves a finite alternative traversal with exact deduplication and no pruning of temporarily scalar, partial or zero-cumulant frontiers. It has the same complete output as the catalog construction.

For the finite library J, exact translation counting gives

\[
 \|J\|_{\kappa,\lambda}
 =\max_{i=0,1}\sum_S n_i(S)|S|
 e^{\kappa|S|+\lambda\operatorname{diam}S}|j_S|.
\]

The [root enclosure proof](agents/root-certified-bounds.md) bounds each exponential by a rational Taylor sum and geometric remainder. Reciprocal endpoints handle negative arguments. Converging upper bounds K_(a,U),ell_(a,U),M_(a,U) give a positive epsilon_L<=epsilon tending to epsilon. Refine until nu>=||J|| satisfies nu<epsilon_L, then set r=(nu+epsilon_L)/2. Every truly strict input is eventually admitted. The working constants L_a=ell_(a,U)+2M_(a,U)r and q_a=ell_(a,U)+M_(a,U)r are strictly below one.

For a complete degree-p polynomial and x=K_(a,U)nu<1, the full omitted interaction obeys

\[
 \|\mathcal R_aJ-\widehat J_p\|
 \le\tau_a(p,\nu)
 =\frac{\nu}{a}\frac{x^p[(p+1)-px]}{(1-x)^2}.
\]

Its positive-series derivation justifies substituting upper constants. Increasing p drives the bound to zero, including every omitted cardinality and range. A partial enumeration does not meet the complete-polynomial premise. Zero interactions have exact zero remainder.

At each finite-word step use the actual approximate input norm upper bound nu_j. The next table has certified norm at most q_a nu_j+tau_j; require that bound to stay below r. The accumulated error satisfies e_(j+1)<=L_a e_j+tau_j. Choosing each tail below both the allocated tolerance t/(m+1) and half the radial margin (1-q_a)r/2 gives strict domain preservation and final error below t for a word of length m. Empty words return the input with zero error. The exact direct-six and staged-two/three targets agree by the prior theorem, while approximate tables are compared using the sum of their error bounds.

The [independent initial reconstruction](agents/independent-initial-reconstruction.md) uses a whole-source finite catalog and ordered occurrences, then independently derives rational admission, the tail and a finite-word induction. Its [mature comparison](agents/independent-proof-check.md) checks the author catalog, multiset weights, connected-growth interface and root constants without identifying these different candidate traversals. Shared model and filesystem limit independence; the displayed arguments, rather than agreement, support the mathematical statements.

The [implementation proof](agents/implementation.md) maps the complete source to these constructions. The sole retained [35-case packet](../../verification/2026-09-09-finite-amplitude-rg/finite-amplitude-tests-20260909T161201401555Z.result.json) passed with zero failure, error or skip; JUnit duration is 0.100 seconds. Actual nonzero fiber checks compare retained coefficients to the returned error, while the full weighted-norm assertion rests on the complete-polynomial and tail proofs. Exact source/config/contract bindings and the unchanged active profile are recorded in the [root readback](evidence/root-result-readback.json). Resource limits are caller-increasable charged-operation/guarded-result limits, not global memory or wall-time guarantees. Native structure checks remain a separate record, not mathematical evidence.

**NOT-CLAIMED.** A finite rational polynomial is an approximation to the exact nonzero interaction. It is not the exact pushed law, its discarded scalar partition term, or a computed VFE value. Every finite probability control retains its own actual normalizer and reference. This phase does not settle larger-orbit entrance, critical or continuum theory, or a physical clock. Gauge holonomy, Fisher curvature and base curvature remain distinct; any added geometric model term retains the prior normalized-generative requirements. The full RG goal remains active.
