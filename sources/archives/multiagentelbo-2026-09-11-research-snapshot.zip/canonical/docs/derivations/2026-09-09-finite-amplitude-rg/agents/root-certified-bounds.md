<!-- rigorous-theory-search-metadata {"schema_version": "rigorous-theory-search/v1", "contract_id": "contract-sha256-2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c", "target_digest": "2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c"} -->

# Exact scalar enclosures and finite-word certificates

This is root's independent construction from the frozen contract and the admitted prior nonlinear theorem. It was written before reading the new author's, worker's or checker's arguments. The complete global goal remains active. All statements below concern the existing high-noise path operator and its fixed scalar-free representation. Exact rational arithmetic is used for the finite calculation; sufficiently large finite resources and a particular bounded completion are separate assertions.

## RI01: rational bounds for the exponential

**ESTABLISHED.** Let x be a nonnegative rational number. Define t_0=1, t_(j+1)=t_j x/(j+1), and s_m=sum_(j=0)^m t_j. Whenever q=x/(m+2)<1, set u_m=s_m+t_(m+1)/(1-q). Then s_m<=exp(x)<=u_m. Indeed all terms are nonnegative, and after the first omitted term each successive ratio x/(j+1), j>=m+1, is at most q. The omitted tail is therefore bounded by its geometric majorant. For x=0 both endpoints are exactly one. For each fixed x the series converges by the ratio test and the displayed upper-minus-lower width tends to zero. Every endpoint and comparison is rational. For a negative argument -x use [1/u_m,1/s_m]. Positive reciprocal reverses inequalities, so these are convergent rational enclosures for exp(-x). No binary floating-point exponential is an admission authority.

**ESTABLISHED.** This is a terminating enclosure procedure to any prescribed positive rational width if arithmetic resources are unrestricted: increase m until q<1 and the rational width is below that width. Every particular finite m uses finitely many rational operations and finite integers. Bit-size, operation, allocation and order limits may interrupt a bounded realization. If an interruption occurs, it establishes only an incomplete calculation; it supplies no successful tolerance or radius certificate. No assertion that a fixed finite budget admits every input follows from mathematical termination. Rational arguments and exact finite input records permit validation before the recurrence; a declared machine integer or denominator guard is an executable resource restriction rather than a new analytic premise.

## RI02: exact finite-orbit norm and computable strict admission

**ESTABLISHED.** Store each nonempty input support S once modulo integer translations, with its coefficient j_S and its first edge anchor translated to the origin. Sort edges lexicographically including orientation, but identify only translations, never rotations. Write s=|S|, d=diam(S), and n_i(S) for the count of its orientation-i edges. Exactly n_i(S) distinct translates of S contain a prescribed orientation-i edge: send each distinct orientation-i member to that edge. These translations are distinct. No nonempty finite set is invariant under a nonzero translation, because iterating that translation would generate infinitely many members. The incidence sum for either orientation is therefore

\[
 N_i(J)=\sum_S n_i(S)|S|\exp(\kappa|S|+\lambda\operatorname{diam}S)|j_S|,
 \qquad \|J\|=\max_{i=0,1}N_i(J).
\]

All sums are finite for a finite support library. Applying RI01 termwise and taking the maximum gives rational lower and upper bounds N_L,N_U converging to the exact norm. Negative-coordinate support members change neither the translation count nor this formula. Consolidating duplicate or zero coefficient supports before this calculation is an exact algebraic operation.

**ESTABLISHED.** Let K_a,ell_a,M_a,epsilon denote precisely the admitted constants in the contract. RI01 gives positive K_a lower/upper enclosures and ell_a lower/upper enclosures. Put M_(a,U)=11K_(a,U)/a. Refine until ell_(a,U)<1 for each factor and set

\[
 \epsilon_L=\min_{a\in\{2,3,6\}}
 \left\{1/48,1/(2K_{a,U}),
 (1-\ell_{a,U})/(2M_{a,U})\right\}.
\]

Then 0<epsilon_L<=epsilon, and it converges to epsilon as all enclosure widths vanish. This uses only monotonicity of positive division and continuity of a finite minimum; each denominator has a positive limit. The true ell_a=exp[-kappa(a-1)]/a is strictly below one. For every input with ||J||<epsilon, sufficiently fine bounds satisfy N_U<epsilon_L. Otherwise convergence would contradict the positive gap epsilon-||J||. Selecting r=(N_U+epsilon_L)/2 gives an explicit rational strict working radius with ||J||<=N_U<r<epsilon_L<=epsilon. This admission covers every strict input in the frozen domain with sufficient finite precision; fixing r to half a single coarse lower bound would unnecessarily exclude some admitted inputs and is not the target theorem.

## RI03: full Taylor remainder and finite order selection

**ESTABLISHED.** The admitted homogeneous bound gives, for integer order p>=1, a rational norm upper bound nu>=||J|| and K_U>=K_a with x=K_U nu<1,

\[
 \left\|\mathcal R_aJ-\sum_{n=1}^{p}P_{a,n}(J,\ldots,J)\right\|
 \le\tau_a(p,\nu)
 =\frac{\nu}{a}
 \frac{x^p[(p+1)-px]}{(1-x)^2}.
\]

The exact positive series behind this expression is (nu/a) sum_(n=p+1)^infinity n (K_U nu)^(n-1). Differentiate the geometric tail x^(p+1)/(1-x) term by term inside |x|<1 to obtain the displayed formula. Each summand is nondecreasing in nonnegative nu and K_U. Replacing the true constants by upper bounds is therefore valid even though one displayed numerator term has a minus sign. The denominator is positive. For fixed x<1 the tail tends to zero, so increasing p finds a bound strictly below every positive rational tolerance. For nu=0 the interaction and all its omitted coefficients vanish identically; tau is zero. This tail includes every omitted order, support cardinality and range. It is not merely a bound on a finite list of observed coefficients.

**ESTABLISHED.** A finite-order coefficient routine must equal the whole homogeneous Taylor sum before RI03 can be attached to its output. Partial enumeration, discarding a generated many-body support, or stopping a cumulant recurrence early leaves this premise open. The exact scalar-free coefficient table does not include the constant term of the conditional partition logarithm. Global Gibbs normalization only subtracts a scalar from that logarithm and hence does not alter these nonempty coefficients. Evidence or VFE evaluations still require their own matching scalar and normalized model; the tail certificate is not itself a VFE value.

## RI04: domain-qualified finite-word propagation

**ESTABLISHED.** Fix the rational r from RI02, or any explicitly certified 0<r<epsilon_L. Define rational bounds

\[
 L_a=\ell_{a,U}+2M_{a,U}r<1,
 \qquad q_a=\ell_{a,U}+M_{a,U}r<1.
\]

The strict inequalities follow directly from r<(1-ell_(a,U))/(2M_(a,U)). On the convex closed norm-r ball, the admitted derivative bound gives ||D R_a||<=L_a. Applying the Banach fundamental theorem of calculus along the segment between two admitted points gives ||R_a J-R_a H||<=L_a||J-H||. The value bound gives ||R_a J||<=q_a||J|| there. Every exact factor trajectory from the ball therefore remains in it; all derivative evaluations above occur strictly inside the theorem's open epsilon domain.

**ESTABLISHED.** Let the exact trajectory be J_(j+1)=R_(a_j)J_j and the computed finite interaction be Jhat_(j+1). Suppose ||Jhat_j||<=r, ||Jhat_j-J_j||<=e_j, and a complete Taylor calculation at Jhat_j has certified omitted tail tau_j. Then

\[
 \|\widehat J_{j+1}-J_{j+1}\|
 \le L_{a_j}e_j+\tau_j.
\]

The triangle inequality separates the Taylor error from the Lipschitz image of the input error. The next computed state obeys ||Jhat_(j+1)||<=q_(a_j)||Jhat_j||+tau_j. Checking this upper bound is at most r, or independently proving a tighter actual finite-output norm bound at most r, admits the following step. A certificate must never apply the derivative bound to an intermediate approximate state outside that ball. A complete output table with cancellation may satisfy a stronger directly computed bound than the absolute polynomial majorant; either valid bound can establish the same premise.

**ESTABLISHED.** For a prescribed word of length m>=1 and requested final tolerance t>0, existence of a finite successful calculation follows by choosing every tau_j less than min{t/(m+1),(1-q_(a_j))r/2}. If the input computed norm is at most r, this bounds the next computed norm by (1+q_(a_j))r/2<r. With e_0=0 and every L_a<1, the propagated final error is less than mt/(m+1)<t. Each step's exact finite table remains finite; RI01 can enclose its norm, RI03 can lower its tail by a finite order, and a complete finite coefficient algorithm terminates at that order. Induction over the finite word proves termination with sufficient finite resources. It does not promise a uniform complexity bound or fixed-size supports across the word.

**ESTABLISHED.** Exact two-then-three and three-then-two targets both equal the admitted direct-six operator. Consequently the difference of independently computed tables is bounded by the sum of their respective norm-error certificates. Different polynomial truncation orders or substitutions need not produce identical tables. A direct coefficient equality test would be legitimate only if it compared the same complete total-degree expansion; it is unnecessary for the general finite-amplitude error guarantee. Empty factor words have the identity table and zero propagated error.

## RI05: noncircular use and remaining obligations

**OPEN.** This note does not by itself prove complete coefficient enumeration or any future source's implementation of these inequalities. Those are separately required direct finite-algorithm arguments. A proof checker must trace every returned radius, norm upper bound, tail and iteration admission to the actual source before treating the executable certificate as established. Finite tests are supplemental evidence for that correspondence.

**NOT-CLAIMED.** No new larger-orbit entrance, critical theory, continuum measure or curvature interaction follows. Gauge-holonomy characters can be inputs to the same normalized model. Fisher curvature is the curvature of an identifiable statistical family; contextual-base curvature requires its own metric and connection. A scalar-free truncated interaction and a norm error cannot be substituted for any of those geometric constructions or for a normalized partition/evidence value.
