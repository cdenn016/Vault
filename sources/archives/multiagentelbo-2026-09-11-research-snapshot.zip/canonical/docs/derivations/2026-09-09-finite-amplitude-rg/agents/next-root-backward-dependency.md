<!-- rigorous-theory-search-metadata {"schema_version": "rigorous-theory-search/v1", "contract_id": "contract-sha256-2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c", "target_digest": "2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c"} -->

# A bounded-dependency representation for the next basin bridge

Date: 2026-09-09. **DISCOVERY ONLY; EXCLUDED FROM THE FINITE-AMPLITUDE CERTIFICATE.** This note supplies a different representation to investigate after the endpoint/interior channel construction. It does not establish the missing weighted interaction expansion. The current local operator and its evaluator remain unchanged. No source or experiment is run.

The fine dressed law has h=atanh(b), J=atanh(c), with 0<b<1 and 0<c<1/12. A fine edge e belongs to exactly two plaquettes. Its single-site conditional plus probability, for the products A and B of the other three signs in those plaquettes, is

\[
 p_e(A,B)=\frac{1+\tanh(h+J(A+B))}{2}.
\]

There are six distinct neighboring signs. Put t=tanh(2J)=2c/(1+c^2), p_-=(1+tanh(h-2J))/2 and p_+=(1+tanh(h+2J))/2. The width of the possible conditional-probability interval is exactly

\[
 d=p_+-p_-=\frac{t(1-b^2)}{1-b^2t^2}\le t<2c,
 \qquad 6d<12c<1.
\]

The inequality d<=t follows from 1-b^2<=1-b^2t^2. It covers the full admitted c interval rather than a smaller unreported high-temperature domain.

A uniform mark U at a heat-bath event gives an exact update with a useful dependency test. If U<p_-, the new sign is plus without querying any neighbor. If U>p_+, it is minus without querying any neighbor. Otherwise query the six neighbors immediately before the event, compute A,B, and return plus exactly when U<p_e(A,B). Endpoints are probability-zero events and can receive a fixed convention. This is the original conditional row, not an approximation or an altered dynamics.

Give each fine edge independent rate-one Poisson event times and independent uniform marks. For a finite query of m signs at time zero, explore their most recent events backward. A newly visited event needs no parents with probability 1-d and at most six earlier neighboring events with probability d. Already visited event identities are reused; they do not create new independent variables or extra vertices. Every previously unqueried uniform mark remains independent of the past exploration. The number of distinct events is therefore bounded by a forest with m roots and offspring 6 with probability d, zero otherwise. This is a domination of the exploration count, not a statement that spatial branches in the actual process are independent.

There is an elementary exponential-moment bound for that dominating total progeny. Write f(u)=1-d+du^6. Since f(1)=1 and f'(1)=6d<1, choose u>1 sufficiently near one that f(u)<u, and then choose 1<z<u/f(u). For a depth-truncated one-root forest, induction in its depth gives E z^T<=u from the recursion z f(E z^T_previous)<=z f(u)<u. Monotone convergence gives the same bound for total progeny, including finiteness almost surely. For m independent dominating roots the bound is u^m. The actual shared exploration only reduces the count. Each spatial parent is a plaquette neighbor, so its fine-coordinate displacement is at most one per ancestral step.

These observations give a concrete candidate route for reconstructing the existing unique fine Gibbs law as a finite-query function of independent space-time randomness. A full proof should define the event graph on the countable lattice, prove consistency for overlapping queries and the finite-volume/infinite-volume passage, and identify the heat-bath invariant law with the previously established unique fine Gibbs law. Almost-sure finite ancestry removes arbitrary starting-state dependence, but these consistency and identification steps should be written rather than cited by a name.

The author channel route uses local functions g_p of at most 4B-4 remaining fine signs and an exponentially small Walsh norm in B. For m channel observables, the above crude progeny moment gives u^{m(4B-4)}. Its exponent can be made arbitrarily small by choosing u close to one, since the subcritical margin is strictly positive at fixed b,c. This suggests preserving part of the channel's exponential B-decay while paying for dependency size. It does not yet control the absolute sum of connected channel clusters.

The unresolved step is an all-order connected expansion for

\[
 \log \mathbb E_{\mu_{b,c}}\prod_p(1+y_p g_p).
\]

Real mixing, finite ancestry, and a bound on each total progeny are not by themselves a proof of the needed weighted Walsh interaction norm. The expansion must account for overlaps of explored randomness and multiplicities without spending a second factorial beyond the labeled Taylor or polymer convention. Its absolute connected activity must be summable after weighting retained support cardinality and coarse diameter. The underlying background is the actual fine Gibbs marginal, with every scalar tilt or normalizer retained. A valid cluster construction with these properties would supply a materially new bridge from the physical family to the certified local RG ball; this note leaves that obligation open.
