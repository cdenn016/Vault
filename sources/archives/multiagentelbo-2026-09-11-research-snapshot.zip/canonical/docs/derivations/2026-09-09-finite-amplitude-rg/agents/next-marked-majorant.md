<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c","target_digest":"2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c"} -->

# A resummed channel and Walsh stationarity route to basin entrance

Date: 2026-09-09. **DISCOVERY ONLY; EXCLUDED FROM THE CURRENT CERTIFICATE.** This note develops a candidate global norm majorant for the existing positive-field, 0<c<1/12 orbit. It does not change the finite-amplitude contract, frozen proofs, source or evidence. The overlapping-path calculation was shared-route work. The endpoint elimination and weighted stationarity construction below were developed here before reading the root's new backward-dependency draft; root messages supplied related context and requested the exact normalized channel and all-order boundary checks. No independent-verifier status is claimed. No code, test or scientific producer was run.

The displayed construction does not assume an unproved implication from real mixing to complex analyticity. Its proposed replacement is an explicit contracting operator on a weighted Walsh coefficient algebra. Its constants, spatial count and finite-volume identification require a separate theorem contract and independent reconstruction before any native closure.

## Why the direct marked source count is inadequate

**DIRECT COUNT; INSUFFICIENT MAJORANT.** For n labeled plaquette occurrences connected through B-path or unused-singleton reference blocks and touching a prescribed retained path, a spanning-tree placement bound is

\[
 2B n^{n-1}(8B)^{n-1}.
\]

Choose one of n root occurrences, one of at most 2B plaquettes touching the prescribed path, one of the n^(n-2) labeled trees for n>=2, and one of at most 8B neighbors for every child. The neighbor bound follows from four touched reference blocks, at most B bits per block, and two plaquettes per fine edge. Repetitions are allowed. The tree count follows from the length-(n-2) leaf-deletion code; the n=1 expression is interpreted as 2B. Every surviving output is supported on touched path blocks. Mapping fine anchors by coordinatewise floor division by B shows that the coarse diameter of a connected order-n contribution is at most n: each plaquette has projected diameter at most one, and a common reference block has one projected anchor.

The local correction from next-overlapping-path-cumulants.md still pays

\[
 \prod_{C\ \mathrm{marked}}b^{B-r_C}
 \le b^{\max(0,Bq-4n)},
\]

where q counts distinct marked paths. This allocation is valid with overlaps and repetitions. But bounding an n-cumulant by n! 2^(n-1), dividing by its Taylor n!, and then separately summing the tree placements leaves n^(n-1). The resulting positive series has no useful radius. A tree-sensitive cumulant bound removes that extra factorial but its bare reference-block degree still grows with B. Neither maneuver proves eventual entrance at fixed c. The following elimination resums the long-path dependence before expanding conditional expectations.

## Simultaneous interior elimination and exact support

**DIRECT FINITE CONSTRUCTION.** Let b=tanh(h), c=tanh(J), with h in a fixed compact positive interval and 0<=c<=1/12. Work first with finitely many retained B-paths, B>=3, and a fine volume containing their full interiors and every touching plaquette. Fixed exterior fine signs remain in those factors. On each retained path leave its first and last edges unintegrated; integrate the B-2 other path edges. No plaquette contains two of these interior edges. A plaquette containing one interior retained edge has three remaining edges, all unused by every retained path. Consequently all chosen interior bits are conditionally independent given the remaining fine variables X.

For a horizontal path with fine origin (0,0), its mean parity given X is

\[
 g_p(X)=z_{(0,0,0)}z_{(B-1,0,0)}
 \prod_{r=1}^{B-2}\tanh\bigl(h+J(u_r+v_r)\bigr),
\]

where u_r and v_r are the products of the three other edges in the upper and lower plaquettes incident to (r,0,0). Its exact supporting edge set S_p comprises the two endpoint edges; horizontal edges (r,1,0),(r,-1,0), 1<=r<=B-2; and vertical edges (r,0,1),(r,-1,1), 1<=r<=B-1. Thus |S_p|=4B-4. Rotation and translation give the other paths. All variables in S_p remain unintegrated.

The S_p are pairwise disjoint for B>=3. For a remaining horizontal edge, membership in a horizontal strip uses x mod B in {1,...,B-2} and y mod B in {1,B-1}; membership in a vertical strip uses x mod B in {0,B-1} and y mod B in {1,...,B-1}. These x-residue classes are disjoint, and the residue 1 versus B-1 identifies the neighboring grid line uniquely. Retained endpoint edges belong only to their own strip. The vertical-edge argument is the rotation of this classification. A horizontal S_p lies in the two projected fine cells at p's anchor and one cell below it; a vertical S_p lies in the corresponding cell and one cell to its left. Its projected diameter is at most one.

Let mu be the actual original fine Gibbs law and P a finite retained-path inventory. Conditional independence gives the exact coarse marginal density relative to fair counting,

\[
 p_P(y)=E_\mu\prod_{p\in P}(1+y_p g_p).
\]

One may take expectation under the marginal on remaining variables because every g_p ignores all eliminated interiors. The formula includes the original field and plaquette partition weights through mu; it is not an independent-reference replacement. Averaging over every y_p gives one, so normalization is explicit.

## A full weighted Walsh activity below one

**DIRECT FINITE ALGEBRA.** For two formal signs u,v put f(u,v)=tanh(h+J(u+v)) and t=tanh(2J)=2c/(1+c^2). Its Walsh expansion is

\[
 f=a_0+a_1(u+v)+a_{12}uv,
\]

with a_0>=0, a_1>=0, a_12<=0 and

\[
 a_0-a_{12}=b,\qquad
 2a_1=\frac{t(1-b^2)}{1-b^2t^2},\qquad
 a_{12}=-\frac{b t^2(1-b^2)}{2(1-b^2t^2)}.
\]

These formulas follow by inserting tanh(h+/-2J)=(b+/-t)/(1+/-bt) into the four-point Walsh transform. The exact unweighted coefficient l1 norm is therefore

\[
 R_0=b+\frac{t(1-b^2)}{1-b^2t^2}.
\]

Throughout c<=1/12, t<=24/145. Since 2t/(1-t^2)<=6960/20449, one obtains

\[
 1-R_0
 =(1-b)\left(1-\frac{t(1+b)}{1-b^2t^2}\right)
 \ge\frac{13489}{20449}(1-b).
\]

Choose a rational rho<1 above the compact's maximum b, put Delta=(13489/20449)(1-rho), and choose a positive rational alpha<=Delta/24. For a fine Walsh polynomial F=sum_S F_S chi_S define ||F||_alpha=sum_S |F_S| exp(alpha |S|), including its scalar coefficient. This is a Banach algebra because symmetric difference does not increase total cardinality. Substituting the three-edge characters for u,v gives

\[
 \|f\|_\alpha
 \le a_0+2a_1 e^{3\alpha}+|a_{12}|e^{6\alpha}
 \le e^{6\alpha}(1-\Delta)
 \le\sigma:=1-3\Delta/4<1.
\]

The final inequality follows from exp(x)<=1/(1-x), 0<=x<1, and 6alpha<=Delta/4. Multiplication and the two endpoint characters imply

\[
 \|g_p\|_\alpha
 \le e^{2\alpha}\sigma^{B-2}
 \le G_B:=\frac{\sigma^{B-2}}{1-2\alpha}.
\]

This bound pays the complete fine-variable support and all overlapping character products. It has no source-order factorial. The use of t=2c/(1+c^2) is exact; J=atanh(c) has not been replaced by c in a convergence condition. It covers the entire requested c interval, and even its upper endpoint in this local estimate.

## Retaining the background tilt

**EXACT NORMALIZED IDENTITY.** Once G_B<1, define finite local functions

\[
 u_p=\tfrac12\log(1-g_p^2),\qquad v_p=\operatorname{atanh}(g_p).
\]

Then log(1+y_p g_p)=u_p+y_p v_p exactly. The convergent algebra series give

\[
 \|u_p\|_\alpha\le U_B:=\frac{G_B^2}{2(1-G_B^2)},\qquad
 \|v_p\|_\alpha\le V_B:=\frac{G_B}{1-G_B^2}.
\]

For finite P write U_P=sum_p u_p and V_P(y)=sum_p y_p v_p. With mu_(P,s,y) the normalized fine law obtained from mu by multiplying exp(U_P+s V_P(y)),

\[
 \log p_P(y)
 =\log E_\mu e^{U_P}
 +\int_0^1\sum_{p\in P}E_{\mu_{P,s,y}}[y_p v_p]ds.
\]

The first term is independent of y but is a real normalization contribution. It is not deleted from the fine law inside the integral. This formula already contains the product-field coarse contribution at c=0; adding another atanh(b^B) term would double count it.

## A contracting character-substitution operator

**CANDIDATE GLOBAL CONSTRUCTION WITH DIRECT BOUNDS.** Use the joint coefficient norm

\[
 \|F\|_{\alpha,\beta}
 =\sum_{S,T}|F_{S,T}|e^{\alpha|S|+\beta|T|},
 \qquad \beta=\alpha,
\]

where S labels fine signs and T labels coarse parameter signs y. Character multiplication remains submultiplicative. Each fine edge lies in at most one S_p. The added conditional fine field H_e from U_P+s V_P(y), after deleting that edge from every incident character, consequently obeys

\[
 \|H_e\|_{\alpha,\beta}
 \le U_B+\frac{V_B}{1-\alpha}=:\eta_B.
\]

This intentionally drops the favorable factor exp(-alpha) and bounds exp(beta) by 1/(1-alpha). It is uniform in P, fine exterior, s in [0,1] and all coarse signs.

For eta_B<1/3, the identity tanh H=(exp(2H)-1)/(2+exp(2H)-1) and its norm-convergent inverse series give

\[
 \|\tanh H_e\|_{\alpha,\beta}
 \le W_B:=\frac{\eta_B}{1-3\eta_B}.
\]

If

\[
 W_B\le\frac{1-\sigma}{2(1+\sigma)},
\]

the tanh addition formula applied to the original conditional mean f_e gives the perturbed fine heat-bath mean F_e with

\[
 \|F_e\|_{\alpha,\beta}
 \le\frac{\sigma+W_B}{1-\sigma W_B}
 \le r_0:=\frac{1+\sigma}{2}<1.
\]

All these gates hold for every sufficiently large B because G_B tends to zero. Fixing exterior fine signs or coarse signs only decreases the coefficient norm. No complex Gibbs measure is assumed by these algebraic inverse series.

Let Pi delete all terms with nonempty fine support. Define A on a joint character with S nonempty by

\[
 A(\chi_S y_T)=\frac1{|S|}\sum_{e\in S}\chi_{S\setminus\{e\}}y_T F_e,
\]

and set A=0 on fine-constant characters. For every nonempty S, stationarity of the actual normalized fine Gibbs law gives E(chi_S y_T)=E A(chi_S y_T). The average over S is part of the definition, not a sum of |S| independent choices. Its norm satisfies

\[
 \|A(1-\Pi)\|\le e^{-\alpha}r_0\le r_0.
\]

Put N=(1-Pi)A. For every finite local F, repeated stationarity therefore gives

\[
 E[F]=\Pi F+\sum_{k\ge1}\Pi A N^{k-1}(1-\Pi)F.
\]

The k-th displayed update contribution has norm at most r_0^k ||F||_(alpha,beta). For each real y the unabsorbed expectation after k steps is bounded in absolute value by the same geometric remainder, so the convergent coefficient series equals the actual expectation. Constant fine terms are absorbed rather than updated; this avoids inverting the zero eigenvalue of a Markov generator. The argument uses neither a cumulant partition count nor a pairwise-to-all-orders inference.

The construction also supplies a finite-volume passage. A fixed number of substitutions sees only a finite neighborhood of the initial support. Once a fine volume includes that neighborhood, its coefficients agree with the infinite update rule, including all touching exterior-reduced factors. The remaining terms are uniformly bounded by the geometric tail. Finite-volume Gibbs measures exist by finite normalization; their cylinder expectations are thus Cauchy uniformly in the boundary. Their limits satisfy the local conditional identities and are unique, since the same series fixes every character expectation. For the globally tilted model, its interactions have finite range at each fixed B; the same argument applies to every coarse sign pattern. No ratio conditioned on an infinite zero-probability event is used.

## Connected placement and the full coarse norm

**DIRECT SPATIAL COUNT FOR THE PROPOSED OPERATOR.** Project fine anchors by coordinatewise floor division by B. Each original heat-bath substitution introduces fine coordinates within projected distance one of its updated edge. The added u_p,v_p terms have the same property because S_p has projected diameter one, and their only possible coarse label is p at distance at most one. Starting from y_p v_p, the k-update absorbed term therefore has every coarse label within distance k+1 of p's anchor and has coarse diameter at most 2(k+1). Repeated labels cancel by character multiplication; they are not treated as distinct support members.

Fix a coarse edge e. For a k-update term to contain e, its initial root p must have anchor within k+1 of e's anchor. There are at most 2(2k+3)^2 such oriented roots. This counts the entire placement sum after the update average has supplied its normalization. It does not enumerate spanning trees or spend a Taylor factorial again.

Choose the final interaction cardinality weight kappa=alpha/2 and a positive rational lambda<=(1-r_0)/8. The elementary bound |T| exp(kappa |T|)<=2 exp(beta |T|)/alpha pays the norm's extra cardinality factor. Write

\[
 Q=\frac{r_0}{1-2\lambda}<1,
 \qquad
 S(Q)=\frac{4Q(1+Q)}{(1-Q)^3}
       +\frac{12Q}{(1-Q)^2}+\frac9{1-Q}.
\]

Here S(Q)=sum_(k>=0)(2k+3)^2 Q^k, and r_0 exp(2lambda)<=Q. Applying the placement bound to the interpolated local expectations gives the explicit candidate full-norm majorant

\[
 \boxed{
 \|\Phi_B\|_{\kappa,\lambda}
 \le C_{\alpha,\lambda,r_0}V_B,
 \qquad
 C_{\alpha,\lambda,r_0}
 =\frac{4 S(Q)}{\alpha(1-\alpha)(1-2\lambda)}.
 }
\]

Indeed the unrounded sum is (4/alpha) exp(beta+2lambda) V_B sum_k (2k+3)^2 [r_0 exp(2lambda)]^k. The stated constant bounds both exponential factors by reciprocal rational bounds. The time integral has length one and introduces no extra factor. All roots, both orientations, repeated substitutions and scalar absorptions are included. This is a global summable placement bound with exponential decay in B through V_B, not a finite-window or diameter-only estimate.

The apparent conclusion is entrance of the compact source family into the prior common coefficient ball: kappa,lambda are independent of B; all gates above and C V_B<epsilon(kappa,lambda) hold eventually. The requested fixed 0<c<1/12 can be treated uniformly up to c=1/12 in the displayed algebra constants. No stronger coupling restriction has been inserted. This conclusion remains a discovery proposal pending the separate scrutiny identified below.

## Coefficient representative and law identification to verify in the next contract

**PROPOSED DIRECT IDENTIFICATION.** For finite P, take the complete nonempty Walsh coefficients of the exact log p_P(y), using the interpolation identity. These coefficients are the finite scalar-free interaction, with no choice of marked root and no vacuum-potential conversion. The displayed majorant is uniform in P. In each fixed number of substitutions only a bounded set of roots and nearby path labels can contribute to a coefficient incident to e. Exhausting P therefore gives convergence of every local incident coefficient sum; the remaining substitution orders are uniformly controlled by the same convergent S(Q) tail. Coarse translations preserve the construction, so the limit is translation invariant.

The finite probabilities are the actual consistent marginals of the original pushed law. Their nonempty Walsh coefficients define exact finite-volume conditional odds. Local incident convergence makes those odds converge uniformly, so the pushed law satisfies the limiting DLR specification. The infinite sum of incident coefficients is absolutely convergent. For any edge e its half-log-odds is sum_(T contains e) Phi_B(T) chi_(T without e); hence Fourier extraction recovers the same coefficient from each possible marked edge. The finite conditional square identities pass to the limit. This is the required consistency route, rather than assuming that a previous vacuum representative already has the new norm.

For sufficiently large B the proposed norm bound lies inside the admitted prior small ball, where its Gibbs law is unique. The existing exact coarse specification is continuous and the pushed law has full cylinder support. Equality almost surely then extends to every exterior. Finite scalar partition shifts remain in the normalized identities above; no VFE value is manufactured from the coefficient bound.

**NEXT-CONTRACT CHECKS, NOT CURRENT CLOSURE.** Independently reconstruct the disjoint-strip residue proof, the two-field Walsh signs and rational slack; check the joint algebra and the conditional-field extraction when a generated term loses an edge; verify the absorbing operator's norm on infinite coefficient inventories and the finite-boundary stabilization count; and check the local incident limit and full conditional-square argument against the exact source family. A tiny future implementation should separately realize the normalized interior channel, its u/v decomposition and the first few substitution terms, including repeated coarse labels and boundary substitutions. No such implementation or experiment is authorized by this discovery note. If one of these steps fails, preserve that precise failure rather than replacing the operator with an unproved cumulant theorem.

## Primary-source screening and scope

**SOURCE CONTEXT ONLY.** Yin's [cluster-expansion treatment](https://arxiv.org/pdf/0911.0117), Sections 1-3 through the proof of Proposition 3.2 and Lemmas 3.3-3.5, was read to check the unresummed route. Its small-norm hypothesis and explicit block-cardinality cost do not supply this compact-field, increasing-B entrance. Its conditional reference normalization also has to be changed when biased parity outcomes are used. No theorem from that paper is imported into the weighted stationarity argument.

**NOT-CLAIMED.** The candidate bound is not added to the current certificate or presented as an independently verified theorem. It supplies no universality, critical or continuum limit, physical clock, or automatic curvature contribution to VFE. Gauge holonomy, parameter Fisher geometry and contextual-base curvature retain their separate normalized-model meanings. The full RG program is not declared complete.
