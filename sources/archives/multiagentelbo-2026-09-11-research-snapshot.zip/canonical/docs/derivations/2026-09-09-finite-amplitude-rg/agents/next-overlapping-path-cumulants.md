<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c","target_digest":"2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c"} -->

# Overlapping character cumulants on one biased parity path

Date: 2026-09-09. **DISCOVERY/OPEN, EXCLUDED FROM THE CURRENT CERTIFICATE.** This is a bounded continuation of next-basin-entrance.md. The root supplied the conditional-moment telescope and ordered-partition candidate; the author checked and developed that shared route below. This is not an independent reconstruction or a native claim closure. Current finite-amplitude source, proofs and evidence remain unchanged. No repository import, test, science, producer or external theorem is used.

## Exact conditional moments, with overlap and repetition

**DEFINITION.** Let Z_1,...,Z_B be independent signs with E_0 Z_e=b, where B>=1 and 0<b<1. Put W=product_e Z_e and let E_y denote expectation conditioned on W=y, for either y in {-1,+1}. The event has probability (1+y b^B)/2>0. Fix n>=1 labeled character occurrences X_i=chi_(A_i), with arbitrary subsets A_i of the B bits. The subsets may overlap, repeat or be empty. Write r=|union_i A_i|. For a label subset I, put D_I=the symmetric difference of A_i over i in I, and d_I=|D_I|. In particular d_I<=r, even with repetitions.

**DIRECT FINITE DERIVATION.** The identity 1_(W=y)=(1+yW)/2 and character multiplication give

\[
 m_y(I)=E_y\prod_{i\in I}X_i
 =\frac{b^{d_I}+y b^{B-d_I}}{1+y b^B},
 \qquad
 m_0(I)=b^{d_I}.
\]

Consequently

\[
 m_y(I)-m_0(I)
 =\frac{y b^{B-d_I}(1-b^{2d_I})}{1+y b^B},
 \qquad
 |m_y(I)-m_0(I)|
 \le \varepsilon_{B,r}:=\frac{b^{B-r}}{1-b^B}.
\]

Here 0<=d_I<=r and 0<b<1 imply b^(B-d_I)<=b^(B-r). Both moments are expectations of signs, so each has absolute value at most one. If D_I is empty, both moments equal one and their difference is exactly zero. This includes I empty and any nonempty subset whose repeated or overlapping supports cancel. No independence among the X_i is assumed.

## The complete cumulant difference

**DIRECT FINITE DERIVATION.** Define the n-variable joint cumulant by the finite moment-partition formula

\[
 \kappa_y(X_1,\ldots,X_n)
 =\sum_{\pi\in\mathcal P_n}
 (-1)^{|\pi|-1}(|\pi|-1)!
 \prod_{C\in\pi}m_y(C),
\]

and define kappa_0 by the same formula using m_0. This formula is the mixed coefficient of the logarithm of the finite moment generating function near zero; expanding the formal logarithm and collecting partitions supplies it without a probabilistic limit theorem.

For a partition with k blocks, order its blocks in any fixed manner and telescope the two products one factor at a time. Every unchanged factor has absolute value at most one. Thus

\[
 \left|\prod_{C\in\pi}m_y(C)-\prod_{C\in\pi}m_0(C)\right|
 \le\sum_{C\in\pi}|m_y(C)-m_0(C)|
 \le k\varepsilon_{B,r}.
\]

Taking absolute values after this identity, rather than replacing cumulants by pairwise covariances, gives the sharper finite combinatorial constant

\[
 |\kappa_y-\kappa_0|
 \le F_n\varepsilon_{B,r},
 \qquad
 F_n=\sum_{k=1}^n k! S(n,k),
\]

where S(n,k) counts the partitions of n labels into k nonempty blocks. F_n counts ordered set partitions. Encode each ordered partition by sorting the labels within each block, concatenating those blocks into a permutation, and recording the cuts. The original ordered blocks are recovered uniquely from that encoding. There are n! permutations and 2^(n-1) cut patterns, so this is an injection into a set of size n! 2^(n-1). Therefore the proposed bound is valid:

\[
 \boxed{
 |\kappa_y(X_1,\ldots,X_n)-\kappa_0(X_1,\ldots,X_n)|
 \le n!2^{n-1}\frac{b^{B-r}}{1-b^B}.
 }
\]

It is a difference bound relative to the unconditioned biased product law. It is not a bound asserting that the conditional cumulant itself is small. Overlapping characters can already have order-one unconditioned cumulants.

**BOUNDARY CASES.** For n=1 the exact difference is the displayed moment difference and F_1=1. If its support is empty, it vanishes. If all supports are empty, r=0 and the cumulant difference vanishes at every n; the positive general upper bound need not be sharp. For r=B the upper bound remains finite for b<1 but supplies no decay with B. For example X_1=W has conditional mean y, so its difference from b^B is y-b^B. For two repeated full-path occurrences, X_1=X_2=W, the conditional variance is zero while the unconditioned variance is 1-b^(2B). Their cumulant difference is therefore -(1-b^(2B)), although the total XOR is empty. This example refutes replacing r by the total-XOR cardinality.

The endpoint b=0 is not needed for the positive-field compact target. It nevertheless has a direct interpretation without ambiguous powers: for a proper nonempty D, both moments are zero; for D empty, both are one; for D the full path, the conditional moment is y and the unconditioned one is zero. If r<B, the entire joint moment arrays agree and the cumulant difference is zero. If r=B, the same partition proof bounds it by F_n. At b=1, the negative-parity event is null and the stated two-parity theorem is inapplicable.

For a compact positive-field interval, take b<=rho<1. Uniformly in both parity signs, all overlaps and all repetitions,

\[
 |\kappa_y-\kappa_0|
 \le n!2^{n-1}\frac{\rho^{B-r}}{1-\rho^B}
 \le\frac{n!2^{n-1}}{1-\rho}\rho^{B-r}.
\]

These are full B-bit reference statements. They do not assert the same B-dependent suppression after arbitrary fine boundary conditions fix part of the path. A future finite-volume construction must retain complete reference path blocks or explicitly derive the changed conditional reference.

## Exact finite product-cumulant placement of the marked correction

**DIRECT FINITE ALGEBRA; GLOBAL SUMMABILITY OPEN.** Consider a finite list of plaquette character occurrences under the product of the conditioned retained-path references and the unconditioned biased unused singletons. Factor source occurrence i into its nonempty components V_(i,p)=chi_(A_i intersect p), one per touched reference block p. Let Lambda be the set of these component labels and let the row partition collect labels belonging to each source occurrence. A partition sigma of Lambda is connected relative to the rows when the equivalence relation generated jointly by sigma and the rows has one class.

The following finite identity supplies the correct connection structure:

\[
 \kappa\left(\prod_p V_{1,p},\ldots,\prod_p V_{n,p}\right)
 =\sum_{\substack{\sigma\in\mathcal P(\Lambda)\\
                    \sigma\vee\mathrm{rows}=1}}
   \prod_{C\in\sigma}\kappa(V_\ell:\ell\in C).
\]

To derive it, expand the source cumulant by its row partitions and expand each resulting component moment into its component cumulants. For a fixed component partition sigma, let q be the number of equivalence classes it induces on the rows. Its coefficient is the sum of (-1)^(k-1)(k-1)! over partitions of those q classes into k blocks. That sum is one for q=1 and zero for q>1, as follows by taking the degree-q coefficient in the formal identity log(exp(t))=t. This yields exactly the displayed connected-partition restriction. Reference blocks are independent, so a component cumulant containing labels from different reference blocks is zero; one can retain only monochromatic sigma blocks. Every source occurrence remains labeled, including repeated plaquettes, so no repetition is silently removed by this identity.

For each retained-path block C in such a sigma, decompose its local cumulant as kappa_(0,C)+Delta_(y,C). Unused-singleton cumulants have no correction. The present lemma bounds Delta_(y,C) with n replaced by |C| and r replaced by r_C, the union of its distinct path bits. Expanding the finite product over these choices marks exactly those local blocks where Delta is selected. Terms with no marks have no parity dependence; in the conditional log partition they contribute only a scalar. This does not remove the separate biased-product coarse field: its exact coefficient is atanh(b^B), coming from the product parity reference before adding plaquette factors.

For any real function f of one parity sign, its two Walsh coefficients satisfy

\[
 |\widehat f(\varnothing)|+|\widehat f(\{p\})|
 =\max(|f(+1)|,|f(-1)|).
\]

Indeed the coefficients are half the sum and difference of the two values. The correction bound therefore also bounds its full one-variable coefficient l1 norm. Multiplication convolves Walsh coefficients, so its l1 norm is submultiplicative, including when several corrections use the same path. A term's nonconstant output support can contain only distinct marked paths. This supplies a coefficient bound for each fixed marked term, not a convergent sum of all such terms.

**DIRECT INCIDENCE BOOKKEEPING.** If n plaquette occurrences are present, their total number of fine-edge occurrences is 4n. Since sigma partitions component labels, even overlapping or repeated physical edges obey

\[
 \sum_{C\ \mathrm{marked}}r_C
 \le\sum_{(i,p)\in\Lambda}|A_i\cap p|
 =4n.
\]

If m local blocks are marked and q distinct paths carry those marks, then m>=q and all B-r_C are nonnegative. Hence

\[
 \prod_{C\ \mathrm{marked}}b^{B-r_C}
 \le b^{\max(0,Bq-4n)}.
\]

In particular q is at least the cardinality of any nonconstant output character appearing in the term. This allocation counts repeated edge uses as separate source incidences and never spends one occurrence twice merely because its bit participates in overlapping characters. It retains one activation per local marked block; it does not replace that block by a tree of pairwise weak links. The remaining local factorial and denominator factors must still be included in every global sum.

## What is still required for the larger basin

**OPEN.** The identity just proved applies directly to the formal exponential source expansion, whose order-n coefficient has the usual 1/n! cumulant factor. The target plaquette activity is c=tanh(J); a proof using factors 1+c chi_p instead must derive its own collection multiplicities, or account exactly for J=atanh(c) and the scalar cosh factors. Interchanging J and c inside a convergence condition is not permitted. These finite identities alone establish neither convergence of the J expansion throughout 0<c<1/12 nor uniform convergence of a reorganized c expansion.

The missing theorem must sum all connected marked component partitions, translated plaquette occurrences and generated supports with the cardinality and diameter weights of one common interaction norm. It must control the local |C|! 2^(|C|-1) factors and denominators without introducing an extra factorial after the Taylor divisor has been spent. It must combine the coverage suppression with small activity when 4n is comparable to or larger than Bq, preserve the real normalized coarse specification for every parity exterior through finite-volume limits, and identify the complete consolidated representative. The incidence estimate removes one bookkeeping ambiguity; it does not pay those global multiplicities or spatial placements.

A generic lattice-animal or absolute-cumulant bound may impose a smaller coupling threshold than 1/12. That would be a partial theorem with a changed domain, not proof of the requested full interval. One possible next construction resums the ordinary unmarked fine clusters before treating marked corrections, but it needs a proved all-orders response or connected activity bound for that background. The earlier real comparison and diameter decay do not automatically supply that bound. A violation of the finite moment or partition formulas would falsify this local route; divergence of a crude majorant alone would not refute entrance of the actual orbit.

**NOT-CLAIMED.** No full-basin entrance, new native theorem closure, numerical validation, efficiency bound, continuum limit or physical clock is supplied. Gauge holonomy, Fisher curvature and contextual-base curvature remain distinct normalized model structures. This discovery adds no automatic curvature penalty to VFE and changes none of the current finite-amplitude release claims.
