<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c","target_digest":"2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c"} -->

# Independent final finite-amplitude coverage

Date: 2026-09-09. This record covers the exact 29 selected proposals and lowercase target. It assigns no ledger state. The conditional derivations are in the immutable initial reconstruction and the mature MA01-MA08 report; this file maps each claim individually to its actual evidence, dependency list, attack and response. Every proof label below is literal text rather than a path basename. Root's later native acceptance is a separate act.

The initial Markdown and JSON were frozen before current counterpart access at 7e417bb7fa59dcfc31d4e26b57e887c297db3c7f69870bb8cf2d997883635a58 and 4b251f71b025c7c24a1e6b59bd32289c5c32dbdad052055de91af933921ca748. They remain unchanged. The initial construction used ordered occurrences in a whole-source catalog; later comparison read the author's literal-anchor catalog, root enclosures, complete connected-growth source and its final tests/runner, then the retained raw evidence and final reports. Shared model family, prior context and filesystem limit independence. Agreement is not evidence.

The raw packet contains 35 distinct JUnit cases, no failures/errors/skips, suite time 0.100 seconds, runner elapsed 0.7094186000758782 seconds and exit zero. All 26 source/config/premise receipt hashes plus runner and contract match. This lane read saved artifacts only; it did not import scientific source or rerun tests. Source-injected Python 3.12.7 compatibility is distinct from the unchanged package >=3.14 requirement and the unexecuted neighborhood CUDA route. Tiny finite-fiber comparisons include actual normalizers and check retained-coefficient consequences; the full weighted-norm bound comes from proof.

Root's preventive logarithm representation finding was sustained and repaired before the only packet by outward positive dyadic input enclosures, preserving the old guard and finite model. No observed failed packet or retry is asserted. The scalar-convention clarification in MA05/MA08 preserves the initial bytes and does not manufacture an evidence/VFE value. The final reports retain all these limits. Next-* discovery notes, larger-orbit entrance, critical/continuum behavior and physical/geometric identifications remain outside this review and are not certified.

## Individual coverage

### FA01

Dependencies: none.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA01 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA01; MA01.

Attack: An orbit may be counted once rather than once per matching-axis edge, or canonicalization could quotient rotations.

Response: Subtracting the actual lexicographically first edge origin gives a unique translation representative, including negative second coordinates. Finite nonempty supports have no nonzero translation stabilizer. Aligning each orientation-i member with the root gives exactly n_i copies; summing their |S| weights and taking the maximum over axes proves the exact norm. Coefficients consolidate before absolute values.

Falsifier: Two distinct canonical shapes represent the same translation orbit or the incident translate count differs from n_(i,j).

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA02

Dependencies: none.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA02 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA02; MA01; MA06.

Attack: Truncation toward zero or an untyped unused owner may change a negative-coordinate blocking phase.

Response: Transverse divisibility decides retained ownership, and parallel floor division gives the unique path block. Source _owner uses these operations and a separate unused kind. _block reconstructs the full path, not only touched edges. Both axes remain literal.

Falsifier: An edge is assigned to the wrong retained path or an unused singleton is merged with another block.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA03

Dependencies: FA02.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA02 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA02; MA01; MA06.

Attack: A count-a owner group may contain repeated edges or the empty set may be confused with an invalid partial path.

Response: The input XOR is a set of distinct edges; a retained owner has exactly a possible edges, so a distinct count of a means that full path. Any unused survivor invalidates the image. Empty XOR is a valid empty tuple, different from None; source moments use is not None.

Falsifier: A passing owner-count test differs from the literal union of complete paths, or the empty support is mishandled.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA04

Dependencies: FA03.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA03 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA02; MA01.

Attack: Partition products may yield different retained characters or miss conditional dependence on untouched path signs.

Response: Fair completion includes the whole path and all unused singletons. Proper path subsets and unused survivors average to zero. Every surviving partition product has the common total-XOR character. Its all-plus coefficient is an integer sum of zero-one moment products with signed factorial weights.

Falsifier: A proper path subset or occupied unused sign has nonzero reference moment, or surviving partition terms have different total characters.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA05

Dependencies: FA04.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA03 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA02; MA01; MA06.

Attack: The subset recurrence may omit repeated labels or use a full submask before its cumulant is known.

Response: Partitioning a moment expansion by the block containing its least label gives m(I)=sum c(B)m(I without B). Isolating B=I proves the recurrence. Occurrences retain separate labels. Proper submasks are smaller and available first. Summing the subset-pair count gives (3^n-1)/2 before excluding the full blocks, below 3^n.

Falsifier: The partition block containing the distinguished label is not uniquely accounted for or the recurrence omits a repeated occurrence.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA06

Dependencies: FA02, FA04.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA04 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA02; MA01.

Attack: Fine-edge adjacency could falsely classify two sources on the same parity block as independent.

Response: The occurrence graph joins sharing of an entire reference block, including repeated literal sources. Distinct graph components depend on disjoint independent conditional-reference coordinates, so their mixed cumulant vanishes. The two-singleton path example directly falsifies the narrower fine-edge graph.

Falsifier: Disconnected occurrence groups fail independence under the factorized reference, or a source pair sharing only a reference block is discarded.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA07

Dependencies: FA02, FA06.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA04 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA03; MA01.

Attack: The finite catalog may miss a distant or negatively anchored translated source contributing to a canonical output.

Response: The first output edge supplies a fine edge at the origin belonging to some occurrence. A simple occurrence-graph path reaches any source with at most n internal diameter costs and n-1 block joins of length a-1. Every source edge, hence its actual canonical anchor, lies in the radius R_n box. Both orientations obey the same bound.

Falsifier: A valid contributing connected tuple has a literal source anchor outside the stated finite box, including a negative-coordinate or mixed-axis case.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA08

Dependencies: FA04.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA05 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA04; MA02; MA06.

Attack: A multiset weight may retain 1/n! or count shape multiplicities rather than literal-instance multiplicities.

Response: There are n!/product m_tau! ordered realizations of each literal multiset. Symmetry makes their contributions identical; division by the admitted n! leaves exactly product m_tau! in the denominator. No root/tree/history factor enters. Source Counter keys include orbit and both translation coordinates.

Falsifier: The weight disagrees with its n!/product m_tau! ordered occurrence realizations and the admitted 1/n! Taylor factor.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA09

Dependencies: FA01, FA03, FA05, FA06, FA07, FA08.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA05 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA03-IA04; MA01-MA02.

Attack: Canonicalizing every emitted translated support and summing it may multiply one coefficient by its incidence count.

Response: The radius catalog contains every nonzero connected contribution. The output must already have the pass root as its literal first edge; it is not shifted before accumulation. The two axis passes are disjoint at emission. Exact multiset weights recover the full ordered formula, so every nonempty many-body coefficient and fine phase is included once.

Falsifier: A nonzero admitted Taylor contribution is omitted, repeated through roots/trees/translation, or assigned to the wrong output orbit.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA10

Dependencies: FA07.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA06 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA03-IA04; MA01.

Attack: Generated support size or diameter may be silently truncated to a pairwise or short-range ansatz.

Response: The XOR contains exactly a fine edges for each retained output edge, giving a|T|<=n s_max. Connecting two output first fine edges through the occurrence tree gives a diam(T)<=n d_max+(a-1)(n-1). These are derived bounds, not candidate-pruning rules; no additional support truncation is admitted.

Falsifier: A surviving full-path character violates the XOR coverage or reference-block tree distance bound.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA11

Dependencies: FA05, FA07, FA09, FA10.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA06 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA05; MA01-MA02.

Attack: A finite-order routine may be called complete despite an unfinished catalog, or a finite work bound may be presented as a practical runtime promise.

Response: The catalog has L(2R_n+1)^2 instances and finitely many size-n multisets. Each finite occurrence subset recurrence, factorial and rational operation has finite size. This proves finite termination with sufficient resources, without a uniform efficiency bound. A partially traversed order cannot use the complete-order tail.

Falsifier: The finite catalog contains infinitely many literal instances, the multiset count omits candidates, or completion is asserted after a partial-order budget stop.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA12

Dependencies: FA09.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA07 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA07; MA04; MA06.

Attack: A tail may cover only observed output supports or use an inward constant substitution because its closed numerator has subtraction.

Response: Summing the admitted positive majorant gives (nu/a)x^p[(p+1)-px]/(1-x)^2. The positive-series form proves monotonicity in nu and K_U; x<1 makes the denominator positive. It covers every omitted order, range and cardinality. Its polynomial-geometric factor tends to zero, with zero input treated exactly.

Falsifier: The positive omitted-order sum differs from the stated formula or the implemented upper values do not dominate the full operator tail.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA13

Dependencies: FA11, FA12, CB01, CB03.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA07 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA06-IA09; MA03-MA04.

Attack: An input near the true radius may never pass a fixed smaller threshold, or a finite error order may not admit its output for iteration.

Response: Convergent norm/constant enclosures eventually resolve every strictly positive input-radius gap. The full tail tends to zero and each selected order has finite enumeration. Exact radial contraction gives a strict output margin, eventually also respected by the polynomial and its enclosure. Fixed budget failures remain incomplete.

Falsifier: The tail fails to tend to zero, the exact radial margin is absent, or a bounded unresolved computation is presented as the unbounded-resource completion theorem.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FA14

Dependencies: FA09.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA08 in agents/finite-amplitude-construction.md.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA10; MA05; MA07.

Attack: A zero retained table could be used to infer the original fine partition is one, or arbitrary finite scalar shifts could be compared through the coefficient norm.

Response: The table omits scalar gauge and has no rooted scalar enumeration. An unused fine field can have a nontrivial cosh partition and zero retained table. A newly declared finite Hamiltonian/window/reference can define its own partition, but that is extra data and calculation, not recovery of discarded fine evidence. Finite norm stability compares the same scalar convention or retains matching scalar/partition cancellation.

Falsifier: A zero scalar-free output forces the unchanged fine normalizer to equal one, contrary to the unused-bit cosh control.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### CB01

Dependencies: none.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/root-certified-bounds.md :: RI01.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA06; MA03; MA06.

Attack: The geometric remainder may start one term late, reverse the reciprocal endpoints incorrectly, or never converge.

Response: After degree m, the first omitted term is m+1 and every subsequent ratio is bounded by x/(m+2)<1. The rational geometric tail is outward and tends to zero by eventual ratio decrease. Negative exponential endpoints are positive reciprocals in reversed order. Increasing the finite degree resolves every requested positive width with sufficient arithmetic resources.

Falsifier: A Taylor/geometric endpoint fails to enclose the exponential, or its width does not tend to zero for a fixed finite argument.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### CB03

Dependencies: CB01, FA01.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/root-certified-bounds.md :: RI02 and RI04.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA06; MA03; MA06.

Attack: A safe enclosure radius may permanently exclude some strictly admitted input or fail to bound derivative constants.

Response: The upper K and ell produce a lower epsilon converging to the original epsilon. Once N_U<epsilon_L, the midpoint r lies strictly between them. It is below every (1-ell_U)/(2M_U), so the Lipschitz and radial constants are strictly less than one. No fixed half-ball is imposed; unresolved bounded precision gives no admission.

Falsifier: An exact strict input remains unadmittable at every finite enclosure refinement or a successful radius/constant inequality is not outward safe.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### CB05

Dependencies: CB03, FA12, FA11, FA13.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/root-certified-bounds.md :: RI04.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA08-IA09; MA04; MA06.

Attack: Accumulated error may be ignored or a derivative estimate applied outside the certified domain.

Response: On the common convex radius-r ball, derivative integration gives L_a and the value bound gives q_a. Thus e_next<=L_a e+tau and norm_next<=q_a nu+tau. Choosing each tail below the tolerance share and radial margin preserves the next domain and yields final error below the request. Each actual current table/norm is used. Exact composition bounds differences of unequal approximate tables rather than forcing equality.

Falsifier: A stage applies the Lipschitz bound outside the ball, omits the accumulated input error, cannot meet the positive per-step margin with sufficient resources, or claims equality of differently truncated tables from exact-map composition.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FG01

Dependencies: FA01, FA02.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/interface-proof.md :: FG01 and Actual source interface readback.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA02; MA02; MA06.

Attack: The neighbor generator could omit block-sharing sources that share no present fine edge or merge phases while deduplicating.

Response: Expand every touched owner into all a path edges or its one unused edge. Align every matching-axis source member to each expanded edge. Every adjacent literal source has such a witness, and every witness creates an adjacent source. Literal (orbit,dx,dy) keys preserve phases and axes. The same alignment gives exact root seeds.

Falsifier: An adjacent source lacks a witness alignment, an owner expands incorrectly, or a deduplication changes a literal phase or orientation.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FG02

Dependencies: FG01.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/interface-proof.md :: FG02 and Actual source interface readback.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA04; MA02; MA06.

Attack: A minimum-ID continuation rule, translation-normalized frontier or set of supports could delete a needed connected multiset.

Response: A parent-before-child spanning-tree order reaches every connected root-containing occurrence multiset, including repeats. Sorting preserves repeated literal IDs and removes only discovery histories. Future neighbors depend only on the multiset touched blocks, so deduplication preserves continuation. The source imposes neither minimum-ID growth nor frontier translation.

Falsifier: A connected rooted multiset lacks a parent-before-child growth order, repeated occurrences disappear, or a canonical shift or minimum-ID restriction deletes a required continuation.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FG03

Dependencies: FG02, FA03, FA04, FA05, FA06, FA07, FA08, FA09, FG04.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/interface-proof.md :: FG03 and Actual source interface readback.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA04; MA02; MA06.

Attack: A scalar, partial, noncanonical or zero-cumulant intermediate could be discarded before it regenerates an output.

Response: The actual extension block is outside every emission conditional. All rooted connected frontiers survive for the next degree. Emission alone checks the nonempty canonical first edge and uses the exact cumulant/multiplicity weight. Complete growth plus that disjoint output selection equals the whole Taylor polynomial; no discovery/root/tree multiplier remains.

Falsifier: An emission filter prunes a future frontier, a contributing connected multiset is omitted, or one translated/multiset Taylor contribution receives an incorrect multiplicity.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FG04

Dependencies: FA04, FA05, FA08.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/interface-proof.md :: FG04 and Actual source interface readback.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA02; MA01; MA06.

Attack: The integer mask recurrence may collapse equal source values, set the empty moment to zero or traverse improper submasks.

Response: Every occurrence has one bit. Removing the least bit gives an already known XOR, and _image is not None admits the empty image as moment one. The decreasing proper submask loop selects exactly those containing the least bit; their cumulants and complementary moments were already assigned. It implements the proved distinguished-label recurrence.

Falsifier: The proper distinguished submasks are not counted exactly once, an empty XOR has moment zero, or repeated source occurrences share a mask bit.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FG05

Dependencies: FA07, FA11, FG01, FG02, FG03, FG04.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/interface-proof.md :: FG05 and Actual source interface readback.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA03-IA05; MA02; MA05-MA06.

Attack: A growth frontier may escape the finite catalog, a hidden hard resource ceiling may remain, or an exhausted run may expose a success certificate.

Response: Every grown cluster is connected and retains a root-containing occurrence, so the same radius proof bounds it even when it emits no coefficient. Each frontier and neighbor inventory is finite. All four budgets are caller-increasable; the source returns no final table/error certificate on declared ResourceExhausted. Instrumented work and result-size guards are not a preallocation-memory or wall-clock guarantee.

Falsifier: A reachable finite-order frontier lies outside every bounded rooted catalog, a fixed universal ceiling remains when caller limits grow, or incomplete growth returns a completed polynomial or final certificate.

Reconstruction result: Direct derivation reconstructed under the stated premises; no unresolved defect found and no ledger state assigned.

### FAI01

Dependencies: FA01, FA02, FA03.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation.md :: FAI01.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA01-IA02; MA06; MA08.

Attack: Canonical translation or negative-coordinate ownership could differ from the mathematical orbit/reference convention.

Response: _canonical subtracts the actual first edge anchor and consolidates exact orbit coefficients; _owner uses divisibility plus floor division, and _image requires all distinct edges of every retained owner with no unused survivor. This is the IA01-IA02 and MA06 source recurrence on every admitted finite input.

Falsifier: Translation-equivalent supports remain duplicated, axes are identified, negative-coordinate blocks use truncation toward zero, or a partial/unused reference block survives as a complete path.

Reconstruction result: Direct finite source-to-recurrence derivation reconstructed under the explicit input, arithmetic, completion and inherited-operator premises; no unresolved defect found and no ledger state assigned.

### FAI02

Dependencies: FAI01, FG01, FG02, FG03.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation.md :: FAI02.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA03-IA04; MA02; MA06; MA08.

Attack: An emission rejection could also prune a needed later frontier, or deduplicating discovery histories could erase genuine phases/repetitions.

Response: The extension branch is outside every emission test. It expands all touched owners, appends every meeting literal instance including existing ones, and deduplicates sorted literal multisets without translating them. A spanning-tree order rooted at a source containing the first fine output edge reaches every contributing multiset; first-edge equality selects one orbit representative.

Falsifier: A connected contributing literal multiset cannot be reached, an intermediate emission filter prunes a later surviving cluster, blocking phase is normalized away, or repeated discoveries alter the coefficient weight.

Reconstruction result: Direct finite source-to-recurrence derivation reconstructed under the explicit input, arithmetic, completion and inherited-operator premises; no unresolved defect found and no ledger state assigned.

### FAI03

Dependencies: FAI01, FAI02, FG04, FA08, FA09.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation.md :: FAI03.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA02-IA05; MA01-MA02; MA06; MA08.

Attack: Repeated literal values could be collapsed before the labeled recurrence, or a shape-count factorial could replace the literal multiplicity divisor.

Response: Every occurrence has its own mask bit. Separating the partition block containing the least label proves the proper-submask recurrence. Counter uses literal source instances and supplies product(m_tau!), exactly canceling ordered multiplicity against 1/n!. All completed degrees and output supports are added exactly before zero deletion. A caught resource exception returns no completed Taylor table.

Falsifier: A labeled partition contribution, repetition factorial or generated many-body support is omitted/multiplied, or an incomplete polynomial receives complete=True.

Reconstruction result: Direct finite source-to-recurrence derivation reconstructed under the explicit input, arithmetic, completion and inherited-operator premises; no unresolved defect found and no ledger state assigned.

### FAI04

Dependencies: FAI01, CB01, CB03.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation.md :: FAI04.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA01; IA06; MA03; MA06; MA08.

Attack: A fixed half-radius, inward reciprocal, wrong incidence count or hidden immutable precision ceiling could invalidate the claimed full strict domain.

Response: Positive exponential tails and swapped reciprocal endpoints enclose all constants and both orientation sums. All four declared budgets are caller-increasable. For every strict input, convergent endpoints eventually yield N_U<epsilon_L; their midpoint is strictly interior. The source uses that actual midpoint, not a half-radius admission restriction. Fixed-budget failure means incomplete rather than proof of exclusion.

Falsifier: An exponential or norm endpoint excludes its true value, a returned strict radius exceeds the admitted radius, or a fixed hidden precision/bit ceiling prevents the claimed sufficiently-large-resources route.

Reconstruction result: Direct finite source-to-recurrence derivation reconstructed under the explicit input, arithmetic, completion and inherited-operator premises; no unresolved defect found and no ledger state assigned.

### FAI05

Dependencies: FAI03, FAI04, FA12.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation.md :: FAI05.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA07; MA04; MA06-MA08.

Attack: A small selected coefficient discrepancy could be mistaken for a full-norm bound, or a tail attached to an unfinished coefficient order.

Response: The tail is the exact closed form of (nu/a) times the sum of n*x^(n-1) for all n>p. Positive summands justify upper-parameter substitution and account for every omitted support and range through the admitted homogeneous norm theorem. evaluate_rg delegates to the word path, which completes _taylor through p before exposing the certificate. Selected numerical coefficient checks remain separate.

Falsifier: The tail omits a degree/support class, underbounds the positive series, or is attached to a partial enumeration or an unadmitted input.

Reconstruction result: Direct finite source-to-recurrence derivation reconstructed under the explicit input, arithmetic, completion and inherited-operator premises; no unresolved defect found and no ledger state assigned.

### FAI06

Dependencies: FAI04, FAI05, CB05, FG05.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation.md :: FAI06.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: IA08-IA09; MA04; MA06; MA08.

Attack: An approximation could leave the common ball, while an inherited contraction estimate or prefix result is still presented as the requested full-word certificate.

Response: The implementation checks nu<r, L<1 and q<1, selects tails strictly below the allocated error and radial margin, then records next_nu=q*nu+tail and next_error=L*error+tail. Radial contraction keeps the exact path inside the same convex ball. Final success requires error<tolerance. Resource exhaustion sets certified=False with no final table/error, although completed prefix records may remain. No total-memory or wall-time bound is asserted.

Falsifier: A Lipschitz step is applied outside the admitted ball, the propagated error is understated, or a budget-exhausted/full-word-incomplete outcome carries a successful requested certificate.

Reconstruction result: Direct finite source-to-recurrence derivation reconstructed under the explicit input, arithmetic, completion and inherited-operator premises; no unresolved defect found and no ledger state assigned.

### FIN01

Dependencies: FAI01, FAI02, FAI03, FAI04, FAI05, FAI06.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation.md :: FIN01.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md and docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: MA07-MA08.

Attack: Predicted cases, duplicate names, elapsed progress text or unchanged-source claims could be substituted for the actual raw observation; the finite controls could be overstated as an infinite-norm measurement.

Response: The saved XML was parsed directly: 35 nodes and 35 distinct classname/name pairs, zero failures/errors/skips, suite 0.100 seconds. The actual result gives exit zero and runner 0.7094186000758782 seconds. All 26 receipt bindings plus runner and contract match. The final tests/runner were read; finite carriers are at most six signs and nonzero tests check retained-coefficient consequences with actual partitions. This lane performed saved-output readback only, without replay.

Falsifier: A mismatch in the bound raw artifacts, nonzero failure/error/skip outcome, duplicate identity counted as distinct, or a different selected source/runtime would contradict the stated bounded execution observation.

Reconstruction result: Saved raw execution and current bindings agree at their recorded finite scope; no replay or ledger state assigned.

### target

Dependencies: FA01, FA02, FA03, FA04, FA05, FA06, FA07, FA08, FA09, FA10, FA11, FA12, FA13, FA14, CB01, CB03, CB05, FG01, FG02, FG03, FG04, FG05, FAI01, FAI02, FAI03, FAI04, FAI05, FAI06, FIN01.

Declared proof: docs/derivations/2026-09-09-finite-amplitude-rg/construction-or-strongest-theorem.md :: complete construction; docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md :: FA01-FA08; docs/derivations/2026-09-09-finite-amplitude-rg/agents/root-certified-bounds.md :: RI01-RI04; docs/derivations/2026-09-09-finite-amplitude-rg/agents/interface-proof.md :: FG01-FG05 and Actual source interface readback; docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation.md :: FAI01-FAI06 and separate FIN01 observation.

Independent reconstruction: docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md :: IA01-IA11; docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md :: MA01-MA08.

Attack: The implementation could be only a finite-volume or point-jet adapter, miss some generated coefficients, admit only a smaller fixed subset of the target ball, or use numerical agreement/finite budget success in place of the complete quantified proof. Scalar and law scope could be silently strengthened.

Response: The independent ordered catalog and the author literal multiset catalog both cover all connected contributions of each finite order; the source growth is proven equivalent. Exact occurrence cumulants and factorials give the entire polynomial. Convergent rational intervals admit every strict rational input with sufficiently large finite resources; the positive-series remainder bounds the whole same-norm tail. The common-ball error/radial induction covers every finite word. The source realizes those recurrences and refuses incomplete requests. The sole finite observation supports only its recorded controls. The prior exact infinite law/specification theorem remains an explicit revision-bound premise; the scalar-free polynomial is an approximation and supplies no discarded partition/VFE. Broader basin, critical/continuum and geometric/physical identifications remain excluded.

Falsifier: An admitted finite interaction whose required complete Taylor coefficient cannot be returned by the declared enumeration with sufficient resources, a missed or multiply counted translated/repeated source, an invalid enclosure or tail bound, or a successful iteration certificate outside its admitted domain refutes the corresponding conjunct. A budget exhaustion or failed efficiency estimate is not a theorem refutation. Record the strongest conditional result and each remaining obligation.

Reconstruction result: All frozen target conjuncts have explicit conditional mathematical/source derivations and the required separately scoped finite observation; no unresolved obligation found in this lane. Native closure remains root-owned.

## Full-target oracle erasure and remaining scope

Erasing favorable expectations, author claims of success and every numerical observation leaves the exact first-edge representative, reference block partition, occurrence-labeled moment identity, connected-growth completeness induction, multiplicity factorials, rational exponential enclosures, entire positive-series tail and common-ball iteration argument. These reconstruct the frozen construction conditional on the admitted prior operator and its exact constants. A missed multiset, phase change, lost repeated occurrence, translation multiplier, inward endpoint, partial polynomial with a tail, or out-of-domain derivative use would defeat the corresponding claim. The numerical record has separate raw-count/outcome/binding falsifiers and cannot prove those universal identities. No unresolved obligation of the frozen target was found; no ledger closure is assigned here.

Finite budgets may return incomplete even for a mathematically admitted input. Sufficient-resource existence is not a claim about the defaults, fixed hardware, wall time, peak memory or every temporary integer. Approximate direct/staged tables need not coincide; exact targets compose and the sum of their errors controls the difference. The scalar-free table does not recover the original discarded scalar, partition contribution or a VFE value. Broader research obligations remain open.

## Current bindings

The table binds actual read evidence and the retained runtime inventory. Inherited inventory hashes are provenance checks, not a fresh broad source review. No native ledger or release scaffold is included.

| Repository-relative file | SHA256 |
| --- | --- |
| Theory/SPEC.md | dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1 |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/author-claims.json | 4de96b0bcf89fb400287f930259f8942873b529d4015c4593b116299191c1068 |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/finite-amplitude-construction.md | d7105bc7685caedb78e1563657d126e6bcadc050ce6bd5d524e09b53c53cd743 |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation-claims.json | ab17900c7486fad9e348eebcd1543e15a498628f89205d6d4a5390956c3bb14b |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation-plan.md | 896f949b4c4c3b51833deae34fc7049bc9b75cae6e9efc403b8b39904895b591 |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/implementation.md | 67b552107414b2264f68ebb5280b8d3b4fd632abf389165b3f508a0ef357a86b |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-initial-reconstruction.md | 7e417bb7fa59dcfc31d4e26b57e887c297db3c7f69870bb8cf2d997883635a58 |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/independent-proof-check.md | 36559c5c36d7c261f17cad5ea53b96288c23b8c200c2906a4346a5c8816ea65d |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/initial-proposals.json | 4b251f71b025c7c24a1e6b59bd32289c5c32dbdad052055de91af933921ca748 |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/interface-claims.json | a8b5b133d6f7b7e99e1c9d7acfe59c96959976b0ad286d38bc8f070d8a9d38ba |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/interface-proof.md | 64a4b412b191e578bd4ce3c1743b7c1d9de7ea4e820b9ae254aa162896d3c969 |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/root-bound-claims.json | 8017b140b3bf012a7cd09935deaad44a1e7e3e8c50fc38d94fe6064ee0e420f2 |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/root-certified-bounds.md | 18d58e4880cb3ca51904a6d5abbe4f835d5f0a8c72181ab4abb2298c0b56ed7e |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/selected-final-proposals.json | fd84f2b4ea01e14590e380fa61ab40369080869841a72279a85554bd548cd5a6 |
| docs/derivations/2026-09-09-finite-amplitude-rg/agents/selected-mathematical-proposals.json | 219306cb0a44e782ad4a83d13fbe7011f7546d1c3ecb03bf554b30bdff7958ba |
| docs/derivations/2026-09-09-finite-amplitude-rg/construction-or-strongest-theorem.md | 5f9156d3b2c284224c4026499b30a39092e282e2b1505ffef1b31467aa5569d4 |
| docs/derivations/2026-09-09-finite-amplitude-rg/counterexample-register.md | 89829d2fd75a2c0e7cf3f6e9c1eeda1f77600f0f5098eb998c69a7960ae86e55 |
| docs/derivations/2026-09-09-finite-amplitude-rg/final-report.md | c8cf25f5d6b015174fed76a98713fb1d8b476c3f1703042909357f6a9f778651 |
| docs/derivations/2026-09-09-finite-amplitude-rg/problem-contract.json | 25bcd2b0884d7873efdcd2f7a37381f0334bcdf7f9610287a1eef7957a17c885 |
| docs/derivations/2026-09-09-open-neighborhood-rg/agents/root-weighted-cumulant-construction.md | 289b0c37c6432bc0cf4764d08079aae5d781f80038c805dc89cd3cd35acba20e |
| docs/derivations/2026-09-09-open-neighborhood-rg/release.json | 13641c198dde60d1a4bd693df31e177a97c603ce129ff9e2e108892606fe93fa |
| docs/reports/2026-09-09-finite-amplitude-rg.md | c7696e7e17faf5f7c8dbc1c005efbba9c376aaea033cb3c9af91d31af2c1ca6e |
| docs/verification/2026-09-09-finite-amplitude-rg/finite-amplitude-tests-20260909T161201401555Z.command.json | e8e9b4929861dac5ffa8ee147857acb100f408f3b7dee0b9affd031c59e01979 |
| docs/verification/2026-09-09-finite-amplitude-rg/finite-amplitude-tests-20260909T161201401555Z.log | 573d9ddc3d79852ed0a179261e99609ff7acdf3e945213b867dd19142d308836 |
| docs/verification/2026-09-09-finite-amplitude-rg/finite-amplitude-tests-20260909T161201401555Z.result.json | 095485d684806a51519d21100bb9ef7c5762c2290decc1d042d718f26a70d3b9 |
| docs/verification/2026-09-09-finite-amplitude-rg/finite-amplitude-tests-20260909T161201401555Z.xml | 8dfca5903f915412b958471a21357c6bd79345f11a7bbaa7cf87211968e770b6 |
| docs/verification/2026-09-09-finite-amplitude-rg/run_finite_amplitude_tests.py | 4b1fb49e95bff3e5253838217ddc1339c6f30aad25ec18442f5afebe44b039c6 |
| experiments/rg_v2/neighborhood.py | 5f2bbae43a160a6bd9df08ec4ed515fd789d9ae3c5675d41640b0d31bbc15685 |
| pyproject.toml | fd64a5cd965e46dbb0e9c8adc3aafae3757193b2b9c63ea9df9f0eeb60110fd7 |
| run_lab.py | a4ec4f955afe6abfe24849e4349719acf6f227129c0d7524f69bb5b76a62717a |
| src/multiagent_elbo/__init__.py | 1cc634856919f6bdcbc201b9eab851c1f1253a7179b41c26334ff5ee5c2e5a09 |
| src/multiagent_elbo/artifacts.py | a2facc98e5193741edd6e24196b2ce31b6b286db605fd7cccd13b471d02e3456 |
| src/multiagent_elbo/config.py | be3805e7cd68daf2ee15f03f594768a1f8363f703affa566c34cd2b6f8183bd6 |
| src/multiagent_elbo/experiment_support.py | b4006ca1559d44846fd736850a224403f941c5be29f91ad279d2bbea86e909e0 |
| src/multiagent_elbo/lab/launcher.py | 5f050b86bc4ff78869714bd003178924b74e255b72c6c11c3a338652acdb4ce8 |
| src/multiagent_elbo/lab/routes.py | fc680668f112a07d1ce37e93bdacf5febe2a3563f36a6ecc2f2e8a3c70b494b5 |
| src/multiagent_elbo/rg_v2/__init__.py | 7cb6c5a3d9a9c8c6ebbe3d64d271a4e13cbc2f6f0cb606e037dd88292efdf4d7 |
| src/multiagent_elbo/rg_v2/certified_logarithms.py | 1eb6db2b17d1ad4598e2e1bf69f89b44afa0501ef8b2cd8349298475b2dc639c |
| src/multiagent_elbo/rg_v2/finite_amplitude_rg.py | 966eb44fe1c502914a166edc1c652c20a3cb6a98125d5974430611a793fdb4cf |
| src/multiagent_elbo/rg_v2/finite_gauge_matter_law_experiment.py | 46cafd1e9fce93ab1afc9dc2b2a9e05991943e2e2d3586f5f2cdbb9730b25c19 |
| src/multiagent_elbo/rg_v2/finite_gauge_matter_law_model.py | 930baa7b53878b3cea27b84db5fae2be08e7f0d5a011c791ae3ef3d46a73f026 |
| src/multiagent_elbo/rg_v2/finite_word_stability_comparison.py | 6195b4ee230db982158ae78d12330829e5d74dd6b45c2867c232f9b8a919c50f |
| src/multiagent_elbo/rg_v2/finite_word_stability_experiment.py | ef6b93a5de4c53c6aca012e16fd20f0d9a0215c97bb967842272ee07d674084f |
| src/multiagent_elbo/rg_v2/finite_word_stability_model.py | 65f7180a2ddf050375106b0c6ecf34d6c63ad30f3b0c76a222505d601e2a6d37 |
| src/multiagent_elbo/rg_v2/inference_persistence_model.py | 206f9b12f76282dc3e45d231b326adbb109e882fc8b53486bb1bed259333d910 |
| src/multiagent_elbo/rg_v2/partition_parent_selection_composition.py | 1383ef5066fa86df2ac5857f4b463a2e3e3ee8ee699aa014729c932711b44bde |
| src/multiagent_elbo/rg_v2/partition_parent_selection_model.py | 92a6978b0bdd03db792356b75eb30ea96c641e9fb5daa2e231c2feed5ffd07ad |
| src/multiagent_elbo/rg_v2/recursive_parent_experiment.py | 94daca4c620c4d89be878221b6366a910fb405deeb5e933cb9a5c42272d11670 |
| src/multiagent_elbo/rg_v2/recursive_parent_model.py | 7fdbf0210c0d62b5cdf2269cf3ff45b1a1c4e8e52cc886f45a3f21e111c3e079 |
| src/multiagent_elbo/rg_v2/spatial_gauge.py | 1d5f51a19dbe05f03a41982d8755ca6035f8b09537ff675f19b0300b7cd349f1 |
| tests/rg_v2/test_finite_amplitude_rg.py | b64bfaccc66ce2ff2d6b72a57ea119a7885ef2dcc4c6ae29ca558e9850889c65 |

Pending obligations for this independent coverage: none. The accompanying coverage-proposals.json contains the same 30 IDs and dependency lists, explicit resolved findings, direct evidence and empty pending arrays.
