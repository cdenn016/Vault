<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c","target_digest":"2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c"} -->

# Independent initial finite-amplitude RG reconstruction

Date: 2026-09-09. This initial record uses only the new frozen contract and the already admitted local RG theorem. I have not read the prior next-discovery note or any current root, author or worker construction, source or test. The unchanged SPEC is retained from the prior full read and its SHA256 was checked again as dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. The prior release hash matches the contract premise. I reread the admitted root weighted-cumulant construction for its occurrence formula and constants. We share model family, prior context and filesystem; this recorded access boundary is not a claim of independent institutional or formal verification. This document proposes derivations and falsifiers, not ledger states.

The target appears constructible. The construction below is intentionally exhaustive, with an explicit finite search region and canonical-output filter. It establishes mathematical computability and termination under the promised strict local-domain premise. It does not promise that a particular small budget will finish or that an implementation with an immutable finite bit cap realizes every possible requested precision. That executable boundary must be checked later.

## IA01: exact finite orbit representation and its norm

Represent an edge as (x,y,i), i in {0,1}, and a nonempty finite support as a sorted set of distinct edges. Let its translation anchor be the origin of its lexicographically least edge, ordered by (x,y,i). Subtract this two-coordinate anchor from every edge without changing its orientation. The result is its canonical translation representative. Negative coordinates other than the anchor remain allowed. In particular this is not independent coordinatewise minimization: the latter might place no edge at the origin and would invalidate the rooted enumeration below. Translation, not rotation, reflection, axis exchange or gauge action, is the equivalence used here.

A finite nonempty support has no nonzero translation stabilizer. Indeed a nonzero translation has a linear coordinate that increases strictly, contradicting finiteness and a maximum of that coordinate on the support. Consequently each support orbit has exactly one canonical representative, and each literal translated support has exactly one library label and one translation after duplicate library orbits have been consolidated. Coefficients are summed as rationals before absolute values are taken; zero totals can be omitted. Distinct translation classes must never be merged merely because their cardinalities, diameters or orientation counts match.

Write the resulting library as (S_r,j_r), r=1,...,L, and let s_r=|S_r|, d_r=diam(S_r), n_i(S_r) be its number of orientation-i edges. The diameter is the admitted origin-distance diameter. The geometric proof below needs only that this distance bounds coordinate displacement and obeys the triangle inequality; the prior lattice diameter does so. For a fixed edge (0,0,i), the translated copies of S_r containing it are precisely the n_i(S_r) translations that move one of its orientation-i edges to that origin. Their support size and diameter do not change. Therefore the exact input norm is

\[
 \mu=\max_{i\in\{0,1\}}\sum_{r=1}^L n_i(S_r)s_r
       e^{\kappa s_r+\lambda d_r}|j_r|.
\]

This is a finite positive sum of rational multiples of exponentials of nonnegative rationals. It is computable to arbitrary rational enclosure accuracy. Summing both orientations rather than taking their maximum gives a safe upper bound but is not this exact norm formula. Omitting n_i loses translated incidence; adding a factor a^2 would mix coefficient and area-density conventions. The same formula applies to every finite output library in its coarse lattice coordinates.

## IA02: literal blocking phases and conditional moments without state enumeration

For a horizontal fine edge (x,y,0), it belongs to a retained a-path exactly when y is a multiple of a. In that case its retained label is (floor(x/a),y/a,0). Otherwise it is an unused singleton reference block. For a vertical fine edge (x,y,1), the condition is that x is a multiple of a, and its retained label is (x/a,floor(y/a),1). Otherwise it is an unused singleton. Integer floor division is essential at negative coordinates. Translations by arbitrary fine integers generally change the blocking phase; translations by a times a coarse lattice vector preserve it. Both orientations use their own transverse congruence.

For a finite edge set D, inspect every reference block it meets. If it includes an unused edge or a proper nonempty portion of any retained path, define m_a(D)=0. If it is a union of entire retained paths, define m_a(D)=1 and let T_a(D) be the corresponding finite coarse support. The empty set has m_a(empty)=1 and T_a(empty)=empty. These are the conditional moments at the all-plus retained configuration. For general retained signs the nonzero moment is the one character chi_(T_a(D)). The test uses finite set membership and path length a, not an enumeration of 2^|D| probability states. Arbitrarily large finite supports therefore do not require a large probability carrier in this coefficient algorithm.

For an ordered occurrence list S_1,...,S_n, including repeated literal supports, its conditional cumulant coefficient at all-plus is the integer

\[
 c_a(S_1,\ldots,S_n)
 =\sum_{\pi\in\operatorname{Part}([n])}
   (-1)^{|\pi|-1}(|\pi|-1)!
   \prod_{B\in\pi}m_a\Bigl(\mathop{\triangle}_{j\in B}S_j\Bigr).
\]

The partition is a partition of occurrence indices, not a set of distinct support values. Each moment is exactly zero or one. The dependency graph has one vertex per occurrence and joins occurrences sharing any retained path or unused singleton reference block, even if they share no fine edge. If this graph is disconnected, the cumulant vanishes by the admitted finite reference factorization. If its total XOR D is not a complete-path union, the cumulant also vanishes by the admitted grading. Otherwise every nonzero partition term has the same retained character chi_(T_a(D)), so c_a is its entire coefficient. No omitted Fourier expansion or numerical cancellation test is needed.

## IA03: a finite universe containing every required translated occurrence

Fix a Taylor order n>=1. If the library is nonempty, let D=max_r d_r and set

\[
 R_n=nD+(n-1)(a-1).
\]

Let U_n contain every literal support S_r+t wholly contained in the fine-origin coordinate box [-R_n,R_n]^2, with its unchanged coefficient j_r. This is a finite set of labeled instances. Because each S_r has its anchor at the origin, every permitted translation t itself lies in that box. Thus |U_n|<=L(2R_n+1)^2 when the admitted lattice diameter is integer valued; a ceiling gives the same safe bound otherwise. Containment imposes additional finite inequalities and only reduces that count.

Consider any nonzero connected occurrence contribution whose nonempty coarse output T is already in canonical translation position. T contains an edge at coarse origin zero. The first fine edge f of its path has fine origin zero and belongs to the total XOR; hence some occurrence contains f. For an arbitrary edge in any other occurrence, choose a simple graph path from this initial occurrence to the occurrence containing that edge. Within each visited source, origin displacement is at most D. Across a common reference block, displacement is at most a-1. The path visits at most n source occurrences and uses at most n-1 block joins. The triangle inequality therefore bounds displacement from f by R_n, and both coordinate displacements are bounded by the same number. Every source in the contribution lies wholly inside that finite box, so every occurrence belongs to U_n. This includes repeated occurrences and disconnected fine supports within a single occurrence.

A connected singleton occurrence needs no reference-block connection; its internal diameter D alone supplies the n=1 bound. A library of singleton sources has D=0, but at order n the nonzero reference-block radius (n-1)(a-1) still includes every needed neighboring singleton. No whole-torus approximation, finite boundary model or global norm convergence of a cutoff is being invoked: U_n is only a finite exact enumeration domain for canonical coefficients at this fixed order.

## IA04: complete polynomial enumeration and the multiplicity trap

For n=1,...,p, enumerate every ordered n-tuple from U_n, with replacement. Reject disconnected occurrence graphs. Compute its total XOR D; reject unless D is a nonempty complete-path union. Form the literal coarse output T=T_a(D), and reject unless its translation anchor is already zero. Only then evaluate the finite partition formula for c_a and add

\[
 \frac{c_a(S_1,\ldots,S_n)}{n!}\prod_{j=1}^n J_{S_j}
\]

to that exact T's coefficient at order n. Sum these rational order tables for n<=p and consolidate equal T. All generated many-body supports are retained; no pairwise, field/plaquette, diameter or cardinality projection is applied. A zero coefficient can be stored or omitted after exact summation, since its library meaning is unchanged.

The retained outputs are already canonical. One must not enumerate many translated outputs and then translate each to the same canonical representative and sum them: that computes a translated incidence multiple instead of one coefficient. For example take one four-consecutive-horizontal-edge source orbit and a=2. At n=1 both its translation at 0 and its translation by -2 fit the radius-three box and are full unions of retained paths. Their outputs are {0,1} and {-1,0}. Both normalize to the same representative, but the true coefficient is j, not 2j. The canonical-output filter retains exactly the first. A second possible duplication comes from separately rooting the same tuple at both orientations when the output contains both origin edges; the Cartesian enumeration here has no such root branch and counts the tuple only once.

Completeness follows from IA03: every nonzero term in the admitted infinite formula for any canonical T occurs in the enumeration. Conversely every accepted tuple is literally one term in that formula, with its prescribed 1/n!, and no tuple is repeated by the Cartesian enumeration. The graph/grading rejections remove only identically zero contributions. Therefore the finite table is exactly P_(a,n)(J,...,J) on every translation orbit. Its translation invariance follows from shifting every occurrence by a coarse translation times a before applying the same formula. No a^2 coefficient factor arises.

An alternative implementation may enumerate multisets of literal sources. If one literal source occurs m_u times, the ordered list has n!/product_u m_u! distinct permutations. Because the cumulant is symmetric, their combined coefficient is c_a product_u j_u^(m_u)/product_u m_u!, not c_a/n! for just one multiset. A tree-growth traversal may also be used, but it needs an exact deduplication or an explicit multiplicity proof; the tree overcounts allowed in a norm majorant are not allowed in an exact coefficient table.

Repeated occurrences are necessary at finite amplitude. In a length-two path with independent equal fields h on its two fine signs, the exact retained coupling is atanh(tanh(h)^2)=h^2-(2/3)h^4+O(h^6). At order four, the multiset with three copies of the first singleton and one of the second has conditional cumulant -2 times the retained character: its full moment contributes 1 and its three pair partitions contribute -3. Its coefficient is -2/(3!1!)=-1/3. The swapped multiset supplies the other -1/3. An enumeration that forbids repeats loses the entire fourth-order correction. This symbolic control uses two fine signs and does not require a scientific run.

## IA05: finite work and exact arithmetic

At each selected order, U_n is finite. The ordered list set has |U_n|^n elements and the occurrence partition set has at most n^n elements, since assigning each of n indices one of n block labels overcounts all partitions. Each graph, XOR, block lookup, factorial and rational product is a finite exact operation. A deliberately loose operation bound is a constant times sum_(n<=p) |U_n|^n n^n n^2 s_max, with extra polynomial factors for set sorting. This is a finiteness statement, not an efficiency claim or a measured runtime. Bit complexity is additional: finite sums and products of the finitely many rational inputs have finite integer lengths, but those lengths can grow rapidly with p and input size.

An executable must count its chosen finite resources and refuse or mark incomplete before treating a partial order, a partial tuple set, a failed rational guard or a truncated output table as a successful certificate. A budget failure is not an RG counterexample. The mathematical termination theorem allows sufficiently large finite tuple, partition, order, output and arithmetic resources. A fixed immutable finite bit cap can honestly produce incomplete outcomes; by itself it does not prove that this single executable completes for every rational input and tolerance. Any stronger implementation promise must expose an increasing resource family or explicitly distinguish the ideal construction from the bounded program.

No probability states are enumerated by IA02-IA04. The contract's six-sign limit on independently enumerated probability carriers can therefore coexist with larger symbolic support libraries. Any finite Gibbs/probability control in the test packet must still respect that limit; it cannot be hidden inside this combinatorial coefficient enumeration.

## IA06: rational exponential and constant enclosures with strict admission

For a nonnegative rational z define L_N(z)=sum_(j=0)^N z^j/j!. If N+2>z, every ratio of consecutive terms after the first omitted term is at most q=z/(N+2)<1, so

\[
 L_N(z)\le e^z\le U_N(z)
 =L_N(z)+\frac{z^{N+1}}{(N+1)!}\frac1{1-z/(N+2)}.
\]

All endpoints are rational. The omitted term tends to zero: after any index at which the term ratio is at most one half, the terms decrease geometrically. The extra geometric multiplier tends to one. Thus U_N-L_N tends to zero. Negative exponents are enclosed by reciprocals of positive-exponent enclosures, with the endpoints reversed. The case z=0 can return the exact value one. Products, positive division and finite maxima/minima preserve valid rational endpoint bounds by elementary monotonicity.

Applying these formulas to IA01 gives convergent lower/upper norm enclosures. Apply them also to the admitted K_a, ell_a and M_a. Write K_a^+>=K_a, ell_a^+>=ell_a and M_a^+=11K_a^+/a. For ell_a one may initially use ell_a^+<=1/a<1, and refine it through the reciprocal exponential. The positive rational number

\[
 r=\min_{a\in\{2,3,6\}}\left\{1/48,\frac1{2K_a^+},
 \frac{1-\ell_a^+}{2M_a^+}\right\}
\]

is a lower bound for the admitted common epsilon. As the enclosures tighten, this lower bound converges to epsilon. Under the promised strict premise norm(J)<epsilon, there is therefore a finite refinement at which a rational norm upper bound u satisfies u<r. This proves terminating strict admission on the promised domain. Equality at the boundary is deliberately excluded. An exhausted precision budget or an inconclusive strict comparison may return nonadmitted/incomplete, not a success and not a claim that the mathematical input is outside the ball. A certified rejection based on separated opposite endpoint bounds is a different outcome.

No floating exponential, rounded-down norm or uncertified decimal constant is needed. The algorithm must retain strict inequalities for admission and for the requested final tolerance. This exact rational enclosure method supplies its own proof; no new external theorem is imported.

## IA07: a rational bound for the entire omitted interaction

Let the exact polynomial through p be Jhat=sum_(n=1)^p P_(a,n)(J,...,J). Choose the already certified u>=norm(J), K_a^+>=K_a and x=K_a^+ u<1, in fact x<1/2 after IA06. The admitted same-norm bound and the triangle inequality give

\[
 \|R_aJ-\widehat J\|
 \le \frac ua\sum_{n=p+1}^{\infty}n x^{n-1}
 =\frac ua\frac{x^p((p+1)-px)}{(1-x)^2}
 =:T_{a,p}(u,K_a^+).
\]

The sum identity follows by differentiating the finite geometric tail x^(p+1)/(1-x); the derivative is a convergent positive series for 0<=x<1. Although one closed form contains subtraction, the bound is increasing in u and K_a^+ because its series has nonnegative coefficients. It therefore remains an upper bound with the stated rational enclosures. All quantities in the final expression are rational. This bounds the full omitted interaction norm, not only omitted coefficients on the returned support inventory or a finite evaluation window.

For fixed x<1, (p+1)x^p tends to zero. For example choose an integer q with x^q<=1/2; grouping p into q-blocks bounds the geometric factor by powers of one half times a linear polynomial. Thus there is a finite p with T strictly below every prescribed positive rational tolerance. Increasing p and completing IA04 for each order terminates mathematically with sufficiently large finite resources. The zero interaction can return zero exactly with zero error and does not need division by u or a positive order.

A norm enclosure for the returned finite library is available again from IA01. Independently, the admitted radial inequality gives the useful bound

\[
 \|\widehat J\|\le\beta_a^+u+T_{a,p},
 \qquad \beta_a^+=(1+\ell_a^+)/2<1,
\]

because u<r<=epsilon and the exact R_a contracts radially. The smaller of two certified upper bounds may be used. A successful error certificate alone does not automatically admit the output to the next stage: its own norm/domain bound must also be checked.

## IA08: domain-qualified finite-word error recurrence

Let exact X_j=R_(a_j)X_(j-1), with X_0=J, and let Jhat_j be the complete polynomial evaluation of R_(a_j) at the finite rational library Jhat_(j-1). The exact initial error is E_0=0. Suppose a certificate gives input error at most E_(j-1), a rational upper bound u_(j-1) for the approximate input norm, and a rational upper bound v_(j-1) for the true input norm, both strictly below the common rational radius r from IA06. The convex segment between these inputs lies inside that ball. The admitted derivative bound and the Banach fundamental theorem along this segment give

\[
 \|R_{a_j}(\widehat J_{j-1})-R_{a_j}(X_{j-1})\|
 \le L_j\|\widehat J_{j-1}-X_{j-1}\|,
 \qquad L_j=\ell_{a_j}^++2M_{a_j}^+\max(u_{j-1},v_{j-1}).
\]

Indeed integrate the derivative of R(X+t(Jhat-X)); its operator norm is bounded throughout the segment by the right side. There is no comparison between independently chosen channels or changing coordinates. If delta_j bounds that stage's full truncation error at its actual approximate input, then

\[
 E_j=L_jE_{j-1}+\delta_j,
 \qquad v_j=\beta_{a_j}^+v_{j-1},
 \qquad u_j=\beta_{a_j}^+u_{j-1}+\delta_j
\]

are certified error/true-norm/approximate-norm bounds. A separately tighter direct norm enclosure may replace u_j. The next stage proceeds only if its declared input norm bounds are strictly below r. Reusing a tail evaluated at the original input norm after the approximate input has changed would not be justified without an upper bound relating them.

The recurrence expands to E_m=sum_(j=1)^m delta_j product_(l=j+1)^m L_l. This is the actual finite-word propagation inequality. It applies to any finite factor word with fixed admitted geometry; it does not require direct and staged finite polynomials to coincide. For a word whose exact target equals R_6J, a separately computed direct approximation with error E_direct differs from the staged approximation by at most E_m+E_direct. Literal support coordinates must agree before taking that norm.

## IA09: constructive choice of tolerances that guarantees word termination

For a promised admissible initial J, perform IA06 until u_0<r, and let q=max_a beta_a^+<1. Fix a finite word length m>=1 and desired positive rational total error eta. Choose one rational delta satisfying

\[
 0<\delta<\min\{(1-q)r/2,\eta/(m+1)\}.
\]

At each stage choose a complete order with its tail delta_j<=delta, tightening to strict inequality if desired. If u_(j-1)<r, the analytic output bound gives u_j<=q u_(j-1)+delta<q r+(1-q)r/2<r. Thus the entire approximate word remains admitted. The true norms remain below r by radial contraction. Moreover r<=(1-ell_a^+)/(2M_a^+) implies L_j<=1, so E_m<=sum delta_j<=m delta<eta. These inequalities prove finite-word termination and final error control without guessing future coefficient cancellations. The empty word returns J and error zero.

Every stage still requires a complete combinatorial order computation. Its number of source orbits and diameters may grow, but each intermediate library is finite and rational. IA03-IA07 therefore apply anew, and a finite number of terminating stages terminates with a sufficiently large finite aggregate resource budget. This is not a practical complexity guarantee or permission to execute a large packet. A bounded implementation may stop before a stage completes, preserving the completed prefix and refusing a certificate for the requested complete word.

## IA10: scalar, normalized finite laws and VFE scope

The target operator is scalar-free. Empty-XOR contributions are conditional log-partition scalar terms, and an infinite translation-invariant scalar sum has no canonical finite total merely because the nonempty interaction norm converges. IA04 skips those terms for exactly that quotient reason. It does not use their omission to assert a normalizer, evidence, pressure, ELBO or VFE value. A finite polynomial output represents an approximate scalar-free interaction with a full-norm error, not an exact finite-amplitude pushed probability law.

For a separately declared finite free edge window Lambda and fixed fine exterior, include every touching source with its exterior signs reduced. If two full interactions differ in norm by at most E, their resulting finite Hamiltonians differ in absolute value by at most |Lambda|E, because summing the incident coefficient errors over Lambda overcounts every touching support and all norm weights are at least one. Their actual finite log partition functions then differ by at most the same number, by bounding the exponential weights above and below. Their normalized log-density ratios differ by at most 2|Lambda|E. For one fixed recognition law with the same support/reference, the difference of the corresponding normalized KL functionals is at most that number. These elementary finite statements require the actual finite partitions; the coefficient table alone does not supply them.

Adding a finite scalar c to H multiplies Z by exp(-c), so H+log Z and the normalized law are unchanged. Dropping c while keeping an old Z would change the result. Observation/evidence terms in the general SPEC remain separately declared; no equality of full cross-model VFE is inferred from these finite prior/interaction controls. Gauge holonomy, Fisher curvature, base curvature and a physical clock remain distinct and are not inserted into the objective by this algorithm.

## IA11: meaningful finite controls and precise unresolved implementation obligations

The independent-field control is exact at nonzero amplitude. A length-a product of independent signs of mean tanh(h) has mean tanh(h)^a and a retained singleton coupling f_a(h)=atanh(tanh(h)^a). Thus the full RG of independent horizontal/vertical fields consists only of the corresponding singleton couplings, separately in each orientation. The a=2 coefficient calculation in IA04 supplies its leading and fourth-order terms. The identity f_d(f_a(h))=f_(ad)(h) tests the fixed geometric composition at the law level; different polynomial truncations need only satisfy the error comparison from IA08. Any direct probability enumeration for these controls can use a single path of at most six signs. Rational exponential/log enclosures or exact conditional-moment identities, rather than uncontrolled floating agreement, must distinguish a proof-level bound from an observed numerical comparison.

Before mature source access the implementation obligations are concrete: it must preserve both orientation counts and all blocking phases at negative coordinates; count every repeated literal occurrence with the correct factorial; avoid canonical-output orbit overcount; complete every declared order and return all nonempty supports; use outward rational norm/constant bounds and strict domain/tolerance tests; distinguish resource exhaustion from success; compute local tails at each actual approximate stage; and retain finite normalization when reporting probability or VFE controls. No current implementation defect is asserted before reading it. These are the exact seams to challenge, not a request for an extra scientific run.

## Initial snapshot handoff

The initial proof is complete as an independent constructive route for the mathematical contract: finite canonical enumeration, rational admission and tails, and domain-safe finite-word propagation. Its efficiency is intentionally not claimed. Source correspondence and the bounded observed implementation remain pending counterpart access; this record does not preclaim any tests, executable completion, target ledger state or final native release. Initial bytes will be preserved before that access.
