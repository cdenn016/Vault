<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c","target_digest":"2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c"} -->

# A marked-path cumulant route to basin entrance

Date: 2026-09-09. **OPEN: DISCOVERY ONLY, EXCLUDED FROM THE CURRENT CERTIFICATE.** This note follows the previous entrance intake but supplies a more specific local calculation and a falsifier for one tempting extension. It does not close basin entrance or change the current finite-amplitude target. The author shares the preceding construction context. No source, test, experiment, primary-literature search or old artifact is changed.

## A new local ingredient: one parity constraint couples all disjoint groups

**DEFINITION.** Work on one B-bit path under the independent biased reference with mean b in (0,1). Condition its complete parity to y in {-1,+1}. Let A_1,...,A_m be disjoint nonempty subsets of that path, m>=2, with r_i=|A_i| and r=sum_i r_i<=B. Set U_i=chi_(A_i), mu_i=b^(r_i), P=product_i mu_i=b^r, and zeta=y b^(B-r). Integrating the remaining path bits gives the exact joint law of these disjoint group variables as their independent biased law multiplied by (1+zeta product_i U_i)/(1+zeta P). This is a finite normalized reference identity.

**ESTABLISHED DIRECT LOCAL CALCULATION, NOT AN ENTRANCE CLOSURE.** Let A_i(s)=E exp(sU_i) and v_i(s)=E[U_i exp(sU_i)]/A_i(s) under the independent reference. The conditional log moment generating function is

\[
 \sum_i\log A_i(s_i)
 +\log\left(1+\zeta\prod_i v_i(s_i)\right)
 -\log(1+\zeta P).
\]

For the mixed derivative using each of the m parameters once, the first sum contributes zero. Since v_i(0)=mu_i and v_i'(0)=1-mu_i^2, expansion of the middle logarithm in a neighborhood of zero gives

\[
 \kappa_y(U_1,\ldots,U_m)
 =\left[\prod_i(1-\mu_i^2)\right]\zeta
 \sum_{n\ge1}(-1)^{n-1}n^{m-1}(\zeta P)^{n-1}.
\]

Here |zeta P|=b^B<1, even when r=B and |zeta|=1. The series and its finitely many derivatives converge in a neighborhood of the point, so coefficient extraction is legitimate. The bound n^(m-1)<=(m-1)! binomial(n+m-2,m-1) yields

\[
 |\kappa_y(U_1,\ldots,U_m)|
 \le\frac{(m-1)!b^{B-r}}{(1-b^B)^m}
 \prod_i(1-b^{2r_i}).
\]

For a compact positive-h interval, b<=b_max<1 supplies a uniform positive denominator. The estimate has one path-activation factor b^(B-r), together with an explicit factorial and denominator, rather than one factor for every pair of groups.

## Why a pairwise tree replacement is wrong

**ESTABLISHED DIRECT COUNTERCHECK.** For two disjoint groups of sizes r,s the formula reduces exactly to

\[
 \operatorname{Cov}_y(U_1,U_2)
 =\frac{y b^{B-r-s}(1-b^{2r})(1-b^{2s})}{(1+y b^B)^2}.
\]

For three distinct single bits the third cumulant is

\[
 \kappa_y(U_1,U_2,U_3)
 =\frac{y b^{B-3}(1-b^2)^3(1-yb^B)}{(1+yb^B)^3}.
\]

At fixed b in (0,1), its leading B dependence is b^(B-3), while the product of two pair covariance scales is b^(2B-4). Their ratio grows as a constant times b^(1-B). Thus no B-independent factor multiplying a tree product of those pairwise suppression weights can bound this three-group cumulant for all large B. Pairwise smallness of the constrained path does not supply the needed all-orders connected estimate. At b approaching zero with r=B, the complete parity cumulant can remain of order one despite vanishing lower-order group moments. The next proof must retain a marked path hyperedge, not replace it by independent weak pair links.

## A precise candidate global construction

**OPEN.** Absorb the original field into the biased independent reference and expand the plaquette factors 1+c chi_p. In a cumulant-of-products decomposition, organize each parity-induced connection by one marked path block. The displayed disjoint-group calculation suggests the bound to seek for that block after its fine-edge occurrence groups have been identified: a factorial/denominator factor multiplied by b^(B-r), where r counts the distinct path bits used by those groups. Fine plaquette overlap connections remain separate. A full proof must derive this product-cumulant decomposition with repeated source occurrences, overlapping fine variables and all multiplicities; the disjoint-group identity does not itself cover those configurations.

A useful coverage split is r<=B/2 versus r>B/2. The former pays at least b^(B/2). The latter requires many fine source incidences: an n-plaquette occurrence list has only 4n edge occurrences. For several marked paths, a successful accounting must allocate those occurrences without reusing one to pay multiple path-activation deficits. Repeated plaquettes and coincident fine variables must remain labeled until that accounting is justified. This suggests a small activity per retained path as B increases, but the lattice placement, factorial and denominator sums must be paid before concluding convergence.

The exact target remains uniform entrance for each compact positive-h interval and fixed 0<c<1/12: exhibit one common kappa_0,lambda_0>0 and a bound tending to zero for the complete consolidated coefficient norm of the exact B-path law, uniformly over that source compact and all sufficiently large B. It must fall below the current local operator radius and preserve the earlier specification through exact representative conversion. A logarithmic or polynomial finite-support calculation alone does not meet this target.

**OPEN.** The difficult step is a convergent connected majorant across the entire stated c interval. Generic plaquette lattice-animal constants may impose c<c_* much smaller than 1/12. The previous real Dobrushin comparison controls local response and spatial dependence, but it cannot be inserted as an unproved all-orders coefficient bound. One possibility is to resum ordinary short fine plaquette clusters before expanding the marked parity connections, using an independently proved strong-response estimate for that background. Another is a direct mixed marked-hypergraph majorant whose convergence exploits 12c<1 with the actual incidence count. Neither is supplied here. Failure of a crude expansion is not evidence that the particular orbit lacks entrance.

## Implementation seam and exclusions

**OPEN.** A later bounded adapter could evaluate the single-path disjoint-group cumulant by two independent finite formulas: the displayed rational series derivative and direct normalized enumeration on at most six bits. It should include m=3 to expose the incorrect pairwise-tree replacement, y=-1, r=B and a subset leaving unused path bits. This is new discriminating finite algebra, but it would support only the marked-path primitive, not a global entrance theorem. No such adapter or execution is part of the current task.

**NOT-CLAIMED.** The existing diameter-norm nonembedding remains relevant but is not repeated as the new argument. The new ingredient is an explicit all-orders one-block cumulant with a single activation cost and a concrete failure of pairwise factorization. The remaining full RG target includes the larger basin, other schemes, critical/continuum structure and geometric extensions. Gauge holonomy, statistical Fisher curvature and contextual-base curvature remain different model data. Any curvature-dependent prior or likelihood still needs its normalized factor and partition derivatives; no physical clock or automatic VFE penalty follows.
