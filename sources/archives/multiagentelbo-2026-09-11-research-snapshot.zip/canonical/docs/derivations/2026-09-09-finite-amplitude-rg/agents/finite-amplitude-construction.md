<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c","target_digest":"2e618884935b5368415d3b699b7068a4150ec277e023f4352ae1f3260ad47b0c"} -->

# Complete finite-amplitude Taylor enumeration

Date: 2026-09-09. **DEFINITION.** This is an author construction, not ledger closure or independent verification. Its initial derivation is persisted before reading any new root, implementation-worker or checker draft in this run. The author participated in the prior operator construction and wrote the discovery intake, so shared-context independence is limited. The frozen contract has SHA256 25bcd2b0884d7873efdcd2f7a37381f0334bcdf7f9610287a1eef7957a17c885. The unchanged SPEC has SHA256 dea95a12a376f5a7c103eeceb5a8613c428edca12da065b6e3383ff6466b06b1. The admitted prior release has SHA256 13641c198dde60d1a4bd693df31e177a97c603ce129ff9e2e108892606fe93fa. RG01-RG14 and their complete conditional-cumulant formula are inputs, not re-proved here. Root separately owns certified transcendental enclosures and multistep propagation. No code, tests or science run.

## FA01. Canonical finite input and norm inventory

**DEFINITION.** An executable edge is (x_0,x_1,i), with i in {0,1}; these are theory axes 1,2 respectively. Order edges lexicographically by (x_0,x_1,i). For a nonempty finite edge set S, subtract the anchor coordinates of its first edge from every edge, keeping all orientations. Call this translation canonicalization can(S). It changes neither cardinality nor anchor diameter. It quotients integer translations only, not rotations, reflections or permutations of axes. Its first edge has anchor zero, but other edges may have negative second coordinates.

An input library contains one such canonical support S_j and rational coefficient j_j per translation orbit. Its represented interaction assigns j_j to every literal translate S_j+v. Duplicate canonical supports must be rejected or consolidated by exact coefficient addition before enumeration; otherwise two input names would denote the same literal source. Zero coefficients may then be removed. The empty library represents zero and returns zero at every order without needing a maximum diameter. Nonempty supports, literal edge distinctness and exact rational coefficients are part of admission.

**ESTABLISHED BY TRANSLATION COUNTING.** Write s_j=|S_j|, d_j=diam(S_j), and n_(i,j) for the number of orientation-i edges in S_j. Exactly n_(i,j) distinct translates of that orbit contain the edge (0,0,i): align each such edge's anchor with zero. A finite nonempty set has no nonzero translation period, so these translates are distinct. Thus the exact input norm is

\[
 \|J\|_{\kappa,\lambda}
 =\max_{i\in\{0,1\}}\sum_j
 n_{i,j}s_j e^{\kappa s_j+\lambda d_j}|j_j|.
\]

The same formula computes the norm of a finite output library after coefficient consolidation. Its exponential values need the root's certified enclosure interface; the coefficients and multiplicities here remain rational and integer respectively.

## FA02. Reference-block ownership, phases and negative coordinates

**ESTABLISHED BY EUCLIDEAN DIVISION.** For factor a, a horizontal edge (x_0,x_1,0) belongs to a retained path exactly when x_1 is divisible by a. Its coarse owner is (floor(x_0/a),x_1/a,0). A vertical edge (x_0,x_1,1) belongs to a retained path exactly when x_0 is divisible by a, with owner (x_0/a,floor(x_1/a),1). Every other edge owns a distinct unused-singleton block. Retained and unused labels must have different types. Division in the parallel coordinate is floor division, with x=aq+r and 0<=r<a. For example, at a=2, the horizontal edge (-1,0,0) belongs to owner (-1,0,0), whose fine path anchors are -2 and -1; truncation toward zero gives the wrong block.

For any finite distinct-edge set D, group its edges by these owner labels. D is a union of complete retained paths exactly when it has no unused owner and every retained-owner group contains a distinct edges. Each retained owner has exactly those a possible edges, so this cardinality test also proves equality with the complete path. Its output is the set T of owner labels. The empty D is a valid union with T empty.

Fine translations not divisible by a preserve the input coefficient but can change its reference-block ownership and survival. Therefore all translation phases enter the source-instance enumeration literally. No phase average or a^2 multiplier is inserted.

## FA03. Exact moments and cumulants of repeated occurrences

**ESTABLISHED BY THE FAIR REFERENCE.** Label n source occurrences S_1,...,S_n, allowing repeated literal instances. For I subset {1,...,n}, let D_I be their symmetric difference and set m(empty)=1. Conditional on all touched retained parities being plus, the moment m(I) is one if D_I is a union of full retained paths and zero otherwise. An occupied unused sign has zero fair mean; a proper nonempty subset of a fixed-parity path is killed by flipping one included and one excluded sign. A complete path contributes its conditioned parity. This calculation includes the missing fine signs in a partially touched path through the reference; it does not replace that path by a shorter one.

At arbitrary parity y, each nonzero block moment is a coarse character. In a product over any partition of the occurrence labels, all surviving characters multiply to the character of D_full. Consequently the conditional joint cumulant is zero unless D_full=lift_a(T), and otherwise equals c_a(S_1,...,S_n)chi_T(y), where

\[
 c_a=\sum_{\pi\text{ partition of }\{1,\ldots,n\}}
 (-1)^{|\pi|-1}(|\pi|-1)!\prod_{I\in\pi}m(I).
\]

In particular c_a is an integer, even when input coefficients are rational. Repeated sources remain separate occurrence labels in every subset and partition; they are not replaced by their support union.

**ESTABLISHED BY PARTITIONING AT ONE DISTINGUISHED LABEL.** A useful exact recurrence avoids explicit partition generation. For nonempty I choose its smallest label r and define

\[
 c(I)=m(I)-
 \sum_{\substack{B\subsetneq I\\r\in B}}c(B)m(I\setminus B).
\]

The block containing r uniquely partitions every moment-cumulant term; the remaining blocks sum to m(I without B). The B=I term is c(I), because m(empty)=1. This proves the recurrence and its singleton base. Computing all subset moments and then increasing subset cardinalities returns c(full) exactly. Fewer than 3^n subset-pair contributions suffice, because the total sum over nonempty I of 2^(|I|-1) is (3^n-1)/2. This is a finite cost bound, not a polynomial-time claim.

## FA04. Connected occurrence graph and finite translation window

**ESTABLISHED UNDER THE ADMITTED CONDITIONAL-CUMULANT FORMULA.** Join two occurrence vertices when their source sets touch a common reference block. Equal literal instances still give distinct adjacent occurrence vertices. If this graph is disconnected, separate components use independent blocks under every conditional fair reference; their joint cumulant is zero. A filter based only on shared fine edges is invalid: two disjoint fine sources can meet the same retained path block.

Let d_max and s_max be the largest diameter and cardinality of the nonzero input shapes. For order n>=1 define

\[
 R_n=nd_{\max}+(n-1)(a-1).
\]

Consider a connected occurrence list producing nonempty output T whose canonical first edge is (0,0,i). Its first fine edge f_i=(0,0,i) belongs to D_full and hence to at least one occurrence. Root a spanning tree there. Starting at f_i, traveling within each visited source costs at most d_max in anchor distance. Crossing a shared reference block costs at most a-1, for either orientation, and costs zero for an unused singleton. The tree path to any source visits at most n vertices and n-1 connections. Every edge anchor of every source occurrence therefore lies in the Chebyshev box of radius R_n about zero.

The canonical first edge of a translated source S_j+v has anchor v and is one of its edges, even if other canonical shape coordinates are negative. Therefore every relevant literal source instance lies in the finite catalog

\[
 \mathcal C_n=\{S_j+v:j\text{ in the input library},\ v\in[-R_n,R_n]^2\cap\mathbb Z^2\}.
\]

This catalog may contain instances whose other edges extend farther; retaining them only overcounts possible candidates. It omits no contributing connected tuple. The proof covers repeated instances, both axes, every blocking phase and negative translations. It is a rooted support bound, not a finite-volume modification of the underlying infinite interaction.

## FA05. Complete multiset algorithm without extra multiplicities

**DEFINITION.** For each n=1,...,N and each output first-axis i, enumerate each multiset of cardinality n from C_n once. It may be prefiltered unless at least one occurrence contains f_i. Build its occurrence graph and discard disconnected candidates. Compute D_full; discard candidates not representing a complete path union and discard the empty output for this scalar-free operator. Require that the first output edge is literally (0,0,i), so T=can(T). Compute c_a by FA03 and add the following exact rational quantity to output coefficient T:

\[
 c_a\frac{\prod_{\tau}j_{\operatorname{shape}(\tau)}^{m_\tau}}
 {\prod_{\tau}m_\tau!},
\]

where tau indexes distinct literal translated source instances and m_tau their multiplicities. Sum all accepted orders and consolidate equal output supports, deleting exact zeros only after their contributions have been added.

**ESTABLISHED BY THE ORDERED CUMULANT COEFFICIENT.** The admitted degree-n coefficient is an ordered occurrence sum divided by n!. A fixed multiset has n!/product_tau m_tau! ordered versions. Their cumulant, source product and output support agree, so the displayed multiset weight is exactly their total. No factorial belongs to the number of input shape types; repetitions concern literal translated instances. There is also no multiplication by the number of possible roots or spanning trees: those prove connectedness and the finite window but are not terms in the coefficient formula.

Every contributing ordered list for a canonically anchored nonempty T is connected or has zero cumulant. FA04 puts its multiset in C_n; its canonical first axis uniquely selects one of the two passes. The moment and scalar filters remove only zero cumulants or the excluded empty character. Conversely every accepted multiset is a legitimate term of the admitted infinite coefficient formula. Thus the algorithm returns exactly the complete degree-n coefficient at every canonical nonempty support, and the full sum through degree N.

If instead one enumerates every support containing the origin and then adds its translated canonical versions, coefficients are multiplied by their incident translate count. That is not this algorithm. Canonicalization supplies the test T=can(T), not a license to accumulate all translated copies. Different fine phases producing genuine distinct source multisets remain distinct contributions; translation-equivalent output coefficients are represented once.

## FA06. Generated support bounds and finite termination

**ESTABLISHED BY SOURCE COVERAGE.** A surviving T obeys a|T|=|D_full|<=n s_max. The first fine edges of two output paths realizing its diameter can be joined through the same occurrence tree, which gives

\[
 a\operatorname{diam}(T)
 \le nd_{\max}+(a-1)(n-1).
\]

These are consequences of complete enumeration, not additional truncation rules. The output library through N is finite, translation invariant, and retains every generated many-body support allowed by the complete Taylor formula. Cancellation can lower its support count but does not justify dropping candidates beforehand.

For a nonempty input library of m shapes, |C_n|=m(2R_n+1)^2 because distinct canonical shapes cannot yield identical literal instances under different names. A conservative candidate count is twice binomial(|C_n|+n-1,n), for the two axes. Every candidate uses finite sets of at most n s_max edge occurrences, n occurrence vertices, at most 2^n moments and fewer than 3^n recurrence contributions. Integer factorials, integer cumulants and rational coefficient arithmetic have finite bit length at every finite n. This proves finite termination at each specified N. Explicit budgets must count or conservatively bound their actual candidate/subset/bit operations and can stop before completion. A partial table is not the complete order-N polynomial and must not receive its completed-order certificate.

## FA07. Complete omitted-order bound and tolerance termination

**ESTABLISHED FROM THE ADMITTED MULTILINEAR BOUND.** Let j=||J|| and x=K_a j<1. The current operator theorem gives degree-n norm at most (j/a)n x^(n-1). Therefore the exact complete polynomial Jhat_N returned above satisfies

\[
 \|R_aJ-\widehat J_N\|_{\kappa,\lambda}
 \le\tau_N(j):=\frac j a
 \frac{x^N[(N+1)-Nx]}{(1-x)^2},\qquad N\ge1.
\]

Differentiate the convergent geometric tail sum_(n>N)x^n=x^(N+1)/(1-x) to obtain the formula. Its positive-series representation makes it monotone in j and K_a. A certified upper norm and upper K_a with product below one therefore give a conservative upper tail. At j=0 all coefficients and the tail are zero; no undefined zero-order expression is required. The remainder covers every order above N and every omitted cardinality and range, not only a finite inspected family.

For a strict admitted input j<epsilon, the exact x is less than one half. Thus tau_N tends to zero, since a polynomial factor times x^N tends to zero. Given a positive rational tolerance, some finite N has tail strictly below it. The root's certified enclosure procedure can then resolve the strict input-radius, product and tolerance inequalities with sufficiently fine finite enclosures. Enumeration at this N terminates by FA06 with sufficiently large finite resources. A fixed finite precision or operation budget need not reach that point and must preserve its noncertificate outcome.

The exact output also has a strict radius margin: ||R_aJ||<=ell_a j+M_a j^2<epsilon. Since ||Jhat_N||<=||R_aJ||+tau_N, sufficiently large N makes the polynomial output lie strictly inside epsilon when iteration is requested. This establishes existence of finite resources for that admission, but does not replace root's actual finite-word error/domain checks.

## FA08. Finite reference meaning and scope of the certificate

**ESTABLISHED BY THE OPERATOR'S SCALAR-FREE TARGET.** Empty output characters contribute only scalar potential gauge and are excluded from this coefficient table. They have no canonical retained-edge root. One cannot sum the discarded scalar candidates from this rooted nonempty enumeration and call that sum a computed partition function or evidence. A finite probabilistic control must retain its complete normalized exponential sum separately. For example, a fine field on an unused fair bit has a nontrivial cosh normalizer while its retained scalar-free interaction is zero. Zero output coefficients therefore do not imply zero fine log evidence.

No finite fine boundary has been introduced in the Taylor enumeration: its finite window is proved to contain all order-n source tuples relevant to one canonical output. The conditional moments still include each whole retained reference path and every unused fair sign. Finite law controls with fixed fine exteriors must instead use their actual full touching sources reduced against that exterior and their actual partition factor. They may test local algebra, but do not silently replace the infinite translation-invariant input underlying Jhat_N.

**NOT-CLAIMED.** Rational Jhat_N is a certified approximation to the exact finite-amplitude interaction, not the exact law at nonzero input. The full law, every-exterior version and same-norm remainder come from the admitted operator theorem plus the complete enumeration, not from numerical coincidence. This author lane supplies no interval implementation, multistep certificate, runtime efficiency claim, new curvature term, critical universality or physical clock. Gauge-covariant dressing and normalized VFE retain their prior meanings.
