"""Assemble root-accepted current derivations and saved finite output; no scientific replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[4]
RUN = Path(__file__).resolve().parent.parent
VERIFY = ROOT / 'docs/verification/2026-09-09-finite-amplitude-rg'

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))

def dump(name: str, value: object) -> None:
    (RUN / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def main() -> None:
    assert not (RUN / 'evidence/native-intake.json').exists()
    contract = read(RUN / 'problem-contract.json')
    meta = {k: contract[k] for k in ('schema_version', 'contract_id', 'target_digest')}
    rows = read(RUN / 'agents/selected-final-proposals.json')['claims']
    coverage = read(RUN / 'agents/coverage-proposals.json')
    ids = [row['id'] for row in rows] + ['target']
    assert len(ids) == len(set(ids)) == 30
    assert set(ids) == {row['claim_id'] for row in coverage['claims']}
    assert not coverage['pending']
    assert all(sha(ROOT / p) == h for p, h in coverage['bindings'].items())
    deps = {row['id']: row.get('dependencies', []) for row in rows}
    deps['target'] = ids[:-1]
    assert all(set(row['dependencies']) == set(deps[row['claim_id']]) for row in coverage['claims'])
    commands = list(VERIFY.glob('*.command.json'))
    results = list(VERIFY.glob('*.result.json'))
    xmls = list(VERIFY.glob('*.xml'))
    assert len(commands) == len(results) == len(xmls) == 1
    command, result = read(commands[0]), read(results[0])
    assert result['returncode'] == 0
    assert all(result[k] for k in ('source_unchanged', 'driver_unchanged', 'contract_unchanged'))
    assert all(sha(ROOT / p) == h for p, h in command['source_sha256'].items())
    assert sha(commands[0]) == result['command_receipt_sha256']
    assert sha(xmls[0]) == result['junit_sha256']
    assert sha(xmls[0].with_suffix('.log')) == result['log_sha256']
    assert sha(VERIFY / 'run_finite_amplitude_tests.py') == command['driver_sha256']
    assert sha(RUN / 'problem-contract.json') == command['contract_sha256']
    for key in ('command', 'config'):
        assert hashlib.sha256(json.dumps(command[key], sort_keys=True).encode()).hexdigest() == command[key + '_sha256']
    assert command['config']['nodes'] == ['tests/rg_v2/test_finite_amplitude_rg.py']
    assert command['config']['maximum_independently_enumerated_signs'] == 6
    tree = ET.parse(xmls[0]).getroot()
    cases = tree.findall('.//testcase')
    names = [x.get('classname') + '::' + x.get('name') for x in cases]
    assert len(names) == len(set(names)) == 35
    assert not any(x.find(t) is not None for x in cases for t in ('failure', 'error', 'skipped'))
    assert {k: result[k] for k in ('tests','distinct_tests','failures','errors','skipped')} == dict(tests=35,distinct_tests=35,failures=0,errors=0,skipped=0)
    frozen = {
        'independent-initial-reconstruction.md': '7e417bb7fa59dcfc31d4e26b57e887c297db3c7f69870bb8cf2d997883635a58',
        'initial-proposals.json': '4b251f71b025c7c24a1e6b59bd32289c5c32dbdad052055de91af933921ca748',
        'finite-amplitude-construction.md': 'd7105bc7685caedb78e1563657d126e6bcadc050ce6bd5d524e09b53c53cd743',
        'author-claims.json': '4de96b0bcf89fb400287f930259f8942873b529d4015c4593b116299191c1068',
    }
    assert all(sha(RUN / 'agents' / p) == h for p, h in frozen.items())
    context = read(RUN / 'evidence/freeze-record.json')
    assert all(sha(ROOT / p) == h for p, h in context['existing_inputs_sha256'].items())
    bindings = set(coverage['bindings']) | set(command['source_sha256']) | set(context['existing_inputs_sha256'])
    bindings.update(p.relative_to(ROOT).as_posix() for p in (RUN / 'agents').iterdir() if p.is_file() and not p.name.startswith('next-'))
    bindings.update((RUN / p).relative_to(ROOT).as_posix() for p in (
        'evidence/freeze-record.json', 'evidence/root-execution-preflight.json',
        'evidence/root-result-readback.json', 'evidence/assemble_native_record.py',
        'evidence/run_structural_checks.py'))
    bindings.update((
        'docs/superpowers/plans/2026-09-09-finite-amplitude-rg.md',
        'docs/reports/2026-09-09-finite-amplitude-rg.md',
        'docs/verification/2026-09-09-finite-amplitude-rg/deliver_to_desktop.py'))
    intake = {**meta, 'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'accepted_current_scoped_evidence': True,
        'read_artifact_sha256': {p: sha(ROOT / p) for p in sorted(bindings)},
        'root_assessment': 'Root read the complete current mathematical derivations, independent initial/mature reconstruction, source, tests, driver, actual reused seams and raw packet. Exact translated occurrence enumeration, rational interval inequalities and domain-qualified induction prove the frozen local evaluator. No infinite or universal claim closes from the finite tests.',
        'independence_limit': 'Shared model family, context and filesystem; distinct persisted initial mechanisms and subsequent checks do not imply institutional or formal independence.',
        'scope': 'Frozen finite-amplitude evaluator only, conditional on the unchanged prior operator. Larger-basin entrance, critical/continuum and physical identification remain open. Next-discovery files are excluded from accepted evidence.',
        'finite_evidence': 'One 35-distinct-case packet; zero failure/error/skip, JUnit 0.100 seconds, 26 current source/config/premise bindings. No replay.',
        'user_excluded_not_run': ['tamper/corruption/forgery checks']}
    dump('evidence/native-intake.json', intake)
    raw = {p.relative_to(ROOT).as_posix(): sha(p) for p in VERIFY.iterdir()
        if p.is_file() and not p.name.startswith(('deliver_', 'delivery'))}
    science = {**meta, 'source_sha256': command['source_sha256'], 'raw_artifact_sha256': raw,
        'execution_history': [dict(path=results[0].relative_to(ROOT).as_posix(), sha256=sha(results[0]), **result)],
        'latest_cases': dict(distinct=35, passed=35, failed=0, errors=0, skipped=0, execution_total=35),
        'junit_cases': names, 'runtime': command['runtime'], 'config': command['config'],
        'user_excluded': ['tamper/corruption/forgery checks'],
        'unrun': ['old tests/producers', 'broad suite', 'Phase13', 'held S1-S3', 'large enumeration', 'GPU science'],
        'scope': 'Finite source controls only. Nonzero fiber comparisons check one retained coefficient, not the full infinite norm; the latter rests on its direct theorem.'}
    dump('evidence/scientific-record.json', science)
    for path in (commands[0], results[0], xmls[0]):
        (RUN / 'evidence' / path.name).write_bytes(path.read_bytes())
    evidence, claims, edges, attacks = [], [], [], []
    def ev(eid: str, kind: str, path: str, statement: str, conditions: list[str]) -> str:
        evidence.append(dict(id=eid, kind=kind, supports=True, scope=statement,
            side_conditions=conditions, artifact_path=path, artifact_sha256=sha(RUN / path)))
        return eid
    for row in rows:
        cid = row['id']
        conditions = list(row.get('assumptions', []))
        numeric = row['kind'] == 'NUMERICAL_OBSERVATION'
        if numeric:
            eids = [ev('raw-' + cid, 'NUMERICAL', 'evidence/scientific-record.json', row['statement'], conditions),
                ev('junit-' + cid, 'NUMERICAL', 'evidence/' + xmls[0].name, row['statement'], ['Retained sole 35-case packet; no replay.'])]
        else:
            if row['kind'] == 'CODE':
                conditions.append('Conditional source-to-algorithm identity with explicit charged-work and guarded-result scope; not universal host success or memory bounds.')
            eids = [ev('proof-' + cid, 'DERIVATION', row['proof_artifact'], row['statement'], [row['proof_section'], *conditions]),
                ev('independent-' + cid, 'DERIVATION', 'agents/coverage-review.md', row['statement'], ['Preserved initial construction followed by complete current per-claim reconstruction.'])]
            if row['kind'] == 'CODE':
                eids.append(ev('finite-' + cid, 'NUMERICAL', 'evidence/scientific-record.json', row['statement'], ['Finite controls supplement the source derivation.']))
        claims.append(dict(id=cid, kind='NUMERICAL_OBSERVATION' if numeric else 'MATHEMATICAL',
            statement=row['statement'], quantifiers=row.get('quantifiers', 'Every admitted finite input on the successfully completed source path, with all stated local premises.'),
            target_digest=meta['target_digest'], state='EVIDENCE_VERIFIED', assumption_ids=[],
            explicit_assumptions=conditions, evidence_ids=eids, bridge_premise_ids=[], falsifier=row['falsifier']))
    target = contract['target']
    claims.append(dict(id='target', kind=target['kind'], statement=target['statement'], quantifiers=target['quantifiers'],
        target_digest=meta['target_digest'], state='EVIDENCE_VERIFIED', assumption_ids=[],
        evidence_ids=[ev('target-proof', 'DERIVATION', 'construction-or-strongest-theorem.md', target['statement'],
            ['Only the frozen finite-amplitude target; prior exact local operator is explicit input. Full goal remains active.'])],
        bridge_premise_ids=[], falsifier=target['falsification_criterion']))
    for claim in claims:
        cid = claim['id']
        edges.extend({'from': cid, 'to': dep} for dep in deps[cid])
        attacks.append(dict(id='attack-' + cid, claim_ids=[cid], attack=claim['falsifier'],
            response='The current per-claim coverage reconstructs this failure condition from the named direct proof, literal source, or retained raw finite outcome with its premises explicit.',
            disposition='REJECTED', artifact_path='agents/coverage-review.md', artifact_sha256=sha(RUN / 'agents/coverage-review.md')))
    dump('claim-ledger.json', {**meta, 'assumptions': [], 'evidence': evidence, 'claims': claims})
    dump('dependency-dag.json', {**meta, 'edges': edges})
    reconstruction = dict(claim_ids=ids, method='Preserved contract-only ordered-catalog construction, then mature mathematical/source and saved-output reconstruction.',
        result='PASS', conclusion='Every frozen-target claim has a current scope-matched derivation or finite observation.',
        artifact_path='agents/coverage-review.md', artifact_sha256=sha(RUN / 'agents/coverage-review.md'))
    dump('adversarial-report.json', {**meta, 'attacks': attacks, 'independent_reconstruction': reconstruction,
        'oracle_erasure': {**reconstruction, 'method': 'Remove favorable expectations; reconstruct literal ownership, partition identities, connected completeness, multiplicities, positive-series bounds, strict domain and error induction. No assumed basin entry or fixed-budget success.'}})
    families = [
        ('literal-anchor-multiset-catalog', [x for x in ids if x.startswith('FA') and not x.startswith(('FAI','FIN'))], 'Finite connected-source radius and full literal multisets with exact labeled cumulants and factorials.'),
        ('independent-ordered-whole-source-catalog', [x for x in ids if x.startswith('FA') and not x.startswith(('FAI','FIN'))], 'Independent whole-source finite window, ordered occurrences and canonical output filtering; coefficient equality by ordered-to-multiset counting.'),
        ('connected-growth-interface', [x for x in ids if x.startswith('FG')], 'Full-block neighbor alignment, spanning-tree reachability and literal multiset deduplication; explicit interface to the complete catalog.'),
        ('rational-enclosure-word-bridge', [x for x in ids if x.startswith('CB')], 'Outward positive-series enclosures, full omitted-order tail and strict-radius finite-word induction.'),
        ('source-and-finite-controls', [x for x in ids if x.startswith(('FAI','FIN'))], 'Actual source-to-formula reconstruction and a single bounded independent-control packet.')]
    dump('approach-registry.json', {**meta, 'mechanism_families': [
        dict(family_id=fid, core_mechanism=mechanism, target_obligation_ids=cids,
            representation='Finite rational translation-orbit library approximating the admitted scalar-free infinite operator.',
            invariant_or_obstruction='Complete phases, labels, canonical output count, whole-norm tail and common local domain.',
            obligations=['Every quantified finite-amplitude premise in the frozen contract.'],
            bridge='Explicit complete catalog/growth correspondence and interval/domain proof.',
            failure_test='Missed or repeated coefficient, inward bound, invalid domain or false incomplete certificate.',
            verified_results=cids, open_gaps=[], novelty_fingerprint=mechanism + ' No novelty claim.',
            disposition='Established at its stated frozen local scope.') for fid, cids, mechanism in families]})
    strongest = 'Complete rational finite-amplitude local path-RG evaluation with certified whole-norm error, caller-increasable resources and domain-qualified finite-word propagation.'
    dump('release.json', {**meta, 'checkpoint': 'Root accepts current proofs/source/finite output; structural checkpoint pending.',
        'target_claim': 'target', 'terminal_status': None, 'certificate_claim': 'target',
        'strongest_result': strongest, 'unresolved_obligations': [],
        'limitations': ['Full RG goal remains active.', 'Larger physical-family basin entrance is not supplied.',
            'Critical/continuum theory and physical identification remain open.',
            'Finite tests do not prove the infinite norm estimate.', 'Scalar-free output supplies no original partition or VFE.',
            'Gauge, Fisher and base curvature retain separate geometric and probabilistic requirements.']})
    dump('evidence/native-adjudication.json', {**meta,
        'method': 'Root accepts direct derivations and saved mechanical output after independent reconstruction; no voting or inference of mathematical truth from a validator.',
        'claims': {c['id']: dict(state=c['state'], kind=c['kind'], evidence_ids=c['evidence_ids']) for c in claims},
        'counts': dict(claims=len(claims), evidence=len(evidence), edges=len(edges), attacks=len(attacks))})
    print(json.dumps(dict(accepted_artifacts=len(bindings), claims=len(claims), evidence=len(evidence),
        edges=len(edges), attacks=len(attacks), intake_sha256=sha(RUN / 'evidence/native-intake.json'))), flush=True)

if __name__ == '__main__':
    main()
