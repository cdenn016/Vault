# RG v2 deprecation audit and cleanup

The standalone RG v1 rescaling application is retired. The cleanup removes
23 files containing 9001 Python lines: one figure launcher, eleven exclusive
predecessor modules and eleven dedicated test files. It also removes two
unused helpers. Current RG v2 scientific code, configuration dictionaries,
fixtures, launchers and the retained exact-channel implementation are unchanged.

The audit baseline is `459aa48a2d5f07e655c686dca12e091f930a7bfa`.
Work is isolated on `codex/rg-v2-deprecation-audit-20260907` to protect
the active L32 producer and canonical Desktop WIP. The user authorized
deprecation and cleanup; this report covers lifecycle, dependencies,
contracts, file hygiene and evidence preservation. It does not claim a
new audit of all repository mathematics or a full-suite pass.

## Audit findings and disposition

| Finding or retention obligation | Independent verdict | Resolution |
|---|---|---|
| Retire the closed rescaling application and its dedicated tests. | Confirmed | Removed the exact 23-path set, including the dependent bidirected/plaquette controls. |
| Remove two unreferenced helpers. | Confirmed | Removed runtime._git_dirty and counterexamples.diagonal_spd_conditioning; the remaining ASTs are identical to baseline. |
| Preserve shared source and historical evidence. | Confirmed | Kept scale_cocycle.py and its laboratory/fixture, shared categorical spine, fixed-ray/CUDA worker protocol, Theory, source snapshots, figures, failed attempts and results. |
| Repair the obsolete legacy source boundary. | Confirmed | Listed only eleven retired package paths and pinned three specific approved source amendments; retained the remaining source, reverse-import and launcher/fixture checks. |
| Remove the unrestricted pytest recommendation. | Confirmed, medium | Root and RG v2 READMEs now direct users to permitted focused checks and current execution policies. |
| Mark withdrawn rescaling interpretations as historical. | Confirmed, medium | Added correction/recovery notices to the retained figure captions and old docs/ROADMAP.md, pointing to STATUS section 16 and the republication JSON. |

The [independent source review](evidence/2026-09-07-deprecation/independent-review.md)
contains the source locations, negative-search scope and limits for each
verdict. Its two medium document findings were downgraded from the
investigators' high candidates: the old instructions require a reader's
action, and the historical documents already identify STATUS as authority.
No high or critical finding remained for adversarial challenge.

Five base investigators covered dead code, file hygiene, runtime wiring,
Python contracts and obsolete workloads. Three domain investigators covered
implementation wiring, numerical-oracle dependencies and research scope,
within the three-agent concurrency limit. GPT-6 authored the investigation
and cleanup; gpt-5.6-sol independently checked the proposal against baseline
source. The installed verification skill is disabled, so this task used
direct source and mechanical evidence without reactivating its ledger gate.

## Exact retirement and retained support

The [retirement inventory](evidence/2026-09-07-deprecation/retirement-inventory.json)
lists every removed path and its original source identity. The
[deprecation record](../deprecations/rg-v1.md) explains recovery from the
complete pre-retirement Git revision and the replacement entry points.
Version-one fixture/schema identifiers remain valid. The shared
blocked-contraction worker operation remains historical protocol
compatibility because the controller and worker also serve fixed-ray work.

The whole mixed-name lab-versus-theory regression file retired because
every scientific test depends on the removed rescaling fixture or modules;
no surviving independent test was discarded from it. Retained source
protection had a pre-existing mismatch for the approved lazy initializer,
before this cleanup. Its narrow amendment now also pins the two helper
removals. A reintroduced retired module still appears as an unexpected
current source path; the current map does not silently exclude it.

No tracked cache, scratch, build, backup or TeX auxiliary artifact was
established as another safe deletion candidate. Archived source duplicates
are retained evidence. The protected root RG_V2_ROADMAP.md was left alone;
current navigation is supplied through the edited README and program links.
Old figure pixels were not reinterpreted or regenerated. Their historical
captions are explicitly superseded where the corrected authority differs.

## Executed checks

One focused packet passed **16 tests**, with zero failures, errors or skips,
in **7.340 JUnit seconds** under isolated CPython 3.14.7, `-I -B -X dev`,
one numerical-library thread, automatic GC suspended and pytest's forced
teardown collection disabled. The fixed node list, runtime, source identities,
native logs and original JUnit are retained beside the
[execution receipt](evidence/2026-09-07-deprecation/focused/execution.json).

The packet checks absence of all retired paths, surviving static import
closure, registered launcher existence, the retained legacy source boundary,
four small RNG/provenance controls, the live diagonal-conditioning diagnostic
and seven exact-channel/cocycle controls. It executes no laboratory producer.
All recorded sources remained unchanged during this run.

The [completion checks](evidence/2026-09-07-deprecation/completion-checks.json)
confirm the exact deletion allowlist, preserved shared files, unchanged
RG v2 scientific/configuration/data/launcher paths and Theory, and unchanged
remaining ASTs in both helper modules. Canonical WIP and all 20 recorded active
science source entries match their prior records; the producer worktree
remains clean and its pipeline is still running.

No full suite, historical producer, GPU, process pool, new research sampling,
tamper, forgery or corruption test ran. Tamper checks are user-excluded/not run.
The current L32 precision result remains pending. External consumers of
undocumented predecessor modules are outside the tracked compatibility check.
