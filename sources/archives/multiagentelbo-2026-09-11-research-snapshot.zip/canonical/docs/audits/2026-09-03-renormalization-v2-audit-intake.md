# Renormalization v2 audit intake after Phase 13 closeout

Date: 2026-09-03
Live baseline: `184d956582b6a1beee45e1c22ff7818f20d56d21` (Phase 13 PR #37 merge).
Mode: read-only intake of an existing report, not a new audit or claim closure.

## Source and evidence boundary

The user-named report was read at
`C:\Users\chris and christine\Desktop\MultiAgentELBO\docs\audits\2026-08-30-renormalization-v2-deep-audit.md`.
It is untracked Desktop WIP, not a file supplied by the merged branch.
Its SHA-256 at intake was
`7FA0EE54A215E5E681139EBFDCEB9CE073572E0CCA2EBB3DC360D11BBA26FAED`.
The accompanying `claim-ledger-v3.json` has SHA-256
`13659849FA28FE5C5153F519D23F6AA1FEBB26C50FB74F4E9679F287991466DF`.
Both bind the historical audit to `05fe2f90e7c15d2c7c4d813bae71420fd7aeb062`.
Neither original nor any other Desktop WIP file was edited, staged, or copied
into the publication branch.

The ledger records RV2-01 as `EVIDENCE_VERIFIED` and RV2-02, RV2-04, and
RV2-05 as `INCONCLUSIVE`. Those are historical dispositions, not fresh
verification at this baseline. The narrative includes additional findings
and a refuted RV2-03 candidate; they are not new closures assigned by this
intake. No witness, test suite, replay, or tamper scenario was executed.

## What carries forward

| Existing audit item | Intake disposition and Phase 14 consequence |
| --- | --- |
| RV2-01, checkout-dependent Phase 12 source binding | Historically verified. The relevant Phase 12 test and `.gitattributes` are unchanged since the audit, including no LF rule for all specs. No fresh reproduction was run. Use Git object bytes for new Phase 14 source identity; do not introduce new physical-checkout-byte assumptions. A general Phase 12 repair remains separate work. |
| RV2-02, incomplete dirty provenance | Historically inconclusive. Phase 13's current publication boundary explicitly requires `git_dirty is False` and checks revision/config/theory inputs (`complete_carrier_covariance_experiment.py:606`). This is a narrower live boundary, not proof that the historical shared/Phase 12 issue is fixed. Keep complete explicit provenance for the new lab. |
| RV2-04, materialized zero complements | Historically inconclusive in the ledger despite the report's measurements. Phase 13 now represents absent sparse keys as exact zero (`complete_carrier_covariance_model.py:693`). Reuse that representation principle for route blocks; do not copy Phase 12's explicit complement representation. |
| RV2-05, V1 archival mismatch | Historically inconclusive. No V1 deletion or broad archival project is authorized by this closeout. Preserve V1 and shared dependencies; do not make their cleanup a prerequisite for the proposed additive Phase 14 work. |
| RV2-06, implicit compute omitted from identity | Narrative finding. The current common serializer still omits implicit compute (`src/multiagent_elbo/config.py:1103`); the intervening changes add Phase 13 theory registration, not a general identity repair. Phase 14 should explicitly record effective compute settings and actual worker resolution before execution. |
| RV2-07, nonoperative exact-lab numerics | Narrative finding. New metadata must distinguish exact arithmetic authority from reporting-only numerical settings. Do not imply a tolerance changes an exact-rational result. |
| RV2-08 and proposed adversarial packet scenarios | Outside the user's authorized execution policy. No tamper scenarios will be invoked or added as milestone blockers. Normal non-mutating integrity checks remain permitted. |

The original report fenced off then-unfinished Phase 13, so its Phase 13
compatibility section is a list of requirements, not findings against the
implementation now merged. Its global mixture, sector-support, and `III`
projection requirements remain relevant to interpreting the retained results.
Operator acceptance does not supply the missing independent relocated replay
or establish any additional theorem.

## Decision

Do not reopen the expensive Phase 13 producer or perform an unrelated audit
remediation sweep. Prepare the smallest next design using the current
sector-aware, exact sparse interfaces and preserve the historical caveats.
The [Phase 14 design gate](../superpowers/specs/2026-09-03-rg-v2-phase14-sector-quotient-design-gate.md)
does this by putting cross-sector admission ahead of full-carrier work.

The old Desktop Phase 14 and Phase 15 drafts remain unmodified proposals.
The Phase 14 draft's hard elapsed caps, inherited mutation count, and
adversarial publication workflow are not adopted. Phase 15 is not started.
