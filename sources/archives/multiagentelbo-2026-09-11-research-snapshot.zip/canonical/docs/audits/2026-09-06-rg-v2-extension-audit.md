# RG v2 extension audit: verified scoped findings

Date: September 6, 2026; verification closed September 7. Eleven investigator reviews, two independent code/math views and separate adjudication are complete. The four code observations below and the scoped mathematical claim are EVIDENCE_VERIFIED at the frozen audited revision. The deterministic validator exited zero before official activation closeout. This does not certify every historical RG v2 path or close the distinct Phase 21 all-parameter obligation.

## Scope and revision

The audited source is bfeeb2b7eb22e2d454c1db946d42000bb1273939 in artifacts/codex-worktrees/phase15-design-20260904. Its frozen binding is git:bfeeb2b7eb22e2d454c1db946d42000bb1273939:sha256:f78bce9a5b332636ef331a8db6f09dc2126beb81e63e000e355e2c5e59b94aeb. Science was committed at 1ffc01a6d4c13a581f26fe0ef5b5a7f1c3396a75; the following bfeeb2b commit retained results and E6 admission documents.

Review covered the completed E1-E6 extension program, with source and mathematical depth concentrated on the new E4b/E5b/E5a operations, E6 transfer argument, and the earlier E1 sampling, E2 Gaussian/mixture and E3 geometry interfaces. It did not reproduce every historical RG v2 phase, rerun a complete carrier, or close Phase 21's separate all-parameter obligation. Each archived investigator report specifies its actual inspected scope.

The author and investigators used GPT-6 Astra. GPT-5.6-sol and fresh GPT-5.5 contexts independently assessed the code observations and mathematical claim in reversed comparison order. A separate GPT-5.6-sol adjudicator checked current domain-eligible evidence and assigned closure states. Both CLI sessions exited zero with unchanged source binding. The initial export rejections were resolved by explicit user approval and, for the mathematical source bundle, byte-identical public GitHub source evidence after the approved push.

## Adjudicated code observations

The four observations below are EVIDENCE_VERIFIED with low severity. Both independent views support their exact scoped statements. No scientific-result failure or high/critical candidate was established by these reviews.

| ID | Observed behavior | Adjudicated assessment | Practical limit and proposed response |
|---|---|---|---|
| RGV2-A1 | The three new direct launchers do not establish disabled automatic GC or the isolated/development flags used by retained execution | EVIDENCE_VERIFIED; low | A public-interface reproducibility limitation. The design's execution paragraph scopes those flags to tests/retained pilots, and the actual retained driver satisfies it. No crash or retained-contract violation is established. Specify a usable supported public path before adding enforcement. |
| RGV2-A2 | The ring case's max_integer_bits field measures A^(N-1) while the computation also forms A^N | EVIDENCE_VERIFIED; low | At active N=2, r=2 the values are 4 versus 8 bits; at r=3 they are 5 versus 11. Separate arithmetic guards remain. Rename the field or define and calculate its intended coverage. |
| RGV2-A3 | E2b-four gauge comparisons reconstruct unchanged original-side moments 384 times for 48 distinct setting/level/law objects | EVIDENCE_VERIFIED; low | There are 336 duplicate constructions. Their runtime share and the speedup from reuse are unmeasured. Consider narrow reuse before a study that needs it; preserve fresh transformed-side comparisons. |
| RGV2-A4 | Nonexact E2b-four observables repeatedly build the same token-dependent weight enclosures and base powers | EVIDENCE_VERIFIED; low | Readback identifies 25,600 such records across the saved shards, with no token variation within the relevant law/shard. Preserve outward rounding, operation order and bit accounting if reusing them. Function-call counts are not timing measurements. |

A1 is located in the three reciprocal-memory/path-resolution/finite-volume launchers, rg_v2/remaining_extension_experiment.py:257 and driven_reference_experiment.py:95. An executed AST/stubbed-main probe reached each fake runner once without importing or running science under enabled GC. A2 is at finite_volume_model.py:135; the independent verifier reproduced the two small integer-size discrepancies. A3 is at four_link_mixture_experiment.py:359 and four_link_mixture_model.py:218. A4 is at four_link_mixture_model.py:199-205 and the moment-shard output loop at four_link_mixture_experiment.py:381-394. Current source, configurations and retained record hashes were checked; no performance benchmark was run.

The original base reviewers and GPT-5.5 recommended medium severity for A1/A3/A4; GPT-5.6-sol recommended low. The adjudicator resolved severity from demonstrated impact: the evidence establishes interface, diagnostic and duplicate-construction behavior, without a scientific failure, reproduced crash or measured material slowdown. Both views support the exact claims, so no substantive unresolved criterion disagreement remains. Proposed future timing or policy work is distinct from an obligation needed to close these scoped observations. No high/critical challenge was required or recorded as executed.

## Mathematical and scientific review

RGV2-M1 is the precise statement that the declared positive D4 vertex/edge nearest-neighbor family has normalized limiting free energy -log(rho(A)/16), real analytic at every finite real r>0, under either open boundaries or the uniform average of all eight labeled ring holonomies. It is EVIDENCE_VERIFIED from the tracked derivations and two independent reconstructions. Root/link-reference normalization, positive Perron amplitudes and analytic simple-eigenvalue dependence establish the thermodynamic limit. The exact executable transfer constructor accepts positive integers; the all-real-r statement concerns the mathematical monomial extension. That code-domain limit is retained as counterevidence and does not refute the scoped theorem. No finite-N equality, singular-endpoint result, physical RG generator or universality claim follows.

No domain reviewer established a defect in the inspected exact memory elimination, finite-time Euler bound, Gaussian normalization/mixture moments, contextual jets or gauge quotient semantics. Those negative review results do not certify uninspected paths. The reviews preserve the distinctions between chosen dynamics and derived physical VFE, projected one-time laws and complete path laws, context and RG depth, coordinate cumulants and full-law approximation error, sampling resolution and RG scale, and a particular noncritical model and a universal no-go theorem.

## Investigators and evidence

| Investigator | Inspected emphasis | Result in its bounded scope |
|---|---|---|
| code-reviewer | New runner/config/artifact paths and Gaussian controls | No candidate |
| debugger | Runtime path, saved E4a inputs, exact transfer readback | A1 |
| python-pro | Config round trips and live shape/type contracts | A1 duplicate |
| refactoring-specialist | Orphans, accepted knobs and diagnostics | A2 |
| performance-engineer | Recorded cost and exact duplicate-work counts | A3, A4 |
| audit-gauge-theorist | D4 root/holonomy reference and E1b quotient | No candidate; explicit transfer derivation |
| audit-numerical-analyst | Rational resolvents, Euler/scalar enclosures and numerical authority | No candidate |
| audit-variational | Memory preparation term, rates, entropy and VFE scope | No candidate |
| audit-info-geometer | Gaussian/mixture laws, cumulants and Fisher interpretations | No candidate |
| audit-geometer | E3 charts, covariant jets, Fisher forms and transport | No candidate |
| audit-philosophy-of-science | Claim boundaries and discriminating next experiments | No candidate |

The [evidence archive](../verification/2026-09-06-rg-v2-audit-evidence/README.md) preserves the initial candidate ledger and original 49 records, plus actual second views, adjudicator records, normalization metadata and the [validated final ledger](../verification/2026-09-06-rg-v2-audit-evidence/verification/rg-v2-overnight-ledger-final.json). The zero-exit pre-closeout validation and official marker-release receipt are authoritative. A later validator attempt after marker removal failed because that marker no longer existed; its actual output remains a separately labeled historical record. Publishing documentation does not rebind the original evidence.

New bounded checks included exact N=3 transfer contractions; D4 geometric actions, composition and reframing; a symbolic projected resolvent with arbitrary initial law; off-grid geometry checks; Gaussian/mixed-cumulant identities; and source/data readback for the duplicate-work candidates. They were not retained-producer reruns. One numerical probe initially used a Decimal reference too coarse for an approximately 1e-298-wide interval; its first output was preserved and only the reference precision was increased. No scientific implementation or guard was changed to resolve that reference issue.

## Original execution results

The new implementation's original machine-readable JUnit records contain 31 focused tests and one separately executed retained test for each of E4b, E5b and E5a. All 34 tests have zero failures, errors or skips. The focused XML time is 0.248 seconds; the retained XML times are 1.678, 1.849 and 1.584 seconds. These are original implementation receipts, not a fresh audit-suite run.

E4b retains 12 projections and 180 resolvent comparisons; E5b retains 54 grid cases; E5a retains 30 volume cases and 55,296 direct smallest-volume enumeration visits. All three packets have 12 files and byte-identical canonical ignored copies. No passing experiment was repeated for this audit.

Tamper, forgery, corruption and malicious-packet checks are user-excluded/not run. No full suite, GPU, pool or new large benchmark ran. Phase 13 remains operator-accepted with incomplete automated publication certification; the old publication producer was not invoked.

## Next work and publication status

The [post-audit program](../research-plans/2026-09-06-rg-v2-post-audit-program.md) gives task-level priorities: interface/diagnostic clarity, Phase 21 adjudication, a hierarchy-mechanism decision, controlled memory approximation, E1 precision, E2 law-approximation bounds, conditional computation reuse, matched-distance/holonomy controls and E6 admission.

The completed extension commits are bc25bdf, 1ffc01a and bfeeb2b on codex/rg-v2-phase21-20260905. The user approved publication to public cdenn016/MultiAgentELBO on September 7, and those commits were pushed before final documentation integration. This audit and the next-work plan accompany that publication. PR #51 and 574b012 refer to the earlier completed handoff.

The original artifact binding was checked before and after independent verification, then released through the official hook after successful adjudication and validation. The publication adds documentation to that source and preserves the accepted ledger as historical evidence. The 35 pre-existing protected WIP paths are separate from the task-owned documentation. Actual merge and canonical-Desktop fast-forward completion are recorded in the task worktree at artifacts/remaining-publication-20260907/completion.json; a changed Git ref alone does not constitute that handoff.