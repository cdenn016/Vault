from fractions import Fraction as F
import json
from pathlib import Path

def factors(n):
    out = {}; d = 2
    while d*d <= n:
        while n % d == 0:
            out[d] = out.get(d, 0)+1; n //= d
        d += 1
    if n > 1: out[n] = out.get(n, 0)+1
    return out

def logs(terms):
    out = {}
    for weight, ratio in terms:
        for n, sign in ((ratio.numerator,1),(ratio.denominator,-1)):
            for prime, exponent in factors(n).items():
                out[prime] = out.get(prime,F(0))+weight*sign*exponent
    return {str(k):str(v) for k,v in sorted(out.items()) if v}

p=[F(i+1,36) for i in range(8)]; q=[F(8-i,36) for i in range(8)]
result = {}
for mask in (1,2,3):
    fibers = [[i for i in range(8) if i & ~mask == t] for t in sorted({i & ~mask for i in range(8)})]
    terms=[(qi,qi/pi) for qi,pi in zip(q,p)]
    cond=[]; coarse=[]; fisher=F(0); lost=F(0)
    score=[qi/pi-1 for qi,pi in zip(q,p)]
    unequal=0
    for f in fibers:
        Q=sum(q[i] for i in f); P=sum(p[i] for i in f)
        coarse.append((-Q,Q/P))
        cond.extend((-q[i],(q[i]/Q)/(p[i]/P)) for i in f)
        unequal += any(q[i]/Q != p[i]/P for i in f)
        h=sum(p[i]*score[i] for i in f)/P
        fisher += P*h*h
        lost += sum(p[i]*(score[i]-h)**2 for i in f)
    residual=logs(terms+coarse+cond)
    fisher_residual=sum(pi*h*h for pi,h in zip(p,score))-fisher-lost
    assert residual == {} and fisher_residual == 0 and unequal == len(fibers)
    result[str(mask)]={'kl_chain_prime_log_residual':residual,'exact_zero_baseline':True,'unequal_conditional_fibers':unequal,'fiber_count':len(fibers),'fisher_conditional_variance_residual':str(fisher_residual),'fisher_loss':str(lost)}
result['scope']='Independent eight-sector exact arithmetic; masks 1,2,3; no decorated Phase14 admission or suite.'
Path('.verification/astra-audit/info-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
