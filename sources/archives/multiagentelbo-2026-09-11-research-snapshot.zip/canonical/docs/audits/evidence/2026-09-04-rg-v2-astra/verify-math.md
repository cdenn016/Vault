# Independent mathematics and source verification

Verifier model: Sol. Work under review: Astra. Artifact revision: git:89b76447d11567c52980471e580bf325f90d35bc:sha256:5929e6800eb9c907cd4e36e07cffc3ce29755683a9960d5ffe8798ba5cac90cf.

The gate capture returned the exact pin before review. Validate rejected only unfinished CANDIDATE states, not drift. No ledger state is assigned.

## RG2-09

Result: support.

Because eta_l is part of random Y_l and the text retains the joint law of (R_l,eta_l), the marginal law is P(I,J)=sum_ij E[eta_ij(Y) K_ij(I,J|Y,R)]. Pulling eta outside, as printed at lines 384--406, requires determinism or eta-assignment independence; endpoint independence given R does not supply that.

The six-vertex derivation is valid apart from its numerical execution. Give two states mass 1/2. State 0 has eta=delta_(2,3) and A={1,2,3},B={4,5,6}; state 1 has eta=delta_(5,6) and A={1,5,6},B={2,3,4}. Anchors 1 and 4 prevent a parent-label swap. Both arcs are non-self. Hard assignments are deterministic given R, hence conditionally independent. The common recognition-independent kernel chooses the partition from the fine state; generative, posterior, and recognition laws may be identical.

The true (AA,BB) pushforward is (1,0); the displayed factorization is (1/2,1/2), exact TV residual 1/2. A fixed-partition control removes the discrepancy.

A charitable conditional interpretation fixes Y=y and averages only channel randomness conditional on y. That narrower formula is valid. The text omits this conditioning, identifies mu as the input law being pushed, and calls the result the coarse event law. Thus the printed general marginal identity is defective, while fixed-eta and explicitly conditional versions remain valid. No executable defect is established.

Criteria: statement_precision=adequate, assumptions=strong, derivation_validity=strong, source_scope=adequate. Evidence: RG2-09-proof; numerical IDs are not proof evidence.

## RG2-08

Result: support.

The reproduced excerpts and hashes establish drift. Vault lines 3092--3100 say every nonrescaling premise is satisfied. Repository lines 3108--3123 leave equivariant conditional versions and rescaling kernels open and deny that finite constructions discharge either. This is source drift only. The external vault is outside the Git digest; the pinned reproduced-source record supplies provenance.

Criteria: quotation_fidelity=strong, freshness=adequate, source_scope=strong, claim_precision=strong. Evidence: RG2-08-source.

sector-derivation.md is sound in its finite positive-law deterministic-map scope and does not establish Phase 14 admission.
