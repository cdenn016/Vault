# RG v2 Phase 14 sector-quotient design gate

Date: 2026-09-03
Status: APPROVED by the user on 2026-09-03; implementation plan authorized;
no implementation started.
Source baseline: `184d956582b6a1beee45e1c22ff7818f20d56d21`.
Approval-host revision: `89b76447d11567c52980471e580bf325f90d35bc`.
Predecessor status: Phase 13 operator-accepted; automated publication certification incomplete.

## Objective and authority

Recommend one authored, deterministic sector quotient on the finite
complete-carrier RG diagram. Keep the existing controls, gauge group,
microscopic state content, branches, exact arithmetic, and Phase 1–13
scientific behavior. The new question is whether information-losing
cross-sector channels can be constructed through explicit equivariant maps
while preserving direct/staged composition and the required probability-law
identities.

The current roadmap names the Phase 14 design gate but does not prescribe
its mechanics. This recommendation refines the user's untracked
`2026-08-31-rg-v2-phase14-complete-carrier-sector-quotient-design.md`
(SHA-256 `5D0E143C3F0CEC0958DA29F4D25356DFAC3EE5D54F7DAD234CF6069535D19690`),
rather than treating that draft as approved. The draft and its implementation
plan are preserved untouched at the Desktop checkout.

The [Phase 13 acceptance record](../../verification/2026-09-03-phase13-operator-acceptance.md)
and [audit intake](../../audits/2026-09-03-renormalization-v2-audit-intake.md)
define the predecessor evidence and remaining caveats. Repository
`Theory/SPEC.md`, `Theory/07b_agent_network_rg.tex`, and
`Theory/10_renormalization.tex` govern the scientific interpretation.
Research context was consulted read-only in `Gauge-Theoretic Multi-Agent VFE Model`,
`Renormalization group flow`, and `Staged hierarchy formation and RG composability`
under `C:\Users\chris and christine\Desktop\Research\wiki`.
No vault changes or new literature/proof claims are part of this proposal.

The live interfaces consulted are `complete_carrier_covariance_model.py`
(sector catalog, sparse mass lookup, and sector-local transform plans),
`complete_carrier_covariance_composition.py` (branch catalogs and `III`
projection), and `complete_carrier_covariance_experiment.py` (provenance
and source bindings), all under `rg_v2/` at the stated baseline.

## Recommended construction

Retain sector order `III, IIN, INI, INN, NII, NIN, NNI, NNN`.
For source sector `(a,b,c)`, use the authored maps

```text
r01(a,b,c) = (a,b,I)
r12(a,b,c) = (a,I,c)
r02(a,b,c) = (a,I,I)
```

These route tables satisfy `r02 = r12 o r01` and fix `III`. They are
declared choices, not routes selected by gauge covariance or data. Each
source sector has one target sector. Source sectors still partition the
carrier; after a many-to-one route, target preimages account for merged
sector mass. Eight distinct target sectors do not survive the quotient.

Use the live branch layout correctly: `L0`, `L1/A0`, `L1/A1`, and
`L2` each contain 4096 states with 512 per sector.
`L1/combined` contains 8192 states, with the retained branch label and
1024 states per sector. The route must preserve the `A0/A1` branch identity
and its declared mass.

For each needed sector pair and retained level/branch, construct an explicit
state/ordinal bijection `tau(s,t)`. The implementation must establish the
group-action intertwining square, compatibility with the existing structural
channels, and identity/inverse/composition consistency of these maps.
Equal sector sizes or matching ordinal positions alone are not evidence of
these properties. Existing Phase 13 transform plans deliberately remain
sector-local; they must not be widened to accept Phase 14 objects.

Lift each old supported sector block by relabeling its target through the
admitted map. Store only the eight source-to-route-target supported blocks.
The other 56 sector-pair blocks remain implicit exact zeros; do not construct
a dense carrier matrix or materialize the complement.

Do not retain the erased sector bits as hidden target marks. If an inherited
history variable retains them, the information-loss claim must be restricted
to a declared marginal or the proposed full-state quotient rejected. A
many-to-one sector table alone does not establish loss for the entire
augmented state or strict KL contraction for the chosen pair of laws.

## Architecture and first admission gate

Use a one-way additive dependency: Phase 14 may consume Phase 13's public
catalog, group-action, exact sparse-arithmetic, and law leaves; Phase 13 must
not import Phase 14. Preserve predecessor fixtures, validators, schemas,
oracles, and science modules. Minimal shared configuration/registry additions,
if required for the new experiment, must be additive and must not change
existing experiment behavior or relabel old evidence as current.

Start with a small model/admission module and focused checks. Add a quotient
composition/law module and a click-to-run laboratory boundary only when
admission passes. Keep route configuration editable through ordinary Python
dictionaries. Do not reproduce the entire Phase 13 publication framework or
create separate modules merely to mirror its layout.

Before any full-carrier run, do the following in order:

1. Check the eight-row route tables, branch/catalog identities, exact source
   bindings, route composition, and `III` fixedness.
2. Construct a representative nonidentity intertwiner and check its action
   and structural-channel squares on branch-local data. This is an early
   rejection check, not permission to assume every remaining pair works.
3. Establish coverage for all required pairs, levels, branches, and both
   controls. Use direct finite checks or a written exact reduction with
   explicit coverage; count the work before executing it. Do not call the
   existing full producer merely to prepare this admission gate.

If the proposed intertwiners or structural-channel squares do not exist,
reject this route-lift design and report the obstruction. Do not substitute
a nonequivariant relabeling or silently choose another scientific model.
No admission check has been executed for this design proposal.

## Verification proportional to the new claim

After admission, test the new behavior: exact row normalization; graph-of-route
support; direct/staged kernel and law equality; common recognition-independent
pushforward of generative, selected-posterior, and recognition laws;
conditional relative-entropy/data-processing accounting with explicit support
conditions; identity-route recovery of Phase 13; and source-first `III`
compatibility with Phase 12. Conditioning on `III` after globally merging
sectors is not a substitute for that source-first projection.

Keep the observation labels and conditioning events declared by Phase 13.
Reconstruct target posteriors by Bayes' rule from the pushed generative joint,
then check the claimed posterior transport. Report the actual information
loss; claim strict positivity only where its support/conditional-law
conditions are established, not merely because the route merges labels.

Use the two existing declared controls. Start with focused in-memory
scientific checks, then run a full-size positive calculation only when it
answers a named obligation that the focused checks cannot establish.
A repeated Phase 13 producer, a full repository suite, and a copied
24/32-case mutation matrix are not prerequisites. No tamper checks will be
created as completion gates or invoked, directly or indirectly.

Treat the old draft's 72,202,414-visit total as historical Phase 13 accounting,
not a proven Phase 14 budget: new cross-sector squares need their own
coverage accounting. Reuse old outputs only as revision-bound predecessor
inputs or unchanged evidence; they cannot establish a new quotient claim.
The missing Phase 13 automated envelope must not be manufactured or demanded
again solely to start this already-authorized design process.

For any needed long calculation, preserve each completed stage's ordinary
results, source/config hashes, counters, and failure logs immediately.
Continuation may reuse only a completed stage whose input/source binding
still matches. Do not introduce a general resumable certification framework
or an all-or-nothing outer test that discards completed work.

CPU `int`/`Fraction` remains the exact scientific authority. Use at most
12 science workers and 14 live processes, preserving the pinned runtime
containment where applicable. CUDA is available but is not a replacement
for exact rational arithmetic. All elapsed values are reporting only; there
is no hard time cap or guessed completion time. Keep sparse storage and
explicit memory/output budgets, with the existing 128-MiB packet bound as
the starting artifact budget. A necessary larger budget requires a documented
scope decision, not a timeout or silent relaxation.

Source identity uses Git object bytes with separately labeled physical-file
hashes. Record effective compute settings and actual resolved workers before
execution. These rules avoid copying the specific provenance and resource
problems identified in the existing audit without making broad Phase 12 or
V1 remediation a prerequisite.

## Alternatives and nonclaims

Keeping the identity route is a compatibility control, not new quotient
behavior. An arbitrary stochastic sector mixer is deferred because it changes
branching/support accounting and needs its own law design. Widening Phase 13
in place is rejected because it erases the predecessor's sector-preserving
contract.

This phase would establish only the declared finite conditional construction.
It would not establish a canonical sector choice, sector conservation from
covariance, physical superselection, autonomous RG flow, fixed points,
stability/attraction, universality, arbitrary graphs or depth, a continuum or
thermodynamic limit, physical time, or a continuous-group/GPU certificate.

## Approval record

The user approved this narrowed Phase 14 design and its admission-first
execution order on 2026-09-03, and requested the task-level implementation
plan. The authoritative plan is
`docs/superpowers/plans/2026-09-03-rg-v2-phase14-sector-quotient-implementation.md`.
The older Desktop implementation plan is not executable authority for this
revised scope. This approval and planning update do not themselves start
Phase 14 implementation. No Phase 14 code, test, producer, or experiment was
run while recording the approval or writing the plan.

The recommendation incorporates separate mathematical-scope, live-architecture,
and resource/verification advisory lanes. Their agreement is design input,
not executed evidence or a theorem.
