# Independent code verifier view

Verifier model: Sol. Author model: Astra. Cross-model independence is satisfied.

Artifact binding: ok. Live, ledger, and active marker all equal git:89b76447d11567c52980471e580bf325f90d35bc:sha256:5929e6800eb9c907cd4e36e07cffc3ce29755683a9960d5ffe8798ba5cac90cf. The closure ledger is still in candidate assembly; this view assigns no ledger state.

The authorized underflow command ran once and exited 0.

| Claim | Result | execution | input_output | configuration_scope | reproducibility |
|---|---|---|---|---|---|
| RG2-01 | support | strong | strong | adequate | strong |
| RG2-02 | support | strong | strong | strong | strong |
| RG2-03 | support | weak | adequate | weak | strong |
| RG2-04 | abstain | absent | absent | adequate | absent |
| RG2-05 | support | adequate | adequate | strong | strong |
| RG2-06 | support | strong | strong | strong | strong |
| RG2-07 | support | adequate | adequate | strong | strong |

## RG2-01 - support

Pinned CPython 3.14.7 execution reproduced the boundary: powers 1073 and below returned zero diagnostics; at powers 1074, 1075, and 1100 exact evidence remained positive and posterior equaled recognition, while the float evidence cell was 0.0 and aggregate_population raised ValueError: posterior requires positive evidence. Source rg_v2/coarse.py:327-355 converts exact masses to float in mandatory _vfe_diagnostics, called at lines 388-392.

Evidence IDs: RG2-01-e1, RG2-01-e2. View IDs: none are defined in the candidate ledger.

## RG2-02 - support

Current source-binding JUnit records the named test failing on the pinned clean Windows checkout. The test hashes physical design bytes as a Git blob, while .gitattributes pins LF only for plan Markdown, not specs; physical CRLF bytes yield a different blob from the LF identity recorded in the plan. The existing test was inspected and not rerun.

Evidence IDs: RG2-02-e1, RG2-02-e2, RG2-02-e3. View IDs: none are defined in the candidate ledger.

## RG2-03 - support

Source contains hard raises at complete_carrier_covariance_assessment.py:1418-1419 and 5926-5934. The mechanical probe executes an exact AST extraction of the barrier with synchronization doubles and observes wait(120) returning when signaled and RuntimeError when false. It did not execute delayed startup, the readiness loop, a worker pool, or frequency behavior.

Evidence IDs: RG2-03-e1, RG2-03-e2. View IDs: none are defined in the candidate ledger.

Open obligation: A real delayed-worker execution is required to quantify occurrence or full-pool behavior; that broader claim is outside this evidence.

## RG2-04 - abstain

Source inspection shows collect_provenance may return dirty_tree_sha256=None and Phase 11/12 collectors validate config_hash and git_commit without requiring that digest. The claim has no current mechanical or reproduced_output evidence, and no permitted execution exercised the path. Source reasoning cannot close a code claim.

Evidence IDs: none. View IDs: none are defined in the candidate ledger.

Open obligation: Run a current non-destructive fixture that makes dirty-tree digest collection unavailable and observes Phase 11/12 admission, without corruption, forgery, or fake provenance.

## RG2-05 - support

The mechanical inventory hashes test_legacy_regression.py and finds run_rescaling_figures absent while run_scale_cocycle_lab.py is present. Independent source inspection confirms the capture and manifest include run_scale_cocycle_lab.py and omit run_rescaling_figures.py. This supports insufficiency as an oracle for the omitted laboratory, not a V2 scientific defect.

Evidence IDs: RG2-05-e1, RG2-05-e2. View IDs: none are defined in the candidate ledger.

## RG2-06 - support

The config probe constructs the active launcher config, runs Phase 13 validation, and serializes it. It observes compute_explicit=false, resolves the effective CPU float64 deterministic block, and observes canonical_has_compute=false. Source config.py:1103-1113 removes compute when implicit, while complete_carrier_covariance_experiment.py:429-443 enforces the effective default.

Evidence IDs: RG2-06-e1, RG2-06-e2. View IDs: none are defined in the candidate ledger.

## RG2-07 - support

The config probe constructs an alternate Phase 13 config with tolerance and SPD settings changed, validation accepts it, and the canonical hash changes. Its inventory finds config.numerics only in config roundtrip/default-comparison sites in the Phase 12/13 experiment modules; independent search agrees. No scientific runner ran, so this supports metadata/config reachability and absence of direct consumers in those modules, not whole-program dynamic noninterference.

Evidence IDs: RG2-07-e1, RG2-07-e2. View IDs: none are defined in the candidate ledger.

Open obligation: A dynamic paired scientific run is required for a stronger whole-program noninterference claim.

No prohibited or heavy checks were run.
