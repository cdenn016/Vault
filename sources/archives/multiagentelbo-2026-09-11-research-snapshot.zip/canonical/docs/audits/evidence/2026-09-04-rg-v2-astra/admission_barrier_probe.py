from pathlib import Path
import ast, hashlib, json
root=Path(__file__).resolve().parents[2]
path=root/'rg_v2/complete_carrier_covariance_assessment.py'
node=next(n for n in ast.parse(path.read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='_install_complete_carrier_admission_barrier')
for n in ast.walk(node):
    if isinstance(n,ast.arg): n.annotation=None
node.returns=None
seen=[]
class OS:
    @staticmethod
    def getpid(): return 4321
class Queue:
    def put(self,value): seen.append(['ready_pid',value])
class Event:
    def __init__(self,result): self.result=result
    def wait(self,timeout): seen.append(['wait_timeout',timeout]); return self.result
ns={'os':OS,'_initialize_complete_carrier_worker_process':lambda *args:seen.append(['initialized'])}
exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),ns)
results=[]
for outcome in (True,False):
    seen.clear()
    try:
        ns[node.name](None,None,None,Queue(),Event(outcome))
        result='returned'
    except RuntimeError as error:
        result=str(error)
    results.append({'event_signaled':outcome,'result':result,'calls':list(seen)})
report={'scope':'Exact AST-extracted barrier with inert initializer and synchronization doubles. No worker, sleep, or artifact modification; branch semantics only, not delayed startup frequency.','source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'results':results}
assert results[0]['result']=='returned'
assert results[1]['result']=='worker-admission barrier timed out'
(root/'.verification/astra-audit/admission-barrier.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
