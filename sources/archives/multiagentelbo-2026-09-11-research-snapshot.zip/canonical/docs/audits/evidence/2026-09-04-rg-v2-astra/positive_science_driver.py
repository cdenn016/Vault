from pathlib import Path
import gc
import json
import os
import sys
import time
import xml.etree.ElementTree as ET

gc.disable()
root = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(root), str(root / 'src')]
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
import pytest
class NoForcedGC:
    def pytest_configure(self, config):
        from _pytest import unraisableexception
        config.stash[unraisableexception.gc_collect_iterations_key] = 0
nodes = [
 'tests/rg_v2/test_population.py::test_population_constructors_normalize_exactly_on_admitted_boundaries',
 'tests/rg_v2/test_population.py::test_product_selector_forms_the_exact_canonical_tensor_product',
 'tests/rg_v2/test_population.py::test_declared_correlated_selector_has_exact_marginals_and_tv_half',
 'tests/rg_v2/test_population.py::test_dirac_boundary_has_one_coupling_and_zero_tv',
 'tests/rg_v2/test_population.py::test_observation_111_derives_exact_evidence_slice_and_posterior',
 'tests/rg_v2/test_population.py::test_product_and_correlated_selection_leave_p_evidence_and_posterior_fixed',
 'tests/rg_v2/test_population.py::test_observation_001_control_and_reordering_are_canonical',
 'tests/rg_v2/test_coarse.py::test_parity_aggregate_matches_full_exact_and_float_oracles',
 'tests/rg_v2/test_coarse.py::test_dirac_boundary_is_exactly_normalized_with_zero_diagnostics',
 'tests/rg_v2/test_coarse_agent.py::test_generative_constructor_runtime_oracle_and_literal_oracle_match_all_cells',
 'tests/rg_v2/test_coarse_agent.py::test_generative_constructor_builds_two_agents_one_record_and_exact_roundtrip',
 'tests/rg_v2/test_gauge_kinematics.py::test_cross_bundle_maps_are_equivariant_exact_one_sided_inverse_projector',
]
out = root / '.verification/astra-audit'
t0 = time.perf_counter()
exit_code = int(pytest.main(['-q', '-p', 'no:cacheprovider', '--junitxml=' + str(out / 'positive-science.junit.xml'), *nodes], plugins=[NoForcedGC()]))
summary = {'executable': sys.executable, 'version':sys.version, 'exit_code':exit_code, 'elapsed':time.perf_counter()-t0, 'nodes':nodes, 'tamper_checks':'user-excluded/not run'}
if (out / 'positive-science.junit.xml').exists():
    tree = ET.parse(out / 'positive-science.junit.xml')
    summary['junit'] = [dict(s.attrib) for s in tree.getroot().iter('testsuite')]
(out / 'positive-science.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
raise SystemExit(exit_code)
