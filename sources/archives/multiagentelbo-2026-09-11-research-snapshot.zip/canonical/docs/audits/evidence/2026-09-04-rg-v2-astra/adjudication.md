# Independent adjudication

The adjudicator assigned seven EVIDENCE_VERIFIED and two INCONCLUSIVE states after checking the artifact pin and recorded evidence. Root transcribed these decisions because the adjudicator encountered a sandbox write failure; the adjudicator remains responsible for the decisions. No source or test was changed.

Two recorded views were used per claim. Weakest criterion levels were retained. Support from both reviewers did not override weak evidence for RG2-03 or missing execution evidence for RG2-04. The mathematical closure links only the derivation; numerical agreement was not treated as proof. Model identity is recorded from explicit dispatch selection, not generic inherited model text.

## RG2-01

**EVIDENCE_VERIFIED**. Pinned CPython 3.14.7 execution reproduced the boundary: powers 1073 and below returned zero diagnostics; at powers 1074, 1075, and 1100 exact evidence remained positive and posterior equaled recognition, while the float evidence cell was 0.0 and aggregate_population raised ValueError: posterior requires positive evidence. Source rg_v2/coarse.py:327-355 converts exact masses to float in mandatory _vfe_diagnostics, called at lines 388-392.

Adjudicator evidence: RG2-01-e2.

## RG2-02

**EVIDENCE_VERIFIED**. Current source-binding JUnit records the named test failing on the pinned clean Windows checkout. The test hashes physical design bytes as a Git blob, while .gitattributes pins LF only for plan Markdown, not specs; physical CRLF bytes yield a different blob from the LF identity recorded in the plan. The existing test was inspected and not rerun.

Adjudicator evidence: RG2-02-e1.

## RG2-03

**INCONCLUSIVE**. Source contains hard raises at complete_carrier_covariance_assessment.py:1418-1419 and 5926-5934. The mechanical probe executes an exact AST extraction of the barrier with synchronization doubles and observes wait(120) returning when signaled and RuntimeError when false. It did not execute delayed startup, the readiness loop, a worker pool, or frequency behavior.

Adjudicator evidence: none eligible for closure.

Open obligation: A permitted non-destructive delayed-worker readiness/barrier fixture must establish the actual process-level rejection path. Current execution and configuration-scope criteria remain weak; no heavy or delayed pool was run.

## RG2-04

**INCONCLUSIVE**. Source inspection shows collect_provenance may return dirty_tree_sha256=None and Phase 11/12 collectors validate config_hash and git_commit without requiring that digest. The claim has no current mechanical or reproduced_output evidence, and no permitted execution exercised the path. Source reasoning cannot close a code claim.

Adjudicator evidence: none eligible for closure.

Open obligation: Obtain current non-forged reproduced output from a real provenance collection path where dirty_tree_sha256 is unavailable and Phase 11/12 admission still accepts. No filesystem corruption, fake provenance, or fault injection was run.

## RG2-05

**EVIDENCE_VERIFIED**. The mechanical inventory hashes test_legacy_regression.py and finds run_rescaling_figures absent while run_scale_cocycle_lab.py is present. Independent source inspection confirms the capture and manifest include run_scale_cocycle_lab.py and omit run_rescaling_figures.py. This supports insufficiency as an oracle for the omitted laboratory, not a V2 scientific defect.

Adjudicator evidence: RG2-05-e2.

## RG2-06

**EVIDENCE_VERIFIED**. The config probe constructs the active launcher config, runs Phase 13 validation, and serializes it. It observes compute_explicit=false, resolves the effective CPU float64 deterministic block, and observes canonical_has_compute=false. Source config.py:1103-1113 removes compute when implicit, while complete_carrier_covariance_experiment.py:429-443 enforces the effective default.

Adjudicator evidence: RG2-06-e2.

## RG2-07

**EVIDENCE_VERIFIED**. The config probe constructs an alternate Phase 13 config with tolerance and SPD settings changed, validation accepts it, and the canonical hash changes. Its inventory finds config.numerics only in config roundtrip/default-comparison sites in the Phase 12/13 experiment modules; independent search agrees. No scientific runner ran, so this supports metadata/config reachability and absence of direct consumers in those modules, not whole-program dynamic noninterference.

Adjudicator evidence: RG2-07-e2.

Closure is restricted to config admission and the inspected Phase 12/13 direct consumers. It does not assert paired-run whole-program noninterference.

## RG2-08

**EVIDENCE_VERIFIED**. The reproduced excerpts show the vault copy says every nonrescaling premise is satisfied, while the pinned repository copy leaves globally gauge-equivariant conditional versions and compatible rescaling kernels open and says finite constructions discharge neither. This verifies source drift only. The external vault is not covered by the Git digest; the pinned reproduced-source record preserves excerpts and hashes.

Adjudicator evidence: RG2-08-source.

## RG2-09

**EVIDENCE_VERIFIED**. For random fine state Y, the marginal law is sum_ij E[eta_ij(Y) K_ij(I,J|Y,R)]. The printed identity factors eta outside without determinism or eta-assignment independence. The exact six-vertex construction uses two non-self arcs and hard assignments deterministic given R, satisfying endpoint conditional independence, yet the true (AA,BB) law is (1,0) and the factorized law is (1/2,1/2), exact TV residual 1/2. Conditioning on realized Y repairs a narrower formula, but that conditioning is absent and conflicts with the description of mu as the input law being pushed. Fixed-eta and explicitly conditional versions remain valid; no executable defect is claimed.

Adjudicator evidence: RG2-09-proof.
