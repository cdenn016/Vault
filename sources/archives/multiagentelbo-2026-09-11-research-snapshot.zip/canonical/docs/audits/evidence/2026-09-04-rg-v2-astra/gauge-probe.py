import sys, json, hashlib
from pathlib import Path
from itertools import product
sys.path.insert(0, str(Path.cwd())); sys.path.insert(0, str(Path.cwd()/"src"))
from rg_v2.gauge_kinematics_fixtures import load_gauge_kinematics_fixture
from rg_v2.gauge_kinematics import gauge_transform_links, ordered_path_product, construct_action_channel
f, _, _ = load_gauge_kinematics_fixture('fgk_s3_noncommuting_holonomy_v1')
g=f.group
violations=[]
checks=0
for vals in product(g.element_labels, repeat=len(f.graph.vertex_ids)):
    active=dict(zip(f.graph.vertex_ids,vals))
    changed=gauge_transform_links(g,f.graph,tuple(active.items()))
    for path in f.graph.generator_paths:
        orig=ordered_path_product(g,f.graph,path)
        observed=ordered_path_product(g,changed,path)
        expected=g.multiply(g.multiply(active[path.target_vertex_id],orig),g.inverse(active[path.source_vertex_id]))
        checks+=1
        if observed != expected: violations.append((vals,path.path_id))
actions=0
for a,b in product(g.element_labels, repeat=2):
    for action in (f.belief_action,f.model_action):
        first=construct_action_channel(g,action,b)
        second=construct_action_channel(g,action,a)
        expected=construct_action_channel(g,action,g.multiply(a,b))
        actions+=1
        if first.compose(second)!=expected: violations.append(('action',a,b))
source_hashes={}
for name in ('07b_agent_network_rg.tex','06_general_coarsegraining.tex'):
    repo=Path('Theory')/name
    vault=Path('C:/Users/chris and christine/Desktop/Research/manuscripts/gauge_vfe_rg')/name
    source_hashes[name]={'repository':hashlib.sha256(repo.read_bytes()).hexdigest(),'vault':hashlib.sha256(vault.read_bytes()).hexdigest(),'physical_equal':repo.read_bytes()==vault.read_bytes()}
result={'fixture':f.fixture_id,'endpoint_conjugation_checks':checks,'row_law_action_order_checks':actions,'violations':violations,'source_hashes':source_hashes,'scope':'tiny exact S3 checks only; no producer or tamper checks'}
Path('.verification/astra-audit/gauge-probe.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))

