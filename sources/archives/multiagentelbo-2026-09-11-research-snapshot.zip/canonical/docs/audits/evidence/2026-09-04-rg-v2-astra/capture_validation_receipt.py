from __future__ import annotations
import json
import subprocess
from pathlib import Path

root = Path(r'C:\tmp\rg-v2-astra-audit-20260904')
evidence = root / '.verification/astra-audit'
command = [r'C:\Python314\python.exe', r'C:\Users\chris and christine\.claude\skills\verification\scripts\verification_gate.py', 'validate', '.verification/astra-audit/claim-ledger.json', '--cwd', str(root)]
result = subprocess.run(command, cwd=root, text=True, capture_output=True)
receipt = {'command': command, 'cwd': str(root), 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
           'artifact_revision': json.loads((evidence / 'claim-ledger.json').read_text(encoding='utf-8'))['artifact_revision']}
(evidence / 'adjudication-validation.txt').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode)
