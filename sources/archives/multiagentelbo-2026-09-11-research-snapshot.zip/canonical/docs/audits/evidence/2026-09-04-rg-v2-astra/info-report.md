# Information-geometry investigation

Revision: 89b76447d11567c52980471e580bf325f90d35bc.

No information-geometry findings.

## Inspected boundaries

The local sector derivation is correct within its stated boundary. For strictly positive finite laws and a deterministic retained statistic r, substituting q_s=Q_r q(s|r) and p_s=P_r p(s|r) directly yields D(q||p)-D(Q||P)=sum_r Q_r D(q(.|r)||p(.|r)). The summands vanish precisely when the corresponding conditional laws coincide. Cardinality reduction alone does not establish strict loss. The authored weights yield distinct q_s/p_s=(8-s)/(s+1) at all eight sectors, so every nontrivial fiber has strict loss. A record disclosing the discarded sector restores recoverability; the result therefore concerns the declared marginal, as sector-derivation.md states.

The independent exact-arithmetic check in info-check.py verifies that identity as a zero vector of rational prime-log coefficients for masks 1, 2, and 3. It also verifies the Fisher conditional-variance identity for the centered score h_s=q_s/p_s-1, with exact residual zero and positive losses 5067/12320, 1089/1120, and 16461/14560 respectively. These are local finite checks, not a differentiability proof for an arbitrary statistical family or Phase 14 admission.

The factorization used by the sector argument is executable: complete_carrier_covariance_composition.py:2122 constructs the prior as sector p times local weights; its observation likelihood at 2132 is independent of sector; recognition at 2154 is sector q times a local law. Thus the posterior preserves sector p. The common local divergence cancels when only a sector bit is erased while the local ordinal survives. A staged second quotient must use the already-pushed weights; the supplied derivation states this requirement explicitly.

At complete_carrier_covariance_composition.py:2232-2272, C01 retains the full ordinal in both branches, C12_combined maps its input modulo 4096, and C02 retains the ordinal. A deterministic ordinal decoder recovers the source of C01/C02. For C12_combined, the common input branch distribution (1/3,2/3) supplies a common reverse kernel for the authored q and posterior laws. Their KL defect is therefore zero. The formal entropy assembly at 2908-2985 uses q in the first slot and q-weighted conditional defects. No nonzero KL-loss conclusion is warranted from this Phase 13 construction, and none was identified in the inspected bounded claims.

finite_depth_stability.py:148-177 computes one-half the L1 row difference and takes its maximum, the forward-kernel Dobrushin coefficient. repeated_scale_model.py:601-618 composes right-acting rows in the correct first-then-second order. Prefix submultiplicativity is checked at finite_depth_stability.py:211-213. Gauge commutation is checked separately at 424-447, and the final declaration at 767-812 is explicitly a six-step finite-window claim. Theory/07b_agent_network_rg.tex:626-705 instead bounds the reverse conditional-expectation action operator. These operators must not be interchanged, but their distinction is not a defect in the inspected code.

Theory/06_general_coarsegraining.tex:85-165 retains finite-divergence hypotheses for its KL equality/recovery conclusion and distinguishes pairwise from common-family recovery. Lines 170-194 retain a normalized parameter-independent Markov channel and DQM for Fisher score projection. Theory/07b_agent_network_rg.tex:846-939 retains the extensive block lift and sqrt(b) bound; it does not incorrectly assert contraction of the unnormalized block score relative to one site's Fisher norm. Theory/07_general_renormalization.tex:1093-1139 explicitly restricts its nonlinear Gaussian pushforward discussion to a local approximation.

No suite, heavy producer, pool, publication workflow, corruption, forgery, or malicious-packet check was run. The only execution was the standalone eight-sector arithmetic script. No production files were edited. Existing positive tests were not rerun. Broader decorated carrier admission remains outside this check.
