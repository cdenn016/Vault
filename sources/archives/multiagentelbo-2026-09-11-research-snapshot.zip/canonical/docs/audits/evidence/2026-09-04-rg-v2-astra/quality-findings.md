# Quality, runtime integration, and provenance lane

Audited revision: `89b76447d11567c52980471e580bf325f90d35bc`, isolated checkout `C:/tmp/rg-v2-astra-audit-20260904`. Read-only source inspection; no producer, worker pool, publication run, tests, artifact mutations, or tamper checks executed. No new distinct defect established in this lane.

## Persistent candidate: dirty-tree provenance can remain unidentified in Phases 11 and 12

**Classification:** old persistent RV2-02, with Phase 11 propagation; not a new defect family.

**Location:** `rg_v2/full_state_covariance_experiment.py:596-603`; `rg_v2/finite_depth_stability_experiment.py:494-510`; `src/multiagent_elbo/runtime.py:72-85,157-177`.

**Severity:** medium.

**Evidence:** shared collector separately executes `git_status = _git_status_bytes(repo_root)` and `dirty_tree_sha256 = _dirty_tree_sha256(repo_root)`, then returns `"git_dirty": None if git_status is None else bool(git_status)` and `"dirty_tree_sha256": dirty_tree_sha256`. `_dirty_tree_sha256` returns `None` when Git queries fail or an untracked path cannot be read. Phase 12 checks `if provenance.get("config_hash") != digest: raise ValueError(...)` and `_require_git_object(provenance.get("git_commit"), "Phase 12 source revision")`, then freezes the mapping. Phase 11 likewise checks config hash and commit and returns the original provenance. Neither requires a usable status or dirty-tree digest.

**Reachability:** both click-to-run launchers construct their respective `ExperimentConfig` and invoke the public experiment. The collectors are unconditionally called on that path. A dirty checkout with an unreadable untracked file, or a failed second Git query, can therefore retain a valid commit and status while losing the additional executed-source identity. Static inspection confirms the old acceptance condition persists; this lane did not reproduce a filesystem error or inject altered provenance. A complete current execution claim requires an allowed reproduction; do not promote this source observation alone to EVIDENCE_VERIFIED code closure.

**Fix:** apply a shared fail-closed provenance admission requiring concrete status and dirty-tree digest values, including the clean empty-stream digest.

**Falsifies:** another reachable prepublication gate rejects the missing digest before finalization, or the supported collector contract proves that a successful status/commit plus missing dirty-tree digest cannot occur.

## Coverage and suppressed candidates

Inspected the common `contracts.py`, Phase 1 public runner and scientific preparation, config/publication seams across experiment modules, public Phase 13 config and runner, common `RunStore`, and shared provenance collector. Read repository instructions, RG v2 README, prior 2026-08-30 audit, Research index and hierarchy/composability theme. Searched all `*experiment.py` provenance/config consumers. Phase 13 has repeated clean-HEAD/source/revision checks before science, after science, and after preparation (`complete_carrier_covariance_experiment.py:515-527,3638-3647,3696-3703,3748-3755`); do not simply transplant the old dirty-tree finding into Phase 13.

The apparently incomplete `PopulationInference` constructor cross-field validation is suppressed: the actual aggregation boundary calls `_validate_inference`, which reconstructs recognition, observed evidence, and posterior and compares them before pushing (`coarse.py:118-159,358-365`). No reachable silent wrong inference was demonstrated.

Phase 13's accepted-but-nonoperative numerical tolerances resemble prior RV2-07; they are not reported as a new high-value defect. Omitted implicit compute values resemble prior RV2-06. Exact rational CPU computation and operator acceptance with incomplete automated certification are intentional scope boundaries.

A possible admission-timeout conflict was forwarded to the runtime/performance lane: `complete_carrier_covariance_assessment.py:1418-1419` uses `release_event.wait(120)` and raises on expiry. This lane does not claim it is a defect without checking the startup-barrier policy and parent lifecycle.

## Evidence limits

No dynamic scientific claim was closed. No source files were changed. Only this lane report was written. No tamper checks were run, including fake-provenance injection. Memory was used only to orient the repository workflow (`MEMORY.md:1-3`); current findings above are based on live source.
