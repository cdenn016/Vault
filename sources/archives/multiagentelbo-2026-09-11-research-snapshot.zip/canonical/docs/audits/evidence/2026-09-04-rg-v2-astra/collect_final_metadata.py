from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

AUDIT = Path(r'C:\tmp\rg-v2-astra-audit-20260904')
EVIDENCE = AUDIT / '.verification/astra-audit'
DESKTOP = Path(r'C:\Users\chris and christine\Desktop\MultiAgentELBO')


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_output(root: Path, args: list[str]) -> str:
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def collect() -> None:
    before = json.loads((EVIDENCE / 'desktop-wip-before.json').read_text(encoding='utf-8-sig'))
    checks = []
    for item in before:
        path = DESKTOP / item['path']
        expected = item['sha256']
        actual = sha256(path).upper() if path.is_file() else None
        checks.append({'path': item['path'], 'expected_sha256': expected, 'actual_sha256': actual,
                       'preserved': expected == actual and (expected is not None or not path.exists())})
    status = git_output(AUDIT, ['status', '--porcelain=v1', '--untracked-files=all'])
    preservation = {'desktop_wip_paths': len(checks), 'all_original_wip_preserved': all(x['preserved'] for x in checks),
                    'audit_source_status': status, 'audit_head': git_output(AUDIT, ['rev-parse', 'HEAD']), 'checks': checks}
    assert preservation['all_original_wip_preserved'], preservation
    assert not status, status
    (EVIDENCE / 'preservation.json').write_text(json.dumps(preservation, indent=2) + '\n', encoding='utf-8')
    suites = []
    total = Counter({'tests': 0, 'passed': 0, 'failures': 0, 'errors': 0, 'skipped': 0})
    for filename in ['positive-science.junit.xml', 'bugs-composition.junit.xml', 'source-binding.junit.xml']:
        root = ET.parse(EVIDENCE / filename).getroot()
        nodes = [root] if root.tag == 'testsuite' else root.findall('testsuite')
        counts = {key: sum(int(node.get(key, '0')) for node in nodes) for key in ['tests', 'failures', 'errors', 'skipped']}
        counts['passed'] = counts['tests'] - counts['failures'] - counts['errors'] - counts['skipped']
        counts['seconds'] = sum(float(node.get('time', '0')) for node in nodes)
        suites.append({'file': filename, 'sha256': sha256(EVIDENCE / filename), **counts})
        total.update({key: counts[key] for key in total})
    (EVIDENCE / 'test-summary.json').write_text(json.dumps({'total': dict(total), 'suites': suites}, indent=2) + '\n', encoding='utf-8')
    files = git_output(AUDIT, ['ls-files', 'rg_v2', 'src/multiagent_elbo/config.py', 'src/multiagent_elbo/runtime.py', 'tests/rg_v2', 'Theory', 'run_renormalization_v2*', 'AGENTS.md', '.gitattributes']).splitlines()
    records = [{'path': name, 'sha256': sha256(AUDIT / name)} for name in files if (AUDIT / name).is_file()]
    (EVIDENCE / 'source-hashes.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
    (EVIDENCE / 'runtime.json').write_text(json.dumps({'executable': sys.executable, 'version': sys.version, 'platform': platform.platform(), 'scientific_arithmetic': 'Python int/Fraction'}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'wip_paths_preserved': len(checks), 'source_files_hashed': len(records), 'tests': dict(total), 'suites': suites}, indent=2))


if __name__ == '__main__':
    collect()
