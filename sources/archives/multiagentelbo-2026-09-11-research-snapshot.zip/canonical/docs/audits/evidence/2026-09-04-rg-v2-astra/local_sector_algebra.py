from pathlib import Path
import ast
import json
from fractions import Fraction
root=Path(__file__).resolve().parents[2]
ns={'Fraction':Fraction}
want={'D4_VERTEX_ACTION_IMAGES','D4_EDGE_ACTION_IMAGES','D4_INCIDENT_FLAGS','D4_NONINCIDENT_FLAGS'}
for name in ('full_state_covariance_model.py','complete_carrier_covariance_model.py'):
    tree=ast.parse((root/'rg_v2'/name).read_text('utf-8'))
    for node in tree.body:
        if isinstance(node,ast.AnnAssign) and isinstance(node.target,ast.Name) and node.target.id in want:
            ns[node.target.id]=ast.literal_eval(node.value)
I,N=ns['D4_INCIDENT_FLAGS'],ns['D4_NONINCIDENT_FLAGS']
V,E=ns['D4_VERTEX_ACTION_IMAGES'],ns['D4_EDGE_ACTION_IMAGES']
violations=[]
for g in range(8):
    for k in range(8):
        i,n=I[k],N[k]
        gi=(V[g][int(i[0][1:])],E[g][int(i[1][1:])])
        gn=(V[g][int(n[0][1:])],E[g][int(n[1][1:])])
        if I.index(gi)!=N.index(gn): violations.append((g,k,gi,gn))
routes={'C01':[s&6 for s in range(8)],'C12':[s&5 for s in range(8)],'C02':[s&4 for s in range(8)]}
p=[Fraction(s+1,36) for s in range(8)]
q=[Fraction(8-s,36) for s in range(8)]
output={'scope':'exact local action reduction and authored sector marginal only; not Phase14 implementation or exhaustive decorated admission', 'action_checks':64,'violations':violations,'map_formula':'(v,e_j) -> (v,e_(j+2 mod 4))', 'route_composition':all(routes['C12'][routes['C01'][s]]==routes['C02'][s] for s in range(8)), 'routes':{}}
for name,route in routes.items():
    fibers={t:[s for s in range(8) if route[s]==t] for t in sorted(set(route))}
    evidence=[]
    for t,fiber in fibers.items():
        Q=sum(q[s] for s in fiber); P=sum(p[s] for s in fiber)
        cq=[q[s]/Q for s in fiber]; cp=[p[s]/P for s in fiber]
        evidence.append({'target':t,'fiber':fiber,'q_mass':str(Q),'p_mass':str(P),'q_conditional':list(map(str,cq)),'p_conditional':list(map(str,cp)),'unequal':cq!=cp})
    output['routes'][name]=evidence
assert not violations
assert output['route_composition']
(root/'.verification/astra-audit/local-sector-algebra.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
print(json.dumps(output))
