# RG v2 dead-code and duplication lane

Revision: `89b76447d11567c52980471e580bf325f90d35bc`, inspected at `C:/tmp/rg-v2-astra-audit-20260904` on 2026-09-04. Source-only investigation; no scientific execution, tests, producer, worker pools, artifact corruption, forgery, or malicious-packet checks were run. No implementation files changed.

Read repository AGENTS.md, root README.md, rg_v2/README.md, and the canonical Desktop 2026-08-30 deep-audit report. Consulted Research/index.md and Research/wiki/concepts/Renormalization-group flow of beliefs.md using the research-wiki skill; this supplied scope context, not correctness evidence. Memory registry search returned no relevant hit.

## Persistent candidates

### RV2-05 persists: legacy-rescaling capture still omits the actual V1 launcher
**Location:** tests/rg_v2/test_legacy_regression.py:66; tests/rg_v2/test_legacy_regression.py:255.
**Severity:** medium.
**Evidence:** The child bootstrap executes `z=runpy.run_path(str(root/"run_scale_cocycle_lab.py"),run_name="rg_v2_legacy_capture")` followed by `r=run_scale_cocycle_experiment(...)`. `_baseline_map` inventories `src/multiagent_elbo` and filters only `.py` and `_SEAMS`; `_current_map` similarly walks all installed package modules. `rg -n 'run_rescaling_figures' tests/rg_v2 rg_v2` returned no matches. These are current source observations, not a fresh execution of the legacy regression suite.
**Reachability:** `test_legacy_manifest_matches_fresh_baseline_and_current_captures` at line 348 invokes the baseline and current capture helpers. This remains insufficient evidence for authorizing retirement of run_rescaling_figures.py. It does not demonstrate a numerical defect in V2.
**Fix:** Capture the actual V1 launcher and its scientific outputs before using this manifest as its retirement oracle.
**Falsifies:** A currently executed capture row or regression test binds the actual V1 launcher and its output semantics.

### RV2-07 persists and extends into Phase 13: numerical settings are nonoperative exact-rational metadata
**Location:** rg_v2/full_state_covariance_experiment.py:423; rg_v2/complete_carrier_covariance_experiment.py:409; run_renormalization_v2_complete_carrier_covariance_lab.py:31.
**Severity:** low.
**Evidence:** The Phase 13 launcher exposes `NUMERICS = {"dtype": "float64", "atol": 1.0e-12, "rtol": 1.0e-12, "min_spd_rcond": 1.0e-12, "max_frame_condition": 1.0e12}`. Both Phase 13 reads are `asdict(config.numerics)` in common-config roundtripping at lines 409 and 433. Its scientific admission separately requires `theory.arithmetic != "exact_rational"` to be false at line 427. Search `rg -n 'config\.numerics' rg_v2/complete_carrier_covariance_experiment.py rg_v2/full_state_covariance_experiment.py` reports only those roundtrip locations and the analogous Phase 12 lines 423 and 441. `NumericsConfig` contains the common float/SPD fields at src/multiagent_elbo/config.py:307-312.
**Reachability:** The active Phase 13 launcher passes NUMERICS to ExperimentConfig.from_dicts at line 47 and then to the exact-rational runner. These values affect recorded config identity, not the exact Fraction calculations. This is a metadata clarity issue; no missing tolerance behavior is claimed, and no alternate config was executed.
**Fix:** Label these shared fields explicitly nonoperative for the exact-rational phases, or pin a canonical reporting tuple if desired without modifying the exact arithmetic.
**Falsifies:** A runtime scientific consumer of these fields exists in the exact-rational path, or the persisted config clearly labels their nonoperative status.

### RV2-06 persists: implicit effective compute settings are omitted from canonical config JSON
**Location:** src/multiagent_elbo/config.py:1103-1112.
**Severity:** low.
**Evidence:** `payload.pop("_compute_explicit")` and `if not config.compute_explicit: payload.pop("compute")`. The Phase 13 launcher omits COMPUTE, and its gate at rg_v2/complete_carrier_covariance_experiment.py:437-442 requires `config.compute_explicit` false and deterministic CPU defaults.
**Reachability:** The active Phase 13 path checks the injected defaults but canonical config serialization omits them. The source revision still identifies the default implementation, so this is incomplete resolved-config metadata, not absent source provenance.
**Fix:** Persist explicitly labeled effective-compute metadata while preserving historical identity rules when needed.
**Falsifies:** The canonical run config already includes the effective implicit compute block through another executed serializer.

## Suppressed candidates and coverage limits

A stdlib AST scan of all rg_v2 Python files identified accepted-unused arguments. Reviewed examples were contextual labels or redundant context parameters, not demonstrated lost numerical controls: `_push_augmented_law(law_kind, ...)`, `_generator_relations_passed(..., catalog_id, ...)`, `_config(..., topology, ...)`, and helper worker counts. No finding is assigned merely because an argument is unused.

A token-reference inventory over rg_v2, tests, src, and top-level Python entry points found four functions with no textual callers: `_relabel_law`, `_graph_from_catalog`, `complete_carrier_catalog_semantic_payload`, and `complete_carrier_closure_semantic_payload`. They are suppressed as reportable orphan findings: the first pair participate in automatic module-binding authority (`for name, value in sorted(vars(module).items())`, composition.py:1512), and the serializer pair are explicit public planned interfaces (Phase 13 implementation plan lines 482-485). No broken runtime or accidentally omitted scientific validation was established.

No new substantive dead-code/duplication finding was established by this bounded lane. Persistent candidates require independent verifier review before any closure classification; this report does not mark them EVIDENCE_VERIFIED.
