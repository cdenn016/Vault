from pathlib import Path
import gc, sys, json, hashlib, ast
from dataclasses import asdict
root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'src')]
gc.disable()
from multiagent_elbo.config import ExperimentConfig, canonical_config_json, config_sha256
from rg_v2.complete_carrier_covariance_experiment import _validate_run_config
namespace={}
source=(root/'run_renormalization_v2_complete_carrier_covariance_lab.py').read_text('utf-8')
for node in ast.parse(source).body:
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('RUN','THEORY','NUMERICS','OUTPUT'):
        namespace[node.targets[0].id]=ast.literal_eval(node.value)
def build(numerics):
    return ExperimentConfig.from_dicts(namespace['RUN'],namespace['THEORY'],numerics,namespace['OUTPUT'])
config=build(namespace['NUMERICS'])
_validate_run_config(config)
alternate=build({**namespace['NUMERICS'],'atol':0.5,'rtol':0.5,'min_spd_rcond':0.5,'max_frame_condition':1.0})
_validate_run_config(alternate)
report={'scope':'config validation and serialization only; no scientific runner invoked; no working config changed','compute_explicit':config.compute_explicit,'effective_compute':{k:str(v) if isinstance(v,Path) else v for k,v in asdict(config.compute).items()},'canonical_has_compute':'compute' in json.loads(canonical_config_json(config)),'baseline_config_hash':config_sha256(config),'alternate_numerics_accepted':True,'alternate_config_hash':config_sha256(alternate),'numerics_consumers':{}}
for name in ('full_state_covariance_experiment.py','complete_carrier_covariance_experiment.py'):
    report['numerics_consumers'][name]=[{'line':i,'source':line.strip()} for i,line in enumerate((root/'rg_v2'/name).read_text('utf-8').splitlines(),1) if 'config.numerics' in line]
legacy=(root/'tests/rg_v2/test_legacy_regression.py').read_text('utf-8')
report['legacy_capture']={'source_sha256':hashlib.sha256(legacy.encode()).hexdigest(),'mentions_run_rescaling_figures':'run_rescaling_figures' in legacy,'mentions_run_scale_cocycle_lab':'run_scale_cocycle_lab.py' in legacy}
(root/'.verification/astra-audit/config-and-legacy.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
