# RG v2 Python-contract lane

Revision: `89b76447d11567c52980471e580bf325f90d35bc`.

No actionable findings in the bounded inspected scope: `complete_carrier_covariance_model.py`, public contract and exact-expression portions of `complete_carrier_covariance_composition.py`, `repeated_scale_model.py`, `finite_depth_stability_model.py`, and catalog/composition/invariant helpers in `finite_depth_stability.py`.

The exact scalar and sparse-domain contracts checked against their normal public constructors consistently retain `Fraction` values, canonical support order, row normalization, and source/target label agreement. Optional generators and invariant-law channels are explicitly dispatched in the finite-depth runtime. Phase 13's fixed observation, sector, and branch constraints match its documented conditional fixture scope.

A possible sparse-composition closure issue was considered and rejected: two permitted input rows can mathematically compose to more than four nonzero targets, but the Phase 10 design explicitly caps every row at four outgoing atoms (`docs/superpowers/specs/2026-08-28-rg-v2-phase10-repeated-structural-cocycle-design.md:896`). This is the declared bounded-domain rejection, not a defect in the admitted fixture route.

Executed command:

```powershell
& C:/tmp/rg-v2-phase13-py3147-runtime-20260901/python.exe -I -B .verification/astra-audit/contracts_probe.py
```

The script injects this checkout and its `src` directory explicitly. Output:

```text
PASS: seven tiny positive exact arithmetic assertions; no producer or pool invoked
```

The independent two-state exact probes check stochastic matrix squaring, stationary-law push, exact stationary solve and residuals, one-step and squared-kernel Dobrushin coefficients, TV distance, and a cancelling prime-log expression. These are seven assertions, not a pytest/JUnit count and not a complete production certificate. All inputs were ordinarily constructed valid scientific objects. No malformed-object scenarios, tamper checks, corruption, forgery, worker pools, producers, or full suites were invoked.
