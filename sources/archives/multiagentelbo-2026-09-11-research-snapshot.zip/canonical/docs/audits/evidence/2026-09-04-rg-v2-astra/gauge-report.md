# Gauge/action/holonomy audit lane

Revision: `89b76447d11567c52980471e580bf325f90d35bc`.

No gauge-theory findings in the inspected scope. This is a bounded negative, not whole-repository verification.

## Executed evidence

`gauge-probe.py` uses the live `fgk_s3_noncommuting_holonomy_v1` fixture and exact row-law channels. `gauge-probe.json` records 72 endpoint-conjugation identities and 72 action-order identities, with zero violations. No producer, pool, full-carrier construction, tamper check, or broad test suite ran. The initial probe had an import-path failure; adding the repository `src` directory fixed the harness before any scientific check executed.

For source-to-target links, `gauge_kinematics.py:793-804` multiplies later traversal edges on the left; `806-855` applies target gauge on the left and inverse source gauge on the right. Therefore adjacent endpoint gauges cancel. The executed nonabelian check covers all 36 S3 assignments on the admitted two-vertex graph and both generator paths. The row-channel composition check covers both belief/model actions for all 36 ordered S3 pairs; it confirms the reversed row-law matrix order used by `validate_finite_action` at lines 366-372.

## Inspected construction boundaries

- `rg_v2/gauge_blocking_model.py:439-475` transports each matter fiber to its block root and dresses links using target-root transport and inverse source-root transport. `637-683` uses vertex-specific presentation-change factors and checks forward/reverse reconstructed links and holonomies. No accidental independent quotient of each holonomy appears in these paths.
- `rg_v2/complete_carrier_covariance_model.py:1052-1125` and `rg_v2/full_state_covariance_model.py:1260-1267,1380-1425` retain the same endpoint/action order. `complete_carrier_covariance_model.py:1310-1450` transforms raw graph links, recomputes path products, transforms parent/event matter at the corresponding roots, and reconstructs decorated state/ordinals.
- `rg_v2/complete_carrier_covariance_composition.py:2017-2103` constructs all sectors from the incident gauge orbit while retaining its graph coordinates and replacing local, parent, and event matter coherently. `2227-2272` uses the same local ordinal in the source and target on each branch, with masses 1/3 and 2/3. These source lines support the absence of an immediate structural-channel algebra obstruction, but do not replace decorated cross-sector admission.
- The apparent incomplete-generator concern in the general graph schema is not a defect on the admitted path: `gauge_kinematics_fixtures.py:373-400` fixes the two generator traversals on the two-vertex, three-orbit graph, while `gauge_kinematics.py:944-975` checks every edge against a reconstructed root trivialization before accepting flatness.
- `Theory/06_general_coarsegraining.tex:545-670` states bimeasurability, family-equivariance, existence/attainment boundaries, and proves path/root/gauge invariance of the marginal KL score. It does not substitute this score for a full-law channel.
- `Theory/07b_agent_network_rg.tex:1826-1911` retains simultaneous root-framed features, based holonomy, and dressed boundaries. It distinguishes passive coordinate rechoices from one active automorphism and distinguishes full-law covariance from fixed-observation isotropy invariance.

## Phase 14 scope

The live approved September 3 design and implementation plan are read-only inputs. Their admission-first boundary explicitly requires action squares, structural-channel squares, inverse and composition consistency; the target-state marginal must erase source-sector marks. The parent's local I/N action probe is supporting triage only. This lane did not execute full decorated admission and makes no Phase 14 theorem, acceptance, implementation, or information-loss claim.

## Source drift

The repository and Research-vault copies of `06_general_coarsegraining.tex` are byte-identical. Their `07b_agent_network_rg.tex` copies differ (56 inserted and 75 deleted lines in repository-to-vault diff). In particular, repository lines 3108-3122 preserve separate OPEN obligations for globally gauge-equivariant conditional versions and compatible rescaling kernels. The vault paragraph near 3092 instead says all other premises are satisfied by the declared finite constructions. This is source drift, not a defect attributed to the reviewed repository revision. Physical SHA-256 values are in `gauge-probe.json`.

Exact source discrepancy locators: the vault's `07b_agent_network_rg.tex:3093-3094` reads, "Every other premise is satisfied by the declared finite constructions of this and the preceding chapter". The repository's `Theory/07b_agent_network_rg.tex:3108` reads, "Two classes of supplied hypotheses remain open construction obligations"; lines 3122-3123 explicitly state, "The finite constructions in this and the preceding chapter are not claimed to discharge either obligation." Reconcile these copies through a separately authorized manuscript edit; do not transfer the vault's stronger claim into this repository audit.
