import gc, sys, json, math
from fractions import Fraction as F
gc.disable()
root = r'C:/tmp/rg-v2-astra-audit-20260904'
sys.path[:0] = [root, root + '/src']
from rg_v2.contracts import AgentDatum, ModelEvaluation, AgentRecognitionDatum, ExactProbabilityLaw, RecordDatum, SelectorSpec, CoarseChannelSpec
from rg_v2.population import construct_population_joint, derive_population_inference
from rg_v2.coarse import aggregate_population, _validate_inputs
from multiagent_elbo.finite.scale_cocycle import ExactMarkovChannel as C
from multiagent_elbo.config import NumericsConfig
print('runtime', sys.version, sys.executable, 'CPU exact Fraction/float64; no torch imported')
labels = ('["b0","m"]', '["b1","m"]')
latent = ('[["a","b0","m"]]', '[["a","b1","m"]]')
half = (F(1,2),F(1,2))
a = AgentDatum('a', (), ('b0','b1'), ('m',), labels, (ModelEvaluation('m',C(('()',),('b0','b1'),(half,))),), C(('()',),labels,(half,)))
recognition = AgentRecognitionDatum(a,ExactProbabilityLaw(labels,half))
config = NumericsConfig('float64',1e-12,1e-12)
for power in (10,1000,1072,1073,1074,1075,1100):
    e = F(1, 2**power)
    r = RecordDatum('r','a',('a',),('yes','no'),C(latent,('yes','no'),((e,1-e),(e,1-e))))
    p = construct_population_joint((a,),(r,),'tiny')
    i = derive_population_inference(p,(('r','yes'),),(recognition,),SelectorSpec('product','product',None))
    channel = CoarseChannelSpec('collapse',('a',),('structural',),C(latent,('z',),((F(1),),(F(1),))))
    _validate_inputs(i,channel,config)
    try:
        result = aggregate_population(i,channel,config)
        outcome = {'conditional_kl':result.conditional_kl_defect,'residual':result.kl_chain_residual}
    except Exception as exc:
        outcome = {'exception':type(exc).__name__,'message':str(exc)}
    print(json.dumps({'power':power,'positive_evidence':i.evidence>0,'posterior_equals_q':i.posterior==i.recognition,'float_evidence_cell':float(i.evidence_measure.masses[0]),'expected_conditional_kl':0,'expected_negative_log_evidence':power*math.log(2),**outcome}))
