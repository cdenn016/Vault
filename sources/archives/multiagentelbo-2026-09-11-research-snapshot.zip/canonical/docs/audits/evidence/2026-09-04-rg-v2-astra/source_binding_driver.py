from pathlib import Path
import gc, os, sys
root=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(root),str(root/'src')]
gc.disable()
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
import pytest
class NoForcedGC:
    def pytest_configure(self,config):
        from _pytest import unraisableexception
        config.stash[unraisableexception.gc_collect_iterations_key]=0
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--junitxml='+str(root/'.verification/astra-audit/source-binding.junit.xml'),'tests/rg_v2/test_full_state_covariance_fixtures.py::test_producer_cap_amendment_and_design_plan_binding_are_exact'],plugins=[NoForcedGC()]))
