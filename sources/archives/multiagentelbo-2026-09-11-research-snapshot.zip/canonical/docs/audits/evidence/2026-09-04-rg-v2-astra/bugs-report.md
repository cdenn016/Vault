# Correctness investigator lane: RG v2

Revision: `89b76447d11567c52980471e580bf325f90d35bc`.

No actionable correctness finding was established in the inspected paths. This is a bounded negative result, not certification of the entire assigned module family.

## Evidence

Executed exactly one existing positive scientific node: `tests/rg_v2/test_composition.py::test_task4_commuting_fixture_closes_every_route_but_retains_information_loss`. Command: `C:/tmp/rg-v2-phase13-py3147-runtime-20260901/python.exe -I -B -X dev .verification/astra-audit/bugs_composition_driver.py`. The driver suspends automatic cyclic GC before imports, disables plugin autoload and pytest forced collection, and selects only that node. JUnit records 1 test, 0 failures, 0 errors, 0 skipped, 18.669 seconds. Machine-readable outputs: `bugs-composition.junit.xml` and `bugs-composition.json`.

The node constructs and validates the declared commuting direct/staged routes, checks exact terminal generative and recognition equality, compares all observation posteriors and evidence, retains nonzero conditional information loss, and checks the composition information-loss residual at 1e-12. It is reachable from the active `run_renormalization_v2_composition_lab.py` fixture `lf4_composition_commuting_v1`, through `composition_experiment.py` loading and `_build_scientific_run` calls to the same public constructors/derivation/validator. It does not execute the publication runner.

An initial attempted invocation with `C:/Python314/python.exe -I -B -c ...` failed before pytest import (`ModuleNotFoundError: No module named pytest`); zero tests executed in that attempt. After the root agent reported overlapping completed positive checks, those selected population/coarse nodes were not rerun.

## Source coverage and limits

Inspected executable population DAG factor multiplication, canonical supports, recognition selector marginals, evidence slicing and normalization; common-channel coarse full-joint/recognition/posterior pushes and VFE diagnostics; recursive combined block channels, evaluator disintegration, information interfaces, and reconstruction; terminal composition disintegration and all-observation stagewise KL checks. Inspected adaptive structural normalizers, event-law mixtures, correlated endpoint membership composition, global-evidence posterior weighting; augmented sparse kernel normalization and convolution, deterministic assignment-keyed tails, conditional KL; repeated-scale retained histories, exact state marginalization, direct/staged law pushes, and interval composition seams.

The exact population and finite kernel arithmetic inspected preserves normalization with Fraction arithmetic. Adaptive posterior masses divide weighted generative masses by the common mixed evidence, rather than incorrectly averaging normalized branch posteriors. Sparse augmented convolution multiplies and sums source/intermediate/assignment-resolved probabilities. Terminal reconstruction checks every pushed joint cell after disintegration. These observations support selection of the positive node; they are not separate formally closed claims.

Coverage is selective. Large adaptive/augmented assessment and experiment modules, full gauge covariance, publication/replay certification, and all five repeated-scale controls were not executed by this lane. Existing tests combining positive composition assertions with deliberate history alterations were inspected but not invoked. Tamper/artifact corruption/forgery/malicious-packet checks were user-excluded/not run. No producer, publication, full-suite, worker-pool, or GPU run occurred. Production files were not edited.

Float conversion in conditional KL diagnostics was considered as a numerical edge case, but no admitted-fixture failing input was established; it is not a finding. Fixture-limited hard constraints and constant initial recognition kernels are deliberate boundaries, not diagnosed defects.

Context consulted: repository AGENTS.md and rg_v2/README.md; the prior 2026-08-30 RG v2 audit; Research/index.md and the theme `Staged hierarchy formation and RG composability`. The memory registry was searched for context only; no current-code conclusion relies on historical memory.

