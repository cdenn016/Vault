# Variational/probability lane

Revision: `89b76447d11567c52980471e580bf325f90d35bc`.

No variational-inference findings.

This was a read-only source review of selected normalized-law, exact-objective, support, and common-channel paths in the assigned files. No pytest, producer, publication, process-pool, tamper, corruption, forgery, or malicious-packet checks were run. No new numerical/probability probe was run. This result is a bounded negative, not exhaustive executable certification.

## Reviewed evidence

- `rg_v2/gauge_matter_network.py:1183-1311` constructs the full population joint and full selected recognition, checks an independent population reconstruction, and obtains the prior by summing observation rows. `:1795-1819` forms population VFE from the joint recognition KL and record likelihood contribution, then checks its exact prime-log equality with posterior KL minus log evidence. The separate edge diagnostic is booked as `composite_not_elbo`; it is not silently substituted for population KL. The public KL at `:1553-1577` omits zero recognition masses and returns an explicit support-violation marker for positive-over-zero mass.
- `rg_v2/gauge_plaquette_model.py:1404-1460` computes collapsed evidence with the declared Haar partition and explicitly requires disjoint primitive faces. `:1566-1623` sums link-conditioned matter terms under recognition link marginals and adds full normalized link KL. Marginals are used only for expectations of single-link additive terms; the full link recognition entropy remains in the link KL. This is not an illicit replacement of joint entropy by marginal entropy.
- `rg_v2/adaptive_partition_model.py:2654-2836` uses the same structural weights for generative and recognition pushes and divides the structural-weighted generative mass by common evidence for the posterior. `rg_v2/adaptive_partition_composition.py:635-740` and `:1229-1323` retain full fine recognition masses while aggregating likelihood signatures through direct/staged parent maps. Their fixed support/weight contract is narrow; it does not claim arbitrary learned channels.
- `rg_v2/complete_carrier_covariance_composition.py:2122-2163` constructs a globally normalized finite law with sector/local factorization, a sector-independent local likelihood, and distinct fixed generative/recognition sector weights. `:2348-2374` applies the same route to recognition and posterior. `:2910-2987` includes the fixed sector mixture term and checks the complete relative-entropy decomposition exactly. The factorization is declared in the approved Phase 13 design, `docs/superpowers/specs/2026-08-30-rg-v2-phase13-complete-carrier-d4-covariance-design.md:232-254`; it is a transported-copy fixture, not a demonstrated general interacting sector law. The design explicitly excludes canonical sector weights and sector superselection at `:487`.
- Selected relevant theorem/proof passages in `Theory/05_elbo.tex`, `Theory/06_general_coarsegraining.tex:85-141,257-301`, and `Theory/07b_agent_network_rg.tex:15-73,165-254` preserve full joint recognition, finite-evidence/extended-real distinctions, one common normalized channel, and the finite-KL condition needed for recovery from equality. The coarse ELBO improvement is identified as discarded conditional inference gap, not increased evidence. I found no contradiction between these passages and the inspected finite constructions.

## Suppressed candidate

`gauge_matter_network._scale_exact_log` (`:1518-1519`) propagates a support-violation marker even for zero weight; `_edge_diagnostic` scales every edge (`:1772-1773`). This would be wrong for a general extended-real expectation with a zero-probability singular edge. It is **not a finding for the admitted route**: `disintegrate_edge_event_law:1632-1633` requires the frozen strictly positive event masses, so the necessary zero-weight configuration is rejected before objective construction. No purported regression was executed or reported.

## Context and limitations

Consulted the Research index and `wiki/concepts/Renormalization-group flow of beliefs.md`; used that page to distinguish the legacy heuristic blocking account from the later finite conditional theory. The current executable source and approved Phase 13 design supplied the actual scope evidence. Memory registry `MEMORY.md:265` likewise identified the frozen theory boundary; current source was checked rather than treating historical results as current tests. No V3-specific neural/optimizer or default-toggle criticism was imported into this separate finite RG audit.
