from pathlib import Path
import gc
import json
import os
import sys
import time
import xml.etree.ElementTree as ET

gc.disable()
root = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(root), str(root / 'src')]
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
import pytest
class NoForcedGC:
    def pytest_configure(self, config):
        from _pytest import unraisableexception
        config.stash[unraisableexception.gc_collect_iterations_key] = 0
nodes = ['tests/rg_v2/test_composition.py::test_task4_commuting_fixture_closes_every_route_but_retains_information_loss']
out = root / '.verification/astra-audit'
t0 = time.perf_counter()
exit_code = int(pytest.main(['-q', '-p', 'no:cacheprovider', '--junitxml=' + str(out / 'bugs-composition.junit.xml'), *nodes], plugins=[NoForcedGC()]))
summary = {'executable': sys.executable, 'version':sys.version, 'exit_code':exit_code, 'elapsed':time.perf_counter()-t0, 'nodes':nodes, 'tamper_checks':'user-excluded/not run'}
if (out / 'bugs-composition.junit.xml').exists():
    tree = ET.parse(out / 'bugs-composition.junit.xml')
    summary['junit'] = [dict(s.attrib) for s in tree.getroot().iter('testsuite')]
(out / 'bugs-composition.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
raise SystemExit(exit_code)

