import sys
sys.path[:0] = [r'C:/tmp/rg-v2-astra-audit-20260904', r'C:/tmp/rg-v2-astra-audit-20260904/src']
from fractions import Fraction as F
from rg_v2.contracts import ExactProbabilityLaw
from rg_v2.repeated_scale_model import StateMarginalEntryDatum as E, StateMarginalKernelDatum as K, canonical_repeated_scale_sha256 as digest, compose_state_marginal_kernels, StructuralInvariantCandidateDatum, solve_unique_stationary_law
from rg_v2.finite_depth_stability_model import push_exact_probability_law, exact_total_variation_distance, exact_dobrushin_coefficient
from rg_v2.complete_carrier_covariance_composition import canonical_prime_log_expression
labels = ('a', 'b')
rows = ((E(0,F(3,4)), E(1,F(1,4))), (E(0,F(1,2)), E(1,F(1,2))))
payload = ('A', labels, rows, labels)
k = K(*payload, digest(payload))
k2 = compose_state_marginal_kernels(k,k,'AA')
assert tuple(tuple(e.mass for e in row) for row in k2.sparse_rows) == ((F(11,16), F(5,16)), (F(5,8), F(3,8)))
law = ExactProbabilityLaw(labels,(F(2,3),F(1,3)))
assert push_exact_probability_law(law,k) == law
result = solve_unique_stationary_law(k,StructuralInvariantCandidateDatum('stationary',1,'two-state',law))
assert result.constructed_laws == (law,) and result.equation_residuals == (F(0),F(0),F(0))
assert exact_dobrushin_coefficient(k).coefficient == F(1,4)
assert exact_dobrushin_coefficient(k2).coefficient == F(1,16)
assert exact_total_variation_distance(ExactProbabilityLaw(labels,(F(1),F(0))), law) == F(1,3)
assert canonical_prime_log_expression(((F(1,2),F(12)),(F(-1),F(2)),(F(-1,2),F(3)))) == ()
print('PASS: seven tiny positive exact arithmetic assertions; no producer or pool invoked')
