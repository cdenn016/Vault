# Runtime/config wiring review

Revision: `89b76447d11567c52980471e580bf325f90d35bc`.

No additional config-wiring findings.

## Executed evidence

`implementation-trace.json` records construction of all 13 shipped `run_renormalization_v2*_lab.py` dictionary configurations through `ExperimentConfig.from_dicts` and agreement with their `EXPERIMENT_REGISTRY` launcher declarations. All resolve to implicit CPU compute. This check reads the actual dictionary AST, not a test fixture. No launcher main function was invoked.

The shipped Release 1 `lf3_product_v1` configuration was also passed through `rg_v2.experiment._validate_run_config:818`, fixture loading, and `_build_scientific_run:608`. A Python execution trace recorded `rg_v2.coarse.aggregate_population:358`, `_validate_numerics:48`, `_vfe_diagnostics:322`, and `_metric_records:412`. Every produced scientific metric had status `pass`. No publication, provenance packet, pool, heavy producer, or prohibited tamper checks ran. Command used `C:/Python314/python.exe -B -`; process exited zero after approximately 1.57 seconds. No CUDA assertion is made.

## Inspected wiring

`run_renormalization_v2_lab.py:36` supplies RUN/THEORY/NUMERICS/OUTPUT without preconstruction mutation to `ExperimentConfig.from_dicts`. The loader resolves theory and implicit compute, validates exact keys and value types, and constructs frozen nested dataclasses (`src/multiagent_elbo/config.py:364` onward). `theory.fixture` reaches `load_fixture` in `rg_v2/experiment.py:861`; `config.numerics` reaches `aggregate_population` at `rg_v2/experiment.py:624`; `run.seed` reaches `RngStreams.from_seed` at `rg_v2/experiment.py:867`; output settings are explicitly constrained in `_validate_run_config`, then passed as the config to `RunStore.create`.

The Phase 4 launcher selects the noncommuting-holonomy fixture. Its runner validates the config at `rg_v2/gauge_kinematics_experiment.py:900`, passes `theory.fixture` into `load_gauge_kinematics_fixture:901`, and builds science at `:911`. This latter path was read, not executed.

The Phase 13 runner re-resolves serialized nested config values at `rg_v2/complete_carrier_covariance_experiment.py:399` and checks losslessness before its fixed route validator at `:418`. Its route requires the complete-carrier fixture, exact rational arithmetic, omitted default deterministic CPU compute, diagnostics enabled, and figures disabled. The heavy path was not executed.

Procedure coverage: active dictionary read and construction, preconstruction AST inspection, declared defaults and loader inspection, dispatch/contract matching, and an executed tiny scientific path. VFE3-specific kernel, E-step, dead-knob warning, and migration mechanisms do not apply to this repository. No complete ten-step fix verification is claimed; no fix was made. No runtime mutation/resume route defect was established within this bounded review.

Previously assigned underflow, Phase 13 admission timeouts, Phase 12 newline behavior, provenance gaps, implicit compute, and nonoperative numerics were excluded from duplicate findings. `pyproject.toml` discovers only `src` packages, but README prescribes checkout-based click-to-run use, so the root-level `rg_v2` package's absence from installed packages was not promoted without an installed-distribution support contract.

