from pathlib import Path
import hashlib,json
root=Path.cwd(); e=root/'.verification/astra-audit'
requests=[(root/'Theory/07b_agent_network_rg.tex',3106,3125),(Path('C:/Users/chris and christine/Desktop/Research/manuscripts/gauge_vfe_rg/07b_agent_network_rg.tex'),3090,3106),(root/'Theory/07c_full_graph_meta_agent_vfe.tex',377,410)]
rows=[]
for path,start,end in requests:
    raw=path.read_bytes(); lines=raw.decode('utf-8-sig').splitlines()
    rows.append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'start_line':start,'end_line':end,'lines':[{'line':i,'text':lines[i-1]} for i in range(start,end+1)]})
(e/'source-excerpts.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
ledger=json.loads((e/'claim-ledger.json').read_text('utf-8'))
for claim in ledger['claims']:
    if claim['id']=='RG2-08':
        claim['evidence']=[{'id':'RG2-08-source','kind':'reproduced_source','location':'.verification/astra-audit/source-excerpts.json','artifact_revision':ledger['artifact_revision']}]
    if claim['id']=='RG2-09':
        for item in claim['evidence']:
            if item['location'].endswith(('.py','.json')): item['kind']='numerical'
( e/'claim-ledger.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
print('Saved exact source excerpts and corrected domain evidence kinds.')
