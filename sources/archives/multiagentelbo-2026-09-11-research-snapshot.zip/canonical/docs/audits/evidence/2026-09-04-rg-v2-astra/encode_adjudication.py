from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

ROOT = Path(r'C:\tmp\rg-v2-astra-audit-20260904/.verification/astra-audit')
ORDER = ['absent', 'weak', 'adequate', 'strong']


def read(name: str) -> object:
    return json.loads((ROOT / name).read_text(encoding='utf-8-sig'))


def criteria(levels: dict[str, str]) -> list[dict[str, str]]:
    return [{'name': key, 'level': value} for key, value in levels.items()]


def main() -> None:
    ledger = read('claim-ledger.json')
    code = {x['claim_id']: x for x in read('verify-code.json')['results']}
    math = {x['claim_id']: x for x in read('verify-math.json')}
    skeptic = {x['claim_id']: x for x in read('verify-skeptic.json')['results']}
    decisions = {
        'RG2-01': ('EVIDENCE_VERIFIED', 'RG2-01-e2'),
        'RG2-02': ('EVIDENCE_VERIFIED', 'RG2-02-e1'),
        'RG2-03': ('INCONCLUSIVE', None),
        'RG2-04': ('INCONCLUSIVE', None),
        'RG2-05': ('EVIDENCE_VERIFIED', 'RG2-05-e2'),
        'RG2-06': ('EVIDENCE_VERIFIED', 'RG2-06-e2'),
        'RG2-07': ('EVIDENCE_VERIFIED', 'RG2-07-e2'),
        'RG2-08': ('EVIDENCE_VERIFIED', 'RG2-08-source'),
        'RG2-09': ('EVIDENCE_VERIFIED', 'RG2-09-proof'),
    }
    notes = []
    for claim in ledger['claims']:
        ident = claim['id']
        first = code.get(ident, math.get(ident))
        second = skeptic[ident]
        view_ids = [f'{ident}-sol', f'{ident}-skeptic-gpt55']
        first_levels = first['criteria']
        second_levels = second['criterion_levels']
        levels = {key: min([first_levels[key], second_levels[key]], key=ORDER.index) for key in first_levels}
        claim['criteria'] = criteria(levels)
        matches = []
        for index, (view, record, view_levels) in enumerate(zip(view_ids, [first, second], [first_levels, second_levels])):
            left, right = ('holds', 'fails') if index == 0 else ('fails', 'holds')
            outcome = ('left' if index == 0 else 'right') if record['result'] == 'support' else 'inconclusive'
            matches.append({'left': left, 'right': right, 'view_id': view, 'outcome': outcome,
                            'criteria': criteria(view_levels), 'result_location': record['result_location']})
        claim['views'] = {
            'calibration_kind': 'Independent domain and adversarial views; explicit opposed hypotheses with AB/BA encoding; weakest ordinal aggregation',
            'unresolved_disagreement': False,
            'comparison': {'method': 'pairwise', 'candidate_count': 2, 'candidate_ids': ['holds', 'fails'],
                           'candidate_descriptions': [{'id': 'holds', 'description': claim['statement']},
                                                     {'id': 'fails', 'description': 'The stated finding is false or not established within its recorded scope.'}],
                           'pivot_ids': [], 'orders': ['AB', 'BA'], 'matches': matches},
            'scores': [{'view_id': view_ids[0], 'criteria': criteria(first_levels)},
                       {'view_id': view_ids[1], 'criteria': criteria(second_levels)}],
        }
        available = {e['id'] for e in claim['evidence'] + claim['counterevidence']}
        claim['verifiers'] = []
        for role, view, record in zip(['verifier-code' if ident in code else 'verifier-math', 'verifier-skeptic'], view_ids, [first, second]):
            claim['verifiers'].append({'role': role, 'view_ids': [view], 'result': record['result'],
                                      'evidence_ids': [e for e in record['evidence_ids'] if e in available],
                                      'result_location': record['result_location']})
        state, evidence_id = decisions[ident]
        claim['state'] = state
        claim['open_obligations'] = []
        if ident == 'RG2-03':
            claim['open_obligations'] = ['A permitted non-destructive delayed-worker readiness/barrier fixture must establish the actual process-level rejection path. Current execution and configuration-scope criteria remain weak; no heavy or delayed pool was run.']
        if ident == 'RG2-04':
            claim['open_obligations'] = ['Obtain current non-forged reproduced output from a real provenance collection path where dirty_tree_sha256 is unavailable and Phase 11/12 admission still accepts. No filesystem corruption, fake provenance, or fault injection was run.']
        adjudication = {'role': 'verifier-adjudicator', 'view_ids': view_ids,
                        'result': 'support' if state == 'EVIDENCE_VERIFIED' else 'abstain',
                        'evidence_ids': [evidence_id] if evidence_id else [],
                        'result_location': f'.verification/astra-audit/adjudication.md#{ident}'}
        claim['verifiers'].append(adjudication)
        notes.append({'claim_id': ident, 'state': state, **adjudication, 'criteria': claim['criteria'],
                      'open_obligations': claim['open_obligations'], 'scope': first['rationale']})
    (ROOT / 'claim-ledger.json').write_text(json.dumps(ledger, indent=2) + '\n', encoding='utf-8')
    result = {'artifact_revision': ledger['artifact_revision'], 'state_author': '/root/adjudicate',
              'encoding': 'Root mechanically transcribed the independent adjudicator decisions delivered in collaboration message; reviewer scores were preserved.',
              'model': 'gpt-5.6-terra per explicit tool dispatch, not introspectively measured',
              'states': dict(Counter(x['state'] for x in ledger['claims'])), 'results': notes}
    (ROOT / 'adjudication.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    text = ['# Independent adjudication', '',
            'The adjudicator assigned seven EVIDENCE_VERIFIED and two INCONCLUSIVE states after checking the artifact pin and recorded evidence. Root transcribed these decisions because the adjudicator encountered a sandbox write failure; the adjudicator remains responsible for the decisions. No source or test was changed.', '',
            'Two recorded views were used per claim. Weakest criterion levels were retained. Support from both reviewers did not override weak evidence for RG2-03 or missing execution evidence for RG2-04. The mathematical closure links only the derivation; numerical agreement was not treated as proof. Model identity is recorded from explicit dispatch selection, not generic inherited model text.', '']
    for note in notes:
        text.extend([f"## {note['claim_id']}", '', f"**{note['state']}**. {note['scope']}", '',
                     'Adjudicator evidence: ' + (', '.join(note['evidence_ids']) or 'none eligible for closure') + '.', ''])
        if note['claim_id'] == 'RG2-07':
            text.extend(['Closure is restricted to config admission and the inspected Phase 12/13 direct consumers. It does not assert paired-run whole-program noninterference.', ''])
        if note['open_obligations']:
            text.extend(['Open obligation: ' + ' '.join(note['open_obligations']), ''])
    (ROOT / 'adjudication.md').write_text('\n'.join(text), encoding='utf-8')
    print(json.dumps(result['states']))


if __name__ == '__main__':
    main()
