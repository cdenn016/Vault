from fractions import Fraction as F
from pathlib import Path
import hashlib, json
root=Path(r'C:/tmp/rg-v2-astra-audit-20260904')
out=root/'.verification/astra-audit'
weights=(F(1,2), F(1,2))
# Fine V={1,...,6}; active events (2,3),(5,6); coarse events (A,A),(B,B).
eta=((F(1),F(0)),(F(0),F(1)))
# R0: A={1,2,3},B={4,5,6}; R1: A={1,5,6},B={2,3,4}. Anchors 1 and 4 stay fixed.
# These are distinct partitions, not parent-label permutations. Each hard endpoint
# assignment is deterministic, so endpoint assignments are independent given R.
route=(((F(1),F(0)),(F(0),F(1))),((F(0),F(1)),(F(1),F(0))))
exact=tuple(sum((weights[s]*eta[s][e]*route[s][e][t] for s in range(2) for e in range(2)),F(0)) for t in range(2))
mean_eta=tuple(sum((weights[s]*eta[s][e] for s in range(2)),F(0)) for e in range(2))
mean_route=tuple(tuple(sum((weights[s]*route[s][e][t] for s in range(2)),F(0)) for t in range(2)) for e in range(2))
factorized=tuple(sum((mean_eta[e]*mean_route[e][t] for e in range(2)),F(0)) for t in range(2))
literal=tuple(tuple(sum((eta[s][e]*mean_route[e][t] for e in range(2)),F(0)) for t in range(2)) for s in range(2))
control=tuple(sum((weights[s]*eta[s][e]*route[0][e][t] for s in range(2) for e in range(2)),F(0)) for t in range(2))
assert exact==(F(1),F(0)) and factorized==(F(1,2),F(1,2)) and literal==(factorized,factorized)
assert control==mean_eta
source=root/'Theory/07c_full_graph_meta_agent_vfe.tex'
vault=Path(r'C:/Users/chris and christine/Desktop/Research/manuscripts/gauge_vfe_rg/07c_full_graph_meta_agent_vfe.tex')
record={'revision':'89b76447d11567c52980471e580bf325f90d35bc','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'vault_sha256':hashlib.sha256(vault.read_bytes()).hexdigest(),'exact_coarse_event':exact,'factorized_formula':factorized,'literal_random_eta_formula_by_state':literal,'total_variation_gap':sum((abs(x-y) for x,y in zip(exact,factorized)),F(0))/2,'total_mass_baseline':sum(exact),'fixed_partition_control':control,'endpoint_independence':'deterministic given R','observation':'singleton; evidence 1; generative = posterior = recognition','scope':'manuscript counterexample; no production path or tests executed'}
(out/'geometry-probe.json').write_text(json.dumps(record,default=str,indent=2)+'\n')
print(json.dumps(record,default=str,indent=2))


