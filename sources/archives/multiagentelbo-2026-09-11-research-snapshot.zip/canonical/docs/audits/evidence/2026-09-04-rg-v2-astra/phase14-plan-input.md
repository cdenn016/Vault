# RG v2 Phase 14 Sector-Quotient Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build and test one authored, deterministic, information-losing sector quotient on the finite Phase 13 complete-carrier diagram, rejecting the construction before quotient-law work if its cross-sector maps are not equivariant and structurally compatible.

**Architecture:** Add one Phase 14 model/admission module that consumes public Phase 13 fixture, catalog, action, and sparse-kernel datums without changing Phase 13. After exact admission passes, add one composition/law module that lifts the existing kernel surfaces sparsely, pushes the three declared law families through a common channel, and checks direct/staged and source-first compatibility. Add the registered click-to-run experiment only after those focused scientific checks pass; do not copy the Phase 13 assessment, mutation, oracle, packet, or publication architecture.

**Tech Stack:** Python 3.14, standard-library `dataclasses`, `fractions.Fraction`, `hashlib`, `json`, exact finite (D_4) actions, existing `rg_v2` datums, and pytest.

**Spec:** `docs/superpowers/specs/2026-09-03-rg-v2-phase14-sector-quotient-design-gate.md`

## Global Constraints

- The approved design gate is the authority. The untracked August 31 Phase 14 design and plan are reference material only.
- Start implementation from current `origin/main`; fetch first and record `HEAD`. The Phase 14-consumed code is unchanged from the design's `184d956582b6a1beee45e1c22ff7818f20d56d21` source baseline through approval-host revision `89b76447d11567c52980471e580bf325f90d35bc`.
- Preserve the canonical Desktop WIP byte-for-byte. Use one isolated worktree for implementation and tests; never stash, reset, restore, overwrite, or delete the protected WIP.
- Phase 14 may import public Phase 13 datums and functions. No Phase 1–13 module may import a Phase 14 module.
- Do not modify Phase 13 fixtures, schemas, model semantics, composition semantics, validators, assessment, experiment, oracle, tests, or retained evidence.
- Do not create `complete_carrier_sector_quotient_fixtures.py`, Phase 14 fixture JSON, a mutation catalog, a separate assessment mirror, an artifact oracle, a publication test, or an evidence envelope. They are not required by the approved scope.
- Never invoke or add deliberate artifact/file corruption, forgery, malicious-packet, or tamper checks, directly or through a bundled command. Record them as user-excluded/not run, never passed.
- Retain sector order `III, IIN, INI, INN, NII, NIN, NNI, NNN` and authored routes (r_{01}(a,b,c)=(a,b,I)), (r_{12}(a,b,c)=(a,I,c)), and (r_{02}(a,b,c)=(a,I,I)).
- Preserve the Phase 13 `L0`, `L1/A0`, `L1/A1`, `L1/combined`, and `L2` layouts, including the `A0/A1` tag and its exact (1/3,2/3) mass. `L1/combined` is derived from the two branch-local maps, not an independent primitive intertwiner.
- Candidate cross-sector maps may pair equal sector-local ordinals, but that pairing is not admission evidence. Exact action-intertwining and structural-channel squares decide admission.
- Store only the eight source-to-route-target blocks on each lifted kernel surface. All other 56 sector-pair blocks are absent-key exact zeros; never materialize a dense carrier matrix.
- Phase 13 history rows may remain external proof witnesses. They are not target-state coordinates. The Phase 14 information-loss claim is restricted to the declared target-state marginal unless a later approved design removes every hidden source-sector mark from an augmented target state.
- Use a common recognition-independent pushforward for the generative joint, Bayes-reconstructed selected posterior, and recognition law. Keep Phase 13 observation labels and conditioning events.
- CPU `int` and `Fraction` arithmetic is authoritative. Focused implementation tests are serial. Any later parallel calculation is limited to 12 science workers and 14 live processes and must record actual resolved workers.
- Elapsed values are reporting only. The ordinary artifact budget starts at 128 MiB; a larger budget requires a documented scope decision.
- Do not rerun the Phase 13 producer, its all-in-one publication node, or the full repository suite. Run the focused Phase 14 files once after their implementation batch and one combined focused pass at the end.
- Do not run the click-to-run full-size laboratory during routine implementation. Run it only after the focused gates pass and a named obligation is recorded that cannot be discharged in memory.

## Planned File Structure

- Create `rg_v2/complete_carrier_sector_quotient_model.py`: route datums, candidate intertwiners, exact action/channel admission, and coverage accounting.
- Create `tests/rg_v2/test_complete_carrier_sector_quotient_model.py`: route, representative, exhaustive-admission, and hard-stop tests.
- Create `rg_v2/complete_carrier_sector_quotient_composition.py`: sparse lifted kernels, external route witnesses, pushed laws, exact relative-entropy accounting, and Phase 13/12 compatibility.
- Create `tests/rg_v2/test_complete_carrier_sector_quotient_composition.py`: sparse support, composition, law, Bayes, data-processing, identity, and `III` tests.
- Create `rg_v2/complete_carrier_sector_quotient_experiment.py`: minimal deterministic lab orchestration, provenance, ordinary JSON artifacts, and result type.
- Create `run_renormalization_v2_complete_carrier_sector_quotient_lab.py`: four-dictionary click-to-run boundary.
- Create `tests/rg_v2/test_complete_carrier_sector_quotient_experiment.py`: in-memory orchestration, provenance, and positive artifact tests.
- Create `tests/rg_v2/test_complete_carrier_sector_quotient_launcher.py`: import-safe launcher contract tests.
- Modify `src/multiagent_elbo/config.py`: additive Phase 14 theory config and resolver branch.
- Modify `src/multiagent_elbo/experiment_support.py`: additive Phase 14 experiment registry entry.
- Modify `tests/test_config.py` and `tests/test_experiment_support.py`: additive config/registry contracts and Phase 13 non-regression.
- Modify `rg_v2/README.md`, `RG_V2_ROADMAP.md`, and `docs/change-logs/2026-09-03.md`: implementation status and bounded claims after focused verification. If execution continues on a later calendar date, record those later edits in that date's daily change log as required by repository policy.

## Hard Execution Gates

1. Route-table failure stops Phase 14.
2. A failed representative nonidentity action or structural square stops Phase 14 before exhaustive coverage.
3. Missing coverage, a failed exhaustive square, or failed bijection, inverse, fixed-sector identity, or intertwiner-composition consistency stops Phase 14 before composition or law work.
4. Dense support, erased-bit leakage into target state, or direct/staged mismatch stops the quotient construction.
5. Law normalization, Bayes reconstruction, common-channel, support, or data-processing failure stops compatibility and laboratory work.
6. Config/provenance/resource failure prevents a laboratory result from being reported as admitted.

---

### Task 1: Freeze the Three Authored Sector Routes

**Files:**
- Create: `rg_v2/complete_carrier_sector_quotient_model.py`
- Create: `tests/rg_v2/test_complete_carrier_sector_quotient_model.py`

**Interfaces:**
- Consumes: `CompleteCarrierSectorId`, `COMPLETE_CARRIER_SECTOR_IDS`, and `canonical_complete_carrier_covariance_sha256` from `rg_v2.complete_carrier_covariance_model`.
- Produces: `CompleteCarrierSectorRouteId`, `CompleteCarrierSectorRouteDatum`, `construct_complete_carrier_sector_routes()`, and `compose_complete_carrier_sector_routes(...)`.

- [ ] **Step 1: Write the failing route-table test**

```python
def test_authored_sector_routes_compose_and_fix_iii() -> None:
    routes = {
        route.route_id: route
        for route in construct_complete_carrier_sector_routes()
    }
    assert routes["C01"].source_to_target == (
        ("III", "III"), ("IIN", "III"),
        ("INI", "INI"), ("INN", "INI"),
        ("NII", "NII"), ("NIN", "NII"),
        ("NNI", "NNI"), ("NNN", "NNI"),
    )
    assert routes["C12"].source_to_target == (
        ("III", "III"), ("IIN", "IIN"),
        ("INI", "III"), ("INN", "IIN"),
        ("NII", "NII"), ("NIN", "NIN"),
        ("NNI", "NII"), ("NNN", "NIN"),
    )
    assert routes["C02"].source_to_target == (
        ("III", "III"), ("IIN", "III"),
        ("INI", "III"), ("INN", "III"),
        ("NII", "NII"), ("NIN", "NII"),
        ("NNI", "NII"), ("NNN", "NII"),
    )
    assert compose_complete_carrier_sector_routes(
        routes["C01"], routes["C12"], "C02"
    ) == routes["C02"]
    assert all(
        dict(route.source_to_target)["III"] == "III"
        for route in routes.values()
    )
```

- [ ] **Step 2: Run the route test and confirm RED**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_model.py::test_authored_sector_routes_compose_and_fix_iii
```

Expected: collection fails because the Phase 14 model module does not exist.

- [ ] **Step 3: Implement immutable route datums and exact composition**

```python
CompleteCarrierSectorRouteId = Literal["C01", "C12", "C02"]
CompleteCarrierSectorMapEntry = tuple[
    CompleteCarrierSectorId, CompleteCarrierSectorId
]

@dataclass(frozen=True)
class CompleteCarrierSectorRouteDatum:
    route_id:         CompleteCarrierSectorRouteId
    source_to_target: tuple[CompleteCarrierSectorMapEntry, ...]
    route_digest:     str

def construct_complete_carrier_sector_routes(
) -> tuple[CompleteCarrierSectorRouteDatum, ...]:
    return tuple(
        _sector_route(route_id)
        for route_id in ("C01", "C12", "C02")
    )

def compose_complete_carrier_sector_routes(
    first:    CompleteCarrierSectorRouteDatum,
    second:   CompleteCarrierSectorRouteDatum,
    route_id: CompleteCarrierSectorRouteId,
) -> CompleteCarrierSectorRouteDatum:
    second_map = dict(second.source_to_target)
    rows = tuple(
        (source, second_map[middle])
        for source, middle in first.source_to_target
    )
    return _validated_route(route_id, rows)
```

Validate exact route order, one target per source, target-preimage accounting, `III` fixedness, digest recomputation, and `C12(C01(s)) == C02(s)`.

- [ ] **Step 4: Run the route node and confirm GREEN**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_model.py::test_authored_sector_routes_compose_and_fix_iii
```

Expected: all route tests pass without loading a Phase 13 fixture or writing files.

- [ ] **Step 5: Commit the route contract**

```powershell
git add rg_v2/complete_carrier_sector_quotient_model.py tests/rg_v2/test_complete_carrier_sector_quotient_model.py
git commit -m "feat(rg-v2): define Phase 14 sector routes"
```

### Task 2: Admit One Representative Nonidentity Intertwiner

**Files:**
- Modify: `rg_v2/complete_carrier_sector_quotient_model.py`
- Modify: `tests/rg_v2/test_complete_carrier_sector_quotient_model.py`

**Interfaces:**
- Consumes: `load_complete_carrier_covariance_fixture(...)`, `COMPLETE_CARRIER_CONTROL_IDS`, `construct_complete_carrier_control(...)`, public Phase 13 action tables, structural channels, and canonical serialization helpers.
- Produces: `CompleteCarrierIntertwinerSurfaceId`, `CompleteCarrierSectorIntertwinerDatum`, and `construct_complete_carrier_sector_intertwiner(...)`.

- [ ] **Step 1: Write one representative failing admission test**

```python
def test_c01_a0_nnn_intertwiner_passes_nonidentity_squares() -> None:
    bundle = load_complete_carrier_covariance_fixture(
        "fcc_d4_complete_carrier_v1"
    )
    control_id = COMPLETE_CARRIER_CONTROL_IDS[0]
    assert control_id == "fsc_d4_nonflat_center_sensitive"
    control = construct_complete_carrier_control(bundle, control_id)

    datum = construct_complete_carrier_sector_intertwiner(
        bundle,
        control,
        "C01_A0",
        "NNN",
    )

    assert datum.source_sector_id == "NNN"
    assert datum.target_sector_id == "NNI"
    assert datum.source_state_count == 512
    assert datum.target_state_count == 512
    assert datum.nonidentity_action_checks > 0
    assert datum.action_square_violations == ()
    assert datum.structural_square_violations == ()
    assert datum.admitted
```

- [ ] **Step 2: Run the representative test and confirm RED**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_model.py::test_c01_a0_nnn_intertwiner_passes_nonidentity_squares
```

Expected: failure because the intertwiner API is absent.

- [ ] **Step 3: Implement the five primitive surface IDs and candidate map**

```python
CompleteCarrierIntertwinerSurfaceId = Literal[
    "C01_A0", "C01_A1", "C12_A0", "C12_A1", "C02"
]

@dataclass(frozen=True)
class CompleteCarrierSectorIntertwinerDatum:
    surface_id:                   CompleteCarrierIntertwinerSurfaceId
    source_sector_id:            CompleteCarrierSectorId
    target_sector_id:            CompleteCarrierSectorId
    source_state_count:          int
    target_state_count:          int
    source_to_target_ordinals:   tuple[int, ...]
    nonidentity_action_checks:   int
    action_square_violations:    tuple[str, ...]
    structural_square_violations: tuple[str, ...]
    admitted:                     bool
    intertwiner_digest:           str
```

Build the candidate map by matching equal sector-local ordinals only after validating that the source and target sector tables have the declared cardinality and canonical order. The candidate pairing is an input to admission, not evidence of admission.

- [ ] **Step 4: Enforce exact action and structural-channel squares**

For every action element `g` and source state `x`, require

```text
q(g . x) = g . q(x).
```

For every Phase 13 structural channel attached to the selected surface, require the corresponding source/target square to commute after canonical serialization. Check identity elements, but separately count nonidentity checks and require the count to be positive. Reject missing action rows, missing channel rows, duplicate ordinals, a route mismatch, or either nonempty violation tuple. Set `admitted` only from those exact checks.

- [ ] **Step 5: Run the representative test and confirm GREEN**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_model.py::test_c01_a0_nnn_intertwiner_passes_nonidentity_squares
```

Expected: the selected `C01_A0` map is admitted with nonidentity coverage and no failed square.

- [ ] **Step 6: Commit the representative admission seam**

```powershell
git add rg_v2/complete_carrier_sector_quotient_model.py tests/rg_v2/test_complete_carrier_sector_quotient_model.py
git commit -m "feat(rg-v2): admit a sector intertwiner"
```

### Task 3: Exhaust the Admission Matrix Before Composition

**Files:**
- Modify: `rg_v2/complete_carrier_sector_quotient_model.py`
- Modify: `tests/rg_v2/test_complete_carrier_sector_quotient_model.py`

**Interfaces:**
- Produces: `CompleteCarrierSectorQuotientWorkDatum`, `CompleteCarrierSectorQuotientAdmission`, `count_complete_carrier_sector_quotient_work(...)`, and `assess_complete_carrier_sector_quotient_admission(...)`.

- [ ] **Step 1: Write count-only and exhaustive failing tests**

```python
def test_admission_work_count_is_exact_before_execution() -> None:
    work = count_complete_carrier_sector_quotient_work(
        control_ids=COMPLETE_CARRIER_CONTROL_IDS,
        surface_ids=("C01_A0", "C01_A1", "C12_A0", "C12_A1", "C02"),
        sector_ids=COMPLETE_CARRIER_SECTOR_IDS,
    )
    assert work.control_count == 2
    assert work.surface_count == 5
    assert work.sector_count == 8
    assert work.intertwiner_count == 80


def test_exhaustive_admission_covers_all_80_intertwiners() -> None:
    admission = assess_complete_carrier_sector_quotient_admission(bundle, control)
    assert admission.expected_intertwiner_count == 80
    assert admission.executed_intertwiner_count == 80
    assert admission.control_ids == COMPLETE_CARRIER_CONTROL_IDS
    assert admission.catalog_ids == (
        "L0:fine", "L1:A0", "L1:A1", "L2:terminal"
    )
    assert admission.bijection_check_count == 80
    assert admission.inverse_round_trip_check_count == 80 * 512 * 2
    assert admission.fixed_sector_identity_check_count == 36 * 512
    assert admission.intertwiner_composition_check_count == 2 * 2 * 8 * 512
    assert admission.missing_keys == ()
    assert admission.duplicate_keys == ()
    assert admission.action_square_violations == ()
    assert admission.structural_square_violations == ()
    assert admission.map_consistency_violations == ()
    assert admission.first_failure is None
    assert admission.admitted
```

- [ ] **Step 2: Run the two tests and confirm RED**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_model.py -k "work_count or exhaustive_admission"
```

Expected: failure because the admission aggregate does not exist.

- [ ] **Step 3: Implement fail-closed ordered admission**

Construct the Cartesian coverage key `(control_id, surface_id, source_sector_id)` in canonical order. Validate the count-only work datum before fixture execution. Bind the exact positive fixture ID and digest, the two ordered Phase 13 control IDs, and catalog identities `L0:fine`, `L1:A0`, `L1:A1`, and `L2:terminal`. Then execute each candidate exactly once, retain each digest and exact check count, and stop at the first failed obligation. The aggregate must reject a missing key, duplicate key, unexpected key, source-binding drift, empty nonidentity coverage, digest mismatch, action-square failure, or structural-square failure.

Require each 512-state map to be a bijection and check both inverse round trips. Whenever a route fixes its source sector, require the ordinal map itself to be the identity; there are 36 such control/surface/sector cases, hence `36 * 512` point checks. For both controls, both branches, all eight sectors, and all 512 ordinals, require `tau_C12_branch(tau_C01_branch(x)) == tau_C02(x)`, hence `2 * 2 * 8 * 512` point checks. These map-consistency checks belong to admission and must finish before kernel lifting.

The primitive maps are `C01_A0`, `C01_A1`, `C12_A0`, `C12_A1`, and `C02`. The `L1/combined` map is derived by applying the admitted `A0` and `A1` maps to their Phase 13 branch-local rows and retaining branch masses `(1/3, 2/3)`; do not add a sixth primitive surface.

- [ ] **Step 4: Run the model test file once and honor the hard stop**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_model.py
```

Expected: all route, representative, count, and exhaustive-admission tests pass. If any square or coverage check fails, stop here, record the exact first failing key and digest, and do not create the composition module.

- [ ] **Step 5: Commit the complete admission gate**

```powershell
git add rg_v2/complete_carrier_sector_quotient_model.py tests/rg_v2/test_complete_carrier_sector_quotient_model.py
git commit -m "feat(rg-v2): exhaust sector quotient admission"
```

### Task 4: Lift the Admitted Quotient as Sparse Kernel Blocks

**Files:**
- Create: `rg_v2/complete_carrier_sector_quotient_composition.py`
- Create: `tests/rg_v2/test_complete_carrier_sector_quotient_composition.py`

**Interfaces:**
- Consumes: admitted Phase 14 intertwiners plus public Phase 13 sparse-kernel and composition datums.
- Produces: `CompleteCarrierSectorRouteWitness`, `CompleteCarrierSectorQuotientControl`, `lift_complete_carrier_sector_quotient_kernel(...)`, and `construct_complete_carrier_sector_quotient_control(...)`.

- [ ] **Step 1: Write the sparse-support and direct/staged failing tests**

```python
def test_each_lifted_surface_has_eight_route_blocks_and_no_dense_support() -> None:
    quotient = construct_complete_carrier_sector_quotient_control(bundle, admission)
    for surface in quotient.kernel_surfaces:
        assert len(surface.present_blocks) == 8
        assert surface.absent_block_count == 56
        assert all(
            target == quotient.route_target(surface.route_id, source)
            for source, target in surface.present_block_keys
        )


def test_direct_and_staged_sector_quotients_are_exactly_equal() -> None:
    quotient = construct_complete_carrier_sector_quotient_control(bundle, admission)
    assert quotient.direct_c02_kernel == quotient.staged_c12_after_c01_kernel
    assert quotient.direct_c02_digest == quotient.staged_c02_digest
    assert quotient.combined_branch_masses == (Fraction(1, 3), Fraction(2, 3))
```

- [ ] **Step 2: Run the composition file and confirm RED**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_composition.py
```

Expected: collection fails because the Phase 14 composition module does not exist.

- [ ] **Step 3: Implement sparse target relabeling**

For each primitive Phase 13 surface and source sector, relabel only its target sector through the admitted route and transform the row/column carrier labels through the admitted intertwiner. Store one block per source sector. An absent `(source_sector, target_sector)` key means the exact zero kernel. Validate eight present keys, 56 absent keys, canonical key order, normalized rows, and no duplicate support.

`L1/combined` is assembled from the lifted `A0` and `A1` kernels with their exact Phase 13 branch masses. It is not admitted as a primitive map.

- [ ] **Step 4: Keep histories outside target-state coordinates**

```python
@dataclass(frozen=True)
class CompleteCarrierSectorRouteWitness:
    route_id:          CompleteCarrierSectorRouteId
    source_sector_id: CompleteCarrierSectorId
    target_sector_id: CompleteCarrierSectorId
    source_digest:     str
    target_digest:     str
```

Use route witnesses to prove support and composition. Do not serialize source-sector bits, erased flags, or a route history into the target-state key. This keeps the information-loss claim scoped to the declared target-state marginal.

- [ ] **Step 5: Implement exact direct/staged composition**

Compose `C01` then `C12` through public Phase 13 sparse-kernel composition and compare it with direct `C02` after canonical ordering and normalization. Require exact equality of datums and digests, including branch-local and combined surfaces. A mismatch stops Phase 14 before law construction.

- [ ] **Step 6: Run the two composition nodes and confirm GREEN**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_composition.py::test_each_lifted_surface_has_eight_route_blocks_and_no_dense_support tests/rg_v2/test_complete_carrier_sector_quotient_composition.py::test_direct_and_staged_sector_quotients_are_exactly_equal
```

Expected: sparse support, branch-mass, route-witness, and direct/staged tests pass.

- [ ] **Step 7: Commit the sparse quotient composition**

```powershell
git add rg_v2/complete_carrier_sector_quotient_composition.py tests/rg_v2/test_complete_carrier_sector_quotient_composition.py
git commit -m "feat(rg-v2): compose sparse sector quotients"
```

### Task 5: Push the Three Law Families and Prove the Bounded Compatibility Claims

**Files:**
- Modify: `rg_v2/complete_carrier_sector_quotient_composition.py`
- Modify: `tests/rg_v2/test_complete_carrier_sector_quotient_composition.py`

**Interfaces:**
- Consumes: `ExactProbabilityLaw`, `push_complete_carrier_probability_law(...)`, `canonical_prime_log_expression(...)`, `CompleteCarrierExactLawBundle`, `complete_carrier_incident_projection_context(...)`, and `project_complete_carrier_incident_control(...)`.
- Produces: `CompleteCarrierSectorQuotientLawBundle`, `CompleteCarrierSectorRelativeEntropyDatum`, `construct_complete_carrier_sector_quotient_laws(...)`, `assess_complete_carrier_sector_relative_entropy(...)`, and `project_complete_carrier_sector_quotient_incident_control(...)`.

- [ ] **Step 1: Write the common-channel and Bayes-reconstruction failing test**

```python
def test_three_law_families_use_one_channel_and_reconstruct_bayes() -> None:
    quotient = construct_complete_carrier_sector_quotient_control(bundle, admission)
    laws = construct_complete_carrier_sector_quotient_laws(quotient)

    assert laws.family_ids == (
        "generative", "selected_posterior", "recognition"
    )
    assert laws.channel_family_id is None
    assert all(
        row.channel_digest == laws.common_channel_digest
        for row in laws.pushforward_rows
    )
    assert all(sum(law.masses, Fraction(0)) == 1 for law in laws.target_laws)
    assert laws.bayes_reconstructed_selected_posterior == laws.target_selected_posterior
    assert laws.pushed_selected_posterior == laws.target_selected_posterior
    assert laws.direct_laws == laws.staged_laws
```

- [ ] **Step 2: Write the support, data-processing, and strictness failing test**

```python
def test_relative_entropy_accounting_is_exact_and_support_explicit() -> None:
    rows = assess_complete_carrier_sector_relative_entropy(laws)
    assert rows
    assert all(row.common_channel for row in rows)
    assert all(row.source_support_valid for row in rows)
    assert all(row.target_support_valid for row in rows)
    assert all(row.chain_rule_identity for row in rows)
    assert all(row.data_processing_holds for row in rows)
    assert all(
        row.strict_loss_established
        == row.has_positive_weight_unequal_conditionals
        for row in rows
    )
```

Add synthetic zero-support cases that require these rules: `q_i = 0` contributes zero; `q_i > 0` with `p_i = 0` is positive infinity; and finite terms require `q_i > 0` and `p_i > 0`. Do not divide by zero or coerce infinity into a finite sentinel.

- [ ] **Step 3: Run the new law nodes and confirm RED**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_composition.py -k "law_families or relative_entropy"
```

Expected: failure because the law and relative-entropy APIs are absent.

- [ ] **Step 4: Implement a single recognition-independent channel**

Construct one exact row-stochastic channel from the admitted sparse quotient, with no law-family field in its identity or digest. Push the Phase 13 generative joint, selected posterior, and recognition law through that same channel. Preserve observation labels and conditioning events. Reconstruct the target selected posterior from the pushed generative joint by exact Bayes normalization, then compare it with the pushed Phase 13 selected posterior.

Require exact normalization, canonical labels, source and target support inclusion, channel-digest equality, and direct/staged law equality. A failed premise prevents construction of a successful law bundle.

- [ ] **Step 5: Implement exact relative-entropy accounting without floating logs**

Reuse the public `PrimeLogExpression` and `canonical_prime_log_expression(...)` representation for finite rows. Represent positive infinity explicitly and separately from finite prime-log coefficients. For each conditioning event, record source divergence, target divergence, fiber-conditional defect, support premises, and the exact chain-rule identity. Establish strict loss only when a merged fiber has positive weight and unequal conditional laws; otherwise report equality or an unestablished strictness claim. Never infer strict contraction merely from a many-to-one route table.

- [ ] **Step 6: Write identity-route and source-first `III` compatibility tests**

```python
def test_identity_route_recovers_phase13_exactly() -> None:
    identity = construct_complete_carrier_sector_identity_control(phase13_closure)
    assert identity.phase13_construction == phase13_closure.construction
    assert identity.phase13_laws == validate_complete_carrier_exact_laws(
        phase13_closure
    )


def test_source_first_iii_projection_matches_phase12_bytes() -> None:
    context = complete_carrier_incident_projection_context(
        phase13_closure.construction.control_id
    )
    expected = project_complete_carrier_incident_control(
        phase13_closure,
        context,
    )
    actual = project_complete_carrier_sector_quotient_incident_control(
        quotient_closure,
        context,
        source_sector_id="III",
    )
    assert actual.inner_serialization_bytes == expected.inner_serialization_bytes
    assert actual.inner_serialization_sha256 == expected.inner_serialization_sha256
```

Implement the identity control as a verification adapter over the unchanged Phase 13 closure, not a fourth configured route. For the `III` check, restrict and normalize the source law to `III` before applying the quotient channel. Reject an implementation that pushes the global eight-sector law and conditions on `III` afterward.

- [ ] **Step 7: Run the complete composition/law file once and honor the hard stop**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_composition.py
```

Expected: sparse composition, common-channel, Bayes, support, exact data-processing, identity-route, and source-first `III` tests pass. If any premise fails, stop before adding the experiment boundary.

- [ ] **Step 8: Commit the exact law and compatibility layer**

```powershell
git add rg_v2/complete_carrier_sector_quotient_composition.py tests/rg_v2/test_complete_carrier_sector_quotient_composition.py
git commit -m "feat(rg-v2): verify sector quotient laws"
```

### Task 6: Register a Minimal Click-to-Run Laboratory

**Files:**
- Create: `rg_v2/complete_carrier_sector_quotient_experiment.py`
- Create: `run_renormalization_v2_complete_carrier_sector_quotient_lab.py`
- Create: `tests/rg_v2/test_complete_carrier_sector_quotient_experiment.py`
- Create: `tests/rg_v2/test_complete_carrier_sector_quotient_launcher.py`
- Modify: `src/multiagent_elbo/config.py`
- Modify: `src/multiagent_elbo/experiment_support.py`
- Modify: `tests/test_config.py`
- Modify: `tests/test_experiment_support.py`

**Interfaces:**
- Produces: `RenormalizationV2CompleteCarrierSectorQuotientTheoryConfig`, `RenormalizationV2CompleteCarrierSectorQuotientExperimentResult`, and `run_renormalization_v2_complete_carrier_sector_quotient_experiment(...)`.

- [ ] **Step 1: Write the additive config contract test**

```python
def complete_carrier_sector_quotient_theory() -> dict[str, object]:
    return {
        "experiment": "renormalization_v2_complete_carrier_sector_quotient",
        "fixture": "fcc_d4_complete_carrier_v1",
        "route_family": "erase_c_then_b_v1",
        "arithmetic": "exact_rational",
    }


def test_phase14_sector_quotient_config_is_exact_cpu_default() -> None:
    run, _, numerics, output = valid_dicts()
    config = ExperimentConfig.from_dicts(
        run,
        complete_carrier_sector_quotient_theory(),
        numerics,
        output,
    )
    assert type(config.theory) is RenormalizationV2CompleteCarrierSectorQuotientTheoryConfig
    assert config.compute_explicit is False
    assert config.compute.backend == "cpu"
    assert config.compute.deterministic is True
```

Also add `test_phase14_sector_quotient_rejects_invalid_theory` and `test_phase14_sector_quotient_preserves_predecessor_prefix`. Require exactly four theory keys, frozen literal fields, rejection of missing/extra/wrong values, rejection of explicit CUDA, Phase 14 immediately after Phase 13 in `NEW_EXPERIMENT_NAMES`, and byte-for-byte equality of the predecessor prefix after canonical JSON serialization.

- [ ] **Step 2: Write the additive registry contract test**

```python
PHASE14_ARTIFACTS = (
    "config", "admission", "sector_quotient", "metrics", "manifest"
)
PHASE14_METRICS = (
    "admitted",
    "expected_intertwiner_count",
    "executed_intertwiner_count",
    "nonidentity_action_check_count",
    "bijection_check_count",
    "inverse_round_trip_check_count",
    "fixed_sector_identity_check_count",
    "intertwiner_composition_check_count",
    "action_square_violation_count",
    "structural_square_violation_count",
    "map_consistency_violation_count",
    "present_kernel_block_count",
    "implicit_zero_block_count",
    "direct_staged_equal",
    "common_channel_equal",
    "bayes_reconstruction_equal",
    "strict_loss_row_count",
    "identity_route_recovered",
    "source_first_iii_equal",
    "resolved_workers",
    "artifact_bytes",
)
```

Add tests named `test_phase14_sector_quotient_registry_contract_is_exact_and_last` and `test_phase14_sector_quotient_preserves_phase13_prefix`. Assert the exact experiment name, lane owner `rg_v2_complete_carrier_sector_quotient_phase14`, launcher name, four config keys, five JSON artifact stems, metric order, unique ownership, and preservation of every Phase 1–13 contract.

- [ ] **Step 3: Run the config and registry nodes and confirm RED**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/test_config.py -k "phase14_sector_quotient"
C:\Python314\python.exe -B -m pytest -q tests/test_experiment_support.py -k "phase14_sector_quotient"
```

Expected: failure because the Phase 14 type, resolver branch, name, and registry contract are absent.

- [ ] **Step 4: Add the config and registry seams without changing predecessors**

Append the frozen theory dataclass and experiment literal. Extend the resolver with an exact-key branch for the Phase 14 experiment and preserve the existing default CPU computation. Append one immutable `ExperimentContract` with the inventories above. Do not edit any Phase 13 key, position relative to its predecessors, default, artifact, or metric.

- [ ] **Step 5: Write orchestration and positive-artifact failing tests**

```python
def test_experiment_admits_before_constructing_quotient(monkeypatch) -> None:
    calls: list[str] = []
    install_recording_phase14_fakes(monkeypatch, calls, admitted=True)
    result = run_renormalization_v2_complete_carrier_sector_quotient_experiment(
        config,
        write_artifacts=False,
    )
    assert calls == ["bind", "count", "admit", "compose", "laws", "compat"]
    assert result.admission.admitted


def test_failed_admission_stops_before_composition(monkeypatch) -> None:
    calls: list[str] = []
    install_recording_phase14_fakes(monkeypatch, calls, admitted=False)
    with pytest.raises(CompleteCarrierSectorQuotientAdmissionError):
        run_renormalization_v2_complete_carrier_sector_quotient_experiment(
            config,
            write_artifacts=False,
        )
    assert calls == ["bind", "count", "admit"]
```

Use prepared immutable positive datums for artifact serialization tests. Do not run the full fixture merely to test orchestration, file names, or JSON determinism.

- [ ] **Step 6: Implement minimal deterministic orchestration and artifacts**

Bind the Git blob identity and separately labeled physical-file hashes for every consumed source. Record the resolved config, pinned interpreter identity, authoritative arithmetic, `resolved_workers=1`, admission, bijection, inverse, fixed-sector identity, intertwiner-composition, action-square, and structural-square counts, every violation count, sparse block counts, exact-law verdicts, compatibility verdicts, artifact byte total, and a digest over canonical JSON content.

With `write_artifacts=True`, write only `config.json`, `admission.json`, `sector_quotient.json`, `metrics.json`, and `manifest.json` through atomic same-directory replacement. Enforce the 128-MiB aggregate budget before publication of the manifest. Do not write NPZ, figures, packets, an oracle comparison, a mutation report, publication control, or an evidence envelope.

- [ ] **Step 7: Implement the four-dictionary launcher**

Expose editable `RUN`, `THEORY`, `NUMERICS`, and `OUTPUT` dictionaries, following the existing Phase 13 import-safe launcher pattern. `THEORY` must contain the four exact keys above. Add no CLI, environment-variable control, device dictionary, `COMPUTE` dictionary, import-time execution, or hidden full-size test invocation. `main()` constructs `ExperimentConfig`, calls the Phase 14 experiment once, type-checks the result, and prints arithmetic, admission, resolved workers, manifest digest, and run directory.

- [ ] **Step 8: Run the four focused integration files once**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/test_config.py -k "phase14_sector_quotient"
C:\Python314\python.exe -B -m pytest -q tests/test_experiment_support.py -k "phase14_sector_quotient"
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_experiment.py
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_launcher.py
```

Expected: all Phase 14 integration tests pass without invoking launcher `main()` or a full-size laboratory.

- [ ] **Step 9: Commit the laboratory boundary**

```powershell
git add src/multiagent_elbo/config.py src/multiagent_elbo/experiment_support.py tests/test_config.py tests/test_experiment_support.py
git add rg_v2/complete_carrier_sector_quotient_experiment.py run_renormalization_v2_complete_carrier_sector_quotient_lab.py
git add tests/rg_v2/test_complete_carrier_sector_quotient_experiment.py tests/rg_v2/test_complete_carrier_sector_quotient_launcher.py
git commit -m "feat(rg-v2): add Phase 14 quotient lab"
```

### Task 7: Run the Focused Acceptance Packet and Record the Bounded Result

**Files:**
- Modify: `rg_v2/README.md`
- Modify: `RG_V2_ROADMAP.md`
- Modify: `docs/change-logs/2026-09-03.md`
- Verify: every Phase 14 source and focused test file created in Tasks 1–6

- [ ] **Step 1: Run one combined focused scientific packet**

Run:

```powershell
C:\Python314\python.exe -B -m pytest -q tests/rg_v2/test_complete_carrier_sector_quotient_model.py tests/rg_v2/test_complete_carrier_sector_quotient_composition.py tests/rg_v2/test_complete_carrier_sector_quotient_experiment.py tests/rg_v2/test_complete_carrier_sector_quotient_launcher.py tests/test_config.py::test_phase14_sector_quotient_config_is_exact_cpu_default tests/test_config.py::test_phase14_sector_quotient_rejects_invalid_theory tests/test_config.py::test_phase14_sector_quotient_preserves_predecessor_prefix tests/test_experiment_support.py::test_phase14_sector_quotient_registry_contract_is_exact_and_last tests/test_experiment_support.py::test_phase14_sector_quotient_preserves_phase13_prefix
```

Expected: every selected test passes in one serial process. Report totals from this command's terminal result; do not extrapolate to the full repository suite.

- [ ] **Step 2: Check the one-way import and prohibited-architecture boundaries**

Run:

```powershell
rg -n --glob '*.py' --glob '!complete_carrier_sector_quotient*.py' "complete_carrier_sector_quotient" rg_v2
rg -n -- "mutation_catalog|publication_control|evidence_envelope|artifact_oracle|malicious_packet|forged_packet" rg_v2/complete_carrier_sector_quotient_model.py rg_v2/complete_carrier_sector_quotient_composition.py rg_v2/complete_carrier_sector_quotient_experiment.py run_renormalization_v2_complete_carrier_sector_quotient_lab.py tests/rg_v2/test_complete_carrier_sector_quotient_model.py tests/rg_v2/test_complete_carrier_sector_quotient_composition.py tests/rg_v2/test_complete_carrier_sector_quotient_experiment.py tests/rg_v2/test_complete_carrier_sector_quotient_launcher.py
```

Expected: both searches return no matches. A Phase 1–13 import of Phase 14 or any copied publication/mutation architecture is a stop condition.

- [ ] **Step 3: Inspect active config reachability and predecessor preservation**

Open the launcher `THEORY` dictionary and trace its four keys through `ExperimentConfig.from_dicts(...)`, the Phase 14 resolver branch, and the registry contract to `run_renormalization_v2_complete_carrier_sector_quotient_experiment(...)`. Confirm the runtime reaches admission before composition. Compare canonical serialized Phase 1–13 config names and registry contracts with the pre-edit values captured by the focused tests.

- [ ] **Step 4: Run static diff and placeholder checks**

Run:

```powershell
git diff --check
$phase14_placeholder_pattern = @("T" + "BD", "TO" + "DO", "NotImplemented" + "Error", "fill in" + " details", "implement " + "later") -join "|"
rg -n -- $phase14_placeholder_pattern rg_v2/complete_carrier_sector_quotient_model.py rg_v2/complete_carrier_sector_quotient_composition.py rg_v2/complete_carrier_sector_quotient_experiment.py run_renormalization_v2_complete_carrier_sector_quotient_lab.py tests/rg_v2/test_complete_carrier_sector_quotient_model.py tests/rg_v2/test_complete_carrier_sector_quotient_composition.py tests/rg_v2/test_complete_carrier_sector_quotient_experiment.py tests/rg_v2/test_complete_carrier_sector_quotient_launcher.py
```

Expected: no whitespace errors and no placeholders in task-owned source or tests.

- [ ] **Step 5: Update documentation with only the executed claims**

In `rg_v2/README.md` and `RG_V2_ROADMAP.md`, record the exact revision, command, passed focused-test total, admitted intertwiner count, bijection/inverse/identity/composition and action/structural check counts, every violation count, sparse block count, direct/staged verdict, common-channel and Bayes verdicts, established strict-loss row count, identity-route verdict, and source-first `III` verdict. State whether `run_renormalization_v2_complete_carrier_sector_quotient_lab.py` was run; routine implementation leaves it unrun.

Retain these boundaries: the result is the declared finite conditional construction only; it does not establish canonical sector selection, superselection, autonomous flow, fixed points, universality, arbitrary graphs/depth, a continuum or thermodynamic limit, physical time, or a continuous-group/GPU certificate. State that Phase 13 remains operator-accepted with automated publication certification incomplete. Record prohibited checks as user-excluded/not run, never passed.

Append the exact changed-file list, commands, outcomes, and omitted full-size lab to `docs/change-logs/2026-09-03.md`. If implementation occurs after 2026-09-03, put the execution record in the corresponding daily file and leave the planning entry intact.

- [ ] **Step 6: Review the final diff and commit the bounded implementation record**

Run:

```powershell
git status --short
git diff --stat
git diff -- rg_v2/README.md RG_V2_ROADMAP.md docs/change-logs/2026-09-03.md
```

Confirm that task-owned changes are limited to the planned files and that protected Desktop WIP is untouched. Then commit:

```powershell
git add rg_v2/README.md RG_V2_ROADMAP.md docs/change-logs/2026-09-03.md
git commit -m "docs(rg-v2): record Phase 14 focused acceptance"
```

Do not merge, push, or synchronize the canonical Desktop checkout unless the user separately requests the Git publication lifecycle.

## Deferred Full-Size Positive Calculation

The click-to-run laboratory is an operator boundary, not a routine acceptance test. Leave it unrun after Task 7 unless a named remaining obligation cannot be discharged by the admitted exact in-memory construction and focused compatibility checks.

Before authorizing a run, write down that obligation, call `count_complete_carrier_sector_quotient_work(...)` without executing the workload, record the exact source/config hashes, select and verify the CPython 3.14 runtime, inspect available memory, and record the requested and resolved worker counts. The current launcher resolves to one serial worker; any later parallel implementation is bounded at 12 science workers and 14 live processes. Keep the aggregate artifact budget at 128 MiB unless a separate documented scope decision changes it.

Run only the Phase 14 launcher:

```powershell
C:\Python314\python.exe -B run_renormalization_v2_complete_carrier_sector_quotient_lab.py
```

Preserve each completed positive stage's ordinary results, counters, hashes, and failure logs immediately. On any admission, composition, law, provenance, resource, or process failure, stop and retain the failure; do not retry until green, weaken a guard, or substitute approximate/CUDA arithmetic. Do not invoke the Phase 13 producer or publication node, a full repository suite, or any prohibited check. A positive run creates only the five ordinary JSON artifacts declared in Task 6 and does not manufacture automated publication certification.
