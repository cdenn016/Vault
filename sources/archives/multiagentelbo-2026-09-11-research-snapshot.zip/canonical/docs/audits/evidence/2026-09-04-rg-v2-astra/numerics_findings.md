# Numerical-analysis lane: RG v2 Astra audit

Revision: `89b76447d11567c52980471e580bf325f90d35bc`, isolated root `C:/tmp/rg-v2-astra-audit-20260904`.

## Finding N1: Mandatory float diagnostics reject valid exact positive-evidence aggregation

**Location:** `rg_v2/coarse.py:332-335` (lossy evidence conversion), `rg_v2/coarse.py:348-354` (float decomposition), `rg_v2/coarse.py:388-392` (unconditional invocation from public aggregation).

**Severity:** medium.

**Evidence:** The public `aggregate_population` API validates exact inference and channel data before computing exact pushes, but `_vfe_diagnostics` converts each exact evidence mass with `[float(value) for value in inference.evidence_measure.masses]`. Its float posterior is mandatory even when all exact pushforwards and posteriors are well-defined. The attached tiny positive-law probe creates one ordinary two-state agent, a normalized binary observation kernel with state-independent positive likelihood `e = 2**(-n)`, uniform recognition, and a deterministic channel to one coarse state. It constructs the population through `construct_population_joint`, derives inference through `derive_population_inference`, and explicitly passes `_validate_inputs`. There are no replaced or corrupted objects. For both states, exact evidence mass is `e/2`, exact posterior equals recognition `(1/2, 1/2)`, conditional KL is exactly zero, and the fine/coarse VFE is the finite value `n*log(2)`.

Recorded output from `numerics_probe.txt`:

```text
runtime 3.14.7 (tags/v3.14.7:823f032, Aug 5 2026, 10:51:32) [MSC v.1944 64 bit (AMD64)]
C:\tmp\rg-v2-phase13-py3147-runtime-20260901\python.exe
CPU exact Fraction/float64; no torch imported
n=1000: float evidence cell=4.6663180925160944e-302; conditional_kl=0.0; residual=0.0
n=1072: float evidence cell=1e-323; conditional_kl=0.0; residual=0.0
n=1073: float evidence cell=5e-324; conditional_kl=0.0; residual=0.0
n=1074: float evidence cell=0.0; ValueError: posterior requires positive evidence
n=1075: float evidence cell=0.0; ValueError: posterior requires positive evidence
n=1100: float evidence cell=0.0; ValueError: posterior requires positive evidence
```

At the measured crossover `n=1074`, the exact evidence remains positive and `-log(e)=744.4400719213812`. Binary64 rounds each `2**(-1075)` cell to zero before summing, destroying support. This is a representation-conversion failure, not inaccurate exact Fraction arithmetic.

Reachability is the reusable public API only: `ExactProbabilityLaw`, `ExactMarkovChannel`, population construction, inference derivation, and aggregation validators impose no lower bound on positive rational mass or denominator. The two-state witness satisfies those ordinary contracts. The checked-in phase launchers instead pin `exact_rational` and specific fixtures (`frs_s3_two_topology_v1`, `fds_s3_finite_depth_v1`, `fcc_d4_complete_carrier_v1`), enforced in their experiment validators. This probe does not show a failure of those fixtures, and no such failure is claimed.

**Fix:** Compute diagnostics from exact normalized posterior/conditional laws with rational-aware log evaluation and an explicit representability policy, so underflow in the raw evidence mirror cannot abort otherwise valid exact aggregation.

**Falsifies:** The same permitted two-state construction at `n=1074` passes unchanged public validation and returns its exact aggregate with finite zero conditional KL, or an existing public arithmetic-domain restriction is shown that legitimately excludes these positive rational inputs before aggregation.

## Reviewed surfaces without additional findings

The Phase 10 marginal residual checks exact differences before conversion, so its always-zero float mirror does not certify an independent float computation, but it also cannot mask nonzero exact differences. Phase 11 prefix compositions, Dobrushin coefficients/submultiplicativity, and stationary RREF use Fraction operations and exact comparisons. Phase 13 canonical prime-log expressions collect rational coefficients by prime; the inspected decomposition retains exact expressions. The private Phase 13 relative-entropy routine assumes strictly positive fixture laws; a zero-mass counterexample outside that frozen scope was not promoted to a finding. No numerical defect of those pinned paths was established.

## Reproduction and limits

```powershell
& 'C:/tmp/rg-v2-phase13-py3147-runtime-20260901/python.exe' -I -B .verification/astra-audit/numerics_probe.py
```

The probe injects the isolated root and `src` explicitly and disables automatic GC before repository imports. It runs in one process, without torch, GPU, workers, producers, publication workflows, or pytest. The source and complete JSON-line output are `numerics_probe.py` and `numerics_probe.txt` beside this report. Only audit-owned files were written. Tamper/corruption/forgery/malicious-packet checks were user-excluded and not run. Research-wiki procedure and index were consulted for context; the numerical conclusion comes from current executable source and recorded reproduction.

