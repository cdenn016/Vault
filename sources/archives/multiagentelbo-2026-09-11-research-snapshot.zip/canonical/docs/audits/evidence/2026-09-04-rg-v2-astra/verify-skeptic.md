# Verifier Skeptic Results

Running model: GPT-5.5 per dispatch. Author model under review: Astra per dispatch. Same-model check: different model per dispatch, so I proceeded. Artifact binding: ok, `git:89b76447d11567c52980471e580bf325f90d35bc:sha256:5929e6800eb9c907cd4e36e07cffc3ce29755683a9960d5ffe8798ba5cac90cf`.

The gate validation did not report drift. It failed only because the intentionally incomplete ledger is in closure mode while claims are still `CANDIDATE`. A direct call to the installed gate's `capture_artifact_revision(Path(worktree), excluded_paths={active_ledger_path})` matched `.verification/active.json` and the ledger artifact revision exactly.

## RG2-01
claim_id: RG2-01
result: support
rationale: Source converts exact Fraction masses and channel entries to float before mandatory diagnostics; the probe shows positive exact evidence underflows to 0.0 at powers 1074+ and aggregate_population raises ValueError even though posterior equals q and exact conditional KL is zero. Scope is the generic public API, not current frozen fixture values.
view_ids: []
evidence_ids: [RG2-01-e1, RG2-01-e2]
result_location: .verification/astra-audit/verify-skeptic.md#RG2-01
criterion_levels: execution=strong, input_output=strong, configuration_scope=adequate, reproducibility=adequate
open_obligations: []
artifact_binding: ok

## RG2-02
claim_id: RG2-02
result: support
rationale: The test hashes design_path.read_bytes() as a Git blob and physical SHA-256, then expects that physical-byte identity in the plan. .gitattributes has text=auto, and source-binding.log records the exact mismatch on the current checkout. This supports the CRLF-sensitive failure mode.
view_ids: []
evidence_ids: [RG2-02-e1, RG2-02-e2, RG2-02-e3]
result_location: .verification/astra-audit/verify-skeptic.md#RG2-02
criterion_levels: execution=strong, input_output=strong, configuration_scope=adequate, reproducibility=strong
open_obligations: []
artifact_binding: ok

## RG2-03
claim_id: RG2-03
result: support
rationale: Source contains hard 120-second readiness and release-event timeout raises while AGENTS.md makes Phase 13 elapsed values reporting-only. The probe reaches the barrier timeout with synchronization doubles. This supports branch reachability only; it does not prove a real delayed worker startup or frequency.
view_ids: []
evidence_ids: [RG2-03-e1, RG2-03-e2]
result_location: .verification/astra-audit/verify-skeptic.md#RG2-03
criterion_levels: execution=adequate, input_output=adequate, configuration_scope=adequate, reproducibility=adequate
open_obligations: [A real delayed-startup reproduction is needed for any claim stronger than branch reachability; it was intentionally not run here.]
artifact_binding: ok

## RG2-04
claim_id: RG2-04
result: abstain
rationale: Source shows collect_provenance records dirty_tree_sha256 and Phase 11/12 admission checks config_hash and git_commit, but the ledger has no evidence entry for an actual environment where dirty_tree_sha256 is unavailable and still accepted. I did not run fake provenance injection or filesystem-fault fabrication.
view_ids: []
evidence_ids: []
result_location: .verification/astra-audit/verify-skeptic.md#RG2-04
criterion_levels: execution=absent, input_output=absent, configuration_scope=weak, reproducibility=absent
open_obligations: [Produce non-forged reproduced output from a real provenance collection path where dirty_tree_sha256 is unavailable and downstream Phase 11/12 admission still accepts the packet.]
artifact_binding: ok

## RG2-05
claim_id: RG2-05
result: support
rationale: The legacy regression test and manifest reference run_scale_cocycle_lab.py. The probe reports mentions_run_rescaling_figures=false and mentions_run_scale_cocycle_lab=true, supporting the claim that legacy_rescaling_v1 is not an execution/reference oracle for retiring run_rescaling_figures.py.
view_ids: []
evidence_ids: [RG2-05-e1, RG2-05-e2]
result_location: .verification/astra-audit/verify-skeptic.md#RG2-05
criterion_levels: execution=adequate, input_output=adequate, configuration_scope=strong, reproducibility=adequate
open_obligations: []
artifact_binding: ok

## RG2-06
claim_id: RG2-06
result: support
rationale: Config resolution creates a default compute block when compute is omitted, but canonical_config_json removes compute when compute_explicit is false. Phase 12/13 compare the resolved compute to the default and require omitted deterministic CPU compute. The probe records effective CPU float64 compute with canonical_has_compute=false.
view_ids: []
evidence_ids: [RG2-06-e1, RG2-06-e2]
result_location: .verification/astra-audit/verify-skeptic.md#RG2-06
criterion_levels: execution=adequate, input_output=adequate, configuration_scope=strong, reproducibility=adequate
open_obligations: []
artifact_binding: ok

## RG2-07
claim_id: RG2-07
result: support
rationale: The config hash includes numerics, and Phase 12/13 pass numerics through construction and default checks. The probe shows alternate numerics are accepted and alter the config hash, while recorded consumers are config/default checks rather than exact-rational computation. This supports the low-severity metadata-clarity claim.
view_ids: []
evidence_ids: [RG2-07-e1, RG2-07-e2]
result_location: .verification/astra-audit/verify-skeptic.md#RG2-07
criterion_levels: execution=adequate, input_output=adequate, configuration_scope=adequate, reproducibility=adequate
open_obligations: []
artifact_binding: ok

## RG2-08
claim_id: RG2-08
result: support
rationale: source-excerpts.json shows the Research vault 07b says every nonrescaling premise is satisfied, while repository 07b says equivariant conditional versions are additional hypotheses, gives no general construction, and requires applications to verify both equivariant conditionals and compatible rescaling kernels. The source discrepancy is directly reproduced.
view_ids: []
evidence_ids: [RG2-08-e1, RG2-08-source]
result_location: .verification/astra-audit/verify-skeptic.md#RG2-08
criterion_levels: quotation_fidelity=strong, freshness=adequate, source_scope=strong, claim_precision=strong
open_obligations: []
artifact_binding: ok

## RG2-09
claim_id: RG2-09
result: support
rationale: Theory/07c places eta outside E_mu in the independent and correlated pushforward formulas. geometry-report.md supplies a finite two-state off-diagonal-edge deterministic-endpoint counterexample satisfying the displayed endpoint-independence condition: true coarse event law is (1,0), but the displayed random-eta expression gives (1/2,1/2). geometry-probe.json records the exact Fraction TV gap. A fixed-eta or conditional-on-fine-state theorem would be narrower than the printed claim.
view_ids: []
evidence_ids: [RG2-09-e1, RG2-09-e2, RG2-09-proof]
result_location: .verification/astra-audit/verify-skeptic.md#RG2-09
criterion_levels: statement_precision=adequate, assumptions=strong, derivation_validity=strong, source_scope=strong
open_obligations: []
artifact_binding: ok
