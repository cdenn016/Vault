# Local sector algebra and information-loss boundary

This argument concerns the frozen local D4 action tables and an ordinal-preserving sector map. It is not an implementation or full admission of Phase 14.

Write the edge index modulo four. A rotation acts by j -> j+k; a reflection acts by j -> k-j-1. The map J(v_i,e_j)=(v_i,e_(j+2)) commutes with either action because -(j+2) and -j+2 are equal modulo four. J is an involution and maps each incident flag to the nonincident flag at the same ordinal in the two source tables. The diagonal product action on three pairs therefore also intertwines any product of these maps. Graph links do not depend on the incidence flag in the inspected literal catalog construction. This local proof does not by itself check every decorated field, structural square, induced action, or inverse/composition datum required by the approved plan.

For a positive finite law pair q,p and deterministic map r, group terms in relative entropy by t=r(s). With Q_t=sum_(r(s)=t) q_s and P_t=sum_(r(s)=t) p_s, expand log(q_s/p_s)=log(Q_t/P_t)+log((q_s/Q_t)/(p_s/P_t)). Summation gives

D(q||p) = D(r_*q||r_*p) + sum_t Q_t D(q(.|t)||p(.|t)).

The summands in the defect are nonnegative by the log-sum inequality. With strictly positive Q_t, strict loss occurs exactly when at least one conditional law differs. It does not follow merely from cardinality reduction. The executable sector check records unequal conditional distributions for every nontrivial fiber of each authored route under the frozen sector weights p_s=(s+1)/36, q_s=(8-s)/36.

The Phase 13 source law factorizes over sector and local ordinal, with likelihood independent of sector. Thus its posterior also factorizes with sector weights p. If an admitted quotient preserves the local ordinal and erases only the specified sector bit(s), the local divergence cancels from the difference and this sector calculation gives its KL loss. For the staged C12 step, use the already-pushed C01 sector weights, not the original weights of the standalone C12 comparison. Keeping a history that reveals the source sector makes this argument inapplicable to the full augmented target; the design correctly limits its claim to the declared marginal.

The Phase 13 C02 kernel keeps the source ordinal unchanged. It therefore admits exact source-ordinal recovery and cannot establish nonzero KL loss by itself. Its successful composition and covariance checks validate that lossless finite construction. They do not establish an attracting RG flow, universality, or a quotient not yet implemented.

Evidence: rg_v2/full_state_covariance_model.py (D4 action tables and incident flags); rg_v2/complete_carrier_covariance_model.py (nonincident flags); rg_v2/complete_carrier_covariance_composition.py:2122 (factorized laws), 2206 (structural kernels); local-sector-algebra.json (bounded exact table checks); phase14-design-input.md (remaining admission requirements).
