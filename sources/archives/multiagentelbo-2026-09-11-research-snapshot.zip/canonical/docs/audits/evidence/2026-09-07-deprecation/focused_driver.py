"""One selected focused packet with the pinned no-collection pytest boundary."""
import gc
gc.disable()
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[4]
sys.path[:0]=[str(ROOT),str(ROOT/"src")]
os.chdir(ROOT)
for name in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","BLIS_NUM_THREADS",
             "VECLIB_MAXIMUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
import pytest
from _pytest.unraisableexception import gc_collect_iterations_key
assert pytest.__version__=="9.1.1"
assert sys.version_info[:3]==(3,14,7) and sys.flags.isolated and sys.flags.dev_mode and sys.flags.dont_write_bytecode

class NoForcedCollection:
    def pytest_configure(self,config: pytest.Config) -> None:
        config.stash[gc_collect_iterations_key]=0

phase="focused"
out=Path(__file__).parent/phase
out.mkdir(exist_ok=False)
tests=[
    "tests/test_deprecation_boundary.py",
    "tests/rg_v2/test_legacy_regression.py::test_boundary",
    "tests/test_runtime.py::test_equal_seeds_produce_identical_named_stream_draws",
    "tests/test_runtime.py::test_named_streams_do_not_share_the_same_initial_draws",
    "tests/test_runtime.py::test_provenance_records_scipy_and_exact_input_hash_bindings",
    "tests/test_runtime.py::test_clean_git_status_has_false_dirty_flag_and_empty_stream_digest",
    "tests/test_counterexamples.py::test_tolerance_scaling_and_diagonal_condition_number_are_exact",
    "tests/test_scale_cocycle.py",
]
names=["src/multiagent_elbo/runtime.py","src/multiagent_elbo/finite/counterexamples.py",
       "src/multiagent_elbo/finite/__init__.py","src/multiagent_elbo/finite/scale_cocycle.py",
       "src/multiagent_elbo/config.py","src/multiagent_elbo/experiment_support.py",
       *sorted({test.split("::")[0] for test in tests})]
sources={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in names if (ROOT/name).exists()}
for name in sources:
    for node in ast.walk(ast.parse((ROOT/name).read_text(encoding="utf-8"))):
        if (isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute)
            and isinstance(node.func.value,ast.Name) and node.func.value.id=="gc"
            and node.func.attr in ("enable","collect")):
            raise RuntimeError("forbidden explicit collector call")
meta={"command":sys.orig_argv,"revision":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),
      "phase":phase,"source_sha256":sources,"runtime":sys.version,"executable":sys.executable,
      "started_utc":datetime.now(timezone.utc).isoformat(),"tests":tests,"retained_inventory":"not_run","purpose":"bounded deprecation compatibility; no science rerun",
      "tamper_checks":"user_excluded_not_run","pytest":pytest.__version__}
(out/"execution.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
code=pytest.main(["-q","-x","-p","no:cacheprovider","--basetemp="+str(ROOT/"artifacts/deprecation-audit/pytest-tmp"),"--junitxml="+str(out/"junit.xml"),*tests],
                 plugins=[NoForcedCollection()])
meta["exit_code"]=int(code)
suites=ET.parse(out/"junit.xml").getroot().findall("testsuite")
meta["junit_totals"]={k:sum(int(s.get(k,"0")) for s in suites) for k in ("tests","failures","errors","skipped")}
meta["junit_seconds"]=sum(float(s.get("time","0")) for s in suites)
meta["junit_sha256"]=hashlib.sha256((out/"junit.xml").read_bytes()).hexdigest()
meta["source_unchanged"]=all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in sources.items())
(out/"execution.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
print(json.dumps({k:meta[k] for k in ("exit_code","junit_totals","junit_seconds","source_unchanged")}))
raise SystemExit(code)
