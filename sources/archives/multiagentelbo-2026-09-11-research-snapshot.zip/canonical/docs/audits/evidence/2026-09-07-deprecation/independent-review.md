# Independent source review: RG v2 deprecation cleanup

Author model: GPT-6

Verifier model: gpt-5.6-sol
Baseline: `459aa48a2d5f07e655c686dca12e091f930a7bfa`

This was a read-only source and Git-metadata review. I ran no tests, imports,
science workloads, GPU work, process pools, or tamper/corruption/forgery
scenarios. The conclusions cover tracked repository consumers at this baseline;
they do not establish compatibility for untracked or external downstream users.

## 1. Exact 23-path retirement set: CONFIRMED

The inventory contains exactly 23 paths: one launcher, eleven finite-source
modules, and eleven dedicated tests (`retirement-inventory.json:4-29`). Every
path is tracked, exists at the baseline, and matches its recorded SHA-256; the
mechanical check returned `mismatch_count=0` for all 23 entries.

I searched all 1,042 tracked Python files for every retired module basename and
the launcher name, then removed the exact 23 inventoried paths from the result.
There were no surviving word hits for `bidirected`, `cocycle_flow`,
`contraction_backend`, `coupling_readback`, `environmental_blocking`,
`holonomy_selection`, `mark_carrying_parent`, `nested_tower`,
`participatory_blocking`, or `plaquette_action`. The surviving `rescaling` hits
were generic prose/config/schema terms rather than imports or calls. The only
surviving `run_rescaling_figures` string is an audit probe that records the
launcher's absence from the legacy capture
(`docs/audits/evidence/2026-09-04-rg-v2-astra/config_and_legacy_probe.py:24`).
The current lazy export table contains no retired module or symbol
(`src/multiagent_elbo/finite/__init__.py:46-82`), and its only dynamic import is
derived from that closed table (`src/multiagent_elbo/finite/__init__.py:85-95`).

This confirms no surviving tracked source/test direct, relative, lazy, or
literal dynamic consumer. It cannot exclude a consumer that constructs a name
without any retired basename in tracked text, or an external user importing an
undocumented module.

## 2. Two helper removals: CONFIRMED

`runtime._git_dirty` is a definition-only wrapper
(`src/multiagent_elbo/runtime.py:180-182`). The live provenance path computes
`git_dirty` directly from `_git_status_bytes` at
`src/multiagent_elbo/runtime.py:72-85`, so deleting the wrapper does not change
that tracked path.

`diagonal_spd_conditioning` is only a backward-compatible alias
(`src/multiagent_elbo/finite/counterexamples.py:582-584`). No other tracked
Python file names it. The retained implementation is
`diagonal_spd_condition_number` (`counterexamples.py:574-579`), imported and
used by the live experiment (`counterexample_experiment.py:19-43, 510-515,
561-568`) and its focused test (`tests/test_counterexamples.py:10-38, 349-351`).
Removing only the alias preserves every tracked live call.

## 3. Required retained seams and evidence: CONFIRMED

The proposed deletion list does not contain the scale-cocycle primitive,
experiment, launcher, two-scale fixture, categorical spine, fixed-ray/CUDA
controller and worker, `Theory/`, `rg_v2/`, results, audits, verification
records, or figure bytes; the inventory explicitly records this preservation
boundary (`retirement-inventory.json:68-72`). Source reachability independently
supports those exclusions:

- `run_scale_cocycle_lab.py:15-22, 54` calls the retained experiment, whose
  public runner reads `tests/fixtures/two_scale_application_v1.json`
  (`src/multiagent_elbo/finite/scale_cocycle_experiment.py:713-730`). The v1
  capture imports and executes the same path and hashes the fixture
  (`tests/rg_v2/test_legacy_regression.py:52-68, 393-394`).
- The categorical falsification experiment imports both retained shared
  components directly (`categorical_falsification_experiment.py:38-45`).
- The fixed-ray experiment imports the shared CUDA controller
  (`src/multiagent_elbo/realizations/gaussian/fixed_ray_experiment.py:22-30`)
  and resolves the retained worker (`:264-273`). The controller still declares
  fixed-ray CPU/CUDA strategies (`src/multiagent_elbo/cuda_backend.py:44-48`),
  and the worker retains both fixed-ray and historical blocked-contraction
  protocol inventories (`tools/cuda_worker.py:1-12, 57-65`).

The figure PDFs/PNGs and the republished result JSON are tracked and absent from
the removal inventory. This verdict confirms the proposed boundary; the later
implementation still must avoid staging any additional evidence or image
deletion.

## 4. Legacy `test_boundary` repair: CONFIRMED

The current boundary test builds an August baseline map for every
`src/multiagent_elbo/**/*.py` file except `config.py` and
`experiment_support.py` (`tests/rg_v2/test_legacy_regression.py:22-27, 255-285`),
then requires exact missing/extra/changed equality (`:288-298, 368-394`). A
baseline-to-`459aa48` Git comparison shows one preexisting additional drift:
`src/multiagent_elbo/finite/__init__.py` changed from eager exports to the
approved lazy table, while `config.py` and `experiment_support.py` are already
the two declared seams. Thus the boundary is already stale before this cleanup.

The correct repair is narrow: subtract exactly the 23 retired paths from the
expected/current comparison and pin explicit source exceptions for
`finite/__init__.py`, `runtime.py`, and `finite/counterexamples.py`. A broad skip
or removal of `_same` would discard useful protection for every remaining
package file, the reverse-import check (`:378-392`), and the launcher/fixture
blob checks (`:393-394`). The exact post-edit blob hashes should be pinned when
the implementation lands; this review cannot pre-verify hashes of unwritten
edits.

## 5. Root README test command: CONFIRMED, MEDIUM severity

`README.md:252-256` instructs users to run unrestricted pytest, while
`pyproject.toml:19-21` makes all of `tests/` the default selection. That set
contains the explicitly prohibited Phase 13 tamper node named by
`AGENTS.md:26-33` and defined at
`tests/rg_v2/test_complete_carrier_covariance_publication.py:3056`. The nearby
README result count is also an old 698-test snapshot (`README.md:265-268`), not
a current execution contract. The command must be replaced with current,
focused, non-tamper checks and an explicit pointer to the applicable runbook for
any gated long-running lane.

I do not confirm the candidate's high severity. This is **medium**: it is a
directly actionable instruction that conflicts with the current execution
policy, but it does nothing until a reader manually follows it, and the
repository policy explicitly names the excluded node. No prohibited check was
run during this review.

## 6. Historical figure/roadmap captions: CONFIRMED, MEDIUM severity

`figures/rescaling-lab/README.md` points to `docs/STATUS.md` section 16 as the
result authority (`:3-10`) but then repeats superseded claims: singleton
preference and a formation interpretation (`:27-30`), a modal flip and eightfold
anchor effect (`:32-36`), a quenched/annealed reversal (`:38-42`), and saturation
by 32 with a ninefold contrast (`:44-49`). The current authority says direct is
modal, withdraws the formation claim, reports a 32-fold anchor effect, says
quenched and annealed agree, places numerical saturation at 64, and reports a
5.6-fold contrast (`docs/STATUS.md:368-395`). The republished data independently
show direct mass `0.958252` at the seed
(`docs/results/2026-08-18-amendments-10-14-republication.json:7-21`), direct modal
in both flow variants (`:255-279`), saturation at 64/128 (`:337-370`), and
`0.006411 / 0.001138`, approximately 5.6, at zero inertia (`:373-385`).

`docs/ROADMAP.md` correctly says it supersedes nothing and that STATUS is the
sole claim authority (`:3-15`), but its body still repeats the retired singleton
masses and no-aggregation conclusion (`:146-159`) plus the retired
ninefold/tipping language (`:161-166`). Both README files need a prominent
supersession/recovery banner that links to `docs/STATUS.md` section 16 and the
republication JSON. The existing PNG/PDF bytes should remain as historical
evidence, explicitly labeled as superseded and recoverable from Git; removing
the old generator must not be presented as retracting that record.

This is **medium**, not high: the prose materially misstates scientific
interpretation and values, but both documents already identify STATUS as the
authority, the current authority explicitly names the retired readings, and no
runtime or evidence bytes are changed. I did not visually inspect the image
pixels, so this verdict establishes stale companion captions and the need for a
banner, not that every rendered panel embeds each stale sentence.
