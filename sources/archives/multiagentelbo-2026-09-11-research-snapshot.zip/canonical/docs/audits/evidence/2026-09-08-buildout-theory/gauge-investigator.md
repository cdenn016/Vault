# Gauge investigator: buildout, Theory, and neighborhood RG

Audit date: September 8, 2026. Inspected Desktop HEAD: `cce4d0eabf7abda451cacaa2297ce59963c5ce9f`. This source-and-derivation assessment covers the current neighborhood priority, foundation contract, completion roadmap and paused suite. Protected WIP was retained. The coordinating audit owns fresh mechanical verification.

No gauge-theory findings.

The inspected plan and neighborhood realization preserve the relevant theoretical distinctions. The absent general curved/noncompact/variable-support construction remains an explicit research obligation, not an undisclosed defect in the admitted flat SO(2) example.

## Local data, one joint ELBO, and RG

The theory starts with local descriptive probability data, not independently complete scalar agent VFEs whose sum determines the joint ELBO. `Theory/SPEC.md:9-30` first constructs the normalized population generative law and separately selects a recognition coupling; only then does it define the population ELBO. The common principal bundle supplies coordinate compatibility, not a probabilistic coupling. `Theory/SPEC.md:261-281` distinguishes joint recognition, posterior, event mass, receiver occupancy and conditional attention. Each observation record is counted once globally even when several local coordinate objectives include it.

The neighborhood source realizes this direction with a declared full population family. `src/multiagent_elbo/experiments/neighborhood/model.py:206-224` constructs a correlated 16-dimensional Gaussian, Gaussian observation model, posterior, correlated recognition Gaussian, reference, and separate correlated joint pair of edge events. Agent laws and conditional evaluators are extracted from those full laws at `model.py:282-297`. No local scalar VFE is assembled into the global law. `model.py:263-271` computes `KL(Q, posterior) - log_Z` at each level after the channels push full laws. This matches `Theory/07_general_renormalization.tex:76-137`: an RG arrow pushes an existing reference/evidence measure pair and preserves its mass.

The live route is `experiments/rg_v2/neighborhood.py`, the strict neighborhood config validator, and `src/multiagent_elbo/experiments/neighborhood/experiment.py`. The legacy `rg_v2/neighborhood_rg_model.py` and `neighborhood_rg_experiment.py` alias the packaged implementation. Admission requires exactly `overlap_so2_gaussian_marked_v1`; CUDA/float64 affects numerical placement and precision, while coupling and frame_scale reach the constructor. These toggles supply no unstated D4, GL(K), curved-connection or inference mode.

## Checked contracts

**Common bundle and cross maps.** `model.py:97-122` forms separate rotation blocks for each agent and channel; `model.py:300-304` supplies the reference identity intertwiner in those frames. The construction report at lines 13 and 63 explicitly selects identical standard SO(2) representations and their identity intertwiner. Equal representations and inverse cross maps are a declared specialization, not inferred from relative frames for inequivalent representations. This agrees with the quotient-representative proof at `Theory/02_geometry.tex:231-252`. The foundation contract at line 31 separately preserves the D4 family's stochastic cross maps and refuses a deterministic substitute.

**Actual Gaussian law pushforward.** `model.py:33-34` executes the mean map and `F @ Sigma @ F.transpose(-1, -2)`. Lines 237-241 apply it to prior, posterior, recognition and reference and retain observation cross covariance. Cross-agent/channel covariance is retained. This is neither diagonal projection nor precision/Galerkin pooling.

**Coarse covariance square.** The live map is `F = G_t L G_s^T`, with `L = W tensor I4` (`model.py:231-246`). For another passive chart, write `G'_s = T_s G_s` and `G'_t = T_t G_t`. Orthogonality gives `F' T_s = T_t F`; hence means and full covariances obey the same law square. This reconstructed identity holds away from identity initialization. It does not assert that a fixed off-diagonal mixer commutes with independent gauges.

**Atlas cocycle.** Smooth chart transitions satisfy `T_beta,alpha = G_beta G_alpha^T`; multiplying two transitions cancels the middle frame. This is a coboundary identity. Its numerical test measures arithmetic consistency and cannot establish nontrivial topology or general descent. The report at line 74 retains precisely that limitation.

**Connection defect.** `model.py:120-121` executes `A = -dG G^T` for the explicitly chosen zero reference connection. Differentiating F and adding `A_t F - F A_s` cancels the frame terms and leaves `G_t (dL) G_s^T`, the expression executed at lines 234-236 and exported at line 269. For SO(2), `A=-J dtheta` gives zero curvature. A generally nonzero coarse defect therefore coexists with flat endpoint connections. The actual horizontal-lift argument at `Theory/02_geometry.tex:349-407` makes transport preservation equivalent to zero defect; neither the source nor report claims that preservation here.

**Events precede attention rows.** `model.py:125-150` declares a normalized joint pair of channel edge events. Lines 160-165 push both endpoints of both events through one deterministic partition; lines 153-157 derive eta, alpha and beta afterward. Receiver occupancy and cross-channel event dependence are not replaced by averages of normalized rows. Independence between continuous state and event pair is explicitly selected in the report at line 15. Transported-divergence/Gibbs attention is not claimed.

**A genuine but restricted neighborhood.** The analytic windows, rotations, moments and kernels vary over the admitted open square (`model.py:75-88,97-122,197-220`). Positive denominators, SPD covariances and constant full row rank supply smoothness on this region. It is not merely a table of context samples. The constructor rejects contexts outside `(-0.6,0.6)^2`; it does not supply changing active-agent sets or a parent on the full union of the four disks.

The external convention check used Cohen, Weiler, Kicanaoglu and Welling 2019, Sections 2.1, 2.3 and 2.4, especially equation (4): represented field coordinates and transports transform by the appropriate endpoint coordinate maps. This primary source supplies no theorem about this program's coupling or coarse kernel. [Primary paper](https://proceedings.mlr.press/v97/cohen19d/cohen19d.pdf).

## Correctly deferred obligations

`docs/research-plans/2026-09-08-neighborhood-rg-overlapping-agents.md:23-25` refuses to infer a parent on a union from child-intersection data and requires compatible full probabilistic laws, not merely matching marginals. Lines 60-79 separately require restriction, chart/kernel, horizontal-defect, curve/graph and rank/support obligations. Lines 89-93 distinguish pointwise law sections from laws on smooth random sections and refuse to identify repeated finite D4 controls with a curved smooth connection.

The construction report retains these boundaries at lines 11-19, 61-74 and 106: one common intersection, trivial SO(2) topology, flat connections, continuous/event independence, no D4 embedding, no smooth-random-section law, no changing-support gluing, no arbitrary representations and no base-changing coarse map. The completion roadmap at lines 145-155 assigns the broader obligations to R7. The paused suite's Z2 oracle and nonflat D4 adapter remain separate steps.

A denser CUDA grid can study this example's resolution and numerical behavior. It cannot discharge changing-support descent, a nonflat extension, a general cross-representation construction or the D4-to-neighborhood bridge. The plan already says this, so no corrective finding is filed.

## Evidence boundary and revision binding

Historical `docs/verification/2026-09-08-neighborhood-rg/final.xml` records 11 tests, zero failures/errors/skips and 2.762 seconds. Its geometry tests cover chart covariance, finite-difference induced connection/curvature/coarse defect, frame-scale KL invariance and cross-map readouts. This investigator did not rerun or relabel those results as current-source evidence. No pytest node, CUDA calculation, producer, benchmark, tamper check or new numerical experiment ran. The identities above were reconstructed from executed formulas, not accepted from comments.

Memory supplied source routing only; present Theory/source files were reread for load-bearing conclusions. Research context consulted: Gauge equivariance and geometric deep learning; GL(K) gauge group; GL(K) gauge-equivariant attention; Agents as fibre-bundle sections; Parallel transport. Their implementation summaries were not treated as proof of current behavior.

| Inspected file | SHA256 |
|---|---|
| `Theory/SPEC.md` | `DEA95A12A376F5A7C103EECEB5A8613C428EDCA12DA065B6E3383FF6466B06B1` |
| `Theory/02_geometry.tex` | `DCC4593A0EE6BD1C3AC91E3FA2EBA09B54813ABD40A0597BC695DE70434D2702` |
| `Theory/06_general_coarsegraining.tex` | `FA10620D2A1D0E51B5A50B88D0A7434AFCDE6A0112AF062E74FED586E97D7166` |
| `Theory/07_general_renormalization.tex` | `CEDA98A49F4122DE39D70F784288860AB727ABFA217A92B1230591E6CE76BCAD` |
| `docs/research-plans/2026-09-08-neighborhood-rg-overlapping-agents.md` | `9E089A747B0257A1C0D89EE6B0E467F1E03442B6C90CDD9D28089A8AF11435E3` |
| `src/multiagent_elbo/experiments/neighborhood/model.py` | `EC01FFDA199A83AE3204301488BC01BDED48656288250F889022DFEBEB4B10FB` |
| `src/multiagent_elbo/experiments/neighborhood/config.py` | `CB0BC8C4B20856C54DC5129D61AC4E10A5F611F0EEA47EEEB420CE54C5BC5E5B` |
| `experiments/rg_v2/neighborhood.py` | `5F2BBAE43A160A6BD9DF08EC4ED515FD789D9AE3C5675D41640B0D31BBC15685` |
| `docs/reports/2026-09-08-neighborhood-rg-construction-and-runner.md` | `2D251FDE505C7646D909CE873E3A5F209C05F7165FF155AF5215DA10C188D44E` |

