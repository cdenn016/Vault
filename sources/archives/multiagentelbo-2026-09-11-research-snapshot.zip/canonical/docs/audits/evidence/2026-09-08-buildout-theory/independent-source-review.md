# Independent source and derivation review

September 8, 2026. This bounded independent review checks BT-01 through BT-06 against current source, reconstructs the mathematical arguments, and inspects the eight selected test bodies and their retained JUnit. It is not a formal verification-skill closure or a new full audit. No source, configuration, or plan was edited; no tests, experiments, heavy nodes, or tamper checks were executed by this reviewer.

The binding under review is `git:cce4d0eabf7abda451cacaa2297ce59963c5ce9f:audit-scope-sha256:fe7c543ce7a2d3eb2685eea132e590d89eefed45373e932e6cd71d77d8f914b5`. Every file hash in `source-binding.json` matched at the initial read. The final check is recorded below. This binds the inventoried live files, including planning WIP, rather than asserting the entire checkout is clean or current with a remote.

## Verdict

No scientific buildout-plan defect is established by these six claims. The plans correctly require a normalized population model and a separately selected full recognition law before evaluating the collective ELBO. They do not derive a population joint from independent marginal ELBO values. The confirmed defect is low-severity operator documentation drift (BT-06). BT-02 is confirmed with its amended explicit fixed-evidence wording, as detailed below.

| Claim | Judgment | Evidence and scope |
|---|---|---|
| BT-01 | CONFIRMED | Exact positive four-state counterexample below; `Theory/05b_local_collective_elbo.tex:464-526` distinguishes total-correlation and record-counting corrections. |
| BT-02 | CONFIRMED, with explicit fixed-evidence condition | Independent chain-rule reconstruction below; `Theory/05b_local_collective_elbo.tex:327-429`; runtime outside-marginal guard at `src/multiagent_elbo/finite/agent_network.py:612-621`. |
| BT-03 | CONFIRMED | `src/multiagent_elbo/rg_v2/population.py:214-289,646-694,729-765`; selected tests at `tests/rg_v2/test_population.py:100-123,361-383`. |
| BT-04 | CONFIRMED within the inspected realization | `src/multiagent_elbo/experiments/neighborhood/model.py:24-52,100-149,190-249`; selected tests at `tests/rg_v2/test_neighborhood_rg.py:49-149`. |
| BT-05 | CONFIRMED | `docs/research-plans/2026-09-08-neighborhood-rg-overlapping-agents.md:3-25,54-58,75-93`; suite pause at `docs/research-plans/2026-09-07-gauge-vfe-multiagent-suite-design.md:5`; roadmap boundary at `docs/research-plans/2026-09-07-gauge-vfe-rg-completion-roadmap.md:5-7,63-73`. |
| BT-06 | CONFIRMED, low severity | Legacy launcher links at `docs/reports/2026-09-08-neighborhood-rg-construction-and-runner.md:5` resolve to absent files. `src/multiagent_elbo/rg_v2/README.md:8` directs running `experiments/rg_v2/base.py`, whose complete source contains a docstring and four dictionary assignments only. |

## Independent mathematical reconstruction

Take two bits with posterior pi=(1/4,1/4,1/4,1/4), and let the sole observation have evidence Z=1. Compare q0=pi with q1=(3/8,1/8,1/8,3/8). Every entry is strictly positive. Both laws have the same fair one-bit marginals, so both agents' marginal KLs and marginal VFEs are zero in both cases. The collective VFE for q0 is zero, whereas for q1 it is

`KL(q1 || pi) = (3/4) log(3/2) + (1/4) log(1/2) = (3/4) log 3 - log 2 > 0`,

because 27>16. Thus even the complete marginal laws, and therefore their local scalar VFE values, do not determine the collective value. This counterexample proves the negative statement without relying on floating-point agreement or investigator judgment. It does not say that additive formulas are impossible under additional product or bookkeeping hypotheses.

For BT-02, fix the same observation model, evidence Z, posterior pi, and block split (y,b). Write pi(y,b)=pi_out(b) pi_B(y|b), q(y,b)=q_out(b)r(y|b), and q'(y,b)=q_out(b)r'(y|b). Expanding the density ratio logarithm gives

`KL(q || pi) = KL(q_out || pi_out) + E_qout KL(r || pi_B)`.

Subtract the corresponding q' identity. The outside KL cancels. Since collective VFE is KL minus log Z, its fixed evidence term cancels too. The conditional local VFE is KL(r || pi_B) minus log Z_B(b); its pointwise evidence term cancels before taking the expectation. Hence

`F(q') - F(q) = E_qout [F_B(r';b) - F_B(r;b)]`.

Finite global KLs supply finite conditional-KL integrals and avoid subtracting infinities. The outside marginal must remain fixed, the local target must be the conditional of that same posterior, and the evidence experiment must remain unchanged. Holding the normalized posterior alone while altering evidence is insufficient: multiplying a positive observation likelihood by a permitted constant leaves its posterior unchanged but shifts VFE by minus the logarithm of that constant. The root task amended BT-02 to state this fixed-evidence condition during review. It is not a defect in the cited theorem, which explicitly fixes the observation problem. Independent parallel replacement of arbitrary full conditionals is not justified by the identity.

## Independent executable reading

The ordinary constructor multiplies every normalized DAG agent kernel and every owned record kernel once, then checks that the full table sums to one. Its parameters contain agents, records, and context, with no recognition parameter. `derive_population_inference` selects Q separately, extracts a column from the completed population joint, sums that column for evidence, and normalizes it for the posterior. Recognition support checks can reject invalid data; they do not alter the probabilities of P, evidence, or posterior on admitted inputs. The selected correlated/product fixture test explicitly checks a recognition TV distance of 1/2 alongside identical P, evidence 6953/40000, and posterior. This supports the stated ordinary path, not a blanket claim about every historical RG-v2 extension.

The neighborhood model supplies a joint correlated 16-dimensional Gaussian and a joint 256-state pair of marked events. Their product is a declared restriction: the continuous coordinates and event pair are independent. Gaussian conditioning and an independent Bernoulli event observation give the full posterior; Q is supplied by a smooth shift/covariance perturbation and event tilt. It is not a trained variational optimum. Every level pushes all four named laws through the same Gaussian map and event membership map. The preserved observation marginal and pushed cross covariance independently reconstruct the coarse Gaussian posterior in the selected test. Event sums check mass preservation. Merely copying `log_Z` would be weak evidence by itself; the same-channel construction and disintegration test are the reason the evidence-preservation interpretation is supported.

For the geometry, G is orthogonal and A=-(dG)G^T. With F=G_parent L G_child^T, direct differentiation yields `dF+A_parent F-F A_child=G_parent(dL)G_child^T`. The nonzero defect therefore reflects context-varying weights, while the chosen connections are flat. The tests check this identity by finite differences, chart cocycles, and transformed full laws at selected context points. Neither those tests nor this construction establishes nontrivial topology, curved connections, changing-support gluing, arbitrary overlaps, or a changed-base RG map. The admitted U is one common overlap and coarse arrows cover its identity. The current plans retain these exclusions explicitly.

## Recorded mechanical evidence and documentation issue

`focused.xml` records exactly eight tests, zero failures, zero errors, zero skipped, and suite time 1.396 seconds. All eight names match the inspected local/global, population, and neighborhood bodies. These retained outcomes are execution evidence supplied by the root task; this reviewer did not rerun them. They are bounded checks, not proof of a general smooth construction or a full suite certificate. Tamper checks were user-excluded and were not run.

The two legacy neighborhood paths were checked directly with `Test-Path` and both were absent. The base profile has no imports, function calls, or execution guard, so invoking it directly only creates dictionaries and exits. The current root `README.md:3-4,49-50` correctly routes operators through `run_lab.py` and its Windows launcher. Updating the two stale documentation locations to that dispatcher and the relevant profiles resolves the identified operator defect; source behavior and the scientific plans need not change for that fix.

Final non-mutating source check: all 239 inventoried file hashes rechecked; 0 mismatches. The artifact revision was not repinned.

