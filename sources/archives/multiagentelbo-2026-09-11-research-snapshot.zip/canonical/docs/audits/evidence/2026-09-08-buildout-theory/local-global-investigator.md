# Local and global ELBO investigator

September 8, 2026. Read-only theory/plan/code review at live checkout HEAD cce4d0eabf7abda451cacaa2297ce59963c5ce9f, with protected WIP. Scope: local-to-population probability construction, exact conditional VFE identity, overlapping local accounting, and the four named buildout plans. No source/plan edits, suite tests, model experiments, GPU work, or tamper checks were run by this investigator. A four-state symbolic algebra check ran with SymPy 1.14.0 under C:/anaconda/python.exe.

## Verdict

No variational-inference findings in this bounded plan/theory comparison.

The user's proposed description is partly right: the theory begins with local descriptive data, but not with independent single-agent ELBOs that are summed into a global ELBO. It constructs a fixed normalized population generative law and separately selects a full recognition coupling consistent with the local laws. These probability objects define one global ELBO. Exact single-agent and block VFEs are conditional objectives of that same joint. RG pushes the full laws through a common channel to define a parent ELBO for the same observation evidence.

## Source-grounded construction

The pipeline at Theory/SPEC.md:9-28 is local agent declarations, local mechanisms, local recognition laws and owned record kernels -> normalized population joint plus selected recognition coupling -> ELBO. Theory/04_generative.tex:123-169 constructs the latent law by ordered normalized agent kernels in a finite DAG; design-point independence is a separate hypothesis. Theory/04_generative.tex:276-301 attaches normalized observation records. The undirected alternative needs its own finite partition function at Theory/04_generative.tex:317-346.

Recognition selection is a separate premise. Theory/03_probability.tex:509-616 defines the coupling class, proves a measurable product coupling exists, and requires a declared measurable selection for the chosen dependence. Two non-Dirac marginals generally do not determine their joint. Local marginal means, covariances, entropies, or optimized ELBO values cannot identify population dependence.

For a fixed observation, write the unnormalized evidence slice as mu_o, its mass as Z_o, and posterior as Pi_o=mu_o/Z_o. On the finite/integrable tier,

    F_o(Q) = integral log(dQ/dmu_o) dQ = KL(Q||Pi_o) - log Z_o;
    L_o(Q) = -F_o(Q).

Substitute mu_o=Z_o Pi_o and integrate the constant against a probability law. Theory/05_elbo.tex:157-204 gives the construction. Blei, Kucukelbir and McAuliffe (2017), section 2.2, equations 12-14, gives the same standard ELBO identity; the primary author paper was checked at https://arxiv.org/pdf/1601.00670. The extended-real formulation remains defined at infinite KL; ordinary subtraction of two infinite VFEs does not.

## Exact local/global derivation

Split Y=(Y_B,Y_out), write Q=Q_out r_B, and let Pi_B(.|b) be the fixed posterior conditional. Let Z_B(b) denote incident-record evidence relative to the baseline conditional. The local objective is

    F_B(r_B;b) = -log Z_B(b) + KL(r_B(.|b)||Pi_B(.|b)).

The KL chain rule is

    KL(Q||Pi_o) = KL(Q_out||Pi_out) + E_Qout KL(r_B||Pi_B).

For two finite-KL laws Q=Q_out r_B and Q'=Q_out r'_B, the outside KL, global log evidence, and conditional log evidence cancel:

    F_o(Q')-F_o(Q) = E_Qout [F_B(r'_B)-F_B(r_B)].

This is Theory/05b_local_collective_elbo.tex:388-428. Exact conditional replacement decreases the collective VFE while preserving the outside marginal and evidence problem. Independently replacing all correlated full conditionals in parallel is not licensed: arbitrary replacement conditionals need not define a joint.

The local functions do not simply add. Under a product baseline rho=product_i rho_i,

    F_o(Q) = TC(Q) + sum_i KL(Q_i||rho_i) + E_Q sum_a E_a;
    TC(Q) = KL(Q||product_i Q_i).

Each record occurs once in this ledger. Summing incident local energies counts record a exactly |boundary(a)| times: twice for a shared pair record, three times for a triple record. Theory/05b_local_collective_elbo.tex:464-526 proves this and distinguishes separate ordered/counting-number ledgers. Substituting marginal entropy for joint entropy makes VFE smaller by TC and the putative ELBO larger by TC, so it need not remain a bound (Theory/05_elbo.tex:72-117).

## What RG does

For one normalized recognition-independent channel C, the parent laws are P_A=P C, Q_A=Q C, and Pi_A=Pi C. Keeping the observation space preserves Z_o. The common-channel chain gives F_fine=F_parent+Delta, where Delta is the parent-recognition-weighted KL between discarded fine conditionals. On the finite-KL tier, L_parent-L_fine=Delta>=0. This is tighter comparison after discarding distinctions, not increased evidence or construction of a learned global law. See Theory/06_general_coarsegraining.tex:255-339 and the pointwise-parent contract in Theory/SPEC.md.

## Plan and executable concordance

| Source | Observed behavior or requirement | Assessment |
|---|---|---|
| docs/research-plans/gauge-vfe-rg-foundation-contract.md:21-29,52-54 | Separates model, evidence slice, posterior and full Q; requires complete outside labels; separates exact rational premises from floating log displays. | Matches conditional theory. |
| docs/research-plans/2026-09-07-gauge-vfe-multiagent-suite-design.md:17-29,37-43,97-101 | Requires a fixed normalized joint and full Q; S3 uses sequential conditional updates and labels product approximations separately. | Correct proposed construction, currently paused. |
| docs/research-plans/2026-09-08-neighborhood-rg-overlapping-agents.md:23-25,45-56 | Supplies full laws on admitted overlaps, distinguishes pointwise laws from random-section laws, requires consistency for descriptions of one experiment. | Does not assume compatible marginals prove global gluing. |
| docs/research-plans/2026-09-07-gauge-vfe-rg-completion-roadmap.md:67-71,103-111 | Requires full recognition lifts, one target, sequential schedules and full normalizer derivatives for model learning. | Preserves theorem premises. |
| src/multiagent_elbo/finite/agent_network.py:511-537,597-627 | Full-law scalar; rejects unequal outside marginals before comparing local and global KL changes. | Matches the distinction; inspected, not rerun by this lane. |
| src/multiagent_elbo/rg_v2/inference_persistence_model.py:142-154,182-201 | Refresh is q_out*p_i/p_out; exact ratio chain and fixed-marginal checks. | Update is relative to an already supplied global target. |
| src/multiagent_elbo/rg_v2/recursive_parent_model.py:369-397 | Reconstructs both observation submeasures from prior, posterior and evidence, and checks the fixed sensor. | Does not silently substitute a posterior table for the complete generative model. |
| src/multiagent_elbo/experiments/neighborhood/model.py:190-241,251-270 | Full correlated Gaussian prior, posterior, supplied perturbed full Q; pushes all law variants through common maps; reports KL(q,p)-log_Z. | Bounded full-law construction, not independent-agent optimization producing a global law. |

## Executed symbolic check

SymPy 1.14.0 used exact target p=(2/5,1/10,1/5,3/10) and q=(1/10,1/5,1/5,1/2) in (00,01,10,11) order. Refreshing the first bit conditional on the second preserved outside marginal (3/10,7/10) exactly. The local/global symbolic residual was 0. With evidence Z=3/7, the residual of F(q)-KL(q,p)+log Z was 0.

The correlated witness q=(3/8,1/8,1/8,3/8) and uniform product law have identical fair one-bit marginals, but KL=log(3^(3/4)/2)=0.13081203594113696 nats. Marginals conceal a nonzero population VFE gap. These tiny calculations check finite identities, not every runtime configuration or convergence.

## Provenance

Theory/05b_local_collective_elbo.tex SHA256: b0ef14dbe891d7890740d6f1e27ced56a6d05c2512804d2de672891a98aab84b.

Prior context: MEMORY.md:260-265. All substantive scope statements were rechecked in current source. Research/wiki/projects/Gauge-Theoretic Multi-Agent VFE Model.md:263-269 records the same local-coordinate and owned-factor distinction. The wiki was read only.
