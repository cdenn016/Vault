"""Reproduce the positive local/global example and capture explicit audit inputs."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[4]
here = Path(__file__).resolve().parent
paths = set()
for folder in ('Theory', 'src/multiagent_elbo/rg_v2', 'src/multiagent_elbo/experiments/neighborhood'):
    paths.update(p for p in (root/folder).rglob('*') if p.suffix in {'.py', '.tex', '.md', '.json', '.bib'})
for name in ('AGENTS.md', 'RG_V2_ROADMAP.md', 'README.md', 'run_lab.py', 'pyproject.toml',
    'docs/superpowers/plans/2026-08-09-six-session-theory-simulation-buildout.md',
    'docs/research-plans/2026-09-07-gauge-vfe-multiagent-suite-design.md',
    'docs/research-plans/2026-09-07-gauge-vfe-rg-completion-roadmap.md',
    'docs/research-plans/gauge-vfe-rg-foundation-contract.md',
    'docs/research-plans/2026-09-08-neighborhood-rg-overlapping-agents.md',
    'docs/reports/2026-09-08-neighborhood-rg-construction-and-runner.md',
    'src/multiagent_elbo/finite/agent_network.py', 'src/rg_v2/__init__.py',
    'experiments/rg_v2/base.py', 'experiments/rg_v2/neighborhood.py',
    'tests/test_agent_network.py', 'tests/fixtures/two_scale_application_v1.json',
    'tests/rg_v2/test_population.py', 'tests/rg_v2/test_neighborhood_rg.py', 'tests/rg_v2/conftest.py'):
    paths.add(root/name)
files = {p.relative_to(root).as_posix():sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
head = subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
revision = 'git:'+head+':audit-scope-sha256:'+sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()
binding = {'artifact_revision':revision,'scope':'Explicit audited source inventory including live dirty planning inputs; not a full-worktree activation.','files':files}
binding_path = here/'source-binding.json'
if binding_path.exists():
    assert json.loads(binding_path.read_text()) == binding, 'Audit inputs drifted; do not re-pin.'
else:
    binding_path.write_text(json.dumps(binding,indent=2)+'\n')
shutil.copyfile('C:/tmp/elbo-buildout-audit-20260908.xml', here/'focused.xml')
tree = ET.parse(here/'focused.xml').getroot()
cases = list(tree.iter('testcase'))
receipt = {'test_revision':head,'runtime':'C:/anaconda/python.exe','worktree':'C:/tmp/elbo-audit-20260908','device':'CPU only','junit_sha256':sha256((here/'focused.xml').read_bytes()).hexdigest(),'tests':len(cases),'failures':len(list(tree.iter('failure'))),'errors':len(list(tree.iter('error'))),'skips':len(list(tree.iter('skipped'))),'names':[c.attrib['name'] for c in cases],'suite_time':[s.attrib.get('time') for s in tree.iter('testsuite')],'omitted':['All tamper scenarios user-excluded/not run','No broad suite','No heavy producer/publication workflow','No CUDA experiment']}
(here/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
q = tuple(map(F, ('3/8','1/8','1/8','3/8')))
p = (F(1,4),)*4
assert sum(q)==sum(p)==1 and min(q)>0
assert (q[0]+q[1],q[2]+q[3]) == (F(1,2),)*2
assert (q[0]+q[2],q[1]+q[3]) == (F(1,2),)*2
assert tuple(a/b for a,b in zip(q,p)) == (F(3,2),F(1,2),F(1,2),F(3,2))
assert q[0]+q[3] == F(3,4) and q[1]+q[2] == F(1,4)
assert F(3,2)**3 * F(1,2) == F(27,16) > 1
example = {'q':list(map(str,q)),'p':list(map(str,p)),'global_kl':'(3/4) log(3/2) + (1/4) log(1/2) = log(27/16)/4 > 0','sum_singleton_marginal_kl':'0','each_expected_conditional_kl':'log(27/16)/4','sum_expected_conditional_kl':'2 * global KL','retain_first_bit':'qK=pK=(1/2,1/2); retained KL=0; discarded conditional KL=global KL','authority':'Exact rational premises and ordinary logarithm identities; no artifact corruption.'}
(here/'positive-counterexample.json').write_text(json.dumps(example,indent=2)+'\n')
print(json.dumps({'bound_files':len(files),'artifact_revision':revision,'execution':receipt,'example':example},indent=2))
