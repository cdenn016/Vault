# Renormalization V2 deep audit

Date: 2026-08-30  
Audited revision: `05fe2f90e7c15d2c7c4d813bae71420fd7aeb062` (`main` = `origin/main`)  
Narrative status: findings and reproduction record; claim closure is assigned only by the validated [claim ledger](evidence/2026-08-30-renormalization-v2/claim-ledger-v3.json)  
Mechanical record: [mechanical-evidence.json](evidence/2026-08-30-renormalization-v2/mechanical-evidence.json)

## Verdict

Renormalization V2 is the correct implementation branch to preserve. Its public claims are consistently limited to declared finite fixtures, and the checked exact probability, conditional-KL, gauge-action, composition, and finite-sector identities did not reveal a mathematical contradiction. The implementation is not yet a reliable foundation for the next carrier expansion without remediation: its strongest problems are in source/provenance binding and an explicit-zero representation that scales badly.

V1 should be deprecated now but not deleted yet. The current object named `legacy_rescaling_v1` does not capture the actual V1 rescaling launcher or its behavior, so it cannot serve as a safe deletion oracle. A true archival capture and a shared-dependency map must precede removal.

The concurrent Phase 13 worktree was fenced off. At the last read-only identity check it was on `codex/rg-v2-phase13-design-20260830` at `71309293310a8bee4594acf33020b774bc9f09b5` with three worktree-status entries. No Phase 13 file was inspected, executed, or changed during this audit. The Phase 13 items below are compatibility gates derived from the audited V2 seams and the user's frozen requirements, not findings against the unfinished Phase 13 implementation.

## Scope, authority, and method

The audit used a detached clean worktree at `C:\tmp\rg-v2-audit-clean-05fe2f9` for revision-bound checks and kept the user's dirty live checkout untouched. The repository `Theory/` tree was treated as implementation authority. Its `06_general_coarsegraining.tex`, `07_general_renormalization.tex`, `09_coarsegraining.tex`, and `10_renormalization.tex` copies matched the Research vault byte for byte. The repository versions of `Theory/SPEC.md` and `Theory/07b_agent_network_rg.tex` were later and contained additional fixed-fiber, normalized-membership, marked-event, and open-kernel obligations; the vault was therefore supplemental rather than controlling for this audit.

Parallel investigator waves covered code correctness, runtime reachability, dead code, performance, Python contracts, gauge covariance, information geometry, differential geometry, variational identities, numerical behavior, and configuration wiring. A separate evidence-gated verifier pass was then requested. This report does not promote agreement among agents to evidence; the ledger records verifier support, refutation, or abstention against the pinned artifact.

No full test suite, Phase 12 publication producer, Phase 12 independent replay, or Phase 13 calculation was run. Those paths are intentionally expensive and the other session owns Phase 13. Bounded CPU-only tests and exact in-memory witnesses used `C:\Python314\python.exe`, `CUDA_VISIBLE_DEVICES=-1`, and `PYTHONHASHSEED=0`.

## Findings

### RV2-01 — Phase 12 source binding depends on checkout line endings

Severity: medium.  
Location: `tests/rg_v2/test_full_state_covariance_fixtures.py:155-195`, `docs/superpowers/plans/2026-08-29-rg-v2-phase12-full-state-d4-covariance-implementation.md`, `.gitattributes`.

The Phase 12 fixture test recomputes a Git blob identifier and SHA-256 from physical worktree bytes, then requires the implementation plan to contain those values. The design specification is only `text=auto`; it has no `eol=lf` rule, while the plan directory does. At the audited commit, the committed LF object is 35,949 bytes, Git blob `2cd7d7fd2ac402f0e311d2d3ad4156f5d494fabb`, and SHA-256 `83e94f88e4582263b357e33116ab9bf3ae8f0c195e476ac70e4a6cb8f14984a7`. A normal Windows checkout materialized 750 CRLF sequences, producing 36,699 bytes, raw blob `0d0ee1de4dafcc77b2615c74f572d0c10ccaf119`, and SHA-256 `77e1e1f2d1b359fa4d644c2ff57b73377a171dcfec788210fc72462dae4dfc02`.

The bounded Phase 12 core run recorded 283 tests and one failure in JUnit: `test_producer_cap_amendment_and_design_plan_binding_are_exact`. This is a committed Windows reproducibility defect, not a scientific failure. The repair is to pin the specification directory to LF or to define provenance in terms of Git object bytes while separately labeling physical checkout bytes.

Falsification condition: a fresh Windows checkout of the audited revision passes the exact binding test without changing global Git configuration, or the binding contract is shown to require platform-specific physical bytes.

### RV2-02 — Phase 12 can publish a dirty tree without a usable dirty-tree identity

Severity: medium.  
Location: `src/multiagent_elbo/runtime.py:72-85`, `src/multiagent_elbo/runtime.py:146-177`, `rg_v2/full_state_covariance_experiment.py:591-603`.

`collect_provenance` computes `git_dirty` and `dirty_tree_sha256` independently. The digest routine returns `None` when a Git query fails, a path is unsafe, or an untracked file cannot be read. Phase 12 requires only a matching config hash and a 40-hex commit before freezing and publishing provenance. An in-memory seam witness produced `git_dirty=True` with `dirty_tree_sha256=None`; the Phase 12 acceptance path returned successfully. Phase 10 already supplies the relevant counterexample design by requiring concrete dirty/status values.

This does not change the exact science values. It does allow a completed artifact to claim a revision while leaving the additional executed bytes unidentified. Phase 12 should share a fail-closed provenance validator that requires a status digest and a dirty-tree digest whenever Git status is available, including the clean empty-stream digest.

Falsification condition: a reachable Phase 12 gate rejects `git_dirty=True` with a missing dirty-tree digest before science or publication, or the collector proves that combination unreachable for every supported filesystem object.

### RV2-04 — Phase 12 materializes large zero complements despite calling the carrier sparse

Severity: medium.  
Location: `rg_v2/full_state_covariance_model.py:598-650`, `rg_v2/full_state_covariance_model.py:2271-2284`, `rg_v2/full_state_covariance_composition.py:1037-1061`.

The sparse-kernel datum stores every zero coordinate as an explicit tuple. Construction and validation enumerate Cartesian universes and complements, while cached composition helpers retain shared complements. The corrected Windows working-set probe counted 2,355,712 unique shared zero-coordinate tuples, a total retained increment of 254,283,776 bytes, and a largest single-kernel transient increment of 378,904,576 bytes. The full two-control publication peak was not measured, so this report does not extrapolate it. An earlier 479 MiB retained estimate ignored sharing and was rejected.

Phase 12 remains executable within its declared caps. The representation is nevertheless the wrong seam to copy into an eight-sector Phase 13 design. Zero support should be represented by dimensions plus ordered positive support, with exact streamed cardinality, canonical order, and digest checks. Cross-sector zeros should be certified structurally, not materialized.

Falsification condition: the live publication path is shown to use lazy or bounded zero support, or a measurement of the named constructors shows the recorded retained/transient increments did not arise from explicit complement materialization.

### RV2-05 — `legacy_rescaling_v1` is not a regression capture of the V1 rescaling laboratory

Severity: medium.  
Location: `tests/rg_v2/test_legacy_regression.py:20-68`, `tests/rg_v2/test_legacy_regression.py:255-377`, `run_rescaling_figures.py`.

The capture boot imports and executes `run_scale_cocycle_experiment`, freezes twelve pre-V2 launchers, and records scale-cocycle artifacts. It does not execute `run_rescaling_figures.py`, whose behavior depends on `cocycle_flow`, `coupling_readback`, `environmental_blocking`, `nested_tower`, `participatory_blocking`, and `partition_dynamics`. Its boundary map also freezes nearly all installed package modules except two declared seams, so the test is simultaneously broader than V1 and incomplete as a V1 behavior oracle.

This matters for deletion. Passing the current manifest would not establish preservation or intentional retirement of the actual rescaling figure laboratory. Before removal, capture the V1 launcher, frozen inputs, declared expensive constants, semantic outputs, and hashes in a plainly named archival packet. Then map shared dependencies. In particular, `contraction_backend.py` participates in other finite/CUDA paths and must not be removed merely because it appears in the old rescaling neighborhood.

Falsification condition: a current manifest row or regression test is shown to execute the actual V1 launcher and bind its declared scientific outputs, not only unrelated pre-V2 launchers and the scale-cocycle experiment.

### RV2-06 — Effective compute defaults are executed but omitted from the resolved config identity

Severity: low.  
Location: `src/multiagent_elbo/config.py:354-370`, `src/multiagent_elbo/config.py:1074-1089`, the twelve V2 launchers.

When launchers omit `COMPUTE`, the loader injects `_default_compute_config` and marks the field implicit. `canonical_config_json` then removes both the marker and the effective compute block before hashing. All checked V2 launchers use this path. The source revision records which default implementation existed, but the artifact called `resolved_config` is not fully resolved, and a future default change can reuse the same config hash and run-directory identity under a different effective compute setting.

Persist and hash an `effective_compute` block for new runs. If old hashes must remain stable, keep the legacy identity as a separately labeled field rather than omitting executed settings.

### RV2-07 — Phase 12 accepts and hashes numerics that do not reach its science

Severity: low.  
Location: `rg_v2/full_state_covariance_experiment.py:418-446`.

Phase 12 round-trips the common numerics record but imposes no canonical Phase 12 values, and no later Phase 12 science, gate, metric, or publication calculation reads `config.numerics`. Legal values such as `atol=rtol=min_spd_rcond=0.5` and `max_frame_condition=1.0` pass the validator and change the config hash without changing the exact-rational packet. These fields should either be fixed to a canonical reporting tuple or explicitly labeled nonoperative for this experiment.

### RV2-08 — The Phase 8 replay trusts child aliases and decompresses before enforcing independent size caps

Severity: low; open hardening claim.  
Location: `tests/rg_v2/_adaptive_partition_artifact_oracle.py:2776-2840`.

The independent replay rejects a symlinked `run_dir` but opens each expected child by name without rejecting a child symlink or other reparse alias. It also calls `np.load(..., allow_pickle=False)` before applying an independent member-size or aggregate-uncompressed-size bound. `allow_pickle=False` closes object deserialization, but it does not bound decompression. This is relevant when packets are treated as adversarial evidence rather than trusted local output. No filesystem exploit was executed in this audit, so the ledger may leave this claim inconclusive. The appropriate repair is non-following child-file admission plus pre-decompression ZIP member and aggregate caps.

## Refuted or suppressed candidates

RV2-03 was refuted by the independent verifier. A coherent receiver/source label substitution with recomputed state content passes the production `_event_boundary` subgate, but the relocated oracle independently reconstructs the receiver and source actions, compares its reconstructed catalog digest, and rejects the packet with `full_state_route_mismatch` before covariance replay. The narrower subgate omission remains useful as a defense-in-depth mutation target; it is not an end-to-end certification defect and requires no missing oracle reconstruction.

The Phase 5 validator reconstructs the full assessment a second time, but the Phase 5 design explicitly requires fresh reconstruction as a certification step. Its cost is intentional, not dead work. The Phase 12 signed formal KL multiset is not a canonical scalar exact-log reduction, but Phase 12 claims exact term reconstruction and reindexing on one positive-support sector, not the stronger global sector-mixture theorem. The public name “full-state” is immediately qualified as the complete decorated state within the 512-state all-incident sector; the README and design explicitly exclude the 4096 carrier. No live SPD/Riemannian exp/log/retraction path exists in this finite `D_4` implementation, so importing Levi-Civita obligations into it would be a category error. The checked gauge, information-geometric, differential-geometric, and variational paths produced no additional finding.

Phase 8 context pickling, two sequential Phase 12 process pools, duplicate Phase 5 hashing, and a small runtime type-annotation mismatch remain optimization or maintenance notes. They do not outrank the findings above without measurement showing a cap violation or a runtime contract failure.

## Theory audit and Phase 13 compatibility gates

Phase 12's finite law construction is normalized on one declared support sector. The Phase 13 extension must define a single global law, not concatenate eight independently normalized Phase 12 laws. For sector weights `rho_s`, sector evidences `Z_s(o)`, recognition weights `q_s(o)`, and posterior sector weights

\[
\pi_s(o)=\frac{\rho_s Z_s(o)}{\sum_t \rho_t Z_t(o)},
\]

the global evidence is `Z(o)=sum_s rho_s Z_s(o)`. If `Q_s` and `Pi_{s,o}` are the normalized within-sector laws, the exact mixture identity is

\[
D(Q\|\Pi_o)=D(q\|\pi_o)+\sum_s q_s D(Q_s\|\Pi_{s,o}).
\]

The corresponding free-energy decomposition is

\[
F=D(q\|\rho)+\sum_s q_s F_s
=D(q\|\pi_o)+\sum_s q_s D(Q_s\|\Pi_{s,o})-\log Z(o).
\]

Extended-support behavior must be explicit: a positive `q_s` with zero `rho_s` or zero `pi_s(o)` gives positive infinity, while a zero-weight sector contributes zero. Phase 13's exact oracle should reduce the logarithmic terms canonically and separately verify the scalar identity and equality conditions; Phase 12's formal term multiset alone is insufficient for this new claim.

Gauge covariance does not imply sector conservation. Phase 13 must carry an explicit sector tag and prove that every structural map, kernel, direct/staged composition, and action has zero support between distinct sectors. Those zero proofs should be structural and sparse. The `III` inclusion/projection must reproduce the Phase 12 catalogs, laws, kernels, histories, digests, and metrics exactly under a declared compatibility map; approximate equality or a shared-formula assertion is not enough.

Although RV2-03 was refuted at the packet level, its coherent label-action substitution is a useful defense-in-depth candidate for Phase 13's twenty-four science mutations. The relocated Phase 13 oracle must preserve the existing independent receiver/source action reconstruction rather than importing the production subgate. The user's other frozen Phase 13 constraints remain unchanged: an additive subsystem, the complete 4096 carrier as eight invariant 512-state sectors, 72,202,414 exact CPU visits with at most twelve Ryzen workers, CUDA as reporting only, sparse cross-sector zero proofs, and a fixed ten-file packet.

## V1 disposition

The recommended disposition is staged deprecation, not immediate deletion. First, label `run_rescaling_figures.py` and its dedicated modules as historical V1 and stop presenting their conclusions as the current RG construction. Second, create a versioned archival packet that actually executes or faithfully replays the launcher and binds all non-recomputed constants to their source artifacts. Third, separate dedicated V1 modules from shared finite/CUDA infrastructure through import and registry reachability. Fourth, add an explicit removal test that proves V2 and the Phase 13 additive subsystem do not import the retired modules. Only then remove the launcher and dedicated code in a separate remediation change. Historical documents and figure provenance should remain available with their V1 status stated.

## Mechanical verification

Pytest collected 2,048 tests under `tests/rg_v2`. The bounded JUnit runs recorded 38/38 passing Phase 3 fixture tests in the clean audit worktree; the live checkout recorded 33 passing and five failing because `rg_v2/data/lf4_two_parent_recursive_v1.json` remained physically CRLF despite its current `eol=lf` attribute. The clean file matched the committed blob and passed, so this is stale local materialization rather than a defect in `05fe2f9`. No user file was rematerialized.

The Phase 12 core selection recorded 282 passing and one failing test, the Windows source-binding failure RV2-01. The VFE core selection recorded 80/80 passing. The focused event-transform and event-gate tests each passed. A separate coherent mutation witness passed the production event subgate, but independent verifier replay established that the relocated oracle rejects the mutated catalog with `full_state_route_mismatch`; the original RV2-03 candidate was therefore refuted. Exact JUnit totals, durations, source paths, and hashes are in the mechanical evidence file.

## Remediation order

The shortest safe order is: fix checkout-independent source binding; make provenance fail closed; replace explicit zero complements before any eight-sector scaling; create the true V1 archive and dependency map; then resolve the lower-severity config and replay-hardening items. Preserve the relocated oracle's independent event-label reconstruction and optionally add the coherent label-action mutation as defense in depth. Phase 13 integration should wait only on the seams it would otherwise copy: global mixture semantics and sparse zero representation. It does not require modifying Phase 12 science modules or artifacts.

The Research vault was consulted read-only. The repository contains newer implementation-authority material in `Theory/SPEC.md` and `Theory/07b_agent_network_rg.tex`; those differences should be offered for vault ingest as a separate, user-approved action rather than silently synchronized during an audit.
