# MultiAgentELBO buildout audit against Theory and RG v2

September 8, 2026. Audited checkout: `cce4d0eabf7abda451cacaa2297ce59963c5ce9f`, including the explicitly hashed live planning documents. Three domain investigators examined variational inference, executable construction/configuration, and gauge/neighborhood geometry; a separate reviewer checked the resulting claims against the primary sources. This is a bounded audit of the buildout's theoretical meaning and implemented connections, not a whole-codebase audit or recertification of historical experiments.

## Answer

The proposed description is partly right: **the theory and original RG-v2 constructor begin with local probability data, but they do not begin with independent single-agent ELBO values and combine those values into a global ELBO.** They construct a normalized population generative joint and separately choose a recognition coupling. Those full probability laws define the global ELBO. Conditional local objectives and their relation to collective inference can then be derived. Coarse-graining is a further operation on the full laws.

The most accurate short description is:

> Local agent mechanisms, observation records and recognition data -> normalized generative joint P plus a declared full recognition coupling Q -> one population ELBO -> compatible conditional inference and coarse parent ELBOs.

The current plans preserve this ordering. The investigators found no substantive mathematical contradiction within the plans' declared scope. They found one low-severity operator-documentation defect. The important remaining limitations concern the generality and connection of the constructions, rather than a missing rule for adding local ELBOs.

## What is local, and what must be supplied globally?

An agent supplies typed belief/model spaces, represented gauge actions, local law data and a generative evaluator. Observation records have declared owners/scopes and normalized kernels. The directed construction supplies a dependency order. In that specialization, suppressing structural parameters and the belief/model coordinate split, its form is

$$
p(y,o)=\prod_i p_i(y_i\mid y_{\mathrm{pa}(i)})\prod_a k_a(o_a\mid y_{\partial a}).
$$

Normalization follows from the ordered conditional construction and normalized observation kernels, not from each agent having a small VFE. An undirected product of potentials is another admissible route only when its partition function is included and finite. Each observation factor occurs once. These are the constructions in [Theory/04_generative.tex](../../Theory/04_generative.tex), particularly lines 123-169, 276-301 and 317-346, and the opening contract in [Theory/SPEC.md](../../Theory/SPEC.md), lines 9-28.

The recognition law is another probability object. Specifying local recognition marginals does not specify their dependence. A product coupling is one explicit choice; a correlated coupling needs additional relational data, parameters or a supplied joint that reproduces those marginals. This is the distinction in [Theory/03_probability.tex](../../Theory/03_probability.tex), lines 509-616. A global population law is not thereby an additional agent. Nor does the theory assert that every arbitrary collection of overlapping local conditionals has a compatible global joint.

For a fixed observation o, let the evidence slice be mu_o(y)=p(y,o), its mass Z_o=sum_y mu_o(y), and the posterior Pi_o=mu_o/Z_o. Then

$$
\mathcal L_o(Q)=\mathbb E_Q[\log p(Y,o)-\log q(Y)]
=\log Z_o-D_{\mathrm{KL}}(Q\Vert\Pi_o),
\qquad
\mathcal F_o(Q)=-\mathcal L_o(Q).
$$

This identity follows by substituting mu_o=Z_o Pi_o; it is not a separate emergence assumption. See [Theory/05_elbo.tex](../../Theory/05_elbo.tex), lines 157-204. The ordinary ELBO/evidence identity is also the standard result in Blei, Kucukelbir and McAuliffe, Section 2.2, equations 12-14, whose [primary author-hosted paper](https://www.cs.columbia.edu/~blei/papers/BleiKucukelbirMcAuliffe2017.pdf) was checked for this audit. The displayed ordinary differences below assume finite KL; extended-real identities do not license subtraction of infinities.

## Why independent local ELBOs cannot simply be added

There are two separate problems. Joint entropy is generally not the sum of marginal entropies, and a shared observation/interaction record can occur in several agents' incident objectives. With a product baseline rho, the exact accounting contains

$$
D_{\mathrm{KL}}(Q\Vert\textstyle\prod_i\rho_i)
=\sum_i D_{\mathrm{KL}}(Q_i\Vert\rho_i)
+D_{\mathrm{KL}}(Q\Vert\textstyle\prod_i Q_i).
$$

The final term is total correlation. Summing marginal complexity terms omits it. Independently summing incident energies counts a record once for every incident block instead of once in the population model. [Theory/05b_local_collective_elbo.tex](../../Theory/05b_local_collective_elbo.tex), lines 464-526, makes both distinctions. Correct ordered chain decompositions and explicitly justified counting schemes remain possible; the exclusion is the unrestricted sum of independently specified agent objectives.

A strictly positive four-state example makes the missing information visible. Take a neutral observation with evidence one, a uniform posterior p=(1/4,1/4,1/4,1/4), and Q=(3/8,1/8,1/8,3/8) in the order 00,01,10,11. Both singleton marginals of Q match p exactly, so the sum of their marginal KLs is zero. Nevertheless,

$$
D_{\mathrm{KL}}(Q\Vert p)
=\frac34\log\frac32+\frac14\log\frac12
=\frac14\log\frac{27}{16}>0.
$$

The population discrepancy is entirely in dependence. Even replacing marginal KLs with expected singleton conditional KLs does not fix naive summation: in this example each expected conditional KL equals the entire joint KL, so their sum doubles it. Exact rational premises and the log identity are recorded in [positive-counterexample.json](evidence/2026-09-08-buildout-theory/positive-counterexample.json).

What does work is conditional coordinate inference. Write Q=Q_out r_B and retain the same posterior, observation and outside marginal while changing r_B. The KL chain rule gives

$$
D_{\mathrm{KL}}(Q\Vert\Pi_o)
=D_{\mathrm{KL}}(Q_{\mathrm{out}}\Vert\Pi_{\mathrm{out}})
+\mathbb E_{Q_{\mathrm{out}}}D_{\mathrm{KL}}(r_B\Vert\Pi_B).
$$

Consequently the change in collective VFE equals the expected change in the conditional local VFE. The outside term and evidence constants cancel. This is a statement about a compatible change to one full joint, not an identity between the absolute global VFE and a sum of local VFEs. See the same chapter, lines 388-428. The executable `local_collective_difference` explicitly checks equality of the outside marginals before making that comparison.

## What RG actually does to the ELBO

For a normalized recognition-independent channel K on the admitted complete state, retaining the same observation record, the parent construction pushes P, Q and Pi_o through that channel. It preserves Z_o. On the finite-KL tier,

$$
\mathcal F_{\mathrm{fine}}
=\mathcal F_{\mathrm{parent}}
+\mathbb E_{QK}D_{\mathrm{KL}}\bigl(Q(dy\mid z)\Vert\Pi_o(dy\mid z)\bigr).
$$

For stochastic K, these are conditionals of the corresponding augmented laws Q(dy)K(dz|y) and Pi_o(dy)K(dz|y). The nonnegative defect is information discarded by the coarse description. Thus the coarse ELBO is at least the fine ELBO for this comparison, while the evidence is unchanged. This does not establish learning, autonomous parent dynamics, criticality, convergence or a renormalization-group fixed point. See [Theory/06_general_coarsegraining.tex](../../Theory/06_general_coarsegraining.tex), lines 255-339.

The complete channel includes any required event, boundary, holonomy and membership marks. Attention rows alone do not carry receiver occupancy or dependence between event channels. The current neighborhood construction pushes joint event mass before deriving coarse attention rows, which matches this requirement.

## The implemented constructions have different directions

| Construction | Actual inputs and direction | What this establishes |
| :--- | :--- | :--- |
| Original ordinary RG v2 | `population.construct_population_joint` receives local normalized generative and record kernels, multiplies each once, and checks normalization. Recognition is selected separately in `derive_population_inference`. | A finite local-data-to-joint construction. No local VFE scalar is an input. |
| D4 Phase 24 and B1/B3 | `recursive_parent_model` supplies a particular full physical law. The ordinary bridges disintegrate/factor that existing law and require exact reconstruction. | An ordinary-agent presentation of an already constructed D4 law, with bounded gauge/structural compatibility. It does not discover that law from local scalar objectives. |
| B2 correlated inference | `SliceProblem` explicitly carries prior, likelihood, evidence, posterior and recognition. Conditional refreshes operate relative to that fixed target. | A bounded same-family inference bridge. The foundation contract records stationary retained recognition and conserved geometry masses; this is not a four-root or neighborhood inference simulation. |
| Current neighborhood profile | A correlated 16-dimensional Gaussian and a joint categorical event-pair law are constructed directly. Posterior conditioning and a prescribed correlated Q follow; local agent readouts are derived afterward. | A smooth, nonconstant family of full laws and coarse maps over a common overlap region. It does not begin with independent single-agent optimizers. |

Primary executable locations are [population.py](../../src/multiagent_elbo/rg_v2/population.py), lines 213-288 and 657-765; [coarse_agent.py](../../src/multiagent_elbo/rg_v2/coarse_agent.py), lines 570-679; [recursive_parent_model.py](../../src/multiagent_elbo/rg_v2/recursive_parent_model.py), lines 174-208 and 369-397; [supported_ordinary_bridge.py](../../src/multiagent_elbo/rg_v2/supported_ordinary_bridge.py), lines 21-146; and [neighborhood/model.py](../../src/multiagent_elbo/experiments/neighborhood/model.py), lines 190-301. The public `src/rg_v2` namespace is now an alias for packaged implementations, not a second codebase.

## Assessment of the buildout plan

The original [six-session plan](../superpowers/plans/2026-08-09-six-session-theory-simulation-buildout.md) already required exact joint construction, a full recognition lift, a fixed-outside local/collective comparison and a counterexample to overlapping-objective summation. The later [completion roadmap](../research-plans/2026-09-07-gauge-vfe-rg-completion-roadmap.md), [foundation contract](../research-plans/gauge-vfe-rg-foundation-contract.md), [suite design](../research-plans/2026-09-07-gauge-vfe-multiagent-suite-design.md) and [neighborhood contract](../research-plans/2026-09-08-neighborhood-rg-overlapping-agents.md) maintain these distinctions. The September 8 instruction pauses simulation S1-S3 and prioritizes the neighborhood extension; the audit does not reinterpret that as authorization to implement the paused suite.

The plan is coherent as a sequence of conditional constructions and controlled numerical realizations. It is not evidence that a general simulator or every stronger RG result is already implemented. Three boundaries deserve particular prominence in the next handoff.

First, the new neighborhood example is a separate statistical family. It uses a trivial SO(2) bundle, identical two-dimensional belief/model representations, a flat reference connection, and a region lying inside every agent domain. Its continuous population state and event-pair state are independent by declaration. Attention varies smoothly with context but is not an inference-driven response to evolving peer beliefs. These restrictions are explicit in the construction report and do not violate a requirement that the general path remain available as theory.

Second, the coarse map is gauge covariant while its connection defect is generally nonzero. With F=G_A L G_I^T and the selected flat connection, the defect is G_A(dL)G_I^T. The implementation measures this term. It does not quietly equate gauge covariance with connection-preserving transport. General nonflat smooth connections, changing-support gluing, arbitrary representations, extension to unions with changing child sets and a map changing the base manifold remain additional obligations. The present common-overlap analytic family establishes more than unrelated point evaluations, but it does not solve those other gluing problems.

Third, constructing a smooth Q(c) is different from running an inference trajectory Q_t, and static law-level coarse-graining is different from constructing a closed parent process. The paused suite's sequential full-joint update, approximation/error and memory contracts are appropriate future requirements. The D4 bridge's bounded inference result and the neighborhood's prescribed recognition family do not establish general interacting-agent adaptation or persistent hierarchy formation. These are declared incomplete extensions, not newly discovered defects in an accepted implementation.

The most useful clarification to carry into future planning is the construction table above: identify whether each unit builds a joint from local kernels, presents an existing joint as local data, updates a recognition joint, or pushes a full law to a parent. All four operations are useful; none should inherit the others' existence or convergence claims simply because it is called multiagent RG.

## Retained finding

**F1, low: current operator instructions still name removed launchers or inert profiles.** The [neighborhood construction report](../reports/2026-09-08-neighborhood-rg-construction-and-runner.md), line 5, links `run_renormalization_v2_neighborhood_lab.py` and its CMD companion, both absent at the audited revision. The [packaged RG README](../../src/multiagent_elbo/rg_v2/README.md), line 8, instructs direct execution of `experiments/rg_v2/base.py`; that module now contains only a docstring and four dictionary assignments. The working path is to edit the profile, select it in `run_lab.py`, then invoke `run_lab.py` or `run_lab.cmd`. Following the stale instruction either fails to find a file or exits without running science. This affects operator access, not the ELBO mathematics.

The correction is limited to refreshing those operator links, profile-editing instructions and the README's obsolete package-layout description. Existing launchers at the exact linked paths, or actual experiment dispatch from the direct profile module, would falsify this finding. Source inspection, the investigator's inert-profile execution and the retained AST/file-existence check support it. No scientific high/critical finding requires adversarial escalation. No remediation was applied during this audit.

## Evidence and limits

The [execution receipt](evidence/2026-09-08-buildout-theory/execution.json) parses the retained [JUnit XML](evidence/2026-09-08-buildout-theory/focused.xml): **8 tests, 0 failures, 0 errors, 0 skips; 1.396 seconds.** They cover the literal local/collective identity, nonsummability, an independent population-joint enumeration, P/evidence/posterior independence from recognition selection, and neighborhood law/observation, event, chart and connection-defect checks. They ran once under `C:/anaconda/python.exe`, with CPU tensors, in a detached worktree at the inspected commit. The CUDA-capable interpreter reported torch 2.10.0.dev20251210+cu128 and CUDA available; no GPU study ran. The tests are bounded controls, not proof of general geometry or global absence of defects.

The [source binding](evidence/2026-09-08-buildout-theory/source-binding.json) records 239 explicit inputs, including the live planning WIP; [static-checks.json](evidence/2026-09-08-buildout-theory/static-checks.json) records equality of 185 source/config/fixture inputs with the test worktree. Theory derivations, a positive rational counterexample, and the investigator's exact symbolic calculation provide the mathematical evidence independently of numerical agreement. Current sources, rather than old memory results, determine the audit conclusions. The Research wiki and manuscript distinction were consulted without editing either source collection.

The independent review is recorded in [independent-source-review.md](evidence/2026-09-08-buildout-theory/independent-source-review.md). Domain investigations are retained in [local-global-investigator.md](evidence/2026-09-08-buildout-theory/local-global-investigator.md), [runtime-investigator.md](evidence/2026-09-08-buildout-theory/runtime-investigator.md) and [gauge-investigator.md](evidence/2026-09-08-buildout-theory/gauge-investigator.md). Conclusions are source-review findings, not a new automated publication certificate. The global verification skill is disabled, and its old activation points to an unrelated audit; it was not changed. The six-entry draft ledger and standalone schema validation are retained as triage records, with no formal EVIDENCE_VERIFIED closure claimed.

All tamper scenarios are user-excluded/not run. No broad suite, historical heavy producer, Phase 13 publication rerun, CUDA experiment or simulation buildout ran. Phase 13's operator acceptance is not recast as automated certification. Source code, configs, plans, manuscript files and preexisting WIP were preserved; changes from this audit are its new report/evidence files and an appended daily change-log entry.
