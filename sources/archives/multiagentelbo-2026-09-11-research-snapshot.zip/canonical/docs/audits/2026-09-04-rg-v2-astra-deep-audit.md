# RG v2 code and theory audit — September 4, 2026

The audit adjudicated 9 findings: 7 evidence-verified and 2 inconclusive. The most consequential new findings are a general adaptive-edge formula that loses statistical dependence and a public exact-aggregation API failure caused by float underflow. A current Windows source-binding test also reproduces an earlier defect. No high-severity finding was established. The remaining items concern a source discrepancy, legacy coverage, configuration metadata, and explicitly unresolved execution claims.

## Revision, authority, and execution scope

The source audit used one detached worktree at `C:/tmp/rg-v2-astra-audit-20260904`, pinned to `89b76447d11567c52980471e580bf325f90d35bc`. A fresh fetch showed the same `origin/main`; the latest remote log began with merge PR #39, the canonical-checkout synchronization documentation commit, and merge PR #38. The Desktop checkout was inspected without normalizing its working files. Its modified/untracked Phase 14 design and plan were copied as review inputs, with separate hashes, rather than substituted for the committed scientific source.

The scope was `rg_v2/`, its 13 click-to-run launchers, relevant shared configuration/runtime code, selected `tests/rg_v2/` checks, and the coarse-graining/RG chapters in `Theory/`. Twelve Astra investigators covered code quality, bugs, unused paths, performance, Python contracts, gauge theory, variational probability, numerical analysis, information geometry, differential geometry, runtime wiring, and scientific framing. Transformer training and optimization lenses were excluded because the audited subsystem uses exact finite CPU arithmetic and has no live neural training path.

The Research vault was consulted as requested. The repository and vault copies of `06_general_coarsegraining.tex` and `07_general_renormalization.tex` matched byte for byte; `SPEC.md`, `07b_agent_network_rg.tex`, and `07c_full_graph_meta_agent_vfe.tex` differed. A claim against one version is not automatically a claim against the other. The two explicit manuscript issues below identify their source.

Astra investigators generated candidates. Separate Sol and GPT-5.5 verification views checked their evidence and scope; an independently dispatched adjudicator assigned the ledger states. Model names refer to tool dispatch selections, not introspective model identification. Agreement was not used as mathematical or executable evidence. The archived ledger, reviewer outputs, test XML, exact probes, source excerpts, and hashes accompany this report.

Phase 13 remains operator-accepted with automated publication certification incomplete. This audit does not reopen that decision or convert the retained packet into a passing automated certificate. No Phase 13 producer, all-in-one publication node, relocated replay, full repository suite, worker pool, GPU calculation, or tamper/corruption/forgery/malicious-packet check ran. Phase 14 was not implemented. All prohibited checks are user-excluded/not run.

## Findings and dispositions

| ID | Severity | State | Finding |
|---|---|---|---|
| RG2-01 | medium | `EVIDENCE_VERIFIED` | Positive exact evidence underflows in mandatory diagnostics |
| RG2-02 | medium | `EVIDENCE_VERIFIED` | Windows design binding hashes CRLF against an LF object |
| RG2-03 | medium | `INCONCLUSIVE` | Admission timeout conflicts with reporting-only policy |
| RG2-04 | medium | `INCONCLUSIVE` | Phase 11/12 unavailable dirty-tree digest admission |
| RG2-05 | medium | `EVIDENCE_VERIFIED` | Legacy capture omits the laboratory it would replace |
| RG2-06 | low | `EVIDENCE_VERIFIED` | Canonical config omits effective implicit compute |
| RG2-07 | low | `EVIDENCE_VERIFIED` | Nonoperative numerical settings remain hashed metadata |
| RG2-08 | medium | `EVIDENCE_VERIFIED` | Vault and repository disagree about open conditionals |
| RG2-09 | medium | `EVIDENCE_VERIFIED` | Adaptive coarse-edge formula factors out random weights |

### RG2-09: the adaptive coarse-edge expectation drops dependence

The repository manuscript makes `eta_l` part of the random graph coordinate `G_l`, hence part of the input state `Y_l` (`Theory/07c_full_graph_meta_agent_vfe.tex:66–94`). Its adaptive edge formulas at lines 384–406 nevertheless place the fine edge weight outside an unconditional input-law expectation:
`sum_ij eta_ij E_mu[M(I,J|i,j,R)]`.
Conditional independence of the two endpoint assignments given the partition does not make the edge law independent of that partition.

A normalized finite counterexample uses two equally likely fine states on six vertices. Parent anchors are 1 in A and 4 in B. State 0 has edge law concentrated on (2,3) and partition A={1,2,3}, B={4,5,6}; state 1 has edge law concentrated on (5,6) and partition A={1,5,6}, B={2,3,4}. The common structural channel deterministically selects the associated partition. All fine active edges are off-diagonal. The endpoint assignments are deterministic conditional on the partition, satisfying the stated independence condition. Zero occupancies are explicitly admitted by the chapter.

The true coarse edge is AA with probability one. The displayed formula yields AA and BB with probability one half each, even under the charitable reading that the outside weight is its mean. Its total mass is still one: a normalization test alone would miss the error. The total-variation discrepancy is exactly 1/2. The accompanying derivation supplies the full fixed-context, trivial-gauge, one-observation construction; the Fraction probe checks its arithmetic.

The correction is to define the random target edge law pointwise under the structural channel. Its marginal event law averages the joint product:
`sum_ij E_(mu C)[eta_ij(Y) M(I,J|i,j,R)]`.
When integrating only partition randomness, condition the expectation explicitly on the fine state. A fixed edge law gives a valid narrower formula. This is a manuscript defect at the general adaptive scope, not evidence of a failing shipped RG v2 experiment. The inspected augmented implementation sums each source mass times its own channel row. The current vault 07c does not contain this exact formula.

### RG2-01: exact aggregation is blocked by a floating-point diagnostic

At `rg_v2/coarse.py:332–335`, the mandatory diagnostic converts individual exact evidence masses to binary64. `aggregate_population` invokes it unconditionally after constructing exact pushforwards (`:388–392`).

The reproduction builds an ordinary valid two-state agent with uniform recognition, a state-independent positive observation likelihood, and a deterministic collapse to one coarse state. At likelihood `2^-1074`, each exact joint evidence cell is `2^-1075`, which rounds to zero. Exact evidence is positive, the posterior equals recognition, and conditional KL is zero, but aggregation raises `ValueError: posterior requires positive evidence`. At likelihood `2^-1073`, the same construction succeeds. The mathematical negative log evidence at the failing point is the finite number `1074 log(2)`, approximately 744.4400719213812.

The witness passes the existing public validators; no object or artifact is corrupted. This is a reusable-API boundary defect. It does not show failure of the checked-in fixtures. Diagnostics should operate on exact normalized posterior/conditional laws with rational-aware logarithms and explicit representability handling, so a raw-evidence float mirror cannot veto a valid exact calculation. Clamping positive masses to an arbitrary epsilon would change the problem.

### RG2-03: worker admission retains hard elapsed deadlines

The active Phase 13 route constructs closures, enters covariance assessment, and invokes mandatory admission for worker cohorts 1, 2, and 12. The worker initializer waits 120 seconds for release (`complete_carrier_covariance_assessment.py:1418–1419`), while the parent independently imposes a 120-second readiness deadline (`:5926–5934`). Either expiration raises an error.

The governing policy says elapsed values are reporting-only and cannot alone fail an otherwise valid calculation. No applicable admission-handshake exception was found. The source indicates a timing-only rejection path after earlier closure work, but a healthy delayed-startup execution was not reproduced. The audit reproduced the exact barrier branch with an AST-extracted function and inert synchronization doubles; it did not start workers, wait 120 seconds, measure incidence, or identify this as the cause of any historical crash.

A repair should retain worker-exit, broken-pool, inventory, and attestation checks while making mere elapsed delay reportable. This finding does not authorize retrying the historical producer or changing host/process settings.

### Persistent findings

**RG2-02 / earlier RV2-01.** The Phase 12 source-binding test still fails on the current normal Windows checkout. It computes a Git blob identifier from physical CRLF bytes and searches for that identity in a plan that records the LF object. The physical blob is `0d0ee1de4dafcc77b2615c74f572d0c10ccaf119`; the committed LF object is `2cd7d7fd2ac402f0e311d2d3ad4156f5d494fabb`. The isolated one-node JUnit records the failure at `test_full_state_covariance_fixtures.py:195`. Define identity using Git object bytes with separately labeled checkout hashes, or explicitly pin the relevant files to LF. This is reproducibility, not failed scientific arithmetic.

**RG2-04 / earlier RV2-02.** Phase 11 and Phase 12 check commit/config identity without requiring an available dirty-tree digest. The collector can separately return a valid status and an unavailable digest. This acceptance condition remains visible in source. No current filesystem-fault reproduction or fake-provenance injection was performed, so the dynamic claim retains its open obligation. Phase 13's repeated clean-tree gates prevent simply transplanting this claim into Phase 13.

**RG2-05 / earlier RV2-05.** The regression named `legacy_rescaling_v1` captures the scale-cocycle launcher and does not reference the actual `run_rescaling_figures.py` laboratory. It should not be used to justify that laboratory's deletion. This audit did not execute the expensive legacy capture or retire any file.

**RG2-06 / earlier RV2-06.** An active implicit-compute config contains effective CPU/dtype/batch/determinism settings, but `canonical_config_json` removes the compute block. The source revision still identifies the defaults. Persisting a separately labeled effective block would make the recorded resolved configuration complete without silently changing historical identities.

**RG2-07 / earlier RV2-07.** Phase 12/13 accept and hash tolerance and SPD-related fields whose only direct consumers in their experiment modules are common-config roundtrips. A valid alternate tuple was accepted in memory and changed the hash; no scientific runner was invoked. Their direct use is metadata in the inspected exact-rational path; this is not a dynamic whole-program noninterference result or evidence of a missing numerical tolerance mechanism. Label them accordingly rather than changing intentional configuration choices.

The earlier explicit-zero-complement concern remains source-visible in Phase 12. It was not remeasured. Phase 13 uses positive sparse entries and streams its compatibility complement, so the old memory measurements were not copied into a new Phase 13 performance claim.

### RG2-08: the two manuscript copies disagree about an open premise

The current Research-vault `07b_agent_network_rg.tex:3093–3104` says every premise except rescaling is satisfied by the declared finite constructions. The repository version at `:3108–3123` also leaves globally gauge-equivariant conditional versions open. The report's source excerpts preserve both texts and hashes.

This is a source-consistency finding, not a new proof that the complete conditional closure theorem is false. The repository correctly states an implication with open instantiation obligations. A future manuscript synchronization should carry the qualifications deliberately; neither blanket copying direction is safe, because the repository-only 07c error above also exists. No vault file was changed.

## What the theory and executable actually establish

The reviewed population and variational paths keep the full correlated recognition law. Common-channel pushforward preserves evidence, and its VFE improvement is a discarded conditional inference gap. The inspected Phase 6 expectation uses link marginals for additive single-link terms while retaining the full link-law entropy. No additional error was established in those formulas.

The checked S3 action and path-order identities passed. The finite D4 construction keeps simultaneous rooted holonomy and boundary marks; graph holonomy is not equated with principal-bundle topology or base curvature. There is no reason to import an SPD retraction or neural attention obligation into this finite permutation-action path.

Phase 13's C01 retains the complete source ordinal while adding an independent branch. C12 removes that branch; C02 retains the source ordinal. Consequently these law pairs admit common recovery and have zero KL loss. Their covariance and composition checks test the declared lossless construction. Phase 11's finite contraction follows from explicitly supplied stochastic kernels, and the README correctly says those kernels are not derived from Phase 10.

The proposed Phase 14 route has a plausible local algebraic basis: mapping edge index j to j+2 modulo four sends incident flags to nonincident flags and commutes with the D4 action. The 64 local table checks had no violations. The separate exact sector checks agree with the KL chain rule and Fisher conditional-variance identity. Under an admitted ordinal-preserving quotient, the supplied unequal sector conditionals can produce strict information loss. None of this discharges the required complete decorated action/channel squares, all branch/control coverage, or the exclusion of hidden source-sector marks from the target.

The largest research obligation remains a justified selection of nontrivial coarse variables/channels from the microscopic model and compatible behavior under repeated scale change. Exact finite diagrams do not alone establish asymptotic attraction, universality, or physical-law identification. The project's present nonclaims are appropriate. Wilson's original scaling analysis explicitly ties the irrelevant-variable scaling conclusion to asymptotic fixed-point behavior ([Wilson, 1971](https://journals.aps.org/prb/abstract/10.1103/PhysRevB.4.3174)); that ingredient is separate from finite channel composition.

## Checks and evidence limits

JUnit XML records **16 tests: 15 passed, 1 failed, 0 errors, 0 skipped** across three disjoint invocations. The 14-test positive scientific selection took 2.548 seconds; the one positive composition check took 18.669 seconds; the one source-binding check failed in 0.763 seconds. These are JUnit suite durations, not total audit wall time. The failure was preserved and not retried. [Machine-readable totals](evidence/2026-09-04-rg-v2-astra/test-summary.json) identify each XML and its SHA-256.

Additional standalone checks are recorded as assertions or finite identities, not added to the pytest count: seven exact contract assertions; 72 S3 endpoint-conjugation plus 72 action-order checks; 64 local D4 checks; exact eight-sector KL/Fisher identities; valid-input underflow probes; config serialization; all 13 launcher configurations and registry mappings; and the six-vertex mathematical counterexample. A tiny Release 1 execution traced the active coarse diagnostic path. No CUDA claim is made; `int`/`Fraction` arithmetic is the relevant authority.

The precise CPU runtime for scientific execution was `C:/tmp/rg-v2-phase13-py3147-runtime-20260901/python.exe`, CPython 3.14.7. Audit pytest drivers disable automatic GC before importing repository code and suppress pytest's forced teardown collections, use explicit repository paths, disable plugin autoload, and run serially. There was no heavy retry.

This was a deep, bounded source and counterexample review, not exhaustive verification of every module or historical result. Absence of another finding is not a correctness certificate. The retained Phase 13 publication history was not rerun or reclassified.

## Recommended order

Correct the random-edge-law expectation in the repository manuscript and add a scientific finite counterexample regression when remediation is requested. Repair the reusable exact aggregation diagnostic without altering its input laws. Align admission timing with the approved policy, preserving process-failure guards. Resolve the reproduced Phase 12 source-binding failure. Then address the provenance and metadata items in their stated scope, and reconcile the two manuscript copies with explicit source comparison.

No implementation, configuration, manuscript, or vault remediation was performed during this audit. The audit report, its evidence archive, and the daily change log are the only intended Desktop additions.


## Evidence archive and handoff

[Validated claim ledger](evidence/2026-09-04-rg-v2-astra/claim-ledger.json), [adjudication](evidence/2026-09-04-rg-v2-astra/adjudication.md), and [archive guide](evidence/2026-09-04-rg-v2-astra/README.md) preserve the findings and their exact scope. The ledger's relative evidence locations refer to the original pinned audit worktree; the archive preserves its bytes without changing that binding. The original source pin does not describe the dirty Desktop checkout.

All 37 pre-existing WIP paths, including the 16 tracked deletions, were checked against the initial byte fingerprints and preserved. The pinned audit source remains clean. Only this report, the evidence archive, and the September 4 change log were added to Desktop. Nothing was committed, pushed, or merged.

Open verification obligations:

- **RG2-03:** A permitted non-destructive delayed-worker readiness/barrier fixture must establish the actual process-level rejection path. Current execution and configuration-scope criteria remain weak; no heavy or delayed pool was run.
- **RG2-04:** Obtain current non-forged reproduced output from a real provenance collection path where dirty_tree_sha256 is unavailable and Phase 11/12 admission still accepts. No filesystem corruption, fake provenance, or fault injection was run.
