"""Replay the declared frozen candidate on an existing numerical path tape."""
from __future__ import annotations

from collections.abc import Mapping
import torch

from .continuous_budget import _run_grid
from .coupled_learning import CoupledModel, CoupledState


@torch.no_grad()
def replay_frozen_budget(
    mobility:       torch.Tensor,
    initial:        CoupledState,
    model:          CoupledModel,
    saved:          Mapping[str, torch.Tensor],
    horizon:        float,
    block_size:     int,
    source_backend:              str  = "binary_integral",
    measure_projection_residual: bool = False,
) -> dict[str, torch.Tensor]:
    r"""Reuse saved initial states, dW, Poisson times and source/probe uniforms.

    Coarse indices are exact lookups in the event-augmented fine mesh.
    Regenerated native values must equal their retained counterparts; only
    candidate quantities may differ. No random draws or hidden resets occur.
    """
    names = ("initial_X", "initial_J", "fine_times", "fine_dW", "proposal_times",
             "proposal_uniforms", "probe_times", "probe_uniforms")
    tape = {name: saved[name] for name in names}
    result = {}
    for level in ("coarse", "fine"):
        grid_times = saved[level+"_times"]
        grid = torch.searchsorted(tape["fine_times"], grid_times)
        if not torch.equal(tape["fine_times"][grid], grid_times):
            raise ValueError("saved grid is not an exact submesh")
        values = _run_grid(mobility, initial, model, tape, grid, horizon, block_size,
                           source_backend=source_backend,
                           measure_projection_residual=measure_projection_residual)
        for name in ("native", "assignments", "times", "dW", "probe_labels", "probe_log_beta",
                     "probe_log_self_native", "proposal_count", "visible_changes"):
            if not torch.equal(values[name], saved[level+"_"+name]):
                raise ArithmeticError(f"native replay differs for {level}_{name}")
        if not all(bool(torch.isfinite(value).all()) for value in values.values()):
            raise FloatingPointError("nonfinite candidate replay")
        result.update({level+"_"+name: value for name, value in values.items()})
    return result
