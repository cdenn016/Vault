"""Streaming frozen-parent budgets with coupled time discretizations.

Exact Poisson proposal times are retained. Euler configuration propagation and
Gaussian endpoint observations approximate the continuous model; no continuous
path-error certificate or discretization limit is asserted by this computation.
"""
from __future__ import annotations

from math import log1p

import torch

from .coupled_learning import CoupledModel, CoupledState, comparison_maps
from .gaussian_message import observe_gaussian, propagate_gaussian
from .source_gaussian import _source_step, sequential_source_message
from .source_square_root import square_root_source_rows
from .switching_paths import sheet_force, source_log_posterior


def _draw_labels(log_rows: torch.Tensor, uniforms: torch.Tensor) -> torch.Tensor:
    r"""Invert the categorical CDF, assigning roundoff at its end to the last label."""
    return (uniforms[..., None] > log_rows.exp().cumsum(-1)).sum(-1).clamp_max(log_rows.shape[-1]-1)


def source_budget_probe(
    X:              torch.Tensor,      # (B,N,K), native state.
    mu:             torch.Tensor,      # (B,N,K), candidate fiber mean.
    covariance:     torch.Tensor,      # (B,NK,NK), candidate fiber covariance.
    assignments:    torch.Tensor,      # (B,N), current sheet.
    prefix_labels:  torch.Tensor,      # (B,N), independent native product draw.
    state:          CoupledState,
    model:          CoupledModel,
    block_size:     int,
    source_backend: str = "dense",
) -> dict[str, torch.Tensor]:
    r"""Estimate D(b||hat b)-psi(b_J,hat b_J) using native prefix row KLs.

    Given X and the candidate message, expectation over prefix_labels equals
    the visible-intensity divergence, including survival. The full mark
    estimate is nonnegative; subtracting the exact self term can make a finite
    Monte Carlo visible estimate negative. Nothing is clipped. Inputs survive.
    """
    if source_backend not in ("dense", "square_root", "binary_integral"):
        raise ValueError("source_backend must be dense, square_root or binary_integral")
    B, N, _ = X.shape
    native = source_log_posterior(X, state, model)
    mean, cov = torch.cat((mu, mu)), torch.cat((covariance, covariance))
    labels = torch.cat((prefix_labels, assignments))
    if source_backend in ("square_root", "binary_integral"):
        rows = square_root_source_rows(mean, cov, labels, state, model, block_size,
            integration="binary_integral" if source_backend == "binary_integral" else "cubature")["log_rows"]
        candidate = rows[:B]                              # (B,N,S), native sampled prefixes.
        log_self_candidate = rows[B:].gather(-1, assignments[..., None]).squeeze(-1).sum(-1)
    else:
        maps = comparison_maps(state.Theta, model)
        candidate_rows = []
        log_self_candidate = X.new_zeros(B)
        for receiver in range(N):
            rows, mean, cov = _source_step(mean, cov, labels[:, receiver], maps,
                                           state, model, receiver, block_size)
            candidate_rows.append(rows[:B])
            log_self_candidate += rows[B:].gather(-1, assignments[:, receiver, None]).squeeze(-1)
        candidate = torch.stack(candidate_rows, dim=1)      # (B,N,S).
    mark = (native.exp()*(native-candidate)).sum((-1, -2))
    log_self_native = native.gather(-1, assignments[..., None]).squeeze(-1).sum(-1)
    difference = log_self_native-log_self_candidate
    self_cost = log_self_native.exp()*difference-log_self_native.exp()+log_self_candidate.exp()
    near = difference.abs() < 1.
    self_cost[near] = log_self_native[near].exp()*(difference[near]+torch.expm1(-difference[near]))
    return {"log_beta": native, "log_candidate_rows": candidate, "labels": prefix_labels,
            "log_self_native": log_self_native, "log_self_candidate": log_self_candidate,
            "mark_kl": mark, "self_psi": self_cost, "visible_kl": mark-self_cost}


def _run_grid(
    mobility:       torch.Tensor,
    initial:        CoupledState,
    model:          CoupledModel,
    tape:           dict[str, torch.Tensor],
    grid:           torch.Tensor,
    horizon:        float,
    block_size:     int,
    source_backend:              str  = "dense",
    measure_projection_residual: bool = False,
) -> dict[str, torch.Tensor]:
    r"""Drive one Gaussian message by one native Euler path on the fixed mesh."""
    if source_backend not in ("dense", "square_root", "binary_integral"):
        raise ValueError("source_backend must be dense, square_root or binary_integral")
    if measure_projection_residual and source_backend == "dense":
        raise ValueError("projection residuals require a square-root source backend")
    X, J = tape["initial_X"].clone()[None], tape["initial_J"].clone()[None]
    N, K = initial.mu.shape
    C = N//block_size
    def mean_block(value: torch.Tensor) -> torch.Tensor:
        """Apply the fixed arithmetic block projection to one or more states."""
        return value.reshape(-1, C, block_size, K).mean(2).flatten(1)
    conditioned = observe_gaussian(initial.mu[None], torch.block_diag(*initial.Sigma)[None], mean_block(X), block_size)
    mu, cov = conditioned["mean"], conditioned["covariance"]
    Qr = 2*mobility.reshape(C, block_size, K, K).sum(1)/block_size**2
    Lr, L = torch.linalg.cholesky(Qr), torch.linalg.cholesky(2*mobility)
    times = tape["fine_times"][grid]
    probe_indices = torch.searchsorted(times, tape["probe_times"], right=True)-1
    events = {float(value): index for index, value in enumerate(tape["proposal_times"])}
    histories = {"native": [X[0].clone()], "mean": [mu[0].clone()], "assignments": [J[0].clone()]}
    rates, noises = [], []
    probes: dict[str, list] = {}
    projection = {name: [] for name in ("event_times", "event_visible", "log_native",
                                       "log_candidate", "log_density_ratio")}
    maximum_mean, maximum_cov, visible_changes = 0., 0., 0
    for step in range(len(times)-1):
        weights = torch.nn.functional.one_hot(J, initial.pi.shape[-1]).to(X.dtype)
        force = sheet_force(X, weights, initial.Theta, model)
        candidate_force = sheet_force(mu, weights, initial.Theta, model)
        projected = mean_block(torch.einsum("nij,bnj->bni", mobility, force-candidate_force)).reshape(C, K)
        white = torch.linalg.solve_triangular(Lr, projected[..., None], upper=False)
        rates.append(.5*white.square().sum())
        maximum_mean = max(maximum_mean, float((mean_block(mu)-mean_block(X)).abs().max()))
        maximum_cov = max(maximum_cov, float(cov.reshape(1, C, block_size, K, N*K).mean(2).abs().max()))
        for probe_index in (probe_indices == step).nonzero(as_tuple=True)[0].tolist():
            native_rows = source_log_posterior(X, initial, model)
            labels = _draw_labels(native_rows, tape["probe_uniforms"][probe_index:probe_index+1])
            values = source_budget_probe(X, mu, cov, J, labels, initial, model, block_size,
                                         source_backend=source_backend)
            for key, value in values.items():
                probes.setdefault(key, []).append((probe_index, value[0].clone()))
        dt = float(times[step+1]-times[step])
        dW = tape["fine_dW"][int(grid[step]):int(grid[step+1])].sum(0)
        noises.append(dW)
        X = X-dt*torch.einsum("nij,bnj->bni", mobility, force)+torch.einsum("nij,nj->ni", L, dW)[None]
        forecast_mu, forecast_cov = propagate_gaussian(mu, cov, J, mobility, initial, model, dt)
        conditioned = observe_gaussian(forecast_mu, forecast_cov, mean_block(X), block_size)
        mu, cov = conditioned["mean"], conditioned["covariance"]
        event = events.get(float(times[step+1]))
        if event is not None:
            native_rows = source_log_posterior(X, initial, model)
            labels = _draw_labels(native_rows, tape["proposal_uniforms"][event:event+1])
            visible = not torch.equal(labels, J)
            if visible or measure_projection_residual:
                if source_backend in ("square_root", "binary_integral"):
                    update = square_root_source_rows(mu, cov, labels, initial, model, block_size,
                        integration="binary_integral" if source_backend == "binary_integral" else "cubature",
                        evaluation_state=X if measure_projection_residual and visible else None)
                else:
                    update = sequential_source_message(mu, cov, J, labels, initial, model, block_size, shortcut_mass=0.)
            if measure_projection_residual:
                projection["event_times"].append(times[step+1])
                projection["event_visible"].append(X.new_tensor(visible, dtype=torch.bool))
                projection["log_native"].append(native_rows.gather(-1, labels[..., None]).sum())
                projection["log_candidate"].append(update["log_rows"].gather(-1, labels[..., None]).sum())
                # A self-proposal is scored but leaves the actual message unchanged.
                projection["log_density_ratio"].append(
                    update["log_density_before_over_after"][0] if visible else X.new_zeros(()))
            if visible:
                mu, cov = update["mean"], update["covariance"]
                visible_changes += 1
            J = labels
        for key, value in (("native", X), ("mean", mu), ("assignments", J)):
            histories[key].append(value[0].clone())
    result = {key: torch.stack(values) for key, values in histories.items()}
    for key, values in probes.items():
        result["probe_"+key] = torch.stack([value for _, value in sorted(values, key=lambda pair: pair[0])])
    result["times"], result["dW"], result["drift_rates"] = times, torch.stack(noises), torch.stack(rates)
    result["drift_integral"] = (result["drift_rates"]*torch.diff(times)).sum()
    for key, source in (("mark", "mark_kl"), ("self", "self_psi"), ("visible", "visible_kl")):
        result[key+"_integral"] = horizon*result["probe_"+source].mean()
    result["total_integral"] = result["drift_integral"]+result["visible_integral"]
    result["augmented_integral"] = result["drift_integral"]+result["mark_integral"]
    result["proposal_count"] = X.new_tensor(len(events))
    result["visible_changes"] = X.new_tensor(visible_changes)
    result["projection_max_error"] = X.new_tensor(maximum_mean)
    result["covariance_projection_max_error"] = X.new_tensor(maximum_cov)
    if measure_projection_residual:
        for name, values in projection.items():
            dtype = torch.bool if name == "event_visible" else X.dtype
            result["projection_"+name] = torch.stack(values) if values else X.new_empty(0, dtype=dtype)
        result["projection_residuals"] = (result["projection_log_density_ratio"]
            +result["projection_log_native"]-result["projection_log_candidate"])
        result["projection_residual_sum"] = result["projection_residuals"].sum()
    return result


@torch.no_grad()
def sample_frozen_budget(
    mobility:       torch.Tensor,
    initial:        CoupledState,
    model:          CoupledModel,
    horizon:        float,
    block_size:     int,
    coarse_steps:   int,
    n_probes:       int,
    seed:           int,
    source_backend: str = "dense",
) -> dict[str, torch.Tensor]:
    r"""Measure one paired coarse/fine frozen-law path without a hidden reset.

    Source proposals are rate-one Poisson events. Brownian increments, proposal
    uniforms and independent budget probes are shared between the two meshes.
    Uniform probe times do not alter either simulation mesh. Conditional on a
    mesh path, the jump estimator is unbiased for its piecewise-constant cost.
    The continuous limit and a confidence bound remain separate obligations.
    """
    N, K = initial.mu.shape
    if source_backend not in ("dense", "square_root", "binary_integral"):
        raise ValueError("source_backend must be dense, square_root or binary_integral")
    if mobility.device.type != "cpu" or mobility.dtype != torch.float64:
        raise ValueError("this declared measurement uses CPU float64")
    if horizon <= 0 or min(block_size, coarse_steps, n_probes) < 1 or N % block_size:
        raise ValueError("positive horizon/counts and a dividing block size are required")
    generators = [torch.Generator().manual_seed(seed+offset) for offset in range(6)]
    X = initial.mu+torch.einsum("nij,nj->ni", torch.linalg.cholesky(initial.Sigma),
        torch.randn((N, K), dtype=mobility.dtype, generator=generators[0]))
    J = _draw_labels(initial.pi.log(), torch.rand((N,), dtype=mobility.dtype, generator=generators[0]))
    events, clock = [], 0.
    while True:
        clock -= log1p(-float(torch.rand((), dtype=mobility.dtype, generator=generators[1])))
        if clock >= horizon:
            break
        events.append(clock)
    fine_regular = torch.linspace(0., horizon, 2*coarse_steps+1, dtype=mobility.dtype)
    fine_times = torch.tensor(sorted(set(fine_regular.tolist()+events)), dtype=mobility.dtype)
    coarse_times = torch.tensor(sorted(set(fine_regular[::2].tolist()+events)), dtype=mobility.dtype)
    fine_noise = torch.randn((len(fine_times)-1, N, K), dtype=mobility.dtype, generator=generators[2])
    fine_noise *= torch.diff(fine_times).sqrt()[:, None, None]
    tape = {"initial_X": X, "initial_J": J, "fine_times": fine_times, "fine_dW": fine_noise,
            "proposal_times": torch.tensor(events, dtype=mobility.dtype),
            "proposal_uniforms": torch.rand((len(events), N), dtype=mobility.dtype, generator=generators[3]),
            "probe_times": horizon*torch.rand((n_probes,), dtype=mobility.dtype, generator=generators[4]),
            "probe_uniforms": torch.rand((n_probes, N), dtype=mobility.dtype, generator=generators[5])}
    result = {key: value for key, value in tape.items()}
    for level, grid_times in (("coarse", coarse_times), ("fine", fine_times)):
        grid = torch.searchsorted(fine_times, grid_times)
        measured = _run_grid(mobility, initial, model, tape, grid, horizon, block_size,
                             source_backend=source_backend)
        result.update({level+"_"+key: value for key, value in measured.items()})
    if not all(bool(torch.isfinite(value).all()) for value in result.values()):
        raise FloatingPointError("nonfinite frozen budget output")
    return result
