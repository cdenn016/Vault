"""Binary Gaussian source integrals for calibration and assumed-density updates.

Probability and moment integrals are numerical references for Gaussian inputs.
"""
from __future__ import annotations

from math import atanh, exp, pi, sinh
import warnings

import numpy as np
from scipy.integrate import IntegrationWarning, quad
from scipy.special import expit


def quadratic_logistic_mean(
    A: np.ndarray,
    b: np.ndarray,
    c: float,
) -> tuple[float, float, float]:
    r"""Evaluate E[sigmoid(z^T A z+b^T z+c)] for z ~ N(0,I).

    Return probability, adaptive quadrature error estimate, and analytic tail
    bound. Individual complex logarithms stay continuous from t=0.
    """
    eigenvalues, vectors = np.linalg.eigh((A+A.T)/2)
    gamma_squared = (vectors.T@b)**2

    def integrand(t: float) -> float:
        if t == 0:
            return float(c+eigenvalues.sum())/pi
        factors = 1-2j*t*eigenvalues
        log_phi = 1j*t*c-.5*np.log(factors).sum()-.5*t*t*(gamma_squared/factors).sum()
        return float(np.exp(log_phi).imag)/sinh(pi*t)

    with warnings.catch_warnings():
        warnings.simplefilter("error", IntegrationWarning)
        integral, error = quad(integrand, 0., 12., epsabs=1e-10, epsrel=1e-10, limit=200)
    probability = .5+integral
    if not 0 < probability < 1 or not np.isfinite(error) or error > 1e-9:
        raise ArithmeticError(f"unresolved source integral: p={probability}, error={error}")
    return probability, error, (2/pi)*atanh(exp(-12*pi))


def activation_mean(
    mu:         np.ndarray,  # (N,K)
    Sigma:      np.ndarray,  # (N,K,K)
    retained:   np.ndarray,  # (N/block_size,K), arithmetic block means
    block_size: int,
) -> np.ndarray:
    r"""Compute m_i=mu_i+Sigma_i S_B^{-1}(block_size R_B-sum_B mu)."""
    n_agents, dimension = mu.shape
    blocks = Sigma.reshape(-1, block_size, dimension, dimension)
    delta = block_size*retained-mu.reshape(-1, block_size, dimension).sum(1)
    solved = np.linalg.solve(blocks.sum(1), delta[..., None])[..., 0]
    return mu+np.einsum("nbij,nj->nbi", blocks, solved).reshape(n_agents, dimension)


def local_activation_covariance(
    Sigma:      np.ndarray,
    nodes:      list[int],
    block_size: int,
) -> np.ndarray:
    r"""Return C_ij=delta_ij Sigma_i-Sigma_i S_B^{-1}Sigma_j within B."""
    dimension = Sigma.shape[-1]
    covariance = np.zeros((len(nodes)*dimension, len(nodes)*dimension))
    sums = Sigma.reshape(-1, block_size, dimension, dimension).sum(1)
    for i, node_i in enumerate(nodes):
        for j, node_j in enumerate(nodes):
            if node_i//block_size == node_j//block_size:
                value = -Sigma[node_i]@np.linalg.solve(sums[node_i//block_size], Sigma[node_j])
                if node_i == node_j:
                    value += Sigma[node_i]
                covariance[i*dimension:(i+1)*dimension, j*dimension:(j+1)*dimension] = value
    return (covariance+covariance.T)/2


def source_quadratic(
    mu:             np.ndarray,  # (r,), sorted local physical coordinates
    covariance:     np.ndarray,  # (r,r), positive definite local marginal
    residual_maps:  np.ndarray,  # (2,K,r)
    H:              np.ndarray,  # (K,K)
    source_prior:   np.ndarray,  # (2,), positive
    tau:            float,
) -> tuple[np.ndarray, np.ndarray, float]:
    r"""Whiten log(beta_0/beta_1) into z^T A z+b^T z+c."""
    R_0, R_1 = residual_maps
    D = (R_1.T@H@R_1-R_0.T@H@R_0)/(2*tau)
    D = (D+D.T)/2
    L = np.linalg.cholesky(covariance)
    A = L.T@D@L
    b = 2*L.T@D@mu
    c = float(mu@D@mu+np.log(source_prior[0]/source_prior[1]))
    return (A+A.T)/2, b, c


def cholesky_source_probability(
    A: np.ndarray,
    b: np.ndarray,
    c: float,
) -> float:
    r"""Average sigmoid at z=+/-sqrt(r)e_k, preserving physical Cholesky axes."""
    r = len(b)
    center = r*np.diag(A)+c
    offset = np.sqrt(r)*b
    return float(np.mean(np.concatenate((expit(center+offset), expit(center-offset)))))


def quadratic_logistic_moments(
    A: np.ndarray,
    b: np.ndarray,
    c: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, float]:
    r"""Return probabilities and Gaussian moments for sigmoid(+/-Z).

    For Z=z^T A z+b^T z+c, integrate phi, phi h and phi(S+hh^T),
    where S=(I-2itA)^(-1) and h=itSb. The tail bound is per component
    in the diagonal Gaussian coordinates, before probability normalization.
    """
    from scipy.integrate import quad_vec

    r = len(b)
    eigenvalues, vectors = np.linalg.eigh((A+A.T)/2)
    gamma = vectors.T@b
    eye = np.eye(r)
    origin_second = (c+eigenvalues.sum())*eye+2*np.diag(eigenvalues)
    origin = np.concatenate(([c+eigenvalues.sum()], gamma, origin_second.ravel()))/pi

    def integrand(t: float) -> np.ndarray:
        if t == 0:
            return origin
        factors = 1-2j*t*eigenvalues
        S = 1/factors
        h = 1j*t*S*gamma
        phi = np.exp(1j*t*c-.5*np.log(factors).sum()-.5*t*t*(gamma**2*S).sum())
        values = np.concatenate(([1.], h, (np.diag(S)+np.outer(h, h)).ravel()))
        return (phi*values).imag/sinh(pi*t)

    integral, error, info = quad_vec(integrand, 0., 12., epsabs=1e-10, epsrel=1e-10,
                                    norm="max", limit=200, full_output=True)
    p = np.array([.5+integral[0], .5-integral[0]])
    if not info.success or not np.isfinite(error) or error > 1e-9 or not np.all((p > 0) & (p < 1)):
        raise ArithmeticError(f"unresolved moment integral: p={p}, error={error}, {info.message}")
    first = vectors@integral[1:1+r]
    second = vectors@(.5*eye+integral[1+r:].reshape(r, r))@vectors.T
    unnormalized_first = np.stack((first, -first))
    unnormalized_second = np.stack((second, eye-second))
    mean = unnormalized_first/p[:, None]
    covariance = unnormalized_second/p[:, None, None]-np.einsum("si,sj->sij", mean, mean)
    covariance = (covariance+covariance.transpose(0, 2, 1))/2
    np.linalg.cholesky(covariance)  # No variance floor or rank truncation.
    return p, mean, covariance, float(error), (2/pi)*atanh(exp(-12*pi))
