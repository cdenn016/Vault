"""Finite-particle prediction for the existing joint switching path law.

This is a randomized controlled approximation, not a regular-filter closure
theorem. Scores condition on the supplied independent random tape.
"""
from __future__ import annotations
from collections.abc import Sequence
from math import log
import torch

from .block_observation import BlockObservation
from .coupled_learning import CoupledModel, CoupledState
from .switching_paths import source_log_posterior, source_transition_log_prob, sheet_force


def condition_particle_weights(
    log_weights:     torch.Tensor,             # (B,L), normalized log weights.
    log_source:      torch.Tensor,             # (B,L), likelihood of observed J_next.
    log_observation: torch.Tensor,             # (B,L), projected Gaussian density.
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    r"""Return log sum w k g, log sum w k, both ESS values, and posterior weights."""
    source = log_weights+log_source
    log_s = torch.logsumexp(source, -1)
    log_w_s = source-log_s[:, None]
    joint = source+log_observation
    log_joint = torch.logsumexp(joint, -1)
    log_w = joint-log_joint[:, None]
    return (log_joint, log_s, torch.exp(-torch.logsumexp(2*log_w_s, -1)),
            torch.exp(-torch.logsumexp(2*log_w, -1)), log_w.exp())


def particle_joint_scores(
    R:               torch.Tensor,            # (B,H+1,m), saved actual observations.
    assignments:     torch.Tensor,            # (B,H+1,N), complete source labels.
    mobility:        torch.Tensor,            # (N,K,K), fixed positive mobility.
    initial:         CoupledState,
    schedule:        Sequence[CoupledState],
    model:           CoupledModel,
    dt:              float,
    block_size:      int,
    n_particles:     int,
    seed:            int,
    refresh_rate:    float = 1.,
    reset_each_step: bool = False,
) -> dict[str, torch.Tensor | float]:
    r"""Score sum_l w_l k(J_next|X_l,J) N(R_next;P m_l,C).

    Weight by BOTH source and retained-observation likelihoods, resample
    ancestors multinomially, then propagate X_next by its exact Gaussian
    conditional given R_next. Initial particles use the actual activation
    conditional. The reset control instead redraws that activation conditional
    at each observed R_t, discarding the particle history.

    Each evaluation path has an independent supplied tape with seed+path index.
    Given that tape all predictive rows are normalized; mean negative log
    scores compare tape-averaged conditional path KL, not marginal-random-parent
    KL. No new native trajectory or learning coefficient is sampled here.
    """
    if n_particles < 1 or dt <= 0 or not schedule:
        raise ValueError("positive particle count, time step, and schedule required")
    B, H = len(R), len(schedule)
    N, K = initial.mu.shape
    if R.shape != (B,H+1,N//block_size*K) or assignments.shape != (B,H+1,N):
        raise ValueError("retained histories must cover every declared microstep")
    activation = BlockObservation.compile(initial.Sigma,block_size)
    observation = BlockObservation.compile(2*dt*mobility,block_size)
    generators = [torch.Generator(device=R.device).manual_seed(seed+b) for b in range(B)]
    def noise() -> torch.Tensor:
        """Consume a fixed-size independent Gaussian portion of every path tape."""
        return torch.stack([torch.randn((n_particles,N,K),dtype=R.dtype,device=R.device,
                                        generator=g) for g in generators])
    log_weights = R.new_full((B,n_particles),-log(n_particles))
    result = {name:R.new_empty((B,H)) for name in ("log_joint","log_source","source_ess","joint_ess")}
    max_projection_error = 0.
    particles = None
    R_blocks = R.reshape(B,H+1,N//block_size,K)
    for t,state in enumerate(schedule):
        observed = R_blocks[:,t,None]
        if t == 0 or reset_each_step:
            particles = activation.sample_conditional(
                initial.mu.expand(B,n_particles,N,K),observed,noise())
        max_projection_error = max(max_projection_error,float((observation.project(particles)-observed).abs().max()))
        X = particles.flatten(0,1)               # (B*L,N,K), actual hidden quadrature.
        old = assignments[:,t,None].expand(B,n_particles,N).reshape(B*n_particles,N)
        new = assignments[:,t+1,None].expand(B,n_particles,N).reshape(B*n_particles,N)
        source = source_transition_log_prob(source_log_posterior(X,state,model),old,new,dt,refresh_rate).reshape(B,n_particles)
        weights = torch.nn.functional.one_hot(new,state.pi.shape[-1]).to(R.dtype)
        force = sheet_force(X,weights,state.Theta,model)
        means = (X-dt*torch.einsum("nij,bnj->bni",mobility,force)).reshape(B,n_particles,N,K)
        next_R = R_blocks[:,t+1,None]
        gaussian = observation.log_prob(next_R,means)
        joint,source_log,source_ess,joint_ess,posterior = condition_particle_weights(log_weights,source,gaussian)
        for name,value in zip(result,(joint,source_log,source_ess,joint_ess)):
            result[name][:,t] = value
        if not reset_each_step and t+1 < H:
            ancestors = torch.stack([torch.multinomial(
                posterior[b],n_particles,replacement=True,generator=g)
                for b,g in enumerate(generators)])
            chosen = means[torch.arange(B,device=R.device)[:,None],ancestors]
            particles = observation.sample_conditional(chosen,next_R,noise())
    return {**result,"projection_max_error":max_projection_error}


def lifted_baseline_log_scores(
    R:            torch.Tensor,
    assignments:  torch.Tensor,
    mobility:     torch.Tensor,
    initial:      CoupledState,
    schedule:     Sequence[CoupledState],
    model:        CoupledModel,
    dt:           float,
    block_size:   int,
    refresh_rate: float = 1.,
) -> torch.Tensor:
    r"""Score the published lifted-source/recognition-drift baseline at actual Y."""
    from .coupled_learning import free_energy
    activation = BlockObservation.compile(initial.Sigma,block_size)
    observation = BlockObservation.compile(2*dt*mobility,block_size)
    B,H,N,K = len(R),len(schedule),*initial.mu.shape
    observed = R.reshape(B,H+1,N//block_size,K)
    logs = R.new_empty((B,H))
    for t,state in enumerate(schedule):
        X = activation.conditional_mean(initial.mu.expand(B,N,K),observed[:,t])
        source = source_transition_log_prob(source_log_posterior(X,state,model),
                    assignments[:,t],assignments[:,t+1],dt,refresh_rate)
        force = sheet_force(X,free_energy(state,model)[1],state.Theta,model)
        mean = X-dt*torch.einsum("nij,bnj->bni",mobility,force)
        logs[:,t] = source+observation.log_prob(observed[:,t+1],mean)
    return logs
