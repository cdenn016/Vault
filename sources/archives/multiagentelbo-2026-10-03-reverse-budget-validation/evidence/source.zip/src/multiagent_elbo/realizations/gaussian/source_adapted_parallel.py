"""Explicit continuation of one partial deterministic Gaussian replay."""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import replace
from datetime import datetime, timezone
import hashlib
import json
import multiprocessing
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import zipfile

import numpy as np
import torch

from .coupled_learning import CoupledState
from .coupled_learning_experiment import build_coupled_case
from .source_adapted_filter import gaussian_joint_scores
from .source_adapted_filter_experiment import _decomposition, _estimate

_context: dict = {}
_KEYS = ("log_joint", "log_source", "source_updates", "shortcut")
_ARMS = ("gaussian", "reset_gaussian")


def _initialize_worker(context: dict) -> None:
    """Install read-only case inputs once in each single-thread child."""
    global _context
    torch.set_num_threads(1)
    _context = context


def _score_task(task: tuple[str, int]) -> dict:
    """Compute exactly one previously missing arm/path, without retry."""
    arm, index = task
    c = _context
    with torch.no_grad():
        scored = gaussian_joint_scores(
            c["R"][index:index+1], c["assignments"][index:index+1],
            c["initial"].Sigma, c["initial"], c["schedule"], c["model"],
            c["dt"], c["block"], refresh_rate=c["refresh_rate"],
            shortcut_mass=c["shortcut_mass"], reset_each_step=arm == "reset_gaussian")
    return {"arm": arm, "path_index": index,
            **{key: scored[key].numpy() for key in _KEYS},
            **{key: float(scored[key]) for key in (
                "projection_max_error", "covariance_projection_max_error")}}


def _load_context(root: Path, original: dict) -> dict:
    """Load the same N1024 native inputs once for the fresh worker generation."""
    native, run, theory = original["native_metadata"], original["run"], original["theory"]
    activation = root/native["run"]["activation_root"]/"N1024-learn_both-final.npz"
    schedule_path = root/native["run"]["schedule_root"]/"N1024-learn_both-schedule.npz"
    with np.load(activation) as z:
        initial = CoupledState(**{key: torch.from_numpy(z[key].copy())
                                 for key in ("mu", "Sigma", "pi", "Theta")})
    with np.load(schedule_path) as z:
        schedule = tuple(CoupledState(**{key: torch.from_numpy(z[key][t].copy())
            for key in ("mu", "Sigma", "pi", "Theta")})
            for t in range(native["theory"]["intervals"]))
    schedule = tuple(state for state in schedule for _ in range(native["run"]["substeps"]))
    with np.load(root/run["input_root"]/"N1024-joint-paths-and-scores.npz") as z:
        R = torch.from_numpy(z[f"block{theory['block']}_paths"][:run["n_paths"]].copy())
        assignments = torch.from_numpy(z["assignments"][:run["n_paths"]].astype(np.int64))
    model, _ = build_coupled_case(1024, native["theory"]["dimension"],
        native["run"]["model_seed"], native["theory"]["link_scale"])
    return {"R": R, "assignments": assignments, "initial": initial, "schedule": schedule,
            "model": replace(model, tau=native["theory"]["tau"]),
            "dt": native["theory"]["interval_dt"]/native["run"]["substeps"],
            "block": theory["block"], "refresh_rate": native["theory"]["refresh_rate"],
            "shortcut_mass": theory["shortcut_mass"]}


def run_source_adapted_continuation(
    checkpoint_root: str,
    output_root:     str,
    workers:         int = 4,
) -> dict:
    """Retain completed science and explicitly schedule only missing N1024 jobs."""
    if not 1 <= workers <= 4:
        raise ValueError("this continuation permits one to four CPU workers")
    torch.set_num_threads(1)
    root = Path(__file__).resolve().parents[4]
    checkpoint_root = Path(checkpoint_root).resolve()
    original = json.loads((checkpoint_root/"metadata.json").read_text(encoding="utf-8"))
    checkpoint_record = json.loads((checkpoint_root/"continuation-checkpoint.json").read_text(encoding="utf-8"))
    retained_case = json.loads((checkpoint_root/"N512.json").read_text(encoding="utf-8"))
    case = json.loads((checkpoint_root/"N1024-progress.json").read_text(encoding="utf-8"))
    if retained_case["status"] != "pass" or original["numerics"] != {
            "device": "cpu", "dtype": "float64", "cpu_threads": 1}:
        raise ValueError("the checkpoint must contain the completed declared CPU N512 case")
    directory = Path(output_root)/datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory.mkdir(parents=True)
    retained = directory/"retained-serial"
    retained.mkdir()
    copied = ("metadata.json", "continuation-checkpoint.json", "source.zip", "N512.json",
              "N512-source-adapted-scores.npz", "N1024-progress.json",
              "N1024-source-adapted-scores.npz")
    for name in copied:
        shutil.copyfile(checkpoint_root/name, retained/name)
    for name in ("N512.json", "N512-source-adapted-scores.npz"):
        shutil.copyfile(checkpoint_root/name, directory/name)
    with zipfile.ZipFile(checkpoint_root/"source.zip") as old:
        sources = list(old.namelist())
    sources += ["src/multiagent_elbo/realizations/gaussian/source_adapted_parallel.py",
                "experiments/gaussian_source_adapted_parallel.py",
                "tests/test_gaussian_source_adapted_parallel.py"]
    sources += [str(p.relative_to(root)).replace("\\", "/") for p in
        (root/"docs/research/2026-10-02-renormalization-completion").glob("*continuation*CONTRACT*.md")]
    hashes = {}
    with zipfile.ZipFile(directory/"source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for relative in dict.fromkeys(sources):
            data = (root/relative).read_bytes()
            archive.writestr(relative, data)
            hashes[relative] = hashlib.sha256(data).hexdigest()
    n_paths, steps = original["run"]["n_paths"], case["microsteps"]
    with np.load(checkpoint_root/"N1024-source-adapted-scores.npz") as z:
        values = {key: z[key].copy() for key in z.files}
    masks, retained_counts = {}, {}
    for arm in _ARMS:
        count = case["arms"][arm]["completed_paths"]
        retained_counts[arm] = count
        masks[arm] = np.arange(n_paths) < count
        for key in _KEYS:
            name = arm+"_"+key
            prefix = values.get(name, np.empty((0, steps)))
            if prefix.shape != (count, steps) or not np.isfinite(prefix).all():
                raise ValueError(f"checkpoint prefix disagrees for {name}")
            values[name] = np.full((n_paths, steps), np.nan)
            values[name][:count] = prefix
    missing = [(arm, index) for index in range(n_paths) for arm in _ARMS if not masks[arm][index]]
    metadata = {key: original[key] for key in
                ("run", "theory", "numerics", "native_metadata", "particle_metadata",
                 "input_sha256_diagnostic")}
    metadata.update({"status": "running", "cases": [retained_case],
        "source_sha256_diagnostic": hashes, "python": sys.executable, "torch": torch.__version__,
        "base_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
        "working_status": subprocess.check_output(["git", "status", "--short"], cwd=root, text=True),
        "continuation": {"checkpoint_root": str(checkpoint_root), "checkpoint_record": checkpoint_record,
            "workers": workers, "retained_N512_arm_paths": 2*retained_case["n_paths"],
            "retained_N1024_arm_paths": retained_counts, "fresh_completed_arm_paths": 0,
            "fresh_planned_arm_paths": len(missing), "automatic_resume": False, "retries": 0},
        "elapsed_components": {"serial_completed_elapsed_seconds": checkpoint_record["serial_completed_elapsed_seconds"],
            "wall_since_original_run_directory_seconds": checkpoint_record["wall_since_original_run_directory_seconds"],
            "serial_recorded_N512_seconds": retained_case["elapsed_seconds"],
            "serial_recorded_N1024_seconds": case["elapsed_seconds"],
            "fresh_continuation_seconds": 0.}})
    started = time.perf_counter()

    def save() -> None:
        """Persist partial arrays with explicit pending masks after each completion."""
        for arm in _ARMS:
            values[arm+"_completed"] = masks[arm]
            case["arms"][arm]["completed_paths"] = int(masks[arm].sum())
        case["status"] = "running" if any(not mask.all() for mask in masks.values()) else case["status"]
        metadata["active_case"] = case
        metadata["elapsed_components"]["fresh_continuation_seconds"] = time.perf_counter()-started
        np.savez_compressed(directory/"N1024-source-adapted-scores.npz", **values)
        (directory/"N1024-progress.json").write_text(json.dumps(case, indent=2), encoding="utf-8")
        (directory/"metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    save()
    print(json.dumps({"run_dir": str(directory), "status": "running", "missing_jobs": len(missing)}), flush=True)
    try:
        context = _load_context(root, original)
        pool = ProcessPoolExecutor(max_workers=workers,
            mp_context=multiprocessing.get_context("spawn"),
            initializer=_initialize_worker, initargs=(context,))
        futures = {}
        try:
            futures = {pool.submit(_score_task, task): task for task in missing}
            for future in as_completed(futures):
                result = future.result()
                arm, index = result["arm"], result["path_index"]
                for key in _KEYS:
                    array = result[key]
                    if array.shape != (1, steps) or not np.isfinite(array).all():
                        raise FloatingPointError(f"invalid fresh {arm} path {index} {key}")
                for key in ("projection_max_error", "covariance_projection_max_error"):
                    value = result[key]
                    if not np.isfinite(value) or value > 1e-9:
                        raise ArithmeticError(f"fresh conditional fiber residual {key}={value}")
                    case["arms"][arm][key] = max(case["arms"][arm][key], value)
                for key in _KEYS:
                    values[arm+"_"+key][index] = result[key][0]
                masks[arm][index] = True
                metadata["continuation"]["fresh_completed_arm_paths"] += 1
                save()
                print(f"N=1024 {arm} path={index+1}/{n_paths}; "
                      f"fresh={metadata['continuation']['fresh_completed_arm_paths']}/{len(missing)}; "
                      f"elapsed={time.perf_counter()-started:.1f}s", flush=True)
        finally:
            for future in futures:
                future.cancel()
            pool.shutdown(wait=True, cancel_futures=True)
        changed = values["changed"]
        for arm in _ARMS:
            if not masks[arm].all() or any(not np.isfinite(values[arm+"_"+key]).all() for key in _KEYS):
                raise ArithmeticError("continuation ended with missing or invalid outputs")
            values[arm+"_source_updates"] = values[arm+"_source_updates"].astype(np.int64)
            values[arm+"_shortcut"] = values[arm+"_shortcut"].astype(bool)
            case["arms"][arm]["negative_log_score"], _ = _decomposition(
                -values[arm+"_log_joint"], -values[arm+"_log_source"], changed)
            for key in ("source_updates", "shortcut"):
                array = values[arm+"_"+key]
                case["arms"][arm][key] = {"total": int(array.sum()),
                    "per_path": _estimate(array.sum(-1)),
                    "changed_total": int(np.where(changed, array, 0).sum()),
                    "unchanged_total": int(np.where(~changed, array, 0).sum())}
        case["observed_assignment_changes"] = int(changed.sum())
        case["assignment_changes_per_path"] = _estimate(changed.sum(-1))
        comparisons = [("gaussian", "reset_gaussian")]
        comparisons += [(arm, reference) for arm in _ARMS for reference in ("baseline", "filter64", "reset64")]
        case["paired_loss_contrasts"] = {}
        for arm, reference in comparisons:
            key = arm+"_minus_"+reference
            summary, per_path = _decomposition(
                values[reference+"_log_joint"]-values[arm+"_log_joint"],
                values[reference+"_log_source"]-values[arm+"_log_source"], changed)
            case["paired_loss_contrasts"][key] = summary
            values.update({key+"_"+component: array for component, array in per_path.items()})
        case["primary_contrast"] = "gaussian_minus_reset_gaussian"
        case["status"] = "pass"
        case["elapsed_seconds"] = metadata["elapsed_components"]["serial_recorded_N1024_seconds"]+time.perf_counter()-started
        case["elapsed_scope"] = "retained serial case time plus fresh continuation wall time"
        metadata["cases"].append(case)
        metadata["status"] = "pass"
        (directory/"N1024.json").write_text(json.dumps(case, indent=2), encoding="utf-8")
    except Exception:
        metadata["status"] = "failed"
        metadata["traceback"] = traceback.format_exc()
        raise
    finally:
        metadata["elapsed_seconds"] = time.perf_counter()-started
        metadata["elapsed_scope"] = "fresh continuation wall time only"
        save()
        print(json.dumps({"run_dir": str(directory), "status": metadata["status"],
                          "elapsed_seconds": metadata["elapsed_seconds"]}), flush=True)
    return metadata
