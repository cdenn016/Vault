"""Replay saved observations through exact-model particle predictors."""
from __future__ import annotations
from dataclasses import replace
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback
import zipfile
import numpy as np
import torch

from .coupled_learning import CoupledState
from .coupled_learning_experiment import build_coupled_case
from .joint_filter import particle_joint_scores,lifted_baseline_log_scores


def _estimate(values: np.ndarray) -> dict[str,float]:
    """Report empirical uncertainty over independent path/tape pairs."""
    return {"mean":float(values.mean()),"standard_error":float(values.std(ddof=1)/len(values)**.5)}


def run_joint_filter_study(run: dict,theory: dict,numerics: dict,output: dict) -> dict:
    """Evaluate the declared saved paths once; no new native paths or learning."""
    if numerics["device"]!="cpu" or numerics["dtype"]!="float64":
        raise ValueError("this profile declares CPU float64")
    torch.set_num_threads(numerics["cpu_threads"])
    root=Path(__file__).resolve().parents[4]
    input_dir=root/run["input_root"]
    native=json.loads((input_dir/"metadata.json").read_text(encoding="utf-8"))
    if native["status"]!="pass":
        raise ValueError("saved native run is incomplete")
    directory=Path(output["root"])/datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory.mkdir(parents=True)
    modules=("joint_filter","joint_filter_experiment","block_observation","switching_paths",
             "coupled_learning","coupled_learning_experiment","network","network_experiment",
             "network_dynamics","predictive_interfaces","locality")
    paths=["src/multiagent_elbo/realizations/gaussian/"+n+".py" for n in modules]+["experiments/gaussian_joint_filter.py"]
    hashes={}
    with zipfile.ZipFile(directory/"source.zip","w",zipfile.ZIP_DEFLATED) as archive:
        for relative in paths:
            data=(root/relative).read_bytes()
            archive.writestr(relative,data)
            hashes[relative]=hashlib.sha256(data).hexdigest()
    metadata={"run":run,"theory":theory,"numerics":numerics,"status":"running","cases":[],
              "source_sha256_diagnostic":hashes,"input_sha256_diagnostic":{},
              "native_metadata":native,"python":sys.executable,"python_version":platform.python_version(),
              "torch":torch.__version__,"cuda_available":torch.cuda.is_available(),
              "base_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),
              "working_status":subprocess.check_output(["git","status","--short"],cwd=root,text=True)}
    def save() -> None:
        """Keep partial cases and the original failure instead of retrying."""
        (directory/"metadata.json").write_text(json.dumps(metadata,indent=2),encoding="utf-8")
    save()
    started=time.perf_counter()
    try:
        for N in theory["n_agents"]:
            case_start=time.perf_counter()
            activation=root/native["run"]["activation_root"]/f"N{N}-learn_both-final.npz"
            schedule_file=root/native["run"]["schedule_root"]/f"N{N}-learn_both-schedule.npz"
            history_file=input_dir/f"N{N}-joint-paths-and-scores.npz"
            for path in (activation,schedule_file,history_file):
                metadata["input_sha256_diagnostic"][str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
            with np.load(activation) as z:
                initial=CoupledState(**{n:torch.from_numpy(z[n].copy()) for n in ("mu","Sigma","pi","Theta")})
            with np.load(schedule_file) as z:
                schedule=tuple(CoupledState(**{n:torch.from_numpy(z[n][t].copy()) for n in ("mu","Sigma","pi","Theta")})
                               for t in range(native["theory"]["intervals"]))
            subdivision=native["run"]["substeps"]
            schedule=tuple(s for s in schedule for _ in range(subdivision))
            dt=native["theory"]["interval_dt"]/subdivision
            with np.load(history_file) as z:
                R=torch.from_numpy(z[f"block{theory['block']}_paths"][:run["n_paths"]].copy())
                assignments=torch.from_numpy(z["assignments"][:run["n_paths"]].astype(np.int64))
            if len(R)!=run["n_paths"]:
                raise ValueError("requested more paths than the saved study contains")
            model,_=build_coupled_case(N,native["theory"]["dimension"],native["run"]["model_seed"],native["theory"]["link_scale"])
            model=replace(model,tau=native["theory"]["tau"])
            refresh=native["theory"]["refresh_rate"]
            mobility=initial.Sigma
            values={}
            arms=[(f"filter{count}",count,False) for count in theory["particles"]]
            arms.append((f"reset{theory['reset_particles']}",theory["reset_particles"],True))
            case={"n_agents":N,"n_paths":len(R),"block":theory["block"],"microsteps":len(schedule),
                  "dt":dt,"native_resampling":False,"relearning":False,"arms":{}}
            with torch.no_grad():
                baseline=lifted_baseline_log_scores(R,assignments,mobility,initial,schedule,model,dt,theory["block"],refresh)
                values["baseline_log_joint"]=baseline.numpy()
                for name,count,reset in arms:
                    chunks={key:[] for key in ("log_joint","log_source","source_ess","joint_ess")}
                    max_projection=0.
                    for start in range(0,len(R),run["batch_size"]):
                        stop=min(start+run["batch_size"],len(R))
                        scored=particle_joint_scores(R[start:stop],assignments[start:stop],mobility,initial,schedule,model,dt,
                            theory["block"],count,run["particle_seed"]+start,refresh_rate=refresh,reset_each_step=reset)
                        for key in chunks:
                            chunks[key].append(scored[key].numpy())
                        max_projection=max(max_projection,scored["projection_max_error"])
                    arrays={key:np.concatenate(chunks[key]) for key in chunks}
                    for key,array in arrays.items():
                        if not np.isfinite(array).all():
                            raise FloatingPointError(f"nonfinite {name} {key}")
                        values[name+"_"+key]=array
                    if max_projection>1e-10:
                        raise ArithmeticError("conditional propagation left the observation fiber")
                    changed=(assignments[:,1:]!=assignments[:,:-1]).any(-1).numpy()
                    score=(values["baseline_log_joint"]-arrays["log_joint"]).sum(-1)
                    values[name+"_minus_baseline"]=score
                    def ess_summary(array: np.ndarray) -> dict:
                        """Describe numerical particle degeneracy, including changed assignments."""
                        return {"min":float(array.min()),"median":float(np.median(array)),
                                "mean_fraction_below_tenth":float((array<count/10).mean()),
                                "changed_assignment_mean":float(array[changed].mean()) if changed.any() else None,
                                "changed_assignment_min":float(array[changed].min()) if changed.any() else None}
                    case["arms"][name]={"particles":count,"reset_each_step":reset,
                        "paired_loss_minus_baseline":_estimate(score),
                        "negative_log_joint":_estimate(-arrays["log_joint"].sum(-1)),
                        "source_ess":ess_summary(arrays["source_ess"]),"joint_ess":ess_summary(arrays["joint_ess"]),
                        "projection_max_error":max_projection,"observed_assignment_changes":int(changed.sum())}
                    print(f"N={N} {name}: loss minus baseline={score.mean():.6f}; elapsed={time.perf_counter()-case_start:.1f}s",flush=True)
                    (directory/f"N{N}-progress.json").write_text(json.dumps(case,indent=2),encoding="utf-8")
                reference="reset"+str(theory["reset_particles"])
                for count in theory["particles"]:
                    name=f"filter{count}"
                    delta=(values[reference+"_log_joint"]-values[name+"_log_joint"]).sum(-1)
                    values[name+"_minus_reset"]=delta
                    case["arms"][name]["paired_loss_minus_reset"]=_estimate(delta)
                if len(theory["particles"])==2:
                    low,high=[f"filter{n}" for n in theory["particles"]]
                    delta=(values[low+"_log_joint"]-values[high+"_log_joint"]).sum(-1)
                    values[high+"_minus_"+low]=delta
                    case["higher_minus_lower_particle_loss"]=_estimate(delta)
            np.savez_compressed(directory/f"N{N}-filter-scores.npz",**values)
            case["elapsed_seconds"]=time.perf_counter()-case_start
            metadata["cases"].append(case)
            (directory/f"N{N}.json").write_text(json.dumps(case,indent=2),encoding="utf-8")
            save()
        metadata["status"]="pass"
    except Exception:
        metadata["status"]="failed"
        metadata["traceback"]=traceback.format_exc()
        raise
    finally:
        metadata["elapsed_seconds"]=time.perf_counter()-started
        save()
        print(json.dumps({"run_dir":str(directory),"status":metadata["status"],
                          "elapsed_seconds":metadata["elapsed_seconds"]}),flush=True)
    return metadata
