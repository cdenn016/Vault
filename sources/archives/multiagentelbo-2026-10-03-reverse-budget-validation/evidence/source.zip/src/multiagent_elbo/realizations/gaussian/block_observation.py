"""Exact Gaussian conditioning on arithmetic block means at fixed c_*."""
from __future__ import annotations

from dataclasses import dataclass
from math import log, pi

import torch


@dataclass(frozen=True)
class BlockObservation:
    r"""Condition independent X_i~N(mean_i,Cov_i) on R_b=sum_{i in b} X_i/s.

    The conditional gain is G_i=s Cov_i (sum_{j in b} Cov_j)^(-1).
    All stored matrices are K by K; no dense NK-dimensional matrix is formed.
    """

    covariance:     torch.Tensor  # (N,K,K), independent node covariances.
    block_size:     int
    noise_chol:     torch.Tensor  # (N,K,K).
    gain:           torch.Tensor  # (nblocks,block_size,K,K).
    projected_chol: torch.Tensor  # (nblocks,K,K), covariance of block means.

    @classmethod
    def compile(
        cls,
        covariance: torch.Tensor,
        block_size: int,
    ) -> BlockObservation:
        r"""Compile G_i and chol[(sum_{i in b} Cov_i)/s^2]."""
        if covariance.ndim != 3 or covariance.shape[-2] != covariance.shape[-1]:
            raise ValueError("covariance must have shape (N,K,K)")
        N, K, _ = covariance.shape
        if block_size <= 0 or N == 0 or N % block_size:
            raise ValueError("block_size must be positive and divide the number of nodes")
        noise_chol = torch.linalg.cholesky(covariance)
        grouped = covariance.reshape(N//block_size, block_size, K, K)
        summed_chol = torch.linalg.cholesky(grouped.sum(1))
        gain = block_size*torch.cholesky_solve(grouped, summed_chol[:, None]).transpose(-1, -2)
        return cls(covariance, block_size, noise_chol, gain, summed_chol/block_size)

    def project(
        self,
        X: torch.Tensor,
    ) -> torch.Tensor:
        r"""Return R_b=sum_{i in b} X_i/s, preserving every leading batch axis."""
        N, K, _ = self.covariance.shape
        return X.reshape(*X.shape[:-2], N//self.block_size, self.block_size, K).mean(-2)

    def _lift(
        self,
        residual: torch.Tensor,
    ) -> torch.Tensor:
        r"""Return G_i residual_b from (...,nblocks,K) to (...,N,K)."""
        lifted = torch.einsum("nbij,...nj->...nbi", self.gain, residual)
        return lifted.flatten(-3, -2)

    def conditional_mean(
        self,
        mean: torch.Tensor,
        R:    torch.Tensor,
    ) -> torch.Tensor:
        r"""Return mean+G(R-P mean), broadcasting leading batch axes."""
        if self.block_size == 1:
            return torch.broadcast_tensors(mean, R)[1]
        return mean+self._lift(R-self.project(mean))

    def sample_conditional(
        self,
        mean:            torch.Tensor,
        R:               torch.Tensor,
        standard_normal: torch.Tensor,
    ) -> torch.Tensor:
        r"""Return mean_cond+eta-G P eta, where eta_i=chol(Cov_i) xi_i.

        Supplied xi must be independent standard normal noise for a random draw.
        The same eta enters both terms, retaining their exact noise correlation.
        """
        mean_cond = self.conditional_mean(mean, R)
        if self.block_size == 1:
            return mean_cond
        eta = torch.einsum("nij,...nj->...ni", self.noise_chol, standard_normal)
        return mean_cond+eta-self._lift(self.project(eta))

    def log_prob(
        self,
        R:    torch.Tensor,
        mean: torch.Tensor,
    ) -> torch.Tensor:
        r"""Return sum_b log N(R_b; P mean_b, (sum_{i in b} Cov_i)/s^2)."""
        residual = R-self.project(mean)  # (...,nblocks,K).
        white = torch.linalg.solve_triangular(
            self.projected_chol, residual.unsqueeze(-1), upper=False,
        ).squeeze(-1)
        dimension = self.projected_chol.shape[0]*self.projected_chol.shape[1]
        log_determinant_half = self.projected_chol.diagonal(dim1=-2, dim2=-1).log().sum()
        return -.5*(white.square().sum((-2, -1))+dimension*log(2*pi))-log_determinant_half
