"""One declared replay of deterministic source-adapted Gaussian predictors."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback
import zipfile

import numpy as np
import torch

from .coupled_learning import CoupledState
from .coupled_learning_experiment import build_coupled_case
from .source_adapted_filter import gaussian_joint_scores


def _estimate(values: np.ndarray) -> dict[str, float]:
    """Report paired-path mean and empirical standard error on the used prefix."""
    return {"mean": float(values.mean()),
            "standard_error": float(values.std(ddof=1)/len(values)**.5)}


def _decomposition(
    joint:   np.ndarray,
    source:  np.ndarray,
    changed: np.ndarray,
) -> tuple[dict, dict[str, np.ndarray]]:
    """Sum source, configuration and joint values on each declared step subset."""
    result, arrays = {}, {}
    components = {"joint": joint, "source": source, "configuration": joint-source}
    masks = {"all_steps": np.ones_like(changed), "changed": changed, "unchanged": ~changed}
    for component, values in components.items():
        result[component] = {}
        for subset, mask in masks.items():
            totals = np.where(mask, values, 0.).sum(-1)
            arrays[component+"_"+subset] = totals
            result[component][subset] = _estimate(totals)
    return result, arrays


def run_source_adapted_study(
    run:      dict,
    theory:   dict,
    numerics: dict,
    output:   dict,
) -> dict:
    """Replay saved observations once, checkpointing each completed arm/path."""
    if numerics["device"] != "cpu" or numerics["dtype"] != "float64":
        raise ValueError("the declared profile requires CPU float64")
    if run["batch_size"] != 1 or run["n_paths"] < 2:
        raise ValueError("the declared replay uses one path per batch and at least two paths")
    torch.set_num_threads(numerics["cpu_threads"])
    root = Path(__file__).resolve().parents[4]
    native_dir, particle_dir = root/run["input_root"], root/run["particle_input_root"]
    native_file, particle_file = native_dir/"metadata.json", particle_dir/"metadata.json"
    native = json.loads(native_file.read_text(encoding="utf-8"))
    particle = json.loads(particle_file.read_text(encoding="utf-8"))
    if native["status"] != "pass" or particle["status"] != "pass":
        raise ValueError("both saved input studies must be complete")
    directory = Path(output["root"])/datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory.mkdir(parents=True)
    modules = ("source_adapted_filter_experiment", "source_adapted_filter", "source_gaussian",
               "gaussian_message", "coupled_learning", "coupled_learning_experiment",
               "switching_paths", "network", "network_experiment", "network_dynamics",
               "predictive_interfaces", "locality")
    sources = ["src/multiagent_elbo/realizations/gaussian/"+name+".py" for name in modules]
    sources += ["experiments/gaussian_source_adapted.py",
                "docs/research/2026-10-02-renormalization-completion/source-adapted-CONTRACT.md",
                "docs/research/2026-10-02-renormalization-completion/source-adapted-filter-construction.md"]
    for name in ("source_gaussian", "gaussian_message", "source_adapted_filter"):
        candidate = "tests/test_gaussian_"+name+".py" if name != "gaussian_message" else "tests/test_gaussian_message.py"
        if (root/candidate).is_file():
            sources.append(candidate)
    hashes = {}
    with zipfile.ZipFile(directory/"source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for relative in sources:
            data = (root/relative).read_bytes()
            archive.writestr(relative, data)
            hashes[relative] = hashlib.sha256(data).hexdigest()
    metadata = {"run": run, "theory": theory, "numerics": numerics, "status": "running",
        "cases": [], "source_sha256_diagnostic": hashes, "input_sha256_diagnostic": {},
        "native_metadata": native, "particle_metadata": particle,
        "python": sys.executable, "python_version": platform.python_version(),
        "torch": torch.__version__, "base_head": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
        "working_status": subprocess.check_output(
            ["git", "status", "--short"], cwd=root, text=True)}
    for path in (native_file, particle_file):
        metadata["input_sha256_diagnostic"][str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()

    def save() -> None:
        """Retain metadata for this attempt, including its original failure."""
        (directory/"metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    save()
    started = time.perf_counter()
    print(json.dumps({"run_dir": str(directory), "status": "running"}), flush=True)
    try:
        for N in theory["n_agents"]:
            case_started = time.perf_counter()
            activation = root/native["run"]["activation_root"]/f"N{N}-learn_both-final.npz"
            schedule_file = root/native["run"]["schedule_root"]/f"N{N}-learn_both-schedule.npz"
            history_file = native_dir/f"N{N}-joint-paths-and-scores.npz"
            old_scores_file = particle_dir/f"N{N}-filter-scores.npz"
            diagnostic_file = root/run["diagnostic_root"]/f"N{N}-decomposed-scores.npz"
            for path in (activation, schedule_file, history_file, old_scores_file, diagnostic_file):
                metadata["input_sha256_diagnostic"][str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
            with np.load(activation) as z:
                initial = CoupledState(**{name: torch.from_numpy(z[name].copy())
                                         for name in ("mu", "Sigma", "pi", "Theta")})
            with np.load(schedule_file) as z:
                schedule = tuple(CoupledState(**{name: torch.from_numpy(z[name][t].copy())
                    for name in ("mu", "Sigma", "pi", "Theta")})
                    for t in range(native["theory"]["intervals"]))
            schedule = tuple(state for state in schedule for _ in range(native["run"]["substeps"]))
            dt = native["theory"]["interval_dt"]/native["run"]["substeps"]
            with np.load(history_file) as z:
                R = torch.from_numpy(z[f"block{theory['block']}_paths"][:run["n_paths"]].copy())
                assignments = torch.from_numpy(z["assignments"][:run["n_paths"]].astype(np.int64))
            if len(R) != run["n_paths"]:
                raise ValueError("the native history does not contain the requested path prefix")
            changed = (assignments[:, 1:] != assignments[:, :-1]).any(-1).numpy()
            values = {"changed": changed}
            with np.load(old_scores_file) as z:
                for name in ("baseline_log_joint", "filter64_log_joint", "filter64_log_source",
                             "reset64_log_joint", "reset64_log_source"):
                    values[name] = z[name][:run["n_paths"]].copy()
            with np.load(diagnostic_file) as z:
                values["baseline_log_source"] = z["baseline_log_source"][:run["n_paths"]].copy()
                if not np.array_equal(z["changed"][:run["n_paths"]], changed):
                    raise ValueError("saved diagnostic assignment changes differ from native input")
            for name, value in values.items():
                if value.shape != changed.shape or not np.isfinite(value).all():
                    raise ValueError(f"invalid saved comparison array {name}")
            model, _ = build_coupled_case(N, native["theory"]["dimension"],
                native["run"]["model_seed"], native["theory"]["link_scale"])
            model = replace(model, tau=native["theory"]["tau"])
            arms = (("gaussian", False), ("reset_gaussian", True))
            keys = ("log_joint", "log_source", "source_updates", "shortcut")
            chunks = {name: {key: [] for key in keys} for name, _ in arms}
            case = {"n_agents": N, "n_paths": len(R), "block": theory["block"],
                "microsteps": len(schedule), "dt": dt, "native_resampling": False,
                "relearning": False, "status": "running", "arms": {
                    name: {"completed_paths": 0, "reset_each_step": reset,
                           "projection_max_error": 0., "covariance_projection_max_error": 0.}
                    for name, reset in arms}}

            def checkpoint() -> None:
                """Store each available arm prefix, even if the next arm fails."""
                for name, _ in arms:
                    for key in keys:
                        if chunks[name][key]:
                            values[name+"_"+key] = np.concatenate(chunks[name][key])
                np.savez_compressed(directory/f"N{N}-source-adapted-scores.npz", **values)
                case["elapsed_seconds"] = time.perf_counter()-case_started
                (directory/f"N{N}-progress.json").write_text(json.dumps(case, indent=2), encoding="utf-8")
                metadata["active_case"] = case
                save()

            with torch.no_grad():
                for path_index in range(len(R)):
                    for name, reset in arms:
                        metadata["active"] = {"n_agents": N, "arm": name, "path_index": path_index}
                        save()
                        scored = gaussian_joint_scores(
                            R[path_index:path_index+1], assignments[path_index:path_index+1],
                            initial.Sigma, initial, schedule, model, dt, theory["block"],
                            refresh_rate=native["theory"]["refresh_rate"],
                            shortcut_mass=theory["shortcut_mass"], reset_each_step=reset)
                        for key in keys:
                            array = scored[key].numpy()
                            if array.shape != (1, len(schedule)) or not np.isfinite(array).all():
                                raise FloatingPointError(f"invalid {name} path {path_index} {key}")
                            chunks[name][key].append(array)
                        for key in ("projection_max_error", "covariance_projection_max_error"):
                            value = float(scored[key])
                            if not np.isfinite(value) or value > 1e-9:
                                raise ArithmeticError(f"conditional Gaussian left its observation fiber: {key}={value}")
                            case["arms"][name][key] = max(case["arms"][name][key], value)
                        case["arms"][name]["completed_paths"] = path_index+1
                        checkpoint()
                        print(f"N={N} {name} path={path_index+1}/{len(R)}; "
                              f"elapsed={time.perf_counter()-case_started:.1f}s", flush=True)
            case["observed_assignment_changes"] = int(changed.sum())
            case["assignment_changes_per_path"] = _estimate(changed.sum(-1))
            for name, _ in arms:
                case["arms"][name]["negative_log_score"], _ = _decomposition(
                    -values[name+"_log_joint"], -values[name+"_log_source"], changed)
                for key in ("source_updates", "shortcut"):
                    array = values[name+"_"+key]
                    case["arms"][name][key] = {
                        "total": int(array.sum()), "per_path": _estimate(array.sum(-1)),
                        "changed_total": int(np.where(changed, array, 0).sum()),
                        "unchanged_total": int(np.where(~changed, array, 0).sum())}
            comparisons = [("gaussian", "reset_gaussian")]
            comparisons += [(name, reference) for name, _ in arms
                            for reference in ("baseline", "filter64", "reset64")]
            case["paired_loss_contrasts"] = {}
            for name, reference in comparisons:
                key = name+"_minus_"+reference
                summary, per_path = _decomposition(
                    values[reference+"_log_joint"]-values[name+"_log_joint"],
                    values[reference+"_log_source"]-values[name+"_log_source"], changed)
                case["paired_loss_contrasts"][key] = summary
                values.update({key+"_"+component: array for component, array in per_path.items()})
            case["primary_contrast"] = "gaussian_minus_reset_gaussian"
            case["status"] = "pass"
            checkpoint()
            metadata["cases"].append(case)
            metadata.pop("active_case", None)
            metadata.pop("active", None)
            (directory/f"N{N}.json").write_text(json.dumps(case, indent=2), encoding="utf-8")
            save()
        metadata["status"] = "pass"
    except Exception:
        metadata["status"] = "failed"
        metadata["traceback"] = traceback.format_exc()
        raise
    finally:
        metadata["elapsed_seconds"] = time.perf_counter()-started
        save()
        print(json.dumps({"run_dir": str(directory), "status": metadata["status"],
                          "elapsed_seconds": metadata["elapsed_seconds"]}), flush=True)
    return metadata
