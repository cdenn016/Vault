"""Candidate-driven fine lift and conservative reverse-KL budget on paired grids."""
from __future__ import annotations

from math import log1p

import torch

from .coupled_learning import CoupledModel, CoupledState
from .gaussian_message import observe_gaussian, propagate_gaussian
from .source_square_root import square_root_source_rows
from .switching_paths import sheet_force, source_log_posterior


def comparison_step(
    X:           torch.Tensor,       # (B,N,K), comparison fine state.
    mu:          torch.Tensor,       # (B,N,K), candidate physical fiber mean.
    covariance:  torch.Tensor,       # (B,NK,NK), candidate fiber covariance.
    assignments: torch.Tensor,       # (B,N).
    mobility:    torch.Tensor,       # (N,K,K).
    dW:          torch.Tensor,       # (N,K), shared fine Brownian increment.
    state:       CoupledState,
    model:       CoupledModel,
    dt:          float,
    block_size:  int,
) -> dict[str, torch.Tensor]:
    r"""Euler-step vhat=v+QP^T(PQP^T)^(-1)(vbar-Pv), then condition.

    Q=2M and P averages blocks. The same fine noise supplies the retained
    observation. Gaussian endpoint conditioning is a discretization of the
    correlated continuous filter, not an exact finite-step realization of it.
    """
    B, N, K = X.shape
    C = N//block_size
    weights = torch.nn.functional.one_hot(assignments, state.pi.shape[-1]).to(X.dtype)
    native_drift = -torch.einsum("nij,bnj->bni", mobility, sheet_force(X, weights, state.Theta, model))
    candidate_drift = -torch.einsum("nij,bnj->bni", mobility, sheet_force(mu, weights, state.Theta, model))
    difference = (candidate_drift-native_drift).reshape(B, C, block_size, K).mean(2)
    Qr = 2*mobility.reshape(C, block_size, K, K).sum(1)/block_size**2
    Lr = torch.linalg.cholesky(Qr)
    solved = torch.cholesky_solve(difference[..., None], Lr).squeeze(-1)
    correction = (2/block_size)*torch.einsum("nij,bnj->bni", mobility, solved.repeat_interleave(block_size, dim=1))
    noise = torch.einsum("nij,nj->ni", torch.linalg.cholesky(2*mobility), dW)
    next_X = X+dt*(native_drift+correction)+noise[None]
    forecast_mean, forecast_cov = propagate_gaussian(mu, covariance, assignments, mobility, state, model, dt)
    retained = next_X.reshape(B, C, block_size, K).mean(2).flatten(1)
    conditioned = observe_gaussian(forecast_mean, forecast_cov, retained, block_size)
    return {"comparison": next_X, "mean": conditioned["mean"],
            "covariance": conditioned["covariance"],
            "drift_rate": .5*(difference*solved).sum()}


def reverse_source_probe(
    X:           torch.Tensor,       # (B,N,K), comparison fine states.
    mu:          torch.Tensor,
    covariance:  torch.Tensor,
    uniforms:    torch.Tensor,       # (B,N), independent candidate-prefix draws.
    state:       CoupledState,
    model:       CoupledModel,
    block_size:  int,
    integration: str = "binary_integral",
) -> dict[str, torch.Tensor]:
    r"""Sample sum_i D(c_i(.|A_<i)||beta_i(X)), with A_<i drawn from c.

    Its conditional expectation is D(hat b||b), a conservative upper bound
    on the visible-intensity divergence. No native-prefix substitution or
    self subtraction is made. The hypothetical message does not change inputs.
    """
    native = source_log_posterior(X, state, model)
    labels = torch.zeros_like(uniforms, dtype=torch.long)
    sampled = square_root_source_rows(mu, covariance, labels, state, model, block_size,
                                      integration=integration, uniforms=uniforms)
    rows = sampled["log_rows"]
    return {"log_beta": native, "log_candidate_rows": rows, "labels": sampled["labels"],
            "mark_kl": (rows.exp()*(rows-native)).sum((-1, -2)),
            "integration_error_max": sampled.get("integration_error_max", X.new_zeros(len(X)))}


def _run_reverse_grid(
    mobility:    torch.Tensor,
    initial:     CoupledState,
    model:       CoupledModel,
    tape:        dict[str, torch.Tensor],
    grid:        torch.Tensor,
    horizon:     float,
    block_size:  int,
    integration: str = "binary_integral",
) -> dict[str, torch.Tensor]:
    r"""Run the comparison law on one mesh; retain pre-step state on failure."""
    X, J = tape["initial_X"].clone()[None], tape["initial_J"].clone()[None]
    N, K = initial.mu.shape
    C = N//block_size
    retained = X.reshape(1, C, block_size, K).mean(2).flatten(1)
    message = observe_gaussian(initial.mu[None], torch.block_diag(*initial.Sigma)[None], retained, block_size)
    mu, cov = message["mean"], message["covariance"]
    times = tape["fine_times"][grid]
    probe_indices = torch.searchsorted(times, tape["probe_times"], right=True)-1
    events = {float(value): index for index, value in enumerate(tape["proposal_times"])}
    histories = {"comparison": [X[0].clone()], "mean": [mu[0].clone()], "assignments": [J[0].clone()]}
    rates, noises = [], []
    probes: dict[str, list] = {}
    event_records: dict[str, list] = {key: [] for key in ("times", "labels", "visible", "log_candidate", "log_native", "log_rows")}
    maximum_mean, maximum_cov, maximum_integration = 0., 0., 0.
    for step in range(len(times)-1):
        try:
            for probe_index in (probe_indices == step).nonzero(as_tuple=True)[0].tolist():
                values = reverse_source_probe(X, mu, cov, tape["probe_uniforms"][probe_index:probe_index+1],
                                               initial, model, block_size, integration)
                maximum_integration = max(maximum_integration, float(values["integration_error_max"].max()))
                for key, value in values.items():
                    probes.setdefault(key, []).append((probe_index, value[0].clone()))
            dt = float(times[step+1]-times[step])
            dW = tape["fine_dW"][int(grid[step]):int(grid[step+1])].sum(0)
            advanced = comparison_step(X, mu, cov, J, mobility, dW, initial, model, dt, block_size)
            rates.append(advanced["drift_rate"])
            noises.append(dW)
            X, mu, cov = advanced["comparison"], advanced["mean"], advanced["covariance"]
            event = events.get(float(times[step+1]))
            if event is not None:
                sampled = square_root_source_rows(mu, cov, J, initial, model, block_size,
                    integration=integration, uniforms=tape["proposal_uniforms"][event:event+1])
                labels = sampled["labels"]
                visible = not torch.equal(labels, J)
                maximum_integration = max(maximum_integration, float(sampled.get("integration_error_max", X.new_zeros(1)).max()))
                native = source_log_posterior(X, initial, model)
                for key, value in (("times", times[step+1]), ("labels", labels[0]),
                    ("visible", X.new_tensor(visible, dtype=torch.bool)),
                    ("log_candidate", sampled["log_refresh"][0]), ("log_rows", sampled["log_rows"][0]),
                    ("log_native", native.gather(-1, labels[..., None]).sum())):
                    event_records[key].append(value.clone())
                if visible:
                    mu, cov = sampled["mean"], sampled["covariance"]
                J = labels
            maximum_mean = max(maximum_mean, float((mu-X).reshape(1, C, block_size, K).mean(2).abs().max()))
            maximum_cov = max(maximum_cov, float(cov.reshape(1, C, block_size, K, N*K).mean(2).abs().max()))
            for key, value in (("comparison", X), ("mean", mu), ("assignments", J)):
                histories[key].append(value[0].clone())
        except Exception as error:
            error.reverse_state = {"comparison": X, "mean": mu, "covariance": cov, "assignments": J,
                                   "step": X.new_tensor(step), "interval_start": times[step],
                                   "interval_end": times[step+1]}
            raise
    result = {key: torch.stack(values) for key, values in histories.items()}
    for key, values in probes.items():
        result["probe_"+key] = torch.stack([value for _, value in sorted(values, key=lambda pair: pair[0])])
    for key, values in event_records.items():
        dtype = torch.long if key == "labels" else torch.bool if key == "visible" else X.dtype
        shape = (0, N, initial.pi.shape[-1]) if key == "log_rows" else (0, N) if key == "labels" else (0,)
        result["event_"+key] = torch.stack(values) if values else torch.empty(shape, dtype=dtype)
    result.update(times=times, dW=torch.stack(noises), drift_rates=torch.stack(rates), final_covariance=cov[0])
    result["drift_integral"] = (result["drift_rates"]*torch.diff(times)).sum()
    result["mark_integral"] = horizon*result["probe_mark_kl"].mean()
    result["total_integral"] = result["drift_integral"]+result["mark_integral"]
    result["proposal_count"] = X.new_tensor(len(events))
    result["visible_changes"] = result["event_visible"].sum()
    result["projection_max_error"] = X.new_tensor(maximum_mean)
    result["covariance_projection_max_error"] = X.new_tensor(maximum_cov)
    result["integration_error_max"] = X.new_tensor(maximum_integration)
    return result


@torch.no_grad()
def sample_reverse_budget(
    mobility:    torch.Tensor,
    initial:     CoupledState,
    model:       CoupledModel,
    horizon:     float,
    block_size:  int,
    coarse_steps: int,
    n_probes:    int,
    seed:        int,
    integration: str = "binary_integral",
) -> dict[str, torch.Tensor]:
    r"""Sample fresh candidate-driven paired paths and their full-mark reverse cost.

    Six separate streams generate activation, rate-one proposal times, fine
    Brownian increments, proposal uniforms, probe times and probe uniforms.
    Coarse and fine grids share these draws; candidate assignments may differ.
    Uniform-time probes estimate each mesh's left-endpoint source integral.
    No continuum certificate or Monte Carlo confidence bound is asserted.
    """
    N, K = initial.mu.shape
    if mobility.device.type != "cpu" or mobility.dtype != torch.float64:
        raise ValueError("the declared reverse-budget calculation uses CPU float64")
    if horizon <= 0 or min(block_size, coarse_steps, n_probes) < 1 or N % block_size:
        raise ValueError("positive horizon/counts and a dividing block size are required")
    if integration not in ("cubature", "binary_integral"):
        raise ValueError("integration must be cubature or binary_integral")
    generators = [torch.Generator().manual_seed(seed+offset) for offset in range(6)]
    X = initial.mu+torch.einsum("nij,nj->ni", torch.linalg.cholesky(initial.Sigma),
        torch.randn((N, K), dtype=mobility.dtype, generator=generators[0]))
    uniforms = torch.rand((N,), dtype=mobility.dtype, generator=generators[0])
    J = (uniforms[:, None] > initial.pi.cumsum(-1)).sum(-1).clamp_max(initial.pi.shape[-1]-1)
    events, clock = [], 0.
    while True:
        clock -= log1p(-float(torch.rand((), dtype=mobility.dtype, generator=generators[1])))
        if clock >= horizon:
            break
        events.append(clock)
    regular = torch.linspace(0., horizon, 2*coarse_steps+1, dtype=mobility.dtype)
    fine_times = torch.tensor(sorted(set(regular.tolist()+events)), dtype=mobility.dtype)
    coarse_times = torch.tensor(sorted(set(regular[::2].tolist()+events)), dtype=mobility.dtype)
    noise = torch.randn((len(fine_times)-1, N, K), dtype=mobility.dtype, generator=generators[2])
    noise *= torch.diff(fine_times).sqrt()[:, None, None]
    tape = {"initial_X": X, "initial_J": J, "fine_times": fine_times, "fine_dW": noise,
            "proposal_times": torch.tensor(events, dtype=mobility.dtype),
            "proposal_uniforms": torch.rand((len(events), N), dtype=mobility.dtype, generator=generators[3]),
            "probe_times": horizon*torch.rand((n_probes,), dtype=mobility.dtype, generator=generators[4]),
            "probe_uniforms": torch.rand((n_probes, N), dtype=mobility.dtype, generator=generators[5])}
    result = dict(tape)
    for level, times in (("coarse", coarse_times), ("fine", fine_times)):
        try:
            measured = _run_reverse_grid(mobility, initial, model, tape,
                                         torch.searchsorted(fine_times, times), horizon, block_size, integration)
        except Exception as error:
            if hasattr(error, "reverse_state"):
                error.reverse_state.update({"tape_"+key: value for key, value in tape.items()})
                error.add_note("reverse-budget level="+level)
            raise
        result.update({level+"_"+key: value for key, value in measured.items()})
    if not all(bool(torch.isfinite(value).all()) for value in result.values()):
        raise FloatingPointError("nonfinite reverse-budget output")
    return result
