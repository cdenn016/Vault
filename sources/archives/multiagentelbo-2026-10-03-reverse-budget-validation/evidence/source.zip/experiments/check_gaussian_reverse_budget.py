"""Reconstruct saved reverse-budget arithmetic independently with NumPy.

This checks finite-grid paths and costs. It does not re-integrate Gaussian
candidate probabilities, reconstruct all message covariances, or certify a
continuous-time budget or its accuracy.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np


ATOL = 1e-10
RTOL = 5e-11


def _load(path: Path) -> dict[str, np.ndarray]:
    """Read an array archive without loading object arrays."""
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}


def _force(
    X:           np.ndarray,
    assignments: np.ndarray,
    maps:        np.ndarray,
    model:       dict[str, np.ndarray],
) -> np.ndarray:
    r"""Compute the prior and incident-record gradient, including senders."""
    receiver = np.arange(len(X))
    sources = model["sources"][receiver, assignments]
    links = maps[receiver, assignments]
    residual = X-np.einsum("nij,nj->ni", links, X[sources])
    record = np.einsum("nij,nj->ni", model["H"], residual)/float(model["tau"])
    force = np.einsum("nij,nj->ni", model["J_0"], X-model["a"])+record
    np.add.at(force, sources, -np.einsum("nji,nj->ni", links, record))
    return force


def _native_rows(
    X:          np.ndarray,
    maps:       np.ndarray,
    activation: dict[str, np.ndarray],
    model:      dict[str, np.ndarray],
) -> np.ndarray:
    r"""Compute log beta from the quadratic costs using stable normalization."""
    residual = X[:, None]-np.einsum("nsij,nsj->nsi", maps, X[model["sources"]])
    cost = .5*np.einsum("nsi,nij,nsj->ns", residual, model["H"], residual)
    logits = np.log(activation["pi"])-cost/float(model["tau"])
    shifted = logits-logits.max(axis=-1, keepdims=True)
    return shifted-np.log(np.exp(shifted).sum(axis=-1, keepdims=True))


def _check_grid(
    arrays:     dict[str, np.ndarray],
    activation: dict[str, np.ndarray],
    model:      dict[str, np.ndarray],
    level:      str,
    block:      int,
    horizon:    float,
    steps:      int,
) -> dict[str, Any]:
    """Record discrepancies for one saved grid, preserving all failed checks."""
    prefix = level+"_"
    values = {name[len(prefix):]: value for name, value in arrays.items() if name.startswith(prefix)}
    errors: dict[str, float] = {}
    failed: set[str] = set()

    def compare(name: str, actual: Any, expected: Any, atol: float = ATOL, rtol: float = RTOL) -> None:
        """Accumulate the largest absolute discrepancy at the stated tolerance."""
        actual, expected = np.asarray(actual), np.asarray(expected)
        if actual.shape != expected.shape:
            errors[name] = float("inf")
            failed.add(name+": shape mismatch")
            return
        delta = np.abs(actual.astype(float)-expected.astype(float))
        error = float(delta.max()) if delta.size else 0.
        errors[name] = max(errors.get(name, 0.), error)
        if not np.allclose(actual, expected, atol=atol, rtol=rtol):
            failed.add(name)

    def bound(name: str, value: float, limit: float) -> None:
        """Check a nonnegative diagnostic against its declared upper limit."""
        errors[name] = value
        if not np.isfinite(value) or value > limit:
            failed.add(name)

    def check_rows(name: str, rows: np.ndarray, uniforms: np.ndarray, labels: np.ndarray) -> None:
        """Check normalized candidate rows and their supplied-uniform intervals."""
        probabilities = np.exp(rows)
        compare(name+"_normalization", probabilities.sum(-1), np.ones(rows.shape[:-1]), 1e-11, 0.)
        cdf = probabilities.cumsum(-1)
        drawn = np.minimum((uniforms[..., None] > cdf).sum(-1), rows.shape[-1]-1)
        compare(name+"_labels", labels, drawn, 0., 0.)
        upper = np.take_along_axis(cdf, labels[..., None], axis=-1)[..., 0]
        lower_cdf = np.concatenate((np.zeros_like(cdf[..., :1]), cdf[..., :-1]), axis=-1)
        lower = np.take_along_axis(lower_cdf, labels[..., None], axis=-1)[..., 0]
        violations = np.maximum(lower-uniforms, uniforms-upper)
        bound(name+"_interval_violation", max(0., float(violations.max())) if violations.size else 0., 1e-14)
        if not np.all(np.isfinite(uniforms) & (uniforms >= 0) & (uniforms < 1)):
            failed.add(name+"_uniform_domain")

    for name, value in values.items():
        if not np.isfinite(value).all():
            failed.add("finite:"+name)
    X, mu, J = values["comparison"], values["mean"], values["assignments"]
    times = values["times"]
    N, K = activation["mu"].shape
    C = N//block
    mobility = activation["Sigma"]
    links = activation["Theta"][model["link_index"]].copy()
    links[model["reverse"]] = np.linalg.inv(links[model["reverse"]])
    Qr = 2*mobility.reshape(C, block, K, K).sum(1)/block**2
    noise_factor = np.linalg.cholesky(2*mobility)
    expected_times = np.unique(np.concatenate((np.linspace(0., horizon, (2 if level == "fine" else 1)*steps+1),
                                               arrays["proposal_times"])))
    compare("grid_times", times, expected_times)
    if np.any(np.diff(times) <= 0):
        failed.add("grid_strictly_increasing")
    compare("initial_comparison", X[0], arrays["initial_X"], 0., 0.)
    compare("initial_assignment", J[0], arrays["initial_J"], 0., 0.)
    fiber_mean = (mu-X).reshape(len(times), C, block, K).mean(2)
    bound("mean_fiber_max", float(np.abs(fiber_mean).max()), 1e-8)
    fine_indices = np.searchsorted(arrays["fine_times"], times)
    compare("grid_in_fine_tape", arrays["fine_times"][fine_indices], times, 0., 0.)
    rates = []
    for step, dt in enumerate(np.diff(times)):
        dW = arrays["fine_dW"][fine_indices[step]:fine_indices[step+1]].sum(0)
        compare("brownian_aggregation", values["dW"][step], dW)
        native = -np.einsum("nij,nj->ni", mobility, _force(X[step], J[step], links, model))
        candidate = -np.einsum("nij,nj->ni", mobility, _force(mu[step], J[step], links, model))
        difference = (candidate-native).reshape(C, block, K).mean(1)
        solved = np.linalg.solve(Qr, difference[..., None])[..., 0]
        correction = (2/block)*np.einsum("nij,nj->ni", mobility, np.repeat(solved, block, axis=0))
        drift = native+correction
        compare("projected_comparison_drift", drift.reshape(C, block, K).mean(1),
                candidate.reshape(C, block, K).mean(1))
        noise = np.einsum("nij,nj->ni", noise_factor, dW)
        compare("euler_comparison", X[step+1], X[step]+dt*drift+noise)
        rates.append(.5*np.sum(difference*solved))
    rates_array = np.asarray(rates)
    compare("drift_rates", values["drift_rates"], rates_array)
    drift_integral = float(rates_array@np.diff(times))
    compare("drift_integral", values["drift_integral"], drift_integral)

    probe_steps = np.searchsorted(times, arrays["probe_times"], side="right")-1
    native_rows = np.stack([_native_rows(X[step], links, activation, model) for step in probe_steps])
    compare("probe_native_rows", values["probe_log_beta"], native_rows)
    candidate_rows = values["probe_log_candidate_rows"]
    check_rows("probe_candidate", candidate_rows, arrays["probe_uniforms"], values["probe_labels"])
    mark = (np.exp(candidate_rows)*(candidate_rows-native_rows)).sum(axis=(-1, -2))
    compare("probe_mark_kl", values["probe_mark_kl"], mark)
    mark_integral = float(horizon*mark.mean())
    total_integral = drift_integral+mark_integral
    compare("mark_integral", values["mark_integral"], mark_integral)
    compare("total_integral", values["total_integral"], total_integral)
    minimum_cost = min(float(rates_array.min()), float(mark.min()), drift_integral, mark_integral, total_integral)
    bound("negative_cost_magnitude", max(0., -minimum_cost), 1e-9)

    compare("event_times", values["event_times"], arrays["proposal_times"], 0., 0.)
    event_rows, labels = values["event_log_rows"], values["event_labels"]
    check_rows("event_candidate", event_rows, arrays["proposal_uniforms"], labels)
    selected = np.take_along_axis(event_rows, labels[..., None], axis=-1)[..., 0].sum(-1)
    compare("event_candidate_score", values["event_log_candidate"], selected)
    expected_assignments = np.empty_like(J)
    expected_assignments[0] = arrays["initial_J"]
    event_steps = np.searchsorted(times, arrays["proposal_times"])
    compare("events_on_grid", times[event_steps], arrays["proposal_times"], 0., 0.)
    event_by_step = {int(step): event for event, step in enumerate(event_steps)}
    visible = np.zeros(len(labels), dtype=bool)
    native_scores = np.zeros(len(labels))
    receiver = np.arange(N)
    for step in range(1, len(times)):
        expected_assignments[step] = expected_assignments[step-1]
        if step in event_by_step:
            event = event_by_step[step]
            visible[event] = np.any(labels[event] != expected_assignments[step-1])
            expected_assignments[step] = labels[event]
            rows = _native_rows(X[step], links, activation, model)
            native_scores[event] = rows[receiver, labels[event]].sum()
    compare("event_native_score", values["event_log_native"], native_scores)
    compare("event_visible", values["event_visible"], visible, 0., 0.)
    compare("assignments_history", J, expected_assignments, 0., 0.)
    compare("proposal_count", values["proposal_count"], len(labels), 0., 0.)
    compare("visible_changes", values["visible_changes"], visible.sum(), 0., 0.)

    covariance = values["final_covariance"]
    fiber_covariance = covariance.reshape(C, block, K, N*K).mean(1)
    bound("final_covariance_fiber_max", float(np.abs(fiber_covariance).max()), 1e-8)
    compare("final_covariance_symmetry", covariance, covariance.T)
    kept = np.array([node*K+coordinate for node in range(N) if node % block != block-1
                     for coordinate in range(K)])
    try:
        factor = np.linalg.cholesky(covariance[np.ix_(kept, kept)])
        minimum_cholesky = float(np.diag(factor).min())
    except np.linalg.LinAlgError:
        minimum_cholesky = None
        failed.add("final_hidden_cholesky")
    for name in ("projection_max_error", "covariance_projection_max_error", "integration_error_max"):
        bound("saved_"+name, float(values[name]), 1e-8)
    bound("probe_integration_error_max", float(values["probe_integration_error_max"].max()), 1e-8)
    return {"status": "fail" if failed else "pass", "failed_checks": sorted(failed),
            "maximum_absolute_discrepancies": errors, "final_hidden_cholesky_min_diagonal": minimum_cholesky,
            "summary": {"drift_integral": drift_integral, "mark_integral": mark_integral,
                        "total_integral": total_integral, "proposal_count": len(labels),
                        "visible_changes": int(visible.sum()), "minimum_cost": minimum_cost}}


def check_run(run_dir: Path) -> int:
    """Save the reconstruction report even when a case or an input fails."""
    report: dict[str, Any] = {
        "status": "fail", "scope": "independent NumPy reconstruction of saved finite-grid paths and costs",
        "limits": "Candidate Gaussian integrals and intermediate covariance updates are not recomputed; no continuous-time or accuracy certificate.",
        "numpy_version": np.__version__, "tolerance": {"atol": ATOL, "rtol": RTOL,
        "rows": 1e-11, "cost_negative_tolerance": 1e-9, "fiber_and_diagnostics": 1e-8},
        "cases": {}, "errors": []}
    try:
        metadata = json.loads((run_dir/"metadata.json").read_text(encoding="utf-8"))
        if metadata["status"] != "pass":
            raise ValueError("runner metadata status is not pass")
        theory = metadata["theory"]
        expected = {"n_agents": [512, 1024], "block_size": 16, "horizon": 1., "tau": .5, "coarse_steps": 64}
        for name, value in expected.items():
            if theory[name] != value:
                raise ValueError(f"declared configuration differs: {name}")
        for N in theory["n_agents"]:
            case: dict[str, Any] = {"status": "fail", "grids": {}}
            report["cases"][str(N)] = case
            try:
                activation = _load(run_dir/"inputs"/f"N{N}-activation.npz")
                model = _load(run_dir/"inputs"/f"N{N}-model.npz")
                arrays = _load(run_dir/f"N{N}-path000.npz")
                if activation["mu"].shape[0] != N or float(model["tau"]) != theory["tau"]:
                    raise ValueError("saved model disagrees with the declared size or temperature")
                for level in ("coarse", "fine"):
                    try:
                        case["grids"][level] = _check_grid(arrays, activation, model, level,
                            theory["block_size"], theory["horizon"], theory["coarse_steps"])
                    except Exception as error:
                        case["grids"][level] = {"status": "fail", "error": f"{type(error).__name__}: {error}"}
                if all(grid["status"] == "pass" for grid in case["grids"].values()):
                    case["status"] = "pass"
                if all("summary" in grid for grid in case["grids"].values()):
                    case["fine_minus_coarse"] = {name: case["grids"]["fine"]["summary"][name]
                        -case["grids"]["coarse"]["summary"][name]
                        for name in ("drift_integral", "mark_integral", "total_integral")}
            except Exception as error:
                case["error"] = f"{type(error).__name__}: {error}"
        if all(case["status"] == "pass" for case in report["cases"].values()):
            report["status"] = "pass"
    except Exception as error:
        report["errors"].append(f"{type(error).__name__}: {error}")
    (run_dir/"independent-checks.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "report": str(run_dir/"independent-checks.json")}))
    return 0 if report["status"] == "pass" else 1


def main() -> int:
    """Accept the directory of one completed declared validation run."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_directory", type=Path)
    arguments = parser.parse_args()
    if not arguments.run_directory.is_dir():
        parser.error("run_directory must be an existing directory")
    return check_run(arguments.run_directory)


if __name__ == "__main__":
    raise SystemExit(main())
