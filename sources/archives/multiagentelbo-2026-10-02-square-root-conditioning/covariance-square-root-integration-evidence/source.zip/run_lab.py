"""Primary click-to-run entry point. Choose PROFILE and edit its file in experiments/."""
from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

# Choose a profile from experiments/README.md, such as "neighborhood", "finite", or "rg_v2/base".
# Edit its RUN, THEORY, NUMERICS, OUTPUT and any declared COMPUTE/SOURCE dictionaries.
# "neighborhood" and "rg_v2/neighborhood" share experiments/rg_v2/neighborhood.py.
PROFILE = "neighborhood"


def main() -> dict:
    """Select the runtime first, then run only the selected experiment profile."""
    from multiagent_elbo.lab.launcher import launch
    return launch(PROFILE)


if __name__ == "__main__":
    main()
