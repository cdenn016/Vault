# Covariance diagnostic: one retained fine-grid path

October 2, 2026. This diagnostic follows the failed continuous-parent budget study published in code PR111 and Research PR64. The preceding goal turn made progress by preserving and publishing the failure. The unresolved question here is the numerical operation at which a recorded conditional covariance leaves its observation fiber; this is a new discriminating diagnostic, not a retry of the study or an attempt to replace its failed record.

## Frozen inputs and scope

Replay only the Gaussian candidate on the archived N1024-path001 fine grid, from continuous-budget-evidence. Its saved native configurations and source assignments fix the observations and assignment changes. Use the identical archived activation, model seed 20261002, K=2, independent GL+(2,R) cycle/stride-17 links with scale0.2, tau0.5, mobility equal to activation covariance, block size16, and recorded step lengths. The production forecast, endpoint observation, and uncut sequential source updates remain unchanged. Initial conditioning uses the actual saved initial block observation. The default run_lab profile remains neighborhood.

The original native path is not resampled. Budget probes are omitted because they copy their candidate inputs and never update the main candidate; their random tape does not enter forecast or conditioning. Replayed main-message means must agree with the saved path through each completed interval at absolute tolerance1e-8. Failure of that comparison stops the diagnostic and invalidates its claimed reproduction. There is no replacement sixteen-path sample or population estimate.

## Recorded discriminator

At each observation and every receiver-level source update, measure maximum absolute entry of P Sigma, where P is the same arithmetic block mean map. Stop at the first observed crossing of the original1e-8 diagnostic tolerance, at a production exception, or at a saved-mean mismatch. Save the operation's incoming and outgoing mean/covariance when available, native endpoint, assignment, time, interval, receiver, copied activation, executed source, and full exception. No projection, jitter, eigenvalue clipping, tolerance change, or source cutoff is introduced.

This locates the first measured fiber-threshold crossing on this replay; it does not automatically locate the first loss of positive definiteness. Analyze the captured pre/post matrices separately: retained covariance, scale and symmetry, an independent-coordinate principal covariance on the hidden fiber, and the receiver's local covariance and cubature weights. Full covariance factorizations are reserved for the captured matrices, not performed at every receiver. A relation to the original terminal Cholesky failure remains unproved unless the evidence establishes it; that failing worker's path index was not retained.

The diagnostic is one CPU float64 process, sequential MKL, one numeric thread, using C:/anaconda/python.exe with isolated mode. It is a large-network scientific script, not a unit test. No GPU is needed. There is no automatic retry. Retain either observed failure, mismatch, exception, or absence of reproduction as its actual outcome.

## Continuity and next decision

Sources are DIRECTION, current STATUS, continuous-budget-RESULTS and numerical-failure notes, source-adapted-filter-construction equations5–6, gaussian_message.py, source_gaussian.py, and the live Research Chapter11 regular-filter/O1 definitions at lines1288–1346. The existing cubature argument preserves positive covariance in exact real arithmetic under its positive-weight assumptions; that is distinct from this floating-point implementation. Current code stores an ambient singular covariance and uses subtractive conditioning and rank updates.

A repair is chosen only after the captured operation and local numerical conditioning are understood. Small cases may then validate an algebraically equivalent stable implementation; they cannot establish large-N study acceptance. The failed run, unrun full-result check, global convergence limitation, and open O1/O4 obligations remain unchanged.
