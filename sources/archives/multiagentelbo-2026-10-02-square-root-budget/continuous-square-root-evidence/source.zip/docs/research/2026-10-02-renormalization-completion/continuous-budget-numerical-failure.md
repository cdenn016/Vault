# Continuous-parent covariance-fiber acceptance concern

October 2, 2026. The study `artifacts/gaussian-continuous-budget/20261003T014438208393Z` **failed**: exec session 74098 exited 1, and metadata records `failed` after 2234.7927338000154 seconds. All 16 N512 paths completed; only nine N1024 paths were archived (indices 0 through 7 and 9), giving 25 NPZ files. The original result checker and accounting were not executed: the checker requires a completed passing run. No threshold was changed, fix applied, or run repeated.

The captured `study.log` traceback reaches [continuous_budget.py:112](../../../src/multiagent_elbo/realizations/gaussian/continuous_budget.py:112), then [gaussian_message.py:77](../../../src/multiagent_elbo/realizations/gaussian/gaussian_message.py:77): Cholesky of the projected forecast covariance failed because leading minor 72 was not positive definite. The failing future's path index and covariance state were not logged. This failure cannot be causally linked to the earlier path001 residual from the saved evidence.

## Confirmed retained evidence

The preterminal inspection found that `N1024-path001.npz` stores `fine_covariance_projection_max_error = 1.8708315162637573e-07`, approximately 18.7 times the checker's absolute limit of `1e-8`. Its fine mean-fiber residual is `3.677613769070831e-16`; its coarse covariance-fiber residual is `1.7061954063132823e-16`. Thus accurate retained means do not establish the covariance constraint.

The diagnostic at [continuous_budget.py:100](../../../src/multiagent_elbo/realizations/gaussian/continuous_budget.py:100) takes the maximum absolute entry of P Sigma over integration left endpoints, where P computes arithmetic block means. For a Gaussian message supported on the observed fiber, the mathematical invariant is P Sigma=0. The gate at `artifacts/continuous-parent-budget-20261002/check_results.py:147` requires this recorded maximum to lie in [0,1e-8]. It is a covariance support check, not an eigenvalue check. The producer checks finite outputs and required scalar fields before marking completion; it does not enforce this acceptance threshold. Producer completion and independent numerical rejection are therefore compatible.

The archived `source.zip` copies of `gaussian_message.py`, `source_gaussian.py`, and `continuous_budget.py` were byte-equal to the inspected working files. The example has two visible changes, at 0.02158746202387166 and 0.3312671829805429. Its smallest fine interval is 0.0018500379761283402; the retained mesh does not exhibit an almost-zero event interval.

## Reachable mechanism, not established cause

[Endpoint conditioning](../../../src/multiagent_elbo/realizations/gaussian/gaussian_message.py:86) subtracts G cross^T from the forecast covariance and symmetrizes. This subtraction can introduce floating-point cancellation error. The [source update](../../../src/multiagent_elbo/realizations/gaussian/source_gaussian.py:65) uses a principal covariance C=Sigma[I,I], computes G=Sigma[:,I] C^(-1), and applies

$$
\Sigma^+=\Sigma+G(C_a-C)G^T.
$$

For symmetric input covariance, writing E=P Sigma gives the exact algebraic identity

$$
E^+=E+E[:,I]C^{-1}(C_a-C)C^{-1}\Sigma[I,:].
$$

Hence exact zero remains zero, but a small existing residual can be amplified by poorly conditioned local solves or large gains. The uncut visible-change update composes 1,024 receiver updates in this case, using full ambient covariances without an exact hidden-coordinate representation. Cholesky success for local matrices establishes neither good conditioning nor positivity of the complete hidden covariance. These observations identify a possible numerical mechanism; they do not identify the operation responsible for this saved residual.

Source-budget probes copy their Gaussian inputs, and the main residual is measured before those probes. They do not assimilate their hypothetical prefixes into the main message.

## Missing evidence and next action

The retained arrays contain fine states, means, assignments, and a scalar covariance-residual maximum. They contain no covariance history, maximizing time or receiver, intermediate residuals, local condition numbers, weight concentration, covariance scale, or hidden eigenvalues. They cannot distinguish observation cancellation from source-update amplification, assess relative error, or quantify resulting score bias.

Preserve both the terminal execution failure and the separate observed threshold violation. The incomplete run cannot receive a passing result-check or accounting report. Raw data and logs are being archived by the parent task. Locating the cause requires a separately declared diagnostic calculation retaining the failing path identity and covariance state; none was performed here.
