# Frozen continuous-parent budget measurement

October 2, 2026. This is the next measurement under the resumed autonomous fixed-c_* goal. It follows the completed scheduled source-adapted comparison, whose saved scores cannot evaluate the continuous budget. This contract is written before the new study. No result is asserted here.

## Target and existing construction

The target is the right side of equation (2) in [continuous-parent-error-budget](continuous-parent-error-budget.md), evaluated along the native law and the Gaussian-message candidate in [continuous-gaussian-parent-admission](continuous-gaussian-parent-admission.md). The current calculation approximates that continuous target using two coupled numerical meshes. It does not compute the retained-path KL, certify a confidence upper bound, or close O1. The regular-filter and two-horizon requirements in live Chapter 11 remain unchanged. O4 recursive formation is a separate open obligation.

Source continuity includes docs/DIRECTION.md, the current STATUS and completion obligations; Research SPEC section 0; live c11_network_coarsegraining.tex, def:rg-regular-finite-filter and open:rg-pointwise-parent-dynamics; c13_formation.tex, def:rg-formation-kinetics and def:rg-formation-cycle-experiment; the Research project page and PIFB2 section 9. The existing fixed-c_* gate, source-prior locality, and sender-inclusive joint dynamics are retained. No base transport, theory manuscript edit, or historical exact-arithmetic heavy node is involved.

## Frozen native law and initialization

For each of N=512 and 1,024, use the existing independent GL+(2,R) cycle/stride-17 model at seed 20261002 and link scale 0.2. Load mu, Sigma, pi and Theta from evidence/activation/N{N}-learn_both-final.npz. Freeze all four and the comparison model at tau=0.5; no supplied learning schedule or relearning is used. The activation draw is X_0 distributed as the product Gaussian with those node means/covariances, independently of J_0 drawn from the product pi rows. This declared independence is part of the activation law, not a statement about an evolved native posterior.

The native continuous target is dX=-M grad U_J(X) dt+sqrt(2M)dW with M=blockdiag(Sigma_i), including every incident sender record. A rate-one Poisson proposal clock redraws the entire assignment from the native pointwise product rows. The frozen covariance is Q=2M, not the manuscript's separate identity-mobility Q=2T I convention. Arithmetic means of blocks of sixteen nodes define P. They are an invertible rescaling of the corresponding orthonormal retained coordinates.

Initialize the candidate with the exact Gaussian conditional on the realized PX_0. Propagate and condition its full Gaussian without resets. At an actual visible change of J, apply the existing uncut sequential source update with ascending receiver order, positive common cubature and retained regression residual covariance. A self-proposal does not assimilate a source observation. The candidate deliberately omits native survival filtering; the budget measures its predictive consequences. Full hidden covariance remains quadratic storage, not a reduced-cost claim.

## Numerical paths and probes

Each independent path has one exact sampled Poisson proposal-time tape over horizon 1. Coarse and fine configuration meshes have maximum steps 1/64 and 1/128, respectively, and both include those proposal times. The fine Brownian increments are summed exactly for coarse intervals. Both levels share activation, proposal times, proposal source uniforms, budget-probe times and probe source uniforms. Assignment labels may differ between grids because their states differ. Every native Euler step must satisfy the precomputed all-assignment curvature bound on the largest permitted step. No result-dependent step adaptation is used.

The message uses the existing affine Euler Gaussian forecast and exact endpoint block observation. [continuous-budget-discretization](continuous-budget-discretization.md) supplies the local correlated-noise gain and Riccati coefficient match. This does not establish finite-horizon convergence. In particular, the numerical mesh subdivides at self-proposals as well as visible changes; those extra subdivisions can affect a finite-grid message even though no self-label is assimilated. The continuous candidate ignores invisible proposal times. Disappearance of this mesh effect, convergence of the likelihood functional and uniform error estimates are not proved by a local expansion or by two meshes. The reported arrays describe the actual approximation used.

At each left endpoint, record the actual drift rate

$$
a_t=\frac12\lVert P v_{J_t}(X_t)-P v_{J_t}(\mu_t)\rVert_{(PQP^T)^{-1}}^2.
$$

Its grid integral is the exact left-rectangle integral of that piecewise-constant recorded rate. Two independent uniform times on [0,1] select left endpoints from the already fixed simulation mesh; probes do not alter the mesh or the native path. At a selected state, draw a native product assignment solely to supply prefixes. At receiver i, compute the full categorical KL between the native row and the candidate row conditioned on that sampled prefix, then update the hypothetical Gaussian with the sampled label. The sum is a nonnegative unbiased estimator of the full mark KL, conditional on that recorded state and message. It never changes the real message.

A second uncut sequential pass evaluates the probability of the current complete assignment J. Subtract the exact self term psi(b_J,hat b_J)=b_J log(b_J/hat b_J)-b_J+hat b_J. Thus the expectation of the corrected probe is the visible-intensity divergence, including the survival compensation; the realized corrected estimate may be negative and is never clipped. The full-mark replacement is also retained as a larger expectation. Uniform-time averaging gives unbiased quadrature of each grid path's piecewise-constant jump cost, conditional on that path. Numerical integration error relative to the continuous process is a different quantity.

For each path retain drift_integral, mark_integral, self_integral, visible_integral, total_integral=drift+visible, and augmented_integral=drift+mark. Keep the probe native/candidate rows, sampled prefixes, self probabilities, per-step drift rates, native configurations, candidate means, assignments, meshes and shared stochastic tape. These permit independent reconstruction of reported finite-grid costs without treating aggregate summaries as evidence of a continuous bound.

## Sampling, execution and interpretation

The standalone profile experiments/gaussian_continuous_budget.py declares sixteen independent paths per size and one generated model realization per size. Path seed is 20261007+100000*size_index+10*path_index; offsets zero through five select activation, clock, Brownian, proposal-label, probe-time and probe-label generators. There are four spawned workers and one parent, CPU float64 with sequential MKL and one numerical thread per worker. The CUDA-capable Anaconda installation is used, but no GPU operations run. The existing run_lab.py remains on its intentional neighborhood profile.

Report path means, empirical path standard errors and paired fine-minus-coarse differences. Variability includes both native-path and probe sampling. Sixteen paths and one model per size are descriptive, especially for rare trajectories. The standard error is not a rigorous confidence bound and does not establish generality across link/model realizations. Step refinement diagnoses sensitivity; finite agreement does not prove convergence, small asymptotic error or the required long-horizon regimes. A large cost only assesses this budget/candidate/regime, not all admitted parents.

Save a fresh source/input snapshot before computation, per-path outputs as jobs finish, machine-readable metadata, stdout and any failure. Source hashes are diagnostic metadata. A failed path is retained and diagnosed; the runner has no automatic retry or resume. The source/source-budget tiny checks and worker transport check are the preflight. Small networks appear only in these validation checks; the study sizes are 512 and 1,024. No passing predecessor study or test is rerun for publication.
