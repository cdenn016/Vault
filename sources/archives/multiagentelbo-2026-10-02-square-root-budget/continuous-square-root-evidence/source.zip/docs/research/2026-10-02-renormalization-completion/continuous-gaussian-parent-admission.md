# A continuous Gaussian-message parent in the regular filter class

October 2, 2026. This is an analytical construction at fixed c_* with frozen structural coefficients. It defines a related continuous-time candidate; it does not identify the running finite-grid replay with that candidate or establish accuracy against the native law. No code, simulation, test, GPU work, or Vault edit is part of this record.

The sources reread are live Chapter 11, def:rg-regular-finite-filter and open:rg-pointwise-parent-dynamics (c11_network_coarsegraining.tex, lines 1288-1346); Chapter 13, def:rg-formation-kinetics and def:rg-formation-cycle-experiment; SPEC section 0; [trajectory-construction.md](trajectory-construction.md), section 8; and [source-adapted-filter-construction.md](source-adapted-filter-construction.md), including its uncut cubature update and same-assignment convention. Chapter 13 uses diffusion covariance 2T I, whereas the prototype's frozen generator uses 2M. The construction keeps the diffusion covariance explicit.

## Statement, joint model and initialization

For every fixed finite d, finite assignment set J=product_i S_i, full-row-rank P:R^d to R^a, positive-definite constant diffusion covariance Q, and finite frozen affine sheet drifts F_jx+f_j, the construction below defines a nonexplosive time-homogeneous Markov parent on a retained configuration r, assignment j, and Gaussian message (m,S). It has a regular filter of dimension k+k(k+1)/2, k=d-a. This dimension is independent of horizon and, for a fixed-dimensional parameterized family, epsilon. Positivity and bounds below are at each positive epsilon; uniform approximation constants are not claimed.

The supplied native comparison law is constructed from its actual Gaussian activation X_0~N(mu_0,Sigma_0), Sigma_0 positive definite, independent J_0~b_0; a Brownian motion; and an independent rate-one Poisson proposal clock. Between proposals,

$$
dX_t=(F_{J_t}X_t+f_{J_t})dt+Q^{1/2}dW_t.
\tag{1}
$$

At a proposal its complete assignment is drawn from b(j'|x)=product_i beta_{i,j'_i}(x), with the positive normalized quadratic-softmax rows of the preceding construction, and X does not jump. These normalized kernels and independent noise specify the joint path law; paths use the usual continuous-coordinate and finite-label measurable path spaces. This includes the frozen prototype with F_jx+f_j=-Mg_j(x), Q=2M, and the identity-mobility manuscript case with Q=2T I and its own sheet force. Their temperatures and drifts must not be interchanged.

Freeze P, all structural coefficients, receiver order and cubature conventions. Set T=P^T(PP^T)^{-1}, and choose fixed orthonormal columns Z spanning ker P. Thus X=Tr+Zz, with z in R^k. The common hidden base measure is dz, not ambient Lebesgue measure on a moving affine fiber. The candidate decoded conditional density is q(z)=phi_S(z-m); it is not asserted to equal the native posterior.

Draw the parent's (R_0,J_0) from the exact pushforward activation. Initialize

$$
\mu^c(r)=\mu_0+\Sigma_0P^T(P\Sigma_0P^T)^{-1}(r-P\mu_0),
$$

$$
m_0(r)=Z^T\mu^c(r),\qquad
S_0=Z^T[\Sigma_0-\Sigma_0P^T(P\Sigma_0P^T)^{-1}P\Sigma_0]Z.
\tag{2}
$$

This is the actual Gaussian conditional, and S_0 is positive definite for k>0. Independence of J_0 is a supplied activation assumption, not a general claim about recognition laws. For a different activation, (2) cannot be substituted without an approximation or a new exact conditional. If k=0 the message is absent.

## Continuous propagation, including correlated noise

On sheet j define

$$
A_j=PF_jT,\quad C_j=PF_jZ,\quad E_j=Z^TF_jT,\quad D_j=Z^TF_jZ,
\qquad u_j=Pf_j,\quad v_j=Z^Tf_j,
$$

$$
Q_r=PQP^T,\qquad Q_z=Z^TQZ,\qquad Q_{zr}=Z^TQP^T.
$$

The transformed native observed and hidden noises have cross covariance Q_zr dt. It generally does not vanish. Define

$$
K_j(S)=(SC_j^T+Q_{zr})Q_r^{-1},
$$

$$
\mathcal V_j(S)=D_jS+SD_j^T+Q_z
 -(SC_j^T+Q_{zr})Q_r^{-1}(C_jS+Q_{zr}^T).
\tag{3}
$$

With one a-dimensional Brownian motion B and L_r L_r^T=Q_r, define the parent between assignment changes by

$$
dR=(A_jR+C_jm+u_j)dt+L_r dB,
$$

$$
dm=(E_jR+D_jm+v_j)dt
 +K_j(S)[dR-(A_jR+C_jm+u_j)dt],
\qquad dS=\mathcal V_j(S)dt.
\tag{4}
$$

These are the correlated-noise Kalman-Bucy propagation coefficients, used here as the definition of a candidate. The covariance calculation is explicit: for a linear Gaussian reference on a fixed sheet, the hidden-error/observation-increment cross covariance is (SC_j^T+Q_zr)dt, whereas observation-increment covariance is Q_r dt to first order. Removing this correlated innovation gives (3). Equivalently, the error noise is dV_z-KdV_r, and expanding its covariance together with drift D_j-KC_j gives exactly (3). The term Q_zr cannot be dropped. This calculation does not condition on the absence of assignment changes; that omitted native information is discussed below.

All coefficients in (4) are smooth on R^a x R^k x SPD_k, hence locally Lipschitz. There is no time argument or supplied schedule. In explicit SDE form the same Brownian motion drives R and m, with diffusion matrix [L_r; K_j(S)L_r]; replacing it by independent noises changes the candidate law.

## Source jumps and normalization

Use the uncut sequential source decoder of the preceding construction. For completeness, at each receiver prefix with message N(m,S), choose the fixed local hidden basis V needed by all that receiver's logits, put C=V^TSV and y_l=V^Tm+chol(C)xi_l, and use common positive moment-exact cubature weights lambda_l for every label. Then

$$
c_i(a)=\sum_l\lambda_l\beta_{i,a}(y_l;R),
\qquad
\widehat b(j'|R,m,S)=\prod_i c_i(j'_i|j'_{<i}).
\tag{5}
$$

Every c_i is positive and sums to one; repeated summation proves widehat b sums to one. After each hypothetical prefix label, use weights w_l=lambda_l beta_i,a(y_l;R)/c_i(a), their mean bar y and covariance C_a, and the Gaussian update

$$
G=SV C^{-1},\qquad
m^+=m+G(\bar y-V^Tm),\qquad
S^+=S-GCG^T+GC_aG^T.
\tag{6}
$$

A receiver with no hidden-dependent logits requires no update. With the symmetric spanning 2r-node rule and strictly positive likelihoods, C_a is positive definite. Equation (6) is positive definite because a vector annihilating both positive-semidefinite summands would also annihilate the original positive-definite S. Finite composition over receivers therefore defines a smooth Gaussian map U_{j'}(R,m,S). Local bases, supports and receiver order are fixed, and no cutoff or discontinuous merge is used.

At an independent rate-one proposal, draw j' from (5). If j' differs from the current j, keep R fixed, replace (m,S) by U_j', and change the sheet to j'. If j'=j, change nothing, including the message. This is the declared same-assignment approximation: a self-refresh is not assimilated as a hidden observation. It makes unobserved self-proposal times irrelevant to the retained-history functional.

The jump contribution to the parent's generator is

$$
\sum_{j'\ne j}\widehat b(j'|R,m,S)
 [f(R,U_{j'}(R,m,S),j')-f(R,m,S,j)].
\tag{7}
$$

Its total visible rate is 1-widehat b(j|R,m,S)<=1. Normalized marks and a rate-one clock, together with (4), specify a normalized path law. The maps for changed labels are smooth in their continuous native inputs; the self-map is the identity. Assignment values are separate strata as required by Chapter 11.

## Positive covariance, existence and retained-history dependence

Write V_j=C_j^TQ_r^{-1}C_j, Dtilde_j=D_j-Q_zr Q_r^{-1}C_j, and Qtilde=Q_z-Q_zr Q_r^{-1}Q_zr^T. The transformed full noise covariance is positive definite, so its Schur complement Qtilde is positive definite. Equation (3) becomes

$$
\dot S=\widetilde D_jS+S\widetilde D_j^T+\widetilde Q-SV_jS.
\tag{8}
$$

While S is positive definite, its trace satisfies

$$
\frac{d}{dt}\operatorname{tr}S
\leq 2\|\widetilde D_j\|\operatorname{tr}S
     +\operatorname{tr}\widetilde Q.
$$

For H=S^{-1}, direct differentiation gives
dot H=-H Dtilde_j-Dtilde_j^T H-H Qtilde H+V_j, hence

$$
\frac{d}{dt}\operatorname{tr}H
\leq2\|\widetilde D_j\|\operatorname{tr}H+\operatorname{tr}V_j.
\tag{9}
$$

Integrating these scalar inequalities gives finite upper bounds for S and its inverse on every finite sheet interval. A solution cannot leave SPD_k through an eigenvalue tending to zero or infinity without violating one bound. The smooth ODE therefore extends through each such interval. No stability or detectability assumption is needed for this finite-horizon claim.

Between proposals, S is consequently a bounded deterministic Riccati solution conditional on its initial state and sheet. The joint (R,m) equation is linear with bounded time-dependent coefficients and additive Brownian forcing on that interval; its variation-of-constants formula gives a unique finite continuous solution. Each jump map sends a finite state to a finite state with positive covariance. A rate-one Poisson clock has finitely many proposals on each finite horizon almost surely. Concatenating these finitely many solutions constructs the unique nonexplosive parent. Constants may depend on the realized number of jumps and on epsilon; this is not a uniform accuracy or moment estimate.

The filter contains no private simulation tape once (R,J) is known. Between visible jumps, K_j(S) is differentiable and has finite variation. Thus

$$
\int_s^tK_j(S_u)dR_u
=K_j(S_t)R_t-K_j(S_s)R_s
 -\int_s^t\frac{dK_j(S_u)}{du}R_udu.
\tag{10}
$$

In (10) the final integral uses ordinary integration; no stochastic term is hidden there. Substituting into (4) yields a deterministic linear integral equation for m driven by the continuous retained path R. Initialization is (2), and every visible jump applies the known smooth U_j'. Self-proposals change no state. Therefore (m_t,S_t) is a deterministic functional of the retained history, without needing proposal times or a Brownian tape.

The Gaussian decoder is continuously Frechet differentiable into L1(dz): its mean and covariance derivatives are degree-at-most-two polynomials times its density. On compact parameter neighborhoods, positive lower/upper covariance eigenvalue bounds and bounded means give a common integrable Gaussian envelope for these derivatives. Dominated convergence gives continuity of the derivative. Together with (2), (4), (6), and nonexplosion, this checks the stated regular-filter conditions for this candidate. Admission is a statement about the candidate's structure, not equality to a native posterior.

## Missing native information and final scope

Native lack of a visible assignment change is informative. On sheet j the native visible exit rate is lambda_j(x)=1-b(j|x), not one, because self-proposals are invisible. A short no-change interval weights a hidden density by 1-lambda_j(x)dt, whose normalization gives the first-order correction

$$
-[\lambda_j-\nu(\lambda_j)]\nudt
=[b(j|\cdot)-\nu(b(j|\cdot))]\nudt.
\tag{11}
$$

Equation (4) omits this survival term. For example, its omitted conditional-mean contribution is Cov_nu(z,b(j|X))dt. At an observed change, the exact native posterior is tilted by b(j'|X), whereas (5)-(6) use cubature and Gaussian projection. These are explicit approximation errors, not facts erased by continuous-time admission.

Both this construction and the running replay carry a full hidden Gaussian covariance. The distinction is the frozen continuous-time candidate versus the scheduled finite-grid replay with a prefix cutoff. This construction has no cutoff, moving schedule, learned structural coordinates, or claimed discretization limit. Even at zero cutoff, convergence of the grid implementation requires a separate consistency/tightness argument covering its propagation and projection choices. None is supplied here.

The strongest result is existence of an autonomous, nonexplosive parent with a deterministic retained-history Gaussian message satisfying the specified regular-filter conditions for frozen coefficients and fixed P. For the manuscript's identity-mobility subclass use its Q=2T I and sheet drift, without importing prototype scaling. The remaining obligation is an actual-law path-error bound, including survival and jump-projection errors, on the specified epsilon-dependent windows, followed by the separately required endogenous structural feedback. Membership in the candidate class alone does not resolve O1 or recursive formation.
