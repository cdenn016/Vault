# Continuous parent error budget for the frozen Gaussian-message candidate

October 2, 2026. Final bounded analytical continuation of this parent round. The result concerns exactly the autonomous candidate in [continuous-gaussian-parent-admission](continuous-gaussian-parent-admission.md). It is not a bound for the running scheduled finite-grid replay. No code, experiment, GPU calculation, or Vault edit was performed.

## Target and the two laws

Fix finite d and assignment set A, a fixed full-row-rank P:R^d -> R^a, constant Q>0, and frozen affine sheet drifts v_j(x)=F_jx+f_j. The native law uses dX=v_J(X)dt+Q^(1/2)dW and a rate-one proposal clock with strictly positive normalized marks b(j'|x)=product_i beta_i,j'_i(x). Only changes j'!=j are visible; X stays continuous. Its visible intensities are lambda_j'(x,j)=b(j'|x) for j'!=j, with total 1-b(j|x).

The candidate retains (R,J), R=PX, and the deterministic retained-history Gaussian message eta=(m,S) defined in the admission record. Its visible intensities are hat lambda_j'=hat b(j'|R,m,S), its Gaussian-message jump map is U_j', and its retained drift is

$$
\bar v_j(R,m)=A_jR+C_jm+u_j,
\qquad A_j=PF_jT,\ C_j=PF_jZ,\ u_j=Pf_j,
\tag{1}
$$

where T=P^T(PP^T)^(-1) and Z spans ker P orthonormally. Its diffusion covariance is Q_r=PQP^T, and its message follows the correlated-noise propagation in that record. Self-proposals change nothing, including eta.

Both native and comparison fine laws start from the same actual activation X_0~N(mu_0,Sigma_0), independent J_0~b_0, and the message initialization in the admission record. In particular their retained initial laws agree. A different initialization adds an initial divergence; Gaussian moment matching alone does not eliminate it.

The user-supplied scope is fixed c_*, joint switching dynamics, retained assignments, and the continuous regular-filter problem in live c11_network_coarsegraining.tex, def:rg-regular-finite-filter and open:rg-pointwise-parent-dynamics. Introduced comparison choices are frozen coefficients, this fixed P, this admitted candidate, and the auxiliary fine lift below. They do not solve the universal problem over all members, assignment-dependent projections, or learned structural feedback. Sources also include trajectory-construction.md section 8 and the source sections fully identified in the admission record. Time is the dynamics parameter, not Fisher duration.

For every finite T_end, the theorem is

$$
\boxed{
D(\mathbb P_{R,J}^{[0,T_{\rm end}]}\Vert
\mathbb S_{R,J}^{[0,T_{\rm end}]})
\leq
\mathbb E_{\mathbb P}\int_0^{T_{\rm end}}
\left\{
\frac12\|Pv_{J_t}(X_t)-\bar v_{J_t}(R_t,m_t)\|_{Q_r^{-1}}^2
+\sum_{j'\ne J_t}
\left[
b_{j'}\log\frac{b_{j'}}{\widehat b_{j'}}
-b_{j'}+\widehat b_{j'}
\right]\right\}dt.
}
\tag{2}
$$

Here b_j'=b(j'|X_t), hat b_j'=hat b(j'|R_t,m_t,S_t), and eta_t is the candidate message driven by the actual retained history. The sum and integral take values in [0,infinity]; finite expectation is not assumed or inferred from nonexplosion. Equation (2) is informative only when its right side is controlled. It bounds joint path law, not only one-time marginals.

## A fine comparison whose retained marginal is the candidate

Define L=QP^T Q_r^(-1), so PL=I, and an auxiliary fine drift

$$
\widehat v_j(x,\eta)
=v_j(x)+L[\bar v_j(Px,m)-Pv_j(x)].
\tag{3}
$$

Keep noise covariance Q. Use visible assignment rates hat b(j'|Px,m,S), leave X unchanged at jumps, and update eta by the same deterministic retained-history rule. This fine coordinate is a comparison device, not additional retained parent state. Since P hat v=bar v, its (R,J,eta) marginal is exactly the admitted candidate: the R noise is PQ^(1/2)dW, and the same noise drives m through K_j(S)dR. Replacing that shared noise by independent noise would destroy this identification.

Both extended native and comparison laws exist and are nonexplosive. The native X has globally linear-growth affine sheet drift, finite sheets and rate at most one. In both laws S follows the same Riccati ODE between jumps; the trace bounds for S and S^(-1) in the admission record prevent boundary escape on any finite sheet interval. Write E_j=Z^TF_jT, D_j=Z^TF_jZ, v_j^z=Z^Tf_j, and K_j(S)=(SC_j^T+Z^TQP^T)Q_r^(-1). Under native observations, its message equation is

$$
dm=(E_jR+D_jm+v_j^{z})dt+
K_j(S)[dR-\bar v_j(R,m)dt].
\tag{4}
$$

With S bounded on that interval, the joint (X,m) system is linear with bounded time-dependent coefficients and additive Brownian noise. The comparison law has the same property using (3). Every visible jump applies a finite smooth SPD-preserving map. A rate-one proposal clock produces finitely many proposals on a finite horizon. Concatenating the unique interval solutions therefore constructs both extended laws, with no explosion or finite-time loss of positive covariance. The same argument provides uniqueness in law, including after stopping. No stability, invariant-distribution, or uniform moment claim is needed.

The drift change in m in (4) is precisely K_j(S)P(hat v-v). It lies in the range of the same joint diffusion as the change in X. Thus applying a Brownian change of drift to X also changes the message correctly; no independent artificial message forcing is being hidden.

The minimum-Q-metric lift (3) has energy

$$
\theta_t=Q^{-1/2}[v_{J_t}(X_t)-\widehat v_{J_t}(X_t,\eta_t)],
\qquad
|\theta_t|^2=
\|Pv_{J_t}(X_t)-\bar v_{J_t}(R_t,m_t)\|_{Q_r^{-1}}^2.
\tag{5}
$$

In hidden coordinates x=TR+Zz, the discrepancy is simply C_j(z-m). The message covariance affects future m and jump rates, but is not substituted for this actual hidden-state mismatch.

## Stopped likelihood, without global Novikov assumptions

The stopped law records both its stopping time and the stopped extended trajectory. Let tau_n be the first exit of the extended state from
||X||+||m||+tr S+tr S^(-1)<n, or its nth visible jump, capped at T_end. Use nested such sets and set tau_n=0 for an initial state outside the set. Before tau_n, drift discrepancy is bounded, and every active native/candidate jump rate has a positive lower bound on the compact state set. Both are continuous and strictly positive on each of finitely many strata. Their ratios and logarithms are consequently bounded. These bounds depend on n and the fixed model.

Under the stopped comparison law let W_hat be its driving Brownian motion and N_j' the visible counting process for transitions into j'. The candidate intensity is hat lambda_j'; when j'=J both intensities are zero and that inactive term is omitted. Put rho_j'=lambda_j'/hat lambda_j' on active channels. The local likelihood is

$$
\log Z_n=
\int_0^{\tau_n}\theta_t^T d\widehat W_t
-\frac12\int_0^{\tau_n}|\theta_t|^2dt
+\sum_{t\leq\tau_n:\Delta J_t\ne0}
\log\frac{\lambda_{J_t}(t)}{\widehat\lambda_{J_t}(t)}
-\int_0^{\tau_n}\sum_{j'\ne J_{t-}}
(\lambda_{j'}-\widehat\lambda_{j'})dt.
\tag{6}
$$

Jump intensities in the sum are evaluated from the pre-jump state with target J_t. The last integral is essential: it is the ratio of survival probabilities between jumps.

For clarity, the stopped likelihood's martingale property does not rely on a global exponential-moment assertion. The exponential in (6) solves

$$
dZ=Z_-\theta^Td\widehat W+
Z_-\sum_{j'}(\rho_{j'}-1)
(dN_{j'}-\widehat\lambda_{j'}dt)
\tag{7}
$$

until tau_n and is constant thereafter. Apply the square formula, first stopping when Z becomes large. Its expected square has drift
E[Z_-^2(|theta|^2+sum hat lambda (rho-1)^2)], bounded by c_n E Z_-^2. Integration gives E Z_stopped^2<=exp(c_n T_end). Letting the additional likelihood stop tend to infinity gives a uniformly integrable martingale with mean one. This elementary bounded-coefficient argument supplies a probability change of measure.

Multiplying (7) by Brownian and compensated counting test martingales and taking quadratic covariations shows that under the weighted law the continuous drift changes by Q^(1/2)theta and each visible intensity by rho hat lambda=lambda. The message changes consistently by (4), while jump destinations/maps stay identical. Thus the weighted law solves the stopped native equations; uniqueness identifies it with the stopped native law. This verifies (6) as its density relative to the stopped comparison, rather than assuming a global change-of-measure theorem.

Under that native law dW_hat=dW_native+theta dt before the stop. The continuous stochastic integral has mean zero after this substitution, and the compensated visible jump sums have mean zero. Taking the expectation of (6) therefore gives

$$
D(\mathbb P^{\tau_n}\Vert\widehat{\mathbb P}^{\tau_n})
=
\mathbb E_{\mathbb P}\int_0^{\tau_n}
\left[
\frac12|\theta_t|^2+
\sum_{j'\ne J_t}
\left(\lambda_{j'}\log\frac{\lambda_{j'}}{\widehat\lambda_{j'}}
-\lambda_{j'}+\widehat\lambda_{j'}\right)
\right]dt.
\tag{8}
$$

Each jump summand is nonnegative because u log(u/v)-u+v>=0 for u,v>0. The stopped initial laws coincide even on tau_n=0.

Nonexplosion and finitely many jumps imply tau_n increases to T_end and the stopped path equals the full path eventually on each realized finite-horizon trajectory. Under either law, the stopped/full path distributions therefore converge in total variation by coupling, with discrepancy at most Pr(tau_n<T_end).

Relative entropy is lower semicontinuous under this convergence. One direct justification is
D(P||Q)=sup_f{E_P f-log E_Q exp(f)} over bounded measurable f: Jensen gives the upper inequality for each f, and truncated log density ratios recover the supremum, with a Q-null positive-P event handling singularity. Each bounded-f expression is continuous under total-variation convergence, so its supremum is lower semicontinuous. Applying this to (8), then monotone convergence to its nonnegative integrand, bounds the full extended divergence by the right side of (2). Finally discard X and eta: factoring the extended density ratio into retained and conditional ratios makes their conditional KL nonnegative, so retained divergence cannot increase. This proves (2), including the infinite-cost case. Finite right side in particular establishes the needed absolute continuity; finite native moments alone were never used as a substitute for global Novikov.

## Visible jumps, survival, and optional mark bound

The visible survival compensation in (2) equals

$$
-\sum_{j'\ne j}b_{j'}+\sum_{j'\ne j}\widehat b_{j'}
=b(j|x)-\widehat b(j|R,m,S).
\tag{9}
$$

It cannot be dropped, even though proposal clocks both have rate one: visible exit rates are 1-b(j|x) and 1-hat b(j|R,m,S). The admitted message deliberately omits the native no-visible-change filtering correction. Equation (2) charges its predictive consequences through actual drift and visible-rate discrepancies.

Let psi(u,v)=u log(u/v)-u+v. Since b and hat b are normalized over all assignments,

$$
\sum_{j'\ne j}\psi(b_{j'},\widehat b_{j'})
=D(b(\cdot|x)\Vert\widehat b(\cdot|R,m,S))
-\psi(b_j,\widehat b_j)
\leq D(b\Vert\widehat b).
\tag{10}
$$

Thus the full normalized mark KL is a valid, generally larger replacement. For native product marks and the candidate's sequential rows c_i, elementary expansion of the log product gives

$$
D(b\Vert\widehat b)=
\sum_i\mathbb E_{J'_{<i}\sim\prod_{h<i}\beta_h(x)}
D\bigl(\beta_i(x)\Vert
c_i(\cdot|J'_{<i};R,m,S)\bigr).
\tag{11}
$$

This is a mathematical identity; enumerating assignments or prefixes can be exponential. Nothing here asserts that (2) or (11) has been computed. No hidden-posterior projection KL has been substituted for the actual-law expectation.

## Scope and decisive next obligation

For each fixed finite model and positive epsilon, (2) is a checkable actual-law budget for the already admitted frozen parent. It accommodates omission of survival filtering, approximate source cubature, and Gaussian jump projection through their resulting prediction errors. It proves neither smallness nor optimality. With Q=2T I the diffusion term is 1/(4T) times the squared discrepancy in the (PP^T)^(-1) metric; the prototype Q=2M has its own metric. Temperature conventions cannot be exchanged.

O1 requires this or a sharper budget to vanish in the stated regimes. Fixed-window control must be uniform over permitted window placements; full-history control must hold for the entire growing horizon on which expected assignment changes diverge. Restarting at a later window requires matched initial law for that comparison, or its initial divergence; a prefix error cannot simply be discarded. Constants from localization establish existence, not these uniform estimates.

The minimal remaining mathematical obligation is an actual-law bound on the integral in (2), including its survival-aware jump term, that is small in a declared epsilon/horizon regime. A finite simulated average would still require a justified uncertainty bound. The present saved-grid upper-functional estimates do not evaluate this continuous-time integral or prove a discretization limit. Endogenous structural feedback, assignment-dependent retention, and recursive formation remain outside this result.
