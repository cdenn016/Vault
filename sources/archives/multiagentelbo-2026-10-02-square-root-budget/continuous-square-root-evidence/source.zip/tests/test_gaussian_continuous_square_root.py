"""Tiny consumer wiring checks for the hidden-factor budget backend."""
from __future__ import annotations

import pytest
import torch

from test_gaussian_message import _example
from multiagent_elbo.realizations.gaussian import continuous_budget as budget
from multiagent_elbo.realizations.gaussian.gaussian_message import observe_gaussian
from multiagent_elbo.realizations.gaussian.source_square_root import square_root_source_rows


def test_factor_probe_preserves_prefix_self_costs_and_input_states() -> None:
    model, state, _ = _example()
    X = (state.mu+.13)[None]
    observed = X.reshape(1, 2, 2, 2).mean(2).flatten(1)
    message = observe_gaussian(state.mu[None], torch.block_diag(*state.Sigma)[None], observed, 2)
    mu, cov = message["mean"], message["covariance"]
    before_mu, before_cov = mu.clone(), cov.clone()
    current, prefix = torch.tensor([[0, 1, 0, 1]]), torch.tensor([[1, 1, 0, 0]])
    dense = budget.source_budget_probe(X, mu, cov, current, prefix, state, model, 2)
    factor = budget.source_budget_probe(X, mu, cov, current, prefix, state, model, 2, source_backend="square_root")
    for key in dense:
        torch.testing.assert_close(factor[key], dense[key], atol=3e-12, rtol=3e-12)
    torch.testing.assert_close(mu, before_mu, atol=0., rtol=0.)
    torch.testing.assert_close(cov, before_cov, atol=0., rtol=0.)


def test_factor_sampler_reaches_updates_and_probes_without_changing_native_tape(monkeypatch: pytest.MonkeyPatch) -> None:
    model, state, mobility = _example()
    batches: list[int] = []
    def observe_rows(*args: object, **kwargs: object) -> dict[str, torch.Tensor]:
        """Record actual consumer entry while running the real factor implementation."""
        batches.append(args[0].shape[0])
        return square_root_source_rows(*args, **kwargs)
    monkeypatch.setattr(budget, "square_root_source_rows", observe_rows, raising=False)
    dense = budget.sample_frozen_budget(mobility, state, model, 1., 2, 16, 2, 78)
    factor = budget.sample_frozen_budget(mobility, state, model, 1., 2, 16, 2, 78, source_backend="square_root")
    assert {1, 2} <= set(batches)
    for grid in ("coarse", "fine"):
        assert factor[grid+"_visible_changes"] > 0
        for name in ("native", "assignments", "times", "dW"):
            torch.testing.assert_close(factor[grid+"_"+name], dense[grid+"_"+name], atol=0., rtol=0.)
        for name in ("mean", "drift_integral", "mark_integral", "self_integral", "visible_integral"):
            torch.testing.assert_close(factor[grid+"_"+name], dense[grid+"_"+name], atol=1e-10, rtol=1e-10)
        assert factor[grid+"_covariance_projection_max_error"] < 1e-13


def test_unknown_source_backend_is_rejected() -> None:
    model, state, mobility = _example()
    with pytest.raises(ValueError, match="source.backend|backend"):
        budget.sample_frozen_budget(mobility, state, model, .1, 2, 4, 1, 93, source_backend="unknown")
