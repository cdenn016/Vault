"""Deterministic cubature source conditioning on block-mean Gaussian fibers.

These are frame- and receiver-order-dependent assumed-density approximations.
They define normalized source laws, not exact native posterior moments.
"""
from __future__ import annotations

from math import log, sqrt

import torch

from .coupled_learning import CoupledModel, CoupledState, comparison_maps


def _point_rows(
    mu:       torch.Tensor,
    maps:     torch.Tensor,
    state:    CoupledState,
    model:    CoupledModel,
    start:    int,
) -> torch.Tensor:
    r"""Return native log beta rows from start onward using precompiled maps."""
    residual = mu[:, start:, None]-torch.einsum(
        "nsij,bnsj->bnsi", maps[start:], mu[:, model.sources[start:]])
    cost = .5*torch.einsum(
        "bnsi,nij,bnsj->bns", residual, model.H[start:], residual)
    return torch.log_softmax(state.pi[start:].log()-cost/model.tau, -1)


def _source_step(
    mu:         torch.Tensor,
    covariance: torch.Tensor,
    labels:     torch.Tensor,
    maps:       torch.Tensor,
    state:      CoupledState,
    model:      CoupledModel,
    receiver:   int,
    block_size: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    r"""Apply positive local cubature and retain conditional residual covariance."""
    _, n_agents, dimension = mu.shape
    if n_agents % block_size:
        raise ValueError("block size must divide the number of agents")
    nodes = sorted({receiver, *model.sources[receiver].tolist()})
    node_set = set(nodes)
    # A block sum is the only local linear constraint, and is usable only if
    # the complete block belongs to this receiver's full softmax star.
    dropped = {
        (node//block_size+1)*block_size-1 for node in nodes
        if all(other in node_set for other in range(
            node//block_size*block_size, (node//block_size+1)*block_size))
    }
    independent = [node for node in nodes if node not in dropped]
    coordinates = torch.tensor(
        [node*dimension+k for node in independent for k in range(dimension)],
        dtype=torch.long, device=mu.device)
    r = coordinates.numel()
    if r == 0:
        residual = mu[:, receiver, None]-torch.einsum(
            "sij,bsj->bsi", maps[receiver], mu[:, model.sources[receiver]])
        cost = .5*torch.einsum("bsi,ij,bsj->bs", residual, model.H[receiver], residual)
        rows = torch.log_softmax(state.pi[receiver].log()-cost/model.tau, -1)
        return rows, mu.clone(), covariance.clone()

    C = covariance[:, coordinates][:, :, coordinates]       # (B,r,r), SPD
    L = torch.linalg.cholesky(C)
    offsets = sqrt(r)*torch.cat((L.mT, -L.mT), dim=1)        # (B,2r,r)
    local_offsets = offsets.reshape(len(mu), 2*r, len(independent), dimension)
    points = mu[:, None, nodes].expand(-1, 2*r, -1, -1).clone()
    positions = {node: index for index, node in enumerate(nodes)}
    independent_positions = {node: index for index, node in enumerate(independent)}
    for node in independent:
        points[:, :, positions[node]] += local_offsets[:, :, independent_positions[node]]
    for node in dropped:
        block = range(node//block_size*block_size, (node//block_size+1)*block_size)
        members = [independent_positions[other] for other in block if other != node]
        # Offsets sum to zero in a complete block, preserving its current mean.
        points[:, :, positions[node]] -= local_offsets[:, :, members].sum(2)
    source_positions = [positions[int(node)] for node in model.sources[receiver]]
    residual = points[:, :, positions[receiver], None]-torch.einsum(
        "sij,bqsj->bqsi", maps[receiver], points[:, :, source_positions])
    cost = .5*torch.einsum("bqsi,ij,bqsj->bqs", residual, model.H[receiver], residual)
    node_logs = torch.log_softmax(state.pi[receiver].log()-cost/model.tau, -1)
    log_rows = torch.logsumexp(node_logs, dim=1)-log(2*r)     # (B,S)
    selected = node_logs.gather(
        -1, labels[:, None, None].expand(-1, 2*r, 1)).squeeze(-1)
    weights = torch.softmax(selected, dim=-1)
    shift = torch.einsum("bq,bqr->br", weights, offsets)
    centered = offsets-shift[:, None]
    tilted_C = torch.einsum("bq,bqi,bqj->bij", weights, centered, centered)
    cross = covariance[:, :, coordinates]                  # (B,NK,r)
    gain = torch.cholesky_solve(cross.mT, L).mT
    mean = mu.flatten(1)+(gain@shift[..., None]).squeeze(-1)
    # Combine the residual and tilted terms into one dense low-rank update.
    updated_covariance = covariance+gain@(tilted_C-C)@gain.mT
    return log_rows, mean.reshape_as(mu), .5*(updated_covariance+updated_covariance.mT)


def gaussian_source_step(
    mu:         torch.Tensor,       # (B,N,K), means on the observed fiber
    covariance: torch.Tensor,       # (B,NK,NK), kernel exactly range(P.T)
    labels:     torch.Tensor,       # (B,), supported label per path
    state:      CoupledState,
    model:      CoupledModel,
    receiver:   int,
    block_size: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    r"""Return c_i, m_a and S_a from a positive 2r-node Gaussian cubature.

    The returned row is logarithmic and normalized. All labels share nodes.
    With local covariance C and gain G, S_a=S-G C G^T+G C_a G^T.
    Only complete observed blocks remove a star coordinate. No jitter or
    rank threshold is used; an invalid hidden covariance fails Cholesky.
    Caller tensors are preserved.
    """
    return _source_step(mu, covariance, labels, comparison_maps(state.Theta, model),
                        state, model, receiver, block_size)


def sequential_source_message(
    mu:            torch.Tensor,       # (B,N,K)
    covariance:    torch.Tensor,       # (B,NK,NK)
    J_prev:        torch.Tensor,       # (B,N)
    J_next:        torch.Tensor,       # (B,N)
    state:         CoupledState,
    model:         CoupledModel,
    block_size:    int,
    shortcut_mass: float = 0.,
) -> dict[str, torch.Tensor]:
    r"""Score the ascending-order refresh law, then return its Gaussian message.

    Each normalized row is scored before conditioning. While a prefix still
    equals J_prev, its first cumulative probability <= shortcut_mass freezes
    the message; the remaining labels use native point-source rows at that
    frozen mean. This prefix-only substitution preserves normalization.
    Zero disables it. Against the uncut candidate its refresh-law TV is at
    most shortcut_mass; this is not a native-law error bound. The returned
    message is the refresh candidate, not the global hold/refresh mixture.
    """
    if not 0. <= shortcut_mass < 1.:
        raise ValueError("shortcut mass must be in [0,1)")
    mean, cov = mu.clone(), covariance.clone()
    batch, n_agents, _ = mu.shape
    maps = comparison_maps(state.Theta, model)
    log_refresh = mu.new_zeros(batch)
    updates = torch.zeros(batch, dtype=torch.long, device=mu.device)
    shortcut = torch.zeros(batch, dtype=torch.bool, device=mu.device)
    same_prefix = torch.ones_like(shortcut)
    log_cutoff = log(shortcut_mass) if shortcut_mass else -torch.inf
    for receiver in range(n_agents):
        active = (~shortcut).nonzero(as_tuple=True)[0]
        if active.numel() == 0:
            break
        rows, next_mean, next_cov = _source_step(
            mean[active], cov[active], J_next[active, receiver], maps,
            state, model, receiver, block_size)
        mean[active], cov[active] = next_mean, next_cov
        log_refresh[active] += rows.gather(-1, J_next[active, receiver, None]).squeeze(-1)
        updates[active] += 1
        same_prefix[active] &= J_next[active, receiver] == J_prev[active, receiver]
        if shortcut_mass and receiver+1 < n_agents:
            stopped = active[same_prefix[active] & (log_refresh[active] <= log_cutoff)]
            if stopped.numel():
                shortcut[stopped] = True
                suffix_rows = _point_rows(mean[stopped], maps, state, model, receiver+1)
                log_refresh[stopped] += suffix_rows.gather(
                    -1, J_next[stopped, receiver+1:, None]).squeeze(-1).sum(-1)
    return {"log_refresh": log_refresh, "mean": mean, "covariance": cov,
            "updates": updates, "shortcut": shortcut}
