"""Full Gaussian propagation and block-mean observation at fixed c_*."""
from __future__ import annotations

from math import log, pi

import torch

from .coupled_learning import CoupledModel, CoupledState, comparison_maps
from .switching_paths import sheet_force


def propagate_gaussian(
    mu:          torch.Tensor,      # (B,N,K).
    covariance:  torch.Tensor,      # (B,NK,NK), possibly singular on a retained fiber.
    assignments: torch.Tensor,      # (B,N), source labels.
    mobility:    torch.Tensor,      # (N,K,K).
    state:       CoupledState,
    model:       CoupledModel,
    dt:          float,
) -> tuple[torch.Tensor, torch.Tensor]:
    r"""Return (A mu+b, A Sigma A^T+2 dt M), A=I-dt M H_J.

    The frozen-assignment Hessian H_J includes every incident sender record.
    Its action uses sparse network gathers and sums, avoiding a dense A matrix.
    """
    B, N, K = mu.shape
    D = N*K
    receiver = torch.arange(N, device=mu.device)
    batch = torch.arange(B, device=mu.device)[:, None]
    maps = comparison_maps(state.Theta, model)[receiver, assignments]  # (B,N,K,K).
    sources = model.sources[receiver, assignments]                    # (B,N).
    source_rows = (sources+N*batch).flatten()
    weights = torch.nn.functional.one_hot(assignments, state.pi.shape[-1]).to(mu.dtype)
    force = sheet_force(mu, weights, state.Theta, model)
    mean_next = mu-dt*torch.einsum("nij,bnj->bni", mobility, force)

    def apply_A(matrix: torch.Tensor) -> torch.Tensor:
        r"""Apply I-dt M H_J to matrix rows without constructing H_J."""
        rows = matrix.reshape(B, N, K, D)
        residual = rows-torch.einsum("bnij,bnjd->bnid", maps, rows[batch, sources])
        record = torch.einsum("nij,bnjd->bnid", model.H, residual)/model.tau
        hessian_rows = (torch.einsum("nij,bnjd->bnid", model.J_0, rows)+record).contiguous()
        sender = -torch.einsum("bnji,bnjd->bnid", maps, record)
        # Flatten both batch and node so each path keeps its own sender sum.
        hessian_rows.flatten(0, 1).index_add_(0, source_rows, sender.flatten(0, 1))
        return (rows-dt*torch.einsum("nij,bnjd->bnid", mobility, hessian_rows)).reshape(B, D, D)

    covariance_next = apply_A(apply_A(covariance).mT).mT
    covariance_next = (covariance_next+covariance_next.mT)/2
    # Add the independent node noise to the owned output's diagonal blocks.
    covariance_next.reshape(B, N, K, N, K).diagonal(dim1=1, dim2=3).add_(
        2*dt*mobility.permute(1, 2, 0))
    return mean_next, covariance_next


def observe_gaussian(
    mu:         torch.Tensor,      # (B,N,K).
    covariance: torch.Tensor,      # (B,NK,NK).
    retained:   torch.Tensor,      # (B,(N/block_size)*K).
    block_size: int,
) -> dict[str, torch.Tensor]:
    r"""Score R~N(P mu,P Sigma P^T), then condition X on R=P X.

    P computes arithmetic block means. The gain uses the full covariance:
    G=Sigma P^T(P Sigma P^T)^(-1). No covariance regularization is applied.
    """
    B, N, K = mu.shape
    if block_size <= 0 or N % block_size:
        raise ValueError("block_size must be positive and divide the number of nodes")
    C, D = N//block_size, N*K
    dimension = C*K
    projected_mean = mu.reshape(B, C, block_size, K).mean(2).reshape(B, dimension)
    cross = covariance.reshape(B, D, C, block_size, K).mean(3).reshape(B, D, dimension)
    projected_covariance = cross.reshape(B, C, block_size, K, dimension).mean(2).reshape(
        B, dimension, dimension)
    projected_covariance = (projected_covariance+projected_covariance.mT)/2
    chol = torch.linalg.cholesky(projected_covariance)
    residual = retained-projected_mean
    white = torch.linalg.solve_triangular(chol, residual.unsqueeze(-1), upper=False).squeeze(-1)
    log_density = -.5*(white.square().sum(-1)+dimension*log(2*pi))-chol.diagonal(
        dim1=-2, dim2=-1).log().sum(-1)
    if block_size == 1:
        mean_conditional = retained.reshape(B, N, K)
        covariance_conditional = torch.zeros_like(covariance)
    else:
        gain = torch.cholesky_solve(cross.mT, chol).mT
        mean_conditional = (mu.flatten(1)+(gain@residual.unsqueeze(-1)).squeeze(-1)).reshape(B, N, K)
        covariance_conditional = covariance-gain@cross.mT
        covariance_conditional = (covariance_conditional+covariance_conditional.mT)/2
    return {
        "log_density": log_density,
        "mean": mean_conditional,
        "covariance": covariance_conditional,
        "projected_mean": projected_mean,
        "projected_covariance": projected_covariance,
    }
