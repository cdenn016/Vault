# Normalized-law foundations and the next formation phase

September 13, 2026. This is the variational foundations lane of the requested program review. The current coalescence objective can build on an already constructed normalized-law core. The next dependency is a coupled formation mechanism and its inherited conditional dynamics, rather than another proof that normalized coarse channels compose. The recent finite-depth and adaptive results close substantial special cases; they do not establish formation for every descent trajectory.

The review is confined to one fixed base point `c_*`. Independent link variables, agent-network loops and their retained joint laws are admitted. No base transport, physical-clock identification, capability threshold, storage saving, learned value for every interaction coefficient, or unique hierarchy is imposed as a prerequisite.

## Coverage and evidence limits

`Theory/SPEC.md` was read in full before writing. The source-first reading included the current opening of `docs/STATUS.md`, the complete central claim appendix, the current numerical-result record and numerical claim inventory, the September 11 full-program reconciliation, the current connected report's scope map, and the live Research index and staged-hierarchy theme. The Theory selection below was read at its claim statements, definitions, relevant proofs and dependency boundaries; this is a bounded foundations assessment, not a new line-by-line certification of every proof in those chapters.

| Source | Coverage relevant to this review |
| --- | --- |
| `Theory/01_introduction.tex` | General-to-Gaussian architecture; exact-law, geometric and RG scope summary. |
| `Theory/03_probability.tex` | Structural typing and evaluators, absolute continuity, selected posterior versions, coupling selection and failure of marginal reconstruction. |
| `Theory/04_generative.tex` | Normalized composition, the recognition-input prohibition, moving-target evidence comparison, normalized records and proper undirected alternative. |
| `Theory/05_elbo.tex` | Extended ELBO, total-correlation correction, conditional updates, M-coordinate acceptance and finite-step limitations. |
| `Theory/05a_expfamily.tex` | Law/kernel fibers, regular statistical tier, exponential-family and operator-domain distinction, quotient/pin repairs, information projection. |
| `Theory/05b_local_collective_elbo.tex` | Collective and conditional VFE, local/global difference theorem, factor counting, exact categorical attention, correlated-label correction and local natural-gradient scope. |
| `Theory/06_general_coarsegraining.tex` | Markov composition, KL/recovery, fixed-evidence push, energy precomposition and the distinct marginal-law mode. |
| `Theory/07_general_renormalization.tex` | Measure-pair arrows, autonomous versus cocycle types, comparison data, limit quantifiers and model-Fisher/Bayesian boundary. |
| `Theory/07b_agent_network_rg.tex` | Pointwise parent theorem and proof, effective-action/interaction claim map, meta-attention, marked operator-feature dependence, exact closure theorem and its supplied hypotheses. |
| `Theory/07c_full_graph_meta_agent_vfe.tex` | Entire chapter: full-law accounting, adaptive structural channels, hierarchical factors, row energies, loops, memberships and downward influence. |
| `Theory/06_gaussian.tex`, `06a_generative_gaussian.tex`, `07_restrictions.tex`, `09_coarsegraining.tex`, `10_renormalization.tex` | Dependency and theorem-summary coverage: Gaussian normalization and information form; declared interaction subfamily; restriction costs; Schur versus Galerkin operations; exact constrained Kron classifications; fixed-ray versus probability distinctions. Their long proof bodies were not independently reconstructed in this lane. |
| Live `Research/manuscripts/PIFB2.tex` | Lines 530–594 (`sec:mixture_derivation`), 3272–3412 (`app:mf_fixedpoint_status`), and 3413–3568 (correlated state/configuration and effective-action extension). |

The September 10–11 dependency reading additionally inspected the actual theorem inputs and formulas in `2026-09-10-equivariant-conditional-lcsc.md`, `2026-09-11-anisotropic-correlated-gaussian-spectrum.md` and `2026-09-11-gaussian-nonlinear-attraction.md`, together with the connected report and reconciliation's named source map. The adaptive completion and its source reconciliation were read for current supersession and assumptions. Other linked derivations were mapped by claim and section, not independently recertified here.

The saved `Theory/verification/current-results.json` labels its PASS as numerical corroboration, not proof. Its manifest refers to the older `manuscripts/gauge_vfe_rg` source layout. For example, its introduction hash is `2237a4294736138d4307e4d69f1870effd473dd429df3cc40198df327f16ab05`, whereas the current Theory introduction hashes to `5e8939fa5e442717aa0bbdc390abe2d14f1970e584842a2f5eec4c16ba4bf62a`. It therefore cannot certify this whole current manuscript. No previous science or validator was rerun; the numerical record's totals are historical readbacks and are not reported as fresh passes. The intentionally deleted vault ledger was not restored.

## Foundations map

**One full law precedes the variational functional.** The primitive agents supply law sections, presentation evaluators and normalized interaction-record kernels; a population dependence law is then constructed or selected. Local marginals are not a replacement for that law. `Theory/03_probability.tex:99–194,509–618` fixes these types, and `Theory/05_elbo.tex:43–119` gives the exact total-correlation correction. With a product reference, `KL(Q || product rho_i) = TC(Q) + sum_i KL(Q_i || rho_i)`. Removing the dependence entropy decreases the VFE by `TC(Q)` and increases its negative by the same amount; the latter need not remain an evidence bound. This is established accounting, not an outstanding request to discover correlations.

**Local descent already has an exact collective interpretation under its hypotheses.** `Theory/05b_local_collective_elbo.tex:388–411`, `thm:obs-local-global-potential`, proves the difference identity for two full recognition laws with the same outside marginal. Every incident record appears in an agent's conditional objective, so a shared factor is counted once globally but in several local coordinate objectives (`:500–526`, `eq:obs-singleton-incident-counting`). The current theory is consequently not a sum of independently optimized local ELBOs. The block natural-gradient dissipation at `:716–743` additionally requires an admitted regular family and block Fisher orthogonality. A correlated full Fisher generally mixes blocks. Objective compatibility does not prove arbitrary scheduling convergence or alignment.

**Exact probability reduction and dynamical reduction are separate.** `Theory/06_general_coarsegraining.tex:258–340` preserves one observation experiment by applying the same recognition-independent channel to generative, posterior and recognition laws. `Theory/07b_agent_network_rg.tex:34–66,76–255` proves

\[
\mathcal F_I(Q)=\mathcal F_A(QC)+\mathbb E_{QC}\operatorname{KL}(Q(dY\mid Z)\Vert\Pi(dY\mid Z)).
\]

The displayed difference is an ordinary finite subtraction only when the fine KL is finite. Vanishing conditional KL is a recovery statement for the pair; one reverse kernel for an entire parameter family needs simultaneous hypotheses. The channel theorem neither supplies an autonomous reduced vector field nor makes a fitted parent exact. The recent conditional-entropy, force and path bounds address these distinct obligations in actual models.

**Exact RG composition already exists without a fixed point.** `Theory/07_general_renormalization.tex:73–148` pushes both the reference probability and evidence submeasure through each normalized channel. Normalization and the tower property compose these arrows exactly. Common-carrier fixed points additionally need comparison maps; a scale-dependent sequence can instead be a cocycle (`:503–554`). The original rescaling laboratory's failure is about its declared family, not the impossibility of ordinary normalized-kernel composition. The September 12 correction at the top of the staged-hierarchy wiki makes this distinction explicit.

**Marked parents already retain the information that loops and interactions generate.** The complete conditional theorem at `Theory/07b_agent_network_rg.tex:3069–3106` includes induced hyperedges, joint attention-event laws, simultaneous root-framed holonomy, boundary generators and full path laws or memory kernels. `:2112–2120` shows why a mean transporter is insufficient: even first operator moments fail to determine a correlated transported feature. `Theory/07c_full_graph_meta_agent_vfe.tex:304–355` allows nonidentity stabilizer holonomy and makes flattening a separate modeling choice. No new Wilson penalty is necessary to maintain the exact-law foundation.

**Attention is already derived, with several different probability objects.** In `Theory/05b_local_collective_elbo.tex:529–711`, fixed sample-level energies `D_ij(Y)` enter a normalized source-label record. The posterior conditional row is `beta^P_ij(Y) ∝ pi_ij exp[-D_ij(Y)/tau_i]`. Restricting recognition to independent constant label rows instead gives `beta^{Q*}_ij ∝ pi_ij exp[-E_Q D_ij/tau_i]`; it is generally not the expectation of the posterior row. Correlated label laws retain conditional total correlation. `Theory/07b_agent_network_rg.tex:1982–2066` then pushes `eta_ij = alpha_i beta_ij`, not a row alone, and uses evidence weights when receivers are combined. The required next work is to couple this existing structure to formation and inherited learning.

**PIFB2 is compatible prior research once its probability levels are respected.** Its mixture derivation (`:530–594`) explicitly says the live-peer row is a consensus-energy ansatz. Its theorem `thm:state_level_elbo_nogo` (`:3281–3332`) concerns one fixed joint on the original state variables over a mixture-open, independently varying recognition family. It does not rule out a normalized law on complete law-point/link configurations, frozen templates or a separately constructed structural hierarchy. Its nested-state/configuration theorem (`:3444–3463`) already gives the exact chain-rule bridge through a proper structural prior. The proposed region, one-loop and 2PI tiers at `:3473–3567` are not all established, and none is required merely to permit a correlated state posterior. In particular, introducing edge pseudomarginals does not repair a live recognition-dependent generative factor (`:3503`).

## What should not be reopened as the next phase

The September 11 full-program reconciliation records the scope that existed when written. Its two highlighted then-open directions have since advanced: the current claim appendix `:710–726` and SPEC section 10 contain the intrinsic finite-dimensional Fisher-defect classification, while appendix `:555–608` and `Theory/09_coarsegraining.tex:321–2216` contain independent-family, retained-boundary, nonflat-series, finite-semialgebraic and variable-support Kron results. Arbitrary unspecified constraints and universal smooth selectors remain outside those theorems. They are not prerequisites to the present coalescence objective.

Several older blanket-open entries also coexist with later scoped constructions in the connected report. Nondominated event inference, LCSC equivariant conditional versions, actual Gaussian lifts, anisotropic correlated tangent spectra, nonlinear iid Gaussian attraction, Bayesian/model-Fisher comparison, scalar hierarchy realization, projectability and strong/weak quotient boundaries have named September 10–11 artifacts. Their admitted hypotheses matter; their existence must not be called absent simply because the appendix retains an older general statement. A source-integration pass is useful coordination work, but another example of the same already established existence statement would not advance formation.

The adaptive completion `adaptive-cyclic-completion.md:7–9,183–189` is especially precise: there are genuine learned normalized parameters and changing hidden conditionals at every prescribed finite depth, but normalized attention rows remain fixed, contrasts are supplied, and much appreciable adaptation occurs after the short formation windows. The nonlinear finite-depth result has a separate fixed-coefficient scope. Combining these mechanisms is a substantive new dependency, not a reason to withdraw their prior completions.

## A source defect candidate relevant to adaptive membership

### Random attention and membership must be averaged jointly

**Location:** `Theory/07c_full_graph_meta_agent_vfe.tex:387–410`, `eq:full-graph-edge-pushforward` and `eq:full-graph-correlated-edge-pushforward`, with random structural state at `:70–124`.

**Severity:** medium.

**Evidence:** The displayed formula places `eta_ij` outside `E_mu[M(I,J|i,j,R)]`, although `eta` is part of the random input graph and `mu` is described as its generative, posterior or recognition input law. The unconditional exact event probability is `sum_ij E_mu[eta_ij M(I,J|i,j,R)]`. Consider equiprobable input states 0 and 1. In state 0, the sole edge event is `1 -> 2` and membership is `{1,3} -> A, {2} -> B`. In state 1, the sole edge event is `1 -> 3` and membership is `{1,2} -> A, {3} -> B`. The true coarse event is `A -> B` with probability one. Multiplying the mean edge-event masses `(1/2,1/2)` by the mean membership indicators `(1/2,1/2)` gives `1/2`. All input laws and hard assignments are normalized. Exact SymPy arithmetic reproduced `exact=1`, `factorized=1/2`, `gap=1/2`.

**Fix:** Put the event mass and assignment inside one expectation, or explicitly condition on the full fine state so that the displayed event mass is fixed and use the corresponding conditional membership kernel.

**Falsifies:** A stated conditioning convention under which `eta` is deterministic, or an explicit independence hypothesis between each event mass and its assignment indicator, retracts the defect for that restricted formula.

**Status:** Candidate for the independent verifier. The general common-structural-channel definition and pushforward theorem remain correct. This lane does not claim a defect in the September 12 adaptive witness, which does not use arbitrary correlated adaptive membership.

## Reconstructed bridge: live attention changes restoring curvature

For fixed positive prior and temperature, write the energy-unit row envelope as

\[
f(x)=-\tau\log\sum_j\pi_j e^{-E_j(x)/\tau}.
\]

Differentiating the normalized Gibbs weights gives

\[
\nabla f=\mathbb E_\beta\nabla E,
\qquad
\nabla^2f=\mathbb E_\beta\nabla^2E-\tau^{-1}\operatorname{Cov}_\beta(\nabla E).
\]

This is the existing Gibbs/envelope mechanism, reconstructed here to identify a next-phase proof obligation. The covariance term is negative semidefinite. With `E_1=(x-1)^2`, `E_2=(x+1)^2` and equal source priors, both individual energies have curvature 2, but `f''(0)=2-4/tau`. SymPy 1.14.0 returned exactly zero for both the gradient and Hessian residuals and the displayed value at zero. Thus replacing supplied weights by optimized attention does not preserve a positive transverse restoring margin automatically. For the exact nats row in `Theory/05b`, divide the energy-unit envelope and this Hessian by its fixed `tau`; the row minimizer is unchanged, but arbitrary sectorwise temperature multiplication is not a standard ELBO identity.

The counterexample does not prove that attention prevents coalescence. It identifies the quantity the new theorem must bound, alongside full-law Fisher mobility and any additional prior/record curvature. At a perfectly aligned configuration all individual mismatch gradients may vanish, so this covariance correction can vanish there; stability through a neighborhood still needs control. If priors or temperatures themselves vary, their extra derivatives must also be retained. The current fixed-weight formation theorems do not assert otherwise.

## Ranked next directions

1. **Couple normalized attention adaptation to actual formation.** Extend the existing source-label/event-law construction to a finite cyclic admitted model in which at least one normalized attention row changes appreciably during a formation episode, while law/model/link coordinates follow one normalized objective. Retain joint event, loop and cut data; derive the actual full-score and Fisher updates; prove a transverse stability margin after paying the attention covariance correction. Then inherit at least two parent levels with separate conditional-VFE and dynamical error control. Supplied microscopic contrast may remain an input. This directly closes the discrepancy between weighted-attention theory and the newest fixed-row adaptive witness without requiring every weight or grouping to be learned.

2. **Join nonlinear parents to changing hidden conditionals.** Extend the admitted nonlinear finite-depth construction with one genuine learned parameter that changes a discarded conditional, inheriting each parent's learning from its own current law. The essential new estimates are nonlinear moving-conditional entropy production, score/force mismatch and quantitative memory or path control on one common formation-and-learning interval. This is narrower than unrestricted `GL(K)` closure and stronger than separately citing a nonlinear fixed model and a Gaussian adaptive one. It is the best alternative if the first attention extension cannot retain a nonzero restoring margin in a tractable family.

3. **Make membership a path-dependent output of the formed regime.** Starting from a completed coupled example, construct an admitted causal/random structural channel for histories and prove that all marks needed by later membership decisions survive each push. Derive the distribution of merger histories and the retained-memory cost, allowing multiple histories and eventual reorganization. The exact event-law correction above is part of this interface. A unique first-hitting hierarchy is optional; exact composition does not require uniqueness, permanent blocks or a universal fixed point.

An unbounded-depth limit, whole-program universality, unrestricted strong/weak geometry, and empirical physicalization have lower immediate dependency on the current formation objective. They can remain visible without becoming gates on the next finite pointwise theorem.

## Work performed

Only this report was created. No Theory, vault, executable, config, claim ledger or historical evidence artifact was edited. There was no Git operation, production run, suite, GPU use, Lean work or prohibited tamper check. The two small exact calculations used `C:/Python314/python.exe` with SymPy 1.14.0 and no torch. The finite event construction used rational arithmetic; the envelope check used exact symbolic differentiation. These are new local bridge checks and do not rebind any prior result.
