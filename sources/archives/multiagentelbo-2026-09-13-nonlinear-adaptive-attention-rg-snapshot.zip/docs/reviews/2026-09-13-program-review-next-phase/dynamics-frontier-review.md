# Dynamics frontier: the nonlinear adaptive conditional bridge

September 13, 2026. This bounded mathematical review reads the completed formation results as inputs to the next construction. It does not reopen their published acceptance or claim to complete the next phase. The ambient principal/associated-bundle types remain those of `Theory/SPEC.md`; all dynamics below occur over the single fixed point c_*. The new results are the elementary partition-ratio and conditional-score lemmas in Sections 3–5. Their assumptions and proofs are explicit.

## 1. What is already available

The current objective is stated in [STATUS.md](../../STATUS.md:5): a recursively composable hierarchy formed through the coupled dynamics of belief/model sections and independent interaction links. External capabilities, storage savings, a unique hierarchy, permanent intermediate levels and physical time are not prerequisites. The one-point restriction is explicit at [STATUS.md](../../STATUS.md:9). This review adds no base transport.

The progression must be read cumulatively. [The original assembly](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/dynamical-rg-assembly.md), [the common-kinetics Gaussian bridge](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/translation-link-conditional-bridge.md:349), [the nonlinear two-stage completion](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/nonlinear-two-stage-completion.md:272), and [the finite-depth nonlinear completion](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/finite-depth-completion.md:106) successively added actual separated formation episodes, positive-temperature conditional-VFE bounds, nonlinear exact parent integrals, and successive activation from the actual retained law. Their early open interfaces are not cumulative current blockers.

The latest [adaptive cyclic completion](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-cyclic-completion.md:5) already establishes a finite Gaussian family for every prescribed finite L at least two. It includes genuine generative-parameter learning, actual changing hidden conditionals, independently learning parents, complete marked normalized parent laws, separate conditional-KL and path estimates, and actual sequential initialization. The [joined reconstruction](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-independent-reconstruction.md:5) identifies the dependencies and reconstructs the required matrix, score, formation and feedback equations. The [conditional reconstruction](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-conditional-check.md:9) and [formation reconstruction](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-formation-check.md:5) preserve the same scope. Own-law parent learning is therefore an available result, not a missing item to rediscover.

Its assumptions are also actual assumptions. The parameter a multiplies supplied edge strengths J_e; normalized rows J_ij divided by their row sums remain fixed. The scalar a changes by more than one half through calibration-assisted normalized model learning, mostly after the short formation intervals. The compatible observation z lies in ker H. The proper reference uses the generally dense projector P_K. Gaussian recognition is propagated by configuration diffusion, not by the full-law Fisher replicator. These points are stated in [the joined theorem](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-cyclic-completion.md:9) and [the normalized model](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-normalized-model.md:132). They are admitted choices, not defects or mandatory reasons to add learned contrasts, local force evaluation, incompatible observations or unbounded depth.

There are three different objects in this result. The physical prior reverse kernel pushes the original evaluator. The physical posterior reverse kernel is determined by the actual normalized joint and observation. The recognition-optimal reverse kernel minimizes the restricted evaluator-family VFE. Their means can coincide in the witness while their precisions differ. [Equations M10a–M10b](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-normalized-model.md:109) retain the physical evidence and the common restricted-objective scalar. Those distinctions must survive the next nonlinear construction.

The existing nonlinear and adaptive theorems cannot simply be concatenated: the nonlinear proof freezes the parameter, whereas the Gaussian covariance comparison uses a closed Lyapunov equation that a nonlinear density does not satisfy. This is already the conclusion of [RG-COMPLETION.md](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/RG-COMPLETION.md:7), not a newly discovered obstruction. The [adaptive geometry analysis](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-loop-parent-geometry.md:142) already supplies a local moving-normal estimate, complete attention differential and Hessian, normalized event-law coarsening, and bounded-score learning defect. Its [independent reconstruction](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-model-geometry-check.md:347) checks these alongside the exact loop flag and warns that the Gaussian score is unbounded. Therefore a new blanket claim that moving attention or moving-score parent identities are absent would be incorrect.

The live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex:929>) supplies prior motivations and explicit conditional machinery. Its imposed microscopic rate hierarchy and normally attracting fast-equilibrium premise are separate from derived collective rates. Its formation section distinguishes barycenters, a proposed improvement criterion and a detector. Its [clock discussion](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex:1828>) distinguishes Fisher length from a fixed-granularity squared increment, with covariance-dependent meta-clock behavior. Neither mechanism supplies the missing nonlinear adaptive conditional estimate. The RG discussion already has the reduced-attention Hessian with its negative covariance term at [equation rg_reduced_hessian](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex:3678>), the graph pullback metric at line 3705, and an explicitly independent force-closure obligation at lines 3668 and 3934. Those are existing research to extend. The read-only [staged hierarchy synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Staged hierarchy formation and RG composability.md>) likewise distinguishes exact law composition from dynamical closure and preserves the latest finite nonlinear/adaptive scopes.

## 2. Which next phase matters

The narrowest consequential bridge is a normalized nonlinear adaptive cyclic model in which the conditional error and actual parent score are controlled together on the model-learning interval. Merely adding an arbitrarily small bounded nonlinear perturbation to the Gaussian witness could establish a useful robustness theorem, but would contribute little to the mechanism already present. A stronger, still bounded continuation joins the existing normalized source-attention mechanism to this bridge, allowing actual changing positive attention while preserving the supplied hierarchy contrasts. This is a recommended research choice; the user has not separately demanded learning every contrast or removing calibration.

An explicit proposed acceptance target is: for every prescribed finite depth L at least two, exhibit a nonempty admitted finite family and initial-data neighborhood with one common microscopic kinetic prescription, independent cyclic links, and a normalized nonlinear joint, such that actual successive coalescence and sequential actual-law parent activation occur before H_epsilon=c/epsilon; a learned generative coefficient changes an eliminated physical and optimizing conditional by a stated positive amount; the exact marked parents compose; and the actual active-interface conditional KL, parent-score discrepancy and retained-path approximation each have a bound tending to zero in one simultaneous parameter regime. Constants may depend on L. Supplying contrasts is allowed. Approximate retained paths are not required to have exactly equal laws, and no equality of their clocks is required.

If changing attention is included, its nontriviality should be declared before construction. A useful discriminating version asks for a normalized source row to change by a fixed positive total-variation amount on an admitted interval while the needed normal-restoring bound remains positive. That condition is an introduced proposed strengthening, not an unspoken requirement of the completed Gaussian result. A result with merely nonconstant rows and vanishing variation is a weaker robustness result and should say so.

The first obligation is more specific than “prove nonlinear closure”: obtain conditional score concentration and a dissipation budget uniform on the adaptation interval, from the actual normalized model and its exact parents. The following lemmas settle a reusable part of that obligation. They do not supply the remaining formation basin, attention-curvature margin or compact-interface estimates.

## 3. A nonlinear entropy budget inherited by every exact parent

This section introduces a conditional subclass. Let S be a standard-Borel space, let mu be a fixed sigma-finite reference, let V:S -> [0,infinity) be measurable, and let T>0. For a in a compact interval [a_-,a_+] with a_->0, suppose

\[
 p_a(ds)=Z(a)^{-1}e^{-aV(s)/T}\mu(ds),\qquad
 0<Z(a/2),Z(a)<\infty,\qquad
 \frac{Z(a/2)}{Z(a)}\le R<\infty.
 \tag{D1}
\]

Here p_a is a lemma-local normalized reference, not a new agent. The fixed reference can contain a parameter-independent potential, observations, or latent source labels. If the chosen normalized model has additional non-affine a-dependence, it must be incorporated and bounded separately; D1 does not cover it by notation alone. A common a-dependent scalar multiplying every raw weight cancels from p_a, but remains in the complete VFE scalar if it comes from evidence or a restricted-family correction.

Let C_s:S rightsquigarrow Y_s be any fixed normalized a-independent channel, with joint p_a(ds)C_s(s,dy). Write pi_a^s=p_a C_s and

\[
 m_{a,s}(y)=E_{p_aC_s}[V\mid y],\qquad \bar V_a=E_{p_a}V.
 \tag{D2}
\]

Assume differentiation under the defining integrals and the selected conditional versions is justified. Then

\[
 \partial_a\log\pi_a^s(y)
 =\frac{\bar V_a-m_{a,s}(y)}T
 \tag{D3}
\]

almost everywhere in a common dominated chart. This follows by differentiating the normalized joint before applying the fixed channel. In particular the derivative of Z(a) is retained. Jensen's inequality and D1 give

\[
 E_{\pi_a^s}\exp\left[\frac{a}{2T}m_{a,s}\right]
 \le E_{p_a}\exp\left[\frac{a}{2T}V\right]
 =\frac{Z(a/2)}{Z(a)}\le R.
 \tag{D4}
\]

For any r << pi_a^s with finite H_s=T KL(r||pi_a^s), nonnegativity of KL to the exponential tilt in D4 implies

\[
 E_r m_{a,s}\le\frac2a H_s+\frac{2T}{a}\log R,
 \qquad \bar V_a\le\frac{2T}{a}\log R.
 \tag{D5}
\]

For completeness the tilt inequality is obtained by expanding KL(r||e^{lambda m}pi/E_pi e^{lambda m})>=0 and taking lambda=a/(2T). Its use does not require r to be Gaussian. Since both m and V are nonnegative, D3–D5 imply

\[
 \left|T E_r\partial_a\log\pi_a^s\right|
 \le \frac2a H_s+\frac{4T}{a}\log R.
 \tag{D6}
\]

Now specify the dynamics, rather than infer it from a static law. On each active smooth parent carrier, assume the actual recognition law r_t follows the reversible diffusion with instantaneous invariant density pi_{a_t}^s, constant inherited mobility M_s>0, and generator

\[
 L_{a,s}f=T\operatorname{tr}(M_s\nabla^2 f)
       +T\langle M_s\nabla\log\pi_a^s,\nabla f\rangle.
 \tag{D7}
\]

The noise covariance is 2TM_s dt. Work on Euclidean space with vanishing boundary terms, or a genuine smooth periodic product where those terms cancel. Positivity, sufficient regularity, finite relative Fisher information and differentiation/integration by parts are hypotheses. The parameter a_t is absolutely continuous, remains in [a_-,a_+], and is allowed to use that parent's own law and complete inherited normalized score. The lemma needs its actual relative variation, not a prescribed schedule. Define

\[
 I_s(t)=E_{r_t}|\nabla\log(r_t/\pi_{a_t}^s)|_{M_s}^2,
 \qquad B(t)=\int_{t_0}^t\frac{|\dot a_u|}{a_u}du.
 \tag{D8}
\]

Differentiating relative entropy for this actual diffusion yields

\[
 H_s'=-T^2 I_s-T\dot a E_{r_t}\partial_a\log\pi_a^s.
 \tag{D9}
\]

Thus D6, followed by the elementary integrating-factor identity, gives the proved bound

\[
 \begin{split}
 e^{-2B(t)}[H_s(t)+2T\log R]
 +T^2\int_{t_0}^t e^{-2B(u)}I_s(u)du
 \le H_s(t_0)+2T\log R,\\
 T^2\int_{t_0}^t I_s(u)du
 \le e^{2B(t)}[H_s(t_0)+2T\log R].
 \end{split}
 \tag{D10}
\]

No order-one calibration energy appears in this budget: H_s is relative entropy against the normalized instantaneous optimizer. The calibration still determines a_t through the full actual learning law; it has not been removed from that law. If |a'|<=epsilon V_a on an interval of length c/epsilon, then B<=cV_a/a_-. Consequently the exponential in D10 is bounded independently of epsilon and of the largest microscopic stiffness. The estimate does not assume H_s decreases during learning.

The same R is inherited by every fixed exact channel, including nested ones, because D4 used only conditional expectation. At an actual activation time, set the next recognition to the preceding retained law and keep its current a. Data processing makes H drop; for a deterministic retention the drop is exactly T times its discarded conditional KL. Therefore D10 also holds across any prescribed finite sequence of exact activations, with the accumulated B and the sum of the active continuous dissipation integrals. This is an energy accounting statement for the sequential process, not an assertion that conditional losses evaluated at different times form one same-time KL chain.

A globally nonquadratic class makes D1 concrete. On R^p suppose V(0)=0, grad V(0)=0, and

\[
 cH\preceq\nabla^2V(x)\preceq CH\quad\hbox{for every }x,
 \qquad H\succ0,\quad 0<c\le C.
 \tag{D11}
\]

Let mu(dx)=exp[-kappa |x|^2/(2T)]dx, with kappa>=0. Taylor's formula with integral remainder gives c x^THx/2<=V(x)<=C x^THx/2. Integrating the two Gaussian envelopes proves

\[
 \frac{Z(a/2)}{Z(a)}
 \le\left[\frac{\det(aCH+\kappa I)}
                   {\det(acH/2+\kappa I)}\right]^{1/2}
 \le(2C/c)^{p/2}.
 \tag{D12}
\]

The last inequality compares each eigenvalue ratio in the fixed eigenbasis of H. It depends on dimension and relative curvature, not the largest eigenvalue of H. A nonquadratic example is V(x)=x^THx/2+delta sum_j[1-cos((H^{1/2}x)_j)] with 0<delta<1; its Hessian is between (1-delta)H and (1+delta)H. This is only a witness for the budget assumptions, not the requested cyclic formation model or a claim that its record kernels have already been built.

The affine tilt can also include a finite source label j in S. Summing that label produces a nonlinear log-sum potential and changing conditional source probabilities, while D3–D10 continue to hold for the marginalized state. One must still construct a normalized generative record realizing that tilt and retain the correct source/occupancy event law. Arbitrary softmax potentials are not thereby admitted, and D12 is not automatically inherited by every such source mixture.

## 4. Conditional score forcing with quadratic tails

The moving-target term is prior work. [Conditional lag, Section 9](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/conditional-lag-and-parent-vfe.md:567), equation (53), already adds minus the expectation of the conditional target's time derivative and explains why the frozen-target entropy budget no longer applies. [Structural-learning closure](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/pointwise-learning-parent-closure.md:82), equations (7)–(10), already derives moving conditional mismatch for the distinct full-law Fisher flow. [Adaptive conditional bounds](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-conditional-bounds.md:263), equations (28)–(33), already includes the exact parent model-score defect and its Gaussian form. The extension here is a conditional exponential-moment bound admitting quadratic scores, joined to D10.

Use a fixed product split x=(y,z), instantaneous normalized density pi_a(y,z)=s_a(y)k_a(z|y), and actual recognition q_t(y,z)=r_t(y)h_t(z|y). In this section h_t is a conditional density; write m(a)>0 for the scalar inherited model metric, to avoid confusing them. The actual microscopic diffusion has mobility diag(I,C), C>0 constant, and potential U_a=-T log pi_a up to a scalar. The parameter follows

\[
 \dot a=-\epsilon m(a)^{-1}g(q_t,a),\qquad
 g(q,a)=\partial_a[T\operatorname{KL}(q\Vert\pi_a)+C_T(a)]\big|_q.
 \tag{D13}
\]

C_T retains every varying evidence and restricted-family scalar. This is deterministic, expectation-driven model learning; the configuration diffusion supplies the noise. No noisy parameter gradient or discretized update is asserted. Smooth positive densities and the boundary/regularity hypotheses of D7 are retained. These hypotheses imply the exact dissipation identity

\[
 \frac{dF_T}{dt}=-T^2 I_{y,z}-\epsilon m(a)^{-1}g^2.
 \tag{D14}
\]

For each conditional k_a(.|y), assume a uniform conditional logarithmic-Sobolev estimate and a mixed-derivative bound

\[
 D(h\Vert k_a)\le\frac{T}{2\lambda}
        E_h|\nabla_z\log(h/k_a)|_C^2,
 \qquad \|C^{1/2}\nabla_z\nabla_y U_a\|\le\Gamma,
 \quad \lambda>0.
 \tag{D15}
\]

These are assumptions to prove from the intended model, not consequences of normalization or coherence alone. Let xi=m(a)^(-1/2) partial_a log k_a, which has zero k_a-mean. Assume uniformly in a,y that

\[
 \log E_{k_a}e^{u\xi}
 \le\frac{v u^2}{2(1-b|u|)},\qquad |u|<1/b,
 \quad v>0,quad b\ge0.
 \tag{D16}
\]

For b=0 the domain is all real u. The tilt inequality used for D5, now with both signs of u, gives

\[
 |E_h\xi|\le\sqrt{2v D(h\Vert k_a)}+bD(h\Vert k_a).
 \tag{D17}
\]

Indeed substitute u=sqrt(2D/v)/(1+b sqrt(2D/v)) in D/u+vu/[2(1-bu)]. At D=0 the conclusion follows by equality of the two laws. This proof is valid for unbounded xi when D16 holds; no bounded-score assumption is hidden.

Define Delta=E_r D(h||k_a), omega=sqrt(m)|a'|, I_y=E_q|grad_y log(q/pi_a)|^2 and I_z=E_q|grad_z log(q/pi_a)|_C^2; the I_{y,z} in D14 is I_y+I_z. The conditional LSI in D15, applied to an exponential tilt of each scalar component of grad_y log k_a, gives

\[
 |E_h\nabla_y\log k_a|
 \le\frac{\Gamma}{\sqrt{T\lambda}}
          \sqrt{2D(h\Vert k_a)}.
 \tag{D18}
\]

This is the same Herbst calculation as the existing conditional-lag equations (19)–(21): the C-norm of the hidden derivative of any unit component is at most Gamma/T; integration of uH'(u)-H(u)<=u^2 Gamma^2/(2Tlambda) gives its centered exponential bound, and the tilt inequality gives D18.

Write w=grad_y log(q/pi_a), e_y=E_h grad_y log k_a, and e_a=E_h partial_a log k_a. The exact conditional balance, reconstructing existing equations (24) and (53), is

\[
 \Delta'=-T I_z-T E_r\operatorname{Var}_h(w)
        +T E_r[e_y\cdot E_hw]-\dot a E_re_a.
 \tag{D19}
\]

To check the sign of the cross term, put A=grad_y log(r/s_a). Normalization gives E_hw=A-e_y. Differentiating conditional entropy gives the y-integrand minus T E_h[w dot(w-A)], which equals minus T Var_h(w)+T e_y dot E_hw. Differentiation of the target contributes the last term. This derivation concerns the actual joint density, rather than a frozen conditional relaxation.

Use D15, D17, D18, Jensen and Cauchy–Schwarz in D19. Allocate lambda Delta/2 to each of its two square-root forcing terms. If b omega<=lambda/2 throughout the interval, the result is

\[
 \boxed{\Delta'\le-\frac\lambda2\Delta
          +\frac{T\Gamma^2}{\lambda^2}I_y
          +\frac v\lambda\omega^2.}
 \tag{D20}
\]

For explicit constants, before imposing b omega<=lambda/2 the right side is minus (lambda-b omega)Delta plus the last two terms. The hidden LSI supplies minus 2lambda Delta; the y-term is at most lambda Delta/2+T Gamma^2 I_y/lambda^2; and the model term is at most lambda Delta/2+v omega^2/lambda+b omega Delta. Thus no unexplained stability coefficient appears.

Set B_y=T^2 integral_(t0)^t I_y(u)du and omega_* = sup omega. Integration gives the proved conditional estimate

\[
 \boxed{\Delta(t)\le e^{-\lambda(t-t_0)/2}\Delta(t_0)
     +\frac{\Gamma^2}{T\lambda^2}B_y
     +\frac{2v\omega_*^2}{\lambda^2}.}
 \tag{D21}
\]

When the normalized target has D1's admitted tilt representation, D10 supplies B_y<=exp(2B)[H_s(t0)+2Tlog R], since I_y is bounded by the complete active relative Fisher dissipation. The same inequality can be applied after each exact activation using that stage's actual initial entropy. Using one large initial budget at all stages is valid but can be much too crude; the nonlinear formation proof must bound the remaining active energy at its actual activation time. Neither a strong Hessian alone nor an appeal to “slow learning” discharges those quantitative requirements.

The Gaussian predecessor is compatible with D16. For a k-dimensional conditional with fixed mean and precision aD_*, let Z be standard normal. Then

\[
 \xi=\frac{k-|Z|^2}{2a\sqrt{m}},\qquad
 \log E e^{u\xi}=\frac{ku}{2a\sqrt m}
       -\frac k2\log\left(1+\frac{u}{a\sqrt m}\right).
 \tag{D22}
\]

For |u|<a sqrt(m), the Taylor series or integration of the geometric series bounds this by D16 with

\[
 v=\frac{k}{2a^2m},\qquad b=\frac1{a\sqrt m}.
 \tag{D23}
\]

Consequently b omega=|a'|/a, and v omega^2=k(a'/a)^2/2. The learning-forcing plateau in D21 is of order (a'/[a lambda])^2 and does not depend on the magnitude of D_*. A globally sub-Gaussian score assumption would exclude this basic quadratic score; the sub-gamma form retains it. General Gaussian conditionals with moving means have additional linear terms, and nonlinear conditionals need their own verified D16 constants.

## 5. Parent learning and the exact remaining interfaces

For the exact restricted parent scalar F_parent(r,a)=T KL(r||s_a)+C_T(a), differentiating the KL chain while holding the actual recognition conditional fixed gives the already-established covector identity

\[
 g(q,a)-g_{\rm parent}(r,a)
       =-T E_q\partial_a\log k_a.
 \tag{D24}
\]

D17 supplies the additional usable nonlinear bound

\[
 \frac{|g-g_{\rm parent}|}{\sqrt{m(a)}}
 \le T\left[\sqrt{2v\Delta}+b\Delta\right].
 \tag{D25}
\]

This is an instantaneous comparison at the same a and actual retained r. The inherited model-velocity error at that state, measured in m, is at most epsilon times the right side of D25. A small scalar conditional KL gives a square-root score error; it does not justify replacing that error by order Delta. The exact fine score includes all normalizers through g_parent and C_T.

The retained conditional-averaged drift defect also obeys

\[
 \|E_h[-\nabla_yU_a]-E_{k_a}[-\nabla_yU_a]\|_{L^2(r)}
 \le\Gamma\sqrt{\frac{2T\Delta}{\lambda}}.
 \tag{D26}
\]

Independently evolving parents then need a stability estimate coupling retained-law error and parameter error. The existing [adaptive comparison](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-conditional-bounds.md:321), equations (35)–(42), already proves the required two-inequality argument for Gaussian affine drift. Its proof extends to a declared nonlinear drift with the same one-sided contraction and law/parameter Lipschitz bounds; obtaining those bounds from the nonlinear exact parent is the obligation, not another use of the word “inherited.” For a diverging contrast family the constants must be controlled in relative forms, as the Gaussian witness does, or paid explicitly in the simultaneous regime.

D21 and D25 concern actual conditional laws, their one-time retained drift and model score. They do not identify the projected microscopic path with the Markov parent. Hidden thermal forcing, the conditional law given the retained history and actual initial correlations remain relevant even at Delta=0. The completed Gaussian witness handles that difference through a separate path coupling and exact-memory alternative. A nonlinear extension needs its own counterpart.

On the existing compact cosine carrier, the primitive principal-coordinate retention has glued faces. It is not the global product diffusion assumed in D19. The exact current term in [conditional-lag equation (24)](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/conditional-lag-and-parent-vfe.md:247), and the off-cube conditional and label entropies in equations (31)–(36), must be restored. D20 then acquires that current term, and D21 its exponentially weighted integral, together with the outside-entropy estimate when a local LSI is used. Reflecting the real process would change the model. The older exp(Lt) boundary bound cannot be advertised as uniform on 1/epsilon without checking its barrier against the same joint scaling.

Changing positive normalized attention makes these admissions more consequential. PIFB2's existing covariance correction can reduce the transverse Hessian away from exact coherence. A positive frozen-edge Hessian is therefore insufficient to establish D15 along the actual entrance tube. Near exact agreement the leading positive normal Hessian and the vanishing covariance correction can give a local route, but the size and invariance of that region must be proved while attention and a actually move. Incompatible forcing should initially be an explicit perturbation with its normal component paid against that same tube. Requiring arbitrary forcing would be a different, generally false universal formation target.

## 6. Supported result and next action

The strongest new result here is D10: an entropy-production budget for a normalized nonlinear tilt family that passes to every exact parent and remains controlled over an O(1/epsilon) learning interval when relative parameter variation is bounded. It does not spend the unrelated order-one calibration energy and does not introduce a largest-stiffness exponential. D20–D25 connect that budget to conditional KL and the complete own-law parent learning score under explicit LSI, mixed-derivative and sub-gamma score assumptions. These are analytical implications with proofs, not numerical observations or a closed formation theorem.

The minimal unresolved obligation is to instantiate those constants, the actual activation entropies and the parent feedback bounds in one normalized nonlinear cyclic model with the chosen source-attention mechanism. If a compact carrier is retained, its boundary-current and off-tube entropy estimates are part of that obligation. The next action that would materially change the answer is to write that model's normalized joint and full reduced transverse Hessian, then exhibit one invariant entrance/formation tube and a common positive score/curvature regime. That decides whether the nonlinear adaptive join is an actual formation mechanism or only an infinitesimal perturbation of the existing Gaussian example. Learned contrast creation, all gauge groups, infinite depth, and base transport remain separate extensions.

Source inspection and the displayed analytical derivations were performed. The primary [Legoll–Lelièvre source](https://arxiv.org/abs/0906.4865) was opened September 13 for the scope of conditional-expectation effective dynamics; it supplies relevant prior context, not a theorem about this adaptive tower. No numerical diagnostic, scientific rerun, full suite, GPU calculation, Lean proof, tamper check, production edit, Theory edit, vault edit or Git action was performed by this lane. This file is the lane's only output.
