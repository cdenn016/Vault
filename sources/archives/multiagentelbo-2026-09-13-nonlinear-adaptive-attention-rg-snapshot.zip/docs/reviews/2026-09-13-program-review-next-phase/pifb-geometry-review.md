# PIFB geometry, clocks, and the next formation interface

This is a bounded source review dated September 13, 2026. The target is to identify what the existing sources establish and what one subsequent formation theorem would have to add, at one fixed base point \(c_*\). The ambient model remains a principal/associated-bundle model of local sections. The pointwise interaction graph is its local view. No base path, base connection descent, spatial continuation, physical-time identification, infinite-depth limit, autonomous membership selector, or task-utility criterion is added to the requested next phase.

The strongest current formation results have different quantifiers. For every prescribed finite depth \(L\geq3\), the completed compact nonlinear construction supplies an admitted family with \(L\) actual formation levels, exact normalized marked parents, inherited geometry, and stated finite-horizon error bounds, with fixed coefficients and supplied interaction contrast. For every prescribed finite \(L\geq2\), the completed adaptive cyclic Gaussian construction supplies actual formation, retained loop marks, and learned model changes that alter hidden conditional laws; its constants, parameter regions, compatible observations, and calibration assumptions remain part of that theorem. Existence of these two families does not establish existence of a family having both sets of properties. This distinction is explicit in [STATUS](../../STATUS.md:37) and is the principal next-phase boundary.

Two narrow manuscript statements need correction. The pushforward of a normalized reference cannot fail sigma-finiteness because a coarse map has positive-dimensional fibers. Also, the square root of a ratio of expected KL increments is a ratio of RMS Fisher increments; it does not generally equal the ratio of expected Fisher arclength increments. The arguments below establish those points directly. They do not refute the exact mass-pushforward theorem, the conditional bit-production calculation, or either completed formation construction.

## Sources and actual review coverage

The full [Theory/SPEC.md](../../../Theory/SPEC.md) was read. The current [STATUS](../../STATUS.md), relevant entries of [the central claim appendix](../../../Theory/appendix_claim_ledger.tex), [adaptive source reconciliation](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-source-reconciliation.md), and the moving-coherence and inherited-geometry derivations in [adaptive loop and parent geometry](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-loop-parent-geometry.md) were consulted. The earlier [full-program mathematical reconciliation](../../research-plans/2026-09-11-full-program-mathematical-reconciliation.md) and portions of [the connected construction](../../reports/2026-09-10-full-gauge-vfe-rg-construction.md) were used for orientation. Historical blanket OPEN entries were not treated as evidence that subsequent constructions are missing.

The live [Research PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) and [Theory/PIFB2.tex](../../../Theory/PIFB2.tex) were byte-identical at inspection: SHA-256 `F80E6DABD9E5485649066E227E80BEFF1DD2B1082CF786BCDAEEDB8CBD080EC4`. This is source identity metadata, not mathematical evidence. The review read the main bundle/law/action setup, independent links and Wilson terms, source-constrained attention, the original-state ELBO obstruction, imposed kinetics, barycenters and formation licensing, shadows/RG/Ouroboros discussion, information clocks, the pullback/physical-interpretation register, and the correlated and RG appendices. The source ranges supplying the load-bearing assessment were approximately 175–594, 929–1005, 1533–1732, 1809–2159, and 3413–3941. Several long shell reads were truncated; targeted follow-ups covered the decisive mechanisms and proof statements. This was not a line-by-line audit of all exposition, bibliography, or physical phenomenology.

The [Research Holonomy note](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Holonomy.md>) was read, including its corrections to older curvature claims; the opening and latest formation-related parts of the Staged hierarchy formation and RG composability theme were consulted. The vault remained read-only. Its deleted `verified-ledger.md` was not restored or used.

For the large Theory chapters, coverage was at the stated theorem/assumption level: the typed setup and action laws in `02_geometry`; the vertical metric and velocity arguments in `05c_pullback_geometry`; the score-projection clock theorem, parameter-dependent-channel warning, and oriented semiconjugacy criterion in `05d_relational_inference`; all theorem/proposition/hypothesis statement headings and associated domains in `07d_neighborhood_parents`, `07e_inference_memory`, `07f_constructive_spatial_rg`, `07g_normalized_geometry`, `07h_geometry_pressure`, and `07i_thermodynamic_fisher`. Selected proof passages were read for the spatial positive Fisher chart, native regularity assumptions, strict-phase derivative bounds, and the bounded-boundary-ratio counterexample in the spatial/thermodynamic appendices. The thousands of lines of those appendices were not independently reconstructed in full. Existing spatial results were assessed for their relevance and scope, not reopened as base-transport work.

The standalone [grand-canonical formation note](../../../Theory/grand_canonical_meta_agent_formation.tex) was read through its mathematical derivations and conclusions; figure source was not audited. No new scientific calculation, numerical experiment, test suite, GPU work, Lean work, publication operation, or source modification was performed. The exact calculations reconstructed in this review are written in this document.

## Pointwise convention table and covariance

The following dictionary fixes conventions for this review. It does not replace the scientific model with an index-space gauge theory.

| Object | Type and convention |
|---|---|
| Base and principal bundle | A base \(\mathcal C\), a right principal \(G\)-bundle \(P\to\mathcal C\), and one fixed \(c_*\). The fiber \(P_{c_*}\) is a right \(G\)-torsor. |
| Associated fibers | Separate belief and model fibers \(E^b=P\times_{\rho_b}F_b\), \(E^m=P\times_{\rho_m}F_m\), with left actions \(\rho_b,\rho_m\). The convention is \([pg,v]=[p,\rho(g)v]\). Their law spaces need not have the same dimension or statistical family. |
| Sections and trivialization | Each agent has a local section and its pointwise value. Choosing \(p_i\in P_{c_*}\) gives coordinates. Under \(p_i'=p_i g_i\), coordinates obey \(v_i'=\rho(g_i)^{-1}v_i\). Write this coordinate action as \(A_i\). |
| Laws | Belief and model laws are separate measures. A bijection \(A_i\) acts by pushforward \(q_i'=A_{i\#}q_i\), with the corresponding action on model objects. Joint laws, posteriors, and recognition laws are additional typed objects, not reconstructed from their node marginals. |
| Connections | Belief/model connection choices are separate geometric data. At \(c_*\), only vertical variations are analyzed. No transport along a base path is used here. |
| Interaction links | \(\Omega_{ij}:E_j^b\to E_i^b\) transports from source \(j\) to target \(i\); analogous model links retain their own typing. These are independently specified dynamic links. Endpoint frames alone do not determine them. |
| Metric | For a regular probability family, the Fisher tensor is \(G_{ab}=\mathbb E[\partial_a\log q\partial_b\log q]\). For a nondegenerate Gaussian law, \(ds^2=d\mu^\top\Sigma^{-1}d\mu+\tfrac12\operatorname{tr}(\Sigma^{-1}d\Sigma\Sigma^{-1}d\Sigma)\). The covariance restriction is the affine-invariant SPD metric with factor \(1/2\). |
| Parent map | One declared normalized recognition-independent channel \(C\) pushes the generative, selected-posterior, and recognition laws, retaining all structural/random marks required by the next level. Equivariance is an additional checked property of that channel. |

For invertible linear coordinate changes, the Gaussian formulas follow immediately from \(x_i'=A_i x_i\):

\[
\mu_i'=A_i\mu_i,\qquad
\Sigma_i'=A_i\Sigma_i A_i^\top,\qquad
\Omega_{ij}'=A_i\Omega_{ij}A_j^{-1}.
\]

The last identity is forced by \(x_i=\Omega_{ij}x_j\). It gives

\[
\Omega_{ij\#}'q_j'=A_{i\#}(\Omega_{ij\#}q_j).
\]

KL is invariant under applying the same measurable bijection to both laws: if \(q\ll p\), the transformed Radon–Nikodym derivative is \((dq/dp)\circ A^{-1}\), so integration by pushforward gives \(D(A_\#q\Vert A_\#p)=D(q\Vert p)\), including extended values. Consequently each transported-law KL is coordinate invariant. The Gaussian Fisher expression is invariant under a fixed \(A_i\) by substituting \((A\Sigma A^\top)^{-1}=A^{-\top}\Sigma^{-1}A^{-1}\) and using cyclicity of trace. If \(A_i\) varies along an optimization path, ordinary coordinate derivatives acquire its derivative terms; they cannot be treated as the fixed-coordinate tangent transformation above.

This does not make arbitrary \(\mathrm{GL}\) transformations symmetries of every model. A fixed Euclidean metric is preserved only by its orthogonal group; a chosen proper reference, covariance restriction, likelihood, observation, or parameter family may have a smaller stabilizer. The Fisher and KL invariances just proved concern the correspondingly transformed laws. The distinction in PIFB2 between diagonal base-local action, common internal frame relabeling, and formal independent index-frame changes must be retained. Independent node coordinate changes are legitimate bookkeeping for the displayed identities; they do not by themselves license an additional physical gauge redundancy.

On overlaps the local associated coordinates obey transition maps inherited from the same principal bundle and its cocycle. At the fixed point, that ambient compatibility remains assumed rather than reconstructed from arbitrary node laws. All path dependence below concerns the agent-network links; it is not base-path transport.

For completeness, covariance-only affine-invariant SPD operations are

\[
\operatorname{Exp}_{\Sigma}(V)
=\Sigma^{1/2}\exp(\Sigma^{-1/2}V\Sigma^{-1/2})\Sigma^{1/2},
\]

\[
\operatorname{Log}_{\Sigma}(T)
=\Sigma^{1/2}\log(\Sigma^{-1/2}T\Sigma^{-1/2})\Sigma^{1/2},
\]

for \(\Sigma,T\succ0\) and \(V=V^\top\). These describe the covariance submanifold with means fixed, not the general joint Gaussian Fisher exponential when means move. No Euclidean covariance interpolation is substituted for a Riemannian geodesic in the review.

## Coherence, loop marks, and inherited dynamics

Let a connected finite agent graph have invertible links, and choose a root \(r\) and tree transports \(\tau_i:E_i^b\to E_r^b\). For every directed edge define

\[
H_{ij}=\tau_i\Omega_{ij}\tau_j^{-1}.
\]

Transported-law coherence \(q_i=\Omega_{ij\#}q_j\) is equivalent to a root law \(b=\tau_{i\#}q_i\) satisfying \(H_{ij\#}b=b\) for all retained edges. In one direction, transport each edge equality to the root. In the other, define \(q_i=\tau_i^{-1}{}_{\#}b\) and use the displayed stabilization equation. This proves the exact condition: network holonomy lies in the stabilizer of the root law. It does not require identity holonomy.

The minimal witness is a triangle with \(q_i=\mathcal N(0,I_2)\), \(\Omega_{12}=-I_2\), and the other forward links equal to \(I_2\), with inverse links on reversed edges. Every edge KL is zero, while the based triangle holonomy is \(-I_2\neq I_2\). This is an exact isotropy example, not a limiting approximation. Under coordinate changes \(H_{ij}'=A_rH_{ij}A_r^{-1}\), so the marked representation changes by root conjugacy. Boundary links between blocks have the corresponding two-root covariance. Discarding these marks is a distinct law-blind coarse-graining claim and requires its own hypotheses.

The sources already formulate moving coherence. If \(b=b(t)\) and \(H=H(t)\), differentiating \(H_\#b=b\) gives

\[
(H_\#-I)\dot b+(\dot H H^{-1})_{\mathcal B}(b)=0,
\]

where the second term is the infinitesimal pushforward action at the coherent law. Thus root-law learning and link learning are constrained together if exact coherence is claimed. Near-coherence requires a quantitative normal estimate instead of replacing this relation by independently chosen paths.

The relevant existing geometric reduction is likewise explicit. For a regular embedding \(x=\iota_\theta(y)\), full fine metric \(G\), and \(J=\partial_y\iota_\theta\), the inherited parent metric is \(G_{\rm par}=J^\top GJ\). Projecting a fine natural-gradient field \(-G^{-1}dU\) onto the moving tangent gives

\[
\dot y=-G_{\rm par}^{-1}\partial_y(U\circ\iota_\theta)
-G_{\rm par}^{-1}J^\top G\partial_\theta\iota_\theta\dot\theta.
\]

Indeed, multiply the tangent projection of \(J\dot y+\partial_\theta\iota_\theta\dot\theta=-G^{-1}dU+n\) by \(J^\top G\), with \(n\) normal. This requires a regular positive-definite visible metric and \(J\\) of full column rank. A compact regular tube, uniform normal gap, controlled actual forcing, and controlled motion of \(\theta\) are substantive hypotheses. Adaptive attention masks or rank changes do not satisfy them automatically.

In particular, if a retained-coordinate density factors as \(q_\theta(y,z)=r_\theta(y)\pi_\theta(z\mid y)\), differentiability and domination allowing conditional differentiation give

\[
\mathbb E[\partial_\theta\log\pi_\theta(Z\mid Y)\mid Y]=0,
\qquad
I(q_\theta)=I(r_\theta)+\mathbb E[I(\pi_\theta(\cdot\mid Y))].
\]

The score cross terms vanish by the first identity. Learning that changes \(\pi_\theta\) carries real hidden conditional Fisher information. Keeping only the metric of \(r_\theta\) would change the inherited learning dynamics. This is the existing adaptive result's relevant mechanism; it should be preserved in a nonlinear continuation.

## Exact correction: a proper reference has a proper pushforward

PIFB2 line 3634 specifies a proper or explicitly normalized reference \(\nu_s\). Line 3639 then states that \(R_\#\nu_s\) fails sigma-finiteness for a block of at least two children because affine barycenter fibers have infinite Lebesgue mass. The conclusion is false for the reference that was specified.

For every measurable map \(R:X\to Y\) and probability measure \(\nu\),

\[
\nu'(Y)=(R_\#\nu)(Y)=\nu(R^{-1}(Y))=1.
\]

Thus \(\nu'\) is finite and sigma-finite, regardless of fiber dimension. More generally, if \(w\geq0\) is integrable, then \(R_\#(w\nu)\ll R_\#\nu\): whenever \(\nu'(B)=0\), \(\nu(R^{-1}B)=0\), hence \(\int_{R^{-1}B}w,d\nu=0\). On standard Borel spaces, the density may be expressed as

\[
\frac{dR_\#(w\nu)}{dR_\#\nu}(y)=\mathbb E_\nu[w\mid R=y]
\quad \nu'\text{-almost everywhere}.
\]

To check the identity, integrate its right side over any measurable \(B\subseteq Y\) using the defining conditional-expectation identity. The result is \(\int_{R^{-1}B}w,d\nu\), exactly the pushed weighted mass. For \(w=e^{-F/T}\) with \(0<\int w,d\nu<\infty\), this supplies the exact coarse density relative to the pushed reference. A separate intrinsic reference is also permitted, but then its absolute-continuity condition must be checked. Neither choice is forced by a non-sigma-finiteness obstruction for probability \(\nu\).

The minimal example is \(\nu=\mathcal N(0,1)\otimes\mathcal N(0,1)\) and \(R(x_1,x_2)=(x_1+x_2)/2\). Its fibers are affine lines, yet \(R_\#\nu=\mathcal N(0,1/2)\). The infinite-fiber argument applies to raw unweighted Lebesgue measure on \(\mathbb R^2\), a different source measure. The correction removes that stated reason for rejecting a pushed reference. It leaves mass preservation, observable preservation, and the independent ansatz-closure problem intact.

## Exact correction: RMS information speed versus mean length

PIFB2 lines 1852–1863 study equal-weight Gaussian mean aggregation with the averaging covariance convention. Under a common precision \(\Lambda\), suppose

\[
\delta\mu_i=c+\epsilon_i,
\quad\mathbb E\langle c,\epsilon_i\rangle_\Lambda=0,
\quad\mathbb E\langle\epsilon_i,\epsilon_j\rangle_\Lambda=0\ (i\neq j),
\quad\mathbb E\|\epsilon_i\|_\Lambda^2=b,
\quad\mathbb E\|c\|_\Lambda^2=a.
\]

The common/idiosyncratic orthogonality and common second moment are made explicit here; cross-agent uncorrelated idiosyncratic terms alone do not imply the first assumption. With \(a+b>0\),

\[
\mathbb E\|\delta\mu_I\|_\Lambda^2=a+b/N,
\qquad
Z=\frac{a+b/N}{a+b}=f_{\rm coh}+(1-f_{\rm coh})/N.
\]

For these fixed-covariance pure mean steps, KL equals half the squared mean-sector Fisher length, exactly. Therefore \(Z\) is the expected KL-increment ratio, and \(\sqrt Z\) is the RMS length-increment ratio. Expected arclength uses \(\mathbb E\|\delta\mu\|_\Lambda\), which is not determined by this second moment calculation.

Take two independent Rademacher increments \(\epsilon_1,\epsilon_2\in\{-\delta,+\delta\}\), \(c=0\), scalar covariance one, and \(\delta>0\). A child always has Fisher path length \(\delta\) and KL \(\delta^2/2\). The averaged parent increment is zero with probability \(1/2\) and has magnitude \(\delta\) with probability \(1/2\). Its expected path length is \(\delta/2\), its expected KL is \(\delta^2/4\), and its RMS path length is \(\delta/\sqrt2\). Hence

\[
\frac{\mathbb E\Delta\tau_I}{\mathbb E\Delta\tau_i}=\frac12
\neq\frac1{\sqrt2}=\sqrt Z.
\]

Straight mean paths give the stated lengths in the declared mean-sector metric; \(\delta\) can be arbitrarily small. The example therefore survives a small-update restriction. Line 1861 should label its square-root ratio as RMS, or supply distributional hypotheses sufficient to establish the intended mean-clock statement. The expected bit-production calculation is not refuted by this example.

Separately, the clock-dissipation identity for one metric gradient flow with scalar rate \(\eta\), \(\dot x=-\eta G^{-1}dF\), is algebraically exact: \(\|\dot x\|_G^2=\eta^2\|dF\|_{G^{-1}}^2=-\eta\dot F\). It is a metric-speed statement. It does not imply that two independently recomputed fine/coarse vector fields are semiconjugate. The Theory clock chapter already distinguishes same-path, parameter-independent-channel Fisher contraction from a dynamical semiconjugacy \(dR(X)=aY\circ R\), and distinguishes both from physical time. A channel that itself depends on the varying parameter contributes its own score derivative and needs a different calculation. None of these extra identifications is required for the next pointwise formation theorem. A separate low-severity wording correction concerns PIFB2 line 1840: a Lorentzian metric is indefinite, but proper time along a future-oriented timelike path does not run backward. This wording is not used in the formation results.

## Assessment of the broader ideas and next action

PIFB2 already contains the useful starting mechanisms: independent links and possible loop frustration; coherent-law formation; covariance-sensitive aggregation; information accumulation along belief trajectories; correlated normalized models; exact measure pushforward; and a separate closure ansatz. These should be continued with their actual maturity levels. Its imposed rate ordering does not derive a slow manifold. A Lyapunov identity alone does not prove intermediate coherent groups form. Marginal barycenters do not reconstruct full parent joints. Small scalar energy residual alone does not bound force error. The completed recent constructions supply specific instances of the missing dynamical and conditional estimates; they do not turn the older broad interpretations into universal theorems.

The grand-canonical note supplies an exact softmax row for its canonical attention functional and an exact logistic occupation rule for its declared binary grand-canonical functional. Occupation costs, chemical potentials, candidate parents, and any Landau reduction are added model inputs. Stationarity of those probabilities is not itself a theorem that nested coherent groups attract under the coupled VFE dynamics. The note offers a possible later extension if changing population is selected as the question; it is not a prerequisite for continuing fixed-population dynamical formation.

The large geometric/RG chapters supply additional established machinery: compatible ambient-law parents; normalized memory mechanisms and conditional histories; strict-phase versus tied-label Fisher scaling; exact full-label statistical experiments; and fixed-depth regular Fisher charts. Their hypotheses matter. A fixed finite-depth metric floor is not a depth-uniform inverse, a full-history law need not admit a finite Markov closure, equal limiting pressure densities do not identify finite laws, and law stabilization does not force a flat network. The current pointwise question does not require reopening those spatial or thermodynamic construction programs.

The recommended bounded next theorem is one common finite nonlinear adaptive cyclic family, initially at two formation interfaces. Require a learned model parameter to change an actual discarded conditional by a fixed positive amount over the declared interval, retain the loop and boundary marks needed by both parents, and derive every parent from the same normalized generative/recognition channel with the full inherited score and metric. Keep supplied interaction contrast, compatible observations, common microscopic kinetics, compact parameter regions, and finite depth as explicit admissible assumptions. Do not add unique grouping, population birth/death, physical clocks, or an infinite tower to this theorem.

Its minimal unresolved geometric obligation is a uniform moving-coherence estimate for that one family: exhibit a regular tube and a normal restoring gap along the learned parameter path, then bound the actual normal forcing and the hidden-conditional/force discrepancy at the second interface. The existing moving-embedding and score-decomposition formulas above state what must be controlled. They do not establish those family-specific bounds. Alternatively, a precise counterexample showing that the proposed nonlinear family loses the required gap or conditional regularity would materially change the next-phase choice. A new abstract bundle dictionary, another fixed-coefficient example, or a marginal-only learning calculation would not settle this interface.

This review therefore returns two reconstructed manuscript corrections and a scoped next obligation. It does not certify the full manuscript, close a formal ledger, or assert that nonlinear adaptive formation has already been proved. The next substantive action is to select the existing compact family and learned parameter seam, then derive its two-interface moving-coherence bounds before generalizing the finite-depth statement.
