"""Check the finite symbolic discriminator used in the next-phase review."""

from __future__ import annotations

import hashlib
import json
import platform
import sys
from pathlib import Path

import sympy as sp


def main() -> None:
    """Check the derivative identities; no hierarchy or trajectory is simulated."""
    x = sp.Symbol("x", real=True)
    a, kappa, tau, nu, t = sp.symbols("a kappa tau nu t", positive=True)
    slope = sp.Symbol("slope", real=True)
    U = (kappa + 1) * x**2 / 2 + a**2 / 2 - tau * sp.log(sp.cosh(a*x/tau))
    grad = (kappa + 1)*x - a*sp.tanh(a*x/tau)
    hessian = kappa + 1 - a**2/(tau*sp.cosh(a*x/tau)**2)
    lag = slope*(1-sp.exp(-nu*t))/(nu*tau)
    checks = {
        "gradient_residual": sp.simplify(sp.diff(U, x)-grad),
        "hessian_residual": sp.simplify(sp.diff(U, x, 2)-hessian),
        "center_curvature_residual": sp.simplify(sp.diff(U, x, 2).subs(x, 0)-(kappa+1-a**2/tau)),
        "constant_slope_lag_residual": sp.simplify(sp.diff(lag, t)+nu*lag-slope/tau),
    }
    curvature = sp.diff(U, x, 2).subs({x: 0, kappa: 1, a: 2, tau: 1})
    if any(value != 0 for value in checks.values()) or curvature != -2:
        raise AssertionError((checks, curvature))
    source = Path(__file__).resolve()
    record = {
        "scope": "Four scalar symbolic residuals and one exact instability value; no formation theorem or old science rerun",
        "python": platform.python_version(),
        "executable": sys.executable,
        "sympy": sp.__version__,
        "script_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "residuals": {name: str(value) for name, value in checks.items()},
        "center_curvature_kappa1_a2_tau1": str(curvature),
        "passed": True,
    }
    output = source.with_name("attention-admission-check.json")
    output.write_text(json.dumps(record, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
