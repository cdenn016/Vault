# Attention stability and lag in the next-phase admission

September 13, 2026. This note reconstructs existing attention formulas and derives two small discriminators for choosing the next research obligation. It does not prove a new coalescence hierarchy.

## Source continuity and probabilistic meaning

The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `eq:rg_reduced_hessian`, already gives the attention-weighted Hessian minus the gradient covariance. The existing [local attraction proof](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/coherence-attraction-and-dynamical-rg.md), equations (2)–(6), already handles optimized positive attention near a regular coherent manifold. The covariance vanishes at exact coherence because every compared divergence has zero differential there. Neither formula is new here.

[Theory/05b](../../../Theory/05b_local_collective_elbo.tex), `prop:obs-attention-elbo` and `eq:obs-attention-replicator`, supplies the normalized source-label model and categorical Fisher dynamics. It distinguishes a posterior row conditional on a latent configuration from a recognition row constrained to be constant in that configuration. [Theory/07b](../../../Theory/07b_agent_network_rg.tex), `sec:rg-meta-attention`, already supplies recursive event-law and marked-kernel integration. A live neighbor's recognition law cannot be inserted into a fixed original-state generative factor without changing that construction.

## A restoring-force condition that can actually fail

Let E_j(x) be C2 finite functions on a fixed finite source set, let pi_j>0 sum to one, and fix tau>0. Define

\[
 A(x)=-\tau\log\sum_j\pi_j e^{-E_j(x)/\tau},
 \qquad b_j(x)=\frac{\pi_j e^{-E_j(x)/\tau}}{\sum_k\pi_k e^{-E_k(x)/\tau}}.
 \tag{R1}
\]

Differentiating the finite sum gives

\[
 db_j=-\tau^{-1}b_j\left(dE_j-\sum_kb_kdE_k\right),
 \qquad dA=\sum_jb_jdE_j,
 \tag{R2}
\]

and therefore

\[
 D^2 A=\sum_jb_jD^2E_j-
 \tau^{-1}\operatorname{Cov}_{b}(dE_j,dE_j).
 \tag{R3}
\]

These are coordinate formulas in a fixed chart. A geometric normal-stability claim uses the Hessian and the normal projection for the declared metric; it is not inferred from untransformed Euclidean eigenvalues. For a chosen unit normal vector v, the negative correction is exactly tau^{-1} Var_b(dE_j[v]). Thus a sufficient local admission for a full potential U=U_other+A is a uniform lower bound

\[
 D^2 U_{\mathrm{other}}[v,v]+\sum_jb_jD^2E_j[v,v]
 -\tau^{-1}\operatorname{Var}_b(dE_j[v])\ge m>0
 \tag{R4}
\]

on the actual visited tube and parameter range. At a stationary coherent manifold the coordinate and covariant Hessians agree. Away from it a general metric requires its connection terms. Positivity at a single point, or only for frozen attention weights, does not establish (R4) on that tube. This is the finite-source version of the cumulant derivative identity; see Wainwright and Jordan, Section 3.5.1, [author manuscript](https://www.cs.princeton.edu/courses/archive/fall11/cos597C/reading/WainwrightJordan2008.pdf). The calculation above supplies the application directly.

A normalized one-coordinate model shows the distinction. Let kappa>0, a>0, tau>0, with

\[
 X\sim N(0,\tau/\kappa),\qquad
 J\sim\operatorname{Uniform}\{-1,1\},\qquad
 O\mid X=x,J=j\sim N(x-ja,\tau).
 \tag{R5}
\]

The prior and both observation kernels are normalized. At the record O=0, the source posterior conditional on x has the row (R1) with E_j=(x-ja)^2/2. Marginalizing J gives, up to an x-independent constant, the scaled negative posterior log density

\[
 U(x)=\frac{\kappa+1}{2}x^2+\frac{a^2}{2}
       -\tau\log\cosh(ax/\tau).
 \tag{R6}
\]

Its evidence density is positive and finite:

\[
 p_O(0)=\frac{\exp[-a^2/(2\tau(1+1/\kappa))]}
 {\sqrt{2\pi\tau(1+1/\kappa)}}.
 \tag{R7}
\]

This follows by Gaussian convolution for either value of J. The posterior is proper, since its log density has a negative quadratic tail. Nevertheless

\[
 U''(0)=\kappa+1-\frac{a^2}{\tau}.
 \tag{R8}
\]

For kappa=1, a=2, tau=1 this is -2, although every source energy has second derivative +1 and the prior contributes +1. The center is unstable for gradient descent with any positive scalar mobility. This is a discriminator against inferring a restoring gap from positive frozen-source curvatures. It is not a counterexample to the earlier near-coherence theorem: the two fixed templates cannot agree at the same x when a>0. It does not demonstrate network formation, failure of normalized VFE, or a defect in the completed adaptive witness.

## If attention evolves at a finite rate

For one recognition row with fixed positive pi, let the actual expected source costs be e_j(t). Consider the already-derived categorical Fisher equation with a fixed rate nu>0,

\[
 \dot b_j=-\nu b_j(c_j-\bar c),\qquad
 c_j=\log(b_j/\pi_j)+e_j/\tau,
 \qquad\bar c=\sum_kb_kc_k.
 \tag{R9}
\]

Assume a strictly interior initial row, finite differentiable e_j, and finite horizon. Subtracting two logarithmic derivatives gives an exact closed identity,

\[
 z_{jk}=\log\frac{b_j\pi_k}{b_k\pi_j},\qquad
 \dot z_{jk}=-\nu\left(z_{jk}+\frac{e_j-e_k}{\tau}\right).
 \tag{R10}
\]

The instantaneous optimum has z*_{jk}=-(e_j-e_k)/tau. Its lag d_{jk}=z_{jk}-z*_{jk} satisfies

\[
 \dot d_{jk}=-\nu d_{jk}+\frac{\dot e_j-\dot e_k}{\tau},
 \qquad
 |d_{jk}(t)|\le e^{-\nu t}|d_{jk}(0)|
 +\frac{1-e^{-\nu t}}{\nu\tau}
   \sup_{0\le s\le t}|\dot e_j(s)-\dot e_k(s)|.
 \tag{R11}
\]

The bound is variation of constants. It neither assumes nor proves that the changing costs are slow; that must be derived from the coupled law/model/link process. In a stochastic sample path, pathwise derivatives of costs may not exist, so (R11) applies to differentiable expected costs, or a separately justified finite-variation input, rather than directly to Brownian samples. Changing priors or temperatures add their derivatives to the target odds.

If all odds lags relative to one fixed reference source are at most delta, the normalized rows obey exp(-2delta)<=b_j/b*_j<=exp(2delta). Indeed b is the normalized exponential tilt of b* by logits with absolute value at most delta. Consequently KL(b||b*)<=2delta. This coarse bound needs no uniform lower probability floor at the finite comparison time; the stronger dynamics and metric estimates may still require one.

The next-phase construction may integrate the conditional posterior labels exactly, or retain finite-rate recognition rows and pay a bound such as (R11). These are different declared dynamics. Neither option permits regenerating a parent softmax from averaged divergences when the exact parent channel instead carries an event law, evidence weights, and conditional marks.

## What this investigation adds

The restored source chain, the explicit proper normalized instability example (R5)–(R8), and the finite-rate lag admission (R10)–(R11) make the next proof obligation testable. They support investigating nonlinear adaptive cyclic formation with controlled attention. They do not prove that the required normal gap, conditional mixing, or two successive parent reductions coexist in such a model. Those are the construction's remaining obligations. A symbolic diagnostic checks the displayed scalar derivatives and the constant-slope solution of the lag equation; its finite output is supporting algebra, not a general formation proof.
