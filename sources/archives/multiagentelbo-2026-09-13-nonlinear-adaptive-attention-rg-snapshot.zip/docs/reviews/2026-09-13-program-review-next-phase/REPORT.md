# Program review and the next formation phase

September 13, 2026. The next research phase should construct **nonlinear adaptive cyclic coalescence with the existing normalized source-attention mechanism**, first through two actual reductions and then through the finite-depth induction. The completed nonlinear and adaptive results supply different parts of this construction. The missing step is to prove that their conditional, dynamical and model-learning estimates hold together in one admitted model. The investigation below establishes useful conditional estimates for that step; it does not establish the proposed formation theorem.

## Scope and reading map

The starting repository revision is `03240a7fa7941400a36c74fef8d5e479dddffe31`. The review began with [STATUS](../../STATUS.md), the complete [Theory specification](../../../Theory/SPEC.md), the [current RG record](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/RG-COMPLETION.md), the relevant live Research synthesis pages and [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>). The live and repository PIFB2 copies had identical bytes when inspected. The [source manifest](source-manifest.json) records the source snapshot; it identifies the reading and supplies no mathematical acceptance criterion.

“Program review” here means a source and dependency assessment across the completed program, with targeted reconstruction of consequential formulas. It does not mean every equation in the Theory chapters, every historical proof, or every experiment was independently rerun. The coverage tables in the [foundations review](foundations-review.md), [PIFB2 and geometry review](pifb-geometry-review.md), and [dynamics review](dynamics-frontier-review.md) identify what was read and what was reconstructed. The [separate check](independent-verification.md) assesses the material findings and new analytical estimates. Historical numerical records retain their original revision and mathematical scope.

All proposed dynamics take place over one fixed base point c_*. Agents remain local sections in the ambient bundle model, and independent interaction links may carry nontrivial agent-network holonomy there. Base paths, neighborhood transport and connection descent remain deferred. The proposed continuation derives coalescence from the specified VFE dynamics. It does not add capability, storage, unique-partition or permanent-membership requirements.

## What the completed program provides

The mathematical foundation is substantially more developed than an alignment heuristic. It starts with a normalized joint law, a correlated recognition law and one collective variational functional. Local objectives are compatible with that collective functional under their stated conditional-update hypotheses. They are not overlapping ELBOs whose sum is automatically another ELBO. Dependence selection and kinetic choice remain additional data when the primitives do not determine them.

| Layer | Existing result and its scope | Implication for the next phase |
| --- | --- | --- |
| Normalized probability and VFE | [Theory/03](../../../Theory/03_probability.tex), [04](../../../Theory/04_generative.tex), [05](../../../Theory/05_elbo.tex) and [05b](../../../Theory/05b_local_collective_elbo.tex) define joint laws, fixed generative records, correlated recognition and the exact local/collective accounting. | Build the next model inside these types. Normalization alone does not select its kinetics or a hierarchy. |
| Exact parent laws | [Theory/06](../../../Theory/06_general_coarsegraining.tex), [07](../../../Theory/07_general_renormalization.tex) and [07b](../../../Theory/07b_agent_network_rg.tex) give common-channel pushforward, conditional KL, reference/evidence push and exact composition. | A normalized parent already exists for an admitted channel. Its autonomous dynamics require a separate argument. |
| Complete graph and geometric parents | [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex) and the subsequent parent chapters retain correlated event laws, induced interactions, loop data and sufficient marks. Their geometric closure results have explicit rank, smoothness and compatibility assumptions. | Retain the required joint marks through recursion. Averaged links or independently regenerated rows need not suffice. The base-dependent constructions remain outside this phase. |
| Static Gaussian and information geometry | The current specification and claim appendix contain the conditional Fisher-defect, Gaussian/Kron, comparison and quotient results linked in the investigator reports. Some September 11 “next” items have since been resolved in these stated classes. | Do not restart a classification already completed under the same hypotheses. These results do not by themselves prove formation. |
| Finite experiments and operational parents | The earlier finite, parity, retention, resource and native-episode investigations establish their recorded positive and negative results under specified observation and retention contracts. | Their obstructions constrain those experiments. They do not prohibit coalescence in an independent dynamic-link model or impose a resource gate on it. |
| Common-kinetics dynamical RG | [The Gaussian bridge](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/translation-link-conditional-bridge.md) joins derived collective rates, actual formation episodes, transient conditional-VFE control and two reductions with supplied interaction contrast. | A common kinetic prescription can yield separated collective dynamics. No claim that the objective uniquely determines mobility is needed. |
| Nonlinear finite-depth RG | [The nonlinear completion](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/finite-depth-completion.md) gives every prescribed finite L>=3 an admitted compact family with actual successive coalescence, exact normalized nonlinear parents and quantitative conditional, force and path bounds. | Nonlinear parent formation already exists. Its coefficients are fixed; it does not settle changing hidden conditionals under model learning. |
| Adaptive cyclic finite-depth RG | [The adaptive completion](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-cyclic-completion.md) gives every prescribed finite L>=2 a Gaussian cyclic family, genuine normalized model learning, changed hidden conditionals, independently learning parents and separate conditional/path bounds. | The remaining join is nonlinear adaptive formation. Own-law parent learning and moving-score identities are already available. |

The latest adaptive witness retains all loops, and for L=2 has 6 -> 2 -> 1 agents and 19 -> 9 -> 8 configuration coordinates. Its changing coefficient multiplies supplied edge strengths: normalized source rows stay fixed. Compatible observations, calibration-assisted scalar learning, a proper correlated reference and Gaussian closure are explicit assumptions. Appreciable parameter motion occurs mostly after the short formation windows, while the error bounds continue over the learning interval. These restrictions describe the theorem actually proved; they do not retract it or make learning every microscopic contrast a new obligation.

The frozen nonlinear result and the adaptive Gaussian result cannot be combined by citing them together. The former holds its model parameter fixed. The latter uses a closed covariance equation unavailable to a general nonlinear density. This is the specific dependency to address.

## What PIFB2 contributes

PIFB2 already formulates the mechanisms relevant to the continuation. Its source-mixture derivation, correlated state/configuration extension, formation discussion, information-clock sections and rigorous RG appendix contain normalized lifts, consensus ideas, moving attention, effective actions and conditional closure questions. The Gibbs configuration lift constructs a law over complete belief configurations. It does not convert a live-peer recognition-dependent consensus functional into the original-state ELBO excluded by the manuscript's own theorem. The Theory source-label model gives a direct normalized construction at a declared probability level.

The distinction between its attention laws matters. A source posterior conditional on a configuration has weights proportional to pi_j exp(-E_j(x)/tau). A recognition row constrained to be independent of the configuration instead optimizes against expected costs. In general the latter is not the expectation of the former. Parent attention is the pushforward of the complete receiver/source event law, with its evidence weights and conditional marks. This construction already exists in Theory/05b and 07b and should be carried into formation.

The clock proposal also already exists. Under its averaging covariance convention and uncorrelated idiosyncratic increments, expected quadratic information production has the familiar coherent-plus-averaged-noise ratio. That is distinct from a relaxation eigenvalue, accumulated Fisher arc length and physical proper time. None is needed as an extra acceptance test for the next finite dynamical construction.

Independent dynamic links can relax disagreement without forcing identity holonomy. Agreement imposes invariance of the compared law under the loop action; a stabilizer can remain. A flattening penalty is a separate model choice. The current constructions and the existing [source reconciliation](../../derivations/2026-09-11-meta-agent-formation-frontier-and-locality/adaptive-source-reconciliation.md) preserve this distinction.

## Localized corrections identified in the sources

The findings below concern particular displayed formulas or interpretations. None of the supplied counterexamples refutes the exact common-channel theorem or the admitted September 12 formation witnesses. The independent assessment and its conditioning qualifications are recorded in [independent-verification.md](independent-verification.md).

| Finding | Evidence and consequence | Required correction |
| --- | --- | --- |
| Medium: random event mass and membership are factorized without the needed qualification | Theory/07c, `eq:full-graph-edge-pushforward` and `eq:full-graph-correlated-edge-pushforward`, place eta outside an expectation over a structural state that may contain eta. In an equiprobable two-state example, the active fine edge always maps A -> B, so its exact coarse mass is 1; multiplying the separate averages gives 1/2. | For the unconditional joint-law reading, use sum E[eta_ij M(I,J given i,j,R)]. Alternatively state the fine-state conditioning or independence that makes eta fixed. Under that restricted reading the defect does not apply. |
| Medium: a proper reference pushforward is declared non-sigma-finite | PIFB2's “Exact pushforward RG” paragraph first chooses a proper reference nu_s, then says its barycenter pushforward cannot be sigma-finite because affine fibers have infinite volume. A probability pushforward has total mass 1. With two standard normal means, their barycenter has the proper N(0,1/2) law. | Restrict the infinite-fiber warning to the raw improper Lebesgue/Haar reference where applicable. For a proper nu, a Gibbs-weighted push has density E_nu[exp(-F/T) given R] relative to R_*nu. An intrinsic parent reference is still a legitimate separate choice. |
| Medium: expected quadratic-clock ratios are converted into expected arc-clock ratios by a square root | Immediately after `prop:meta_clock_slowdown`, PIFB2 takes the square root of the expected KL ratio as the corresponding primary-clock ratio. For two independent equiprobable unit signed mean increments with unit covariance, child expected length is 1 and parent expected length is 1/2. The root-mean-square ratio is 1/sqrt(2). | Call the square-root quantity an RMS step-length ratio, or add distributional hypotheses for the expected arc-length ratio. The conditional expected-bit calculation is a different statement and survives this example. |

The first issue is especially relevant if later memberships depend on the same state as attention. Its general structural-channel theorem already has the correct joint-law form. The second changes a justification for the reference choice, not mass preservation by pushforward. The third changes the clock interpretation, not the normalized parent construction. No Theory or PIFB2 source was edited during this review.

## Analytical progress from the investigation

### Attention admission and finite-rate lag

The [attention note](attention-admission.md) reconstructs PIFB2's existing reduced Hessian,

\[
D^2\left[-\tau\log\sum_j\pi_j e^{-E_j/\tau}\right]
=\mathbb E_b D^2E_j-\tau^{-1}\operatorname{Cov}_b(dE_j,dE_j).
\]

The covariance correction can remove positive restoring curvature. A proper normalized Gaussian observation mixture has full potential U(x)=(kappa+1)x^2/2+a^2/2-tau log cosh(ax/tau), with U''(0)=kappa+1-a^2/tau. At (kappa,a,tau)=(1,2,1), this is -2 despite positive curvature for each fixed source and the prior. This challenges only an unrestricted frozen-weight-to-moving-weight inference: the incompatible templates do not satisfy the earlier exact-coherence hypotheses. At exact coherence the source gradients can all vanish, eliminating the covariance term there. The actual entrance tube still needs a uniform bound. The underlying cumulant identity is also standard; see Wainwright and Jordan, Section 3.5.1 of the [author manuscript](https://www.cs.princeton.edu/courses/archive/fall11/cos597C/reading/WainwrightJordan2008.pdf).

For the existing categorical Fisher flow with rate nu and fixed prior/temperature, the log-odds lag from the instantaneous optimum obeys an exact scalar equation. If d is that lag and e_j are differentiable expected costs,

\[
\dot d_{jk}=-\nu d_{jk}+\frac{\dot e_j-\dot e_k}{\tau}.
\]

Variation of constants bounds the lag by its decaying initial value plus sup|dot e_j-dot e_k|/(nu tau). This does not show that the coupled costs vary slowly. It specifies the quantity to derive if finite-rate recognition attention is retained. Integrating posterior source labels exactly and evolving a separate recognition row are different choices of dynamics.

### A nonlinear dissipation budget that passes to exact parents

The new derivation in [dynamics-frontier-review.md](dynamics-frontier-review.md), D1–D12, assumes a normalized tilt p_a proportional to exp(-aV/T)mu with V>=0 and a>0. Suppose Z(a/2)/Z(a)<=R uniformly on the actual parameter interval, the reference and retention channels are parameter independent, and the displayed regularity assumptions hold. For an exact parent pi_a and its actual reversible diffusion, let H=T KL(r||pi_a) and I be relative Fisher information in the inherited mobility. Define B(t)=integral |dot a|/a. Then

\[
T^2\int_{t_0}^t I(u)du
\le e^{2B(t)}\left[H(t_0)+2T\log R\right].
\]

The proof differentiates the normalized score, bounds its conditional expectation by the entropy inequality, and uses an integrating factor. Jensen's inequality passes the same partition-ratio bound to every fixed exact channel. Data processing handles actual successive activation when the current parameter, target and complete law are pushed consistently. The estimate allows a parent to update its own parameter from its own law; it is not restricted to an externally scheduled parameter.

On a time interval of order 1/epsilon, a relative variation bound keeps B finite. The estimate avoids charging unrelated calibration energy to conditional dissipation. It also has no explicit exponential in the largest stiffness. This does not make the right side uniformly small automatically: the actual activation entropy H, the ratio R and the variation B still require bounds in the chosen regime. A nonquadratic uniformly Hessian-comparable potential supplies one explicit class with stiffness-independent R; that example is a budget witness, not the new cyclic formation model.

### Conditional KL and the actual parent learning score

D13–D26 use a genuine product conditional split, a uniform conditional logarithmic-Sobolev rate lambda, a mixed-derivative bound Gamma, and a two-sided exponential-moment bound for the centered conditional parameter score. If its sub-gamma constants are v,b, the scalar model metric is m(a), and omega=sqrt(m)|dot a| satisfies b omega<=lambda/2, the derived estimate is

\[
\Delta(t)\le e^{-\lambda(t-t_0)/2}\Delta(t_0)
+\frac{\Gamma^2}{T\lambda^2}\mathcal B_y
+\frac{2v\omega_*^2}{\lambda^2},
\]

where Delta is the actual expected conditional KL, B_y=T^2 integral I_y and omega_* is the maximum metric speed on the interval. The preceding budget can bound B_y when its additional tilt assumptions hold. The complete fine and parent score covectors at the same retained law and parameter satisfy

\[
\frac{|g-g_{\mathrm{parent}}|}{\sqrt m}
\le T\left(\sqrt{2v\Delta}+b\Delta\right).
\]

The score bound admits quadratic tails and recovers the Gaussian precision example. A blanket bounded-score or sub-Gaussian-score assumption would exclude that example. It is also an instantaneous comparison; an independently evolving parent's parameter and path need stability estimates in addition. Existing moving-conditional balance equations and score identities are credited explicitly in the derivation. These estimates extend that machinery rather than claiming to discover conditional memory.

The assumptions remain substantive. The existing compact principal-coordinate construction has glued faces, so its true boundary-current and off-tube entropy terms must be restored before applying a product-space estimate. A local normal Hessian is not automatically a global conditional logarithmic-Sobolev bound. Small one-time conditional KL also does not identify a projected path with an autonomous Markov path. Classical conditional-expectation reductions illustrate these distinctions under their own assumptions; see Legoll and Lelièvre's [primary paper](https://arxiv.org/abs/0906.4865). That paper does not establish an adaptive hierarchy.

## The next construction and its decisive obligations

The recommended first target is one admitted finite cyclic model with two actual coalescence episodes, exact normalized nonlinear parents and a learned generative parameter that changes an eliminated conditional. Use the existing source-label construction and preserve supplied microscopic contrasts. Specify the joint law, reference, observation records, recognition family, kinetic metrics and full parameter score before deriving dynamics. Retain all varying evidence and restricted-family constants.

A useful additional discriminator is a normalized source row changing by a stated positive total-variation amount during the common formation-and-learning interval. This is a proposed strengthening that would make the attention mechanism substantive. It is not a retrospective requirement on the completed adaptive theorem, and it does not require learning all interaction weights. The posterior/recognition meaning of that row and the interval must be declared. If only vanishing row variation can be shown, label the result as a perturbative extension.

| Obligation | What must be derived in the chosen model |
| --- | --- |
| Admission and coherence tube | A proper normalized joint, a nonempty admitted initial-law neighborhood, the full metric transverse Hessian including the attention covariance correction, and an invariant or quantitatively controlled entrance/formation tube. |
| Conditional control through learning | Conditional mixing and score-moment constants, actual activation entropies, the partition-ratio or another sufficient dissipation budget, and any compact boundary/tail terms on the same time interval. |
| Own-law parent feedback | The complete inherited score and metric, force and score mismatch estimates, and stability for an independently evolving parent initialized from the actual retained law. |
| Actual successive formation | Two separated coalescence episodes from the stated common kinetics and supplied interaction contrasts, with distinct conditional-VFE and path estimates in one simultaneous regime. |
| Recursive continuation | Exact composition of normalized marked parents, sufficient source/occupancy/loop marks, and an induction allowing constants to depend on each prescribed finite depth. |

The first calculation that will decide feasibility is the full reduced normal Hessian and conditional score law of a concrete normalized nonlinear cyclic example. A loss of restoring margin or uncontrolled score moments should lead to a precisely narrower family. It would not prove that VFE-driven coalescence is generally impossible. Conversely, a small nonlinear perturbation of the Gaussian example does not justify claims about unrestricted attention, arbitrary forcing or all gauge groups.

After this join, state-dependent membership and merger histories are a natural subsequent direction. Their exact laws must retain the dependence between attention and assignment, and any memory needed by future decisions. Universal membership selection, unbounded depth and base transport remain separate questions. None is required to finish the next finite model.

## Evidence and handoff

The review supplies source-level reconciliation, localized analytical counterexamples, the attention admission calculation and the conditional lemmas above. Their proofs and independent assessment are linked here. The saved [symbolic output](attention-admission-check.json) records four exactly zero scalar residuals and the curvature value -2 under Python 3.14.4 and SymPy 1.14.0; this is supporting algebra, not a simulated formation result or a current manuscript certificate.

The installed verification skill's target is missing, as recorded in [scope.md](scope.md). The separate analytical reconstruction remains available, but this review does not claim a certificate from that unavailable workflow. Historical evidence was not rebound to current files. No old science, full suite, GPU computation, Lean work or prohibited tamper check was run. The manuscript and Research vault were consulted read-only. The only updates outside this review directory are the existing status/progress pointers, the research record and the daily change log.

The final [document check](document-validation.json) found no errors across 150 source entries, 76 local file-link occurrences and the three independently reviewed report bindings. The two changed files inside that source manifest are the intentional RG progress and research-record updates; scientific and manuscript source bytes remain unchanged. This is document validation, not mathematical evidence.

The research handoff is the concrete model admission above. The investigation has completed the requested review and identified a supported next step; the nonlinear adaptive attention construction remains open.
