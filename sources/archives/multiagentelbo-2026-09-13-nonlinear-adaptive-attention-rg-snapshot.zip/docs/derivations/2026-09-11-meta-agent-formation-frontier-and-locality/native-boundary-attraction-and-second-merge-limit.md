# Native boundary attraction and the second-merge limit

September 12, 2026. The fixed-pair native learner has a locally attracting boundary limit at positive child and block variances but vanishing link variance. Its parent merge readout is approximately 0.4872933347, below one half. A nearby open family of strictly positive full ancestry priors retains a corresponding physical attraction region with a persistently preferred first-level pair and a split-favored second-level diagnostic. This is a local result; the unchanged unit preparation has not been proved to enter that region.

The numerical unit-start trajectory and the exact local result are separate evidence. One diagnostic trajectory through native time 20 detected no merge crossing and ended near 0.45565. A stationary solver seeded from that endpoint failed its evaluation limit while approaching zero link variance. A subsequent exact calculation addressed that distinct boundary problem and enclosed its critical point. The failed interior attempt is retained and does not become an interior-stationarity certificate.

## 1. Source, state and scope

[The native shared-parent learner](shared-parent-native-learning-and-memory.md), Section 4, defines one normalized negative ELBO, the complete-model Fisher metric, the full recognition Fisher flow and their finite inference lag. [The transported prior](transported-parent-priors-and-induced-couplings.md), Section 4, carries those equations to the current primitive energies. [The second-level calculation](second-level-prior-learning-and-agreement.md) defines the actual parent-cut diagnostic and its initial response. [The scale classification](second-merge-scale-regime-and-native-barrier.md) supplies a static favorable interval but explicitly does not make its common-scale curve a native trajectory. The present calculation addresses that dynamical gap.

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, distinguishes the barycenter, a coherence detector and a license involving free energy and organizational cost. The [operational wiki definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) retains joint law, evaluator, access, marks and memory. None of those requirements is removed by the local dynamical result below. All work stays at one base point, with the original ordered records, priors, graph and two channels.

Begin with the boundary prior pi_P=1 for P={{0,1},{2,3}}, keeping all four of its root decorations. This is a limiting reference for a later positive-prior continuation, rather than the full positive-prior target. The count coordinate is redundant in this reference. Keep s=1 and the matched root variance v=1. Write a_j for the three model variances and r_j for the three recognition variances, j=a,b,c. The exact six-variable equations are

\[
 \dot a_j=\frac{\langle E_j\rangle_{Q_r}}{d_j}-a_j,

 \dot r_j=r_j\left(1-\frac{r_j}{a_j}\right),
 (d_a,d_b,d_c)=(16,8,16).
 \tag{1}
\]

The b denominator is eight because both the prior and recognition have k=2 in this limiting reference. It is not the replacement to use for uncertain ancestry; Section 7 restores that dependence. The positive-variance native existence theorem remains applicable for every finite time.

Let Z_P(r) be the normalized pair evidence. Differentiating its Gaussian variance normalizers gives

\[
 \langle E_j\rangle_{Q_r}
 =d_jr_j+2r_j^2\partial_{r_j}\log Z_P(r),

 \dot a_j=r_j-a_j+\frac{2r_j^2}{d_j}\partial_{r_j}\log Z_P(r).
 \tag{2}
\]

This identity retains the recognition variances in the moments. Setting r=a in the dynamics would remove the native lag.

## 2. The two numerical diagnostics

The first calculation integrated (1) in log variances over the declared native interval [0,20], starting with every model and recognition variance equal to one. It used the installed SciPy 1.16.0 DOP853 solver, relative tolerance 10^-9, absolute tolerance 10^-11 and maximum numerical step 0.1. Log coordinates preserve positivity under evaluation. The right-hand side used all four decorations, represented by their three distinct covariance maps and exact multiplicities. Its unit evidence, moments and merge value match the saved exact values within the stated floating-point checks.

| Native time | Model a,b,c | Recognition a,b,c | Numerical parent merge probability |
| ---: | --- | --- | ---: |
| 0 | 1, 1, 1 | 1, 1, 1 | 0.2938789175 |
| 4 | 0.2887602, 0.6063739, 0.6788293 | 0.3620996, 0.6733831, 0.7350123 | 0.3257793984 |
| 12 | 0.0933850, 0.3051180, 0.4053017 | 0.1013099, 0.3262739, 0.4269995 | 0.3987221437 |
| 20 | 0.0666962, 0.2065682, 0.2954243 | 0.0683811, 0.2144894, 0.3049687 | 0.4556486287 |

The solver took 204 accepted steps and reported no half-merge event. All accepted states and its dense polynomial representation are saved in [pilot-trajectory.json](evidence/fixed-pair-native/pilot-trajectory.json). The smallest recorded ratio of a signed Gaussian sum to the sum of absolute terms was approximately 3.94 x 10^-5. These facts describe the numerical run. They are not a rigorous enclosure of the continuous solution, a proof of no crossing between evaluations or a long-time result. No horizon extension was run.

The second calculation solved the stationary moment equations from the single saved time-20 model endpoint. The solver exhausted its 150-evaluation limit, reporting 152 calls, and returned approximately (a,b,c)=(0.0569444765,0.3092749578,6.98 x 10^-11). It failed the predeclared interior guard c>10^-8. Its normalized moment residual was about 1.73 x 10^-11, but this small number is compatible with a boundary: at matched recognition, (2) makes the c-variance velocity proportional to c^2 times its evidence score. The score need not vanish when that velocity becomes small. The [failed probe](evidence/fixed-pair-native/stationarity-probe.json) remains a failed interior attempt, not evidence that no interior stationary point exists anywhere.

One direct score evaluation at the suggested c=0 boundary gave a negative c derivative of log evidence. That was a numerical diagnostic for the separate exact obligation below, not an extra trajectory or an interior-solver retry.

## 3. The normalized boundary problem

At c=0 the link-noise law is a Dirac measure at its pushed reference. It is a proper weak limit of the admitted Gaussian priors, although its covariance is no longer positive definite. Every finite-time physical trajectory still has c>0. All P decorations now have the same residual covariance

\[
 \Gamma_0(a,b)=aBB^T+bJJ^T,
  J=B\begin{pmatrix}1&0\\1&0\\0&1\\0&1\end{pmatrix}.
 \tag{3}
\]

It has rank three for a,b>0. The Gaussian determinant identity remains valid for this positive-semidefinite covariance; I+Gamma_0 D has positive determinant for every positive exponent matrix D. The link-free boundary is not substituted for the general independent-link model.

The sum of all four residuals vanishes on this boundary. Consequently the two parent residuals are negatives of one another. Let t=(1/2,1,1/2,0), and for l=0,1,2 set

\[
 e_l(a,b)=\sum_{S\subseteq E}(-1)^{|S|}
 \det\left[I+\Gamma_0(a,b)
       \left(\operatorname{diag}(n+1_S)+l t^Tt\right)\right]^{-1}.
 \tag{4}
\]

Then Z_P(a,b,0)=e_0(a,b)^2 and the boundary parent merge readout is

\[
 M_0(a,b)=\frac{2e_1(a,b)^2-e_2(a,b)^2}{e_0(a,b)^2}.
 \tag{5}
\]

The cut flags remain conditionally independent even though their probabilities coincide; identifying the flags themselves would change (5). The four decorations also remain in the transverse derivative. Their average link Gram matrix is diag(0,2,0,2). Since their unshifted integrals coincide at c=0, differentiating the full average of squared integrals gives

\[
 g_c(a,b):=\left.\partial_c\log Z_P(a,b,c)\right|_{c=0}
 =\frac{2\bar e_c(a,b)}{e_0(a,b)},

 \bar e_c=\frac14\sum_{H\mid P}\left.\partial_c e_H\right|_{c=0}.
 \tag{6}
\]

Linearity of this first derivative permits the averaged Gram matrix in (6). It would not generally justify replacing the full decorated model at positive c by its averaged covariance.

## 4. Exact local critical-point enclosure

The [exact boundary calculation](evidence/fixed-pair-native/boundary_enclosure.py) constructs the rational functions (4) and (6), and the numerator polynomials of partial_a e_0 and partial_b e_0. Multiprecision Newton evaluation supplies a rational center with eighty recorded decimal digits. It is used only to propose a box. All subsequent enclosure and sign decisions use exact Fraction arithmetic.

There is exactly one critical point in the saved box, whose coordinate half-width is 10^-20. Its approximate coordinates are

\[
 a_*=0.056944476505069695\ldots,
  b_*=0.3092749579198564\ldots.
 \tag{7}
\]

Here is the existence and uniqueness argument carried by the coefficient certificate. Let f be the two derivative numerator polynomials, x_0 the rational center, A=[Df(x_0)]^-1 and X the closed radius-r box. Exact polynomial interval evaluation encloses Df(X). The calculation checks

\[
 q:=\sup_{J\in Df(X)}\|I-AJ\|_\infty<6.0\times10^{-17},

 \|Af(x_0)\|_\infty<3.8\times10^{-75},

 \|Af(x_0)\|_\infty+qr<r,
  r=10^{-20}.
 \tag{8}
\]

The map x to x-Af(x) therefore maps X strictly into itself and is a contraction there, by the integral mean-value formula. Its iterates form a Cauchy sequence in the complete closed box and converge to a fixed point. Invertibility of A makes that fixed point a zero of f, and contraction gives uniqueness in X. The denominators and e_0 are enclosed away from zero, so this zero is an actual critical point of log Z_P. The numerical refinement alone supplies none of these conclusions.

The exact intervals also prove that the Hessian of log Z_P in a,b is negative definite. Its approximate entries are

\[
 D^2_{a,b}\log Z_P(a_*,b_*,0)
 \simeq\begin{pmatrix}
 -611.9265053811&-7.9858989526\\
 -7.9858989526&-10.9660582892
 \end{pmatrix}.
 \tag{9}
\]

The proof uses the strictly negative upper-left entry and strictly positive determinant of the rational interval enclosure at the root. It is not an eigenvalue decision from the displayed rounded matrix. Two further strict enclosures give

\[
 g_*:=g_c(a_*,b_*)=-1.986779116200665\ldots<0,

 M_0(a_*,b_*)=0.4872933347114485\ldots<1/2.
 \tag{10}
\]

The full rational endpoints are in [boundary-local-enclosure.json](evidence/fixed-pair-native/boundary-local-enclosure.json). Thus the boundary point is a strict local evidence maximum on the physical side c>=0: it has negative tangential curvature and negative inward c score. This is a local statement; neither a global maximum nor a classification of every boundary critical point is claimed.

## 5. The fast native modes are stable

For a,b alone at the matched boundary posterior, put D=diag(16,8), and define the two-by-two matrix

\[
 A_{jk}=\frac{\operatorname{Cov}_{Q_*}(E_j,E_k)}
                    {2d_j a_{j*}a_{k*}},
  j,k\in\{a,b\}.
 \tag{11}
\]

Exponential-family differentiation gives partial_{log r_k} E_Q E_j=Cov(E_j,E_k)/(2r_k). Therefore the linearization in model and recognition log variances has the block form

\[
 J_{ab}=\begin{pmatrix}-I&A\\I&-I\end{pmatrix},

 D^2_{\log a,\log b}\log Z_P=\tfrac12D(A-I).
 \tag{12}
\]

The matrix D^(1/2) A D^(-1/2) is a symmetric positive-semidefinite covariance matrix. The negative Hessian in (9), after the invertible log-coordinate congruence, implies that its eigenvalues satisfy 0<=lambda<1. The eigenvalues of (12) are -1 plus or minus sqrt(lambda), all strictly negative. This proves stability of these four native modes without using the failed probe's finite-difference eigenvalues.

The c limit needs a different coordinate because log c diverges. Set z=log(r_c/c), and keep c itself as the remaining model coordinate. With g_c now evaluated at the current recognition variances, (2) gives the analytic extension

\[
 \dot c=c(e^z-1)+\frac{c^2e^{2z}}8g_c,

 \dot z=2(1-e^z)-\frac{ce^{2z}}8g_c.
 \tag{13}
\]

At the boundary point this adds one zero eigenvalue and one stable eigenvalue -2. The determinant formulas are analytic in a full mathematical neighborhood of c=0 with e_0>0 and all denominators nonzero. Negative c in that extension is only a device for differentiating the vector field; it is not a probability model. The physical half-space c>=0 is invariant, and positive c stays positive for every finite time because its derivative contains a factor c.

Let v collect the five fast coordinates, including z, after centering the four a,b log coordinates. Its linear part is v'=A_f v+B_f c, with A_f strictly stable. Set h_1=-A_f^-1 B_f and w=v-h_1 c. The z row of (13) directly gives

\[
 (h_1)_z=-g_*/16,

 \dot c=\kappa_*c^2+c\ell^Tw
          +O(c^3+c^2\|w\|+c\|w\|^2),

 \kappa_*=g_*/16<0,
 \tag{14}
\]

and w'=A_f w+O(||w||^2+c||w||+c^2). The coefficient kappa_* is fixed by the existing model and inference rates. It is not a new slow-clock parameter.

## 6. One-sided attraction and the derived approach rate

A direct Lyapunov argument handles the physical half-space. It does not assume two-sided stability of a scalar c'=kappa_* c^2 equation. Since A_f is strictly stable, the matrix

\[
 L=\int_0^\infty e^{A_f^Ts}e^{A_fs}ds,
 \tag{15}
\]

is finite and positive definite and satisfies A_f^T L+L A_f=-I. Taylor bounds in (14) and the inequality 2xy<=epsilon x^2+y^2/epsilon imply, on a sufficiently small neighborhood with c>=0,

\[
 \frac{d}{dt}(w^TLw)\leq-\tfrac12\|w\|^2+C_1c^4,

 \dot c\leq-k_0c^2+C_2\|w\|^2,
  k_0>0.
 \tag{16}
\]

For the second inequality, first absorb the cubic c term using kappa_*<0, then bound c||w|| by a small multiple of c^2 and a finite multiple of ||w||^2. For the first, the c^2||w|| term is bounded by a small multiple of ||w||^2 and a finite multiple of c^4; terms containing ||w||+c are absorbed by shrinking the neighborhood.

Choose K sufficiently large to dominate C_2, then shrink the neighborhood further to absorb K C_1 c^4. The function V=c+K w^TLw is positive on the physical half-space away from the origin and satisfies

\[
 \dot V\leq-\gamma_c c^2-\gamma_w\|w\|^2,
  \gamma_c,\gamma_w>0.
 \tag{17}
\]

A sufficiently small sublevel set stays inside the chosen neighborhood. Its trajectories remain there and the integral of c^2+||w||^2 is finite. The vector field is bounded and smooth on its compact closure, so these quantities are uniformly continuous. If c or w failed to tend to zero, uniform continuity would force infinitely many intervals with a positive contribution to that integral. This contradiction proves local asymptotic attraction from c>0. The conclusion is one-sided; the artificial negative-c extension has no such claim.

The rate is also determined by the native equations. Local convergence and (14) give (log c)' to zero. For any sufficiently small epsilon>0 and sufficiently late times, c(s)<=exp(epsilon(t-s))c(t) for s<=t. Stable variation of constants for w, with its small nonlinear w terms absorbed, gives a decaying homogeneous term plus a convolution of c(s)^2. Choosing twice epsilon below the stable decay rate bounds that convolution by a constant times c(t)^2; its homogeneous term divided by c(t)^2 tends to zero. Hence w=O(c^2). Substitution into (14) proves

\[
 \dot c=\kappa_*c^2+O(c^3),

 \lim_{t\to\infty}t c(t)=-\frac{16}{g_*},

 \frac{r_c(t)}{c(t)}=1-\frac{g_*}{16}c(t)+O(c(t)^2).
 \tag{18}
\]

For the limit, differentiate 1/c to obtain -kappa_*+O(c), then integrate and divide by t. The ratio formula follows from z=(h_1)_z c+O(c^2). If recognition were replaced by an instantaneous posterior in (13), z would be set to zero and the leading c coefficient would instead be g_*/8. The actual recognition lag halves that coefficient. No rescaled physical time is assigned.

The model and recognition a,b coordinates converge to (a_*,b_*), with deviations O(c). By continuity of the complete parent readout, a sufficiently small physical attraction region has M<1/2 throughout and in its limit. This is a learned, persistent second-level split preference near the boundary, not an inference that maximal agreement should cause a merge.

For context, [Carr's author exposition](https://www.scholarpedia.org/article/Center_manifold) describes the usual zero/stable spectral split and invariant-graph equation. The present argument supplies the one-sided Lyapunov estimate directly; its attraction claim does not depend on applying a two-sided stability statement to the physical boundary. The indexed article was available to the bounded source lookup, while a subsequent direct page fetch timed out.

## 7. Persistence for nearby strictly positive ancestry priors

The boundary reference pi_P=1 is not the final prior scope. Restore the full twelve-ancestry model and its count memory lambda=omega-2 log rho_b. At a finite matched boundary posterior, lambda=0, and the boundary a,b stationarity conditions are the two derivatives of the full log evidence log Z_pi(a,b,0).

The functions e_H(a,b,c), their scores and the explicit native vector field extend smoothly in pi near the P vertex, as their normalizers are positive there and K_pi stays near two. The nonsingular negative Hessian in (9) implies a unique nearby boundary critical point (a_*(pi),b_*(pi)) for priors sufficiently close to that vertex. This follows by solving the two gradient equations with the same nonsingular local derivative; the physical portion includes a nonempty open family with every pi_R>0. No prior is assigned a numerical value.

The count-memory equation is

\[
 \dot\lambda=-\lambda-2\left[x-1-\log x\right],
  x=\frac{r_b}{b}.
 \tag{19}
\]

At the matched boundary, its linear part is -lambda, since x-1-log x has zero value and first derivative at one. At the P vertex lambda is otherwise redundant. The full boundary linearization therefore has six stable modes and one zero mode. Strict fast stability persists for sufficiently nearby positive priors by continuity of the finite matrix eigenvalues. The c equation retains d_c=16, so its slow coefficient remains g_*(pi)/16. Negativity of that coefficient and the strict merge gap in (10) also persist.

The Lyapunov construction in Section 6 now applies with six fast coordinates. For each prior in a sufficiently small positive-prior neighborhood, there is an open set of positive model/recognition states whose actual native trajectories stay near and approach the corresponding boundary. They satisfy

\[
 c(t)\sim-\frac{16}{g_*(\pi)t},

 \lim_{t\to\infty}M_P(Q_t)
 =M_0(a_*(\pi),b_*(\pi))<1/2.
 \tag{20}
\]

The decimal value in (10) belongs to the P reference; the nearby priors have their continuously shifted limits. Since Q(P)=1 at the vertex and the other evidence coefficients are finite, the neighborhoods can also be chosen so that Q(P)>1/2 throughout the local attraction region. P is then the unique first-level MAP ancestry while its second-level merge diagnostic remains below one half. All other ancestries still have positive mass at every finite time. This is an actual local native persistence result, not a frozen parameter curve or a hard ancestry selection.

The result supplies no numerical size for the prior or state neighborhoods. In particular, the unit preparation and the near-O/P-tie priors of the earlier crossing theorem are not certified to lie in them. A local attracting boundary and a static merge-favored region can coexist. Transient excursions above one half from a more distant initial state are not excluded.

## 8. Completion boundary and evidence

The present result closes a local dynamical obligation: a proper nearby positive-prior family has learned first-pair persistence with a disfavored second merge, and its link-variance approach rate follows from the coupled native equations. The c=0 limit is a degenerate Gaussian law; it is not an interior SPD fixed point or exact finite-time disappearance of the links. Original record probabilities, primitive energies, marked geometry, covariance couplings and the posterior reverse-kernel correction still belong to every complete finite-time parent.

Native entry from the unchanged unit preparation remains open. The one numerical trajectory provides a saved candidate path only through time 20. Its dense polynomial and all states are retained for a later error enclosure if one is warranted. Its event count is not a mathematical no-crossing certificate, and the failed stationary attempt is not a global absence theorem. Neither calculation demonstrates a useful second-stage episode from that preparation.

The complete resource license also remains open. The auxiliary parent panel is a common normalized channel, without new observations or a hierarchy likelihood. Selecting a branch still has the previously derived support cost. Complete native and density evaluation, generation, interfaces, storage, filtering when required and organizational overhead must be compared with the fine implementation. The original fifteen exact negative admissions and the wider goal remain intact.

[The pilot program](evidence/fixed-pair-native/pilot_native.py) completed in 0.24372340000263648 seconds under existing Anaconda Python 3.12.7, NumPy 2.0.0 and SciPy 1.16.0. [The stationary probe](evidence/fixed-pair-native/stationarity_probe.py) completed its failed-solver report in 0.021189099999901373 seconds. One inline boundary-score evaluation identified the negative transverse score without dividing by c^2. [The exact enclosure program](evidence/fixed-pair-native/boundary_enclosure.py) completed in 1.8520724999980303 seconds under the same Python runtime with SymPy and mpmath. Its multiprecision center is followed by exact rational interval contraction, denominator, curvature and score checks; it does not rely on floating-point root residuals for closure.

The three substantive passes were the bounded six-variable trajectory, diagnosis of the failed interior stationarity attempt, then the exact boundary enclosure and local native attraction proof. No trajectory was extended, no second interior attempt was run and no earlier scientific main was rerun. The 307-file preservation baseline permits updates only to STATUS.md, RG-COMPLETION.md, RECORD.md and the September 12 change log. Saved data, previous evidence, sources and WIP remain preserved. No new data, sampled states or flags, production/configuration changes, numerical positive-prior search, GPU, suite, Lean, tamper check, vault edit, publication or canonical synchronization occurred. No formal ledger or independent-review certificate is issued.
