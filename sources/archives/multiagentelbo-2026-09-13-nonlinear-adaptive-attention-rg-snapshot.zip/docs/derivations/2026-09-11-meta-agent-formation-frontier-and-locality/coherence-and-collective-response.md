# Coherence and collective response: an operational continuation

September 12, 2026. The user proposed preserving subagent coherence and approved investigating stable internal coherence together with preserved collective response. This supplies a direction for the previously blocked operational question. It does not select a numerical tolerance, new observations, or a dynamics. The full formation objective remains active and incomplete.

The existing constructions already retain the original scalar agreement probabilities. The new obligation is their response to a change in the surrounding group state. In the current transported Gaussian family, that obligation separates into an exact directional-access question and a quantitative approximation bound. The two investigations are [response access](coherence-response-access.md) and [response bounds](coherence-response-bound.md).

## Source and experiment boundary

The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:epistemic_collapse`, already distinguishes controlled internal disagreement from perfect consensus. Its RG appendix separately assumes a small force residual: a small scalar energy error does not imply a small derivative error. The [wiki's operational parent definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) already requires an evaluator, boundary access, structural marks and memory. These ideas are the starting point, not new claims introduced here.

The model remains the [transported two-channel Gaussian construction](transported-parent-priors-and-induced-couplings.md), at one base point, with independently specified translation links, correlated population recognition, both channels and every labeled cut. The primitive child-noise energy is the transported E_a. The fifteen exact negative heterogeneous admissions and the [conditional common-prior hierarchy](common-prior-native-hierarchy-episodes.md) retain their original contracts and conclusions.

The diagnostic intervention adds a common mean displacement u_A to every child in an existing block A, while holding links and internal contrasts fixed. This is an explicit collective input on the existing law-mean coordinates. It preserves internal coherence instantaneously and changes cut residuals. It does not model how the system relaxes after that input, choose a physical actuator, or make these inputs part of the saved observation archive. Their use as the task that ultimately licenses a parent remains a scientific modeling choice.

For an oriented cut i in A to j in B, write

\[
 \mu_i=g_i+z_A+\delta_i,\qquad
 r_e(u)=d_e+u_B-u_A+\eta_e,
 \qquad d_e=z_B-z_A-V_e,\quad\eta_e=\delta_j-\delta_i.
\]

Each formula acts separately on the two two-dimensional channels. The actual response is exp(-||r_e(u)||^2/2); the barycenter response sets eta_e to zero. Passive changes of the translation frames push the means, links and reference laws together. They leave the residual and these response comparisons invariant. This calculation supplies no general nonabelian or covariance-learning extension.

## What coherence can certify

The response-bound report proves a uniform probability error bounded by exp(-1/2) times ||eta_e|| and a relative-input probability-gradient error bounded by ||eta_e||. Both statements hold for every collective displacement. Tree disagreement energies, recoverable from the retained internal agreement probabilities, give explicit upper bounds on each endpoint contrast. Their constants depend on the tree and the actual pooling masses; no coherence threshold is fitted.

For the two pairs A={0,1} and B={2,3}, with internal trees 01 and 23, both directed cut errors have

\[
 \eta_{12}=\eta_{30}=-\frac{r_{01}+r_{23}}2,\qquad
 \|\eta_e\|\le\frac{\sqrt{-2\log p_{01}}+\sqrt{-2\log p_{23}}}{2}.
\]

The physical relative displacement has opposite signs on the two oppositely oriented cuts. The displayed common error is their unperturbed contrast contribution, not an instruction to apply the same input sign on both cuts.

Thus internal coherence has a concrete operational consequence in this family: it bounds the error made by replacing individual boundary children with their group barycenter. The bound provides a curve indexed by the measured disagreement, which can later be compared with a declared query horizon and loss requirement. The two-pair access report also bounds the centered log-response increment error by the input magnitude times the same disagreement radius. It does not turn an arbitrary coherence threshold into a universal formation law.

A positive lower bound on the raw-conductance normalizer also gives a C1 error bound for the corresponding log-sum interaction potential. The report states that additional hypothesis explicitly. A probability-gradient bound alone does not control failure log likelihoods near probability one, all terms in the coupled VFE, a changed Fisher metric, or the complete natural-gradient vector field.

## Exact access and complete accounting

Unperturbed agreement values are insufficient for exact pointwise response. The access report constructs four legitimate fine configurations with the same entire first-parent carrier, including all eight probabilities, all four primitive energies, both barycenters and both dressed cuts. Independent reflections in the two channels preserve these quantities while changing directional cut responses. This is a global access obstruction even where the local differential rank does not increase.

On the generic two-pair geometry, two branch bits suffice for the response directions and four distinct labels are necessary at the witness. Retaining the four coordinates of one cut residual supplies a globally smooth sufficient augmentation, giving 44 fine coordinates to 32 retained coordinates; the report treats degenerate cases and minimality limits separately. Its costs belong to that precise two-dimensional, two-cut setting. They are not a general fixed-size interface claim for larger graphs, other representations, or further input families. Recursive use must retain each admitted response evaluator before a later channel discards its arguments.

This pointwise obstruction does not invalidate the existing common-reference conditional. Under the admitted population family, that conditional still defines averaged predictions of any integrable fine query. Using it for a new response task may require integration, and repeated queries update its conditional distribution. Those operations and any filter state must be counted. The obstruction concerns replacing that conditional information with the existing parent coordinates and claiming exact predictions for every fine preparation.

## Stability and the remaining formation question

The present displacement is instantaneous and deliberately preserves internal contrasts. Internal recovery after heterogeneous forcing, persistence of a coherent region under the coupled update, and accuracy of a dynamically closed parent require the actual dynamics. If a valid response certificate stays small over a declared time interval, the same error bounds hold there; the inequality does not prove that premise.

The existing native split and merge windows establish preferences of the retained joint law. They have not yet been evaluated as uniform small-response-error windows for this new collective-input contract. Their proofs remain intact. No new microscopic sample process, likelihood, ancestry prior, physical clock, or permanent-membership requirement is introduced.

The next bounded obligation is to apply the response certificate to the existing native family and compare complete candidate interfaces for the same collective task. This can begin from its retained law and trajectory evidence; another trajectory, a prior search, or new data is not a prerequisite. A final operational selection still needs the tolerated loss and the workload being priced. The user's coherence hypothesis now provides a measurable response target instead of leaving that target wholly unspecified.

## Evidence

The two reports contain the derivations and the access report's new exact rational calculation. A separate [reconstruction](coherence-response-reconstruction.md) checks the claims against their hypotheses. [Inspection](evidence/coherence-response/inspection.json) records source and earlier-artifact preservation and document checks. These records are distinct from a formal ledger certificate. No earlier successful scientific calculation, training configuration, saved data, GPU work, Lean proof, tamper check, vault edit or publication is part of this continuation.
