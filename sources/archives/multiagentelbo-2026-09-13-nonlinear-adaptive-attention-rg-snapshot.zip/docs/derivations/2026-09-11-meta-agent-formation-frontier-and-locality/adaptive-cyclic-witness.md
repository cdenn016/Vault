# An adaptive cyclic Gaussian formation witness

September 12, 2026. This is the dynamical construction component of the [frozen adaptive contract](evidence/2026-09-12-adaptive-cyclic-rg-goal/problem-contract.json), digest `e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90`. Its normalized model and actual model-Fisher update are in [the normalized model](adaptive-normalized-model.md). Its exact marked parent formulas are in [the loop geometry](adaptive-loop-parent-geometry.md), and its conditional and feedback estimates are in [the conditional calculation](adaptive-conditional-bounds.md). A reference to another component below identifies an interface; it does not replace the proof supplied here.

The source boundary matters. The [finite-depth Gaussian reference](finite-depth-gaussian-reference.md) already proves a weighted-flag estimate and a fixed-covariance formation family on a path. The [compact parent class](finite-depth-parent-class.md), [nonlinear comparison](finite-depth-nonlinear-comparison.md), and [finite-depth completion](finite-depth-completion.md) keep exact nonlinear integrals, inherited metrics, and actual-law activations separate. Section 11 of [the microscopic construction](microscopic-vfe-dynamics-construction.md) supplies the complete normalized model score. Sections 6–7 of [the Gaussian learning example](pointwise-gaussian-link-learning.md) show why that score can move a hidden conditional even when the VFE decreases. Section 6 of [complete coherence dynamics](complete-coherence-dynamics.md) already establishes local restoring geometry with independent cyclic links and possible nonidentity stabilizers. The live PIFB2 passages on fast and slow timescales, lines 938–968, make fast attraction a hypothesis; its loop discussion, lines 387–418, distinguishes independent loop data from an optional explicit loop penalty. No such penalty is inserted here.

## 1. Statement, supplied constraints, and introduced specialization

For every fixed integer L at least 2, the construction below gives a finite cyclic weighted graph with L actual formation episodes, a positive smooth correlated Gaussian recognition law, independent moving translation links, zero inter-agent model-alignment coupling, and an actually learned positive generative precision coefficient. Learning uses the complete normalized VFE and its model Fisher metric. The learning horizon is 2/epsilon. The model coefficient changes by more than 1/2 on that horizon and changes a first eliminated Gaussian conditional by a relative entropy bounded below independently of epsilon. All L episodes occur before the end of that horizon and persist through its remainder with a stated exceptional probability.

The user supplies the fixed-base-point scope, the independent-link ontology, actual model learning, exact normalized marked parents, shared microscopic peer kinetics, and the prohibition on manufacturing a hierarchy through new parent rates or a prescribed learning schedule. This witness introduces a regular scalar Gaussian specialization, a chain of triangle subgraphs, fixed hierarchical edge-energy contrasts, a compatible heterogeneous vector observation, Gaussian initial recognition, and the slower microscopic model metric stated in the normalized-model component. These are explicit microscopic data. They are not a universal result for arbitrary graphs, laws, priors, or incompatible observations. The supplied contrast is not learned away: learning changes all its energy coefficients through one common learned factor.

The continuous process is a configuration diffusion plus a deterministic expectation-driven model-parameter equation. There is no numerical discretization or implementation claim. Exact equality below concerns normalized pushforwards, conditionals, and their composition. Parent dynamics are comparison processes with inherited metrics; their replacement of a fine projected trajectory requires the separate quantitative errors. Actual evolving Gaussian densities are not Dirac recognition laws.

## 2. Cyclic graph, coordinates, and the retained holonomies

Put b=2^(L-1). There are n=3b vertices, organized into b disjoint triangles. Orient each triangle cyclically. Choose one portal vertex per triangle and connect portal j to portal j+1 by one bridge edge, for j=1,...,b-1. Thus the connected graph has E=4b-1 edges and cycle rank b. Every triangle edge has level 1. Bridge j has level

\[
\ell(j)=2+v_2(j),\qquad 2\le\ell(j)\le L.
\tag{W1}
\]

The scalar state is x=(u,v,alpha) in R^(2n+E). It records one belief mean u_i, one sampled model-law mean v_i, and one independent translation link alpha_e on every original oriented edge. For incidence convention (Du)_e=u_i-u_j, put

\[
d_i=u_i-v_i,\qquad r_e=(Du)_e-\alpha_e.
\tag{W2}
\]

Belief and model laws are N(u_i,1) and N(v_i,c), where 0<c<1 is fixed. The model/evaluator coupling and its exact cost are equations M2–M3 of the normalized-model component. There is no model-channel alignment term: gamma=0. The belief edge energy is a J_ell r_e^2/2, which equals a J_ell times the transported belief KL. The numbers a J_ell are energy strengths, not simplex attention probabilities.

For triangle q define its holonomy h_q as the oriented sum of its three alpha coordinates. Let z_q=h_q/sqrt(3). The row extracting z_q is a unit Euclidean covector. Distinct triangle covectors are orthogonal. Choose the following orthonormal contrast matrix on three edge residuals:

\[
Q_\triangle=
\begin{pmatrix}
1/\sqrt2&-1/\sqrt2&0\\
1/\sqrt6&1/\sqrt6&-2/\sqrt6
\end{pmatrix}.
\tag{W3}
\]

Because a triangle incidence sum vanishes,

\[
\sum_{e\in q}r_e=-h_q,\qquad
\sum_{e\in q}r_e^2=|Q_\triangle r_q|^2+z_q^2.
\tag{W4}
\]

Let B_1 contain all n bridge-to-model rows d_i and the 2b internal contrast rows Q_triangle r_q. For s=2,...,L, let B_s contain all intertriangle bridge-edge residual rows with level s. Write B for their stack. The rows of B are independent: the alpha columns first force every internal contrast coefficient and every bridge coefficient to vanish, then the v columns force every d coefficient to vanish. Consequently B has n+3b-1=6b-1 independent rows. Each z_q covector is orthogonal to every row of B. This orthogonality follows from the zero sum of each contrast row, the absence of its alpha coordinates from all other rows, and the cancellation of triangle incidence sums.

Let K be the kernel of the full residual map consisting of all d and all original edge r rows. It has dimension n. Its vectors are exactly

\[
u_i=v_i=t_i,\qquad \alpha_e=t_i-t_j.
\tag{W5}
\]

Let H_h be the b-dimensional span of the unit holonomy covectors, viewed as vectors. Put N=range(B^T). The complete scalar space splits orthogonally as

\[
\mathbb R^{2n+E}=N\oplus H_h\oplus K.
\tag{W6}
\]

For J_1>=...>=J_L=1, define H_N=B^T diag(J_s I) B and

\[
H=H_N+J_1P_{H_h}
=J_1\sum_i b_{d_i}^Tb_{d_i}
+\sum_eJ_{\ell(e)}b_e^Tb_e.
\tag{W7}
\]

This is the full microscopic precision contribution, including every original triangle edge and its holonomy energy. There is no independent curvature term. A loop sum appears in (W4) only by resolving the original sum of pairwise KL energies into orthogonal coordinates.

Define W_s=ker(B_1,...,B_s), P_s its orthogonal projector, P_0=I, and take the retention x to P_s x in W_s. These maps compose since the subspaces are nested. Every P_s preserves all z_q exactly and preserves K exactly. The final retained space is W_L=H_h direct-sum K, of dimension b+n=4b. It retains all original holonomies, including their small but nonzero finite-temperature fluctuations. The parent is not declared to have only one scalar coordinate merely because the final agent count is one.

The original cut-edge copies and their observation/presentation kernels remain marked. A projected coordinate need not equal a raw tree-dressed cut value at finite strength. Its exact conditional mark law is therefore obtained by disintegrating the same normalized joint, with the physical reverse kernel distinguished from the optimizer reverse kernel and from the current recognition reverse kernel. These finite-strength kernels, and any retained conditional memory used for an exact dynamic lift, are part of the parent data. Replacing them by evaluation at P_s x would lose information and is not an equality used in this proof.

## 3. Normalized law and actual slow learning

Use exactly M4–M16 of [the normalized model](adaptive-normalized-model.md), with H defined by (W7), proper root precision P_K, fixed 0<kappa<=1, and a fixed heterogeneous observation z in K. In particular the physical prior precision, optimizer precision, and source vector are

\[
A_0(a)=aH+P_K-TR,\quad
K_a=aH+P_K+\kappa I,\quad f=\kappa z,
\qquad R=\frac{b_d^Tb_d}{1-c}.
\tag{W8}
\]

The prior, both Gaussian observations, model presentations, and evaluator kernels are normalized. Recognition is the complete correlated Gaussian outer law followed by the fixed-marginal optimizing evaluator coupling. The exact parameter score and actual full-model Fisher metric are

\[
g=a-2+\frac12E_Qx^THx
-\frac T2\operatorname{tr}(A_0^{-1}H),\qquad
M(a)=\frac1T+\frac12\operatorname{tr}[(A_0^{-1}H)^2].
\tag{W9}
\]

All peer scalar coordinates have the same unit microscopic mobility. With model metric T M(a)/epsilon, the coupled equations are

\[
dX=(-K_aX+f)dt+\sqrt{2T}dW,
\qquad
\dot a=-\epsilon[TM(a)]^{-1}g.
\tag{W10}
\]

They satisfy the exact coupled dissipation identity M16. The normalizer term in (W9) is essential; removing it defines another model update. The model metric is fixed at the microscopic level and inherited by each retained model parameter. A new marginal-model Fisher matrix or a block-size rate is not substituted later.

The density remains Gaussian. The mean and covariance satisfy mu'=-K_a mu+f and Sigma'=-K_a Sigma-Sigma K_a+2TI. Equations M17–M22 prove, for sufficiently small initial H-energy and T rank(H),

\[
1\le a(t)\le2.1,\qquad
|\dot a(t)|\le1.1\epsilon,\qquad
a(2/\epsilon)>1.5.
\tag{W11}
\]

Their hypothesis checks are nonempty in the explicit regime of Section 8. Smooth coefficients and these moment and parameter bounds give a unique global solution on the stated horizon. There is no boundary hitting on the Euclidean state space; the positive parameter interval is invariant by the stated inward-pointing score bounds.

The holonomy coordinates are independent scalar processes at the fine level:

\[
dz_q=-(aJ_1+\kappa)z_qdt+\sqrt{2T}dW_q.
\tag{W12}
\]

This follows from (W6)–(W8), not from freezing the cycles. Each h_q=sqrt(3)z_q is retained exactly at every level. Link motion is also explicit before taking cycle sums: alpha_e has drift aJ_ell r_e-(P_K x)_alpha_e-kappa(alpha_e-z_e), as well as its Brownian term. At the prepared mean P_K mu_0=0; generic preparation below makes at least one initial mean link drift nonzero. Thus coherence is produced with moving independent links. Translation-law stabilizers are trivial in this specialization; nonidentity stabilizer holonomy in other representations is not ruled out by its particular decay law.

The observation-driven K component is exact and shared by all parents:

\[
P_K\mu(t)=\frac\kappa{1+\kappa}
\left(1-e^{-(1+\kappa)t}\right)z.
\tag{W13}
\]

It gives a nonzero collective response while the normal means cohere. The observation is compatible and heterogeneous; arbitrary incompatible normal forcing is not silently included.

## 4. Uniform restoring and Schur bounds through every level

Restrict now to N. Let N_s=W_s intersect N. Choose orthonormal columns Q_s spanning N_(s-1) intersect N_s perpendicular. In the resulting flag coordinates O=[Q_1 ... Q_L], the matrix T_B=BO is block lower triangular with invertible diagonal blocks. The earlier row independence proves that no flag layer is missing. Both T_B and its inverse are block lower triangular.

For descending J_s, conjugation by diag(sqrt(J_s)I) multiplies every possibly nonzero block (j,i) by sqrt(J_j/J_i)<=1. The same fact holds for the inverse. Therefore finite constants

\[
c_L=\|T_B^{-1}\|_F^{-2}>0,\qquad C_L^{(0)}=\|T_B\|_F^2
\tag{W14}
\]

satisfy

\[
c_L\sum_sJ_s|w_s|^2\le x^TH_Nx
\le C_L^{(0)}\sum_sJ_s|w_s|^2.
\tag{W15}
\]

Constants denoted C_L below may increase by finite matrix norms, dimensions, and inverse bounds from this fixed graph. They do not depend on epsilon, temperature, or descending weight magnitudes. The parameter range (W11) and 0<kappa<=1 can be absorbed into those constants.

Let K^(p)(a) be the exact Gaussian marginal precision on N_p obtained from aH_N+kappa I. For y in N_p,

\[
y^TK^{(p)}(a)y
=\min_{u\in N_p^\perp\cap N}(u+y)^T(aH_N+\kappa I)(u+y).
\tag{W16}
\]

Minimizing the lower bound in (W15) and using u=0 for the upper bound proves the same weighted bounds on all remaining layers. This proves positive restoring geometry at every parent; recursive admissibility is not assumed. Repeating the minimizations proves the exact Schur composition law.

For p<s, split N_p into F_(p,s)=N_p intersect N_s perpendicular and N_s. Write

\[
K^{(p)}=
\begin{pmatrix}F&G\\G^T&V\end{pmatrix},\qquad
S=V-G^TF^{-1}G=K^{(s)}.
\tag{W17}
\]

Put J_(L+1)=0. For s<L the bounds are

\[
F\succeq c_LJ_s I,\quad
\|F\|\le C_LJ_{p+1},\quad
\|G\|\le C_LJ_{s+1},\quad
\|S\|\le C_LJ_{s+1}.
\tag{W18}
\]

For s=L there is no future N component, so G and S in this normal split vanish. The root and holonomy directions already decouple exactly from N and are not included in a fictitious slow cross block.

Here is a direct check of the nontrivial cross estimate. In the original matrix, rows with level at most s annihilate N_s, so both original current-future and eliminated-future blocks are bounded by C_L J_(s+1). Rows with level at most p annihilate current and future directions, so the eliminated-current block is bounded by C_L J_(p+1). The previously eliminated diagonal inverse is bounded by C_L/J_p. The Schur correction is consequently at most C_L(J_(p+1)/J_p)J_(s+1)<=C_L J_(s+1). The kappa I term has no original cross block. The same calculation gives the bound on S by testing zero eliminated coordinate in (W16).

The parameter derivatives also obey

\[
0\preceq\partial_aK^{(p)}\preceq K^{(p)}/a,
\qquad \|\partial_aG\|\le C_LJ_{s+1}.
\tag{W19}
\]

For the first inequality, differentiate the minimizing quadratic in (W16). The derivative is the H_N energy at its minimizer, bounded by the total quadratic divided by a. For the cross derivative, differentiate the Schur formula. The terms have the same eliminated-current and eliminated-future factors just used. In the derivative of an inverse use
A_EE^(-1) H_EE A_EE^(-1) <= a^(-1) A_EE^(-1),
which follows from H_EE<=A_EE/a. This avoids a spurious J_1 factor in that term. It proves the second inequality in (W19) with the same type of finite constant.

## 5. An explicit preparation and actual formation

Choose a fixed orthonormal basis of N. For each future bridge edge e and each s<ell(e), the row b_e P_s restricted to N is nonzero, since b_e is independent of all earlier rows. For each internal triangle edge, b_e restricted to N is also nonzero: its projection has a nonzero internal contrast component. Include each of these finitely many linear forms in a list, including bridge edges at s=0. Their definitions involve only the finite graph and flag, not the stiffness magnitudes.

There is a constructive way to avoid every zero without assuming desired formation. In this fixed basis take v(t)=(1,t,...,t^(dim(N)-1)). Each listed nonzero form gives a nonzero polynomial of degree at most dim(N)-1. If there are m forms, at most m(dim(N)-1) real values can be zeros of at least one of them. Among the integers 0,...,m(dim(N)-1), at least one therefore avoids all zeros. Choose the smallest such integer and normalize v(t) to have unit norm. This finite definition gives a particular v with

\[
m_L=\min_{e,s:\ s<\ell(e)}|b_eP_sv|>0,
\tag{W20}
\]

where internal edges occur only with s=0. No target-dependent dynamical grouping rule is used. This choice is initial data in a fixed microscopic system. The same strict inequalities hold on an open neighborhood of v.

Prepare the mean mu_0=A v in N, with zero root and holonomy means, and covariance T K_1^(-1). All coordinate variances are positive; the complete recognition law is smooth and correlated. The initial nonzero edge residual means in (W20) are all separated from zero by m_L A. Since A J_1 diverges in the regime (W38)–(W39), while z and kappa stay fixed, each internal initial mean link drift a J_1 r_e-kappa(alpha_e-z_e) is nonzero for sufficiently small epsilon. Here the root-precision term vanishes because P_K mu_0=0. Initial mean link motion is therefore verified independently of Brownian motion.

Consider the fine process, an autonomous exact ancestor, or a sequentially activated process at level p. The normal mean is unforced and its norm is at most A, since its symmetric positive precision generates a Euclidean contraction and every retention is an orthogonal projection. For a further split at s, its current normal coordinate u solves

\[
\dot u=-F(t)u-G(t)y.
\tag{W21}
\]

Variation of constants and (W18) give

\[
|u(t)|\le C_L A\left[
e^{-c_LJ_s(t-t_0)}+J_{s+1}/J_s\right].
\tag{W22}
\]

For s=L the second term is absent. The retained future derivative has norm at most C_L A J_(s+1). To see this without multiplying a fast normal coordinate by J_1, note that the full block row (G^T,V) is bounded by C_L J_(s+1): the estimate on V follows by the same zero-elimination variational upper bound as (W18). Therefore

\[
|P_s\mu(t)-P_s\mu_0|\le C_L A J_{s+1}t.
\tag{W23}
\]

This remains true through sequential transitions before level s, because those projections preserve P_s mu exactly. Combining (W22)–(W23), on the active level s-1 after its actual activation time tau_(s-1), gives

\[
|\mu(t)-P_s\mu_0|\le C_L A\left[
e^{-c_LJ_s(t-\tau_{s-1})}
+J_{s+1}/J_s+J_{s+1}t\right].
\tag{W24}
\]

At s=L the comparison target is zero in N and both future terms vanish. The same argument applies to cumulative elimination from an earlier ancestor, using its own start time. Thus the formation proof does not require a cooperative residual generator or a fresh Gaussian equilibrium at later activations.

For a sufficiently small right side, every residual of an already formed edge is small because it annihilates N_s. The internal triangle residual additionally includes -z_q/sqrt(3), which is controlled by its retained loop fluctuation. Every future bridge residual stays at least m_L A minus the same finite matrix norm times the error. Consequently small current residuals and separated future residuals follow from the equations, rather than being imposed by the chosen reduction times.

The centered fluctuation Z has drift matrix at least c_L I on N direct-sum H_h. Its initial covariance and all activated covariances are bounded by C_L T I; Section 6 gives the sharper tracking estimate. Choose a positive c smaller than the reciprocals of those finite covariance constants and smaller than the drift lower bound. For

\[
V(Z)=\exp[c|Z|^2/(4T)],
\tag{W25}
\]

the time-dependent diffusion generator satisfies L_t V<=C_L: Ito differentiation gives a negative multiple of |Z|^2 V/T plus a constant multiple of V, whose maximum is finite after writing u=c|Z|^2/(4T). The initial Gaussian exponential moment is finite and bounded by a constant depending only on dimension. At each retention, V cannot increase since the centered variable is orthogonally projected. Optional stopping on a finite horizon, first at bounded stopping times and then by monotone convergence, proves

\[
\Pr\left(\sup_{t\le H_*}|Z_t|\ge\rho A\right)
\le C_L(1+H_*)\exp[-c_L\rho^2 A^2/T].
\tag{W26}
\]

This is a full finite-time event estimate for the actual time-dependent process; a one-time Gaussian variance was not substituted for a path maximum. A union bound covers the finitely many separately considered ancestors. There is no assertion of exact agreement or permanent coherence at positive temperature.

The inherited physical edge statistic also has the same episodes. It is the conditional expectation of the original transported edge KL, not an unsupported identification of a mixture KL with one quadratic residual. At a retained state y whose N component has norm at most C_L A, the cumulative optimizer hidden conditional at stage p>=1 has mean -F^(-1)G y and covariance TF^(-1). Consequently

\[
E(|u_{\rm hidden}|^2\mid y)
\le C_L\left[A^2(J_{p+1}/J_p)^2+T/J_p\right].
\tag{W26a}
\]

The same bound holds for the physical prior and physical observed-posterior conditionals. To check it, their hidden precision differs by the retained evaluator correction -TR and, for the prior, omission of kappa I. The prior positivity bound M5 keeps its hidden block at least c_L J_p. Since every d row belongs to the first eliminated layer, R annihilates N_p and has no hidden-future cross block. The original cross-block argument in (W18) therefore still gives C_L J_(p+1), and the physical covariance remains at most C_L T/J_p. No optimizer kernel is used in place of the physical one.

For an original edge, its full residual differs from its retained-state residual by the fixed linear form b_e u_hidden. Thus its conditional root-mean-square difference, divided by A, is at most

\[
C_L\left[J_{p+1}/J_p+1/(R\sqrt{J_p})\right].
\tag{W26b}
\]

In the explicit regime this tends to zero at every level. The coherent retained residuals therefore have small expected original transported KL under either specified conditional, while future bridge residuals retain a positive multiple of A^2 as a lower bound. The conditional mark law, its correlations, and the parent presentation remain intact. This argument does not identify the KL of two complete correlated parent presentations with a scalar pairwise ansatz.

During level 1 the triangles are the coherent connected components, giving 3b to b agents. During level s>=2, bridges of level at most s join consecutive groups of 2^(s-1) triangles, giving b/2^(s-1) agents. The chronology is

\[
3\cdot2^{L-1}\longrightarrow2^{L-1}
\longrightarrow2^{L-2}\longrightarrow\cdots\longrightarrow1.
\tag{W27}
\]

Every original loop belongs to agents that coalesce at the first episode. All its edges and holonomy marks remain in the exact parent description. The construction does not replace its cycles by a spanning tree.

## 6. Moving conditional means and direct conditional KL

The covariance estimate used here can be proved without simultaneous diagonalization. Suppose a symmetric precision K(t)>=mI satisfies -rho K<=Kdot<=rho K. If Sigma follows its actual Lyapunov equation, the matrix barriers

\[
(1-r(t))TK(t)^{-1}\preceq\Sigma(t)
\preceq(1+r(t))TK(t)^{-1},\quad
\dot r=-(2m-\rho)r+\rho
\tag{W28}
\]

are preserved from their initial ordering. For example, subtract the covariance equation from the derivative of the upper barrier. The result contains (r'-rho(1+r)) T K^(-1)+2r T I, which is positive semidefinite for the displayed r equation and K>=mI. The lower barrier is checked with the opposite inequalities. Matrix ordering propagates under the Lyapunov evolution because its inhomogeneous solution is a positive congruence integral. The initial exact covariance has r(0)=0. Orthogonal marginalization preserves the inequality. Schur differentiation as in (W19) preserves its relative-speed hypothesis. Thus actual-law parent activation requires no covariance reset. Here m>=c_L and rho<=C_L epsilon, so r(t)<=C_L epsilon uniformly to 2/epsilon at every finite level, with finite increases for repeated activations.

For (W17), the optimizer hidden conditional is N(-F^(-1)G y,TF^(-1)). Write R_F=F^(-1)G and e=mu_u+R_F mu_y. Its mean contribution to cumulative conditional KL is exactly e^T F e/(2T). The full covariance contribution is at most

\[
\frac{dr^2}{4(1-r)^2},
\tag{W29}
\]

by the Gaussian relative-entropy formula and subtraction of the nonnegative retained covariance KL. Indeed every normalized covariance eigenvalue lies in [1-r,1+r], and t-1-log t<=(t-1)^2/[2(1-r)^2] on that interval. This proves a conditional entropy estimate directly; a path distance is not used to infer it.

The mean defect is a moving target. The exact equations are

\[
\dot\mu_y=-S\mu_y-G^Te,\qquad
\dot e=-(F+R_FG^T)e+(\dot R_F-R_FS)\mu_y.
\tag{W30}
\]

Put q=(e^T F e)^(1/2). Multiplication by e^T F gives

\[
q\dot q=-e^TF^2e-|G^Te|^2
+e^TF\dot R_F\mu_y-e^TGS\mu_y
+\tfrac12e^T\dot F e.
\tag{W31}
\]

Equations (W11), (W18), and (W19) give
|F^(1/2) Rdot_F|<=C_L epsilon J_(s+1)/sqrt(J_s).
To check the derivative term, use Rdot_F=F^(-1)Gdot-F^(-1)Fdot F^(-1)G, the relative Fdot bound, and |F^(-1/2)G|<=C_L J_(s+1)/sqrt(J_s). Therefore, also in the upper-right-derivative sense when q=0,

\[
D^+q\le-(c_LJ_s-C_L\epsilon)q
+\frac{C_L A}{\sqrt{J_s}}
\left[J_{s+1}^2+\epsilon J_{s+1}\right].
\tag{W32}
\]

Since J_(s+1)>=1 for s<L, the epsilon term is absorbed into the first one. Initially q^2<=C_L A^2 J_(p+1). Integrating (W32), after decreasing epsilon, and combining (W29) gives

\[
\Delta_{p:s}(t)\le C_L\epsilon^2
+C_L\frac{A^2}{T}
\left[J_1e^{-c_LJ_s(t-t_0)}
+\frac{J_{s+1}^4}{J_s^3}\right].
\tag{W33}
\]

At the final normal elimination the plateau is zero. At an actual sequential activation use elapsed time since that activation. Every adjacent conditional cost is bounded by its nonnegative cumulative cost. Multiplication by T is the exact discarded conditional VFE at that same time, with the original evidence constants retained. Costs at different activation times are not falsely added into a same-time chain-rule identity.

## 7. Force and retained-path estimates supplied by the witness

For any current law with finite conditional entropy, the Gaussian exponential-tilt calculation gives

\[
\|G^T(E[u\mid y]+F^{-1}Gy)\|_{L^2(Q_y)}
\le C_L J_{s+1}\sqrt{T/J_s}\sqrt{2\Delta_{p:s}}.
\tag{W34}
\]

This is the instantaneous conditional-averaged force defect. For a pathwise comparison driven by the same a(t), couple the fine projected noise and the autonomous parent noise identically. The difference has dissipative matrix S(t) and forcing -G(t)^T E_t, where E_t=u_t+F(t)^(-1)G(t)y_t. Its mean has the unweighted estimate C_L A[exp(-c_L J_s(t-t_0))+J_(s+1)/J_s], obtained directly from (W22). Its covariance is bounded by C_L T F^(-1), using (W28) and the exact block inverse identity. Thus integration and Markov's inequality give, for 0<delta<1,

\[
\Pr\left\{
\frac1A\sup_{t\le H_*}|Y_t-\bar Y_t|
>C_L\left[
\frac{J_{s+1}}{J_s}
+H_*\frac{J_{s+1}^2}{J_s}
+\frac{H_*J_{s+1}}{\delta R\sqrt{J_s}}
\right]\right\}\le\delta,
\qquad R=A/\sqrt T.
\tag{W35}
\]

The two processes start from the same actual retained state, so their initial discrepancy is zero. Stationarity is not required for the integral first-moment bound. The independent root and retained loop processes are exactly equal in this coupling at the same a(t). Finite composition contributes a finite sum of these errors.

Equation (W35) alone does not compare two separately learned model parameters. That distinction is explicit. The separately evolved parent uses its inherited complete model score under its optimizing hidden lift, rather than being supplied the fine parameter trajectory. First record an exact small-score interface. At a common a and retained law, the K_a-energy discrepancy between the actual fine Gaussian law and its optimizing lift is

\[
e^TFe+\operatorname{tr}\left[F(\operatorname{Cov}(E)-TF^{-1})\right].
\tag{W36}
\]

The retained energy cancels. Replacing K_a by H on N uses H=(K_a-kappa I)/a. Cauchy–Schwarz, the covariance barrier, and |F^(-1)G|<=C_L imply the score estimate

\[
|g_{\rm fine}-g_{\rm lifted}|
\le C_L\left[T(r+\Delta_{\rm mean})
+A\sqrt{T\Delta_{\rm mean}}\right],
\quad \Delta_{\rm mean}=e^TFe/(2T).
\tag{W37}
\]

For the Euclidean-energy correction, expand x=(y,-F^(-1)Gy+E): its mean cross term is bounded by C_L A|e|, its covariance difference by C_L T r, and its quadratic mean term by C_L T Delta_mean. This supplies the stated bound without treating a small KL value as a direct unbounded-score bound. After activation, (W33) makes (W37) at most C_L[T epsilon+A sqrt(T) epsilon]. The same bound holds at every active interface.

Here is a conservative full feedback bound, using the proved calculations in Sections 6.1–6.2 of the conditional component. Put E_0=mu_0^T K_1 mu_0 and p=rank H. Equation (42c) there requires

\[
\delta_L=\tfrac12e^{11(2)/10}E_0+\tfrac{29}{8}Tp<1/20.
\tag{W37a}
\]

Its hypotheses follow here: the normal mean is unforced, every Schur precision obeys (W19), the initial covariance is exact, and (W28) is preserved at actual-law activations. The proof bounds the optimizing lifted energy by the retained Schur mean energy, its actual covariance trace, and T times the hidden dimension. The mean energy grows at most by exp(1.1 epsilon t) and cannot increase at projection. The complete model score therefore gives a'=epsilon(2-a)+epsilon R_t with |R_t|<=delta_L on each actual fine or reduced trajectory. Inward velocities close the parameter and speed bootstrap. Two processes initialized with the same actual a at an activation time consequently satisfy

\[
\sup|a(t)-\bar a(t)|\le2\delta_L.
\tag{W37b}
\]

This is a comparison proved from the two distinct inherited model scores, not an imposed parameter schedule. It also proves the speed and parameter hypotheses needed above for every self-learning ancestor, rather than assuming them from the fine model.

For completeness, the mean sensitivity has no largest-stiffness factor. The relative derivative (W19), integrated between two parameters, gives
|v^T(S_a-S_b)w|<=C_L|a-b|sqrt(v^TS_av)sqrt(w^TS_bw).
For the difference u of two unforced parent means, Young's inequality gives
d|u|^2/dt<=-u^TS_au+C_L|a-b|^2 m_b^TS_bm_b.
But integral m_b^TS_bm_b equals half the decrease of |m_b|^2. For equal initial means this proves

\[
\sup|m_a-m_b|\le C_L A\sup|a-b|.
\tag{W37c}
\]

The actual projected source mean differs from the same-a autonomous parent mean by at most the deterministic part of (W35). Combining these comparisons proves, for an actual source-to-parent activation,

\[
\sup|P_s\mu_{\rm source}-\mu_{\rm parent}|
\le C_L A\left[
J_{s+1}/J_s+H_*J_{s+1}^2/J_s+\delta_L\right].
\tag{W37d}
\]

This estimates separately learned mean paths. To upgrade it to actual paths, use (W26) for both processes with radius rho=epsilon^2. This is a new maximum-event calculation, not an inference from one-time covariance agreement. In the regime of Section 8, each centered normal-plus-holonomy path has magnitude at most A epsilon^2, except with probability C_L(1+H_*) exp(-c_L/epsilon^2). Start the parent with the exact retained source state and couple root noise identically; the other noises may be synchronously coupled. On the intersection of these two tube events,

\[
\sup_{t\in[\tau,H_*]}
|P_sX_{\rm source}(t)-X_{\rm parent}(t)|
\le C_L A\epsilon^2,
\tag{W37e}
\]

because delta_L=O_L(epsilon^4) and the two deterministic geometric terms are O_L(epsilon^15). Its exceptional probability is at most C_L(1+2/epsilon) exp(-c_L/epsilon^2). This is a conservative positive-temperature coupling of paths with independently learned parameters. It does not assert exact Markov closure. Exact retained path law can instead be represented by the inherited conditional memory equation (44) of the conditional component, at the stated memory cost.

Finite sequential replacement follows by telescoping branches that agree through each activation and differ by exactly that one subsequent source-to-parent replacement. Further projections have norm one. The finite sum of (W37b) and (W37e), and the union of their exceptional events, bounds the full sequential description. Every activation uses the preceding actual Gaussian law and current model parameter. No covariance or parameter is reset to its target.

## 8. One simultaneous finite-depth regime

For 0<epsilon<1 define exponents and parameters by

\[
a_L=0,\qquad a_s=2a_{s+1}+16,
\qquad J_s=\epsilon^{-a_s},
\qquad R=\epsilon^{-3},
\tag{W38}
\]

\[
A=\epsilon^{a_1/2+2},\qquad
T=A^2/R^2=\epsilon^{a_1+10},\qquad
H_*=2/\epsilon.
\tag{W39}
\]

For each fixed finite L all constants are finite. The first identity below holds at every level; the two identities containing J_(s+1) hold for s<L, and their left sides are zero at s=L:

\[
A^2J_1=\epsilon^4,\qquad
J_{s+1}^2/J_s=\epsilon^{16},\qquad
H_*J_{s+1}/(R\sqrt{J_s})=2\epsilon^{10}.
\tag{W40}
\]

These formulas simultaneously satisfy the normalized model's small-energy, positive-prior and Fisher bounds for sufficiently small epsilon. Fix any kappa in (0,min(1,c_L)/2] and any c in (0,1); both remain strictly positive. The compatible heterogeneous z can be any fixed nonzero element of K. Its response need not shrink with A.

Choose a finite constant k_L so large that c_L k_L/2>a_1+10, using the final decay constant in (W33), and put

\[
t_s=k_L\log(1/\epsilon)/J_s,\qquad
I_s=[t_s,2t_s],\qquad \tau_s=2t_s.
\tag{W41}
\]

For sufficiently small epsilon these are ordered, disjoint, nondegenerate intervals, tau_(s-1)<t_s/2, and 2t_L<H_*. The times select when to describe an already formed object by its parent; they do not change the microscopic dynamics or its coefficients.

Equations (W24) and (W40) put every already formed mean residual below eta/2 and every future mean residual above m_L A/2 on I_s, where eta is a fixed sufficiently small multiple of m_L A depending only on the finite residual matrix norms. Choose rho in (W26) so all residual fluctuation images are below eta/2. Its exceptional probability is at most

\[
C_L(1+2/\epsilon)\exp[-c_L\epsilon^{-6}].
\tag{W42}
\]

After level L there are no future normal means, and the remaining normal mean contracts. The same event therefore preserves the final coherence through H_*. Applying (W33) with elapsed time at least t_s/2 gives

\[
\sup_{t\in I_s}\Delta_{s-1:s}(t)\le C_L\epsilon^2,
\tag{W43}
\]

and the bound persists after formation for the corresponding actual evolving law. In fact the plateau contribution is at most C_L epsilon^26 because R^2 J_(s+1)^4/J_s^3<=epsilon^26. The covariance lag supplies the larger O(epsilon^2) term.

With delta=epsilon^2, (W35) is O_L(epsilon^8) relative to A, with probability cost epsilon^2, for each interface at common a. The finite number of interfaces is absorbed into C_L. The score defect (W37) is O_L(epsilon^(a_1+8)). These powers explicitly exhibit a common regime; no hypothesis of conditional equilibration or future restoring rank is inserted.

By M23–M24, a(2/epsilon)>1.5 changes the first eliminated conditional at every common retained value by

\[
\operatorname{KL}(\pi_1(\cdot\mid y)\Vert
\pi_{a(2/\epsilon)}(\cdot\mid y))
\ge\frac{\dim F_{0,1}}2
\left[\frac14-\log\frac54\right]>0.
\tag{W44}
\]

The physical generative conditional has its distinct evaluator-adjusted precision and also changes; it is not identified with the optimizer conditional. The width T may shrink along the admitted family, but the relative-entropy change in (W44) does not. Model learning is active from the start. The large majority of its order-one change occurs after the short formation episodes, while the resulting coherent parents remain valid through the rest of the admitted learning interval. The theorem does not assert that every episode itself contains an order-one parameter change.

## 9. Scope and remaining interface

The displayed argument, together with the explicitly matched normalized-model, marked-geometry, and feedback components, establishes a nonempty cyclic formation family for every finite L>=2. It has exact retention of its loop holonomies, actual shared-kinetics coalescence, inherited restoring bounds at every level, a changing normalized learned conditional over 2/epsilon, and direct moving-target conditional-VFE estimates from actual Gaussian laws. The independently learned parent parameter differs by O_L(epsilon^4); retained paths have the conservative O_L(A epsilon^2) coupling error in (W37e), and exact retained dynamics remain available with the explicitly inherited memory. The induced parent score and metric come from the microscopic model, so there is no new parent rate.

No unresolved formation, normal-attraction, or recursive Gaussian-admission assumption remains in this family. The restriction is material: a regular Gaussian carrier, fixed microscopic contrast, compatible observations, scalar precision learning, finite depth, and a finite learning horizon. Arbitrary nonlinear models need their own controlled remainder, and incompatible observations need their own normal-force bound. A next mathematical action that would change the scope is to prove one of those extensions while retaining the exact physical and recognition kernels. Neither extension is claimed here.

No numerical experiment, symbolic software calculation, test suite, GPU run, Lean work, tamper check, Git operation, or Research-vault edit was performed for this document. Its evidence is the finite matrix algebra, exact Gaussian identities, differential inequalities, and explicit parameter choice above. This lane wrote only its assigned witness document; the parent owns shared status and the daily log.
