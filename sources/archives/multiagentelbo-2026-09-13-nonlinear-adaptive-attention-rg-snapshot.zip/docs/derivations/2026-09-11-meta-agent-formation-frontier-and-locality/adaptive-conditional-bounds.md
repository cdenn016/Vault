# Moving Gaussian conditionals, learned parent forces, and actual-law activation

September 12, 2026. This is the conditional-control lane for contract `contract-sha256-e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90`, in [the frozen problem contract](evidence/2026-09-12-adaptive-cyclic-rg-goal/problem-contract.json). Mechanism family ID: **ACRG-GAUSSIAN-TRANSPORT-MOVING-PRECISION-v1**. All results below concern one fixed base point and finitely many real configuration coordinates with proper laws. They do not replace the ambient associated-bundle and independent-link types.

The main result is a covariance comparison valid for a moving, noncommuting positive precision, followed by a direct conditional-KL bound for every fixed physical retention. The comparison survives Schur reduction and initialization from an actual retained law. It gives a useful bound over `c/epsilon` time without an exponential in `1/epsilon`. Exact retained paths are described by inherited Gaussian memory; a separate estimate quantifies a Markov replacement. The full normalized model score, its conditional correction, and its effect on a separately learned parent are included. Formation and appreciable learning are inputs to be proved by the cyclic witness, not assumptions declared solved by this lane.

## 1. Target, source boundary, and quantifiers

The user requires, for every prescribed finite depth, an exhibited cyclic model with genuine parameter learning, actual successive formation, normalized marked parents, and controlled conditional VFE and dynamics over appreciable adaptation. This lane proves the following reusable implication for every finite dimension, every fixed orthogonal flag of retained configuration subspaces, and every coupled solution in the regular class defined below. If the witness establishes positive precision, bounded relative precision speed, its mean-residual estimates, and its actual score bounds on `0 <= t <= c/epsilon`, then the displayed conditional-VFE, force, memory, and restart bounds hold throughout that interval. No conditional matching, equilibrium preparation of means, formation, or approximate recursive closure is a hypothesis of the theorem.

The added modeling assumptions are finite-dimensional Euclidean configuration transport, positive temperature, quadratic effective potential, a fixed positive model metric, and Gaussian initial recognition with positive covariance. Mean data are unrestricted. An open covariance neighborhood is allowed. The target is a theorem for this admitted class; it is not a theorem for arbitrary nonlinear laws or full-law Fisher inference.

The source starting points are [the current RG priority](RG-COMPLETION.md), [the exact full-law moving-conditional calculation](pointwise-learning-parent-closure.md), [the Gaussian link-learning calculation](pointwise-gaussian-link-learning.md), [the earlier configuration-diffusion entropy calculation](conditional-lag-and-parent-vfe.md), and [the normalized microscopic construction](microscopic-vfe-dynamics-construction.md), Sections 1–4 and 11. The first two moving-conditional sources use a full-law Fisher metric; their natural-parameter equation is not the stochastic configuration dynamics studied here. The existing entropy source supplies a local compact calculation with boundary current. Its factor `exp(Lt)` does not supply a uniform `1/epsilon` compact-boundary estimate, so no such inference is made here.

[Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex), `sec:full-graph-vfe-global`, `sec:full-graph-vfe-joint`, and `sec:full-graph-vfe-nonflat`, fixes the complete normalized joint, common channels, and retained holonomy/cut records. The live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), lines 938–968 and `sec:adiabatic_hierarchy`, supplies the conditional fast/slow motivation, explicitly subject to an attracting-fast-system obligation. The [September wiki synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>) preserves the difference between exact normalized composition and autonomous dynamics. These sources were read as prior work; their status labels are not a proof of the estimates below.

## 2. The joint law, the complete score, and the actual metric

Let `x in R^d` contain law-point coordinates, independently represented link coordinates, and every retained linear mark. Coordinates are in fixed local frames. Let `a` belong to a compact interval `I=[a_-,a_+]` inside an open parameter chart. Use Lebesgue reference on `x`, a fixed observation reference on `o`, and a fixed conditional reference on the inner physical variables `k`. Declare

$$
 P_a(do,dx,dk)=Z_0(a)^{-1}e^{-V_{0,a}(x)/T}L_a(o\mid x)dx do P_{{\rm in},a}(dk\mid x),
 \qquad T>0.
 \tag{1}
$$

Every conditional kernel is normalized, `0<Z_0(a)<infinity`, and the observed slice is finite and nonzero. The notation `do` in (1) denotes the declared observation reference. The density formula includes its normalizers. Fix a normalized inner recognition kernel `R(dk|x)`, independent of `a`, with `R(.|x) << P_in,a(.|x)`. Define its finite conditional KL by the expectation

$$
 d_a(x)=\mathbb E_{R(\cdot\mid x)}\log\frac{dR(\cdot\mid x)}{dP_{{\rm in},a}(\cdot\mid x)}.
 \tag{2}
$$

For arbitrary correlated outer recognition `Q(dx)=q(x)dx`, the restricted exact scaled VFE is

$$
 \mathcal F_T(Q,a)=T\mathbb E_{QR}\log\frac{q(x)dR(k\mid x)}{p_a(o,x)dP_{{\rm in},a}(k\mid x)}
 =T\mathbb E_Q\log q+\mathbb E_Q U_a+T\log Z_0(a),
 \tag{3}
$$

where `U_a=V_0,a-T log L_a(o|x)+T d_a(x)`. The theorem assumes that this exact effective potential is

$$
 U_a(x)=\tfrac12x^TK_ax-f_a^Tx+c_a^{\rm pot},\qquad K_a=K_a^T\succ0.
 \tag{4}
$$

This is an equality in the admitted model, not a Taylor approximation. All constant terms in (3)–(4) are retained. Completing the square defines

$$
 \Pi_a=N(K_a^{-1}f_a,TK_a^{-1}),\qquad
 c^{\rm eff}(a)=Z_0(a)^{-1}\int e^{-U_a(x)/T}dx,
 \qquad
 \mathcal F_T=T D(Q\Vert\Pi_a)-T\log c^{\rm eff}(a).
 \tag{5}
$$

The physical parent evaluator uses the conditional of the generative law in (1), not `Pi_a(.|y)`. The latter is the optimizing conditional of this particular restricted VFE. Gaussian tails and polynomial scores give all integrability needed below. More generally, the derivative in (6) requires dominated differentiation of the displayed normalizers and finite expectations of the displayed scores. An `a`-dependent recognition restriction would require its own derivative or a proved envelope identity and is not silently included.

At fixed `Q`, the complete model covector is

$$
 g(Q,a)=\left.\partial_a\mathcal F_T\right|_Q
 =\mathbb E_Q\partial_a V_{0,a}-\mathbb E_{P_{0,a}}\partial_a V_{0,a}
 -T\mathbb E_Q\partial_a\log L_a(o\mid x)+T\mathbb E_Q\partial_a d_a.
 \tag{6}
$$

The subtraction is the derivative of the prior partition function. A calibration observation depending on `a` contributes through its normalized likelihood in this same equation, including when independent of `x`. No externally prescribed schedule is used. Declare a positive scalar parameter metric `h(a) da^2/epsilon` and common unit microscopic configuration mobility. The coupled update is

$$
 dX_t=(-K_{a_t}X_t+f_{a_t})dt+\sqrt{2T}dB_t,
 \qquad \dot a_t=-\epsilon h(a_t)^{-1}g(Q_t,a_t),\qquad Q_t=\operatorname{Law}(X_t).
 \tag{7}
$$

The law-dependent parameter is deterministic for this exact-law evolution. It is not the score evaluated at one random particle. A positive configuration covariance is preserved and a Gaussian initial law stays Gaussian: integrating the linear SDE with its deterministic fundamental matrix makes it an affine function of Gaussian initial data and Gaussian noise. Its moments obey

$$
 \dot m=-K_am+f_a,\qquad
 \dot\Sigma=-K_a\Sigma-\Sigma K_a+2TI_d.
 \tag{8}
$$

For a Gaussian law, integration by parts has vanishing boundary terms. Differentiating (3) and using (7) gives

$$
 \frac d{dt}\mathcal F_T
 =-T^2\mathbb E_Q\left|\nabla_x\log(q/\pi_a)\right|^2
 -\epsilon h(a)^{-1}g(Q,a)^2\le0.
 \tag{9}
$$

Thus (7) is the declared configuration-transport gradient flow plus a slow model metric. It is not full-law Fisher–Rao flow. In a new scalar coordinate `b=psi(a)`, the covector is `g_b=g_a/psi'(a)` and the metric is `h_b=h_a/[psi'(a)]^2`; these transformations reproduce (7). The same full model metric is inherited by a parent. Replacing it by the marginal model Fisher metric would be a new update rule when the conditional depends on `a`.

## 3. Noncommuting covariance tracking on the adaptation interval

**Theorem 1.** Fix a finite horizon `H_*=c/epsilon`. Along any solution (7), suppose

$$
 K_t\succeq m_*I_d,\qquad
 -\rho K_t\preceq\dot K_t\preceq\rho K_t,
 \qquad \beta=2m_*-\rho>0,
 \tag{10}
$$

with constants independent of time on that interval. Suppose, for `0<=r_0<1`,

$$
 (1-r_0)TK_0^{-1}\preceq\Sigma_0\preceq(1+r_0)TK_0^{-1}.
 \tag{11}
$$

Set

$$
 r(t)=r_0e^{-\beta t}+\frac\rho\beta(1-e^{-\beta t}).
 \tag{12}
$$

At every time at which `r(t)<1`,

$$
 \boxed{(1-r(t))TK_t^{-1}\preceq\Sigma_t\preceq(1+r(t))TK_t^{-1}.}
 \tag{13}
$$

No commutativity between `K_t` at different times or between `K_t` and `Sigma_t` is required.

*Proof.* Put `C_t=TK_t^{-1}`. Differentiating the inverse and congruencing (10) gives `-rho C_t <= Cdot_t <= rho C_t`. Let `U_t=(1+r)C_t` and `L_t=(1-r)C_t`. Because `KC=CK=TI` and `2TI >=2m_* C`,

$$
 \dot U+KU+UK-2TI
 \succeq[\dot r-(1+r)\rho+2m_*r]C=0.
 \tag{14}
$$

Similarly,

$$
 \dot L+KL+LK-2TI
 \preceq[-\dot r+(1-r)\rho-2m_*r]C=-2\rho r C\preceq0.
 \tag{15}
$$

If a symmetric matrix difference satisfies `Edot+KE+EK=R` with `E_0>=0` and `R_t>=0`, its solution is

$$
 E_t=\Phi(t,0)E_0\Phi(t,0)^T+
 \int_0^t\Phi(t,s)R_s\Phi(t,s)^Tds\succeq0,
 \quad \partial_t\Phi(t,s)=-K_t\Phi(t,s).
 \tag{16}
$$

Applying (16) to `U-Sigma` and `Sigma-L` proves (13). This is a matrix comparison proof of the theorem. It uses no functional inequality or convergence theorem. ∎

For the cyclic candidate `K_a=aH+P_K+kappa I`, with `H>=0`, `HP_K=0`, `a>=a_->0`, and `|adot|<=epsilon V`, one has

$$
 -\rho K_a\preceq\dot K_a\preceq\rho K_a,
 \qquad \rho=\epsilon V/a_-.
 \tag{17}
$$

Indeed `H<=K_a/a_-`. The witness must prove `|h^{-1}g|<=V` from (6), as well as parameter confinement. It must choose the slowest positive restoring rate to dominate learning: `rho/m_*` must be small. Strong internal stiffness alone does not suffice if the last collective rate is smaller than `epsilon`.

With `r_0=0`, the covariance discrepancy is `O(epsilon/m_*)` uniformly on `0<=t<=c/epsilon`, including order-one changes of `a`. With a nonzero fixed `r_0`, the same discrepancy follows after the explicit initial layer `beta^{-1} log(r_0/delta)`, up to the floor `rho/beta`. Neither assertion constrains the initial means to equilibrium. A strict version of (11) supplies an open initial-covariance class. The theorem is conditional on remaining in the regular parameter region; a separate score argument must rule out exit.

## 4. Exact physical retention, conditional VFE, and force

Choose a fixed orthogonal split `x=(y,z)` with dimensions `p` and `k=d-p`, and write

$$
 K_a=\begin{pmatrix}A_a&B_a\\B_a^T&D_a\end{pmatrix},\quad
 f_a=\binom{f_{y,a}}{f_{z,a}},\quad
 S_a=A_a-B_aD_a^{-1}B_a^T,
 \tag{18}
$$

$$
 C_a=-D_a^{-1}B_a^T,\quad v_a=D_a^{-1}f_{z,a},\quad
 k_a(dz\mid y)=N(v_a+C_ay,TD_a^{-1})(dz).
 \tag{19}
$$

The target marginal has precision `S_a/T` and force vector `fbar_a=f_y,a-B_a v_a`. Gaussian integration supplies its full determinant and scalar normalization. No diagonal-covariance or independent-agent approximation occurs. Let `r_t=C_#Q_t`, and write the actual conditional `h_t(dz|y)=Q_t(dz|y)`. The exact VFE chain rule is

$$
 \mathcal F_T(Q_t,a_t)=\mathcal F_{T,1}(r_t,a_t)+T\Delta_t,
 \quad
 \Delta_t=\mathbb E_{r_t}\mathbb E_{h_t(\cdot\mid y)}
       \log\frac{dh_t(\cdot\mid y)}{dk_{a_t}(\cdot\mid y)},
 \tag{20}
$$

where `F_T,1(r,a)=T D(r||C_#Pi_a)-T log c^eff(a)`. It is the conditional-family parent objective of (3). Its scalar is exactly the same scalar as in (5). The physical generative pushforward and its evaluator remain separately recoverable from (1).

Define the mean residual

$$
 e_t=m_{z,t}-v_{a_t}-C_{a_t}m_{y,t},\qquad
 E_t^{\rm mean}=\frac{e_t^TD_{a_t}e_t}{2T},\qquad
 \Psi_d(r)=\frac{d r^2}{4(1-r)^2}.
 \tag{21}
$$

**Theorem 2.** Whenever (13) holds with `r(t)<1`,

$$
 \boxed{0\le\Delta_t\le\Psi_d(r(t))+E_t^{\rm mean}.}
 \tag{22}
$$

Consequently the discarded scaled VFE is at most `T Psi_d(r)+e^TD e/2`. This is a direct conditional-relative-entropy estimate; it is not inferred from path closeness.

*Proof.* Let `Ptilde` have covariance `TK_a^{-1}` and mean `(m_y,v_a+C_am_y)`. Its hidden conditional is exactly (19); its retained mean equals that of `Q`. The relative-entropy chain rule gives

$$
 \Delta=D(Q\Vert\widetilde P)-D(r\Vert\widetilde P_y).
 \tag{23}
$$

The Gaussian log-density expectation is

$$
 2D(N(m,\Sigma)\Vert N(\widetilde m,TK^{-1}))
 =\operatorname{tr}(K\Sigma/T)-d-\log\det(K\Sigma/T)
 +(m-\widetilde m)^TK(m-\widetilde m)/T.
 \tag{24}
$$

Its mean term is `e^TD e/T`, because the retained mean difference is zero. By (13), the eigenvalues of `K^(1/2) Sigma K^(1/2)/T` lie in `[1-r,1+r]`. For such an eigenvalue `u`, Taylor's integral formula and `(u-1-log u)''=1/u^2` give

$$
 0\le u-1-\log u\le\frac{(u-1)^2}{2(1-r)^2}.
 \tag{25}
$$

Discarding the nonnegative marginal term in (23) and summing (25) proves (22). ∎

This bound includes conditional regression errors caused by covariance lag. It is not merely the KL of the hidden marginal. The `d` in `Psi_d` is conservative; retaining the exact subtraction in (23) can sharpen it.

The actual retained drift conditional on the current retained configuration is

$$
 b_t^{\rm cur}(y)=-S_{a_t}y+\bar f_{a_t}+\delta b_t(y),\qquad
 \delta b_t(y)=-B_{a_t}\bigl(\mathbb E_{h_t}[z\mid y]-v_{a_t}-C_{a_t}y\bigr).
 \tag{26}
$$

For every `y`, the mean contribution to the Gaussian conditional KL is at least the quadratic displacement divided by `2T`. Hence

$$
 \boxed{\mathbb E_{r_t}|\delta b_t(Y)|^2
 \le2T b_{D,t}\Delta_t,\qquad
 b_{D,t}=\|B_{a_t}D_{a_t}^{-1}B_{a_t}^T\|.}
 \tag{27}
$$

For any vector `u`, `|Bu|^2 <= ||BD^{-1}B^T|| u^TDu`, which verifies the constant. The scalar VFE and the force estimate remain distinct outputs. In particular a small energy value for a model-channel coupling was not used as a bound on its derivative.

## 5. The discarded conditional contribution to actual learning

Let `g_1(r,a)=partial_a F_T,1(r,a)` at fixed `r`. Differentiating (20) at fixed actual conditional gives the exact covector defect

$$
 \boxed{g(Q,a)-g_1(r,a)
 =-T\mathbb E_Q\partial_a\log k_a(z\mid y).}
 \tag{28}
$$

This includes the original prior and observation normalizers through `g_1`. Only the conditional score is displayed as a difference. Set `w=z-v_a-C_ay`. Differentiating the normalized Gaussian conditional yields

$$
 \partial_a\log k_a
 =\tfrac12\operatorname{tr}(D_a^{-1}D_a')
 -\tfrac1{2T}w^TD_a'w
 +\tfrac1T w^TD_a(v_a'+C_a'y).
 \tag{29}
$$

The first term is the conditional determinant derivative and cannot be removed.

Here is a directly computable bound. Put

$$
 \mathcal A=D^{-1/2}D'D^{-1/2},\qquad
 S_y=TS^{-1},\qquad
 \mathcal W=T^{-1/2}D^{1/2}C'S_y^{1/2},
 \tag{30}
$$

$$
 z_m=T^{-1/2}|D^{1/2}e|,\qquad
 h_m=T^{-1/2}|D^{1/2}(v'+C'm_y)|.
 \tag{31}
$$

The nuclear norm, denoted `||.||_*`, is the sum of singular values. If (13) holds, then

$$
 \boxed{|g-g_1|\le T\left[
 r\left(\tfrac12\|\mathcal A\|_*+\|\mathcal W\|_*\right)
 +\tfrac12\|\mathcal A\|z_m^2+z_mh_m\right].}
 \tag{32}
$$

To prove it, use the linear change `(y,z) -> (y,w)`. Under the target covariance the two blocks are uncorrelated, with covariances `S_y` and `TD^{-1}`. The congruenced version of (13) says that the complete covariance, whitened by this block diagonal matrix, differs from identity in operator norm by at most `r`. Its hidden covariance error and its off-diagonal covariance block therefore both have norm at most `r`. Insert these facts in the expectation of (29), use `|tr(AE)|<=||A||_*||E||`, and separate the mean terms. This gives (32) with the displayed constants.

For the pure scaling case `K_a=aK_*`, `f_a=0`, one has `C'=v'=0`, `D'=D/a`, and the simpler exact expression and bound are

$$
 g-g_1=\tfrac12\left[\mathbb E_Qw^TD_*w-\frac{Tk}{a}\right],\qquad
 |g-g_1|\le\frac{Tkr}{2a}+\frac12 e^TD_*e.
 \tag{33}
$$

Thus a changing eliminated covariance can have an `O(epsilon)` score error even when its conditional KL is `O(epsilon^2)`. Squaring the score error because the KL is quadratic would be incorrect. With the isotropic observation correction `kappa I`, (29)–(32) retain the extra conditional-regression derivative.

## 6. Uniform retained-law and parameter comparison

The instantaneous conditional drift (26) defines a time-inhomogeneous affine Gaussian diffusion whose one-time laws are exactly `r_t`. Indeed the marginal of the full Fokker–Planck equation is its Fokker–Planck equation, and the positive Gaussian covariance and affine drift give the same unique mean/covariance solution. This auxiliary diffusion need not have the fine process's retained path law. Its role in this section is to compare one-time laws only.

Start an autonomous Gaussian parent at a time `tau` from the actual retained law and actual parameter:

$$
 \overline Q_\tau=r_\tau,\qquad \bar a_\tau=a_\tau,\qquad
 d\overline Y_t=(-S_{\bar a_t}\overline Y_t+\bar f_{\bar a_t})dt+\sqrt{2T}d\overline B_t,
 \quad \dot{\bar a}_t=-\epsilon h(\bar a_t)^{-1}g_1(\overline Q_t,\bar a_t).
 \tag{34}
$$

The metric `h` is inherited from (7). Assume on the two compared regular trajectories that `S_a>=k_*I`, that their second moments are bounded by `M_2`, and that the following explicit sensitivity constants are finite:

$$
 \left(\mathbb E\left|(-S_a+S_b)Y+\bar f_a-\bar f_b\right|^2\right)^{1/2}
 \le L_b|a-b|\quad\text{when }\mathbb E|Y|^2\le M_2,
 \tag{35}
$$

$$
 |h(a)^{-1}g_1(r,a)-h(b)^{-1}g_1(s,b)|
 \le L_q W_2(r,s)+L_a|a-b|.
 \tag{36}
$$

For example, `L_b=sup||S'|| sqrt(M_2)+sup|fbar'|`. These are finite Gaussian moment conditions, not stability assumptions about formation. The score of a normalized Gaussian joint is quadratic plus a scalar. On a second-moment bound, its expectation is Lipschitz in `W_2`: for a symmetric coefficient `A`,

$$
 |\mathbb E X^TAX-\mathbb E Y^TAY|
 \le2\|A\|\sqrt{M_2}\left(\mathbb E|X-Y|^2\right)^{1/2},
 \tag{37}
$$

and a linear coefficient has the corresponding bound `|b| W_2`. Parameter derivatives of those coefficients and scalars, together with bounds on `h^{-1}` and its derivative, give (36). Thus the witness can calculate the constants directly from the matrices and normalized score.

Define

$$
 b(t)=\sqrt{2T b_{D,t}\Delta_t},\qquad
 p(t)=h(a_t)^{-1}|g(Q_t,a_t)-g_1(r_t,a_t)|,
 \qquad C_*=L_a+L_qL_b/k_*.
 \tag{38}
$$

With equal initialization, for `tau<=t<=tau+c/epsilon`,

$$
 \boxed{|a_t-\bar a_t|\le
 \epsilon e^{\epsilon C_*(t-\tau)}
 \int_\tau^t\left[p(s)+\frac{L_q}{k_*}b(s)\right]ds,}
 \tag{39}
$$

$$
 \boxed{W_2(r_t,\overline Q_t)\le
 \frac{L_b}{k_*}\sup_{\tau\le s\le t}|a_s-\bar a_s|
 +\int_\tau^t e^{-k_*(t-s)}b(s)ds.}
 \tag{40}
$$

In particular, bounded defects `b<=b_*`, `p<=p_*` give parameter error at most `c exp(c C_*)[p_*+L_q b_*/k_*]` and retained-law error at most that number times `L_b/k_*`, plus `b_*/k_*`. There is no `exp(constant/epsilon)` term. Constants may depend on finite depth and interaction contrast.

For proof, synchronously couple the current-law diffusion in this section to (34), and let `x(t)` be the square root of the mean squared difference. The negative quadratic form of `S_a` gives the upper Dini inequalities

$$
 x'\le-k_*x+L_b y+b(t),\qquad
 y'\le\epsilon[L_qx+L_ay+p(t)],\qquad y=|a-\bar a|.
 \tag{41}
$$

The zero-distance cases follow by regularizing each norm and passing to the limit. Integrating the first inequality gives (40) with `x` in place of `W_2`, and also `integral x <= L_b integral y/k_*+integral b/k_*`. Insert the latter in the integral form of the second inequality and apply the elementary integrating-factor bound to obtain (39). Since this coupling bounds `W_2`, the statements follow. With nonzero initial errors `x_0,y_0`, add `exp(-k_*(t-tau))x_0` in (40), and replace the right-hand side of (39) by

$$
 e^{\epsilon C_*(t-\tau)}
 \left[y_0+\frac{\epsilon L_qx_0}{k_*}
 +\epsilon\int_\tau^t\left(p(s)+\frac{L_qb(s)}{k_*}\right)ds\right].
 \tag{42}
$$

This states the cost of unsynchronized inherited parameters instead of resetting them without accounting.

### 6.1. Stiffness-independent feedback for the cyclic calibration model

The generic constants in (35)–(42) need not remain bounded if a witness lets the largest microscopic stiffness diverge with `epsilon`. The cyclic model has a sharper comparison that does not use those constants. This subsection uses the exact model in [the normalized-model lane](adaptive-normalized-model.md), equations M4–M16, with `a in [1,21/10]`, `K_a=aH+P_K+kappa I`, observation forcing in `ker H`, and inherited metric

$$
 h(a)=TM(a)=1+\frac T2\operatorname{tr}[(A_0(a)^{-1}H)^2],\qquad
 A_0(a)\succeq\frac a2H+P_K.
 \tag{42a}
$$

All parents retain `ker H` and its independently forced dynamics. Work on the learned normal sector of dimension `p=rank H`, where the means are unforced. The complete microscopic covector, including calibration and the prior normalizer, is

$$
 g(Q,a)=a-2+\frac12\mathbb E_Q X^THX
 -\frac T2\operatorname{tr}(A_0(a)^{-1}H).
 \tag{42b}
$$

The parent covector at fixed retained law is this same expression evaluated in its optimizing conditional lift `Q^lift=r(dy) k_a(dz|y)`. To verify this envelope statement without assuming an envelope theorem, differentiate `F_T(r k_a,a)` directly. The additional derivative through `k_a` pairs with `T log[(r k_a)/pi_a]+T`, a retained-only function. Each conditional derivative integrates to zero. What remains is the derivative at fixed fine law, namely (42b) at the lift. Thus the parent learns from its own actual law, its own current parameter, and its own exact conditional lift. No fine parameter schedule is supplied.

Let `E_0` bound the initial normal mean energy `m_0^T K_1m_0`, and fix horizon `c/epsilon`. Suppose the initial covariance is `T K_1^{-1}`, or has an initial relative error already bounded by the value `r_*` below. Require

$$
 \rho=\frac{11}{10}\epsilon,\qquad
 r_* =\frac{\rho}{2m_*-\rho}\le\frac14,
 \qquad
 \delta=\frac12e^{11c/10}E_0+\frac{29}{8}Tp<\frac1{20}.
 \tag{42c}
$$

For every finite sequence of exact Gaussian Schur parents activated from the preceding actual law with the parameter carried continuously, all learned parameters remain in `[1,21/10]`, all have `|adot|<=11 epsilon/10`, and

$$
 \boxed{|a_t-(2-e^{-\epsilon t})|
 \le\delta(1-e^{-\epsilon t}),\qquad 0\le t\le c/\epsilon.}
 \tag{42d}
$$

The same assertion holds for the unreduced fine system. If a separately evolved parent starts from the fine retained law and fine parameter at `tau`, their parameters satisfy

$$
 \boxed{|a_t-\bar a_t|\le2\delta(1-e^{-\epsilon(t-\tau)}).}
 \tag{42e}
$$

In particular every such trajectory has `a(2/epsilon)>3/2` when `c=2`. The constants contain initial energy and dimension, but no bare factor of the largest stiffness or of `1/epsilon`.

Here is the proof, including the invariant-region bootstrap. On any provisional interval with `a in [1,21/10]` and `|adot|<=11 epsilon/10`, each parent precision satisfies (48), and Theorem 1 bounds its actual covariance by `r_*`. Marginalization at activation preserves that bound. For the actual normal parent mean, `mdot=-S_am`. Its energy obeys

$$
 \frac d{dt}(m^TS_am)=m^T\dot S_am-2m^TS_a^2m
 \le\rho m^TS_am.
 \tag{42f}
$$

At an activation, the new Schur mean energy is at most the previous energy, since the Schur value is the minimum over the discarded coordinates. Hence, over the sum of all elapsed stage intervals, `m^TS_am <= exp(11c/10) E_0`. This uses no bound on a Hessian maximum. The root forcing does not enter this normal-sector equality.

Under the optimizing lift, completing the square gives exactly

$$
 \mathbb E_{Q^{\rm lift}} X^TK_aX
 =m_y^TS_am_y+\operatorname{tr}(S_a\Sigma_y)+T p_{\rm hid}
 \tag{42g}
$$

on the normal sector. Here `p_hid` counts every eliminated learned normal coordinate; retained loop modes are counted in the retained trace. The covariance term is at most `(1+r_*)T p_ret`. Since `H<=K_a/a`, the lifted expectation of `X^THX` is bounded by

$$
 a^{-1}\left[e^{11c/10}E_0+(1+r_*)Tp\right].
 \tag{42h}
$$

The unreduced law has the same bound, with no hidden block. From (42a), `tr(A_0^{-1}H)<=2p/a` and `0<=h-1<=2Tp/a^2`. In (42b), write `g=a-2+u`. Then

$$
 |u|\le\frac12e^{11c/10}E_0+\frac{13}{8}Tp=:\zeta,
 \qquad
 \left|-h^{-1}g-(2-a)\right|\le\zeta+2Tp=\delta.
 \tag{42i}
$$

The second estimate uses `sup_[1,2.1]|2-a|=1` and `h>=1`. The strict condition `delta<1/20` implies an inward velocity at both parameter endpoints and `|adot|<11 epsilon/10`. It therefore closes both provisional assumptions by a first-exit argument. Equations (42f)–(42h), positivity, and the finite-dimensional Gaussian moment equations also prevent a finite-time loss of existence on the required interval. Finally write `adot=epsilon(2-a)+epsilon R_t` with `|R_t|<=delta` and integrate the scalar linear equation. This proves (42d); subtracting two equations with the same activation parameter proves (42e). Each correction `R_t` is generated by that trajectory's own law and normalized score. The reference `2-exp(-epsilon t)` is a comparison solution, not a prescribed learning schedule.

Thus for the witness scaling `E_0<=C_L A^2J_1`, `Tp<=C_L T`, conditions (42c) give `delta=O_L(A^2J_1+T)`. In particular `A^2J_1=epsilon^4` makes the independent-parameter discrepancy `O_L(epsilon^4)`, provided the other displayed conditions hold. This is an all-depth admission for self-learning parents; it does not by itself establish their mean-formation windows.

### 6.2. Parameter sensitivity without a large-stiffness exponential

The normal Schur precisions of the cyclic family satisfy `0<=partial_a S_a<=S_a/a_-`. Put `R_a=exp[(a_+-a_-)/a_-]` and `C_a^*=R_a/a_-`. Integrating this relative inequality and applying Cauchy–Schwarz in the positive form `partial_a S_a` gives, for every `a,b in I`,

$$
 |v^T(S_a-S_b)w|
 \le C_a^*|a-b|\sqrt{v^TS_av}\sqrt{w^TS_bw}.
 \tag{42j}
$$

Indeed at each intermediate parameter `q`, `S_q<=R_a S_a` and `S_q<=R_a S_b`; integrate `|v^TS_q'w| <= a_-^{-1}sqrt(v^TS_qv)sqrt(w^TS_qw)`. This supplies the displayed constant independently of the eigenvalue ratio of `S`.

For two unforced parent means with the same initial value and different admitted parameter paths, let `u=m_a-m_b`. Then

$$
 \frac d{dt}|u|^2
 \le-u^TS_{a_t}u+(C_a^*)^2|a_t-b_t|^2m_b^TS_{b_t}m_b.
 \tag{42k}
$$

The identity `d|m_b|^2/dt=-2m_b^TS_bm_b` therefore proves

$$
 \boxed{\sup_{\tau\le t\le H_*}|m_a(t)-m_b(t)|
 \le\frac{C_a^*}{\sqrt2}|m_\tau|
 \sup_{\tau\le t\le H_*}|a_t-b_t|.}
 \tag{42l}
$$

The retained root response is identical and cancels in this comparison. Combining (42e) with (42l) gives an `O_L(A delta)` mean perturbation with no elapsed-time or largest-stiffness multiplier. For an actual marginal versus a Schur parent, the additional deterministic force is `-B_ae_t`; its contribution can be paid directly by (40), or in energy norm by integrating `|S_a^{-1/2}B_ae_t|^2`. This term concerns the actual conditional mean and must not be set to zero because the covariance is near its target.

A covariance-law comparison likewise avoids stiffness maxima. If two actual parent covariances at time `t` obey (13) with errors `r_1,r_2<1` at parameters `a,b`, let `C=TS_a^{-1}` and `q=|a-b|/a_-`. Their covariance contribution to `W_2` is at most

$$
 \sqrt{\operatorname{tr}C}\left[
 \frac{r_1}{1+\sqrt{1-r_1}}+
 \max\left\{e^{q/2}\sqrt{1+r_2}-1,
                  1-e^{-q/2}\sqrt{1-r_2}\right\}\right].
 \tag{42m}
$$

To verify it, couple each centered Gaussian to `N(0,C)` using the same standard Gaussian and the covariance square root in `C`-whitened coordinates. The whitened covariance eigenvalues lie in `[1-r_1,1+r_1]` for the first law and in `[e^{-q}(1-r_2),e^q(1+r_2)]` for the second. Bound their square-root deviations from one and apply the triangle inequality for the coupling's root mean square distance. Adding the mean distance gives a valid `W_2` bound. Since `tr C<=Tp/m_*`, the estimate involves the smallest admitted rate, which is already controlled in (42c), and does not introduce the largest stiffness.

## 7. Actual retained paths: exact memory and a separate approximation bound

For the actual fine process after `tau`, define the hidden propagator by

$$
 \partial_t\Phi_D(t,s)=-D_{a_t}\Phi_D(t,s),\qquad \Phi_D(s,s)=I,
 \qquad \|\Phi_D(t,s)\|\le e^{-d_*(t-s)}
 \tag{43}
$$

when `D_a>=d_*I`. Variation of constants gives the exact hidden process

$$
 Z_t=\Phi_D(t,\tau)Z_\tau+
 \int_\tau^t\Phi_D(t,s)(f_{z,a_s}-B_{a_s}^TY_s)ds
 +\sqrt{2T}\int_\tau^t\Phi_D(t,s)dB_s^z.
 \tag{44}
$$

Substitution into `dY=(-A_aY-B_aZ+f_y,a)dt+sqrt(2T)dB^y` gives an exact retained Volterra equation. Its kernel is `B_a(t) Phi_D(t,s) B_a(s)^T`, its initialization is the actual joint Gaussian `(Y_tau,Z_tau)`, and its colored noise is the last term in (44) multiplied by `-B_a(t)`. All these objects are inherited. This description has **zero retained path-law error**. It retains sufficient memory; it does not assert an autonomous Markov quotient or a reduction in stored Gaussian moment count. The coupled model score is evaluated from the moments reconstructed by (44), or equivalently (8), and therefore remains (6).

Ordered elimination of two hidden blocks gives the same retained path law as eliminating their union: both operations substitute the unique solution of the same finite linear SDE, with the same initial Gaussian law and noises. At the law level this is also associativity of integrating a normalized joint path law. Positivity of the full covariance and finite interval Gaussian moments justify each integration. Kernel coefficients and noise covariances generated by elimination are retained, not projected to a new pairwise ansatz.

For a Markov path replacement, one must account for hidden thermal fluctuations even when `Delta=0`. Let `E_t=Z_t-v_a-C_aY_t`. From (13) and the target block factorization,

$$
 \mathbb E|B_aE_t|^2\le
 T(1+r(t))\operatorname{tr}(B_aD_a^{-1}B_a^T)+|B_ae_t|^2
 =:b_{\rm path}(t)^2.
 \tag{45}
$$

Compare the actual `Y_t` with the Schur diffusion driven by the same retained Brownian motion and the same parameter path, started at `Y_tau`. Dissipativity gives

$$
 \left(\mathbb E|Y_t-\overline Y_t|^2\right)^{1/2}
 \le\int_\tau^t e^{-k_*(t-s)}b_{\rm path}(s)ds,
 \tag{46}
$$

$$
 \boxed{\mathbb E\sup_{\tau\le t\le H_*}|Y_t-\overline Y_t|^2
 \le\frac1{k_*}\int_\tau^{H_*}b_{\rm path}(s)^2ds.}
 \tag{47}
$$

Indeed the squared path difference has derivative at most `-k_*|difference|^2+|B E|^2/k_*`; integrate, take the supremum, and then expectation. For separately learned parameter paths, an additional drift has `L^2` norm bounded by `L_b|a-abar|`; replacing `b_path` in (46) by their sum is valid, and twice the sum of their squares in (47) is a valid bound. Equations (39)–(42) can likewise be run with `b_path` to obtain a conservative joint parameter/path comparison.

Over `c/epsilon`, (47) requires the displayed integral to be small if a small uniform path error is desired. There is no claim that `Delta=O(epsilon^2)` alone makes it small. For the exact memory parent no such approximation condition is needed. A finite memory truncation has an additional exponentially decaying convolution tail under (43), but dropping the colored noise or changing its covariance is another approximation and is not covered by merely truncating that deterministic kernel.

## 8. Schur stability and sequential actual-law activation

**Theorem 3.** Let `R_0=R^d superset R_1 superset ... superset R_L` be a fixed orthogonal flag. Retained root, cycle, and cut marks belong to every carrier where the construction requires them. Obtain `K_a^(s)` and its affine force by exact Gaussian integration over the orthogonal complement of `R_s`. Then the following statements hold for each prescribed finite `L`.

First, every parent is positive and normalized, ordered integration equals direct integration, and its full scalar and determinant terms are those obtained from (3). The inherited unit mobility on the retained orthogonal coordinates is unchanged; it is not multiplied by the number of children or a newly chosen rate.

Second, if `K_a>=m_*I` and `-rho K_a<=Kdot_a<=rho K_a`, then

$$
 K_a^{(s)}\succeq m_*I,\qquad
 -\rho K_a^{(s)}\preceq\dot K_a^{(s)}\preceq\rho K_a^{(s)}.
 \tag{48}
$$

For one step, write `X_a=[I;-D_a^{-1}B_a^T]`. The Schur identity and its derivative are

$$
 S_a=X_a^TK_aX_a,\qquad \dot S_a=X_a^T\dot K_aX_a.
 \tag{49}
$$

The terms containing `Xdot` vanish because `KX=[S;0]` and the retained rows of `Xdot` are zero. Congruencing the relative inequality proves the second part of (48). Also `y^TSy=min_z (y,z)^TK(y,z)>=m_*|y|^2`, proving the lower bound. Iteration proves (48).

Third, the actual retained covariance satisfies

$$
 (1-r(t))T(K_{a_t}^{(s)})^{-1}
 \preceq\Sigma_t^{(s)}\preceq
 (1+r(t))T(K_{a_t}^{(s)})^{-1},
 \tag{50}
$$

because a principal covariance block preserves Loewner inequalities and `(K^{-1})_ret,ret=(K^(s))^{-1}`. Thus at an activation time `tau_s`, the next parent may start from **the actual law** `Q_tau_s^(s)`, with its actual mean and covariance. No hidden or retained state is replaced by an equilibrium sample. Its autonomous covariance then satisfies Theorem 1 with initial defect `r(tau_s)`, provided its own learned parameter remains in the admitted region and satisfies the speed bound. Those bounds are derived from its full inherited objective and (28)–(32), not assumed from the fine score by name alone.

At the explicit two-level interface `x=(y,z_1)`, `y=(w,z_2)`, compute `Delta_1` from (22) on the fine law, and compute `Delta_2` from (22) on either the actual `y` marginal or the actually activated first parent. The covariance condition in both cases follows from (50) or its restart version. The required means are their respective actual means. Exact disintegration gives

$$
 D(Q(dx\mid w)\Vert\Pi_a(dx\mid w))\text{ averaged over }Q_w
 =\Delta_1+\Delta_2.
 \tag{51}
$$

For clarity, `Delta_2` on the right of (51) is the discrepancy of the actual fine `y` marginal, not that of an independently evolved approximation. Equations (39)–(42) compare the approximation when needed; its separate conditional VFE is recomputed with its own actual moments. Repeating this argument gives `sum_s Delta_s` for a fixed finite flag. Exact marked-law composition and quantitative dynamical replacement are different statements at each step.

If `f_a=0` on the normal sector, the mean residual in (21) has the directly checkable form

$$
 e=D_a^{-1}(K_am)_z,\qquad
 E^{\rm mean}=\frac1{2T}(K_am)_z^TD_a^{-1}(K_am)_z.
 \tag{52}
$$

This is the interface for the formation witness's transverse estimates. If tangent heterogeneous forcing belongs to the retained root space, its hidden component is zero and (52) remains valid on the normal sector. A coarse mean being close to an actual mean can be transferred into (21) using the operator norm of `[-C_a,I]` and the displayed parameter sensitivities; it cannot replace a bound on the actual transverse residual without this calculation.

### 8.1. Exact restoring equation for the conditional mean

The following calculation supplies the mean interface in (52) for an arbitrary ancestor parent. In this subsection put the hidden block first, and write its unforced normal mean equations as

$$
 \binom{\dot z}{\dot y}
 =-\begin{pmatrix}F&G\\G^T&A\end{pmatrix}\binom z y,
 \qquad S=A-G^TF^{-1}G,
 \qquad e=z+F^{-1}Gy.
 \tag{52a}
$$

The matrices are evaluated along the ancestor's own learned parameter trajectory. Define `L=F^{-1}G`. Direct differentiation, using `zdot=-F e` and `ydot=-S y-G^Te`, gives exactly

$$
 \dot e=-(F+F^{-1}GG^T)e+(\dot L-LS)y.
 \tag{52b}
$$

In particular there is no assumption that the conditional mean is instantaneously minimized. If `F>=d_*I` and `|F^{-1/2} Fdot F^{-1/2}|<=rho`, then `r_m=(e^TFe)^{1/2}` satisfies

$$
 r_m'\le-(d_*-\rho/2)r_m+
 \|F^{1/2}(\dot L-LS)\||y|.
 \tag{52c}
$$

For proof, the derivative of `r_m^2` contains `-2e^TF^2e-2e^TGG^Te` from (52b). The second form is nonnegative before its minus sign, the first is at most `-2d_*r_m^2`, and the metric derivative is at most `rho r_m^2`. Cauchy–Schwarz bounds the remaining term. Division by `2r_m` and a regularization at zero prove (52c).

Suppose a witness proves at level `s`, uniformly in the parameter interval and for the relevant ancestor Schur matrices,

$$
 F\succeq c_LJ_sI,\qquad
 \|G\|\le C_LJ_{s+1},\qquad
 \|\partial_aG\|\le C_LJ_{s+1},\qquad
 \|F^{-1/2}(\partial_aF)F^{-1/2}\|\le C_L,
 \tag{52d}
$$

and `||S||<=C_L J_s+1` on the coupled slow subspace, `|y|<=C_L A`, and `|adot|<=C_L epsilon`. Retained decoupled root and holonomy modes may be excluded from this coupled subspace: their columns in `G` vanish, so their possibly large `S` eigenvalues do not enter `LS`. These precise exclusions must be checked in the witness. The two source estimates are

$$
 \|F^{1/2}\dot L\|
 \le\|F^{-1/2}\dot G\|
 +\|F^{-1/2}\dot F F^{-1/2}\|\|F^{-1/2}G\|
 \le C_L\epsilon J_{s+1}/\sqrt{J_s},
 \tag{52e}
$$

$$
 \|F^{1/2}LS\|\le C_LJ_{s+1}^2/\sqrt{J_s}.
 \tag{52f}
$$

Consequently, if `C_L epsilon <= c_L J_s/2`, integrating (52c) gives

$$
 r_m(t)\le e^{-c_LJ_s(t-\tau)/2}r_m(\tau)
 +C_L A\frac{J_{s+1}^2+\epsilon J_{s+1}}{J_s^{3/2}}.
 \tag{52g}
$$

With `r_m(tau)^2<=C_L A^2J_1`, the directly relevant conditional-VFE term is

$$
 \boxed{\frac{r_m(t)^2}{2T}\le
 C_L\frac{A^2}{T}\left[
 J_1e^{-c_LJ_s(t-\tau)}+
 \frac{J_{s+1}^4+\epsilon^2J_{s+1}^2}{J_s^3}
 \right].}
 \tag{52h}
$$

This estimate has no hidden dependence on the elapsed adaptation horizon. At the final reduction, if all surviving root/holonomy modes are decoupled, `G=0` and the forcing terms are exactly zero; writing `J_s+1=0` is then legitimate. If `J_s+1>=1` and `epsilon<=1`, its two displayed polynomial terms can be bounded by twice the first. With other scale choices both terms must remain.

The scalar equation (52c) and its consequences are proved here. The structural cross-block estimates (52d), the coupled-subspace identification, and the initial residual estimate remain the finite cyclic witness's matrix obligations. They cannot be inferred from a spectral lower bound alone. Once they hold for every ancestor and own-parameter trajectory, (52h) applies after each actual-law activation; the covariance theorem applies independently to that same law.

## 9. A changing conditional is quantitatively detectable

The covariance theorem does not require a small total parameter displacement. To check that an admitted learned path really changes discarded geometry, suppose on a normal sector

$$
 K_a=aH+\kappa I,\qquad H\succeq h_*I>0,
 \qquad a_1-a_0\ge c_a>0.
 \tag{53}
$$

Set `c_kappa=kappa/h_*`. Since `partial_a K=H>=K/(a+c_kappa)`, (49) gives the same inequality for every Schur precision and every subsequently eliminated conditional precision `D_a`. Therefore

$$
 D_{a_1}\succeq\frac{a_1+c_\kappa}{a_0+c_\kappa}D_{a_0}
 \succeq(1+\delta)D_{a_0},\qquad
 \delta=\frac{c_a}{a_0+c_\kappa}>0.
 \tag{54}
$$

The first inequality follows by differentiating `D_a/(a+c_kappa)` in Loewner order and integrating. For every fixed retained value `y`, Gaussian conditional KL therefore obeys

$$
 \boxed{D(k_{a_0}(\cdot\mid y)\Vert k_{a_1}(\cdot\mid y))
 \ge\frac{k}{2}\bigl[\delta-\log(1+\delta)\bigr]>0.}
 \tag{55}
$$

Its covariance eigenvalues are those of `D_a0^(-1/2) D_a1 D_a0^(-1/2)`, all at least `1+delta`; the Gaussian mean term is nonnegative. When `c_a`, `a_0`, and `kappa/h_*` are fixed independently of `epsilon`, so is this lower bound. Retained null/root directions are excluded from the normal-sector hypothesis in (53). Retained loop modes may also change; they are not counted as discarded modes in (55).

This establishes the conditional-change implication. It does not establish `a_1-a_0>=c_a`; that must be proved from the complete actual model score (6) on the same interval. A prescribed path or a change in a retained-only scalar does not satisfy this hypothesis map.

## 10. Witness interface, failure tests, and remaining obligation

The cyclic witness supplies the finite network, typed independent links, retained loop/cut records, positive microscopic strengths, and physical orthogonal flag. To invoke these theorems it must give the exact matrices `K_a`, `f_a`, and the generative factors producing them; a prior normalizer and any evaluator compensation; bounds on `h^{-1}g` and parameter confinement from (6); a lower restoring rate `m_*`; and the actual mean residual (52) at each activation and over its asserted persistence interval. It must also give the observation/exterior force and its retained/hidden projections. These are concrete matrix and moment obligations. No assumption that children have already equilibrated is accepted in their place.

For a prescribed error target and fixed finite depth, one valid order of choices is to choose finite microscopic contrast and the formation initial means first, then sufficiently small positive temperature and observation perturbations consistent with those means and the score bound, and finally learning speed small relative to every admitted restoring rate. The actual inequalities (12), (22), (27), (32), and (39)–(47) determine whether that order works in the witness. The order itself is not a proof of a nonempty joint regime. In particular making temperature small can enlarge `E^mean`; the witness must establish the transverse mean bound on that same temperature scale.

The following conditions falsify applicability of this mechanism family, without establishing a project-wide impossibility: a nonpositive prior precision; omission of a varying normalizer in (6); a claimed Gaussian target obtained only by an uncontrolled nonlinear approximation; `rho` comparable to the slowest restoring rate when a small covariance error is asserted; a retained map that discards a required cycle record; use of (40) as a claim about the actual retained path law; use of conditional KL alone to drop the thermal term in (45); or starting a later parent from an equilibrium law in place of the actual retained law. A time-dependent retention map additionally needs its coordinate-velocity terms and is outside this fixed-flag theorem.

The strongest result of this lane is the proved long-horizon covariance, conditional-VFE, model-score, and restart interface for the declared Gaussian transport family, together with exact retained path memory. The minimal remaining joint obligation is the witness's proof that its cyclic mean-formation and score estimates satisfy these inequalities simultaneously on an interval of length `c/epsilon` with an order-one parameter change. Once that hypothesis map is supplied, substitution of its constants into (12), (22), (27), (32), and the chosen path bound materially determines whether the full adaptive construction closes.

This document is an analytical derivation. No simulation, symbolic package, test suite, GPU computation, Lean work, tamper check, or Research-vault edit was used to establish it. Only this assigned document was written by this lane; the existing ledger and shared progress files were not edited.
