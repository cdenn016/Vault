# Finite-coherence regions and native ancestry response

September 12, 2026. The transported parent-predictive model has a nonempty finite-coherence region in which two proper blocks have greater evidence than every other admitted ancestry. This is proved for the entire positive child-variance axis at fixed b=c=1, including every candidate and tie. At the common unit exact posterior, the actual finite-rate native learner initially increases these two blocks' odds against the single block for every fixed positive partition prior. These are conditional static and local dynamic results. Reaching that region, remaining there, and obtaining a complete resource advantage are separate unresolved requirements.

## 1. Existing construction and the question resolved

The [transported-prior derivation](transported-parent-priors-and-induced-couplings.md) already defines the normalized downward generator, the original labeled observation channel, the shared structural mixture, the native E/M flow and the correlated recursive parent prior. Its Sections 5-6 establish that one block wins at a=b=c=1, whereas the singleton posterior dominates as a approaches zero at fixed positive b,c. Neither boundary excludes useful intermediate coherence. This continuation resolves the intervening comparison and the initial direction of the same learner without choosing a favorable numerical variance or ancestry prior.

The source motivation is the existing [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) sections `sec:meta_agent_variational` and `sec:epistemic_collapse`: licensing needs the actual post-merge model and cost, and useful formation does not require perfect consensus. The [wiki's operational parent requirements](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>), [complete parent channel](shared-parent-complete-channel-and-recursive-cost.md) and [native-learning derivation](shared-parent-native-learning-and-memory.md) remain in force. These sources motivate and type the construction; the calculations below establish only the stated specialization.

Work remains at the single base point. Conditional on a connected four-cycle partition R and its root/tree decoration H, the model is Y distributed as N(0,v I_4), block coordinates Z_A conditional on Y distributed as N(Y,b I_4), independent links ell_e distributed as N(0,c I_4), and child law-mean coordinates mu_i conditional on Z,ell,H distributed as N(Z_R(i)+g_i,a I_4). The g_i are actual internal tree-path link sums. A fixed positive prior pi_R is arbitrary; roots and trees are conditionally uniform, and both channels share H. There are twelve connected partitions, forty-five decorations and thirty-one distinct residual covariance functions.

Write L=BB^T for the cycle Laplacian, J_R=BR for the block-incidence map and C_H=I-BP_H for the tree-path residual map. The covariance in each coordinate direction and the evidence for the unchanged ordered record batch are

\[
 \Gamma_H(a,b,c)=aL+bJ_RJ_R^T+cC_HC_H^T,
 \qquad
 e_H(a,b,c)=\sum_{S\subseteq E}
 \frac{(-1)^{|S|}}{\det[I+\Gamma_H(a,b,c)\operatorname{diag}(n+1_S)]},
 \quad n=(8,1,8,1).
 \tag{1}
\]

There is one failure per label and channel, in addition to the stated successes. The joint two-channel evidence is

\[
 \mathcal E_R(a,b,c)=\frac1{N_R}\sum_{H:R(H)=R}e_H(a,b,c)^2.
 \tag{2}
\]

The shared H requires the average of squares. Squaring the average would change the model. The common translation root and v remain ancillary for these internal records. No new observations, empirical preparation or latent sample path is supplied here.

## 2. Exact classification for every positive a at b=c=1

**Conditional classification.** Let alpha and beta be the positive algebraic numbers specified below. Among all twelve connected partitions, the evidence maximizer on the full positive a axis is as follows.

| Child variance at b=c=1 | Maximizing partition |
| --- | --- |
| 0<a<alpha | Four singletons, uniquely |
| a=alpha | Four singletons and {0,1},{2,3}, and no others |
| alpha<a<beta | {0,1},{2,3}, uniquely |
| a=beta | {0,1},{2,3} and {0,1,2,3}, and no others |
| beta<a | {0,1,2,3}, uniquely |

The exact endpoint definitions use the unique positive roots of the corresponding rational comparison numerators. Their rational isolating intervals are

\[
 \frac{863481278245}{281474976710656}<\alpha<
 \frac{431740639123}{140737488355328},\qquad
 \frac{46735407510261}{281474976710656}<\beta<
 \frac{23367703755131}{140737488355328}.
 \tag{3}
\]

Their approximate values are alpha=0.00306770174861 and beta=0.166037521546. The intervals and defining polynomials, rather than those rounded decimals, specify the boundaries.

The computation first constructs each conditional evidence as an exact rational function over Q(a). For all thirty-one covariance functions and sixteen failure subsets, det[I+Gamma_H(a,1,1) diag(n+1_S)] is a polynomial of degree at most three with nonnegative coefficients and strictly positive constant term. These coefficients are retained in [evidence-functions.json](evidence/finite-coherence-classification/evidence-functions.json). In particular, none of the original denominators vanishes on a>0. Evaluating the constructed rational functions at a=1 reproduces every previously saved conditional and partition evidence exactly.

Averaging the squared functions gives seven distinct partition evidence functions. Equality within each row below is an exact rational identity on the entire axis, rather than a tie at sampled points.

| Group | Partitions sharing one evidence function | Numerator/denominator degree |
| --- | --- | ---: |
| 0 | {0,1,2,3} | 112 / 118 |
| 1 | {0,1},{2,3} | 88 / 94 |
| 2 | Each connected triple and its singleton | 282 / 288 |
| 3 | {0,1},{2},{3} and {0},{1},{2,3} | 90 / 96 |
| 4 | {0,3},{1,2} | 88 / 94 |
| 5 | {0,3},{1},{2} and {0},{1,2},{3} | 90 / 96 |
| 6 | {0},{1},{2},{3} | 32 / 38 |

For each of the twenty-one distinct group pairs, [comparison-polynomials.json](evidence/finite-coherence-classification/comparison-polynomials.json) stores the reduced numerator and denominator of the difference, with rational coefficients in ascending degree order. Every comparison denominator has nonnegative coefficients and a positive constant term. Every numerator, after omitting zero coefficients, has either zero or one sign change. This permits an elementary complete root count.

For zero sign changes, every nonzero coefficient has the same sign, so the polynomial has that strict sign for positive a. For one sign change, multiply by minus one if necessary and remove any initial power of a. The polynomial then has the form

\[
 p(a)=-\sum_{i\leq j}c_i a^i+\sum_{i>j}d_i a^i,
 \qquad c_i,d_i\geq0,
 \tag{4}
\]

with a nonempty negative group and a nonempty positive group, and j the highest negative exponent. The derivative of p(a)/a^j is strictly positive on a>0: the negative terms of degree below j have positive derivatives after division, the degree-j term is constant, and every positive term has positive derivative. The limit at zero is negative or negative infinite, and the limit at infinity is positive infinite. There is exactly one positive root. At that root p'(a)=a^j (p(a)/a^j)' is positive, so the root is simple. Reversing the initial sign preserves simplicity and the count.

Groups 1 and 2 each exceed group 4 everywhere, and group 3 exceeds group 5 everywhere. Each of the other eighteen pairs crosses exactly once. Exact integer evaluation and rational bisection isolate all eighteen roots in disjoint intervals of width at most 2^-48. This isolates already-proved unique algebraic roots; it does not compare evidence on a numerical parameter grid. The small-a group order is

\[
 6>3>5>1>2>4>0,
 \qquad\hbox{and the large-a order is}\qquad
 0>2>1>4>3>5>6.
 \tag{5}
\]

Sorting the disjoint root intervals and exchanging the crossing adjacent groups gives the full ordering on every intervening interval. Every exchange is checked to involve adjacent groups, and the final comparison signs agree with every leading coefficient. Exactly two exchanges change the maximizer: group 1 crosses group 6 at alpha, and group 0 crosses group 1 at beta. These are root indices 6 and 15 in the zero-based full list. The other sixteen crossings occur below the maximum. [classification.json](evidence/finite-coherence-classification/classification.json) retains all roots, signs, intermediate orders, ties and maximizer transitions. Equations (1)-(5), the exact coefficient tables and the sign proof establish the stated classification without an unexamined candidate or interval.

## 3. Prior dependence and the remaining licensing cost

The classification concerns evidence. The model posterior is proportional to pi_R times that evidence, so it is not an unconditional MAP statement for arbitrary prior weights. At any interior point of the pair-winning interval, the strict inequalities also hold in an open neighborhood of (a,b,c)=(a,1,1), by continuity of the finite family of positive Gaussian likelihood integrals. Thus the pair region is not confined to a curve, although its full three-parameter boundary has not been classified.

Let P denote {0,1},{2,3}. At such a parameter point the posterior selects P uniquely precisely when

\[
 \frac{\pi_R}{\pi_P}<\frac{\mathcal E_P}{\mathcal E_R}
 \quad\hbox{for every }R\ne P.
 \tag{6}
\]

This defines a nonempty open region of positive structural priors containing the uniform prior. No numerical prior is selected in the calculation. Likewise, the logarithm of the pair evidence divided by the largest competing evidence is strictly positive. It is a data-likelihood margin, not a measured resource gain.

If a supplied organizational cost C_R is combined with the posterior negative log weight, the actual licensing condition is

\[
 C_P-C_R<\log\frac{\pi_P\mathcal E_P}{\pi_R\mathcal E_R}
 \quad\hbox{for every }R\ne P.
 \tag{7}
\]

Equation (7) retains the actual prior and model comparison; dropping them or inventing a penalty would change the question. The present result supplies a nonzero permissible cost margin for appropriate priors. It does not supply measured C_R, automatically count the parent as cheaper, or license a preferred grouping outside that margin.

## 4. Initial response of the full native learner

The native equations evolve the model and recognition parameters together. Use model precisions u_j, recognition precisions rho_j, block-count parameter omega and likelihood power s from the [transported-prior flow](transported-parent-priors-and-induced-couplings.md), Section 4. Initialize at u_j=rho_j=1, omega=0, s=1, with the exact posterior of the common unit model and any fixed positive pi_R. The root remains matched. The recognition equations are

\[
 \dot\rho_j=u_j-\rho_j,\qquad
 \dot\omega=2\log u_b-\omega,\qquad
 \dot s=1-s.
 \tag{8}
\]

For each partition R, let d_R=(d_Ra,d_Rb,d_Rc) be the saved fixed-R unit native variance derivative, obtained by averaging the complete primitive posterior energies over its decorations. The saved [transported result](evidence/transported-parent-prior/result.json) defines each d_R exactly. Equivalently, d_Rj=m_Rj-1 for its Gaussian energy M-coordinate. Let Z_pi=sum_R pi_R mathcal E_R, gamma_R=pi_R mathcal E_R/Z_pi, and K_pi=sum_R pi_R k_R. All evidences in this section are at unit variances. The actual full model velocity is

\[
 A=\dot a(0)=\sum_R\gamma_R d_{Ra},\qquad
 B_0=\dot b(0)=\frac{\sum_R\gamma_R k_Rd_{Rb}}{K_\pi},\qquad
 C_0=\dot c(0)=\sum_R\gamma_R d_{Rc}.
 \tag{9}
\]

The prior-count metric K_pi in B_0 is required by the complete model Fisher matrix. Averaging fixed-R b velocities without this factor would produce a different flow. The exact data give d_Ra<0 and d_Rc<0 for every R, d_Rb<=0 for every R, and d_Rb<0 whenever k_R>1. Therefore A,B_0,C_0 are all strictly negative for every positive structural prior. The b=c=1 comparison slice is not invariant even at the initial point.

The unit evidence score in variance coordinates is

\[
 g_R=\nabla_{(a,b,c)}\log\mathcal E_R
       =(8d_{Ra},2k_Rd_{Rb},8d_{Rc}).
 \tag{10}
\]

This is the Gaussian score identity with primitive counts 16, 4k_R and 16. It concerns the full mixture over decorations at fixed R. For P={0,1},{2,3} and O={0,1,2,3}, the exact g_P-g_O has three negative components, approximately (-0.0887534682634,-0.822647249900,-0.106694939747). Full fractions are retained in [native-jet.json](evidence/finite-coherence-classification/native-jet.json).

Let Lambda(t)=log[Q_t(P)/Q_t(O)] be the actual recognition log odds. Initially every recognition derivative in (8) vanishes, even though the model already moves. Differentiating (8) once gives ddot rho_j(0)=dot u_j(0), ddot omega(0)=2 dot u_b(0) and ddot s(0)=0. In recognition variance coordinates tilde a_j=1/rho_j, this means ddot tilde a_j(0)=dot a_j(0). The normalizer memory lambda=omega-2 log rho_b has both first and second derivative zero at this start. Differentiating the structural marginal formula therefore gives

\[
 \dot\Lambda(0)=0,\qquad
 \ddot\Lambda(0)=(g_P-g_O)\mathbin{\cdot}(A,B_0,C_0)>0.
 \tag{11}
\]

The strict sign follows componentwise from (9)-(10), with no chosen pi_R. In particular, one must not report a positive first derivative of Q's odds by replacing finite-rate recognition with the instantaneous posterior. The latter's first derivative equals the second derivative in (11); recognition starts with a quadratic response.

There is also a uniform positive lower bound over all positive pi_R. Put m_a=min_R(-d_Ra)>0 and m_c=min_R(-d_Rc)>0. Ignoring the nonnegative b contribution gives

\[
 \ddot\Lambda(0)\geq-(g_{Pa}-g_{Oa})m_a
                         -(g_{Pc}-g_{Oc})m_c
 =q_0>0,
 \qquad q_0\simeq0.0407076474536.
 \tag{12}
\]

The exact q_0 is in the same result file. Smoothness of the finite Gaussian moment family near the positive initial parameters gives Lambda(t)=Lambda(0)+ddot Lambda(0)t^2/2+O(t^3), for each supplied fixed positive prior. Thus the pair's odds against one block initially increase along the actual coupled learner. No numerical duration or uniform remainder interval is claimed, and the pair need not initially be the MAP ancestry for an arbitrary prior.

## 5. Relative coherence and normalization memory

The same initial data show that a shrinks relative to both b and c, rather than merely that all three variances decrease. Since the initial ratios are one, their derivatives are A-B_0 and A-C_0. Every row has d_Ra<d_Rc, proving A-C_0<0. For the other ratio, clear the strictly positive denominator Z_pi K_pi in A-B_0. Its quadratic coefficients in the prior weights are

\[
 q_{RR}=\mathcal E_R k_R(d_{Ra}-d_{Rb}),\qquad
 q_{RS}=\mathcal E_R(k_Sd_{Ra}-k_Rd_{Rb})
         +\mathcal E_S(k_Rd_{Sa}-k_Sd_{Sb}),\quad R<S.
 \tag{13}
\]

All seventy-eight coefficients are nonpositive, and at least one diagonal coefficient is strictly negative. Exact fractions and signs are saved. As every pi_R is positive, the quadratic is strictly negative. Hence both initial ratio derivatives are negative. This is an initial increase of relative child precision within the declared model. It does not prove that transported law KL decreases on every edge or that either ratio remains monotone later.

The earlier negative normalizer-memory formula also gives the first nonzero term here. With h=dot u_b(0)=-B_0>0, differentiating (8) three times as needed yields

\[
 \lambda(t)=-\frac{h^2}{3}t^3+O(t^4).
 \tag{14}
\]

Indeed lambda'(0)=lambda''(0)=0 and lambda'''(0)=-2h^2. This term favors fewer blocks relative to the normalized mixture at the current recognition precisions. It is generated memory, not a prescribed static resource penalty. Its cubic onset cannot cancel the positive quadratic pair-versus-one-block response in (11), although its later competition with evidence remains part of the full dynamic problem.

## 6. Evidence and bounded execution

Four distinct exact calculations resolved four successive obligations. `evidence_functions.py` constructed all conditional and partition rational functions and matched the saved unit values, completing in 4.8738918 seconds. `comparison_polynomials.py` formed all twenty-one rational differences, completing in 10.0993055 seconds. `classify_positive_axis.py` proved the finite root counts from the retained signs, isolated and ordered all roots, and reconstructed the full ordering, completing in 0.6442577 seconds. `native_jet_exact.py` checked the exact unit scores, the prior-independent second-derivative bound and all seventy-eight relative-variance coefficients, completing in 0.0040936 seconds. No completed scientific calculation was rerun.

The existing pinned CPython 3.14.7 runtime did not have SymPy; the availability probe raised ModuleNotFoundError. The rational-function calculations therefore used the existing C:/anaconda/python.exe, Python 3.12.7 with SymPy 1.14.0 and Python rational ground types. Nothing was installed and no Torch or GPU operation was involved. Root isolation and the native response used pinned CPython 3.14.7 with exact Python integers and Fraction arithmetic.

The first comparison invocation failed before forming any comparison because its rational-field coefficient constructor rejected a SymPy Rational. The failed script and error remain as `comparison_polynomials-before-coercion-fix.py` and `coercion-failure.txt`. Supplying explicit integer numerators and denominators corrected only that conversion, after which the unchanged scientific formulas completed. The coefficients, exact scripts, stdout/stderr and source/input hashes are all retained under [evidence/finite-coherence-classification](evidence/finite-coherence-classification/). This is an executed algebraic argument with a written root/sign and native-flow proof, not a formal proof-system or independent-review certificate.

The previous goal turn was progress, supplying the normalized transported parent prior and its boundary/recursive-covariance result. This turn used three substantive passes: source/model reconciliation and exact evidence functions; all-candidate positive-axis classification; and the actual native initial response with prior-independent sign reconstruction. Only the new derivation/evidence and current STATUS, RG-COMPLETION, RECORD and daily change log were edited. Prior results and protected source/data/WIP remain covered by the preservation receipt. No ODE integration, iterative fitting, parameter-point search, numerical prior selection, finite M update, new data, sampling, full suite, GPU, Lean, tamper check, production/configuration change, canonical synchronization, Git publication or vault/manuscript edit occurred.

## 7. Next unresolved requirement

There is now a strict finite-coherence evidence region admitting two proper first-level blocks, with an open posterior-prior and licensing margin, and an initial native response favoring those blocks against one block for every positive pi_R. These facts replace the earlier lack of any admitted intermediate winner. They do not establish that the model and delayed recognition enter and remain in a pair-dominant region from the stated unit preparation. Both b and c move immediately, the recognition law lags, and the full parameter objective has noncompact boundary directions. A finite-horizon or basin argument must use this coupled system and state its prior dependence; the one-dimensional static classification cannot substitute for it.

Any claimed second learned parent must retain the induced parent/loop covariance or its exact conditional decoder, the original record probabilities, primitive energies and inherited access. The existing eight-coordinate law solver is available to the fine representation too. The 44-to-28-to-20 continuous sample counts do not price law normalization, moment evaluation, generation, interfaces, future-record filtering or newly generated parent interactions. Actual useful persistence, complete resource benefit and a second learned stage remain open parts of the full goal.
