# Exact heterogeneous local-parent admission

September 11, 2026. Source ed8f22a56df353b1535744509cc23fae46d5813c. The fifteen-subset strong-exterior experiment returns identity retention for every subset. This is a complete negative result for useful exact local compression under the specified experiment, not absence of organization and not a universal no-go for RG. The [admission table](evidence/local-admission/admission.csv) and fifteen exact JSON certificates contain every map, normalized quotient row, initial marker, factorized source fiber, refinement trace, and separating pair witness.

| Subsets | Number | Local classes | Full retained states including exterior | Refinement |
| --- | ---: | ---: | ---: | --- |
| Singletons | 4 | 2 | 16 | 1 to 2 |
| Pairs | 6 | 4 | 16 | 1 to 4 |
| Triples | 4 | 8 | 16 | 1 to 8 |
| Whole system | 1 | 16 | 16 | 1 to 13 to 16 |

## Exact executed construction

The [runner](evidence/local-admission/run_admission.py) reuses ControlledProcess, coarsest_partition, and quotient_process without changing production code. For subset A, input is (a,y_E), local state is y_A, and STEP records contain (e,y_E'). One disjoint integer-coded START symbol has zero emitted mass and unit initial mass. Every emitted row is the original joint K, reorganized by local destination and record. Thus normalization follows by partitioning the original complete target sum. An independent refinement trace agrees with the API's map and class counts; exact aggregation agrees with every quotient row and every initial sensor. All 480 source rows passed. The [execution log](evidence/local-admission/execution.log) records the completed serial run under pinned CPython 3.14.7.

The full parent map is G_A(y)=(h_A(y_A),y_E). Its fibers are explicitly h_A^{-1}(s) times {y_E}. Every admitted h_A is injective; hence every G_A is a bijection of sixteen configurations. The full categorical filter for a record-only observer is represented by fifteen simplex coordinates; minimal filtering dimension is not established here. Smaller local cardinalities do not provide total compression because the exterior is retained. Stored adapter entries include deliberately unused START columns; the separate physical joint row count excludes those bookkeeping columns. Neither count is a Fisher rank or an effective parameter estimate.

## Why every proper block fails to compress

Fix an exterior site j. Under the uniform-site reset,

\[
\mathbb E[Y'_j\mid y,a]
=\tfrac34 y_j+\tfrac14\left(a+\sum_{i\ne j}J_{ji}y_i\right).
\]

For fixed exterior and action, the only local dependence is the linear signal sum_{i in A} J_ji y_i. Strong exterior closure requires equality of this expectation for any two local sources sharing a class. Each full neighbor-weight list has distinct subset sums: at sites 1,2,3,4 the weights are respectively (15,20,24)/240, (7,14,16)/112, (2,3,4)/24, and (21,30,35)/210. Their eight subset sums are all distinct; consequently every sublist's signed sums are distinct. Any exterior site therefore distinguishes all local configurations. This proves injectivity of h_A for every proper nonempty A. The argument uses the observed next exterior and does not depend on the parity sensor's informativeness.

[Preparation-separation evidence](evidence/local-admission/preparation-separation.json) retains the fourteen explicit injective probes, minimum signal gaps, and 448 exact expectation checks. A difference Delta in the linear signal gives next-exterior-bit TV |Delta|/8. These are exact finite certificates, not a data-fitted preference.

## Record-only preparation separation and the memory limit

For the whole system, first-record means are eta P(y)[a M(y)+2 sum_{i<j}J_ij y_i y_j]/4. Across both actions they give thirteen distinct signatures. The only remaining pairs are complementary configurations with two positive and two negative spins. Their two-event record responses differ even when both fields are fixed at +1/5.

Write d_i=sum_j J_ij and D(y)=sum_i d_i y_i. For balanced configurations y and -y, direct action of the reset operator on the parity characters gives

\[
\mathbb E[E_2\mid y,a,b]-\mathbb E[E_2\mid -y,a,b]
=-\frac{\eta(b+2a)}8D(y).
\]

The [independent reconstruction](local-admission-reconstruction.md) supplies the character calculation. For the three complementary pairs, |D(y)| is 5/24, 5/42, or 1/20. At a=b=1/5 the second-record TV values are exactly 3/512, 3/896, and 9/6400. The [signature table](evidence/local-admission/preparation-signatures.csv) and [check log](evidence/local-admission/preparation-check.log) exhibit a separating event for all 120 pairs; 117 pairs separate at the first-response panel and the last three at the second-response probe.

Any normalized predictor initialized solely from a deterministic class h(Y0), including arbitrary latent memory or full record history, assigns the same future experiment to two preparations sharing h. Since the true record laws separate every pair by horizon two, an all-preparation exact predictor requires h injective. Memory initialized from discarded fine information would change the preparation interface. This conclusion does not establish minimum cardinality among arbitrary stochastic preparation encoders or hidden-state realizations, and it does not forbid approximate or preparation-averaged prediction.

## Complete parents and recursive consequences

Each exact parent has carrier S_A times {m_*} times Y_E times {h_*}. The local and exterior coordinates are random samples; the singleton coordinates are fixed model and generative-memory marks. Recognition is a law on the carrier. Structural couplings and schedule stay outside it. Its transition evaluator is precisely the reorganized original normalized kernel. A static evaluator is obtained from the pushed joint conditional on the exterior, as specified in the preceding local contract; it is not the transition evaluator's input type.

Because G_A is bijective, one normalized deterministic channel pushes any admitted generative law, selected posterior, and full correlated recognition law without information loss. Applied coordinatewise to an augmented path, it remains bijective on the latent path while retaining observations once. Conditional posterior and recognition fibers are identical point masses, so the discarded conditional KL is zero under the existing absolute-continuity hypotheses. No product approximation or fitted mechanism is substituted. This supplies complete exact parents, but they are lossless reexpressions with no reduction.

For every disjoint partition of the four children, the joint of these injective local maps also retains sixteen states. A second deterministic exact quotient of that joint cannot compress the same experiment: composing it with the first bijection would contradict the preparation-separation result. Therefore the heterogeneous source admits no useful exact two-level compressed hierarchy in this declared class. The previously completed symmetric 16-to-9-to-5 calibration is a different source and remains valid.

The requested local phase is complete. Approximate spatial selection requires a declared accuracy tolerance or resource requirement, not a coefficient chosen to obtain an intermediate result. The current goal is broader than this negative theorem; its remaining decision is recorded in [RG completion status](RG-COMPLETION.md).
