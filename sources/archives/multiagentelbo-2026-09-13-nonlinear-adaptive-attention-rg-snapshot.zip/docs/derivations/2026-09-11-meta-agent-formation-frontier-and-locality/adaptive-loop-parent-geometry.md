# Adaptive cyclic parents: normal defects, attention, and an exact loop-preserving flag

September 12, 2026. This is the geometry interface for the [frozen adaptive contract](evidence/2026-09-12-adaptive-cyclic-rg-goal/problem-contract.json), whose target digest is `e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90`. Its statements concern the fibers over one fixed base point `c_*`. The construction below supplies exact marked probability identities, a conditional moving-manifold estimate, a nonempty compact cyclic regular geometry, and an explicit Gaussian retention flag for the companion dynamical witness. It does not assert that a regularity hypothesis alone produces successive formation or appreciable model learning.

The full contract asks, for every prescribed finite integer `L >= 2`, for one nonempty admitted regime with `L` actual formation levels, genuine normalized-VFE learning that changes an eliminated conditional by an amount independent of the fast/slow parameter, and quantitative conditional-VFE and dynamical bounds on the same finite adaptation interval. Those existence and interval estimates belong to the companion dynamics and conditional-control arguments. The exact equivalence proved here is equality of normalized pushforwards, conditional decompositions, and nested Gaussian eliminations. Replacing a projected dynamics by an autonomous parent remains a quantitative operation with its displayed defect.

## 1. Prior work and the specific extension

The [full graph chapter](../../../Theory/07c_full_graph_meta_agent_vfe.tex), especially `sec:full-graph-vfe-global`, `sec:full-graph-vfe-scale-local`, and `sec:full-graph-vfe-nonflat`, already puts the complete correlated recognition over one normalized joint, retains attention entropy and normalizers, and keeps rooted holonomies and dressed cut copies. The [network RG chapter](../../../Theory/07b_agent_network_rg.tex), `sec:rg-gauge-cross-scale` and `sec:rg-meta-attention`, already derives root conjugation, exact marked attention, and the distinction between an averaged linear operator and a group-valued link. These constructions are reused.

The [GL marked-parent calculation](gl-alignment-marked-parent.md), Sections 2–8, proves regular coherent-set ranks with independently varying links, permits noncommuting stabilizer holonomy, and supplies the normal determinant measure and admitted finite-depth recursion. The [singular calculation](singular-holonomy-alignment-limit.md), Sections 5–7, retains the integrable, cycle-sized holonomy determinant and its labeled weight factors. The [critical two-cycle calculation](critical-two-cycle-alignment-limit.md), Sections 5–8, additionally retains oriented direction marks and the logarithmic evidence correction. They are separate admissions; a regular moving-manifold theorem cannot silently cover their singular junctions. The [agreement-sufficient parent](agreement-sufficient-marked-parents.md), Sections 2, 3, and 5, proves common-channel closure for a particular matched conditional family and a positive-probability two-level channel event. It does not prove descent of an arbitrary microscopic vector field. The [coherence-attraction argument](coherence-attraction-and-dynamical-rg.md) supplies the fixed-manifold normal estimate and inherited metric. The extension here makes the moving law/link defect, adaptive attention derivatives, and loop-preserving linear flag explicit.

The [September 8 report](../../reports/2026-09-08-curvature-base-and-renormalization.md) and [September 9 loop-inference report](../../reports/2026-09-09-holonomy-curvature-inference.md) already distinguish normalized latent-link inference, induced interactions, and conditional VFE. Their base transport and curvature priors are historical context, outside this pointwise assignment. No Wilson term is imported. The current correction in the live [Holonomy note](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Holonomy.md>) permits nontrivial holonomy with zero transported marginal KL and separates graph links from transition cocycles. The live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), lines 387–418 and the mixture-of-sources derivation around lines 522–620, already contains independent-loop observables and entropy-regularized attention, while expressly qualifying the population consensus energy's ELBO status. Reading these sources supplies continuity, not an assumption of their universal correctness.

The user supplies the fixed-base scope, independent link ontology, normalized-joint requirement, preservation of loop/cut data, allowance for negligible model alignment, and prohibition on inserting a merger schedule or parent rate factors. Smooth finite-dimensional charts, positive metrics, compact localization, and the concrete Gaussian and circle-law models below are additional mathematical admissions.

## 2. Types and conventions

| Object | Type and convention |
| --- | --- |
| Base and principal bundle | `c_*` is fixed in a contextual base `C`; `P_G -> C` is one right principal `G`-bundle. No base curve is used. |
| Associated sample fibers | `S_b,S_m` have left bimeasurable actions `rho_b,rho_m` of the same `G`. Their dimensions and representations may differ. |
| Associated law fibers | `B_x` consists of normalized laws on `S_x`; `g` acts by `rho_x(g)_#`. The bundle is `P_G x_(rhohat_x) B_x`, with `(u g,b)` identified with `(u,g_# b)`. |
| Agents and sampled laws | A local section evaluated at `c_*` supplies `b_i` or `m_i`, a law point. A complete configuration `W` may itself contain random law points, links, and model presentations. Recognition `Q(dW)` is a law over configurations, not a list of those law points. |
| Model evaluation | A model presentation belongs to a declared space `M_i` and has a normalized evaluator `ev_i:M_i -> Kernels`. A law over presentations and a learned generative parameter `theta` are different objects. |
| Local frames | Belief and model may choose frames `u_i^b,u_i^m` in the same principal fiber. If `u_i^m=u_i^b h_i`, `h_i` does not identify inequivalent sample representations. |
| Passive frame convention | Write `A_i=a_i^{-1}` for the coordinate action of the principal frame rechoice `u_i -> u_i a_i`. Then `b_i'=A_i#b_i`. A physical symmetry additionally has to preserve the fixed model, reference, observations, and metric. |
| Graph | A finite oriented multigraph at `c_*`; `e:j -> i` has one independent variable `Theta_e in G`. Reverse traversal of that copy uses its inverse. Distinct parallel or reverse-directed copies need not be inverse variables. |
| Graph links | `Theta_e'=A_i Theta_e A_j^{-1}`. These are independent interaction coordinates. They are not the transition functions of the principal bundle. |
| Root and tree maps | `g_i` is the ordered graph-tree product from the block root to child `i`, with `g_root=I`. Products act on the left and the rightmost factor acts first. |
| Loop and cut marks | `H_e=g_i^{-1}Theta_e g_j` for an internal cotree copy; `V_e=g_i^{-1}Theta_e g_j` for a cut copy with its two respective block roots. |
| Connections | Ambient principal connections, if supplied, remain separate typed data. Their base transport, curvature, or descent is not used or derived here. |
| Metrics | A smooth SPD configuration metric `G_W` is declared. Fisher blocks are admitted only for regular identifiable law families. Link and learned-parameter blocks require their own positive choices. The induced constraint metric is `J^T G_W J`. |
| Gaussian covariance geometry | For `N(mu,Sigma)`, the Fisher form is `dmu^T Sigma^{-1}dmu + (1/2)tr(Sigma^{-1}dSigma Sigma^{-1}dSigma)`. Its covariance block is one-half the affine-invariant SPD metric. No SPD exponential, logarithm, or parallel transport is substituted for a Euclidean operation. |
| Strengths and attention | `w_e >= 0` denotes an energy strength. `beta_ij` or `gamma_ij` denotes a row probability only when explicitly declared as such. `eta_ij=alpha_i beta_ij` is a joint event law with receiver occupancy `alpha`. Signed effective-action coefficients are a third object. |

For densities, covariance under a general invertible frame change includes the pushed reference measure or its Jacobian. For example, an invertible linear `A` sends a Gaussian to `N(A mu,A Sigma A^T)`, and the same change of variables in both terms of a log-density ratio proves

\[
\operatorname{KL}(A_\#p\Vert A_\#q)=\operatorname{KL}(p\Vert q).
\tag{1}
\]

An arbitrary `GL(K)` change does not preserve a fixed Euclidean metric, fixed isotropic Gaussian subclass, or a fixed density against untransformed Lebesgue measure. Such extra structure must transform as well. A proper prior on noncompact links is sufficient for a model only after integrability of its other factors is checked; there is no normalized Haar prior on `GL(K)` or on the translation group.

## 3. Exact link, loop, and moving-law formulas

Tree cancellation gives

\[
g_i'=A_i g_i A_{r_I}^{-1},\qquad
H_e'=A_{r_I}H_eA_{r_I}^{-1},\qquad
V_e'=A_{r_I}V_eA_{r_J}^{-1}.
\tag{2}
\]

These statements are exact for independently specified links. Only the selected tree edges have trivial based marks. Changing the tree changes the generators and rooted cut descriptions by ordered products of retained marks. It does not remove them or replace them by their separate conjugacy classes: their joint orientation relative to the root laws matters.

Let the coordinates depend differentiably on an auxiliary update parameter `t`, with fixed passive frames. Put `a_i=g_i^{-1} dot g_i`. Differentiating a product and inverse gives

\[
\dot H_e=-a_i H_e+g_i^{-1}\dot\Theta_e g_j+H_ea_j,
\qquad
\dot V_e=-a_i V_e+g_i^{-1}\dot\Theta_e g_j+V_ea_j.
\tag{3}
\]

In the cut formula the two tree frames use their respective roots. For a time-dependent passive root frame, differentiating (2) adds `[dot A_r A_r^{-1},H_e']` to the transformed loop velocity. This is a moving coordinate term, not a base connection.

Let `X_B(p)` denote the fundamental law tangent of the pushforward action generated by `X` in the Lie algebra. For a linear sample action its density form is `-div(rho_*(X) x p)` whenever that expression is in the admitted tangent space. Gaussian parameters give

\[
X_{\mathcal B}(\mu,\Sigma)
 =\bigl(\rho_*(X)\mu,
        \rho_*(X)\Sigma+\Sigma\rho_*(X)^T\bigr).
\tag{4}
\]

At an equal-law edge, write `xi_e=dot Theta_e Theta_e^{-1}`. The derivative of its mismatch is the difference of tangents at the same law:

\[
\mathcal R_e
=\dot b_i-(\Theta_e)_\#\dot b_j
 -(\xi_e)_{\mathcal B}\bigl((\Theta_e)_\#b_j\bigr).
\tag{5}
\]

The tangent action in (5) is the derivative of the pushforward on signed score tangents, not a new probability measure. If `b_i=b_i(z,theta)`, the dots include both parameter derivatives. Formula (5) accounts for independent link velocities as well as changing law parameters.

On a coherent block, `b_i=(g_i)_#b_I` and every loop satisfies `H_#b_I=b_I`. Its exact infinitesimal compatibility is

\[
(H_\#-I)\dot b_I
 +(\dot H H^{-1})_{\mathcal B}(b_I)=0.
\tag{6}
\]

Thus a changing root law and a changing holonomy cannot be specified independently while asserting exact coherence. For Gaussian parameters (6) is

\[
\begin{split}
\zeta\mu+(H-I)\dot\mu&=0,\\
\zeta\Sigma+\Sigma\zeta^T
       +H\dot\Sigma H^T-\dot\Sigma&=0,
\qquad \zeta=\dot H H^{-1}.
\end{split}
\tag{7}
\]

No equation here requires `H=I`. As a minimal failure test, hold `H=diag(1,-1)` fixed at `N((1,0),I)` and choose `dot mu=(0,1)`. Then `(H-I)dot mu=(0,-2)`, so the state leaves the stabilized sector despite starting at zero transported KL. A descent identity for another part of a VFE cannot annul this tangent defect.

For a smooth mismatch map `R(W,theta)` with coherent set `M_theta={R=0}`, a local embedding `W=iota_theta(y)` satisfies

\[
D_W R J=0,\qquad
D_W R \partial_\theta\iota+\partial_\theta R=0,
\qquad J=D_y\iota.
\tag{8}
\]

Let `V=dot W` be the actual microscopic field, and let `P_N` be the `G_W`-orthogonal projection normal to `M_theta`. The exact normal defect and the induced tangent velocity on the moving manifold are

\[
\begin{split}
n&=P_N\bigl(V-\partial_\theta\iota \dot\theta\bigr),\\
v_y&=(J^TG_WJ)^{-1}J^TG_W
       \bigl(V-\partial_\theta\iota \dot\theta\bigr).
\end{split}
\tag{9}
\]

Vanishing of `n` is equivalent to `D_W R V+partial_theta R dot theta=0` when the kernel of `D_W R` is exactly the tangent space. Formula (9) follows by the unique orthogonal decomposition of `V-partial_theta iota dot theta`. If `V=-grad_G U` on `M_theta`, its second line is

\[
v_y=-(J^TG_WJ)^{-1}\partial_y(U\circ\iota)
 -(J^TG_WJ)^{-1}J^TG_W\partial_\theta\iota \dot\theta.
\tag{10}
\]

This last term is present even when the scalar restricted energy is known exactly. Alternatively include `theta` in one enlarged configuration space; then its block metric and all induced cross blocks give the same tangent projection. Neither prescription invents a new parent clock.

## 4. A conditional normal estimate under adaptation

Here is a local theorem with explicit scope. Suppose `D(W,theta)` and the chosen metric are sufficiently smooth on a compact tube of a regular family `M_theta`, `D=0` and `d_W D=0` there, and the normal Hessian is uniformly positive. Choose a smooth orthonormal normal coordinate `xi` on this tube. Assume that the actual dynamics has `V=-kappa grad_G D+V_0`, and the coordinate calculation gives

\[
\dot\xi=-\kappa A(y,\theta)\xi+b(y,\theta,t)+R_1,
\quad
\langle\xi,A\xi\rangle\ge\lambda\|\xi\|^2,
\quad
\|R_1\|\le\kappa C\|\xi\|^2+B_1\|\xi\|.
\tag{11}
\]

The field `b` is the normal-coordinate form of (9) at `xi=0`; its bound must include the actual external force, learned-parameter drift, and moving link contribution. Taylor's formula on the compact tube gives (11) from a regular Fisher-positive mismatch Hessian and bounded derivatives. It is an assumption to check in a new family, not an assertion about every normalized VFE.

If `||xi|| <= delta`, `C delta <= lambda/4`, `B_1 <= kappa lambda/4`, and `||b|| <= B_0`, then until exit from the tube

\[
\|\xi(t)\|\le e^{-\kappa\lambda(t-t_0)/2}\|\xi(t_0)\|
 +\frac{2B_0}{\kappa\lambda}
       \bigl(1-e^{-\kappa\lambda(t-t_0)/2}\bigr).
\tag{12}
\]

Indeed the upper right derivative of the norm is at most `-kappa lambda ||xi||/2+B_0`; multiplying by its scalar integrating factor proves (12), including at zero by continuity. A first-exit argument applies when the right side stays below the normal boundary and the retained path remains in the inner tangential patch. A claim on a meaningful adaptation horizon still requires those horizon and tangential-path checks.

The retained field differs from (9) by at most

\[
C_2\bigl((1+\|\dot\theta\|)\|\xi\|
                       +\kappa\|\xi\|^2\bigr)
\tag{13}
\]

under the corresponding derivative bounds. The quadratic alignment contribution follows because the linearized normal Hessian has zero tangent projection. A finite-horizon trajectory comparison integrates (13) and applies a Lipschitz integrating-factor bound to the retained field. Its initial state is the actual retained state at activation. An initial layer cannot be deleted while retaining its old initial condition: the integral of `kappa ||xi||^2` over that layer can be nonzero.

For positive weights on a fixed candidate graph, changing the weights changes `A`, its gap, and the fluctuation determinant but not `{D=0}`. Vanishing weights, hard attention masks, a stabilizer-rank change, a covariance boundary, or noncompact escape may change the zero set or eliminate the uniform gap. The theorem ends at such an exit unless a separate admission supplies a replacement. The singular and critical limits cited in Section 1 remain their own results.

## 5. Adaptive attention and negligible model coupling

For a fixed finite positive candidate row with probability prior `pi`, temperature `tau>0`, and `beta` in the simplex, define

\[
\Phi(\beta,W,\theta)
=\sum_j\beta_j D_j+\tau\sum_j\beta_j\log(\beta_j/\pi_j).
\tag{14}
\]

Differentiation on the simplex, using `sum d beta_j=0`, gives the complete differential

\[
d\Phi=\sum_j\beta_j dD_j
 +\sum_j\bigl[D_j+\tau\log(\beta_j/\pi_j)\bigr]d\beta_j
 -\tau\sum_j\beta_j d\log\pi_j
 +\operatorname{KL}(\beta\Vert\pi)d\tau.
\tag{15}
\]

The unique interior minimizer and reduced scalar are

\[
\beta_j^*=\frac{\pi_j e^{-D_j/\tau}}{Z},
\qquad Z=\sum_j\pi_j e^{-D_j/\tau},
\qquad \Phi^*=-\tau\log Z.
\tag{16}
\]

Substituting (16) into (15) removes the `d beta` term because its coefficient is constant across the row. It retains both the varying prior and temperature terms. For fixed `pi,tau`,

\[
\nabla^2\Phi^*
=\sum_j\beta_j^*\nabla^2D_j
 -\tau^{-1}\operatorname{Cov}_{\beta^*}(\nabla D_j).
\tag{17}
\]

At complete row coherence all `D_j` and their first derivatives vanish, so `beta*=pi` and the normal Hessian is the positive prior-weighted sum of the edge Hessians. If `pi_j>=pi_min>0`, `tau>=tau_min>0`, and `D_j<=D_max`, then `beta_j*>=pi_min exp(-D_max/tau_min)`, since `Z<=1`. This supplies one explicit weight floor for a normal-gap proof. Away from coherence the covariance term in (17) must be kept. Updating only `sum beta_j D_j` with `beta=beta*(W)` is the derivative of a different scalar.

For coarse attention, retain the joint marked event law, including the receiver distribution. With a fixed hard partition and a specified conditional bridge, its coarse event mass is

\[
\eta^c_{IJ}(y)
=\mathbb E\left[\sum_{i\in I,j\in J}\eta_{ij}(W)\mid Y=y\right],
\qquad
\alpha_I^c=\sum_J\eta^c_{IJ},
\qquad
\beta^c_{IJ}=\eta^c_{IJ}/\alpha_I^c
\tag{18}
\]

on positive occupancy. The bridge is identified as prior, selected-posterior, or actual-recognition wherever used; they are not interchangeable during adaptation. Nested conditional expectation proves composition of the joint law. Averaging normalized receiver rows without occupancies does not. Each edge's mark is retained jointly with its event, or by its full conditional mark kernel. The exact coarse source energy within one row is the weighted log-sum-exp of (16), with source-block prior equal to the sum of its fine priors. Merging different receiver rows also carries their evidence weights. These are probability identities, not an assumption of a scalar pairwise energy family after elimination.

A signed real coefficient in an effective action is neither an attention probability nor a nonnegative KL strength. Negative strengths can produce a negative normal Hessian: when links vary independently, a variation supported on an edge with negative weight already gives a negative quadratic direction. Such a signed model needs its own positivity and normalization proof. A total energy strength times a probability event law is permissible, but that total strength must survive along with the normalized event law.

The phrase “negligible model coupling” requires a force admission. If an actual energy contribution is `R_delta=sum_e gamma_e D_e^m`, then

\[
dR_\delta=\sum_e\gamma_e dD_e^m+\sum_eD_e^m d\gamma_e.
\tag{19}
\]

Thus `gamma_e<=delta`, `||grad_G D_e^m||<=L_e`, `D_e^m<=M_e`, and `||grad_G gamma_e||<=delta K_e` imply `||grad_G R_delta||<=delta sum_e(L_e+M_e K_e)`. If `gamma` is an independent learning coordinate, its differential is `D_e^m d gamma_e`; small `gamma_e` alone does not make that component of the metric force small. A simplex row cannot have every entry close to zero. Exactly absent inter-agent model alignment is declared by zero energy strengths, or by zero model-channel intensity when `gamma` denotes a normalized row. It does not remove the model evaluator, self/prior terms, bridge, observations, or learned generative parameters.

Even uniformly small energy values do not suffice. For `epsilon>0`, let

\[
D_\epsilon(x)=2+\sin(x/\epsilon^2),\qquad
R_\epsilon(x)=\epsilon D_\epsilon(x).
\tag{20}
\]

This is the Gaussian KL between `N(0,1)` and `N(sqrt(2D_epsilon(x)),1)` times a positive strength. The energy is bounded by `3 epsilon` everywhere, whereas `R_epsilon'(0)=1/epsilon`. This is an exact counterexample to an energy-value-only admission.

For a normalized Gibbs prior, dropping a coupling also changes its partition and the learned-parameter score. If `p_delta proportional to exp[-(E_0+delta V)/T]`, `|V|<=M`, and `||partial_theta E_0||<=M_0`, then its density ratio to `p_0` lies between `exp(-2 delta M/T)` and `exp(2 delta M/T)`. Consequently its total variation tends to zero at order `delta`, and

\[
\left\|\partial_\theta\log Z_\delta
              -\partial_\theta\log Z_0\right\|
\le\frac{\delta}{T}\sup\|\partial_\theta V\|
 +\frac{2M_0}{T}\operatorname{TV}(p_\delta,p_0).
\tag{21}
\]

This follows by differentiating each partition and adding/subtracting the expectation of `partial_theta E_0` under the two priors. It supplies a normalized-score bound under explicit uniform bounds. The primary Gaussian witness below takes the inter-agent model-alignment strengths exactly zero and avoids this perturbative admission.

## 6. Exact normalized parents, moving scores, and two-level marks

Let `P_theta(do,dw)` be one normalized joint on standard-Borel spaces and let `o` have positive finite evidence. Let `Q(dw)` be normalized correlated recognition with finite KL to the selected posterior `Pi_theta,o`. Let `C` be a normalized common Markov channel, independent of recognition and leaving `o` unchanged. For a deterministic `Y=C(W)`, write the posterior disintegration `Pi(dw|y,o)` and recognition disintegration `Q(dw|y)`. A stochastic channel is handled identically on the augmented `(W,Y)` joint. Then

\[
\mathcal F_\theta(Q)
=\mathcal F_\theta^c(Q^c)
 +\int Q^c(dy)\operatorname{KL}
       \bigl(Q(dw\mid y)\Vert\Pi_\theta(dw\mid y,o)\bigr).
\tag{22}
\]

The proof is the factorization of the density ratio into its retained ratio and its conditional ratio, followed by integration. The evidence is unchanged by a normalized channel. For nonnegative extended KL the identity remains additive; ordinary subtraction uses finiteness.

The physical parent likelihood is obtained from the **prior** reverse kernel,

\[
L_\theta^c(do\mid y)
=\int L_\theta(do\mid w)P_\theta(dw\mid y).
\tag{23}
\]

The selected-posterior conditional in (22) is not freely substituted for (23). A proposed evaluator must equal the induced kernel or carry its discrepancy. Parameter-dependent Jacobians and channel derivatives enter if one chooses a moving coarse chart; a fixed full-state map avoids that extra term.

Under a fixed differentiable dominated channel, set `s_theta(w)=partial_theta log p_theta(o,w)`. Differentiating the integral for the retained observed density gives

\[
\partial_\theta\log p_\theta^c(o,y)
=\mathbb E_{\Pi_\theta(\cdot\mid y,o)}s_\theta,
\qquad
\partial_\theta\log\Pi_\theta(w\mid y,o)
=s_\theta(w)-\mathbb E_{\Pi_\theta(\cdot\mid y,o)}s_\theta.
\tag{24}
\]

These centered conditional scores are the changing-conditional interface. In particular, the difference between the fine and coarse learning force at fixed `Q,Q^c` is

\[
\partial_\theta\mathcal F_\theta(Q)
-\partial_\theta\mathcal F_\theta^c(Q^c)
=-\int Q^c(dy)
 \left(\mathbb E_{Q(\cdot\mid y)}-
       \mathbb E_{\Pi_\theta(\cdot\mid y,o)}\right)s_\theta.
\tag{25}
\]

If `||s_theta||<=M_s`, the norm of (25) is at most `M_s sqrt(2 Delta)`, where `Delta` is the conditional KL in (22). This follows from the total-variation bound `TV<=sqrt(KL/2)` on each conditional and Cauchy–Schwarz over `Q^c`. For unbounded Gaussian scores use explicit conditional moments instead; the bounded-score inequality is not automatically applicable.

For a normalized Gibbs prior `p_theta=e^{-E_theta/T}/Z_theta` with fixed reference and normalized likelihood, the score in (24) contains

\[
s_\theta=-T^{-1}\partial_\theta E_\theta
 +T^{-1}\mathbb E_{P_\theta}\partial_\theta E_\theta
 +\partial_\theta\log L_\theta(o\mid W).
\tag{26}
\]

The partition term is essential. With a declared smooth recognition parameter `lambda`, positive metrics `G_lambda,K_theta`, and coupled descent `dot lambda=-G_lambda^{-1}partial_lambda F`, `dot theta=-epsilon K_theta^{-1}partial_theta F`, the exact chain rule gives

\[
\frac{d\mathcal F}{dt}
=-\|\partial_\lambda\mathcal F\|_{G_\lambda^{-1}}^2
 -\epsilon\|\partial_\theta\mathcal F\|_{K_\theta^{-1}}^2.
\tag{27}
\]

This identity does not prove that `theta` changes appreciably or that (22)'s conditional term stays small. Those are additional quantitative obligations.

At a second grouping let `t_I` carry the new root to the old root `I`. The composite child frame is `g_i t_I`, and direct substitution gives

\[
H_{I,e}^{(2)}=t_I^{-1}H_{I,e}^{(1)}t_I,
\qquad
V_e^{(2)}=t_I^{-1}V_e^{(1)}t_J.
\tag{28}
\]

Keep every inherited loop with its label, every new cotree loop, every cut copy with its orientation, strength, attention-event data and record, and every required singular direction mark. For a connected grouped graph, `beta_total=sum_I beta_I+beta_quotient` by `beta=E-N+1`. This counts all fundamental loop generators. The compatible joint law retains products of noncommuting marks. The inherited integrable factors from the singular theorem and the critical direction lifts remain attached to their own labeled subsets; they are not recomputed from one averaged loop. Nested common channels then prove exact probability composition by iterated integration. A new grouping law which needs discarded conditional data is not a function of the displayed parent alone; it requires retained memory or a larger channel state.

## 7. A nonempty regular cyclic geometry with nonidentity stabilizers

This compact example establishes that the regular geometry does not exclude stabilized nonidentity loops. It is not the companion successive-formation witness. Let `G=S^1` rotate the sample circle `x in R/(2pi Z)`, and take

\[
b_{\phi,a}(dx)=\frac{1+a\cos(2(x-\phi))}{2\pi}dx,
\qquad
\phi\in\mathbb R/(\pi\mathbb Z),
\qquad 0<a_-\le a\le a_+<1.
\tag{29}
\]

The density is bounded above and below by positive constants. Its stabilizer is exactly `{0,pi}` in `S^1`. Independent links have angles `theta_e mod 2pi`. Put `delta_e=phi_i-phi_j-theta_e mod pi`. With `c(a)=1-sqrt(1-a^2)`, the exact KL is

\[
D_e=c(a)\bigl(1-\cos(2\delta_e)\bigr).
\tag{30}
\]

To check (30), set `r=(1-sqrt(1-a^2))/a`, so `a=2r/(1+r^2)`. The uniformly convergent logarithmic Fourier series

\[
\log(1+a\cos t)
=-\log(1+r^2)
 +2\sum_{k\ge1}\frac{(-1)^{k+1}r^k}{k}\cos(kt)
\tag{31}
\]

follows by adding the power series of `log(1+r e^{it})` and its conjugate. Integrating against a density containing only the constant and first cosine harmonics retains only `k=1`; the difference of the self and shifted terms is `a r(1-cos(2delta))`, and `a r=c(a)`.

The phase Fisher information is `4c(a)>0`. For fixed positive weights, on each local coherent branch the residual Jacobian is

\[
\delta\phi_i-\delta\phi_j-\delta\theta_e,
\qquad
\nabla^2D=4c(a)B^T\operatorname{diag}(w_e)B.
\tag{32}
\]

Each link angle appears in its own row with coefficient `-1`, so `rank B=E`. Thus the coherent manifold has dimension `N` in the `N+E` dimensional phase/link configuration, and the full normal rank is `E`, even on a cyclic graph. On a triangle choose two tree angles zero and the cotree angle `pi`, and all phases zero. Every edge KL is zero while the based loop is the nonidentity half turn. Small coherent variations retain its discrete stabilizer component. No curvature penalty was needed.

The exact local remainder obeys

\[
\left|D_e-2c(a)\delta_e^2\right|
\le\frac{2}{3}c(a)|\delta_e|^4,
\tag{33}
\]

by Taylor's remainder for cosine. On a compact regular branch, (32) has a uniform positive normal gap. If the generative parameter `a` changes, the normal quadratic form changes through `c'(a)=a/sqrt(1-a^2)`, even though the coherent set stays fixed. Consequently an eliminated Gibbs conditional with that energy generally changes. This example supplies geometry and a computable nonlinear remainder; an externally specified `a(t)` would not satisfy the contract's learning condition. At `a=0` the phase becomes unidentifiable and (32)'s normal gap vanishes, providing a minimal excluded case.

## 8. The companion triangle-chain flag preserves every loop

Fix `L>=2`, put `N=2^{L-1}`, and take a chain of `N` triangles. There are `n=3N` vertices and `E=4N-1` oriented edge copies. Every triangle has three cyclically oriented internal edges. Adjacent triangle portals are joined by one bridge; bridge `j`, for `1<=j<N`, has dyadic level `ell(j)=2+v_2(j)`. This assigns microscopic interaction contrasts, not a time-dependent merger instruction.

For the translation specialization, let the complete coordinate be

\[
x=(u,v,\alpha)\in\mathbb R^{2n+E},\qquad
d=u-v,\qquad r=D u-\alpha,
\tag{34}
\]

where each row of incidence `D` is `u_receiver-u_source`. The law points are `N(u_i,1)` and a declared sampled-model family indexed by `v_i`; the model-to-belief bridge is `d`. There is no inter-agent model-residual energy in this witness. The scalar link `alpha_e` is an independent translation, with endpoint reexpression `alpha_e'=alpha_e+a_i-a_j`, `u_i'=u_i+a_i`, `v_i'=v_i+a_i`.

For triangle `b`, define `h_b=sum_{e in b}alpha_e=-sum_{e in b}r_e`, and use

\[
Q_\triangle=
\begin{pmatrix}
1/\sqrt2&-1/\sqrt2&0\\
1/\sqrt6&1/\sqrt6&-2/\sqrt6
\end{pmatrix},
\qquad z_b=h_b/\sqrt3.
\tag{35}
\]

The rows of `Q_triangle` are orthonormal, perpendicular to `(1,1,1)`, and

\[
\|r_b\|^2=\|Q_\triangle r_b\|^2+z_b^2.
\tag{36}
\]

Let `H` be the matrix whose `b`th row extracts `z_b` from `x`. The rows have disjoint link support and unit norm, so `H H^T=I_N`. Define `B_s x` to stack `d`, the two contrasts `Q_triangle r_b` for every triangle, and all bridge residuals with level at most `s`. Then

\[
H B_s^T=0,\qquad
\operatorname{rank}B_s=6N-N/2^{s-1},
\qquad 1\le s\le L.
\tag{37}
\]

For the first identity, the triangle circulation annihilates incidence and every contrast has zero coefficient sum; bridge and `d` rows have no triangle-cycle link component. For the rank statement, a row dependence inspected in the bridge-link columns first sets every bridge coefficient to zero. Each triangle's three link columns then set both contrast coefficients to zero. The `v` columns finally set every `d` coefficient to zero. There are `3N+2N` initial rows and `N-N/2^{s-1}` bridge rows. This proves full row rank without a numerical threshold.

Set `W_s=ker B_s` and let `P_s` be its Euclidean orthogonal projector. Choose orthonormal coordinate matrices `C_s` with row space `W_s`, always including the `N` rows of `H`. Nested spaces permit nested bases, and

\[
P_s=C_s^TC_s,\quad C_sC_s^T=I,\quad
A_s=C_{s+1}C_s^T,\quad
C_{s+1}=A_sC_s,\quad A_sA_s^T=I.
\tag{38}
\]

This follows because `W_{s+1}` is a subspace of `W_s`. No kinetic multiplier is introduced by the coordinate choice. The final dimension is `4N`: it contains the `n=3N` dimensional space

\[
K=\{(u,u,Du):u\in\mathbb R^n\}
\tag{39}
\]

and all `N` holonomy coordinates. Extra tangent frame directions have not been declared dynamically dispensable. Removing them would need another projectability proof.

The space `W_s` is an eliminated-contrast constraint space, not the full exact translation-coherence manifold. With triangle contrasts zero, `r_e=-h_b/3` on that triangle. A nonzero translation has no stabilizer on `N(u,1)`, so this retained holonomy is a small frustrated mode rather than exact law agreement. Its energy in `(a/2)J_1 sum r_e^2` is `a J_1 h_b^2/6`. The formation proof must bound this retained contribution together with the eliminated contrasts. Setting `h_b=0` by projection would erase the microscopic loop distribution and is not the map (38).

## 9. Exact Gaussian parents and inherited kinetic matrices

Give every `d` and internal triangle residual strength `J_1>0`, and each bridge strength `J_ell>0`. Let `B_all x=(d,r)` and let the resulting PSD stiffness be

\[
\mathsf H=B_{\rm all}^T\mathsf J B_{\rm all}
          =\mathsf H_N+J_1P_h,
\qquad P_h=H^TH,
\qquad \mathsf H_NP_h=0.
\tag{40}
\]

Its kernel is exactly `K` in (39), since all strengths are positive. The decomposition follows from (36) and (37). Declare

\[
K_a=a\mathsf H+P_K+\kappa I,
\qquad a\in[1,3],\quad\kappa>0,
\qquad f=P_Kw+\kappa z_{\rm obs},
\tag{41}
\]

where `w in K`. This precision is SPD because it is bounded below by `kappa I`. A Gaussian prior and normalized observation realizing the particular source `f` must retain their individual constants in the full joint. For the declared Gaussian target, the complete-state density is exactly

\[
\pi_a(x)=\frac{\det(K_a)^{1/2}}{(2\pi T)^{(2n+E)/2}}
 \exp\left[-\frac{(x-K_a^{-1}f)^TK_a(x-K_a^{-1}f)}{2T}\right].
\tag{42}
\]

There is no improper translation reference hidden in (42). Under a passive translation of coordinates, its mean, observation offsets, and prior data are pushed. The anchor breaks an active translation symmetry with fixed data; it does not break covariance under reexpression of those data.

For the specific normalized experiment (M7) in [the adaptive model](adaptive-normalized-model.md), `f=kappa z` and (42) is the **restricted variational optimizer**, not the physical outer posterior. That posterior has precision `K_a^phys=A_0(a)+kappa I=K_a-TR`. Equations (43)–(46) and (51) apply separately to either Gaussian target after substituting its own precision. The optimizer kernels below govern the configuration diffusion (M11). The physical prior reverse kernel required by (23) instead uses `A_0(a)` before observations. The exact restricted parent scalar retains the common additive term `C_T(a)` displayed in (M10a) of the adaptive model; Gaussian marginalization does not remove it or its learning derivative.

At stage `s`, choose orthonormal hidden-coordinate rows `U_s` spanning `range B_s^T`. In the orthogonal coordinates `y=C_s x`, `z=U_s x`, form

\[
\begin{array}{lll}
\mathsf A_s=C_sK_aC_s^T,&
\mathsf B_s=C_sK_aU_s^T,&
\mathsf D_s=U_sK_aU_s^T,\\
f_y=C_sf,& f_z=U_sf.&
\end{array}
\tag{43}
\]

The exact parent precision, linear source, and hidden target conditional are

\[
\begin{split}
S_s&=\mathsf A_s-\mathsf B_s\mathsf D_s^{-1}\mathsf B_s^T
       =(C_sK_a^{-1}C_s^T)^{-1},\\
j_s&=f_y-\mathsf B_s\mathsf D_s^{-1}f_z,\\
z\mid y&\sim\mathcal N\left(
\mathsf D_s^{-1}(f_z-\mathsf B_s^Ty),
T\mathsf D_s^{-1}\right),\\
y&\sim\mathcal N(S_s^{-1}j_s,T S_s^{-1}).
\end{split}
\tag{44}
\]

Complete the square in `z` to prove these identities. In particular the unnormalized integration factor is

\[
(2\pi T)^{\operatorname{rank}B_s/2}
\det(\mathsf D_s)^{-1/2}
\exp\left(\frac{f_z^T\mathsf D_s^{-1}f_z}{2T}\right).
\tag{45}
\]

It multiplies the remaining raw exponential with precision `S_s` and source `j_s`. Its determinant, source constant, and derivatives in `a` must remain in the evidence or effective action. Merely restricting `K_a` to `W_s` gives `mathsf A_s`, not generally `S_s`.

For two successive stages, exact mean and covariance composition is

\[
\mu_{s+1}=A_s\mu_s,
\qquad
\Sigma_{s+1}=A_s\Sigma_sA_s^T
=T C_{s+1}K_a^{-1}C_{s+1}^T.
\tag{46}
\]

Thus sequential Schur elimination agrees with direct elimination. The full row rank in (37) and (38), together with `K_a` SPD, proves that every displayed inverse and Gaussian density exists. The same matrices push an arbitrary actual Gaussian recognition mean and covariance; it need not equal (42).

If `P_h z_obs=0`, the Gaussian target's loop block is independent of all other Gaussian coordinates, with `z_b` mean zero and precision `aJ_1+kappa`. For the microscopic Langevin law with mobility `I`, drift `-K_a x+f`, and noise `sqrt(2T)`,

\[
dz_b=-(a(t)J_1+\kappa)z_bdt+\sqrt{2T}dB_b,
\qquad
dh_b=-(a(t)J_1+\kappa)h_bdt+\sqrt{6T}dB_b.
\tag{47}
\]

The Brownian motions in the orthogonal loop subspace are independent of its complement. This is an exact retained dynamics for a deterministic parameter trajectory `a(t)` supplied by the coupled recognition/learning equation. It is not a prescribed learning schedule. If the loop variance initially equals `T/(a(0)J_1+kappa)` and `a(t)>=1`, its scalar variance equation gives `Var(z_b(t))<=T/(J_1+kappa)`; multiply by three for `h_b`. The instantaneous equilibrium variance `T/(a(t)J_1+kappa)` is generally not the actual time-dependent variance.

For a general constant microscopic mobility `M`, linear projection has inherited instantaneous mobility

\[
M_s=C_sMC_s^T.
\tag{48}
\]

Indeed the projected quadratic variation is `2T M_s dt`. With constant `C_s` and the exact target conditional, the conditionally averaged Gaussian drift is `-M_s(S_sy-j_s)`. This follows from `E[x|y]=K_a^{-1}f+K_a^{-1}C_s^TS_s(y-C_sK_a^{-1}f)`. With the actual recognition conditional, define the hidden mean defect

\[
e_s(y,t)=\mathbb E_{Q_t}[x\mid y]
 -\mathbb E_{\pi_{a(t)}}[x\mid y].
\tag{49}
\]

Then its actual conditional projected drift is exactly

\[
-M_s(S_sy-j_s)-C_sMK_a e_s(y,t).
\tag{50}
\]

This gives the force interface needed by the conditional-control lane. The projected process need not be Markov, because hidden conditional means depend on history. A closed conditional-averaged diffusion is a replacement unless the generator is projectable or the conditional memory is retained. For `M=I` and the orthonormal `C_s`, `M_s=I` at every level. This inheritance does not assign larger mobilities to parent nodes. The holonomic pullback metric `(D iota)^T M^{-1}(D iota)` of Section 3 is a different operation and need not be the inverse of (48).

Finally, retaining a coordinate in a Gaussian law does not license replacing every microscopic mark by its value on the reconstructed constraint representative `C_s^T y`. A raw rooted cut translation is a linear covector of `x` and may have a component on `range B_s^T`. Retain its original copy, orientation, weight, and its full induced conditional kernel. If `m=L_s x` is the tuple of all required translation loop/cut marks for the declared trees, (44) gives its exact target-conditional kernel:

\[
\begin{split}
\mathbb E[m\mid y]
 &=L_s C_s^Ty
 +L_sU_s^T\mathsf D_s^{-1}(f_z-\mathsf B_s^Ty),\\
\operatorname{Cov}(m\mid y)
 &=T L_sU_s^T\mathsf D_s^{-1}U_sL_s^T.
\end{split}
\tag{51}
\]

This is a possibly degenerate Gaussian measure on the mark space, not necessarily a density against its full Lebesgue measure. A triangle holonomy row has `L_s U_s^T=0`, so its conditional covariance is zero and its value is retained exactly. Distinct cut copies can remain correlated through (51). For actual recognition use its own conditional mean and covariance; for the physical evaluator use the prior reverse conditional in (23). A nonlinear attention function of these marks is pushed through their complete kernel, not evaluated at their conditional means.

These kernels preserve correlated cut copies and generated interactions. They can be implemented as auxiliary conditional memory when a later operation needs them. A state-dependent sequence of mark draws must use the same joint conditional law, rather than independently redrawing each copy. If a demanded later operation needs the raw mark as a state coordinate and cannot consume this kernel, augment the retention map and redo its rank/metric calculation. No point estimate of a cut mark is called an exact kernel here.

## 10. Supported result and remaining interface

Equations (3)–(10) give the exact dynamic compatibility for changing law points, independent links, and stabilized loop marks. Equations (14)–(26) retain attention entropy, the changing normalizers, and conditional scores. Equations (35)–(50) prove a full-row-rank nested Gaussian flag, every loop's exact retention, direct/staged normalization, and inherited mobility with an explicit conditional drift defect. The compact construction (29)–(33) proves that regular nonidentity stabilizer holonomy is an inhabited option; the translation witness instead retains a small fluctuating, frustrated holonomy law.

The minimal remaining obligation for the full adaptive goal is to put these interfaces together with one dynamics proof that establishes, on the same finite adaptation interval, all successive formation episodes, substantial normalized-VFE learning, the conditional KL and moment bounds needed in (25) and (50), and continued admission at each actual activation. The raw cut-kernel versus explicitly retained cut-coordinate choice must be declared in that assembled witness. The most direct next action is to substitute its actual Gaussian mean/covariance equations into (44), (49), and (50) and quantify their changing-conditional errors. The geometry does not replace that calculation.

The evidence in this file is analytical. No scientific run, symbolic script, suite, GPU operation, vault edit, or publication action was executed for this derivation. Historical numerical results cited in the source documents have not been rerun or rebound to this artifact.
