# Agreement-derived partitions, common-data selection, and lineage

September 11, 2026. This continuation addresses the selection obligation left after the [critical alignment limit](critical-two-cycle-alignment-limit.md). It constructs a normalized, gauge-invariant partition kernel from the existing binary agreement likelihood, derives its induced partition prior and posterior, and proves how its connectivity calculation composes through complete coherent parents. It also gives an exact obstruction: decreasing total transported mismatch under the actual full-law Fisher flow does not ensure nested partition laws. A separate independence admission supplies a constructive nested coupling, with a positive-probability two-stage four-child example.

The distinction between a partition law and a useful meta-agent remains necessary. A connected component of one random agreement panel need not already have zero transported KL, a closed evaluator, or a cheaper complete interface. The new construction is a candidate common structural channel allowed by the source, not a claim that the source uniquely selected it or that the full RG goal is complete.

## 1. What the current sources specify

[Theory/05b_local_collective_elbo.tex](../../../Theory/05b_local_collective_elbo.tex), following eq:obs-interaction-energy, explicitly supplies a normalized binary success kernel exp(-E_a) for nonnegative sample-level energy. Its state hypothesis permits belief-law and model-law points. The [full-graph chapter](../../../Theory/07c_full_graph_meta_agent_vfe.tex), eq:full-graph-common-structural-channel, declares one recognition-independent channel with membership and complete parent variables among its outputs. Its partition section permits a normalized Gibbs membership factor but explicitly leaves the selector unspecified. Its top-down factors are conditional disintegrations of the selected joint; they are not independent extra arrows that can be chosen after the fact.

[Theory/06_general_coarsegraining.tex](../../../Theory/06_general_coarsegraining.tex), eq:cg-partition-naturality, requires gauge and node-relabeling compatibility without supplying a unique rule. The finite assignment move graph in [Theory/07e_inference_memory.tex](../../../Theory/07e_inference_memory.tex) supplies normalized dynamics for declared assignments, not an intrinsic assignment criterion. These are distinct provisions.

The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), sec:meta_agent_variational and sec:meta_agent_threshold, distinguishes its free-energy licensing proposal from its implemented coherence detector. It says that the post-merge functional and the claimed replacement of pair interactions have not been derived there, and identifies the detector's thresholds as choices. Its barycenter M-step does not supply the missing grouping comparison. No threshold value or overhead from that manuscript is imported into this construction.

The current [September research synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>) preserves the normalized common-channel and complete-interface requirements. Its older linked laboratory pages contain dated results and corrections; they are not used here as a selection law for the current GL model. All work remains over c_*.

## 2. Exact representations do not compete by observation evidence

Let W be the complete fine random state, P(do,dW) one fixed normalized joint, Pi_o its selected posterior, and p(o)>0 the evidence density. For every candidate R, suppose C_R is a normalized channel that leaves the same observation coordinate unchanged. Its exact coarse observed joint is

\[
 P_R(do,dz)=\int P(do,dW)C_R(W,dz),\qquad
 p_R(o)=p(o).
 \tag{1}
\]

The second equality follows by integrating z. Consequently, when the variational family is unrestricted on each admitted coarse carrier,

\[
 \inf_{Q_R}\mathcal F_R(Q_R;o)=-\log p(o)
 \quad\hbox{for every such }R.
 \tag{2}
\]

A restricted variational family can have a different approximation gap, and two independently specified generative models can have different evidence. Neither is the comparison in (1). A decrease of the coarse VFE at a fixed pushed recognition law can be discarded conditional KL; it is not an increase of the evidence.

For example, if two independent observed agreement bits have known success probabilities 1/2, the same two successes have probability 1/4 under every exact representation. Omitting both bits from a singleton candidate gives the empty-event probability 1. Comparing 1 with 1/4 would compare different data. Moving a bit from an internal edge to a cut edge does not authorize omitting it.

The normal-volume coefficients and logarithms in the earlier alignment limits are required terms in the induced measure. They cannot independently be used as an Occam score for arbitrary representations of the same exact joint. In particular, if every edge's observed count grows with n, an internal-block asymptotic that treated all exterior likelihoods as fixed cannot be applied separately to different blocks while ignoring that exterior n-dependence. Ordered conditional limits and a common-data model comparison are different calculations.

A membership variable can nevertheless be induced without inventing an independent partition prior. Choose one normalized structural kernel K_part(dR|W), fixed before recognition, and augment the joint:

\[
 P^{\rm aug}(do,dW,dR)=P(do,dW)K_{\rm part}(dR\mid W).
 \tag{3}
\]

This leaves the entire observed fine joint unchanged. Write P_0 for the fine prior and L(o|W) for its likelihood. For a discrete partition R of positive induced prior mass,

\[
 \begin{split}
 k_R&=\int P_0(dW)K_{\rm part}(R\mid W),\\
 p(o\mid R)&=\frac{1}{k_R}
   \int L(o\mid W)P_0(dW)K_{\rm part}(R\mid W),\\
 \pi_R(o)&=\frac{k_R p(o\mid R)}{p(o)}.
 \end{split}
 \tag{4}
\]

These are the prior, conditional likelihood, and posterior of a random variable in one joint, not evidences of competing exact representations. The choice of K_part remains a modeling or coarse-channel choice. Taking it to be any constant partition distribution demonstrates why the VFE identity alone cannot identify a unique selector.

For a recognition joint with partition marginal r and fine conditionals Q(dW|R), the exact decomposition is

\[
 \mathcal F^{\rm aug}
   ={\rm KL}(r\Vert k)-\sum_R r_R\log p(o\mid R)
      +\sum_R r_R\Gamma_R,\qquad
 \Gamma_R={\rm KL}\bigl(Q(dW\mid R)\Vert\Pi_o^{\rm aug}(dW\mid R)\bigr).
 \tag{5}
\]

This is a finite-density formula; the measure-level nonnegative KL chain handles extended values. The last term cannot be discarded unless the conditional recognition is matched. The entropy coefficient is one when measured in nats. An additional temperature requires its own declared normalized model; it is not generated by changing the grouping notation.

## 3. A partition kernel from the existing agreement experiment

Take a finite graph with labeled edge copies and let

\[
 d_e(W)=w_e{\rm KL}\bigl(b_i\Vert(\Theta_e)_\# b_j\bigr)\ge0,\qquad
 p_e(W)=e^{-d_e(W)}.
 \tag{6}
\]

For a two-channel bond, d_e can instead be the sum of the required belief and model weighted divergences, with the success event requiring all of those channel successes. This uses conditional independence of those specified record kernels given W, while allowing arbitrary correlations in W. A test of only the belief channel does not establish complete belief/model agreement.

Use the source's conditional agreement law to draw auxiliary bond bits B_e, independently given W, with success probabilities p_e(W). Let comp(B) be the partition into connected components of the underlying undirected active edge copies, including isolated vertices. Direction still matters in d_e and in every transport; weak connectivity is the explicitly chosen grouping readout. Define

\[
 \begin{split}
 K_B(B\mid W)&=\prod_e p_e(W)^{B_e}[1-p_e(W)]^{1-B_e},\\
 K_{\rm part}(R\mid W)&=
    \sum_{B:\operatorname{comp}(B)=R}K_B(B\mid W).
 \end{split}
 \tag{7}
\]

This uses one predictive agreement panel as the auxiliary seed of the structural channel. It is not a claim that such a panel was observed, and it is not multiplied into the data likelihood. Summing B, or equivalently summing R, gives one for every W. There is no new threshold or adjustable complexity coefficient in (7). Choosing this component readout is still an explicit construction, not a uniqueness theorem.

There is a useful exact formula for each partition. For a block I, let c_I(W) be the probability that its internal bond subgraph is connected, with c_singleton=1. Then

\[
 K_{\rm part}(R\mid W)=
  \prod_{e\ {\rm crossing}\ R}[1-p_e(W)]
  \prod_{I\in R}c_I(W).
 \tag{8}
\]

Indeed, a graph has components exactly R if every cross-block edge is closed and every within-block subgraph connects its block. Conditional independence gives (8). This formula includes all partitions, assigning probability zero to impossible disconnected blocks.

Transported KL is invariant under simultaneous passive reexpression of the incident laws and link. Thus each p_e and K_part is gauge invariant. A node permutation bijects bond configurations and component partitions, giving exact relabeling naturality. To attach a root and transport tree without breaking that naturality, one admissible seed rule chooses the root uniformly in each component and a spanning tree uniformly among its active edge copies. Relabeling bijects both finite choices. Carry the chosen root and tree as marks. This rule is fixed and used for prior, posterior, and recognition pushes alike.

For any input law Q, the actual partition marginal is

\[
 r_Q(R)=\mathbb E_Q K_{\rm part}(R\mid W).
 \tag{9}
\]

It is generally not obtained by replacing every p_e in (7) or (8) by E_Q p_e. Marginalization over a shared W correlates the bonds. In the exact four-node calculation below, the all-singleton probabilities are 13/180 from the true mixture and 77/1215 from that replacement, differing by 43/4860.

## 4. What composes through a coherent parent

On a selected coherent block, suppose the complete laws satisfy b_i=(g_i)#b_I. Use the corresponding transport in every channel required by the parent. For a cut edge e=(i,j) between coherent blocks I,J, retain its own dressed link V_e=g_i^{-1}Theta_e g_j. Invertible pushforward invariance of KL gives

\[
 d_e(W)=w_e{\rm KL}\bigl(b_I\Vert(V_e)_\#b_J\bigr).
 \tag{10}
\]

Thus the complete coherent parent, with every cut copy, weight, and required channel, evaluates the original conditional bond probabilities exactly. Stabilizer loops need not be identity and are not erased. The existing marked-parent constructions supply the associated-fiber types; no base-path transport is introduced.

The next formulas concern a new predictive panel given W and an already specified coherent parent partition. If that partition was selected from an earlier panel, the new panel is conditionally independent of that earlier seed given W. Conditioning on the components of the very same panel instead forces its cross-component bonds to be closed. With this distinction, if only the event that some new bond crosses a particular pair of blocks is requested, its conditional probability is

\[
 p_{IJ}^{\rm any}(W)=
       1-\prod_{e:I\leftrightarrow J}[1-p_e(W)].
 \tag{11}
\]

The scalar negative log-failure values -log(1-p_e) add in this expression, with their extended endpoint values. This aggregates a particular Boolean event. It does not identify the several V_e with one transporter, reproduce every labeled edge record, or justify discarding the joint law of the cut copies. Once W is integrated out, the expectation of the product is still required; the product of marginal failures is generally wrong. The finite check gives 31/45 versus 91/135 for those two cut-bundle predictions.

For a finite-strength coherent approximation C_0(W), coupling each pair of conditional Bernoulli bits with the same uniform seed gives

\[
 \left\|\mathcal L(B\mid W)-\mathcal L(B\mid C_0W)\right\|_{\rm TV}
 \le\sum_e|p_e(W)-p_e(C_0W)|
 \le\sum_e|d_e(W)-d_e(C_0W)|.
 \tag{12}
\]

The second inequality uses the Lipschitz constant one of exp(-d) on d>=0. Pushing the coupled bits to their components cannot increase this error. On compact Gaussian domains, the cut KL is locally Lipschitz in the complete law/link coordinates. The previously proved projection bounds therefore give the corresponding averaged partition-prediction bound whenever that complete interface is retained. In the critical case this permits an O(1/log n) bound against the same finite projected prior. Changing to the limiting prior adds its separate o(1) error. No bound is obtained by retaining only an averaged cut link or untracked direction.

There is also an exact deterministic composition identity. Let B^(1) and B^(2) be two sets of fine edge flags. First contract the components of B^(1), then apply the B^(2) flags to the quotient graph, keeping each endpoint incidence. Expanding the final components to fine vertices gives

\[
 \operatorname{comp}\bigl(\operatorname{quotient}_{\operatorname{comp}(B^{(1)})}
                                  (B^{(2)})\bigr)_{\rm expanded}
       =\operatorname{comp}(B^{(1)}\lor B^{(2)}).
 \tag{13}
\]

Every path in the union projects to a quotient path, and each quotient step expands to a B^(2) edge joined by B^(1) paths inside its endpoint components. This proves both containments. It remains valid with parallel edges and quotient loops.

If the two panels are conditionally independent given W with probabilities p_e^(1),p_e^(2), their union has probabilities

\[
 p_e^{\cup}=1-[1-p_e^{(1)}][1-p_e^{(2)}].
 \tag{14}
\]

It is this union law, not either original panel law, that the staged component calculation reproduces. If one reuses the very same panel after contracting all its components, there are no active cross-component edges left. If one draws another panel, the structural channel has acquired another declared seed. Those operations cannot be conflated. After averaging W, the joint mixture and complete endpoint/mark distribution must still be pushed once; independently fitted quotient bond rows do not inherit (13).

## 5. Exact zero, predictive bonds, and the strong-record endpoint

The hard graph of edges satisfying d_e=0 is a different readout from (7). For an absolutely continuous Gaussian law/link prior with the SPD polar variables free, each event d_e=0 has prior measure zero: it requires B_e=I and the matching mean constraint. A finite exponential tilt is absolutely continuous with respect to that prior. Consequently the hard exact-zero graph is empty almost surely at every finite strength, even though its limiting coherent state can have every edge aligned. Taking that hard readout before or after the singular limit does not commute.

The predictive-bond kernel is continuous in the p_e and avoids that particular discontinuity, but an open random bond does not imply d_e=0. It is an event with probability exp(-d_e). At finite strength, formation still needs its separate evaluator and accuracy admission.

For the repeated all-success model, put D=sum_e d_e and Pi_n proportional to a exp(-nD). Let R_G denote the connected-component partition of the entire available graph. If every edge bond is open then comp(B)=R_G. The union bound gives

\[
 \mathbb P_{\Pi_n K_{\rm part}}(R\ne R_G)
 \le\mathbb E_{\Pi_n}\sum_e[1-e^{-d_e}]
 \le\mathbb E_{\Pi_n}D.
 \tag{15}
\]

Whenever one of the earlier regular, high-cycle, or critical admissions supplies E D=d/(2n)+o(n^{-1}), this becomes

\[
 \mathbb P(R\ne R_G)\le\frac{d}{2n}+o(n^{-1}).
 \tag{16}
\]

The d here is the appropriate energy-shape dimension from that admission. For the critical K=2 example it is the d in its logarithmic theorem. This probability bound is faster than the slow mean-radius bound because agreement records test D, not the raw mean.

Thus, on one connected graph under these repeated all-success records, this particular selector ultimately chooses the whole connected component. It does not select two persistent proper intermediate blocks in the strong-record limit. Nonidentity stabilizer holonomy does not prevent that result: the holonomy can preserve the common law and leave every tested KL equal to zero. Heterogeneous observed failures, unobserved edges, different record schedules, and other selected interfaces are different conditions, not corrections to (16).

Both binary outcomes remain available in the original normalized model. With s_e successes and f_e failures the likelihood is p_e^{s_e}(1-p_e)^{f_e}. An interior empirical success fraction favors a positive mismatch rather than exact zero when the corresponding vector of probabilities is attainable in the model. No such new record dataset is assumed or generated here.

## 6. Decreasing mismatch does not imply nested lineage

Take the actual full-law Fisher flow for a fixed target with two selected successes on every edge and baseline preparation P_0. Its fine recognition is

\[
 Q_t(dW)\ \propto\ P_0(dW)e^{-\kappa(t)D(W)},\qquad
 \kappa(t)=2(1-e^{-t}).
 \tag{17}
\]

This is one fixed observed target. The values kappa=0 and kappa=1 occur at t=0 and t=log 2; no observations are changed between these two inference times. Augment every Q_t with the same kernel (7). The K factors cancel from the joint log-density ratio, so this is also the corresponding augmented Fisher flow.

A three-node chain (0,1),(1,2) gives a counterexample. Put prior mass (9/10,9/100,1/100) on three law/link configurations with

\[
 \begin{array}{c|ccc}
 &A&B&C\\ \hline
 p_{01}&1&1/2&1\\
 p_{12}&1/4&1&1\\
 D/\log2&2&1&0
 \end{array}.
 \tag{18}
\]

These probabilities are realizable in the same GL(2) Gaussian-KL likelihood: take unit edge weights, centered identity-covariance Gaussian laws and, independently on each edge, a polar factor diag(h,1) with h>=1 solving h^2/2-log h-1/2=d_e. That function is continuous, strictly increasing above h=1, and ranges from zero to infinity. Choose the orthogonal factors to be I for this witness. The finite atomic prior is proper. This witness concerns the general normalized model; it does not claim the continuous-prior asymptotic assumptions of the previous section.

At kappa=1 the normalized configuration masses are

\[
 Q_1(A,B,C)=(45/56,\ 9/56,\ 1/28),\qquad Z_1=7/25.
 \tag{19}
\]

On a chain, vertices 0 and 1 share a component exactly when B_01=1. Therefore

\[
 \begin{split}
 r_0(0\sim1)&=191/200,\\
 r_1(0\sim1)&=103/112,\\
 r_0(0\sim1)-r_1(0\sim1)&=99/2800>0.
 \end{split}
 \tag{20}
\]

At the same time,

\[
 \mathbb E_{Q_0}D=(189/100)\log2,\qquad
 \mathbb E_{Q_1}D=(99/56)\log2
                  <\mathbb E_{Q_0}D.
 \tag{21}
\]

The full fixed-target VFE also decreases, since this is its Fisher flow. Yet no coupling of these two partition marginals can make the later partition a coarsening of the earlier partition almost surely. Under any such coupling, the event 0~1 could only gain probability. In fact every coupling has probability at least 99/2800 that this pair is together initially and separated later, by the elementary bound P(A and not B)>=P(A)-P(B).

This is stronger than showing that one independently redrawn sequence can split a block: the marginal laws themselves rule out a nested coupling at these two times. The coherent state C has positive prior mass and dominates at infinite strength, so the counterexample is not caused merely by excluding global alignment from the model.

The general marginal equation also exposes the missing closure. Let pi_R be the fixed augmented target marginal, r_R the current marginal, and Gamma_R its conditional KL from (5). On the finite positive domain,

\[
 \dot r_R=-r_R\left[
     \log\frac{r_R}{\pi_R}+\Gamma_R
       -\sum_S r_S\left(\log\frac{r_S}{\pi_S}+\Gamma_S\right)
                         \right].
 \tag{22}
\]

Integrate the augmented Fisher equation conditional on R and use the KL chain to obtain (22). It reduces to the autonomous partition Fisher equation only when the conditional terms are equal across occupied partitions, in particular when all are zero. A list of partition probabilities does not generally carry those conditional dynamics.

## 7. A constructive sufficient condition for a nested coupling

The obstruction is not universal. Suppose the baseline law of the edge energies is a product of proper measures nu_e on [0,infinity), and records have the common all-success strength kappa. Other state coordinates may be correlated conditional on the energies. Then the energy posterior remains a product, with factors

\[
 \nu_{e,\kappa}(dd)=
    \frac{e^{-\kappa d}\nu_e(dd)}
         {\int e^{-\kappa s}\nu_e(ds)}.
 \tag{23}
\]

For kappa_2>kappa_1 and any threshold a, both 1_{d<=a} and exp[-(kappa_2-kappa_1)d] decrease in d. Their covariance under nu_{e,kappa_1} is nonnegative, as follows from half the expectation of the product of their two-copy differences. Dividing by the positive exponential expectation proves

\[
 F_{e,\kappa_2}(a)\ge F_{e,\kappa_1}(a).
 \tag{24}
\]

Draw independent U_e,V_e uniform on (0,1) once, and use the generalized quantile functions:

\[
 d_e(\kappa)=F_{e,\kappa}^{-1}(U_e),\qquad
 B_e(\kappa)=\mathbf1\{V_e\le e^{-d_e(\kappa)}\}.
 \tag{25}
\]

For every kappa, the joint energy/bond law is exactly (23) followed by (7). Equation (24) makes every d_e nonincreasing and every bond bit nondecreasing. The component partitions consequently coarsen pathwise. This establishes one explicit normalized coupling of the inference marginals with nested membership. It uses the prior, record family, and fixed seed rule; it does not read a current approximate recognition law to change a generative factor.

If every nu_e charges every neighborhood of zero, d_e(kappa) tends to zero almost surely under this quantile coupling. To see this, compare the exponentially tilted masses above epsilon and below epsilon/2. Their ratio tends to zero, so F_{e,kappa}(epsilon) tends to one; apply this to each fixed U_e<1 and rational epsilon>0. Every V_e<1 is eventually exceeded by exp(-d_e). Along the unbounded record-strength family, a finite connected graph therefore reaches its whole component after finitely many bond-opening events almost surely. The number of component merges is at most N-1. At a fixed Fisher target with record count n, the accessible range is only 0<=kappa<n; a merger beyond that range is not reached by continuing inference on the same fixed data.

This is a sufficient condition, not a property established for the arbitrary correlated induced priors in the preceding alignment papers. The counterexample violates energy independence. Nor does (25) prove that a given structural optimizer, sampled physical process, or arbitrary coupling of Fisher marginals follows this path. Its native object is a specified coupling along the inference index. Completing a full law/model/link trajectory and proving that its parent evaluators and memory close remain separate requirements.

### A proper full-GL realization of the independence admission

The admission can be realized without restricting the link variable to orthogonal matrices. In the centered Gaussian sector already produced by the earlier limits, draw arbitrary proper covariance and retained-mark data. For each new edge independently, draw d_e from nu_e, a Frobenius-unit symmetric direction U in dimension s=K(K+1)/2, and O from normalized Haar measure on O(K). Set B=exp(tU), where the unique t>=0 solves

\[
 w_e\phi(\exp(tU))=d_e,\qquad
 \phi(B)=\frac12\operatorname{tr}(B^2)-\log\det B-\frac K2.
 \tag{26}
\]

For a nonzero unit U with eigenvalues u_j,

\[
 \frac{d}{dt}\phi(\exp(tU))
    =\sum_j u_j(e^{2t u_j}-1)>0\quad(t>0).
 \tag{27}
\]

Each nonzero term is positive. The function starts at zero and tends to infinity: a positive eigenvalue gives exponential growth; if all eigenvalues are nonpositive, a nonzero negative eigenvalue gives linear growth through -t tr U. This proves existence and uniqueness. Reconstruct the physical link as Sigma_i^{1/2} B^{-1}O Sigma_j^{-1/2}. The centered mean term vanishes, so its actual weighted KL is exactly the sampled d_e.

This defines a normalized probability by pushforward of proper energy, direction, orthogonal, and covariance measures. With positive energy density and full direction/O support, its link support is the full GL(K) polar domain. The links remain independent variables and are not frame coboundaries; their orthogonal loop marks need not be flat. Their statistical relation to the covariance coordinates is part of this declared proper prior.

This is an explicit prior witness for one centered Gaussian channel, not a claim that the preceding arbitrary prior or the saved experiment has this factorization. Applying the theorem to a sum of active belief and model energies requires the corresponding joint energy-independence admission. The induced density near B=I depends on nu_e. A Gamma energy prior of shape gamma and rate a gives the exact integral and posterior

\[
 Z_\kappa=\prod_e\left(\frac{a_e}{a_e+\kappa}\right)^{\gamma_e},
 \qquad d_e\mid\kappa\sim{\rm Gamma}(\gamma_e,a_e+\kappa).
 \tag{28}
\]

An arbitrary gamma need not give the earlier bounded, nonvanishing Cartesian density at B=I. Its evidence exponent cannot be borrowed from the previous smooth-volume theorem. Equation (28) follows directly from its own normalized energy prior and keeps that distinction explicit.

### A two-stage membership event with positive probability

For an explicit scalar calculation, take three independent Exp(a) edge-energy priors on the four-node chain (0,1),(1,2),(2,3). Under (25), d_e(kappa)=X_e/(a+kappa), where X_e=-log U_e has unit exponential law. With Y_e=-log V_e independent, the bond opens at

\[
 T_e=\max(0,X_e/Y_e-a),\qquad
 \mathbb P(T_e>t)=\frac{1}{1+a+t}\quad(t\ge0).
 \tag{29}
\]

The last identity is the integral of exp[-(a+t)y] against exp(-y)dy. The opening times are independent and identically distributed, with atom a/(1+a) at zero and continuous laws conditional on being positive. Conditional on all three starting closed, their six strict orders have equal probability. The two outer edges come first in two of those orders. Therefore

\[
 \begin{split}
 P_{\rm two\ stages}(\kappa<\infty)&=\frac{1}{3(1+a)^3},\\
 P_{\rm two\ stages}(\kappa<n)&=
   \frac13\left[\frac{n}{(a+1)(a+n+1)}\right]^3.
 \end{split}
 \tag{30}
\]

For the second formula, each edge must have 0<T_e<n, of probability n/[(a+1)(a+n+1)], and the two outer edges must again occupy the first two places. Thus a fixed all-success target with a=1 and n=2 has probability 1/192 of completing this sequence at finite inference times. Along the unbounded strength family the probability is 1/24. This is a two-stage membership event under the declared coupling, with no list of admissible pairings imposed. It is not a claim that the hierarchy is preferred, that these finite-strength components are exactly aligned, or that the complete parent representation is smaller after interface and memory costs. Its clock is the inference-strength parameter, and no physical relaxation scale is inferred.

Selecting a partition also changes the conditional energy law. Even when the unconditional energies in (23) are independent,

\[
 \Pi_\kappa(dW\mid R)
    \ \propto\ \Pi_\kappa(dW)K_{\rm part}(R\mid W).
 \tag{31}
\]

contains the within-block connectivity sums in (8). Those sums generally couple the edge energies. Conditioning on the complete bond panel instead retains the product of its edge likelihoods. Consequently the independence hypothesis cannot simply be reapplied after retaining only R. This is a concrete conditional-state obligation for recursion, not a reason to discard the partition's selection likelihood.

## 8. Exact checks and the next useful-parent obligation

[partition_selection_exact.py](evidence/partition-selection/partition_selection_exact.py) ran once under pinned CPython 3.14.7 using Fraction arithmetic. It checks (8) against the full bond sum on every one of the fifteen four-node partitions for two conditional states; checks (13)-(14) on all 256 pairs of four-edge bond configurations and their complete probability law; and checks the correlation and common-data examples. It reproduces (19)-(21) exactly and the value 1/24 in (30). The [saved result](evidence/partition-selection/partition-selection-exact-result.json) records the probability rows and coefficients.

The script does not simulate a lineage, integrate the nonlinear GL model, or reproduce the saved heterogeneous experiment. The covariance, coupling, and quantile proofs above establish the general claims; the finite arithmetic checks their explicit witnesses. No independent-agent review or formal ledger certificate is asserted.

This step supplies an actual normalized partition construction, an exact coherent-parent connectivity evaluator, a controlled finite-projection comparison, and both a lineage obstruction and a constructive nested-coupling admission. It also shows why the earlier same-evidence parent limits cannot select a hierarchy merely by comparing their normalizing coefficients.

The next obligation is useful parent closure for this explicit selector under the actual correlated marked laws. In particular, determine what retained conditional state makes the joint bond/record evaluator and the Gamma_R term in (22) closed, and whether that state is smaller and informative at two proper first-level blocks. The edge probabilities are a candidate sufficient coordinate for the agreement experiment, while retaining the selected bond panel rather than only its components is a candidate way to keep its conditioning explicit; neither yet discharges the root/holonomy/interface or resource requirements. Carry the original observations, cut copies, root/holonomy/direction marks, and the membership-update seed protocol once. An energy-independent prior or a chosen monotone coupling cannot be silently attributed to a previously derived correlated parent. A complete answer must either provide the admitted reduced state and its cost or prove the necessary interface/memory obstruction. No new empirical dataset, tolerance, grouping penalty, production change, or base-manifold transport is introduced by this ticket. The full goal remains incomplete.
