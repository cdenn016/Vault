# Reconstruction of native-law collective response and parent access

September 12, 2026. The new native response moment, finite-query guarantee, interval readout, and 24-coordinate merged interface follow within their stated domains. This report reconstructs those claims from the formulas and inspects the saved exact calculations without rerunning them. It assigns no ledger state and establishes no causal effect of merging, individual sampled-state persistence, or complete runtime saving.

## 1. Sources and quantified target

The checked new sources are [the native response law](native-coherence-response-law.md), [the interval synthesis](native-coherence-response-episodes.md), and [the merged parent interface](native-response-parent-interface.md). Their retained inputs are [transported parent priors](transported-parent-priors-and-induced-couplings.md), Sections 2–4; [complete parent channels](shared-parent-complete-channel-and-recursive-cost.md), Sections 3–7; [common-prior hierarchy episodes](common-prior-native-hierarchy-episodes.md), Sections 1–6; and the preceding [response reconstruction](coherence-response-reconstruction.md). The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:epistemic_collapse` and its C0/C1 closure discussion, and the [wiki's operational introduction](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) were read in this continuing reconstruction. They identify existing coherence and closure questions, rather than certify the new mathematics.

The supplied model has a four-cycle, independent translation links, two two-dimensional unit-covariance law-mean channels, twelve connected generative ancestries, and forty-five root/tree decorations H. Its original ordered records have successes n=(8,1,8,1) and one failure per label in each channel. The native variance parameters are positive. The existing unit-start flow has likelihood power s=1 and a matched root throughout, and includes the recognition ancestry-count memory coordinate lambda. Its already certified path and error bound are retained inputs, not new computations here.

The new diagnostic fixes the same geometric output P={{0,1},{2,3}} on every fine draw, with roots 0 and 2 and internal tree edges 01 and 23. The generative H is still random. Neither the moment calculation nor the output map conditions on H=P. All primitive energies, particularly E_a, retain their definitions using H's generative tree paths.

For every such fine configuration and channel, let eta=-(r01+r23)/2. The fixed output's actual barycenters and dressed cuts give r_e=d_e+eta for both e=12,30. A collective query shifts the first geometric block relative to the second by h, holds the baseline draw and links fixed, and evaluates phi(r_e+s_e h), where phi(v)=exp(-||v||²/2), s12=1, and s30=-1. This identity is ordinary translation algebra and does not require equality of the output and generative trees.

The moment identity below is exact for every positive parameter choice and every proper fixed ancestry prior in this family, including the boundary reference. The interval constants are computationally established on the particular retained O/P reference path. The continuation conclusion is existential: there is a nonempty relatively open set of strictly positive priors near that reference on which the stated strict coarse inequalities hold. It is not a uniform statement over the full prior simplex.

For each time in the specified intervals, each finite K, each finite R>=0, and every common measurable adaptive policy with one Bernoulli answer per query, the anchored guarantee permits either channel to be chosen from shared retained information and earlier answers, with each input norm at most R. Every transcript reuses one frozen latent draw. Comparing different native times compares different preparation laws; it does not couple an individual hidden state across those times. For exact equality of first-parent and merged-parent transcripts, the policy may use only information present in both advertised interfaces. Arbitrary discarded first-parent geometry requires additional retained memory and is outside that equality claim.

## 2. Gaussian moments and the two-channel normalization

Given H, write the four residuals in one spatial coordinate as R in R⁴, with covariance

\[
\Gamma_H=r_aG_a+r_bG_{b,H}+r_cG_{c,H}>0.
\tag{1}
\]

The transported-generator positivity proof applies at every decoration: the child term has only the constant cycle direction in its kernel, and the independent-link term is positive on that direction. There are two identically distributed, independent spatial coordinate vectors before conditioning on their channel likelihood. For a failure mask M, set

\[
D_M=\operatorname{diag}(n+1_M),\quad
A_M=I+\Gamma_HD_M,\quad d_M=\det A_M,\quad
\Lambda_M=(\Gamma_H^{-1}+D_M)^{-1}.
\tag{2}
\]

Both precision matrices in (2) are positive definite where applicable, and d_M=det(Gamma_H)det(Gamma_H^(-1)+D_M)>0. Expanding the four failure factors gives the finite signed identity for the original likelihood. Completing the square in one spatial coordinate gives Gaussian integral d_M^(-1/2) and unnormalized second moment d_M^(-1/2)Lambda_M. The other coordinate supplies a second factor d_M^(-1/2). Thus

\[
e_H=\sum_M\frac{(-1)^{|M|}}{d_M},\qquad
T_H=\sum_M\frac{(-1)^{|M|}\Lambda_M}{d_M},\qquad
C_H=T_H/e_H.
\tag{3}
\]

Here C_H is the posterior second moment for one spatial coordinate of the original four residuals. The original likelihood is bounded and positive except where one residual vector vanishes, a finite union of Gaussian-null sets. Hence e_H>0, all required polynomial moments are finite, and C_H is positive definite. These facts come from the positive likelihood integral; the signs in (3) are not mixture weights.

Let q=(1,0,1,0)^T. In each spatial coordinate eta=-q^TR/2. Rotational symmetry gives the same second moment in both coordinates. Therefore

\[
\mathbb E[\|\eta^x\|^2\mid H,o]
=\frac12q^TC_Hq=\frac{\nu_H}{e_H},
\quad
\nu_H=\frac12\sum_M
\frac{(-1)^{|M|}q^T\operatorname{adj}(A_M)\Gamma_Hq}{d_M^2}.
\tag{4}
\]

The factor one half is essential: each of two spatial coordinates contributes q^TC_Hq/4. The matrix order is correct because Lambda_M=A_M^(-1)Gamma_H; no commutation of Gamma_H and D_M is assumed.

Conditional on H, the two channels have independent primitive coordinates and separate identical record likelihoods. Their joint evidence is e_H². They share the same H. For a_H=pi_R w(H|R) exp(lambda k_H), the full native mixture consequently has

\[
Z=\sum_Ha_He_H^2,\qquad
M_Q=\mathbb E_Q\|\eta^x\|^2
=\frac{\sum_Ha_He_H\nu_H}{Z}.
\tag{5}
\]

The extra e_H in the numerator is the evidence of the other channel. Neither averaging e_H before squaring nor replacing the full mixture by its conditional-P component gives (5). The common factor exp(lambda) can be canceled, leaving exp(lambda(k_H-1)). The current model posterior uses its model variances and lambda=0. The common root translation cancels from every residual.

The scalar T(t) in the synthesis has a different role from the matrix T_H in (3):

\[
T(t)=\mathbb E[-\log p_{01}^x-\log p_{23}^x]
=\sum_H\alpha_H(C_{H,00}+C_{H,22}).
\tag{6}
\]

It is half the expected sum ||r01||²+||r23||², since each channel has two spatial coordinates. Cauchy–Schwarz gives E(epsilon_x²|H)<=((sqrt(C00)+sqrt(C22))²)/2<=C00+C22 for epsilon_x=(||r01||+||r23||)/2. The exact omitted-vector moment (4) retains the cross term C02 and can be smaller. The coefficient script's `unit_coherence_nu` has the explicit factor two for the full sum of squared lengths, whereas the window script's scalar T uses no such factor. Those conventions are consistent with (6).

## 3. Anchored queries and finite adaptive transcript bounds

The first carrier retains p_e(0). Its anchored evaluator is

\[
\widehat p_{e,\mathrm{anc}}(h)
=\operatorname{clip}_{[0,1]}
\{p_e(0)+\phi(d_e+s_eh)-\phi(d_e)\}.
\tag{7}
\]

This lies in [0,1] and equals p_e(0) at h=0. Fix d,eta and k=s_e h. Subtracting the unclipped approximation from the true response gives

\[
\phi(d+\eta+k)-\phi(d+\eta)-\phi(d+k)+\phi(d)
=\int_0^1\int_0^1
k^T\nabla^2\phi(d+t k+u\eta)\eta du dt.
\tag{8}
\]

The differential operator is evaluated at the same d+tk+u eta in both integrations. The earlier direct calculation gives ||Hess phi||<=1 and ||grad phi||<=exp(-1/2). Thus (8) is bounded by ||h||||eta||. Separately grouping the two displaced-point differences bounds it by 2exp(-1/2)||eta||. Projection onto [0,1] cannot increase distance to the true probability in that interval, so for ||h||<=R the error is at most c_R||eta||, where c_R=min(R,2exp(-1/2)). This establishes a normalized approximate query, not a modification of the original record likelihood. No derivative claim through clipping boundaries is needed.

For a fixed channel, E||eta||<=sqrt(M_Q). When the policy can choose the channel using retained state or answers, the statewise error instead uses max(||eta^b||,||eta^m||). Its expectation is at most sqrt(2M_Q), because max(a,b)²<=a²+b² and both channel second moments equal M_Q. Independence after mixing H is not assumed.

Couple policy randomness and Bernoulli uniforms in the fine and approximate experiments. Before the first answer mismatch their shared histories, labels, and inputs agree. For a fixed X, the per-step mismatch probability is at most c_R max(||eta^b||,||eta^m||), regardless of the common history. A union bound on the first mismatch event, followed by integration over the same full preparation Q, proves

\[
\operatorname{TV}(\mathcal L_Q(\text{fine transcript}),
\mathcal L_{Q_R}(\text{parent transcript}))
\le\min\{1,Kc_R\sqrt{2M_Q}\}.
\tag{9}
\]

A channel schedule independent of the draw and query outcomes uses sqrt(M_Q). Two separately returned channel flags use the sum of their mismatch bounds, giving 2sqrt(M_Q); a joint-success Bernoulli is a single radial exponential in R⁴ and uses sqrt(2M_Q), provided R bounds the combined input norm. For the unanchored evaluator, replace c_R by exp(-1/2). The current model posterior has the identical proof with M_Pi. All these bounds concern finite frozen-query transcripts and absolute inputs relative to the same baseline. Clipped increments are not asserted to compose as sequential physical state updates.

## 4. Reconstruction of the exact coefficient and interval methods

I read [response_moments.py](evidence/native-coherence-response/response_moments.py) and [moment-polynomials.json](evidence/native-coherence-response/moment-polynomials.json). The numerator construction has an exact algebraic basis beyond its unit checks. By multilinearity of the determinant,

\[
\left.\frac{d}{ds}\det(A+s\Gamma_Hqq^T)\right|_{s=0}
=\sum_{j=0,2}\det(A\text{ with column }j\text{ replaced by }\Gamma_Hq)
=q^T\operatorname{adj}(A)\Gamma_Hq.
\tag{10}
\]

The code performs those two column replacements in A=I+Gamma_H D_M, with the j-th diagonal coefficient multiplying the j-th column. Replacing each selected column by Gamma_H e_j instead yields the diagonal selector for C00+C22. Polynomial multiplication and determinant permutation sums use Fraction coefficients. Dividing by d_M², inserting the mask sign, and including the one-half factor reproduces (4). The old exact denominator polynomials are reused as retained inputs.

The stored seven covariance groups have multiplicities 4,4,4,4,2,1,1, hence twenty O/P decorations. Their 112 terms are seven groups times sixteen failure masks. The saved PASS record reports that every unit numerator agrees with a separately computed Fraction covariance inverse and that the full normalizer matches the saved exact reference value. Its full-law unit moment is approximately 0.21599212425540337. The finite unit comparisons alone would not prove the formula at arbitrary parameters; the determinant identity (10) supplies that general argument. The new calculation's recorded runtime is CPython 3.14.7, with elapsed time 0.2993387000024086 seconds. It was not rerun in this reconstruction.

I also read [enclose_response_windows.py](evidence/native-coherence-response/enclose_response_windows.py), its [window record](evidence/native-coherence-response/moment-window-enclosures.json), the imported dyadic and jet helpers, and the relevant older path-validator definitions. The old certificate supplies a weighted Euclidean error E between the saved seven-coordinate log path and the actual native solution. Its coordinate weights are (1,1/sqrt(2),1,1,1/sqrt(2),1,1/2), with outward dyadic enclosures for the irrational entries. Every weight is at least one half, so every log-coordinate error is at most 2E. The new readout uses the recorded global E rather than a potentially smaller endpoint error.

The saved DOP853 dense data are used only as exact rational representations of the stored floating-point coefficients. `verify_candidate` reconstructs the alternating multiplications by x and 1-x, adds the saved left state, and restricts that polynomial to each proposed subinterval by an exact affine substitution. It compares every rational coefficient with the old candidate record before evaluation. Thus the new readout uses the polynomial to which the retained path certificate applies; no ODE is solved or reintegrated.

The treatment of path error does not require differentiating it. Write P(u) for the certified polynomial on normalized time u in [-1,1]. For each constant parameter delta in [-2E,2E]^7, consider the smooth readout f(P(u)+delta). Its zeroth input jet includes delta; higher input jets differentiate P only. Interval evaluation encloses these jets for every fixed delta, and Taylor bounds are uniform in that box. At each actual time, the actual error is some delta(u) in the box, so the union over fixed delta covers f(P(u)+delta(u)) pointwise. No assertion that the actual error is constant or has bounded derivatives is made.

The arithmetic endpoints are integers divided by 2^128. Addition is exact on that grid; multiplication and division use integer floor/ceiling; inversion rejects an interval containing zero. The exponential helper reduces to 0<=z<=1/2, sums through degree 48, and bounds the remaining positive tail by its degree-49 term divided by 1-z/50, then squares back. Reciprocal symmetry handles negative inputs. The finite-jet product, reciprocal, and exponential recurrences are those for derivatives divided by their factorials.

For each intermediate normalizer or moment, the order-10 tightening applies Taylor's theorem to f^(k)(u)/k!: its center coefficients carry binomial factors binom(l,k), and its last derivative bound carries binom(10,k). The final readout uses the order-0 Taylor radius sum of absolute center coefficients of orders 1 through 9 plus the uniform order-10 coefficient bound. Intersecting this with the direct interval enclosure is valid. Intersecting the final M,T,P lower bounds with zero is justified by their positive-integral definitions; a zero-containing denominator would fail before that operation. Alternating failure terms are evaluated algebraically with outward arithmetic, not treated as positive mixture components or clipped into probabilities.

The recognition readout selects saved coordinates 3,4,5 and active count coordinate 6. The model-posterior readout selects coordinates 0,1,2 and sets lambda exactly to zero. The numerical mixture routine uses exp(lambda) only for k=2 and one for k=1; this is correct after canceling the common exp(lambda) on the specified O/P boundary reference. It is not an implementation of the all-ancestry continuation, whose general weights remain exp(lambda(k_H-1)).

The saved output reports 17 contiguous covering intervals for [5,7] and 41 for [35,40]. Coverage endpoints and adjacency are checked in the script, and every chosen polynomial is matched to the old dense segment. All 58 new readouts passed, with recorded elapsed time 12.642194700005348 seconds under CPython 3.14.7. This reconstruction accepts the earlier full-path error certificate as a revision-matched input and checks the new readout logic; it does not claim a second independent full-path certification.

## 5. Interval consequences and the open-prior statement

The following are outward decimal supersets of the saved exact rational M enclosures:

| Interval | Recognition M_Q | Current model-posterior M_Pi |
| --- | --- | --- |
| [5,7] | [0.181245915, 0.196359349] | [0.174707415, 0.190241281] |
| [35,40] | [0.119453661, 0.121633988] | [0.119438088, 0.121538063] |

The broader M and T table in the synthesis also rounds outward from those saved rational ranges. In particular, both early M upper bounds are below 0.196359349, and both late bounds are below 0.121633988. The shared constants can be checked without relying on rounded square roots:

\[
0.628^2=0.394384>2(0.196359349)=0.392718698,
\]
\[
0.494^2=0.244036>2(0.121633988)=0.243267976.
\tag{11}
\]

Consequently (9) gives the stated strict-coefficient upper curves min(1,0.628 K c_R) early and min(1,0.494 K c_R) late under either complete reference law. Replacing c_R by R gives the simpler KR curves. These are bounds for every finite budget and radius, and can become one for large KR; they do not choose a tolerance or measure actual prediction errors.

The late upper M bound is strictly below the corresponding early lower M bound under each law. This proves a reduction of the fixed probe's omitted-vector second moment between those intervals. It proves neither monotonicity between intervals nor an effect caused by the merge, because both the conditional law and ancestry weights change and no counterfactual merger experiment is supplied.

For continuation, take a compact tube around the positive reference path through time forty. There are finitely many H, so their positive Gamma_H, positive e_H, and smooth moment formulas have uniform finite derivative bounds on a sufficiently small compact tube. The finite mixture Z and native K_pi remain bounded away from zero near the reference, including a relative neighborhood of its boundary prior. The full native field is thus locally Lipschitz in the state and has a bounded derivative in the fixed prior. If delta is the prior perturbation size, equal initial coordinates give state error at most B delta t exp(Lt), by integrating the differential inequality error'<=L error+B delta. Choosing delta small enough prevents exit from the tube. Bounded readout derivatives then make the moment perturbation tend uniformly to zero with delta.

The strict slack in (11), the strict earlier hierarchy-preference margins, and any desired finite list of strict interval comparisons therefore survive simultaneously on a small prior neighborhood. The already supplied curve pi_O=pi_O^0+epsilon, pi_P=pi_P^0-epsilon-10epsilon², and the remaining ten weights epsilon² enters the strictly positive simplex for sufficiently small epsilon>0. Every sufficiently small such point has a relative-open neighborhood preserving the strict inequalities. The conclusion uses all forty-five decorations analytically and selects no numerical perturbed prior. No narrow reference table interval is thereby certified for that entire neighborhood.

## 6. Exact merged access with 24 displayed real coordinates

The interface report uses S=(H,p₈,E₄), retaining the actual generative energy definitions. Its geometric first output is (S,z_A,z_B,V12,V30), with 28 real fields. Set L=V12+V30 and d12=z_B-z_A-V12. Then

\[
d30=z_A-z_B-V30=-L-d12.
\tag{12}
\]

For final root 0, the path to B is V12 when tree 12 is selected and -V30 when tree 30 is selected, because the latter edge is directed from B to A. Therefore

\[
z_*^{12}=(z_A+z_B-V12)/2,\qquad
z_*^{30}=(z_A+z_B+V30)/2.
\tag{13}
\]

In both cases the remaining non-tree mark is L. Substituting the first barycenters gives the direct fine barycenter using flattened paths (0,ell01,V12,V12+ell23) or (0,ell01,-V30,-V30+ell23), respectively. The direct remaining-edge mark is L in each case. Thus the stage map is the actual composition of the first output and the chosen second map. The roots differ by L/2 across the two tree choices, as expected when the loop is nonzero; the claim does not erase holonomy or assert tree independence.

The root retains (S,z_*^tau,L,d12) and its discrete tree/input-port history. Its count is 12+4+4+4=24. Equation (12) recovers d30 globally. Hence it evaluates all four old first-parent scalar probabilities phi(d_e^x), and every anchored query (7), exactly as the first output does. This is equality of the declared approximation, not equality of its barycenter residual with the fine residual. No additional error is added to (9) by this second compression.

Under passive translations of child frames, z_A and z_B shift by their respective root offsets, V12 and V30 by opposite offset differences, d12 and L are invariant, and either z_* shifts by the final root offset. With the generative reference also pushed, S is invariant. This establishes the stated translation covariance; it provides no general GL(K) or learned-covariance extension. The active ports A and B remain separately named after merging. An input uniform over all four children would instead force h=0. Their labels, orientations, and any controller memory are real parts of the retained interface.

Each anchored value lies in [0,1], so its Bernoulli kernel is normalized. With a shared policy restricted to common advertised information, equality of query values and common uniforms gives equality of all finite transcripts by induction, conditional on X and after mixing every H. A policy that reads an arbitrary discarded first-parent coordinate is not thereby reproduced. For the optional fixed-probe agreement panel, the two conditional flag probabilities produce normalized mask weights; that panel is distinct from the earlier ancestry-dependent panel. Its full-law merger probability m is not supplied by the previous native regime probabilities.

A deterministic forward map is a normalized Dirac kernel. A normalized randomized panel can first augment a full-support reference on the finite disjoint union of Euclidean H branches. Both root maps retain S, and all native prior, original posterior, and recognition density ratios to that reference are S-measurable. The elementary disintegration substitution

\[
\int 1_A(X)a(S(X))R_*(dX)
=\int a(S(y))\Psi(A\mid y)R_{*,C_2}(dy)
\tag{14}
\]

shows that all normalized native tilts share the same conditional after pushing. The standard Borel disintegration hypothesis holds by taking the finite discrete catalogs and full Euclidean coordinate spaces as codomains. Native relative entropy, evidence, and the sufficient-score Fisher moments are unchanged under the existing regularity hypotheses. The correlated reverse kernels compose; replacing them by independent parent or child marginals would change this result. Existence of these kernels does not establish cheap evaluation or sampling.

## 7. Storage arithmetic and its practical scope

The fine branch H has 36+4k_H real primitive coordinates, ranging from 40 to 52. The deterministic merged root has 24 on every branch, so

\[
\mathbb E[N_{\rm fine}-24]=12+4\mathbb E k_H,
\qquad
\mathbb E[N_{\rm fine}-28]=8+4\mathbb E k_H.
\tag{15}
\]

On the O/P reference, k_H=1+1_{H\in P}, giving 16+4w_P and 12+4w_P. The exact late P lower endpoints quoted by the interface report are the same fractions in the new window output. Both exceed 47/50. Thus the deterministic root saves strictly more than 19.76 displayed fields in expectation relative to the fine state, and the fixed first output saves strictly more than 15.76, under either reference law throughout [35,40]. These are fresh consequences of (15). The strict bounds also persist on a sufficiently small positive-prior neighborhood by the same continuity argument. The optional fixed-probe panel instead has expected output count 28-4m; its uncomputed m must not be imported from the different older panel.

The root's 24 fields replace the older root's four scalar parent-cut probabilities by d12's four vector components. It preserves those scalar probabilities and the larger anchored query family at the same displayed count. This does not assert a minimum dimension. Relative to retaining both first parents, it saves four real fields but can add formation, metadata, evaluator, and controller costs. With per-real storage price c and merged-minus-split additional cost Delta C, the net gain is 4c-Delta C. No sign follows without those prices and a workload. Four cached unshifted phi(d_e^x) values would be an additional optional cost on either representation. A fine implementation can compile the same interface and use the same native law solver, so the storage result is not an exclusive inference-speed advantage.

## 8. Evidence binding and outcome

The inspected new artifact hashes are:

| Artifact | SHA-256 |
| --- | --- |
| native-coherence-response-law.md | 966c22d606cec3e0ee294b106e4bfc80425e97f130735550618fab84f4ca7396 |
| native-coherence-response-episodes.md | 0f545c369112367db99bdfc619e0d4d0c7e1f9482bc2d4934cad9f8e07199d7a |
| native-response-parent-interface.md | 0285df8455f14eff1184a16b7e4d91e5925376edaa6bac0ae055ad62afd54bab |
| response_moments.py | 57c78e2ec5b54c32b3c88f4d7681233e07eaf1d87c8e66d9592d70e345d28a8c |
| moment-polynomials.json | af0023ade3deeb5241db7f6b8205897b8dee6a49699fcb8f471bb7ed730b1469 |
| enclose_response_windows.py | c1b9701141b9e0b35a034afec31580a3cdc4b307e07c68a3895e2082be1f76c0 |
| moment-window-enclosures.json | c629daf10739fb8ed12ea9d42b00687545d6c49eb256d919a5e781f7d7304c60 |

All 27 source entries across the two new receipts and the old path/regime receipts matched current SHA-256 values during read-only inspection. This includes the exact denominator catalog, saved trajectory, old path bound, readout candidates, and interval helpers. The new coefficient script's recorded self hash also matches the script hash bound by the window receipt. The final synthesis explicitly retains the common-information policy restriction and distinguishes its fixed probe from the actual ancestry-dependent hierarchy output.

Only source reads, saved-JSON inspection, hash comparisons, and this assigned report write were performed here. No coefficient producer, interval producer, old science, ODE, model, test, suite, GPU job, Lean operation, tamper check, or vault edit was run. The primary new evidence is the analytical reconstruction above, together with inspection of the recorded mechanical outputs. No conclusion is based on agreement among reviewers, and no formal ledger closure is assigned.

The strongest supported result is uniform native-law error control for the specified finite frozen-query task on the existing two windows, with strict continuation to an open full-positive-prior family, and an actual 28-to-24 parent map preserving that same anchored query interface without extra prediction error. This refutes any inference that the stated response requirement by itself makes two separate geometric parents necessary. It does not establish that merging is optimal after full costs, that learning selected the fixed probe, or that individual sampled agents persist.

The immediate remaining mathematical obligation is to extend the fixed-probe guarantee to the actual ancestry-dependent output of the existing hierarchy channel: use that output's own cuts, tree contrasts, and input ports; average over its full ancestry and panel law; and retain each needed evaluator before its arguments are discarded. The fixed-probe moment cannot simply be relabeled as that result or obtained by conditioning on a favored ancestry. This extension can begin with the existing native law and saved path evidence. A priced workload and tolerated loss, or a specifically required additional input family, remain necessary to resolve operational preference among complete interfaces. No further trajectory is needed to establish the scoped results already reconstructed here.
