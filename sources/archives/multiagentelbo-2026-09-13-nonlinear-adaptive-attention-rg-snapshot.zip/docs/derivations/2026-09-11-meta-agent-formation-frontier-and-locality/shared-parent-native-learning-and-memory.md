# Native shared-parent learning and normalization memory

September 12, 2026. The [shared-parent model](shared-parent-record-law-and-ancestry.md) now has an explicit native recognition/model learning law. The construction below covers finite-rate correlated inference, rather than replacing it by an instantaneous posterior. When ancestry is uncertain, Gaussian block normalizers produce an additional scalar memory. This term is required by the same normalized joint; it is not an added preference for a desired hierarchy.

The update has a global positive finite-dimensional solution in the declared model family. A separate exact E-step/M-step calculation supplies accepted finite updates and checks one such update for each fixed ancestry. Neither result establishes convergence to an informative two-level organization, a slow physical clock, or a resource advantage for a complete geometric parent.

## 1. Source and model boundary

The generative family, original eight record labels, mathematical ordered batch and positive variances are those of [shared-parent-record-law-and-ancestry.md](shared-parent-record-law-and-ancestry.md). [Theory/05](../../../Theory/05_elbo.tex), `prop:elbo-exact-m-coordinate`, `def:elbo-generalized-m-acceptance` and `prop:elbo-evidence-monotonicity`, requires finite expected log densities and an accepted M-coordinate. It distinguishes these from an arbitrary finite natural-gradient proposal. Its general alternating-convergence question remains open.

[learning-compatible-alignment-parents.md](learning-compatible-alignment-parents.md), Section 2, already derives native exponential-family E/M equations with the full recognition Fisher metric and model Fisher metric. The earlier [conditional-memory analysis](pointwise-learning-parent-closure.md) explains why a changing hidden conditional cannot simply be discarded. The present derivation applies those methods to the new hierarchical Gaussian prior. The old beta-prior flow is a different family. The live [PIFB2 tree source](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) and the [corrected root-prior objective](post-merge-source-and-gaussian-parent-bridge.md) remain the cross-scale source and normalization boundary. [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex) supplies the correlated hierarchical accounting.

For fixed ancestry T with k blocks, define primitive noises epsilon_i=mu_i-Z_T(i), xi_A=Z_A-Y, graph links ell_e and root Y. Each vector has four coordinates. Write their squared-energy sums as E_a,E_b,E_c,E_v, respectively. Their coordinate counts are

\[
 d_a=16,\qquad d_b(T)=4k,\qquad d_c=16,\qquad d_v=4.
 \tag{1}
\]

The generative variances are a,b,c,v. Their positive precisions are u_a,u_b,u_c,u_v, the reciprocals of those variances. These u variables are not the earlier beta concentration parameters. All frame-dependent means and cross-scale offsets are pushed with the reference laws under passive translations; the squared noises mean deviations from those pushed references. No independent link is replaced by a frame coboundary.

## 2. Exact posterior moments and accepted M-coordinates

For the fixed mathematical batch n=(8,1,8,1) in each channel, let Gamma=a B B^T+b H H^T+cI, where H=B R_T. For a subset S of the four physical edges, put D_S=diag(n+1_S) and

\[
 w_S=\frac{(-1)^{|S|}}{\det(I+\Gamma D_S)},\qquad
 V_S=(\Gamma^{-1}+D_S)^{-1},\qquad
 e=\sum_S w_S,\qquad
 C_o=\frac{\sum_S w_S V_S}{e}.
 \tag{2}
\]

C_o is the posterior residual second-moment matrix in any one of the four coordinate directions. The two channels have identical counts, and each two-dimensional channel is rotation invariant, so all four directions have the same matrix and zero mean. Equation (2) follows by integrating r r^T in the same sixteen Gaussian terms used for the evidence. Its signed coefficients are not latent mixture probabilities. The positive original posterior density proves C_o positive definite.

For an arbitrary correlated recognition law Q with finite positive energies, maximizing the expected complete log likelihood over the four variances gives

\[
 a^+=\frac{E_Q E_a}{16},\qquad
 b^+=\frac{E_Q E_b}{4E_Q k},\qquad
 c^+=\frac{E_Q E_c}{16},\qquad
 v^+=\frac{E_Q E_v}{4}.
 \tag{3}
\]

For fixed T, E_Q k=k. The variable-k case in (3) applies to the normalized mixture introduced below. Each denominator is positive. These are the unique interior maxima of the corresponding functions -(d/2)log variance-E_Q energy/(2 variance). In the admitted densities all energies have positive expectation, so the source's covariance-boundary exception does not invalidate a single update.

At the exact old posterior for fixed T, Gaussian conditioning of the primitive noises on r makes (3) directly evaluable. With C=Gamma^{-1}(C_o-Gamma)Gamma^{-1},

\[
 a^+=a+\frac{a^2}{4}\operatorname{tr}(BB^\top C),\qquad
 b^+=b+\frac{b^2}{k}\operatorname{tr}(HH^\top C),\qquad
 c^+=c+\frac{c^2}{4}\operatorname{tr}(C),\qquad v^+=v.
 \tag{4}
\]

For example, epsilon conditional on r has mean a B^T Gamma^{-1}r and covariance aI-a^2 B^T Gamma^{-1}B. Taking its posterior second moment yields the first formula; the block and link formulas follow from their corresponding linear maps. The root is independent of r and the records. This also shows why finite-rate recognition need not use the same conditional geometry as the current model.

Holding Q fixed, the change in negative ELBO under (3) is a sum of terms proportional to log x+1-x, with x the new-to-old variance ratio. Hence it is nonpositive. If Q was the exact old posterior, the source's ELBO identity gives nondecreasing observed evidence after the step. For an inexact Q, accepted M-coordinate monotonicity concerns that ELBO; evidence monotonicity does not follow without the exact-E hypothesis.

The [exact calculation](evidence/shared-parent-learning/learning_exact.py) applies one exact E-step and one M-coordinate to each of the fifteen existing fixed-tree candidates from a=b=c=v=1. All fifteen variances remain positive and all fifteen exact evidences are nondecreasing. The one-block candidate remains the unique evidence maximizer after this one update. Its variances become approximately (0.575846624,1,0.709034223,1); the adjacent two-pair candidate becomes (0.615663342,0.775124264,0.723527397,1). Their new evidences are approximately 9.29476582749 x 10^-13 and 2.47138738251 x 10^-13. The [result](evidence/shared-parent-learning/result.json) retains every candidate, tie, covariance and exact fraction. No subsequent iterations search for a preferred grouping.

## 3. One normalized ancestry joint

To describe uncertain ancestry, let pi_T be any fixed strictly positive normalized prior on the fifteen candidate trees. Its values are an input to the theorem; no numerical pi_T is selected here. The state space is the finite disjoint union of each tree's continuous latent space. This gives one normalized generative joint pi_T P_u(X|T)L_o(X), rather than independently chosen posterior structural kernels.

With U_j=-E_j/2 and k=k(T), use the reference measure whose density on tree T is pi_T(2pi)^(-d_T/2) relative to its latent Lebesgue measure. The actual prior log density relative to this reference is

\[
 \sum_j u_j U_j+2k\log u_b
       +8\log u_a+8\log u_c+2\log u_v.
 \tag{5}
\]

The term 2k log u_b is indispensable when k varies. It is the Gaussian normalization of the four coordinates in each block. Integrating the prior over all continuous latents returns pi_T for each T.

Define a correlated recognition family with positive precisions rho_j, real omega, and likelihood power s in [0,1]:

\[
 Q_\eta(dT,dX)=Z(\eta)^{-1}
 \exp\left[\sum_j\rho_j U_j+\omega k+s\log L_o(X)\right]\mu(dT,dX),
 \qquad \eta=(\rho_a,\rho_b,\rho_c,\rho_v,\omega,s).
 \tag{6}
\]

The positive Gaussian reference and bounded L^s normalize this family. Gaussian moments and powers of log L are integrable, including at s=0: the logarithmic singularities at zero residual have codimension two per record label and are locally integrable. On compact positive-precision sets these moments vary smoothly. Each point used here lies in a regular open natural-parameter domain; a small negative neighborhood of s=0 is also integrable when its Gaussian tail quadratic remains positive. For full ancestry support, the four energy statistics, k and log L have no affine dependence, so the recognition Fisher covariance is positive definite. At fixed T, k is constant and its redundant coordinate is omitted.

Conditional on T, (6) is the normalized Gaussian prior at variances 1/rho_j tilted by L^s. Let zeta_T(rho,s) be that full eight-label tilt normalizer. Its ancestry marginal is

\[
 Q_\eta(T)=
 \frac{\pi_T e^{\lambda k(T)}\zeta_T(\rho,s)}
      {\sum_A\pi_A e^{\lambda k(A)}\zeta_A(\rho,s)},
 \qquad \lambda=\omega-2\log\rho_b.
 \tag{7}
\]

All conditional and ancestry laws in (7) are disintegrations of the same Q. They are not multiplied independent parent posteriors. At the exact current model posterior, rho=u, s=1 and omega=2 log u_b, hence lambda=0.

## 4. The full finite-rate native flow

The target natural parameter of the current model posterior is eta_*=(u_a,u_b,u_c,u_v,2 log u_b,1). The standard exponential-family calculation gives the exact native recognition flow

\[
 \dot\rho_j=u_j-\rho_j,\qquad
 \dot\omega=2\log u_b-\omega,\qquad
 \dot s=1-s.
 \tag{8}
\]

It uses the full correlated recognition Fisher metric. It is not a Gaussian mean-field update and does not assume rho=u or an instantaneous E-step.

Let K_pi=sum_T pi_T k(T). The model Fisher metric for the complete normalized joint, including its fixed conditional record kernel, is diagonal:

\[
 G_P(u)=\operatorname{diag}\left(
 \frac8{u_a^2},\frac{2K_\pi}{u_b^2},
 \frac8{u_c^2},\frac2{u_v^2}\right).
 \tag{9}
\]

Conditioning on T proves (9): primitive Gaussian noise scores have zero conditional mean and independent fluctuations; averaging their variances gives the prior expected number of blocks. The observation kernel adds no precision derivative conditional on the complete state.

Native model-Fisher descent of the same negative ELBO gives

\[
 \dot u_a=u_a-u_a^2\frac{E_Q E_a}{16},\qquad
 \dot u_c=u_c-u_c^2\frac{E_Q E_c}{16},\qquad
 \dot u_v=u_v-u_v^2\frac{E_Q E_v}{4},
 \tag{10}
\]

and

\[
 \dot u_b=\frac{E_Q k}{K_\pi}u_b
                 -\frac{u_b^2 E_Q E_b}{4K_\pi}.
 \tag{11}
\]

The denominator in the metric is the prior mean K_pi; the score numerator uses the recognition moments E_Q k and E_Q E_b. Replacing all of them by a fixed k or silently averaging per-tree updates gives a different vector field. For a fixed tree they all reduce to that tree's k.

To verify the common objective, put A(eta)=log Z(eta) and A_P(u)=-8 log u_a-8 log u_c-2 log u_v. Then

\[
 F(\eta,u)=(\eta-\eta_*(u))^\top\nabla A(\eta)
                  -A(\eta)+A_P(u).
 \tag{12}
\]

Differentiating in eta gives G_Q(eta)(eta-eta_*). Differentiating in u_b includes both the block-energy term and the derivative 2k/u_b of (5), giving (11). The other derivatives give (10). Consequently

\[
 \dot F=-(\eta-\eta_*)^\top G_Q(\eta)(\eta-\eta_*)
             -(\nabla_uF)^\top G_P(u)^{-1}\nabla_uF\le0.
 \tag{13}
\]

These equations define law-level inference and model learning in the declared unit inference scale. They do not specify a stochastic particle motion or a physical clock for individual links. A finite Euler step in precision coordinates is not the accepted M-coordinate (3), and it must not inherit that coordinate's monotonicity claim. For uncertain ancestry, even a unit natural step in b-variance coordinates need not equal (3), because (11) contains E_Q k/K_pi.

## 5. Global positive existence and the neutral root

The flow (8)-(11) has a unique global solution with positive model and recognition precisions for every positive initial u,rho, finite omega and s in [0,1]. Here global means every finite inference time; it does not mean boundedness as time tends to infinity.

The proof uses the actual finite family. Each model precision obeys an equation A(t)u-B(t)u^2 with nonnegative B. The non-block coefficients A are one, while the block coefficient is E_Q k/K_pi, bounded between 1/K_pi and 4/K_pi. This gives an exponential upper bound on every u over each finite interval. The explicit filter solution of (8) gives rho_j(t)>=exp(-t)rho_j(0)>0 and a finite upper bound. Also s stays in [0,1].

For these compact positive rho ranges, the conditional energy moments Q(.|T) are uniformly finite over the finite tree set and s in [0,1]. Arbitrary omega only changes their convex mixture weights, so B(t) has a finite upper bound independent of omega on that time interval. From d(1/u)/dt=B-A/u<=B_max one obtains a positive lower bound on u. The log u_b forcing in the omega equation is therefore bounded on finite intervals. No variable can reach the boundary or escape at finite time, and the locally smooth vector field continues uniquely.

The root factor separates exactly: E_Q E_v=4/rho_v. If rho_v(0)=u_v(0), then both root precisions remain at that common value and the root posterior remains its initial Gaussian. The resulting native learner has eight evolving scalars: three u, three rho, omega and s. Equivalently it carries lambda instead of omega. For a fixed ancestry the count coordinate is redundant, leaving seven scalars under the same matched-root condition. A supplied inference time can replace the known solution for s, but an autonomous state description retains it.

The nonnegative discrete-record objective F decreases, but this does not prove convergence to an interior stationary point. For example, take a toward zero with b,c,v fixed and Q the corresponding exact posterior. Each Gamma_T has a positive limit because c>0, and the evidence has a positive finite limit. Thus bounded objective values allow an unbounded precision u_a. The level sets are not coercive; the source's general convergence gap has not disappeared.

## 6. Normalization memory and its precise directional effect

Combining the first two relevant equations in (8) gives

\[
 \dot\lambda=-\lambda
       -2\left[\frac{u_b}{\rho_b}-1-\log\frac{u_b}{\rho_b}\right].
 \tag{14}
\]

The bracket is nonnegative. With lambda(0)=0,

\[
 \lambda(t)=-2\int_0^t e^{-(t-z)}
       \left[\frac{u_b(z)}{\rho_b(z)}-1-\log\frac{u_b(z)}{\rho_b(z)}\right]dz\le0.
 \tag{15}
\]

The forcing equals minus the KL between the four-dimensional Gaussian block reference at recognition precision rho_b and the model block reference at u_b. This is a comparison of the Gaussian reference factors; the actual record-conditioned block marginal need not be Gaussian.

At fixed rho and s, lambda changes the relative ancestry odds by exp(lambda times the block-count difference). Thus its negative sign favors fewer blocks relative to the mixture pi_T zeta_T(rho,s). It does not prove that the actual evolving expected block count decreases, because rho and s also move. It is not a newly chosen static cost and does not compare exact representations by different evidence. If u_b/rho_b tends to one, the memory relaxes to zero; every finite interior stationary point has lambda=0.

This effect occurs for a concrete admitted initial state, not just a hypothetical mismatch. Start at the exact unit-variance posterior, so rho=u=1, s=1 and lambda=0. The saved exact M-coordinate has b^+=1 for the one-block tree and b^+<1 for each other tree. For every positive pi_T, (11) therefore has dot u_b(0)>0. Since dot rho_b(0)=0, the ratio initially departs from one. If h=dot u_b(0), smoothness gives

\[
 \lambda(t)=-h^2t^3/3+O(t^4)<0
 \tag{16}
\]

for sufficiently small positive t. This is a local written expansion, not an integrated trajectory. The unconditioned-prior initial state s=0 has a different startup order and is not assigned (16).

The count memory cannot be dropped from this full recognition family. Holding rho,s fixed, the derivative of E_Q k with respect to lambda is Var_Q(k)>0 because all block counts retain positive weight. Distinct lambda values therefore give distinct ancestry laws even when all other displayed recognition coordinates agree. This is a family-wide statement; no minimality claim is made for one fixed autonomous trajectory.

## 7. Tempered inference is finite-dimensional but not a sixteen-term oracle

For 0<s<1, the conditional normalizer in (7) is not the finite failure expansion used in (2). In one channel, define

\[
 c_j(s)=(-1)^j\binom{s}{j},\qquad
 z_T(\rho,s)=\sum_{j\in\mathbb N^4}
 \left[\prod_e c_{j_e}(s)\right]
 \det[I+\Gamma_T(\rho)\operatorname{diag}(sn+j)]^{-1}.
 \tag{17}
\]

Here Gamma_T(rho) uses variances 1/rho_a,1/rho_b,1/rho_c. The full zeta_T equals z_T squared in the equal-channel batch. The series follows from (1-p)^s=sum_j c_j p^j. For 0<s<1, c_0=1 and all c_j for j>=1 are negative, with total absolute sum two. The four-fold series is absolutely convergent, so termwise Gaussian integration is justified. Replacing each determinant term by that term times its Gaussian covariance gives the analogous absolutely convergent second-moment numerator.

This representation also gives a certified truncation bound without assuming cheap evaluation. For J>=1,

\[
 \tau_J(s)=\sum_{j>J}|c_j(s)|
            =\prod_{j=1}^{J}(1-s/j).
 \tag{18}
\]

The truncated polynomial g_J(p)=sum_{j=0}^J c_j p^j lies between (1-p)^s and one and decreases to the former. Its pointwise excess is at most tau_J. Replacing all four failure factors by these polynomials therefore gives a positive upper approximation z_J with

\[
 0\le z_J-z_T\le4\tau_J.
 \tag{19}
\]

For the second-moment numerator N_J in one coordinate direction, the same positive-weight argument gives 0<=N_J-N<=4 tau_J Gamma_T in Loewner order. If z_J>4 tau_J, these inequalities supply finite bounds on the normalized second moment. At s=1 the expansion terminates at J=1; at s=0 the prior is evaluated directly. No truncated-series calculation was executed. The slow tail near s=0 and the number of terms remain computational costs; eight state coordinates do not imply an inexpensive solver.

## 8. The record carrier does not close the full native learner by itself

The previous beta family had a common conditional geometry given p. Here that conditional depends on recognition and model precisions. A simple admitted pair of recognition states shows the missing information. Fix the four-singleton tree, model variances a=b=c=v=1, and s=0. Take recognition Gaussian variances (a_Q,b_Q)=(1,1) or (1/2,3/2), with c_Q=v_Q=1. Both give Gamma_Q=2BB^T+I and hence exactly the same full original record law. Their hidden child/block noise energies differ.

Under (10), the native model variance derivatives for a and b are respectively (0,0) in the first state and (-1/2,+1/2) in the second. Thus the same retained p law and same current model do not determine the full model-learning vector field. Recognition precision or equivalent conditional-energy information must be carried. The example is a full-family obstruction; it does not establish minimal memory on a smaller reachable set from one chosen initial condition.

A sufficient-statistic construction can retain T, the full original p catalog, and the learned Gaussian noise-energy statistics. The source's common-channel score argument then becomes applicable, but the complete geometric parent also needs its own laws, interface and structural marks. No law-level parameter count is a substitute for that construction. In particular, the eight-scalar native learner and the fixed ancestry catalog are already available to the fine analytic implementation; they are not a formation-specific saving.

The next obligation is the complete parent channel for this actual learner, including the conditional-energy information, local access, retained graph marks, and recursive cost. The ancillary root, endpoint ancestry equivalence, and one-static-preparation identification limit remain in force. Full sampled-link dynamics and physical time are not supplied by a trajectory of recognition laws. The useful learned-hierarchy goal remains incomplete.

## 9. Execution and preservation

The [exact result](evidence/shared-parent-learning/result.json) checks posterior covariance positivity, Gaussian conditional energy formulas against the complete primitive-noise covariance, root neutrality, the singleton variance symmetry and exact evidence nondecrease for all fifteen single M-coordinates. It also stores coefficient arrays for the shared M-coordinate under any supplied pi_T: posterior weights are proportional to pi_T times old evidence; block-variance pooling additionally weights by k. No numerical ancestry prior is chosen.

The first invocation stopped while serializing a generated exact rational with more than Python's default 4,300 decimal digits. Its [script](evidence/shared-parent-learning/learning_exact-before-serialization-fix.py) and [error output](evidence/shared-parent-learning/serialization-failure.txt) are retained. The fix raises only that calculation process's integer-to-text limit to 200,000 digits. No formula, input, scientific assertion or host setting changed. The corrected invocation passed in 0.1694268999999622 seconds. This is one completed scientific calculation after an output-format failure, not a first-invocation pass.

No old scientific main, iterative fitting, parameter search, ODE, sampling, broad suite, GPU, Lean or tamper check ran. The finite-rate flow, global existence, normalization memory and series bounds are written derivations; the only executed learning steps were the stated exact M-coordinates. The [inspection receipt](evidence/shared-parent-learning/execution-and-inspection.json) binds scripts, results, sources and preserved artifacts. No formal ledger certificate is issued.
