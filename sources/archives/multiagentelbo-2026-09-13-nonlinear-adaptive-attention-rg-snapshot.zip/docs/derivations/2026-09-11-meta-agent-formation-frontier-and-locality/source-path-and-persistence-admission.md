# Source reconciliation: learned laws, kinetic paths, and finite persistence

September 11, 2026 continuation at fixed c_*. This analysis resumes the path-and-stopping gate from [learned-multilabel-membership-and-stopping.md](learned-multilabel-membership-and-stopping.md). The source already contains a parent-sensitive Markov mechanism, finite survival laws, and clock controls. They must be used before declaring a temporal construction absent.

The preceding result did not disprove useful finite-lived organization: changing partitions can have informative long-lived responses, and a finite RG tree can legitimately terminate in a whole-system root. What remains unestablished is a specific useful learned hierarchy under its complete experiment, response, memory, preparation, and kinetics. Eventual constancy and avoidance of a final root are not added requirements of the user's task.

## 1. What the live sources specify

The current source comparison gives the following distinct constructions.

| Source | Existing construction | Boundary relevant here |
| --- | --- | --- |
| [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex), eq:full-graph-common-structural-channel through eq:full-graph-common-structural-pushforwards | One normalized structural channel pushes the complete generative, posterior, and recognition laws, retaining membership, edge laws, and geometric marks. | This is a scale channel. It does not specify the inference-time transition or a unique selector. |
| [Theory/07e](../../../Theory/07e_inference_memory.tex), eq:rg-memory-sweep and thm:rg-memory-prepared-parent | A declared local Metropolis step followed by a full-parent conditional refresh; an exact prepared parent-history law. | Its proposal, update order, positive target, and preparation are specified inputs. |
| Theory/07e, eq:rg-memory-killed-survival and thm:rg-memory-episode-means | Exact finite-episode survival and stationary entrance/exit means, with explicit waiting controls. | Persistence comparisons need the event or response, preparation, clock, and comparator. Permanent group membership is not required. |
| [September 9 parent-sensitive construction](../2026-09-09-parent-sensitive-rg/construction-or-strongest-theorem.md) | An executed nonflat finite realization, exact prepared parent transitions, and survival-curve crossings after flux matching. | The declared 432-row component, 250 decorated parents, and original mechanism remain a separate admitted experiment; none is rerun here. |
| Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), sec:meta_agent_variational and sec:rg_status | A proposed post-merge free-energy criterion, the distinction between tying and marginalization, and conditional RG closure. | The post-merge replacement functional and complexity choice are not uniquely specified. |
| PIFB2, ass:closure_regime and thm:rg_exact_closure | Exact quadratic-plus-log-determinant closure under a global conditional Gaussian fiber identity, with the measure and other stated assumptions. | A local quadratic expansion, the general dynamic nonflat model, and automatic closure of the original KL family do not satisfy this by notation alone. |
| PIFB2, thm:rg_detector_retention | Positive retention conditional on a calibrated saving bound and an inequality dominating cost and residuals. | The positive saving term is assumed, not derived from coherence or the detector. |

The live implementation [parent_sensitive_transition.py](../../../src/multiagent_elbo/rg_v2/parent_sensitive_transition.py) follows the same order: metropolis_kernel constructs the symmetric-proposal Metropolis step, step applies that local kernel and then refreshes the retained parent conditional, and d_endpoint_kernel builds the prepared parent operator. This was read directly; no production route or historical experiment was executed or changed.

The source's Gibbs configuration energy and the native recognition ELBO are also distinct objects. Exact Gibbs pushforward preserves its partition function but need not preserve the minimum of its energy density under a changed reference. For the normalized common-data Bayesian experiment, exact representation change preserves the observed evidence; unrestricted posterior minimization gives the same -log evidence on each sufficient representation. Those statements must not be interchanged to manufacture the proposed post-merge saving.

## 2. The existing kinetic mechanism

Use the finite notation of Theory/07e. Let pi be its positive normalized target on incidence states i, C the complete parent projection, J its target conditional lift, and M the declared target-reversible local proposal step. Then

\[
 JC=I,\qquad D=CJ,\qquad T=MD,\qquad L=JMC,\qquad JT=LJ.
 \tag{1}
\]

The prepared initial law nu J gives the parent Markov history with transition L. An arbitrary initial law only acquires that preparation after a completed D stage. The full chain has the original target and preserves connected-component masses. Its VFE decrease is the conditional KL of the reverse transition, as already derived in the source. These are existing results.

For a proper event A in a finite irreducible component, the killed matrix retains escaped mass as lost mass:

\[
 P_\mu(\tau_{A^c}>n)=\mu T_A^n{\bf1},\qquad
 E_\mu\tau_{A^c}=\mu(I-T_A)^{-1}{\bf1}.
 \tag{2}
\]

Under stationary entrance, writing J_A for crossing flux,

\[
 E_{\rm entrance}\tau_{A^c}=\frac{\pi(A)}{J_A},\qquad
 E_{\rm entrance}\tau_A=\frac{\pi(A^c)}{J_A}.
 \tag{3}
\]

The source already proves why whole-clock waiting changes both means and why flux matching does not determine the entire survival curve. No new persistence advantage follows from quoting (2) or making a chain lazy.

The revised attachment further asks for stability of an informative, action-specific response vector, not merely an integer group label. The response can be a finite catalog of conditional probabilities of future labeled words under the retained policy. The event, response norm or exact equality, preparation, and clock must therefore travel with any application of (2).

## 3. Applying the sweep to the learned matched family

Let W be the full law/model/link state in the existing learned family. Let p(W) be its entire labeled agreement-probability catalog, and write its fixed conditional geometry as Psi(dW|p). Let K(dh|W) be the normalized auxiliary membership, root, and tree channel. The augmented family is

\[
 Q_\rho(dW,dh)=\rho(dp)\Psi(dW\mid p)K(dh\mid W),\qquad
 \Pi_\theta(dW,dh)=\nu_\theta^*(dp)\Psi(dW\mid p)K(dh\mid W).
 \tag{4}
\]

Assume the needed domination and finite KL for subtraction statements. The full retained parent Z=C(W,h) determines p, as required by the separately labeled record experiment. Use the source mechanism in its natural fixed-W form: M changes h through a finite K(.|W)-reversible proposal, while holding W fixed; D resamples the target conditional of (W,h) at fixed complete Z.

There is a direct obstruction to interpreting this sweep as the existing E/M learning. First, every Q_rho already has conditional K(.|W), so Q_rho M=Q_rho. Second,

\[
 \frac{dQ_\rho}{d\Pi_\theta}(W,h)
 =\frac{d\rho}{d\nu_\theta^*}(p(W))
 \tag{5}
\]

is Z-measurable. The conditional fine laws of Q_rho and Pi_theta given Z are therefore equal. Refreshing that conditional also leaves Q_rho unchanged:

\[
 Q_\rho D=Q_\rho,\qquad Q_\rho T=Q_\rho
 \quad\hbox{for every admitted }\rho.
 \tag{6}
\]

The posterior conditional defining D is independent of theta in this matched family, since the theta-dependent factor in (5) is already retained. Both stages preserve p pointwise. Thus the chain can change auxiliary membership and hidden geometry while leaving every labeled response depending on p, the whole p law, and the VFE of Q_rho exactly unchanged.

Equation (6) does not contradict the source's strict-descent theorem. Here p separates closed components, and Q_rho is already target-matched inside each component, with its original component weights conserved. In the earlier finite experiment the actual incidence projection and observable fibers determine different components; its strict-descent result is not invalidated.

Nor does (6) refute all possible parent-sensitive kinetics. It applies to this specific source-based extension: M holds W fixed and the complete parent retains all p. A move that changes p, a different retained interface, or an additional algorithm state is a different explicit mechanism. The fixed-W sweep alone supplies no evolution of the recognition or learned-prior parameters in the native E/M equations.

## 4. Exact finite witness of the mismatch

A small positive model makes the obstruction checkable without using the historical component. Let retained r take values 1/4 and 3/4. Let w and h be binary. Given r, let w be uniform and use

\[
 K(h=1\mid r,w)=
 \begin{cases}
  1/4,&r=1/4,\ w=0,\\
  3/4,&r=1/4,\ w=1,\\
  1/5,&r=3/4,\ w=0,\\
  2/5,&r=3/4,\ w=1.
 \end{cases}
 \tag{7}
\]

Choose prior masses (3/5,2/5) on r and one external Bernoulli record with success probability r. At observed success, evidence is 9/20 and posterior masses on r are (1/3,2/3). The augmented target includes the same w conditional and K. These are eight states with a normalized unchanged external record.

Take M to flip h at fixed (r,w), using symmetric proposal mass 1/2 and the target Metropolis acceptance. Let C retain (r,h), and D refresh w conditional on those variables. This is a separate one-neighbor specialization of (1), not the old seven-neighbor proposal or the old 432-row dataset.

In parent order (1/4,0),(1/4,1),(3/4,0),(3/4,1), exact multiplication gives

\[
 L=
 \begin{pmatrix}
  3/4&1/4&0&0\\
  1/4&3/4&0&0\\
  0&0&11/14&3/14\\
  0&0&1/2&1/2
 \end{pmatrix}.
 \tag{8}
\]

Its target parent masses are (1/6,1/6,7/15,1/5). A matched recognition with different r masses (3/4,1/4) has parent masses (3/8,3/8,7/40,3/40) and is also stationary. Its next external success probability is 3/8, whereas the target predicts 7/12. The difference 5/24 is not reduced by a single sweep or any number of sweeps.

The operator is nontrivial: from (r=1/4,w=0,h=0), a full sweep reaches (1/4,1,1) with probability 1/8. Conditional resampling changes actual states; stationarity of the whole matched family is not an identity-kernel artifact.

For the target and event h=1, stationary entrance flux is 17/120 and occupancy is 11/30. The exact entrance survival law and mean are

\[
 s_n=\frac5{17}(3/4)^n+\frac{12}{17}(1/2)^n,\qquad
 E_{\rm entrance}\tau=44/17.
 \tag{9}
\]

Starting instead from the target conditioned on h=1 gives mean 32/11. Both are finite persistence measurements under their named preparations. Neither proves useful learned membership, and neither is a claim that the source has no finite persistence construction.

## 5. A fixed Markov kernel cannot represent all Fisher preparations

The previous obstruction concerns the specific sweep. There is a more general reason that a native recognition-law equation must not automatically be called a microscopic Markov process.

For a fixed strictly positive target pi, the full Fisher gradient flow of KL(q||pi) on a finite simplex has the solution

\[
 \Phi_t(q)_i=
 \frac{q_i^{a}\pi_i^{1-a}}
      {\sum_jq_j^{a}\pi_j^{1-a}},\qquad a=e^{-t}.
 \tag{10}
\]

Substitution into the centered logarithmic replicator equation proves the formula. For a fixed Markov kernel T_t independent of initial recognition, q maps to q T_t affinely. The map (10) is generally not affine.

At uniform binary pi and t=log 2, take q_1=(1/5,4/5), q_2=(1/17,16/17), and lambda=7/24. Then

\[
 \lambda q_1+(1-\lambda)q_2=(1/10,9/10),\qquad
 \Phi_t(q_1)_1=1/3,\quad \Phi_t(q_2)_1=1/5,
 \quad\Phi_t(\lambda q_1+(1-\lambda)q_2)_1=1/4,
 \tag{11}
\]

while lambda/3+(1-lambda)/5=43/180, differing from 1/4 by 1/90. All preparations are interior. Consequently no single recognition-independent Markov T_t realizes these Fisher solutions for all initial laws, even with the structural model frozen.

This does not exclude a kernel for one chosen preparation, recognition-dependent nonlinear kinetics, a particle ensemble model, or an augmented state carrying the recognition parameters. It also does not rule out a fixed kernel on a particular restricted nonconvex parametric family: the counterexample concerns a common kernel for all the displayed preparations and their mixture. The augmentation proposed below is a constructive route, not a minimality theorem for every beta or Gaussian family. For the admitted beta family that state can include alpha,beta,u and their existing finite ODE. Such state must be counted, and a specific transition or transport of its random samples must still be constructed. Adding an unrecorded recognition-dependent kernel to a fixed generative model would evade the hypothesis rather than solve it.

## 6. Stationary time, lifetime, and RG depth

Let a finite stationary chain have a partition R(i), and suppose every positive transition can only coarsen R. Let k(i) be its number of blocks. Then k(j)<=k(i) on positive transitions. Stationarity yields

\[
 0=E_\pi[k(X_0)-k(X_1)]
   =\sum_{i,j}\pi_iT_{ij}[k(i)-k(j)].
 \tag{12}
\]

Every summand is nonnegative. On positive stationary support, each positive transition therefore preserves k. Coarsening with unchanged block count leaves the partition unchanged. A stationary chain with genuinely changing positive-mass groups must allow splitting or another change incompatible with this monotonicity.

The claim is about nesting along one stationary inference-time chain. It does not forbid nested levels inside a state, transient formation, finite-lived metastable blocks, or a finite depth tower ending at its root. In a local merge/split process, stationary merge and split fluxes balance. A history recording past mergers can preserve lineage even when current membership changes, but that history is additional state.

The prior cumulative auxiliary-panel construction is indexed by RG stages and is allowed to absorb into a root. Its absorption result is therefore not a failure of the desired finite two-level structure. The unresolved question is whether its intermediate blocks are useful and response-stable under a declared inference-time dynamics, and whether their complete representation is admitted before the next level.

## 7. What is specified, and the next constructive admission

The source supplies static scale channels and a declared parent-sensitive kinetic mechanism. It supplies finite persistence measures with explicit controls. It does not specify a unique post-merge statistical model, saving term, complexity preference, or useful stopping objective. In PIFB2 the detector-retention theorem assumes a calibrated positive saving bound; its algebra does not derive that bound. The revised finite experiment independently retains its external accuracy/resource gate and the completed identity-only admissions.

For the already admitted labeled learning family, there is nevertheless a concrete mathematical continuation that does not invent a new loss or repeat the old benchmark. Construct one normalized kinetic realization on an augmented state containing its native (alpha,beta,u), retained probabilities, membership seed/history, and necessary geometric memory. It must actually move p according to the native evolving family, preserve the same separately labeled external record experiment, and supply a complete parent path law or an explicit obstruction. A fixed-W membership sweep is insufficient by (6), and a universal initial-law-independent kernel is insufficient by (11).

The next question is then informative finite-time response persistence in that declared realization, measured with the response vector and the same update clock. Keep equilibrium membership, sampled group labels, stable response, and nested depth as separate assertions. Count any continuous seed, recognition state, conditional geometric sampler, and inherited interface; do not claim a resource benefit from concealing them.

This source reconciliation does not select a post-merge cost functional or authorize new data collection. It advances the existing construction by identifying the exact kinetic seam. The full goal remains incomplete, with its original scope and negative results preserved.


## Execution and scope

[source_path_exact.py](evidence/source-path-admission/source_path_exact.py) passed once under pinned CPython 3.14.7 with -I -B in 0.002203600000939332 seconds. Its [saved result](evidence/source-path-admission/result.json) contains every entry of M,D,T,C,J,L, the two invariant full laws, the 9/20 evidence, the unchanged 5/24 response gap, the nontrivial 1/8 transition, seven exact survival probabilities, both preparation-dependent means, and the 1/90 Fisher-affinity discrepancy.

This is one new eight-state calculation and a positive binary preparation counterexample. It does not rerun the old parent-sensitive component, estimate a lifetime from truncated simulations, or certify the general claims by enumeration. The general stationary-fiber, nonaffinity, and monotone-stationarity conclusions are proved above. No independent agent or formal ledger certificate was invoked. The prior evidence, all fifteen heterogeneous admissions, saved data, production/configuration, canonical WIP, and Research sources are preserved; no Lean, tamper checks, broad suite, GPU work, empirical collection, base transport, or publication occurred.
