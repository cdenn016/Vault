# Conditional-matching dynamics and the local reduction boundary

September 11, 2026. This continues [agreement-sufficient-marked-parents.md](agreement-sufficient-marked-parents.md) at fixed c_*, on source HEAD ed8f22a56df353b1535744509cc23fae46d5813c. The previous goal turn was progress: it supplied a sufficient record statistic and a geometric trajectory counterexample. The present question is which actual coupled update can descend through a useful parent, and what has to change when its posterior conditionals move.

Three conclusions are obtained. In the freely learned Gaussian residual model, the family-wide sufficient-statistic test extends beyond linear maps and generically forbids any nontrivial proper local retention with the exterior fixed. A constrained conditional-matching flow is nevertheless explicit: pulling back the existing joint metric adds the hidden conditional Fisher information to the structural metric. That flow has a closed parent equation and an additive metric rule for nested constraints. Finally, the source's stochastic conditional-refresh construction closes complete record histories only with the appropriate emission-conditioned lift; a small exact example shows the extra state required when records distinguish hidden fibers.

The constrained and refreshed dynamics are declared alternatives. Neither is identified with the previously specified unconstrained Gaussian E/M flow. Their conditional closure does not supply endogenous alignment or a learned hierarchy. The original fifteen heterogeneous admissions and their negative conclusion remain unchanged.

## 1. The actual model and the fixed update being compared

Use [pointwise-gaussian-link-learning.md](pointwise-gaussian-link-learning.md), Sections 1-2, for the normalized two-channel Gaussian residual model and its metric derivation. At one base point, x stacks belief and model sample coordinates in their associated fibers. Q is the correlated recognition law over all these coordinates. Structural theta contains the independent represented link matrices in the admitted identifiable chart. This is structural link learning; the preceding agreement model instead treated law points and links as latent random variables. Results are not transferred between these two models by renaming their symbols.

The source model is p_theta(o,x)=N(x;0,J_0(theta)^{-1})N(o;Hx,S), with fixed H, S positive definite, and J_0=A+sum_e R_e(theta)^T W_e R_e(theta) positive definite. Each variable edge has residual x_i-Theta_e x_j and receiving weight W_e positive definite. Fixed cross-channel residuals may be included. The complete-joint model Fisher metric is M_ab=(1/2)tr(C_0 J_a C_0 J_b), with C_0=J_0^{-1} and J_a=partial_a J_0. It is inverted only on an identifiable chart. For Q=N(mu,C), the actual continuous update is

\[
 \dot J=K(\theta)-J,\qquad \dot h_q=h-h_q,\qquad
 \dot\theta=-M^{-1}g,\qquad
 g_a=\tfrac12\operatorname{tr}[(C+\mu\mu^\top-C_0)J_a].
 \tag{1}
\]

Here J=C^{-1}, h_q=J mu, K=J_0+H^T S^{-1}H, and h=H^T S^{-1}o. Its metric is the product of the recognition Fisher metric and M. The prior normalization and its C_0 subtraction remain present. The [ELBO chapter](../../../Theory/05_elbo.tex), its exact-coordinate and accepted-proposal discussion, separately requires actual acceptance for finite parameter proposals. Equation (1) is the continuous model analyzed here, not every accepted numerical optimizer.

## 2. Nonlinear sufficiency does not remove the generic local obstruction

Consider one connected channel graph, nonzero endpoint vectors, and independently variable full GL(K) edge matrices on open charts. No other residual shares the variation of the edge being tested. Fix the exterior and all observation information required by the proposed parent. The admission in this section is family-wide common conditional recovery: likelihood ratios between every admitted theta and a reference theta_0 must be constant on each retained fiber. For positive regular densities this is the likelihood-ratio form of a parameter-independent conditional recovery kernel. We use its pointwise regular-fiber version; it is stronger than closure along one particular learning trajectory.

For e=(i,j), introduce the matrices

\[
 S_j=x_jx_j^\top,\qquad C_{ij}=x_ix_j^\top.
 \tag{2}
\]

The varying part of its residual action is

\[
 -2\operatorname{tr}(W_e\Theta_e C_{ij}^{\top})
       +\operatorname{tr}(W_e\Theta_e S_j\Theta_e^\top).
 \tag{3}
\]

The x_i^T W_e x_i term, all fixed residuals, and the observation likelihood cancel in a theta/theta_0 ratio. Its determinant term depends only on theta. Consequently the collection of matrices (2), over all independently varied edges and channels, is a sufficient statistic for this structural family at every fixed observation.

Conversely, suppose two fine configurations give the same complete family of likelihood ratios. Vary one Theta_e while holding all other parameters fixed. Equality of (3) up to its reference constant is a polynomial identity on an open set of matrices, so its quadratic and linear coefficients agree. To see the quadratic conclusion, evaluate the polynomial extension on Theta=t u v^T: its t-squared coefficient is (u^T W_e u)v^T Delta S_j v. Since W_e is positive definite, Delta S_j=0. The remaining linear coefficient and invertibility of W_e give Delta C_ij=0. Rank-one matrices are used to evaluate the polynomial identity, not admitted as invertible physical links. Thus (2) is also necessary for the stated regular-fiber admission.

If x_j is nonzero, equality x_j'x_j'^T=x_jx_j^T gives x_j'=epsilon_e x_j with epsilon_e in {+1,-1}. Equality of C_ij then gives x_i'=epsilon_e x_i. Every nonzero shared endpoint makes these signs agree along a connected graph. Therefore the generic equivalence class is exactly

\[
 x' = x\quad\hbox{or}\quad x'=-x
 \quad\text{on each independently varied connected channel component}.
 \tag{4}
\]

With independently varied belief and model link charts, apply the argument in each channel. Fixed cross-channel couplings can correlate the conditional signs but do not enter the varied likelihood ratio. Equation (4) is a statistical equivalence, not an assertion that each separate sign is a gauge symmetry of the fixed observation or joint law. If one shared group parameter constrains both represented channels, the independent-variation premise must be checked; this proof does not manufacture that freedom for arbitrary representations.

For a proper local block in a connected graph, retain a nonzero exterior configuration. The exterior cannot flip, so its component sign in (4) is +1 and the entire local configuration is fixed. Every such local retention is therefore injective on the generic nonzero domain. Exceptional zero-vector strata need separate treatment; they have zero measure under the positive Gaussian laws but are not assigned this pointwise conclusion.

This also constrains smooth geometric representation. On a neighborhood excluding its sign-reflected copy, the sufficient statistic separates every point. A C1 retention into fewer real coordinates cannot be locally injective throughout an open domain: at a point of maximal rank, its nearby constant-rank fibers have positive dimension. Thus the sign quotient retains the same local continuous dimension. A Borel encoding into a single real number would require a different representation and computational contract; coordinate-count savings do not follow from such an encoding.

There is a real native positive statement at the global level. Let T be (2). The ratio factorization supplies a theta-independent conditional Psi_o(dx|T). On Q(dx)=r(dT)Psi_o(dx|T), the full E-vector depends only on T and the M-score is retained. The full-law Fisher E-flow and the model natural M-flow preserve this family and its coarse VFE and complete-joint Fisher metric exactly. For the Gaussian update (1), use the intersection with the Gaussian family: it contains every posterior and remains invariant because both the ambient Gaussian closure and the common-conditional closure hold. This is the nonlinear counterpart of the earlier linear common-kernel theorem. It removes the conditional sign ambiguity, not the continuous local degrees of freedom needed for useful proper child-block formation. Retaining structural link values, holonomy, interfaces, and memory can only add resources.

These are family-wide sufficiency results. They do not rule out a constrained invariant trajectory, a different interaction family, approximate prediction, an externally restricted preparation class, or a memory model with a different access contract. In particular they are not a universal impossibility theorem for the user's coalescence mechanism.

## 3. Exact conditional matching as a declared constraint

Take any fixed parent map y=f(x), independent of theta, and the actual posterior disintegration

\[
 \pi_\theta(dx\mid o)=\pi_\theta^y(dy\mid o)\Psi_\theta(dx\mid o,y).
 \tag{5}
\]

Assume a common regular support, differentiability in an identifiable parameter chart, normalized conditional versions, and square-integrable conditional scores. In the Gaussian application with a fixed linear map and SPD precisions these conditions hold locally. Declare the conditional-matching family

\[
 Q_{r,\theta}(dx)=r(dy)\Psi_\theta(dx\mid o,y).
 \tag{6}
\]

This family contains the exact posterior at every theta. Its objective is exactly

\[
 \mathcal F(Q_{r,\theta},\theta)
       =D(r\Vert\pi_\theta^y)-\log e_\theta(o)
       =:\mathcal F_y(r,\theta).
 \tag{7}
\]

No conditional penalty coefficient is added. Equation (6) is a constraint on the recognition family. When Psi_theta moves, the unconstrained update (1) generally leaves it; conditional matching is not assumed to be dynamically attractive.

Let s_a(x|o,y)=partial_a log Psi_theta and define its conditional information

\[
 I_{ab}(y,\theta)=E_{\Psi_\theta(\cdot\mid o,y)}[s_as_b],\qquad
 \mathcal I_{ab}(r,\theta)=\int I_{ab}(y,\theta)r(dy).
 \tag{8}
\]

A tangent of (6) has log-density variation delta log r(y)+s_a delta theta^a. The conditional mean of every s_a is zero. Squaring and integrating therefore yields the pullback of the original product metric:

\[
 G_{\rm constrained}=G_{\rm Fisher}(r)
                   \oplus [M(\theta)+\mathcal I(r,\theta)].
 \tag{9}
\]

The cross block vanishes by conditional centering. The additional matrix is positive semidefinite; the original positive M makes the sum invertible. It measures how much the full recognition must move to keep matching the changing hidden conditional. It is not an adjustable learning-rate coefficient.

Let g_y=partial_theta F_y at fixed r. On the matching family, g_y equals the original partial_theta F at fixed Q, evaluated at that Q: the extra derivative through Psi_theta integrates a conditional score against log(r/pi_theta^y), which is constant on the fiber and hence gives zero. The natural gradient of (7) in (9) is

\[
 \partial_t\log r=-\left[\log\frac r{\pi_\theta^y}
                  -E_r\log\frac r{\pi_\theta^y}\right],\qquad
 \dot\theta=-(M+\mathcal I)^{-1}g_y.
 \tag{10}
\]

Its exact dissipation identity is

\[
 \dot{\mathcal F}_y=-\operatorname{Var}_r\left(\log\frac r{\pi_\theta^y}\right)
                  -g_y^\top(M+\mathcal I)^{-1}g_y\le0.
 \tag{11}
\]

These equations define the orthogonal projection of the original full gradient onto the tangent space of (6). To check this directly, the original E-vector on the matching family has only a y-score, while the original structural vector has M times its value equal to -g_y. Testing its projection against a constrained theta tangent adds exactly the conditional score norm in (8), giving (10).

The lifted recognition velocity contains the extra term s_a dot theta^a. That term is absent from the unconstrained hidden E-vector at a matched point. Thus (10) defines a different coupled trajectory whenever the target conditional moves. If Psi is theta-independent, I=0 and the earlier native conditional-recovery regime is recovered. A rule that first uses -M^{-1}g_y and then resets the conditional is another possible normalized update; it is not the orthogonal projection in (9).

A finite implementation must accept a trial using the actual restricted objective (7) and its lifted Q. Changing theta while simultaneously changing Psi is a joint constrained move, not the ordinary M-coordinate holding Q fixed. The continuous identity (11) does not certify an arbitrary finite step. Smooth local existence holds on the stated regular chart; boundary escape and global convergence remain separate.

## 4. Gaussian conditional metric and a fully specified rate comparison

For a linear parent y=Fx and a fixed complement u, write the actual posterior conditional as N(b+B y,Gamma^{-1}), where Gamma=K_uu, b=Gamma^{-1}h_u, and B=-Gamma^{-1}K_uy. Derivatives below hold y fixed. Gaussian score integration gives

\[
 I_{ab}(y)=\tfrac12\operatorname{tr}(\Gamma^{-1}\Gamma_a\Gamma^{-1}\Gamma_b)
       +(b_a+B_a y)^\top\Gamma(b_b+B_b y).
 \tag{12}
\]

The quadratic centered score and linear centered score have zero covariance because odd Gaussian moments vanish. Their variances give the two terms. For r=N(mu_y,V), its average is

\[
 \mathcal I_{ab}=\tfrac12\operatorname{tr}(\Gamma^{-1}\Gamma_a\Gamma^{-1}\Gamma_b)
 +(b_a+B_a\mu_y)^\top\Gamma(b_b+B_b\mu_y)
 +\operatorname{tr}(\Gamma B_a V B_b^\top).
 \tag{13}
\]

Equations (10), (12), and (13) are closed finite equations in the parent Gaussian parameters and theta. Their E-part is dot J_y=K_y-J_y and dot h_y=h_{p,y}-h_y. Gamma,b,B and their derivatives are obtained from the actual model, not evolved as an independent hidden-recognition memory. Computing them can still require full-sized inverses and linear solves.

Use the already defined two-node model x_1~N(0,1), x_2|x_1~N(theta x_1,1), o|x_2~N(x_2,1), at o=0, theta=1/2, and initial recognition equal to the posterior. Retain y=x_2. The source calculation gives M=1, g_y=2/9, V=5/9, hidden variance C_u=4/5, regression B=2/5, and derivatives C_u'=-16/25, B'=12/25. Therefore

\[
 I(y)=\frac{36}{125}y^2+\frac8{25},\qquad
 \mathcal I=\frac{12}{25},\qquad M+\mathcal I=\frac{37}{25}.
 \tag{14}
\]

The two structural velocities and the constrained dissipation at that same state are

\[
 \dot\theta_{\rm original}=-\frac29,\qquad
 \dot\theta_{\rm constrained}=-\frac{50}{333},\qquad
 \dot{\mathcal F}_{\rm constrained}=-\frac{100}{2997}.
 \tag{15}
\]

The rate ratio 25/37 follows from the induced metric. It is a local comparison for this constrained mechanism, not evidence for an emergent universal parent clock. At the initial state the parent E-vector is zero, but the lifted fine conditional already moves with theta; the original fine E-vector is zero everywhere at that instant. This makes their inequivalence explicit.

A separate exact reconstruction computes the conditional score directly. With epsilon=u-(2/5)y, y and epsilon are independent centered Gaussians of variances 5/9 and 4/5. The score is (3/5)y epsilon-(1/2)epsilon^2+2/5. Its mean is zero and its variance is 12/25, verifying (14) without using the matrix metric formula.

For a two-channel four-child example, each child has one belief and one model sample coordinate, so n=8. Fixed first-level roots from the proper blocks {1,2} and {3,4} retain both channels and give y dimension four. A grandparent root retaining both channels gives z dimension two. The evolving Gaussian recognition counts are then 44, 14, and 5 respectively. The original structural parameters theta remain at every level, as do all observation data, geometric/interface marks required by the chosen experiment, and the model's conditional evaluators. These are reductions of free recognition parameters on the declared matching families. They are not reductions of every fine structural variable, measured runtime savings, or learned choices of the two blocks. A full-cost admission must include the matrices needed for (13) and for the original M.

## 5. Nested constraints carry an additive information metric

Let x map to y and then z by fixed compatible deterministic maps, and suppose the actual posterior disintegrations and scores obey

\[
 \Psi_\theta(dx\mid o,z)
  =\Psi_\theta(dx\mid o,y)\Psi_\theta(dy\mid o,z)
 \tag{16}
\]

as conditional measures. For deterministic nested maps this is the conditional factorization, with the intermediate y integrated in the right-hand side. Scores add, and their cross expectation vanishes after conditioning on y. On Q=r_z(dz)Psi_theta(dx|o,z), the total conditional information is therefore

\[
 \mathcal I_{x\mid z}(r_z)=
 E_{r_z\Psi_\theta(y\mid o,z)} I_{x\mid y}(y)
       +E_{r_z} I_{y\mid z}(z).
 \tag{17}
\]

Pulling back the original metric directly to (r_z,theta) or first to (r_y,theta) and then to (r_z,theta) gives the same matrix M+I_x|z. The objective likewise reduces directly or in stages to F_z. Hence imposing all of these nested constraints gives the same final gradient whether the metric is computed directly or in stages. This supplies compatible evolution of every level obtained by lifting the deepest law through the actual posterior conditionals.

An intermediate level evolved using only its own constraint generally leaves the deeper matching family when theta moves. Its unconstrained-in-z E-vector cannot track the changing y|z conditional. Thus successive finite evolutions and projections are not claimed to commute. Exact compatibility here requires the jointly constrained hierarchy, with the inherited metric and downward conditional dependence retained. Replacing the intermediate metric by a new coarse-only model Fisher metric, or dropping its first hidden-information contribution, changes the flow.

The structural metric M is the original complete-joint model metric. The Fisher metric of a newly marginalized generative model can be smaller by its own conditional score information. That separate generative information loss must be retained if the original structural geometry is to be reproduced. It cannot be identified with the recognition-weighted term (8), which conditions on the fixed observed o and averages under the current r.

A scalar Gaussian chain checks (17) explicitly. Let y|z~N(2theta z,3), u|y~N(theta y,2), and r_z=N(0,5), at theta=1/2. Then E y^2=8, the u|y contribution is 4, and the y|z contribution is 20/3, giving

\[
 \mathcal I_{(u,y)\mid z}=\frac{32}{3}.
 \tag{18}
\]

The direct conditional covariance of (u,y)|z is [[11/4,3/2],[3/2,3]], its derivative is [[3,3],[3,0]], and its mean derivative is (2z,2z). Substitution into the full two-dimensional Gaussian score formula gives the same 32/3. This calculation checks the inherited metric contribution; it is not a new dataset or a simulation of formation.

## 6. What conditional refresh proves for complete record histories

The source's [prepared-parent theorem](../../../Theory/07e_inference_memory.tex) uses a target conditional lift J, projection C, posterior-preserving fine proposal M, and T=MCJ. It proves Markov closure of parent histories from a J-prepared start. The proposal, the refresh, and their order are declared mechanism choices. A deterministic learning flow such as (1) is not converted into this stochastic kernel by citing stationarity. J is a target conditional used by an auxiliary inference algorithm at fixed observed o, not a current recognition law inserted into the original generative mechanism. Its transition index is not physical time.

Complete emitted-record histories require their own conditional lift. In a finite notation, let z=f(w), let J_z(w) be the target conditional, and let eta_w(e) be the normalized record row emitted after the final refresh. Define

\[
 \bar\eta_z(e)=\sum_wJ_z(w)\eta_w(e),\qquad
 J_{z,e}(w)=\frac{J_z(w)\eta_w(e)}{\bar\eta_z(e)}.
 \tag{19}
\]

Use only positive-probability (z,e), with normalized versions on null events. Under the fine update M followed by J refresh and then emission, the complete parent (z,e) is Markov from the corresponding prepared law, with joint row

\[
 \bar K((z,e),(z',e'))=
       [J_{z,e}MC](z')\bar\eta_{z'}(e').
 \tag{20}
\]

The proof follows the actual order. Given the retained history ending at (z,e), the last refresh and last emission leave conditional fine law J_z,e, independently of earlier history. Apply M, project its destination to z', refresh within z', and emit e'. Summing the intermediate fine states gives (20). This argument also permits controls chosen from the retained record/state history; a controller reading discarded w changes the conditioning problem. An observer given only records must filter z, not receive its hidden realized value.

If eta_w(e) already factors through z, then J_z,e=J_z and no additional last-record dependence enters the state transition. The agreement-sufficient parent retains every p_e, so its declared agreement records satisfy exactly this condition. A parent retaining only a geometric mark or component partition may not. Applying (20) to the agreement evaluator still defines the refreshed path model; emission descent alone does not preserve an earlier unrefreshed or fixed-latent path law.

For an exact example, take four fine states (z,u) with z,u in {0,1}, uniform target and J uniform in u. A symmetric lazy M switches z with probability 1/4 at u=0 and 1/8 at u=1, retaining u during the proposal. Refresh u uniformly after that proposal, then emit e=u correctly with probability 3/4. The parent z by itself has transition probability 3/16 to the other z when records are ignored. After the current record is included,

\[
 P(z_{t+1}\ne z_t\mid z_t,e_t=0)=\frac7{32},\qquad
 P(z_{t+1}\ne z_t\mid z_t,e_t=1)=\frac5{32}.
 \tag{21}
\]

Thus using the row 3/16 together with a conditionally independent emission would lose the joint history experiment. Retaining the last observed record in (20) repairs this declared refresh model exactly. A record-only observer uses one probability for z and the known last symbol, while the unconstrained fine filter would use three probabilities for w. Its reachable fine conditional family is J_z,e, so this filter saving has an explicit preparation and update assumption. It does not establish that the original unrefreshed process has the same paths. In this example, the stationary probability of two consecutive equal records changes from 5/8 under M to 1/2 under MCJ, because M preserves u while the refresh redraws it. That change is checked exactly.

Nested refreshes also have a precise composition boundary. For C_1:x->y and C_2:y->z with target conditionals J_1,J_2, define C_12=C_1C_2 and J_12=J_2J_1. Since J_1C_1=I,

\[
 (C_1J_1)(C_{12}J_{12})=C_{12}J_{12},\qquad
 L_2=J_2(J_1MC_1)C_2=J_{12}MC_{12}.
 \tag{22}
\]

This is one original proposal followed by the declared nested refreshes, with compatible preparation and record access. Running another proposal between levels changes the transition count. Record-dependent lifts must be carried when (19) requires them. The conditional integrations in J may be expensive; these identities alone provide no resource advantage for an arbitrary GL marked law.

## 7. What this resolves and what still needs a formation mechanism

The current constructions support the following distinct conclusions.

| Update or admission | Exact result here | Remaining formation requirement |
| --- | --- | --- |
| Original Gaussian E/M flow with independent full-matrix edge variations | Generic family-wide sufficient statistics determine the fine connected-channel configuration up to a global sign; proper local blocks with fixed exterior are injective. A matched global sign quotient is an exact native path. | Useful local formation requires a more restricted invariant regime, an approximation contract, or a different admitted interaction/update family. |
| Projected conditional-matching flow, same normalized Gaussian model | Closed joint parent/structural evolution, induced metric M+I, exact dissipation, and direct/staged metric agreement for a jointly constrained hierarchy. | The matching constraint and fixed block maps have been declared. Their endogenous selection, attraction, and complete resource advantage are not established. |
| Proposal plus posterior-conditional refresh | Exact prepared Markov parent and complete record-history lift, with a priced finite filter example. | The refresh changes trajectories. A useful GL implementation needs an evaluable conditional lift and an information-persistence result for its actual proposal. |

The original attachment's statistical spatial-selection phase is still unadmitted without a justified prediction/resource criterion for its unchanged heterogeneous experiment. The user's lack of a numerical tolerance is retained, not repeatedly queried or converted into a coefficient. The broader pointwise theory is not blocked by that benchmark-specific choice, but its independently dynamic links and coalescence mechanism cannot be replaced by a fixed chosen partition and called discovered formation.

The completed negative results, exact static laws, conditional dynamics, and two-level examples answer different gates. None implies every gate of the full objective is complete. Before any new family is added, the existing RG progress record must retain this distinction and identify the actual mechanism being advanced. No base transport, new observations, production optimizer, or vault edit is introduced here.

## 8. Direct calculation and evidence

[conditional_matching_exact.py](evidence/conditional-matching/conditional_matching_exact.py) checks the nonlinear-statistic fibers on a small two-node amplitude grid, the conditional-score calculation and projected rate in (14)-(15), direct versus staged Gaussian conditional information in (18), and all rows of the finite emission-conditioned lift (19)-(21). These are exact rational calculations under pinned CPython 3.14.7, saved in [conditional-matching-exact-result.json](evidence/conditional-matching/conditional-matching-exact-result.json). They do not rerun the earlier heterogeneous admissions or simulate either learning dynamics.

The general polynomial-identification, score-pullback, dissipation, and conditional-history arguments are written above. Their quantified claims rely on those derivations and stated assumptions, not on agreement among reviewers or finite enumeration. No formal ledger certificate is issued. The next unresolved constructive obligation is an endogenous alignment/membership mechanism compatible with one of the explicitly identified dynamics and a complete useful parent cost; the present constrained or refreshed alternatives must retain their changed-dynamics label until that obligation is actually met.
