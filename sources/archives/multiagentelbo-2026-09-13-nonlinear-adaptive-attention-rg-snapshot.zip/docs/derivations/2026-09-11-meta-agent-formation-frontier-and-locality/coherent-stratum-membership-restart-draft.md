# Coherent-stratum membership and complete-parent cost: unfinished derivation

Saved before the user's requested computer restart on September 11, 2026. **IN PROGRESS / UNVERIFIED.** This is a working construction and a record of proposed proofs, not an accepted result. No new scientific script, simulation, or evidence receipt has been produced for this construction. The latest completed calculation remains `conditional-matching-dynamics-and-local-obstruction.md` and its existing evidence directory.

## Purpose and admission boundary

Investigate whether a proper latent partition prior on coherent strata can learn membership from the same labeled binary agreement records, then admit an exact complete parent with an explicit resource count. This changes the prior: exact coherence receives positive prior mass. It does not show that the old absolutely continuous prior reaches a measure-zero coherent set in finite inference time, repair the old heterogeneous benchmark, or establish the native Gaussian E/M trajectory. It must not be described that way.

The live source consulted is `Theory/07c_full_graph_meta_agent_vfe.tex`, especially the normalized joint and structural-channel requirements near lines 18-207 and the membership discussion near lines 355-376. Its random state can include R, but every prior and recognition law must belong to one normalized joint before coarse-graining. A coarse representation alone does not supply a membership mechanism. The source permits such a declaration; it does not choose a unique partition prior.

Let R range over connected partitions of a finite graph, with a proper prior pi_R positive on every admitted R. For the four-vertex complete-graph witness, use all fifteen partitions with equal weight; do not favor the intended pairing. Cross-dimensional strata use the mixture probability measure as the dominating measure, not a Lebesgue density silently shared across dimensions. Include partition prior costs and all normalization constants.

A general prospective construction draws one root belief/model law pair per block, proper child frames g_i, and internal h_e in the common stabilizer of both laws. Set b_i = rho_b(g_i)#b_A, m_i = rho_m(g_i)#m_A, and Theta_ij = g_i h_e g_j^{-1}. Cuts use a proper full-group law. This requires a measurable normalized stabilizer kernel; do not claim that requirement for an arbitrary varying root pair without proving it. The explicit Gaussian construction below avoids this gap by using a fixed compact stabilizer.

## Explicit two-channel normalized model

Take G = GL(K). Belief b_i is N(0, Sigma_i) on R^K. The model law m_i is a full normalized joint law on (x,z) in R^{2K}:

    x ~ N(0, c_i Sigma_i),
    z | x ~ N(x, s_i Sigma_i),
    s_i = c_i/(c_i - 1),  c_i > 1.

Its covariance is M(c_i) tensor Sigma_i, where

    M(c) = [[c, c], [c, c^2/(c-1)]],
    det M(c) = c^2/(c-1).

The conditional x|z is N(((c_i-1)/c_i) z, Sigma_i), so b_i is the conditional at the reference argument z=0. This is an evaluator identity. Do not add local z=0 observations to the actual population evidence unless separately modeled. The model representation is diag(Theta,Theta); the belief representation is Theta. Equality of the complete model law implies covariance of the complete conditional evaluator for every z, not merely one marginal.

Draw Sigma_i independently from a proper SPD law. Draw one c_A per block from a proper law bounded away from 1, or fix a common c_0>1 for the simplest fully evaluable witness. For internal edges set

    Theta_ij = Sigma_i^(1/2) O_e Sigma_j^(-1/2),
    O_e ~ Haar O(K).

Both transported divergences are zero. The common stabilizer is conjugate to O(K). Internal holonomies need not be flat. Retain based cotree holonomies, including noncommuting ones when the chosen group permits them; SO(2) alone would not justify a noncommutativity claim.

On each cut draw A_e = B_e^{-1} O_e, with B_e SPD and O_e Haar O(K), from a proper bi-O(K)-invariant full-GL-support law. For example B=exp(S) with an isotropic symmetric-Gaussian S is a possible proper construction. Set Theta_ij = Sigma_i^(1/2) A_e Sigma_j^(-1/2). With Y=B^2, the proposed exact KL formulas are

    D_b = (tr Y - K - log det Y)/2,
    a = tr(M(c_j)^(-1) M(c_i)),
    Delta = log(det M(c_j)/det M(c_i)),
    D_m = (a tr Y - 2K + K Delta - 2 log det Y)/2,
    D_b + D_m = ((1+a) tr Y - 3K + K Delta - 3 log det Y)/2.

Verify orientation and all dimensions against the full 2K covariance. The sum is minimized at Y=3I/(1+a), with value

    (K/2) [3 log((1+a)/3) + Delta].

Writing the two positive eigenvalues of M(c_j)^(-1) M(c_i) as lambda_1,lambda_2, AM-GM applied to (1,lambda_1,lambda_2) should prove nonnegativity and equality only when M(c_i)=M(c_j). For c_i=c_j=c_0, D_m=2D_b. These channels then have coupled energies, which must be explicit, although the model channel is still a genuine complete 2K joint evaluator. Continuous cut laws give D_b+D_m>0 almost surely. Thus components of the zero-joint-divergence graph recover R almost surely.

## Membership from the same labeled records

Conditional on one fixed latent W,R, probe each edge and both channels repeatedly, with success probability exp(-D_b) and exp(-D_m), respectively. Use the same known schedule for every candidate model. Internal records always succeed. Every cut eventually fails in at least one channel almost surely. Because there are finitely many edges and connected blocks, the connected components of edges with no observed failure equal the true R after a finite random time almost surely.

This operational readout initially starts at the whole graph and splits. It is not a nested coalescing lineage and must not be called one. It does provide eventual membership persistence under this declared sequential observation experiment.

After n paired probes per edge, a proposed classifier error bound is

    P(error_n) <= sum_R pi_R sum_(e cut R) E_R exp[-n(D_b,e+D_m,e)].

Dominated convergence sends the bound to zero when cuts have no joint-zero atom. For posterior weights r_R(O_n), condition on O_n and let g be this classifier. Then

    1 - sum_R r_R^2 <= 1-r_g^2 <= 2(1-r_g),
    E[1-r_(true R)] <= 2 P(error_n) -> 0.

This proves joint-prior L1/probability posterior consistency if all preceding conditions hold. For almost-sure posterior consistency and eventual MAP stability, supply a precise bounded-martingale/upward-conditional-expectation argument with an appropriate primary source. Do not silently upgrade this to uniform consistency for every fixed W. The finite-time stabilization of the explicit failure classifier itself has the elementary direct proof above and does not require that upgrade.

Failure observations set some candidate likelihoods exactly to zero. Exact Bayesian conditioning/support restriction is appropriate. An initial recognition law assigning positive mass to a newly impossible stratum can have infinite KL; do not apply a finite positive-support Fisher-flow formula through that support change. Prior atoms supply coherent support; continuous flow from the old atom-free prior does not create it by this argument.

## Prospective exact parent and hidden-frame integration

For each R choose a spanning forest and one root per block with a declared normalized seed rule, common to fine and coarse laws. Let U_i be the tree products of internal O_e. Retain root Sigma_A (and c_A when variable), every based cotree H_e = U_i^{-1} O_e U_j, and every cut mark

    Ahat_e = U_i^{-1} A_e U_j,
    V_e = Sigma_root(I)^(1/2) Ahat_e Sigma_root(J)^(-1/2).

Preserve each original cut copy, observation label, R, and root/forest seed. Do not average multiple cut transporters. Conditional on the tree frames, Haar cotree links remain independent Haar links and bi-O(K)-invariant cut A_e retain their original independent law. This should prove independence from tree frames. Independent nonroot Sigma_i priors then integrate to one after their cancellation from the root-dressed likelihoods. Prove this as a probability pushforward; do not introduce an improper GL Haar prior or reuse fluctuation-volume formulas from a different prior.

Internal record likelihoods are 1 or 0 according to whether an impossible failure was reported. Cut likelihoods are exactly evaluable from the root law pairs and V_e. Hence discarded-frame conditionals are unchanged by all declared agreement records. The induced common structural channel retains R as a measurable coherence readout almost surely and admits the same conditional recovery for prior, actual posterior, and matched recognition. A zero KL defect is prospective under these assumptions. Correlations through R remain in the complete joint; a product of block marginals is not a substitute.

Additional queries about discarded child frames or individual Sigma_i require conditional recovery and its cost. They are outside the fixed agreement-record contract. Gauge changes push proper priors passively; coordinate-dependent proper priors need not be invariant under a noncompact group.

## Resource count requiring confirmation

Let s=K(K+1)/2, h=K(K-1)/2, N vertices, b blocks, e_int internal edges, e_cut cuts, and beta=e_int-N+b. With shared c_0, fine coherent-stratum coordinates total

    N*s + e_int*h + e_cut*K^2.

The complete parent coordinates total

    b*s + beta*h + e_cut*K^2.

The difference is (N-b)K^2. If c_A varies, add b scalar coordinates on both sides. Count the actual parameter sharing in the full model law; do not double-count it as an arbitrary independent 2K covariance.

For four vertices on K4, R={01,23}, K=2, e_int=2, e_cut=4, b=2, beta=0: the fine coherent stratum has 30 real coordinates, the complete parent 22, saving 8. Compare against the optimized 30-coordinate fine coherent model, not the unrelated 36-coordinate generic singletons. Direct parent sampling needs 2 root SPD draws, 0 internal Haar draws, and 4 cut draws, versus 4 SPD, 2 internal Haar, and 4 cut draws for that fine stratum. Straight matrix sandwiches are 8 vs 12. These are proposed operation counts, not measured speedups or total inference-complexity claims.

Prior/posterior uncertainty over R and all observation counts must be charged on both sides. The number of candidate partitions can be exponential. Exact direct sampling after analytical frame integration need not first instantiate every hidden frame, but processing the full partition posterior still costs work.

## Fully evaluable beta slab witness

Fix common c_0>1. On cuts take p=exp(-D_b) ~ Beta(a,beta_par) with positive shape parameters. Choose U uniformly on the Frobenius unit sphere of symmetric matrices and O Haar O(K). Solve for t>=0 in

    phi(exp(t U)) = -log p,
    phi(B) = (tr B^2 - K - log det B^2)/2,
    B=exp(tU), A=B^{-1}O.

The prior partition derivation supplies the ray-monotonicity argument, but verify it here and cite the exact earlier result. Conjugation invariance of U plus independent Haar O should make this a proper bi-O(K)-invariant full-support pushforward law. Do not require an arbitrary Lebesgue density at the identity. Internal p=1 is an atom supplied by the coherent stratum.

Channel success probabilities are p and p^2. For ordered records with counts s_b,f_b,s_m,f_m, set S=s_b+2s_m. The cut likelihood is

    p^S (1-p)^(f_b+f_m) (1+p)^f_m.

The proposed exact evidence is the positive sum

    z_e = sum_(j=0)^f_m binom(f_m,j)
          Beta(a+S+j, beta_par+f_b+f_m) / Beta(a,beta_par).

The binomial coefficient is from expanding (1+p)^f_m, not a combinatorial factor for ordered observations. The posterior is a positive finite beta mixture or an equivalent three-statistic density; evaluation work grows with f_m. Internal-edge evidence is the indicator of no failure in either channel. For each R,

    z_R = product_internal 1{no failure} * product_cut z_e,
    Z = sum_R pi_R z_R,
    posterior(R) = pi_R z_R / Z.

The same per-edge cut posterior may be shared among all candidate partitions cutting that edge. An exact complete posterior sampler first samples R, then its root and cotree prior variables and each retained cut's conditional p/U/O. Marginalizing R correlates the full state. Preserve the absolute cross-record factor in Z even when it cancels in posterior odds.

Proposed tiny exact witness, NOT RUN: enumerate all fifteen K4 partitions with pi_R=1/15 and a=beta_par=1. Edges 01 and 23 have n belief and n model successes, no failures. Every one of the four other edges has at least one failure. Only four refinements of {01,23} survive. Their relative weights are 1,A_n,A_n,A_n^2, with A_n=1/(3n+1). The true-pairing posterior is therefore ((3n+1)/(3n+2))^2: 16/25 at n=1, 49/64 at n=2, 625/676 at n=8. This is algebra for a specified possible record pattern, not a newly collected dataset or a simulated trajectory. For an absolute rational-evidence check at n=2, choose each cut's counts explicitly, for example s_b=1,f_b=1,s_m=2,f_m=0, and retain its nontrivial factor.

One prospective standard-library Fraction script should check: all fifteen partition weights and absolute evidence; the full Gaussian conditional identity; trace and determinant coefficients in the full model KL for rational small matrices; the coordinate counts; and any exact noncommutative cancellation actually needed. Run only after the analytic construction and obligations are written, once, under the existing pinned CPU runtime. Do not rerun old science or generate an empirical dataset. No test suite is needed for the draft.

## Second learned level remains open

Adding a normalized second coarse representation to the same fine joint preserves the original observed evidence; this alone cannot learn a new hierarchy. If an auxiliary R_2 has only a prior conditional on R_1 and does not affect the conditional fine observation law given R_1, then

    P(R_2 | R_1,O) = P(R_2 | R_1).

Prove and retain this boundary. Exact composition of root/holonomy/cut marks is useful but does not make the higher parent learned. A deterministic whole-system grandparent, or a preplanted hierarchy, must not be reported as an emergent second level. The next source-level obligation would be a normalized identifiable higher structural dependence that actually changes the fine joint, with its prior and complete resource costs. This has not been constructed.

The full objective remains incomplete even if every proposed first-level result above is established. Retain the original fifteen negative local admissions, the global stochastic realization open problem, native dynamics limitations, operational tolerance gaps, and the user's deferral of base-space transport.
