# Reconstruction of the coherence and collective-response claims

September 12, 2026. This report reconstructs the mathematics in [response access](coherence-response-access.md), [response bounds](coherence-response-bound.md), and their [synthesis](coherence-and-collective-response.md). The scoped claims follow from the calculations below. The conclusion is a statewise access counterexample and a conditional approximation theorem, not a completed formation or persistence theorem. This is a written analytical reconstruction with inspection of existing exact evidence; it is not a new scientific execution or a formal ledger closure.

## 1. Target, supplied assumptions, and source scope

The source model is the transported Gaussian family in [transported parent priors](transported-parent-priors-and-induced-couplings.md), Sections 2–4. The common carrier and its law-level sufficiency are supplied by [complete parent channels](shared-parent-complete-channel-and-recursive-cost.md), Sections 3–7, with the transported child energy substituted as required by the later construction. [Common-prior hierarchy episodes](common-prior-native-hierarchy-episodes.md), Sections 4 and 8, retains the existing finite composition and fixed-query contracts. None of those inputs is a new claim of this reconstruction.

I read the live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:epistemic_collapse` and the appendix surrounding `eq:rg_closure`, `eq:rg_schur_flow`, and the adiabatic-elimination discussion. The source distinguishes finite coherence from perfect consensus and explicitly leaves derivative closure separate from scalar closure. The [wiki's operational introduction](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires a joint law, evaluator, access, marks, and memory. Those statements identify the prior research boundary; they are not used to prove the results below.

For the exact-access claim, the supplied domain fixes four vertices, the directed cycle 01,12,23,30, ancestry blocks A={0,1} and B={2,3}, roots 0 and 2, internal trees 01 and 23, and two channels x=b,m, each in R² with unit child-law covariance. With positive variances, the primitive vector X in R⁴⁴ contains four child noises, two block noises, four links, and one common ancestor, each in R⁴. Its Gaussian density is positive everywhere. In each channel,

\[
\mu_i=Y+\xi_{R(i)}+g_i+\epsilon_i,
\quad g_0=g_2=0,\quad g_1=\ell_{01},\quad g_3=\ell_{23}.
\]

The complete retained continuous carrier is F₁=(p₈,E₄,z_A,z_B,V₁₂,V₃₀), with its fixed discrete labels, ancestry, roots, trees, and incidence understood. In particular, E_a is the sum of squared primitive epsilon values, equivalently the squared transported child residuals; it is not the earlier untransported energy.

The added diagnostic, expressly introduced by the response reports rather than forced by the user's coherence direction, shifts all means in one block by the same vector and holds links fixed. Write h=u_B-u_A, with signs s₁₂=1 and s₃₀=-1. The exact target is whether functions G_e^x can satisfy

\[
G_e^x(F_1(X),h)=\exp[-\|r_e^x(X)+s_eh^x\|^2/2]
\]

for every X in this domain, every cut and channel, and every h in some open neighborhood of zero. No continuity assumption is imposed on G for the negative result. This universal statewise target is distinct from conditional prediction almost everywhere under a native probability law.

The approximation target fixes any realized connected-tree partition in the same translation family and bounds, for every finite configuration and every collective input, absolute probability error and Euclidean input-gradient error. Its adaptive corollary uses a finite number of fresh Bernoulli queries, a common measurable policy, and a frozen latent draw. Its interaction-potential corollary separately assumes a positive normalizer floor and constant nonnegative coefficients. Those are additional conditional hypotheses, not consequences of small coherence. Recursive statements concern finite depth and retain the necessary labels, marks, masses, and stage statistics.

## 2. Exact residual algebra and the full-carrier counterexample

Suppress the channel superscript. Put R=epsilon₁-epsilon₀, S=epsilon₃-epsilon₂, and t=(R+S)/2. The block contrasts are (-R/2,R/2) and (-S/2,S/2). With

\[
d_{12}=z_B-z_A-V_{12},\qquad d_{30}=z_A-z_B-V_{30},
\]

substitution of the transported means gives

\[
r_{01}=R,\quad r_{23}=S,\quad
r_{12}=d_{12}-t,\quad r_{30}=d_{30}-t,
\quad w:=r_{12}-r_{30}=d_{12}-d_{30}.
\tag{1}
\]

In particular, it is the cut difference that is retained. The cycle sum includes R and S and cannot be used to assert that the cut sum is retained.

The proposed witness has, in each channel,

\[
\begin{aligned}
&(\epsilon_0,\epsilon_1,\epsilon_2,\epsilon_3)
 =((-1,-1),(1,1),(-1,0),(1,0)),\\
&(\xi_A,\xi_B,Y)=((-1,-1),(2,-1),(1,1)),\\
&(\ell_{01},\ell_{12},\ell_{23},\ell_{30})
 =((1,1),(0,-1),(1,-1),(-3,1)).
\end{aligned}
\]

Both block-average epsilon values vanish. Hence z_A=(0,0), z_B=(3,0), V₁₂=(1,0), and V₃₀=(-2,0). Thus d₁₂=(2,0), d₃₀=(-1,0), R=(2,2), S=(2,0), and t=(2,1). Equation (1) gives the residual tuple ((2,2),(0,-1),(2,0),(-3,-1)). Reflecting only the second coordinate of the four epsilon values changes t to (2,-1), so the tuple becomes ((2,-2),(0,1),(2,0),(-3,1)). Every squared residual norm is unchanged.

The epsilon reflection also preserves each epsilon norm and each block average. It therefore preserves E_a and both barycenters. The other primitives are fixed, so E_b,E_c,E_v and all marks are fixed. Summing over both channels gives E=(12,14,30,4). The probability-equivalent squared-norm catalog is (8,8,1,1,4,4,10,10). All its entries are positive, so all eight probabilities are in (0,1). Both channel reflections are independently admissible and yield four distinct response families at one complete carrier value.

For h=(0,s), the two edge-12 responses have squared norms (s-1)² and (s+1)². These differ for every nonzero s. Every neighborhood of zero contains such an input. Thus no G can satisfy the universal statewise target. A randomized decoder also has one output distribution at the common carrier and input, so it cannot equal both distinct Bernoulli distributions under their respective point preparations. This argument uses equality of the full carrier, not only equality of unperturbed probabilities.

Scaling all epsilon values by tau>0 preserves the same reflection equality. The internal squared norms become 8tau² and 4tau² per channel, while the edge-12 residuals are (2-2tau,-tau) and (2-2tau,tau). Their perturbed squared norms differ by 4tau s. Consequently their log probabilities differ by -2tau s and their transverse log-response derivatives differ in magnitude by 2tau. The internal Gaussian KLs are one half the internal squared norms and tend to zero quadratically. For every positive coherence threshold, sufficiently small positive tau satisfies it while retaining unequal exact responses. At tau=0 the reflected states coincide in their response residuals. This limiting argument refutes a strictly positive threshold guaranteeing exact access; it does not refute approximate access.

## 3. Branch access, exceptional directions, and the inspected rank evidence

For w nonzero, let J(w₁,w₂)=(-w₂,w₁) and q_e=-2 log p_e. Writing r₁₂=alpha w+beta Jw and expanding q₃₀=||r₁₂-w||² gives

\[
\alpha=\frac{q_{12}+\|w\|^2-q_{30}}{2\|w\|^2},\qquad
\beta^2=\frac{q_{12}}{\|w\|^2}-\alpha^2.
\tag{2}
\]

The radicand is nonnegative on the actual carrier image. When it is positive, its sign choice is exactly the sign of det(w,r₁₂). A branch bit per channel therefore reconstructs all cuts, then all the stated responses. When the radicand vanishes, there is one residual pair and the bit is unnecessary. The four-state witness proves that any additional finite label valid throughout the nondegenerate two-channel domain must have at least four values. Two bits attain this bound in that domain. This is not a bit lower bound for arbitrary other graphs, dimensions, preparations, or encodings that mix continuous coordinates with labels.

On a fixed nondegenerate branch, (2) is a smooth decoder. Equivalently, DF₁(v)=0 implies dw(v)=0, hence dr₁₂(v)=dr₃₀(v). The retained squared norms imply r₁₂ dot dr₁₂(v)=r₃₀ dot dr₁₂(v)=0. If the two residuals are independent, both differentials vanish. Thus the cut-component rows lie in the row span of DF₁ there. This independently explains why appending the cut residuals cannot increase the local rank, even though a global branch ambiguity exists.

At w=0, choose z_A=z_B=0 and V₁₂=V₃₀=0. This is realized by zero block-average epsilon, xi_A=xi_B=-Y, and ell₁₂=-ell₀₁, ell₃₀=-ell₂₃. Rotate R and S jointly in a channel, keeping their norms and relative angle fixed. All energies, probabilities, barycenters, and marks stay fixed. Both cuts equal -(R+S)/2, which traverses a nontrivial circle if R+S is nonzero. Independent rotations in both channels give two independent angular directions in a fiber of F₁. No finite label covers that continuum. Along these directions the response residual has differential rank two; therefore a smooth augmentation admitting a differentiable decoder needs at least two added real coordinates locally when both radii are nonzero. Angular coordinates suffice locally, but do not supply a global angular chart. Zero-radius channels require no direction. Retaining the four real components of r₁₂ across the two channels is globally smooth and sufficient by (1), giving 28+4=32 displayed retained real coordinates from 44 fine coordinates. Global minimality among all smooth encodings is not established.

I inspected the complete [exact script](evidence/coherence-response-access/response_access_exact.py) and the saved [result](evidence/coherence-response-access/result.json), without executing the script. Its construction uses the correct transported mu, primitive E_a, eight squared residual norms, four energies, and sixteen linear barycenter/mark entries. Its derivative routine differentiates each squared linear form as 2r times its coefficient row. The row elimination and square-minor elimination use exact Fraction arithmetic. At the declared point X_j=((17j+3j²) mod 97-48)/17, the saved result records ranks 28 and 28, a nonzero 28-by-28 minor

\[
\frac{23322776888068669440}{582622237229761},
\]

and cut-pair determinants -3610/289 and 9467/289. The dimensions give the first rank's upper bound; the recorded nonzero minor supplies its mechanical lower bound. The preceding differential calculation supplies the augmented rank's analytic upper bound at those nonzero determinants. Replacing squared norms by exp(-q/2) preserves rank because its derivative is nonzero for every finite q. These are scoped statements about this point and its applicable open neighborhood, not a rank claim at every configuration. I did not independently rerun or recalculate the large minor.

The script hash is `380416989a6363e6c2af9c7401a6627eadce439dae8706bafc35ad76f04c66fc`; the saved result hash is `1bdd74e497dc7ba4276a6ae8a71accd6e5d54318e1f8449b06b1b7ad72fa956a`. Read-only SHA-256 comparisons matched all five source hashes stored in the result, including the live PIFB2 and wiki inputs. The result reports CPython 3.14.7 and the four query outputs (81/100,81/100), (121/100,81/100), (81/100,121/100), and (121/100,121/100). Those values agree with the direct small witness calculation above. The reported prior execution time is 0.06439989999489626 seconds; no execution time for a new science run is asserted.

## 4. Coherence certificates from tree disagreement

For one connected block with n vertices, set delta_i=mu_i-g_i-z and sum_i delta_i=0. Every internal tree residual is its endpoint contrast difference. For positive fixed edge weights, let L=B^T diag(w)B and D=sum_f w_f||r_f||². Connectivity makes ker L the constants: its quadratic form is a sum of positive squared edge differences. Hence the least Rayleigh quotient lambda on the zero-sum unit sphere is positive for n>1. Applying it to both coordinate columns gives

\[
\sum_i\|\delta_i\|^2\le D/\lambda,
\qquad
\|\delta_i\|^2\le(1-1/n)D/\lambda.
\tag{3}
\]

The second step uses delta_i=(e_i-1_n/n)^T delta and ||e_i-1_n/n||²=1-1/n, where 1_n is the all-ones vector. No constant independent of tree size and gap is inferred from an average KL.

Let a_i=e_i-1_n/n and L† be the inverse on the zero-sum subspace, extended by zero. With v=L†a_i, a_i^Tf=v^TLf. Cauchy–Schwarz in the L quadratic form proves

\[
\|\delta_i\|^2\le (a_i^TL^\dagger a_i)D.
\tag{4}
\]

One coordinate proportional to v attains equality when D alone is fixed. For individual retained lengths, expanding delta_i=n⁻¹ sum_j[(mu_i-g_i)-(mu_j-g_j)] along unique tree paths instead gives

\[
\|\delta_i\|\le
\sum_{f\in T}\frac{N_i(f)}n\sqrt{-2\log p_f}.
\tag{5}
\]

Each edge appears on exactly N_i(f) of those paths. Aligning its signed increments in one common direction attains the endpoint bound with the given lengths; a tree has no incompatible cycle constraint. Sharpness here is relative to those length data alone, not every other coordinate of the complete carrier. A singleton has delta=0, and requires neither a gap nor an inverse. A cut from i in A to j in B satisfies r_e=d_e+eta_e with eta_e=delta_j-delta_i, so summing any valid endpoint radii proves ||eta_e||<=epsilon_e. A non-tree edge within one block uses a=e_j-e_i in (4); its coefficient is the tree effective resistance, equal to the path sum of 1/w_f. Its dressed loop mark remains in d_e and need not vanish.

## 5. Uniform response bounds and centered log increments

For phi(v)=exp(-||v||²/2), direct differentiation gives

\[
\nabla\phi=-v\phi,
\qquad \nabla^2\phi=(vv^T-I)\phi.
\]

The gradient norm t exp(-t²/2) is maximized at t=1, with value exp(-1/2). The Hessian has tangential eigenvalue -exp(-t²/2) and radial eigenvalue (t²-1)exp(-t²/2). The positive radial maximum is 2exp(-3/2)<1, and the negative part has magnitude at most one. Thus the global gradient and Hessian operator bounds are exp(-1/2) and one. Integrating along the finite segment from v to v+eta yields, in every collective input,

\[
|\phi(v+\eta)-\phi(v)|\le e^{-1/2}\|\eta\|,
\qquad
\|\nabla\phi(v+\eta)-\nabla\phi(v)\|\le\|\eta\|.
\tag{6}
\]

Probability error can also be capped at one. Here v=d_e+u_B-u_A, and uniform block shifts leave every delta and certificate unchanged. The derivative with respect to either endpoint input has the same error bound; the full product-space gradient has the incidence factor sqrt(2) on a cut. Internal edges have zero collective-input derivative. Stacking the two channels gives the same radial proof for the joint-success scalar; a pair of Bernoulli flags instead uses the sum of the two channel TV errors. Correlation after mixing the latent law is retained, not factored away.

For the two-pair specialization eta=-t and v=d_e+s_eh. Expanding the two quadratic logarithms, then subtracting the value at h=0, gives exactly

\[
[\log p_e(h)-\log p_e(0)]
-[\log\widetilde p_e(h)-\log\widetilde p_e(0)]
=s_e h\cdot t.
\tag{7}
\]

Its absolute value is at most ||h||epsilon and its gradient discrepancy has norm ||t||<=epsilon. The uncentered difference is (d_e+s_eh) dot t-||t||²/2, so its stated separate bound also follows. These log-gradient bounds use the exact quadratic, not a general implication from C0 to C1. The current access report correctly calls -r_e and +r_e the log-probability derivatives. The corresponding probability derivatives include the multiplicative p_e.

## 6. Finite adaptive Bernoulli queries and conditional potentials

Fix X, the realized structure, and its retained image. Use the same measurable randomized policy in both experiments, with no fine-only state access. Couple its randomness and each fresh Bernoulli uniform until the first answer mismatch. With identical pasts the next query is identical; common-uniform Bernoulli draws disagree with probability exactly |p-hat p|. If every query possible at step t has a common deterministic bound q_t in [0,1], conditional mismatch probability is at most q_t. Induction gives probability of no mismatch at least product_t(1-q_t). The two transcripts, including labels and inputs, agree on that event. For every measurable transcript event, the difference of probabilities is therefore at most the mismatch probability. This proves

\[
\operatorname{TV}\le1-\prod_{t=1}^K(1-q_t)
\le\min(1,\sum_{t=1}^Kq_t).
\tag{8}
\]

Mix this same coupling over any joint Q, using its actual push Q_R on the parent side. If q(X) is the retained maximum over permitted labels, the integrated mismatch bound is E_Q[min(1,Kq(X))]. A good-state set of mass 1-delta supplies min(1,delta+Kq), without conditioning away its complement. This theorem requires a finite query budget and a frozen latent draw. It is not TV control of unequal deterministic derivative readouts, nor an equivalence of evolving sampled-state processes.

For F=-tau log Z and hat F=-tau log hat Z, let Z=sum_e a_ep_e, with constant a_e>=0 and sum a_e>0. On a domain where both normalizers are at least m>0, suppose |Z-hat Z|<=a₀, ||grad Z-grad hat Z||<=a₁, and ||grad hat Z||<=M₁. Equation (6) gives exactly the finite-sum constants in the bound report, including each incidence norm. Integrating the scalar log derivative gives |F-hat F|<=tau a₀/m. Also

\[
\frac{\nabla Z}{Z}-\frac{\nabla\widehat Z}{\widehat Z}
=\frac{\nabla Z-\nabla\widehat Z}{Z}
+\nabla\widehat Z\left(\frac1Z-\frac1{\widehat Z}\right),
\]

so the gradient error is at most tau(a₁/m+M₁a₀/m²). The stated floor from bounded residuals is valid: ||d_e+B_eU||<=R and epsilon_e<=epsilon_* imply every exact and approximate probability is at least exp(-(R+epsilon_*)²/2). The summed floor is A₀ times this value. A variable coefficient would add derivative terms and is outside the claim.

The limits are necessary. At v=-eta with eta nonzero, p=1 and hat p=exp(-||eta||²/2)<1, so the failure negative log likelihood is infinite on one side and finite on the other. Near zero residual its score magnitude is asymptotic to 2/||r||. For the success energy, the discrepancy v dot eta+||eta||²/2 is unbounded along suitable v when eta is fixed and nonzero. Thus (6) alone proves neither full likelihood closure nor full VFE or natural-gradient closure. No controlled inverse Fisher metric or all-term force estimate is supplied here.

## 7. Weighted recursion and law-level prediction

At a further aggregation let positive masses be m_A, choose actual retained tree translations t_A, and define z_C=sum_A m_A(z_A-t_A)/M_C and Delta_A=z_A-t_A-z_C. The mark update is V_e^new=V_e+t_A-t_B. Substitution gives

\[
d_e^{\rm old}=d_e^{\rm new}+\Delta_B-\Delta_A.
\tag{9}
\]

Weighted centering creates no gap in the endpoint proof. Set a_A=e_A-m/M_C, whose coordinate sum is zero. For a weighted-centered coordinate column f, a_A^Tf=f_A. Since LL†a_A=a_A, the same Cauchy–Schwarz proof gives |f_A|²<=(a_A^TL†a_A)f^TLf even though f need not have arithmetic mean zero. Subtracting the arithmetic mean leaves a_A^Tf and f^TLf unchanged; the identification a_A^Tf=f_A uses the original weighted-centered f. The path proof replaces vertex count across an edge by total mass across it. The stage energy must use the actual current d_e^old on its own tree, not silently reuse original fine probabilities.

Summing (9) over a fixed finite hierarchy and adding the first omitted contrast gives the exact telescoping identity and the triangle-inequality sum of radii stated in the bound report. Top-level shifts lift uniformly to each descendant and leave those lower contrasts unchanged. The response bound (6) then applies with the total radius. Previously separate input directions need their own retained evaluator after merging. Each original edge copy retains its incidence and mark when it becomes a loop. A depth-independent small-error claim would require a summable sequence of radii, which is not proved.

Finally, pointwise failure does not invalidate native-law prediction. The reference probability on this finite Euclidean/discrete domain admits a regular conditional Psi(dX|F₁). Every native model, posterior, or recognition density ratio is a function of the retained statistics, so tilting the reference by that ratio preserves the same conditional. For each bounded response p(X,h),

\[
\overline p(y,h)=\int p(X,h)\Psi(dX\mid y)
\]

is a valid conditional success probability for those laws, almost everywhere in y, and its integral gives their exact averaged success probability. Versions on null fibers are arbitrary and do not solve the universal point-preparation target. Repeated adaptive responses condition the residual latent distribution on the new transcript; a single fixed conditional mean cannot silently replace that update. The reports retain this distinction and claim neither a cheap conditional evaluator nor autonomous sampled-state dynamics.

## 8. Revision binding and remaining obligation

This reconstruction checks the final response documents with SHA-256 values:

| Document | SHA-256 |
| --- | --- |
| coherence-response-access.md | 6240dcae07617d4b47dbb9e0378b326a29c2ed05be948475bf97304be4069aeb |
| coherence-response-bound.md | 6d071fb1463172d0509669e399a803509922aec0d39726caf051af64aefa86bd |
| coherence-and-collective-response.md | 9aa0c2b9a0d8353470bbceb6549bc17d798a6ec14964b0ac267c503c6f77898a |

Only source reads, JSON inspection, SHA-256 comparisons, and this report write ran in this assignment. The exact witness script, its existing result, older scientific outputs, source manuscripts, vault, and other workers' documents were not edited or executed. No test, ODE, new experiment, suite, GPU computation, Lean operation, or tamper check ran. The report is the primary new analytical artifact; the recorded rank result remains the existing inspected mechanical evidence. No conclusion is based on reviewer agreement, and no ledger state is assigned.

The strongest supported result is the exact-access obstruction together with explicit finite coherence bounds for the stated translation/unit-covariance collective-input experiment, finite adaptive query laws, a positive-floor interaction potential, and finite-depth weighted composition. The generic branch count, exceptional local direction count, and global sufficient 32-coordinate representation have their separate scopes. No extension to arbitrary GL transports, learned covariances, general graphs' minimal interfaces, full VFE forces, natural-gradient dynamics, or persistent individual meta-agents follows.

The minimal remaining mathematical obligation is to bound E_Q[min(1,Kq(X))] uniformly over an existing native law interval, and then compare complete candidate interfaces for the same chosen collective-response workload. A tolerated loss and priced workload are still needed for an operational selection. This can reuse the existing full correlated law and its trajectory evidence; another scientific trajectory is not implied. Such a bound would establish uniform frozen-query guarantees across that family of laws. It would not by itself specify or prove persistence of an evolving individual sampled configuration.
