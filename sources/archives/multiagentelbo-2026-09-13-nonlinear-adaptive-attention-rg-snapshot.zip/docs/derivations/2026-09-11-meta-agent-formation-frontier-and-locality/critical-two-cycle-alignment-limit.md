# The critical two-cycle Gaussian alignment limit

September 11, 2026. This completes the K=2, beta=2 logarithmic calculation left open in [the singular-holonomy derivation](singular-holonomy-alignment-limit.md). For the same normalized agreement-record model with freely variable GL(2) links, the leading evidence is an explicit positive coefficient times n^{-(3E+2N)/2} log n. The limiting parent carries a centered Gaussian law, every based loop and cut-edge copy, and an oriented direction mark when its observation interface needs that mark. A disappearing mean does not justify discarding its direction.

The conclusion is conditional on the prior and interface hypotheses below. It advances the single-point latent-link inference construction; it does not select a grouping or prove closure under an independently specified structural-parameter optimizer. The original finite admissions, earlier regular and higher-cycle proofs, and saved observations remain unchanged.

## 1. Model, coordinates, and measure

Fix c_* and a connected internal multigraph with N vertices, E edge copies, positive fixed weights w_e, and beta=E-N+1=2. Orient each edge e=(i,j) according to its transported KL. The law at vertex i is b_i=N(mu_i,Sigma_i), with Sigma_i SPD. Each Theta_e is a separate GL(2) variable. The source's normalized binary agreement kernel assigns success probability exp[-w_e KL(b_i || (Theta_e)#b_j)]. Conditioning on n selected successes at every internal edge gives the factor exp[-nD]. This is a specified family of records; no newly observed empirical data are asserted.

As derived directly from the Gaussian KL in the preceding document, set

\[
 u_i=\Sigma_i^{-1/2}\mu_i,\qquad
 A_e=\Sigma_i^{-1/2}\Theta_e\Sigma_j^{1/2}=B_e^{-1}O_e,\qquad
 B_e\succ0,\quad O_e\in O(2).
 \tag{1}
\]

The full finite-strength phase is

\[
 D=\sum_e w_e\left[\frac12\operatorname{tr}(B_e^2)-\log\det B_e-1\right]
       +\frac12\sum_{e=(i,j)}w_e\|B_eu_i-O_eu_j\|^2.
 \tag{2}
\]

In particular, the SPD factors B_e have not been fixed to I. Both determinant components of an orthogonal factor are included whenever the original prior supports them.

Let xi include the covariance coordinates and every declared spectator or interface variable. Write a(xi,B,O,u) for the proper prior density times any fixed selected observation likelihood, including the entire Jacobian of (1). The references are Frobenius-orthonormal symmetric-matrix Lebesgue measure for B, ordinary Lebesgue measure for u, normalized Haar measure for O, and a fixed smooth measure for xi. These are coordinate references, not independence assumptions on a or an improper Haar prior on GL(2).

The initial admission is that a is continuous and nonnegative, has compact xi and B support inside their admissible domains, and either has compact u support or satisfies

\[
 a(\xi,B,O,u)\le C\exp(-c\|u\|^2),\qquad C,c>0.
 \tag{3}
\]

A conditional correlated Gaussian mean prior with uniformly bounded mean and uniformly bounded positive covariance on the compact spectator domain satisfies (3). The leading integral defined below must be positive. Properness alone, unrestricted noncompact covariance/link tails, or a density vanishing on the relevant coherent set do not imply this admission.

Choose a root 0 and a spanning tree. Products of the orthogonal tree links give frames Q_i, with Q_0=I. Change means to v_i=Q_i^{-1}u_i, conjugate each receiver's B by Q_i, and change the non-tree O variables to the two based holonomies H_1,H_2. The tree links become I. Orthogonal changes in the symmetric B and vector u coordinates have absolute Jacobian one. The triangular dependence of these changes on O adds no determinant. Haar invariance changes the original edge reference to the product of tree-frame Haar measure and the two holonomy Haar measures. Denote the pulled-back full density by tilde a.

For v_0 nonzero, use its unique polar coordinates with rho>0:

\[
 v_0=\rho e(\varphi),\quad
 e(\varphi)=(\cos\varphi,\sin\varphi),\quad
 v_i=\rho e(\varphi)+\delta_i,\quad \delta_0=0.
 \tag{4}
\]

For epsilon=+1 or -1 define H_epsilon(e)=P_e+epsilon P_{e^\perp}. Every H_l in its determinant component has the representation

\[
 H_l=R(a_l)H_{\epsilon_l}(e),\quad
 \epsilon_l=\det H_l,\quad -\pi<a_l\le\pi,\qquad
 dH_l=\frac{da_l}{4\pi}.
 \tag{5}
\]

R(a) is the plane rotation. This formula is global up to the harmless angular seam. It follows because H_epsilon fixes e and the remaining factor has determinant +1. For fixed e each component is a circle with probability mass 1/2. Although H_{-1}(e)=H_{-1}(-e), (4) does not identify e with -e: rho is positive and the original root vector is oriented. In the full transformation from the original holonomy angles to (varphi,a_1,a_2), the angular Jacobian is one.

## 2. Exact normal Hessian, including covariance variations

For a fixed positive rho, the coherent configurations in these coordinates have B=I, delta=0, and a=0. Define eta_l=rho a_l as the angular normal coordinates. With S_e=B_e-I, J the quarter-turn rotation, and H_e=I on tree edges or H_epsilon on chords, the quadratic part of D is

\[
 q_\rho(S,\delta,\eta)=\sum_e w_e\operatorname{tr}(S_e^2)
  +\frac12\sum_{e=(i,j)}w_e
   \|\delta_i-H_e\delta_j+\rho S_e e
                -\mathbf1_{\{e=l\ {\rm chord}\}}\eta_l Je\|^2.
 \tag{6}
\]

The number of these normal coordinates is

\[
 d=3E+2(N-1)+2=3E+2N.
 \tag{7}
\]

Let tau_w be the determinant of the root-deleted scalar Laplacian of the full weighted graph, with ordinary oriented incidence and all edge copies. It is positive because the graph is connected. Set W=product_e w_e. If Htilde(rho) is the Hessian of q_rho in Frobenius symmetric coordinates, then

\[
 \Delta(\rho):=\det\widetilde H(\rho)
    =2^{3E}\tau_w W^4(1+\rho^2/2)^2,\qquad
 \Delta_0=2^{3E}\tau_w W^4.
 \tag{8}
\]

This determinant is independent of varphi and of the two signs. It stays positive as rho tends to zero in the rescaled angular coordinates. It is not the determinant of the original angular-coordinate Hessian at the singular point rho=0.

Here is a direct calculation. Rotate e to the first coordinate and write S=[[s,t],[t,z]]. Before converting to Frobenius coordinates, the covariance Hessian for each edge is diag(2w,4w,2w). The mean part adds rho s to the parallel residual and rho t to the perpendicular residual. Eliminating s,t,z gives residual weights 2w/(2+rho^2) in the parallel channel and 4w/(4+rho^2) in the perpendicular channel. The parallel variables are the N-1 relative means. Their weighted Gram determinant is

\[
 \left(\frac{2}{2+\rho^2}\right)^{N-1}\tau_w.
 \tag{9}
\]

The perpendicular variables are the N-1 relative means and two eta coordinates, hence E variables. Their edge residual matrix has a rooted tree incidence block and a signed identity block for the chord etas. Its determinant is plus or minus one, regardless of epsilon. Their weighted Gram determinant is therefore

\[
 \left(\frac{4}{4+\rho^2}\right)^E W.
 \tag{10}
\]

The eliminated B block, after the factor 2 per edge converting the raw off-diagonal coordinate to the Frobenius coordinate, contributes W^3[(2+rho^2)(4+rho^2)]^E. Multiplication by (9)-(10), using E-N+1=2, gives (8). The same elimination proves positive definiteness, not just a nonzero determinant. This argument also explains why omitting the covariance variables would produce a wrong full evidence coefficient.

## 3. Leading logarithmic measure

Let lambda=(xi,Q,varphi,epsilon_1,epsilon_2), where Q denotes the tree-frame variables. Reconstruct the original orthogonal links from Q and the coherent H_epsilon(e). Define the coherent trace

\[
 a_*(\lambda)=
 \widetilde a\bigl(\xi,I,Q,
       H_{\epsilon_1}(e),H_{\epsilon_2}(e),v_i=0\ {\rm for\ all}\ i\bigr).
 \tag{11}
\]

Write d lambda for d xi, normalized tree-frame Haar measure, d varphi on [0,2pi), and counting measure on the four sign pairs. The critical measure and its mass are

\[
 \nu_{\rm crit}(d\lambda)
    =\frac{a_*(\lambda)}{2(4\pi)^2\sqrt{\Delta_0}} d\lambda,\qquad
 I_{\rm crit}=\int\nu_{\rm crit}>0.
 \tag{12}
\]

All coordinate Jacobians and original prior factors are in a_*. The references in Section 1 fix the numerical constant. No arbitrary cutoff, renormalization of a divergent determinant, or new alignment penalty appears.

The full evidence satisfies

\[
 Z_n=\int a e^{-nD}
       =\left(\frac{2\pi}{n}\right)^{d/2}
          (\log n) I_{\rm crit} [1+o(1)].
 \tag{13}
\]

Moreover, the distribution of lambda obtained from the actual finite-strength variables by (4)-(5) converges in total variation to nu_crit/I_crit. This is a statement about an explicit projected coordinate distribution. The map is defined arbitrarily at v_0=0, a null set for the finite absolutely continuous laws. A theorem requiring continuity of a raw-state map through v_0=0 is not being applied.

### Proof of the asymptotic and the measure

First restrict to compact mean support ||u||<=R. The exact polar phase and the tree Poincare bound proved in the preceding document give constants depending on this compact set, the graph, and the weights such that

\[
 c_R\left(\|B-I\|_F^2+\|\delta\|^2+\rho^2|a|^2\right)
 \le D\le
 C_R\left(\|B-I\|_F^2+\|\delta\|^2+\rho^2|a|^2\right).
 \tag{14}
\]

For clarity, the covariance potential controls ||B-I||^2 on its compact SPD domain. The difference between the mean residuals with B and with I is bounded by ||B-I|| times ||u||. The tree controls every delta; each chord's root residual is rho(e-R(a_l)e), whose squared norm is 2rho^2(1-cos a_l). On [-pi,pi] this is bounded above and below by positive constants times rho^2 a_l^2. These facts prove both directions of (14), including large chord angles, without a constant-rank assumption. The inverse lower-bound constant grows at most polynomially in R.

Fix Lambda large and epsilon small. In the radial bulk Lambda/sqrt(n)<=rho<=epsilon, set

\[
 B=I+\frac{Y}{\sqrt n},\quad
 \delta=\frac{z}{\sqrt n},\quad
 a_l=\frac{\eta_l}{\sqrt n \rho}.
 \tag{15}
\]

The complete normal-coordinate Jacobian, including the original root polar factor rho d rho, is

\[
 n^{-d/2}\frac{d\rho}{\rho} 
       \frac{dY dz d\eta}{(4\pi)^2} d\lambda.
 \tag{16}
\]

The factor (4pi)^{-2} in this expression accounts for the two chord Haar measures; d lambda itself contains only the tree Haar factors and the sign counting measure.

On bounded Y,z,eta sets, the exact nD differs from q_rho(Y,z,eta) by a quantity tending uniformly to zero as n tends to infinity and then Lambda tends to infinity. The mean-residual error after multiplication by sqrt(n) is bounded by a constant times

\[
 \frac{\|Y\|\|z\|}{\sqrt n}
    +\frac{|\eta|^2+|\eta|\|z\|}{\sqrt n \rho}.
 \tag{17}
\]

The covariance Taylor remainder is O(||Y||^3/sqrt(n)). Equation (14) supplies a uniform Gaussian bound for the rescaled variables. The angular domain contains [-pi Lambda,pi Lambda]^2, so its missing Gaussian tails vanish as Lambda increases. The coefficient a approaches a_* uniformly on bounded normal sets as epsilon decreases, Lambda increases, and n increases in that order of error control. Thus the normal integral approaches (2pi)^{d/2} a_*/sqrt(Delta_0). This also follows by first using the all-radius determinant (8), then taking rho to zero.

The remaining bulk integral is

\[
 \int_{\Lambda/\sqrt n}^{\epsilon}\frac{d\rho}{\rho}
      =\frac12\log n+\log(\epsilon/\Lambda).
 \tag{18}
\]

It supplies the 1/2 in (12). The region rho<=Lambda/sqrt(n) has bounded angles. Integration of B and delta in (14) costs n^{-(d-2)/2}; integration of rho d rho costs O(Lambda^2/n). This region is O_Lambda(n^{-d/2}), negligible after division by n^{-d/2} log n. For rho>=epsilon, the two-angle Gaussian integral is at most C/(n rho^2), so the compact remainder is O_{epsilon,R}(n^{-d/2}). It is also negligible. Letting n tend to infinity, and then removing the epsilon and Lambda errors, proves (13).

The same estimates apply at each lambda, uniformly on its compact reference space, and give an integrable bound for the scaled marginal density. Its pointwise limit and mass converge to the density in (12). Dominated convergence and normalization therefore give the stated L1, hence total-variation, convergence. Compact spectator supports may be covered by finitely many smooth coordinate patches and the result added.

For (3), decompose u into integer-radius shells. The comparison constant and the normal Gaussian integrals cost at most a polynomial in 1+j on the jth shell, with a possible extra log(2+j) from the root integral. The amplitude supplies exp(-c j^2). The resulting series is summable uniformly after division by n^{-d/2} log n, and its tail tends to zero. Compact truncations therefore establish both conclusions under the Gaussian envelope. This extension retains correlations in the original density.

## 4. The mean has a logarithmic distribution of scales

Define the root scale exponent

\[
 s_n=-\frac{\log\rho}{\log n}.
 \tag{19}
\]

For every 0<a<b<1/2, the same bulk proof over n^{-b}<=rho<=n^{-a} replaces the 1/2 in (18) by b-a. It follows, including the negligible endpoint regions, that

\[
 (\lambda,s_n)\ \Longrightarrow\
       \frac{\nu_{\rm crit}}{I_{\rm crit}}
          \otimes {\rm Uniform}(0,1/2).
 \tag{20}
\]

This joint statement is weak convergence in the scale coordinate; it does not assert a total-variation limit for every rescaling. The exponent and the retained lambda are independent in the leading law, even when the original prior is correlated.

The raw mean radius tends to zero in probability, but sqrt(n) rho tends to infinity in probability. The latter follows directly from the O_M(n^{-d/2}) bound for rho<=M/sqrt(n). Thus the sqrt(n)-rescaled root means are not tight. No fixed exponent describes the whole mean distribution: (20) distributes mass across exponents between zero and one half. Every child's tree-gauged normalized mean tends to e in probability, since delta/rho tends to zero on the bulk and the discarded radial regions have vanishing mass.

A fixed continuous raw-state observation loses this radial scale as rho tends to zero. An observation depending on normalized direction need not lose e. An n-dependent observation of s_n is a further explicit interface choice; if it is required, (20) provides its extra asymptotic mark. It is not automatically part of every parent's state.

## 5. Parent law, direction mark, and covariance

Define the finite critical projection by retaining xi,Q,e,epsilon, replacing B by I and every mean by zero, and replacing each H_l by H_epsilon_l(e). The coherent reconstructed links and tree transports are

\[
 \Theta_e^0=\Sigma_i^{1/2}O_e^0\Sigma_j^{-1/2},\qquad
 g_i=\Sigma_i^{1/2}Q_i\Sigma_0^{-1/2}.
 \tag{21}
\]

Apply the source's [complete rooted marked-parent construction](../../../Theory/07c_full_graph_meta_agent_vfe.tex) to these variables. Retain b_I=N(0,Sigma_0), all based internal loops g_i^{-1}Theta_e^0 g_j, every dressed cut-edge copy with its weights and record kernel, and whatever additional interface is required for the original joint evaluators. When the interface uses mean direction, retain also

\[
 \ell_I=\Sigma_0^{1/2}e,\qquad
 \ell_I^\top\Sigma_0^{-1}\ell_I=1.
 \tag{22}
\]

This mark is a vector in the root's associated fiber at c_*. It is not declared to be the mean of the centered parent Gaussian. In the ++ sign sector both based orthogonal holonomies equal I, so they encode no e at all. A reflection records an unoriented axis and does not distinguish e from -e. The oriented mark is therefore necessary for an interface that makes that distinction. If every required evaluator ignores it, marginalizing it is allowed.

Under passive local GL changes A_i, the whitened transformations R_i=Sigma_i'^{-1/2} A_i Sigma_i^{1/2} are orthogonal. At the root, e'=R_0 e, rho'=rho, and ell_I'=A_0 ell_I. In physical root coordinates each based loop transforms by A_0 H A_0^{-1}, and cut links transform between their new endpoint roots. Equation (12) is a measure and is pushed with its full amplitude/Jacobian. These laws establish the required associated-fiber covariance without treating independent links as bundle transition functions or introducing transport across the base.

Apply (12) to the prior without the fixed observation likelihood and call the result nu_prior with mass I_0. If C_crit maps lambda to the complete parent just described, then the normalized parent prior is

\[
 \bar P_0=(C_{\rm crit})_\#\nu_{\rm prior}/I_0.
 \tag{23}
\]

A normalized observation kernel compatible with this parent defines a proper parent joint. For a selected observation o with positive limiting evidence, the original agreement-plus-observation evidence is

\[
 p_n(o,\mathbf1)
   =\left(\frac{2\pi}{n}\right)^{d/2}
       (\log n) I_0 \bar p(o) [1+o(1)].
 \tag{24}
\]

For ordinary continuous kernels this follows from Section 3. The same conclusion permits bounded directional kernels whose expressions in (4)-(5) have a uniform continuous limit as rho, B-I, delta/rho, and a tend to zero. Their limiting kernel can depend on e. The negligible endpoint regions and the uniform normal bounds prove this extension; raw continuity at mu=0 is not asserted. Internal covariance/frame variables may be integrated only when all required kernels factor through the retained parent.

## 6. A finite-strength prediction bound

The logarithmic limit also gives a quantitative upper bound for a compatible observation comparison. For compact mean support, integrate (14) first in B and delta. The remaining two-angle integral and its first angular moment satisfy

\[
 \int e^{-c n\rho^2|a|^2} da
       \le C\min(1,(n\rho^2)^{-1}),\qquad
 \int |a|e^{-c n\rho^2|a|^2} da
       \le C\min(1,(\sqrt n \rho)^{-3}).
 \tag{25}
\]

The first bound with an extra rho from the root-mean norm, and the second bound with the polar measure rho d rho, each give an O(n^{-1}) radial numerator. After the other normal integrations and division by (13), they are O(1/log n). A delta or B-I insertion costs n^{-1/2} in its Gaussian integral. Finally, the clipped normalized-direction error is bounded by a constant times min(1,||delta||/rho). Integrating its Gaussian upper bound min(1,C/(sqrt(n) rho)) against the first bound in (25) again gives an O(n^{-1}) radial numerator. Therefore, for sufficiently large n,

\[
 \begin{split}
 \mathbb E_{\Pi_n}\rho+\mathbb E_{\Pi_n}|a|
   +\mathbb E_{\Pi_n}\min(1,\|\delta\|/\rho)
       &\le \frac{C}{\log n},\\
 \mathbb E_{\Pi_n}\|B-I\|_F+\mathbb E_{\Pi_n}\|\delta\|
       &\le \frac{C}{\sqrt n}.
 \end{split}
 \tag{26}
\]

The Gaussian-envelope extension uses the same shell argument with additional polynomial radial factors. These are upper bounds under the positive I_crit admission, not optimal rates claimed for every prior.

Suppose a required normalized record kernel differs in total variation from its value on the critical parent by at most a constant times the quantities in (26). This includes suitable Lipschitz raw kernels and the directional kernels just bounded. Its joint prediction error against the same finite projected parent prior is then O(1/log n). Replacing that projected prior by (23) adds its o(1) total-variation error; no rate for that additional term is asserted. Arbitrary discontinuous records, latent transitions, and unbounded observation horizons are not covered.

## 7. Fisher inference and the evidence correction

Let the selected unnormalized density before the repeated agreement records be a. Prepare recognition proportional to a f(C_crit), where f is continuous on the retained lifted coordinates and bounded above and below by positive constants. In the original variables this preparation can be direction-dependent and discontinuous at the null set mu_0=0; the resolved-coordinate proof covers that case. For the full-law Fisher flow toward a exp(-nD), the exact density at time t is

\[
 Q_{n,t}\ \propto\ a f(C_{\rm crit})^\alpha e^{-\kappa D},
       \qquad \alpha=e^{-t},\quad \kappa=n(1-\alpha).
 \tag{27}
\]

This is the full normalized joint inference law. It does not replace joint entropy by the entropies of the sampled Gaussian agent laws. Applying (13) to the bounded amplitude f^alpha gives the limiting parent density proportional to f^alpha relative to its induced observed measure. It obeys the corresponding full parent Fisher flow for each fixed t>0. The initial layer at t=0 remains.

For the posterior at strength n, the Laplace transform of nD is Z_{n(1+s)}/Z_n for s>=0. Equation (13) makes this ratio tend to (1+s)^{-d/2}. Also Z_{n/2}/Z_n stays bounded, which controls an exponential moment and gives convergence of every fixed polynomial energy moment. Consequently

\[
 nD\Longrightarrow{\rm Gamma}(d/2,1),\qquad
 \mathbb E_{\Pi_n}D=\frac{d}{2n}+o(n^{-1}).
 \tag{28}
\]

Real positive strengths in this argument are simply the same well-defined exponential integral; they need not be integer record counts. The identical argument applies with amplitude f^alpha and strength kappa. It does not infer an energy moment by differentiating a two-sided order estimate.

Let nu_eff be the induced observed parent measure, I_obs its mass, pi_eff=nu_eff/I_obs, and r_t the limiting parent recognition. Define

\[
 c_n=\frac d2\log\frac{n}{2\pi}-\log\log n,\qquad
 \psi_d(\alpha)=\frac d2\left[\frac{\alpha}{1-\alpha}
                                    +\log(1-\alpha)\right].
 \tag{29}
\]

The exact logarithm of (27), together with (13) and (28), gives

\[
 \mathcal F_n(Q_{n,t})-c_n
   \longrightarrow
    {\rm KL}(r_t\Vert\pi_{\rm eff})-\log I_{\rm obs}
                          +\psi_d(\alpha).
 \tag{30}
\]

Here log log kappa - log log n tends to zero at fixed t>0. The first two terms equal the normalized parent VFE minus log I_0. The extra -log log n in c_n is required by the original fine evidence; it is not an optional parent-complexity penalty. At the baseline preparation f=1, expected total D also decreases by the exact exponential-tilt variance identity. These are inference statements, not a theorem about an unspecified structural-link learning rule.

## 8. Recursive centered parents with retained directions

The new limiting mean support is exactly centered. Under the smooth version of the stated compact prior hypotheses, the induced density has a smooth compact lift on the remaining covariance/interface coordinates, the circle e, the discrete sign pair, and any other retained compact orthogonal marks. Marginalizing compact smooth internal frame variables preserves smoothness. The raw loop-only pushforward can have coincident fibers, particularly in the ++ sector; retaining the explicit circle/discrete lift avoids treating that pushforward as an everywhere smooth loop density.

At a subsequent admitted grouping, the Gaussian parent laws are centered. Their new alignment action is only the sum of the SPD covariance potentials in (2). It does not align the inherited e marks of different children. Each direction and loop required by the inherited interface must therefore be transported into the new root frame and retained with its label. They cannot be replaced by a single averaged axis without a separate evaluator-factorization argument.

Orthogonal root changes preserve circle measure and act simultaneously on each child's inherited direction/holonomy tuple. The new B normal Hessian is positive with 3E_new coordinates. A bounded smooth lifted amplitude and Gaussian domination in these normals yield the next normalized parent, including its normal evidence coefficient. The same class is thus closed at every fixed admitted finite depth in the prescribed ordered strong-record limit, provided each stage has positive coherent mass and a complete compatible interface. There is no repeated logarithmic mean factor at these later centered stages, because no freely variable nonzero means have been reintroduced.

This class can also retain the integrable inherited factors F_I(H) from the higher-cycle theorem on distinct labeled holonomy subsets. Those factors are invariant under common orthogonal conjugation, independent of the new B normals, and integrable against their own retained Haar references. A bounded correlated amplitude times their finite product still supplies the required domination. Direction marks from the present critical block remain explicit beside those factors.

Compatible Bayesian records preserve this centered support. A matched conditional lift gives the preceding common-channel KL identity and parent Fisher closure. The construction can retain multiple directions and many loop/cut records, so it does not by itself guarantee a fixed-dimensional parent or a net resource saving. Closure of arbitrary finite-strength dynamics, joint structural-parameter learning, and endogenous partition selection remain separate obligations.

## 9. Exact calculation, scope, and continuation

[critical_hessian_exact.py](evidence/critical-alignment/critical_hessian_exact.py) ran once under pinned CPython 3.14.7 using Fraction arithmetic. For the three-node graph with directed edge copies (0,1),(1,2),(2,0),(0,2) and weights (1,2,3,5), tau_w=26, W=30, and d=18. It computes the full 18-by-18 normal Hessian before converting its raw symmetric coordinates to the Frobenius convention. For all four sign pairs, at rho=0,1/2,2, it obtains respectively

\[
 \Delta=86261760000,\quad109175040000,\quad776355840000,\qquad
 \sqrt{\Delta_0}=57600\sqrt{26}.
 \tag{31}
\]

These agree exactly with (8); at rho=0 the mean-normal determinant is tau_w W=780. The [saved output](evidence/critical-alignment/critical-hessian-exact-result.json) records all twelve cases. The evidence in this example is therefore proportional to n^{-9} log n with the full coefficient (12), not to n^{-9} times a cutoff-dependent determinant integral.

This arithmetic calculation checks the Hessian constants for the displayed graph. The general determinant identity, singular integral, projected measure, scale distribution, prediction bound, and recursive class are supported by the derivations above. No nonlinear alignment integration, sampling, training, or broad test suite was run, and no independent reviewer or formal verification certificate is claimed.

The named critical-case obligation is now resolved under its explicit admission. Single-cycle and K=1 singular limits, arbitrary noncompact covariance/link priors, and vanishing coherent traces are outside this theorem. The next task is to use the induced normalized parent measures to examine block selection on one common observation space: identify whether the source defines blocks as a readout of the law/link state or as an explicit latent partition. Derive selection from that definition, retaining any source-specified partition prior, all loop/cut interfaces, and the evidence coefficients. Changing which agreement records are conditioned on between candidate blocks cannot be treated as a Bayes factor for the same data. No free grouping penalty or prior will be invented to force a hierarchy. The full RG objective remains incomplete; base-manifold transport remains deferred.
