# A merged parent that preserves the native collective-response interface

September 12, 2026. This analytical construction addresses the additional-information cost of the fixed two-block probe in [the native response-law calculation](native-coherence-response-law.md). It changes neither the native generator, its generative ancestry, its original observations, nor its learning law. The fixed two-block output has 28 displayed real coordinates. After a declared actual tree merger, retaining one four-vector yields a 24-coordinate root that evaluates every old first-parent cut probability and every anchored collective-response query exactly. The response requirement therefore does not, by itself, force the two intermediate geometric parents to remain separate.

## 1. Existing construction and precise target

The source inputs are [complete parent channels](shared-parent-complete-channel-and-recursive-cost.md), Sections 3–7; [transported parent priors](transported-parent-priors-and-induced-couplings.md), Sections 2–4; [common-prior native episodes](common-prior-native-hierarchy-episodes.md), Section 4; [response access](coherence-response-access.md); [the response-error certificate](coherence-response-bound.md); and [the native-law response readout](native-coherence-response-law.md). The previously consulted live PIFB2 and meta-agent wiki distinguish finite coherence, exact response access, approximate closure, and persistence. The calculation below continues that distinction and introduces no new formation principle.

Fix one base point. The graph has directed edges 01,12,23,30, with four-vector translation links ell_e; the vector stacks two two-dimensional unit-covariance Gaussian law-mean channels b,m. The full native law retains its generative decorated ancestry H, its latent parent and root variables, and its existing transported generator. The energy E_a is always computed using H's generative tree paths. It is not recomputed around the output partition below.

For every H, apply the same geometric probe

\[
 P=\{A=\{0,1\},B=\{2,3\}\},\qquad
 g_0^P=g_2^P=0,\quad g_1^P=\ell_{01},\quad g_3^P=\ell_{23}.
 \tag{1}
\]

Its roots are 0 and 2. P is a chosen output partition, not an assertion that the native latent ancestry H equals P. In particular, the same probe is applied to generative one-block states and to every other retained ancestry.

Let

\[
 S=(H,p_8,E_a,E_b,E_c,E_v),\qquad
 z_A=\tfrac12(\mu_0+\mu_1-\ell_{01}),\quad
 z_B=\tfrac12(\mu_2+\mu_3-\ell_{23}),
\]
\[
 V_{12}=\ell_{01}+\ell_{12},\qquad
 V_{30}=\ell_{23}+\ell_{30}.
 \tag{2}
\]

The complete first output is C_1=(S,z_A,z_B,V12,V30). It has 12 scalar probability/energy fields and 16 geometric fields, hence 28 displayed real coordinates. All original labels, P's membership, roots, masses, incidence, H and any panel/controller history are additional discrete or controller data.

Define its two four-vector residuals

\[
 d_{12}=z_B-z_A-V_{12},\qquad
 d_{30}=z_A-z_B-V_{30},\qquad
 L=V_{12}+V_{30}.
\]

They satisfy, for every fine configuration and every H,

\[
 d_{12}+d_{30}=-L.
 \tag{3}
\]

For each old cut e in {12,30}, channel x in {b,m}, and relative input h^x=u_B^x-u_A^x, the newly admitted query is

\[
 a_e^x(C_1,h)
 =\operatorname{clip}_{[0,1]}
   \left[p_e^x(0)+\phi(d_e^x+s_eh^x)-\phi(d_e^x)\right],
 \quad
 \phi(v)=e^{-\|v\|^2/2},\quad s_{12}=1,\ s_{30}=-1.
 \tag{4}
\]

Its zero-input value is exactly the original retained p_e^x(0). The old first-parent cut probabilities are tilde p_e^x=phi(d_e^x).

The exact target is: for every generative H, every fine configuration admitted on that branch, each merger tree tau in {12,30}, every label e,x and every h in R^4, construct a normalized merged parent and a query evaluator agreeing pointwise with (4) and with all old tilde p values. The forward maps must compose with the actual first output, preserve the native common sufficient statistic and correlations, and have an explicit displayed-storage count. No minimum global representation dimension or measured runtime saving is assumed.

## 2. Two actual mergers, with directed tree signs retained

Choose final root 0. Both first blocks have mass two. For merger tree 12, the path from A's root to B's root is V12; hence t_A=0 and t_B=V12. For merger tree 30, the edge is directed from B to A, so the path from final root A to B uses its inverse: t_A=0 and t_B=-V30. The two root means are therefore

\[
 z_*^{12}=\tfrac12(z_A+z_B-V_{12}),\qquad
 z_*^{30}=\tfrac12(z_A+z_B+V_{30}).
 \tag{5}
\]

The non-tree dressed mark is L in either case. In the first case it is the old edge 30, because V30+t_B-t_A=L; in the second it is old edge 12, because V12+t_A-t_B=L. The selected tree mark is zero by its path definition. Its label and orientation remain in the structural registry.

Define the augmented root, including the selected tree history, by

\[
 C_2^\tau=(S,z_*^\tau,L,d_{12},\tau,P,\text{required records}).
 \tag{6}
\]

The displayed continuous count is 12+4+4+4=24. There is one four-vector d12, not four scalar norm probabilities. Equation (3) reconstructs d30 with no additional fine information.

To check actual direct/staged composition, define flattened fine paths for tree 12 as

\[
 (g_0^{12},g_1^{12},g_2^{12},g_3^{12})
 =(0,\ell_{01},V_{12},V_{12}+\ell_{23}),
\]

and for tree 30 as

\[
 (g_0^{30},g_1^{30},g_2^{30},g_3^{30})
 =(0,\ell_{01},-V_{30},-V_{30}+\ell_{23}).
\]

Substituting (2) into (5) gives, separately for each tau,

\[
 z_*^\tau=\tfrac14\sum_{i=0}^3(\mu_i-g_i^\tau).
 \tag{7}
\]

The direct non-tree mark ell_ij+g_i^tau-g_j^tau is L on the remaining edge. The directly retained d12 is obtained by substituting the first two barycenters (2) into its definition. Thus C2^tau equals the actual composition G_tau(C1(X)), component by component, including S and the retained history.

Different trees need not give identical root coordinates. In fact,

\[
 z_*^{30}-z_*^{12}=L/2.
 \tag{8}
\]

This is the expected path dependence in the presence of translation-loop holonomy. Keeping the tree history and loop establishes the direct/staged identity without assuming flatness or averaging the two cuts together. Both maps use the same final root label.

## 3. Gauge covariance and the meaning of the input ports

Under passive translation of child frames by h_i^g,

\[
 \mu_i'=\mu_i+h_i^g,\qquad
 \ell_{ij}'=\ell_{ij}+h_j^g-h_i^g.
\]

The first quantities transform as

\[
 z_A'=z_A+h_0^g,\quad z_B'=z_B+h_2^g,\quad
 V_{12}'=V_{12}+h_2^g-h_0^g,\quad
 V_{30}'=V_{30}+h_0^g-h_2^g.
\]

Therefore d12,d30,L are invariant and z_*^tau transforms by addition of h_0^g for both trees. The probability/energy part S is invariant when the generative reference offsets and distributions are pushed coherently, as required by the existing transported-prior construction. This is covariance under a change of coordinates, not a claim that a fixed centered Gaussian reference measure is translation invariant.

The active inputs u_A,u_B in (4) are different objects: they shift all child law means in the corresponding fixed probe block while holding links fixed. Then d12 changes by h=u_B-u_A and d30 by -h. In the translation specialization the input vectors are unchanged under passive frame translations. The signs in (4) thus match the two directed cuts. The construction makes no GL(K) claim: general linear transformations require the covariance/metric and representation rules absent from a fixed Euclidean unit-covariance specialization.

After merging, A and B remain two named input ports in the query interface. The root may answer different hypothetical shifts on its former children. It has not replaced this interface by a single uniform input to all four children; such a single input would give h=0. The port labels, membership and controller state must be retained and priced.

The query is evaluated against one frozen draw and its original p(0) anchors. It is not a microscopic actuation kernel or an update rule for S. In particular, clipping successive anchored increments is not generally associative, so (4) must not be promoted to a group action or sequential state dynamics. Adaptive queries use absolute inputs relative to that same frozen preparation. No physical link motion or base-manifold transport is introduced.

## 4. Exact query equality and normalized channel composition

The root decoder uses its retained d12 and sets d30=-L-d12. It then evaluates all four old scalar probabilities phi(d_e^x), and uses the original p_e^x from S in (4). Consequently, for every fine X, every tau, and every permitted input,

\[
 \widetilde p_e^x(C_1(X))
   =\widetilde p_e^x(C_2^\tau(X)),\qquad
 a_e^x(C_1(X),h)=a_e^x(C_2^\tau(X),h).
 \tag{9}
\]

These are exact global vector identities. There is no branch-bit decoder, exceptional reflection case, hidden fine-state reconstruction, or assumption that the fine residual r_e equals d_e. The root reproduces the declared anchored approximation exactly; its remaining error relative to the actual fine response is the already proved error of (4).

For one Bernoulli query, the kernel is

\[
 B_e^x(y,h;\{b\})
   =a_e^x(y,h)^b[1-a_e^x(y,h)]^{1-b},\qquad b\in\{0,1\}.
 \tag{10}
\]

Use the endpoint convention B({1})=a, B({0})=1-a rather than ambiguous zero powers. Clipping and continuity of phi make the kernel measurable; its two values are nonnegative and sum to one. If two channel flags are returned, their conditional noise kernel is the declared product of these two Bernoulli kernels. Integrating the retained joint law generally destroys independence between channels and cuts.

For any finite K, take the same randomized policy on both representations, using only their advertised common retained query information and the preceding transcript. Couple its randomness and query uniforms. Equality (9) makes every answer, and hence every subsequent selected label and input, equal by induction. The complete transcript laws coincide conditional on X and therefore under every admitted joint native law.

A policy that inspects arbitrary discarded first-stage geometric coordinates is not covered merely because it uses the same response labels. Such information must be carried as explicit controller memory or otherwise made available to both representations. This restriction prevents an unpriced first-parent oracle from entering the comparison.

For a fixed tau the deterministic forward channel is a Dirac probability. If tree choice is to come from the existing two-cut agreement-panel rule applied to this fixed probe, set gamma_e=phi(d_e^b)phi(d_e^m), draw the two edge flags independently conditional on C1, and use tree 12 when its flag is active, otherwise tree 30 when only that flag is active. The no-active-edge branch retains the split C1. The four mask probabilities sum exactly to

\[
 [\gamma_{12}+(1-\gamma_{12})]
 [\gamma_{30}+(1-\gamma_{30})]=1.
\]

Retain the actual flag/tree history. This is the previous panel's normalized functional rule applied to the chosen probe on every H. It is an auxiliary forward readout, not a new observation or evidence that P is an endogenous preferred partition. Its regime probabilities are not the earlier ancestry-dependent panel's regime probabilities.

## 5. Native common-reference sufficiency for every generative ancestry

There are finitely many generative decorations H. A branch with k_H latent blocks has 36+4k_H real primitive coordinates, so the fine space is a finite disjoint union of Euclidean spaces of dimensions 40,44,48,52. Choose a positive reference mass on every decoration and its normalized unit-variance transported Gaussian generator. It defines a probability P_* on that standard Borel space. A native prior with some zero ancestry masses is still absolutely continuous with respect to this reference; zero-mass branches need not be removed from the construction.

The original native model and recognition Radon–Nikodym ratios have the forms

\[
 \frac{dP_u}{dP_*}
 =c_H(u)\exp[-\tfrac12\sum_j(u_j-1)E_j],\qquad
 \frac{dQ_\eta}{dP_*}
 =Z_\eta^{-1}c_H^\eta
     \exp[-\tfrac12\sum_j(\rho_j-1)E_j+\omega k_H+s\log L_o].
 \tag{11}
\]

Here c_H includes the unchanged structural-prior ratio and Gaussian normalizers; c_H^eta includes any fixed structural-reference ratio. The original likelihood L_o is a function of p_8. Every term is S-measurable. In particular, k_H remains the generative block count even when the geometric output has two or one blocks. Neither the energy definition nor the native count-memory coordinate is reset by a merger.

For a fixed tree, take the reference forward map directly. For a randomized panel, augment P_* with the same normalized parameter-independent panel kernel and denote the augmented probability by R_*. The native measures receive the identical augmentation. Their ratios to R_* are still the S-measurable functions in (11), and the original posterior adds only the S-measurable factor L_o divided by its evidence.

The precise disintegration fact used here is: if R is a probability on a standard Borel space E and C:E→Z is measurable with Z standard Borel, a probability kernel Psi(dx|z) exists such that R(A intersect C^{-1}(B)) equals the integral over B of Psi(A|z) R_C(dz); Psi is supported on the corresponding fibers for R_C-almost every z. Our finite disjoint unions, finite flags and Euclidean-coordinate target spaces meet these hypotheses.

Apply this to the root map. Its density ratios are functions of S, which the root retains. For any normalized native tilt a(S) and measurable set A,

\[
 \int 1_A(X)a(S(X))R_*(dX)
 =\int a(S(y))\Psi(A\mid y)R_{*,C_2}(dy).
 \tag{12}
\]

Thus all native models, original posteriors and recognition laws share the same reference conditional Psi after the root push. This proves normalization and the common-conditional reconstruction simultaneously across all generative H and all positive native variance parameters. Changing the admissible fixed structural prior only changes the retained H-dependent tilt; the channel itself still uses the fixed P probe.

The relative-density ratio of recognition to original posterior is unchanged on each root fiber, so its joint relative entropy and negative ELBO are preserved. The original evidence is unchanged because its normalized record kernel depends only on retained p. On the positive parameter domains with the already established differentiation and moment regularity, every native model/recognition score is S-measurable. Its Fisher second moment is therefore identical before and after pushing. This preserves the existing native law evolution; it is not a Euclidean-coordinate entropy approximation or a new independent-parent learner.

For explicit reverse composition, disintegrate the augmented reference first over (C1,actual tree history), then over C2. Composing these two conditional kernels reconstructs the same full reference, and (12) transfers the composition to every native tilt. The first-parent and fine conditional distributions can be correlated and singular on geometric constraint sets. No product of Gaussian child resets is substituted. A conditional kernel's existence is not an inexpensive implementation.

## 6. The existing native response bounds transfer without an added error

Equation (9) identifies the first and merged anchored query kernels exactly. Therefore every already established bound comparing the true fine query with the first anchored query also compares it with the merged root query, for the same common policies and the full unconditioned native law.

For example, the existing native-law report gives the bounds

\[
 {\rm TV}\le
 \begin{cases}
 \min\{1,0.628K\min(R,2e^{-1/2})\},&t\in[5,7],\\
 \min\{1,0.494K\min(R,2e^{-1/2})\},&t\in[35,40],
 \end{cases}
 \tag{13}
\]

for its specified adaptive single-channel query interface, under either complete law. The exact coefficient enclosures and strict-prior continuation are evidence in that report, not new computations here. The present implication is algebraic: no additional compression error appears on replacing C1 by C2. The same applies to its other stated query-output conventions with their corresponding constants.

This continuation retains every generative H; it does not replace the full native law by a conditional-P law. The native regime windows remain results about their own ancestry-dependent panel. They do not imply that this fixed geometric P was selected by learning, and they do not become probabilities for the new fixed-probe panel. Native time continues to index frozen preparation laws, not a sampled-state path.

## 7. Displayed storage, evaluation costs, and what the comparison excludes

The complete counts for the present map are:

| Representation | Displayed real coordinates |
| --- | ---: |
| Fine state on generative H | 36+4k_H, from 40 to 52 |
| Fixed two-parent probe C1 | 28 |
| Geometric root carrying only S,z_*,L | 20 |
| Root additionally retaining four old scalar parent-cut probabilities | 24 |
| Root instead retaining the four-vector d12 | 24 |

The vector root has the same displayed count as the older scalar-augmented root while preserving the larger anchored-response contract. It saves four displayed real coordinates relative to the separate fixed probe parents. Fine-to-root savings are 12+4k_H coordinates on each branch. These are direct storage counts; no rank computation or global minimality claim is made.

If the optional fixed-probe panel is used, let m denote its actual full-law merger probability. The mean displayed count is exactly

\[
 28(1-m)+24m=28-4m,\qquad 24\le\mathbb E N\le28.
 \tag{14}
\]

Here m=E[gamma12+gamma30-gamma12 gamma30] under the actual full joint law. It was not evaluated in this assignment. The earlier expected 18-field saving and complete resource license used a different ancestry-dependent geometry/output map. They cannot be transferred to (14) or used to supply its uncomputed m.


For the deterministic merged candidate C2^tau, the full-law expected savings have a separate exact expression,

\[
 \mathbb E[N_{\rm fine}-24]=12+4\mathbb E k_H,\qquad
 \mathbb E[N_{\rm fine}-28]=8+4\mathbb E k_H.
 \tag{15}
\]

On the already certified O/P reference prior, k_H=1+1_{H\in P}, so these equal 16+4w_P and 12+4w_P. This is a fresh storage consequence for the present fixed-probe map, not a transfer of the old resource license or a statement about the optional panel average (14).

The [existing moment-window record](evidence/native-coherence-response/moment-window-enclosures.json), under its late-window P ranges, supplies the exact lower endpoints

\[
 w_P^Q\ge
 \frac{80094717247053422530909343402424717181}
      {85070591730234615865843651857942052864},
 \qquad
 w_P^\Pi\ge
 \frac{320411568101414148304292863652032702969}
      {340282366920938463463374607431768211456}.
\]

Both fractions exceed 47/50 by cross-multiplication. Thus throughout [35,40], under either full reference law, the root saves strictly more than 19.76 displayed real coordinates in expectation relative to the fine state; the fixed two-parent output saves strictly more than 15.76. No trajectory, moment readout or numerical calculation was rerun here. For priors positive on all twelve ancestries, (15) remains exact with the full E k_H. Continuity of the finite ancestry weights and native path, already established in the native-law report, preserves these strict coarse lower bounds on a sufficiently small nonempty relative-open positive-prior family. It does not transfer the reference's narrow numerical ranges to that family.

Forming d12 from the first state and L and z_* from (5) uses a fixed finite number of four-vector additions and scalar multiplications. This one-time arithmetic must be paid. Query evaluation needs a retained original p anchor, d12 or the reconstructed -L-d12, a two-dimensional shift, two squared norms/exponentials and clipping. Both representations can share exactly the same compiled evaluator. Caching all four unshifted phi(d_e^x) costs four additional real values on either side; it is optional and does not belong invisibly to the 24 count.

The following costs remain explicit: the finite P-to-child input-port map and orientation convention; generative H and all original labels; masses, roots, tree/flag history and loop incidence; evaluator instructions and constants; native law parameters, moment evaluation and normalization; the joint reference law or its evaluated representation; any reverse sampler; controller memory; and any per-query cache or retained transcript. Keeping two input ports after merger does not make controller or actuation costs disappear. A fine implementation may compile the identical query interface, so this argument provides no exclusive online computational advantage.

For a per-real storage price c>0 and identical prices for genuinely shared data, the bare storage difference is 4c in favor of the merged root. If Delta C denotes the merged-minus-split additional formation, metadata, evaluator, controller and execution cost at a specified workload, the total saving is 4c-Delta C. Its sign is not established without that workload and those costs. The law solver's native coordinate count has not decreased merely because a sampled carrier is shorter.

## 8. Supported conclusion and remaining scope

For this fixed P, every native generative ancestry, either directed merger tree with root 0, and every finite collective input, the explicit map (6) is a normalized, gauge-covariant translation-family parent channel. It composes exactly with its actual first output, retains the native law/Fisher sufficient statistic and all conditional correlations, and preserves both old first-parent cut probabilities and the expanded anchored-response query kernel. Its displayed count is 28→24.

Consequently, this response contract alone cannot establish that two separate intermediate geometric parents are necessary: a merged root can keep the same query interface with fewer displayed real fields. It still remembers the two input ports and its ancestry. The result does not prove that the system should merge, that P is learned, or that complete costs favor the merge.

Further inputs could require information absent from d12 and L, including nonuniform within-block perturbations, new labeled interactions, independent link changes, or stronger observation/actuation interfaces. Fixed-input query equality is not closure of a full dynamic force. General GL(K) geometry, sampled-state persistence, recursive indefinite-depth error budgets and a complete measured resource comparison remain separate obligations. Clipping leaves the anchored kernel normalized but may introduce nondifferentiable boundaries.

No scientific calculation, old run, trajectory integration, new prior, new observation, GPU, Lean, tamper check, or agent delegation was performed for this assignment. Only this derivation was written. The next work that would change its practical conclusion is a priced workload for this exact fixed-probe interface, or an explicitly required additional input family that the 24-coordinate root cannot evaluate.
