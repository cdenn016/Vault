# Native inference memory, effective link metrics, and local parent reduction

September 11, 2026. This continues the fixed-point formation investigation on source HEAD ed8f22a56df353b1535744509cc23fae46d5813c. The preceding goal turn made progress: a coherent-stratum prior admitted membership learning, but static maximal-coherence contraction was idempotent. The present result returns to the already specified coupled E/M dynamics. It derives their structural memory force, gives an explicit finite-time residual for replacing that force by a conditional Fisher metric, and constructs a smaller, informative first-variation parent for one actual Gaussian link-learning system. No new data, rate ratio, formation threshold, or production model is introduced.

The strongest positive statement is conditional and local. The previously derived constrained parent flow is also the slowly varying approximation to the native flow when the displayed lag and acceleration residuals are small. At an interior stationary point, the complete native first variation has a finite memory realization and can be reduced without changing its retained observation response. This does not establish nonlinear coalescence, two proper first-level blocks, their persistence, or a second learned level. Those parts of the original objective remain open.

## 1. Source reconciliation and the update contract

The existing [moving-target calculation](pointwise-learning-parent-closure.md), equations (11)-(16), already supplies the exponential-conditional filter and the structural covector. The [Gaussian application](pointwise-gaussian-link-learning.md), equations (1)-(8), supplies one normalized model with nontrivial observations and independently variable structural links. The [conditional-matching derivation](conditional-matching-dynamics-and-local-obstruction.md), equations (8)-(15), already supplies the metric M plus conditional Fisher information when matching is imposed as a constraint. We do not claim those formulas as new. The missing connection is whether, and with what residual, that metric follows from eliminating the actual native conditional lag.

The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) was consulted at sec:timescales, sec:meta_agent_variational, sec:meta_agent_state_construction, sec:rg_status, sec:time_info, sec:scale_dependent_time, and the RG appendix's adiabatic-elimination passage. Its within-scale rates are imposed, its graph-pullback slow metric requires additional hypotheses, and its unresolved force residual is distinct from a small static energy discrepancy. The present argument supplies a force residual for one admitted inference dynamics; it does not prove that appendix's general slow-manifold hypotheses. The existing covariance-pooling and information-clock claims remain separate. The [fast/slow construction](../2026-09-11-fast-slow-derived-hierarchy/final-report.md) uses a different local kinetic metric and supplied interaction structure; its collective rates are not imported into the full-law Fisher dynamics below.

The Research wiki's Meta-agents and hierarchical emergence and Staged hierarchy formation and RG composability pages, with their linked [formation source](<C:/Users/chris and christine/Desktop/Research/sources/manuscripts/multiagentelbo-2026-09-11-formation.md>), preserve the operational requirements: complete joint law, evaluator, structural marks, sufficient memory, and admitted boundary access. All analysis stays at c_*. A link is a structural parameter here, not a latent draw. No base transport, independent replacement bundles, flat-frame assumption, or identity-holonomy requirement is added.

Let the fixed-observation posterior of one normalized joint be
\[
 \pi_\theta(z,u)=s_\theta(z)b_{\eta_z(\theta)}(u),\qquad
 b_\eta(u)=h_z(u)\exp[\eta^\top T_z(u)-A_z(\eta)].
 \tag{1}
\]
The observation and z-dependent carrier are fixed during a trajectory. Recognition is Q=r(z)b_{\alpha_z}(u). The natural domains are open and convex, and the trajectory and interpolation segments used below remain in them. The minimal regular conditional family and integrable differentiated moments are assumptions. Finite positive spaces provide an elementary instance; Gaussian conditionals provide another. The generative evidence e_theta(o) is positive and remains in
\[
 F(Q,\theta)=D(Q\Vert\pi_\theta)-\log e_\theta(o),\qquad
 F_z(r,\theta)=D(r\Vert s_\theta)-\log e_\theta(o).
 \tag{2}
\]
Set B_z=D_theta eta_z, H_z(eta)=nabla^2 A_z(eta), and g_z=partial_theta F_z at fixed r. M(theta) is the same positive structural metric as in the native model, on its identifiable chart. The existing equations are
\[
 \dot r=-r[\log(r/s_\theta)-E_r\log(r/s_\theta)+d-E_rd],
 \quad \dot\alpha_z=\eta_z-\alpha_z,\quad
 M\dot\theta=-g,
 \tag{3}
\]
\[
 d_z=D(b_{\alpha_z}\Vert b_{\eta_z}),\qquad
 g=g_z-E_r B_z^\top[\nabla A_z(\alpha_z)-\nabla A_z(\eta_z)].
 \tag{4}
\]
These are continuous inference equations in a declared clock normalization. They are not a transition law for physical microscopic samples.

For external background, differentiating a regular exponential-family normalizer gives grad A=E T and Hess A=Cov(T), as recorded in Wainwright and Jordan's [author-hosted text, equation (3.41)](https://people.eecs.berkeley.edu/~jordan/sail/readings/wainwright-jordan-fnt.pdf#page=68). Gaussian conditioning and matrix differentiation use [Rasmussen and Williams, Appendix A](https://gaussianprocess.org/gpml/chapters/RWA.pdf). The memory, reduction, and error statements below are derived here. A publisher URL returned 403 and an obsolete author URL returned 404; the accessible author-hosted text was used. This was a bounded primary-source check, not a novelty search or a systematic review.

## 2. The exact structural memory force

Define delta_z=alpha_z-eta_z(theta), and write v=dot theta. The existing filter gives
\[
 \delta_z(t)=e^{-t}\delta_z(0)
 -\int_0^t e^{-(t-s)}B_z(\theta(s))v(s)ds.
 \tag{5}
\]
This equality is exact even when v depends on Q. The integral records that same coupled trajectory; it is not permission to prescribe an unrelated link path.

Define the symmetric positive matrix
\[
 \overline H_z(t)=\int_0^1 H_z(\eta_z(t)+a\delta_z(t)) da.
 \tag{6}
\]
The fundamental theorem of calculus gives grad A(alpha)-grad A(eta)=overline H delta. Substitution into (4) therefore gives the exact Volterra form
\[
 \begin{split}
 M(t)v(t)&+E_{r(t)}B_z(t)^\top\overline H_z(t)
       \int_0^t e^{-(t-s)}B_z(s)v(s)ds\\
 &=-g_z(t)+e^{-t}E_{r(t)}
       B_z(t)^\top\overline H_z(t)\delta_z(0).
 \end{split}
 \tag{7}
\]
The expectation is over the current retained law; the same retained coordinate z indexes past conditional parameters. Positive definiteness of overline H at each time does not make the cross-time matrix B(t)^T overline H(t)B(s) symmetric or positive. Equation (7) is a memory force, not an instantaneous positive friction theorem. The original product-gradient dissipation remains valid, with hidden inference included.

The conditional KL has the integral expression
\[
 d_z=\int_0^1 a \delta_z^\top
       H_z(\eta_z+a\delta_z)\delta_z da.
 \tag{8}
\]
To check the weight, differentiate D(b_{eta+a delta}||b_eta) in a: its derivative is a delta^T H(eta+a delta)delta, and its value at zero is zero. This also shows why the parent E-force is second order in lag while the structural force in (4) is generally first order.

For two or more conditional layers, applying (3) independently to every layer is generally incorrect away from equilibrium: a projected intermediate E-flow already contains a centered conditional-KL correction. Exact nonlinear recursion must carry that correction and the joint correlations. Section 5 gives a separate exact first-variation composition statement where these quadratic corrections vanish to first order.

## 3. Recovering the conditional Fisher metric with a residual

Assume eta_z(theta(t)) is twice differentiable. Define
\[
 \rho_z(t)=\delta_z(t)+\dot\eta_z(t)
 =e^{-t}[\delta_z(0)+\dot\eta_z(0)]
       +\int_0^t e^{-(t-s)}\ddot\eta_z(s)ds.
 \tag{9}
\]
Integration by parts in (5) proves the second equality. The initial term cannot be dropped at a newly matched start. Neither small pairwise KL nor a large static precision gap bounds rho.

Taylor expansion of grad A gives
\[
 R_z=\nabla A_z(\eta_z+\delta_z)-\nabla A_z(\eta_z)
                           -H_z(\eta_z)\delta_z,\qquad
 \mathcal I(r,\theta)=E_r B_z^\top H_z(\eta_z)B_z.
 \tag{10}
\]
Because dot eta=Bv, the exact structural equation becomes
\[
 (M+\mathcal I)v=-g_z+\mathcal R_\theta,\qquad
 \mathcal R_\theta
       =E_r B_z^\top[H_z(\eta_z)\rho_z+R_z].
 \tag{11}
\]
The matrix I is precisely the conditional Fisher information in the earlier constrained construction. Equation (11) now follows from the unconstrained native dynamics, with an explicit residual. Setting that residual to zero is an approximation; the earlier constrained flow is exact for its separately imposed family.

For a quantitative finite-state version, assume uniformly over the retained z and interpolation segments that ||B_z||<=b, ||H_z||<=h, Hess A is ell-Lipschitz, and M>=m I with m>0. Write epsilon(t)=sup_z||delta_z(t)|| and beta(t)=sup_z||rho_z(t)||. Equations (5) and (9) bound these directly by exponentially weighted target velocities and accelerations. Taylor's integral remainder gives
\[
 \|R_z\|\le\frac{\ell}{2}\|\delta_z\|^2,\qquad
 \|v+(M+\mathcal I)^{-1}g_z\|
 \le\frac{b h\beta+b\ell\epsilon^2/2}{m}.
 \tag{12}
\]
The exact E-vector differs from its marginal Fisher vector by -r(d-E_rd). Positivity and (8) give
\[
 \|r(d-E_rd)\|_1\le2E_rd\le h\epsilon^2.
 \tag{13}
\]
Thus closeness of the structural velocity requires an acceleration/transient bound in addition to small conditional KL.

Let w=(r,theta), let V_bar be the constrained parent vector field from the earlier derivation, and use the sum of the l1 and Euclidean norms. Suppose V_bar is L-Lipschitz on a common domain containing the native projected trajectory and the constrained comparison trajectory, with the required connecting segments in that domain. If they start at the same w(0), subtraction and the integral Gronwall inequality yield
\[
 \|w(t)-\bar w(t)\|
 \le\int_0^t e^{L(t-s)}
 \left[h\epsilon(s)^2+
 \frac{b h\beta(s)+b\ell\epsilon(s)^2/2}{m}\right]ds.
 \tag{14}
\]
A nonzero initial difference adds e^{Lt}||w(0)-w_bar(0)||. The proof follows by integrating the norm inequality D^+||w-w_bar||<=L||w-w_bar||+||V_native-V_bar||. All constants and hypotheses are displayed. This is a finite-horizon bound on the actual coupled state, not a uniform-in-time theorem or a sampled path-law identity.

For Gaussian z, a global supremum over all real z need not be finite. Equations (5)-(11) still hold with the source's finite conditional coefficients Gamma,a,L; one must evaluate weighted moments in (8) and (11), or establish bounds on those Gaussian moments on an admitted SPD parameter domain. The finite-state constants above are not asserted for unbounded Gaussian z. The Gaussian result in Sections 5-6 instead uses its finite parameter chart and a direct Taylor bound.

As one operational consequence of (14), suppose the finite-state version also has bar r_z>=r_min>0, and eta is b-Lipschitz along the parameter comparison segments. For the lifted comparison Q_bar=bar r b_eta(bar theta),
\[
 D(Q\Vert\bar Q)\le
 \frac{\|r-\bar r\|_1^2}{r_{\min}}
 +\frac h2(\epsilon+b\|\theta-\bar\theta\|)^2.
 \tag{15}
\]
The first term follows from KL<=chi-squared; the second uses the chain rule and the same Hessian bound on the extended natural-parameter segments. Every common, fixed normalized observation kernel contracts this KL and has output TV at most its square root divided by sqrt(2). This applies to an actual common record channel, including a fixed Gaussian sensor in a separately admitted moment bound. It does not create a multi-time sample process from recognition marginals. A sequence of conditionally refreshed samples would be a new observation protocol and is not assumed.


## 4. Exact first variation of the native coupled dynamics

A sharper local result does not assume slow target motion. Fix an interior stationary pair (pi_0,theta_0), with recognition equal to the posterior and grad_theta[-log e_theta(o)]=0. Work in an admitted finite-dimensional recognition tangent space containing all posterior scores; the full Gaussian tangent space satisfies this for the Gaussian model. Assume differentiability sufficient for the following first variation. Let vartheta be the structural perturbation, xi the centered recognition log-density perturbation, and
\[
 S=\partial_\theta\log\pi_\theta|_{\theta_0},\quad
 P=E_{\pi_0}SS^\top,\quad
 A=\nabla_\theta^2[-\log e_\theta(o)]|_{\theta_0},\quad
 M=M(\theta_0).
 \tag{16}
\]
Here P is posterior information; it is not automatically the complete generative Fisher M. These are fixed matrices in the linearization. At a strict local evidence optimum A is positive definite; some constructions allow semidefinite A and neutral directions.

Centering the first variation of the E-equation and differentiating the structural score give
\[
 \dot\xi=S^\top\vartheta-\xi,\qquad
 M\dot\vartheta=-(A+P)\vartheta+E_{\pi_0}S\xi.
 \tag{17}
\]
For the second equation, write g=-partial log e-E_Q partial log pi. The normalization identity E_pi partial_theta S=-P gives the P term, while the Q variation supplies -E S xi. The derivative of M multiplies the zero stationary covector and therefore contributes nothing at this order. This derives (17) from the normalized objective rather than omitting its determinant.

The source [full-law Fisher analysis](../2026-09-11-fast-slow-derived-hierarchy/dynamics-construction.md) already identifies unit recognition relaxation at fixed target. Equation (17) adds actual structural feedback. In the scalar structural case, the score-driven two-dimensional sector has decay rates determined by
\[
 M r^2-(M+A+P)r+A=0.
 \tag{18}
\]
Indeed, write xi=S psi in this sector. Then dot psi=vartheta-psi and M dot vartheta=P psi-(A+P)vartheta. The determinant of its Jacobian plus r I is (18)/M. Orthogonal recognition perturbations decay at rate one and do not enter the structural equation. If M>0, A>0, and P>=0, the discriminant is (M-A)^2+2P(M+A)+P^2>=0 and both rates are positive. A small slower rate may arise from evidence curvature and posterior coupling; it is not a separately assigned learning rate. One slow eigenmode still does not make every retained sector slow or select a group of agents.

## 5. A parent with exactly sufficient linear memory

For one fixed map y=f(x), let E_y denote conditional expectation under pi_0. Assume the retained and hidden tangent subspaces lie in the admitted recognition tangent model; fixed linear maps of a Gaussian meet this condition. Decompose
\[
 \xi_y=E_y\xi,\quad \xi_h=\xi-\xi_y,\qquad
 S_y=E_yS,\quad S_h=S-S_y,\quad
 P_y=E S_yS_y^\top,\quad I_h=E S_hS_h^\top.
 \tag{19}
\]
Conditional centering makes all cross inner products vanish, so P=P_y+I_h. Define the hidden force memory
\[
 m_h=E S_h\xi_h\in\operatorname{range}(I_h).
 \tag{20}
\]
Its range assertion follows because c in ker I_h implies c^T S_h=0 almost surely. Projecting (17) gives the closed exact first-variation system
\[
 \dot\xi_y=S_y^\top\vartheta-\xi_y,\qquad
 \dot m_h=I_h\vartheta-m_h,\qquad
 M\dot\vartheta=-(A+P_y+I_h)\vartheta+E S_y\xi_y+m_h.
 \tag{21}
\]
No fine conditional trajectory is needed after initializing m_h. Hidden perturbations orthogonal to every component of S_h decay at rate one, exert no first-order structural force, and affect no retained marginal at first order. This proves closure for every admitted initial tangent perturbation, not only a posterior-matched initial tangent.

The required memory has rank(I_h) independent coordinates, rather than all hidden recognition coordinates, for this response contract. It is initialized from the fine recognition perturbation and is part of the parent. Omitting it loses first-order information whenever it is nonzero. If a record reads hidden coordinates, its first-order conditional response directions must also be retained unless they lie in the existing span. In general that addition can recover the full dimension. In contrast, every fixed normalized sensor depending only on y is determined by the retained marginal, and its full first-variation density is reproduced by (21).

Define k_h=I_h vartheta-m_h. Then dot k_h=I_h dot vartheta-k_h, and the third equation is M dot vartheta=-g_y^lin-k_h, with g_y^lin=(A+P_y)vartheta-E S_y xi_y. With zero initial lag the Laplace-domain force relation is
\[
 \left(M+\frac{I_h}{s+1}\right)\widehat{\dot\vartheta}(s)
                =-\widehat{g_y^{\rm lin}}(s).
 \tag{22}
\]
A nonzero k_h(0) adds -k_h(0)/(s+1) on the right. The exact memory relaxes at the E-clock rate. Only the low-frequency limit gives M+I_h. Replacing the frequency-dependent term by I_h at all frequencies changes the linear dynamics. This distinction remains even though the associated static metric is positive.

For nested fixed maps x to y to z, the posterior score splits into S_z, S_{y|z}, and S_{x|y}. Conditional centering makes them orthogonal at this same stationary reference, and
\[
 I_{x|z}=I_{x|y}+I_{y|z}.
 \tag{23}
\]
Each eliminated component has the same unit filter in the present full-law Fisher E-flow. Its force memories add; direct and staged elimination therefore produce the same (I_{x|y}+I_{y|z})/(s+1) kernel, including the summed initial forcing. This is exact composition of the stationary first variation with shared structural coordinates. It does not license adding nonlinear, time-dependent kernels evaluated at different reference laws, resetting memory at a stage, or replacing each stage by a fresh Fisher update. If conditional sectors have different separately declared kinetics, their different poles must be retained.

For a dense Gaussian recognition on n sample coordinates and retained rank r, the full recognition count is n(n+3)/2. Equation (21) retains r(r+3)/2 recognition tangent coordinates, d structural coordinates, and rank(I_h)<=d force-memory coordinates. Fixed equilibrium matrices, structural links, the observation map, membership, and any additional access marks remain resources. This is a local response realization, not a lower-dimensional sufficient statistic of the whole nonlinear family. The earlier family-wide no-compression result is unchanged.

A finite-horizon nonlinear remainder can be stated without claiming a global slow manifold. Use any fixed smooth finite parameter chart near the stationary state, centered at zero, with native vector field f, Jacobian J_f, and norm bounds ||J_f||<=L and ||D^2 f||<=B on a convex ball. Suppose the trajectory stays in that ball. Taylor's integral remainder gives ||f(v)-J_f v||<=B||v||^2/2. For initial norm delta, scalar comparison yields
\[
 \|v(t)\|\le
 \frac{\delta e^{Lt}}{1-\frac{B\delta}{2L}(e^{Lt}-1)}
 \quad(L>0),
 \tag{24}
\]
while the denominator is positive. If it is at least 1/2 and the resulting bound lies inside the ball, continuation ensures the required trajectory admission. Variation of constants then gives
\[
 \|v(t)-e^{tJ_f}v(0)\|
 \le \frac{2B\delta^2}{L}e^{Lt}(e^{Lt}-1).
 \tag{25}
\]
For L=0 the corresponding bounds are delta/(1-B delta t/2) and 2B delta^2 t under the same half-denominator condition. To check (25), use ||v(s)||<=2 delta e^{Ls} in the remainder integral. Applying the linear retained-coordinate map multiplies (25) by that map's norm. Smooth output means and covariances have corresponding bounded-derivative remainders. The constants are properties of the actual admitted vector field and chart; no numerical radius or tolerance is claimed until they are evaluated. This supplies an explicit conditional order-two error statement, not a tested finite-amplitude operating range.

## 6. An actual Gaussian link equilibrium and an informative reduction

Use the same source-admitted two-node subclass as the earlier link-learning discriminator:
\[
 x_1\sim N(0,1),\qquad x_2|x_1\sim N(\theta x_1,1),
 \qquad o|x_2\sim N(x_2,1),\qquad \theta>0.
 \tag{26}
\]
The positive scalar link is independently learned. Its complete model Fisher is M=1; in log-link coordinates it is theta^2. Thus the update remains a natural gradient, not an unpreconditioned prescription on a Lie algebra. The complete two-channel residual framework admits (1)-(23); the small instance here exercises one channel and does not assert a completed two-channel child-block hierarchy.

Fix the possible observation o=3/2. Since o has variance s=2+theta^2, the negative log evidence is log(s)/2+o^2/(2s), up to a constant. It has an interior strict local minimum at theta_0=1/2. The posterior at that point is
\[
 \mu=\begin{pmatrix}1/3\\5/6\end{pmatrix},\qquad
 C=\begin{pmatrix}8/9&2/9\\2/9&5/9\end{pmatrix},
 \quad A=\frac8{81},\quad M=1.
 \tag{27}
\]
This is an analytic conditioning value, not a collected datum. The structural posterior score is S=x_1x_2-x_1^2/2. Its mean is zero, E x_1^2=1, and direct Gaussian fourth moments give
\[
 P=E S^2=\frac{73}{81},\qquad A+P=1,\qquad
 r_\pm=1\pm\frac{\sqrt{73}}9.
 \tag{28}
\]
The remaining four Gaussian recognition tangent modes decay at rate one. Both r values are positive, so the full six-dimensional smooth E/M equilibrium is locally asymptotically stable. This follows, for example, by choosing the positive quadratic Lyapunov form obtained by integrating e^{tJ_f^T}e^{tJ_f} for its stable Jacobian; the quadratic Taylor remainder is dominated in a sufficiently small neighborhood. No basin radius or global convergence claim is made. The slow rate is approximately 0.0507 in the native E-clock, derived from the actual normalized model.

Now retain y=x_2 and the same family of future single-observation queries o'|y~N(y,1). This sensor is nonconstant, fixed, and normalized. At the stationary law,
\[
 S_y=\frac8{25}y^2-\frac25,\qquad
 P_y=\frac{448}{2025},\qquad I_h=\frac{17}{25}.
 \tag{29}
\]
For a direct check, let epsilon=x_1-(2/5)y. Then epsilon and y are independent, with epsilon~N(0,4/5) and y~N(5/6,5/9), and
\[
 S_h=\frac35 y\epsilon-\frac12\epsilon^2+\frac25.
 \tag{30}
\]
Its conditional mean vanishes; its variance is 17/25 and its covariance with S_y is zero. Consequently P_y+I_h=73/81 exactly.

A bivariate Gaussian recognition has five local coordinates. The retained univariate Gaussian has two. Including theta and the one scalar force memory gives an exact first-variation reduction from six evolving coordinates to four. It reproduces the retained mean, variance, structural perturbation, and complete first-order density of the same future sensor for every Gaussian initial tangent. The stationary sensor law is N(5/6,14/9); perturbing the retained mean or variance changes that law, so this is not a constant-response quotient.

For transparent coordinates, write the fine centered tangent in the basis
(x_1-E x_1, x_2-E x_2, x_1^2-E x_1^2, x_1x_2-E x_1x_2, x_2^2-E x_2^2).
Conditional expectation maps its coefficients to the two centered basis coefficients of y and y^2 by the matrix
\[
 C_y=\begin{pmatrix}2/5&1&0&0&0\\0&0&4/25&2/5&1\end{pmatrix}.
 \tag{31}
\]
Together with theta and m_h=E S_h xi, this defines a rank-four linear map T from the six native perturbation coordinates. The accompanying exact-arithmetic calculation constructs the full six-by-six Jacobian J_f, the four-by-four realization J_c from (21), and checks T J_f=J_c T. The sensor response map factors through C_y. This matrix identity, plus the derivation above, is the precise linear path-equivalence claim. It concerns trajectories of inference parameters and their query responses, not a stochastic physical sample path.

The memory-free constrained comparison uses M+I_h=42/25. Its coupled retained/structural decay polynomial is
\[
 \frac{42}{25}r^2-2r+\frac8{81}=0,
 \tag{32}
\]
whereas the native polynomial is r^2-2r+8/81. At a nonzero native root, their difference is (17/25)r^2. Thus even at this favorable stable point the instantaneous metric replacement is not exact. Equation (22) retains the missing frequency dependence. Both models have an informative slow response, but they have different finite-time kinetics.

## 7. Costs, limits, and the next formation obligation

The four-coordinate realization is exact only for the first variation and the declared retained sensor. It retains one structural link and one initialized memory scalar; it does not eliminate the link or infer a partition. Two fine Gaussian tangent directions are invisible to that linear response, but nonlinear structural forces can read them at second order. The full Gaussian conditional-memory representation still has six evolving coordinates in this two-node model. Equations (24)-(25) bound the discrepancy locally; no finite-amplitude loss threshold has been selected.

The exact force memory is the appropriate fallback when the low-frequency condition fails. The instantaneous constrained metric is justified only with the transient, velocity, acceleration, and regularity bounds in (9)-(14). A positive static precision gap alone does not establish those bounds, and unit Fisher E-relaxation does not speed up merely because a Gaussian target has a larger precision eigenvalue. For a different local kinetic operator, the source's normal-mode rates and the resulting memory poles must be derived again. The newly obtained slow link mode measures inference relaxation, not the Fisher arc clock, the fixed-granularity KL clock, or physical time.

This identifies a narrower next question that advances the original target: in the complete coupled two-channel model, can two proper candidate blocks have low-rank structural-and-observation response memory on an admitted neighborhood, with moving cut links, and can the output of both support a second compatible reduction? The relevant test is the span of hidden structural scores and every required observation response, together with its nonlinear residual and total cost. A small score-memory rank by itself is not permission to discard an exterior interface or recover omitted data from an oracle. Intermediate blocks must be selected or licensed by actual distinctions and persistence, not supplied as the desired answer.

This continuation does not reopen the fifteen exact heterogeneous admissions or relax their all-preparation contract. It makes progress on the separately authorized dynamic continuation: an exact native memory equation, a conditional finite-time approximation bound, an additive linear memory rule for nested maps, and one nonconstant, smaller local response realization with an actual moving link. The full RG objective remains incomplete.

## 8. Execution and evidence

The three substantive passes were source reconciliation and exact memory elimination, stationary first-variation reduction and its finite-time remainder, and reconstruction using exact Gaussian moments and matrix intertwiners. All were performed sequentially; this is not an independent agent review. The [exact calculation](evidence/native-memory/native_memory_exact.py) and [machine-readable result](evidence/native-memory/result.json) record one pinned-CPython-3.14.7 execution. No trajectory integration, parameter sweep, empirical collection, pytest, GPU work, historical producer, Lean work, tamper check, publication, or canonical synchronization was run.

The preservation receipt binds this continuation to the current source files and records unchanged prior results. Source hashes are diagnostic provenance, not proof. The proofs are equations (5)-(25) with their assumptions; the finite instance is additionally supported by the exact moment and intertwining calculation. No formal verification ledger certificate is issued. The daily change log and existing RG progress record are updated with the same scope.

