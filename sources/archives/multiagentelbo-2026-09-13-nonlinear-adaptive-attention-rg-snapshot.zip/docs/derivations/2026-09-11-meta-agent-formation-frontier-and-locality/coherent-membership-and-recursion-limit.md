# Coherent membership from agreement records and the obstruction to a second exact level

September 11, 2026. This resolves the first-level question saved in [the restart draft](coherent-stratum-membership-restart-draft.md). The result is conditional on an explicit proper prior charging coherent strata. It does not establish formation from the preceding continuous prior or complete the RG goal. Under this admission, the same labeled agreement records identify a partition, and a complete marked parent integrates out redundant frames exactly. A separate theorem shows that maximal zero-KL contraction is idempotent with unchanged cut links: it cannot itself generate a second nontrivial level.

The proof gives a four-child, two-channel example with fifteen possible partitions, an explicit posterior over all of them, and a reduced complete-parent sample description. It also identifies two limitations material to the goal. Almost-sure identification need not have a finite expected duration. In the evaluable example, recognition learns membership and links while the marginal laws of the child belief/model coordinates remain unchanged; the example does not supply the intended coupled coalescence dynamics.

## Source continuity and the exact question

The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) already defines the forward-KL Gaussian barycenter in `sec:meta_agent_definition`, states the unresolved post-merge functional in `sec:meta_agent_variational`, and distinguishes covariance averaging from precision pooling in `sec:meta_agent_state_construction`. Its `sec:time_info` and `sec:scale_dependent_time` already discuss Fisher arc length, fixed-granularity KL updates, and conditional slowdown under covariance averaging. Those constructions are not missing and are not reintroduced here as new ideas. They do not identify a partition from the agreement experiment studied below.

The current [wiki formation page](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) and its [September 11 source investigation](<C:/Users/chris and christine/Desktop/Research/sources/manuscripts/multiagentelbo-2026-09-11-formation.md>) distinguish complete operational parents, engineered calibration, and unplanted selection. The [staged-hierarchy investigation](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Staged hierarchy formation and RG composability.md>) retains path-dependent and prior-sensitive examples. Their conditional or tentative status remains in force.

The normalized [local interaction-record source](../../../Theory/05b_local_collective_elbo.tex), `sec:local-interaction-record-model`, permits law-valued belief/model coordinates and binary records with success probability exp(-E) for nonnegative E. The [full-graph source](../../../Theory/07c_full_graph_meta_agent_vfe.tex), `sec:full-graph-vfe-joint`, `sec:full-graph-vfe-nonflat`, and `sec:full-graph-vfe-partitions`, requires one joint before recognition, a common structural channel, all required root/holonomy/cut marks, and a declared membership model. It supplies no unique partition prior. The [existing radial construction](agreement-partition-selection-and-lineage.md), equations (26)-(27), already realizes proper edge-energy priors on full GL(K) links; it is reused below.

Fix one base point c_*, a finite simple undirected graph G=(V,E), and one orientation per edge for its labeled record. Reverse transport is the matrix inverse. The two associated representations share G_0=GL(K,R), acting on R^K and R^{2K}. No base-space transport is introduced. Connected partitions are partitions whose blocks induce connected subgraphs. Let P_G be their finite set and pi_R>0, with sum_R pi_R=1. These masses are introduced model data. Uniform masses on all fifteen K4 partitions are a symmetric example, not a derived universal selector.

## A proper prior on coherent strata with a complete model channel

For Sigma positive definite and c>1, define a belief-law coordinate b and a complete model-law coordinate m by

\[
 b_\Sigma=\mathcal N(0,\Sigma),\qquad
 x\sim\mathcal N(0,c\Sigma),\qquad
 z\mid x\sim\mathcal N\left(x,\frac{c}{c-1}\Sigma\right).
 \tag{1}
\]

The model m is the normalized joint law of (x,z), rather than a second copy of the belief marginal. Its covariance and selected conditional evaluator are

\[
 \operatorname{Cov}_m(x,z)=M(c)\otimes\Sigma,\qquad
 M(c)=\begin{pmatrix}c&c\\c&c^2/(c-1)\end{pmatrix},\qquad
 x\mid z\sim\mathcal N\left(\frac{c-1}{c}z,\Sigma\right).
 \tag{2}
\]

Indeed det M(c)=c^2/(c-1)>0, the conditional mean coefficient is c divided by c^2/(c-1), and the covariance Schur complement equals Sigma. The belief in (1) is the conditional at reference argument z=0. No such local observation is added to the population data. Law-valued coordinates b_i,m_i are distinct from the population recognition law Q over those coordinates. This evaluator identity does not identify b_i with a posterior marginal of Q. The actions are Theta on x and diag(Theta,Theta) on (x,z), so the complete joint and its conditional evaluator transform compatibly.

Draw R with mass pi_R. For each block A draw one c_A from a proper probability on a compact subinterval of (1,infinity). A fixed common c_0>1 is another specialization used later. Independently draw each Sigma_i from a proper full-support SPD law nu; for example Sigma_i=exp(T_i) for a nondegenerate Gaussian symmetric T_i. Put S_i=Sigma_i^{1/2}. For every internal edge draw O_e independently from normalized Haar O(K), and set

\[
 b_i=b_{\Sigma_i},\qquad m_i=m_{c_A,\Sigma_i},\qquad
 \Theta_{ij}=S_iO_eS_j^{-1}\quad(i,j\in A).
 \tag{3}
\]

For each cut draw A_e=B_e^{-1}O_e from a proper bi-O(K)-invariant law tau with full GL(K) support and no mass on O(K), independently of the other cuts, R, c and Sigma. Set

\[
 \Theta_{ij}=S_iA_eS_j^{-1}\quad(i\in A,j\in B,A\ne B).
 \tag{4}
\]

An explicit tau is B=exp(T), with T an isotropic nondegenerate Gaussian symmetric matrix, and independent O Haar O(K). Conjugation invariance of T and Haar invariance prove bi-orthogonal invariance of B^{-1}O. Polar decomposition proves full support on both GL(K) components. B=I has probability zero. All draws are proper probability kernels, so their pushforward P_0 is normalized. This compact Haar measure is not an improper Haar prior on GL(K).

These strata have different dimensions. The dominating probability is the mixture P_0, or its equivalent disjoint-stratum presentation, not one Cartesian Lebesgue measure. No normal-volume coefficient from the earlier atom-free limit is imported. The internal constraints in (3) are prior support, not an outcome of continuous dynamics. Cuts retain full GL(K) support.

### Exact divergences and the orbit obstruction

Write D^b_e=KL(b_i || Theta_ij#b_j) and D^m_e=KL(m_i || diag(Theta_ij,Theta_ij)#m_j), with j transported into i. Set Y=B_e^2, a_ij=tr(M(c_j)^{-1}M(c_i)), and delta_ij=log(det M(c_j)/det M(c_i)). Then

\[
 \begin{aligned}
 D^b_e&=\tfrac12(\operatorname{tr}Y-K-\log\det Y),\\
 D^m_e&=\tfrac12(a_{ij}\operatorname{tr}Y-2K
                 +K\delta_{ij}-2\log\det Y).
 \end{aligned}
 \tag{5}
\]

For the first line, Theta Sigma_j Theta^T=S_i B^{-2} S_i and the relative trace is tr Y. For the second use (2): the relative trace is a_ij tr Y, and the target/source determinant ratio is (det M(c_j)/det M(c_i))^K (det Y)^{-2}. The full 2K model, including its observation coordinate, has been compared.

The minimum over positive-definite Y is

\[
 \min_Y(D^b_e+D^m_e)
 =\frac K2\left[3\log\frac{1+a_{ij}}3+\delta_{ij}\right],
 \qquad Y_* =\frac3{1+a_{ij}}I.
 \tag{6}
\]

The strictly convex trace-minus-log-determinant objective gives Y_*. If lambda_1,lambda_2 are the positive eigenvalues of M(c_j)^{-1}M(c_i), the bracket is log(((1+lambda_1+lambda_2)/3)^3/(lambda_1 lambda_2)). AM-GM on (1,lambda_1,lambda_2) proves nonnegativity with equality exactly when both eigenvalues are one. Similarity to an SPD matrix then implies M(c_i)=M(c_j), hence c_i=c_j. One common transport cannot erase a difference in this model invariant. With common c_0,

\[
 D^m_e=2D^b_e.
 \tag{7}
\]

This is an explicit coupling in that specialization, not independent controllability of arbitrary belief/model energies. Internal edges have both divergences zero; cuts have D^b_e>0 almost surely. Hence R equals the component partition of the joint-zero edge graph almost surely and is measurable from the law/link state. The common stabilizer is S_r O(K) S_r^{-1}. For K=2, diag(1,-1) and the coordinate-swap reflection are noncommuting O(2) examples; their root conjugates preserve both laws. Coherence does not force flat links.

## Common records, identification, and its time cost

At each paired round probe both channels of every edge, independently conditional on W. Every R uses the same observable catalog and schedule:

\[
 \mathbb P(E^x_{e,n}=1\mid W)=p^x_e(W)=e^{-D^x_e(W)},
 \qquad x\in\{b,m\}.
 \tag{8}
\]

For a finite ordered word o let L_o be the Bernoulli product. The joint, evidence, and posterior are

\[
 \mathbb P(dW,do)=P_0(dW)L_o(W),\qquad
 Z_o=\int L_o dP_0,\qquad
 \Pi_o(dW)=Z_o^{-1}L_o(W)P_0(dW).
 \tag{9}
\]

Counting measure is used for o. Conditional record kernels sum to one, so this is one normalized joint for all words. Every finite word has Z_o>0: the singleton stratum has positive mass, and its continuous cuts give probabilities strictly between zero and one almost surely. Also Z_o<=1. Ordered observations acquire no binomial count factors.

**Identification statement.** Let R_hat_n be the components of edges with no observed failure in either channel by round n. For P_0-almost every W, this readout equals R for all sufficiently large n with conditional probability one. Posterior probability of the true R tends to one almost surely under the joint prior/record law and in L1.

Internal edges never fail. A fixed cut remains unfailed through n rounds with probability exp[-n(D^b_e+D^m_e)], tending to zero. There are finitely many cuts, so all eventually fail. Connected internal blocks give the finite-random-time stabilization. In particular,

\[
 \mathbb P(R_{\mathrm{hat},n}\ne R)
 \le \sum_{R_0}\pi_{R_0}
       \sum_{e\in\operatorname{cut}(R_0)}
       \mathbb E_{P_{R_0}}e^{-n(D^b_e+D^m_e)}
 \longrightarrow0.
 \tag{10}
\]

Dominated convergence suffices without a lower bound on cut divergence. Infinite records reveal R almost surely. Apply increasing-sigma-field conditional-expectation convergence to each bounded indicator 1{R=R_0}, with F_n generated by the first n rounds and F_infinity their union sigma-field. The limiting conditional expectation is the indicator because the stabilized readout is F_infinity-measurable. These are exactly the hypotheses of [Durrett, Theorems 4.6.8-4.6.9, printed page 247](https://math.duke.edu/~rtd/PTE/PTE5_011119.pdf#page=255). This is joint-prior almost sure, not a uniform claim at every exceptional latent state. MAP membership is eventually correct, with any fixed tie rule.

An elementary quantitative bound is available. For posterior masses r_A and any observed-data classifier g,

\[
 \mathbb E[1-r_R]
 =\mathbb E\left[1-\sum_A r_A^2\right]
 \le 2\mathbb E[1-r_g]
 =2\mathbb P(g\ne R).
 \tag{11}
\]

Use sum_A r_A^2>=r_g^2 and 1-r_g^2<=2(1-r_g), then (10) with g=R_hat_n. The readout starts at the whole graph and splits as failures appear; it is not coalescence. Its eventual correctness time is not generally observable as a certified stopping time: an apparently internal edge can still fail later. No confidence threshold is introduced.

A failure makes every stratum declaring that edge internal impossible. Exact conditioning handles this support change. Recognition charging an excluded stratum has infinite KL to the new posterior, so a positive-support finite Fisher ODE cannot be applied without a separate support restriction. Consistency does not prove that continuous Fisher flow creates atoms from the old prior.

## Complete marked parent and exact integration of hidden frames

For each R choose a root and spanning tree in every block by a fixed normalized seed rule, such as uniform choice from the finite possibilities. Retain the seeds. They are independent of recognition and records conditional on R. Let U_i be the orthogonal tree product from the root to i, with U_r=I, and define rootward transport

\[
 T_i=S_{r_A}U_i^{-1}S_i^{-1}\quad(i\in A).
 \tag{12}
\]

Internal tree links become identity in their root frame. For cotree edges and each original cut copy retain respectively

\[
 \begin{aligned}
 H_e^{\mathrm{wh}}&=U_i^{-1}O_eU_j,\qquad
 H_e=S_{r_A}H_e^{\mathrm{wh}}S_{r_A}^{-1},\\
 \widehat A_e&=U_i^{-1}A_eU_j,\qquad
 V_e=S_{r_A}\widehat A_eS_{r_B}^{-1}=T_i\Theta_{ij}T_j^{-1}.
 \end{aligned}
 \tag{13}
\]

The complete parent Z consists of R, seeds, root law pairs (Sigma_r,c_A), every H_e, every V_e, and original incidence/record labels. R and seeds identify the deterministic-success internal records. Boundary records use the complete root laws and their own V_e in (5), rather than an average cut transporter. Internal cotree H_e are retained even though the agreement records cannot see their stabilizer action.

**Integration statement.** Conditional on R and seeds, the parent prior is obtained directly by drawing root Sigma_r from nu, c_A from its admitted law, each H_e^wh independently Haar O(K), and each Ahat_e independently tau, then forming (13). No hidden-frame integration oracle is needed for this prior.

Condition on all internal tree matrices. The U_i are fixed. Each cotree O_e is independent Haar, so its left/right multiplication by U_i^{-1},U_j preserves its law. The same argument uses bi-orthogonal invariance for each independent cut A_e. Their conditional joint law is a product independent of the tree matrices. Thus the retained marks remain independent of tree frames after those frames are integrated out. Nonroot Sigma_i are independent nu variables and cancel from (13) and every record probability. Their integral is one. This proves the probability pushforward directly, without a density change across strata or an omitted Jacobian. Conversely, tree matrices and nonroot covariances drawn from these same conditional priors reconstruct the fine state from the parent, including all dependence through R.

Let C be this measurable channel with its normalized seeds and J(dw|z) its prior conditional recovery. Then

\[
 P_0(dw)=P_0^Z(dz)J(dw\mid z),\qquad
 L_o(w)=L_o^Z(z),\qquad
 \Pi_o(dw)=\Pi_o^Z(dz)J(dw\mid z).
 \tag{14}
\]

Here the factorization denotes the augmented fine/seed/parent law and its fine marginal as appropriate; adding an independent normalized seed does not add evidence. Observations remain unchanged. The same C pushes prior, posterior, and recognition. For Q<<P_0 with disintegration Q^Z Q(dw|z), the conditional-KL chain gives

\[
 \mathcal F(Q)
 =\mathcal F_Z(Q^Z)
 +\int \operatorname{KL}(Q(\cdot\mid z)\Vert J(\cdot\mid z))Q^Z(dz),
 \quad
 \mathcal F_Z=-\log Z_o+\operatorname{KL}(Q^Z\Vert\Pi_o^Z).
 \tag{15}
\]

On a finite-KL domain this is ordinary subtraction; the nonnegative KL chain also has its extended meaning before adding the finite evidence term. Exact posterior and matched recognition Q^Z J have zero defect. Arbitrary recognition need not. When a random seed is used, the claim concerns its actual augmented joint and compatible input recognition, rather than silently assigning an arbitrary lifted seed law back to the fine system. Integrating out R or replacing the joint by independent block marginals loses required dependencies.

For passive frame change a_i, Sigma_i becomes a_i^{-1}Sigma_i a_i^{-T}. Whitening induces orthogonal coordinate changes, so (13) obeys the root conjugation and dressed-edge laws of the full-graph source. Proper coordinate priors are pushed as measures; noncompact invariance is not claimed. Relabeling vertices carries the uniform seed rule and exchangeable prior. At internal coherence every transported constituent Gaussian equals the root Gaussian, so both PIFB2's strict forward-KL barycenter and covariance averaging equal this root law. No precision-pooling factor of block size appears.

The local Gaussian evaluator (2) and population record evaluator L_o^Z have different types. Parent recognition is a generally correlated law on the complete retained coordinates, not just its root Gaussian. This distinction is necessary for the exact claim.

### Controlled record closure and the dynamics it does not supply

The generative state here is fixed while records arrive. An action chooses an edge and channel to probe. Policies may use retained information and past actions/records, but not discarded variables unavailable to the parent. The fine transition is identity on W followed by the chosen emission. Since every p_e^x descends through C, the joint next-parent/record kernel is

\[
 \overline K^{(e,x)}(z,dz',de')
 =\delta_z(dz')\operatorname{Bernoulli}(p_e^x(z))(de').
 \tag{16}
\]

Choose the seed once at preparation and retain it throughout; resampling roots at each event would be a different kernel. Equation (16) equals the pushed fine row for every preparation in the admitted support. Induction over common retained-history policies proves complete record/parent path equality. Conditioning commutes with the channel. Queries about discarded individual frames or covariances require J and its reconstruction cost; hidden-state-aware controls are excluded.

This is an exact static-latent observation experiment, not a coupled evolutionary law for child fields and links. Constant latent membership is not evidence of organizational persistence. In the common-c_0 case, L_o is independent of every Sigma_i and nu is the same for every R. Consequently

\[
 \Pi_o(d\Sigma_i)=\nu(d\Sigma_i)
 \quad\text{for every }i\text{ and finite }o.
 \tag{17}
\]

Membership and cuts can be learned while the marginal distributions of the child belief/model coordinates do not move. This is a precise reason the construction does not close the coupled-coalescence requirement. A clock on posterior membership is also a different object from the manuscript's clock along b_i trajectories; no slowdown law follows from (17).

## An evaluable two-channel beta admission

Set all c_A=c_0. Reuse the earlier radial GL construction with cut p~Beta(alpha,beta), alpha,beta>0, uniform Frobenius-unit symmetric U, and independent O Haar O(K). Solve

\[
 \phi(e^{tU})=-\log p,\qquad
 \phi(B)=\tfrac12(\operatorname{tr}B^2-K-\log\det B^2),\qquad t>0.
 \tag{18}
\]

For eigenvalues u_j of U the derivative is sum_j u_j(exp(2tu_j)-1)>0. The function starts at zero and tends to infinity, exponentially if some u_j>0 and at least linearly otherwise. Thus t exists uniquely and measurably. B=e^{tU}, A=B^{-1}O define a proper full-support tau. Conjugation of U preserves its uniform sphere law. For orthogonal L,R, transforming A to LAR conjugates B by L and replaces O by LOR, so tau is bi-O(K)-invariant as required in (14). The excluded point p=1 has zero slab probability but remains in its support; internal p=1 is supplied by R.

The two success probabilities are p and p^2. For ordered counts (s_b,f_b,s_m,f_m), set S=s_b+2s_m and F=f_b+f_m. Exact cut likelihood and evidence are

\[
 L_e(p)=p^S(1-p)^F(1+p)^{f_m},\qquad
 z_e=\sum_{j=0}^{f_m}{f_m\choose j}
       \frac{B(\alpha+S+j,\beta+F)}{B(\alpha,\beta)}.
 \tag{19}
\]

Expand (1+p)^{f_m} and apply [Euler's beta integral, DLMF 5.12.1](https://dlmf.nist.gov/5.12.E1), whose positive-shape conditions hold termwise. This yields a positive finite beta mixture for the cut posterior. The binomial factor comes from algebraic expansion, not from replacing ordered observations by unordered counts. All normalizers are finite and positive.

Let I_e be one if edge e has no failure in either channel, zero otherwise. Then

\[
 z_R=\prod_{e\in\operatorname{int}(R)}I_e
      \prod_{e\in\operatorname{cut}(R)}z_e,\qquad
 Z_o=\sum_R\pi_Rz_R,\qquad
 r_R=\frac{\pi_Rz_R}{Z_o}.
 \tag{20}
\]

A single per-edge cut-posterior bank can serve every R cutting that edge. Draw R according to r_R, its retained roots and cotree marks from their priors, and cuts from (19). Angular conditionals at fixed p retain their prior law. This exactly samples the complete parent posterior. Mixing R creates correlations despite the conditional factorization. Processing all candidate partitions can still cost exponentially in N; the construction does not remove that cost.

### Explicit identification without an asymptotic theorem

True internal edges have n successes in each channel after n paired rounds. A candidate refinement splitting such an edge pays

\[
 a_n=\frac{B(\alpha+3n,\beta)}{B(\alpha,\beta)}\longrightarrow0.
 \tag{21}
\]

Apply dominated convergence to p^{3n}. After every true cut has failed, any nonrefining candidate has zero likelihood: a connected candidate block crossing true blocks contains a path crossing a true cut and declares that cut internal. Each proper connected refinement splits at least one true internal edge. True-cut evidence is common to remaining refinements and cancels in their ratios. Thus for every admitted fixed latent state with all cut probabilities below one, (20) directly gives r_(true R) to one almost surely. This pointwise result belongs to the factorized beta admission, not every prior of the general theorem.

On K4 take pi_R=1/15 and alpha=beta=1. Suppose 01 and 23 have n successes in each channel and all other edges have a failure. Only {01,23}, its two three-block refinements, and singletons survive. Relative likelihoods are 1,a_n,a_n,a_n^2, yielding

\[
 r_{\{01,23\}}=\left(\frac{3n+1}{3n+2}\right)^2.
 \tag{22}
\]

At n=2 set every cut's ordered counts to (1,1,2,0); its evidence is 1/42. Absolute evidence and posterior masses are

\[
 Z_o=\frac1{15}\left(\frac1{42}\right)^4\left(\frac87\right)^2
     =\frac4{142943535},\qquad
 (r_2,r_{3a},r_{3b},r_4)
 =\left(\frac{49}{64},\frac7{64},\frac7{64},\frac1{64}\right).
 \tag{23}
\]

This is a possible-word calculation covering all fifteen alternatives, not a new dataset, simulation, or discovery claim about the heterogeneous experiment. No pairing is supplied to the inference rule. The chosen word illustrates conditional identification without a typicality claim.

Let T_e be the first paired round with any failure on a true cut. For its uniform prior,

\[
 \mathbb P(T_e>n)=\int_0^1p^{3n}dp=\frac1{3n+1},\qquad
 \mathbb E T_e=\sum_{n\ge0}\frac1{3n+1}=+\infty.
 \tag{24}
\]

T_e is still finite almost surely. With m independent true cuts, readout error probability is exactly 1-(1-a_n)^m: internal edges remain connected, and any unfailed cut joins true blocks. Here m=4 for two pairs. Eventual correctness therefore supplies no finite expected observation budget under this proper prior. Changing its near-coherence tail would be a new prior choice.

## Complete-parent sample cost with membership uncertainty retained

Let s=K(K+1)/2 and h=K(K-1)/2. A stratum R has N vertices, b blocks, e_int internal edges, e_cut cuts, and beta_G=e_int-N+b. Independent continuous sample coordinates before and after frame integration total

\[
 d_{\mathrm{fine}}=Ns+e_{\mathrm{int}}h+e_{\mathrm{cut}}K^2,
 \qquad
 d_{\mathrm{parent}}=bs+\beta_Gh+e_{\mathrm{cut}}K^2,
 \qquad
 d_{\mathrm{fine}}-d_{\mathrm{parent}}=(N-b)K^2.
 \tag{25}
\]

Variable c_A adds b coordinates on both sides. The full 2K Gaussian model shares the parameters in (2); it is not an arbitrary second covariance. Discrete orthogonal components, R, graph labels, counts, root/tree seeds and their probability/encoding costs occur on both sides. The difference counts the eliminated N-b covariances and N-b orthogonal tree matrices. It is an intrinsic sample-description count, not minimal storage, Fisher rank, a memory benchmark, or total inference speedup.

For K=2 on K4, conditional on two pairs, the fine count is 30 and the parent count 22. Direct parent sampling uses two SPD roots, zero internal Haar matrices, and four cuts; fine coherent-stratum sampling uses four SPD covariances, two internal Haar matrices, and four cuts. Beta inversion and matrix functions still cost work. The baseline is the optimized 30-coordinate coherent stratum, not the unrelated 36-coordinate singleton stratum.

For the uncertain posterior (23), the two three-block refinements have counts 33 and 29, while singletons have counts 36 and 36. Therefore

\[
 \mathbb E[b\mid o]=\frac94,\qquad
 \mathbb E[d_{\mathrm{fine}}\mid o]=\frac{123}4,\qquad
 \mathbb E[d_{\mathrm{parent}}\mid o]=\frac{95}4,
 \qquad \mathbb E[d_{\mathrm{fine}}-d_{\mathrm{parent}}\mid o]=7.
 \tag{26}
\]

Both samplers retain the four posterior masses and the same six original edge-record banks. No MAP substitution occurs in this count. Posterior entropy/codelength of R is shared, and additional query costs must be added separately. Representation does not improve evidence: (14)-(15) preserve Z_o and the unrestricted optimum VFE. This is not a derivation of PIFB2's unspecified organizational overhead or licensing preference.

## Why the exact coherent quotient stops after one maximal level

**Idempotence statement.** Fix one fine law/link configuration, use the same belief/model comparisons, and preserve each original cut through its dressed mark. Contract every connected component of the joint-zero edge graph, with internal tree paths carrying zero discrepancy. The resulting graph has no joint-zero edge between distinct parents. Applying the same maximal-coherence rule again yields only singleton parents at that level.

For a cut e from B to A, internal tree transports preserve the compared law pairs. Common-pushforward invariance gives

\[
 D^x_e(\mathrm{fine})
 =\operatorname{KL}\big(b_A^x\Vert (V_e^x)_{\#}b_B^x\big)
 =D^x_e(\mathrm{parent}),\qquad x\in\{b,m\}.
 \tag{27}
\]

Here b_A^b is the root belief law, b_A^m the root complete model law, and V_e^m=diag(V_e,V_e). If both parent discrepancies were zero, that fine cut would connect distinct maximal joint-zero components, a contradiction. Multiple cut copies are essential. Averaging them may create a different comparison but is not this exact map. Internal stabilizer holonomies do not alter the argument. With a nonmaximal coherent first refinement, repeated contraction can reach the same maximal component; coherence alone supplies no preference for that intermediate refinement. This limits the fixed-state rule, not time-evolving or approximate hierarchies.

There is also an inference obstruction. If a higher organization H is appended through p(dH|R), and the conditional fine experiment given R does not depend on H, then

\[
 \mathbb P(dH\mid R,o)=\mathbb P(dH\mid R).
 \tag{28}
\]

The likelihood P(o|R) cancels in Bayes' formula. Uncertainty in R may change the marginal mixture over H but supplies no additional identification conditional on R. A normalized representational pushforward, fixed whole-system grandparent, or higher index stored only as an auxiliary prior variable does not satisfy the second learned-level requirement. An H-dependent fine joint would be a different admission and must exhibit that dependence rather than merely add an index.

## Result, verification boundary, and next obligation

The proof supplies a proper coherent-stratum prior, full two-channel typing, conditional membership consistency, exact marked-parent integration, record-path closure for a static-latent experiment, and an explicit posterior/sample-cost calculation. Its output is learned structural membership under that prior. Equations (17), (24), and (27)-(28) prevent promoting it to the dynamic hierarchy. Prior atoms, frozen latent state, coupled energies in the evaluable example, unchanged belief/model-coordinate marginals, potentially infinite identification time, and second-level idempotence are material limitations.

The companion exact-arithmetic script is a finite coefficient/probability check with separately recorded output. It cannot prove the general Haar, conditional-expectation, path, or idempotence statements. No old scientific run, data collection, production/configuration edit, base transport, vault write, Lean proof, or tamper check belongs to this construction. The original fifteen negative admissions remain intact.

The next continuation must resolve a different step: derive a source-admitted evolution of the actual belief/model/link law in which coherent subblocks can become useful before the whole system, and establish the complete parent path law while cuts evolve. Read the existing fast/slow and PIFB2 adiabatic-elimination constructions first. The decisive result is a controlled continuation or explicit finite-horizon residual retaining the necessary normal modes; fixed-state zero-KL contraction and a clock relabeling cannot supply it. Approximation loss and each retained resource can be reported as a frontier without inventing a tolerance or penalty. The full RG goal remains incomplete.

Execution details are recorded in [the finite arithmetic result](evidence/coherent-membership/coherent-membership-exact-result.json) and [the execution/source inspection](evidence/coherent-membership/execution-and-inspection.json). These artifacts distinguish executed finite identities from the general written proofs.
