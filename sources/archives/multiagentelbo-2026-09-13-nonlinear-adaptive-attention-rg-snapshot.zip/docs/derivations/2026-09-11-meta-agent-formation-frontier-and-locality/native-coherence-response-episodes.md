# Native hierarchy intervals with a collective-response guarantee

September 12, 2026. The existing native hierarchy now has an explicit, uniform prediction-error guarantee for a declared collective-input task. In the current Gaussian/translation family, the later merge-preferred interval has a strictly smaller response-error moment than the earlier split-preferred interval. The calculation uses the complete native joint law and the already certified trajectory; it does not condition on the preferred ancestry or integrate another trajectory.

The guarantee is conditional on the same model and input contract. It does not establish that merging caused the improvement, select an operational loss tolerance, or define an individual sampled-state process. The [law-level derivation](native-coherence-response-law.md) gives the probability, moment, and continuity proofs. The [parent-interface derivation](native-response-parent-interface.md) identifies the complete information needed by successive descriptions.

## The same probe on every ancestry

Use the fixed geometric candidate A={0,1}, B={2,3}, with roots 0 and 2 and internal trees 01 and 23, for every fine draw. The generative ancestry H remains a random variable in the native law. It is not replaced by this output partition. Each query chooses an original cut and a channel, displaces all law means in one geometric block relative to the other by h, and reads the original Bernoulli agreement probability. Links and the baseline draw are held fixed. The two oppositely directed cuts receive opposite signs of h.

For each channel, the omitted contrast is eta=-(r01+r23)/2. Let M(t)=E_Qt||eta||². This expectation includes every ancestry/decorated tree in Q_t and its actual posterior weight. The model-posterior expectation is computed separately at the current model parameters, with its own normalization. A fixed geometric probe is an explicitly chosen diagnostic candidate, not a newly discovered partition or an asserted physical actuator.

The current carrier retains each exact unperturbed probability p_e(0). A normalized approximation that uses it is

\[
 \widehat p_e(h)=\operatorname{clip}_{[0,1]}
 \left[p_e(0)+\phi(d_e+s_eh)-\phi(d_e)\right],
 \qquad \phi(v)=\exp(-\|v\|^2/2).
\]

It is exact at zero input. The mixed finite-difference identity and the bound ||Hess phi||<=1 give probability error at most ||h|| ||eta||. Projection onto [0,1] cannot increase the error. This is a normalized query approximation; it does not replace the generative prior, recognition law, native update, or full VFE force. No derivative claim is made through the clipping boundaries.

For K queries under a common adaptive policy that uses only the query information retained in both descriptions and the preceding transcript, where the policy may choose either channel and every queried input satisfies ||h||<=R, coupling gives

\[
 \operatorname{TV}(\mathcal L_{Q_t}(\text{fine transcript}),
                    \mathcal L_{Q_t}(\text{parent transcript}))
 \le\min\{1,KR\sqrt{2M(t)}\}.
\]

The factor two allows a channel choice informed by retained state or previous answers. A channel schedule fixed independently of that information admits sqrt(M) instead. The fine latent draw is frozen during this finite-query experiment. Repeating the bound at successive native times does not turn it into a theorem about one hidden draw evolving through those times.

## Uniform bounds on the existing intervals

The existing exact reference prior has O/P support and includes all twenty of their root/tree decorations, represented by seven distinct covariance matrices. It is the same evidence-defined boundary reference used in the [common-prior hierarchy theorem](common-prior-native-hierarchy-episodes.md), not a newly chosen prior. The recognition count-memory coordinate remains active. No alternative ancestry is dropped from that reference during the response readout.

The following intervals are rounded outward from the new exact rational enclosures.

| Native interval | Law | M(t), omitted-vector moment | T(t), internal mismatch moment |
| --- | --- | --- | --- |
| [5,7], split-preferred | Recognition | [0.1812, 0.1964] | [0.3648, 0.3967] |
| [5,7], split-preferred | Current model posterior | [0.1747, 0.1903] | [0.3515, 0.3837] |
| [35,40], merge-preferred | Recognition | [0.1194, 0.1217] | [0.2374, 0.2422] |
| [35,40], merge-preferred | Current model posterior | [0.1194, 0.1216] | [0.2373, 0.2420] |

Here T=E[-log p01-log p23] in one channel. It bounds the mean squared retained-length certificate, while M also uses the actual cross-correlation of the two residuals. The two channels have the same unconditional moment by symmetry, although mixing over their common ancestry correlates their law.

For both recognition and the current model posterior, the simpler strict upper bounds yield

\[
 \operatorname{TV}\le\min\{1,0.628 KR\}
       \quad (5\le t\le7),\qquad
 \operatorname{TV}\le\min\{1,0.494 KR\}
       \quad (35\le t\le40).
\]

These are upper bounds on error, not measured errors or lower bounds. No value of R, K, or an acceptable loss is selected by writing this curve. For large KR the guarantee can be uninformative. The unclipped barycenter approximation has the separate unrestricted-input, per-query coefficients below 0.381 and 0.300 for adaptive channel choice, respectively; it does not exploit exact agreement at zero input.

The largest later M is below the smallest earlier M for each law. This proves a strict improvement in this particular moment between the two intervals. Both learning and ancestry weights change; the calculation supplies no counterfactual causal attribution to formation or merging.

The displayed upper bounds have strict slack. The finite Gaussian moment ratios and the native field depend continuously on the positive variance parameters and ancestry prior near the existing compact trajectory. The law-level report therefore extends these bounds, together with the earlier strict hierarchy-preference windows, to a nonempty open family of fixed priors assigning positive mass to all twelve connected ancestries. This is an analytical continuity statement, not a numerical sweep over those priors or a quantitative radius for that open set.

## The next parent preserves this query interface

The [complete interface construction](native-response-parent-interface.md) starts from the fixed two-parent output with 28 displayed real coordinates. A merged root retains the original sufficient statistic, its four-vector mean, the four-vector loop L, and one four-vector d12. It reconstructs d30=-L-d12. Thus its 24 coordinates evaluate the same old first-parent cut probabilities and every anchored query exactly, for either actual directed merger tree and every generative ancestry. The native common conditional, negative ELBO and Fisher matrices survive the push. Direct and staged maps agree for each retained tree history; the two different trees need not produce the same root coordinate.

The root retains two labeled input ports and the required ancestry, geometry and controller records. For policies using only information common to both query interfaces, the merge adds zero prediction error. Arbitrary access to discarded first-stage geometry requires additional retained information. Clipping defines a normalized frozen-query kernel, not a sequential actuation law.

The root saves four displayed real coordinates relative to the two-parent probe. Its expected saving relative to the fine native carrier is 12+4 E k_H, which exceeds 19.76 throughout the later interval under both reference laws. This is a new storage consequence for the fixed-probe map. The earlier ancestry-dependent panel's eighteen-field resource license and regime probabilities do not transfer to its optional merger panel. Complete prices include formation, metadata, evaluator, controller and execution costs; the bare split-to-root storage saving 4c is a total saving only when it exceeds their net extra cost.

Consequently, retaining these response queries does not require two separate intermediate geometric parents. A root can preserve the same interface with fewer displayed coordinates while remembering the two ports. Operational preference and formation dynamics still need their own arguments.

## Exact readout and execution boundary

The [moment coefficient calculation](evidence/native-coherence-response/response_moments.py) constructs the new rank-one and diagonal numerator polynomials for all 112 existing failure-mask terms. It reuses the saved evidence-denominator coefficients. At unit variances, each new term is checked against a separate Fraction covariance inverse, and the unchanged evidence normalizer matches the saved exact value. The [coefficient result](evidence/native-coherence-response/moment-polynomials.json) passed once in 0.2993387000024086 seconds under pinned CPython 3.14.7. The new unit full-law M is approximately 0.2159921243; its exact fraction is saved.

The [window readout](evidence/native-coherence-response/enclose_response_windows.py) uses the already certified path, global path-error bound, 128-bit outward dyadic arithmetic, and order-10 derivative jets. It directly reconstructs each stored interval polynomial from the saved dense trajectory coefficients and verifies equality before use. It treats the unknown path error as a bounded parameter in the output function, not as a differentiable error trajectory. Existing path and regime-window source hashes are checked first.

All seventeen intervals covering [5,7] and forty-one covering [35,40] passed in 12.642194700005348 seconds. The [window result](evidence/native-coherence-response/moment-window-enclosures.json) contains every rational moment enclosure and the exact constants behind the displayed bounds. Signed failure expansions are evaluated algebraically; they are not interpreted as mixtures with negative probabilities. Positivity and normalization follow from the original positive likelihood integral.

The [independent reconstruction](native-coherence-response-reconstruction.md) checks the derivation, scripts, retained evidence, interface composition, and scope. [Inspection](evidence/native-coherence-response/inspection.json) records document and preservation checks. No earlier scientific producer, trajectory, model configuration, dataset, full suite, GPU, Lean proof, tamper check, vault edit, or publication was run or changed.

## What this adds to formation

The coherence direction now supports an explicit response guarantee throughout two intervals of the existing coupled native law, and the same guarantee passes to a 24-coordinate root. It remains necessary to compare the complete descriptions under a declared workload and loss requirement. The immediate mathematical continuation is to extend this fixed-probe result to the actual ancestry-dependent output of the existing hierarchy channel, retaining its own cuts, tree radii, input ports and all ancestry probabilities. The current window names describe that older channel; they do not prove that the new fixed probe was selected. A prediction guarantee alone does not show that intermediate geometric organization is operationally preferable. The original fifteen negative finite admissions and their separate fresh-selection gate remain unchanged.
