# Independent stochastic-realization reconstruction

September 11, 2026. **Result: reconstructed proof with checked hypotheses.** For the unchanged heterogeneous four-spin record experiment, any exact stochastic initialization on a finite complete carrier, followed by a common conditional predictor, requires at least two, four, or eight retained preparation states for a singleton, pair, or triple, respectively, when its exterior preparation is fixed. Globally, the general bound is fifteen to sixteen states. Sixteen is necessary under the additional assumption that every latent decoder law is a mixture of the original fine-preparation laws.

This is an independent reconstruction of the parity, rank, and factorization argument, with one independently implemented exact finite-minor check. The later comparison with [stochastic-local-admission.md](stochastic-local-admission.md) and [stochastic-realization-analysis.md](stochastic-realization-analysis.md) found no defect in their scoped proper-block theorem. Neither the finite rank result nor the conditional fine-lift result settles unrestricted positive fifteen-state realization.

## Target, supplied data, and introduced hypotheses

The supplied source is the saved experiment at revision ed8f22a56df353b1535744509cc23fae46d5813c. Its fine state space is \(Y=\{-1,+1\}^4\); the couplings on edges \(12,13,14,23,24,34\) are \(1/16,1/12,1/10,1/8,1/7,1/6\). The action is a field \(a\in\{-1/5,+1/5\}\), and the destination-parity sensor has strength \(\eta=3/4\). Every deterministic fine preparation is available. The specified record experiment has no informative pre-reset observation. Every action/record word through horizon four is an admitted test.

The realization hypothesis is separate from these source data. For each nonempty proper block \(A\subset\{1,2,3,4\}\) and each fixed exterior value \(u\in\{-1,+1\}^{A^c}\), choose one row-stochastic encoder \(E_u(s\mid x)\), with \(x\in\{-1,+1\}^A\) and \(s\) in a finite set of size \(k_u\). The encoder is fixed before the future test is selected. Conditional on \(s,u\), the reduced system has one normalized future predictor common to all \(x\). Exactness means equality of every admitted record-word probability for every local preparation and every admitted open-loop action sequence. A common policy depending on visible history is allowed. No first-order Markov assumption is needed for the lower bound.

All preparation dependence accessible to the future predictor is included in the joint initial carrier. In particular, a random seed with preparation-independent marginal may still encode preparation information through its correlation with \(s\); then the accessible pair must be counted. A decoder supplied the whole preparation-dependent probability vector as a separate input is outside the sampled-state factorization. No claim about arbitrary nonlinear continuous-state dimension is made.

The extra assumption used only for the global sixteen-state corollary is a row-stochastic fine lift \(D\), independent of the future test, such that every latent decoder's test law is \(G=D O\), where \(O\) is the fine test matrix defined below. This stronger assumption is not silently added to the general realization problem.

## Direct construction of the record matrices

Write \(J_{ii}=0\), and let \(T_{a,i}\) reset site \(i\). For source \(y\) and destination \(z\),

\[
 T_{a,i}(y,z)
 =\mathbf 1_{\{z_{-i}=y_{-i}\}}
 \frac{1+z_i(a+\sum_{j\ne i}J_{ij}y_j)}2,
 \qquad
 T_a=\frac14\sum_{i=1}^4T_{a,i}.
\]

The maximum incident coupling sum is \(43/105\), attained at site four. Thus the reset mean has absolute value at most \(1/5+43/105=64/105<1\). Every reset probability is positive on its permitted destination pair, and summing that pair gives one. Hence \(T_a\) is row-stochastic.

For parity \(p(y)=y_1y_2y_3y_4\), the destination sensor and emitted matrices are

\[
 b_e(z)=\frac{1+(3/4)e p(z)}2,
 \qquad
 K_{a,e}=T_a\operatorname{diag}(b_e),
 \qquad e\in\{-1,+1\}.
\]

Each \(b_e\) is either \(1/8\) or \(7/8\), and \(\sum_eK_{a,e}\mathbf1=\mathbf1\). These formulas match the source's destination-major, record-minor emitted-row indexing. For a word \(w=((a_1,e_1),\ldots,(a_h,e_h))\), its column is

\[
 t_w=K_{a_1,e_1}\cdots K_{a_h,e_h}\mathbf1,
 \qquad t_{\varnothing}=\mathbf1.
\]

Matrix multiplication here follows chronological order. This can also be evaluated from right to left, which is the recursion used in the independent checker.

## The unique relation and its exact finite witness

For fixed \(i\) and fixed \(y_{-i}\), the value \((T_{a,i}f)(y)\) is independent of the old sign \(y_i\): the reset mean omits \(y_i\), and the destination overwrites it. The two summands with \(y_i=\pm1\) therefore cancel in the parity-weighted sum. For every function \(f:Y\to\mathbb R\),

\[
 \sum_y p(y)(T_{a,i}f)(y)=0,
 \qquad p^\top T_a=0,
 \qquad p^\top K_{a,e}=0.
\]

Also \(p^\top\mathbf1=0\). For every nonempty word, its first matrix is annihilated by \(p^\top\). Consequently all finite-word columns belong to the fifteen-dimensional hyperplane \(p^\perp\). This is an all-horizon analytical upper bound; it is not extrapolation from a finite numerical test.

For the lower bound, use precisely the fifteen original test columns retained in [observable-rank.json](evidence/local-admission/observable-rank.json). Let \(\alpha=(0,0)\), \(\beta=(0,1)\), and \(\gamma=(1,0)\), where action ordinal zero means field \(-1/5\), action ordinal one means \(+1/5\), and record ordinals zero and one mean signs \(-1,+1\). In the retained order, the words are

\[
 \varnothing,\ \alpha,\ \gamma,\ \alpha\alpha,\ \alpha\gamma,\
 \beta\alpha,\ \beta\gamma,\ \gamma\alpha,\ \gamma\gamma,\
 \alpha\alpha\alpha,\ \alpha\alpha\gamma,\ \alpha\beta\alpha,\
 \alpha\beta\gamma,\ \gamma\alpha\alpha,\ \alpha\alpha\alpha\alpha.
\]

Call their sixteen-by-fifteen matrix \(O\). The checker recomputed all 240 entries directly from the source with exact rational arithmetic and matched every saved entry. It then formed one fixed fifteen-by-fifteen minor \(M\), omitting the last lexicographic preparation \((1,1,1,1)\). The prime was fixed in the checker before execution as 1009. Trial remainders for every divisor from 2 through 31 are nonzero, and \(31^2<1009<32^2\), so this modulus is prime. Every denominator in \(M\) is nonzero modulo 1009.

The separately implemented modular elimination returned

\[
 \det(M\bmod1009)=85\ne0.
\]

Reduction is a ring homomorphism from rationals whose denominators are coprime to 1009 into the field with 1009 elements. It commutes with the determinant polynomial. Thus a zero rational determinant would reduce to zero, contradicting the computed value 85. This is an exact certificate that \(\operatorname{rank}O\ge15\); it uses no tolerance.

Combining the minor with the analytical upper bound gives

\[
 \operatorname{rank}O=15,\qquad
 \ker(O^\top)=\operatorname{span}\{p\},\qquad
 \operatorname{span}\{t_w:w\text{ any finite word}\}=p^\perp.
\]

The proof does not need the producer's separate ranks at smaller horizons or its sixty invariance checks. The independent calculation checked the one load-bearing minor, not those additional claims.

As an exact consequence, two initial distributions \(\mu,\nu\) have identical entire future record experiments if and only if \(\mu-\nu=c p\) for some real \(c\), subject to both distributions remaining nonnegative. Necessity follows from \(O\); sufficiency follows from the all-word annihilation. For example, all \(\mu_c(y)=1/16+c p(y)\), with \(|c|\le1/16\), have the same future record laws. This equality of mixtures does not merge any two deterministic preparations.

## Proper-block stochastic lower bound

**Theorem.** Under the realization hypotheses above, for every nonempty proper \(A\) and every fixed \(u\),

\[
 k_u\ge 2^{|A|}.
\]

**Proof.** The \(m=2^{|A|}\) rows corresponding to \((x,u)\) form a proper subset of the sixteen rows of \(O\). Any linear dependence among these rows extends by zero on the omitted rows to an element of \(\ker(O^\top)\). It must equal \(c p\). Since \(p\) has no zero coordinate and at least one row was omitted, \(c=0\). Thus the restricted test matrix \(O_u\) has row rank \(m\).

Let \(G_u(s,w)\) be the common decoder's probability of test \(w\), conditional on its complete initial state and fixed exterior. Conditioning on the stochastic initialization gives, entry by entry,

\[
 O_u(x,w)=\sum_s E_u(s\mid x)G_u(s,w),
 \qquad O_u=E_uG_u.
\]

Every column uses the same \(E_u\); this is where fixing the encoder before choosing the future test matters. The column space of the product is contained in the column space of \(E_u\), which has at most \(k_u\) columns. Therefore

\[
 2^{|A|}=\operatorname{rank}O_u
 \le\operatorname{rank}E_u\le k_u.
\]

This proves the theorem. Identity encoding attains the bound with the unchanged source predictor and retained exterior. If all exterior values remain distinct states of a retained random interface, summing the lower bounds over its \(2^{|A^c|}\) disjoint fibers gives at least sixteen joint local-plus-exterior states.

A common history policy does not invalidate the argument. For any realized action-record path, its mass is the open-loop record probability multiplied by the product of that policy's action probabilities at the visible prefixes. The latter factors are common across the compared preparations. Equality of open-loop laws therefore gives equality under every such policy. A policy that directly reads discarded preparation information changes the interface and is not covered.

## Global scope and conditional sixteen-state result

Globally, \(O=E G\) gives only \(k\ge15\), while the original source gives an exact normalized sixteen-state model at every horizon. Thus the minimum lies in \(\{15,16\}\). Rank alone proves neither a positive fifteen-state construction nor its nonexistence.

The additional fine-lift assumption yields a stronger exact conclusion. Suppose \(E\) and \(D\) are row-stochastic of sizes \(16\times k\) and \(k\times16\), respectively, and \(O=E D O\). Each row of \(ED-I_{16}\) lies in \(\ker(O^\top)\). Hence there are scalars \(c_x\) with

\[
 (ED-I_{16})_{xy}=c_x p(y).
\]

For each fixed \(x\), the off-diagonal indices \(y\ne x\) include both parity signs. Nonnegativity of \(ED\) at those indices forces simultaneously \(c_x\ge0\) and \(c_x\le0\). Thus \(c_x=0\) for every \(x\), so

\[
 ED=I_{16},\qquad k\ge\operatorname{rank}(ED)=16.
\]

Equivalently, all sixteen rows of \(O\) are extreme points of their convex hull. A convex expression of one row using the others would give a dependence with only one positive coefficient, whereas either nonzero multiple of \(p\) has eight positive and eight negative coefficients.

For a fixed prior \(\pi_x>0\), the Bayes initial lift of \(E\) is

\[
 D_{sx}=\frac{\pi_x E_{xs}}{\sum_z\pi_z E_{zs}}
\]

on every reachable state \(s\); states with zero denominator are unreachable for all preparations and can be removed. This lift is row-stochastic, so the sixteen-state conclusion applies when the stipulated decoder is \(G=D O\). Merely using Bayesian terminology, or merely requiring decoder probabilities to be positive, does not impose this fine-lift restriction.

For a partition into at least two nonempty proper child blocks, the original product cardinality is sixteen. If one factor of original size \(n\le8\) shrinks to at most \(n-1\) and all other factors do not grow, the total size is at most

\[
 16\frac{n-1}{n}\le14.
\]

Such a common joint finite predictor cannot reproduce a rank-fifteen preparation experiment. Extra accessible memory or shared interfaces must be included in its total carrier.

## Execution, provenance, and remaining obligation

The compared root note stochastic-local-admission.md has SHA-256 50fb1f38e6368e08d2e64a9db0fe446456f5ca413083e0e1266a1ac2ee6d9122, including the final fixed-encoder, joint-memory, retained-exterior, and fine-lift qualifications. The compared investigator note stochastic-realization-analysis.md has SHA-256 2408553e9c506e0cb43779bd2bbe186f3b32dba1b27cf0e961c4b47141aca908. These are the exact revisions compared with the independently reconstructed argument.

The independent checker ran once, successfully, under pinned CPython 3.14.7:

    & 'C:\tmp\rg-v2-phase13-py3147-runtime-20260901\python.exe' -I -B 'C:\tmp\elbo-cover-20260908\docs\derivations\2026-09-11-meta-agent-formation-frontier-and-locality\evidence\local-admission\check_observable_minor.py'

Its recorded in-script elapsed time was 0.011991900002612965 seconds. It performed one modular determinant and recomputed the selected 240 rational entries. It verified the saved configuration against the current THEORY dictionary and matched the current two source-file hashes against the original rank certificate. It did not rerun the rank producer, enumerate a new test panel, resample observations, run pytest, or change source/configuration/data.

The complete 225-entry rational minor, its residue matrix, fifteen modular pivots, denominator list, primality checks, source bindings, and runtime are retained in [observable-minor-check.json](evidence/local-admission/observable-minor-check.json) and the identical [log](evidence/local-admission/observable-minor-check.log). Their SHA-256 is f05af27609d5bf589d0e4959bb10c4de489821f21cb50a691abeaa520bc3b281. The [checker](evidence/local-admission/check_observable_minor.py) SHA-256 is 13e5e7758da386366b9c73f57855944272d89a7e6f6bfb05f5780ab7e5321524. The input observable-rank certificate SHA-256 is 1563a62d49adfa907aa12cbfeec0563e774a45dc4adec549272108c567b79db2.

The independently inspected source hashes are 97554c5d23af8b03569c4fe6ea51756c01bafc35e649e22debbdb5185e153238 for finite_data_formation.py and 59a222c5dc3ce5f55e2e1983e3a283eb468d0d9a94442e2235a98c0bc6e211b5 for finite_formation.py. The saved results hash is 8a1ac816e1692d7d14cfb857765cb817dd7955088e616f7427e012183947084f; the active profile hash is 7e6ef228eb653e325833c4d1e86863f715e34da131a0c6370b269303414334f7.

The proper-local finite-carrier theorem is established by the derivation and exact minor. No unresolved obligation remains for that scoped theorem. The smallest unresolved global question is existence of an exact normalized fifteen-state common causal realization whose latent continuation laws need not lie in the fine-preparation convex hull. For the narrower homogeneous Markov category, a concrete next step would be to construct or exclude nonnegative emitted matrices and a row-stochastic encoder satisfying the controlled intertwining and normalization equations. That additional search was not run and is not needed for the proper-local negative result. These results do not establish a useful compressed RG hierarchy.
