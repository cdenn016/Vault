# Retrospective frontier and preparation-loss derivation

The saved experiment reproduces without resampling: all 288 validation NLL, binary Brier, and penalized scores agree exactly in floating-point output with the retained results (declared acceptance tolerance 1e-12). All complete rankings, all nine selected indices (30), and all nine selected rational transition tables agree. The endpoint result is retained. The searched family consists of one training-derived partition per cardinality, with base and previous-record-conditioned transition models, rather than all partitions of sixteen configurations or subsets of four children.

## Reproduction and numerical scope

`evidence/frontier/analyze.py` reads only saved ladders, rows, and episodes. It calls `fit_parent` and `score`, not either collection runner or `partition_ladder`. JSON arrays are converted to tuples; rationals are compared as `Fraction` values. Ranking ties use `(criterion,effective_states,index)`, exactly as the source. The complete reconstruction gate is written before held-out or oracle calculations. `reconstruction.json` records runtime, input hashes, and maximum score difference zero. The pinned CPython 3.14.7 interpreter executed all analysis serially with `-I -B`. No pytest, GPU, observation collection, or production edit occurred.

`validation-frontier.csv` contains 288 candidates and all resource coordinates. `heldout-frontier.csv` contains 294 candidate/cell rows, exactly six environment/policy cells for each frontier candidate and the two base endpoints. `preparation-attribution.csv` contains 228 rows, exactly six cells for 38 preselected candidate instances. `attribution-episodes.csv` retains their 58,368 paired episode triples. The deterministic attribution rule was fixed before oracle inspection: base constant (30), base identity (0), then at most three distinct nonendpoint frontier partitions ordered by validation NLL and candidate index. `oracle-selection.json` records every choice.

The primary Pareto frontier minimizes validation NLL and log2 effective state count. It is not a multidimensional resource frontier. Circles in the transition-storage plot still mark this same primary frontier, not a separate storage frontier. Its sizes, in budget-major and seed order, are 1, 5, 2; 3, 8, 5; 5, 7, 6. Strict componentwise comparison defines dominance; equal coordinates retain every tied index. The separately exported costs are k-1 continuous filter coordinates, one observed memory bit when present, 4k² stored base entries (tripled with two memory contexts), and 2k(2k-1) normalized-row coordinates (also tripled). These row coordinates are neither effective degrees of freedom nor Fisher rank. The declared partition representation uses sixteen fixed-width labels of ceil(log2 k) bits, with the ambient sixteen-state carrier and k supplied out of band; this is a representation convention, not a minimal description length. At k=1 the label string needs zero bits under this convention.

For each candidate i, `coefficient-intervals.csv` solves all linear inequalities L_i+lambda c_i <= L_j+lambda c_j over lambda>=0. A candidate may be Pareto yet absent from every lower-envelope interval. Interval endpoints include exact ties in the computed floating loss/cost coordinates; the original lexicographic tie rule resolves selection there. This is retrospective sensitivity, not an externally justified replacement coefficient. The original 0.005 selects the base constant endpoint in every run. Some memory candidates remain nondominated; memory constant index 31 even lies on the lower envelope for seed 4307 at budget 128. Rejection at the declared coefficient does not establish universal dominance of memory models. The greatest constant-onset coefficient across runs is approximately 0.002997, below 0.005.

The binary Brier convention is (p(E=+1)-1{E=+1})², which equals (1-p(observed record))² for either observed binary outcome. It omits the factor two used by the sum over both class coordinates convention. Paired differences use each complete four-event episode as one evaluation unit, divide its log loss by four, and compare the same episode across models. Reported paired SD and SE are descriptive, conditional on fitted models; SE is sample SD/sqrt(256). No confidence interval or selection-adjusted inference is claimed. Validation was used to choose the frontier and held-out cells were already inspected historically. Budgets, policies, and seeds are not independent physical replicates.

## Exact preparation identity

Fix a training dataset D and hence a deterministic map h=h_D on a finite state space Y and a fitted normalized parent model. This conditioning is essential: the expectation below is over an evaluation episode with the fitted objects held fixed. Supplied conditions are finite horizon H>=1, finite action and record alphabets, counting base measures, a preparation law mu, normalized nonnegative emitted kernels K^a(y',e|y), and a common policy pi_t(a|a_<t,e_1:t) with no hidden-state or additional preparation information. The actual experiment uses H=4, uniform mu, two actions, two records, and strictly positive record likelihoods. Introduced notation is Z=h(Y_0), V=(A_0:H-1,E_1:H).

The normalized joint law is

P(y_0:H,a_0:H-1,e_1:H)=mu(y_0) product_{t=0}^{H-1}[pi_t(a_t|a_<t,e_1:t) K^{a_t}(y_{t+1},e_{t+1}|y_t)].

Normalization follows by summing backward over the last record, destination, and action, repeatedly using the row normalizations, then summing mu. The parent starts in retained state z, uses its normalized base row at t=0, and the previous-record row thereafter when enabled. Summing its latent path defines Q_z(V). Write P_y(V)=P(V|Y_0=y) and P_z(V)=sum_{y:h(y)=z}mu(y|z)P_y(V) for positive-mass fibers. Require P_z << Q_z on the finite path alphabet; all expectations of log ratios are then finite after restricting to positive P mass. Zero-probability policy paths are omitted. This support requirement is automatic for these fitted positive pseudocount rows and shared policies. Fibers of zero preparation mass contribute zero.

Let q_t be the parent's predictive record probability after filtering, and p_t^y the fine predictor initialized at y. Define expected record losses before simplification:

H R(Q,h)=E_P[-sum_t log q_t(E_{t+1}|Z,A_0:t,E_1:t)],

H R(P,id)=E_P[-sum_t log p_t^{Y_0}(E_{t+1}|A_0:t,E_1:t)].

Each path likelihood contains the same product of policy factors. On every positive P path these factors cancel in P_y(V)/Q_z(V), even for randomized or previous-record-feedback policies. Thus

H[R(Q,h)-R(P,id)]
= sum_y mu(y) sum_v P_y(v) log[P_y(v)/Q_{h(y)}(v)]
= sum_y mu(y) sum_v P_y(v) log[P_y(v)/P_{h(y)}(v)]
  + sum_z P(Z=z) sum_v P_z(v) log[P_z(v)/Q_z(v)]
= I_P(Y_0;V|Z) + E_Z KL(P_Z||Q_Z).

The second equality inserts P_z into the log ratio, and the third uses Z=h(Y_0) and the mixture identity. All sums are finite under the stated support assumption. Equivalently, for expected same-preparation fine-oracle loss R(P,h), H[R(P,h)-R(P,id)] is the conditional mutual information and H[R(Q,h)-R(P,h)] is the average KL. Each is nonnegative at population level. This is an exact conditional identity, not a mean-field approximation or an assertion that the fitted parent equals the true coarse path law. The KL need not split into independent estimation, memory, and closure errors.

The policy restriction is load-bearing. If an action depends on a hidden state or private history, the action itself supplies information and the filters and joint law must include that conditioning. A common policy depending on z would require a correspondingly specified reference law and cancellation check. The displayed experiment does not grant that additional dependence.

## Source-matched oracles and finite checks

For each held-out cell, the full oracle uses that cell's original or reversed-coupling kernel and a point mass at the prepared y. The same-preparation oracle uses that same kernel and a uniform distribution on h^{-1}(h(y)), then filters in the full sixteen-state space. It has equal initial information to the fitted parent; it is not a compressed implementation. Both thereafter use only actions and records. The fitted parent stays fixed from original-environment training, so reversed-environment discrepancy includes distribution shift. No original-environment oracle is mislabeled as a shifted exact reference.

The filter implementation uses record ordinals directly with emitted-table columns. It does not call `finite_formation.filter_step`, whose record argument instead takes -1 or +1. Exact rational normalization was checked for both environment kernels. A two-event positive-then-negative action word, records +1 then -1, uniform preparation, was summed over all 16³ hidden triples: 19682267/80281600. The floating filter returned 0.24516535544882015, the identical floating conversion. This checks one direct sum and all row normalizations; it does not turn every floating score into an exact rational identity.

Sample attribution estimates are signed differences of paired losses, not nonnegative estimates imposed by clipping. At budget 512 in the original environment, the equal-weight mean over the three seeds and three policy cells gives constant preparation difference 0.005951605 nats/event and constant mismatch difference 0.000848035. Identity has zero preparation difference and mismatch 0.000550766. Their combination explains the retained identity advantage approximately 0.006249. At budget 32 the corresponding constant terms are 0.004202395 and 0.001594337, while identity mismatch is 0.008544239; estimation discrepancy can reverse the fitted advantage despite greater information. These descriptive averages do not establish a population decomposition numerically. Every component cell remains in the tables.

## Structural diagnostics and conditional coverage

`structural-diagnostics.csv` contains exact d_f, d_f/2, a maximizing action/source pair where nonzero, and fitted `oracle_error` for the 38 frozen attribution instances in both environments (76 rows). These quantities compare joint next-retained-state/record rows, separately from record prediction. Their inequality oracle_error>=d_f/2 was checked exactly. A previous-record index does not shrink the source fiber admitted by that uniform diagnostic. It therefore cannot remove its intrinsic minimax floor. The local-contract proof gives the universal triangle bound independently.

`response_check.py` checks the reset first-record expression by Fraction arithmetic on all 16 states, both actions, and both environments: 64 exact identities. It verifies the all-positive/all-negative next-record TV is 3/20 and the constant-row floor is 3/40. A tiny adapter check for subset {0}, every exterior source and both actions, verifies 32 normalized joint STEP rows, zero STEP probability of START, and a unit-mass initial START law. This is not the fifteen-subset refinement or local-compression admission experiment, which remains next-stage work.

The base estimator pools 32b independently prepared transitions and 4b training-episode transitions, totaling 36b. Conditional memory uses only the last three steps per episode, totaling 3b over 4k previous-record/action/source-class rows. `coverage-rows.csv` exposes every row count and `coverage-summary.csv` reports min, max, zero, below-five, and below-ten counts. At b=512,k=16 its mean is exactly 24 observations per conditional row before imbalance. Sparsity therefore confounds rejection of the previous-record-conditioned model with intrinsic memory utility. All models already filter record history; the extra memory is a transition-row context, not permission to begin using history.

## Figures, scope, and next obligation

`plot.py` renders three PDF/300-dpi PNG figure pairs: loss against two separate resources, preparation attribution, and memory occupancy. Points are descriptive; coverage bands are occupancy min–max ranges. The plotting skill informed dimensions, readable labels, vector export, and color/shape choices; no unsupported significance markers were added. The image viewer sandbox helper failed initially; an elevated read-only base64 fallback then displayed the attribution and coverage PNGs. Their labels, legends, and panels were visually inspected and legible.

The strongest supported empirical result is the reproduced cost-driven endpoint decision together with a complete declared validation frontier and the bounded six-cell oracle attribution. A unique preferred parent still needs an externally justified tolerance or resource preference. The scientific next action is the separately typed, fifteen-subset strong exterior-contract admission experiment, on explicit continuation. No coefficient tuning, new sensor, new observations, spatial learner, or full local refinement was performed here.

After execution, function annotations alone were added to the analysis and plotting scripts. Static compilation of all four final scripts passed; completed science was not rerun for these behavior-preserving annotation edits. Final script and imported-source hashes and exact commands are recorded in execution.json. The coordinator independently viewed the loss/resource figure and found it legible; the attribution and coverage figures were also visually inspected through the read-only fallback.

