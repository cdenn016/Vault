# Hierarchy completion: named theorem and remaining requirements

September 12, 2026. Independent bounded source and proof reconstruction. The common-prior theorem closes its named gap: within the admitted transported Gaussian family, one nonempty open set of fixed, strictly positive ancestry priors has a learned first-pair preference and a later second-merge preference, with exact normalized recursive carriers and finite preference windows. It does not complete data-derived spatial selection for the original heterogeneous finite experiment or determine an operationally preferred intermediate organization. No defect in the common-prior continuation argument was found in this reconstruction. This report does not issue a formal certificate or independently rerun the interval calculations.

## 1. Target, sources, and quantifiers

The original [attachment](<C:/Users/chris and christine/.codex/attachments/be4e6f63-61a2-4b23-812a-608a92793312/pasted-text.txt>), Section 1, lines 7–17, asks when interacting children support a useful, recursively usable parent carrying a recognition law, normalized model evaluator, retained interface, and sufficient memory for a declared operational experiment. It distinguishes an exact parent, a useful approximation, data-derived child-subset selection, and persistent recursive organization. Sections 7–10, lines 174–236, add the operational selection, memory, geometry, and composition gates. They explicitly exclude inference of infinite RG convergence or autonomous agency from two finite levels. The later one-point direction, recorded in [STATUS](../../STATUS.md), lines 7–23, keeps the principal/associated-bundle model and independent interaction links while deferring base transport.

The live [wiki](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>), lines 21–22, states the current operational parent definition. Its older Gaussian/coherence descriptions are specializations. Live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) separates barycenter construction, licensing, and detector at lines 1533–1615; its post-merge functional and organizational price remain expressly unspecified at lines 1593–1604. The downward mechanism is already present at lines 1662–1677. These are research sources with mixed maturity, not independent authority for their own unresolved claims.

The theorem actually asserted in [common-prior-native-hierarchy-episodes](common-prior-native-hierarchy-episodes.md), Sections 1–7, has the following quantifiers. For the fixed four-cycle, fixed ordered two-channel record batch, twelve connected ancestries with forty-five shared decorations, and the stated seven-coordinate native unit-start flow, there exists a nonempty relative-open set U in the interior of the twelve-prior simplex such that, for every fixed pi in U:

* O is the unique initial ancestry and complete regime, a local O-to-P ancestry crossing occurs, and P_split is uniquely modal throughout [5,7].
* P_merge is uniquely modal throughout [35,40], under both recognition and the current model posterior.
* The same normalized two-stage channel carries the declared old and first-parent-cut queries, complete joint VFE and Fisher matrices, and actual-output geometric composition.
* During the later window, expected displayed storage saving is greater than eighteen real fields; total resource usefulness requires the separately stated workload inequality.

This is an existence statement over fixed priors, not an all-prior theorem. The initial prior is not learned by an additional algorithm, and its theoretical construction from a tie surface is not fresh-data confirmation. The reference point is on the simplex boundary; the final theorem concerns interior priors by continuity. There is no assertion of a majority merged regime, unique global crossing time, sample-path lineage, permanent membership, or physical time.

The original fifteen heterogeneous strong-exterior admissions remain a different completed negative result. A conditional continuous Gaussian construction does not turn those injective finite parents into compressed parents. Conversely, their obstruction does not invalidate this different admitted family.

## 2. Convention dictionary and the geometric scope

| Object | Ambient type and convention | Realization used by this theorem |
| --- | --- | --- |
| Base and available agents | One contextual base C; agent sections are restricted to domains U_i, and only i with c_* in U_i participate. | One fixed c_*. No curve through C is used. |
| Principal bundle | Right G-bundle P_G; associated quotient (u g,beta) is identified with (u,g beta). | A local trivialization at c_*; translations provide the concrete specialization. |
| Law fibers | Invariant normalized-law spaces with left sample actions rho_b,rho_m and induced pushforwards. A law fiber is not a transition-kernel space. | Two copies of N(mu_i^x,I_2), x=b,m. Stacked means lie in R^4. One may realize the common group as R^4 with its two projected translation actions. |
| Sections and frames | Belief/model sections and their two local principal frames can differ on the common principal bundle. | Their evaluated local coordinates and coherently pushed reference laws. |
| Interaction | An independent oriented edge e:i to j maps source coordinates to destination coordinates. Reverse edges have inverse links. | ell_e in R^4, with ell_ij'=ell_ij+h_j-h_i when mu_i'=mu_i+h_i. |
| Tree maps and marks | A declared rooted internal tree chooses graph transport; cotree and cut links remain distinct. | g_i is the tree sum from the block root to i; V_ij=ell_ij+g_i-g_j. |
| Parent law point | A typed aggregation in the selected law family. | z_A=n_A^(-1) sum_i(mu_i-g_i), giving N(z_A^b,I_2), N(z_A^m,I_2). The complete recognition law is a law on all retained coordinates, not either Gaussian law point. |
| Statistical metric | Fisher covariance of square-integrable model or recognition scores; nondegeneracy is a separate condition. | The full correlated native Fisher matrices. Fixed-unit-covariance mean pooling minimizes an ordinary quadratic Gaussian-KL objective. No SPD manifold exponential, logarithm, or transport is invoked. |
| Connections | Principal connections and their induced associated connections are distinct data from independent graph links. | Not evaluated in this fixed-context theorem. No base-flatness or global bundle-triviality conclusion. |

These conventions come from live geometry, `def:geo-principal-systems`, `eq:geo-pushforward-actions`, `eq:geo-quotient-convention`, and repository [geometry](../../../Theory/02_geometry.tex), `def:geo-graph-links`. The latter uses the opposite edge notation e:j to i and frame rechoices a_i; the displayed old-to-new translation convention corresponds to h_i=a_i^(-1) in multiplicative notation.

The transformation calculation is direct:

\[
 g_i'=g_i+h_i-h_{r_A},\qquad
 z_A'=z_A+h_{r_A},\qquad
 V_{ij}'=V_{ij}+h_{r_B}-h_{r_A}.
\]

Hence the residual mu_j-mu_i-ell_ij is unchanged, as are its Gaussian agreement probability and each primitive-noise energy when reference means and cross-scale offsets are pushed coherently. Internal loop sums are invariant. This is passive covariance, not invariance of a zero-centered proper Gaussian prior under arbitrary active translation.

A minimal geometry countercase is two parallel links from one vertex to another with ell_1 unequal to ell_2. Their loop mark is ell_1-ell_2, which can be nonzero. Replacing both by an endpoint frame difference would force equality and remove an admitted degree of freedom. The present retained-link construction does not make that replacement. Topology and overlap extension over varying c remain deferred; a theorem over one fiber neither proves nor needs a global trivialization.

## 3. Reconstruction of the common-prior argument

Let pi^0_O=zeta^0_P/(zeta^0_O+zeta^0_P), pi^0_P=zeta^0_O/(zeta^0_O+zeta^0_P), with all other entries zero. The saved unit evidences are strictly positive. Their exact fractions therefore define a normalized O/P reference, and its unit posterior ancestry masses are both one half. The complete initial O regime is nevertheless uniquely modal because 0<M_0<1 and the pair mass divides into split and merged histories.

For the actual seven-coordinate field, the model block-variance metric uses K_pi=sum_R pi_R k_R. The derivative cannot use the posterior expected block count in this denominator. The retained count memory lambda obeys

\[
 \dot\lambda=-\lambda-2(r_b/b-1-\log(r_b/b)).
\]

Both terms survive the O/P reference. The derivation in [native learning](shared-parent-native-learning-and-memory.md), Sections 3–6, and its explicit transfer in [transported priors](transported-parent-priors-and-induced-couplings.md), Section 4, justify this field. The latter changes E_a to the transported primitive child-noise energy; reusing the earlier untransported energy would be a different flow.

At the reference, write w=Q(P) and M for its conditional second-merge probability. The complete regime masses are

\[
 q_O=1-w,\qquad q_{\mathrm{split}}=w(1-M),\qquad
 q_{\mathrm{merge}}=wM.
\]

The saved path and readout bounds show all four strict inequalities needed for the two windows, under each law. For example, recognition has q_split-q_O>0.1416 and q_split-q_merge>0.2326 on [5,7], and q_merge-q_O>0.4296 and q_merge-q_split>0.0123 on [35,40]. Thus the second statement is a mode comparison, not an assertion that q_merge exceeds one half.

Here is the load-bearing continuation argument. On a compact tube around the positive reference trajectory, each conditional evidence is positive and smooth, the finite ancestry denominator is bounded away from zero, and K_pi is at least one on the whole prior simplex. The vector field and finitely many readouts are uniformly continuous in state and pi, with bounded state/prior derivatives on a sufficiently small compact neighborhood. A first-exit argument and the integral inequality

\[
 \|z_\pi(t)-z_{\pi^0}(t)\|
 \le B\|\pi-\pi^0\|\int_0^t e^{L(t-s)}ds
\]

give uniform solution dependence through time forty. Choosing the perturbation small enough keeps the path inside that tube and preserves every strict window margin. Each competing regime from a previously absent ancestry has mass at most that ancestry's mass; all such masses tend uniformly to zero. There are only finitely many of them.

The concrete direction pi_O=pi^0_O+epsilon, pi_P=pi^0_P-epsilon-10epsilon^2, pi_R=epsilon^2 for the other ten ancestries is normalized and positive for sufficiently small epsilon>0. Initially, O minus P unnormalized posterior mass is epsilon(zeta^0_O+zeta^0_P)+10epsilon^2 zeta^0_P>0. The initial O/P log advantage tends to zero while P's advantages over other ancestries diverge. The finite constants and strict inequalities in [native ancestry crossings](native-ancestry-crossings-and-selection-loss.md), Section 2, then place the local ancestry crossing below any suitably chosen local time T<5. Finally, strictness at every sufficiently small interior member gives an open neighborhood around that member. This proves a full-dimensional relative-open prior family, not merely a curve.

An explicit numerical radius is unnecessary for this existence statement. It would be needed to deploy a particular numerical prior with a quantitative margin, which is a different deliverable. The theorem does not obtain its two stages by concatenating incompatible earlier trajectories.

## 4. Complete channels, access, and recursion

Use the transported unit-variance reference P_* for the same fixed positive pi and retain S=(H,p,E_a,E_b,E_c,E_v). The exact prior and recognition density ratios are

\[
 f_u(S)=u_a^8u_c^8u_v^2u_b^{2k(H)}
 \exp[-\tfrac12\sum_j(u_j-1)E_j],
\]

\[
 g_\eta(S)=Z_\eta^{-1}
 \exp[-\tfrac12\sum_j(\rho_j-1)E_j+\omega k(H)+s\log L_o(p)].
\]

The uniform second panel is a fixed parameter-independent normalized kernel K on actual first-parent cut probabilities. Its product Bernoulli flags and deterministic graph rule sum to one for every complete input. It is applied to prior and recognition alike. Append every first-parent-cut evaluator when a contraction would otherwise discard its arguments.

Let R_*=P_*K, let C be the complete retained channel, and let Psi be a disintegration of R_* given C. The finite-discrete/Euclidean spaces are standard Borel. Since f_u and g_eta, the record likelihood, and all their parameter scores are measurable from C, multiplication of the reference disintegration by these factors gives the same conditional Psi for prior, posterior, and recognition. Consequently conditional KL is zero and

\[
 F(Q,P)=F(C_\#Q,C_\#P),\qquad
 G_Q=G_{C_\#Q},\qquad G_P=G_{C_\#P}.
\]

These identities use the complete joint laws. They do not sum parent marginal entropies or independently reset the children. Shared H, energies, parameters, label catalog, controller memory, and moment evaluation remain available and are charged. Local access is coordinate projection plus explicitly shared incident cuts and learning data, as specified in [complete channel](shared-parent-complete-channel-and-recursive-cost.md), Section 3. The result does not claim independent autonomous local learners.

For a second component C formed from actual first parents A, its tree shifts t_A yield

\[
 z_C=\frac{\sum_A n_A(z_A-t_A)}{\sum_A n_A}
     =\frac{\sum_{i\in C}(\mu_i-g_i-t_{A(i)})}{\sum_A n_A},
 \qquad V_e^{new}=V_e+t_A-t_B.
\]

This is exactly the flattened fine map. Every edge copy, loop, evaluator, and structural history is retained where needed. The same S survives, so the common-conditional proof applies to the composed kernel. The current catalog contains 176 decoration/active-mask cases; its all-case calculation checks this finite realization. General finite repetition remains conditional on retaining each newly admitted evaluator and pricing it before discarding its arguments.

The top-down relation has two compatible, distinct meanings. The transported Gaussian generator supplies proper child conditionals around its latent parent coordinate. Disintegration of the complete geometric parent supplies a generally correlated reverse kernel, and integrating it against a parent law gives a child predictive law. It need not equal independent Gaussian resets around the displayed barycenter. For two children, the recovered contrasts sum to zero and have cross covariance -a/2 in each coordinate; independent resets fail that exact constraint. The induced grandparent/loop covariance -c in transported-prior Equation (14) is another explicit reason not to restart an independent next-level template.

## 5. Requirement-to-result assessment

| Requirement | Result currently supported | Smallest remaining boundary |
| --- | --- | --- |
| General-law ambient model and two associated channels at one point | Types retained; a specific translation/Gaussian law-on-law family gives an explicit normalized example. | No universal theorem over every group, family, or dynamic generator is asserted. No new global geometry task is required. |
| Independent dynamic links and model learning | Link variables are independent structural coordinates; their joint model and recognition laws evolve through the native energy/variance flow. | An individual-link process is unspecified. Only a request for such sample dynamics makes its transition/observation contract necessary. |
| Complete normalized first and second parents | Common-conditional law, VFE, Fisher, query, ancestry, and geometric composition identities above. | New interactions outside the retained evaluator catalog require new retention and cost accounting. They cannot be inferred from the old channel. |
| Local access and memory | Shared interfaces and complete sufficient energy/count memory are explicit; the original global native solver is available at every level. | Independent per-parent learning or local-only access would be a different contract. Arbitrary fine preparations are not covered by the restricted common-conditional family. |
| At least two proper first blocks followed by a second parent | P_split and P_merge are uniquely modal in separated windows under the same fixed positive-prior family. Actual second geometry is formed from actual first output. | This establishes finite law-level preference episodes. It does not select one ancestry realization or provide a temporal coupling of sampled memberships. |
| Persistence and clocks | Informative retained response queries survive exactly for frozen draws; regime inequalities hold over finite native-time windows. | Native time, sample-path time, and resource accounting ticks are different. No permanent-parent or physical-clock requirement follows. |
| Complete usefulness | A conditional field/storage-and-work frontier is supplied for the same family. | An actual workload and admissible access contract are needed to select an operational winner; real-field counts alone do not select it. |
| Data-derived child-subset selection | The family updates ancestry preference using the fixed data likelihood. | Attachment Section 7's training-derived candidate rule, external task/loss/resource specification, precision target, and independent confirmation are not supplied by the sensitivity theorem. |
| Original finite heterogeneous target | All fifteen exact local admissions are retained negative results; the stochastic local attempt does not evade its complete-carrier obstruction. | A useful approximation or changed operational experiment requires the explicitly stated additional criterion. Reclassifying the Gaussian family as success for that experiment would change the target. |

The current detector has a concrete unresolved selection comparison, not a universal-algorithm obligation. Under only the current original and first-parent-cut query catalog plus native sufficient statistics, forcing the P branch to merge preserves the statistical experiment and stores four fewer fields whenever the panel would have left P split. Its expected extra saving is 4 Q(P_split). This does not prove universal total-cost dominance, since assembly/access may differ, but it proves that exact VFE equality and current storage charges do not themselves justify retaining separate first-parent means. Requiring those means statewise would change the query contract and must come from the operational task, not from the desired grouping.

Likewise, a path of probability laws does not determine sample lineage. Even the constant two-state marginal (1/2,1/2) can arise from a fixed initial state forever or fresh independent states at each tick. These processes have identical one-time laws and different persistence. The present theorem correctly avoids that inference. No additional sampled process should be imposed solely to keep a completed law-level theorem open.

The clock intuition is already developed in live PIFB2, `sec:time_info` and `sec:scale_dependent_time`, lines 1828–1865. It distinguishes Fisher arc length from granular KL increments and motivates coherent/idiosyncratic aggregation under a covariance convention. This continuity should be preserved, but those particular update-noise assumptions are not established for the current native hierarchy. A physical clock is not a prerequisite for the finite result, and accounting ticks in the cost inequality are not its information clock.

## 6. Evidence inspected and next action

Read-only source inspection covered the attachment sections named above, live wiki and PIFB2 mechanisms, the geometry source map in RG-COMPLETION lines 93–137, STATUS's current gate, the common-prior derivation, native crossing and learning proofs, complete-channel construction, transported-prior normalization, and the saved common-prior path/window/geometry artifacts. The checked worktree HEAD was ed8f22a56df353b1535744509cc23fae46d5813c. Mutable research artifacts remain distinguished from that committed baseline.

A standard-library parsing check ran under C:/tmp/rg-v2-phase13-py3147-runtime-20260901/python.exe with -I -B. It read the existing JSON only: all 22 hashes in the common-prior inspection receipt matched current files; the 326 saved path intervals cover [0,40] contiguously; every recorded within-interval error is below its recorded tube radius; the 17 and 41 saved readout intervals are contiguous with all requested stored margins positive; and every printed strict decimal lower bound is below its saved exact rational lower bound. This is consistency of the retained evidence and report, not a rerun of the interval arithmetic, ODE, determinant calculation, or geometry enumeration. No science test, new data, grid, sampling, GPU, Lean, tamper check, vault edit, production edit, or publication ran. Only this report was written by this investigator.

The strongest supported completion is therefore the conditional finite hierarchy theorem, including complete recursively composed laws and same-family resource conditions. Its named common-prior gap is closed. The minimal unresolved requirement for a selected useful organization is the operational distinction between the admitted representations: which retained geometry must remain accessible, for which predictive or intervention task, at what loss tolerance and resource workload. The original fresh-data selection gate additionally needs its predeclared accuracy/precision and sampling specification. Those are external scientific inputs, not a missing ODE extension.

The next action is for the coordinator to reconcile that distinction with the actual later user directions. If the requested endpoint is the admitted conditional theorem, no additional trajectory is mathematically necessary. If the endpoint includes a selected learned operational hierarchy or Section 7 confirmation, obtain or locate the missing task/access/cost specification and then freeze its candidate rule and evaluation protocol. Do not manufacture a new price, prior, sensor, sample process, permanent-parent condition, infinite-depth condition, or physical-clock requirement to convert either conclusion into the other.