# Reconstruction of response guarantees for the actual hierarchy

September 12, 2026. This report reconstructs the actual-tree response majorant, the forest decoder, and their finite-depth extension for the existing native hierarchy. It distinguishes exact vector identities, analytical probability bounds, retained numerical window certificates, and the new finite symbolic map check. No scientific calculation was rerun in this reconstruction, and no ledger state is assigned.

## 1. Sources, assumptions, and precise comparison

The immediate claims are in [the selected-hierarchy response law](selected-hierarchy-response-law.md) and [the selected-hierarchy response interface](selected-hierarchy-response-interface.md). Their supplied model and channel are [transported parent priors](transported-parent-priors-and-induced-couplings.md), Sections 2–4; [complete parent channels](shared-parent-complete-channel-and-recursive-cost.md), Sections 3–7; and [common-prior hierarchy episodes](common-prior-native-hierarchy-episodes.md), Section 4. The [native response law](native-coherence-response-law.md), [fixed-probe interface](native-response-parent-interface.md), and [previous reconstruction](native-coherence-response-reconstruction.md) supply the anchored-query estimate and the existing native moment windows. I reread the live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:epistemic_collapse` and `eq:rg_closure`, and the [wiki's operational definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>). They distinguish finite coherence, response, full force closure, and persistence; none substitutes for the calculation below.

The supplied finite family has the directed four-cycle 01,12,23,30; two channels b,m, each with means in R² and unit law-point covariance; independent translation links; twelve connected generative ancestries and forty-five root/tree decorations H. The existing native family has positive variance coordinates, the original ordered record counts (8,1,8,1) with one failure at every label in both channels, invariant likelihood power s=1 on the retained unit-start flow, and its existing ancestry-count memory. Every primitive energy, especially E_a, uses H's generative tree paths. Geometric coarsening does not reset those energies or replace the generative count k_H by the later output count q.

The first output now uses the actual partition, roots, and trees of H. Its original cut catalog is E_cut(H), with separately labeled and oriented input ports. A query chooses one such cut from first block A to first block B, one channel, and a collective input whose queried relative displacement h_e=u_B-u_A has norm at most R. This relative-input convention is necessary for the stated constant; another norm on all block inputs would require its incidence-map factor. The query returns one Bernoulli answer. When k_H=1, the new collective-response interface has a null port with a deterministic common answer. When k_H>1 and a later merger has q=1, the old first ports remain available. These two cases are not interchangeable.

Before queries, the actual normalized second panel is sampled once from the baseline first-parent state. Both experiments use that same panel kernel and its same realized mask/tree history sigma. Queries are absolute hypothetical inputs relative to the frozen draw and do not resample the panel. The policy may adapt labels, channels, and inputs from common advertised retained information and preceding answers. It may not consult arbitrary discarded first-stage coordinates without retaining them in the controller interface.

The one-panel theorem below quantifies over every admitted H, every finite fine configuration on its branch, every panel history, every finite K, and every such policy. Section 8 checks the additional source assumptions for every finite number L of later contractions and for historical and new current ports. At a fixed native time the probability statement compares the joint law of common advertised information, hierarchy history, and response transcript. It does not compare a fine continuous state with a lower-dimensional state in total variation. Native time indexes preparation laws; it does not define an individual sampled-state path. All structural and query restrictions here are supplied by the claim reports; no new scientific assumption is introduced to obtain their stated conclusion.

## 2. Reconstructing the omitted-vector coefficients

Work in one channel. Let B be the directed cycle incidence, r=B mu-ell, and let psi_Hi be the signed edge-path row from the root of i's block to i along H's internal tree. Then g_i=psi_Hi ell. Telescoping vertex differences along the same path gives

\[
\mu_i-g_i=\mu_{r_A}+\psi_{Hi}r\quad(i\in A).
\tag{1}
\]

With z_A=n_A^(-1)sum_i(mu_i-g_i), delta_i=mu_i-g_i-z_A, and bar psi_HA=n_A^(-1)sum_i psi_Hi, equation (1) yields

\[
\delta_i=(\psi_{Hi}-\overline\psi_{HA})r,
\qquad \sum_{i\in A}\delta_i=0.
\tag{2}
\]

For an original cut e=(i,j), i in A and j in B, retain V_e=ell_e+g_i-g_j and set d_e=z_B-z_A-V_e. Direct substitution gives

\[
r_e=d_e+\eta_{H,e},\qquad
\eta_{H,e}=\delta_j-\delta_i=c_{H,e}r,
\]
\[
c_{H,e}=\psi_{Hj}-\overline\psi_{HB}
-\psi_{Hi}+\overline\psi_{HA}.
\tag{3}
\]

Every coefficient row is rational and supported on the selected internal trees. Changing the root changes each path row within a block by the same row and cancels after centering. Thus these formulas do not depend on a favorable root choice. They also do not average different original cut labels or erase loop marks.

For P={{0,1},{2,3}}, the within-pair contrasts are plus or minus r01/2 and r23/2. Both directed cuts consequently have c=-(1,0,1,0)/2, independently of the four root choices. At k_H=4 every block is a singleton, delta=0 and all c rows vanish. At k_H=1 there are no cut rows. As an additional check of the coefficient rule, for a three-vertex path 0,1,2 with singleton 3, the cuts 23 and 30 have rows -(1,2,0,0)/3 and -(2,1,0,0)/3 when the internal edges are 01 and 12. They are distinct forms and must not be collapsed into one norm term.

Choose one representative of each distinct nonzero row c up to multiplication by -1, and call that finite set U_H. Only the sign is discarded: rows with different magnitudes are not identified. Define

\[
J_H=\sum_{c\in U_H}c^Tc,\qquad
W_H(X)=\sum_{x=b,m}\sum_{c\in U_H}\|c r^x\|^2.
\tag{4}
\]

J_H is positive semidefinite, and may be zero or rank deficient. Each queried omitted norm is one of these terms, or zero, so

\[
\max_{e\in E_{\mathrm{cut}}(H),x}\|\eta_{H,e}^x\|^2
\le W_H(X),
\tag{5}
\]

with the empty maximum defined as zero. This deduplication is only an estimate; every original edge label and orientation still belongs to the response catalog.

## 3. The factor four and the full native mixture

For one spatial coordinate of a channel at fixed H, the original residual vector has Gaussian covariance Gamma_H before the likelihood tilt. The retained Gaussian calculation gives one-channel evidence e_H>0 and posterior per-coordinate second moment C_H=T_H/e_H, where

\[
e_H=\sum_M\frac{(-1)^{|M|}}{\det(I+\Gamma_HD_M)},
\qquad
T_H=\sum_M\frac{(-1)^{|M|}(\Gamma_H^{-1}+D_M)^{-1}}
{\det(I+\Gamma_HD_M)}.
\tag{6}
\]

Here D_M=diag(n+1_M), n=(8,1,8,1). Positive variance parameters make Gamma_H positive definite in this model. The original likelihood is positive almost everywhere and bounded by one, so normalization and finite polynomial moments follow from its positive Gaussian integral. The finite alternating expansion in (6) is an algebraic identity, not a signed sampling mixture.

For a row c and one channel, two spatial coordinates give

\[
\mathbb E[\|c r^x\|^2\mid H,o]=2cC_Hc^T.
\]

Summing both channels supplies the second factor two. With a_H=pi_R w(H|R)exp(lambda k_H), Z=sum_H a_H e_H², and alpha_H=a_H e_H²/Z, the full law therefore has

\[
V_Q:=\mathbb E_Q W_H
=4\sum_H\alpha_H\operatorname{tr}(J_HC_H)
=\frac{4\sum_Ha_He_H\operatorname{tr}(J_HT_H)}{Z}.
\tag{7}
\]

The two channels share H, so their evidence e_H² must be formed before summing over H. The factor e_H in the numerator is the other channel's evidence. Formula (7) includes all ancestries in the native law with their actual weights and uses no independence after mixing H. For the current model posterior, use the model variances and lambda=0. The matched root translation cancels from residuals.

## 4. Joint response error through the actual panel

For an available old cut define

\[
a_{H,e}^x(h)=\operatorname{clip}_{[0,1]}
\{p_e^x(0)+\phi(d_e^x+h)-\phi(d_e^x)\},
\qquad \phi(v)=e^{-\|v\|^2/2}.
\tag{8}
\]

The edge-specific input h already means target minus source; no common two-pair sign convention is silently imposed on all edges. The evaluator is a Bernoulli probability and equals the retained original probability at zero input. To reconstruct the earlier estimate, write r=d+eta and Delta_h phi(v)=phi(v+h)-phi(v). Before clipping, the probability error equals Delta_h phi(d+eta)-Delta_h phi(d). Its mixed integral is

\[
\int_0^1\int_0^1 h^T\operatorname{Hess}\phi(d+s\eta+t h)\eta ds dt.
\]

Here grad phi(v)=-v phi(v) and Hess phi(v)=(vv^T-I)phi(v). Their global operator bounds are exp(-1/2) and 1: the Hessian eigenvalues are -exp(-a/2) transversely and (a-1)exp(-a/2) radially, for a=||v|| squared. The mixed integral is therefore at most ||h|| ||eta|| in absolute value. Alternatively, bounding each of the two eta-differences by the gradient bound gives 2 exp(-1/2)||eta||. Projection onto [0,1] cannot increase distance from the true probability in that interval. Consequently

\[
|p_e^x(h)-a_{H,e}^x(h)|
\le c_R\|\eta_{H,e}^x\|,
\qquad c_R=\min(R,2e^{-1/2}).
\tag{9}
\]

No differentiability through clipping is required or claimed.

Let K(dsigma|C1) be the actual second-panel kernel. It draws cut flags using gamma_e=phi(d_e^b)phi(d_e^m) and then applies the declared forest and root rule. For each baseline state its mask probabilities sum to one. The fine comparison uses this same parent-based panel rule; substituting probabilities from the fine residuals would define a different comparison and is not licensed by the proof.

For fixed (X,H,sigma), couple the common policy randomness and the query uniforms. Until the first differing answer, the histories and selected queries agree. By (5) and (9), each conditional mismatch probability is bounded by c_R sqrt(W_H(X)), regardless of which old port or channel the policy chooses. Hence the conditional probability of any mismatch in K queries is at most min(1,K c_R sqrt(W_H(X))). Integrating the same coupling over Q(dX,dH)K(dsigma|C1) gives

\[
\operatorname{TV}
\le \mathbb E_Q\min\{1,Kc_R\sqrt{W_H}\}
\le\min\{1,Kc_R\sqrt{V_Q}\}.
\tag{10}
\]

The first inequality bounds the difference of probabilities of every measurable event in the common hierarchy-history and query-transcript space by the mismatch event. The panel need not be independent of W_H: the envelope is independent of sigma, and integrating K at each fixed state gives one. There is no conditioning on a preferred ancestry or mask.

If instead a regime E determined by H and sigma is conditioned on, let p_E>0 be its common probability. The correct moment is

\[
\mathbb E[W_H\mid E]
=\frac{\mathbb E_Q[W_HK(E\mid C1,H)]}{p_E}
\le\frac{V_Q}{p_E}.
\tag{11}
\]

The conditional TV bound replaces V_Q by this conditional moment. The panel dependence prevents factoring its numerator into E(W_H) times the event probability. The unconditional constants cannot be reused unchanged after selecting a winning or merged regime. If the event probability is zero, no such conditional guarantee is asserted.

## 5. Why the old window constants apply, and what they do not show

On the retained O/P boundary reference, U_O is empty and J_O=0. For P, J_P=vv^T/4 with v=(1,0,1,0)^T. The old fixed-probe omitted vector was eta=-v^Tr/2, so

\[
V_Q=2\mathbb E_Q[1_{H\in P}\|\eta^b\|^2]
\le 2M_{\mathrm{fixed\ probe}}.
\tag{12}
\]

The inequality removes the nonnegative old fixed-probe contribution of O. It is exact majorization at this reference, not a numerical evaluation of the new selected moment and not a claim that every other ancestry satisfies the same inequality. The same proof applies under the current model posterior.

The already saved moment-window certificate bounds the fixed-probe recognition moment above by 0.196359349 early and 0.121633988 late, with smaller model-posterior bounds. Since 0.628²>2(0.196359349) and 0.494²>2(0.121633988), equations (10)–(12) give

\[
\operatorname{TV}\le
\begin{cases}
\min\{1,0.628Kc_R\},&5\le t\le7,\\
\min\{1,0.494Kc_R\},&35\le t\le40.
\end{cases}
\tag{13}
\]

No old moment window is rerun for this implication. The coefficients have strict slack. All forty-five terms in (7) are smooth and finite on a compact positive-variance tube about the reference path, the mixture denominator stays positive, and the native field has the previously established uniform finite-time dependence on its fixed prior. Thus V and the earlier regime inequalities vary continuously and uniformly with the prior there. Choosing a sufficiently small neighborhood preserves (13) together with the earlier strict hierarchy preferences; the existing positive-prior curve enters that neighborhood, and its interior points have relative-open neighborhoods in the full simplex. The additional ancestries contribute through (7), not through an assigned zero error. No quantitative size of this neighborhood or new perturbed path is supplied.

A smaller late upper bound does not establish that the actual selected V is smaller late than early. The earlier strict decrease was proved for the different fixed-probe moment. The present phase has not evaluated the new V numerically. Likewise, a one-block first ancestry has no internal group-separation port in this chosen contract; zero error for its null action is not a guarantee for the old fixed two-pair task. Capabilities differ across first ancestries. These limits are material when using the result to compare formation choices under an external task.

## 6. A forest decoder for every old response

Let the actual first parents have means z_A, positive masses n_A, and individual marks V_e. A realized panel forest F joins them into q components C, with k-q selected edges. Let t_A be the signed sum of the actual marks along F from C's selected root to A. The existing second geometry is

\[
Z_C=\frac{\sum_{A\subset C}n_A(z_A-t_A)}{M_C},
\quad M_C=\sum_{A\subset C}n_A,
\quad V_e^{\mathrm{new}}=V_e+t_A-t_B.
\tag{14}
\]

Set xi_A=z_A-t_A-Z_C. Then sum_A n_A xi_A=0 in each component. On a selected oriented tree edge f=(A,B), t_B-t_A=V_f, hence

\[
d_f=z_B-z_A-V_f=\xi_B-\xi_A.
\tag{15}
\]

Retain d_f as a four-vector on each selected tree edge. Starting with b_root=0, integrate these differences with their directed signs along each unique forest path. This gives b_A=xi_A-xi_root. Mass-weighted centering recovers

\[
\xi_A=b_A-\frac{\sum_{B\subset C}n_Bb_B}{M_C}.
\tag{16}
\]

The centering is essential: unweighted centering would fail for parents with unequal numbers of fine constituents. The solution is unique because tree differences determine a vector field up to one constant per component, and the positive mass constraint fixes that constant. A singleton component has xi=0 and requires no stored difference.

For any old cut copy e from A in C to B in D, substitution into (14) gives

\[
d_e^{\mathrm{old}}
=Z_D-Z_C-V_e^{\mathrm{new}}+\xi_B-\xi_A.
\tag{17}
\]

If e is a selected tree edge, its new mark is zero by construction. Otherwise its individual new mark remains in the carrier. Equation (17) covers old cuts that become loops as well as those still crossing different new components. It reconstructs every old d_e from the actual second geometry and stored forest differences, without recovering the full fine state. All original anchors are already in S, so every old phi(d_e) and anchored kernel (8) is then recovered exactly. The second compression adds zero response error to (10). A scalar phi(d_f) would not generally suffice in (15), because it loses the vector direction needed for the path integration and the input response.

The forward map uses the actual first output and forest, not independently fitted new parents. Its underlying geometric composition is the existing mass-weighted flattened-path identity. Passive translations shift root means and marks by their endpoint offsets, while each d_f is invariant. Equations (15)–(17) therefore respect the same translation covariance. There is no implication for arbitrary GL transports, learned covariances, or noncommuting frame maps.

There is also a precise linear minimality statement. At one spatial coordinate, the positive mass-centered contrast space has dimension sum_C(|C|-1)=k-q. The forest difference map in (15) is a linear isomorphism by (16). Across all four geometric coordinates it is a basis of dimension 4(k-q). This dimension claim concerns that contrast space itself; it is not a lower bound on all nonlinear encodings or on augmentation relative to the nonlinear statistic S. To check the coordinate argument, additionally retain the old selected link marks V_f. They determine t_A, after which z_A=Z_C+xi_A+t_A and V_e=V_e^new-t_A+t_B recover every old geometric coordinate. Thus the original geometry is linearly equivalent to the new geometry, the forest response vectors, and the discarded forest links. Their dimensions sum to 8k. Dropping the links preserves the response directions by (17), but not every old geometric degree of freedom.

Section 8 gives the exact backward induction for further contractions and a separate bound for their new current ports. Nonuniform inputs within the queried stage's blocks, changed links, other evaluator families, or arbitrary regrouping remain outside the claimed extension. The forest lemma does not supply a bound on all interface memory or a full VFE-force closure theorem.

## 7. Native sufficiency and displayed costs

The original sufficient statistic S=(H,p₈,E_a,E_b,E_c,E_v) survives the map. Augment a full-support normalized reference by the same normalized panel kernel. Each native model, original posterior, and recognition density ratio to that reference remains a function of S. Disintegrating the reference over the augmented second carrier therefore gives one conditional shared by all those native tilts. Substitution of the retained density ratio into the disintegration integral proves normalization and exact reverse reconstruction. The conditional can be correlated and supported on constraints; independence of parent marginals is not introduced.

The original evidence and relative entropy are unchanged, and the existing native scores are S-measurable, so their Fisher second moments are also unchanged under the already supplied regularity assumptions. This preserves the native law solver. It does not make a new response observation part of the original likelihood or reduce the solver's parameter dimension. In particular, generative k_H and its count normalization are retained despite a smaller geometric q.

On the four-cycle, the new geometry has q mean four-vectors and q non-tree mark four-vectors. The response forest adds k-q four-vectors. Together with twelve original probability/energy scalars, the displayed count is

\[
N_{\mathrm{response}}=12+8q+4(k-q)=12+4(k+q).
\tag{18}
\]

Compared with the first output's 12+8k fields, the saving is 4(k-q), four real fields per forest merger. The fine branch has 36+4k coordinates, so its saving relative to (18) is 24-4q>=8. For q=k the forest catalog is empty and the first carrier is unchanged. For k=q=1 it has twenty fields and only the new null port. For k>1,q=1 it retains k-q vector differences and the old multiport task.

The old scalar-augmented carrier had count 12+8q+2k when q<k, but supported a smaller scalar query catalog. Its difference from the new response count is 2k-4q; equality happens in some branches and not others. Neither that scalar count nor its older resource license proves the total cost of the new interface. Finite ancestry, original labels, input-port maps, selected forest and incidence history, evaluator instructions, formation arithmetic, controller memory, caches, native law evaluation, and any reverse sampler still require their ordinary charges. A fine implementation can compile the same evaluator. Displayed storage savings do not establish a runtime advantage, global minimum representation, or preference after all costs.

The new branchwise count itself gives the full-law identity

\[
\mathbb E[N_{\mathrm{fine}}-N_{\mathrm{response}}]
=24-4\mathbb E q.
\tag{19}
\]

On the O/P reference, q=2 exactly on P_split and q=1 otherwise, so this equals 20-4Pr(P_split). The [saved regime-window record](evidence/joint-native-episode/regime-window-enclosures.json) supplies late-window upper bounds

\[
U_Q=\frac{159978436666380997144230744043547521983}
{340282366920938463463374607431768211456},\qquad
U_{\Pi}=\frac{159190668892750365980513968648004414417}
{340282366920938463463374607431768211456}.
\]

Both numerators are strictly smaller than 170141183460469231731687303715884105728, half the common denominator. Thus the new displayed saving is strictly greater than 18 under both reference laws throughout [35,40]. This implication uses the saved split-probability enclosures, not the old resource-license conclusion. For a sufficiently small positive-prior perturbation, finite mask sums and bounded q give continuity of the expectation, uniformly on the compact window under the supplied native continuity result. The same strict inequality survives after shrinking the common neighborhood. Its numerical reference endpoints and any net-cost conclusion do not transfer automatically.

## 8. Every finite contraction history and a single moment bound

The extension assumes the same fixed four-vertex graph and original fine draw. All L later panels, for any finite L>=0, are sampled from retained baseline states before the response queries. A step may only merge connected current components along a forest of original labeled cuts, add their actual masses, and retain one of their roots. There is no splitting, added edge, replacement of a tree by a closed walk, or erasure of old input ports. Every historical port keeps its stage, cut orientation, block-input domain and original fine anchor p_e(0). A stage with one block adds no nontrivial current port; it does not remove earlier ports. These are hypotheses of the extension, not consequences of a one-panel check.

For the exact decoder, retain d_f^ell for every newly selected edge f in F_ell, together with all prior records. Its stage's masses and forest incidence reconstruct the unique contrasts xi_A^ell by (16). For an old cut e, let D_e be zero if e was selected into F_ell, the next-stage cut residual if it still crosses next-stage components, and -V_e^(ell+1) if it becomes a non-tree loop. In all cases (17) becomes

\[
d_e^{\ell}=D_e+\xi_B^{\ell}-\xi_A^{\ell}.
\tag{20}
\]

The final geometry supplies final cut residuals and all individual loop marks. An internal loop is never selected into a later connecting forest; under a later translation its two endpoints acquire the same root offset, so its mark is unchanged. Hence its value is available at every backward step. Surviving next-stage cuts are supplied by the immediately preceding backward reconstruction. This proves by induction from the final stage that (20) recovers every historical cut residual, including edges that later become selected tree edges or internal loops. Old merger-tree links are unnecessary. The original anchor and stage-specific input then reproduce every historical anchored evaluator exactly, with no accumulated decoding error.

Since each forest contains k_ell-k_(ell+1) edges, the retained response vector count telescopes. The final displayed size is

\[
\sum_{\ell=0}^{L-1}|F_\ell|=k_0-k_L,
\qquad N_L=12+8k_L+4(k_0-k_L)=12+4(k_0+k_L).
\tag{21}
\]

This counts real carrier fields only. Arbitrarily many repeated no-merge rounds can still produce arbitrarily many discrete panel records, stage identifiers and controller entries. Their memory and evaluation costs do not follow from (21).

For the new current ports, the old W_H is insufficient in general: an initial singleton partition has W_H=0 but later mergers can produce nonzero omitted contrasts. A separate majorant closes this obligation. At every admitted stage, flatten the geometric trees back onto the original four vertices. Initially their edge set is H's forest. A proper merge adds edges joining distinct current connected components; it preserves acyclicity and increases the edge count by exactly the reduction in component count. The flattened forest therefore has at most three edges. Its edges and retained fine-root labels belong to finite fixed sets. Equal-fine-mass barycenters are fixed by the component, flattened tree paths and root, because masses add under the prescribed weighted averaging. Thus the set of reachable geometries G from any fixed H is finite and independent of L; a no-merge step repeats one of them. The argument requires the actual geometric composition identity, not just an abstract count of partitions.

For every such G, apply (1)-(3) to its flattened paths, giving r_e=d_G,e+c_G,e r for its current cuts. H remains the original generative index for the covariance C_H and mixture weight alpha_H. G does not replace it in the generator or likelihood. Let U_H^all be the finite union of nonzero c_G,e up to sign over all reachable G, including the initial H, and set

\[
J_H^{\mathrm{all}}=\sum_{c\in U_H^{\mathrm{all}}}c^Tc,
\quad W_H^{\mathrm{all}}=\sum_{x=b,m}\sum_{c\in U_H^{\mathrm{all}}}\|cr^x\|^2,
\quad V_Q^{\mathrm{all}}=4\sum_H\alpha_H\operatorname{tr}(J_H^{\mathrm{all}}C_H).
\tag{22}
\]

Every current or historical omitted contrast is bounded by sqrt(W_H^all). Each historical stage occurred in this reachable set, and its decoder is exact by (20). Coupling any K adaptive queries as in Section 4 therefore gives, for every finite L,K and R>=0,

\[
\operatorname{TV}\le
\min\{1,K\min(R,2e^{-1/2})\sqrt{V_Q^{\mathrm{all}}}\}.
\tag{23}
\]

The normalized product of the state-dependent panel kernels integrates to one for each (X,H). The envelope in (22) does not depend on their realized history, so its unconditional moment stays (22). No independence of panels after marginalizing the state is used. This proves the bound on the common advertised history/query space, including all admitted stage choices, with no panel-count multiplier. For a regime selected from the longer history, replace W_H and V_Q in (11) by their all-geometries versions and use the entire history kernel.

At the O/P reference, no reachable O geometry has a cut. A P geometry either keeps its two first cuts or merges to one block, which has no new cut. Historical P ports are still kept, and their omitted row is unchanged. Hence V_Q^all=V_Q<=2M_fixed_probe on the reference, under either law. The same window constants (13) consequently hold at every finite depth. The finite family J_H^all is fixed once the original graph and retention rules are fixed. Smooth finite Gaussian moment ratios on the supplied compact positive-variance tube and uniform finite-time native dependence thus give one common positive-prior neighborhood preserving these constants for every finite L, together with the existing strict initial-regime and expected displayed-saving inequalities. This does not take an intersection of infinitely many unrelated neighborhoods. It uses a single continuous majorant (22).

The proof adds no new deeper-regime preference, infinitely long processor, infinite-history memory guarantee, changing-graph result, or sampled-state kinetics. Only the first forty-five geometries and 176 one-panel cases were mechanically checked. Finite-depth composition and the uniform bound are analytical consequences of (20)-(23) under the stated rules.

## 9. What the saved exact run checks

I read the complete new [response_maps.py](evidence/selected-hierarchy-response/response_maps.py), its [response-maps.json](evidence/selected-hierarchy-response/response-maps.json), and its [stdout](evidence/selected-hierarchy-response/stdout-stderr.txt). The script constructs one-coordinate linear maps on the four fine means and four links, with Fraction entries. It verifies (3) by equality of coefficient rows against the original residual matrix, not by agreement at a few sample points. It checks that omitted rows have no cut-edge coefficients, canonicalizes only their signs for J_H, and explicitly checks the P and singleton cases.

For every saved panel case it appends the selected d_f rows to the actual saved second geometry map, constructs signed tree integrals and the actual mass center, and checks that each decoded old cut row equals its original first-state row. It also composes that equality with the fine-to-first map. Thus each passed matrix identity holds for every real mean/link input on that fixed structural branch. The general proof is (1)–(3) and (14)–(17); the executed finite algebra checks the implementation of the present catalog.

There are 68 original cut rows across all forty-five decorations: 20 two-block decorations times two cuts, eight three-block decorations times three cuts, and one singleton decoration times four cuts; the sixteen one-block decorations contribute none. The 176 panel cases consist of 16 at k=1, 80 at k=2, 64 at k=3, and 16 at k=4. The saved PASS record verifies every count and the displayed-storage identities. It reports pinned CPython 3.14.7 and elapsed time 0.07183760000043549 seconds. The old geometry producer is only read through its saved output; its main program and the old moment-window calculation were not executed.

The script SHA-256 is `11e62c661cd05b8bbe99a9534e862eea607fe86dd23c0db1f83d07801023b397`; the result SHA-256 is `22bb9a9fa67adb7be128868718d79f47cf393fc619359f3b976191cd5c0131c9`. All six source hashes in the new result matched the current source files during read-only inspection, including the existing prior result, old panel maps and producer, common-prior episode report, fixed-probe interface, and native response law. The stored script hash also matched the current script. The saved regime-window record used for (19) has SHA-256 `376b9c6a8156c3189123969416737fa1757023830113cf3317c76f09411fc8ce`; I inspected its late-window summary and the underlying recognition/model-posterior P_split entries. These are provenance and saved-output inspections, not reruns or tamper checks.

The final claim reports inspected here have SHA-256 `9ba6b7680a738d9ef8392ab68b2f9521655d5e8365b6fab8078f643efadacd40` for [the law](selected-hierarchy-response-law.md), `175f445278f66e6bca509060bcbe2b213bad2d67ad18b47b1f19100268bd39c5` for [the interface](selected-hierarchy-response-interface.md), and `d22ac38301b41500830bbea4b96730a50f7d362113277d54d39e28994b63ad50` for [the synthesis](selected-hierarchy-response.md). The reconstruction binds to these versions; later mathematical changes need comparison against the proof here. The synthesis displays the looser coefficients multiplied by R, which follow from c_R<=R. Its final row convention is J_H=sum q^T q, consistent with (4).

## 10. Outcome and remaining obligations

The reconstructed result covers the actual H-dependent first-parent response catalog and the actual second panel over the complete native law. The all-ancestry moment (7) gives a joint finite-query bound, and the older window certificate supplies the stated 0.628 and 0.494 coefficients by (12), with strict positive-prior continuation. The forest decoder preserves that anchored query exactly after compression at count (18). Under the stated monotone forest and historical-port rules, (20)-(23) extend exact decoding and the same window constants to every finite depth in one common positive-prior neighborhood, with the displayed count (21). No additional approximation error arises from the later decoders.

The remaining scope is precise. The new V and V_all have not been numerically evaluated or shown to decrease between the windows. A regime-conditional guarantee needs (11), rather than silently selecting a favorable branch. First-ancestry null ports change the available capabilities and do not answer an independently fixed missing task. Continued contractions must retain the admitted response catalog, while query families outside the specified historical/current cut contract require new information analysis. None of this proves causal formation, complete cost preference, full natural-gradient force closure, or persistence of an individual sampled configuration. I found no mathematical defect in the claims at the bound report versions under their stated restrictions.

The next action that would change a formation conclusion is to compare the complete actual hierarchy interfaces under the required capability set, workload, and loss criterion. Sharper selected or conditional moments are optional improvements to the established bound, not prerequisites for it. Further scientific reruns, new trajectories, or sampled-state kinetics are not needed to establish the scoped result reconstructed here. Only this assigned report was written; no other worker's file, vault source, scientific output, test, ODE, GPU job, Lean artifact, or ledger was changed or executed.
