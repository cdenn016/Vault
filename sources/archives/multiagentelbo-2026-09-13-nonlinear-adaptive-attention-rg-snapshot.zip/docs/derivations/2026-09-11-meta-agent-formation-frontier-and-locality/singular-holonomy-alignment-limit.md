# Alignment across singular Gaussian holonomy regions

September 11, 2026. This resolves the leading alignment integral across the K=3 two-cycle junction identified in [the GL(K) marked-parent construction](gl-alignment-marked-parent.md), and covers a wider class of connected blocks. The same normalized Gaussian-KL agreement factors are retained. Under the stated prior and tail conditions, when (beta-1)(K-1)>1, the evidence has a finite centered-sector coefficient even though the prior charges neighborhoods of rank-changing configurations. The induced holonomy density has an integrable determinant singularity. It yields a proper marked parent and a recursive class that retains this density.

The calculation does not remove the original model's means or restrict its links to an orthogonal group. Both conclusions at the limit are derived after an exact change of coordinates in the full GL(K) model. K=2 with two cycles is a borderline case: for the stated positive-prior admission, its evidence gains a logarithmic factor. Its full limiting measure remains the next separate calculation.

## 1. An exact coordinate change in the existing normalized model

Use the one-point, one-channel law/link model of the preceding derivation. There are N vertices, E internal edge copies with weights w_e>0, and cycle rank beta=E-N+1 in a connected block. Each b_i=N(mu_i,Sigma_i) has Sigma_i SPD, and each Theta_e is independently variable in GL(K), including whichever determinant components its proper prior supports. The binary agreement likelihood is exp[-w_e KL(b_i || (Theta_e)#b_j)]. Let D be the sum of its weighted KL values and let n be the number of selected successes on every internal edge. Recognition is over the complete law/link configuration, not a product of the sampled Gaussian agent laws.

Whiten each mean and write the left polar decomposition of each whitened link as

\[
 u_i=\Sigma_i^{-1/2}\mu_i,
 \qquad A_e=\Sigma_i^{-1/2}\Theta_e\Sigma_j^{1/2}=B_e^{-1}O_e,
 \qquad B_e\succ0,\quad O_e\in O(K).
 \tag{1}
\]

This decomposition is unique: B_e=(A_e A_e^T)^{-1/2} and O_e=B_e A_e. In particular, B_e is a free SPD coordinate. It is not fixed to I in the finite model. The Gaussian KL becomes exactly

\[
 D=\sum_e w_e\phi(B_e)
       +\frac12\sum_{e=(i,j)}w_e\|B_eu_i-O_eu_j\|^2,
 \qquad
 \phi(B)=\frac12\operatorname{tr}(B^2)-\log\det B-\frac K2.
 \tag{2}
\]

To check the mean term, the transported covariance in receiver-whitened coordinates is B_e^{-2}, while the transported mean is B_e^{-1}O_e u_j. Multiplication by B_e gives the displayed residual. The trace and determinant terms reduce to tr(B_e^2) and -2 log det B_e. This derivation uses the whole Gaussian KL, including its normalizing determinant.

Let xi collect all covariance coordinates and the declared spectator/interface coordinates. Write a(xi,B,O,u) for the selected joint density, including the exact coordinate Jacobian from the original proper prior and any fixed compatible observation likelihood. Use Lebesgue measure in u, Frobenius-orthonormal symmetric-matrix coordinates for every B_e, normalized Haar measure on each compact O(K) factor, and a fixed smooth reference measure in xi. Haar measure here is a reference measure for the compact polar coordinate; it is not a prior on GL(K), nor an independence assumption on the actual density a.

The admission is that a is continuous and nonnegative, its xi and B support lies in a compact subset of their admissible domains, and

\[
 a(\xi,B,O,u)\le C e^{-c\|u\|^2},\qquad C,c>0.
 \tag{3}
\]

Continuous compact support in u also suffices. Conditional Gaussian mean priors with uniformly bounded means and uniformly SPD, bounded covariances on the compact spectator domain satisfy this bound; cross-agent and law/link correlations are allowed. The selected density must have positive finite mass and the leading coherent integral below must be positive. Properness alone, with arbitrary noncompact covariance/link tails or vanishing coherent density, is not the admission.

## 2. Exact Gaussian mean integration and what remains singular

For fixed B and O, assemble L(B,O) by

\[
 \frac12u^\top L(B,O)u
 =\frac12\sum_e w_e\|B_eu_i-O_eu_j\|^2.
 \tag{4}
\]

It is PSD. If the conditional prior on u at these coordinates is N(m,C), C SPD, its mean integral is exact:

\[
 \int \mathcal N(u;m,C)e^{-n u^\top L u/2}du
 =\det(I+nCL)^{-1/2}
   \exp\left[-\frac n2m^\top L(I+nCL)^{-1}m\right].
 \tag{5}
\]

Completing the square gives posterior precision C^{-1}+nL and proves (5), including its determinant. Although CL need not be symmetric, I+nCL is similar to the positive matrix I+n C^{1/2}LC^{1/2}; its determinant is positive. The exponent can equivalently be written using m_tilde=C^{-1/2}m and M=C^{1/2}LC^{1/2} as -m_tilde^T nM(I+nM)^{-1}m_tilde/2. Its value is nonpositive. These forms fix the matrix order.

At B=I, write L(O)=L(I,O). Its kernel is the space of means parallel under the orthogonal links, equivalently the root vectors fixed by every based holonomy. This kernel criterion is also explicit in [Theory/09_coarsegraining.tex](../../../Theory/09_coarsegraining.tex), `eq:cg-nonflat-series-properness`. The determinant identity below is derived directly and does not invoke that source's degree-two elimination theorem outside its hypotheses.

For generic two-cycle K=3 marks, L(O) is positive definite, but it becomes singular at the earlier common-fixed-line junction. Pointwise replacement of (5) by its large-n determinant limit is therefore insufficient. The remaining question is integrability over the full orthogonal-link domain, including neighborhoods of its singular marks.

## 3. The integrability criterion, proved over the entire mark space

Define the finite nonnegative energy

\[
 E_0(v,O)=\frac12\sum_e w_e\|v_i-O_ev_j\|^2
          =\frac12v^\top L(O)v.
 \tag{6}
\]

Choose a rooted tree. Orthogonal changes of node coordinates set its links to I. By left and right Haar invariance, the product reference measure on all edge O_e becomes the product measure on the tree frame variables and beta independent based non-tree marks H_ell. This is a measure-coordinate identity; the density a can remain fully correlated. The changes in v have absolute Jacobian one.

In those tree coordinates let z=v_root and delta_i=v_i-z, with delta_root=0. Positive tree weights and a finite tree give a uniform bound on sum ||delta_i||^2 by the tree residual energy. Conversely, each non-tree root residual (I-H_ell)z differs from its actual edge residual by delta_i-H_ell delta_j. Orthogonality bounds these terms independently of the marks. Thus there are graph-dependent positive constants c_1,c_2 such that

\[
 c_1\left[\sum_{i\ne r}\|\delta_i\|^2
      +\sum_{\ell=1}^{\beta}\|(I-H_\ell)z\|^2\right]
 \le E_0(v,O)
 \le c_2\left[\sum_{i\ne r}\|\delta_i\|^2
      +\sum_{\ell=1}^{\beta}\|(I-H_\ell)z\|^2\right].
 \tag{7}
\]

For a Haar orthogonal matrix H, H e_1 is uniform on the unit sphere. Set

\[
 J_K(t)=\int_{O(K)}e^{-t\|(I-H)e_1\|^2}dH.
 \tag{8}
\]

For K>=2 there are positive constants c_K,C_K with

\[
 c_K(1+t)^{-(K-1)/2}\le J_K(t)
       \le C_K(1+t)^{-(K-1)/2},\qquad t\ge0.
 \tag{9}
\]

For the lower bound, integrate a spherical cap of radius proportional to (1+t)^{-1/2} around e_1, where the exponential is bounded below and the cap has that radius to power K-1. For the upper bound, divide the sphere into the cap chart and its complement. In the chart use Euclidean tangent coordinates with bounded surface Jacobian and a quadratic bound on squared chordal distance; on the complement use a positive distance gap. This also covers K=2. Alternatively, integration in the first spherical coordinate gives

\[
 J_K(t)=\Gamma(K/2)t^{-(K-2)/2}e^{-2t}I_{(K-2)/2}(2t),
 \qquad J_K(0)=1.
 \tag{10}
\]

The normalization in (10) agrees with the integral representation [NIST DLMF 10.32.2](https://dlmf.nist.gov/10.32.E2), with nu=(K-2)/2. The proof uses the cap bounds, so no asymptotic expansion of the Bessel function is needed.

Integrating the delta variables in (7) and then using polar coordinates for z reduces finiteness of the full integral to the tail of

\[
 \int_0^\infty r^{K-1}J_K(c r^2)^\beta dr.
 \tag{11}
\]

Its large-r power is r^{-(beta-1)(K-1)}. Consequently, with chi=(beta-1)(K-1),

\[
 \int_{O(K)^E}\int_{\mathbb R^{NK}}e^{-E_0(v,O)}dvdO<\infty
 \quad\Longleftrightarrow\quad \chi>1.
 \tag{12}
\]

Equivalently, integrating v first by Tonelli and the Gaussian formula proves

\[
 \int_{O(K)^E}\frac{dO}{\sqrt{\det L(O)}}<\infty
 \quad\text{when }\chi>1.
 \tag{13}
\]

The determinant is positive almost everywhere under this condition; its singular set and all its neighborhoods were included in (11). The formula is understood as an almost-everywhere density. Choosing an arbitrary value on its null singular set does not remove its neighborhoods from the integral.

For K=3, J_3(t)=(1-e^{-4t})/(4t). A direct reference integral makes the beta=2 bound explicit:

\[
 \int_{\mathbb R^3}J_3(c\|z\|^2)^2dz
 =\frac{\pi^{3/2}(2-\sqrt2)}{2c^{3/2}},\qquad c>0.
 \tag{14}
\]

To derive it, expand (1-e^{-4cr^2})^2, group it as twice (1-e^{-4cr^2}) minus (1-e^{-8cr^2}), and use integration by parts to obtain integral_0^infinity (1-e^{-a r^2})/r^2 dr=sqrt(pi a). Equation (14) is an exact comparison integral, not the complete graph's evidence coefficient.

## 4. The full GL(K) limit across the singular junction

Let s=K(K+1)/2, d_0=E s+N K, and assume chi>1. Define

\[
 c_B=\prod_e(2w_e)^{-s/2},\qquad
 I_{\rm obs}=c_B\int
       \frac{a(\xi,I,O,0)}{\sqrt{\det L(O)}}d\xi dO.
 \tag{15}
\]

The integral is finite by (3), compact spectator support, and (13). Positivity is an explicit condition on the prior and selected observation slice. Under it, the unchanged Gaussian-KL model satisfies

\[
 Z_n=(2\pi/n)^{d_0/2}[I_{\rm obs}+o(1)].
 \tag{16}
\]

In particular, for the K=3, N=3, E=4 example, d_0=33. Its evidence is of order n^{-33/2}, even when the proper prior charges neighborhoods of the rank-32 junction and the rank-34 nonzero-mean sector. Their neighborhoods contribute to the finite coefficient in (15); no rank-32 determinant was inserted into a regular-manifold formula.

Here is the proof for the full nonlinear phase. First restrict to a compact u support ||u||<=R. The scalar function lambda^2/2-log lambda-1/2 has second derivative 1+lambda^{-2} and a minimum at one. Spectral decomposition therefore bounds phi(B) below by a positive multiple of ||B-I||_F^2. Also

\[
 u_i-O_eu_j=(B_eu_i-O_eu_j)-(B_e-I)u_i.
 \tag{17}
\]

Squaring, summing with positive weights, and using ||u_i||<=R gives a constant c_R>0 such that, on this support,

\[
 D(B,O,u)\ge c_R\left[\sum_e\|B_e-I\|_F^2+E_0(u,O)\right].
 \tag{18}
\]

One may choose c_R bounded below by a fixed constant divided by 1+R^2. This inequality retains the B-u coupling; it does not freeze B before the integral.

Now set Y_e=sqrt(n)(B_e-I) and v=sqrt(n)u. The total Jacobian is n^{-d_0/2}. At each fixed finite Y,v,O,

\[
 nD(I+Y/\sqrt n,O,v/\sqrt n)
 \longrightarrow\sum_e w_e\operatorname{tr}(Y_e^2)+E_0(v,O).
 \tag{19}
\]

The cross term Y_e v_i/sqrt(n) tends to zero. Equation (18) gives the integrable dominating function C exp[-c_R(sum ||Y_e||^2+E_0(v,O))], by (12). Dominated convergence applies jointly to Y, v, all orthogonal links, and the compact spectators. The Y integrals supply (2pi)^{Es/2} c_B and the v integral supplies (2pi)^{NK/2}/sqrt(det L). This proves the full constant in (16).

For the Gaussian envelope (3), decompose u into integer-radius shells. On the shell j<=||u||<=j+1, the density is at most C exp(-c j^2), and (18) holds with inverse constant of order 1+(j+1)^2. After the same rescaling, integrating the comparison function costs at most a constant times (1+(j+1)^2)^{d_0/2}. The tail series

\[
 \sum_{j\ge R}e^{-cj^2}(1+(j+1)^2)^{d_0/2}
 \tag{20}
\]

converges and tends to zero with R, uniformly in n after multiplication by n^{d_0/2}. Compact truncations therefore give (16) for (3). The proof permits a conditional correlated Gaussian mean prior without requiring compact mean support.

The joint law of (xi,O,Y,v) converges in total variation to the normalized density

\[
 \frac{a(\xi,I,O,0)}{(2\pi)^{d_0/2}I_{\rm obs}}
 \exp\left[-\sum_e w_e\operatorname{tr}(Y_e^2)-\frac12v^\top L(O)v\right].
 \tag{21}
\]

This follows from the same L1 argument and convergence of normalizers. In the limiting law, conditional on xi,O, v is N(0,L(O)^{-1}) and the Y_e are independent symmetric-coordinate Gaussians with covariance (2w_e)^{-1}I_s. The marginal xi,O density is exactly the normalized integrand of (15).

Consequently B tends to I and u tends to zero in probability. These are inference conclusions from a model with freely variable full GL(K) links and nonzero prior means. The covariance state and orthogonal holonomies remain random. The scaled energy nD converges to Gamma(d_0/2, rate 1), including every fixed polynomial energy moment. To justify moment insertion, bound (nD)^p exp(-nD) by a constant times exp(-nD/2) and reuse the domination and shell bounds. In particular,

\[
 \mathbb E_{\Pi_n}D=\frac{d_0}{2n}+o(n^{-1}).
 \tag{22}
\]

This energy statement does not give moments of every coordinate. Near a small eigenvalue of L(O), the conditional scaled-mean covariance can be large. Tightness or total-variation convergence in (21) cannot be used to claim convergence of its unbounded mean-coordinate moments without an extra bound.

## 5. A compact evaluation of the surviving holonomy weight

The singular weight in (15) can be evaluated using matrices controlled by the cycle rank. Work in rooted orthogonal tree coordinates. Let A=L_T,red tensor I_K, where L_T,red is the root-deleted scalar tree Laplacian with its positive weights. Let W_c=diag(w_ell I_K) for the beta non-tree edges. Write their mean residuals as C_H z+D_H delta, with C_H stacking I-H_ell and D_H selecting delta_i-H_ell delta_j. Define

\[
 R_H=W_c^{-1}+D_H A^{-1}D_H^\top,\qquad
 S_H=C_H^\top R_H^{-1}C_H.
 \tag{23}
\]

R_H is SPD and S_H is PSD, with kernel equal to the common fixed-vector space. Gaussian elimination of delta gives S_H as the root precision. The block determinant and determinant lemma give the exact identity

\[
 \det L(O)=\det A\det W_c\det R_H\det S_H
       =\left(\prod_e w_e\right)^K\det R_H\det S_H.
 \tag{24}
\]

For the last equality, the rooted incidence matrix of the tree is square with determinant plus or minus one, so det L_T,red is the product of its edge weights. The same block calculation proves (24) when S_H is singular, with both sides zero; it does not invert S_H in that case. R_H has dimension beta K and S_H dimension K.

The entries of D_H A^{-1}D_H^T use only the scalar tree Green values at non-tree edge endpoints and products of their H matrices. For a tree, each such Green value is the sum of reciprocal edge weights along the common part of the two root-to-endpoint paths: the inverse rooted incidence matrix records those paths. Those endpoint values and the weight-product scalar can be retained once. Thus this particular holonomy-density factor does not require evaluating an NK-by-NK determinant at every parent evaluation when beta is small. This is an exact algebraic reduction of one factor. It does not establish the cost of the entire induced correlated prior or its evaluators.

The determinant weight is unchanged under simultaneous orthogonal conjugation of every based mark: L changes by a block orthogonal conjugation. A different choice of original gauge frames or of smooth matrix coordinates pushes the full density a and its Jacobian. The invariant object is the resulting measure, not a bare determinant stripped of its measure convention.

## 6. The resulting parent and its finite-strength observation bound

Define a coherent projection P_0 in the polar coordinates by B_e -> I and u_i -> 0, retaining xi and every O_e. It gives centered Gaussian children with covariances Sigma_i and links

\[
 \Theta_e^0=\Sigma_i^{1/2}O_e\Sigma_j^{-1/2}.
 \tag{25}
\]

This is a smooth declared finite-strength approximation in these coordinates, including at the singular holonomy set. It is not a claim that every finite-strength configuration was already coherent. For a rooted block, let Q_i be the orthogonal tree product and set g_i=Sigma_i^{1/2}Q_i Sigma_root^{-1/2}. The parent retains b_I=N(0,Sigma_root), every based mark g_i^{-1}Theta_e^0 g_j, and every dressed cut-edge copy g_i^{-1}Theta_cut g_j, together with the required extra interface. These are exactly the source's rooted marked-parent variables evaluated on P_0.

Apply (15) without the fixed compatible observation likelihood and call its coherent measure nu_prior and mass I_0. Let C_0 be the marked parent map after P_0. Then

\[
 \bar P_0=(C_0)_\#\nu_{\rm prior}/I_0,
 \qquad p_n(o,\mathbf1)=(2\pi/n)^{d_0/2}I_0\bar p(o)[1+o(1)].
 \tag{26}
\]

Appending the compatible inherited normalized kernels gives a proper parent joint. Every loop and cut copy remains present. Internal covariance/frame coordinates can be integrated only if the required kernels factor through this complete parent; otherwise their interface remains. Formula (21) implies total-variation convergence of this projected parent law. Raw complete states retain the earlier singular-support limitation and need not converge in total variation.

For compact mean support, the same comparison gives an explicit observation bound. In the rooted variables of (7), the first-moment numerator is controlled by the radial integral of r^K J_K(c r^2)^beta up to a constant times sqrt(n). Its tail is r^{1-chi}. Delta and Y have Gaussian comparison bounds. After division by the positive asymptotic normalizer,

\[
 \mathbb E_{\Pi_n}\|u\|+
 \mathbb E_{\Pi_n}\sum_e\|B_e-I\|_F
 \le
 \begin{cases}
 C n^{-1/2}\log(2+n),&\chi=2,\\
 C n^{-1/2},&\chi>2.
 \end{cases}
 \tag{27}
\]

These are upper bounds, not claims of an optimal rate for each prior. The Gaussian-envelope extension follows by the shell argument with the additional polynomial and logarithmic factors, still summable against exp(-c j^2).

If a required record kernel differs in total variation from its value on P_0 by at most a constant times ||u||+sum ||B-I|| on the admitted domain, (27) bounds its joint prediction error against the same finite projected parent prior. In particular the K=3 two-cycle case admits an O(log(n)/sqrt(n)) bound. Replacing that finite prior by the limiting prior adds its total-variation convergence error from (21), for which no rate is asserted here. This comparison avoids the false global inequality D>=c||u||^2 near nonzero coherent configurations. Discontinuous mean-direction records, arbitrary latent transitions, or uncontrolled horizons require a different interface or argument.

## 7. Inference, persistence, and recursion with an integrable mark density

For initial recognition proportional to a f(C_0), where f is continuous and bounded above and below by positive constants, full-law Fisher inference has the same exact form as before: a f(C_0)^alpha exp[-kappa D], normalized, with alpha=exp(-t) and kappa=n(1-alpha). Equation (21) and the energy moment argument apply with this bounded amplitude for each fixed t>0. The limiting projected parent has density proportional to f^alpha relative to its induced observed measure and obeys the full parent Fisher flow. The initial layer remains; no uniform t=0 claim is added.

With nu_eff the induced observed parent measure, I_obs its mass, and pi_eff=nu_eff/I_obs, the fine free energy satisfies

\[
 \mathcal F_n-c_n\longrightarrow
 \mathrm{KL}(r_t\Vert\pi_{\rm eff})-\log I_{\rm obs}
 +\frac{d_0}{2}\left[\frac{\alpha}{1-\alpha}+\log(1-\alpha)\right],
 \qquad c_n=\frac{d_0}{2}\log\frac{n}{2\pi}.
 \tag{28}
\]

This uses the actual evidence coefficient (16) and moment (22), not the Hessian rank at the exceptional point. For the normalized parent model, the first two terms are its VFE minus log I_0. At the baseline preparation f=1, total expected D also obeys the exact decreasing exponential-tilt identity. None of these updates is an unspecified deterministic structural-link optimizer.

The singular determinant does not by itself prevent later centered-parent coarse-graining. In rooted polar coordinates the first induced prior has the form a_eff(x,H) F_I(H), where a_eff is a smooth compact amplitude when the initial density is smooth on its stated compact spectator support and F_I(H)=det L_I(H)^{-1/2}. The tree orthogonal variables and internal covariances integrate into a_eff; F_I depends only on the based holonomies and graph/weight data. The condition chi>1 makes F_I integrable on its compact mark group.

More generally retain finitely many inherited factors F_I on their labeled loop subsets, times one bounded smooth compact amplitude. Their reference mark variables remain distinct. At a later centered-law grouping, the means are already exactly zero in the parent model. The new alignment action is sum w_e phi(B_e), with a positive SPD normal Hessian of dimension E_new s. Existing factors do not depend on these new B normals. After grouping, each inherited loop subset is conjugated into the new root frame. Its F_I is unchanged by the corresponding common orthogonal conjugation in whitened coordinates, and the normalized Haar measure is preserved.

Dominated convergence for the new B integral is therefore licensed by the product of the inherited integrable factors and a Gaussian in the new normal variables. Its parent amplitude remains smooth after integration of compact smooth fiber variables, while the same labeled F_I factors remain explicit. New non-tree orthogonal marks are retained, but there is no new mean determinant at this stage because the parent mean support was already centered. This proves closure of this weighted marked class at every fixed admitted finite depth, including the class produced by the singular-neighborhood calculation above. Positive coherent mass, the complete observation interface, and the prescribed order of strong-record limits remain required.

Compatible Bayesian observations preserve centered support and the conditional law of discarded frames when their kernels factor through the parent. A matched recognition lift then has the exact KL-chain and Fisher closure already derived. No finite-dimensional parameterization of the arbitrary amplitude a_eff, general runtime guarantee, endogenous grouping, or invariance under structural-model learning is inferred from this probability-level recursion.

## 8. The borderline two-dimensional case

Condition chi>1 is sharp for the full comparison integral. For K=2 and beta=2, chi=1 and (11) has a logarithmic tail. Suppose the prior is smooth with compact spectator/B support and the stated Gaussian mean envelope, and is bounded below on some spectator neighborhood, all orthogonal link values, B near I, and u near zero. Then constants 0<c<C give

\[
 c n^{-d_0/2}\log n\le Z_n\le C n^{-d_0/2}\log n
 \quad\text{for sufficiently large }n,
 \qquad d_0=3E+2N.
 \tag{29}
\]

For the upper bound, use (18), integrate the tree deltas, and truncate the root radius at O(sqrt(n)) for a compact u piece. Equation (9) leaves integral dr/r, of order log n. The Gaussian-shell argument extends this to (3). For the lower bound, restrict the spectator coordinates to the positive-prior neighborhood, ||Y|| and tree deltas to fixed bounded sets, and root radius between a fixed constant and epsilon sqrt(n). On that region the reverse comparison to (18) also holds, by smoothness of phi on the compact B domain and the triangle bound on (B-I)u. Integrating Haar marks gives the lower cap bound in (9) and again integral dr/r. This proves the two-sided order without a numerical fit.

The lower-bound hypothesis is stronger than properness; it is stated to make the logarithmic claim checkable. A prior supported away from the singular configurations can instead remain in the earlier regular regime. Equation (29) does not yet identify the leading logarithmic coefficient, the distribution of retained loop marks, or any limiting mean-direction information. In particular, replacing the divergent determinant density by an arbitrary cutoff would change the model. Those are the next obligations for the borderline case; K=1, single-cycle singular limits, and unconstrained covariance/link tails are not silently included in the present theorem.

## 9. Executed matrix check and what it establishes

[singular_matrix_exact.py](evidence/singular-alignment/singular_matrix_exact.py) ran once under pinned CPython 3.14.7, using exact rational matrix arithmetic. A noncommuting SPD polar factor and orthogonal factor reproduce the raw Gaussian trace term 16, mean quadratic 107, and covariance determinant ratio 1/25, agreeing with det B=5 and D=60-log(5) in (2). At n=0,1,4,16 it checks both ordered forms of the Gaussian mean integral by determinant and exponent identities.

For the K=3, N=3, E=4 graph with weights (1,2,3,5), it verifies the cycle/root determinant factorization (24). The common-fixed-line marks have det L=0. The rationally perturbed marks from the prior derivation give det L=3085906560000/104060401. The computation compares the full 9-dimensional mean determinant with a 6-dimensional cycle matrix and a 3-dimensional root matrix; it does not numerically integrate the nonlinear alignment model. [The saved result](evidence/singular-alignment/singular-matrix-exact-result.json) records all checked coefficients and matrices.

The written polar, integrability, domination, and recursion proofs establish the stated limit. The small matrix calculation checks order and constants in their finite algebraic ingredients. The earlier GL(K) regular proof, its singular rank example, the translation parent, all fifteen original heterogeneous admissions, and the saved experimental data remain unchanged. The full RG objective remains incomplete, with the borderline integral and the existing grouping, finite-interface usefulness, structural-learning, and resource obligations retained. No base-manifold transport is used.
