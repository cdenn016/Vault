# Collective response on the actual native hierarchy

September 12, 2026. The response guarantee now applies to the actual ancestry-dependent first parents and their actual second-panel mergers in the admitted Gaussian/translation family. It no longer relies on imposing the same geometric two-block probe on every ancestry. The original native law, records, ancestry uncertainty, learner and panel rule are unchanged.

The new interface preserves every original first-parent cut response through a merger by retaining a finite set of vector contrasts. Its displayed size falls by four real coordinates per merger. This establishes a controlled response task on the existing conditional hierarchy. It does not establish an operational reason to stop at an intermediate geometric partition, a fitted useful hierarchy for the original parity experiment, or a process of individually moving sampled agents.

## The actual output and query contract

The [common-prior hierarchy](common-prior-native-hierarchy-episodes.md), Section 4, defines the output used here. First, the realized generative ancestry H supplies its own connected blocks, roots and internal trees. Its posterior probability changes under the existing native learner; no branch is removed from the joint law. Second, a normalized parameter-independent agreement panel is drawn on the actual first-parent cuts. Connected active components and the source's spanning-forest rule determine the next parents.

This first-stage ancestry is part of the existing latent model. Its posterior inference is distinct from the original attachment's fresh-data procedure for learning spatial candidates. The second panel is an auxiliary model readout, not an additional observation or an optimized grouping selector.

A query names an actual first-parent cut, one of the two channels, and a collective displacement of its endpoint blocks. R bounds the relative displacement at the queried cut. The baseline fine draw, links and already drawn panel are held fixed while the query is answered. Policies may adapt to common retained information and previous answers. The same source law and policy are used in the fine and parent experiments.

If the initial ancestry has one block, there is no first-parent cut; its interface returns an explicit null answer for this query class. If an ancestry with several first blocks subsequently merges to one root, its old input ports remain queryable. A merger cannot erase the tested task by replacing those ports with a null answer. Histories, port memberships, controller memory and input conventions remain part of the complete interface.

## Error controlled by actual internal contrasts

For each first block A, let delta_i=mu_i-g_i-z_A be the mass-centered transported child deviation, using that block's actual tree. For a cut e=(i,j) from A to B,

\[
 r_e=d_e+\eta_e,\qquad \eta_e=\delta_j-\delta_i.
\]

Each eta_e is a linear combination of internal tree residuals. The new [law derivation](selected-hierarchy-response-law.md) gives the exact coefficient rows and their Gaussian moments. Equal or opposite coefficient rows can share a moment bound, while all corresponding labeled query ports remain distinct.

With the retained original probability p_e(0), the parent query uses

\[
 a_e(h)=\operatorname{clip}_{[0,1]}
 \left[p_e(0)+\phi(d_e+h)-\phi(d_e)\right],\qquad
 \phi(v)=\exp(-\|v\|^2/2).
\]

The input h is oriented according to the queried edge. The true fine query is phi(r_e+h). The earlier mixed finite-difference proof bounds its error by min(R,2 exp(-1/2)) ||eta_e||. Clipping preserves normalization and cannot increase this probability error. It does not define sequential physical actuation or guarantee derivatives through clipping boundaries.

Let q range over the distinct nonzero coefficient rows for one ancestry, identified only up to sign, and put J_H=sum_q q^T q. If C_H is the existing per-coordinate posterior residual second-moment matrix and alpha_H is the full native posterior ancestry/decorated-tree weight, define

\[
 V=4\sum_H\alpha_H\operatorname{tr}(J_H C_H).
\]

The factor four counts the two spatial coordinates in each of the two channels. This quantity bounds the expected squared worst cut/channel omitted contrast. For K queries, the full joint transcript error is at most

\[
 \operatorname{TV}\le
 \min\left\{1,K\min(R,2e^{-1/2})\sqrt V\right\}.
\]

The actual second-panel probabilities need not be independent of the contrasts. The same panel is coupled in both experiments, and its normalized conditional weights sum to one before the unconditioned bound is taken. A claim conditioned on one selected regime needs the corresponding conditional moment or a probability-denominator correction; the joint constant cannot be reused unchanged.

At the saved O/P reference, O has no cut query. Every P decoration has the same omitted vector as the previous fixed-P calculation. Therefore V=2 E[1_P ||eta^b||^2], which is bounded by twice the earlier unconditioned moment. The existing strict constants consequently give, under both recognition and the current model posterior,

\[
 \operatorname{TV}\le\min(1,0.628 K R),\quad t\in[5,7],
 \qquad
 \operatorname{TV}\le\min(1,0.494 K R),\quad t\in[35,40].
\]

These transferred upper bounds do not prove that the actual ancestry-dependent V decreases between the two windows. The earlier strict moment decrease concerns the different fixed-probe observable. No trajectory or moment enclosure was rerun to obtain this implication. Finite Gaussian moment ratios and the native path depend continuously on the prior in the already admitted positive-variance neighborhood. The strict bounds extend simultaneously with the two hierarchy-preference windows to a nonempty open family of fixed priors positive on every ancestry. The precise numerical reference intervals are not asserted throughout that neighborhood.

## A complete parent that keeps the responses

Suppose k first parents merge to q second parents, using a forest F with k-q edges. Store the old four-vector residual d_f on each selected forest edge, together with the ordinary new barycenters and individual surviving loop/cut marks. Within each new component C define

\[
 \chi_A=z_A-t_A-z_C,\qquad \sum_{A\subset C}n_A\chi_A=0.
\]

On a selected edge A to B, d_f=chi_B-chi_A. Tree integration and the mass-centering constraint recover every chi_A. For every old cut,

\[
 d_e=d_e^{\mathrm{new}}+\chi_B-\chi_A.
\]

The new geometry supplies d_e^new, including zero on a selected tree edge and the appropriate negative mark on an internal loop. Thus every old d_e, its unshifted parent probability and its anchored query is recovered exactly. This adds zero response error beyond the fine-to-first-parent approximation. The [interface derivation](selected-hierarchy-response-interface.md) proves the actual composition, passive translation covariance, normalized common conditional, and retained native negative ELBO/Fisher equality.

The continuous carrier contains twelve original probability/energy fields, 8q geometric fields and 4(k-q) response fields. Hence

\[
 N=12+4(k+q),\qquad
 N_{\mathrm{first}}-N=4(k-q),\qquad
 N_{\mathrm{fine}}-N=24-4q.
\]

The two-pair case is 28 to 24. The complete all-ancestry counts are recorded in the exact evidence. Extra response vectors replace the previous scalar cut-probability copies; both are not charged as if separately necessary. Discrete histories, input ports, evaluators, conditional distributions and controller costs remain additional.

At the O/P reference, q=2 exactly on the P_split branch and otherwise q=1. The new expected storage saving is therefore 20-4 Pr(P_split), greater than 18 fields throughout the later interval under both laws. This is a fresh consequence of the new count and saved regime probabilities. For other ancestries the old scalar and new vector counts differ; the previous complete workload license cannot be copied unchanged. A field saving is useful only when it exceeds the additional formation, metadata, evaluator, storage-access and controller costs under the chosen workload.

## Repeated contractions and historical input ports

The forest decoder composes. At each proper contraction retain the newly selected tree residuals, with their stage, orientation and child masses, alongside earlier response records. Reconstructing the next finer cut residuals from the coarser cut residuals and that stage's contrasts can then be repeated backward. Internal loops use their retained individual mark, and selected tree edges have zero new dressed mark. This recovers all advertised historical query baselines without reconstructing discarded merger-tree links.

For initial block count k0 and final count kL, the number of retained response four-vectors telescopes to k0-kL. The displayed carrier therefore has

\[
 N_L=12+8k_L+4(k_0-k_L)=12+4(k_0+k_L).
\]

Each proper merger still saves four real fields. Stage history, ports, panel records, controller memory and evaluation work remain charged; the telescoping identity does not bound their cost.

New current-parent input ports require their own fine-to-coarse error, rather than inheriting the old error by relabeling it. The [law derivation](selected-hierarchy-response-law.md) supplies that extension on this fixed graph. Flattened trees only add original edges joining disjoint blocks. There are finitely many reachable rooted forest geometries, with at most three edges; idle panel rounds add no geometry. For each initial H, collect the nonzero omitted-contrast rows for every cut in every reachable geometry, identifying rows only up to sign, and use their finite sum to define J_H^all. The resulting V_all=4 sum_H alpha_H tr(J_H^all C_H) bounds every historical or new current-cut query at any finite number of admitted contraction stages.

On the reference O/P support, this larger catalog adds no contrast: O never has a cut, and P either retains its original two cuts or merges to one root with no new cut. Historical P ports still remain active. Consequently the same 0.628 K R and 0.494 K R bounds hold, and the finite-catalog continuity argument supplies one sufficiently small positive-prior neighborhood for all finite depths. This is an analytical induction and finite-catalog theorem. The new mechanical calculation checks only the actual forty-five first geometries and 176 second-panel cases; it is not an enumeration of every history or a claim about an infinite hierarchy.

## Evidence and what remains

One new [exact response-map calculation](evidence/selected-hierarchy-response/response_maps.py) checked 68 omitted-vector identities on all forty-five decorated ancestries and the response decoder on all 176 previously retained second-panel maps. Every case passed under pinned CPython 3.14.7 in 0.07183760000043549 seconds. The [result](evidence/selected-hierarchy-response/response-maps.json) retains the complete rational coefficients, quadratic majorants, augmented maps, decoders and field counts. It reads the saved geometry maps; it does not rerun the older geometry producer.

The [separate reconstruction](selected-hierarchy-response-reconstruction.md) checks the new derivations and their scoped use of saved evidence. The [inspection receipt](evidence/selected-hierarchy-response/inspection.json) records source bindings, report checks and preservation. No old scientific calculation, ODE, observations, active configuration, broad suite, GPU, Lean, tamper check, vault edit, publication or canonical synchronization was performed.

The response contract now covers the actual native hierarchy's cut catalog, with all ancestry alternatives and the existing panel law retained. The full program still lacks operational selection for the original heterogeneous parity experiment: the approved qualitative coherence direction has supplied a response task and error curve, but no loss requirement, complete workload or fresh-confirmation precision is selected. The finite and Gaussian conclusions remain separate. Preserving these queries also does not require retaining separate intermediate geometric parents when a root can carry the same historical input ports. The existing exact negative admissions and their scientific acceptance remain intact.
