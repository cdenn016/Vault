# Learning structural links and conditional parent closure at one point

September 11, 2026. Work is at one fixed base point c_*. Agents retain their associated-fiber types; no base path or base-manifold transport appears. This derivation extends the existing fixed-target conditional-parent calculation to a target changed by structural learning. It provides an exact conditional-memory closure in an admitted exponential-family class. It does not select child blocks, establish coalescence, or complete the RG program.

## Existing result and the new obligation

The [September 8 conditional-parent derivation](../2026-09-08-conditional-parent-inference.md) already gives the centered conditional-KL correction to projected full-family Fisher flow, and [categorical completion](../2026-09-08-categorical-conditional-completion.md) gives its fixed-target finite-time update. Those calculations must not be presented as new here. The [August pointwise result](../2026-08-14-pointwise-meta-agent-rg/evidence/direct-derivation.md), Section 9, already states the moving-map chain rule. The [full graph VFE](../../../Theory/07c_full_graph_meta_agent_vfe.tex) includes structural/link coordinates in its complete datum, and [ELBO parameter acceptance](../../../Theory/05_elbo.tex) distinguishes an actual accepted update from a proposed direction.

There are two meanings of a dynamic link. If a link is a latent coordinate of a fixed generative joint, inference changes its posterior along with other coordinates; the existing fixed-target formulas apply after including it in the fine state. If an independently parameterized link changes the generative model itself, its posterior target changes. The calculation below addresses this second case. Neither reading is silently substituted for the other.

## 1. Fixed-point types and regularity

Fix an observation o and a normalized generative model with positive evidence e_theta(o). In a retained/hidden coordinate description (z,u), write its selected posterior as

\[
 \pi_\theta(z,u)=s_\theta(z)b_\theta(u\mid z),\qquad
 q(z,u)=r(z)a(u\mid z).
 \tag{1}
\]

For a completely elementary domain, z and u range over finite sets and all displayed masses are positive. The integral version holds on a fixed dominated product support when the differentiations and conditional expectations below are justified and the displayed KL and score moments are finite. This regular dominated tier is an assumption, not a restriction of the ambient general-law theory. Coordinates are fixed at c_*; inference index t is neither base position nor RG depth.

The parameter theta may include independent inter-agent links, as local coordinates on their declared parameter manifold, as well as model parameters. Link metrics and any gauge identifications remain part of that model. A fixed retained map is assumed. If selection reads q and changes the map, the existing moving-map term is additionally required; this derivation does not omit it by calling adaptive selection fixed.

The exact fine VFE is

\[
 \mathcal F(q,\theta)=\mathrm{KL}(q\Vert\pi_\theta)-\log e_\theta(o).
 \tag{2}
\]

Adopt the existing full-law Fisher E-flow, with theta held fixed in the E-direction, and let theta follow an actual differentiable learning trajectory:

\[
 \dot q=-q\left[\log(q/\pi_\theta)
                    -\mathbb E_q\log(q/\pi_\theta)\right],
 \qquad \dot\theta=V(q,\theta).
 \tag{3}
\]

Equation (3) declares a continuous update contract. It is not an assertion that a finite Armijo step, a local per-agent metric, or an arbitrary implementation equals this full-law flow. The formulas first hold for any smooth supplied V; Section 4 supplies a descent-compatible choice with an explicitly declared metric.

## 2. Exact moving-target parent and conditional equations

Define

\[
 d_z=\mathrm{KL}(a(\cdot\mid z)\Vert b_\theta(\cdot\mid z)),
 \quad \bar d=\sum_z r_zd_z,
 \quad F_r=\mathrm{KL}(r\Vert s_\theta).
 \tag{4}
\]

Marginalizing (3) and then differentiating a=q/r gives

\[
 \dot r_z=-r_z\left[\log(r_z/s_{\theta,z})-F_r+d_z-\bar d\right],
 \tag{5}
\]

\[
 \dot a(u\mid z)=-a(u\mid z)
       \left[\log\frac{a(u\mid z)}{b_\theta(u\mid z)}-d_z\right].
 \tag{6}
\]

These equations are exact even while theta changes. To prove them, split the log ratio in (3) into log(r/s) plus log(a/b), condition on z, and use E_q log(q/pi)=F_r+bar d. Subtracting (5) from the logarithmic derivative of q cancels every retained-only term and yields (6). No derivative of the target occurs in the instantaneous E-direction; its time variation instead changes the right-hand side.

The conditional discrepancy satisfies the additional identity

\[
 \dot d_z
 =-\operatorname{Var}_{a(\cdot\mid z)}
       \left(\log\frac{a}{b_\theta}\right)
   -\mathbb E_{a(\cdot\mid z)}
       \left[D_\theta\log b_\theta(u\mid z) V(q,\theta)\right].
 \tag{7}
\]

Differentiate the KL integral. The derivative through a is the first variance by (6) and normalization; differentiating the target contributes the second term. Thus structural learning can replenish conditional mismatch while E-inference removes it. The mean conditional KL and its variation across parent states play different roles: only the centered field in (5) changes the instantaneous parent E-velocity.

### Exact matching is not automatically an invariant set

On the set a=b_theta, equation (6) gives dot a=0. Remaining on that set also requires

\[
 D_\theta b_\theta(\cdot\mid z) V(q,\theta)=0
 \quad\text{for every positive-mass retained state }z.
 \tag{8}
\]

This is the tangent condition for invariance of the matching set under the declared coupled flow. Under ordinary smooth finite-dimensional local existence and uniqueness, tangency at every point of this set gives local invariance. Matching at one instant alone does not. This condition allows links to move in directions that preserve the relevant conditionals; it does not assert that all links must freeze. It also does not require d_z=0 for parent autonomy: the weaker instantaneous condition is constancy of d_z on the retained support, whose persistence must still be proved.

For a twice differentiable finite positive trajectory starting from a=b_theta at t=0, define the conditional target speed

\[
 v_z^2=\mathbb E_{b_{\theta(0)}(\cdot\mid z)}
  \left[\left(D_\theta\log b_{\theta(0)} V(q(0),\theta(0))\right)^2\right].
 \tag{9}
\]

The two coincident conditional distributions have initial velocities zero and dot b respectively. Expanding KL at equality gives

\[
 d_z(t)=\tfrac12t^2v_z^2+o(t^2),
 \qquad
 \Delta\dot r_z(t)
 =-\tfrac12t^2r_z(0)
   \left[v_z^2-\sum_w r_w(0)v_w^2\right]+o(t^2).
 \tag{10}
\]

Here Delta dot r compares (5) with the autonomous-parent Fisher vector evaluated at the same current r and supplied theta. In finite support the expansion follows directly from log(1+x)=x-x^2/2+o(x^2), cancellation of normalized first variations, and the conditional score's zero mean. Equality of the speeds removes this leading term only; it is not a proof of exact closure.

## 3. Finite conditional-memory closure when the moving target stays exponential

Suppose every conditional target and initial recognition conditional belongs to one fixed regular minimal exponential family,

\[
 b_\theta(u\mid z)=h_z(u)
    \exp\left[\eta_z(\theta)^\top T_z(u)-A_z(\eta_z(\theta))\right],
 \quad
 a(u\mid z)=h_z(u)
    \exp\left[\alpha_z^\top T_z(u)-A_z(\alpha_z)\right].
 \tag{11}
\]

The natural-parameter domain is open and convex, the statistics and carrier h_z do not change during the update, and the evolving parameters stay in this regular domain. Substitution into (6) gives the closed exact equation

\[
 \dot\alpha_z=\eta_z(\theta)-\alpha_z,
 \tag{12}
\]

because dot log a=dot alpha_z transpose (T_z-grad A_z(alpha_z)). Its solution along any supplied learning path is

\[
 \alpha_z(t)=e^{-t}\alpha_z(0)
       +\int_0^t e^{-(t-s)}\eta_z(\theta(s))ds.
 \tag{13}
\]

This is inference memory forced by the moving model, not a new chosen time-scale coefficient. The coefficient one comes from the E-flow normalization in (3); changing that clock changes (12) correspondingly. It does not prove that a complete parent is slower than its children.

The discrepancy needed by (5) is evaluated from the same retained parameters:

\[
 d_z=(\alpha_z-\eta_z)^\top\nabla A_z(\alpha_z)
                  -A_z(\alpha_z)+A_z(\eta_z).
 \tag{14}
\]

Therefore (r,alpha,theta) is an autonomous description of (3) whenever the actual V can be evaluated from those variables. It reconstructs q=r a_alpha, so its sufficiency is exact on this admitted family. It does not compress information relative to that already parameterized fine family. Compared with a dense finite conditional table it can reduce stored coordinates when dim alpha_z is smaller than the number of conditional cells minus one; this is a representation count, not evidence of formed child blocks.

## 4. Coupled model learning and exact descent

The model derivative in an M-direction holds the recognition law fixed. Using pi_theta=s_theta b_theta in (2), define

\[
 g_\theta:=\left.\partial_\theta\mathcal F(q,\theta)\right|_q
 =-\partial_\theta\log e_\theta(o)
   -\sum_z r_z\partial_\theta\log s_{\theta,z}
   -\sum_z r_z[D_\theta\eta_z]^\top
          [\nabla A_z(\alpha_z)-\nabla A_z(\eta_z)].
 \tag{15}
\]

This follows by differentiating the normalized conditional log density at fixed a_alpha. The evidence derivative and all target normalizers are retained. They cannot be dropped when theta changes the generative joint.

Choose a positive-definite parameter metric M(theta) on the identifiable structural chart, for example the model Fisher metric when it is nondegenerate and evaluable. The metric is additional declared geometry, not a raw Euclidean Lie-algebra update or a claimed canonical metric for every gauge model. Set

\[
 V=-M(\theta)^{-1}g_\theta.
 \tag{16}
\]

Equations (5), (12), (15), and (16) close on the augmented state, and

\[
 \frac{d}{dt}\mathcal F(q,\theta)
 =-\operatorname{Var}_q\left(\log\frac{q}{\pi_\theta}\right)
  -g_\theta^\top M^{-1}g_\theta\le0.
 \tag{17}
\]

The first term follows by substituting the normalized E-direction into the derivative at fixed theta; the second is the ordinary pairing of the M-covector with (16). This is exact descent for the declared continuous block geometry. It proves neither global existence nor convergence to a particular partition; degeneracies, support loss, parameter-boundary escape, and finite integration steps require their own admission.

## 5. A small analytic discriminator

Let z,u be binary, s_theta(z)=1/2, and b_theta(u=1|z)=sigma(c_z theta), with sigma the logistic function, c_0=1 and c_1=2. Start q at the uniform four-state law and supply theta(t)=t. This supplied path is a discriminator for target motion, not a claimed M-descent trajectory or a model of agent formation.

The conditional log odds satisfy alpha_z'=c_z t-alpha_z, so

\[
 \alpha_z(t)=c_z(t-1+e^{-t}).
 \tag{18}
\]

Equation (9) gives v_0^2=1/4 and v_1^2=1. Hence d_0=t^2/8+o(t^2), d_1=t^2/2+o(t^2), and the parent velocity at the current state differs from its uniform-target Fisher velocity by +3t^2/32+o(t^2) in cell zero and the opposite amount in cell one. If ell=log(r_0/r_1), (5) gives ell'=-ell+d_1-d_0; integrating its Taylor coefficient yields

\[
 r_0(t)=\tfrac12+\tfrac1{32}t^3+o(t^3).
 \tag{19}
\]

The standalone parent Fisher flow with the same constant target remains uniform. Thus target changes confined to hidden conditionals can move the fine-induced parent even when its target marginal stays fixed. This analytic example checks the sign and normalization of (7)-(10); it is not a new scientific dataset or numerical confirmation.

## 6. Relation to the intended single-point hierarchy

This calculation provides a concrete condition and a constructive conditional-memory route for the missing moving-structure arrow. The model evaluator p_theta(o,z), the conditional family, its statistics, the structural metric, and the actual parent map must all come from the selected pointwise model. If they are not available, (11) is an unadmitted hypothesis, not a solution by relabeling. Generic variable marginalization does not preserve a fixed exponential conditional family.

For nested fixed parent maps, ordinary marginalization still composes. A memory closure at each depth additionally needs its own invariant conditional family and all shared structural parameters/records carried consistently. The equations above do not assert that independently fitted parent families satisfy those requirements. Dynamic membership changes need the moving-map correction and may change the memory dimension.

Vanishing inter-agent mismatch, an invariant low-dimensional conditional family, and useful recursive coalescence are separate obligations. This result closes neither the block selector nor the original heterogeneous compression gate. It also does not replace the user's independent dynamic links by frame coboundaries. Passive coordinate changes that are fixed during the inference trajectory preserve the KL identities by common pushforward; time-dependent coordinate changes need their usual coordinate-velocity terms and are not new physical forces.

The next decisive application is to identify the actual pointwise generative factors and link update, and determine whether their hidden conditional family satisfies (11) or what statistics it generates beyond that family. No base-manifold extension is authorized by this result.


## 7. Second derivation from the actual recognition Fisher metric

This reconstruction checks the update by a separate coordinate calculation; it is not an independent review or a numerical test. In the regular minimal family (11), let H_z(alpha)=nabla squared A_z(alpha). A tangent (delta r,delta alpha) with sum delta r=0 has score

\[
 \delta\log q(z,u)=\frac{\delta r_z}{r_z}
       +\delta\alpha_z^\top[T_z(u)-\nabla A_z(\alpha_z)].
 \tag{20}
\]

The second term has zero conditional mean. Squaring the score and taking its expectation therefore gives the exact Fisher quadratic form

\[
 \mathsf G_q(\delta,\delta)
 =\sum_z\frac{(\delta r_z)^2}{r_z}
   +\sum_z r_z\delta\alpha_z^\top H_z(\alpha_z)\delta\alpha_z.
 \tag{21}
\]

The cross term vanishes by conditional centering; distinct z blocks have disjoint support. Differentiating (2) in these coordinates, with theta fixed, gives

\[
 \partial_{\alpha_z}\mathcal F
   =r_zH_z(\alpha_z)(\alpha_z-\eta_z),
 \qquad
 \partial_{r_z}\mathcal F
   =\log(r_z/s_{\theta,z})+1+d_z.
 \tag{22}
\]

Inverting the actual conditional Fisher block r_z H_z gives (12), with no spurious occupancy factor. The simplex natural gradient subtracts the r-weighted mean of its covector, giving (5). Thus these equations are the restriction of the full-law E-flow to an invariant conditional family, not an approximation obtained by replacing its Fisher metric with unweighted agent blocks.

For coupled parameter learning, the declared product metric is G_q plus M(theta). It is not the Fisher metric of q alone on theta directions: q in the independent coordinates (r,alpha,theta) has no theta dependence, so that Fisher block would be zero. Structural learning uses the separately specified model metric in (16). This distinction prevents a false full-joint-Fisher identification. With that product metric the two nonpositive terms in (17) follow exactly.

At matching a=b_theta, (22) gives zero conditional recognition velocity while a moving eta has nonzero parameter velocity. This reproduces the tangent test (8) without differentiating a KL integral. In the binary discriminator H_z(0)=1/4, so (21) independently gives the conditional speeds c_z squared divided by four and the coefficient 1/32 in (19).
