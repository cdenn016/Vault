# One prior family with successive native hierarchy preferences

September 12, 2026. One fixed strictly positive ancestry prior can support both previously separate stages. In the existing transported Gaussian specialization, an open family of priors starts with one-block ancestry preferred, develops a two-pair preference, and later prefers the history in which those two parents merge. The complete split-pair regime is uniquely most probable throughout native times [5,7], and the merged-pair regime throughout [35,40], under both the actual recognition law and the current model posterior. The two-stage carrier preserves the declared original and parent-cut queries, joint negative ELBO and native Fisher information. Its expected storage saving exceeds eighteen real-valued fields per draw during the later window.

This closes the common-prior gap between the earlier first-level crossing and later second-level episode. It is a conditional finite-family result. The prior family is constructed around an exact initial posterior-tie surface, not estimated by a new prior-learning mechanism. The parent panel is a fixed normalized auxiliary kernel. Neither its modal history nor the conditional resource inequality establishes that this history is the operationally best organization, a permanent membership, a microscopic link trajectory or an autonomous agent.

## 1. Sources and the exact reference

[Native ancestry crossings](native-ancestry-crossings-and-selection-loss.md), Sections 1-3, supplies the full seven-coordinate learner and a local O-to-P crossing region. [Unit-start second merge](unit-start-second-merge-and-positive-prior-persistence.md), Sections 3-6, supplies the saved-path enclosure method and a later episode for a different, near-P prior family. [The resource frontier](native-episode-resource-frontier.md) supplies complete assembly/storage pricing and its selection countercomparison. Those results could not previously be placed on a single fixed-prior trajectory.

The live [PIFB2 source](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, distinguishes the barycenter, coherence detector and net resource license. Its `sec:cross_scale_shadows` and `app:augmented_joint` motivate the parent-predictive family without making a recognition-dependent generative factor legitimate. The operational [wiki definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires a joint law, evaluator, access, marks and memory. The [transported-prior derivation](transported-parent-priors-and-induced-couplings.md) and [complete-channel construction](shared-parent-complete-channel-and-recursive-cost.md) remain the normalization and geometry authorities.

Keep the four-cycle, original ordered records with success counts (8,1,8,1) and one failure per label in both channels, all twelve connected ancestries and their forty-five decorations. Both channels share the same ancestry and decoration. Work stays at one base point. Model and recognition variances start at one; the matched root remains at variance one, and likelihood power s=1 remains exactly invariant. No new observation or likelihood factor is added.

Write O={{0,1,2,3}} and P={{0,1},{2,3}}. Let zeta_O^0,zeta_P^0 be their saved exact unit evidences, already averaged over sixteen and four decorations respectively. Define the boundary reference

\[
 \pi_O^0=\frac{\zeta_P^0}{\zeta_O^0+\zeta_P^0},\qquad
 \pi_P^0=\frac{\zeta_O^0}{\zeta_O^0+\zeta_P^0},\qquad
 \pi_R^0=0\quad(R\ne O,P).
 \tag{1}
\]

Its two nonzero entries are approximately 0.288410341942445 and 0.711589658057555. They are exact rational functions of the retained evidence fractions, not rounded input parameters. Equation (1) makes the initial O and P posterior masses both one half. It specifies a reference within the preexisting prior family for a sensitivity theorem. It is not a recommendation to choose a prior after inspecting the same records, and no numerical full-positive prior is selected as the final scientific model.

## 2. The full native flow, including count memory

Let a_j be model variances and r_j recognition variances for j=a,b,c. Set x_j=log a_j, y_j=log r_j and lambda=omega-2 log rho_b, where rho_b=1/r_b. The same normalized joint gives

\[
 \begin{aligned}
 \dot a&=\langle E_a\rangle_Q/16-a,\qquad
 \dot c=\langle E_c\rangle_Q/16-c,\\
 \dot b&=\frac{\langle E_b\rangle_Q}{4K_\pi}
          -\frac{\langle k\rangle_Q}{K_\pi}b,\qquad
 K_\pi=\sum_R\pi_R k(R),\\
 \dot r_j&=r_j(1-r_j/a_j),\\
 \dot\lambda&=-\lambda-2[r_b/b-1-\log(r_b/b)].
 \end{aligned}
 \tag{2}
\]

The reference has K_pi=pi_O^0+2 pi_P^0, approximately 1.71158965805756. It cannot be replaced by two, by the current recognized expected block count, or by a fixed-P update. The count coordinate is active even though only two ancestries have positive reference weight. All seven coordinates start at zero in (x,y,lambda). The global positive finite-time existence argument in the native-learning derivation applies to this closed field and to every nearby proper prior.

For each decoration H and failure mask B, reuse

\[
 D_{H,B}(r)=\det[I+(r_aG_a+r_bG_b+r_cG_{c,H})\operatorname{diag}(n+1_B)],
 \qquad
 e_H(r)=\sum_B(-1)^{|B|}D_{H,B}(r)^{-1}.
 \tag{3}
\]

The reference has seven distinct covariance maps. The forty-eight P determinant polynomials were reused unchanged; sixty-four O polynomials were computed exactly. All have constant term one and positive nonzero coefficients, and their unit sums reproduce both saved evidence fractions exactly.

Put y_H=pi_R exp(lambda(k_R-1))/N_R; the removed common exp(lambda) factor changes no normalized expectation. Define

\[
 Z=\sum_H y_H e_H^2,\qquad
 K=Z^{-1}\sum_H y_H k_H e_H^2,\qquad
 A_j=Z^{-1}\sum_H y_H e_H\partial_j e_H.
 \tag{4}
\]

Then the log model rates used by the validator are

\[
 \begin{aligned}
 \dot x_j&=e^{y_j-x_j}-1+
       \tfrac14e^{2y_j-x_j}A_j,\quad j=a,c,\\
 \dot x_b&=\frac{K}{K_\pi}(e^{y_b-x_b}-1)
             +\frac1{K_\pi}e^{2y_b-x_b}A_b.
 \end{aligned}
 \tag{5}
\]

This follows from E_a=16r_a+4r_a^2 A_a, E_c=16r_c+4r_c^2 A_c, and E_b=4r_b K+4r_b^2 A_b. The recognition rates are 1-exp(y_j-x_j), followed by the last equation of (2).

For a checkable Jacobian construction, define T_jl=sum_H y_H[(partial_j e_H)(partial_l e_H)+e_H partial_jl e_H] and B_j=sum_H y_H k_H e_H partial_j e_H. Direct differentiation gives

\[
 \partial_{r_l}A_j=T_{jl}/Z-2A_jA_l,\qquad
 \partial_\lambda A_j=B_j/Z-KA_j,
 \tag{6}
\]

and

\[
 \partial_{r_l}K=2(B_l/Z-KA_l),\qquad
 \partial_\lambda K=E_Q(k^2)-K^2.
 \tag{7}
\]

Applying these identities to (5) and differentiating the explicit recognition/count rates gives the complete seven-by-seven Jacobian. No dependence on lambda or the block normalization is suppressed.

## 3. Numerical candidate and rigorous path enclosure

One DOP853 diagnostic integrated this reference from native time zero to forty, with relative tolerance 10^-10, absolute tolerance 10^-12 and maximum step 1/8. It completed 325 accepted steps and 4,877 right-hand-side calls in 0.558307599996624 seconds. Every accepted state and dense polynomial is saved in [reference-trajectory.json](evidence/joint-native-episode/reference-trajectory.json). This is a new O/P reference; the earlier fixed-P trajectory was not repeated or extended.

The diagnostic's most probable regime changed from O to P_split between accepted times 2.9081 and 3.0331, and from P_split to P_merge between 30.5331 and 30.6581. These are numerical brackets, not certified crossing times or uniqueness results. The minimum recorded signed-sum ratio was approximately 3.67089 x 10^-6.

Before validating the path, all forty-nine analytic Jacobian entries at one saved state were compared with derivatives propagated separately through the full vector field. Their outward intervals overlap. Three declared path intervals also admitted small residual and logarithmic-norm bounds. This bounded check addresses the new Jacobian/count coupling; it does not by itself certify the trajectory.

The [path enclosure](evidence/joint-native-episode/enclose_reference_path.py) then treats each stored binary polynomial coefficient as an exact rational candidate. It uses the existing 128-bit dyadic arithmetic, positive-series exponential bounds, order-16 residual jets, order-12 Jacobian jets and exact rational LDL upper-eigenvalue tests. The constant error norm has

\[
 W=\operatorname{diag}(1,1/\sqrt2,1,1,1/\sqrt2,1,1/2).
 \tag{8}
\]

This matrix prices numerical error only; it changes no native Fisher metric or learning rate. The largest symmetric part of W J W^-1 bounds the logarithmic norm on each candidate tube. If b is its current error, R a defect bound and L a logarithmic-norm bound, the same first-exit proof as the earlier enclosure gives

\[
 D^+\|z-p\|_W\le L\|z-p\|_W+R.
 \tag{9}
\]

Integrating this inequality, charging every polynomial-piece jump, and verifying each within-step bound below its tube radius closes the induction from the exact zero initial error. The exact reference prior fractions, rather than the floating-point trajectory's rounded weights, enter (4)-(7) in this validation.

All 326 subinterval checks passed through time forty in 401.73523019999993 seconds. The uniform weighted error is below 1.127 x 10^-8, hence every individual log-coordinate/count error is below 2.254 x 10^-8. The [certificate](evidence/joint-native-episode/path-enclosure.json) stores rational endpoints, complete symmetric-matrix bounds and positive LDL pivots. Floating-point eigenvalues only propose rational bounds that the exact factorization then checks. This is a certificate for the actual solution of (2) against the saved candidate, not another integration or a solver-tolerance claim.

## 4. One second-panel rule for every ancestry

Use a single rule on the actual first parents of any realized H. On each cut between distinct first parents, compute the two original-form transported Gaussian agreement probabilities from their barycenters and individual dressed cut. The active-edge probability is their product. Draw independent edge flags conditional on the complete retained state, form their connected components, and choose a spanning forest by increasing original edge label. Root each new component at the smallest retained root label. These are fixed graph-label conventions, applied to every ancestry; no branch tests whether its ancestry is P.

The kernel is normalized and parameter independent. It is the marginal active-edge version of the existing two-channel flag construction, and adds no observed record. On P, it reproduces the previous two-cut merge probability exactly. On O there is no cut between distinct first parents. Other ancestries now receive the same panel rule rather than a fixed no-merge branch.

Let k be the first number of blocks, q the number after the panel, and n_A each first block's mass. In the current four-cycle, k>1 has k cuts, while k=1 has only its internal loop. For each new component C, its retained geometry is

\[
 z_C=\frac{\sum_{A\subset C}n_A(z_A-t_A)}{\sum_{A\subset C}n_A},\qquad
 V_e^{\rm new}=V_e+t_A-t_B.
 \tag{10}
\]

Carry every surviving loop/cut copy, original label and structural history. Always retain H, the eight original probabilities and all four learned-prior energies. Whenever q<k, additionally retain both channel probabilities on every first-parent cut; there are 2k of them. If no merge occurs, these values are computable from the unchanged barycenters and marks, so separate stored copies are unnecessary. This rule preserves the same old and newly admitted pair-cut query contract on P and its corresponding first-parent-cut contract on other ancestries.

There are 176 decoration/active-mask cases: 16 at k=1, 80 at k=2, 64 at k=3 and 16 at k=4. The [exact geometry calculation](evidence/joint-native-episode/uniform_panel_geometry.py) checks every case. It constructs the first map on formal child means and links, the second map on actual first outputs, and the direct flattened map. Exact Fraction multiplication gives equality of the composite and flattened maps in all 176 cases, with exactly q non-tree marks retained. This checks the declared finite maps; the existing transformation laws supply general translation covariance.

The common sufficient statistic (H,p,E_a,E_b,E_c,E_v) survives every branch. Its prior and recognition density ratios and scores are unchanged along a retained fiber. Applying the single normalized panel to a fixed full-support reference therefore gives the same common-conditional proof of exact negative-ELBO and Fisher equality. Original and first-parent-cut Bernoulli query paths from a frozen draw are identical under every common adaptive label policy, by coupling their uniforms and inducting on the retained history. Controller memory is carried and charged. This does not define how an individual sample moves when the native parameters change.

The evaluated parent law uses Radon-Nikodym densities against that normalized reference, the retained record kernels and the existing moment evaluator. Its downward kernel is the correlated reference conditional. Replacing it by independent Gaussian child resets would change the recognized law. Repeating an admitted contraction requires retaining every further evaluator before its arguments are discarded; the fixed finite-depth composition theorem remains conditional on that retention.

## 5. Two rigorously separated regime windows

Define a regime by its pair of ancestry partitions (R,R_2), summing over roots, spanning-tree decorations and active masks within that pair. Structural details remain in each complete sample. The regime O means (O,O), P_split means (P,P), and P_merge means (P,O). Their final one-block outputs in the first and third cases have different retained ancestries; they are not the same complete model merely because their final partition is one block.

At the reference let w_P=Q(P), and let M_P be the conditional parent merge probability. The three regime masses are

\[
 q_O=1-w_P,\qquad q_{\rm split}=w_P(1-M_P),\qquad
 q_{\rm merge}=w_PM_P.
 \tag{11}
\]

The current model posterior uses the same formulas at model variances with lambda=0; the native recognition uses recognition variances and its driven lambda. A strict merged mode requires q_merge to exceed both competitors, not to exceed one half of all mass. This is the ordinary most-probable-category comparison on the declared regime catalog. It neither conditions the law on that category nor discards alternative histories.

The [window enclosure](evidence/joint-native-episode/enclose_regime_windows.py) evaluates complete probability-ratio jets, retaining the common evidence denominator and its dependence on the same path. It reuses the saved 144 activated P determinant polynomials. Seventeen intervals cover [5,7] and forty-one cover [35,40]. All comparisons passed in 20.554244099999778 seconds. The following lower bounds are rounded downward from the exact [window evidence](evidence/joint-native-episode/regime-window-enclosures.json).

| Window and strict comparison | Recognition margin | Model-posterior margin |
| --- | ---: | ---: |
| [5,7]: P_split minus O | >0.1416 | >0.2089 |
| [5,7]: P_split minus P_merge | >0.2326 | >0.2308 |
| [35,40]: P_merge minus O | >0.4296 | >0.4323 |
| [35,40]: P_merge minus P_split | >0.0123 | >0.0171 |

At the initial reference, the masses are exactly one half for O, (1-M_0)/2 for P_split and M_0/2 for P_merge, with the saved M_0 approximately 0.2938789175. O is therefore the unique initial regime, despite its ancestry tie with P. Continuity gives a positive initial O-dominant interval. The two later windows prove at least two separated changes in the preferred regime. They do not prove unique global crossing times or exclude further changes outside those windows.

The conditional merge readout is uniformly above 0.5092 in recognition and 0.5117 in the model posterior on [35,40]. The enclosed merged-regime mass does not establish a majority throughout that interval. The earlier stronger majority result near the fixed-P prior remains valid for its own different family.

## 6. A single open family with every ancestry prior positive

The preceding reference lies on a boundary of the full prior simplex. The full field (2) and all finite regime probabilities extend smoothly in pi on a compact neighborhood of its certified positive path. Their denominators are finite sums of positive conditional evidences, and K_pi is bounded away from zero. On that compact set, finite state and parameter derivative bounds give uniform continuous dependence through time forty. For example, with state Lipschitz constant L and prior derivative bound B, a perturbation of size delta obeys the usual bound B delta times (exp(Lt)-1)/L, with its continuous L=0 interpretation. No numerical neighborhood size is asserted.

An explicit direction into the desired region is

\[
 \begin{aligned}
 \pi_O(\varepsilon)&=\pi_O^0+\varepsilon,\\
 \pi_P(\varepsilon)&=\pi_P^0-\varepsilon-10\varepsilon^2,\\
 \pi_R(\varepsilon)&=\varepsilon^2,\quad R\ne O,P.
 \end{aligned}
 \tag{12}
\]

For sufficiently small epsilon>0 these twelve weights are positive and sum to one. At the unit preparation the O-minus-P unnormalized posterior weight is

\[
 \varepsilon(\zeta_O^0+\zeta_P^0)
       +10\varepsilon^2\zeta_P^0>0.
 \tag{13}
\]

All other weights are order epsilon squared, so O is the unique initial ancestry. Every such prior is held fixed during its native evolution; (12) is an existence construction, not a fitting algorithm.

Choose epsilon small enough to preserve all strict margins of Section 5 under uniform finite-time dependence. The total mass of the other ancestries is then uniformly small. Each of their second-stage regimes has mass at most its own ancestry mass, so none can overtake the certified winner. This proves the early P_split and later P_merge windows under both recognition and model posterior for the same fixed full-positive prior. The inequalities are strict, hence each sufficiently small member of (12) has a full-dimensional relative-open neighborhood in the prior simplex with the same property. The theorem therefore concerns a nonempty open family, not just the one-dimensional perturbation curve.

The earlier local crossing theorem can also be applied within that same family. Its initial O/P log advantage tends to zero from above as epsilon tends to zero; its advantages over every other ancestry diverge. Choose its positive local time T below five, and then epsilon small enough to meet its strict acceleration/remainder inequalities. The actual ancestry O-to-P crossing is then established before the early regime window, with P uniquely preferred on the theorem's subsequent local interval. The new regime windows supply the later first-pair and second-merge episodes. No result from an incompatible prior trajectory is concatenated into this proof.

The exact initial native model gradient is nonzero at the reference, as the saved rational energy rates show. It remains nonzero in a sufficiently small prior neighborhood. Since Q_0 is the exact unit model posterior and the same negative ELBO decreases along (2), F(t)<F(0) for every positive time. The identity F=KL(Q||posterior)-log evidence then gives strict original-data model-evidence improvement over the initial preparation. This is shared by the fine implementation and is not an additional coarse-graining benefit.

## 7. Complete resource bound for this same family

For the uniform panel, the displayed continuous parent count is

\[
 N_{\rm parent}=12+8q+2k\mathbf1_{q<k},\qquad
 N_{\rm fine}=36+4k.
 \tag{14}
\]

At k=1 no merge occurs and the added-probability term is zero. These counts include every required first-parent-cut evaluator after a contraction. All 176 cases have at least eight saved fields. Their largest saving is twenty-four; none has more fields than the complete first-parent state. In particular the P branch still has 44 fine fields, 28 split fields and 24 merged fields.

At the O/P reference the expected saving is exactly

\[
 E(N_{\rm fine}-N_{\rm parent})=20-4q_{\rm split}.
 \tag{15}
\]

The same complete-output enclosure gives uniform lower bounds greater than 18.1194 fields in recognition and 18.1287 in the model posterior on [35,40]. The finite case catalog and uniform prior/path continuity preserve a strict saving greater than eighteen on a smaller nonempty open family satisfying all of Section 6. This places the learned-stage episodes and storage margin under the same fixed proper prior.

The earlier coupled generator gives the fine implementation the same residual-first rejection, visible conditional Gaussian factors, exact normalizer/moment solver and analytic link reduction. Its first-parent assembly uses at most 52 multiplications and 80 additions under the declared arithmetic convention. Here at most four cut activations add 28 multiplications, 40 additions, eight exponentials, four uniforms and four comparisons. The exact 176-case geometry maps use at most 28 multiplications and 36 additions across all four coordinate directions. A fixed lookup by H and the active-bit mask selects the precomputed map; charge its bit operations and lookup by c_case. A conservative upper bound on extra parent assembly relative to the coupled fine baseline is therefore

\[
 A_G=108c_{\times}+156c_++8c_{\exp}
           +4c_U+4c_{\rm cmp}+c_{\rm case}.
 \tag{16}
\]

As before, ignoring the fine completion's positive cost and granting its required panel/readout calculation for free favors the fine side of this bound. Factor preparation, the full lookup catalog, static storage and backend/interface construction are charged separately. This is a straight-line ideal-real calculation, not a lower bound over algorithms, a finite-bit claim or a benchmark. Exact rejection still has finite expected cost on the compact native region; the earlier unit-state numerical rejection constants are not imported to this window.

For N resident frozen-law draws retained for L accounting ticks, real-field charge c_w>0, extra one-time setup B_0, static overhead B_s per tick and recurring metadata/access charge d per draw per tick, the same sufficient license is

\[
 NL(18c_w-d)-LB_s>B_0+NA_G.
 \tag{17}
\]

It has a nonempty finite N,L region whenever d<18c_w and the other charges are finite: first choose N with N(18c_w-d)>B_s, then choose L beyond the displayed setup/assembly threshold. These accounting ticks do not lengthen the native interval or specify a physical clock. All noncommon costs must retain their actual dependence on N and L. In particular, repeated first-parent-cut queries on an unmerged branch may require recomputation: charge that work in d. Caching those extra probabilities instead changes the sample-field count and must be priced explicitly. No resource price or actual machine workload is chosen, and no conversion of memory/time into nats is derived. The exact negative ELBO and native law solver are shared across representations.

## 8. What is completed and what is still a selection question

The conditional finite construction now has one full-positive-prior family with learned first-ancestry change, two proper first parents, a later second-parent preference, complete normalized channels, actual-output geometric composition, original and retained new response sufficiency, native Fisher closure, finite preference intervals and a complete conditional resource inequality. The original fifteen exact heterogeneous local admissions remain completed negative results under their different strong-exterior contract. Neither family overwrites the other.

The complete law retains every ancestry and alternative panel outcome. A most-probable history is a summary of that law, not an exact support collapse or a permanent individual membership. The first-parent induced prior and reverse kernel inherit learning from the same joint; no independently fitted next-level reset is introduced. Individual link motion, filtering of a changing sampled state, active coordination and a physical clock still require a stated transition/observation contract. The present frozen-query path equality must not be presented as those stronger statements.

The resource frontier's selection countercomparison also survives. For only the retained original and first-parent-cut queries and native sufficient statistics, forcing the P branch to merge preserves the same statistical experiment and saves additional fields. The generic panel does not derive an operational reason to keep separate first-parent means on its split branch. Conversely, requiring those means statewise changes the admissible query contract. A fine implementation allowed to emit the same sufficient carrier can use the same algorithm. Thus (17) licenses a declared representation/workload comparison; it does not establish a unique or universally best formation rule.

The next action is a requirement-by-requirement reconciliation of the revised September 11 attachment, later one-base-point directions and the current completion gates against these artifacts. That should identify which remaining obligations are explicitly specified and executable, which are already established conditionally, and which require external operational information. Do not add another trajectory horizon, a new prior search, a penalty, a physical dynamics requirement or a global convergence condition merely to keep the investigation running. The full goal stays active until that reconciliation supports its actual requested endpoint or identifies a genuine external impasse.

The calculations and their complete outputs are in [evidence/joint-native-episode](evidence/joint-native-episode). They comprise one bounded numerical reference, new exact O coefficients with P coefficients reused, a 49-entry Jacobian comparison and three local probes, the saved-path enclosure, both regime windows, and the 176 uniform geometry cases. All passed in their stated scopes. No previous scientific main, fixed-P trajectory, parameter grid, sampled flag/state, new data, full suite, GPU, Lean or tamper check was run. Production/configuration files, source manuscripts, historical failures, prior passing results and protected WIP remain preserved. No vault edit, publication or canonical synchronization occurred. No formal-ledger or independent-review certificate is issued.
