# Shared-parent record laws, ancestry, and the remaining learning gate

September 11, 2026. This continuation follows the user's parent-as-prior direction through the existing normalized hierarchical generator. It supplies an explicit record-relevant prior family rather than another geometry conditional with unchanged agreement probabilities. Every added assumption is stated. The earlier labeled beta model, heterogeneous parity experiment, fifteen local-subset admissions, and their evidence remain unchanged.

The result has three parts. This shared-parent family gives different laws for the original labeled agreement records. Its nontrivial ancestry can be recovered from the population record law under stated parameter conditions. Nevertheless, the fixed unit-variance comparison favors the single-block endpoint, and allowing variances to vary makes the single-block and all-singleton endpoints observationally equivalent as families. Repeated records from one static latent preparation cannot identify a unique ancestry with certainty. These limitations are part of the construction, not a reason to change its data or tune its parameters.

## 1. Scope decision and source continuity

The [preceding bridge](post-merge-source-and-gaussian-parent-bridge.md) established that changing only a normalized conditional geometry at fixed agreement-probability prior cannot improve the current labeled-data evidence. That is not a prohibition on investigating a record-relevant hierarchical generator. The user's earlier instructions identify parent beliefs inducing child priors/models through cross-scale structure as the intended mechanism, with the live PIFB2 work supplying motivation. A qualitative choice was requested during this continuation; pending a reply, that existing parent-as-prior direction is the working assumption. No production model or saved experiment is changed.

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `app:augmented_joint` and `sec:cross_scale_shadows`, supplies the finite normalized tree and parent-predictive interpretation. [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex), the normalized top-down factorization, permits general downward kernels and correlated recognition. [Theory/04](../../../Theory/04_generative.tex) requires a fixed normalized generative mechanism. The earlier [cross-scale-prior report](../../research/2026-09-11-fast-slow-cross-scale-priors/REPORT.md) already explains why a joint and map are additional structure and why the same observation cannot be counted again on a downward pass. The [root-prior correction](post-merge-source-and-gaussian-parent-bridge.md), Section 2, applies throughout.

The present model uses Gaussian kernels on the child law-mean coordinates of the existing translation example. Its independent within-scale links remain distinct from cross-scale reference maps. Isotropic noises, a finite tree, the particular common variance parameters below, and conditional independence of the generative noises are hypotheses. They are not claimed to follow uniquely from gauge covariance or VFE. They are fixed before the exact comparison, and no parameter search follows its outcome.

## 2. A proper hierarchical prior with independent graph links

There are four children and the oriented cycle 01,12,23,30 at one base point. Each child has belief and model law points N(mu_i^b,I_2) and N(mu_i^m,I_2). Stack their two two-dimensional means into mu_i in R^4. The group is the previous R^2 times R^2 translation specialization. Let T be a fixed partition of the children, with k blocks. It is an ancestry hypothesis, distinct from the earlier auxiliary connected-component readout.

For any a,b,c,v>0, generate independent Gaussian noises through

\[
 Y\sim N(0,vI_4),\qquad
 Z_A\mid Y\sim N(Y,bI_4),\qquad
 \mu_i\mid Z_{T(i)}\sim N(Z_{T(i)},aI_4),\qquad
 \ell_e\sim N(0,cI_4).
 \tag{1}
\]

The link coordinates ell_e are independent latent inter-agent relations. This statement specifies their prior, not a time evolution. Every conditional is proper; integrating leaves, links, block variables and then Y proves prior normalization. The maps in (1) are written in common reference coordinates. Passive frame translations push the full means, cross-scale offsets and link priors together, leaving the residuals and record law invariant. A fixed zero mean is not asserted to be an invariant probability law under the noncompact group.

With the destination-minus-source incidence matrix

\[
 B=\begin{pmatrix}-1&1&0&0\\0&-1&1&0\\0&0&-1&1\\1&0&0&-1\end{pmatrix},
 \tag{2}
\]

let r=B mu-ell. Split each r_e into the original belief and model two-vectors. Their original record probabilities remain

\[
 p_e^x=\exp(-\|r_e^x\|^2/2),\qquad x=b,m.
 \tag{3}
\]

This is the transported KL of the two unit-covariance Gaussian law points, as in the existing labeled construction. All eight record labels are preserved, with conditionally independent Bernoulli observations given the one static latent configuration in a record batch. No internal observations are deleted on a proposed merge.

Let R_T be the 4-by-k block indicator matrix and K_T=R_T R_T^T. Child means have covariance aI_4+bK_T+v11^T in each of their four coordinate directions. Since B1=0, the residual covariance in each direction is

\[
 \Gamma_T=aBB^\top+bBK_TB^\top+cI_4>0.
 \tag{4}
\]

The strict inequality follows from c>0. The four coordinate directions are independent under the prior. Each record channel therefore has a Gaussian residual vector with covariance Gamma_T tensor I_2. The induced law of p depends on T and the three variances a,b,c. This changes the agreement-probability prior, which is exactly the condition excluded from the preceding geometry-only equality. It is a new declared generative family using the same record evaluator; it is not an exact reexpression of the beta prior.

The top translation Y is independent of every residual and every record. Thus

\[
 P(Y\mid o,T)=N(0,vI_4),\qquad P(o\mid T,a,b,c,v)=P(o\mid T,a,b,c).
 \tag{5}
\]

This root coordinate is ancillary for these gauge-invariant internal records. The result concerns this translation family and evaluator. It does not say that arbitrary parent variables, model hyperparameters, or general-group holonomy are unobservable. Block contrasts can be informed by the cut records even though the common root translation cannot.

## 3. Exact common-record evidence

For nonnegative integer powers t_e, Gaussian integration gives, in one channel,

\[
 E_T\prod_e(p_e^x)^{t_e}
       =\det(I_4+\Gamma_T\operatorname{diag}(t))^{-1}.
 \tag{6}
\]

To derive it, the prior precision becomes Gamma_T^{-1}+diag(t) in each of two independent coordinate directions. Its Gaussian normalization ratio is the inverse square root of the determinant ratio per direction; the two factors give (6). Positivity follows by similarity to the symmetric positive matrix I+sqrt(D) Gamma_T sqrt(D). The zero-power case equals one.

Keep the mathematical record batch already used in the labeled example: n=(8,1,8,1) successes per channel around the ordered cycle and one failure at each original label, with the same specified order. There is no binomial count multiplicity for that ordered record. Expanding only the failure factors gives

\[
 e_T(a,b,c)=\sum_{S\subseteq\{0,1,2,3\}}
 \frac{(-1)^{|S|}}{\det[I_4+\Gamma_T\operatorname{diag}(n+1_S)]},
 \qquad P_T(o)=e_T(a,b,c)^2.
 \tag{7}
\]

The square uses the equal record counts and independent prior channels in this specialization. With unequal channel counts, use their two corresponding factors. Although (7) is an alternating sum, it integrates a strictly positive bounded likelihood against a proper prior, so 0<e_T<1. Its signed terms are an algebraic expansion, not mixture probabilities for latent model sampling.

All fifteen set partitions of four children are included. These are the fifteen Bell partitions, not the earlier fifteen nonempty child subsets used in the exact local-admission test. This menu includes disconnected blocks to classify the generative family; it does not certify every partition as a spatial coarse-graining of the cycle. Restricting to connected blocks retains both the winning endpoint and the adjacent two-pair comparison below. The comparison sets a=b=c=1 for every T. This is one explicit covariance point, not a fitted optimum or a search for a favorable hierarchy. The v parameter cancels analytically. No prior over T, complexity cost, or stopping penalty is selected; the results are evidences and evidence ratios.

| Ancestry hypothesis | Exact arithmetic evidence, displayed approximately |
| --- | ---: |
| One block {0,1,2,3} | 7.79697570845 x 10^-14 |
| Two blocks {0,1}, {2,3} | 2.40753251678 x 10^-14 |
| Two blocks {0,3}, {1,2} | 1.56466800619 x 10^-14 |
| Two blocks {0,2}, {1,3} | 1.37154273722 x 10^-14 |
| Four singleton blocks | 5.32453323302 x 10^-15 |

The [full result](evidence/shared-parent-record/result.json) retains all fifteen rows, exact fractions, every tie, and the evidence ratios to the single block. The unique maximizer at these common fixed variances is the single block. The two-pair hypothesis matching the larger success counts is second, not selected. These numbers concern the declared mathematical batch, not the saved heterogeneous parity observations and not fresh empirical confirmation.

## 4. What the population record law identifies

There is an exact inversion from the one-channel joint panel law to Gamma_T within this family. Write m_S=E product(p_e:e in S), obtained as the probability of successes on S without conditioning the remaining panel outcomes. Define d_i=1/m_{i}=1+Gamma_{ii}. Then

\[
 \Gamma_{ij}^2=d_i d_j-1/m_{\{i,j\}}.
 \tag{8}
\]

For adjacent oriented cycle edges, the corresponding entry of BK_TB^T is one of 0,-1,-2. This follows by considering the equality partition of their three incident vertices: all equal or one adjacent equal pair gives zero, three distinct gives -1, and equal outer vertices gives -2. Hence every adjacent Gamma_{ij} is strictly negative, since a>0. Its sign is determined rather than lost by (8).

For three consecutive edges i,j,k, the opposite entry is then recovered from the third principal minor:

\[
 \Gamma_{ik}=
 \frac{1/m_{\{i,j,k\}}-d_i d_j d_k
       +d_i\Gamma_{jk}^2+d_j\Gamma_{ik}^2+d_k\Gamma_{ij}^2}
      {2\Gamma_{ij}\Gamma_{jk}}.
 \tag{9}
\]

The square on the right is already known from (8); its denominator is nonzero. Apply (9) to 0,1,2 and 1,2,3. This reconstructs both opposite entries and therefore the entire covariance from moments of at most three original labels. The proof uses the special oriented-cycle sign pattern; no general phase-retrieval claim is made.

The independent-link variance is also determined because

\[
 \Gamma_T1=c1.
 \tag{10}
\]

Let S_0=I_4-11^T/4 and B^+ be the Moore-Penrose inverse of B, so B^+B=S_0. The reconstructed centered child covariance is

\[
 M=B^+(\Gamma_T-cI_4)(B^+)^\top
        =aS_0+bS_0K_TS_0.
 \tag{11}
\]

If a,b,c are known, G=(M-aS_0)/b is known. It determines the full block-equivalence matrix because

\[
 K_T=G+1w^\top+w1^\top,
 \qquad w_i=(1-G_{ii})/2.
 \tag{12}
\]

To check (12), S_0 K_T S_0=G and K_T has unit diagonal. The difference between two symmetric matrices with identical double-centered parts is 1w^T+w1^T; the diagonal fixes w. Equivalently, a zero-diagonal symmetric difference annihilated by double centering must vanish. Thus all fifteen partition laws are distinct for every fixed a,b,c>0, not just at the executed unit point.

The finite reconstruction script recovers Gamma exactly from all fifteen saved moment vectors. This calculation corroborates the formulas at one point. The sign, minor, and centering arguments establish the universal statement within the declared family.

## 5. Unknown variances: thirteen identifiable non-endpoints and one endpoint ambiguity

When a,b,c may vary with T, c remains determined by (10). The remaining classification follows from S_0 K_T S_0 acting on the three-dimensional centered subspace.

For two blocks A and its complement, with sizes n_A,n_B, let u=S_0 1_A. Since S_0 1_B=-u,

\[
 S_0K_TS_0=2uu^\top,
 \qquad \operatorname{spec}_{1^\perp}(S_0K_TS_0)
          =\{0,0,n_A n_B/2\}.
 \tag{13}
\]

Consequently M has a double lowest eigenvalue a and one larger eigenvalue. Its unique contrast eigenvector has exactly the two blockwise coordinate values of u, identifying the bipartition up to interchange of its blocks. The known sizes then recover b from the eigenvalue gap. This covers all seven bipartitions, including both 2+2 and 3+1 types.

For three blocks, there is one pair {i,j} and two singletons {k,l}. The mutually orthogonal centered vectors e_i-e_j, e_k-e_l, and e_i+e_j-e_k-e_l have respective eigenvalues 0,1,3/2 under S_0 K_T S_0. Therefore

\[
 \operatorname{spec}_{1^\perp}(M)=\{a,a+b,a+3b/2\}.
 \tag{14}
\]

The lowest eigenvector identifies the pair by its two nonzero entries; the gaps recover b. These six partitions cannot be confused with the bipartitions because their three eigenvalues are distinct for b>0. Thus all thirteen non-endpoint partitions, and their a,b,c parameters, are identifiable from the population record law within this family. The top variance v remains unidentifiable from these records.

The two endpoints instead give

\[
 M_{\rm one\ block}=aS_0,\qquad
 M_{\rm singletons}=(a+b)S_0.
 \tag{15}
\]

Their families of record laws coincide when positive variances are free: every positive effective coefficient in the first can be split into positive a and b in the second. In the single-block family b is also absorbed into an unobserved common translation. The unit-point evidence preference does not resolve this family-level ambiguity, because it compares fixed a values that are not equivalent effective variances.

This is a statistical ambiguity of latent ancestry, not failure of normalization. Arbitrarily many independent repetitions of the same observable experiment cannot distinguish two hypotheses with exactly the same induced record law. A different prior over variance decompositions or an explicit structural cost can favor one representation, but that preference must be identified as such. No cost or hyperprior is inserted here to break the tie.

## 6. One static preparation is not many independent latent preparations

Population-law identifiability in Sections 4-5 does not imply consistent recovery of T from arbitrarily many repeated Bernoulli records of one fixed latent p. For every fixed positive variance triple, the induced p density is positive throughout (0,1)^8. This follows directly by transforming the positive Gaussian residual density to radial variables and integrating its positive finite angular density. In one channel, writing r_e(p_e,phi_e)=sqrt(-2 log p_e)(cos phi_e,sin phi_e), that density is

\[
 f_T^x(p)=\frac{\prod_e p_e^{-1}}{(2\pi)^4\det\Gamma_T}
 \int_{[0,2\pi)^4}
 \exp\left[-\tfrac12\sum_{e,f}(\Gamma_T^{-1})_{ef}
           r_e\mathbin{\cdot}r_f\right]d\phi.
 \tag{16}
\]

The two channels multiply. The Jacobian is d^2r_e=dD_e dphi_e with D_e=-log p_e. For interior p the integrand is positive and continuous on a compact angular domain, so the density is finite and strictly positive.

If a fixed strictly positive prior pi_T on the finite ancestry set were supplied, even observing p exactly would leave

\[
 P(T=t\mid p)=\frac{\pi_t f_t(p)}{\sum_s\pi_s f_s(p)}\in(0,1).
 \tag{17}
\]

Repeated cyclic probes of all labels recover their fixed p values almost surely by the Bernoulli strong law. Conversely, T to p to the complete record sequence is a Markov chain, so the infinite record sequence supplies no further ancestry information after p is known. The conditional ancestry entropy remains positive; its Bayes classification error is also positive. A unique true tree cannot be recovered with certainty from this one latent draw. This does not deny useful finite posterior preference or the population-law inversion above.

Independent latent re-preparations, or a specified evolving latent process with a suitable identification result, constitute different sampling contracts. The current static batch cannot silently be treated as either. Auxiliary draws produced by an inference algorithm do not supply new observations about the unknown ancestry. Likewise, an asymptotic batch with indefinitely many successes and only one failure is a valid conditioning calculation but is not a typical infinite record path at a fixed interior p.

## 7. Parent interpretation, costs, and the next admitted step

Equation (1) supplies actual parent-dependent child priors. Exact inference must still use one correlated posterior of this joint, with the root-prior term retained. The posterior of a block contrast can respond to cut records; the common translation root cannot respond to the present internal records. Adding a hierarchical latent label is therefore insufficient to establish a useful second learned parent.

The explicit tree samples contain 4 root, 4k block, 16 child-mean and 16 graph-link coordinates, totaling 36+4k. This is 40,44,48,52 across one through four blocks. These are counts for a declared expanded sampler, not minimum representations or a net computational advantage. The Gaussian tree can be integrated analytically, and all record moments above can be evaluated from Gamma alone. Complete geometric/interface recovery, structural learning state, time evolution and history filtering still require their own accounting. The earlier marked-parent sample reductions do not automatically transfer to this different prior.

The next admitted calculation is the actual E/M structural update under this joint, using its exact non-Gaussian posterior and the source's normalized Gaussian variance factors. It must retain the endpoint variance ambiguity and the ancillary root direction. The previous beta-prior vector field and feedback kernel are not the dynamics of this new prior and must not be reused as if they were. A subsequent claim of persistent, useful two-level organization needs the complete parent evaluator, future record law, learning state and costs under that specified update.

This continuation closes the missing record-prior bridge for one explicit source-motivated family. It does not discover a useful hierarchy in the heterogeneous saved experiment or select a preferred new physical model. The common unit-variance result and ancestry ambiguities remain negative results. Base transport, new observations, parameter tuning, arbitrary penalties and physical clocks remain outside this calculation.

## 8. Executed evidence and preservation

[shared_parent_exact.py](evidence/shared-parent-record/shared_parent_exact.py) ran once and saved the complete exact evidence comparison, all normalized one-panel record probabilities and moment vectors. [record_identifiability_exact.py](evidence/shared-parent-record/record_identifiability_exact.py) then addressed the new inversion/classification obligation using those saved vectors; it did not rerun the first calculation. Its [output](evidence/shared-parent-record/identifiability-result.json) checks all covariance reconstructions and the centered partition spectral identities. General identifiability and static-preparation limitations are supported by the written arguments, not by finite arithmetic alone.

Both scripts passed on their first invocations, in 0.07881710000037856 and 0.012221699998917757 seconds, respectively. They used pinned CPython 3.14.7 with -I -B. The earlier matrix helper's definitions were loaded without its main. No science was retried, sampled, or fitted; no ODE, parameter search, broad suite, GPU, Lean, or tamper check ran. The [inspection receipt](evidence/shared-parent-record/execution-and-inspection.json) records source/result binding and preservation. No formal ledger certificate is claimed.
