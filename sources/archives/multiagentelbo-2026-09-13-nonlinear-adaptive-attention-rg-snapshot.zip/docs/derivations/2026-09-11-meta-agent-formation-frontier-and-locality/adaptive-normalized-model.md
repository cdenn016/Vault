# A normalized adaptive model on the cyclic configuration family

September 12, 2026. This is the model and learning component of the [adaptive cyclic RG contract](evidence/2026-09-12-adaptive-cyclic-rg-goal/problem-contract.json), digest `e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90`. The [cyclic witness](adaptive-cyclic-witness.md) supplies the graph and restoring flag; the [conditional calculation](adaptive-conditional-bounds.md) supplies the dynamical approximation. No formation claim follows from normalization alone.

The construction reuses the optimizing Gaussian evaluator in [the microscopic model, Sections 2–4](microscopic-vfe-dynamics-construction.md), its complete parameter score in Section 11, and the Gaussian source/recognition distinction in [pointwise Gaussian learning](pointwise-gaussian-link-learning.md). Gaussian integration, conditional covariances, and log-determinant differentiation agree with [Rasmussen and Williams, Appendix A, equations A.4–A.6 and A.11–A.15](https://gaussianprocess.org/gpml/chapters/RWA.pdf), retrieved September 12. The learning inequalities below are derived here.

## 1. Carrier, energy, and observations

Let the finite connected graph consist of triangles connected by bridges, as specified in the witness. A configuration is `x=(u,v,alpha)` in `R^d`, where u and v are scalar belief/model means and alpha contains one independent translation link for every oriented edge. With incidence convention `(Du)_e=u_i-u_j` for the edge from j to i, put

\[
b_d x=u-v,\qquad b_e x=u_i-u_j-\alpha_e,
\qquad H=J_1b_d^Tb_d+\sum_eJ_{\ell(e)}b_e^Tb_e.
\tag{M1}
\]

All weights are strictly positive, and all peer coordinates have the same unit microscopic metric. Write K=ker H, P_K for its orthogonal projector, N=K perpendicular, and p=rank H. The independent alpha columns and the v columns show that the residual rows are independent. Thus H is positive on N. Proper confinement along K is a declared prior, not a gauge-invariant Haar probability on a noncompact group.

Fix an evaluator variance split c in (0,1). At node i the belief is `N(u_i,1)` and the model presentation is `N(v_i,c)`. The evaluator sends zeta_i to `N(zeta_i,1-c)`. The fixed-marginal optimizing joint uses

\[
\zeta_i=v_i+\xi_i,\qquad k_i=u_i+\xi_i+\epsilon_i,
\quad \xi_i\sim N(0,c),\quad\epsilon_i\sim N(0,1-c),
\tag{M2}
\]

independently. Its relative entropy against the model/evaluator joint is

\[
d^{\rm ev}(x)=\frac{\|b_dx\|^2}{2(1-c)}
=\frac12x^TRx,\qquad R=\frac{b_d^Tb_d}{1-c}.
\tag{M3}
\]

To check optimality, subtract the log density of (M2) from that of the physical model/evaluator joint. The difference is an affine function of k_i and zeta_i plus the constant in (M3). Its expectation is fixed by the prescribed marginals. Subtracting this identity from the relative entropy of any other coupling leaves its KL to (M2), which is nonnegative. The minimizing joint and value are therefore exact; no independence of the two prescribed marginals is imposed.

Let a be a genuinely learned positive model coefficient. Define

\[
A_0(a)=aH+P_K-TR,\qquad
P_{0,a}=N(0,T A_0(a)^{-1}).
\tag{M4}
\]

The condition `T <= J1(1-c)/2` implies `TR <= H/2`. Consequently, for a>=1,

\[
A_0(a)\succeq \frac a2H+P_K\succ0.
\tag{M5}
\]

The normalizer relative to Lebesgue measure is `(2 pi T)^(d/2) det(A0)^(-1/2)`; it is not dropped. All subsequent densities have full support and finite Gaussian moments.

Use two normalized observations, with fixed kappa in (0,1]:

\[
O\mid x\sim N(x,T\kappa^{-1}I_d),\qquad
Y\mid a\sim N(a,T).
\tag{M6}
\]

Select the record O=z, Y=2, where z is a fixed nonzero vector in K with unequal node entries. Such vectors exist: select any unequal t_i and put `u_i=v_i=t_i`, `alpha_e=t_i-t_j`. Every cycle sum of alpha is zero in z. The selected record is heterogeneous but compatible; a later section separates this admission from arbitrary incompatible forcing. The joint observation is a declared vector record, with node and link components. No spatial/base observation is introduced.

The complete normalized generative joint is

\[
P_{0,a}(dx)L_O(dO\mid x)L_Y(dY\mid a)
\prod_i m_i(d\zeta_i\mid v_i)\operatorname{ev}_i(dk_i\mid\zeta_i).
\tag{M7}
\]

Recognition uses a correlated outer density Q(dx), followed by (M2) at each node. The scaled exact restricted VFE is

\[
F_T(Q,a)=T\operatorname{KL}(Q\Vert P_{0,a})
+T E_Qd^{\rm ev}-T E_Q\log L_O(z\mid x)-T\log L_Y(2\mid a).
\tag{M8}
\]

The evaluator correction in (M4) cancels only after the exact term `T E_Q d^ev` is included. Up to explicit observation-density constants, (M8) equals

\[
T\int q\log q+E_Q\left[\frac a2x^THx+
\frac12\|P_Kx\|^2+\frac\kappa2\|x-z\|^2\right]
+T\log Z_0(a)+\frac12(a-2)^2.
\tag{M9}
\]

The minimizing outer law at fixed a is

\[
\pi_a=N(K_a^{-1}f,TK_a^{-1}),\quad
K_a=aH+P_K+\kappa I,
\quad f=\kappa z.
\tag{M10}
\]

It is the optimizer of the restricted evaluator family. It is not substituted for the physical outer posterior, whose precision is `A0(a)+kappa I`. Their respective conditional kernels and evidence constants remain different.

The complete constants can be retained explicitly. Set `d=dim x`, `c_O=(kappa/(2 pi T))^(d/2)`, `c_Y=(2 pi T)^(-1/2)`, and, for any SPD matrix `K`, define

\[
\mathcal Z(K,f)=(2\pi T)^{d/2}\det(K)^{-1/2}
       \exp\left(\frac{f^TK^{-1}f}{2T}\right).
\]

Writing `K_a^phys=A_0(a)+kappa I`, the physical evidence of the selected pair of records and the common restricted-objective offset are

\[
\begin{split}
p_a(z,2)&=\frac{c_Oc_Y}{Z_0(a)}
  \exp\left[-\frac{\kappa\|z\|^2+(a-2)^2}{2T}\right]
  \mathcal Z(K_a^{\rm phys},f),\\
C_T(a)&=T\log Z_0(a)-T\log(c_Oc_Y)
 +\frac{\kappa\|z\|^2+(a-2)^2}{2}
 -T\log\mathcal Z(K_a,f),\\
F_T(Q,a)&=T\operatorname{KL}(Q\Vert\pi_a)+C_T(a).
\end{split}
\tag{M10a}
\]

These follow by completing the square and integrating the normalized inner kernels in (M7). Since `f in K` and `R K=0`, the physical posterior and optimizer have the same mean, and

\[
C_T(a)=-T\log p_a(z,2)
 +\frac T2\log\frac{\det K_a}{\det K_a^{\rm phys}}.
\tag{M10b}
\]

The second term is the positive evaluator-restriction gap. For any fixed retention `C_s`, put `pi_a^s=(C_s)_# pi_a` and `Q_s=(C_s)_#Q`. The exact restricted parent scalar is `F_T^s(Q_s,a)=T KL(Q_s||pi_a^s)+C_T(a)`. The conditional-KL chain rule gives `F_T(Q,a)=F_T^s(Q_s,a)+T E_{Q_s} KL(Q(.|y)||pi_a(.|y))`. The same `C_T(a)` survives every nested retention; its derivative must remain in the parent learning force. This restricted parent scalar is distinct from the ordinary physical-parent VFE, whose posterior is the pushforward of the Gaussian with precision `K_a^phys` and whose evidence is `p_a(z,2)`.

The graph contribution in (M1) is precisely `a J_ell KL(N(u_i,1)||N(u_j+alpha_e,1))`. These coefficients are positive edge energy strengths. They are not row-normalized attention probabilities. If a row-stochastic notation is desired, write `a J_e=lambda_i beta_ij`, with `lambda_i=sum_j a J_ij` and `beta_ij=J_ij/sum_k J_ik` on each nonempty row. This is an exact decomposition into occupancy/strength and a normalized row, not a derivation of a softmax law. The witness learns a, hence the strengths; it does not claim that the normalized rows change. Inter-agent model alignment is exactly absent: gamma=0. The model-to-belief evaluator, the local bridge, and model coefficient learning remain present.

## 2. Actual coupled kinetics and Fisher model metric

The microscopic outer-law evolution is the declared configuration diffusion with common unit coordinate mobility

\[
dX_t=(-K_{a_t}X_t+f)dt+\sqrt{2T}dW_t.
\tag{M11}
\]

Its drift is the unit-metric gradient of the configuration energy in (M9). This is the configuration-diffusion realization used in earlier dynamical witnesses; it is not the full-law Fisher replicator flow. At fixed a it dissipates F_T by the usual Gaussian integration-by-parts identity. Gaussian preparation remains Gaussian along every deterministic parameter trajectory, with

\[
\dot\mu=-K_a\mu+f,\qquad
\dot\Sigma=-K_a\Sigma-\Sigma K_a+2TI.
\tag{M12}
\]

The exact parameter covector of (M8), holding Q fixed, is

\[
g(a,Q)=a-2+\frac12E_Qx^THx
-\frac T2\operatorname{tr}(A_0(a)^{-1}H).
\tag{M13}
\]

The last term is the derivative of the prior normalizer. The observation O has no a-score at fixed x. The calibration observation Y has score `(Y-a)/T` and contributes `1/T` to the Fisher metric of the complete normalized generative experiment. The prior score has variance `tr[(A0^-1 H)^2]/2`, by the Gaussian quadratic-form variance. Its mean is zero, as is the conditional calibration score. Their cross term vanishes. Thus the actual model Fisher metric is

\[
M(a)=\frac1T+\frac12\operatorname{tr}[(A_0(a)^{-1}H)^2].
\tag{M14}
\]

Use the slow model metric `T M(a)/epsilon` for the scaled objective F_T, equivalently mobility epsilon times inverse Fisher for the unscaled objective F_T/T. The actual learning equation is

\[
\dot a=-\epsilon[T M(a)]^{-1}g(a,Q).
\tag{M15}
\]

The model metric is declared once microscopically and is inherited. Replacing it by the Fisher metric of a marginal observed model at a later RG level would define different kinetics. The combined dissipation is

\[
\frac{dF_T}{dt}
=-T^2\int q\|\nabla\log(q/\pi_a)\|^2dx
-\epsilon[T M(a)]^{-1}g(a,Q)^2\le0.
\tag{M16}
\]

Every score and moment is evaluated from the current law, not a frozen equilibrium substitution. Smooth finite moment equations, the positivity estimates below, and continuation yield a unique solution on the required finite horizon. This is learning in the normalized model, not a prescribed coefficient schedule.

## 3. Nonempty long-horizon learning admission

Start a(0)=1 and `Q0=N(mu0,T K1^-1)`, with `P_K mu0=0`. The formation construction selects a nonzero normal mean mu0; require

\[
\frac12\mu_0^TH\mu_0\le\frac1{40},\qquad
Tp\le\frac1{40},\qquad T\le\frac{J_1(1-c)}2.
\tag{M17}
\]

These inequalities allow nonzero preparation amplitudes and positive T for every fixed finite graph/contrast. Later choices of amplitude and temperature must satisfy both these conditions and the formation/conditional bounds; no bound is obtained by setting either to zero.

While a stays in [1,21/10], the normal mean is

\[
\mu_N(t)=e^{-\kappa t}\exp\left[-H\int_0^t a(s)ds\right]\mu_0.
\tag{M18}
\]

Hence its H-energy never increases. In a fixed eigenbasis of H, each positive-eigenvalue variance satisfies `c_j'=-2(a lambda_j+kappa)c_j+2T`; the constant `T/(lambda_j+kappa)` is an upper barrier, attained initially. Therefore `tr(H Sigma)<=Tp`. On K the law is an independent stable Gaussian process and contributes nothing to this trace.

By (M5), `tr(A0^-1 H)<=2p/a<=2p`. Combining these bounds gives

\[
-\frac1{40}\le g-(a-2)\le\frac3{80}.
\tag{M19}
\]

The same similarity to an SPD matrix gives `tr[(A0^-1 H)^2]<=4p/a^2`, and consequently

\[
1\le T M(a)\le1+2Tp\le\frac{21}{20}<\frac{11}{10}.
\tag{M20}
\]

For convenience weaken (M19) to absolute value at most 1/10. At a=1 equation (M15) points inward; at a=21/10 it points inward. Thus the interval is invariant, proving the provisional assumption by a first-exit argument. In particular `|a'|<=11 epsilon/10`. Until a reaches 19/10,

\[
\dot a\ge\frac{10\epsilon}{11}\left(\frac{19}{10}-a\right).
\tag{M21}
\]

Comparison with this scalar equation, including the inward derivative at a=19/10, gives

\[
a(t)\ge\frac{19}{10}-\frac9{10}e^{-10\epsilon t/11}.
\tag{M22}
\]

In particular `a(2/epsilon)>3/2`. The learned parameter therefore changes by more than 1/2 over the horizon `2/epsilon`, independently of epsilon. The mean/covariance equations have finite coefficients and moments throughout that interval, so the solution continues through it. The parameter bound does not require the internal conditional to equilibrate instantly.

## 4. A changed eliminated conditional and collective response

For any fixed orthogonal retention whose hidden subspace lies in N, the optimizer's hidden precision is

\[
D_a=aF+\kappa I,\qquad F=UHU^T\succ0.
\tag{M23}
\]

Choose kappa no greater than the least eigenvalue of F for a first-stage hidden block; the finite flag proves that this is a nonempty choice. At a>=3/2, every eigenvalue of `D_a D_1^-1` is at least 5/4. Comparing the two Gaussian conditionals at the same retained value y therefore gives

\[
\operatorname{KL}(\pi_1(\cdot\mid y)\Vert\pi_a(\cdot\mid y))
\ge\frac{\dim U}{2}\left[\frac14-\log\frac54\right]>0.
\tag{M24}
\]

The conditional-mean contribution is nonnegative, so the lower bound holds for every y. It is independent of epsilon, T, and the absolute stiffness. This verifies that the hidden conditional itself changes appreciably, even when its physical width becomes small. Equation (M24) is not a statement about the actual tracking error; that error is bounded separately.

The physical posterior hidden precision is `D_a-T U R U^T`. It changes by `(a-1)F` and stays SPD by (M5). Its covariance likewise changes. No claim equates that physical conditional to (M23).

The same quantitative lower bound also holds for these physical posterior conditionals. Put `D_1^phys=F+kappa I-T U R U^T`. Since `kappa I<=F` and `U R U^T>=0`, `D_1^phys<=2F`. For `a>=3/2`,

\[
D_a^{\rm phys}=D_1^{\rm phys}+(a-1)F
 \succeq D_1^{\rm phys}+\frac12F
 \succeq\frac54D_1^{\rm phys}.
\tag{M24a}
\]

The eigenvalues of `(D_1^phys)^(-1/2) D_a^phys (D_1^phys)^(-1/2)` are therefore at least `5/4`. The Gaussian KL formula, with its nonnegative conditional-mean term, proves (M24)'s lower bound for `KL(P_1^phys(.|y,z,2)||P_a^phys(.|y,z,2))` for every retained value y. This argument does not assume that F commutes with `U R U^T`.

The compatible heterogeneous record also produces an exact nonzero collective response:

\[
P_K\mu(t)=\frac\kappa{1+\kappa}
\left(1-e^{-(1+\kappa)t}\right)z.
\tag{M25}
\]

The observations and prior references stay fixed during this motion. Thus relative predictions and the selected observation likelihood change; it is not merely a passive coordinate relabeling. Every admitted parent retains K, so it inherits exactly the same response and kernel noise. Independent Gaussian observation perturbations outside K are not covered by the zero normal-forcing formula (M18). For a fixed vector f_N they add the explicit variation-of-constants term bounded by `||f_N||/lambda_min(K_a|N)`; the formation margin and conditional error must then pay that term. No unrestricted heterogeneous-forcing robustness is claimed.

## 5. Gauge, scope, and continuation

An independent passive translation at every node sends `u_i,v_i` to `u_i+g_i,v_i+g_i`, and `alpha_ij` to `alpha_ij+g_i-g_j`. This is addition of an element of K. The proper root reference, observation z, and density coordinates are pushed by the same translation. All residuals, covariance metrics, likelihood ratios, scores, and loop sums transform consistently; Lebesgue measure is unchanged. Holding those references fixed instead defines an active physical displacement. No base path is present.

The witness uses scalar translation laws and a finite cyclic graph. Its loop holonomies are real cycle sums with nonzero finite-temperature distributions. Gaussian translation stabilizers are trivial, so small transported mismatch makes those particular loop sums small. This is a property of the chosen representation, not a general identity-holonomy law; the existing GL marked-parent construction retains nonidentity stabilizers in its own scope.

The established component is a normalized exact VFE, genuine Fisher-preconditioned model learning with an appreciable changed hidden conditional, and a compatible collective response. Actual formation, inherited error bounds, and the finite-L simultaneous parameter regime are separate claims in the joined construction. No production code, heavy experiment, earlier science rerun, or vault edit is required for these identities.
