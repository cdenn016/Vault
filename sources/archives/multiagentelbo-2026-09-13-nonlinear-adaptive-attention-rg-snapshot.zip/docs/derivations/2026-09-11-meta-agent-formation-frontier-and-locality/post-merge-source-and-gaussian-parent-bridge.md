# Post-merge source, Gaussian parent admission, and common-data licensing

September 11, 2026. This continuation completes the source reconciliation requested after [auxiliary feedback](auxiliary-feedback-and-filter-cost.md). The source already supplies a normalized hierarchical generative model. Its unresolved connection is to the existing labeled law/link experiment and an actual replacement of its internal interactions. A Gaussian shared-parent factorization gives a checkable admission for that connection; it does not by itself provide a formation gain.

The strongest new conclusions are conditional and negative where required. A four-dimensional shared Gaussian latent with conditionally independent children cannot represent all admitted four-child conditional laws. An explicit sixteen-dimensional child covariance has minimum shared-latent dimension eight in that architecture. Any normalized change confined to geometry conditional on the retained agreement probabilities has identical evidence for the present labeled records. Thus specifying a tree-shaped geometry conditional alone cannot close the post-merge licensing gate.

## 1. What the existing sources actually specify

[Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex), its normalized hierarchical joint and parent-to-child influence sections, already permits correlated recognition, a proper top prior, structural channels, and normalized downward kernels. It does not require a product of independent child recognition factors. Its exact VFE includes the top-prior KL. Parent-dependent downward kernels can couple optimization across levels, subject to their stated model and update contract.

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), Appendix `app:augmented_joint`, equations `eq:augmented_joint` through `eq:mf_fixedpoint`, specifies a finite fixed tree, Gaussian child conditionals, a proper fixed top prior, and a likelihood on the leaves. This is an existing normalized generator. Section `sec:meta_agent_variational` separately states the licensing inequality involving optimized pre/post free energies and a cost C(I), while leaving the removed terms and post-merge functional unspecified. These two facts must be retained together: there is a hierarchical generator, but there is no specified equality between it and the current experiment's post-merge model.

The same appendix already distinguishes the Gaussian parent-predictive mixture from a strict mean-field coordinate update. Integrating a Gaussian conditional over a Gaussian parent adds transported parent covariance to the noise; taking the expected log conditional in a mean-field update does not. This distinction is reused, not proposed as a new mechanism. The manuscript's `sec:rg_status` also separates exact Gaussian marginalization from tying variables and warns that a Schur complement need not preserve its five-term functional family. The existing [Gaussian coefficient derivation](nonlinear-coefficient-memory-and-parent-cost.md), Section 4, already keeps the Schur normalizer and direct/staged integration.

The present calculation uses the explicit [labeled model](learned-multilabel-membership-and-stopping.md), equations (3)-(8): four agents, eight separate belief/model agreement probabilities p, sixteen child mean coordinates mu, independent residual angles, and independent dynamic graph-link coordinates recovered from means and residuals. Its conditional is h(mu|p)=N(a+Lp,Sigma), with Sigma positive definite. It does not replace the retained heterogeneous parity experiment. All work remains at one base point.

## 2. The complete tree objective, including the root

For a finite rooted tree, write the source's proper prior and likelihood as

\[
 P(k,o)=L_o(k_{\rm leaf})\pi(k_{\rm root})
             \prod_{v\ne {\rm root}}\chi_v(k_v\mid k_{{\rm pa}(v)}).
 \tag{1}
\]

Successive leaf integration normalizes the prior to one. A normalized observation kernel gives a normalized joint over k and o; the bounded-likelihood assumption in the source also ensures finite fixed-o evidence. For any absolutely continuous recognition Q for which the expectations exist, the exact objective is

\[
 F(Q)=E_Q\log Q-E_Q\log L_o-E_Q\log\pi
                         -\sum_{v\ne {\rm root}}E_Q\log\chi_v.
 \tag{2}
\]

The displayed source `eq:mf_free_energy` omits the third term, although its product recognition includes top-level factors. A fixed generative prior is not a fixed variational root factor. The omission changes the objective whenever that factor varies. It is ignorable in a coordinate calculation only if the entire root recognition is held fixed, which is an additional restriction. This correction is recorded here; the source manuscript has not been edited.

Under Q=product(q_v), varying one normalized factor in (2) gives

\[
 \log q_v(k_v)=c_v+E_{Q_{-v}}\left[
 \log L_o(k_{\rm leaf})+\log\pi(k_{\rm root})
                  +\sum_{w\ne {\rm root}}\log\chi_w\right].
 \tag{3}
\]

Terms independent of k_v join c_v. The root receives its prior message; a leaf in a joint likelihood receives an expectation over the other leaves. The source's unaveraged single-leaf likelihood expression requires a corresponding likelihood factorization. Its initial definition allows a general joint leaf likelihood, so that simplification is not available without an added hypothesis. Equation (3) follows by writing the variation as log q_v+1 minus the expected log joint, plus the normalization multiplier. It is a stationarity equation, not a global mean-field optimum theorem.

The one-root, one-child example Z~N(0,1), X|Z~N(Z,1), L=1 has joint precision [[2,-1],[-1,1]], determinant one. Omitting the root prior gives [[1,-1],[-1,1]], determinant zero and a free common-translation direction. The correct mean-field root precision is two; the omitted-prior objective gives one at fixed child factor. This is a direct counterexample within the source's common-unit-noise tree, independently of any complicated graph.

## 3. Exact Gaussian shared-parent admission

Condition on p and put x=mu-a-Lp in R^n, with n=16 in the current example. Partition x into four blocks of dimension four. Consider the following declared latent representation, with independent noises:

\[
 Z\sim N(0,I_r),\qquad x_i=A_iZ+\epsilon_i,\qquad
 \epsilon_i\sim N(0,D_i),\quad D_i>0.
 \tag{4}
\]

Stack the loadings into A and set D=diag(D_i). Integrating Z gives N(0,D+AA^T). Therefore (4) represents the existing conditional exactly if and only if

\[
 \Sigma=D+AA^\top,\qquad D=\operatorname{diag}(D_1,D_2,D_3,D_4)>0.
 \tag{5}
\]

Necessity follows from conditional independence and covariance addition; sufficiency follows from the normalized Gaussian construction. This is an admission for a particular shared-parent architecture. It is not necessary for arbitrary correlated downward kernels allowed by Theory/07c, and it is not a general no-go theorem for meta-agents.

Writing M=I_r+A^T D^{-1}A and completing the square yields the normalized recognition channel

\[
 \Gamma(dz\mid x)=N\left(z;M^{-1}A^\top D^{-1}x,M^{-1}\right)dz.
 \tag{6}
\]

The same completion gives

\[
 \Sigma^{-1}=D^{-1}-D^{-1}AM^{-1}A^\top D^{-1},\qquad
 \det\Sigma=\det D\det M.
 \tag{7}
\]

Indeed the joint exponent is x^T D^{-1}x-2z^T A^T D^{-1}x+z^T Mz. Translation by its unique minimum in z leaves the first expression in (7); Gaussian integration contributes (det M)^(-1/2), giving the second expression. All matrices inverted here are positive definite. These are the standard Gaussian and matrix identities in [Rasmussen and Williams, Appendix A.2-A.3](https://gaussianprocess.org/gpml/chapters/RWA.pdf), applied here with all normalizers retained.

For an exact rational illustration, take four scalar children, D=diag(1,2,3,4), and A=(1,2,3,4)^T. Then M=11, det Sigma=264, the posterior mean is sum(x_i)/11, and its variance is 1/11. The marginal precision is diag(1,1/2,1/3,1/4) minus the all-ones matrix divided by 11. Omitting the root prior changes the root joint precision from 11 to 10, producing determinant zero and null vector (1,1,2,3,4). The finite matrix equalities are checked in the saved script.

The A_i are linear latent loadings, not the independent graph links Theta_e. In particular, (4) does not force existing graph holonomy to be flat. The original residual/link reconstruction, both record channels, dressed cut links, and loop marks remain. The offsets a_i+L_i p preserve direct p dependence in each child conditional. This is more general than the source's special child mean Omega_i k_parent, whose mean and covariance constraints must also be checked if that stricter model is used.

With no p-dependent child offsets, a linear root mean Bp and stacked loadings A would require L=AB. Hence rank(L)<=r. The existing 16-by-8 L is allowed to have rank eight, already excluding r=4 in that stricter mean architecture. Allowing the offsets removes this obstruction by retaining p access; it does not compress that access. General linear changes of child coordinates push D_i and A_i with the laws. Holding an isotropic covariance numerically fixed under an arbitrary GL change would specify a different family, not coordinate covariance.

## 4. An explicit dimension-eight minimum

Let I be the four-dimensional identity and take Sigma=C tensor I, where

\[
 C=\begin{pmatrix}
 10&1&1&1\\1&10&1&2\\1&1&10&1\\1&2&1&10
 \end{pmatrix}.
 \tag{8}
\]

C is symmetric strictly diagonally dominant with positive diagonal; its quadratic form is positive, with a lower eigenvalue bound six. Its determinant is 9216. Consequently Sigma is a fully admitted positive definite covariance in the existing labeled family.

Suppose (5) holds. Its off-diagonal blocks require A_1 A_3^T=A_1 A_4^T=I and A_2 A_4^T-A_2 A_3^T=I. Therefore

\[
 A_1(A_4-A_3)^\top=0,\qquad
 A_2(A_4-A_3)^\top=I.
 \tag{9}
\]

The second equality gives rank(A_4-A_3)=4. Also rank(A_1)=4, since A_1 A_3^T=I. The first equality makes these two four-dimensional row spaces orthogonal in R^r, proving r>=8. This argument allows every positive definite block noise D_i and every real loading A_i; it is not a failed numerical fit.

The lower bound is attained. Use

\[
 A_1=A_3=\begin{bmatrix}I&0\end{bmatrix},\quad A_2=A_4=\begin{bmatrix}I&I\end{bmatrix},\qquad
 (D_1,D_2,D_3,D_4)=(9I,8I,9I,8I).
 \tag{10}
\]

Their Gram off-diagonal blocks reproduce (8), while the diagonal noise fills every diagonal to 10I. Thus eight is the exact minimum for this witness within (4). The saved calculation constructs the full 16-by-16 covariance, checks its determinant 9216^4, and checks both identities (9). The universal lower-bound step is the written row-space argument.

There is also a family-wide dimension obstruction. Four symmetric 4-by-4 noise blocks have 40 free parameters. Rank-r positive semidefinite 16-by-16 Gram matrices have dimension 16r-r(r-1)/2: full-column loadings have 16r coordinates and their orthogonal redundancy has dimension r(r-1)/2. The sum map to Sigma therefore has image dimension at most

\[
 40+16r-r(r-1)/2,
 \tag{11}
\]

whereas positive definite 16-by-16 covariances form an open set of dimension 136. For r=4 the bound is 98; for r=7 it is 131. Smooth rank-stratum charts, including the smaller ranks, show that r<=7 cannot cover an open full-measure generic family. The count alone does not prove that r=8 suffices for every covariance. Equation (10) establishes sufficiency only for its explicit witness. Neither result is a bound on arbitrary nonlinear parent state or on a history filter.

## 5. Exact augmentation and the stronger evidence obstruction

When (5) holds, add Z to the full existing model using Gamma in (6), without changing the original state or records. If Q is a fine recognition law, its matched extension Q Gamma obeys

\[
 P^+(W,Z,o)=P(W,o)\Gamma(Z\mid W),\qquad
 F^+(Q\Gamma)=F(Q).
 \tag{12}
\]

The common channel cancels in the density ratio. More generally, an extension Q R has excess E_Q KL(R(.|W)||Gamma(.|W)) when the divergence is defined. Integrating Z recovers the original prior, evidence, posterior, and original record distribution. Adding the latent does not prescribe a new temporal update. This specializes the existing common-data equality in [agreement-partition-selection-and-lineage.md](agreement-partition-selection-and-lineage.md), Section 2; it is not a new selection principle.

For the current archive there is a stronger obstruction that does not require (5). Let T index ANY fixed, normalized replacement of geometry conditional on p, with the same probability prior f_u(p) and the same labeled likelihood L_o(p). Its joint can be written

\[
 P_T(dp,dW,do)=f_u(p)dp \Psi_T(dW\mid p)L(do\mid p).
 \tag{13}
\]

Here W can include a complete finite latent hierarchy, graph links, or other hidden geometry, provided Psi_T is normalized and realizes the same retained p coordinates. Tonelli's theorem gives

\[
 P_T(o)=\int f_u(p)L_o(p)dp
       =\prod_j\frac{u_j}{(u_j+n_j)(u_j+n_j+1)}.
 \tag{14}
\]

Thus replacing only that conditional geometry is not identifiable from these records, even when it changes the full hidden-state law. With an independent fixed prior on T, P(T|o)=P(T). A p-dependent membership channel can induce changing posterior membership, as the earlier construction already shows, but it is a different object from comparing generative models T with the same f_u. No geometry-dependent evidence term may be manufactured by dropping a normalizer or retaining only the favorable part of the joint.

In the particular standardized factorization (4), integrating the children also gives

\[
 P(dp,dz,o)=f_u(p)L_o(p)dp N(z;0,I_r)dz.
 \tag{15}
\]

Hence Z is independent of the existing observations and p, and its exact posterior stays N(0,I_r). Auxiliary flags depending only on p do not alter this conclusion. This newly introduced residual latent alone cannot carry the original record predictions. Retaining p alongside it retains that information, but the record carrier is then still required. This statement concerns the present labeled experiment; new observations of geometry would define another experiment. Existing marked parents need not be such standardized residual latents.

The proper shared-parent prior in PIFB2 can be used to define a different generative model. To change evidence here it must change the induced joint on record-relevant probabilities or their normalized observation evaluator, or be assessed by a separately declared task/resource criterion. The source has not specified that replacement for this experiment. Its existence as a proper tree generator does not establish the missing equality, improvement, or model choice.

## 6. Resource and recursion accounting

The old conditional geometry uses sixteen random mean coordinates and a generic fixed description with 16 entries of a, 128 of L, and 136 of Sigma: 280 scalar coefficients. A dense implementation of (4) uses 184+16r stored coefficients before removing loading redundancies, and draws sixteen noise coordinates plus r latent coordinates. For r=4 the smaller family is restrictive; for r=8 the raw coefficient count is 312 and the draw count is 24. These are declared representations, not minimum description lengths or runtime measurements. The structured witness (8) has a compact description on either side, so its symmetry cannot be counted as a formation-specific saving.

Integrating children can reduce a sampling array if the complete retained evaluator, marks and conditional recovery permit it. Equations (12)-(15) show why retaining Z alone fails the current records and why simply adding it supplies no cost reduction. The earlier 32-to-24-to-16 marked geometry counts, native 24-coordinate learning state, and finite feedback-filter costs are unchanged. Nothing in this calculation closes their net resource gate.

A finite Gaussian tree composes by normalized integration, as the existing source establishes. If it is to reproduce a particular child law, its conditional-independence, separator-rank, mean, and covariance constraints must hold at each proposed separator. An admitted marginal factorization does not also prove descent of the original dynamics, the sufficiency of Z under all preparations, or an informative reduced two-level predictor. Those are separate obligations in the attachment. This calculation neither reruns nor weakens the fifteen exact local negative admissions.

## 7. Evidence and the next decision

The [exact script](evidence/post-merge-bridge/gaussian_bridge_exact.py) checks the scalar normalizers, the omitted-root singularity, the positive-definite witness, its exact dimension-eight realization and row-space identities. Its [result](evidence/post-merge-bridge/result.json) records the command, runtime, hash, and outcome. General statements above are supported by written derivations, not by numerical agreement or a formal ledger certificate. The [inspection receipt](evidence/post-merge-bridge/execution-and-inspection.json) binds preservation and source checks.

Source reconciliation is complete for the named bridge: a proper fixed-tree generator exists; its displayed mean-field objective needs the root term; exact Gaussian replacement has restrictive admission conditions; and changing normalized geometry alone cannot improve this archive's evidence. The remaining model-level decision is the actual induced prior on the original record probabilities after merging, together with the complete operational resource comparison. No unique prior, cost, or preferred hierarchy follows from the current sources. This is a concrete specification gap, not a missing Gaussian integration or an invitation to repeat membership samplers.

The next continuation should reconcile completion requirements against this boundary: retain the admitted negative and conditional results, identify whether later user/source instructions authorize a particular record-relevant generative replacement or task-dependent approximation, and request only that consequential choice if none is supplied. Do not select a new likelihood, collected data, cost coefficient, or target grouping to manufacture success. The full useful learned-hierarchy goal remains incomplete.
