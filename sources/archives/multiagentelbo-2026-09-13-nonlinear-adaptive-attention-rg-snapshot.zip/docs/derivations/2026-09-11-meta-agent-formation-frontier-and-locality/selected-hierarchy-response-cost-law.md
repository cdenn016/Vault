# A joint resource and response frontier for the selected hierarchy

September 12, 2026. This report derives a parametric workload license for the complete vector-response carrier. It uses the same compact late native window and positive-prior family as the existing hierarchy and response results. Prices, workload sizes, query radii and tolerated errors remain variables. The result is a sufficient expected-cost certificate for specified implementations, not an optimized formation rule.

## 1. Sources, supplied results and the added workload assumptions

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, distinguishes a net organizational-cost license from its unproved replacement of pairwise coupling terms by child-parent KL terms. The [operational wiki definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires a joint law, evaluator, boundary access, marks and sufficient memory. Neither source identifies field counts with entropy or supplies resource prices.

The immediate inputs are [selected-hierarchy response](selected-hierarchy-response.md), the [interface construction](selected-hierarchy-response-interface.md), Sections 7–8, and the [response-law proof](selected-hierarchy-response-law.md), Sections 5–7, including their finite-depth qualifications. [Common-prior native episodes](common-prior-native-hierarchy-episodes.md), Section 7, supplies the saved late split-probability bounds. [The earlier resource frontier](native-episode-resource-frontier.md), Sections 2–5, supplies the fair coupled generator, available native evaluator, accounting convention and selection countercomparison. Its scalar-interface operation bound is not a bound for the present vector decoder without a new count.

Three mechanisms are relevant: direct accounting, whose first lemma is the new expected field gain; amortization, whose first lemma is the simultaneous residence-time and accuracy interval; and an obstruction, whose first lemma is containment of the parent algorithm in a sufficiently broad fine algorithm class. We prove the direct accounting result first, then solve its feasible region and state the obstruction.

Fix a prior in a sufficiently small common relative-open family positive on all twelve ancestries, a native preparation time t in I=[35,40], and either the recognition law or the current model posterior at t. These choices are held fixed throughout the workload. Let J>=1 be the finite number of admitted normalized contraction panels after the initial ancestry geometry, including the actual first panel. Every old input port remains available, with its original anchor, stage and block-input domain. The source's finite-depth theorem also covers new current cuts under those exact assumptions.

The added accounting contract has N>=1 resident preparations, L>=1 residence ticks and at most K>=0 anchored Bernoulli queries per preparation, with relative input norm at most R>=0. N,L,K,J are integers. A tick measures storage or an explicitly specified full-state transmission operation; L does not advance t. Queries are absolute counterfactual inputs to frozen preparations, not state updates. Cost expectations need only the prescribed marginal preparation laws; independence is imposed below only for the stated product-transcript accuracy claim.

## 2. The new field gain on the same native window

Let k_0 be the initial ancestry block count and k_j the count after panel j. The complete base carrier, including all necessary response vectors but no optional caches, has

\[
 n_{\rm fine}=36+4k_0,\quad n_J=12+4(k_0+k_J),\quad
 \Delta_J(t):=\mathbb E(n_{\rm fine}-n_J)=24-4\mathbb E k_J.
 \tag{1}
\]

The interface proof derives the response-vector count sum_j(k_{j-1}-k_j)=k_0-k_J, so (1) charges their actual storage. At the O/P reference, k_1=2 precisely on P_split and otherwise k_1=1. Thus Delta_1=20-4 Pr(P_split)>18 on all of I under both laws, by the saved strict upper bounds Pr(P_split)<1/2. The finite Gaussian/panel continuity argument preserves this strict inequality together with the response coefficients on one common full-positive-prior family. This is the new vector count, not the old scalar count imported by name.

Every further contraction has k_J<=k_1 pointwise. Therefore Delta_J>=Delta_1>18 for every finite J>=1 on that same family, without another continuity neighborhood depending on J. The base field gain lies in [8,20] on every realization. These facts are expected resident-field comparisons, not high-probability cost guarantees or minimal coding dimensions.

## 3. A complete sufficient cost inequality

Use the available shared residual-first generator, visible Gaussian factors, original-record/Radon–Nikodym evaluations and native moment solver in both implementations. Fine generation receives the same analytic reductions. We conservatively grant the fine side its positive microscopic-completion, required panel/readout and query costs for free when bounding the remaining parent-minus-fine cost. Common computations cancel only when their actual charged implementations and schedules agree.

Let c_w>0 price one resident real field per tick. Let B_0 be extra one-time preparation and implementation cost, B_s extra static storage/access cost per tick, A_J an upper bound on extra formation cost per accepted preparation, Q_J an upper bound on the extra cost per answered query, and d an upper bound on extra recurring per-preparation cost per tick. All are finite nonnegative charges in one adopted resource unit. They include actual lookups, masks, roots, masses, ports, history, decoder instructions, native memory and controller costs wherever those differ. In particular, the same adaptive controller program can have different work or storage after fine and approximate answers diverge; such differences belong in Q_J or d unless the charged schedule and allocation are fixed and common.

A_J includes vector-interface construction, all J panels, retained-history writes and any chosen decoder preparation. Q_J includes access, directional decoding, input differences, both Gaussian radial evaluations unless explicitly cached, the original anchor, clipping, answer generation and response-dependent controller work. Bounds may use the whole parent operation count and zero fine cost. They need not assume independence between branch cost and branch probability.

The new [operation record](evidence/selected-hierarchy-response-cost/cost-maps.json) counts all 176 augmented maps and 416 old-cut decoder rows. Under its convention every nonzero coefficient other than +1, including -1, costs one multiplication; an n-term sum costs n-1 additions. The four-coordinate next-carrier map costs at most 52 multiplications and 60 additions; a two-coordinate old-cut decoder costs at most 8 of each. Combining its literal panel and anchored-evaluator counts with the inherited first-assembly bound gives

\[
 A_1=164c_{\times}+180c_++8c_{\exp}+4c_U+4c_{\rm cmp}+c_{\rm case},\quad
 Q_1=15c_{\times}+14c_++2c_{\exp}+c_U+3c_{\rm cmp}+c_{\rm query}.
 \tag{A}
\]

Here c_case and c_query bound the additional charged formation and query access/control operations just specified; static preparation and recurring state remain separately charged. A new current cut needs at most four multiplications and four additions to form its two-coordinate residual, so the same Q_1 also bounds that case. The arithmetic query count takes h already oriented from source to target. If two endpoint inputs are supplied instead, add two multiplication charges and two addition charges for their two-coordinate difference. The record prices elementary functions as primitives, not their implementation internals. This is an ideal-real algorithm bound, not a finite-precision benchmark or an operation lower bound. The cost theorem admits implemented policies with the stated finite bounds; a measurable policy covered by the response theorem does not acquire a finite-cost implementation automatically.

For the stated workload, linearity of expectation and these cost upper bounds give

\[
 \mathbb E(C_{\rm fine}-C_{\rm parent})
 \ge NLc_w\Delta_J-B_0-LB_s-NA_J-NKQ_J-NLd
 >L\{N(18c_w-d)-B_s\}-B_0-N(A_J+KQ_J).
 \tag{2}
\]

No product of expected branch costs was used. A sufficient strict resource license is consequently

\[
 L\{N(18c_w-d)-B_s\}>B_0+N(A_J+KQ_J).
 \tag{3}
\]

Equation (3) is a conservative certificate, not a necessary condition for the actual implementation to win. If charges depend on N,L,K,J, precision, R or the prepared law, retain those arguments in (2)–(3). The constant-charge amortization below applies only when B_0,B_s,A_J,Q_J,d are uniform over the varied N,L. Any remaining implemented overhead D_extra(N,L,K,J) must be subtracted in (2) and added to the right of (3); an unspecified cost cannot be declared canceled or hidden as a fixed setup term.

This is a complete accounting contract for the frozen native-sufficient/Radon–Nikodym and anchored-query workload just stated. The correlated reverse conditional is retained as a mathematical interface, but its existence does not supply a conditional microscopic sampler. Actual reverse draws, an absolute Lebesgue-density oracle, a new filter or movement of sampled states require an implementation and its costs before they can be added to this theorem. We do not assume that an unavailable oracle becomes finite-cost by naming it B_0.

## 4. Joint accuracy and a nonempty compatible region

Put s_*=2 exp(-1/2), c_R=min(R,s_*) and beta_K(R)=min(1,0.494 K c_R). The source response theorem proves, uniformly on I and the same prior family, total variation at most beta_K(R) for the complete K-answer transcript of one preparation, including its common initial hierarchy/panel information and adaptive inputs. This is a transcript bound, not a claim that 0.494 K c_R is the risk of each individual query. The early window [5,7] instead uses 0.628; the present greater-than-eighteen storage certificate is established on I.

If the N preparations, panel randomness, local controllers and answer randomness are independent across preparations, their transcript laws are products. Couple each fine/parent transcript with its stated error bound and independently combine these couplings. The probability of any disagreement is at most 1-(1-beta_K)^N<=N beta_K. Thus

\[
 \operatorname{TV}_{\rm all\ N}\le\min(1,N\beta_K(R))
 \le\min(1,0.494 NKc_R).
 \tag{4}
\]

Within each preparation queries may remain fully adaptive. We do not invoke (4) for correlated preparations or a controller coupling different preparations without a corresponding joint conditional coupling argument. Per-preparation guarantees and the expectation identity (2) do not require the product assertion.

Let epsilon in (0,1) be a symbolic permitted transcript error, not an adopted user tolerance. Use m=1 for the per-preparation requirement and m=N for the product-workload requirement. Equations (3) and

\[
 0.494 mKc_R\le\epsilon
 \tag{5}
\]

describe a sufficient joint resource/accuracy region. Set a=18c_w-d. For fixed finite charges and fixed J,K, if a>0 and an integer N satisfies Na>B_s, every integer

\[
 L>\frac{B_0+N(A_J+KQ_J)}{Na-B_s}
 \tag{6}
\]

satisfies (3). Hence, for a per-preparation requirement already satisfying (5), the resource region is nonempty: N_min=max(1,floor(B_s/a)+1) is finite, and then the right side of (6) is finite. This does not improve an accuracy certificate that fails at the prescribed K,R.

For a whole-product requirement with fixed K,R and eta=0.494 Kc_R>0, choosing N large is not sufficient. The exact integer feasibility condition for these certificates is

\[
 N_{\min}\le N\le N_{\max}:=\lfloor\epsilon/\eta\rfloor,
 \qquad L\text{ satisfies (6)}.
 \tag{7}
\]

If eta=0 the accuracy condition adds no bound on N. If R is itself a variable of the workload, every finite positive K and any finite N satisfying Na>B_s admit strictly positive radii satisfying (5), followed by finite L from (6). This proves a nonempty parametric region without selecting any price, tolerance, query count or radius. It does not change a fixed task radius to manufacture a license. All error statements remain sufficient upper bounds; their failure is not a lower bound on actual response error.

## 5. Query density, finite depth and cache costs

Suppose K=ceil(rho L), rho>0, with fixed finite J and uniform charges. Since K<=rho L+1, a convenient sufficient resource condition is

\[
 L\{N(a-\rho Q_J)-B_s\}>B_0+N(A_J+Q_J).
 \tag{8}
\]

It can amortize finite setup when a-rho Q_J>0 and N(a-rho Q_J)>B_s. If that coefficient is nonpositive, increasing residence time cannot satisfy this certificate; it does not disprove a gain using sharper costs or Delta_J. For R>0 and either fixed choice of m, (5) additionally requires ceil(rho L)<=K_max=floor(epsilon/(0.494 m c_R)), equivalently L<=floor(K_max/rho). Compatible integer residence times must therefore lie above the strict threshold in (8) and below this accuracy ceiling. The interval can be empty. Fixed K avoids this density obstruction because its query cost is paid once per preparation and its error bound does not grow with L.

J is a separate parameter from L. The possible flattened geometries are precisely covered by the rooted connected-forest catalog: a whole-cycle tree has four missing-edge choices and four roots (16); a two-block partition has two pair-pair shapes with four root choices and four singleton-triple shapes with three root choices (20); a three-block partition has four possible paired edges and two roots for that pair (8); all singletons give one case. Later contractions use a subset of this catalog. The operation record counts maps with 2k input columns per scalar direction, namely current barycenters and marks, with actual block masses. Thus its current-carrier input contract matches later stages, and its map bound can be repeated while copying earlier response records with separately charged access/history work.

For a compiled historical/current-cut query, the final geometry and stored contrasts have 2k_J+(k_0-k_J)=k_0+k_J<=8 columns per scalar direction. Every decoded d is a linear row in them by the backward reconstruction proof. Two directions therefore cost at most 16 multiplications and 14 additions; the anchored remainder adds 7 and 6. Together with the repeated map/panel count this gives

\[
 A_J\le(52+112J)c_{\times}+(80+100J)c_+
       +J(8c_{\exp}+4c_U+4c_{\rm cmp})+c_{\rm case}(J),\quad
 Q_J\le23c_{\times}+20c_++2c_{\exp}+c_U+3c_{\rm cmp}+c_{\rm query}(J).
 \tag{B}
\]

Here c_case(J) includes actual formation-time routing, retained-record and history work; the same optional query input-conversion charge applies. Compiling and storing the coefficient rows, port lookup and history interpretation must be priced. Proper forest histories are finite because each proper contraction reduces a block count initially at most four; idle rounds do not alter the linear geometry. The deeper query bound uses this dimension argument, not a new enumeration or an optimality claim.

At most three original forest edges can be selected by proper contractions, which explains telescoping real-vector storage. Arbitrarily many finite idle panels can still generate flags, records, queries and access work. Their formation, static and recurring history costs retain their actual J dependence. If J grows with L, A_J and d cannot be held fixed in (6) or (8). Finite depth and a bounded geometric catalog are not depth-independent runtime or memory guarantees.

For an optional cache using at most s extra resident real fields per preparation, filling cost A_cache and changed query bound Q_cache, replace A_J by A_J+A_cache, Q_J by Q_cache and a by (18-s)c_w-d. More accurately one can retain the actual expected cache-field count in (2). Cached historical d vectors, endpoint contrasts or phi(d) values are additions to the base count, unless an explicit replacement eliminates other fields. Shared original anchors are already counted. Temporary scratch is charged for its actual lifetime and accesses rather than automatically for all L ticks. Cache construction or controller storage that grows with K or J keeps that dependence; no cache is simultaneously free storage and a claimed query saving.

## 6. Selection boundary, falsifiers and the remaining obligation

The native negative ELBO and Fisher information are unchanged by the complete sufficient channel. Therefore a resource gain from (3) can improve an adopted total resource objective while (5) controls this added response task. It neither derives a conversion of RAM fields or runtime into nats nor proves the manuscript's conjectured KL replacement. Evidence improvement along native t is shared with the fine implementation and cannot be credited again as a compression gain. Accounting ticks do not supply a native or physical clock.

There is no universal algorithmic superiority: if the admissible fine algorithm class contains the exact parent compiler and permits its output carrier, its minimum cost is at most that parent's cost. The stated comparison is between retaining the complete fine latent output and a specified sufficient vector-response output under the same declared capabilities. A sharper algorithm, different access contract or changed precision may change the frontier.

The source's selection countercomparison also survives. On a P_split preparation, force the two first parents into one root while retaining S, the root geometry, the one selected four-vector d_f and the original historical ports. This gives 24 fields instead of 28 and exactly decodes every original/first-cut anchored query. Preserve any required nominal panel record and charge the extra formation/history work. The expected additional field saving is 4 Pr(P_split)>0, so a sufficiently storage-heavy version of this narrower task can favor forced merging. This comparison does not preserve the same actual current membership/geometric output or statewise access to the two old means. It shows why those capabilities need an explicit requirement; a field charge and historical queries alone do not select the intermediate partition.

The theorem's proof fails if the actual carrier omits a declared port or sufficient field, if extra caches invalidate its field count, if a cost upper bound omits operations or has hidden workload dependence, if a noncommon evaluator is called free, or if (4) is applied without its product/conditional-coupling hypotheses. Numerical violation of a sufficient cost or accuracy inequality leaves that certificate unavailable rather than refuting all possible implementations. The strongest supported result is the explicit compatible region (3),(5)–(8) on the common late family, with the counted one-panel coefficients (A) and all other charges retained. The next material action is to supply the intended prices, workload and tolerated loss and evaluate these inequalities; no new trajectory is required.

The single [cost_maps.py](evidence/selected-hierarchy-response-cost/cost_maps.py) count ran in the companion assignment under pinned CPython 3.14.7 and reports `PASS_EXACT_RESPONSE_OPERATION_COUNTS`, taking 0.014742200000910088 seconds. Its result was read here; no calculation was rerun. The first-assembly coefficients remain inherited evidence, and the deeper bounds are the written arguments above. This assignment writes only this report and performed no scientific execution, new observation, larger-graph calculation, Lean, tamper check or edit to an earlier report.
