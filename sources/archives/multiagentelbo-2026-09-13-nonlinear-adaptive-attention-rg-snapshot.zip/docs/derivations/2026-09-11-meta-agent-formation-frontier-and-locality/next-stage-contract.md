# Next execution ticket: heterogeneous local-block admission

September 11, 2026. This ticket is the next discriminating phase after the retrospective frontier. It is a DEFINITION of a finite structural experiment. Execution requires the subsequent continuation requested in the governing plan; this session has not executed its fifteen-subset refinement or implemented a spatial learner.

## Question and frozen input

Does the frozen heterogeneous four-child process admit any proper reduction of a local child configuration while preserving its complete joint response to every exterior input? A partition of sixteen global configurations is not a partition of children. The earlier symmetric 16-to-9-to-5 hierarchy is completed calibration, and the nine finite-data one-state selections remain retained negative results for their frozen criterion.

Use the exact original process at source revision ed8f22a56df353b1535744509cc23fae46d5813c, with symmetric couplings (1/16,1/12,1/10,1/8,1/7,1/6), field actions ±1/5, sensor signal 3/4, and one uniformly selected reset site per event. Preserve counting measure, the complete record, and the inherited schedule. Do not change couplings, add a sensor, fit a new model, or gather data in this admission phase. Newer source changes require explicit reconciliation of the mathematical inputs.

The candidate menu is every nonempty subset of V={1,2,3,4}: {1}, {2}, {3}, {4}; {1,2}, {1,3}, {1,4}, {2,3}, {2,4}, {3,4}; {1,2,3}, {1,2,4}, {1,3,4}, {2,3,4}; V. All fifteen belong to the supplied complete graph. Connectedness supplies no additional selection among them. Include singletons and the whole-system endpoint; report ties and identity maps.

## Typed strong-exterior contract

For each A, let E=V\A, local configurations u in Y_A={-1,+1}^A and exterior x in Y_E={-1,+1}^E in increasing-site order. Seek one onto map h_A:Y_A -> S_A, independent of x. Require, for every u,x,a,s',x',e,

\[
\sum_{u':h_A(u')=s'} K^a(u',x',e\mid u,x)
=\overline K_A(s',x',e\mid h_A(u),x,a).
\]

This is a sufficient modular interface contract; it is not necessary for every weaker preparation-averaged prediction problem. Retain the entire next exterior sample x' jointly with local destination s' and the one shared record e. Do not multiply independently fitted exterior marginals or duplicate records.

The adapter to ControlledProcess has local state u, input (a,x), and integer-coded record alphabet

\[
\mathsf R_A=\{\mathrm{START}\}\sqcup
 (\{\mathrm{STEP}\}\times\{-1,+1\}\times\mathsf Y_E).
\]

Save an explicit codebook with START at ordinal zero. Store each emitted column in destination-major, record-major order. Define

\[
L^{(a,x)}(u',\mathrm{STEP},e,x'\mid u)
=K^a(u',x',e\mid u,x),\qquad
L^{(a,x)}(u',\mathrm{START}\mid u)=0.
\]

Every initial_sensor row is delta_START. Summing the emitted row over u',x',e gives one by the original normalized K; the unused START columns add zero. Initial rows also sum to one. START is noninformative bookkeeping excluded from likelihood and event counts. It is not an observation of the next exterior, and it does not reproduce the auxiliary fair symbol that the saved episode sampler never observes. If a later experiment observes an initial sensor, retain its actual tagged law and separately prove descent.

Run coarsest_partition on this local adapter and quotient_process on its result. The coarsest stable partition is common to every exterior input. Refining the global state while requiring exterior labels is not a substitute: it can yield different local partitions for different exterior configurations. A global parent formed from this adapter has sample map G_A(u,x)=(h_A(u),x) and fibers h_A^{-1}(s) x {x}.

## Complete parent and information access

Use the finite fixed-context carrier

\[
\mathsf Z_A=\mathsf S_A\times\{m_*\}\times\mathsf Y_E\times\{h_*\}.
\]

The response coordinate s and interface x are random samples; m_* is a fixed model-presentation mark and h_* is a fixed generative-memory mark. A recognition law is a distribution over this carrier, not the sample s. Couplings, sensor, schedule, and subset remain structural X outside the random channel. The singleton presentation evaluates one fixed normalized mechanism and establishes no model learning. Exact Markov closure permits singleton generative memory but a partially observed observer still requires a filter.

For one augmented fine source W and unchanged observation O, exhibit the deterministic normalized channel C_A(w,z)=1{z=g_A(w)}. Apply it to the same full correlated generative law, selected posterior at positive evidence, and recognition law. Local extraction reads u; interface extraction reads x. The recursive full-interface implementation receives (s,x) and its retained updates. A record-only observer has a different access map and filters the joint latent (s,x); do not give the saved parity predictor undeclared exterior access.

The induced static evaluator is the conditional law of (s,O,h_*) given (m_*,x) under the actual pushed joint. Choose explicit normalized versions on null interface fibers. The controlled evaluator is instead the row over (s',x',e) given (s,x,a). Prove their compatibility where claimed; they have different input types. Apply the existing finite conditional-KL identity to the actual common push under absolute continuity and finite log expectations. A fitted replacement joint adds the signed mismatch correction in local-contract.md §5 and cannot inherit the exact accounting by substitution.

## Outputs and focused acceptance

Save local maps, class counts, all factorized source fibers, initial codebooks and sensor checks, refinement class-count traces, normalized quotient rows, and exact emitted-row equality certificates for all fifteen subsets. For identity-only maps retain separating source pairs and exact discrepancies from the final refinement where useful. Record local size |S_A|, full retained size |S_A|2^{|E|}, observed interface bits |E|, filter coordinates for the declared access, and row storage. A reduction of the local sample must not hide unchanged or larger total interface/filter cost.

Use one CPU science process and the pinned interpreter, exact Fraction kernels, and a minimal analysis adapter. Tiny focused checks should cover START normalization and nonemission, emitted-row equality and source-fiber factorization, and direct finite sums. No broad suite, historical producer, corruption scenario, Lean, or GPU is needed. The normalized binary example in local-contract.md §7 can check that dropping exterior response is insufficient; it is a scientific counterexample, not a file-corruption test.

On the full Cartesian four-spin carrier, when two disjoint local maps are admitted, the block-replacement proof in local-contract.md §6 establishes closure of their single joint map F(y)=(h_1(y_A1),...,h_k(y_Ak),y_R). Initial-sensor descent remains separate. Any later second-level quotient must operate on that actual joint kernel under final-retained-history policies. Preserve the original scheduler; do not introduce simultaneous independent block updates. A useful two-level learned hierarchy is a later target, not implied by this structural admission.

The accepted exit is a complete finite admission table with proofs, or a precise no-compression result. If every proper subset requires identity, stop exact useful-local-compression claims for this interface. Approximation, a richer memory model, or a new boundary experiment would require a separately stated target; none is an automatic repair of that negative result. Do not tune the present sensor or coefficients until compression appears.

The single next action is to implement and execute these fifteen exact local adapters. No statistical spatial selection or fresh confirmation data are justified before this admission result is known.
