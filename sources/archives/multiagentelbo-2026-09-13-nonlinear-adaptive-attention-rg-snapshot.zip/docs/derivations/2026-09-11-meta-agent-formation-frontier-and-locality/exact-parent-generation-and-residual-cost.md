# Exact parent generation and residual-first cost

September 12, 2026. The complete parent construction had a normalized law and relative-density evaluator, but no concrete low-rejection generator. The positive envelope from [ancestry screening](certified-ancestry-screening-and-native-error.md) now supplies an exact sampler of the full correlated recognition law, with all ancestry hypotheses retained. At the saved unit precisions its expected number of proposals is at most approximately 23.13354 for every positive ancestry prior. No target normalizer is needed to draw a sample.

A second exact reduction removes link directions invisible to the transported parent, retaining their squared radius for the learned link energy. Testing the two channels in sequence reduces the Gaussian work further. Under an explicit random-variate charge, the resulting parent generator uses fewer than 236 standard Gaussian variates on average at this point, plus fewer than 58 additional uniforms and at most six logarithms for the radius. These are mathematical work bounds, not executed sampling or elapsed-time measurements. Exact moment/density evaluation, native learning, interfaces and organizational overhead remain separate costs.

## 1. Source boundary and the operation being constructed

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, requires a net benefit after carrying the parent and its cross-scale structure. The [current wiki definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires complete law, evaluator, access, marks and memory. The [complete-channel derivation](shared-parent-complete-channel-and-recursive-cost.md), Sections 4-6, explicitly separates the existence of a normalized reference law from an inexpensive generator. The [transported-prior derivation](transported-parent-priors-and-induced-couplings.md), Sections 2-4, supplies the specific Gaussian model and its downward recovery. Its formulas, including the transported child-noise energy, govern this continuation.

Freeze one recognition state while drawing a parent sample. The root remains matched, the likelihood power is s=1, and the original ordered record batch has n=(8,1,8,1) successes and one failure at every label in each of the two channels. No observation, prior value, trajectory, parameter fit or selected grouping is introduced. H denotes an ancestry R with its existing root/tree decoration; both channels share it. The first geometric parents in this construction use that same realized H. Their uncertainty is retained as part of the sample; H is not replaced by its MAP value.

Write v_j=1/rho_j and let G_H be the normalized Gaussian primitive law at these recognition variances. For each coordinate direction, its residual is r=B epsilon+J_R xi-C_H ell, with positive covariance Gamma_H. Let y_H=pi_R exp(lambda k_R)/N_R, where lambda=omega-2 log rho_b. Then the recognition law is

\[
 Q(dH,dX)=Z^{-1}y_H L_o(r)G_H(dX),
  Z=\sum_H y_H\zeta_H,
 \zeta_H=E_{G_H}L_o.
 \tag{1}
\]

The symbols y_H need not sum to one; Z provides the normalization. The sampler changes no generative factor or complete-model Fisher metric. It constructs a frozen-state draw from (1), not a process of physical links or an integration of the native learning equations.

## 2. A normalized Gaussian proposal and exact acceptance

The preceding bound has L_o<=C L_half, where L_half=product_(e,x)(p_e^x)^(n_e/2) and p_e^x=exp(-||r_e^x||^2/2). Its constants are

\[
 C=C_1^2,
  C_1=\frac{262144}{263671875},
  D=\operatorname{diag}(n/2),
 \bar e_H=\frac{C_1}{\det(I+\Gamma_HD)},
 \bar\zeta_H=\bar e_H^2.
 \tag{2}
\]

The same bound holds separately for each channel, with constant C_1. Tilting G_H by L_half makes its four residual coordinate vectors independent zero-mean Gaussians with covariance

\[
 \widetilde\Gamma_H=(\Gamma_H^{-1}+D)^{-1}
 =\Gamma_H-\Gamma_H(\Gamma_H+D^{-1})^{-1}\Gamma_H.
 \tag{3}
\]

This identity follows by multiplying either side by Gamma_H^(-1)+D. It is positive definite. Define bar Z=sum_H y_H bar zeta_H. First choose H with probability y_H bar zeta_H/bar Z, then draw its four residual vectors from (3). Accept with probability

\[
 A(r)=\frac{L_o(r)}{C L_{\rm half}(r)}
      =a_b(r^b)a_m(r^m),
 
 a_x(r^x)=C_1^{-1}\prod_{e=1}^4(p_e^x)^{n_e/2}(1-p_e^x).
 \tag{4}
\]

Each a_x lies between zero and one by the original envelope proof. At a zero residual with p=1, define the factor as zero. The proposed joint density times (4) is y_H times the original Gaussian residual density times L_o/bar Z. Conditioning on acceptance therefore gives exactly the H,r marginal of (1). Repeated independent proposals terminate almost surely, because Z/bar Z>0. This proof includes the posterior reweighting of ancestry and geometry; choosing H once from the proposal and then retrying its residual indefinitely would generally give the wrong ancestry distribution.

Exactness here refers to the probability construction with ideal real Gaussian and uniform variates. A floating-point implementation requires controlled rounding and acceptance decisions before it can claim exact simulation; no such numerical sampler is implemented here.

The prior-to-posterior acceptance probability Z/bar Z does not inherit the extremely small absolute evidence of the original ordered batch. The Gaussian tilt has already absorbed its success factors. Neither Z nor the sixteen-term exact likelihood integral is required for the acceptance test. The thirty-one distinct covariance maps suffice for the proposal normalizers; the full forty-five-decoration metadata remains available. Decorations with the same covariance and prior weight can be drawn conditionally within that proposal class without changing the law.

## 3. Test one channel before generating the next

One can draw the two coordinate vectors of channel b first, using eight scalar standard Gaussian variates after factoring (3). Test a_b using one independent uniform. On failure, start a fresh attempt with a freshly chosen H. On success, generate the eight Gaussian variates for channel m and test a_m with a fresh uniform. Any second-channel failure also restarts the whole attempt. Once both tests pass, retain the same H and the two accepted residuals.

The probability of acceptance for a given proposed H remains t_H^2, where t_H=e_H/bar e_H and e_H is the exact one-channel evidence. Thus the staged algorithm has the same exact accepted law as (4). It does not reuse an accepted first channel after a rejected second channel under a newly drawn ancestry.

Define the cross integral J=sum_H y_H bar e_H e_H. The expected attempt count, second-channel generation count and Gaussian residual work per accepted sample are

\[
 E N=\frac{\bar Z}{Z},
  E N_2=\frac{J}{Z},
  E N_{G,\rm residual}=8\frac{\bar Z+J}{Z}.
 \tag{5}
\]

For example, a single attempt reaches channel m with probability J/bar Z and succeeds with probability Z/bar Z. If c is its expected work and W is the expected work until acceptance, restarting gives W=c+(1-Z/bar Z)W, hence W=c bar Z/Z. This proves (5) even though work within an attempt and its acceptance are dependent. The expected number of acceptance uniforms is (bar Z+J)/Z. A direct inverse-CDF categorical implementation uses one further uniform per attempt; its search and table costs must be charged separately.

Let zeta_R,bar zeta_R,j_R be the conditional-decoration averages of e_H^2,bar e_H^2,bar e_H e_H. With w_R=Q(R),

\[
 \frac{\bar Z}{Z}=\sum_Rw_R\frac{\bar\zeta_R}{\zeta_R},
  \frac{J}{Z}=\sum_Rw_R\frac{j_R}{\zeta_R},
  j_R^2\leq\bar\zeta_R\zeta_R.
 \tag{6}
\]

The last inequality is the finite weighted Cauchy-Schwarz inequality. These coefficients pool with the target ancestry probabilities, although the algorithm proposes H using different probabilities. A ratio bar zeta_R/zeta_R is the mean attempt count for a sampler restricted to R; it is not the mean waiting time of the full sampler conditioned on its final accepted R.

At the saved unit precisions, exact fractions give

\[
 \max_R\frac{\bar\zeta_R}{\zeta_R}
   \simeq23.13353654<24,
 
 \max_R\frac{\bar\zeta_R+j_R}{\zeta_R}
   \simeq27.94319779<28.
 \tag{7}
\]

Consequently EN<24 and Pr(N>n)<=(23/24)^n for every positive pi and every real lambda at this point. All evidence functions are positive and continuous near unit rho, so these strict rounded bounds persist on a nonempty recognition-precision neighborhood, uniformly over pi and lambda. No radius is evaluated. Continuity of the native filter gives a corresponding short interval from the unit preparation; its numerical duration is not claimed. A finite attempt cap would introduce failure or bias and is not part of the exact sampler.

## 4. Generate the hidden Gaussian variables only after acceptance

For one coordinate direction let X=(epsilon[4],xi[k],ell[4],Y), with diagonal covariance V_0 and residual matrix A_H=[B,J_R,-C_H,0]. Its dimension is 9+k and A_H has rank four because Gamma_H=A_H V_0 A_H^T is positive definite. The Gaussian conditional given r is

\[
 X\mid r,H\sim N\left(V_0A_H^T\Gamma_H^{-1}r,
 V_0-V_0A_H^T\Gamma_H^{-1}A_HV_0\right).
 \tag{8}
\]

Multipliers depending only on H,r leave this conditional unchanged. It is therefore the correct lift after either acceptance algorithm. The covariance has rank 5+k: conjugating by V_0^(-1/2) gives the orthogonal projector onto a kernel of codimension four. A thin Gaussian factor uses 4(5+k) scalar Gaussian variates across the four directions, generated once after acceptance. This deferred construction is also available to a fine sampler and must be included in a fair baseline.

## 5. A radial quotient of the invisible tree-link directions

Let D_H be the k non-tree rows of C_H and let V=D_H ell denote the individual cut/loop marks. The current transported construction makes D_H full row rank. Put

\[
 M_H=D_HD_H^T,
 \Pi_H=D_H^TM_H^{-1}D_H,
 \ell=D_H^TM_H^{-1}V+\ell_\perp,
  D_H\ell_\perp=0.
 \tag{9}
\]

Pi_H is the Euclidean orthogonal projector onto the visible link directions. Because the link covariance is v_c I_4, ell_perp is independent of V and all other primitive noises, with covariance v_c(I-Pi_H). Every row of C_H is either zero or a row of D_H, so the residual is independent of ell_perp as well. In the transported model z_A=Y+xi_A+bar epsilon_A; its first barycenters also do not depend on these hidden directions. Every subsequent prescribed contraction uses only those barycenters and V marks. Thus all these geometry maps remain independent of ell_perp.

The learned energy E_c prevents discarding the hidden links completely. Instead retain their one total squared radius:

\[
 E_c=\sum_{d=1}^4(V^{(d)})^TM_H^{-1}V^{(d)}+R_\perp,
  R_\perp/v_c\sim\chi^2_{4(4-k)}.
 \tag{10}
\]

The radius is independent of the visible variables conditional on H, before and after the record acceptance. For k=4 it is zero. A generator using only uniforms and logarithms is

\[
 R_\perp=-2v_c\sum_{j=1}^{2(4-k)}\log U_j,
  U_j\overset{\rm iid}{\sim}{\rm Uniform}(0,1).
 \tag{11}
\]

For s>=0, each factor has E exp(2v_c s log U)=(1+2v_c s)^(-1). The product transform of (11) is (1+2v_c s)^(-2(4-k)), equal to the Gaussian squared-radius transform in dimension 4(4-k). Equality of Laplace transforms of nonnegative probability laws proves (10)-(11). Their means and variances are 4(4-k)v_c and 8(4-k)v_c^2. The executed check below independently reconstructs the first two total link-energy moments from the full and reduced covariances; the transform calculation establishes the whole radius law.

Conditional on its radius, the omitted vector is uniform on the sphere in ker D_H across the four coordinate directions. Its orientation is independent of the precision parameters and original likelihood. This supplies a normalized common reverse kernel for this angular quotient; it is not merely equality of two marginal energy moments. The other primitive energies are unchanged. The restriction to the first geometry's own ancestral H matters: an unrelated geometric partition with different internal paths could expose discarded link directions and requires its own retention check.

## 6. A complete parent draw without materializing the fine links

Use the reduced per-coordinate Gaussian variable eta=(epsilon[4],xi[k],V[k],Y), whose dimension is 5+2k. If E_H embeds non-tree rows into the four edge rows, then

\[
 \mathcal V_H=\operatorname{diag}(v_aI_4,v_bI_k,v_cM_H,v_v),
 \mathcal A_H=[B,J_R,-E_H,0],
  r=\mathcal A_H\eta.
 \tag{12}
\]

Its residual covariance is still Gamma_H. After the accepted r, draw eta from the Gaussian conditional obtained from (8) by replacing V_0,A_H with mathcal V_H,mathcal A_H. Its covariance has rank 1+2k. Generate these 4(1+2k) Gaussian variates, then the independent radius (11). This lift exactly matches the joint law of every visible primitive and the full link energy under (1).

The output consists of H, the eight probabilities p from the accepted residuals, E_a=sum||epsilon||^2, E_b=sum||xi||^2, E_v=||Y||^2, E_c from (10), z_A=Y+xi_A+bar epsilon_A and all individual V marks. It is precisely the existing complete first-parent state. No full fine vector mu, discarded tree-link orientation or independent product of parent marginals is needed. The conditioning matrices and their thin factors are additional preprocessing, with at most forty-five decorated cases and matrices of dimension at most thirteen; they are not counted as free Gaussian draws.

Apply the existing weighted barycenter and mark maps to that same accepted sample to obtain a second prescribed geometric level. The induced correlation is preserved. For the canonical pair roots 0,2 and trees 01,23, the second barycenter and loop satisfy, per coordinate at the original unit prior,

\[
 z_*=(z_{01}+z_{23}-V_{12})/2,
  W=V_{12}+V_{30},
 
 \operatorname{Cov}[(z_*,W)^T]=
 \begin{pmatrix}9/4&-1\\-1&4\end{pmatrix}.
 \tag{13}
\]

The calculation checks (13) and equality of full and reduced proposal covariances too. The accepted law then agrees by the preceding conditional and acceptance proofs. Independently resetting the next-level covariance would change the model.

Given one parent draw, repeated original record queries must reuse its p values. Drawing a fresh parent before every query would generally erase the repeated-query dependence already established by the nonzero conditional probability variance. Conditional Bernoulli draws using the retained p reproduce any finite sequence of the original queries, including adaptive label choices using their shared history. Such a controller's history is additional state when needed. Changing the learned recognition parameters during a draw, or between queries while pretending the same sample has the new law, requires a specified update kernel. The present generator supplies no physical trajectory or new online filter, and samples do not replace the exact moment inputs to the native natural-gradient learner.

## 7. What this prices, and what it does not

The following counts concern one accepted state with k ancestral blocks. The Gaussian counts are only the conditional lift after its residuals have passed both tests. Discrete ancestry/tree metadata and Gaussian factorization are additional.

| k | Full conditional Gaussian variates | Reduced conditional Gaussian variates | Radius uniforms and logs | Fine sample coordinates | First-parent coordinates |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1 | 24 | 12 | 6 each | 40 | 20 |
| 2 | 28 | 20 | 4 each | 44 | 28 |
| 3 | 32 | 28 | 2 each | 48 | 36 |
| 4 | 36 | 36 | 0 | 52 | 44 |

The first-parent displayed count is 12+8k. For a pair followed by one root, the corresponding displayed sequence remains 44 to 28 to 20, with the original ancestry, counts, probabilities and energies retained. This is not a peak-scratch count, a bit-complexity bound or a minimality theorem for the transported model. The reduced generator may use more transient coordinates than its final output.

Combining (5) with the conditional Gaussian ranks gives exact work coefficients

\[
 E N_{G,\rm full}
 =\sum_Rw_R\left[8\frac{\bar\zeta_R+j_R}{\zeta_R}+4(5+k_R)\right],
 
 E N_{G,\rm parent}
 =\sum_Rw_R\left[8\frac{\bar\zeta_R+j_R}{\zeta_R}+4(1+2k_R)\right].
 \tag{14}
\]

At unit precisions the maxima of these coefficients are approximately 247.5455823 and 235.5455823. The parent additionally uses 2 E_Q(4-k) uniforms and logarithms for the radius, at most six of each. Its categorical uniforms average less than 24 and acceptance uniforms less than 28; together with the radius these are fewer than 58 additional uniforms on average. Gaussian generation uses its own randomness, so the latter count must not be advertised as all underlying random bits. These bounds hold for every positive prior without choosing one. The earlier simultaneous-channel generator instead had Gaussian maxima approximately 394.1365846 and 382.1365846; the new staged calculation prices a different, exactly equivalent rejection order.

A cost comparison can remain explicit without inventing a scientific penalty. Let c_N,c_U,c_log price a Gaussian variate, an additional uniform and a logarithm in a chosen implementation. For otherwise identical staged samplers, the radial replacement changes this part of expected cost by

\[
 \Delta C_{\rm random}
 =E_Q(4-k)[4c_N-2(c_U+c_{\log})],
 \tag{15}
\]

where positive Delta C means a saving. One must add differences in conditional factoring, matrix/vector arithmetic, aggregation, storage, access and startup amortization to decide total cost. There is no assumed sign for their sum. A specified Box-Muller implementation, for example, can generate four normals using four uniforms, two logarithms, two square roots and four trigonometric values; a radius with four degrees uses two uniforms and two logarithms. This illustrates the eliminated orientation work under one explicit primitive implementation, not a benchmark against every Gaussian generator.

The fine implementation can also use residual-first rejection and can exploit the angular quotient when asked to return only this same parent interface. The saving therefore belongs to an exact sufficient implementation, not independently to endogenous group formation. Relative parent density evaluation still needs its reference and normalizer, exact native force evaluation still needs the established moment oracle, and the seven evolving law coordinates remain shared across scales. The sampler does not establish an improved optimized VFE, pay a positive organizational overhead, select persistent membership or introduce a second learned interaction law. New parent interactions must have their evaluators retained and their normalized generator and Fisher metric derived before being used.

## 8. Evidence and continuation

The [Gaussian identity calculation](evidence/parent-generation/generation_exact.py) ran once under pinned CPython 3.14.7 and passed in 0.380060899995442 seconds. It covers all twelve ancestries and forty-five decorations: thirty-one residual proposal covariances, projector identities, full/reduced conditional means and covariance ranks, independence of hidden link directions, equality of two link-energy moments and the recursive geometry covariance. It draws no random variable and does not rerun the earlier likelihood integrals.

The separate [staged-cost calculation](evidence/parent-generation/staged_cost_exact.py) passed once in 0.007346999998844694 seconds. It uses saved exact evidence/envelope fractions to calculate all one-channel acceptance factors, cross integrals and the uniform work bounds. It performs no matrix-integral reevaluation. The complete output laws, termination, radius law, arbitrary-positive-prior bounds and finite-depth pushforward equality are established by the written arguments; the scripts are algebraic evidence for the declared finite instances.

This resolves a concrete generation obligation for the current complete correlated parent, including the link energy that its native learner needs. The next gap is the complete reusable-parent implementation and its recursive learning contract: what additional second-level state or interaction is learned, what full operation benefits, and how its complete cost compares with the fine analytic implementation. The current global update, neutral ancillary root and inherited correlated prior remain unchanged. Original data, earlier results, negative admissions and WIP are preserved. No sampling, observations, fitting, ODE, numerical prior, parameter search, full suite, GPU, Lean, tamper check, production sampler, vault edit, publication or canonical synchronization was run.
