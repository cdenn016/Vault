# Collective response of the actual retained hierarchy

September 12, 2026. This extends the frozen anchored-response guarantee from the fixed pair probe to the actual H-dependent first partition, and through the existing second panel while retaining the old input ports. The resulting bound applies to the complete native joint law, without conditioning on a preferred regime. No new dynamics, observation or tolerance is introduced.

## 1. Sources and the common experiment

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:epistemic_collapse` and `eq:rg_closure`, was reread: finite coherence, response accuracy, force closure and persistence remain separate claims. The [wiki's operational definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires complete law, evaluator, access, marks and memory. [Common-prior native episodes](common-prior-native-hierarchy-episodes.md), Section 4, supplies the actual forty-five first-stage decorations and 176 second-panel cases. [Complete channels](shared-parent-complete-channel-and-recursive-cost.md), Sections 3–7, supplies individual marks, actual geometric composition and native sufficiency; [transported priors](transported-parent-priors-and-induced-couplings.md), Sections 2–4, fixes the generator and its energy definitions. The [response bound](coherence-response-bound.md), [native response-law calculation](native-coherence-response-law.md), and [selected interface construction](selected-hierarchy-response-interface.md) are the immediate dependencies.

For every realized generative decoration H, use its actual partition, roots and trees as the first geometric output. Keep all twelve connected ancestries in the family. Let k_H be its number of first blocks and E_cut(H) its original labeled cuts. On a frozen draw, a query selects an available first cut e=(i,j), a channel x=b or m, and collective shifts u_A of the first blocks. Its relevant input is h_e=u_B-u_A for i in A,j in B, with ||h_e||<=R. The answer is one Bernoulli draw. The same policy may choose cuts, channels and inputs adaptively using common retained information and preceding answers.

If k_H=1, the only new response action is a null port with deterministic answer bottom. It is not a hidden independent-group input. All original unperturbed records remain retained. This null rule concerns the first partition: if k_H>1 and the second panel merges everything to q=1, the old first-parent ports remain available. A merger cannot obtain zero error by deleting the tested task.

The second panel is sampled once from the baseline first state, by the existing rule, before response queries. Queries use absolute hypothetical inputs relative to that frozen preparation; they neither move a sampled state nor resample the panel. Native time indexes the preparation law. The fifteen earlier negative admissions retain their separate experiment and conclusions.

## 2. Actual-tree residual contrasts

Work in one channel and use edge order (01,12,23,30). Put r_e=mu_j-mu_i-ell_e, z_A=n_A^(-1)sum_i(mu_i-g_i), and delta_i=mu_i-g_i-z_A. The actual path translations g_i and dressed marks give

\[
 r_e=d_{H,e}+\eta_{H,e},\qquad
 d_{H,e}=z_B-z_A-V_e,\qquad \eta_{H,e}=\delta_j-\delta_i.
 \tag{1}
\]

Let psi_Hi be the row of signed internal-tree path coefficients from the root of A to i, now acting on the residual vector r rather than on links. On an internal tree edge the difference of mu_i-g_i is exactly r_e. Therefore

\[
 \delta_i=(\psi_{Hi}-\overline\psi_{HA})r,\quad
 \overline\psi_{HA}=n_A^{-1}\sum_{i\in A}\psi_{Hi},\quad
 \eta_{H,e}=c_{H,e}r,
 \tag{2}
\]
\[
 c_{H,e}=\psi_{Hj}-\overline\psi_{HB}
                       -\psi_{Hi}+\overline\psi_{HA}.
\]

These rows are fixed rational coefficients for each H, supported on its internal trees. Changing a root adds a common row within its block and cancels after centering. Thus for P={01},{23}, every root decoration has c_12=c_30=-(1,0,1,0)/2. For k_H=4 every block is a singleton, all c rows are zero, and the anchored approximation is exact. For k_H=1 there is no cut row to evaluate. No loop or parallel cut is averaged away.

For each H let U_H contain one representative of every distinct nonzero c_H,e up to sign, and set J_H=sum_{c in U_H}c^T c. This deduplication is only for a norm bound: all original port labels, orientations and endpoints remain distinct. For the two channels define

\[
 W_H(X)=\sum_{x=b,m}\sum_{c\in U_H}\|c r^x\|^2,
 \qquad \max_{e\in E_{\rm cut}(H),x}\|\eta_{H,e}^x\|^2\le W_H(X).
 \tag{3}
\]

The empty maximum is defined as zero. Repeated or opposite rows have the same squared norm, so (3) follows by bounding the maximum by the sum of nonnegative terms.

## 3. One explicit native-law moment

Use the positive likelihood-tilted residual moments already proved in the native response-law report. Conditional on H and one channel, with n=(8,1,8,1),

\[
 \Gamma_H=r_aG_a+r_bG_{b,H}+r_cG_{c,H}>0,\quad
 D_M=\operatorname{diag}(n+\mathbf1_M),\quad
 \Lambda_{H,M}=(\Gamma_H^{-1}+D_M)^{-1},
\]
\[
 e_H=\sum_M\frac{(-1)^{|M|}}{\det(I+\Gamma_HD_M)},\quad
 T_H=\sum_M\frac{(-1)^{|M|}\Lambda_{H,M}}{\det(I+\Gamma_HD_M)},\quad C_H=T_H/e_H.
 \tag{4}
\]

Here e_H>0 is the original one-channel evidence and C_H is its per-coordinate residual second moment. Positivity and finite moments follow from the original nonnegative Gaussian likelihood tilt, positive almost everywhere; the finite alternating expansion is not a mixture with signed probabilities. There are two coordinate directions per channel, hence E(||c r^x||²|H)=2c C_H c^T.

Let a_H=pi_R w(H|R)exp(lambda k_H), Z=sum_H a_H e_H² and alpha_H=a_H e_H²/Z. The desired nonnegative scalar is

\[
 V_Q(t):=\mathbb E_{Q_t}W_H
  =4\sum_H\alpha_H\operatorname{tr}(J_HC_H)
  =\frac{4\sum_Ha_He_H\operatorname{tr}(J_HT_H)}{Z}.
 \tag{5}
\]

Both channels share H, so e_H is squared before mixing over H. Equation (5) uses every native ancestry with its actual weight and requires no independence after this mixture. For the current model posterior use its model variances and lambda=0. The likelihood power is the existing invariant s=1; no fractional-power expansion is being approximated. Formula (5) is a finite Gaussian moment calculation for every positive variance preparation, including the full-positive prior family.

## 4. Anchored queries and the actual second panel

For each available old cut and channel, use the original p_e^x(0) anchor and define

\[
 a_{H,e}^x(h)=\operatorname{clip}_{[0,1]}
 \{p_e^x(0)+\phi(d_{H,e}^x+h)-\phi(d_{H,e}^x)\},\qquad
 \phi(v)=e^{-\|v\|^2/2}.
 \tag{6}
\]

It is a normalized Bernoulli kernel exact at h=0. The previously proved mixed finite-difference identity, ||Hess phi||<=1 and projection onto [0,1] give

\[
 |p_e^x(h)-a_{H,e}^x(h)|\le c_R\|\eta_{H,e}^x\|,
 \qquad c_R=\min(R,2e^{-1/2}).
 \tag{7}
\]

Let sigma denote the actual active-mask/tree history. The existing normalized panel kernel K(dsigma|C_1) uses gamma_e=phi(d_e^b)phi(d_e^m), independently drawn edge flags conditional on C_1, and the declared spanning-forest/root rule. Fine and compressed experiments use this same kernel, not different fine-residual and parent-residual panel rules. Couple their panel uniforms so sigma is identical before queries.

The old vector responses must remain reconstructible after the panel. A concrete sufficient construction retains d_f on each of the k_H-q actual second-tree edges. To see why, let t_A be its actual path translations and let

\[
 Z_C=\frac{\sum_{A\subset C}n_A(z_A-t_A)}{\sum_{A\subset C}n_A},\quad
 \Delta_A=z_A-t_A-Z_C,\quad \sum_{A\subset C}n_A\Delta_A=0.
\]

On a selected tree edge f=(A,B), d_f=Delta_B-Delta_A. Integrating these stored differences along the tree, then subtracting their actual mass-weighted mean, reconstructs every Delta_A. For every old cut copy,

\[
 d_e^{\rm old}=d_e^{\rm new}+\Delta_B-\Delta_A,
 \quad d_e^{\rm new}=Z_D-Z_C-(V_e+t_A-t_B).
 \tag{8}
\]

The new marks are retained individually; selected tree marks are zero with their labels recorded. Thus all old d_e, old phi(d_e), and anchored kernels (6) are recovered exactly. The [interface report](selected-hierarchy-response-interface.md) gives the complete construction and its count 12+4(k_H+q). Scalar phi(d_e) values alone do not supply the directional input dependence. Old ports remain old ports even when their edges become internal loops at the second stage. A controller that accesses discarded first geometry needs that information carried separately.

For K queries under the common policy, couple Bernoulli uniforms until a first differing answer. Equations (3) and (7) bound its probability by min(1,K c_R sqrt(W_H(X))). The panel can depend on the same state as W_H; this causes no error in the unconditioned calculation because sum_sigma K(sigma|C_1)=1 pointwise. Cauchy–Schwarz then proves the single curve

\[
 \operatorname{TV}(\mathcal L(\text{fine hierarchy, transcript}),
                    \mathcal L(\text{retained hierarchy, transcript}))
 \le\min\{1,Kc_R\sqrt{V_Q(t)}\}.
 \tag{9}
\]

Here the compared hierarchy data are the identical advertised ancestry, panel/stage history and common retained query information, together with cut labels, inputs and answers. Raw fine coordinates and a different-dimensional compressed geometry are not appended as competing observed outputs. Hierarchy history, cut labels and inputs are included in the transcript. The identical initial history and port information keep policy choices equal until an answer differs. The second compression adds zero error because its decoded kernels equal (6) pointwise. Both channels and every available cut can be chosen adaptively. This is the complete joint comparison, not a product of parent marginals or a selection-conditioned likelihood.

## 5. Existing window constants transfer without a new moment run

At the existing O/P boundary reference, O contributes zero to (5), whereas each P decoration has the single contrast class represented by (1,0,1,0)/2. Therefore

\[
 V_Q(t)=2\mathbb E_{Q_t}[\mathbf1_{H\in P}\|\eta^b\|^2]
       \le2M_{\rm fixed\ probe}(t).
 \tag{10}
\]

The same identity holds for the model posterior. Root choices do not change eta on P. The O term omitted on the left was a nonnegative term of the old fixed-probe moment, so this is a proved majorization, not a new numerical evaluation of a selected moment. The saved native bounds consequently give, under either complete law,

\[
 \operatorname{TV}\le
 \begin{cases}
 \min\{1,0.628K\min(R,2e^{-1/2})\},&t\in[5,7],\\
 \min\{1,0.494K\min(R,2e^{-1/2})\},&t\in[35,40].
 \end{cases}
 \tag{11}
\]

These coefficients retain strict slack. Equation (5) is continuous, indeed smooth, in the positive variance coordinates, lambda and fixed ancestry prior wherever Z>0. On a compact tube about the existing positive native path, all forty-five conditional moments are finite and the mixture denominator stays positive. The native field's established uniform finite-time dependence on its prior therefore preserves (11) on a smaller nonempty relative-open family of priors positive on all twelve ancestries, simultaneously with the original strict hierarchy-preference windows. The additional ancestries contribute through (5); they are not assigned zero error. No positive-prior trajectory or new moment window was evaluated for this implication.

The actual H-dependent moment V_Q has not been numerically evaluated here. A smaller late upper bound does not prove that its late value is below its early value; the previous strict ordering concerned the different fixed-probe moment. Null ports also change which capabilities are available across H. Equation (11) does not claim that a one-block H can answer the old fixed two-pair probe, or that a merger caused lower prediction error.

## 6. A depth-independent bound for every finite admitted contraction history

The following extension is conditional on repeating the existing normalized contraction rule; it asserts no new panel outcomes or additional learned hierarchy regime. Fix any finite number L>=0 of later panels, all sampled from retained baseline states before the response queries. Each panel may merge connected current blocks along a tree of their original labeled cuts, with actual additive masses and a retained root. It may not split blocks, replace a tree by a closed walk, introduce an edge or forget an old input port. Retain the complete history and every old vector-response decoder. At each stage add that stage's current cuts to the response catalog; an old port remains labeled by its original stage, cut, channel and block-input domain. Null stages introduce no new nontrivial ports, but cannot remove earlier ones. These are precisely the monotone geometric composition and response-retention assumptions being extended.

Let G range over every geometry reachable from the initial H by these contractions. The flattened forest of G contains the forest of H: a proper merge adds original edges joining different connected components, so cannot form a cycle. There are at most three selected forest edges in total. The vertex and edge sets, possible forests and retained fine-root labels are finite. A panel with no merge repeats the geometry. Thus the set of reachable geometries, although not the set of arbitrarily long discrete histories, is finite and independent of L. The direct/staged identities in the complete-channel source, Section 5, give the flattened fine paths at each step. Actual masses imply that its barycenters are the corresponding equal-fine-mass means. Applying (1)-(2) to that flattened forest gives r_e=d_{G,e}+c_{G,e}r on every current cut. Here H still labels the original generative decoration and its conditional covariance C_H; G labels only a later geometric output.

Let U_H^all be the finite union, up to sign, of all distinct nonzero rows c_G,e for current cuts of every such reachable G, including H, and define

\[
 J_H^{\rm all}=\sum_{c\in U_H^{\rm all}}c^Tc,\quad
 W_H^{\rm all}=\sum_{x=b,m}\sum_{c\in U_H^{\rm all}}\|cr^x\|^2,\quad
 V_Q^{\rm all}=4\sum_H\alpha_H\operatorname{tr}(J_H^{\rm all}C_H).
 \tag{12}
\]

Every historical or new cut error is bounded by sqrt(W_H^all). Repeating (8) reconstructs every previously retained d exactly, by induction on the finite stage index; a new current d is directly available. For each port use its own original fine anchor p_e(0), stage-specific d and actual collective input in (6). Hence no decoding error accumulates with depth. The same-policy coupling used for (9) applies simultaneously to all available stage/cut/channel choices. For every finite L,K and R>=0,

\[
 \operatorname{TV}(\mathcal L(\text{fine history, transcript}),
                    \mathcal L(\text{retained history, transcript}))
 \le\min\{1,K\min(R,2e^{-1/2})\sqrt{V_Q^{\rm all}(t)}\}.
 \tag{13}
\]

Indeed the normalized product of the possibly state-dependent preparation kernels sums to one for each fine draw; integrating the history-independent majorant W_H^all therefore gives exactly (12). This does not factor the joint law or assume independent panels after marginalizing the state. The bound depends on query count K, not on panel count L. Unlike the initial-port case, a k_H=4 preparation can later develop nonzero contrasts after mergers; its contribution is included in (12).

At the O/P boundary, O has no reachable cut and P has only its original contrast class: its sole proper merger produces one block with no new current cut. Thus V_Q^all=V_Q<=2M_fixed_probe there. The coefficients in (11) consequently apply to (13) for every finite L. The matrices J_H^all form one fixed finite family, so the compact-tube continuity argument in Section 5 supplies one common full-positive-prior neighborhood for these same constants at every finite depth, simultaneously with the established initial hierarchy-preference windows. It does not claim a new preference for deeper outcomes. All history, access and controller data must be priced; no bound on infinite-history memory, limiting processor, new graph family or physical path law follows. This extension is proved by the finite-forest argument and induction, not by a new enumeration or simulation.

## 7. Conditioning, evidence and remaining scope

For a specific regime event E determined by H and sigma, fine and retained preparations give the same probability p_E. If p_E>0, the conditional guarantee is instead

\[
 \operatorname{TV}(\cdot\mid E)\le
 \min\{1,Kc_R\sqrt{\mathbb E[W_H\mid E]}\},\qquad
 \mathbb E[W_H\mid E]
 =\frac{\mathbb E_{Q_t}[W_H K(E\mid C_1,H)]}{p_E}
 \le V_Q/p_E.
 \tag{14}
\]

Panel dependence matters in the middle expression: generally E(W_H K_E) is not E(W_H)E(K_E). The same joint coefficient cannot simply be reused after conditioning on a winning or merged regime. A sharp conditional result needs the panel-weighted moment and its normalization; (14) gives the available conservative alternative. For a finite deeper history use its normalized history kernel and replace W_H,V_Q by W_H^all,V_Q^all. No conditioning is needed for (9)–(11) or (13).

The new [map record](evidence/selected-hierarchy-response/response-maps.json) reports `PASS_SELECTED_HIERARCHY_RESPONSE_MAPS`: [response_maps.py](evidence/selected-hierarchy-response/response_maps.py) checked 68 cut-contrast identities over all 45 decorations and old-port decoder maps for all 176 saved panel cases, including the k_H=1 null case, k_H=4 zero contrasts, and every P root choice. Its exact rows and quadratic majorants are stored. It completed once in 0.07183760000043549 seconds under pinned CPython 3.14.7. That output was read here; no helper main, old geometry calculation, moment readout or ODE was rerun. The written identities establish the general finite-tree argument; the new exact check verifies the present catalog's coefficient implementation.

The supported result is (11) for the actual H-dependent first ports and actual second panel, and the same constants for all historical/new ports under every finite admitted contraction history by (12)-(13). The latter is conditional on the stated extension and retention rule; only the original 176 second-panel cases were mechanically checked. The construction preserves the complete native law and original sufficient statistics, while making no full-VFE force, physical-state persistence, causal selection or global-minimality claim. Complete resource costs belong to the explicit interface and workload comparison; they are not inferred from an error bound. Sharper coefficients would require evaluating (5) or (12), and a regime-conditional coefficient would require (14), but neither is needed for the established joint guarantee. No new tolerance, data, kinetics, Lean, tamper check, GPU calculation or formal ledger was introduced. Only this report was written in this assignment.
