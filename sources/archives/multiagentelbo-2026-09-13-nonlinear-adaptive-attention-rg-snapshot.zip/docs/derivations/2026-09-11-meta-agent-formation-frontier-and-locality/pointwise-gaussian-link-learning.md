# Pointwise Gaussian link learning: complete flow and exact parent admission

September 11, 2026. This applies the [structural-learning conditional-memory result](pointwise-learning-parent-closure.md) to actual normalized Gaussian factors in the project. It derives the model Fisher metric, the complete coupled flow, a criterion for an exact conditional-matched parent, and a concrete failure of that criterion under an actual link update. All work is at one fixed base point c_*. The results below are analytical statements under their displayed assumptions, with one exact rational coefficient check. They are not a completed formation mechanism or a general impossibility result for meta-agents.

## 1. Source and model boundary

The source model is the normalized undirected alternative in [Theory/04_generative.tex](../../../Theory/04_generative.tex), section `sec:gen-undirected`, with the nonflat Gaussian residual action in [Theory/09_coarsegraining.tex](../../../Theory/09_coarsegraining.tex), equation `eq:cg-nonflat-series-action`. We use that action and its SPD admission; the degree-two restriction belongs to the source's series-elimination theorem and is not needed to normalize the action here. The normalized directed two-channel factors in [Theory/06a_generative_gaussian.tex](../../../Theory/06a_generative_gaussian.tex), equations `eq:gen-lg-model` through `eq:gen-lg-spd`, are another realization of the same assembled quadratic form. [Theory/06_gaussian.tex](../../../Theory/06_gaussian.tex) gives its information coordinates. No flat-frame substitution is made.

Fix the agents available at c_* and stack their belief and model sample coordinates as x in R^n, with their possibly different representation dimensions. Their law marginals are distinct from these sample coordinates. The associated bundles and common principal bundle supply the types. In fixed local frames, allow independent structural link parameters Theta_e^b and Theta_e^m. Their finite-dimensional chart is theta. This addresses structural learning of links, not a posterior over random links; the latter requires including links in the latent law and generally leaves the joint Gaussian family.

For this admitted Gaussian application, use zero prior offsets, fixed observation matrices and covariances, and a prior precision

\[
 J_0(\theta)=A+\sum_a R_a(\theta)^\top W_a R_a(\theta)\succ0,
 \qquad A\succeq0,\quad W_a\succ0.
 \tag{1}
\]

An edge residual is R_e x=x_i-rho_x(Theta_e)x_j in its own channel. Fixed model-to-belief residuals and the source's directed residuals can be included as additional rows. For example, a directed belief residual contains k_i-F_i^b rho_b(Theta_e^b)k_j-B_i m_i. W_a is the receiving precision. The SPD condition in (1) is the exact proper-law admission; positive anchors on all coordinates are sufficient, but are not necessary. Neither compactness of G nor zero graph holonomy is assumed. No integration over a Haar law on links occurs, because theta is a structural parameter.

Declare the actual normalized joint

\[
 p_\theta(o,x)=\mathcal N(x;0,J_0(\theta)^{-1})
                  \mathcal N(o;Hx,S),\qquad S\succ0.
 \tag{2}
\]

The second factor can stack all fixed Gaussian record kernels, including ones reading model coordinates. This is a specialization of the existing normalized construction, not an assertion that every agent model or every interaction record is Gaussian. The whole quadratic normalizer remains present. Its posterior and evidence are

\[
 K(\theta)=J_0(\theta)+H^\top S^{-1}H,\qquad
 h=H^\top S^{-1}o,\qquad
 \pi_\theta=\mathcal N(K^{-1}h,K^{-1}),
 \tag{3}
\]

\[
 \log e_\theta(o)=\tfrac12\log\det J_0-\tfrac12\log\det K
 -\tfrac12\log\det S-\tfrac{d_o}{2}\log(2\pi)
 -\tfrac12o^\top S^{-1}o+\tfrac12h^\top K^{-1}h.
 \tag{4}
\]

Completing the square in (2) proves (3)-(4); J_0 and K are SPD, so every integral is finite and the evidence is positive. Standard Gaussian conditioning, block inversion, and log-determinant differentiation are also recorded in Rasmussen and Williams, [Appendix A, equations A.4-A.6 and A.11-A.15](https://gaussianprocess.org/gpml/chapters/RWA.pdf), checked September 11. The following dynamic admission statements are derived here, not attributed to that appendix.

## 2. The structural metric and actual coupled update

Let recognition be the complete positive Gaussian q=N(mu,C), with J=C^{-1} and h_q=J mu. The exact objective is F=KL(q||pi_theta)-log e_theta(o). Adopt the full-law recognition Fisher flow used in the preceding derivation. Set J_a=partial_a J_0 and C_0=J_0^{-1}. Differentiating the normalized prior at fixed q gives the structural covector

\[
 g_a=\left.\partial_a\mathcal F\right|_q
 =\tfrac12\operatorname{tr}\left[(C+\mu\mu^\top-C_0)J_a\right].
 \tag{5}
\]

The subtraction of C_0 comes from the prior log determinant. Dropping it would change the actual link update. Formula (5) is equivalent to differentiating the KL and evidence together; an evidence term cannot be declared constant during structural learning.

Use the Fisher metric of the complete normalized generative joint (2) on theta. Because the observation kernel is theta-independent at fixed x, its structural score is the prior score. Centering the quadratic Gaussian score gives

\[
 M_{ab}(\theta)=\tfrac12\operatorname{tr}(C_0J_aC_0J_b).
 \tag{6}
\]

For completeness, a direction with A_v=sum_a v_a J_a has score one half of tr(C_0 A_v)-x^T A_v x. The Gaussian fourth-moment identity gives Var(x^T A_v x)=2 tr(C_0 A_v C_0 A_v), proving (6). Equivalently, whitening x reduces the variance to that of a sum of eigenvalues times independent centered squared standard normals. Thus v^T M v is one half the squared Frobenius norm of C_0^(1/2) A_v C_0^(1/2). M is positive definite exactly when theta -> J_0 is an immersion in the chosen identifiable chart. Redundant parameters must be removed or supplied with a separately declared metric; no inverse is asserted on a degenerate chart.

With this metric the coupled equations are

\[
 \dot J=K(\theta)-J,\qquad
 \dot h_q=h-h_q,\qquad
 \dot\theta=-M^{-1}g.
 \tag{7}
\]

The first two follow by equating coefficients in dot log q=-log(q/pi_theta)+E_q log(q/pi_theta). The Gaussian family is invariant because that centered field is quadratic. Its mean and covariance equations are

\[
 \dot\mu=C(h-K\mu),\qquad \dot C=C-CKC.
 \tag{8}
\]

On any finite interval on which theta remains in the admitted smooth chart, the integral solution J(t)=e^{-t}J(0)+integral_0^t e^{-(t-s)}K(theta(s))ds is SPD. This proves preservation of the recognition domain along such a structural trajectory; it does not prove global existence of theta or prevent escape to a degenerate model boundary.

The product of the recognition Fisher metric and (6) gives

\[
 \dot{\mathcal F}
 =-\operatorname{Var}_q\left(\log\frac{q}{\pi_\theta}\right)
   -g^\top M^{-1}g\le0.
 \tag{9}
\]

Here the variance notation means the ordinary variance without any additional geometric convention. The recognition Fisher metric alone has no block in an independently parameterized theta direction. Equation (9) concerns this declared product geometry and continuous flow. It is not a claim about an arbitrary finite optimizer step, a raw Lie-algebra gradient, a chosen physical clock, or block coalescence.

## 3. Finite conditional memory for a fixed candidate parent

Let y=F x have dimension r with 0<r<n, choose a fixed linear complement u, and write T x=(y,u). Transform every precision by T^{-top} J T^{-1} and every information vector by T^{-top}; all blocks below are in these split coordinates. This is a fixed candidate map, not adaptive membership or a moving link-dependent basis.

Write recognition as

\[
 q_y=\mathcal N(\bar\mu,V),\qquad
 q(u\mid y)=\mathcal N(b+B y,\Gamma^{-1}),\qquad
 b=\Gamma^{-1}a,\quad B=\Gamma^{-1}L.
 \tag{10}
\]

Its hidden natural data are Gamma=J_uu, a=h_{q,u}, and L=-J_uy. The target has Gamma_p=K_uu, a_p=h_u, and L_p=-K_uy. Thus the preceding abstract exponential-conditional memory has the finite matrix realization

\[
 \dot\Gamma=\Gamma_p-\Gamma,\qquad
 \dot a=a_p-a,\qquad
 \dot L=L_p-L.
 \tag{11}
\]

These coefficients suffice for all y simultaneously. They are not a separate table of parameters for each real-valued retained state.

Define b_p=Gamma_p^{-1}a_p, B_p=Gamma_p^{-1}L_p, delta b=b-b_p, and delta B=B-B_p. Direct Gaussian integration gives

\[
 d(y)=\mathrm{KL}(q(u\mid y)\Vert\pi_\theta(u\mid y))
      =d_0+c^\top y+\tfrac12y^\top D y,
 \quad D=\delta B^\top\Gamma_p\delta B,\quad
 c=\delta B^\top\Gamma_p\delta b,
 \tag{12}
\]

\[
 d_0=\tfrac12\left[
 \operatorname{tr}(\Gamma_p\Gamma^{-1})-(n-r)
 +\log\frac{\det\Gamma}{\det\Gamma_p}
 +\delta b^\top\Gamma_p\delta b\right].
 \tag{13}
\]

For retained natural coordinates J_y=V^{-1}, h_y=J_y bar mu and target marginal natural coordinates K_y,h_{p,y}, the exact induced E-flow is

\[
 \dot J_y=K_y-J_y+D,\qquad
 \dot h_y=h_{p,y}-h_y-c.
 \tag{14}
\]

This follows either by centering (12) in the marginal log-density equation or by differentiating the Schur complement of the full (7). The constant d_0 affects the fine VFE but cancels from the parent E-vector. Therefore a positive hidden KL by itself is not a failure of marginal autonomy; the centered quadratic field is the relevant object.

Equations (5)-(7), (11), and (14) close after reconstructing the fine moments. The reconstruction is exact: J_uy=-L, J_uu=Gamma, J_yy=J_y+L^T Gamma^{-1}L, h_{q,u}=a, and h_{q,y}=h_y-L^T Gamma^{-1}a. Consequently this augmented representation retains n(n+3)/2 recognition parameters, precisely the full Gaussian count. It is a concrete implementation formula for the complete model, not information compression.

## 4. Exact conditional-matched parents and recursive composition

There is a stronger regime that really can remove evolving hidden recognition parameters. Suppose on a structural parameter domain the posterior hidden conditional b_*(u|o,y) is independent of theta and recognition starts on the matched family

\[
 q(x)=r(y)b_*(u\mid o,y).
 \tag{15}
\]

Coordinate Jacobians are fixed and are included when expressing densities in (y,u). The hidden E-vector in (11) vanishes on this family, and target independence prevents structural learning from moving it away. The log ratio q/pi_theta depends only on y. Hence the full Fisher E-flow restricts exactly to the parent Fisher flow, and

\[
 \mathcal F(q,\theta)=\mathcal F_y(r,\theta).
 \tag{16}
\]

For the model (2), the same condition holds simultaneously for all observations whenever

\[
 [J_0(\theta)-J_0(\theta_*)]v=0
 \quad\text{for every }v\in\ker F\text{ and every admitted }\theta.
 \tag{17}
\]

To prove sufficiency, the difference precision has only a yy block in split coordinates, so K_uu and K_uy are constant in theta; h_u is already fixed by o. These are exactly all the natural coefficients of the posterior conditional. It also proves the factorization p_theta(o,x)=p_theta(o,y)b_*(u|o,y). Its structural score is therefore the retained-joint score. Integration over u proves equality of the complete and retained generative Fisher metrics, while differentiating (16) proves equality of their structural covectors. Thus the M-flow also closes with the same metric (6), not merely the E-flow.

Condition (17) is also necessary for theta-independent posterior conditionals in this fixed-observation-matrix, zero-prior-mean model. Equality of the positive Gaussian conditionals implies equality of their hidden precision and affine information coefficients for every y. Hence the uu and uy blocks of every precision difference vanish, which is (17). This statement concerns parameter-independent conditional recovery, not every conceivable dynamic quotient.

Condition (17) is invariant under a fixed passive frame re-expression. With x'=R x, transform J_0'=R^{-top}J_0 R^{-1} and F'=F R^{-1}. Then ker F'=R ker F and Delta J_0' R v=R^{-top}Delta J_0 v. Receiving weights and observation maps transform with their source-defined congruence and inverse laws. Thus the criterion concerns the represented law and retained map, not the arbitrary chosen chart. A frame choice changing with the inference index would require the coordinate-velocity term and is outside this fixed-map calculation.
The minimal dimension of a linear statistic with that family-wide property is explicit. Define

\[
 \mathcal N=\bigcap_\theta\ker[J_0(\theta)-J_0(\theta_*)],
 \qquad r_{\min}=n-\dim\mathcal N.
 \tag{18}
\]

Every admitted F has ker F contained in N, giving r>=r_min. Conversely choose ker F=N and any full-rank coordinate map onto its quotient; (17) holds. This proves (18) for linear statistics. There is no assertion of minimality among nonlinear statistics, task-specific predictive parents, or parents with conditional memory. Additional retained interfaces can only increase the required state.

For a smooth path-connected chart, the same N can be obtained by intersecting the kernels of every J_a(theta): differentiate (17) for one direction, and conversely integrate the zero derivative along piecewise smooth parameter paths. At a single current state, the weaker tangent requirement for staying on the matched family along an actual learning trajectory is

\[
 \dot K_{uu}=0,\qquad \dot K_{uy}=0,
 \qquad \dot h_u=0,
 \tag{19}
\]

where dot K=sum_a J_a dot theta_a in the fixed split. The last equation is automatic here. Invariance requires (19) along the matched trajectory, or tangency throughout the matching manifold under the usual smooth-ODE hypotheses. A zero value at one instant is insufficient. In particular, (17) is stronger than an actual-trajectory admission and must not be promoted into a requirement for every possible formation process.

If two nested fixed channels each have parameter-independent hidden conditionals, and recognition is matched to the deepest retained channel, their conditional factorizations compose by ordinary disintegration. The fine-to-intermediate and intermediate-to-coarse E/M flows then both satisfy (16), and their composition equals direct reduction. This is an exact finite recursive regime. Its conditions are the two factorizations and the matched initial recognition law; recursive marginalization alone would not prove dynamic closure.

On this regime the evolving recognition count can fall to r(r+3)/2 while theta remains. The fixed recovery kernel, the evaluator, observation interface, structural parameters, and any stored matrices still count as resources. Their evaluation can require fine-sized computation. Neither the count nor (16) establishes an endogenous selector, a faster implementation, an attractive matching manifold, or persistence of a dynamically chosen partition.

## 5. What freely learned full-matrix links imply for this regime

A sharp diagnostic is available inside the residual model. Assume a distinct edge e=(i,j), with no tied dependence through other residuals, has an independently variable represented GL(K) link and an SPD weight W. All matrix variations delta Theta are then admissible tangents. Its precision variation on the two endpoints is

\[
 \delta J_e=
 \begin{pmatrix}
 0&-W\delta\Theta\\
 -\delta\Theta^\top W&
 \delta\Theta^\top W\Theta+\Theta^\top W\delta\Theta
 \end{pmatrix}.
 \tag{20}
\]

If (v_i,v_j) is killed by every such variation, the first row gives W delta Theta v_j=0 for all delta Theta, hence v_j=0. The second row then gives delta Theta^T W v_i=0 for all delta Theta, hence v_i=0. Thus no coordinate at either endpoint belongs to the common invisible subspace (18). If such independently variable edges cover every vertex in a channel, that channel has no nonzero invisible linear direction. This applies separately to the two channels under those same variation hypotheses.

This establishes a scoped obstruction to family-wide linear sufficient reduction while retaining every such link as freely learnable. The statistical-family statement does not require M to be invertible; using the particular natural M-flow still requires its separate identifiability admission. It does not cover a general representation of G, tied or constrained learning directions, nonlinear statistics, a trajectory that remains in a smaller parameter subset, approximate coalescence, or a memory-augmented parent. In particular it is not an impossibility theorem for the user's mechanism. The diagnostic explains which learning dependence a proposed exact collective sector must neutralize; no identity-holonomy assumption or frame coboundary has been imposed.

## 6. Actual learning can leave the matched sector

Consider the source's two-node scalar directed subclass

\[
 x_1\sim\mathcal N(0,1),\qquad
 x_2\mid x_1\sim\mathcal N(\theta x_1,1),\qquad
 o\mid x_2\sim\mathcal N(x_2,1),\qquad \theta>0.
 \tag{21}
\]

The independent scalar link is a GL^+(1) coordinate. This is an analytic discriminator, not a replacement formation dataset. It can be embedded in the complete two-channel construction with an independent proper model channel; that embedding does not change the calculation. The prior and its derivative are

\[
 J_0=\begin{pmatrix}1+\theta^2&-\theta\\-\theta&1\end{pmatrix},
 \qquad J_\theta=\begin{pmatrix}2\theta&-1\\-1&0\end{pmatrix},
 \qquad \det J_0=1,\quad\det J_\theta=-1.
 \tag{22}
\]

The actual complete-joint Fisher metric is M=E[x_1^2]=1, also obtained from (6). In log-link coordinates lambda=log theta its value is theta^2. Therefore using dot theta=-g here is the model natural gradient in this particular chart, not a prescription for unpreconditioned Lie-algebra descent.

Take o=0, theta(0)=1/2, and q(0)=pi_{1/2}. Then

\[
 C(0)=\begin{pmatrix}8/9&2/9\\2/9&5/9\end{pmatrix},\qquad
 g(0)=2/9,\qquad \dot\theta(0)=-2/9.
 \tag{23}
\]

The E-vector initially vanishes, while the M-vector does not. This agrees independently with differentiating the evidence o~N(0,2+theta^2). Retain y=x_2 and discard u=x_1. The target hidden conditional has variance C_p=1/(1+theta^2) and regression B_p=theta/(1+theta^2). At the initial point,

\[
 C_p=4/5,\quad B_p=2/5,\quad
 \dot C_p=32/225,\quad\dot B_p=-8/75.
 \tag{24}
\]

Thus exact matching is not invariant under this actual learned-link update. Its conditional Fisher speed is

\[
 v_y^2=\frac{(\dot B_p y)^2}{C_p}
             +\tfrac12\left(\frac{\dot C_p}{C_p}\right)^2
       =\frac{16}{1125}y^2+\frac{32}{2025}.
 \tag{25}
\]

The preceding moving-target result gives d(y,t)=t^2 v_y^2/2+o(t^2). Consequently the difference between the induced retained variance velocity and the autonomous-parent Fisher velocity, evaluated at the same current retained law and current theta, is

\[
 \Delta\dot V(t)=-\frac{16}{3645}t^2+o(t^2).
 \tag{26}
\]

This compares vector fields at the same state; it is not a global comparison between separately trained trajectories. Conditional posterior matching in this example is not zero inter-agent transported KL; those are different matching conditions.

A second calculation derives (26) directly from the complete ODE, without inserting the conditional-KL formula. Since J'(0)=0, write J(t)=K_0+J_2 t^2+J_3 t^3+o(t^3). With v=dot theta(0), theta_2=-C_11(0)v/2, the coefficients satisfy J_2=J_theta v/2 and 3J_3=J_theta theta_2+J_thetatheta v^2/2-J_2. Expand V(t)=(J(t)^{-1})_22 and subtract V-V^2 K_y(theta(t)); K_y=(2+theta^2)/(1+theta^2). This gives the same coefficient -16/3645. The finite rational values of both routes are reproduced by [two_node_exact.py](evidence/pointwise-learning-gaussian/two_node_exact.py), with its [saved output](evidence/pointwise-learning-gaussian/two-node-exact-result.json). The script ran once under pinned CPython 3.14.7, serially, without torch, pytest, numerical integration, sampling, or fitting. Its exact arithmetic checks this instance; the general statements rely on the displayed proofs.

## 7. Direct test of the proposed alignment mechanism

Conditional matching in (15) must not be confused with inter-agent alignment. For one represented link T_ij=rho(Theta_ij), let the Gaussian marginal mismatch be D_ij=KL(N(mu_i,C_ii)||N(T_ij mu_j,T_ij C_jj T_ij^T)). At D_ij=0, define the mean and covariance velocity defects

\[
 v_\mu=\dot\mu_i-\dot T_{ij}\mu_j-T_{ij}\dot\mu_j,
 \qquad
 v_C=\dot C_{ii}-\dot T_{ij}C_{jj}T_{ij}^\top
 -T_{ij}\dot C_{jj}T_{ij}^\top
 -T_{ij}C_{jj}\dot T_{ij}^\top.
 \tag{27}
\]

These use the actual marginal blocks of (8) and the actual structural velocity in (7); the cross-covariances inside CKC are retained. Along a twice differentiable positive Gaussian trajectory starting at alignment, expansion of the Gaussian KL at equality gives

\[
 D_{ij}(t)=\tfrac12t^2v_\mu^\top C_{ii}^{-1}v_\mu
 +\tfrac14t^2\operatorname{tr}[(C_{ii}^{-1}v_C)^2]+o(t^2).
 \tag{28}
\]

One proof expands log det(I+t C_ii^{-1}v_C) to second order; normalization cancels the first-order trace and leaves the displayed covariance quadratic. The mean difference contributes its usual second-order quadratic. Each term is nonnegative, since C_ii^{-1}v_C is similar to a symmetric matrix. Vanishing of both defects throughout a smooth aligned manifold is the tangency condition for preserving alignment. Attraction to that manifold additionally requires an off-manifold stability argument. A scalar VFE descent identity supplies neither condition by itself.

The same normalized two-node model (21) gives an explicit test. Take o=0, theta=1 and q=N(0,I_2). The marginal laws of x_2 and theta x_1 agree exactly, so D_21=0. But (7)-(8) give

\[
 K=\begin{pmatrix}2&-1\\-1&2\end{pmatrix},\quad
 g=1,\quad\dot\theta=-1,\quad
 \dot C=\begin{pmatrix}-1&1\\1&-1\end{pmatrix}.
 \tag{29}
\]

The child variance velocity is -1, while the velocity of the transported parent variance theta^2 C_11 is -3. Thus v_C=2, v_mu=0, and D_21(t)=t^2+o(t^2). The full VFE nevertheless decreases: Var_q log(q/pi_theta)=tr((K-I_2)^2)/2=2, and g^2/M=1, so dot F=-3 at that point. This is a direct analytical matrix calculation, separate from the executed conditional-matching coefficient check above.

Consequently this admitted normalized Gaussian model with learned links does not preserve even exact marginal alignment under its chosen full-law E/model-Fisher M dynamics. It cannot be labeled an established realization of coalescence just because its VFE decreases. This counterexample does not rule out the proposed mechanism under other admitted factors or dynamics. It identifies the missing proof: the actual interaction-driven vector field must make the alignment set tangent and restoring, or quantify the mismatch it leaves. It also does not identify law alignment with identity holonomy.

## 8. Result and the next formation obligation

The abstract conditional closure is now admitted for an actual normalized link-dependent Gaussian class, with its own model Fisher metric and all evidence/normalizer terms. Its generic finite conditional-memory realization is exact but reconstructs the fine law. A parameter-independent conditional plus matched recognition supplies a stricter exact E/M parent and composes recursively under the stated conditions. The common-kernel criterion identifies exactly when a linear retained statistic can support that family-wide regime.

The remaining formation question is narrower and concrete: which existing normalized interaction factors and admitted update make the velocity defects (27) vanish on the proposed aligned sector and make deviations decay, while also preserving the parent conditional or controlling its memory? The first calculation is the actual alignment tangent and stability test, not another Gaussian family closure demonstration. Independent full-matrix link freedom alone does not supply such a sector. Neither (20) nor the two-node example rules out dynamic alignment on a smaller reachable family. Establishing attraction or a controlled finite-mismatch regime requires analyzing that actual direction and its coupling to the proposed alignment measure; a new base-transport construction is not part of this step.

The original fifteen heterogeneous admissions and their exact negative results are unchanged. No new spatial experiment, tolerance, resource penalty, model replacement for the saved experiment, manuscript edit, or full-RG completion is claimed.
