# Reconstruction of the selected-hierarchy response-cost frontier

September 12, 2026. The stated ideal-real operation schedule and sufficient expected-cost/accuracy region reconstruct under their declared workload assumptions. This report gives the arithmetic argument, including an analytical derivation of the saved map maxima, and checks the finite-depth, controller and transcript boundaries. No operation counter, earlier scientific calculation, trajectory, test suite or benchmark was rerun. No ledger state is assigned.

## 1. Source continuity and quantified target

The claims checked are in [the cost synthesis](selected-hierarchy-response-cost.md), [the cost law](selected-hierarchy-response-cost-law.md), and [the count report](selected-hierarchy-response-cost-calculation.md). Their mathematical inputs are [selected-hierarchy response](selected-hierarchy-response.md), [the response interface](selected-hierarchy-response-interface.md), Sections 7–8, [the response law](selected-hierarchy-response-law.md), Sections 5–7, and [its reconstruction](selected-hierarchy-response-reconstruction.md). The [native resource frontier](native-episode-resource-frontier.md), Sections 2–5, supplies the coupled generator and first-parent assembly allowance. [Common-prior native episodes](common-prior-native-hierarchy-episodes.md), Sections 4–7, supplies the actual all-ancestry panel and saved probability windows.

I reread live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, and the [operational wiki definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>). The manuscript requires a net organizational-cost comparison while leaving its proposed pairwise-KL replacement underived. The wiki requires the law, evaluator, access, marks and memory. The present resource proof addresses a declared implementation workload; it does not prove that manuscript replacement or identify resource charges with nats.

The supplied scientific domain is the existing four-cycle, two two-dimensional translation channels, all forty-five decorated ancestries, the unchanged native learner and likelihood, and the established nonempty relative-open family of fixed priors positive on all twelve ancestries. Fix any prior in a sufficiently small common such family, any preparation time t in [35,40], and either recognition or the current model posterior. The law and t stay fixed during the workload. Every preparation retains the actual initial ancestry H and uses its actual geometry. All J>=1 normalized monotone forest panels are sampled before response queries. Historical ports retain their stage, cut, orientation, original anchor and block-input domain; later one-block outputs do not erase them.

The added accounting assumptions, explicitly supplied by the cost law rather than consequences of the scientific model, are integers N,L>=1 and K>=0, finite depth J>=1, a relative-input radius R>=0, and finite nonnegative resource charges with one real-field-per-tick price c_w>0. A tick is accounting residence or a specified transmission operation, not native or physical time. Each preparation is frozen during its at-most-K adaptive anchored Bernoulli queries. Implemented controllers must have the charged finite bounds; an arbitrary measurable query policy need not have a finite-cost implementation. Expectations need the prescribed marginal preparation laws. Independence of preparations, controllers and answer randomness is additionally assumed only for the product-transcript statement below.

The target is a sufficient inequality for these specified fine and parent implementations, uniformly over the admitted structural branches and query choices. The fine side retains the full latent sample. The parent retains the complete sufficient statistic, current geometry and historical response vectors. Native density ratios and Fisher/negative-ELBO quantities agree exactly; anchored response transcript laws are compared approximately on their common advertised-information/query space. Equality of differently dimensioned geometric outputs in total variation, actual microscopic recovery, feedback dynamics and global algorithmic optimality are not the asserted equivalences.

## 2. Reconstructing the literal arithmetic count

For a scalar row y=sum_j a_j x_j, let n be its number of nonzero coefficients and v its number of coefficients different from both zero and +1. The declared direct evaluation costs v multiplications and max(n-1,0) additions. In particular a coefficient -1 costs a multiplication. Assignments and coefficient +1 are arithmetic-free, while their memory and control work are separately charged. Applying a row independently to r coordinate directions multiplies both counts by r. Exponentials, ideal uniforms and comparisons have their own primitive prices. This is exact accounting for this ideal-real program, not an arithmetic lower bound or finite-bit error analysis.

There is a direct cycle proof of the augmented-map maxima. Consider one panel acting on k current parents and producing q parents. Put s=k-q and let b be the number of nontrivial merger components. The forest has s selected edges. In a component with m>=2 current parents, its new mass-weighted mean contains m old means and m-1 tree-mark terms. Each mean coefficient is strictly between zero and one. Each tree-mark coefficient is a signed proper-subtree mass divided by the total component mass, hence is nonzero and has magnitude strictly below one. The mean row therefore costs 2m-1 multiplications and 2m-2 additions per coordinate. Singleton mean rows are assignments. Summing gives 2s+b multiplications and 2s additions.

Every retained nonforest mark has coefficient +1 on its own old mark. Along the directed quotient cycle, its additional tree-path terms also have coefficient +1. For a proper path component, edges before its root contribute to the incoming dressed cut and edges after its root to the outgoing dressed cut. Thus each selected edge occurs once across those retained-mark sums. For q=1 the sole loop contains all selected edges once. The retained-mark rows consequently cost zero multiplications and s additions per coordinate. This is where the cycle orientation matters; an unrelated directed graph need not have this count.

Each stored selected-edge response is d_f=z_B-z_A-V_f, whose row has one +1 and two -1 coefficients. It costs 2 multiplications and 2 additions per coordinate. Including these s rows, the complete augmented map has exactly

\[
M_{\rm map}=4(4s+b)=16s+4b,
\qquad A_{\rm map}=4(5s)=20s.
\tag{1}
\]

The factor four counts both coordinates of both channels. Since k<=4, s<=3 and b<=min(s,q), the componentwise maxima are 52 multiplications and 60 additions, attained for k=4,q=1,s=3,b=1. At s=0 both counts vanish. This derivation matches the saved literal maps and works for their actual positive masses, including unequal masses and later flattened forests. It does not charge the separately retained twelve sufficient fields as arithmetic, nor does it make their copying free memory traffic.

The saved attaining map at case 167 makes the calculation concrete. With scalar input ordered as four means followed by four cycle marks, its first row is

\[
(1/4,1/4,1/4,1/4,-3/4,-1/2,-1/4,0),
\]

followed by the loop row (0,0,0,0,1,1,1,1) and three selected d_f rows. These contribute respectively 7M+6A, 0M+3A, and 6M+6A per coordinate: 13M+15A, hence 52M+60A in four directions.

The one-panel decoder maximum also follows structurally. A selected old forest edge is already stored and costs no arithmetic to decode. If an old cut still crosses two new components with m_C and m_D current constituents, its decoder contains three geometric terms Z_D-Z_C-V_e and m_C+m_D-2 centered forest-response terms. All those centered coefficients are nonzero and have magnitude below one. There are m_C+m_D+1 nonzero coefficients, of which m_C+m_D differ from +1. Since m_C+m_D<=k<=4, its two-coordinate cost is at most 8M+8A. If an old cut instead becomes the sole nonforest loop at q=1, its residual is minus the new loop mark minus the signed path sum of the k-1 stored edge residuals. For the directed cycle these k coefficients are -1, giving 2k multiplications and 2(k-1) additions, at most 8M+6A. The initial k=1 branch has no eligible cut.

In saved case 163, edge 23 has decoder row

\[
(-1,1,-1,0,-1/3,-2/3).
\]

Its five nonzero coefficients and four nonunit coefficients give exactly 8M+8A for one two-dimensional channel. These attaining examples check the meaning of the maxima; the proof of the upper bounds is the preceding argument, and the saved count covers the entire finite catalog.

There are 16,20,8,1 decorations at k=1,2,3,4. Their panel counts are respectively 1,4,8,16 per decoration. Thus the saved 176 cases and 416 eligible old-cut rows satisfy

\[
16+20(4)+8(8)+16=176,
\qquad 20(4)(2)+8(8)(3)+16(4)=416.
\tag{2}
\]

No new catalog enumeration is needed for these identities.

## 3. Complete query, formation and finite-depth allowances

For one eligible channel, the query probability is clip[p_0+phi(d+h)-phi(d)] with phi(v)=exp(-||v|| squared/2). Here h is already the target-minus-source relative input. After decoding d, forming d+h costs 2 additions. The two squared norms cost 4 multiplications and 2 additions; scaling both by -1/2 costs 2 multiplications. Two exponentials follow. Explicitly negating the unshifted exponential costs 1 multiplication, then combining it with the anchor and shifted exponential costs 2 additions. Clipping costs 2 comparisons and assignments; a Bernoulli answer costs 1 uniform and 1 comparison. The remainder is therefore

\[
7M+6A+2\exp+U+3\mathrm{cmp}.
\tag{3}
\]

Adding the decoder bound yields 15M+14A+2exp+U+3cmp. If the query supplies the two endpoint vectors instead of h, their two-coordinate difference adds 2M+2A under the same -1 convention. A newly current cut directly uses d=z_B-z_A-V and costs at most 4M+4A for the selected channel, so the one-panel bound also covers it. Null responses still incur dispatch/validity costs even though they require no floating arithmetic or Bernoulli draw.

A panel uses both channels. For each of at most four cuts, d costs 8M+8A in four coordinates. Its two Gaussian probabilities cost 6M+2A+2exp; their product adds 1 multiplication. One uniform and one comparison draw the flag. The literal panel bound is 60M+40A+8exp+4U+4cmp. The older 28-multiplication panel allowance used direct subtraction instructions; it cannot be mixed with the current convention. By contrast, the inherited first-parent assembly source explicitly counts every nonzero coefficient other than +1, so its 52M+80A allowance already includes negative coefficients.

Summing that inherited first assembly, the present panel, and (1) gives conservative arithmetic cores

\[
\begin{aligned}
A_1&=164c_{\times}+180c_++8c_{\exp}+4c_U+4c_{\rm cmp}
       +c_{\rm case},\\
Q_1&=15c_{\times}+14c_++2c_{\exp}+c_U+3c_{\rm cmp}
       +c_{\rm query}.
\end{aligned}
\tag{4}
\]

These sum componentwise upper bounds; they do not assert one branch attains the whole sum. The remaining case/query charges must include the actual applicable routing, access, input conversion and controller work. Static preparation, coefficient storage, recurring metadata and scratch lifetimes are charged where they occur rather than assumed absent.

For J panels, each later current geometry is another rooted connected forest on this same cycle, with actual additive masses. The counted maps take current means and marks as inputs; they do not require freshly generated microscopic coordinates. Thus a stage allowance is 112M+100A plus the panel elementary operations. Earlier response records are copied and retained at their actual access/history cost. Initial first-parent assembly is paid once.

The exact backward decoder expresses every historical residual linearly in the final geometry and retained forest responses. Per coordinate there are 2k_J+(k_0-k_J)=k_0+k_J<=8 such fields. A compiled row therefore uses at most 8 multiplications and 7 additions per coordinate, even if every coefficient is nonunit. With two coordinates and (3), a constructive choice of finite-depth upper bounds is

\[
\begin{aligned}
\overline A_J&=(52+112J)c_{\times}+(80+100J)c_+
 +J(8c_{\exp}+4c_U+4c_{\rm cmp})+c_{\rm case}(J),\\
\overline Q_J&=23c_{\times}+20c_++2c_{\exp}+c_U+3c_{\rm cmp}
 +c_{\rm query}(J).
\end{aligned}
\tag{5}
\]

The original anchor is already retained separately. Compiling the row, storing its coefficients, identifying its stage and interpreting the port history remain priced work. Equation (5) is an analytical row-width bound, not an attained maximum or a new history enumeration. At most three proper merges occur, but every requested idle panel still consumes panel, record and control work. If J grows with residence length, these charges must keep that dependence. The finite geometric catalog does not bound all history memory or runtime independently of J.

## 4. Storage margin and expected-cost inequality

The existing interface carries k_0-k_J response four-vectors, because the number of selected forest edges telescopes. Its displayed field count and the branchwise saving against the fine output are

\[
n_J=12+4(k_0+k_J),\quad n_{\rm fine}=36+4k_0,
\quad n_{\rm fine}-n_J=24-4k_J\in[8,20].
\tag{6}
\]

At the retained O/P reference, k_1=2 exactly on P_split and otherwise k_1=1. The previously inspected saved late-window split-probability enclosures are strictly below one half under both laws. Hence Delta_1=24-4 E k_1=20-4Pr(P_split)>18 throughout [35,40]. The earlier response reconstruction proves its simultaneous continuation with the accuracy bound to a common nonempty full-positive-prior neighborhood. Further contractions satisfy k_J<=k_1 pointwise, so

\[
\Delta_J:=\mathbb E(n_{\rm fine}-n_J)\ge\Delta_1>18
\quad\text{for every finite }J\ge1.
\tag{7}
\]

No new J-dependent prior neighborhood is needed. This is an expectation; some individual branches save only eight fields. It is neither a high-probability memory result nor a statement about allocation headers, finite precision or shortest codes.

Use the same accepted residual-first proposal, available visible Gaussian reductions and native normalizer/moment algorithms on both sides. Common work cancels only when the actual charged operations and schedules agree. Giving the fine side its positive microscopic-completion and query costs for free is conservative when upper-bounding parent-minus-fine extras. A different response distribution does not make controller costs common merely because its source code is identical. A controller may branch or retain different transcripts after the first differing answer. Its actual extra work must be bounded, or its entire parent-side work charged while the fine side is granted zero.

Let B_0 be additional one-time setup, B_s additional shared static cost per tick, d an upper bound on additional recurring per-preparation cost per tick, A_J an extra formation allowance and Q_J an extra per-query allowance. Include every implemented overhead; (4)-(5) can supply their arithmetic parts. With N resident preparations, L ticks and at most K queries each, linearity of expectation gives

\[
\begin{aligned}
\mathbb E(C_{\rm fine}-C_{\rm parent})
&\ge NLc_w\Delta_J-B_0-LB_s-NA_J-NKQ_J-NLd\\
&>L\{N(18c_w-d)-B_s\}-B_0-N(A_J+KQ_J).
\end{aligned}
\tag{8}
\]

No independence of cost and panel branch or of different preparations is required for (8). A positive right side is a sufficient resource certificate. If charges depend on N,L,K,J, precision, R or the prepared law, those arguments stay in (8). In particular an overhead growing with L cannot be renamed fixed setup and amortized away.

Native Radon–Nikodym evaluation and moment sufficiency are the specified available tasks. Retaining a normalized correlated reverse conditional proves an exact mathematical recovery statement but does not implement conditional microscopic sampling. Such sampling, an absolute-density oracle, a new filter or physical state updates need a concrete available algorithm and charges before entering this workload. Naming an unavailable oracle inside B_0 does not establish its finiteness. Native negative-ELBO or evidence gains along learning are shared with the fine implementation and cannot be credited again as formation savings.

## 5. Joint accuracy, integer feasibility and query-rate obstruction

Write c_R=min(R,2exp(-1/2)) and eta=0.494Kc_R. The prior response proof gives a one-preparation transcript bound beta=min(1,eta), on the same late window and prior family as (7). The transcript includes common preparation information, adaptive cut/input choices and answers. Neither L accounting ticks nor idle panel depth multiply this bound; the source's finite-catalog majorant covers every finite admitted J.

If N complete preparation/controller/answer experiments are independent, independently combine their fine/parent couplings. Each component coupling disagrees with probability at most beta, so the probability of at least one disagreement is at most 1-(1-beta)^N<=N beta. Therefore

\[
\operatorname{TV}_{\rm batch}\le\min(1,N\beta)
\le\min(1,0.494NKc_R).
\tag{9}
\]

Within each preparation the policy may be adaptive. Equation (9) is not invoked for arbitrary correlated preparations or a controller using multiple preparations without an additional joint conditional coupling argument. The cost expectation in (8) still does not require product laws. A per-draw guarantee is not automatically the same guarantee for the whole independent batch.

Let epsilon in (0,1) be a symbolic target, with m=1 for per-draw accuracy and m=N for the linear product-batch certificate. The sufficient joint region is

\[
L\{N(18c_w-d)-B_s\}>B_0+N(A_J+KQ_J),
\qquad 0.494mKc_R\le\epsilon.
\tag{10}
\]

For constant charges over the varied N,L and fixed J,K, put a=18c_w-d. If a>0, the least positive integer making the resource slope positive is

\[
N_{\min}=\max\{1,\lfloor B_s/a\rfloor+1\}.
\]

For any N>=N_min, every integer

\[
L>\frac{B_0+N(A_J+KQ_J)}{Na-B_s}
\tag{11}
\]

satisfies the resource part. Thus a fixed per-draw accuracy certificate that already holds has a nonempty compatible retention region. Increasing N or L cannot repair an accuracy condition that fails at a fixed K,R.

For the batch condition with eta>0, N is also bounded above by N_max=floor(epsilon/eta). Existence under these conservative inequalities is exactly N_min<=N_max, followed by an integer L satisfying (11). If eta=0, accuracy gives no upper bound on N. The sharper product expression in (9) could enlarge the region; N_max is exact for the chosen linear certificate, not for actual error. When R is itself free, any finite N,K>0 admit some strictly positive R satisfying the accuracy inequality, and then finite L from (11). That proves parametric nonemptiness without changing an externally fixed radius or adopting any tolerance.

For a fixed query rate rho>0, take K=ceil(rho L). The inequality K<=rho L+1 gives the sufficient cost condition

\[
L D_\rho>B_0+N(A_J+Q_J),
\qquad D_\rho=N(a-\rho Q_J)-B_s.
\tag{12}
\]

If D_rho<=0, increasing L cannot satisfy this certificate with the nonnegative right side. If R>0 and m is fixed, accuracy also requires

\[
K\le K_{\max}=\left\lfloor\frac{\epsilon}{0.494m c_R}\right\rfloor,
\qquad L\le\left\lfloor\frac{K_{\max}}{\rho}\right\rfloor.
\tag{13}
\]

For D_rho>0, compatible positive integer L must exceed the threshold in (12) and stay below (13); equivalently its least permitted integer must not exceed that ceiling. The interval may be empty. Thus fixed query density reduces the recurring resource slope and imposes an accuracy horizon. Neither obstruction is a lower bound on actual error or a proof that every implementation loses. If R=0 the response cap vanishes, but query/controller costs remain. J and L are different variables; setting J to grow with L requires substituting its actual costs before this constant-charge argument.

An optional cache of s extra resident fields replaces a by (18-s)c_w-d, adds its filling cost to A_J, and replaces Q_J by its actual cached bound. For example, caching phi(d) leaves 4M+5A+exp+U+3cmp after decoding, giving 12M+13A for the one-panel decoder, but a full first-cut/channel cache stores 2k fields when k>1. Historical-stage caches may store more. They cannot take this query saving while retaining the uncached storage margin. Temporary scratch is charged for its actual lifetime rather than automatically for all L ticks.

## 6. Selection boundary, evidence binding and outcome

The forced-P countercomparison has the claimed restricted scope. On a P_split preparation, an extra deterministic merger can retain S, the root geometry, one selected response four-vector and the original historical ports in 24 fields instead of 28. The forest decoder preserves those anchored queries exactly. Keeping any nominal panel record and paying the extra construction/access work gives an additional expected displayed saving 4Pr(P_split)>0. This does not preserve the same current membership or separate old means. It illustrates why a historical-response task and a storage price alone need not select an intermediate geometry; it is not an optimum proof for the full original access contract.

More generally, if the allowed fine algorithm class may emit exactly this sufficient carrier, it contains the parent algorithm. Its infimum cost is then at most the cost of that parent algorithm. The present strict comparison is between two specified retained representations and workloads. It supplies neither universal parent superiority nor an independently derived RAM-to-nats conversion or physical persistence mechanism.

I read [cost_maps.py](evidence/selected-hierarchy-response-cost/cost_maps.py), the saved [cost-maps.json](evidence/selected-hierarchy-response-cost/cost-maps.json), the completed calculation/law reports, the earlier map rows at the attaining cases, and the source cost convention. The counting code parses exact Fraction coefficients, applies the row formula to all 176 maps and 416 decoders, checks their geometry prefixes and selected-row increments, and aggregates componentwise maxima. It records one run under pinned CPython 3.14.7 with `-I -B`, status `PASS_EXACT_RESPONSE_OPERATION_COUNTS`, and elapsed time 0.014742200000910088 seconds. That was the investigator's run; I did not rerun it. The deeper bound (5), cost expectations and coupling statements are written proofs, not results of that finite count.

The final inspected artifacts are bound by lowercase SHA-256:

| Artifact | SHA-256 |
| --- | --- |
| selected-hierarchy-response-cost.md | `6e69abbc030b6d83c79c515b72abdbdf332de42fed5cb8e156cce4d11594e196` |
| selected-hierarchy-response-cost-law.md | `f690cd58229da963ff04c86527550ac61664975d91d3ecd068c73fe7e2eed8df` |
| selected-hierarchy-response-cost-calculation.md | `b2d11a5c0d90015bc810d6b237a1ee0da37917d43e6e8e79a3e43d9908c20044` |
| evidence/selected-hierarchy-response-cost/cost_maps.py | `97bb402b73805557636fbe2cbd08b92df71ab76018617807044b720122c28a3f` |
| evidence/selected-hierarchy-response-cost/cost-maps.json | `e09df074f0a3473f6cd8216fc8cba02214638e153aec298c992f4f407a04fb78` |

Read-only hashes matched all eight sources recorded by cost-maps.json: selected response maps `22bb9a9fa67adb7be128868718d79f47cf393fc619359f3b976191cd5c0131c9`, earlier panel geometry `697820da3c45dd3e21159fbf0b0a570566f74e2f68531fc5f9f93043c62705ce`, their respective producers `11e62c661cd05b8bbe99a9534e862eea607fe86dd23c0db1f83d07801023b397` and `a3a2a94b9fd4e989582463064c574ec67e7d9a1d357e8f252761540080a55ca6`, the response interface `175f445278f66e6bca509060bcbe2b213bad2d67ad18b47b1f19100268bd39c5`, response synthesis `d22ac38301b41500830bbea4b96730a50f7d362113277d54d39e28994b63ad50`, common-prior episodes `07dc59d83d9645f6b6b2553b0f7ae69e98d706e84413331698aa459e1bde1551`, and native resource frontier `3a03e9edf025711d07b9c0cc98683a5f8b5fa17084a8228cced856d2d47ea208`. The first-parent assembly allowance and native window remain inherited scientific evidence, explicitly distinguished from the new count. These inspections neither execute a producer nor alter any evidence.

I found no defect in the finalized claims under their stated hypotheses. The proof would fail for an omitted retained port or field, an uncharged negative coefficient under the literal convention, hidden workload dependence, a noncommon controller/evaluator cost declared canceled, or a product-transcript assertion without its independence or replacement coupling hypothesis. Those are falsifiers of the accounting or proof assumptions, not effects demonstrated in the finalized artifacts. Violating a sufficient frontier inequality only makes that certificate unavailable.

The strongest supported result is the concrete one-panel cores (4), finite-depth allowances (5), and compatible expected-cost/accuracy region (10)-(13) on the admitted late native family. The remaining operational obligation is to specify the required access and loss criterion, prices and complete implemented workload, then evaluate this region. No new trajectory, tighter scientific coefficient or benchmark is required to prove the stated conditional result. Only this assigned reconstruction file was written; no other report, source, configuration, vault file, scientific output or ledger was changed, and no old science, new count, suite, ODE, GPU, Lean or tamper check was run.
