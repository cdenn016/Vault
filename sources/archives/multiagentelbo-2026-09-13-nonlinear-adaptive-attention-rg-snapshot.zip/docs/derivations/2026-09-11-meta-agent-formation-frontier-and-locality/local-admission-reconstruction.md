# Independent local-admission reconstruction

This finite proof was derived independently of a coordinator candidate proof. It uses the frozen four-site reset at source revision ed8f22a56df353b1535744509cc23fae46d5813c: edges (12,13,14,23,24,34) have weights (1/16,1/12,1/10,1/8,1/7,1/6), the site is selected uniformly, its reset mean is a+sum_j J_ij y_j, actions are a=±1/5, and the destination record has mean eta times parity with eta=3/4. There is no initial informative record. No code was rerun, no observations collected, and no production file changed in this lane.

## Exact proper-block obstruction

Fix any nonempty proper subset A of the four sites and retain its whole exterior E. Suppose h:Y_A -> S is exterior independent and satisfies the complete emitted-row closure equation for every source, action, next exterior, next local class, and record. Equality of these rows implies equality of every next-exterior marginal. For an exterior site j,

\[
\mathbb E[Y'_j|u,x,a]=\frac34x_j+\frac14\left(a+\sum_{i\in E}J_{ji}x_i+\sum_{i\in A}J_{ji}u_i\right).
\]

The factor 3/4 accounts for the events resetting another site. Thus h(u)=h(v) implies sum_{i in A}J_ji u_i=sum_{i in A}J_ji v_i for every exterior j and every fixed x,a. It suffices to prove injectivity for one such j.

In fact every site j works. The three nonzero entries in its coupling row, expressed with a common denominator, are

\[
(15,20,24)/240,\quad (7,14,16)/112,\quad (2,3,4)/24,\quad (21,30,35)/210.
\]

Their eight unsigned subset sums are respectively

\[
\{0,15,20,24,35,39,44,59\},\quad
\{0,7,14,16,21,23,30,37\},
\]
\[
\{0,2,3,4,5,6,7,9\},\quad
\{0,21,30,35,51,56,65,86\}.
\]

Every displayed set has eight distinct elements. A signed spin sum is twice the sum of its positive-spin entries minus the total row sum. Hence all eight signed sums are distinct. Restricting to A preserves injectivity: fix the missing entries and apply the full-row result. Since A is proper, an exterior j exists, and h(u)=h(v) therefore forces u=v. This proves that every exact strong local quotient is injective. The complete local-plus-exterior parent retains 2^|A| times 2^|E|=16 states.

This is an all-source, full-exterior conclusion. It does not establish an obstruction for a changed sensor, weaker exterior retention, selected stationary preparation, or approximate criterion. None of those changes is part of this calculation.

## Whole-system record separation in at most two events

Write P(y)=product_i y_i, M(y)=sum_i y_i, S=sum_{i<j}J_ij, d_i=sum_j J_ij, and D(y)=sum_i d_i y_i. The degree vector and total are

\[
(d_1,d_2,d_3,d_4)=(413,555,630,688)/1680,\quad S=381/560.
\]

The established exact first-record mean is

\[
m_a(y)=\frac{\eta P(y)}4\left(a M(y)+2\sum_{i<j}J_{ij}y_i y_j\right).
\]

Equality for both a=±1/5 implies equality of P M and of P C, where C=sum_{i<j}J_ij y_i y_j. The five magnetization levels M=-4,-2,0,2,4 have respective P M values -4,2,0,-2,4, so different levels separate. Within M=±2, each configuration is specified by its exceptional site r, and C=S-2d_r. The four distinct degrees separate the four configurations at each such level. The levels M=±4 each contain one state.

At M=0, P=1 and the three complementary pairs are represented by positive-spin sets {1,2}, {1,3}, {1,4}. Their within-sign matching sums are

\[
W_{12|34}=11/48,\quad W_{13|24}=19/84,\quad W_{14|23}=9/40.
\]

They are distinct; C=2W-S separates the three pairs. Complementation leaves C unchanged, so exactly these three pairs remain inseparable after one record. The first-record experiment therefore has 13 preparation classes.

For the second event define T_a f(y)=E[f(Y_1)|Y_0=y,a]. For a spin character chi_B=product_{i in B}y_i, conditioning on the chosen reset site gives the exact operator formula

\[
T_a\chi_B=(1-|B|/4)\chi_B+\frac14\sum_{i\in B}\left(a\chi_{B\setminus\{i\}}+\sum_jJ_{ij}\chi_{(B\setminus\{i\})\mathbin\triangle\{j\}}\right).
\]

Let S_3=sum_{|B|=3}chi_B=P M and L_2=2sum_{i<j}J_ij chi_{V\setminus\{i,j\}}. Then T_b P=(b S_3+L_2)/4. Write Odd(f)(y)=(f(y)-f(-y))/2. Grouping the character terms in the preceding operator formula yields

\[
\operatorname{Odd}(T_aS_3)
=\frac14S_3+\frac14\left[2\sum_k(S-d_k)y_k+\sum_i d_i P y_i\right],
\]
\[
\operatorname{Odd}(T_aL_2)=\frac a2\sum_k(S-d_k)y_k.
\]

For the first formula, a term where the reset neighbor is another site of the original triple becomes a singleton; every edge among the other three contributes twice to the singleton coefficient. A neighbor outside the triple produces another triple, whose coefficient is the degree of its missing site. This accounts for all three-spin and one-spin terms. For the second formula, only the a terms are odd; each complement pair contributes the sum of its two singleton characters.

On a balanced state M=0 and P=1, these formulas reduce to -D(y)/4 and -a D(y)/2. Consequently, for the open-loop word with first field a and second field b,

\[
\operatorname{Odd}(T_aT_bP)(y)=-\frac{b+2a}{16}D(y),
\]
\[
\mathbb E[E_2|y;a,b]-\mathbb E[E_2|-y;a,b]
=-\frac{\eta(b+2a)}8D(y).
\]

For the three representatives with positive sites 12,13,14 respectively,

\[
D(y)=-5/24,\quad -5/42,\quad -1/20.
\]

Choose the admitted fixed word a=b=1/5. The corresponding second-record mean differences are 3/256, 3/448, and 9/3200. Since a binary ±1 law has TV equal to half its mean difference, the second-record marginal TV values are

\[
3/512,\quad 3/896,\quad 9/6400.
\]

They are all positive. Marginal distinction implies distinction of the joint two-record law. Thus every pair among the sixteen preparations is separated by an admitted open-loop record experiment of horizon at most two. The argument uses neither observation of the reset site nor observation of a hidden destination state.

## Consequence for arbitrary normalized memory predictors

Suppose a predictor has any normalized latent-memory mechanism and initial memory distribution depending only on the deterministic retained value h(y). Fix its model and a common open-loop action word. If h(y)=h(v), its entire initialized law is identical for the two preparations. By repeated use of the same normalized kernels its predicted record law is identical at every finite horizon, regardless of the amount of memory or the use of past records. Exact matching to both true preparation laws is therefore impossible whenever a separating experiment above exists. The preceding separation theorem forces h to be injective if all sixteen preparations and all admitted open-loop words must be matched exactly. Arbitrary memory added after a lost initialization cannot repair that loss.

This proves a cardinality lower bound of sixteen for deterministic retained preparation labels under that exactness contract. It does not prove minimality among arbitrary stochastic encodings y -> distribution on a smaller latent carrier, nor a general lower bound on parameter count or approximate prediction error. It does not establish that a partially observed filter needs sixteen distinct realized values: a filter is itself a probability-valued state.

## Bounded implementation inspection

After deriving the formulas, the adapter and trace code in `evidence/local-admission/run_admission.py` and the saved `admission.csv` were inspected without execution. `assemble` inserts local and exterior coordinates in fixed site order. Adapter actions are source action ordinals paired with the complete source exterior; their string representations are unique API labels. Records have a separate START tag and STEP tuples carrying the actual ±1 record value and complete next exterior, then are encoded as integer ordinals. Destination-major flattening uses the adapter record width, while extraction from the original kernel converts the ±1 record to its actual original ordinal. Thus action codes are not silently interpreted as physical field values, and record values are not confused with ordinal indices.

The initial sensor is delta_START for every local state/action; all emitted START entries are zero. No informative time-zero observation is added. One map on the local carrier is refined across every exterior action, so the algorithm does not choose different partitions at different source exteriors. The reconstructed global fibers are explicitly checked against local fibers times one fixed exterior. The trace starts from the constant partition and retains old labels in each refinement key, preventing merges after a split. It aggregates the joint next-class/record rows and retains a differing atom for every newly separated pair. It compares final labels and class-count traces to the existing coarsest-partition routine and compares aggregated rows and initial sensors to the quotient.

The saved table reports identity local maps for all fifteen subsets: traces 1;2, 1;4, and 1;8 for proper subsets and 1;13;16 for the whole system. Those values agree with the independently proved separation mechanism: next-exterior marginals distinguish proper-block sources immediately, while the whole-system first-record experiment has exactly 13 classes. This inspection is not a second execution or certification of every serialized atom. The proof above supplies the finite no-compression conclusion independently of numerical agreement.

## Final candidate comparison

After the independent derivation was recorded, `local-admission.md` was inspected. Its proper-block subset-sum argument, thirteen first-response signatures, three complementary-pair second-response distinctions, and exact constants agree with the explicit proofs above. Its next-exterior TV conversion is also correct: a signal difference Delta changes the next-spin mean by Delta/4, and hence the binary marginal TV by |Delta|/8.

For its complete-parent claim, an injective local map together with the unchanged exterior gives a bijection G_A onto its parent carrier. At any positive parent fiber the fine conditional law is the same singleton mass for the posterior and recognition. Thus their conditional KL is zero, and the common-push VFE identity has zero discarded term under the stated support and finiteness assumptions. Applying the same bijection coordinatewise to a latent path has the same property, provided every additional latent coordinate in the declared augmented object is also retained. This is a bijective reexpression result, not a fitted-model VFE claim.

For disjoint blocks, the tuple of their injective maps is injective on the full product carrier. A subsequent deterministic compression would compose to a noninjective preparation map on the original sixteen states. If it preserved the same all-preparation record experiment, this would contradict the two-event separation theorem. Therefore the candidate's negative exact two-level conclusion is valid within its stated deterministic preparation and same-experiment class. Stochastic initial encodings, approximate prediction, and changing the sensor remain outside that conclusion.

One wording correction was sent to the coordinator: the statement that a record-only observer “still needs a fifteen-coordinate filter” should read that the full categorical filter is represented by fifteen simplex coordinates. The theorem proves the number of deterministic retained preparation labels; it does not prove minimal dimension of every predictive or filtering realization. Apart from that dimension wording, the scoped mathematical comparison is complete. The additional execution certificates referenced by the candidate were not rerun in this lane.
