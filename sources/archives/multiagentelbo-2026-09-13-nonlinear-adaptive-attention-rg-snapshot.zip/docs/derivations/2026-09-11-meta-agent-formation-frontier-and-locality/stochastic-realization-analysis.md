# Stochastic initialization and exact local-parent realization

September 11, 2026. The saved heterogeneous experiment admits no exact reduction of a proper child block by a finite stochastic initialization followed by a common normalized predictor, provided all deterministic preparations and the original record experiment through horizon four must be preserved. Globally, the available result is different: the linear predictive rank is fifteen, while the minimum positive finite-state realization remains between fifteen and sixteen. No positive fifteen-state construction is claimed.

## Source, evidence and exact quantifiers

This continuation reads `local-admission.md`, `local-admission-reconstruction.md`, the live implementation `src/multiagent_elbo/rg_v2/finite_data_formation.py:40-69`, and `docs/reports/data/2026-09-11-finite-data-formation/results.json`. The saved configuration is the original four-spin reset with couplings `(1/16,1/12,1/10,1/8,1/7,1/6)` on edges `(12,13,14,23,24,34)`, actions `a=+-1/5`, destination-parity sensor strength `eta=3/4`, and saved horizon four. No couplings, sensor, initial observation or protocol are changed. The implementation's fair `initial_sensor` is not observed by the saved episode sampler; there is no informative record before the first reset.

The Research wiki pages `Coarse Graining` and `Statistical Experiment Comparison and Deficiency` were consulted for the distinction between preserving one law, preserving a statistical experiment by a common channel, and preserving a selected tangent. The current investigation resumes the stochastic-initialization gap explicitly left open in the two admission notes. Their pairwise separation theorem concerns deterministic labels and does not itself imply a stochastic lower bound.

The root's newly executed exact certificate is [observable-rank.json](evidence/local-admission/observable-rank.json), SHA-256 `1563a62d49adfa907aa12cbfeec0563e774a45dc4adec549272108c567b79db2`. It is bound to revision `ed8f22a56df353b1535744509cc23fae46d5813c`, the saved input hashes, pinned CPython 3.14.7, and exact `fractions.Fraction` arithmetic. The inspected live implementation hash is `97554c5d23af8b03569c4fe6ea51756c01bafc35e649e22debbdb5185e153238`, matching the certificate. The certificate reports ranks `1,3,9,14,15` through horizons `0,1,2,3,4`, respectively, for all 341 words including the empty word; it retains fifteen original independent word-probability columns and exact elimination data. It also records 64 emitted-matrix left-null checks, sixty span-invariance checks, and rank fifteen after removal of each individual preparation row. This lane read those results and derives their implications; it did not rerun them or independently certify the serialized minor. The independent lower-bound reconstruction is the remaining mechanical/evidence check owned by the root.

**Target.** Let an initial encoder map every deterministic fine preparation `y` to one probability distribution on a fixed finite parent alphabet with `K` states. After initialization, require one normalized predictor, independent of the preparation except through that initialized state, to reproduce the original record laws for every common admitted open-loop action word. A predictor may use its internal randomness and full observed record/action history. Any additional preparation-dependent memory is part of the initialized carrier and must be counted. A common policy may depend on time and past actions/records; it may not read discarded fine coordinates. The local version fixes an exterior preparation and varies every child-block preparation. The theorem is about exact finite sample-state cardinality, not arbitrary nonlinear parameter dimension, approximate prediction, or preparation-averaged performance.

| Symbol | Type and convention |
| --- | --- |
| `Y` | `{-1,+1}^4`, ordered as in the saved source, with sixteen deterministic preparations. |
| `a,e` | Field action `a in {-1/5,+1/5}` and recorded parity sign `e in {-1,+1}`. |
| `T_a` | Row-stochastic hidden reset matrix, source row and destination column. |
| `K_(a,e)` | Substochastic emitted matrix with entries `P(Y'=y',E=e|Y=y,a)`. |
| `t_w` | Column of record-word probabilities under the action sequence in `w`; `t_empty=1`. |
| `F_H` | Matrix with sixteen source rows and every test column `t_w` of length at most `H`. |
| `E` | Row-stochastic initial encoder, sixteen rows and `K` columns. |
| `B_H` | Conditional test probabilities given each initialized parent state, for the common predictor. |
| Context/gauge | One fixed context and unchanged structural data; passive finite relabelings permute rows/columns and preserve all rank and factorization assertions. No physical symmetry or new principal bundle is inferred. |

## S1. The structural invisible signed direction is exactly parity

Define the signed column `v(y)=P(y)=y_1y_2y_3y_4`. For a selected reset site `i`, the source transition probability depends on `y_-i` and the newly sampled destination spin, but not on the old value `y_i`. Thus, for each fixed destination, summing the signed source mass over the two old values gives

\[
 \sum_{y_i=-1,+1}P(y)T_{a,i}(y,y')
 =\left(\prod_{j\ne i}y_j\right)T_{a,i}(y,y')\sum_{y_i=-1,+1}y_i=0,
\]

where the common transition factor is understood on the fixed `y_-i` source fiber and is zero unless the unchanged destination coordinates match. Summing over those fibers proves `v^T T_(a,i)=0`; averaging uniformly over sites proves

\[
 v^{\top}T_a=0. \tag{1}
\]

This uses the exact no-self-coupling reset in the source, not numerical rank. With the destination sensor

\[
 b_e(y')=(1+\eta eP(y'))/2,\qquad
 K_{a,e}=T_a\operatorname{diag}(b_e),
\]

we obtain

\[
 v^{\top}K_{a,e}=0 \quad\hbox{for every admitted }a,e. \tag{2}
\]

Also `v^T 1=0`, because each parity class has eight configurations. Every nonempty test column is `t_w=K_(a1,e1)...K_(ah,eh)1`; its first matrix is annihilated in (2). Therefore

\[
 v^{\top}F_H=0\quad\hbox{for every horizon }H,\qquad
 \operatorname{rank}F_H\le15. \tag{3}
\]

The uniform law on even-parity preparations and the uniform law on odd-parity preparations consequently give the same entire future record experiment. This is a signed-mixture relation; it does not say any two point preparations have the same response. It is consistent with the existing horizon-two pairwise separation theorem.

The observed rank fifteen at horizon four supplies the complementary lower bound. Since a sixteen-by-anything matrix of rank fifteen has a one-dimensional left kernel, (3) implies

\[
 \ker(F_4^{\top})=\operatorname{span}\{v\}. \tag{4}
\]

The all-horizon observable span is therefore exactly the fifteen-dimensional hyperplane orthogonal to `v`: horizon four already spans that hyperplane, and (3) excludes growth afterward. This conclusion uses the executed rank result only for the lower bound; the upper bound is the direct reset calculation above.

Equality under all open-loop words also implies equality under every common record/action-history policy. For a realized action-record path, its mass under a policy is its open-loop record mass multiplied by the common product of policy action probabilities on that path's prefixes. Sum over paths to obtain policy equality. No policy may depend on the unknown preparation except through the common retained history. An informative initial parity measurement would invalidate (3), but it is not part of this experiment.

## S2. The matrix-factorization bound applies to stochastic initialization

Condition on the initialized parent state `z`. For each finite test, the law of total probability gives

\[
 F_H(y,w)=\sum_{z=1}^K E(y,z)B_H(z,w),\qquad F_H=E B_H. \tag{5}
\]

The encoder `E` must be common across tests and row-stochastic; the decoder rows contain nonnegative probabilities of tests from one common normalized causal predictor. The empty column of `B_H` is one. The factors do not depend on `y` after conditioning on `z`. Consequently

\[
 K\ge\operatorname{rank}F_H. \tag{6}
\]

This elementary rank inequality needs no Markov assumption about the predictor after initialization. Unbounded observed-history dependence, private randomness, and arbitrary memory sampled from a law depending only on `z` remain inside `B_H`. If some extra memory is initialized from `y` independently of `z`, (5) is no longer the claimed factorization; include that memory in the initial carrier before applying (6). The same caution applies to an uncounted preparation-dependent continuous interface.

Since both factors in (5) are nonnegative, the nonnegative rank of the finite matrix is another lower bound. But an arbitrary nonnegative factorization is not automatically a normalized causal factorization: probability normalization within each action context, consistency under record marginalization, and one common policy-compatible mechanism still have to hold. A homogeneous finite Markov realization imposes further transition consistency. Thus ordinary predictive rank, nonnegative rank, and positive Markov realization size are different quantities.

## S3. Every proper child block still needs all its local states

**Theorem.** Conditional on the rank-fifteen certificate, let `A` be any nonempty proper subset of the four sites, and fix any exterior preparation `x in {-1,+1}^{V\A}`. Every stochastic initialization on a finite carrier followed by one normalized predictor preserving all original record laws through horizon four, for all local point preparations and common policies, requires at least `2^|A|` initialized states. The predictor and encoder may even depend on the fixed exterior `x`; the bound still holds.

**Proof.** Let `S_x={(u,x):u in {-1,+1}^A}`. It is a proper subset of the sixteen source preparations. Suppose its rows in `F_4` have a linear dependence. Extend its coefficient vector by zero on the missing source preparations. The resulting vector belongs to the left kernel of `F_4`, hence equals `alpha v` by (4). At least one coordinate was set to zero, while every coordinate of `v` is `+1` or `-1`; therefore `alpha=0`. Thus all `2^|A|` rows are linearly independent.

The local stochastic encoder and predictor give the restricted factorization

\[
 F_4|_{S_x}=E_xB_x,
 \qquad \operatorname{rank}(F_4|_{S_x})=2^{|A|}\le K_A. \tag{7}
\]

This proves the bound. It uses only the original record experiment, not observation of the next exterior or the stronger complete emitted-row closure contract. Requiring that stronger interface cannot weaken it. This is a stochastic-initialization strengthening of the existing deterministic local obstruction, under the explicit rank evidence above. \(\square\)

Singletons therefore require at least two states, pairs at least four, and triples at least eight. If the entire exterior remains a random retained interface, the complete carrier has at least `2^|A| 2^|V\A|=16` local-plus-exterior states. Allowing different local carrier sizes at different exterior values gives the same lower bound after summing over the disjoint exterior fibers. No local reduction has been hidden in preparation-dependent memory or interface data.

The proof is stronger than injectivity of a deterministic map: a simplex of `K_A` stochastic initialization laws cannot linearly generate these `2^|A|` independent response rows when `K_A<2^|A|`. It does not constrain every nonlinear continuous representation by the same integer cardinality bound.

## S4. The global fifteen-versus-sixteen limit

For a global stochastic initial encoder, (6) and the saved rank give `K>=15`. The original sixteen-state normalized emitted kernels, with identity initialization, give an exact construction with `K=16` for every horizon and common history policy. Hence

\[
 15\le K_{\rm global}^{\min}\le16. \tag{8}
\]

Equation (8) does not prove a positive fifteen-state realization. Distinct point preparations can be encoded as distinct distributions on fifteen states, so the earlier deterministic injectivity argument cannot exclude that possibility. Conversely, rank fifteen only permits a signed linear predictive representation; it does not establish nonnegative decoder probabilities or normalized Markov transitions.

For specificity, a sufficient all-horizon fifteen-state Markov construction would provide a row-stochastic full-column-rank matrix `E` of size sixteen by fifteen and nonnegative emitted matrices `A_(a,e)` of size fifteen by fifteen such that

\[
 K_{a,e}E=E A_{a,e},\qquad E\mathbf1=\mathbf1,
 \qquad\sum_eA_{a,e}\mathbf1=\mathbf1. \tag{9}
\]

Then repeated multiplication proves `E A_(a1,e1)...A_(ah,eh)1=t_w` for every word. This is a common normalized controlled evaluator, not merely a factorization of one terminal-horizon table. If a fifteen-state Markov realization is exact at all horizons and both its state dimension and predictive rank are fifteen, the same intertwining is necessary: factor all future tests as `F=E B`, note that `B` has row rank fifteen, compare `K_(a,e)E B` with `E A_(a,e)B`, and cancel a right inverse on fifteen independent test columns. These finite-dimensional operations justify the necessity without assuming positivity from rank.

For a predictor with arbitrary history-dependent memory, a common normalized causal family of decoder rows in (5), coherent over all horizons, is the more general existence condition; (9) is sufficient but need not be necessary in that enlarged category. No such positive fifteen-state construction is supplied here. This unresolved global issue cannot by itself repair the proven lack of useful proper child blocks.

There is a further distinction if hidden decoder states are required to be actual mixtures of original fine preparations. Let `r_y` be the row of `F_4` at preparation `y`. Each of the sixteen rows is an extreme point of their convex hull. Otherwise a convex representation of one row by the others would give a dependence with one positive coefficient and all remaining coefficients nonpositive. By (4) that dependence must be a multiple of `v`; either nonzero multiple has eight positive and eight negative coefficients, a contradiction. If every decoder row itself belongs to `conv{r_y}`, a convex encoding that recovers every extreme `r_y` needs at least one decoder state for every such extreme. It therefore requires sixteen states. A hypothetical positive fifteen-state realization must use latent continuation laws outside this fine-preparation convex hull. Such auxiliary states are not automatically forbidden, but their normalized causal and transition realizability needs its own proof.

## Linear rank is not nonlinear state dimension

The rank result does give a fifteen-dimensional unnormalized linear predictive realization: choose fifteen independent test columns, including the normalization column, as a basis of `v`-orthogonal observables. Every `K_(a,e)` sends this space into itself by (2), so its action has a fifteen-by-fifteen matrix in that basis. Those matrices may have negative entries. On the feasible domain inherited from fine probability laws, record probabilities remain nonnegative and the normalized prediction state has fourteen affine coordinates. This is a linear-statistical representation, not a fifteen-state Markov sample model.

A general nonlinear continuous state has another type. Sixteen preparation codes may be distinct points of a low-dimensional space, and nonlinear output maps do not factor through a matrix with that dimension as its inner size. Thus (6) is not a theorem that every nonlinear filter needs fifteen real parameters. Additional regularity, affine-mixture compatibility, a declared domain of all mixed preparations, and resource accounting would be needed for a dimension bound. Nor should real-valued encodings or a large history-dependent decoder be counted as free compression.

## Supported conclusion and stopping boundary

With the original experiment and all-preparation record exactness, allowing finite stochastic initialization does not permit useful exact compression of any proper child block. This follows from the factorization inequality and the full-support unique parity dependence in the exact rank certificate. It strengthens the local deterministic result while retaining its finite-carrier and information-access qualifications.

Globally, parity is an invisible signed initial direction at every horizon, predictive rank is fifteen, and an exact sixteen-state construction already exists. Positive fifteen-state realization remains unresolved. Deterministic state count, stochastic realization size, linear predictive rank and nonlinear continuous dimension must therefore remain separate in the report. No global fifteen-state search is needed to close the proper-local loophole addressed here.

Two analytical passes were used: source-based parity/factorization derivation, then reconstruction of the local row-independence consequence using the saved exact rank evidence. This lane ran only read-only source/certificate inspections and wrote this assigned Markdown file. It ran no simulation, code test, scientific experiment, Lean work or tamper check, and changed no source, data, configuration or other artifact. The root's separate reconstruction of the exact minor and factorization argument is the next evidence step; no alternative experiment is proposed.
