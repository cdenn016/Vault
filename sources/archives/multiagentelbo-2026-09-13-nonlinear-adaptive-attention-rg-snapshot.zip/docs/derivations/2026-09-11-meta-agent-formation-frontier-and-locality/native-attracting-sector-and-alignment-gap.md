# A native attracting sector and its alignment gap

September 11, 2026 continuation. The unchanged positive-link, two-channel Gaussian model has a five-dimensional equilibrium manifold that attracts all sufficiently nearby native E/M states in the admitted coefficient family. Every edge nevertheless has strictly positive transported marginal KL at every point of that manifold. The fixed sensor also gives the same posterior prediction throughout the manifold, although the complete models and child alignment values vary. This closes a local attraction question for the existing model and separates it from the requested formation mechanism.

## 1. Exact source and scope

Use the normalized model, fixed observation, and native product-Fisher equations in [nonlinear-coefficient-memory-and-parent-cost.md](nonlinear-coefficient-memory-and-parent-cost.md). The eight sample coordinates are x=(m1,b1,m2,b2,m3,b3,m4,b4). The bridge is c=1/2, and all six independent link coordinates theta=(m12,b12,m23,b23,m34,b34) are positive. Let R(theta)x be the residual vector m1, b1-c m1, mi-theta_mi m_(i-1), bi-c mi-theta_bi b_(i-1). The prior is N(0,C0(theta)), where C0=R^{-1}R^{-T}. The fixed sensor is

\[
 O\mid x\sim N(Hx,\sigma^2),\qquad
 Hx=\tfrac12(m2+b2+m4+b4),\quad
 \sigma^2=\frac{600923}{46656},\quad o=4.
 \tag{1}
\]

This is the supplied analytic experiment from [local-interfaces-and-two-stage-response.md](local-interfaces-and-two-stage-response.md), not a new data collection or sensor choice. The two channels are coupled by the bridge. Their scalar graph links act by multiplication when comparing marginal laws. Structural parameters, random samples, and recognition-law coefficients remain distinct.

The native recognition law has information vector h=H^T o/sigma^2 and precision J(z), affine in the twelve coefficients z=(ell,nu). Its exact equations are dot ell=theta-ell, dot nu=theta squared-nu, and dot theta=-M^{-1}g, with the actual complete-model Fisher metric and normalized covector from the preceding derivation. The open SPD part of this twelve-dimensional coefficient family is used for the local theorem. It includes a neighborhood of the reference posterior; the forward-invariant history-variance cone nu>=ell squared is a subset. Posterior-prepared trajectories near the reference are included.

The prior [alignment-tangency counterexample](pointwise-gaussian-link-learning.md), Section 7, already shows that VFE descent does not preserve zero transported KL in this native model class. The question here is different: does the actual nonlinear dynamics approach a smaller attracting sector, and does that sector make the children align? Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), sections sec:meta_agent_variational and app:rigorous_rg, requires a separate licensing/closure argument and distinguishes graph pullback from a quotient metric. The current [meta-agent concept](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) likewise requires a complete law, evaluator, access, marks and memory. We do not infer those requirements from attraction alone.

## 2. The equilibrium manifold comes from the actual likelihood

Define the total evidence variance and negative log evidence by

\[
 S(\theta)=\sigma^2+HC_0(\theta)H^\top,\qquad
 L(S)=\tfrac12\left[\log(2\pi S)+\frac{o^2}{S}\right].
 \tag{2}
\]

The exact objective is F(z,theta)=KL(q_z||pi_theta)+L(S(theta)). The posterior pi_theta has precision K(theta)=J0(theta)+H^T H/sigma^2. Direct differentiation gives

\[
 L'(S)=\frac{S-o^2}{2S^2},\qquad L''(o^2)=\frac1{2o^4}>0.
 \tag{3}
\]

Since S>0, L has its unique global minimum at S=o squared. The known reference theta0=(1/3,1/2,1/2,2/3,2/3,1/3) satisfies S(theta0)=16. Introduce the innovation loading and prior response vectors

\[
 u=R^{-T}H^\top,\qquad w=C_0H^\top=R^{-1}u.
 \tag{4}
\]

Every entry of u and w is strictly positive on the positive-link domain. Indeed R^{-1} is the finite directed path-sum matrix with nonnegative coefficients, and every innovation has a strictly positive path to an observed coordinate at child 2 or 4. If edge e enters coordinate i from coordinate j=i-2, differentiating R^{-1} gives

\[
 \partial_e S=2u_iw_j>0.
 \tag{5}
\]

Thus S is regular everywhere in this domain. In particular S=16 is a smooth five-dimensional level surface near the reference.

Let f(theta)=(theta,theta squared) be the posterior precision coefficients. The complete local stationary set is

\[
 \mathcal M=\{(z,\theta):z=f(\theta),\ S(\theta)=16\}.
 \tag{6}
\]

To check both directions, the E-equation vanishes exactly when z=f(theta), because its twelve precision basis matrices are independent. At that point the structural covector is grad_theta L(S). Equations (3) and (5) make it zero exactly when S=16. Conversely every point of (6) is a stationary native E/M pair. All have the same global minimum F=L(16) within this fixed experiment. No block partition or coherence penalty was introduced to obtain this set.

## 3. Nonlinear local attraction, with a direct proof

The zero eigenvalues recorded in the earlier linear response do not imply instability; they parametrize (6). A local nonlinear argument can establish convergence without treating a finite linearization as a proof of attraction.

Use coordinates a=S(theta)-16 and five local tangent coordinates tau for theta, which exist by (5). Set v=z-f(theta); here v is a twelve-dimensional posterior-displacement coordinate, not the per-link history variance of the preceding document. Write n=(v,a), so n has thirteen components. Define E=F-L(16). At n=0,

\[
 E(n,\tau)=\tfrac12v^\top G_z(\tau)v+\frac{a^2}{1024}
 +O(\|n\|^3).
 \tag{7}
\]

Here G_z is the recognition Fisher metric in the twelve precision coefficients at the posterior. Its statistic for a precision basis matrix A is -x^T A x/2. If a linear combination had zero variance under a positive Gaussian, its quadratic polynomial would be constant almost everywhere and hence everywhere, forcing that matrix combination to vanish. The independent basis therefore makes G_z positive definite. The cross terms in the Hessian between v and a vanish because KL(q_f(theta)+v||q_f(theta)) and its first v derivative vanish at v=0 for every theta. The scalar term in (7) follows from (3).

Restrict to a sufficiently small coordinate neighborhood with compact closure inside the positive-link and SPD domain. Smoothness and (7) give constants c1,c2,c3,c4>0 such that

\[
 c_1\|n\|^2\le E\le c_2\|n\|^2,\qquad
 c_3\|n\|\le\|\nabla E\|\le c_4\|n\|.
 \tag{8}
\]

The lower gradient bound follows already from the normal-coordinate derivative: its linear part is the uniformly positive normal Hessian, with a quadratic remainder. All norms here are Euclidean in the displayed finite chart; bounded coordinate changes merely change the constants.

The actual product-Fisher metric, pulled into this chart, is smooth and SPD. The recognition block is G_z(z); the structural block is the complete-model Fisher M(theta), whose diagonal entries are the positive prior second moments of the source coordinates. On the chosen compact neighborhood its inverse has a positive lower eigenvalue bound m and a finite upper norm bound B. The native descent identity and (8) imply

\[
 \dot E=-\nabla E^\top G^{-1}\nabla E
 \le-\gamma E,\qquad \gamma=\frac{mc_3^2}{c_2}>0,
 \tag{9}
\]

\[
 \|\dot{(n,\tau)}\|\le Bc_4\sqrt{E/c_1},\qquad
 \int_t^\infty\|\dot{(n,\tau)}\|ds
 \le\frac{2Bc_4}{\gamma\sqrt{c_1}}\sqrt{E(0)}e^{-\gamma t/2}.
 \tag{10}
\]

These estimates are initially valid only until exit. Choose the initial point in an interior smaller neighborhood and its initial E small enough that the right side at t=0 is less than the distance to the outer boundary. The finite-length bound then prevents exit. Standard local existence of this smooth finite-dimensional ODE extends the solution for all positive time inside that neighborhood. The trajectory is Cauchy by (10), converges to a point in its closure, and (8)-(9) put that limit on M. Its distance to that particular limit decays exponentially with the displayed bound.

This proves local attraction to some equilibrium on M, including all sufficiently nearby posterior-prepared initial states. It does not identify one universal limiting theta, a global basin, a radius for a numerical admission, or a preferred partition. It does not assume a time-scale parameter or use a constrained replacement flow. No numerical trajectory was run.

For comparison, the earlier exact reference matrices give a_star=80708039077537/5273247146803200 in (0,1). On the eighteen-coordinate family the linearized decay rates are six copies of 1, five copies of 2, and 1 plus or minus sqrt(1-a_star), together with five zero tangent rates. This matches thirteen attracting normal directions and the five-dimensional stationary surface. Those retained reference numbers are not rerun evidence; the nonlinear claim rests on (7)-(10).

## 4. Every stationary edge remains misaligned

Gaussian conditioning at any point of M gives

\[
 \mu=\frac w4,\qquad C=C_0-\frac{ww^\top}{16},
 \qquad R\mu=\frac u4.
 \tag{11}
\]

For a model-channel edge entering mi, the transported mean difference is

\[
 \Delta^m_i=\mu_{m_i}-\theta^m_i\mu_{m_{i-1}}
 =\frac{u_{m_i}}4>0.
 \tag{12}
\]

For its belief-channel counterpart, the fixed bridge is part of the conditional model but is not part of the same-channel graph transport used by the alignment definition. Hence

\[
 \Delta^b_i=\mu_{b_i}-\theta^b_i\mu_{b_{i-1}}
 =\tfrac12\mu_{m_i}+\frac{u_{b_i}}4>0.
 \tag{13}
\]

Every posterior covariance block is positive. If V_e=theta_e squared times C_jj is the transported source variance, the directed marginal KL is

\[
 D_e=\tfrac12\left[r_e-1-\log r_e+\frac{\Delta_e^2}{V_e}\right]
 \ge\frac{\Delta_e^2}{2V_e}>0,
 \qquad r_e=C_{ii}/V_e.
 \tag{14}
\]

The Gaussian formula follows by integrating the two log densities; standard conditioning and KL formulas are also recorded in [Rasmussen and Williams, Appendix A, A.6 and A.23](https://gaussianprocess.org/gpml/chapters/RWA.pdf). Equations (12)-(14) prove the alignment gap on the entire positive-link equilibrium surface, not just at a computed point. Their proof uses this positive directed model and this common positive observation. It is not a statement about every Gaussian graph or the ambient law-valued theory.

At the retained reference, the exact mean gaps and KL lower bounds are:

| Edge | Mean gap | Lower bound on transported KL |
| --- | ---: | ---: |
| m12 | 79/288 | 505521/1467904 |
| b12 | 1615/5184 | 2608225/16528248 |
| m23 | 7/48 | 285768/6787631 |
| b23 | 2011/10368 | 36397089/1313664736 |
| m34 | 3/16 | 1062882/31845575 |
| b34 | 4981/15552 | 446586498/2007365351 |

The smallest listed lower bound is delta0=36397089/1313664736>0. By continuity there is a neighborhood of this reference state with all six D_e>delta0/2. Initial states sufficiently close to the reference remain in such a neighborhood by the local attraction proof. Alternatively, every trajectory whose limit lies in a compact patch of M has a positive eventual alignment floor in that patch. No uniform positive floor over the entire noncompact level surface is asserted; links can approach a boundary or become unbounded outside the local admission.

Thus the native attracting sector near this reference is not a sector of asymptotically zero transported KL. This strengthens the earlier non-tangency counterexample in a different direction: the full nonlinear system actually converges locally, but what it converges to remains misaligned. Intermediate nonzero coherence is not excluded. PIFB2 explicitly places any positive-overhead licensing gain at intermediate coherence and leaves the relevant post-merge functional/closure conditions to be derived; (14) neither supplies that gain nor disproves every such regime.

## 5. Equal evidence and prediction do not fix the complete model or coherence

The same sensor reads U=Hx. Throughout M its posterior law and its existing one-query posterior prediction are

\[
 U\mid o\sim N\left(o-\frac{\sigma^2}{o},
 \sigma^2-\frac{\sigma^4}{o^2}\right),\qquad
 O'\mid o\sim N\left(o-\frac{\sigma^2}{o},
 2\sigma^2-\frac{\sigma^4}{o^2}\right).
 \tag{15}
\]

The second formula uses the previously declared same Gaussian query kernel with fresh conditional noise; no query was collected and no unspecified inference-time sample process is inferred. It follows from HC0H^T=16-sigma squared and (11). The output is a nondegenerate calibrated Gaussian, but it contains no distinction between theta values along this stationary level surface at this fixed o. This is a statement about variation along M, not that the sensor never carried information about the latent variable or that prediction is constant across different observations.

The mean is 145573/186624, the latent variance is 87478163879/34828517376, and the query variance is 536064779687/34828517376. Those values were computed exactly. The reference gradient of S, in the same edge order, is

\[
 dS=\left(\frac{553}{486},\frac{671}{972},\frac{5761}{3888},
 \frac{1981}{3888},\frac{1579}{864},\frac{13957}{7776}\right).
 \tag{16}
\]

Consider the tangent vector t=(1,0,0,0,0,-8848/13957). Equation (16) gives dS(t)=0. The implicit-function theorem, using its nonzero final entry, makes this the velocity of an actual local curve in M. Along this direction the complete-model Fisher norm is

\[
 t^\top M t=\frac{30212810569}{15778625769}>0.
 \tag{17}
\]

The complete normalized models therefore change, although the evidence and the query law (15) do not. The exact derivative of D_m12 along this same stationary curve is

\[
 dD_{m12}(t)
 =-\frac{4852899481699951481709}{199345140954202972928}\ne0.
 \tag{18}
\]

The calculation differentiates (14), including the moving link's effect on its transported mean and variance; no finite-difference approximation or logarithm rounding is used. Thus equal native minima can have different alignment values. VFE descent in this experiment does not minimize those values along the equilibrium surface: the vector field is zero at every such point.

For the supplied stages Y=(m2,b2,m4,b4) and Z=(Y_A+Y_B)/2, the exact differential ranks of their posterior covariance maps restricted to the tangent kernel of dS are five and two. These come from rank([D C_F;dS])-rank(dS), with full rational Jacobians. The fixed sensor combination inside Z has zero mean and variance derivative along every such tangent, in agreement with (15). A retained root law can still vary in two directions that this sensor does not read. Neither that variation nor its loss establishes an informative learned second level under another undeclared record experiment.

Preserving the entire original normalized model family on M requires five local structural degrees of freedom: its Fisher metric restricts positively to every nonzero five-dimensional tangent direction. A smooth exact representation with fewer coordinates cannot reproduce those complete model score directions. A single calibrated prediction can be stored more cheaply precisely because it has a narrower information contract. The original complete-carrier requirement cannot be silently replaced by that one-query contract.

## 6. What this resolves and what remains

A native attracting smaller sector exists here; it was derived from the unchanged likelihood and actual product-Fisher dynamics. Its existence did not require assuming exact inter-agent alignment, selecting a grouping, or replacing the native equations by a constrained flow. Its thirteen stable normal directions relax recognition/history mismatch and one evidence-variance direction. Five structural model directions remain as a stationary family. The finite-time trajectories still carry the nonlinear memory described in the preceding paper; attraction is not exact deletion of those coordinates at a finite time.

This attracting family does not implement the proposed asymptotic coalescence mechanism: all six transported marginal comparisons remain strictly positive. The same observation admits differing complete models and differing coherence at equal minimum VFE, and its stationary predictive law is identical across that family. These facts block interpreting the existing reference's stable response or neutral directions as a learned informative hierarchy. They do not prove impossibility of intermediate-coherence parents, another admitted factorization, law-valued random-link models, or a derived restricted dynamics with different hypotheses.

The new [exact evidence](evidence/attracting-sector/result.json) covers (5), (12)-(18), positive rational KL lower bounds, stationary tangent information, and retained-covariance tangent ranks. The first script invocation failed while reading the edge dictionary as a list, before scientific checks. Its error and source hash are retained. After correcting that schema assumption, the calculation passed once under pinned CPython 3.14.7 with -I -B in 0.006616800000301737 seconds. It reads existing reference data and imports guarded helpers without executing old experiments. The local attraction theorem is the written proof (7)-(10), not a numerical simulation. No formal ledger certificate, ODE integration, new data, broad suite, GPU work, Lean, tamper check, publication or vault edit is claimed.

The preceding goal turn was progress. This continuation used three sequential substantive passes: identify and prove attraction of the native stationary sector; establish its positive alignment gap; and compute exact model/coherence distinctions invisible to the same sensor. All fifteen heterogeneous exact negatives, previous conditional constructions and saved data remain unchanged. The full goal remains incomplete.

The next work should return to the existing normalized law-valued alignment construction and its actual conditional learning equations, rather than retest this positive-chain equilibrium. In particular, read normalized-alignment-parent-limit.md and its marked/singular extensions alongside the native moving-target formulas, and identify whether a finite-strength coupled learning regime admits the required coherent slow sector with a complete reusable parent and counted interfaces. The already established concentration limits and supplied-grouping examples are inputs, not a newly discovered mechanism or a completed dynamic hierarchy. Any new factor, learning parameter or observation contract must be stated explicitly; the present result does not authorize changing the saved experiment or inventing a tolerance or licensing penalty.
