# Native ancestry crossings, response persistence, and selection loss

September 12, 2026. The same transported-parent learner admits an actual one-block-to-two-pair change in its most probable ancestry for an explicitly described open set of structural priors. A positive interval of preference and distinct original-record responses follows from the full coupled flow, including recognition lag. This result is conditional on those priors and is not a claim that the uniform prior has that trajectory. Every finite-time posterior still has full ancestry support. Selecting its most probable ancestry therefore requires a separate approximation and resource decision, with an exact loss given below.

## 1. The source and the unchanged learner

The [finite-coherence result](finite-coherence-regions-and-native-ancestry-response.md) already proves the complete evidence ordering at b=c=1 and a positive initial pair-versus-one-block log-odds acceleration for every positive prior. Its remaining dynamic gap is real: the full learner moves b and c immediately, so the static slice is not invariant. This continuation works with the existing [transported generator](transported-parent-priors-and-induced-couplings.md), its forty-five decorated structures and original eight record labels. No numerical ancestry prior, new data, time kernel or model factor is chosen.

The live [PIFB2 source](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, requires optimized free energy plus actual organizational cost; its `sec:epistemic_collapse` does not require perfect consensus. The [wiki's current operational definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires the joint parent law, evaluator, access, marks and sufficient memory. The [complete parent channel](shared-parent-complete-channel-and-recursive-cost.md) and induced parent/loop covariance in the transported-prior derivation remain the composition authority. A most-probable ancestry label alone meets none of these additional requirements.

Let P={{0,1},{2,3}} and O={{0,1,2,3}}. The fixed prior pi_R is positive and normalized over all twelve connected partitions; decorations are conditionally uniform and shared by the two channels. Start with unit model and recognition precisions, omega=0 and s=1, so recognition is the exact posterior of the unit model. The matched root stays constant. Since dot s=1-s, s remains exactly one. The actual prepared trajectory therefore has seven evolving law coordinates, although the earlier general autonomous family retains eight when s is variable.

Write x=(u_a,u_b,u_c,rho_a,rho_b,rho_c,omega). The equations inherited from the normalized joint are

\[
 \dot\rho_j=u_j-\rho_j,\qquad
 \dot\omega=2\log u_b-\omega,\qquad
 \dot u_j=u_j-u_j^2\langle E_j\rangle_Q/16\quad(j=a,c),
 \qquad
 \dot u_b=\frac{\langle k\rangle_Q u_b-u_b^2\langle E_b\rangle_Q/4}{K_\pi},
 \quad K_\pi=\sum_R\pi_R k_R.
 \tag{1}
\]

The transported child-noise energy is the actual E_a, not the earlier untransported statistic. For positive recognition precisions, define zeta_R(rho) as the exact evidence at variances 1/rho and the same integer batch. Then

\[
 w_R(t)=Q_t(R)=\frac{\pi_R e^{\lambda(t)k_R}\zeta_R(\rho(t))}
                        {\sum_S\pi_S e^{\lambda(t)k_S}\zeta_S(\rho(t))},
 \qquad \lambda=\omega-2\log\rho_b\leq0.
 \tag{2}
\]

All moments in (1) are those of this same correlated mixture. The existing global positive finite-time existence proof applies. Equation (2) is a distribution over latent ancestries, not a process of sampled memberships or a physical clock.

## 2. A uniform local crossing theorem

Define the prior-free log-weight difference

\[
 \ell_R(x)=(k_P-k_R)\lambda+\log\zeta_P(\rho)-\log\zeta_R(\rho).
 \tag{3}
\]

The actual log odds are log(pi_P/pi_R)+ell_R(x(t)). At the common initial state x_0, every dot ell_R is zero. The preceding exact calculation gives a strictly positive constant q_0, independent of the positive structural prior, such that

\[
 \frac{d^2}{dt^2}\ell_O(x(t))\bigg|_{t=0}\geq q_0,
 \qquad q_0\simeq0.0407076474536.
 \tag{4}
\]

Its exact fraction is retained in [native-jet.json](evidence/finite-coherence-classification/native-jet.json). This is a second derivative of finite-rate recognition, not a first derivative of an instantaneous posterior.

To control the remainder, take the compact state box D with each u and rho in [1/2,2] and omega in [-1,1]. Extend the coefficients of (1) continuously to the closed prior simplex for the purpose of bounds. The conditional moments remain finite smooth functions of positive rho. Each mixture denominator is a convex sum of strictly positive conditional normalizers and is bounded away from zero on this compact set; K_pi>=1. Thus the vector field f_pi and every derivative used below are bounded on D times the closed simplex. Zero prior weights are used only for compact bounds, not asserted to retain the full-family nonsingular Fisher metric.

Let L_f denote directional differentiation along (1), and set

\[
 B=1+\sup_{D,\pi}\|f_\pi\|_\infty,\qquad
 M=1+\max_{R\ne P}\sup_{D,\pi}|L_f^2\ell_R|,\qquad
 J=\sup_{D,\pi}|L_f^3\ell_O|,
 \quad
 T_* = \min\left\{\frac1{4B},\frac{q_0}{2(1+J)}\right\}>0.
 \tag{5}
\]

These are specified finite analytic bounds, not numerically evaluated durations. All functions are given by the finite determinant integrals and (1), so the constants can in principle be bounded from those expressions. No practical lower bound on T_* is claimed. The displacement bound B T_*<=1/4 keeps every trajectory inside D. Integrating the third-derivative bound from (4) gives ell_O''(t)>=q_0/2 on [0,T_*], while |ell_R''(t)|<=M for every competitor.

Fix any 0<T<=T_*. Write the initial one-block advantage over the pair as d, and the pair's advantages over all remaining candidates as m_R:

\[
 d=\log\frac{\pi_O\mathcal E_O(1,1,1)}{\pi_P\mathcal E_P(1,1,1)},
 \qquad
 m_R=\log\frac{\pi_P\mathcal E_P(1,1,1)}{\pi_R\mathcal E_R(1,1,1)}
 \quad(R\ne P,O).
 \tag{6}
\]

Suppose

\[
 0<d<\frac{q_0T^2}{4},\qquad
 \min_{R\ne P,O}m_R>\frac{MT^2}{2}.
 \tag{7}
\]

Then O is the unique initial MAP ancestry, there is exactly one O/P crossing time tau in (0,T), P is the unique MAP ancestry on (tau,T], and no third ancestry intervenes. Moreover,

\[
 \sqrt{\frac{2d}{M}}\leq\tau\leq2\sqrt{\frac d{q_0}},
 \qquad
 T-\tau\geq T-2\sqrt{\frac d{q_0}}>0.
 \tag{8}
\]

For the proof, twice integrate the derivative bounds with zero initial first derivative. Pair-versus-O log odds lie between -d+q_0t^2/4 and -d+Mt^2/2 and increase strictly for t>0. Pair-versus-every-other-candidate log odds stay at least m_R-Mt^2/2>0. The intermediate-value argument, strict monotonicity and these margins prove existence, uniqueness, all-candidate preference and (8).

Conditions (7) describe a nonempty open set of positive priors. Algebraically, positive initial unnormalized posterior weights with O/P ratio exp(d) and all other weights below the required margins can be divided by the fixed positive evidences and normalized to demonstrate nonemptiness. This is a sensitivity theorem over the preexisting prior family. It is not a prescription to estimate a prior from the same records after observing them, and no member of that family was selected or simulated. The exact unit tie surface has prior ratio pi_P/pi_O equal to the O-to-P evidence ratio, approximately 2.46728204427. The theorem concerns a neighborhood on the initially O-dominant side of that surface. It does not establish a crossing for the uniform prior, generic priors far from the surface, or the earlier fixed-b,c evidence interval.

## 3. Why no prior-independent finite-time selection follows

For any finite T, a nonempty open set of strictly positive priors instead keeps O uniquely preferred throughout [0,T]. A quantitative sufficient condition follows directly from the same flow; no counterexample trajectory is fitted.

Since dot u_a<=u_a and dot u_c<=u_c, both model precisions are at most exp(t). Solving the recognition filter with unit initialization gives

\[
 e^{-t}\leq\rho_a(t),\rho_c(t)\leq\cosh t.
 \tag{9}
\]

The O evidence is independent of rho_b. Let m_Oa and m_Oc be its unit-posterior Gaussian energy means divided by 16, already saved in the native calculation. Changing Gaussian precision from one to rho and applying convexity of the exponential gives

\[
 \log\frac{\zeta_O(\rho)}{\mathcal E_O(1,1,1)}
 \geq8\log\rho_a+8\log\rho_c
      -8m_{Oa}(\rho_a-1)-8m_{Oc}(\rho_c-1).
 \tag{10}
\]

This is an expectation under the proper unit posterior, so the retained energies and shared decoration are included. Equations (9)-(10) imply the positive lower bound

\[
 \zeta_O(\rho(t))\geq L_O(T)
 :=\mathcal E_O(1,1,1)
   \exp[-16T-8(m_{Oa}+m_{Oc})(\cosh T-1)].
 \tag{11}
\]

The original likelihood has the universal upper bound

\[
 L_o\leq L_{\max}
 :=\prod_{e=1}^{4}\left[\frac{n_e^{n_e}}{(n_e+1)^{n_e+1}}\right]^2<1.
 \tag{12}
\]

Each factor follows by maximizing p^n(1-p) on [0,1]. Thus zeta_R<=L_max. Every R other than O has k_R>1, while lambda<=0. Equation (2) consequently gives

\[
 \frac{w_R(t)}{w_O(t)}
 \leq\frac{\pi_R}{\pi_O}\frac{L_{\max}}{L_O(T)}
 \quad(0\leq t\leq T).
 \tag{13}
\]

Taking each pi_R/pi_O<L_O(T)/L_max is a nonempty open positive-prior condition for no switch away from O over that horizon. The bound is conservative and not an asymptotic convergence statement. It establishes that a favorable initial pair-odds direction cannot imply universal finite-time pair selection over arbitrary positive priors. The crossing region and this noncrossing region are both properties of the unchanged family.

## 4. Distinct responses persist through the conditional episode

A MAP crossing should not be mistaken for informative behavior merely because its integer label changes. The original record kernel gives a direct check. At the unit posterior conditional on R, let e_H(n+r 1_e) denote the same one-channel likelihood integral with r extra success powers on label e. Then, for r=1,2,

\[
 M_{Re}^{(r)}=E_{Q_0(\cdot\mid R)}[p_e^r]
   =\frac{N_R^{-1}\sum_{H:R(H)=R}e_H(n+r1_e)e_H(n)}
          {\mathcal E_R(1,1,1)}.
 \tag{14}
\]

The other channel contributes its unchanged e_H(n), and H is still shared. These are prospective probabilities for the already declared static-latent record kernel; no additional record is collected. Both channels have the same marginal values for this batch. One exact Fraction calculation evaluates (14) for every label of all twelve ancestries and retains the complete results in [predictive-moments.json](evidence/native-ancestry-crossing/predictive-moments.json).

| Label type | Pair conditional mean p | Pair conditional variance of p | Pair minus O mean p |
| --- | ---: | ---: | ---: |
| Internal labels 01 and 23 | 0.811822424388 | 0.0131372043023 | 0.00180784163308 |
| Cut labels 12 and 30 | 0.386868213109 | 0.0556907926303 | -0.0605664946851 |

The pair and O therefore have distinct forecasts on the original cut record, with Bernoulli total-variation distance delta_0 approximately 0.0605664946851. This distinction is conditional on ancestry, not a claim that the full posterior has identified the true ancestry. Every retained p variance is strictly positive in all twelve cases.

For two future queries of the same label at the same latent preparation, the exact ordered outcome law is

\[
 (P_{00},P_{01},P_{10},P_{11})
   =(1-2M^{(1)}+M^{(2)}, M^{(1)}-M^{(2)},
      M^{(1)}-M^{(2)}, M^{(2)}).
 \tag{15}
\]

Its distance from independent Bernoulli emissions with the same mean is exactly 2 Var(p). The pair values are approximately 0.0262744086047 on an internal label and 0.111381585261 on a cut. All entries are positive and sum to one. A constant independent-emission replacement thus loses an explicit part of the original two-query experiment. A separate history-dependent predictor could encode this dependence; (15) is not a lower bound on the cost of every such predictor. The calculation also retains the nonnegative same-label cross-channel covariance induced by uncertain shared H.

These responses are smooth functions of rho at s=1. Their first time derivatives vanish at the unit preparation, as dot rho(0)=0. On the compact box used in Section 2, take H_resp to exceed all absolute second flow derivatives of the relevant one-record means, and H_var to exceed those of the pair probability variances. Both bounds are finite uniformly over the closed prior simplex by the same positive-integral argument. Decrease T_* if necessary so that

\[
 H_{\rm resp}T_*^2\leq\delta_0/2,\qquad
 H_{\rm var}T_*^2\leq\min_e\operatorname{Var}_{Q_0(\cdot\mid P)}(p_e).
 \tag{16}
\]

The cut forecast distinction then stays at least delta_0/2 and the pair's probability variances at least half their initial values throughout [0,T_*]. Combining this smaller T_* with (7)-(8) gives an actual conditional MAP episode with distinct, nonconstant original-record responses. Its duration is an existence/bound statement in native inference time; the constants have not been numerically evaluated and no physical membership process has been introduced.

The complete parent channels retain p, all required energies, geometry and marks, and their common conditional is unchanged. Pushing these laws to the two proper parents and then through the admitted second geometric contraction preserves (14)-(15) exactly. For any parameter-independent record kernel, the absolute change of a forecast is bounded by the total variation of the input law: integrate the signed input-law difference against a kernel taking values in [0,1]. Conditional law variation itself is bounded by one half of the integral of its Fisher speed, obtained by differentiating the normalized density and applying Cauchy-Schwarz to its centered score. These are response-persistence and composition statements for the original kernel. They do not prove that a second parent is selected by learning or that newly defined parent-cut records survive a smaller carrier.

## 5. Hard selection has an exact cost even during a MAP episode

Positive priors, finite lambda and positive Gaussian likelihood integrals make every w_R(t) strictly positive at every finite time. The native flow therefore never changes the support to a single ancestry in finite time. This does not forbid exact marginalization of hidden ancestry or an exact parent carrying its mixture evaluator. It forbids identifying such marginalization with conditioning on the winning ancestry.

For any nonempty retained set A of ancestries, let W_A=Q_t(R in A) and Q_t^A=Q_t(.|R in A). For every law nu supported on that event,

\[
 D(\nu\Vert Q_t)=D(\nu\Vert Q_t^A)-\log W_A.
 \tag{17}
\]

The proof substitutes dQ_t^A/dQ_t=1_A/W_A. Thus the closest support-restricted law in forward KL is Q_t^A, with loss -log W_A. Directly splitting the mass inside and outside A also gives

\[
 \operatorname{TV}(Q_t^A,Q_t)=1-W_A,
 \qquad D(Q_t\Vert Q_t^A)=+\infty\quad(A\ne\mathcal R).
 \tag{18}
\]

These are complete latent-law quantities. They remain exact under the current complete carrier, which retains the ancestry/decorative record. A further record-only push can reduce the loss; its bound by (18) does not generally become equality. For a prescribed complete-law TV tolerance epsilon, W_A>=1-epsilon is both necessary and sufficient for this conditional replacement. No tolerance is selected here.

At the O/P MAP crossing in Section 2, w_P=w_O<1/2 because the other ten ancestries have positive mass. Hence selecting P discards more than half the complete recognition mass and costs more than log 2 in forward KL. By continuity, a nonzero initial portion of the P-dominant episode still has w_P<1/2. A unique MAP label is therefore compatible with a substantial support-restriction loss. A persistence certificate for that label cannot stand in for a complete-law approximation certificate.

The optimized free-energy comparison in the source uses the exact posterior Pi_u of the current model, not an inexact Q_t. Keeping that generative joint fixed, the best free energy constrained to ancestry set A obeys

\[
 F_A^*(u)-F^*(u)=-\log\Pi_u(R\in A)>0
 \quad(A\ne\mathcal R).
 \tag{19}
\]

This follows from F=D(Q||Pi_u)-log P_u(o) and (17) applied to Pi_u. The finite-rate recognition loss -log W_A and the optimized penalty in (19) must not be substituted for each other. If actual computational/organizational costs C_A and C_full are supplied in the same objective, the constrained representation beats the unrestricted optimum only when C_full-C_A exceeds the right side of (19). A common exact coarse channel has zero VFE loss instead; any saving then has to come from its implementation. Changing or refitting the generative model after selection is another model comparison and requires its own normalized factors and inherited correlations.

## 6. A declared oracle-work frontier, not a complete cost claim

The prepared trajectory has s=1 forever. Its recognition normalizer and Gaussian energy moments therefore use the finite sixteen-term failure expansion at every inference time, even while rho differs from u. The slower infinite expansion needed for intermediate likelihood powers is not part of this preparation. This is a useful reduction of the evaluator obligation, available equally to fine and parent representations.

The calculation inventories the entire covariance maps aL+bJ_RJ_R^T+cC_HC_H^T, comparing the b and c coefficient matrices separately. There are thirty-one distinct maps, not merely thirty-one matrices at the unit point. Their sets are disjoint across different R. The catalog gives d_R=5-k_R maps per partition in this four-cycle family: four for O, three for each two-block partition, two for each three-block partition and one for the singleton partition.

Consider the explicit direct evaluator that forms one four-by-four determinant and covariance solve for each map and failure subset, reuses it over decorations, and sums the exact likelihood and energy expressions. Its matrix-term count is 16 sum_R d_R=496 for the full ancestry family, 48 for the conditional pair branch, and 64 for O. These are counts for this evaluator, not lower bounds on all algorithms or measured runtime ratios. Scalar weighting, joint geometry, law storage, interfaces, generation, future-record filtering and switching all have additional costs. Selecting a branch also changes the admitted inference problem as described in Section 5.

For completeness, at any supplied current ancestry weights w_R, this particular oracle charge has an exact approximation frontier over retained ancestry sets. Define

\[
 V(B)=\max_{A: \sum_{R\in A}d_R\leq B}\sum_{R\in A}w_R,
 \qquad 1\leq B\leq31.
 \tag{20}
\]

The smallest forward-KL restriction loss within that budget is -log V(B), with complete-law TV loss 1-V(B). A finite dynamic program computes V: when adding candidate j of cost d_j, either exclude it or add its weight to the preceding value at budget B-d_j, taking the larger value and retaining ties. Induction over the twelve candidates proves the recurrence covers every subset. No budget, weight vector or scalar penalty was supplied or optimized here. Equation (20) describes computational thinning of an ancestry mixture; its subsets are sets of hypotheses, not subsets of children and not a learned RG hierarchy. It is one quantified component of the resource question, not a substitute for the complete parent cost.

## 7. Execution, preservation, and the remaining gate

One new exact Fraction calculation ran once under pinned CPython 3.14.7 and passed in 0.1403162999995402 seconds. It evaluates ninety-six first/second probability moments across the twelve conditional response rows, checks every two-query probability law and nonzero variance, and inventories all forty-five decorated covariance maps. The complete outputs, source/input hashes and stdout are retained in [evidence/native-ancestry-crossing](evidence/native-ancestry-crossing/). Existing helper definitions were imported without executing their guarded scientific mains. An initial read used the nonexistent plural directory shared-parent-records; the imported source names the correct shared-parent-record path, which was read before construction. No source reconstruction or scientific execution failed.

The prior goal turn was progress. This turn used three substantive passes: uniform coupled-flow crossing and noncrossing arguments; exact original-record responses and full covariance-map inventory; and response persistence, selection loss and the declared oracle frontier. The crossing theorem, global finite-horizon prior bound, KL identities, and frontier recurrence are written proofs, not simulated outcomes. No numerical remainder constants, ODE trajectory, prior fit, parameter search, fresh data, samples, GPU, suite, Lean, tamper check, production/configuration edit, Git publication, canonical synchronization or vault/manuscript edit occurred. The current status, RG progress record and daily log are updated; all earlier artifacts are preserved.

The next gate is substantive licensing under the same normalized model: combine actual retained posterior mass, complete approximation/response requirements and actual resource savings, rather than equating a MAP crossing with formation. The new theorem supplies an open family of genuine preference episodes, but it leaves the uniform-prior trajectory, longer-time attraction or release, numerical useful duration and a second learned stage unresolved. The complete geometric parent and induced correlated recursive prior already exist and should be reused. An inference-time episode remains distinct from sampled-link or physical-time persistence.
