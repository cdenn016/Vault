# Independent reconstruction

This note records the independent argument before reading `frontier-analysis.md` or `local-contract.md`. The source model definition inspected is `src/multiagent_elbo/rg_v2/finite_data_formation.py`, function `heterogeneous_process`, at the assigned source revision ed8f22a56df353b1535744509cc23fae46d5813c. No scientific process or numerical experiment was run. The conclusions below are proved by finite sums. They are not a ledger certificate.

## Predictive loss decomposition

Fix a positive integer H, finite state, action, and record spaces, normalized emitted transition kernels K^a(y',e|y), one preparation mu, deterministic h, and Z=h(Y_0). Fix the fitted mechanism and all design data before evaluating risk. Put V=(A_1,E_1,...,A_H,E_H). The supplied policy assumption means that, under both the true experiment and the fitted experiment, the conditional action law given the full hidden and observed past is the same pi_t(a|v_<t). Thus policy randomization carries no additional hidden-state information. In particular this is a conditional-independence assertion, not merely equality of marginal action frequencies.

Let P_y(v) be the true V-law initialized at y, P_z(v)=sum_{y:h(y)=z}mu(y|z)P_y(v), and Q_z(v) the fitted law initialized at z. Define the true and fitted full-past record predictors p_y(e_t|v_<t,a_t) and q_z(e_t|v_<t,a_t). All risks use the same evaluation law mu(y)P_y(v):

\[
R(Q,h)=H^{-1}\mathbb E_{\mu P}\left[-\sum_{t=1}^H\log q_Z(E_t|V_{<t},A_t)\right],\quad
R(P,\mathrm{id})=H^{-1}\mathbb E_{\mu P}\left[-\sum_{t=1}^H\log p_{Y_0}(E_t|V_{<t},A_t)\right].
\]

Assume P_z is absolutely continuous with respect to Q_z for every z of positive mu_Z mass. On every evaluated word of positive P_y mass the factors pi_t are positive and

\[
P_y(v)=\prod_t\pi_t(a_t|v_{<t})p_y(e_t|v_{<t},a_t),\quad
Q_z(v)=\prod_t\pi_t(a_t|v_{<t})q_z(e_t|v_{<t},a_t).
\]

A word with positive P_y mass has positive P_z mass whenever mu(y)>0, so the support assumption makes all denominator factors on this path positive. Finiteness of all spaces and H then makes all evaluated logarithms integrable. Canceling the common policy factors gives

\[
H[R(Q,h)-R(P,\mathrm{id})]
=\sum_{y,v}\mu(y)P_y(v)\log\frac{P_y(v)}{Q_{h(y)}(v)}.
\]

Insert P_{h(y)} between numerator and denominator. The first resulting sum is, by its definition, I_P(Y_0;V|Z). In the second sum the logarithm depends on y only through z; summing mu(y)P_y(v) inside each fiber gives mu_Z(z)P_z(v). Consequently the requested identity is exact:

\[
H[R(Q,h)-R(P,\mathrm{id})]
=I_P(Y_0;V|Z)+\sum_z\mu_Z(z)D_{\mathrm{KL}}(P_z\Vert Q_z).
\]

No Markov property of h(Y_t) is needed. The fitted mechanism can contain auxiliary state or previous-record memory provided Q_z is normalized and its predictor is its actual full-past conditional. Zero-probability histories admit arbitrary conditional versions and contribute nothing. With finite spaces, dropping domination gives both fitted risk and the relevant KL value +infinity whenever a positive evaluation word is impossible under Q; the true risk is finite, so an extended-real version remains valid. An assertion of finite loss nevertheless requires domination. If H=0, the per-event risk is undefined.

The identity uses the evaluation preparation's conditional mixture mu(y|z), not the preparation used to fit the parent. A different fitted preparation is allowed inside Q, but its discrepancy contributes to the displayed KL term. Replacing P_z by a mixture from another preparation is not this identity. Likewise the fine comparator is the true predictor initialized at the actual Y_0, not a separately fitted identity partition.

The policy assumption is load-bearing. For H=1, let Y_0 be a fair bit, Z constant, A_1=Y_0, and E_1=0 deterministically. A parent with fair action and deterministic zero record has zero excess record NLL, whereas I(Y_0;A_1,E_1)=log 2 and its V-law equals the unconditional true V-law. The proposed right side is log 2. The hidden-aware action policy violates the stated conditional-independence premise and proves why the identity cannot be applied there. A policy depending on Z but not hidden state inside Z can be treated by conditioning the same policy factors on z; this is a distinct, explicitly weakened policy hypothesis, not needed for the supplied statement.

## Simultaneous local quotient

Here a carrier hypothesis must be stated. Assume the fine carrier is the full finite product of site spaces. Let A_1,...,A_k be pairwise disjoint site blocks, R their complement, h_j maps on block carriers independent of exterior values, and F(y)=(h_1(y_A1),...,h_k(y_Ak),y_R). Assume the supplied full emitted-row identity for every j, source y, action a, target block label s'_j, target exterior y'_-Aj, and record e:

\[
\sum_{y'_{A_j}:h_j(y'_{A_j})=s'_j}K^a(y'_{A_j},y'_{-A_j},e|y)
=\bar K_j^a(s'_j,y'_{-A_j},e|h_j(y_{A_j}),y_{-A_j}).
\]

For a fixed retained target f' and e define

\[
T^a(f',e|y)=\sum_{y':F(y')=f'}K^a(y',e|y).
\]

If u and v differ only inside A_j and h_j(u_Aj)=h_j(v_Aj), expand T by target exterior coordinates. The allowed exterior set is determined by the other target block labels and target remainder. Sum the assumed identity over this identical allowed set. Its right sides are equal for u and v because their source exteriors and source h_j labels agree. Thus T^a(f',e|u)=T^a(f',e|v).

If F(y)=F(tilde y), replace the blocks A_1 through A_k successively, retaining the fixed remainder. Every intermediate source is admissible on the product carrier, and every replacement is of the preceding type. Hence T^a(f',e|y)=T^a(f',e|tilde y). Define this common value to be K_F^a(f',e|F(y)). Nonnegativity is inherited, and summing over f',e partitions the original target sum, giving one. This proves exact full emitted-row closure on the image of F for every action, independently of the preparation.

For identical controlled retained path laws, initialize the parent with F_#mu and apply the same action policy based on retained history (or the same externally specified action sequence). Conditional on every fine hidden history, the next retained state and record law is K_F; summing and inducting proves equality of all finite retained path cylinders. A fine-state-aware controller can destroy this conclusion even though every per-action row closes: it may choose different actions inside one fiber. The quotient then needs a separately admitted common action kernel. If an initial sensor E_0 is part of the retained path, its law must additionally factor through F, or the claim must be restricted to the actual preparation-specific pushed initial joint and compatible conditioning. Closure of transition emissions alone says nothing about a separately chosen initial sensor.

The product-carrier hypothesis cannot simply be omitted. Let the admissible fine carrier be {(0,0),(1,1)}, take A_1={1}, A_2={2}, constant h_1,h_2, identity transition, and record e=y_1. For each block, retaining the entire source exterior identifies its sole admissible interior, so the stated single-block quotient exists: it preserves the exterior and emits that exterior bit. But F is constant, and its two source states emit different records. Thus simultaneous closure fails. More generally the proof only needs every F-fiber to be connected under admissible one-block replacements; a product carrier is sufficient. If finite Y was intended to allow constrained subcarriers, this is a demonstrated missing assumption.

## Shared-row obstruction and first response

For distributions p,q,r on the same finite output alphabet, the coordinate inequality |p_i-q_i|<=|p_i-r_i|+|r_i-q_i|, summed and divided by two, gives

\[
\operatorname{TV}(p,q)\leq\operatorname{TV}(p,r)+\operatorname{TV}(q,r),\quad
\max\{\operatorname{TV}(p,r),\operatorname{TV}(q,r)\}\geq\tfrac12\operatorname{TV}(p,q).
\]

Therefore if a retained fiber contains preparations with output-row diameter d_f, every one shared approximating row has worst-case error at least d_f/2. The same holds for the supremum diameter if the supremum is not attained. This is a lower bound, not general attainability of radius d_f/2 for three or more rows. It concerns a common response row; it does not by itself lower-bound an average NLL without evaluation weights and a corresponding conversion argument.

For the inspected four-spin reset, y_i is in {-1,1}, J_ij=J_ji and J_ii=0. A site i is selected with probability 1/4, its new spin U has mean a+sum_j J_ij y_j, and all other spins remain unchanged. The admission |a|+sum_j|J_ij|<1 ensures strictly positive reset probabilities. Define P(y)=product_i y_i and M(y)=sum_i y_i. For a chosen site, P(Y_1)=P(y)y_i U; therefore

\[
\mathbb E[P(Y_1)|y,a]
=\frac{P(y)}4\sum_i y_i\left(a+\sum_jJ_{ij}y_j\right)
=\frac{P(y)}4\left[aM(y)+2\sum_{i<j}J_{ij}y_i y_j\right].
\]

The destination sensor has mean eta P(Y_1), hence

\[
\mathbb E[E_1|y,a]
=\frac{\eta P(y)}4\left[aM(y)+2\sum_{i<j}J_{ij}y_i y_j\right].
\]

This is an exact expectation, not a response derivative or small-coupling expansion. For y^+=(1,1,1,1), y^-=(-1,-1,-1,-1), P=1 in both cases and all pair products equal one. Their emitted means differ by 2 eta a. On {-1,1}, TV equals half the absolute mean difference, giving eta|a|. At eta=3/4 and |a|=1/5 this is 3/20, with shared-row floor 3/40. These constants hold for every symmetric admitted coupling profile and for either fixed action sign. The preparations must be merged by the candidate map for the shared-row obstruction to apply. If both signs of a are averaged without retaining the action, their contrasts can cancel; a fixed or retained action is required.

## Independent recording boundary

The independent derivations above were written before reading either candidate proof. The comparison below was added only afterward.

## Candidate comparison after independent recording

The subsequently inspected `local-contract.md` sections 2, 3, and 6 have the same mathematical content as the reconstructed shared-row bound, exact first-record expectation, and block-replacement proof. Its section 1 explicitly fixes the full four-spin product carrier. Thus the nonproduct example above is a scope clarification, not a defect of its four-spin theorem. Restating the product premise locally in section 6 would prevent accidental generalization. The draft correctly retains fixed actions, separates initial sensor descent, and requires retained-history policies. No defect was demonstrated in these scoped statements.

In the final comparison, the now-available `frontier-analysis.md` was read after the independent proof above had been recorded. Its Exact preparation identity section supplies the same fixed training data, common evaluation preparation, deterministic retention map, finite positive horizon, normalized mechanisms, observed-history policy, and path-support assumptions. Its zero-based action indexing consistently pairs A_t with the next E_(t+1), so its policy uses only prior records. Its explicit hidden-path joint gives the required conditional independence of policy randomization. The finite-mixture expansion, policy-factor cancellation, and two log-ratio terms match the independent derivation. Its full-past filtered record risk is the quantity proved here; no Markov assumption for the true retained process enters. Its warnings concerning hidden-aware actions and source-matched preparation are sufficient. No defect was demonstrated in that scoped identity. Numerical reproduction and numerical summaries in that file were not independently rerun or certified by this reconstruction lane. The displayed information term is irreducible only relative to the fixed h, evaluation preparation, action/record experiment, and allowed conditioning. It is not a universal obstruction to a different experiment or retention map.

