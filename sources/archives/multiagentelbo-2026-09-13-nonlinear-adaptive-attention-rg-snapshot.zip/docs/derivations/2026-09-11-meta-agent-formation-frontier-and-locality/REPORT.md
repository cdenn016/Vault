# Meta-agent formation: retrospective frontier and locality

September 11, 2026. The requested first bounded session is complete at source revision ed8f22a56df353b1535744509cc23fae46d5813c in the existing isolated worktree. All 288 saved candidate scores and complete rankings reproduce, and all nine selected rational models match exactly. The retained constant-endpoint result survives. The analysis separates its declared resource preference from preparation-information loss, fitted-model discrepancy, and sparse conditional transition data. It does not establish informative intermediate formation or absence of organization.

## Saved experiment and source reconciliation

The [execution record](RECORD.md) contains the operational contract and round accounting. The live isolated worktree and canonical Desktop HEAD both match the handoff revision; the isolated worktree was clean. The older d7cb849 planning/execution references describe historical snapshots. The published finite formation sources already provide exact deterministic emitted-row closure, correlated VFE accounting, a memory obstruction and repair, and the symmetric 16-to-9-to-5 hierarchy with three admissible pairings. This session preserves those completed results.

The empirical source is the frozen heterogeneous four-spin process with six unequal symmetric couplings, fields ±1/5, and a noisy destination-parity record of signal 3/4. One event resets one uniformly selected site. Preparation is uniform over sixteen fine states; a candidate receives only its retained initial class, then actions and records. Subsequent fine states in the archive are training or diagnostic information. The auxiliary fair initial_sensor array is not an observed time-zero record. All candidates filter record histories; the additional previous-record index conditions transition rows.

The empirical four-record prediction task and the universal retained-state/record path theorem are different experiments. Average record accuracy under the saved preparation and policies does not certify joint path preservation for all fine preparations. The [input binding](evidence/input-binding.json) and [completion inspection](evidence/completion-inspection.json) record source and retained-input checks. No new observations were collected, and the production learner, active profile, Theory, Research vault, historical evidence, and canonical checkout were not edited.

## Reproduction and accuracy/resource frontier

[Reconstruction evidence](evidence/frontier/reconstruction.json) records maximum absolute score difference zero against a declared tolerance of 1e-12. The nine selected indices are all 30, the base constant model. Their rational rows equal the retained models. The saved tie rule is criterion, then effective state count, then original candidate index. The reconstruction uses saved partition ladders and original row/episode observations; it never regenerates the ladder or invokes either observation-collecting runner.

The [machine-readable frontier](evidence/frontier/validation-frontier.csv) contains all 288 candidates, including NLL, binary Brier, paired episode differences from fitted constant and identity endpoints, class count, observed memory bits, filter coordinates, transition storage, normalized-row coordinate count, and a declared partition encoding cost. The searched family has one training-derived partition per cardinality, with two transition model choices. It is not all partitions of sixteen states and not a menu of child subsets.

The primary frontier uses NLL and log2 effective recurrent state count. Its candidate counts are 1, 5, 2 at budget 32; 3, 8, 5 at 128; and 5, 7, 6 at 512, in seed order 1701, 2903, 4307. Other costs are exported separately, not folded into an unspecified total. For k classes the base model stores 4k² entries with 2k(2k-1) normalized-row coordinates; previous-record conditioning triples these counts. The filter still has k-1 free coordinates because the previous record is observed. The partition cost is sixteen labels of ceil(log2 k) bits, with k and the carrier supplied separately. This is a storage convention, not an MDL optimum, effective degrees of freedom, or Fisher rank.

[Coefficient intervals](evidence/frontier/coefficient-intervals.csv) solve the lower-envelope inequalities over every nonnegative penalty coefficient. The largest coefficient at which a nonconstant model remains preferable before the constant endpoint takes over is approximately 0.002997235, below the frozen 0.005. Some Pareto candidates never lie on this lower envelope. Some previous-record models are Pareto candidates; the one-class previous-record model lies on the envelope for seed 4307 at budget 128. Thus memory is not uniformly dominated, even though the frozen criterion rejects it in all nine fits. This retrospective sensitivity supplies no new justified coefficient.

The [held-out table](evidence/frontier/heldout-frontier.csv) has 294 rows: six environment/policy cells for each primary-frontier candidate and the named base endpoints. Each cell remains visible. The binary Brier convention is (p(+1)-1{e=+1})². Paired comparisons use complete four-event episodes, with SD and SE conditional on fitted models. They are descriptive: no selection-adjusted confidence interval or fresh confirmation is claimed. The three seeds, three policies, and three budgets are not independent physical replicates.

![Validation loss versus two separately declared resources](evidence/frontier/loss-resources.png)

The [vector figure](evidence/frontier/loss-resources.pdf) shows the primary frontier with circles in both rows; the storage panels do not claim a separately optimized storage frontier. Full numerical and statistical definitions are in [frontier-analysis.md](frontier-analysis.md).

## Preparation-information loss and fitted discrepancy

The [independent reconstruction](reconstruction.md) derives the finite identity under fixed training data, one evaluation preparation, common action/record-history policies, normalized path laws, and positive fitted support on the true evaluated paths:

\[
H\{R(Q,h)-R(P,\operatorname{id})\}
=I(Y_0;V\mid h(Y_0))
+\mathbb E_Z D_{\mathrm{KL}}(P(V\mid Z)\Vert Q_Z).
\]

The proof factors each path into common policy probabilities and record predictions, cancels the policy factors, and inserts the conditional fine law P(V|Z) into the likelihood ratio. It requires neither Markov closure of h(Y_t) nor a mean-field recognition law. Hidden-state-aware actions need a different conditioning contract; the checker supplies a counterexample to the unrestricted formula. The same-preparation oracle maintains the full fine posterior initialized uniformly within the retained fiber. It has the same initial information as the fitted parent but is not a compressed implementation.

The [attribution table](evidence/frontier/preparation-attribution.csv) has all six cells for 38 candidate instances fixed before oracle inspection: both base endpoints and at most three distinct nonendpoint validation-frontier partitions per dataset. Their [58,368 paired episode triples](evidence/frontier/attribution-episodes.csv) are retained. Each oracle uses its cell's environment kernel; fitted models remain frozen from original-environment training. Reversed-environment mismatch therefore includes distribution shift.

The following descriptive means weight the three seeds and three policy cells equally within each budget/environment. Values are nats per event. Preparation difference is same-preparation oracle minus full-preparation oracle; mismatch is fitted model minus same-preparation oracle. These are signed sample differences, not computed population mutual information or KL.

| Budget | Environment | Constant preparation difference | Constant mismatch | Identity mismatch |
| --- | --- | ---: | ---: | ---: |
| 32 | Original | 0.004202395 | 0.001594337 | 0.008544239 |
| 128 | Original | 0.004717651 | 0.000759880 | 0.001122602 |
| 512 | Original | 0.005951605 | 0.000848035 | 0.000550766 |
| 32 | Reversed couplings | 0.003270787 | 0.000267250 | 0.008498033 |
| 128 | Reversed couplings | 0.004184645 | 0.000148000 | 0.003160146 |
| 512 | Reversed couplings | 0.003664495 | 0.000439193 | 0.001721525 |

At budget 512 in the original environment, 0.005951605+0.000848035-0.000550766 gives the retained fitted-identity advantage of approximately 0.006249 nats/event. Its declared complexity charge is 0.020. At budget 32, the fitted identity's larger mismatch reverses that advantage. The data support this accounting on the saved episodes; they do not isolate independent causal contributions from estimation, closure, or memory within the mismatch term.

![Preparation attribution on individual seed and policy cells](evidence/frontier/preparation-attribution.png)

The [vector figure](evidence/frontier/preparation-attribution.pdf) retains negative sample differences. Neither component was clipped to manufacture population nonnegativity.

## Structural aliasing and memory coverage

The [local derivation](local-contract.md) and independent reconstruction prove that source-fiber row diameter d_f implies worst shared-row error at least d_f/2 by the TV triangle inequality. This is a lower bound, not a universal claim that the minimax radius equals half the diameter. Exact [structural diagnostics](evidence/frontier/structural-diagnostics.csv) contain 76 comparisons for the bounded attribution subset in the two environments, separating d_f, its floor, fitted oracle_error, and a maximizing witness.

For the constant map, original-environment diameter is 617/2240 and its floor is 617/4480, approximately 0.137723. The reversed assignment gives diameter 149/560 and floor 149/1120, approximately 0.133036. These quantify intrinsic all-preparation incompatibility. They are not average prediction errors. The identity map has zero intrinsic diameter while its fitted rows can still have substantial uniform error. A previous-record index leaves the full fine fiber used by oracle_error unchanged, so it cannot remove this certificate under those quantifiers.

A separate analytical calculation gives

\[
\mathbb E[E_{\mathrm{next}}\mid y,a]
=\frac{\eta P(y)}4
\left[aM(y)+2\sum_{i<j}J_{ij}y_i y_j\right].
\]

All-positive and all-negative preparations have first-record TV 3/20 for either fixed field sign, hence any retention merging them has a shared first-response floor 3/40. The constant map necessarily merges them. A common uninformative initial memory cannot distinguish them, and later records cannot restore a lost first response in an all-preparations path claim. The stronger diameter values above are compatible with this separate two-preparation witness.

The [coverage tables](evidence/frontier/coverage-summary.csv) distinguish 36b pooled base transitions from 3b previous-record-conditioned transitions. At b=512,k=16, 64 conditional rows average 24 observations, yet 28, 31, and 30 rows have fewer than ten observations across the three fits; one fit retains a zero-count row. At b=32 the zero-row counts are 24, 27, and 23. Rejection of these models therefore does not identify memory's intrinsic value separately from conditional-data scarcity.

![Conditional row occupancy](evidence/frontier/memory-coverage.png)

The [vector figure](evidence/frontier/memory-coverage.pdf) uses occupancy ranges, not uncertainty intervals for a population parameter.

## Locality result and next action

The next spatial contribution is a typed contract, not a learned local parent. It includes all fifteen nonempty child subsets and one exterior-independent local map per subset. The normalized adapter treats (field, current exterior) as its input and tags the next exterior and boundary record as a STEP output. A disjoint noninformative START symbol supplies initial API typing without inventing a time-zero exterior observation. The full parent distinguishes response sample, singleton model presentation, random exterior interface, and singleton generative memory, together with common pushes of the generative, posterior, and correlated recognition laws. Static conditional and controlled transition evaluators have separate input types. Fitted replacement introduces a signed mismatch correction to the exact common-push VFE identity.

Independent reconstruction confirms that strong exterior-compatible local maps compose on the full Cartesian fine carrier by replacing source blocks one at a time and pushing each equal joint output law. The product premise is now explicit; a constrained-carrier counterexample records why it matters. Initial-sensor descent and common retained-history policies remain separate hypotheses. Correlated joint laws and the original one-site schedule are preserved.

The single justified next phase is the [fifteen-subset exact local-admission ticket](next-stage-contract.md). Its outcomes are exact local compression certificates or an identity-only/no-compression result under the declared strong interface. No class counts for that phase were computed. Statistical spatial selection, sensor changes, and fresh confirmation are subsequent decisions. A unique preferred parent still requires an externally justified predictive tolerance or resource preference; the frontier is the present result.

## Bounded prior-art positioning

Tishby, Pereira, and Bialek formulate compression relative to a supplied predictive variable, using mutual information in their information-bottleneck functional (Section 3, Eq. 15). That motivates making the predictive target explicit. The present finite training-derived ladder and log-cardinality penalty do not optimize that functional. [Primary paper](https://arxiv.org/pdf/physics/0004057).

Shalizi and Crutchfield define causal states through conditional future distributions and develop predictive minimality in their stationary discrete-time process setting (Sections III and IV). Their history-state result is not a theorem that the present controlled deterministic quotient is a smallest arbitrary hidden-state realization, nor a spatial or gauge-parent construction. No theorem is imported without those extra hypotheses. [Primary paper](https://arxiv.org/pdf/cond-mat/9907176).

These two sources were consulted for bounded positioning, not a systematic survey. The Research wiki's [Coarse Graining](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Coarse Graining.md>) page was consulted read-only for its distinctions between same-law reduction, model replacement, and partition selection. Current repository artifacts govern completed formation status.

## Evidence and limits

Four small scripts ran serially under pinned CPython 3.14.7 and exited zero; [execution.json](evidence/frontier/execution.json) records commands, source hashes, and scope. Direct checks include the 288-score/nine-model reconstruction, a two-event exact hidden sum 19682267/80281600 matching floating filtering, 64 exact reset-response equalities, 32 normalized singleton-adapter rows with START handling, and 76 exact structural-floor inequalities. The adapter check is a small row-construction check, not full fifteen-subset admission. No pytest ran in this session; the retained seven-test JUnit belongs to the earlier experiment. Accurate terminal summaries are retained, but raw stdout was not saved as a separate file.

Function annotations were added after execution without changing calculation bodies; the final four scripts passed static compilation and completed science was not repeated. The three standalone PDF/PNG figures were visually inspected. The final input and output inventory is recorded by the completion inspection. The disabled verification skill was not reactivated; these are explicit derivations, independent reconstruction, and executed numerical evidence, without a formal ledger certificate.

The session used the three requested substantive rounds and has no remaining required first-session calculation. Population precision, a uniquely preferred resource tradeoff, intrinsic memory utility, and heterogeneous local compression remain unresolved at the scopes explained above. The retained observations and all excluded work remain untouched.
