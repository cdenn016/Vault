# Collective-response interfaces on the actual selected hierarchy

September 12, 2026. This construction uses each realized generative ancestry H as the actual first geometric partition, then applies the existing normalized agreement panel to every H. Retaining one four-vector residual per selected merger-tree edge preserves all first-parent cut responses. The complete second output has 12+4(k+q) displayed real coordinates, where k and q are the first and second block counts. The construction extends through any finite sequence of the same forest contractions while preserving the advertised historical cut queries.

The result concerns exact access to the declared anchored response evaluator. Its error relative to actual fine-state responses remains a separate coherence question. Unlike the earlier fixed-P probe, the available first-parent input ports and cut labels here depend on H.

## 1. Source continuity, supplied model, and exact target

Live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), section `sec:epistemic_collapse`, rejects perfect pointwise consensus as the formation target. Its equation `eq:rg_closure` and following discussion separate scalar closure from an independently required derivative bound. The [meta-agent wiki](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires a joint law, evaluator, boundary access, structural marks and sufficient memory. These are the source requirements being addressed, not premises that certify the answer.

The executable mathematical inputs are [common-prior native episodes](common-prior-native-hierarchy-episodes.md), Section 4, for the exact all-H panel; [complete parent channels](shared-parent-complete-channel-and-recursive-cost.md), Sections 3–7, for geometric composition and native sufficiency; and [transported parent priors](transported-parent-priors-and-induced-couplings.md), Sections 2–4, for the current generator and energies. The [fixed-P response interface](native-response-parent-interface.md) supplies the two-parent example generalized below. [Native response-law bounds](native-coherence-response-law.md) concern a different, fixed-P probe, so their numerical constants do not automatically apply to the present H-dependent query task.

Fix one base point, the directed four-cycle 01,12,23,30, and two two-dimensional translation-family Gaussian law-mean channels b,m. Each displayed geometric vector has four real coordinates. The unchanged generative joint first draws one of the forty-five decorated connected ancestries H, with k=k(H) blocks, roots r_A, internal trees, and masses n_A=|A|. Its original prior, recognition family, observations and native dynamics remain unchanged.

The first geometric output now uses exactly this H. With g_i the signed internal-tree path from r_A to i, define

\[
 z_A=\frac1{n_A}\sum_{i\in A}(\mu_i-g_i),\qquad
 V_e=\ell_e+g_i-g_j,\quad e=(i,j),\quad i\in A,\ j\in B.
 \tag{1}
\]

Every original non-tree copy is retained individually. For k>1, the proper connected blocks are paths on the four-cycle, and there are k interblock cuts forming a directed quotient cycle. For k=2 the two opposite-direction cuts remain distinct. For k=1 there is one internal loop mark and no interblock cut.

Let S=(H,p_8,E_a,E_b,E_c,E_v), where p contains all original labeled probabilities and the energies use the actual H-dependent transported generator. In particular the E_a statistic is not recomputed after geometric merging. The first carrier C0 is S plus the k barycenters and k marks, with displayed real count N0=12+8k.

For each first cut e:A→B, set

\[
 d_e=z_B-z_A-V_e,\qquad
 a_e^x(C_0,u)
 =\operatorname{clip}_{[0,1]}
 \left[p_e^x(0)+\phi(d_e^x+u_B^x-u_A^x)-\phi(d_e^x)\right],
 \quad \phi(v)=e^{-\|v\|^2/2}.
 \tag{2}
\]

The old first-parent agreement probabilities are phi(d_e^x). The input u assigns a four-vector to each actual first block, with links held fixed. All historical query anchors in this report remain the corresponding original p_e^x(0).

The exact target is quantified over every H, every finite fine configuration on that branch, every panel mask, every original first-cut label and channel, and every collective input u. Construct a second carrier from the actual first carrier that evaluates (2) and all phi(d_e^x) exactly, composes with the actual geometric maps, and preserves native law sufficiency and correlated downward recovery. Give explicit storage and interface costs. No global minimality, improved physical force, or new learned grouping is assumed.

## 2. The unchanged normalized panel, including the one-block case

Use the actual rule in the native-episode source. For every first cut e, its conditional active probability is

\[
 \gamma_e=\phi(d_e^b)\phi(d_e^m).
\]

Draw the cut flags independently conditional on C0. Form their connected components, choose a spanning forest by increasing original edge label, and root each new component at the smallest first-root label it contains. Retain the flags, chosen forest and incidence history. There is no special branch testing whether H is the two-pair ancestry P.

For k>1 a flag mask m has probability

\[
 K(m\mid C_0)=\prod_{e\in E_H^{\rm cut}}
       \gamma_e^{m_e}(1-\gamma_e)^{1-m_e},
 \qquad
 \sum_m K(m\mid C_0)=1.
 \tag{3}
\]

At endpoint probabilities use the direct Bernoulli convention rather than ambiguous zero powers. The normalization follows by multiplying the k identities gamma_e+(1-gamma_e)=1. This kernel is parameter independent and is an auxiliary readout, not an added observation or a new generative prior.

Let q be the number of second components and F the selected forest. Then |F|=k-q. The first tree edges together with F form the actual flattened fine forest. There are q remaining original mark copies.

When k=1, take the unique empty mask, q=1, and F empty. The interparent response interface has no eligible cut. A query for an ineligible label returns a deterministic null symbol bottom, not a fabricated Bernoulli boundary response. Original record evaluation from p_8 still exists. This null rule applies to a first hierarchy with k=1. It does not erase the old input ports when k>1 subsequently merges to q=1.

The decoration counts are 16,20,8,1 for k=1,2,3,4. Therefore the panel has 16+20·4+8·8+1·16=176 decoration/mask cases. The algebra below covers every case, including masks that can have zero probability at exceptional configurations.

## 3. A forest basis that reconstructs every old cut residual

Let C(A) be the second component containing first block A, with mass M_C=sum_{A in C} n_A. Define t_A as the signed sum of old V links along F from the new root of C to r_A. Its value is zero at that root. The existing second geometry is

\[
 z_C=\frac1{M_C}\sum_{A\in C}n_A(z_A-t_A),\qquad
 V_e^+=V_e+t_A-t_B,\quad e:A\to B.
 \tag{4}
\]

For selected forest edges, V_f^+=0. Every other original cut copy retains its own V_e^+, whether it is now an external cut or an internal loop. Define merger contrasts

\[
 \chi_A=z_A-t_A-z_{C(A)},\qquad
 \sum_{A\in C}n_A\chi_A=0.
 \tag{5}
\]

These contrasts are distinct from both the native primitive block noise and the fine child contrasts considered below.

For a selected edge f:A→B, (4) gives t_B-t_A=V_f. Consequently

\[
 d_f=z_B-z_A-V_f=\chi_B-\chi_A.
 \tag{6}
\]

Retain precisely these |F|=k-q old residual four-vectors d_f. They determine every chi_A. To see this constructively, choose the new root A_C of each component and set

\[
 b_A=\sum_{f\in\operatorname{path}_F(A_C,A)}
           \operatorname{sgn}(f,A_C\to A)d_f,\qquad b_{A_C}=0,
\]
\[
 \overline b_C=\frac1{M_C}\sum_{A\in C}n_A b_A,\qquad
 \chi_A=b_A-\overline b_C.
 \tag{7}
\]

The tree-path difference b_B-b_A equals d_f on each selected oriented edge. Weighted centering gives (5). A second solution with the same edge differences differs by a constant on each connected tree; its weighted mean fixes that constant to zero. Thus (7) is the unique reconstruction.

For any old cut e:A→B, put C=C(A), D=C(B) and define

\[
 D_e=z_D-z_C-V_e^+.
\]

Use V_e^+=0 for a selected edge, making D_e=0 there. Substitution of (5) proves the decoder

\[
 \boxed{d_e=D_e+\chi_B-\chi_A.}
 \tag{8}
\]

For an internal non-tree edge C=D and D_e=-V_e^+. For a surviving cut, D_e is available from the second means and that individual dressed mark. Equation (8) recovers every first-cut vector globally, with no norm inversion, reflection ambiguity, exceptional branch choice, or hidden fine-state decoder.

For k>1, the quotient-cycle identity also gives

\[
 \sum_{e\in E_H^{\rm cut}}d_e=-L,\qquad
 L=\sum_{e\in E_H^{\rm cut}}V_e
   =\sum_{e\notin F}V_e^+.
 \tag{9}
\]

At q=1 the forest has k-1 edges, and (9) recovers the last residual from the k-1 stored vectors and the final loop. At q>1 it is unnecessary to retain k-1 vectors: the surviving geometric means and marks already provide additional relations. The k-q forest vectors suffice.

There is an exact geometric-coordinate check on this economy. For each fixed discrete branch, the first geometric variables are in bijection with

\[
 \left((z_C)_C,(V_e^+)_{e\notin F},(d_f)_{f\in F},
                      (V_f)_{f\in F}\right).
 \tag{10}
\]

To invert, obtain chi from (7), obtain t from the supplied V_f along F, set z_A=z_C+chi_A+t_A, and set V_e=V_e^+-t_A+t_B for nonforest edges. This reconstructs every first mean and link, and direct substitution verifies both round trips.

Thus the chosen decoder does not secretly retain the old merger-tree links; those are exactly the additional geometric quantities needed for full first-geometry reconstruction. The forest differences form a basis for the unrestricted weighted-zero contrast space, of dimension 4(k-q). This is a minimal linear basis for that contrast space independently of S, not a lower bound for all encodings using the nonlinear probability and energy information in the complete carrier.

## 4. Actual composition and translation covariance

The complete second output is

\[
 C_1=
 \left(S,(z_C)_C,(V_e^+)_{e\notin F},(d_f)_{f\in F},
          m,F,\text{roots, masses, labels and port history}\right).
 \tag{11}
\]

It is a function of the actual C0 and the realized panel mask. To compare direct and staged construction, for each fine child i in first block A define the flattened path g_i^+=g_i+t_A. Then

\[
 \frac1{\sum_{A\in C}n_A}
   \sum_{A\in C}\sum_{i\in A}(\mu_i-g_i^+)
 =\frac1{M_C}\sum_{A\in C}n_A(z_A-t_A)
 =z_C.
 \tag{12}
\]

For each surviving original edge e=(i,j),

\[
 \ell_e+g_i^+-g_j^+=V_e+t_A-t_B=V_e^+.
\]

The direct d_f is the old first-barycenter residual defined by (1)–(2); it equals the value retained before deletion. S and all history records agree identically. These calculations prove direct/staged equality component by component for every H and mask.

Under passive child-frame translations h_i^g, the first quantities obey z_A'=z_A+h_{r_A}^g and V_e'=V_e+h_{r_B}^g-h_{r_A}^g. For a second root r_C,

\[
 t_A'=t_A+h_{r_A}^g-h_{r_C}^g,\quad
 z_C'=z_C+h_{r_C}^g,\quad
 (V_e^+)'=V_e^++h_{r_D}^g-h_{r_C}^g.
\]

It follows that chi_A,d_e,D_e are invariant. Panel probabilities are invariant, so the same labeled flag/tree construction commutes with passive frame change. As in the native source, generative offsets and reference laws must be pushed coherently; a fixed centered Gaussian measure is not translation invariant.

The active query inputs u_A act on the first block means with links held fixed. Their edge input is u_B-u_A. In the translation specialization these tangent vectors need no additional frame matrix. The old first ports remain identified by H after merging. A uniform shift on an entire second component is only a restricted case of this larger historical input interface.

This is not a GL(K) theorem, a proof that physical fine-state actions descend, or a rule for updating the original p anchors after an intervention. The queries use a frozen preparation and absolute input requests. Clipping sequential increments need not be associative, so the anchored evaluator is not promoted to an action group or sampled-state dynamics.

## 5. Normalized query equality despite geometry-dependent selection

Decode d_e from (7)–(8) and evaluate (2). Every old phi(d_e^x), gamma_e and anchored response probability agrees pointwise between C0 and C1. In particular, although selection depends on the full first geometry through its d values, every probability used by the panel remains evaluable after selection. The actual mask and forest are retained.

Use the query alphabet {0,1,bottom}. An ineligible original label returns bottom with probability one. An eligible cut/channel returns Bernoulli a_e^x from (2), whose probability lies in [0,1] by clipping. This defines a measurable normalized kernel on every H, including k=1. A first-cut label stays eligible after it becomes internal to a second component: its two old ports remain in the interface.

For every finite K, consider a policy using only advertised common retained information, the retained panel outcome, preceding query answers and shared policy randomness. Couple the policy randomness and the Bernoulli uniforms between the first and second representations. The first answers agree because their probabilities and validity rules agree; induction makes all selected labels, inputs and answers agree. Thus the complete conditional transcript laws are equal, for each fine X and realized mask. Integrating against any native law and its normalized panel preserves that equality. Conditioning on any positive-probability event measurable in the retained selection history preserves exact equality too.

Arbitrary policies that inspect discarded first-geometry fields are not included without carrying the necessary controller information. The coordinate splitting (10) makes this limitation explicit. Nor does equality of the anchored query imply equality with the true fine response: (8) recovers old barycenter residuals, not the omitted child contrast.

## 6. Native sufficiency, joint correlations, and the remaining approximation

The fine space is the finite disjoint union of its 36+4k-dimensional primitive Gaussian branches. Take a unit-variance transported reference with positive mass on every H, then augment it with the same panel K. Denote this normalized joint reference by R_*.

The native model, recognition and original posterior density ratios relative to R_* are functions of S alone: their Gaussian energy factors use E_a,E_b,E_c,E_v and k(H), and their original likelihood factor uses p_8. The output (11) retains S. The generative block count in these ratios is never replaced by q. The H-dependent coordinate change and the already normalized panel introduce no new learned factor.

The disintegration fact needed here is precise: a probability on a standard Borel space and a measurable map to another standard Borel space admit a probability conditional kernel whose integration reproduces the original probability and whose mass lies on the corresponding fibers almost everywhere. Finite unions of Euclidean primitive spaces, finite structural catalogs and the coordinate targets here satisfy those hypotheses.

Let Psi(dX,dm|C1) be that conditional for R_*. Multiplying the defining disintegration identity by any normalized S-measurable native tilt proves that the same Psi reconstructs every native model, recognition law and original posterior from its pushforward. Consequently the joint relative entropy and original negative ELBO are unchanged. Under the existing positive-parameter differentiability and moment hypotheses, native scores remain S-measurable, so their Fisher second moments and native law evolution are also unchanged.

Disintegrating the augmented reference at successive retained levels gives normalized reverse kernels whose composition reconstructs the fine native family. These are full correlated conditionals, possibly singular on geometric constraint sets. There is no product reset, independent-parent entropy substitution, posterior-specific fitted decoder, or claim that conditional evaluation is cheap.

For clarity, define fine child contrasts separately:

\[
 \delta_i=\mu_i-g_i-z_A,\quad i\in A,\qquad
 \eta_e=\delta_j-\delta_i,\quad e=(i,j),\ i\in A,\ j\in B.
\]

The true fine residual satisfies

\[
 r_e=d_e+\eta_e.
 \tag{13}
\]

Retaining merger contrasts chi through the forest records does not determine eta. The [coherence certificate](coherence-response-bound.md) bounds eta from the actual first internal trees and retained p. Its anchored-query argument gives, whenever ||u_B^x-u_A^x||<=R,

\[
 |p_e^x(u)-a_e^x(u)|
 \le c_R\|\eta_e^x\|,\qquad
 c_R=\min(R,2e^{-1/2}).
 \tag{14}
\]

This comes from the Gaussian Hessian bound and nonexpansiveness of clipping relative to a probability target; it is not a consequence of preserving the scalar native VFE.

For arbitrary adaptive old-cut/channel choice, set rho(X)=max_{e,x}||eta_e^x|| over actual first cuts, and rho=0 when k=1. The same first-mismatch coupling gives the full-law bound E_Q[min(1,K c_R rho(X))]. Since the old query domain is preserved on every second branch and sum_m K(m|X)=1, this unconditional envelope requires no independence from the panel. A conditional-on-selection bound must instead use the actual selected conditional law. A simple, possibly loose moment envelope is E_Q sum_{e,x}||eta_e^x||².

The H-dependent omitted vectors and valid-label domain are different from the fixed-P probe. Its old numerical moment constants cannot be copied here. A null response at k=1 contributes no mismatch because both representations reject that request; this is not evidence that a one-block hierarchy answered an otherwise missing boundary question accurately. When k=4 the first blocks are singletons and eta is exactly zero on every first cut. The other shapes require their actual first-tree contrast moments.

## 7. Finite-depth preservation of historical interfaces

The construction can be repeated for any finite sequence of possible outcomes of the same normalized forest rule. Let k_0,k_1,...,k_L be the component counts, with the original realized first ancestry having k_0=k. At stage ell retain the first-parent cut residual d_f^{ell} on each newly selected edge f of F_ell, before its arguments are discarded. Keep all earlier response records and the actual stage/port/edge history.

To decode backward from stage ell+1 to ell, form that stage's contrasts chi_A^{ell} using its stored forest residuals and masses by (7). For each old cut e there are three cases. If e is selected into F_ell, its new residual D_e is zero. If it remains a next-stage cut, D_e is the corresponding next-stage cut residual. If it becomes an internal non-tree edge, D_e=-V_e^{ell+1}, and that loop mark is carried forward. In each case,

\[
 d_e^{ell}=D_e+\chi_B^{ell}-\chi_A^{ell}.
 \tag{15}
\]

The final geometry supplies final cut residuals and all surviving loop marks. Induction using (15) therefore reconstructs every historical advertised cut residual, even though old merger-tree links are absent. In this translation family an internal loop is invariant under subsequent changes of root, and every original edge copy remains individually identified. The argument does not average parallel edges or change ancestry.

This gives exact query equality for any fixed finite historical catalog, with its declared original anchors, stage-specific input ports and common counted controller. It preserves all native conditional correlations by the same reference-disintegration induction. Each added forest record is available from the actual retained preceding output, so no fine access is introduced at a later stage.

The total number of stored response vectors telescopes:

\[
 \sum_{\ell=0}^{L-1}|F_\ell|
 =\sum_{\ell=0}^{L-1}(k_\ell-k_{\ell+1})
 =k_0-k_L.
 \tag{16}
\]

Hence the final displayed count is

\[
 N_L=12+8k_L+4(k_0-k_L)=12+4(k_0+k_L).
 \tag{17}
\]

This preserves historical queries, not a constant error bound for newly defined current-parent inputs. A new current-parent approximation has a different fine contrast, including the intervening merger contrasts; it needs the appropriate finite-depth response certificate or a new law-level majorant. Reusing an old historical query has exactly its old evaluator and error, but changing its ports is a different task. A final one-block state may have no new current cuts while retaining many legitimate historical cuts.

Equation (17) does not bound all memory uniformly in L. Structural histories, repeated no-merge panel records, stage identifiers and arbitrary controller transcripts can grow even when no new real response vector is added. No infinite-depth attraction, physical lifetime or sampled-state path law follows.

## 8. Complete displayed counts and explicit resource limits

For one panel, the count is

\[
 N_1=12+8q+4(k-q)=12+4(k+q).
 \tag{18}
\]

The entries include the k=q=1 carrier with its null interparent response interface.

| First k | Second q | Displayed real fields | Saving versus fine 36+4k |
| --- | --- | ---: | ---: |
| 1 | 1 | 20 | 20 |
| 2 | 2 | 28 | 16 |
| 2 | 1 | 24 | 20 |
| 3 | 3 | 36 | 12 |
| 3 | 2 | 32 | 16 |
| 3 | 1 | 28 | 20 |
| 4 | 4 | 44 | 8 |
| 4 | 3 | 40 | 12 |
| 4 | 2 | 36 | 16 |
| 4 | 1 | 32 | 20 |

Every successful contraction saves four real coordinates relative to the preceding complete response carrier. The selected first-parent scalar-only augmentation in the source stored 12+8q+2k fields when q<k. The new-minus-old difference on such branches is 2k-4q: the counts agree for k=2,q=1; partial mergers can store fewer fields than that scalar catalog; complete roots with k=3 or 4 require respectively two or four more fields. The old scalar probabilities are computed from reconstructed vectors rather than retained again.

Subtracting (18) from the correct fine branch dimension gives the fresh full-law identity

\[
 \mathbb E[N_{\rm fine}-N_1]=24-4\mathbb E q.
 \tag{19}
\]

For the existing O/P reference, q=2 only in P_split, so (19) is 20-4Pr(P_split). The [saved regime-window record](evidence/joint-native-episode/regime-window-enclosures.json) bounds the late-window split probabilities above by

\[
 U_Q=
 \frac{159978436666380997144230744043547521983}
      {340282366920938463463374607431768211456},
 \quad
 U_\Pi=
 \frac{159190668892750365980513968648004414417}
      {340282366920938463463374607431768211456}.
\]

Both are strictly below one half. Thus the present expanded selected-interface map saves more than 18 displayed real fields in expectation under either complete reference law throughout [35,40]. This conclusion is derived from the split probabilities and (19), not from the old resource-license field. Continuity of the actual native joint law and finite normalized panel preserves the strict coarse inequality on a sufficiently small nonempty relative-open family of priors positive on all twelve ancestries. The narrow reference numerical ranges are not transferred to that family.

This is a displayed-storage statement. The shared H/p/energy catalog, original labels, port memberships, roots, masses, full masks, forest incidence, historical stage identifiers, native parameter memory, evaluator instructions, reference-law representation, moment calculations, reverse recovery, controller memory and any transcript are still charged. A fine implementation can compile the same response evaluator. None of these costs is free because normalization has a mathematical definition.

The decoder integrates along a forest and forms mass-weighted centers. It can compute endpoint contrasts on demand or cache them. Caching every first chi_A costs four values per first block before eliminating redundant centers; caching each historical phi(d_e^x) costs two values per corresponding edge. Such caches are optional additions, not hidden parts of (18) or (17). A query then needs the retained original anchor, reconstructed endpoint residual, input difference, two Gaussian radial evaluations and clipping.

If c is the per-real storage price, the bare first-to-second saving is 4c(k-q). Deduct the actual additional formation, history, decoding, caching, controller and workload costs before making a net saving claim. The earlier complete workload license does not transfer unchanged when the stored catalog and evaluator have changed. Exact vector access, native metric sufficiency and a lower sample count are not a proof that persistent intermediate agents are preferable.

## 9. Checkable evidence and the next obligation

The associated new [exact map calculation](evidence/selected-hierarchy-response/response_maps.py) ran once under pinned CPython 3.14.7 and returned [PASS_SELECTED_HIERARCHY_RESPONSE_MAPS](evidence/selected-hierarchy-response/response-maps.json). It checked 68 omitted-residual identities on all 45 decorations and the new forest-response decoder and augmented-map composition on all 176 saved panel cases. It also checked the counts in (18)–(19), the two-pair omitted-vector identity and zero first-level omission for k=4. Its calculation time was 0.07183760000043549 seconds. It read the existing geometry rather than rerunning that program's main calculation or any trajectory.

The script SHA-256 is `11e62c661cd05b8bbe99a9534e862eea607fe86dd23c0db1f83d07801023b397`; the result SHA-256 is `22bb9a9fa67adb7be128868718d79f47cf393fc619359f3b976191cd5c0131c9`. These identify the executed artifacts. The general normalized-kernel, covariance, disintegration and finite-depth arguments are the written proofs above; finite arithmetic checks alone do not establish them.

This assignment writes only this derivation. No old scientific run, test suite, ODE, new prior, new observation, Lean, tamper check or additional delegation was performed for it.

The strongest result is an exact, all-H, all-panel-branch extension of the actual selected hierarchy's response interface, with the explicit forest decoder, native-law preservation and finite-history count (17). The companion [actual-hierarchy error proof](selected-hierarchy-response-law.md), Sections 5–6, now supplies the separate law-level certificate for first and newly admitted historical/current ports. It constructs the actual-contrast moment majorant, proves its reference comparison, and retains null-domain semantics and selection conditioning; the fixed-P result is not merely relabeled. The remaining practical obligation is a priced workload and loss requirement for the decoder and historical ports. Neither net resource benefit nor operational selection follows from the displayed sample count.
