# Complete resource frontier for the native merge episode

September 12, 2026. The current transported Gaussian family admits a complete, lossless resource comparison during its certified native merge episode. An adaptive two-stage carrier retains every ancestry, every original record probability, all four learned-prior energies, the required geometry and the four new pair-cut evaluators. It saves more than eighteen real-valued fields per resident draw on a nonempty open family of fixed positive ancestry priors throughout native times 35-40. This is an expected storage bound for a specified representation, not a bit-complexity or runtime claim.

A coupled generator gives both the fine and parent implementations the same residual-first rejection, conditional Gaussian reduction and native moment solver. Exact straight-line coefficients price their remaining generation and geometry work. They yield a conditional net resource license for a sufficiently reused resident-state workload, including finite setup overhead. The likelihood alone does not select this workload or its prices. Nor can the parent have an intrinsic computational advantage over a fine implementation allowed to return the identical sufficient representation. These limitations prevent a declaration that useful endogenous hierarchy formation is complete.

## 1. Existing construction and comparison contract

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, requires the net improvement after organizational overhead. It leaves the post-merge replacement functional and complexity choice unresolved; its strict Gaussian barycenter coordinate does not supply that license. The operational [wiki definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires a joint law, evaluator, boundary access, structural marks and memory. These are requirements of the comparison, not cost-free names for a pair of marginal beliefs.

The [complete channel](shared-parent-complete-channel-and-recursive-cost.md), Sections 2-7, supplies the sufficient statistic, geometry, access and finite-depth composition, including the four new cut evaluators needed after the pair merges. The [transported prior](transported-parent-priors-and-induced-couplings.md), Sections 2-4, supplies the actual Gaussian child generator. The [exact parent generator](exact-parent-generation-and-residual-cost.md), Sections 2-7, supplies the staged rejection and radial quotient. The [unit-start episode](unit-start-second-merge-and-positive-prior-persistence.md), Sections 5-6, supplies the actual native interval and its proper-prior continuation. No earlier trajectory or likelihood integral is recomputed here.

Freeze a recognition state at a native time in [35,40], with likelihood power one and the matched root. A draw is retained while answering a finite sequence of the already admitted original labeled Bernoulli queries. Repeated queries use the same latent probabilities. A controller can choose labels from the shared observed history; its state is retained and charged equally in both implementations. The complete hierarchy additionally exposes its present barycenters, retained loop/cut marks, label/incidence catalog and the pair-cut probability evaluators described below. It does not promise arbitrary recovery of discarded child coordinates.

This is a workload on a frozen law. Native parameter evolution is the existing exact moment-based learner; it is not implemented by treating a retained draw as though it changed law when the parameters changed. No microscopic link trajectory, new observation, online Bayesian filter or physical event schedule is specified by this comparison. A workload requiring those operations needs their additional update and memory costs.

## 2. One normalized adaptive channel, without conditioning on a winner

Write P={{0,1},{2,3}} and let H contain one of the twelve connected ancestries and its existing root/tree decoration. Set k=k(H). The complete first-parent statistic is

\[
 Z_1=(H,p,E_a,E_b,E_c,E_v,(z_A)_A,(V_e)_e).
 \tag{1}
\]

There are eight original probabilities p, four energy totals, 4k barycenter coordinates and 4k individual non-tree link coordinates. Conditional on H=P, evaluate the four two-channel pair-cut probabilities from the actual z and V. For cuts 12 and 30, draw independent active-edge flags with probabilities equal to the product of their two channel probabilities. This is the marginal of the existing independent two-channel flag construction. Keep the two active flags; a non-P branch has a fixed sentinel. This defines a single normalized, parameter-independent kernel K at every parameter value.

If at least one of these two cuts is active, merge the two pair parents. Use cut 12 as the new tree when active, otherwise use the reverse of cut 30. Retain the final mass-weighted barycenter, the single loop mark, and all four pair-cut probabilities. If no cut is active, retain Z_1. All non-P ancestries retain their existing first-parent output. Let S denote the merged-P event. Every ancestry remains in the law; there is no rejection of an accepted non-P draw, posterior truncation or MAP replacement.

The shared discrete catalog contains ancestry, roots, original trees, masses, edge incidence, active flags and the deterministic second-tree convention. Both the augmented fine carrier and the parent carry this same catalog. Physical implementation headers, lookup tables or additional local copies must be charged if they differ. Interface access uses references into shared probabilities and marks; the same cut at two endpoints is not two independent variables or two mandatory stored copies.

Choose a unit Gaussian reference with fixed full-support structural weights. Changing the scientific ancestry prior contributes only an H-measurable ratio. The primitive prior and recognition density ratios relative to this reference depend only on

\[
 S_0=(H,p,E_a,E_b,E_c,E_v).
 \tag{2}
\]

The adaptive carrier always retains S_0. Augmenting the reference by K and then disintegrating over the adaptive carrier therefore gives one conditional reverse kernel for the entire positive-parameter prior, exact posterior and recognition family. To prove this, multiply the reference disintegration by each S_0-measurable density ratio. Each ratio pulls outside the conditional integral. Their scores pull outside as well. Consequently

\[
 F(Q_{\rm parent},P_{\rm parent})=F(Q,P),\qquad
 I_{\rm parent}=I_{\rm fine}.
 \tag{3}
\]

The reference itself is a normalized pushforward with the constructive generator below. The evaluator contract uses Radon-Nikodym densities against this reference, the original normalized record kernels and the existing exact moment formulas. No separate fast Lebesgue-density inversion algorithm is asserted. Requiring such an oracle would introduce another cost obligation.

The four new pair-cut probabilities survive the second channel pointwise. Original and pair-cut Bernoulli responses from a fixed draw therefore survive every finite adaptive query string: couple both implementations to the same independent uniforms, and induct on the identical emitted history. This is a frozen-state query-path result. The retained probabilities are evaluators; they are not four new observations or a new learned likelihood. The weighted barycenter and loop identities in the complete-channel derivation prove direct/staged geometry equality. Child reconstruction is the common correlated conditional, not independent Gaussian resets around the displayed parent.

## 3. A storage margin on the actual native episode

Count real-valued sample fields, excluding the shared discrete catalog and the shared law solver. The fine output (mu_i,Z_A,ell_e,Y) has 36+4k fields. The adaptive carrier has

\[
 N_{\rm parent}=12+8k-4\mathbf1_S,\qquad
 N_{\rm fine}=36+4k.
 \tag{4}
\]

On P the first level has 28 fields; a merged sample has 24. The latter includes eight original probabilities, four energies, four final barycenter coordinates, four loop coordinates and four new pair-cut probabilities. Using twenty at this stage would omit the new evaluators. The per-sample saving is

\[
 d=24-4k+4\mathbf1_S.
 \tag{5}
\]

It is at least eight on every branch and equals twenty on S. Thus, for any full positive-prior law with alpha=Q(S),

\[
 E_Q d=24-4E_Q k+4\alpha\ge 8+12\alpha.
 \tag{6}
\]

In particular alpha>1/2 gives a saving greater than fourteen fields. This uses k=2 on S, rather than treating its ancestry and merge flag as independent.

A stronger margin follows near the certified reference. At the fixed-P reference the existing enclosure gives M_rec(t)>0.5130 throughout [35,40]. Therefore

\[
 E_Qd=16+4M_{\rm rec}(t)>18.052.
 \tag{7}
\]

The model-posterior bound M_model>0.5154 gives a separate margin greater than 18.0616. These expectations are finite sums of positive continuous evidence and readout functions along the continuous native path. Compact-time parameter dependence, with the full count-memory equation retained, gives a neighborhood of the reference prior in which both margins remain strictly greater than eighteen uniformly on [35,40]. Intersect it with the prior family already preserving the merge episode and evidence improvement. The intersection contains a nonempty open set of fixed priors with all twelve entries positive. No numerical prior or neighborhood radius is chosen.

The second channel alone saves 4 alpha fields in expectation relative to retaining every first-parent sample, hence more than two during this episode. This is the extra saving after paying the four new cut-evaluator fields, not a reuse of the first-level count. The reference can prefer P initially; none of these inequalities proves first-level discovery.

These are counts of declared arrays. They are neither minimal sufficient dimensions nor entropy/code-length bounds. Arbitrary real encodings, finite-precision error, variable-length compression and platform allocation change the relevant question. The unchanged seven evolving native coordinates in the transported matched-root parameterization are shared algorithm state, not another per-sample saving.

## 4. A fair coupled generator and explicit remaining work

Give both implementations the existing staged proposal: redraw H on every rejected attempt, test the first channel before generating the second, and draw the accepted visible Gaussian conditional only after both pass. Per coordinate the common visible variable is eta=(epsilon[4],xi[k],V[k],Y), with conditional Gaussian rank 1+2k. Both implementations use exactly this same factorization and can cache the same thirty-one distinct residual covariance maps. Neither is forced to perform a larger dense fine-space factorization.

Let D_H map the four links to the k visible marks, L_H=D_H^T(D_HD_H^T)^(-1), and let U_H have orthonormal columns spanning ker D_H. Across the four coordinate directions, the hidden link dimension is 4(4-k). Set q=2(4-k). Generate q shared radial quantities R_j=-2v_c log U_j. The parent needs only their sum. A specified Box-Muller fine completion additionally draws q angular uniforms, q square roots and 2q trigonometric values, with three multiplications per pair, to produce the hidden Gaussian coordinates t. It then forms

\[
 \ell=L_HV+U_Ht,\qquad
 Z_A=Y+\xi_A,\qquad
 \mu_i=Z_{H(i)}+\epsilon_i+g_i(\ell).
 \tag{8}
\]

The parent instead forms E_a,E_b,E_v, the visible quadratic contribution to E_c and the shared radius sum, and z_A=Y+xi_A+average_A epsilon. Thus the parent pays for its energy and geometry assembly. The full conditional fine baseline is allowed the same analytic radial decomposition; no saved Gaussian variate is priced twice as an additional uniform or elementary function.

The [exact calculation](evidence/resource-license/resource_cost_exact.py) constructs rational orthogonal kernel bases, checks their projector and link-lift identities, and counts the displayed straight-line maps for all forty-five decorations. Normalization constants for the orthogonal columns are precomputed square roots. Assignments and multiplication by one are free in this declared arithmetic convention; any other nonzero scalar coefficient uses one multiplication, and an n-term nonempty sum uses n-1 additions. This is an algorithm count, not an operation lower bound.

The following costs exclude the identical accepted eta, radial uniforms/logs/scales, rejection work and shared preprocessing. They include the remaining energy, barycenter, link and fine-coordinate assembly. The P cases show the actual dependence on root decoration.

| Pair roots | Fine extra multiply/add | Parent extra multiply/add | Fine extra uniform/sqrt/trig |
| --- | ---: | ---: | ---: |
| 0,2 | 44 / 48 | 52 / 60 | 4 / 4 / 8 |
| 0,3 | 48 / 52 | 48 / 60 | 4 / 4 / 8 |
| 1,2 | 48 / 52 | 48 / 60 | 4 / 4 / 8 |
| 1,3 | 52 / 48 | 52 / 60 | 4 / 4 / 8 |

For P, computing the four new probabilities and the marginal active-edge panel costs an additional fourteen multiplications, twenty additions, four exponentials, two uniforms, two comparisons and one Boolean OR in the declared implementation. An actual second merge adds four multiplications and twelve additions for its root barycenter and loop. No independence between this branch cost and its probability is assumed; expected costs weight the complete decorated joint law.

Across all forty-five cases the first-parent extra work is at most 52 multiplications and 80 additions. Therefore the deliberately conservative parent-only bound for all remaining sample assembly and the adaptive panel is

\[
 A_{\max}=70c_{\times}+112c_+
             +4c_{\exp}+2c_U+2c_{\rm cmp}+c_{\rm or}.
 \tag{9}
\]

Here each c is the supplied nonnegative charge for that primitive. Ignoring the fine completion's positive cost makes (9) an upper bound on the parent-minus-fine assembly cost for these coupled algorithms. It does not say that the parent is faster per draw. The augmented fine generator must also produce the same active flags; granting its required geometry/panel calculation for free makes this bound conservative as well. Fine queries may cache probabilities and energies; granting the fine implementation that access without charging its additional sample storage only makes the storage comparison more conservative.

At a frozen state the shared expected rejection work remains bar Z/Z attempts and 8(bar Z+J)/Z Gaussian residual variates, as previously derived. The unit-state bounds of 24 attempts and 236 total parent Gaussians must not be transferred numerically to times 35-40. What is established there is finite, uniformly bounded expected work on each compact prior/path neighborhood: every decorated evidence e_H is continuous and positive, every envelope normalizer is continuous, and their finite positive ratios are bounded on a compact set of positive variances. The existing certified path remains in such a set, as do sufficiently nearby fixed positive priors. No new numerical rejection constant for that episode is claimed.

## 5. Complete workload inequality and its selection boundary

Consider N frozen-law resident draws, each retained for L accounting ticks while serving the declared queries. A tick is a resource-accounting unit, not a physical or native-time postulate. Let c_w>0 charge one real-valued field for one tick. The present theorem also applies to a workload that repeatedly moves the complete state across a boundary at a per-field transmission charge, if the same precise fields and access contract are required.

Use the same native update, normalizer and query algorithm in both implementations. Charge all extra parent setup, static geometry/catalog storage over the workload, conditional-factor preparation, and required backend/interface construction by C_0. It may depend on the chosen fixed law and workload dimensions; it is not declared zero. The controller and shared catalog are the same. If actual representations add different recurring metadata or access costs, add their complete workload charge D. Conditional expected sampling work is finite by Section 4. The construction gives

\[
 E(C_{\rm fine}-C_{\rm parent})
 >18NLc_w-C_0-NA_{\max}-D.
 \tag{10}
\]

The strict inequality is for the open native prior family of Section 3. If C_0 includes a setup component growing with N or L, it must retain that dependence in (10); it cannot be silently amortized away. In the standard case of finite one-time setup B_0, finite extra static storage B_s per tick and recurring metadata/access cost N L d, the explicit sufficient license is

\[
 NL(18c_w-d)-LB_s>B_0+NA_{\max}.
 \tag{11}
\]

For d<18c_w, choose a finite N with N(18c_w-d)>B_s. Every finite L>(B_0+NA_max)/(N(18c_w-d)-B_s) then satisfies (11). This proves a nonempty resource/workload region for every fixed finite primitive and setup charge with that positive storage margin. The ideal shared-catalog construction has d=0; it is a specified comparison, not a prediction that every backend does. All law-evaluator and native-force costs cancel only because the same operations and reductions are available on both sides. An extra filter, absolute-density oracle, new model coordinate or future geometric query is not covered by that cancellation.

By (3), the fine and parent negative ELBOs are equal for the complete pushed family at the same learning state, as are their attainable optima in that family. Thus (10)-(11) yield a strict total-objective improvement if an adopted resource objective charges these operations in common units. They do not derive a conversion from RAM cells or elapsed time into nats, nor the manuscript's conjectured replacement of pairwise coupling terms. Original-data evidence improvement along the native trajectory is shared by the fine implementation and must not be counted a second time as a coarse-graining benefit.

A hard selection of S is a different operation. Its recognized support loss remains KL(Q(.|S)||Q)=-log alpha and TV=1-alpha; the fixed-model optimum restricted to S costs -log beta, where beta is its model-posterior mass. The full adaptive carrier incurs none of these support losses. The two penalties cannot be substituted for each other or for the difference of finite-recognition negative ELBOs.

There is also a precise limit to what a fair cost comparison can establish. If the fine algorithm class is allowed to emit this identical complete sufficient carrier, it contains the parent algorithm itself. Consequently its optimal cost is at most the parent cost. No theorem can make the parent strictly cheaper than every such fine implementation. The saving is obtained by using the exact quotient instead of retaining the full latent sample. Native learning supplies a changing preferred geometric branch; it does not manufacture a new computational primitive unavailable at the fine level.

For only the original labeled queries and native parameter scores, S_0 already suffices. It has twelve continuous coordinates plus H. Keeping barycenters and loop/cut geometry is justified by the additional complete-hierarchy access contract, not by the original likelihood alone. Requiring all future microscopic geometry instead would invalidate the reduction. These distinctions are part of the resource license rather than omissions to be hidden in an overhead term.

A further comparison prevents reading the resource inequality as a derivation of the half-merge detector. If the required experiments are only the original and pair-cut queries, plus native VFE/Fisher closure, one can merge every P draw while retaining the same S_0, four pair-cut probabilities, root barycenter and loop. Use the previous tree on S and cut 12 on the other P draws. This is another parameter-independent normalized channel with the same sufficient-statistic proof. Compared with the panel-gated carrier, it saves another 4 Q(P and not S) fields on average. That probability is strictly positive at every finite admitted state: P has positive mass, and on an open positive-density set both cut activations have probability below one. The extra finite geometry work is dominated in a sufficiently storage-heavy workload. Thus those statistical requirements and a field charge alone favor merging even when the diagnostic says to split. The alternative does not preserve statewise access to the two separate first-parent means on the split branch. If that access is part of the intended task, its requirement or allowed loss must be explicit. Neither this comparison nor the twelve-coordinate S_0 alternative can replace the user's complete geometric parent by silently dropping its access contract.

## 6. Evidence and next decisive obligation

The exact coefficient calculation passed once under pinned CPython 3.14.7 in 0.01904919999651611 seconds. It checks all forty-five rational link lifts and hidden projectors and records every coefficient count in [cost-coefficients.json](evidence/resource-license/cost-coefficients.json). The native storage margin and full-prior extension use the written algebra and the already saved path/readout enclosure. No random variable, state, flag, additional likelihood integral, ODE, benchmark or test suite was executed. The preservation receipt binds the calculation and current report to their source bytes. This is direct mathematical and algebraic evidence, not a new formal-ledger or independent-review certificate.

This continuation replaces an unpriced sample-dimension observation by a complete conditional workload inequality with an actual native storage margin. It leaves the resource prices and operational workload as selection data and does not claim that a chosen implementation has met (11). The current prior family may favor its first pair at the initial preparation. It therefore still does not exhibit both first-level discovery and later merger under one fixed unplanted choice.

The next mathematical target is the overlap question already exposed by the two native constructions: whether one fixed positive-prior family can exhibit a learned first-level ancestry transition and a later merged-P episode, while using this same complete carrier and cost frontier. Even a positive overlap result would leave the forced-merger comparison above and the actual operational resource choice to resolve; it would establish a common native episode, not an unconditional selection rule. A source-defined initial O/P posterior-tie family is an available reference, distinct from choosing a new numerical prior to obtain a desired answer. First inspect its exact stored evidence ratio and full native count-memory equations; do not repeat the fixed-P trajectory or expand its horizon. If that route fails, retain the failure and do not merge incompatible prior-family results. Separately, applying (11) to a real workload requires its actual resource criterion; no coefficient is selected here. The full RG goal remains active.
