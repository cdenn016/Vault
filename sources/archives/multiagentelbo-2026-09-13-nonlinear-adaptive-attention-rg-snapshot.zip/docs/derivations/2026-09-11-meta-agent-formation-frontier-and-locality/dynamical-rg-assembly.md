# A finite dynamical RG construction at one base point

September 12, 2026. This is the synthesis of the user-authorized six-step investigation. The finite construction is supported by the written derivations and independent reconstruction. The [frozen contract](evidence/2026-09-12-dynamical-rg-goal/problem-contract.json) asks for one nonempty admitted family with two compatible reductions. It does not ask for a theorem covering arbitrary local models, infinite depth, or a unique hierarchy selected by the dynamics.

The construction joins a normalized local model, attracting coherence, external response and departure, normalized parent laws, inherited kinetics, and two successive eliminations in the same compact example. The primary derivations are the [microscopic construction](microscopic-vfe-dynamics-construction.md), [complete coherence analysis](complete-coherence-dynamics.md), and [parent and dynamic reduction](dynamical-parent-rg-bridge.md). The compact common-regime proof is in the last document, Sections 7.1–7.3. The noncompact radial example is additional evidence about formation and stabilizer holonomy; it is not substituted for the compact example at an interface.

## What is supplied and what is derived

The starting point is the current local-to-global Theory: local normalized mechanisms and explicit dependence data determine one population joint; correlated recognition is selected separately. The live PIFB2 supplies the tentative internal-Hessian, slow-mode, inherited-metric, and cross-scale-prior mechanisms that this investigation develops. It is not used as a proof of the resulting construction.

The admitted example supplies a three-agent cycle, the compact group SO(2), positive intrinsic alignment interactions, a normalized physical evaluator, and local kinetic coefficients. The two law channels have distinct fixed Gaussian covariances. Their means lie on circles. Each of the six interaction links is an independent angle. The microscopic law-point process is explicitly a reversible diffusion whose probability law decreases an exact constrained VFE. It is an additional kinetic realization of the law-valued model, not an identification of this process with every agent's deterministic Fisher inference.

The derivations establish normalization, the evaluator's variational correction, an open coherent basin, the normal-mode ranks and stiffness, collective response, a departure mechanism, the exact parent laws and conditional costs, and finite-time comparisons with both inherited parent processes. The chosen microscopic rate factors and the order of elimination remain assumptions. Neither an agent count nor a precision matrix is identified with physical time.

## The local model and the complete VFE

At a given law-point configuration, the belief and model laws are `b_i=N(r n(theta_i),I_2)` and `m_i=N(r n(psi_i),a I_2)`, with `r>0` and `0<a<1`. The physical evaluator is the normalized kernel `k_i|zeta_i ~ N(zeta_i,(1-a)I_2)`. The configuration contains the six law angles and six independent link angles, so it lives on a twelve-dimensional torus. Its reference measure is normalized product Haar measure.

Local normalized node factors and positive edge tilts give a proper generative configuration law `P_0`. Its intrinsic action `U_0` contains transported belief/model mismatch and same-agent compatibility. These are declared baseline interactions. They are not recovered by integrating an unobserved agreement record, which would contribute one.

The conditional recognition coupling with the prescribed physical marginals has a unique information projection. Its exact cost is

\[
d(W)=\sum_i\frac{r^2}{1-a}[1-\cos(\theta_i-\psi_i)].
\]

For arbitrary correlated outer recognition `Q`, the scaled objective is

\[
\mathcal F_T(Q)=T\operatorname{KL}(Q\Vert P_0)+T\mathbb E_Qd
=T\operatorname{KL}(Q\Vert\Pi)+T\log(1/c),
\quad \Pi=c^{-1}e^{-d}P_0,
\quad c=\mathbb E_{P_0}e^{-d}>0.
\]

This is the exact negative ELBO of the unchanged augmented model in its declared conditional recognition family. The generative law `P_0`, the variational optimizer `Pi`, and the evolving law `Q_t` are different objects. A law point conditional on `W` is also different from the unconditional mixture obtained by integrating it against `Q`. The noncompact version uses the KL expression as the extended-real definition and restricts its split into energy and differential entropy to a domain where that split is defined.

## Coalescence and the modes that are eliminated

The complete unforced action has a coherent minimum manifold: the two angles at each node agree, and each link transports its source mean into its target mean. There are nine independent mismatch equations in twelve variables. Their derivative has rank nine because each edge equation has its own independent link column and the three remaining same-agent equations are independent. The resulting minimum manifold is a three-dimensional torus. The full Hessian has precisely these three tangent directions as its kernel and is positive on all nine normal directions.

Compactness makes this an open deterministic basin. Energy decreases under the specified local gradient field, the normal mismatch decays, and each sufficiently close trajectory converges to a point of the coherent manifold. Links genuinely move on an open set of initially perturbed configurations. The whole zero-two-channel-KL set would be too broad: the separate full-model counterexample shows that evaluator incompatibility can immediately destroy its tangency.

Holding the root and link marks fixed pins the omitted matter angles. The first eliminated node has a positive two-by-two conditional Hessian. The four-dimensional Hessian of both omitted nodes is bounded below by the least edge coefficient times the identity; the second conditional Hessian is its positive Schur complement. Consequently both eliminations remove restoring mismatch modes. They do not obtain a reduction merely by erasing passive gauge coordinates. The retained marks continue to encode the relative frame information.

One connected block first combines nodes 0 and 2, with node 1 and its incident information retained as exterior data. A second reduction combines that parent with node 1. Whole-network coherence in the admitted basin licenses these connected reductions. This does not prove an earlier pair-only formation episode or a uniquely preferred partition.

## Normalized parents and downward priors

Let `C_1` omit the two node-2 matter angles and `C_2` omit the two node-1 matter angles. Both maps retain the root's two law coordinates and all required link information. They are fixed, recognition-independent maps applied to the same underlying laws, giving `T^12 -> T^10 -> T^8`.

At the first stage the true generative parent is `P_1=(C_1)_# P_0`. The internal conditional cost and optimal recognition kernel are

\[
d_1(y)=-\log\mathbb E_{P_0(\cdot\mid y)}e^{-d(W)},
\qquad K_1^*(dW\mid y)=e^{-d(W)+d_1(y)}P_0(dW\mid y).
\]

The exact identity is

\[
\mathcal F_T(Q)/T
=\operatorname{KL}(Q_1\Vert P_1)+\mathbb E_{Q_1}d_1
+\mathbb E_{Q_1}\operatorname{KL}(Q(\cdot\mid y)\Vert K_1^*(\cdot\mid y)).
\]

The first two terms are the exact parent objective after conditional minimization. This parent is an augmented conditional-family ELBO: the derived internal kernel is integrated as part of its distributional structure and has no independently evolving parent coordinate. If those latent variables are also removed from both augmented distributions, a further nonnegative conditional KL appears. An ordinary coarse ELBO without that correction is not claimed to equal the original VFE.

The true downward generative prior is `P_0(dW|y)`. It is distinct from the recognition-optimal `K_1^*`. Parent evaluators are obtained by integrating the original normalized generative kernels against the former. They remain normalized and retain their required source dependence. The second elimination applies exactly the same operation to `(P_1,d_1)`; conditional expectation proves equality with direct elimination. Original evidence constants, generated interactions, and conditional variational costs are retained. No new independent parent prior, synthetic agreement observation, or pairwise closure ansatz is inserted.

At finite rates the actual fine law `Q_t` need not have conditional `K_1^*`. Its conditional KL in the displayed identity is retained explicitly. The path bounds below do not bound that dimensionless KL, particularly as temperature tends to zero. The autonomous parent is therefore not claimed to reproduce the entire fine VFE trajectory by itself. The proved interface is an exact objective decomposition with a conditional-family contraction and a controlled retained-path comparison.

## Inherited dynamics and a common finite-time regime

The microscopic mobility is diagonal in the declared angular coordinates, with node-rate factors `(s_2,s_1,s_0)=(epsilon^-1,delta^-1,1)` and positive independent link mobilities. Conditional averaging uses `Pi`, the invariant law of this actual diffusion. The parent drift is the gradient of its exact conditional-integral potential with the inherited mobility; in general coordinates both the pushed covariance and divergence term must be retained. A separately chosen parent Fisher metric would define another dynamics.

At a fixed positive temperature, a Poisson-corrector proof establishes two successive averaging estimates on the entire compact torus. Its constants are not uniform as temperature tends to zero. The joint coherence/reduction result therefore uses a second argument within the same model. First, positive conditional Hessians bound deterministic tracking errors at both eliminations. Second, unique global nondegenerate conditional minima give a uniform Laplace estimate for the parent forces. Third, a Brownian maximal bound compares the fine and parent diffusions with those same deterministic trajectories.

For a finite horizon `H`, the resulting bound has the form

\[
B_H\le C_H\left[\delta+
\frac{\epsilon}{\delta^2}e^{CH/\delta}
+(1+\rho_*^{-1})e^{CH/\epsilon}
\left(\sqrt{T/\epsilon}+T/\epsilon\right)\right].
\]

Here `rho_*` is an actual margin inside the admitted retained neighborhood. Constants are justified by compactness, positive conditional Hessians, smoothness, and the fixed model coefficients. One first chooses `delta`, then a sufficiently smaller `epsilon`, and finally a sufficiently small positive `T`. Strict inequalities give an open nonempty regime with small path error and small probability of leaving the coherence tube on the specified horizon. All parent laws remain normalized at these positive temperatures. This conservative existence construction is not a proposed experimental parameter setting.

The synchronous collective responds to normalized external heading observations with a derived equation `dot w=-h sin(w-a_ext)` when observation strengths are matched to the specified microscopic mobilities. Nearby independent-link configurations have controlled finite-time response. A sufficiently strong declared external mismatch force supplies a finite tube-exit certificate. After exit, the local reduction is no longer licensed by its coherence and conditional-branch margins, although the exact probability pushforwards still exist. Observation-conditioned reductions retain their evidence constants and distinguish the selected posterior from the original generative law.

## Acceptance boundary

This is a finite, single-point, conditional construction. It supplies actual local motion, an admitted coherent basin, controlled response, and two compatible parent reductions with generated operators and inherited dynamics. It does not establish arbitrary-initial-state convergence, a unique endogenous partition law, repeated merger episodes through arbitrary changes of membership, universal parent slowdown, a physical-time interpretation, or infinite-depth RG. It retains complete conditional-integral interactions rather than proving closure in the original short list of pairwise terms.

The evidence package records the exact target, component claims, derivations, independent reconstruction, corrections, and unresolved extensions. Its structural validator checks the package and its source bindings; mathematical support comes from the written derivations and reconstructed interfaces. The separate exact Fourier calculation checks finite induced-interaction identities. It is not used to prove the attraction or approximation theorems.

The independent reports reconstruct the [complete coherence proof](coherence-independent-check.md), the [parent and common-regime proof](parent-independent-check.md), and the [model, geometry, and contract interfaces](model-and-contract-independent-check.md). They record the corrections made during checking and the boundaries that survive it. The [release report](evidence/2026-09-12-dynamical-rg-goal/final-report.md) binds the finite conclusion to its exact assumptions and evidence.
