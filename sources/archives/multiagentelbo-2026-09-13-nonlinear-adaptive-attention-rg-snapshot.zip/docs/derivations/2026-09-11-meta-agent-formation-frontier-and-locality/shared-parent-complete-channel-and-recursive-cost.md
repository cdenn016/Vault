# Complete shared-parent channels and the cost of new interactions

September 12, 2026. The [native shared-parent learner](shared-parent-native-learning-and-memory.md) admits an exact geometric parent channel when the original labeled record probabilities and the learned Gaussian noise energies are retained together. The construction carries transported barycenter laws, independent-link loop and cut marks, ancestry, and explicit access maps. Its full correlated laws and native Fisher updates compose through any declared finite sequence of these channels.

This is a closure result for the declared translation specialization and original experiment. It supplies two proper first-level parents with an exact 44-to-28-to-20 continuous sample representation in one admitted ancestry sector. It does not show a lower inference cost: the same eight-coordinate law solver is available at fine and coarse levels, and a normalized parent density can remain expensive to evaluate. Nor does it identify an auxiliary component partition with the latent generative ancestry. A separate exact rank witness shows why adding interactions between the new parents changes the retention requirement.

## 1. Sources, family, and the question settled here

The live [PIFB2 source](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `app:augmented_joint`, supplies the normalized finite Gaussian tree. Its `sec:cross_scale_shadows` treats parent-predictive priors separately from strict mean-field messages; `sec:epistemic_collapse` explicitly distinguishes useful organization from imposed perfect consensus. [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex), `eq:full-graph-generative-factorization` and `sec:full-graph-vfe-downward`, permits general normalized downward kernels and correlated recognition. The [root-prior correction](post-merge-source-and-gaussian-parent-bridge.md), Section 2, remains necessary.

The current [wiki entry](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires a joint law, evaluator, boundary access, structural marks and sufficient memory. [Agreement-sufficient marked parents](agreement-sufficient-marked-parents.md), Sections 1-3 and 5, already supplies the common-channel and geometric composition method. Its fixed conditional given probabilities alone is unavailable to the new learned Gaussian prior. The additional energies below repair that specific failure. [Local interfaces and two-stage response](local-interfaces-and-two-stage-response.md), Sections 2-3, already distinguishes joint force information from independent local marginals; the present exact nonlinear construction respects that distinction.

Keep the complete family in [shared-parent-record-law-and-ancestry.md](shared-parent-record-law-and-ancestry.md): four children, the oriented cycle 01,12,23,30, two two-dimensional Gaussian law channels, independent four-dimensional translation links, a latent ancestry partition T, and primitive Gaussian noises epsilon_i, xi_A, ell_e, Y. In common reference coordinates, mu_i=Y+xi_T(i)+epsilon_i. The positive variance parameters a,b,c,v and the recognition precisions, block normalizer and likelihood power are unchanged. No base transport, physical dynamics, production model, data, or prior over ancestry is selected here.

Let R denote a geometrically connected partition used for a coarse channel, with q blocks. It is distinct from T, the partition indexing the generative Gaussian parent latents. All fifteen T remain in the model family; connectedness is required of R to choose its internal graph trees. In particular, the three disconnected ancestry candidates do not acquire nonexistent internal cycle edges.

## 2. Fixed sufficient coordinates for the native learner

Write E_a=sum_i ||epsilon_i||^2, E_b=sum_A ||xi_A||^2, E_c=sum_e ||ell_e||^2 and E_v=||Y||^2. Norms mean deviations from the pushed reference laws when frames change. Let p contain all eight original label probabilities. Retain

\[
 S=(T,p,E_a,E_b,E_c,E_v).
 \tag{1}
\]

The k(T) count and the likelihood of every original labeled finite record string are functions of S. The four energies are shared totals for the actual four global variance parameters; they are not four separately learned local parameters per component. E_v is retained even when the matched root precision remains constant. It is needed for the full variable-root family and is included in the counts below.

Use the proper unit-variance prior P_* with the same fixed positive ancestry weights pi_T as a reference probability. If u_j denotes a model precision, its exact Radon-Nikodym derivative is

\[
 \frac{dP_u}{dP_*}(X,T)
 =u_a^8u_c^8u_v^2u_b^{2k(T)}
   \exp\left[-\frac12\sum_{j=a,b,c,v}(u_j-1)E_j\right].
 \tag{2}
\]

Conditional Gaussian integration proves that (2) integrates to one separately at every T. The normalized record kernel is still the product of the original labeled Bernoulli factors conditional on p. For the current fixed batch o, the full recognition family has

\[
 \frac{dQ_\eta}{dP_*}(X,T)
 =Z_\eta^{-1}\exp\left[-\frac12\sum_j(\rho_j-1)E_j
                        +\omega k(T)+s\log L_o(p)\right].
 \tag{3}
\]

The recognition family and its normalizer are exactly those in the native-learning derivation, expressed relative to a probability reference instead of Lebesgue measure. Both density ratios depend only on S. Positive precisions, s in [0,1], and the already established log-moment assumptions remain the domain. Keeping p also permits evaluation of other original strings; it does not authorize new data collection or replace the current six-statistic recognition parameterization by an unmentioned online filter.

## 3. Parent law points, graph marks, and access

Choose a root r_A and oriented spanning tree for every connected component A of R. With ell_e taking the source frame to the destination frame, let g_i be the signed sum of internal tree links from r_A to i. The two transported unit-covariance Gaussian law barycenters are represented together by

\[
 z_A=\frac{1}{n_A}\sum_{i\in A}(\mu_i-g_i),\qquad n_A=|A|.
 \tag{4}
\]

Split z_A into its two channel means; the two law points are N(z_A^b,I_2) and N(z_A^m,I_2). For equal unit covariance, (4) is the unique minimizer over the parent mean of the sum of either oriented Gaussian KLs: the objective is one half the sum of squared distances to the transported child means, plus a constant. This is a declared equal-mass barycenter, with n_A carried for further composition. It is not the source's state-dependent weighted detector, nor an assertion that all child laws equal it. The actual parent recognition is a joint law on all retained coordinates, distinct from either Gaussian law point.

For every original non-tree edge e=(i,j), retain its individual dressed translation

\[
 V_e=\ell_e+g_i-g_j.
 \tag{5}
\]

An internal non-tree edge supplies a fundamental loop mark; a cut edge supplies a directed interface mark. Tree edges have V_e=0 by construction and need only their label/incidence records. Never combine parallel cuts into one average link. On the connected four-cycle there are m-n+q=q retained vector marks: zero to one internal cycles plus the individual cuts. Each vector has four real coordinates.

Under passive child-frame shifts h_i, mu_i'=mu_i+h_i and ell_ij'=ell_ij+h_j-h_i. Therefore g_i'=g_i+h_i-h_rA, z_A'=z_A+h_rA and V_ij'=V_ij+h_rB-h_rA for i in A,j in B. Internal loops are invariant in this abelian specialization. Original residuals, probabilities and noise energies are invariant when the reference laws and cross-scale offsets are pushed too. These identities prove the channel's covariance within the declared translation model. They assert no nonabelian result or normalizable translation-invariant Gaussian prior.

Let H record the partition, roots, trees, masses, original label/incidence registry and any retained auxiliary panel history. The same normalized, parameter-independent kernel K(dH|p) is used for prior, posterior and recognition. It may fix a partition/tree, or use the existing agreement-panel construction: conditionally independent original-channel flags, an edge active when both channel flags succeed, connected components, and a declared root/tree rule. This is a derived readout of the latent probabilities, not an additional observation. Its unconditional sum is one. Choosing it does not prove that its components are the most useful ancestry.

The complete coarse variable is

\[
 Z_R=(S,(z_A)_A,(V_e)_{e\notin\text{internal trees}},H).
 \tag{6}
\]

Each component accesses its own z_A and n_A, owned internal loop marks and original internal labels, plus every individual incident cut's p entries, V_e and incidence. A single shared registry stores original probabilities once; a cut is accessible at both endpoints without becoming two independent random variables. T and the four energy totals are common learning data. The shared parameter vector and a joint moment evaluator supply the existing global variance update. This gives concrete access maps by coordinate projection, but does not turn that global correlated learner into autonomous independent local learners. Computing the shared energies from fine data initially requires an aggregation pass. Allowing separately learned node/block/link precisions would require their corresponding separate energies and a new cost count.

## 4. One common conditional, exact VFE, and Fisher closure

Augment P_* by K and call the resulting probability R_*. Let nu_R be its push to (6). All spaces are finite disjoint unions of Euclidean spaces with finite discrete catalogs, hence standard Borel. A regular conditional Psi_R(dX,dH|Z_R) exists. The ratios (2)-(3), and their products with L_o, are constant on each retained fiber. Consequently

\[
 P_uK=P_{u,R}\Psi_R,\qquad
 \Pi_uK=\Pi_{u,R}\Psi_R,\qquad
 Q_\eta K=Q_{\eta,R}\Psi_R.
 \tag{7}
\]

Here Pi_u is the exact posterior for the original o. The same conditional version works for all positive parameters by tilting the common reference; no new posterior-specific channel is fitted. Null fibers can be assigned any normalized version. Equation (7) is proved by substituting the S-measurable density ratio into the defining disintegration integral.

The evaluated parent prior is (2) times nu_R, its recognition is (3) times nu_R, and its observation evaluator is the original normalized Bernoulli kernel given p. These are normalized, measurable model presentations. The joint parent law includes all correlations among component law points, energy totals, ancestry and graph marks. It is not a product of parent marginals. The exact conditional-KL identity gives

\[
 D(Q_\eta\Vert\Pi_u)=D(Q_{\eta,R}\Vert\Pi_{u,R}),\qquad
 F(Q_\eta,P_u)=F(Q_{\eta,R},P_{u,R}).
 \tag{8}
\]

Augmenting by the same K first has zero KL cost; the conditional term after pushing is zero by (7). The evidence is unchanged. The second identity uses F=D(Q||Pi)-log P(o). It is a statement about relative densities and the complete joint entropy, not replacement of a joint entropy by a sum of differential entropies of the displayed coordinates.

Differentiating (2) or (3) produces S-measurable scores. Their conditional covariance given Z_R is zero, so the model and recognition Fisher matrices at the parent are exactly their fine counterparts. Equivalently, the parent scores are the same functions of S and have the same joint moments under a push. Therefore the already derived finite-rate E/M parameter flow descends exactly, including its prior-mean-block-count model metric and recognition block-normalization memory. There is no extra conditional Fisher approximation. The Gaussian energy M-coordinates also use the same expected energies and expected k.

These statements close laws and their parameter evolution. A path of laws does not specify a process of individual sampled links. No microscopic link ODE, jump law, filtering scheme or physical clock is inferred from (7)-(8). Likewise, the existence of nu_R and Psi_R is not a cheap numerical evaluator or sampler.

The conditional Psi_R is a normalized downward generative kernel in the sense permitted by Theory/07c. It depends on parent coordinates through its conditional support and probabilities. It generally couples children and retains the original latent ancestry in S. It is not the simple Gaussian kernel around z_A, and z_A need not equal any original latent Z_A of ancestry T. Thus the construction supplies an exact top-down reexpression of this model, not a proof that newly discovered groups have become its original Gaussian ancestor variables.

## 5. Recursive composition with barycenters

At the next stage form connected collections C of the actual first-level components, using only their retained cuts and a normalized kernel of retained information. Carry S unchanged. Let t_A be the path translation from the new root to the old root of A along a spanning tree of retained cut links. Define

\[
 z_C=\frac{\sum_{A\subset C}n_A(z_A-t_A)}{\sum_{A\subset C}n_A},\qquad
 V_e^{\rm new}=V_e+t_A-t_B.
 \tag{9}
\]

Carry old internal loop marks, all new cotree marks and all unused cuts. In the translation case an internal loop is unaffected by a root change. For a fine child i in A, the flattened path is g_i+t_A. Substituting (4) into (9) gives the direct fine barycenter with these flattened paths. Substituting (5) gives the direct fine dressed link. This proves direct/staged equality, including every original edge copy; it is not an average over links or a flatness assertion. Integer masses add associatively.

The composite channel is the actual composition of the two normalized kernels, with any inherited history retained. Since it still retains S, the proof of (7)-(8) applies to that channel too. Repetition proves finite-depth composition by induction. Disintegrating the common reference at consecutive levels gives normalized reverse kernels whose composition reconstructs the fine family. These reverse kernels need not factor over parent blocks.

Two proper first-stage blocks occur, for example, when the agreement panel selects {0,1} and {2,3}. For any interior p this event has positive probability; a fresh cut panel merges the two with positive probability too. The Gaussian prior and finite-record recognition put full mass on interior p. Thus the event has positive probability under every admitted positive prior and recognition. This is not a computed probability, preference for that pairing, or a learned persistent hierarchy. If R is instead taken directly from a supplied ancestry T, the grouping is imposed. Neither construction silently equates T with the sampled agreement components.

## 6. Counts and an evaluator with explicit costs

The fine latent sample has 4n+4k+4m+4=36+4k real coordinates. For any connected q-block geometric partition of the four-cycle, (6) stores eight original probabilities, four energy totals, 4q barycenter coordinates and 4q loop/cut coordinates. Its real-coordinate count is

\[
 N_R=12+8q.
 \tag{10}
\]

Ancestry, original labels, incidence, masses, roots, trees and panel history are additional discrete data. They are not free and must be stored once in the shared structure. Equation (10) counts displayed continuous samples, not bit complexity, minimal sufficient dimension, memory of a joint density, or integration work. It includes all four energies even on the initially matched-root trajectory.

For fixed ancestry T={{0,1},{2,3}}, the fine sample has 44 real coordinates. The two-parent state has 28; the final root state has 20. The exact calculation below gives full ranks 28 and 20 at one interior point, so these two displayed maps are not merely padding a smaller continuous image at that point. This local rank assertion does not prove a global minimal representation or a lower bound for arbitrary measurable encodings. The law-level native solver still has eight evolving coordinates when the root is matched, at every stage and in the fine implementation.

A direct, positive definition of the parent reference evaluator integrates the unit Gaussian primitive density against the delta map (6) and K. The density ratios (2)-(3) then evaluate all model and recognition integrals relative to that reference. The native moment evaluator remains the preceding determinant formula at the exact posterior endpoint and its convergent series at intermediate likelihood power. Neither evaluator becomes cheaper solely because a geometric sample is shorter.

For completeness, fixed realized trees also have a finite-dimensional Gaussian transform representation. In one coordinate direction let x=(epsilon,xi,ell,Y) have covariance D, let A x collect all retained linear barycenter/mark coordinates, and let W be a nonnegative quadratic form assembled from the energy selectors and residual rows. Completing the square gives

\[
 E\exp\left[-\frac12x^TWx+i t^TAx\right]
 =\det(I+DW)^{-1/2}
   \exp\left[-\frac12t^TA(D^{-1}+W)^{-1}A^Tt\right].
 \tag{11}
\]

The inverse exists because D>0 and W is positive semidefinite. This follows by replacing the Gaussian precision by D^{-1}+W and shifting the linear Fourier source. The four coordinate directions give four factors, with shared energy Laplace variables and the two channel-specific residual-energy variables. The original p entries are exp(-residual energy/2). Thus the joint characteristic/Laplace transform of the displayed geometric and quadratic coordinates is explicit. The fixed finite ancestry mixture is a finite sum; the recognition likelihood and panel selection tilt this reference. For the fixed integer batch their failure factors can be expanded algebraically; intermediate tempering uses the existing convergent expansion. Signed expansion coefficients are not sampling probabilities.

Equation (11) supplies a constructive integral representation, not an implemented fast inversion algorithm. Direct fine sampling followed by the channel is an available exact generative construction, but it retains fine generation work and peak memory. No sampling or transform inversion ran in this turn. A measured net resource gain, efficient conditional recovery and finite online filter remain open.

## 7. New interactions do not automatically survive the next parent

The first-level parents have their own transported divergence on every retained cut. With e directed from A to B, its two channel probabilities would be

\[
 \widetilde p_e^x=\exp\left[-\|z_B^x-z_A^x-V_e^x\|^2/2\right].
 \tag{12}
\]

These are evaluable from Z_R. They are generally different from the original child-pair p_e. Calling them parent interactions does not make them observations already present in o. Using them in a new prior or likelihood is a declared model extension; observing them would be a changed experiment requiring its own operational justification.

The twenty-coordinate grandparent need not determine (12). The exact witness fixes T={{0,1},{2,3}}, first internal trees 01 and 23, root children 0 and 2, and the second tree edge 12 with final root 0. Primitive variables have the order recorded in [result.json](evidence/shared-parent-channel/result.json). At the single declared rational point x_j=((17j+3j^2) mod 97-48)/17, j=0,...,43, every original residual energy and all four Gaussian energy totals are positive.

Use the eight residual squared norms in place of p when taking derivatives; exponentiation has a nonzero derivative there and hence does not change rank. Let F_2 be those eight values, the four primitive energy totals, final barycenter and final loop. Let d_new be the four squared norms in (12) for cuts 12,30 and channels b,m. Exact Fraction elimination gives

\[
 \operatorname{rank}DF_2=20,\quad
 \operatorname{rank}D(F_2,d_{{\rm new},1})=21,\quad
 \operatorname{rank}D(F_2,d_{\rm new})=24.
 \tag{13}
\]

This yields an actual local obstruction, not just a tangent warning. A nonzero 20-by-20 minor makes F_2 a submersion on a neighborhood of the point. Its level set is a smooth 24-dimensional manifold. The augmented ranks show that the restriction of d_new to this level set has differential rank four, so its values range over a local open set while F_2 is fixed. In particular, two legitimate fine configurations have exactly the same complete grandparent state and different new parent-record probabilities. Their original T, realized trees and other discrete marks are held fixed. The Gaussian law has positive density in the neighborhood, and all panel choices used have positive conditional probability there.

Consequently no deterministic decoder of F_2, even a discontinuous one, recovers these new probabilities throughout that neighborhood. A stochastic decoder cannot recover every point-preparation Bernoulli experiment either, because its output distribution would be identical for those equal inputs. This is a statewise access obstruction; it does not contradict the common-reference conditional predictions under the restricted family.

Appending all four new probabilities is sufficient for these four scalar evaluators and increases the second-state count from 20 to 24. It is locally necessary to add at least four real coordinates among smooth augmentations admitting a differentiable decoder: the augmented differential must have rank at least 24. No lower bound for arbitrary pathological measurable encodings is claimed. This amendment still gives 44-to-28-to-24 displayed sample compression, but still does not prove a cheaper law solver or useful selection.

The obstruction also affects model learning without collecting new observations. On this fixed-tree branch, take the original conditional prior P and form the declared normalized prior tilt

\[
 P_\kappa(dX)=C(\kappa)^{-1}e^{-\kappa\cdot d_{\rm new}(X)}P(dX).
 \tag{14}
\]

For nonnegative kappa the multiplier is positive and at most one, so 0<C<=1. A neighborhood of zero is also integrable: d_new is a finite quadratic form and the original Gaussian precision remains positive under sufficiently small signed perturbations; the bounded panel multiplier does not spoil that bound. The original observation kernel remains unchanged. This is a possible model extension on a fixed branch, not an endogenous grouping rule or a selected prior for the full program.

Its model score is -d_new+E d_new. The Fisher information lost on F_2 is exactly E Cov(d_new|F_2). The local submersion above makes the joint (F_2,d_new) distribution have a positive density on an open set under this branch's prior. Therefore every nonzero linear combination of d_new has positive conditional variance on a set of positive parent probability: the four-dimensional Fisher-loss matrix is positive definite. Carrying only the old energy totals cannot preserve the full natural-gradient metric of this extension. Appending the four d_new values restores score sufficiency for this tilt. This conclusion concerns the new conditional model family and does not invalidate the exact native learner in Sections 2-4.

More generally, preserve each admitted new scalar evaluator in a shared catalog before any later channel discards its arguments. Then every finite model tilt that depends only on that catalog has the same common-conditional sufficiency proof. This describes a condition for an extension; it does not supply its normalization, metric, learning rule, complexity preference or empirical need. Future parent-predictive kernels can require vector or additional structural information beyond the four scalars in this example. A constant twenty-coordinate claim cannot cover such unspecified extensions.

## 8. Evidence and next obligation

The [calculation](evidence/shared-parent-channel/channel_exact.py) ran once under pinned CPython 3.14.7 and finished in 0.023485399997298373 seconds. It checks direct/staged barycenter and loop coefficient equality, one exact passive-translation check, positivity of the witness's record/energy coordinates and all four reported ranks. The written algebra supplies general translation covariance and composition; the rank values and the submersion argument together establish the scoped new-record obstruction. No random search, trajectories, parameter fitting or test suite was run. A preservation/inspection receipt accompanies the result. No formal ledger certificate is issued.

The previous goal turn was progress: it supplied the native learner and exact single M-coordinates. This continuation supplies its complete geometric common channel, recursive law-level closure, priced sample representations and a new-interaction access obstruction. It does not revisit the negative fifteen-subset admission, select ancestry weights, add data or edit the source manuscripts.

The next decisive obligation is an explicit post-merge parent-predictive model on this actual retained carrier, with its new sufficient information and native update cost. Any such model must state how its geometric component partition R relates to latent ancestry T, retain every new evaluator it requires, and compare the same original observations under a normalized joint. A strict resource comparison must price density/moment evaluation, generation, interfaces and any online filter against the fine analytic implementation. Useful endogenous selection, response persistence and a hierarchically reusable learned model remain unproved. The full goal remains open.
