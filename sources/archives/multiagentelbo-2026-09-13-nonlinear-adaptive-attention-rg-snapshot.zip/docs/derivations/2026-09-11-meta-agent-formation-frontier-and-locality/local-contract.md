# Structural obstruction and local parent contract

September 11, 2026. Source revision: ed8f22a56df353b1535744509cc23fae46d5813c. This is a finite mathematical derivation and an execution contract. No spatial learner, new observations, or local admission sweep was executed. The conclusions below follow from the displayed calculations; no formal verification-ledger certificate is issued.

## 1. Target, supplied assumptions, and conventions

The supplied model has four labeled children V={1,2,3,4}, fine state Y={-1,+1}^4, counting measure, symmetric couplings J_ij=J_ji (the six couplings need not be equal), actions a=±1/5, signal eta=3/4, one uniformly chosen reset site per event, and noisy destination parity. The sufficient positivity condition is |a|+sum_{j != i}|J_ij|<1 at each site. The live constructor restricts its six rational couplings to nonnegative values. The first-response proof only needs symmetry and positivity. Preparations for the strong theorem are every fine probability law, including every point mass. The empirical saved protocol instead prepares uniformly and observes no time-zero sensor. These are different quantifiers.

For each nonempty A subset V, write E=V\A and Y=Y_A x Y_E in fixed increasing-site order. The sought map h_A:Y_A -> S_A is onto and independent of the exterior input. Equality means equality of joint retained-state, exterior-state, action, and record paths at every finite horizon, under corresponding pushed preparations and common policies using retained history. It does not mean equality only after stationary averaging or only for one policy. The introduced choices are an explicit START encoding, singleton fixed model presentation, singleton generative memory, and the complete exterior interface. They specify the next experiment without changing the current saved observations.

| Object | Type and convention |
|---|---|
| Context base | One point c_*; no smooth base or base map is constructed |
| Fine fiber | Finite Y_A x Y_E with counting measure |
| Structural X | Fixed couplings, signal, action alphabet, schedule, subset, ordering, retention |
| Fine emitted kernel | K^a(y_A',y_E',e | y_A,y_E), nonnegative, sum over all outputs one |
| Local sample | s=h_A(y_A) in S_A; distinct from a recognition distribution on S_A |
| Interface | xi=y_E, a random retained exterior sample, not structural X |
| Model and memory | m_* and h_* are singleton retained marks |
| Parent sample | Z_A=(s,m_*,xi,h_*) |
| Group/representation | Only finite coordinate bijections are used below, acting on samples on the left; law action is pushforward |
| Connections/transports/metric | None needed or supplied; TV and KL act on probability laws, not on an SPD manifold |

## 2. Intrinsic shared-row floor

For arbitrary nonempty finite Y, action and record alphabets, normalized K, and deterministic onto f:Y -> Z, set

p_y^a(z',e)=sum_{v:f(v)=z'} K^a(v,e|y),

d_f=max_{a,y,v:f(y)=f(v)} TV(p_y^a,p_v^a),

where TV(p,q)=(1/2)sum_u |p(u)-q(u)|. Every collection of normalized shared rows q_z^a satisfies

max_{a,y} TV(p_y^a,q_{f(y)}^a) >= d_f/2.

Indeed choose a maximizing pair (finite alphabets ensure attainment). Since f(y)=f(v), the TV triangle inequality gives d_f <= TV(p_y^a,q_z^a)+TV(q_z^a,p_v^a), at most twice the displayed maximum. This is a lower bound, not a claim that every finite collection has minimax radius exactly half its diameter. Pushforward to record alone contracts TV by grouping signed differences, so record separation also supplies a lower bound on the joint-row discrepancy.

The live closure_defect returns exactly d_f. The live oracle_error maximizes against the fitted base rows and, when present, every previous-record-conditioned row. For each fixed memory index it still compares the same complete fine fiber. Consequently adding that index does not remove this certificate. A history-restricted reachable-posterior problem would change the quantifiers and requires a separate initialization and reachability argument.

## 3. First-record obstruction

Let P(y)=product_i y_i and M(y)=sum_i y_i. Given selected reset site i, the new spin U has mean a+sum_j J_ij y_j. Since y_i^{-1}=y_i, destination parity is P(y)y_i U. The noisy record has conditional mean eta times destination parity. Averaging the four sites gives

E[E_next|y,a] = eta P(y)/4 sum_i y_i(a+sum_j J_ij y_j)
              = eta P(y)/4 [a M(y)+2 sum_{i<j} J_ij y_i y_j].

The second equality uses symmetry J_ij=J_ji and zero diagonal, not equality of couplings. For y_+=(+1,+1,+1,+1) and y_-=(-1,-1,-1,-1), both P=1 and each pair product is one, whereas M=±4. Their record means differ by 2 eta a. A binary ±1 law of mean m has probability (1+m)/2 at +1, hence their next-record TV is eta|a|=3/20. Any map merging these preparations and assigning one first-record prediction has worst-case error at least 3/40. The constant map necessarily does so; this is not a claim about every intermediate partition. With no informative initial record, common initial memory or independent random initial memory cannot distinguish these preparations. Later records cannot repair a first-response mismatch in an all-preparations path equality. The obstruction may vanish under an action mixture that averages opposite fields, which is why the claimed experiment keeps action-specific responses.

## 4. Strong exterior adapter

Define the tagged record set R_A={START} disjoint-union ({STEP} x {-1,+1} x Y_E). Choose and save an explicit bijection enc:R_A -> {0,...,|R_A|-1}, assigning START=0. The ControlledProcess adapter has local states Y_A, actions (a,x) in {±1/5} x Y_E encoded as unique strings, and integer records enc(r). Its emitted row is

L^{(a,x)}(u',enc(STEP,e,x') | u)=K^a(u',x',e|u,x),
L^{(a,x)}(u',enc(START)|u)=0.

Its initial_sensor row is delta_START for every local source and action. Thus sum_{u',r}L= sum_{u',x',e}K=1 and the initial row sums to one. START is bookkeeping only: exclude it from event counts and likelihood factors; it never invents a next-exterior observation at time zero. An actual observed initial sensor would instead need its actual tagged law and a separate descent condition. The source API's auxiliary fair initial row is not the sampled protocol's observation law.

The actual API stores emitted columns destination-major then record-major and requires Fraction entries. ControlledProcess labels and actions are tuples of strings and records a tuple of distinct integers. coarsest_partition(process, required_keys=None) returns (labels, refinement_class_counts); quotient_process rejects nonzero emitted defect and non-descending initial sensors. These functions are sufficient for the proposed adapter, without changing the learner. The adapter is a family of local-input rows: arbitrary exterior inputs at each invocation are stronger than physically realized trajectories. Its step output x' must become the next interface when reconstructing the actual coupled process.

With h=h_A, adapter closure is precisely

sum_{u':h(u')=s'} K^a(u',x',e|u,x)
 = barK_A(s',x',e|h(u),x,a)

for every u,x,a,s',x',e. Normalization follows by summing the left side over s',x',e. Define G_A(u,x)=(h(u),x). Its fibers factor exactly as h^{-1}(s) x {x}; the quotient source cardinality is |S_A| 2^{|E|}. The equation is exactly full emitted closure of G_A. Repeated refinement only splits source classes. Any stable admissible partition refines the initial partition and, inductively, every refinement: equal stable-class sources have equal sums to each union of stable classes. Termination on the finite local carrier therefore gives the coarsest admissible equivalence relation, up to integer relabeling. This does not prove that global refinement with required exterior marks has product-form fibers; that different construction can vary the local partition with x.

## 5. Complete parent, common push, and evaluators

Set B_A=S_A, M_A={m_*}, Xi_A=Y_E, H_A={h_*}. A local extraction of s uses u only; interface extraction uses x. For an operational recursive interface the parent receives (s,x) initially and retained updates thereafter. A parity-only external observer need not receive x or s after initialization; its recognition must then filter their joint law. These access choices must be stated when deploying the next phase. They do not grant the saved empirical predictor new exterior information.

For any declared finite experiment, let W be its complete augmented fine latent source: current fine state for a static law, or the complete fine path plus any declared controller latent state for a path law. Let O be the actually observed record/action data. Fix one normalized joint P(W,O|X), independent of recognition, and a deterministic map g(W) retaining the parent coordinates (coordinatewise for paths), with O retained once. Define

C(w,z)=1{z=g(w)}.

This is one normalized channel, independent of Q and the realized posterior. Push P to P_A(z,o)=sum_{w:g(w)=z}P(w,o), push the full correlated recognition Q_o to Q_A,o by the same sum, and push the selected posterior Pi_o(w)=P(w,o)/p(o), at p(o)>0. Finite summation gives Pi_A,o=Pi_o C. Never reconstruct Q from child marginals or multiply block marginals.

For a static experiment the normalized induced evaluator at each positive-mass exterior x is

Ev_A(m_*;x)(s,o,h_*) = P_A(s,m_*,x,h_*,o)/P_A(Xi=x).

On a null exterior fiber choose any declared normalized row; no experiment identifies it. If desired augment W with fixed marks (m_*,h_*) before applying C. This evaluator is conditional on the chosen joint and preparation. It is distinct from the transition evaluator barK_A(s',x',e|s,x,a), which normalizes over future sample, exterior, and record at each source and action. Singleton presentation supplies a fixed evaluator, not model learning. Singleton generative memory is allowed by exact emitted closure, but it does not make a partially observed filter memoryless.

Assume Q_o << Pi_o. Finite support makes the relevant KL values finite. With q_A(z)>0, factor Q_o(w)=q_A(z)Q_o(w|z) and Pi_o(w)=pi_A(z)Pi_o(w|z). Expansion of the logarithm gives

D(Q_o||Pi_o)=D(Q_A,o||Pi_A,o)+sum_z q_A(z)D(Q_o(.|z)||Pi_o(.|z)).

Because p(o) is unchanged by the common push, F_I=F_A+Delta with the last nonnegative conditional sum Delta. For a fitted normalized joint P_hat_A positive on the needed (z,o) support,

F_hat_A-F_A = E_{Q_A,o} log[P_A(Z,o)/P_hat_A(Z,o)],
F_I = F_hat_A + Delta + E_{Q_A,o} log[P_hat_A(Z,o)/P_A(Z,o)].

The last expectation has no universal sign. Thus replacing the actual push by a fitted Markov joint does not inherit an unmodified nonnegative conditional-gap identity. A normalized fitted transition alone also needs a declared preparation and observation law to define this joint.

## 6. Disjoint composition and paths

Proposition. Assume the fine carrier is the full Cartesian product of its child carriers, as in Section 1 (or, more generally, every F-fiber is connected by admissible single-block replacements). Let A_1,...,A_k be disjoint nonempty subsets, R their complement, and suppose each h_j satisfies the strong exterior equation for the same fine kernel K, actions, and single record. Then

F(y)=(h_1(y_A1),...,h_k(y_Ak),y_R)

has exact emitted-row closure. For y,v with F(y)=F(v), replace blocks in order to form y^(0)=y,...,y^(k)=v. Consecutive sources agree outside A_j and have the same h_j value. Strong exterior equality says their joint output laws for (h_j(Y'_Aj),Y'_{V\Aj},e) agree. F(Y') is a deterministic function of this output, so pushing that equality gives equality of (F(Y'),e). Transitivity across the k replacements proves closure. This argument keeps correlations and the one shared record; no independence assumption occurs.

Initial sensors must separately descend through F. In the current no-initial-observation experiment delta_START does so. A sensor depending on a discarded coordinate would invalidate the path claim even if all emitted rows closed. Given this initial check, choose a representative in each F-fiber to define the quotient row; normalization and representative-independence are immediate. At any positive retained history, the fine conditional law is supported on the current F-fiber. A common policy depending only on retained history leaves that conditional law unchanged after conditioning on its selected action. Averaging the equal emitted rows over this conditional law yields the quotient row. Induction establishes equality of every finite retained-state/action/record path for every fine preparation. Conversely, horizon one, point preparations, and fixed actions recover the closure equation. Policies using discarded microscopic state are outside this equivalence.

If an admitted second map g acts on F(Y), direct and staged sums agree since sum_{z:g(z)=r}sum_{y:F(y)=z} equals sum_{y:g(F(y))=r}. This proves equality of channels, generative/recognition/posterior pushes, and emitted rows when the second quotient is admitted. It does not authorize separate simultaneous block resets: the inherited kernel keeps the original one-site event schedule. Independent copies of each full exterior interface must not be multiplied into a product parent; use the single joint F and its correlations.

## 7. Minimal failure and coordinate covariance

A two-bit counterexample shows why exterior outputs matter. Let u,x be binary, one action, constant sensor e=0, and K(u',x',0|u,x)=1{u'=u,x'=u}. The local record alone is identical for u=0 and u=1, but a constant h cannot satisfy the strong exterior equation: at x'=0 its rows are respectively one and zero, TV one. This is a normalized scientific counterexample, not an artifact mutation. Conversely identity h_A always supplies an exact adapter quotient, so admission cannot fail merely for lack of any map; the substantive issue is compression.

Finite coordinate reexpression is lawful as follows. For bijections R_A,R_E,R_a,R_e define K' by transporting all arguments of K, set h'_A=R_S h_A R_A^{-1}, and transport the quotient in the same way. Substitution in the finite sum proves h'_A R_A=R_S h_A and strong-closure covariance. Counting measure is preserved by bijections. This establishes table reexpression, not a symmetry of the restricted heterogeneous parameter family: independent sign flips usually require signed couplings and site-specific fields. No frame connection, principal-bundle topology, Fisher metric, or SPD transport follows from this finite result.

## 8. Next authorized stage and remaining obligation

The first-session spatial deliverable is complete on paper. No class counts for the fifteen heterogeneous local adapters have been computed here. The next action, requiring the subsequent continuation specified in the user's plan, is to construct all fifteen exact adapters using the frozen original kernel, run refinement once per adapter, and emit every map, class count, factorized fiber, initial check, refinement trace, and exact equality certificate. For an identity-only result, retain separating local source rows and stop useful exact-compression claims. Include |S_A|2^{|E|}, filter coordinates, and interface storage so apparent local reduction is not confused with whole-parent resource reduction. Admission of at least two proper useful disjoint blocks precedes a second-level attempt. No penalty change, new sensor, new data, or spatial fitted learner is part of this ticket.

Sources inspected: finite_formation.py (ControlledProcess, coarsest_partition, quotient_process, closure_defect); finite_data_formation.py (heterogeneous_process and oracle_error); completed boundary-parent-contract.md and formation-composition.md; Theory/SPEC.md and the common-push/evaluator seams of Theory/07b_agent_network_rg.tex and Theory/07c_full_graph_meta_agent_vfe.tex. The completed symmetric 16/9/5 hierarchy is retained as prior calibration and is not recomputed or superseded by this heterogeneous admission contract.
