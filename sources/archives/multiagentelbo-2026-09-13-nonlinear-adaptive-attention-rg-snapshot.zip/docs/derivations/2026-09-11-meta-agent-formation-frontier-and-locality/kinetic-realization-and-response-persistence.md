# A kinetic realization of the labeled learning family

September 11, 2026 continuation at the fixed base point c_*. There is an explicit normalized discrete inference process whose probability marginals follow the existing native E/M flow, whose complete marked parents preserve its record paths, and whose membership episodes have computable lifetimes. This is a declared realization of the learning law. The ELBO does not select this realization, and it is not a derivation of physical microscopic time.

The construction uses fresh conditional geometry and fresh auxiliary membership panels at each unit of the already fixed inference clock. It introduces no persistent uniform seeds. The previous frozen-angle trajectory obstruction remains valid for that different process. Below, retained-state responses converge and are exactly stationary at equilibrium, while membership remains variable. Conditioning on survival can change an observer's forecasts even at equilibrium.

## 1. Source boundary and unchanged model

The starting model is [learned-multilabel-membership-and-stopping.md](learned-multilabel-membership-and-stopping.md), Sections 2–5: the common translation group R^2 times R^2, correlated Gaussian child means conditional on all eight labeled probabilities, independent two-dimensional residual angles conditional on their lengths, and the native restricted learning of positive concentrations. Its prior P_u, fixed labeled record archive, recognition family, likelihoods and E/M vector field are unchanged. The auxiliary component/root/tree channel is the previously admitted one. [Agreement partition selection](agreement-partition-selection-and-lineage.md), Section 7, already uses common quantile ranks for a different monotone coupling; the construction here resumes that idea for the coupled learned parameters rather than claiming a new quantile principle.

[Source-path-and-persistence-admission.md](source-path-and-persistence-admission.md), Sections 2–3, proves that the old fixed-W membership sweep and posterior conditional refresh preserve every matched probability law. They cannot realize this learning. [Conditional matching](conditional-matching-dynamics-and-local-obstruction.md), Section 6, and [Theory/07e](../../../Theory/07e_inference_memory.tex) supply the record-conditioned lift and distinguish changed refresh paths from the original unrefreshed paths. These are constraints on the present construction, not missing source ideas.

The revised attachment's Sections 8–10 require action-specific response distributions, declared preparation and clocks, a complete interface/filter cost, and one correlated law through the hierarchy. Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), sec:meta_agent_variational, still leaves the post-merge net-gain functional unspecified. A finite-lived useful parent is permitted; permanent membership is not an added requirement. Neither the unchanged heterogeneous experiment nor its fifteen exact negative admissions is replaced by this specialization.

## 2. A moving probability path on explicit algorithm state

Let a=(alpha,beta,u) contain the existing 3m coordinates, m=8 on the four-cycle. Write Phi_t(a) for the global native E/M solution proved in the labeled source. Its j-th block is

\[
 \dot\alpha_j=u_j+n_j-\alpha_j,\qquad
 \dot\beta_j=1-\beta_j,\qquad
 \dot u_j=u_j-u_j^2[\psi(\alpha_j+\beta_j+1)-\psi(\alpha_j)].
 \tag{1}
\]

The archive has n_j>=1 successes and one failure per original label. Take alpha,u>0 and beta>=0. The source proves convergence to a_* with u_j*=sqrt(n_j(n_j+1)), alpha_j*=n_j+u_j*, beta_j*=1. Let F_(alpha,beta)(p) be the CDF of Beta(alpha,beta+1). Its defining normalized integral is the regularized incomplete beta function in [NIST DLMF 8.17.1–2](https://dlmf.nist.gov/8.17). The density is strictly positive on (0,1), so F is strictly increasing there, maps onto (0,1), and has a unique continuous inverse.

For interior p, define a deterministic flow on (a,p) by

\[
 H_t(a,p)=(a_t,p_t),\qquad a_t=\Phi_t(a),\qquad
 (p_t)_j=F_{(\alpha_t)_j,(\beta_t)_j}^{-1}
                   (F_{\alpha_j,\beta_j}(p_j)).
 \tag{2}
\]

The CDF evaluated after this map is the same rank as before it. Thus H_s H_t=H_(s+t), with the usual state-map composition convention, and H_0 is the identity. If the initial p coordinates have the source's independent beta law nu_a, their CDF ranks are independent uniforms, so p_t has exactly nu_(a_t). This proves equality of the recognition probability laws at every time, not just equality of moments. The auxiliary ranks are reconstructible from the retained (a,p); no separate rank array or uniform-seed memory is required.

For p in the interior, differentiating the defining identity gives the velocity

\[
 \dot p_j=-\frac{\dot\alpha_j\partial_\alpha F_{\alpha_j,\beta_j}(p_j)
                     +\dot\beta_j\partial_\beta F_{\alpha_j,\beta_j}(p_j)}
                    {\partial_p F_{\alpha_j,\beta_j}(p_j)}.
 \tag{3}
\]

Parameter differentiation is legitimate locally: on a compact positive parameter neighborhood, the beta density times its parameter-log factors has an integrable endpoint bound. The denominator is positive. At n=1, (alpha,beta,u)=(1,1,1), p=1/2, (1) gives (1,0,-1/2). Since F_(alpha,1)(p)=p^alpha[(alpha+1)-alpha p], (3) gives dot p=(3 log 2-1)/4>1/8, using log 2=integral_1^2 dx/x>1/2. Thus the new process actually moves p; it does not repeat the stationary fixed-W sweep.

The flow is a fixed function of the explicit algorithm state and its fixed archive. It is not a Markov kernel on W alone chosen separately for each unrecorded current recognition law. It realizes the recognition trajectory Q_a. Transporting a model-prior initial draw by H_t is generally not the model prior P_(u_t). Static common-channel closure of the prior, posterior and recognition laws is retained, but no simultaneous temporal transport theorem for all three laws is asserted. Future probe records below are prospective outputs and are not fed back as new training data.

## 3. Normalized fine kinetics and complete parent rows

Use integer inference ticks k. One tick advances the exact native flow by one unit; there is no added slowing coefficient, deleted self-transition, or conversion to physical seconds. Let Psi_p(dW) be the source's normalized conditional geometry: draw the m uniform residual angles with fixed norms sqrt(-2 log p_j), draw the joint Gaussian means conditional on p, then recover the independent link coordinates. Let K(dh|W) be the normalized membership/root/tree channel, including a fixed finite number of RG stages when those are requested. Each stage samples fresh flags on the currently surviving cuts. All original labels, cut incidences and loop histories travel through the same joint channel.

With x=(a,W,h) and p=p(W), define

\[
 T(x,da'dW'dh')=
       \delta_{\Phi_1(a)}(da')\Psi_{p'}(dW')K(dh'\mid W'),
 \qquad (a',p')=H_1(a,p).
 \tag{4}
\]

Every row has mass one because Psi and K do. The hidden geometry and panels at the next tick are conditionally independent of the old geometry given (a,p). The initial prepared law delta_a nu_a(dp) Psi_p(dW) K(dh|W) becomes exactly the corresponding law at a_1 after one tick and hence at a_k after k ticks. All tick-indexed joint laws are defined by ordinary repeated kernel integration. This is a discrete process; no continuous sample-path limit for instantaneous geometry resampling is used.

Let C retain a and the complete marked parent of the source: all p, rooted belief/model coordinates, every dressed original cut copy, independent internal loop marks, and the finite panel/root/tree/incidence history. The sample space is the finite disjoint union over its possible partitions and charts. Write S_p=C_#[Psi_p K] for its normalized conditional sampling law, suppressing the unchanged a coordinate. The parent row is

\[
 \bar T((a,z),da'dz')=\delta_{\Phi_1(a)}(da')S_{p'}(dz').
 \tag{5}
\]

Because p is retained and the right side depends on x only through Cx, TC=C bar T in row-kernel notation. This is strong one-step lumpability for this declared process, for every initial source state on the consistent carrier. Preparation is needed to identify its one-time laws with Q_(a_k), not to prove the row factorization. The conditional sampler of the labeled source draws only the Gaussian root marginal and the residual angles needed for its dressed cuts and loops; it need not reconstruct non-root means. The old frozen-angle dynamics did not have this property, so (5) does not repair that earlier counterexample without changing its kinetics.

For a probe choosing one original label j after a tick, emit e in {0,1} with probability p'_j^e(1-p'_j)^(1-e). Multiply (4) and (5) by this same factor. It is retained-measurable, so the conditioned lift in the source does not introduce an additional hidden-geometry dependence. Iterating the equal joint rows proves equality of all finite emitted-record histories, including label policies depending on the retained record history. A policy reading discarded geometry is outside this admission. A record-only observer still filters the hidden p; it does not receive the realized p for free.

All operations remain at c_*. Under passive frame translations, the conditional Gaussian law and root coordinates are pushed together, residuals and p are invariant, and dressed cuts transform by their endpoint root translations. Consequently (4)–(5) inherit the source's gauge covariance. This is the translation example; it proves no noncommutative GL(K) extension.

## 4. Two stages on the actual same-tick joint law

At each inference tick draw the two finite auxiliary stages on one W, conditioning the second on the first cuts. Keep the shared history on the augmented fine and first-parent carriers. Let C_1 and C_2 be the source's marked projections, and C_12 their flattened-tree composite. The newly defined time row first advances H_1 once, then samples this joint geometry and hierarchy. It does not advance H_1 once per RG level.

Both parent stages retain (a,p). Hence the same calculation as (5) gives

\[
 T C_1=C_1\bar T_1,\qquad
 \bar T_1 C_2=C_2\bar T_2,\qquad
 T C_{12}=C_{12}\bar T_2.
 \tag{6}
\]

The second equality uses the second-stage law conditional on the actual first panel, not fresh unconditional edge means. Source equation (12) remains its strictly positive pair-then-merge event. The existing approximately 0.13921742 equilibrium probability is reused without rerunning that calculation. Direct and staged records are identical because every label's p is retained. The same argument applies to any fixed finite depth with the full catalog and compatible history carried once. It proves neither infinite-depth convergence nor a preferred stopping depth.

Across inference ticks the hierarchy is resampled. Across RG levels within a tick it is nested. This is an explicit membership-update process, not a fixed membership map evaluated repeatedly. There is no claim of a persistent ancestry registry across arbitrary splits and later mergers; adding such a registry would add memory.

## 5. Finite response stability and operational information

Define the state-conditioned response vector by all words on a declared finite panel of original-label probe schedules. For r=(j_1,...,j_L) and w in {0,1}^L, the next L ticks have

\[
 \mathcal R_{a,p}^{r}(w)=
    \prod_{\ell=1}^{L}
       (p_\ell)_{j_\ell}^{w_\ell}
       [1-(p_\ell)_{j_\ell}]^{1-w_\ell},
 \qquad (a_\ell,p_\ell)=H_\ell(a,p).
 \tag{7}
\]

Retain separate schedules and labels; do not average action forecasts. Include every label's one-tick probe when complete one-record information is wanted. The vector is independent of the root chart and discarded geometry for this experiment.

For every initial interior rank, a_t->a_* implies p_t->p_*. To prove quantile convergence, choose points on either side of the unique limiting quantile; parameter convergence gives convergence of their CDF values, trapping the new quantile between those points. Tightening the bracket proves the claim. With the common-uniform Bernoulli coupling, the response law at a late tick k and the limiting response law satisfy

\[
 \operatorname{TV}(\mathcal R_{a_k,p_k}^{r},
                    \mathcal R_{a_*,p_*}^{r})
 \le \min\left(1,\sum_{\ell=1}^{L}
                    |(p_{k+\ell})_{j_\ell}-(p_*)_{j_\ell}|\right)
 \longrightarrow0.
 \tag{8}
\]

This is a finite-horizon pathwise limit, with convergence in expectation under the prepared law by bounded convergence. It supplies no uniform rate over all initial states and endpoint ranks. For any fixed realized path and prescribed tolerance, it yields eventual stability of that response panel. No numerical tolerance or persistence threshold is selected here. At equilibrium p is fixed by H, so (7) is exactly the same at every tick, even while geometry and membership fluctuate.

The response is informative in a record-only sense, not merely in a hidden-state diagnostic. At equilibrium, two repeated probes of label j satisfy P(E_1=E_2=1)=E p_j^2, whereas two independent outputs of the constant mean predictor have probability (E p_j)^2. Their difference is Var(p_j)>0. Moreover, after observing success the next success probability is E p_j^2/E p_j, strictly above E p_j. A one-state process could reproduce this only by retaining extra history/filter state; it would cease to be the memoryless constant endpoint.

For the source's internal and cut labels those exact covariance gaps are respectively (-4+3 sqrt 2)/49 and (-2+3 sqrt 2)/49, approximately 0.00495185 and 0.04576818. The next-success forecasts after one observed success are approximately 0.89735842 and 0.63060194; after a failure they are approximately 0.84603764 and 0.44590291. These are original-label predictions accessible from records under the stated preparation. They are not evidence that one particular partition creates that information.

## 6. Membership episode lengths and survival-conditioned forecasts

For the pair partition R={{0,1},{2,3}}, conditional on p the full refreshed panel gives

\[
 s(p)=q_{01}q_{23}(1-q_{12})(1-q_{30}),\qquad
 q_e=p_{e,b}p_{e,m},\qquad A_k=E_{\nu_*}[s(p)^k].
 \tag{9}
\]

At equilibrium, panels are independent across ticks conditional on p. Every s(p) is strictly between zero and one. Initialize with nu_* and a stationary panel, and condition on an outside-to-R entrance at tick zero. This tilts the p law by s(1-s). Let T_R>=1 count consecutive R ticks starting with that entrance, and let l count additional survived ticks. Then

\[
 J=A_1-A_2,\qquad
 P(T_R>\ell\mid\text{entrance})=
       \frac{A_{\ell+1}-A_{\ell+2}}{J},\qquad
 E[T_R\mid\text{entrance}]=\frac{A_1}{J}.
 \tag{10}
\]

The last identity follows by telescoping and A_k->0, proved by bounded convergence since s<1. It is valid even though the whole equilibrium process has conserved p sectors. Starting at an arbitrary stationary tick conditioned on R instead tilts by s and gives A_(l+1)/A_1. That is a different preparation. Physical time and an event-only clock are not substituted for these base attempts.

For this source, let alpha_I=8+6 sqrt 2, alpha_C=1+sqrt 2, and m_X(k)=(alpha_X)_k/(alpha_X+2)_k. Beta integration gives

\[
 B_C(k)=\sum_{r=0}^{k}(-1)^r{k\choose r}m_C(r)^2,\qquad
 A_k=m_I(k)^4 B_C(k)^2.
 \tag{11}
\]

This evaluates all finite survival probabilities exactly in Q(sqrt 2). The entrance flux is approximately 0.19951240 per tick and the mean pair episode is approximately 1.55739681 ticks. A constant response vector at known p therefore coexists here with short membership episodes. These numbers do not establish slow organization.

An observer who is additionally informed of the entrance and l survived ticks has a changed p posterior. With C_j(k)=E[p_j s(p)^k], its label forecast is

\[
 P(E_j=1\mid\text{entrance},T_R>\ell)=
       \frac{C_j(\ell+1)-C_j(\ell+2)}
            {A_{\ell+1}-A_{\ell+2}}.
 \tag{12}
\]

For one internal label, C_j(k)=m_I(k+1)m_I(k)^3 B_C(k)^2. For a cut label, replace one B_C(k) in (11) by sum_r (-1)^r choose(k,r)m_C(r+1)m_C(r). The exact calculation finds that one additional survived tick raises the internal-label forecast by approximately 0.00480604 and lowers the cut-label forecast by approximately 0.02870286. Thus retained-state response stationarity does not imply that an observer learning from survival has a fixed forecast. Membership information was not added to the original external sensor; this is a separately labeled diagnostic experiment.

Away from equilibrium, conditional on (a,p), fresh panels remain independent with deterministic success probabilities s(p_k). The finite continuation probability is the product of those probabilities over the requested ticks. Its finite-window limit follows from p_k->p_*. Stationary entrance formulas (10) are not applied to that transient law.

## 7. Complete cost and the record-only comparison

The unchanged geometry arrays use 32 real coordinates for the fine four-cycle, 24 on the pair event, and 16 at the grandparent. The same 24 algorithm coordinates give totals 56, 48 and 40, respectively. These are sample-plus-algorithm arrays in the same augmented experiment, not minimal dimensions or measured bits. All panel/root/tree/incidence history, shared original labels, the fixed 280 generic Gaussian-conditional coefficients and the training archive remain present on both sides. Singleton outputs can cost more; adding 24 to the source's full partition averages gives approximately 46.94175888 and 42.78736554 after one and two stages.

At each new tick p is transported rather than redrawn. Every implementation needs the native-flow evaluation and the beta CDF/inverse operations. The fine conditional geometry sampler uses eight angles and sixteen Gaussian mean coordinates; the pair and grandparent samplers use eight angles plus eight or four Gaussian root coordinates. The corresponding continuous random-input counts are 24, 16 and 12 per tick, alongside finite auxiliary random choices. No continuous seed is retained, and no runtime saving is inferred from this accounting. A practical pseudorandom generator state, if used, belongs in both implementations.

The 24-coordinate native E/M state is not automatically a filter for new probe histories. At equilibrium, if only the original external records are observed, the p filter is a product of Beta(alpha_j*+S_j,2+F_j) laws, requiring two counts per label: sixteen counters, shared by fine and parent descriptions. They may be reused as updated filter parameters instead of stored twice when implementing the same information. If memberships are observed as well, their likelihood factors must be included and can correlate labels. If learning is still transient, a record at time k has likelihood evaluated at the transported p_k; its filter generally does not remain beta. An exact specification stores a measure on the eight initial ranks and updates it with those factors, or retains the record schedule/history needed to reconstruct that measure. No uniformly bounded finite-dimensional transient filter is proved here. Any such cost is shared by the exact fine and complete-parent path constructions, but it prevents a blanket total-memory advantage claim.

The beta-filter caveat has a local obstruction in the native example of Section 2. At (alpha,beta,u)=(1,1,1), a just-observed success changes the initial p density from f(p)=2(1-p) to g(p)=6p(1-p). Keep the training archive fixed and transport this filtered density with the same H_t that realizes the unfiltered recognition law. The transport velocity is v(p)=-p[(2-p)log p+1-p]/[2(1-p)]. Since the unfiltered density has score dot f/f=log p+3/2, the transported filtered density has score

\[
 -\frac{(v g)'(p)}{g(p)}
 =\log p+\tfrac32-\frac{v(p)}p
 =2+\frac{4-3p}{2(1-p)}\log p.
 \tag{13}
\]

A beta-family tangent lies in the span of 1, log p and log(1-p). The displayed score is bounded as p approaches one, forcing the log(1-p) coefficient to vanish. Its expansion at zero would then force the other coefficients to be 2 and 2. But its limit at one is 3/2, whereas 2+2 log p tends to 2. Thus this filter immediately leaves the beta manifold under the underlying native rank transport. This proves failure of continuous-flow beta invariance, not impossibility of another finite filter or a theorem that every isolated unit-time image is non-beta. The equilibrium conjugate counter remains valid.

There is also a group-free response carrier (a,p). Equations (2) and (7) give its normalized deterministic transition and every original-label response. Given (a,p), adding the geometric parent and partition supplies no additional prediction of those records. Conversely, the full one-tick label vector at the post-update state is p itself, so erasing any distinct p values loses that complete response family. At equilibrium this is immediate for the current state as well.

The group-free carrier uses 24+8 coordinates for the stated algorithm-plus-sample representation and preserves the same record filter; its count is below either complete geometric parent. It omits the mandated rooted geometric interface, so it is not a cheaper complete geometric meta-agent. It establishes a narrower and useful boundary: this label-only record experiment cannot by itself justify the extra geometry or attribute prediction quality to formation. A geometry-sensitive interaction or independently justified retention cost would need its own operational contract. No new sensor or penalty is selected here.

## 8. Evidence and resulting obligation

[kinetic_exact.py](evidence/kinetic-realization/kinetic_exact.py) ran once under pinned CPython 3.14.7, in 0.07648410000001604 seconds, and passed. It checks nine exact pair moments, seven entrance and occupancy survival values and their difference, the telescoping remainder, all episode-conditioned forecasts for both label classes, their nonzero survival-induced drift, the record-only covariance and Bayesian predictions, and the nonzero native velocity coefficient. It loads guarded exact-arithmetic helper definitions without running their prior main. [result.json](evidence/kinetic-realization/result.json) retains coefficients and environment information. No trajectory, Monte Carlo run, saved-data replay, broad suite, GPU work, Lean or tamper check ran.

The moving-law transport, normalization, complete path factorization, finite-depth composition and limiting response statements are the written arguments above. The exact arithmetic supports the named finite coefficients; it is not a proof of those general statements or a formal ledger certificate.

This closes the requested explicit kinetic-realization admission for the existing restricted family. It does not close the full formation program. In this process, panels and geometric marks do not feed back into (a,p), and the original-label response has a sufficient carrier independent of the grouping. Complete geometric sample reduction, response stability and actual membership updating now coexist, but there is no demonstrated formation-specific predictive advantage, long lifetime, or total transient-filter saving. The next substantive question is whether the existing source's parent-sensitive feedback can act on the retained learned probability/algorithm state while preserving a normalized model and useful complete closure. Its target and cost must be derived from the existing model or left explicitly unspecified; an arbitrary persistence reward, new dataset or chosen penalty would change the problem.
