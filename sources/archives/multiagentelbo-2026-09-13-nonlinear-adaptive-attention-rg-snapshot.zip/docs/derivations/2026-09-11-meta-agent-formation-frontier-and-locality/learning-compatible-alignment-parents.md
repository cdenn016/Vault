# Learning-compatible alignment parents and finite agreement strength

September 11, 2026 continuation. The saved agreement-sufficient parent family admits exact simultaneous recognition and model-prior learning when the learned prior changes only the retained agreement statistics. This gives a finite-strength native E/M closure and compatible staged law reductions under a stated restriction on model learning. It also exposes a distinction hidden by success-only conditioning: unconstrained concentration learning then runs toward a singular boundary, while one recorded failure can stabilize a finite, globally attracting learning equilibrium in an exact two-channel example.

These are analytical model-family constructions within the existing normalized law-valued branch. They do not modify the saved heterogeneous experiment, replace its labeled observations by an aggregate flag, establish a particle trajectory for latent links, or select a useful hierarchy. The newly varied prior family is stated explicitly below.

## 1. Sources and the remaining learning question

[normalized-alignment-parent-limit.md](normalized-alignment-parent-limit.md) already supplies normalized success/failure kernels, full-law alignment inference, concentration limits, and conditional parent recursion. Its Gaussian GL(K), singular-holonomy, and critical-two-cycle extensions retain the required loop/direction marks and distinguish finite-strength dynamics from limiting closure. [agreement-sufficient-marked-parents.md](agreement-sufficient-marked-parents.md), Sections 1-5, already constructs the joint probability statistic, beta-mixture evaluators, marked common channels and fixed-target Fisher inference. Those are prior results, not new proposals here.

The outstanding point addressed here is simultaneous structural model learning. [pointwise-learning-parent-closure.md](pointwise-learning-parent-closure.md), equations (7)-(14), shows why changing a hidden conditional target normally generates memory. Its parameter-independent conditional case supplies an exact native exception. The [recent Gaussian attractor](native-attracting-sector-and-alignment-gap.md) does not itself align the children and must not be relabeled as this exception.

The normalized source is [Theory/05b_local_collective_elbo.tex](../../../Theory/05b_local_collective_elbo.tex), hyp:local-interaction-kernels and the binary-kernel passage following eq:obs-interaction-energy. It permits law-valued agent states and a nonnegative sample energy in a normalized Bernoulli kernel. The current [Research concept](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires a complete law/evaluator/interface/memory construction. Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), sec:meta_agent_variational, separately leaves the net post-merge licensing gain to be derived. None of the results below supplies that gain by omitting a normalizer or an original observation.

## 2. Exact marked-parent closure with learned priors

Let W be the complete law/model/link state at c_*, with a proper correlated base law B. Let p(W)=(p_e(W)) contain every separately labeled agreement probability required by the experiment. For example p_e=exp(-w_e D_e), with the actual transported KL D_e of that channel. Work on interior probabilities and a regular exponential-family domain. Define

\[
 T(p)=(\log p_e,\log(1-p_e))_e,\qquad
 A(\theta)=\log\int e^{\theta^\top T(p(W))}B(dW).
 \tag{1}
\]

Use a minimal identifiable set of these statistics; if the actual geometric probability support creates an affine dependency, remove that redundancy before inverting a Fisher matrix. Their actual joint induced law is used. Independent beta marginals for incompatible two-channel geometries are not assumed.

The model-family choice introduced in this continuation is

\[
 P_\theta(dW)=e^{\theta^\top T-A(\theta)}B(dW),\qquad
 Q_\eta(dW)=e^{\eta^\top T-A(\eta)}B(dW).
 \tag{2}
\]

Thus the model learns the prior weights of already retained record statistics. It does not freely vary the conditional geometry at fixed p. This restriction is the admission making exact closure possible, not a conclusion that arbitrary independently optimized structural links satisfy it. For an ordered record string with count vector c=(successes,failures), the likelihood is exp(c^T T). All labels/order stay in the record archive; no binomial multiplicity is inserted. The normalized evidence and target are

\[
 e_\theta=\exp[A(\theta+c)-A(\theta)],\qquad
 \Pi_\theta=Q_{\theta+c}.
 \tag{3}
\]

Let m=grad A and G=Hess A=Cov(T). Use the full recognition Fisher metric and the complete normalized generative model Fisher. The latter is G(theta), because the fixed record kernels have no theta derivative conditional on W. The native coupled flow is

\[
 \dot\eta=\theta+c-\eta,\qquad
 \dot\theta=G(\theta)^{-1}[m(\eta)-m(\theta)].
 \tag{4}
\]

Indeed the exact objective is

\[
 \mathcal F=(\eta-\theta-c)^\top m(\eta)-A(\eta)+A(\theta).
 \tag{5}
\]

Its eta gradient is G(eta)(eta-theta-c), and its theta covector is m(theta)-m(eta). Therefore

\[
 \dot{\mathcal F}=-(\eta-\theta-c)^\top G(\eta)(\eta-\theta-c)
 -[m(\eta)-m(\theta)]^\top G(\theta)^{-1}[m(\eta)-m(\theta)]\le0.
 \tag{6}
\]

These equations hold while the trajectory stays in the admitted regular domain. They do not alone prove global existence or a finite model optimum. If the learned model is a subfamily theta=theta0+E lambda, use the induced metric E^T G(theta)E and structural vector [E^T G(theta)E]^{-1}E^T[m(eta)-m(theta)], while keeping the first equation of (4). This includes the one-parameter example below.

Disintegrate B as nu(dp)Psi(dW|p). Every prior, posterior and matched recognition in (2) has the same conditional Psi. If a normalized marked-parent channel retains the full p catalog and draws its other marks using the fixed conditional rules of the saved construction, its conditional laws given the complete retained parent are likewise independent of theta and eta. Its prior, posterior and Q therefore have the same hidden conditional. The conditional KL is zero, all scores T-m are retained-measurable, and the complete and parent Fisher matrices and structural covectors agree. Applying that channel to (4) gives exactly the parent law evolution, including model learning.

Two compatible marked channels that both retain the original p catalog and required loop/cut/history marks inherit this property. Their composition is the same normalized push as direct reduction, and the coupled law trajectories commute with both stages. This extends the previous fixed-prior result to the admitted learned-prior family. Shared probabilities, shared observations and structural parameters are counted once in the full joint incidence structure. Independently multiplying parent marginals is still invalid.

This is an exact trajectory of recognition/model probability laws. The earlier counterexample for a deterministic angular trajectory of individual latent links is unchanged: no stochastic process or particle ODE on W is specified by the one-time laws Q_t. Changing the conditional geometry Psi with a learned parameter would reintroduce precisely the moving-target memory in the existing derivation. Retaining the full probability catalog can also cost as much as the original operational interface. The theorem does not establish a useful membership rule, computational gain, two-channel beta realizability, or full hierarchy completion.

## 3. Success-only concentration learning escapes to a boundary

A scalar specialization explains why finite-strength model learning needs its own existence analysis. Let D(W)>=0 be nonconstant and finite B-almost surely, with essential infimum zero. Let

\[
 Z(\rho)=\int e^{-\rho D}B(dW),\quad
 P_\rho=Z(\rho)^{-1}e^{-\rho D}B,\quad
 m_\rho=E_{P_\rho}D,\quad V_\rho={\rm Var}_{P_\rho}D.
 \tag{7}
\]

Start at rho0>0 so all needed energy moments are finite. Nonconstancy makes V_rho>0 at every finite rho. A success record has probability exp(-D), and its failure probability is 1-exp(-D). This may be an explicitly selected combined-success flag; it must not substitute for separately observed labels. For n>=1 fixed successes and recognition initially Q=P_rho0, write Q=P_alpha. Equation (4) becomes

\[
 \dot\alpha=\rho+n-\alpha,\qquad
 \dot\rho=\frac{m_\rho-m_\alpha}{V_\rho}.
 \tag{8}
\]

The prior log normalizer in (7) is indispensable in the second equation. It is actual model-Fisher preconditioning, not Euclidean descent on a group coordinate. Set Delta=alpha-rho. Since m'_rho=-V_rho<0,

\[
 0\le\Delta(t)\le n,\qquad \dot\rho\ge0,\qquad
 \dot\alpha=n-\Delta\in[0,n].
 \tag{9}
\]

To prove invariance, at Delta=0 its derivative is n; at Delta=n its derivative is -dot rho<0. The parameters stay above rho0 and alpha(t)<=rho0+nt, so smoothness on compact finite-parameter intervals gives global existence for this preparation. If rho had a finite limit, the first equation of (8) would give alpha->rho_infinity+n. The second would then tend to a strictly positive number, contradicting bounded rho. Thus rho and alpha both diverge.

The existing exponential-tilt concentration argument gives Q_t(D>epsilon)->0 for every epsilon>0 and m_alpha->0. At every finite time Q_t remains equivalent to B; if B(D=0)=0, it never becomes exactly coherent at a finite time. In particular this model has no finite interior E/M equilibrium. It explains all successes increasingly well by making its own prior concentrate on agreement. This is a boundary limit in a declared learning family, not evidence that an arbitrary fixed prior yields finite-time coalescence.

The regular coherent and admitted singular results already supply cases where

\[
 m_\rho\sim a/\rho,\qquad V_\rho\sim a/\rho^2,\qquad a>0.
 \tag{10}
\]

For a regular normal integral a=d_perp/2. The critical logarithmic case also has these leading moment forms by its recorded Gamma-limit and uniform energy-moment control; its additional geometric marks remain required. Under (10), the ratio V_(rho+s)/V_rho tends to one uniformly for 0<=s<=n. Using m_rho-m_(rho+Delta)=integral_0^Delta V_(rho+s)ds in (8) yields dot rho=Delta[1+o(1)], and Delta obeys dot Delta=n-[2+o(1)]Delta. A stable scalar comparison proves

\[
 \Delta\longrightarrow n/2,\qquad \rho(t)/t\longrightarrow n/2,
 \qquad E_{Q_t}D\sim\frac{2a}{nt}.
 \tag{11}
\]

Thus the typical regular normal displacement is of order t^{-1/2}; no new slow learning coefficient is introduced. These are asymptotics in the declared inference time, not a physical clock.

The evidence and VFE accounting differ from the fixed-prior strong-record limit. The current evidence is Z(rho+n)/Z(rho), which tends to one. Here

\[
 \mathcal F=(n-\Delta)m_\alpha+\log Z(\rho)-\log Z(\alpha),
 \qquad 0\le\mathcal F\le n m_\rho\longrightarrow0.
 \tag{12}
\]

Under (10), F~2a/t. Both normalizers in (12) are present. The divergent fixed-base evidence term from the old n->infinity construction has not been silently dropped; the prior itself is now learned. Its limiting coherent parent measure is the previously derived coherent restriction of B when that limit is admitted. No new tangential selection rule follows from moving rho alone.

## 4. Both outcomes admit a finite globally attracting example

A fully evaluable example is available inside the source's fixed-unit-variance translation subclass. Use two agents, with belief-law points b_i=N(mu_i^b,1), model-law points m_i=N(mu_i^m,1), and two independent translation-link coordinates a_b,a_m. Let t_x=mu_2^x-mu_1^x, r_x=t_x-a_x for x=b,m. The complete state has six continuous coordinates. Set

\[
 z=(\mu_1^b,\mu_1^m,t_b,t_m),\qquad
 D=\tfrac12(r_b^2+r_m^2),\qquad
 p_u(z,r)=p_Z(z)\frac{u}{2\pi}e^{-uD},\quad u>0.
 \tag{13}
\]

Take any specified proper correlated Gaussian p_Z, possibly coupling the belief and model coordinates. The transformation between (z,r) and the original means/links has absolute Jacobian one. The covariance restriction to unit agent-law variance, the Gaussian residual prior, and its single learned concentration u are named specializations. The links are independent coordinates, not an imposed frame factorization. Their law changes as u and recognition change. The z marginal itself remains p_Z throughout this record-only example; the calculation does not claim that those mean-law marginals learn.

The two separate transported KLs are r_b squared/2 and r_m squared/2. Here the declared observation is their combined-success flag A, with K(1|W)=exp(-D) and K(0|W)=1-exp(-D). It is the conjunction of the two elementary successes if those elementary kernels are sampled conditionally independently and only that conjunction is observed. This is a separate analytical record protocol; it is not the full separately labeled experiment of Section 2 or the saved heterogeneous data.

Under p_u, D has the exponential density u exp(-uD), and p=exp(-D) has Beta(u,1). Condition on one specified ordered string with n>=1 successes and one failure. Its evidence is

\[
 e(u)=u\mathrm B(u+n,2)=\frac{u}{(u+n)(u+n+1)}.
 \tag{14}
\]

The product denotes those observed outcomes; no synthetic failure was collected. The beta identity is the existing evaluator from [NIST DLMF 5.12.1](https://dlmf.nist.gov/5.12.E1). It also follows here by integrating exp(-(u+n)D) times (1-exp(-D)). No binomial count multiplier is needed for an ordered string.

The exact recognition family is

\[
 q_{\alpha,\beta}(z,r)=p_Z(z)
 \frac{e^{-\alpha D}(1-e^{-D})^\beta}
 {2\pi\mathrm B(\alpha,\beta+1)},
 \qquad \alpha>0,\quad\beta>-1.
 \tag{15}
\]

Its prior-prepared initialization has alpha(0)=u(0), beta(0)=0. The transformed p law is Beta(alpha,beta+1), with

\[
 m(\alpha,\beta)=E_QD
 =\psi(\alpha+\beta+1)-\psi(\alpha),
 \quad m(\alpha,1)=\frac1\alpha+\frac1{\alpha+1}.
 \tag{16}
\]

This formula follows by differentiating the beta integral; all derivatives are integrable on compact subsets of alpha>0,beta>-1. The two recognition statistics D and log(1-exp(-D)) are linearly independent modulo constants, so their Fisher matrix is positive definite. The complete-model Fisher in u is Var_(p_u)D=1/u squared. The full native E/M equations are

\[
 \dot\alpha=u+n-\alpha,\qquad \dot\beta=1-\beta,
 \qquad \dot u=u-u^2m(\alpha,\beta).
 \tag{17}
\]

There is no conditional reset and no constrained metric replacement. The stationary point is unique:

\[
 u_* =\sqrt{n(n+1)},\qquad
 \alpha_*=u_*+n,\qquad\beta_*=1,\qquad E_{Q_*}D=1/u_*.
 \tag{18}
\]

Substitute (16) in dot u=0 to obtain u squared=n(n+1). The evidence (14) tends to zero at both u->0 and u->infinity, and its log derivative has numerator n(n+1)-u squared over a positive denominator. Hence (18) is its unique strict interior maximum.

There is also a global convergence proof for (17), for every u(0)>0, alpha(0)>0, beta(0)>=0. The exact F=KL(Q||Pi_u)-log e(u) decreases under the product-Fisher flow. Its finite initial value and F>=-log e(u) keep u in a compact positive interval, by the two boundary limits of (14). The stable alpha filter in (17) then bounds alpha above and away from zero. The explicit solution beta=1+(beta(0)-1)exp(-t) keeps beta in a compact subset of beta>-1. Thus the complete solution stays in a compact regular domain and exists globally. The dissipation vanishes only when alpha=u+n, beta=1 and m=1/u, namely at (18).

For completeness, convergence follows directly from this compactness and strict dissipation. F has a limit. A nonstationary accumulation point would have dot F bounded above by a negative constant on some neighborhood. The bounded smooth vector field would force a uniform positive loss of F on each sufficiently close return, contradicting that limit. Every accumulation point is therefore stationary, and uniqueness of (18) makes the entire trajectory converge to it. This establishes convergence from prior preparation as well as from the larger displayed initial family; no numerical integration substitutes for this argument.

For n=1 the exact values are

\[
 u_*=\sqrt2,\quad E_{Q_*}D=1/\sqrt2,\quad
 M=1/2,\quad P={\rm Var}_{Q_*}D=9/2-3\sqrt2,
 \quad A=\left.\partial_u^2[-\log e(u)]\right|_{u=u_*}=3\sqrt2-4>0.
 \tag{19}
\]

The linearized alpha/u sector has characteristic polynomial lambda squared+2lambda+A/M, and beta has eigenvalue -1. Its decay rates are 1 plus or minus sqrt(9-6sqrt2), together with 1. These are derived native rates, not chosen time scales. The next combined agreement probability and current model-prior probability differ:

\[
 E_{Q_*}e^{-D}=\frac{1+2\sqrt2}{7},\qquad
 E_{p_{u_*}}e^{-D}=2-\sqrt2,
 \qquad e(u_*)=3-2\sqrt2.
 \tag{20}
\]

The general stationary mean mismatch in (18) is of order 1/n for large numbers of observed successes and one failure. At every fixed n it is positive, and exact coherence has zero probability. This supplies finite-strength joint learning and calibrated disagreement, rather than replacing mixed records by an all-success limit.

## 5. A complete sufficient channel for this restricted experiment

In (13)-(17), retain the root belief/model law points and the residual energy:

\[
 C(W)=(\mu_1^b,\mu_1^m,D).
 \tag{21}
\]

This is a fixed normalized deterministic channel on the six-dimensional random source. Given the roots, the relative-frame coordinates (t_b,t_m) follow the same p_Z conditional for every u,alpha,beta. Given D>0, the residual vector has uniform angle on its radius-sqrt(2D) circle, independently of u,alpha,beta and z. The D=0 conditional can be defined arbitrarily on its common null set. Thus the entire discarded conditional is common to prior, posterior and every Q in (15).

The parent's static prior is the two-root marginal of p_Z times Exp(u) on D; its recognition law has the corresponding transformed beta density on D. The record evaluator is exp(-D) for success and its complement for failure. Its model presentation is indexed by the genuinely learned scalar u; this is structural prior learning, not a Bayesian distribution over u. Every E/M score in (17) is retained-measurable, so the conditional-KL defect is zero and the full and parent Fisher metrics/covectors agree. The normalized generative, posterior and recognition pushes therefore reproduce the exact coupled trajectory (17).

The random carrier has continuous dimension six before this channel and three after it. The evolving inference/model parameters are (alpha,beta,u) on both sides: three to three. Both descriptions require the observation archive and the fixed correlated p_Z specification or its requisite marginal/conditional data; a claim about reconstructing discarded child presentations must count that conditional. There is no measured computation or complete resource-gain claim from the random-coordinate count alone. The root law coordinates have unchanged marginals in this particular construction. Nor does one closed two-child example supply two proper first-level blocks and a learned second parent.

The restriction to the combined flag is substantive. Residuals (1,2) and (2,1) have the same D=5/2 but different labeled energies (1/2,2) and (2,1/2). Their separate belief/model success probabilities are exchanged. Consequently (21) does not preserve separately labeled channel queries, cut-edge records reading discarded directions, or arbitrary individual-child evaluations. Those experiments require additional retained information. Section 2 handles labeled records only by retaining the full actual p vector and its required marks; it cannot inherit this three-coordinate count by renaming the combined flag.

## 6. Evidence and the next hierarchy obligation

The [exact calculation](evidence/learned-alignment/result.json) contains 27 rational success-only vector-field cases, twelve beta-integral/moment cases checked by direct alternating exponential integrals, and arithmetic in Q(sqrt2) for (18)-(20) at n=1. It also records the separate-label obstruction just described. It passed once under pinned CPython 3.14.7 with -I -B in 0.0009285999994972371 seconds. No ODE trajectory, new record collection, statistical fit, prior scientific rerun, broad suite, GPU work, Lean or tamper check was executed. The general closure, divergence and convergence results are the written arguments, not a numerical sweep or formal ledger certificate.

The preceding goal turn was progress. This continuation used three sequential substantive passes: extend common-conditional marked parents to native learned priors; derive success-only concentration escape; and construct mixed-record finite learning with a normalized sufficient-parent example and exact checks. The original fifteen heterogeneous negative admissions and all previous geometric/path limitations remain unchanged.

The admitted positive result is now sharper: changing a model's retained-statistic prior can preserve exact marked-parent E/M closure, and both record outcomes can yield finite globally stable learning in an explicit two-channel law-valued example. The remaining hierarchy question concerns the actual multi-label, multi-block joint: whether these learned probabilities yield informative persistent membership and a second useful parent after the full probability/mark/filter costs, without replacing original labels by a combined flag or treating auxiliary membership panels as fresh external evidence. The saved marked-parent channel and beta-mixture construction are the starting point for that question. No numerical tolerance, penalty, new dataset, base transport or full goal completion is implied.
