# Unit-start second merge and positive-prior persistence

September 12, 2026. The unchanged unit-prepared native learner enters a second-merge-favored regime in the existing transported Gaussian specialization. For the limiting fixed-pair prior, an outward interval calculation encloses its actual coupled trajectory through native time 40. Both the recognition-law merge probability and the current model-posterior merge probability exceed one half throughout [35,40]. A written finite-time continuity argument extends this strict episode to a nonempty open family of fixed, strictly positive priors on all twelve admitted ancestries. No numerical positive prior is chosen.

This supplies native entry and a finite persistence interval beyond the earlier static common-scale construction. It does not show a first-level transition from an initially preferred one-block ancestry under the same prior. The nearby-P family can prefer the pair from the beginning. The common auxiliary panel also remains a diagnostic with an explicit support cost; full resource licensing and a useful learned hierarchy are still open.

## 1. Source and fixed preparation

[The native shared-parent learner](shared-parent-native-learning-and-memory.md), Sections 4-6, defines one normalized negative ELBO, its complete-model Fisher metric, the full recognition flow and its count memory. [The transported-prior construction](transported-parent-priors-and-induced-couplings.md) supplies the current covariance maps and primitive energies. [The inherited second-level calculation](second-level-prior-learning-and-agreement.md) defines the actual parent-cut probabilities. [The scale classification](second-merge-scale-regime-and-native-barrier.md) finds a favorable static curve without identifying it with native time. [The preceding boundary analysis](native-boundary-attraction-and-second-merge-limit.md) proves local attraction to a split-favored limit but leaves unit-start entry and transient excursions undecided. The current calculation resumes that preparation question.

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, distinguishes the shared-prior barycenter, a coherence detector and a free-energy/resource license. The [operational wiki definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) and its [formation source](<C:/Users/chris and christine/Desktop/Research/sources/manuscripts/multiagentelbo-2026-09-11-formation.md>) retain joint law, evaluator, access, structural marks and memory. Those requirements remain part of the target. Work stays at one base point and preserves the original graph, ordered records, two channels and learned-prior family.

Write P={{0,1},{2,3}}. The reference prior pi_P=1 retains all four of its root decorations. It is a boundary reference used to prove a later proper-prior result. Keep the matched root variance v=1 and the exact-posterior preparation s=1. Initially every model variance a_j and recognition variance r_j equals one, for j=a,b,c. The six native equations are

\[
 \dot a_j=\frac{\langle E_j\rangle_{Q_r}}{d_j}-a_j,

 \dot r_j=r_j(1-r_j/a_j),
 (d_a,d_b,d_c)=(16,8,16).
 \tag{1}
\]

The d_b=8 denominator applies to this fixed-P reference. The full ancestry learner uses its prior expected block count and recognition count moment, restored in Section 6. The parameter t is the existing native inference time. Neither a physical sample-path clock nor a new learning rate is introduced.

For each decoration H and original failure subset S, let

\[
 \begin{aligned}
 \Gamma_H(r)&=r_aG_a+r_bG_b+r_cG_{c,H},\\
 D_{H,S}(r)&=\det[I+\Gamma_H(r)\operatorname{diag}(n+1_S)],\\
 e_H(r)&=\sum_{S\subseteq E}(-1)^{|S|}D_{H,S}(r)^{-1},
  n=(8,1,8,1).
 \end{aligned}
 \tag{2}
\]

Every covariance Gram term is positive semidefinite. The determinant polynomials have constant term one and positive remaining nonzero coefficients. The four decorations have three distinct covariance maps with their exact multiplicities retained. The two-channel evidence is Z(r)=sum_H w_H e_H(r)^2. It is not the square of an averaged one-channel integral.

Set x_j=log a_j and y_j=log r_j. With S_j=sum_H w_H e_H partial_j e_H, differentiation of the normalized Gaussian factors gives the actual log-coordinate field

\[
 \begin{aligned}
 \dot x_j&=e^{y_j-x_j}-1
       +\frac4{d_j}e^{2y_j-x_j}\frac{S_j(r)}{Z(r)},\\
 \dot y_j&=1-e^{y_j-x_j}.
 \end{aligned}
 \tag{3}
\]

Thus the validation evaluates the same energy-moment equations as (1). The recognition variances remain distinct from the model variances.

## 2. The numerical continuation changed the next obligation

The previous DOP853 diagnostic already stored every accepted state and its dense polynomial on [0,20]. One new calculation continued from that saved time-20 endpoint to time 120, with relative tolerance 10^-10, absolute tolerance 10^-12 and maximum step 0.25. The earlier interval was not reintegrated. This produced 401 new accepted steps and 6,017 right-hand-side calls in 0.37310689999867463 seconds under existing Anaconda Python 3.12.7, NumPy 2.0.0 and SciPy 1.16.0.

| Native time | Numerical recognition merge probability |
| ---: | ---: |
| 20 | 0.4556486287 |
| 25 | 0.4813128291 |
| 30 | 0.5005947631 |
| 40 | 0.5254967250 |
| 60 | 0.5464033009 |
| 80 | 0.5520407760 |
| 120 | 0.5515749367 |

The diagnostic detected one upward half-merge event near 29.8215067842. Its largest value at accepted states was approximately 0.5527441877 near time 94.30. These are numerical observations from [continuation.json](evidence/native-transient/continuation.json), not a certified crossing time, global maximum, return time or infinite-time result. The minimum recorded signed-sum ratio was approximately 2.2851 x 10^-5.

The crossing supplied a specific new obligation: enclose the existing candidate path only through time 40, where the readout has a useful strict margin. No further trajectory extension, stationary search, new initialization or numerical positive-prior selection was run.

## 3. A posteriori enclosure of the actual native path

The [path program](evidence/native-transient/validate_saved_path.py) treats the stored dense representation as a fixed piecewise polynomial candidate p(t) in the six log coordinates. Every binary floating-point coefficient and segment endpoint is interpreted as an exact rational number. Its actual polynomial, rather than a solver tolerance, is checked against (3). A change between adjacent polynomial pieces is charged as an additional candidate jump.

The error is measured with the constant matrix

\[
 W=\operatorname{diag}(1,1/\sqrt2,1,1,1/\sqrt2,1),
  \|v\|_W=\|Wv\|_2.
 \tag{4}
\]

This matrix is used only to bound numerical error. It changes no native update. The square root is enclosed using an integer square root of the exact dyadic numerator.

The [arithmetic kernel](evidence/native-transient/dyadic_interval.py) represents each interval endpoint as an integer divided by 2^128. Addition, multiplication, division and reciprocal use integer floor and ceiling operations. Exponentials use monotonicity, range reduction and a positive Taylor series. For 0<=z<=1/2, the exact bound is

\[
 \sum_{k=0}^{48}\frac{z^k}{k!}
 \le e^z
 \le \sum_{k=0}^{48}\frac{z^k}{k!}
       +\frac{z^{49}/49!}{1-z/50}.
 \tag{5}
\]

After the first omitted term, the ratio of consecutive positive terms is at most z/50, proving the upper tail bound. Repeated squaring reverses the range reduction. Negative arguments use reciprocal, and every arithmetic operation remains outward. No platform exponential approximation supplies an acceptance inequality.

For a normalized subinterval coordinate u in [-1,1], automatic derivative jets propagate the determinant sums and complete rational output expressions. The determinant coefficients and all necessary partial derivatives are exact. Each jet coefficient encloses the corresponding derivative divided by its factorial. For a scalar analytic composition h, Taylor's formula applied to its kth derivative gives

\[
 \frac{h^{(k)}(u)}{k!}
 =\sum_{l=k}^{N-1}\binom{l}{k}h_l(0)u^{l-k}
   +\binom Nk h_N(\xi)u^{N-k},
  h_l=h^{(l)}/l!,
 \tag{6}
\]

with xi between zero and u. Interval evaluation over the full subinterval encloses the remainder. This tightens every derivative coefficient before reciprocals of evidence normalizers are formed. The final path calculation uses order 16 for the defect and order 12 for the complete Jacobian expressions. Subintervals have length at most 1/8; the actual stored numerical polynomials remain unchanged.

Let R_i bound ||W(f(p)-p dot)||_2 on one subinterval. It is bounded by the sum of the weighted component bounds obtained from (6). Let J be the Jacobian of (3) on a tube around the candidate. The program encloses the symmetric part of W J W^-1. Write C for the exact rational midpoint of this symmetric enclosure and R for its entrywise radius matrix. If

\[
 qI-C\succ0,
  \rho=\max_i\sum_j R_{ij},
 \tag{7}
\]

then its largest eigenvalue is at most q+rho. Indeed, for any symmetric perturbation E with |E_ij|<=R_ij, the inequality 2|v_i v_j|<=v_i^2+v_j^2 bounds |v^T E v| by rho ||v||_2^2. The positive-definite condition in (7) is checked by exact rational LDL pivots. A floating-point eigenvalue calculation only proposes q; the rational factorization decides the bound. All 36 analytic Jacobian entries were also compared with directional differentiation at the identified discriminator state.

Consequently the true native solution z(t) satisfies the upper right derivative inequality

\[
 D^+\|z-p\|_W\le L_i\|z-p\|_W+R_i,
  L_i=q_i+\rho_i,
 \tag{8}
\]

while it stays in that tube. To see this, write f(z)-f(p) as the integral of J along the segment from p to z, differentiate the squared weighted norm when nonzero and bound the defect by Cauchy-Schwarz. The zero-error case follows from the upper right derivative.

For a subinterval of length h, let b_i be the incoming error bound including its candidate jump. The program uses the conservative consequences

\[
 \begin{aligned}
 b_{i+1}&\le e^{L_i h}b_i
       +h\max(1,e^{L_i h})R_i,\\
 \sup_{0\le s\le h}\|z(t_i+s)-p(t_i+s)\|_W
       &\le \max(1,e^{L_i h})(b_i+hR_i).
 \end{aligned}
 \tag{9}
\]

These follow by integrating (8). Each computed within-step bound is strictly below the lower endpoint of the declared tube radius. A first-exit argument therefore justifies the tube hypothesis used to obtain it. The exact initial error is zero, and the local bounds and charged jumps concatenate through time 40.

The final calculation passed 365 such subinterval checks in 199.83911960000114 seconds. Its endpoint weighted log-state error is below 4.2970 x 10^-9, and the bound throughout [0,40] is below 4.3 x 10^-9. Therefore every individual log-coordinate error is below 8.6 x 10^-9 throughout that interval. The exact rational bounds, symmetric matrix enclosures and positive LDL pivots are saved in [path-enclosure.json](evidence/native-transient/path-enclosure.json). This is an enclosure of the true ODE solution against the stored candidate, not another numerical integration.

Two earlier attempts are retained. The first only tightened normalizer values and failed its error cap near time 0.00325. The second tightened normalizer derivative coefficients but left the complete Jacobian expressions too broad; it failed its tube inequality near time 0.423. One-interval calculations isolated the excess remainder and dependency bounds. The successful version tightens the complete output expressions at the recorded higher orders. No model, preparation, trajectory coefficient or acceptance error cap was changed to make an attempt pass. Exact source snapshots accompany the failed attempts.

## 4. The complete merge readout is above one half

For the existing two parent-cut functions, put

\[
 t_1=(1/2,1,1/2,0),
  t_2=(1/2,0,1/2,1).
 \tag{10}
\]

For a mask A subset of {1,2}, add sum_{j in A} t_j^T t_j to the exponent matrix in (2), and denote the resulting integrals by e_{H,A}. The exact two-channel numerator and the common auxiliary merge readout are

\[
 Z_A(r)=\sum_H w_H e_{H,A}(r)^2,

 M_P(r)=\frac{Z_{\{1\}}(r)+Z_{\{2\}}(r)-Z_{\{1,2\}}(r)}
                   {Z_{\varnothing}(r)}.
 \tag{11}
\]

This retains the conditional independence of the two flags and the correlation induced by their shared continuous state and decoration. The 48 unshifted determinant polynomials were reused; 144 activated polynomials were computed exactly. Their unit evaluation reproduces the saved exact merge probability below one half.

The recognition readout is M_P(r(t)). The current model-posterior readout is M_P(a(t)). They differ because native recognition lags. Combining their exact determinant formulas with the enclosed state at time 40 gives the conservative displayed intervals

\[
 \begin{aligned}
 0.5254967190&<M_P(r(40))<0.5254967309,\\
 0.5273019505&<M_P(a(40))<0.5273019621.
 \end{aligned}
 \tag{12}
\]

The full rational endpoints are in [the entry enclosure](evidence/native-transient/second-merge-entry-enclosure.json). Its simpler rectangular bounds did not prove the requested [35,40] window; that failed wider-window decision is retained as false in the output. It does not negate (12).

A separate calculation applies order-10 derivative jets to the complete rational readout (11), preserving its dependence on the same candidate polynomial and error tube. Its 41 covering intervals prove, uniformly for every t in [35,40],

\[
 M_P(r(t))>0.5130,
  M_P(a(t))>0.5154.
 \tag{13}
\]

The exact saved lower bounds are approximately 0.5130100825903775 and 0.5154393703622601, respectively. [The window enclosure](evidence/native-transient/merge-window-enclosure.json) passed in 13.082488699998066 seconds. The initial unit value is approximately 0.2938789175. Continuity therefore proves at least one crossing before time 35 and a merge-favored episode lasting throughout the five-unit native interval [35,40]. It does not prove a unique crossing, the numerical crossing time near 29.82, or eventual return below one half.

The earlier local boundary theorem remains consistent with this result. Its attracting reference limit has M approximately 0.4872933347. The unit-prepared path now has a certified finite merge-favored interval through time 40; whether it later enters that particular boundary basin is still open. Its numerical continuation through time 120 is not an infinite-time certificate.

## 5. Original evidence improves along this same learner

The source's normalized negative ELBO has the identity

\[
 F(Q,\theta)=\operatorname{KL}(Q\Vert P_\theta(\cdot\mid d))
              -\log Z_\theta(d).
 \tag{14}
\]

At the unit preparation Q_0 is the exact model posterior. At the P reference, at least one model gradient is nonzero there, as the saved exact energy moments and (1) show. The complete-model Fisher metric is positive definite. Hence native descent has dot F(0)<0, while dot F<=0 for every later finite time. It follows that F(t)<F(0) for every t>0 and therefore

\[
 Z_{\theta(t)}(d)>Z_{\theta(0)}(d),
  t>0.
 \tag{15}
\]

This strict argument uses the actual coupled recognition and model flow; recognition need not remain an exact posterior. It also persists for priors sufficiently close to P because the nonzero initial gradient is continuous. Thus the favorable episode in (13) occurs with improved original-data model evidence, rather than on an externally prescribed scale curve.

## 6. A proper full-prior family has the same finite episode

Restore all twelve ancestry priors pi_R and the count memory lambda=omega-2 log rho_b. The full variance equations for a and c retain (1). The b equation and count memory are

\[
 \begin{aligned}
 \dot b&=\frac{\langle E_b\rangle_Q}{4K_\pi}
            -\frac{\langle k\rangle_Q}{K_\pi}b,
        K_\pi=\sum_R\pi_R k(R),\\
 \dot\lambda&=-\lambda-2[x-1-\log x],
        x=r_b/b.
 \end{aligned}
 \tag{16}
\]

The recognition variance rates stay r_j(1-r_j/a_j). At the P vertex, lambda can be driven and nonzero during learning even though it is redundant in the conditional P law. To embed the six-variable reference into the full seven-variable field, retain its unique solution of the second equation in (16), starting at zero. It is bounded on [0,40] because the certified a,b,c,r coordinates stay in a compact positive region. Setting lambda to zero along that reference would give the wrong full-coordinate comparison.

On a compact neighborhood of this reference path, all determinant normalizers are positive and K_pi stays near two. The explicit full vector field and both complete readouts are smooth in state and pi. A finite derivative bound L and parameter derivative bound B give, for solutions with the same unit coordinate preparation,

\[
 \sup_{0\le t\le40}\|Y_\pi(t)-Y_P(t)\|
 \le B\|\pi-\pi_P\|\frac{e^{40L}-1}{L},
 \tag{17}
\]

with the usual value 40 when L=0. This is obtained by subtracting the integral equations and integrating the scalar Gronwall inequality. Choosing the prior neighborhood sufficiently small keeps that bound inside the chosen state neighborhood, completing the same first-exit argument. No numerical value for the prior-neighborhood radius is claimed.

Let S denote the single augmented event that ancestry is P and its two parents merge under the common auxiliary panel. Its recognition and model-posterior probabilities are

\[
 \alpha_\pi(t)=Q_\pi(P;t)M_P(r_\pi(t)),

 \beta_\pi(t)=P_{\theta_\pi(t)}(P\mid d)M_P(a_\pi(t)).
 \tag{18}
\]

At the P reference these reduce to the two quantities in (13). Their strict uniform gaps on the compact interval imply that, for every prior in a sufficiently small neighborhood within the simplex,

\[
 \alpha_\pi(t)>1/2,
  \beta_\pi(t)>1/2,
  35\le t\le40.
 \tag{19}
\]

The physical neighborhood contains a nonempty relatively open set with every pi_R>0. Every other ancestry then retains positive mass at every finite time. This gives the promised proper-prior result under one fixed prior per trajectory, without a hard ancestry selection or a time-dependent prior.

Initially both probabilities in (18) are at most the conditional P unit value, which is below one half. Thus a genuine second-merge entry occurs for each such prior. The neighborhood may also be shrunk so Q_pi(P;t)>1/2 throughout [0,40], since it equals one along the entire boundary reference. P is then the unique first-level MAP ancestry throughout that horizon.

This last fact limits the interpretation: the proof does not derive the first appearance of the pair from an initially preferred one-block ancestry. The earlier [O-to-P crossing family](native-ancestry-crossings-and-selection-loss.md) is a different admitted prior region. Their overlap with (19), or another single fixed prior producing both learned transitions, remains unproved. The new result establishes a learned second-level episode after a prior-favored first pair, not a complete endogenous hierarchy.

## 7. Selection cost and the remaining license

The panel is a common normalized channel on the complete state. Adding it as an unobserved auxiliary variable changes neither original evidence nor exact joint VFE. It creates no additional hierarchy observation. If the augmented recognition law is hard-conditioned on S, then

\[
 \operatorname{KL}(Q(\cdot\mid S)\Vert Q)=-\log\alpha,

 \operatorname{TV}(Q(\cdot\mid S),Q)=1-\alpha.
 \tag{20}
\]

In the window (19), these losses are strictly positive and below log 2 and one half, respectively. The reverse KL from the original full-support law to the restricted law is infinite. Neither improved agreement nor MAP preference makes this support restriction exact.

The fixed-model optimized restriction penalty uses beta rather than alpha. Minimizing the same augmented negative ELBO over recognition laws supported on S gives

\[
 F^*_{S,\theta}-F^*_\theta=-\log\beta\in(0,\log2).
 \tag{21}
\]

This follows by normalizing the model posterior on S in (14). Comparing with an unlearned fine baseline would charge unequal learning opportunities. A fair complete resource comparison must let the fine implementation use the same native moments, ancestry structure and analytic reductions.

The existing complete probability/energy channel, posterior reverse-kernel correction, correlated second-stage prior, screening and exact generator remain available. Retain the parent-cut arguments and selection marks required by later contractions. Native and density evaluation, generation, interface access, factorization, storage, filtering when required and organizational overhead must all enter the comparison. The current calculation establishes none of the missing total net benefit or selection-cost tradeoff by choosing a new coefficient.

## 8. Evidence and continuation boundary

The numerical continuation, failed enclosure attempts, successful path enclosure, endpoint readout and complete-window enclosure are separate artifacts under [evidence/native-transient](evidence/native-transient/). The 48 exact unshifted polynomial checks completed in 0.053626500004611444 seconds. The one-interval order discriminator completed in 0.3355731999981799 seconds. The complete-Jacobian discriminator checked 36 directional entries and completed in 0.6154587999990326 seconds. The endpoint and initial coarse-window program completed in 2.1007645999998203 seconds; its endpoint passed and its wider-window flag was false. The subsequent complete-output window program passed. No failed result is reclassified as a pass.

The three substantive passes were the one bounded numerical continuation, the a posteriori path/readout construction with recorded failed bound mechanisms, then the full-prior continuity and common-objective/support-cost derivation. The next obligation is a complete parent implementation and net resource/selection license for this admitted fixed-prior episode, with the first-level discovery limitation retained. The new episode supplies native second-level entry and a five-unit persistence interval, but does not discharge that full requirement.

The 323-file preservation baseline permits updates only to STATUS.md, RG-COMPLETION.md, RECORD.md and the September 12 change log. Earlier science, saved observations, source manuscripts and WIP remain preserved. No new data, sampled state or flag, second trajectory extension, stationary retry, numerical positive-prior search, production/configuration change, GPU, suite, Lean, tamper check, vault edit, publication or canonical synchronization occurred. No formal ledger or independent-review certificate is issued.
