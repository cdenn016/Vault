# Coherence and exact access to collective mean-shift responses

September 12, 2026. This bounded calculation concerns the current transported Gaussian generator at one base point, a fixed two-block ancestry, and a newly declared response query. The complete first parent preserves the original experiment and native learner, but it does not determine every fine-state response to that query. The obstruction is a global reflection ambiguity, not a generic local Jacobian-rank loss. A directional augmentation resolves the stated query; this is not a proof of persistent or preferred meta-agent formation.

## 1. Sources, assumptions, and exact target

The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), section `sec:epistemic_collapse`, expressly rejects perfect pointwise consensus as the formation target. Its appendix `eq:rg_closure` through `eq:rg_schur_flow` separates scalar-energy closure from force closure and leaves a small force residual as an independent hypothesis. The [current meta-agent wiki entry](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires a joint law, evaluator, boundary access, structural marks, and sufficient memory. These sources motivate examining response access; they do not establish the finite result below.

The [transported-parent construction](transported-parent-priors-and-induced-couplings.md), Sections 2–4, supplies the actual generator and updated child-noise energy. The [complete-parent construction](shared-parent-complete-channel-and-recursive-cost.md), Sections 3–7, supplies the carrier, original observation labels, structural marks, and common-reference disintegration. The older untransported helper was read for its primitive ordering and exact-arithmetic method, not executed or used as the current generator.

The supplied scope fixes ancestry A={0,1}, B={2,3}, roots 0 and 2, internal trees 01 and 23, directed cycle 01,12,23,30, and two independent two-dimensional law-mean channels x in {b,m}. Each child law has identity covariance in its channel. The continuous primitive vector is

\[
 X=(\epsilon_0,\epsilon_1,\epsilon_2,\epsilon_3,\xi_A,\xi_B,
       \ell_{01},\ell_{12},\ell_{23},\ell_{30},Y)\in\mathbb R^{44}.
\]

Every displayed primitive is a four-vector, with the two channels stacked. At any fixed positive variances a,b,c,v, these are independent centered Gaussians under the declared generator. Its density is positive everywhere. Set Z_A=Y+xi_A, Z_B=Y+xi_B and

\[
 g_0=g_2=0,\quad g_1=\ell_{01},\quad g_3=\ell_{23},
 \qquad \mu_i=Z_{R(i)}+g_i+\epsilon_i.
 \tag{1}
\]

The four energies are E_a=sum_i||epsilon_i||², E_b=||xi_A||²+||xi_B||², E_c=sum_e||ell_e||², E_v=||Y||². In particular E_a uses the transported residual in (1).

Write r_ij=mu_j-mu_i-ell_ij and p_e^x=exp(-||r_e^x||²/2). With fixed discrete ancestry and tree records suppressed from the notation, the complete first carrier is

\[
 F_1(X)=(p_8,E_4,z_A,z_B,V_{12},V_{30})\in\mathbb R^{28},
 \quad
 z_C=|C|^{-1}\sum_{i\in C}(\mu_i-g_i),
 \quad
 V_{12}=\ell_{01}+\ell_{12},\quad
 V_{30}=\ell_{23}+\ell_{30}.
 \tag{2}
\]

The new modeling choice is only a query: shift every child mean in block C by a declared u_C, hold the links fixed, and ask for the resulting original-cut Bernoulli probabilities. This is not a new observation, a new likelihood objective, an inferred intervention mechanism, or a dynamical law. With h^x=u_B^x-u_A^x and edge signs s_12=1, s_30=-1, its physical directed-edge form is

\[
 p_e^x(X,h)=\exp[-\|r_e^x(X)+s_eh^x\|^2/2].
 \tag{3}
\]

For an edge parametrized instead by its own target-minus-source shift, both signs become +1. The log-probability derivative with respect to that edge shift is -r_e at zero; the log-probability derivative with respect to its source-block shift is +r_e. No sign convention is implicit.

The exact statewise question is whether, for some open neighborhood U of h=0, there exist functions G_e^x such that for every admissible X and every h in U,

\[
 G_e^x(F_1(X),h)=p_e^x(X,h).
 \tag{4}
\]

Measurability or continuity of G is not needed for the negative result. The question is stronger than exact conditional or averaged prediction under the restricted native family; Section 7 keeps those targets separate.

## 2. What the existing carrier already determines

Work in one channel and suppress its superscript. Let

\[
 R=r_{01}=\epsilon_1-\epsilon_0,\quad
 S=r_{23}=\epsilon_3-\epsilon_2,\quad
 t=(R+S)/2,
\]
\[
 d_{12}=z_B-z_A-V_{12},\qquad
 d_{30}=z_A-z_B-V_{30}.
\]

The zero-sum contrasts within A are -R/2 and R/2, and those within B are -S/2 and S/2. Direct substitution into (1) gives

\[
 r_{12}=d_{12}-t,\qquad r_{30}=d_{30}-t.
 \tag{5}
\]

Consequently

\[
 w:=r_{12}-r_{30}=d_{12}-d_{30}
 \tag{6}
\]

is retained. In contrast, r12+r30=-(V12+V30)-(R+S) is not fixed by the marks alone. The cancellation identity for the entire directed cycle includes its two internal residuals.

The original probabilities retain q12=||r12||² and q30=||r30||². If w is nonzero, put J(w1,w2)=(-w2,w1). Then every compatible cut pair has

\[
 r_{12}=\alpha w+\beta Jw,\qquad
 r_{30}=r_{12}-w,
\]
\[
 \alpha=\frac{q_{12}+\|w\|^2-q_{30}}{2\|w\|^2},\qquad
 \beta^2=\frac{q_{12}}{\|w\|^2}-\alpha^2.
 \tag{7}
\]

These equations follow by expanding ||r12-w||². The radicand is nonnegative on the actual image. When it is positive there are at most two residual pairs, distinguished by sigma=sign det(w,r12). When it is zero the pair is unique. The other carrier statistics can remove a branch in a particular fiber; they cannot remove the explicit four-state ambiguity in Section 3.

On a neighborhood where w is nonzero, the radicand is positive and a branch sign is fixed, (7) is a smooth decoder from F1. Thus no extra local real coordinate is necessary on such a branch. In differential form, if DF1(v)=0 then dw(v)=0 and dr12(v)=dr30(v). The retained squared norms give

\[
 r_{12}\cdot dr_{12}(v)=0,\qquad
 r_{30}\cdot dr_{12}(v)=0.
\]

When the two cut residuals are linearly independent, these equations force dr12(v)=dr30(v)=0. Appending their components cannot increase the Jacobian rank there. A proposed generic local-rank obstruction would therefore be incorrect.

## 3. Four fine states with exactly the same complete carrier

The following primitive values are used in each of the two channels:

| Primitive | Two-dimensional value |
| --- | --- |
| epsilon_0, epsilon_1 | (-1,-1), (1,1) |
| epsilon_2, epsilon_3 | (-1,0), (1,0) |
| xi_A, xi_B | (-1,-1), (2,-1) |
| ell_01, ell_12 | (1,1), (0,-1) |
| ell_23, ell_30 | (1,-1), (-3,1) |
| Y | (1,1) |

Equation (1), rather than the untransported generator, gives

\[
 z_A=(0,0),\quad z_B=(3,0),\quad
 V_{12}=(1,0),\quad V_{30}=(-2,0),
\]
\[
 (r_{01},r_{12},r_{23},r_{30})
   =((2,2),(0,-1),(2,0),(-3,-1)).
 \tag{8}
\]

Reflect only the second coordinate of epsilon_0 through epsilon_3, holding xi, ell and Y fixed. Their block averages remain zero, their norms remain fixed, and (8) becomes

\[
 (r_{01}',r_{12}',r_{23}',r_{30}')
   =((2,-2),(0,1),(2,0),(-3,1)).
 \tag{9}
\]

All four residual norms remain unchanged. The four energies summed over both channels are (E_a,E_b,E_c,E_v)=(12,14,30,4), and every z and V is unchanged. Thus the complete F1, including every original label, energy and geometric mark, is identical before and after reflection.

The two channel reflections can be applied independently. They give four legitimate fine states with the same F1 and four distinct pairs of cut12 residual vectors. All eight original squared residual norms are positive, so all original probabilities lie strictly between zero and one. Any optional agreement-panel branch requiring these fixed trees has positive probability at these states.

For h=(0,s) in one channel, the two cut12 squared residuals are (s-1)² and (s+1)². For every nonzero s, however small, their probabilities differ. At the executed check s=1/10 the squared norms are exactly 81/100 and 121/100; the probabilities are exp(-81/200) and exp(-121/200).

This is a counterexample to (4) for every neighborhood U of zero. It does not depend on a discontinuity or a differentiability assumption on the decoder. At a common input F1 a stochastic decoder also has the same output law for all four point preparations, so it cannot reproduce all four specified Bernoulli experiments exactly. It can still reproduce the conditional mixtures addressed in Section 7.

## 4. Arbitrarily strong finite coherence and an explicit response bound

The same analytic witness can be scaled without another computation. Multiply all epsilon_i in the preceding table by tau>0, leave the remaining primitives fixed, and perform the same independent reflections. For each tau the four carriers remain exactly equal. Their internal squared residual norms in each channel are 8tau² and 4tau², their energy E_a is 12tau², and all other displayed carrier coordinates retain the equality.

The two cut12 residuals are now (2-2tau,-tau) and (2-2tau,+tau). For h=(0,s),

\[
 q_{12}^{+}(h)-q_{12}^{-}(h)=4\tau s,\qquad
 \frac{p_{12}^{+}(h)}{p_{12}^{-}(h)}=\exp(-2\tau s).
 \tag{10}
\]

The internal transported Gaussian KL divergences are half the internal squared residual norms, hence are O(tau²), while the transverse log-response derivatives differ by 2tau. Therefore no strictly positive small-coherence threshold implies exact statewise access to all these responses. The ambiguity vanishes in the tau=0 limit. This does not establish a defect in approximate formation criteria.

There is also a positive quantitative result specific to this quadratic model. From the retained internal probabilities define

\[
 \varepsilon_x
  =\frac{\sqrt{-2\log p_{01}^x}+\sqrt{-2\log p_{23}^x}}{2}.
\]

Equation (5) and the triangle inequality give ||t^x||<=epsilon_x. Let tilde p_e^x(h)=exp(-||d_e^x+s_eh^x||²/2) be the directly evaluable parent-cut response. Subtract each log probability's value at h=0. Then exactly,

\[
 [\log p_e^x(h)-\log p_e^x(0)]
 -[\log\widetilde p_e^x(h)-\log\widetilde p_e^x(0)]
   =s_e h^x\cdot t^x,
\]
\[
 \left|[\log p_e^x(h)-\log p_e^x(0)]
 -[\log\widetilde p_e^x(h)-\log\widetilde p_e^x(0)]\right|
 \le \|h^x\|\varepsilon_x.
 \tag{11}
\]

The difference between their h-gradients is exactly s_e t^x, so its norm is at most epsilon_x for every h. This derivative bound is derived from the explicit Gaussian quadratic and the retained internal disagreements. It is not inferred from a general C0 error estimate. It supports an approximate collective-response diagnostic with a stated error budget, while the reflection witness refutes exact access at every positive coherence scale.

The uncentered log-probability difference is (d_e+s_eh)·t-||t||²/2. It obeys the separate bound (||d_e||+||h||)epsilon_x+epsilon_x²/2; a small centered response error does not assert equal unperturbed original and parent probabilities.

## 5. Directional information and exact displayed costs

On the domain w^b,w^m nonzero, retaining sigma_x=sign det(w^x,r12^x) and using (7) determines every cut residual and every response (3). Set sigma_x=0 when the radicand is zero. On the nondegenerate stratum these are two binary branch labels, one per channel. Section 3 exhibits four distinct response families at one identical carrier, so any additional finite label must have at least four values in this scope. Two bits attain that bound. The displayed continuous sample count remains 28, with two additional bits on this stratum; the already required ancestry, labels, incidence and tree records still have their original discrete costs.

No added real coordinate is locally needed where a nondegenerate branch is already specified by restricting the preparation domain. This local statement does not furnish a global decoder on the four-state witness.

At w=0 the two cut residuals coincide and the two norms coincide. They can leave a whole circle of directions. This is reachable by taking z_A=z_B=0 and V12=V30=0, fixing the other primitives, and rotating R and S together within each channel. Set the block-average epsilon to zero; choose xi_A=xi_B=-Y and cancel each tree link by its associated cut link. The rotated epsilon contrasts preserve their norms, all energies, both internal probabilities, the cut norm ||(R+S)/2||, barycenters and marks. Unless R+S=0, the residual rotates around a nontrivial circle. The channels can rotate independently.

A finite branch label cannot cover this degenerate family. Along its two independent angular directions the response residual differential has rank two while DF1 vanishes. Any smooth augmentation with a differentiable decoder must therefore add at least two local real coordinates there. One angular coordinate per channel is locally sufficient when the radius is nonzero, but a single angular chart is not global. At zero radius the response is already determined and a direction need not be specified.

A globally defined, smooth, sufficient augmentation with no branch conventions is to retain r12^b and r12^m themselves, four real coordinates. Equation (6) then reconstructs r30 exactly. Its displayed count is

\[
 44\ {\rm fine\ real\ coordinates}\ \longrightarrow\
 28+4=32\ {\rm retained\ real\ coordinates}.
 \tag{12}
\]

This preserves every original probability, energy, ancestry and mark. It does not hide a fine-state decoder. The four-coordinate augmentation is sufficient, not claimed globally minimal among all joint smooth encodings across singular strata. The exact least global scalar-storage count for that broader encoding problem is not settled here. The generic two-bit minimum and degenerate local two-coordinate lower bound are the stated minimality results.

These are sample-coordinate and discrete-label counts, not savings in density evaluation, conditional integration, online filtering, floating-point bytes, or native learning work. No cost for a new physical action mechanism is asserted.

## 6. Exact calculation and what it establishes

The [minimal script](evidence/coherence-response-access/response_access_exact.py) ran once under pinned CPython 3.14.7 with `-I -B`. It uses only Python Fraction arithmetic. Its [result](evidence/coherence-response-access/result.json) and [stdout](evidence/coherence-response-access/stdout-stderr.txt) are saved. The result records source SHA-256 metadata, the complete Jacobians, the primitive order, the witnesses, and the rational outputs. The old helper was not rerun.

At the single declared generic rank point X_j=((17j+3j²) mod 97-48)/17 for j=0,...,43, it reports

\[
 \operatorname{rank}DF_1=28,\qquad
 \operatorname{rank}D(F_1,r_{12},r_{30})=28.
 \tag{13}
\]

The calculation uses the eight squared residual norms in place of the eight p values. Exponentiation has nonzero derivative everywhere at finite residuals, so this does not change rank. Its 28-by-28 minor is exactly

\[
 \frac{23322776888068669440}{582622237229761}\ne0.
\]

The two cut-pair determinants are -3610/289 and 9467/289. Their nonzero values match the local algebra in Section 2. Fraction elimination and an independently evaluated square-minor determinant establish the stated rank; the reconstruction formula explains why adding directional components does not increase it at this point.

The same single execution verifies the coefficient identities (5)–(6), exact full-carrier equality of the four prescribed witnesses, and their response squared norms 81/100 versus 121/100. Its computation elapsed time was 0.06439989999489626 seconds. The scaled witness and the uniform response-increment bound are analytical derivations, not additional runs.

No search, grid, ODE, fitted parameter, new observation, production model, full suite, GPU, Lean, tamper check, or old calculation was run. There is no new formal evidence-ledger certificate; the output supports the bounded calculations and the written proofs above.

## 7. Native-law predictions remain available; the next decision is operational

The complete carrier's existing common-reference disintegration has

\[
 Q_\eta(dX)=Q_{\eta,F_1}(dy)\Psi(dX\mid y)
\]

and the corresponding model/posterior identities for the restricted native family, with the fixed ancestry records understood. Consequently

\[
 \overline p_e^x(y,h)
   =\int p_e^x(X,h)\Psi(dX\mid y)
 \tag{14}
\]

is a normalized Bernoulli evaluator that gives the exact conditional and averaged response of those native laws. It uses the reference conditional; its existence and exactness do not imply cheap evaluation. The global statewise ambiguity neither invalidates that law-level prediction nor contradicts native Fisher and VFE sufficiency.

The original family does not include every fine point preparation as a parameter value. Insisting on (4) is an explicitly stronger operational requirement. If the intended collective response is only (14), no new statistic is proved necessary here. If the parent must act on every admitted current fine state with exact original-cut response, the branch/directional information must be retained or the preparation domain restricted. Repeated adaptive interventions and their posterior updates would require their own declared law and memory analysis.

The strongest result is therefore exact and conditional: in this transported four-cycle specialization, arbitrary finite internal coherence does not imply global statewise response access from F1; generic branch labels resolve the ambiguity, a four-real directional catalog resolves it globally, and retained coherence yields the explicit approximate response bound (11). The companion [collective-response bound](coherence-response-bound.md) already supplies a probability/derivative certificate and finite adaptive-query error control without selecting a numerical tolerance. The next bounded step is to apply that certificate over an existing native interval under the full correlated Q_t, bounding its law-level error quantity while preserving the distinction from a sampled-state path law; this available work does not require another unspecified operational choice. This calculation selects no ancestry, establishes no attractor or persistence time, and does not close the full RG objective.
