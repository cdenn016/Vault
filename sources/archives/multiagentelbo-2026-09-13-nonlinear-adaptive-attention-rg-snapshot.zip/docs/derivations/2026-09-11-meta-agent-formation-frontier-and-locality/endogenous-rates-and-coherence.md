<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c","target_digest":"b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c"} -->

# Common local kinetics, inherited restoring rates, and separated formation episodes

September 12, 2026. Constructive dynamics lane for the [frozen endogenous-dynamics contract](evidence/2026-09-12-endogenous-dynamical-rg-goal/problem-contract.json). This document proves the rate, stable-fiber, and open-neighborhood formation statements below. It is not certification of the complete four-obligation contract. In particular, a small state-path error is not a bound on conditional relative entropy.

## 1. Target and source boundary

The assigned target is existential: exhibit a nonempty finite-dimensional specialization of the two-law/link model, an open parameter and initial-data regime, common local kinetics at peer nodes, derived internal and retained restoring rates, and a pair-only formation interval preceding a later coalescence interval. The intended dynamical equivalence is an explicitly bounded finite-horizon comparison with an inherited retained flow. Exact normalized pushforwards are separate static identities. All analysis is at one fixed base point; there is no base transport.

The user supplies the paired law-section ontology, independent interaction links, normalized physical evaluators, correlated recognition, and the prohibition on inserting node-specific speed factors or fresh parent rates. This construction supplies compact circle-valued law coordinates, a graph with one stronger edge, constant unit microscopic mobility, positive energy coefficients, and finite-temperature reversible diffusion. The supplied strong/weak **interaction energy ratio** selects the eventual bands. It is exposed as microscopic data, not derived from scalar VFE or from the requested grouping.

The sources read before constructing the bridge were [STATUS](../../STATUS.md), [microscopic VFE](microscopic-vfe-dynamics-construction.md), [complete coherence](complete-coherence-dynamics.md), [earlier assembly](dynamical-rg-assembly.md), [the Gaussian hierarchy](../2026-09-11-fast-slow-derived-hierarchy/gaussian-hierarchy-construction.md) and its [report](../2026-09-11-fast-slow-derived-hierarchy/final-report.md), and Theory chapters [01](../../../Theory/01_introduction.tex), [03](../../../Theory/03_probability.tex), and [05b](../../../Theory/05b_local_collective_elbo.tex). The read-only live sources were [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), labels `sec:timescales`, `sec:adiabatic_hierarchy`, and `sec:meta_agent_rg`, especially `eq:rg_internal_hessian`, `eq:rg_reduced_hessian`, and `eq:rg_slow_graph_metric`; and the [September synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>).

The source Gaussian construction already derives rates from heterogeneous couplings under common local Fisher updates, but does not supply this complete dynamic-link formation mechanism. The compact assembly supplies complete law/link formation but assigns unequal node speeds and does not prove a pair-only episode. The present bridge changes the energy-scale input and uses the actual stable fibers. It does not reuse the previous coordinate-deletion averaging claim.

## 2. One normalized two-channel specialization

Let the node set be `{1,2,3}`. The path has edges `12` and `23`; the triangle adds `13`. Edge `ij` is oriented from `j` to `i`. Write `E=2` or `3`, `D=6+2E`, and `m=2(E-1)`. There are angular coordinates

\[
x=(\theta_1,\theta_2,\theta_3,\psi_1,\psi_2,\psi_3,
                 (\alpha_e^b)_e,(\alpha_e^m)_e)\in\mathbb T^D.
\tag{1}
\]

Use the compact group `G=SO(2) x SO(3)` in its block-diagonal representation on `R^5`, and define `u_i=(cos theta_i,sin theta_i,0,0,0)`, with `v_i` defined using `psi_i`. Every link is the independent variable

\[
\Theta_e^x=\operatorname{diag}(R(\alpha_e^x),H_e^x),
\qquad H_e^x\in SO(3),\qquad x=b,m.
\tag{2}
\]

The complete configuration space is `W=T^D x SO(3)^(2E)`, with normalized product Haar reference `nu`. This is a finite-dimensional compact standard-Borel space, not a finite set. The additional group marks have dimension `6E`. They are retained, not silently identified with vertex-frame ratios.

For `0<a<1`, the conditional belief/model laws and physical evaluator are

\[
b_i=N(u_i,I_5),\qquad m_i=N(v_i,aI_5),\qquad
\operatorname{ev}_i(\zeta_i,dk_i)=N(\zeta_i,(1-a)I_5)(dk_i).
\tag{3}
\]

Thus the evaluated model is `N(v_i,I_5)`. The model presentation is `zeta_i`; the evaluator does not read recognition. Its fixed-marginal optimizing coupling is the correlated Gaussian

\[
\zeta_i=v_i+\xi_i,\quad k_i=u_i+\xi_i+\epsilon_i,
\quad \xi_i\sim N(0,aI_5),\quad
\epsilon_i\sim N(0,(1-a)I_5),\quad \xi_i\perp\epsilon_i.
\tag{4}
\]

The source's affine log-density-ratio calculation gives, over **all** couplings with these marginals, the minimum evaluator KL

\[
d_i=\frac{1-\cos(\theta_i-\psi_i)}{1-a}.
\tag{5}
\]

For completeness, the log ratio of (4) to `m_i ev_i` is
`[(u_i-v_i)^T(k_i-zeta_i)-|u_i-v_i|^2/2]/(1-a)`. Its expectation under any coupling with the fixed marginals is `|u_i-v_i|^2/[2(1-a)]`. Adding this log ratio to the KL relative to (4) proves the minimum and its uniqueness. All Gaussian first moments exist.

Define residuals

\[
d_i^{\rm ang}=\theta_i-\psi_i,\qquad
r_{ij}^b=\theta_i-\theta_j-\alpha_{ij}^b,\qquad
r_{ij}^m=\psi_i-\psi_j-\alpha_{ij}^m.
\tag{6}
\]

Let `B_f` have the five rows `(d_1^ang,d_2^ang,d_3^ang,r_12^b,r_12^m)`, and let `B_s` have the other `m` edge rows, in channel-major order (`23b,13b,23m,13m` for the triangle). Define `F(z)=sum_j(1-cos z_j)` in whatever residual dimension is indicated. Choose

\[
K>0,\quad k>0,\quad T>0,\quad K>\frac{T}{1-a},
\tag{7}
\]

and specify the generative configuration energy

\[
U_0=\left(K-\frac{T}{1-a}\right)\sum_i(1-\cos d_i^{\rm ang})
 +K\sum_{x=b,m}(1-\cos r_{12}^x)
 +k\sum_{\text{cut }e,x}(1-\cos r_e^x).
\tag{8}
\]

The coefficient compatibility in (8) is an explicit parameterization of this admitted model family. It is not a force inferred from a missing observation. An equivalent description first selects its positive node coefficient `lambda_0` and writes `K=lambda_0+T/(1-a)`, then matches the strong-edge coefficient to that `K`. Openness below is in the parameters of this specified family, not in an unrestricted space of all independent coefficients.

Local normalized node mechanisms are a uniform `psi_i` prior and a von Mises `theta_i|psi_i` kernel with coefficient `K-T/(1-a)`. Its normalizer is independent of `psi_i` by translation invariance. Multiply their normalized product and Haar links by the positive edge tilt and normalize once. Compactness and positivity give

\[
P_0(dW)=Z_0^{-1}e^{-U_0/T}\nu(dW),\qquad 0<Z_0<\infty.
\tag{9}
\]

The full experiment is `P_0(dW) product_i m_i(dzeta_i) ev_i(zeta_i,dk_i)` with singleton observation. It is normalized by integration of the declared kernels. Its augmented recognition is arbitrary correlated outer `Q(dW)` followed by (4) at each node. The exact scaled constrained VFE is

\[
\mathcal F_T(Q)=\mathbb E_Q U+T\int q\log q d\nu+T\log Z_0,
\qquad U=K F(B_fx)+kF(B_sx),
\tag{10}
\]

where `q=dQ/dnu`; the extra term `T sum_i d_i` turns (8) into `U`. More generally its extended definition is

\[
\mathcal F_T(Q)=T\operatorname{KL}(Q\Vert\pi)+T\log(Z_0/Z),
\quad \pi=Z^{-1}e^{-U/T}\nu,\quad 0<Z<\infty.
\tag{11}
\]

The generative law `P_0`, variational target `pi`, conditional laws (3), and outer recognition `Q` are distinct. The unconditional section marginals are mixtures over `Q`, not Gaussians evaluated at mean angles. No deterministic configuration is asserted to be a finite-entropy Dirac recognition density.

## 3. Common microscopic kinetics and symmetry

Every angular coordinate has the same unit mobility; every `SO(3)` mark has the same fixed bi-invariant metric. The microscopic dynamics are

\[
dx=-\nabla U(x)dt+\sqrt{2T}dB_t\pmod {2\pi},\qquad
\mathcal L_H=T\sum_{e,x}\Delta_{SO(3),e,x}.
\tag{12}
\]

All Brownian drivers are independent in orthonormal frames. The drift-only comparison is `xdot=-grad U`, with constant `H` marks. Smooth coefficients on a compact boundaryless manifold give global solutions: in angular lifts the drift is globally Lipschitz and bounded; the compact group Brownian motions can equivalently be constructed in finitely many smooth charts with no finite-time escape. This is a declared local Dirichlet/transport kinetics. It is not the full-joint Fisher reaction flow and is not forced by the scalar objective.

Each node derivative contains precisely the node and incident edge terms of (10); link derivatives are `dot alpha_e^x=w_e sin r_e^x`, with `w_12=K` and `w_cut=k`. Peers use the same prescription. There is no `epsilon^-1` node mobility and no per-parent reset. Deterministically `dot U=-|grad U|^2`. For a smooth positive outer density,

\[
\frac{d\mathcal F_T}{dt}
=-\int q\left|\operatorname{grad}(U+T\log q)\right|^2d\nu.
\tag{13}
\]

Equation (13) follows by substituting the divergence-form forward equation and integrating by parts on the compact manifold. Smooth finite-entropy initial densities can be treated from positive times. No discrete integrator is analyzed or run.

Under a passive node frame change with angle `h_i` and rotation `G_i in SO(3)`, both law angles gain `h_i`, the link angles gain `h_i-h_j`, and `H_ij^x` becomes `G_i H_ij^x G_j^-1`. All residuals, energies, metrics, and equations transform covariantly. The common-frame specialization has identity cross-channel map; changing the channels independently requires transforming that map as in the microscopic source.

All `SO(3)` marks stabilize (3), but they are independent retained data. On the triangle each channel can have arbitrary nonidentity holonomy; the two channel holonomies at a common root may be noncommuting. At `T>0` the marks diffuse. They do not create the restoring-rate separation. Three angular directions lie in `ker B_f intersect ker B_s` and carry passive frame motion; they are not counted as relaxation modes or physical clocks. With no fixed external reference, collective coordinate motion must be interpreted through the gauge-invariant residuals rather than through a root angle alone.

## 4. Exact fast fibers and inherited coordinates

Put

\[
C=B_fB_f^T,\quad R=B_f^TC^{-1},\quad P=I-RB_f,\quad
A=B_sR,\quad S=B_sPB_s^T.
\tag{14}
\]

`B_f` has full row rank: the two strong-link columns determine their own rows, and the three same-node rows are independent. Indeed it has an integer right inverse, obtained by taking all `theta=0`, then `psi_i=-d_i`, and choosing each strong link to give its specified residual. Hence its kernel torus `M_f` is connected. The full residual matrix has rank `5+m`, by the additional independent cut-link columns. It follows that `C>0`, `P=P^T=P^2`, `B_fP=0`, and `S>0`. For the last claim, `v^TSv=|PB_s^Tv|^2=0` would make `B_s^Tv` a combination of fast rows, contradicting full row rank.

On the tube where the principal fast residual `z=principal(B_fx)` has coordinates in `(-rho_f,rho_f)`, `rho_f<pi/2`, define

\[
y=\Pi_f(x)=x-Rz\pmod {2\pi}\in M_f.
\tag{15}
\]

For the **fast-only** vector field `xdot=-K B_f^T sin(B_fx)`, `Pi_f` is constant, since its derivative is `P`. Each sufficiently small fiber is attracted to its unique `z=0` point, as the next section proves. Thus (15) projects along actual local stable fibers. It is not deletion of child matter coordinates while retaining original root/link coordinates that those same fast forces move.

Locally `x=y+Rz`, with `dy in ker B_f`, and the inherited metric is exactly

\[
|dx|^2=|dy|^2+dz^TC^{-1}dz.
\tag{16}
\]

There is no mixed covariance. If `y=F eta` in any tangent basis, its metric is `F^TF`, and the retained mobility in `eta` is `(F^TF)^-1`. The retained cut residual is `s=B_sy`; its induced mobility is `S`, not a newly chosen unit matrix. The exact local drift equations are

\[
\dot z=-K C\sin z-k C_{fs}\sin(s+Az),\qquad C_{fs}=B_fB_s^T,
\tag{17}
\]
\[
\dot y=-kPB_s^T\sin(s+Az),\qquad
\dot s=-kS\sin(s+Az).
\tag{18}
\]

The inherited constrained flow and its cut dynamics are

\[
\dot{\bar y}=-kPB_s^T\sin(B_s\bar y),\qquad
\dot{\bar s}=-kS\sin\bar s.
\tag{19}
\]

Their initial state is `bar y(0)=Pi_f(x(0))`; their metric and weak potential are restrictions of the microscopic objects. Equations (17)-(19) follow by direct matrix multiplication, not by assuming conditional equilibration.

The fast manifold records identical law means in the two channels at each node and transported agreement across edge `12`. It retains the cut marks and all stabilizer marks. A convenient chart has the three `theta_i` and the cut angles as free coordinates; `psi_i=theta_i` and `alpha_12^b=alpha_12^m=theta_1-theta_2`. These chart coordinates acquire the metric (16), and must not be assigned independent original mobilities. The pair's relative internal frame remains encoded in the chart and its group marks.

## 5. The rate calculation

For both graphs,

\[
C=\begin{pmatrix}
2&0&0&1&-1\\0&2&0&-1&1\\0&0&2&0&0\\
1&-1&0&3&0\\-1&1&0&0&3
\end{pmatrix},
\quad
\operatorname{spec}C=\left\{2,2,3,\frac{5-\sqrt{17}}2,
                                    \frac{5+\sqrt{17}}2\right\}.
\tag{20}
\]

To check the eigenvalues, `d_3`, `d_1+d_2`, and the sum of the edge rows give eigenvalues `2,2,3`. On the remaining orthonormal difference subspace the matrix is `[[2,2],[2,3]]`. Its characteristic polynomial is `lambda^2-5lambda+2`.

For the path, direct multiplication in (14) gives

\[
S=\begin{pmatrix}11/6&5/6\\5/6&11/6\end{pmatrix},
\quad\operatorname{spec}S=\{1,8/3\},\quad B_sB_s^T=3I_2.
\tag{21}
\]

For the triangle,

\[
S=\begin{pmatrix}
11/6&2/3&5/6&2/3\\2/3&11/6&2/3&5/6\\
5/6&2/3&11/6&2/3\\2/3&5/6&2/3&11/6
\end{pmatrix},
\quad\operatorname{spec}S=\{1,1,4/3,4\},
\quad\operatorname{spec}(B_sB_s^T)=\{2,2,4,4\}.
\tag{22}
\]

Thus the fast-only restoring rates are `K spec(C)`, while the inherited retained linearized rates at `bar s=0` are `k spec(S)`. These are genuine residual relaxations. The remaining three angular tangent modes and the `SO(3)` stabilizer directions are neutral; there is no single slowing clock for the full parent.

Here is a finite-ratio band check for the complete evolving Hessian. Write `c_-`, `c_+` for the extreme eigenvalues of `C`, `s_-` for the least eigenvalue of `S`, and `d_s=||B_s||^2` (`3` for the path, `4` for the triangle). At complete coherence the Hessian is

\[
H_0=KB_f^TB_f+kB_s^TB_s.
\tag{23}
\]

It has three zero eigenvalues, `m` remaining slow eigenvalues no larger than `k d_s`, and five fast eigenvalues at least `K c_-`. These counts follow by the min-max principle: restriction to `ker B_f` gives a `(D-5)`-dimensional subspace bounded by `k d_s`, while adding a positive matrix cannot lower the five positive eigenvalues of `K B_f^TB_f`.

An elementary uniform lower bound needs no perturbation theorem. For `x` perpendicular to the full angular kernel, write `x=y+Rz`; then `y` is perpendicular to that kernel within `ker B_f`. Since the positive tangent singular values of `B_s` are the square roots of `spec(S)`,

\[
|x|^2\le\frac{2}{s_-}|B_sx|^2+
 \left(\frac{2\|A\|^2}{s_-}+\frac1{c_-}\right)|B_fx|^2.
\tag{24}
\]

If

\[
\frac{K}{2\|A\|^2/s_-+1/c_-}\ge\frac{k s_-}{2},
\tag{25}
\]

every positive eigenvalue of (23) is at least `k s_-/2`. When all current residuals have magnitude below `rho<pi/2`, the actual Hessian obeys

\[
\cos(\rho)H_0\preceq\nabla^2U(x)\preceq H_0.
\tag{26}
\]

Consequently its `m` low positive eigenvalues lie in `[cos(rho) k s_-/2,k d_s]`, its five high eigenvalues lie in `[cos(rho) K c_-,K c_++k d_s]`, and its angular kernel remains exactly three-dimensional. The gap is nonempty for `cos(rho)Kc_->kd_s`. This is a statement about instantaneous restoring quadratic forms. The next section supplies the actual finite-time tracking argument rather than treating those eigenvalues alone as a trajectory theorem.

As `K/k` tends to infinity, the true low eigenvalues divided by `k` tend to `spec(S)`. To see this, use an orthonormal normal/tangent decomposition for `B_f`. The normal block is `K C` up to an orthogonal basis change plus an `O(k)` matrix. For bounded `lambda/k`, its inverse is `O(1/K)`. The characteristic determinant factors into the normal determinant and the tangent Schur determinant `det(k P B_s^TB_s P-lambda I+O(k^2/K))`. The nonzero roots converge to those of `S`; the three exact zero roots remain zero. This limiting argument is finite-dimensional and does not assume a relaxation law for a parent.

## 6. Full-neighborhood normal tracking and second coalescence

All norms in this section are Euclidean operator/vector norms on compatible continuous angular lifts unless explicitly labeled. They also bound the corresponding torus distances. Fix `rho_f<pi/2` and set

\[
R_f=(z^TC^{-1}z)^{1/2},\quad
\alpha=c_-\frac{\sin\rho_f}{\rho_f},\quad
\beta=\sqrt m\|C^{-1/2}C_{fs}\|.
\tag{27}
\]

While `|z|<=rho_f`, differentiate (17). The identity

\[
\frac12\frac d{dt}R_f^2
=-K z^T\sin z-kz^TC^{-1}C_{fs}\sin(s+Az)
\le-K\alpha R_f^2+k\beta R_f
\tag{28}
\]

uses `z_j sin z_j >= (sin rho_f/rho_f)z_j^2`. A comparison argument, or its regularization at `R_f=0`, yields

\[
R_f(t)\le e^{-K\alpha t}R_f(0)+\frac{k\beta}{K\alpha},
\qquad |z(t)|\le\sqrt{c_+}R_f(t).
\tag{29}
\]

If `sqrt(c_+)[R_max+k beta/(K alpha)]<rho_f` and `R_f(0)<=R_max`, a first exit through the fast boundary contradicts (29). Thus the bound holds for the whole finite horizon, in fact for all time in this fast chart. The forcing floor is of order `k/K`; it was not set to zero by assumption.

Let `bar s` solve (19) with `bar s(0)=s(0)`. Since sine is 1-Lipschitz, Gronwall applied directly to (18) gives, for `0<=t<=H`,

\[
|s(t)-\bar s(t)|\le E_H,
\quad E_H=k\|S\|\|A\|\sqrt{c_+}e^{k\|S\|H}
\left[\frac{R_{\max}}{K\alpha}+\frac{k\beta H}{K\alpha}\right].
\tag{30}
\]

This follows by integrating (29); no stochastic or conditional-equilibrium claim is involved. With `H=H_bar/k`, `E_H=O(k/K)` for fixed `H_bar`. Since both `y-y(0)` and `bar y-y(0)` lie in `range(P B_s^T)`,

\[
|y(t)-\bar y(t)|\le E_H/\sqrt{s_-}.
\tag{31}
\]

Indeed `y-bar y=P B_s^TS^-1(s-bar s)` and this right inverse has squared norm `1/s_-`. This proves a comparison for the full retained angular state, not just its cut residuals.

The reduced cut flow has a quantitative basin. Fix `0<rho_0<pi/2`, `E_bar<1-cos rho_0`, and an initial condition with `F(bar s(0))<=E_bar` on the principal branch. It cannot leave that branch through `|bar s_j|=rho_0`, because

\[
\frac d{dt}F(\bar s)=-k\sin(\bar s)^TS\sin(\bar s)
\le-2k\gamma F(\bar s),
\quad \gamma=s_-\cos^2(\rho_0/2)>0.
\tag{32}
\]

The last inequality uses `sin^2 u=2(1-cos u)cos^2(u/2)`. Set `c_0=(1-cos rho_0)/rho_0^2`; then

\[
|\bar s(t)|\le M_0e^{-k\gamma t},\qquad
M_0=\sqrt{E_{\rm bar}/c_0}.
\tag{33}
\]

The decreasing ratio `(1-cos u)/u^2` on `(0,pi/2)` gives the quadratic bound used here; differentiating it gives numerator `u sin u-2(1-cos u)<=0`, equivalently `u<=2tan(u/2)`.

**Open two-episode statement.** Choose a small `sigma>0` and `rho_0` so that every `s(0)` in a nonempty open box strictly inside `(sigma,2sigma)^m` has `F(s(0))<E_bar<1-cos rho_0`. Fix a detector tolerance `epsilon>0` sufficiently smaller than `sigma`. This is an error tolerance, not an extra term in the model. Set

\[
h=\frac{\epsilon}{4(1+\|A\|)},\quad
t_b=\frac{\sigma}{4k\|S\|\sqrt m},\quad
t_2=\frac1{k\gamma}\log\frac{2M_0}{\epsilon},\quad H>t_2.
\tag{34}
\]

Choose `epsilon` small enough at this stage that `t_2>t_b`, and take `H=H_bar/k` with fixed `H_bar` larger than `k t_2`. Choose a small open fast initial neighborhood in which both strong-edge residuals exceed `2 epsilon` but `R_f(0)<R_max`, with `R_max` small enough for the tube margins. Such a set is nonempty because the full residual map is surjective and `epsilon` can be chosen arbitrarily small. In particular, the pair is initially outside the `epsilon` coherence tolerance.

Now take `K/k` sufficiently large that all of the following strict bounds hold:

\[
\sqrt{c_+}\frac{k\beta}{K\alpha}<\frac h2,\qquad
t_f:=\frac1{K\alpha}\max\left\{0,\log\frac{2\sqrt{c_+}R_{\max}}h\right\}<\frac{t_b}{2},
\tag{35}
\]
\[
E_H<\min\{\epsilon/4,\sigma/8\},\qquad
\epsilon<\sigma/2.
\tag{36}
\]

Also retain a strict cut-chart margin
`E_H+||A|| sqrt(c_+)[R_max+k beta/(K alpha)]<rho_s-rho_0`
for some `rho_0<rho_s<pi/2`. Choose `R_max` small enough first, then increase `K/k`. All these choices are possible: `t_f/t_b` and `E_H` tend to zero with `k/K`, while `sigma,epsilon,H_bar` are fixed.

For every initial datum in this open set, (29) gives `|z(t)|<h` for `t>=t_f`. Thus the strong edge and same-node evaluator residuals have become small through the actual flow. On `[0,t_b]`, the reduced flow moves by at most `k||S||sqrt(m)t_b=sigma/4`. Therefore, on the nonempty interval `[t_f,t_b]`, every actual cut residual obeys

\[
(s+Az)_j\ge\sigma-\sigma/4-E_H-\|A\|h>\sigma/2.
\tag{37}
\]

This is a pair-only interval: both strong-edge channel KLs are small, while every weak cut has a positive lower KL bound. In the belief channel these bounds are respectively at most `h^2/2` and at least `1-cos(sigma/2)`; model-channel KL multiplies them by `1/a`.

For every `t in [t_2,H]`, equations (30), (33), and (35) give

\[
|B_sx(t)|=|s(t)+Az(t)|
\le\epsilon/2+\epsilon/4+\|A\|h<\epsilon,
\qquad |B_fx(t)|<\epsilon.
\tag{38}
\]

Since `t_2>t_b`, the trajectory has a later complete-coherence interval separated from the pair-only interval. The inherited flow (19) itself starts with nonzero cuts and undergoes the second episode under its existing weak potential and metric. It is not an algebraic second decimation of an already coherent starting network. Its relation to the **finite-temperature conditional-integral** parent force remains the interface in Section 9.

The construction has genuinely moving independent links: in the selected open fast initial set, `dot alpha_12^x=K sin r_12^x` is nonzero. Cut links also move whenever their mismatch sine is nonzero. No initialization in a frame-factorized link family is imposed.

## 7. Finite positive noise and non-Dirac recognition

Let `x^0(t)` be a deterministic trajectory in the strict episode regime, and couple (12) with the same initial configuration in a continuous angular lift. A global Lipschitz constant for the deterministic angular drift is

\[
L=Kc_++kd_s.
\tag{39}
\]

Thus the pathwise integral equation gives
`sup_(t<=H)|x^T(t)-x^0(t)|<=sqrt(2T) exp(LH) sup_(t<=H)|B_t|`.
The norm `Y_t=|B_t|` is a square-integrable nonnegative submartingale. The maximal inequality `E sup_(t<=H)Y_t^2<=4 E Y_H^2` therefore gives `E sup |B_t|^2<=4DH`. One direct derivation uses the stopping-time inequality `lambda P(Y_max>=lambda)<=E[Y_H 1_(Y_max>=lambda)]`, integrates in `lambda`, and applies Cauchy-Schwarz to obtain `E Y_max^2<=2 E[Y_H Y_max]<=2 sqrt(E Y_H^2 E Y_max^2)`. Truncation justifies the integration if needed. Consequently

\[
\Pr\left(\sup_{t\le H}|x^T(t)-x^0(t)|>\delta\right)
\le\frac{8DTH e^{2LH}}{\delta^2}.
\tag{40}
\]

Choose `delta` smaller than the strict fast/cut margins divided by the norms of the corresponding residual maps. The same two episode inequalities, with those margins subtracted, then hold with at least the probability supplied by (40). Since `K,k,H` were selected first, sufficiently small **positive** `T` makes this probability as high as any fixed target less than one and also satisfies (7). Strict inequalities leave a nonempty open parameter regime. The estimate is deliberately conservative and does not claim useful simulation-scale temperatures.

For a smooth outer initial density `q_0` assigning probability greater than `1-eta_0` to the admitted open initial set, integrate (40) over initial data. The success probability is at least
`1-eta_0-8DTH exp(2LH)/delta^2`. Such correlated finite-entropy densities exist: use a smooth nonproduct bump inside the initial set, optionally mixed with a positive multiple of `pi`. This is a distributional statement, not a Dirac recognition substitution. The `SO(3)` marks are unrestricted and retained, so no small-noise bound on them is needed for the angular episode. Positive noise does not preserve exact zero-KL support, and no infinite-lifetime or mixing claim is made.

## 8. Exact static fiber measure, with the boundary qualification

The principal-residual rule in (15) defines a Borel map on the whole torus. Up to the chosen half-open faces, it has the Borel inverse

\[
(y,z)\longmapsto y+Rz\pmod {2\pi},
\quad y\in M_f,\quad z\in[-\pi,\pi)^5.
\tag{41}
\]

Indeed `B_fR=I`, so the principal residual of this inverse is exactly `z`, and subtracting `Rz` returns `y`. Haar disintegration of the surjective torus homomorphism `B_f` is uniform Haar on each coset of its connected kernel. Translating each such coset by `-Rz` therefore gives the exact reference identity

\[
\nu_{\mathbb T^D}(dx)
=\nu_{M_f}(dy)\prod_{j=1}^5\frac{dz_j}{2\pi}.
\tag{42}
\]

One can check (42) without a geometric theorem: integrate a continuous function on the kernel against its Haar measure; translations within the kernel leave that integral invariant, so the resulting product pushforward is translation invariant on the full torus and has mass one. The unique normalized translation-invariant torus measure is product Haar, as follows by testing Fourier characters. All `SO(3)` marks are additionally retained.

For the effective target `pi`, the exact fiber potential is

\[
V_y(z)=KF(z)+kF(B_sy+Az),\qquad
\mu_y(dz)=\frac{e^{-V_y(z)/T}\prod_jdz_j/(2\pi)}
 {\int_{[-\pi,\pi)^5}e^{-V_y(w)/T}\prod_jdw_j/(2\pi)}.
\tag{43}
\]

All these integrals are positive, finite, and smooth in `y`: the integrands and all derivatives on any finite-order compact chart are bounded on a finite domain, so differentiation under the integral is justified. The generative fiber prior instead uses `U_0`; it is not (43). Exact normalized generative parents/evaluators must use that prior. Relative-entropy disintegration gives, for every `Q<<pi`,

\[
\operatorname{KL}(Q\Vert\pi)
=\operatorname{KL}(\Pi_{f\#}Q\Vert\Pi_{f\#}\pi)
 +\mathbb E_{\Pi_{f\#}Q}\operatorname{KL}(Q(dz\mid y)\Vert\mu_y).
\tag{44}
\]

This is an exact nonnegative identity, interpreted in the extended sense. It is not a decay bound on the final term.

**Boundary qualification.** When a principal residual crosses `z_j=pi`, the equivalent chart has `z_j=-pi` and `y` shifts by `2pi R e_j`. Thus (41) is not a global smooth product chart, and the original diffusion is not a fixed-`y` periodic or reflecting diffusion on this cube. Equations (17)-(18), their diagonal noise covariances, and their local generator apply before the relevant chart exit. A global parent forward equation needs the gluing flux, or a controlled localization error. Haar factorization and static normalized laws do not remove that dynamical boundary obligation.

## 9. Scope, obstruction, falsifier, and route disposition

The proved bridge is a full open-neighborhood construction under one local microscopic mobility: five fast restoring directions, two or four slower cut directions, a stable-fiber projection with inherited metric, an actual pair-only interval, and a later coalescence interval. The triangle retains arbitrary stabilizer holonomy. These statements hold for a nonempty open regime of this explicitly specified model family and its initial data, not for arbitrary agent models. Both episodes are driven by the same time-independent energy; no merger schedule or parent rate is prescribed.

The exact normalized finite-temperature parent potential is the conditional integral in (43), while (19) uses its constrained zero-width potential. Their force difference, the nonequilibrium conditional force, and the conditional KL in (44) must be controlled before the complete contract can close. In particular, (30), (38), and (40) alone do not imply small dimensionless KL. The stable-fiber chart also has the gluing qualification just stated. These are the minimal remaining interfaces of this lane; they are not a nonexistence theorem for the target.

A counterexample to universal slowdown is already visible: if `K/k` is bounded near one, the inequalities (25)-(26) provide no large separation; if the initial cuts are already below tolerance, there is no second episode; and all angular gauge and stabilizer directions remain neutral. If one retains unprojected root/internal-link coordinates and resets their mobility, equations (17)-(18) show explicitly why the claimed reduced dynamics changes.

The route is falsified if a claimed full-state trajectory violates the exact residual equations, if a proposed retained kinetic matrix differs from (14)/(16), if the specified strict episode inequalities have no simultaneous solution, or if the conditional-lag analysis cannot control the complete inherited parent on the same parameter regime. Failure of this route would not refute the existential frozen contract.

The novelty fingerprint is the tuple `(complete normalized law/evaluator model, common peer mobility, heterogeneous energy scales, actual stable-fiber projection, Schur cut mobility, full-neighborhood two-episode bounds)`. Strong/weak Gaussian rates, generic Morse-Bott attraction, the VFE chain rule, and stabilizer holonomy were already present in the sources and are not claimed as new. Only one mechanism was pursued here: energy separation in the existing compact normalized model. The path and triangle are two graph sizes of that same mechanism.

Proposed disposition: retain this construction as a conditional component and pass its exact fiber law and boundary behavior to the conditional-lag lane. The next action that would materially change the full answer is a quantitative conditional-force and conditional-KL estimate, including gluing flux or localization error, on the same `K/k`, `T`, and `H` regime; then compare the inherited finite-temperature parent to (19) through its second formation interval.

## 10. Executed evidence and edit record

One small exact SymPy calculation ran under `C:/anaconda/python.exe`, without importing torch or using a GPU. The command was `C:/anaconda/python.exe docs/derivations/2026-09-11-meta-agent-formation-frontier-and-locality/evidence/endogenous-rates/check_matrices.py`. The [script](evidence/endogenous-rates/check_matrices.py) saved [matrix-results.json](evidence/endogenous-rates/matrix-results.json), containing exact ranks, spectra, the two inherited cut matrices, and projection identities. This checks the displayed finite matrices; it is not the proof of the open-regime estimates. No trajectory experiment, suite, Lean, tamper check, Git publication, or vault edit ran.

The lane changed only this derivation and its owned `evidence/endogenous-rates/` directory. Shared status, ledgers, prior proofs, configurations, and production code were left to their owners.
