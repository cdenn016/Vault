# Mechanical cost of the complete selected-hierarchy response interface

September 12, 2026. One new isolated counting script read the saved exact maps and counted the declared instruction schedule. Across all 176 panel maps, the augmented four-coordinate assembly needs at most 52 multiplications and 60 additions. Across all 416 eligible old-cut decoder rows, decoding both coordinates of one selected channel needs at most 8 multiplications and 8 additions. An uncached anchored Bernoulli query therefore has the uniform arithmetic bound in Section 3.

These are exact operation counts for a specified ideal-real program and conservative combinations of such counts. They are not benchmarks, arithmetic lower bounds, finite-bit guarantees, or claims that all remaining costs vanish.

## 1. Inputs, scope and counting convention

The current [selected interface](selected-hierarchy-response-interface.md) and [response synthesis](selected-hierarchy-response.md) fix the actual H-dependent first partition, the normalized all-H panel, the historical input ports, and the finite-depth extension. The [exact response-map record](evidence/selected-hierarchy-response/response-maps.json) contains the augmented second maps and old-cut decoder rows. The [saved geometry](evidence/joint-native-episode/uniform-panel-geometry.json) identifies their original geometric parts. Their producing Python sources were inspected but neither imported nor rerun.

[Common-prior native episodes](common-prior-native-hierarchy-episodes.md), Section 7, supplies the old assembly comparison and its cost assumptions. [Native resource frontier](native-episode-resource-frontier.md), Sections 2–5, supplies the coupled baseline and the already established first-parent bound of 52 multiplications and 80 additions. That first-parent work and the old scientific runs were not repeated.

The mathematical object counted here is a saved rational linear form y=sum_j a_j x_j. Zero coefficients are ignored; an assignment and a coefficient +1 are free. Every other nonzero coefficient, including -1, costs one multiplication. A row with n nonzero terms costs max(n-1,0) additions. Rows are evaluated independently, without common-subexpression factoring. If L is a saved matrix and r is the number of coordinate directions, the counts are exactly

\[
 M(L;r)=r\sum_{i,j}\mathbf 1_{\{L_{ij}\ne0,\ L_{ij}\ne1\}},
 \qquad
 A(L;r)=r\sum_i\max\left(0,\sum_j\mathbf1_{\{L_{ij}\ne0\}}-1\right).
 \tag{1}
\]

For each (H,mask) case with first count k and second count q, its augmented map has k+q rows and 2k columns per coordinate direction. It forms the q new means, q retained marks and k-q selected forest-response vectors from the actual first geometry. This assembly uses r=4.

Each old-cut decoder is one row of length k+q. A query selects one of the two channels, each having two coordinates, so its decoder uses r=2. This includes both coordinates, not just one. Channel labels share the same geometric coefficients.

The counter covers every saved row, including the 16 k=1 cases whose interparent response interface is null. The output records all case identities, maps' dimensions, per-cut counts, componentwise maxima and their attaining cases. It does not infer values from a few representative matrices.

## 2. Exact map and decoder counts

The following are componentwise maxima within each (k,q) group. M denotes multiplication and A addition.

| k | q | Map cases | Eligible decoder rows | Four-coordinate assembly M / A | Two-coordinate old-cut decode M / A |
| --- | --- | ---: | ---: | ---: | ---: |
| 1 | 1 | 16 | 0 | 0 / 0 | null |
| 2 | 1 | 60 | 120 | 20 / 20 | 4 / 2 |
| 2 | 2 | 20 | 40 | 0 / 0 | 4 / 4 |
| 3 | 1 | 32 | 96 | 36 / 40 | 6 / 4 |
| 3 | 2 | 24 | 72 | 20 / 20 | 6 / 6 |
| 3 | 3 | 8 | 24 | 0 / 0 | 4 / 4 |
| 4 | 1 | 5 | 20 | 52 / 60 | 8 / 6 |
| 4 | 2 | 6 | 24 | 40 / 40 | 8 / 8 |
| 4 | 3 | 4 | 16 | 20 / 20 | 6 / 6 |
| 4 | 4 | 1 | 4 | 0 / 0 | 4 / 4 |

The maximum assembly count 52 M + 60 A is attained at case index 167 in the saved ordering. The maximum decoder count 8 M + 8 A is attained at case index 163, old edge index 2, meaning original edge 23. Its row has five nonzero coefficients, four of which differ from +1, so (1) gives 2·4=8 multiplications and 2·(5-1)=8 additions. The complete identifiers are in the [count result](evidence/selected-hierarchy-response-cost/cost-maps.json).

The counter also verifies the exact incremental count against the retained original geometry metadata:

\[
 M_{\rm augmented}=M_{\rm old\ geometry}+8(k-q),\qquad
 A_{\rm augmented}=A_{\rm old\ geometry}+8(k-q).
 \tag{2}
\]

Each added forest residual is z_B-z_A-V_f. It has one +1 and two -1 coefficients in each of four coordinates, hence costs eight multiplications and eight additions. This agrees with direct counting of the complete augmented row array.

The no-merge maps are coordinate assignments, hence have zero floating arithmetic under the convention. They still have memory-access, dispatch and metadata costs. The q=1 roots created from k>1 retain their historical old-cut interfaces; they are not counted as null queries.

## 3. One complete anchored query

Fix an eligible old cut and one two-coordinate channel. Its input h is already supplied in that edge's target-minus-source orientation. The probability is

\[
 a=\operatorname{clip}_{[0,1]}
       [p_0+\phi(d+h)-\phi(d)],\qquad
 \phi(v)=\exp(-\|v\|^2/2).
 \tag{3}
\]

The original p_0 is retained. The implementation first decodes d using its saved row, then follows this explicit scalar schedule:

| Operation after decoding d | Multiplications | Additions | Other operations |
| --- | ---: | ---: | --- |
| Form the two coordinates of d+h | 0 | 2 | |
| Form the two squared norms | 4 | 2 | |
| Multiply both norms by -1/2 | 2 | 0 | |
| Evaluate both exponentials | 0 | 0 | 2 exponentials |
| Multiply the unshifted exponential by -1 | 1 | 0 | |
| Add the anchor and the two signed exponential terms | 0 | 2 | |
| Clip to [0,1] | 0 | 0 | 2 comparisons |
| Draw one Bernoulli answer | 0 | 0 | 1 uniform, 1 comparison |

A square is one multiplication. The clipping schedule compares to each endpoint and conditionally assigns; assignments are free, while dispatch and memory access are priced separately. The Bernoulli uses one ideal uniform. No exponentials, uniforms or answers were generated by the counting script.

The remainder after decoding is therefore 7 M + 6 A + 2 exponentials + 1 uniform + 3 comparisons. Adding the exact uniform decoder bound gives

\[
 C_{\rm query}\le
 15c_{\times}+14c_+
 +2c_{\exp}+c_U+3c_{\rm cmp}
 +c_{\rm route/access}+c_{\rm controller}.
 \tag{4}
\]

The charges are nonnegative costs supplied by the intended workload. If only the probability is requested, omit the uniform and final sampling comparison. If two endpoint displacement vectors are supplied instead of their already oriented difference, forming h=u_B-u_A adds two multiplications by -1 and two additions. An ineligible request returns the declared null answer without floating arithmetic, an exponential or a Bernoulli draw; it still pays its validity/dispatch cost.

The bound is uniform over all native ancestries, masks and eligible cuts. It is safe for an adaptive policy that chooses expensive rows based on its retained state and history. A cheaper expected cost requires the actual query workload and its joint distribution; it cannot be inferred from a mean branch cost independent of the policy.

Caching the unshifted phi(d) values is optional. With that cache the after-decode remainder is 4 M + 5 A + 1 exponential + 1 uniform + 3 comparisons, and the uniform query bound becomes 12 M + 13 A with those elementary operations. Caching every old-cut/channel value adds 2k real fields when k>1. It is not included in the uncached storage formula or in (4). A historical catalog may require more cached values, each of which must be counted.

## 4. Consistent assembly and panel bound

For an actual first cut, forming the four-coordinate residual d=z_B-z_A-V with the literal coefficient convention costs 8 M + 8 A. Forming its two channel probabilities costs another 6 M + 2 A + 2 exponentials. Multiplying those probabilities, drawing the active flag and comparing adds one multiplication, one uniform and one comparison. Thus each cut costs

\[
 15c_{\times}+10c_++2c_{\exp}+c_U+c_{\rm cmp}.
\]

There are at most four first cuts. A uniform literal panel bound is consequently

\[
 60c_{\times}+40c_++8c_{\exp}+4c_U+4c_{\rm cmp}.
 \tag{5}
\]

The old source's 28 M + 40 A panel allowance uses direct subtraction instructions without separately scaling every negative term by -1. That cheaper schedule remains its own stated implementation. The present schedule deliberately charges the explicit -1 scalings, consistently with (1) and the query schedule; it does not rewrite the old result or silently mix the two schedules.

Add the inherited first-parent assembly bound 52 M + 80 A and the newly counted augmented-map bound 52 M + 60 A. A conservative parent-only extra assembly bound relative to the same coupled baseline is

\[
 A_{\rm vec}=
 164c_{\times}+180c_+
 +8c_{\exp}+4c_U+4c_{\rm cmp}+c_{\rm case}.
 \tag{6}
\]

This is a componentwise combination of upper bounds, not a claim that one case attains the whole combined cost. The case charge includes selecting the precomputed map and forest/port record. Static coefficient storage and preprocessing remain separate. Carrying the common S coordinates is arithmetic-free under the assignment convention, but it is not free memory traffic.

As in the source coupled construction, accepted residual generation, native normalization and moment evaluation, common conditional factors, shared radial work and other genuinely shared tasks are not falsely charged to one side. Ignoring the fine completion's positive extra work makes (6) a conservative parent-minus-fine assembly allowance for those stated algorithms. It does not measure total runtime or prove that the parent is faster.

The full interface must also pay for reference-law representation, label and incidence catalogs, roots and masses, history/port storage, lookup code, rational constants, any reverse evaluator, model parameters, controller state and repeated access. Costs scaling with the number of retained draws, ticks or queries must retain that dependence; they cannot all be hidden in one fixed setup constant. The count supplies concrete coefficients for the larger resource comparison without selecting its prices.

## 5. Conservative finite-history bounds without a new enumeration

The finite-depth interface proof gives a historical decoder linear in the final geometry and retained response records. With k_0 initial blocks and k_L final blocks, it has at most k_0+k_L scalar inputs per coordinate direction. Since k_0<=4 and k_L<=4, a flat historical decoder row has at most eight nonzero inputs. Under (1), a conservative two-coordinate bound is therefore 16 M + 14 A. Adding the uncached query remainder gives 23 M + 20 A + 2 exponentials + 1 uniform + 3 comparisons, plus actual route/access/controller costs.

This is an analytical upper bound from row width, not an attained maximum or an enumeration of all histories. Compiling that flat row, storing its coefficients and identifying the relevant historical ports are additional work. The original record anchor remains separately retained. No claim is made that all historical queries cost only the one-panel maximum in (4).

For a finite sequence of requested panel stages, every proper contraction still uses a geometry of the four-cycle with at most four parents. The one-stage map and panel bounds provide a conservative stage allowance of 112 M + 100 A plus the panel elementary operations. Initial first-parent assembly is paid once. A no-merge geometry map has no floating arithmetic, but its requested panel and history/control work are still paid. There are at most three strictly count-reducing contractions, while arbitrarily many requested idle rounds can accumulate costs. No new history or scientific state was enumerated for these observations.

These resource bounds do not establish an error bound for newly defined current-parent inputs. The historical/current-interface distinction and the actual omitted-contrast law remain the separate mathematical results in the response derivations.

## 6. Executed evidence and remaining obligation

The [counting script](evidence/selected-hierarchy-response-cost/cost_maps.py) ran once with pinned CPython 3.14.7 and flags `-I -B`. It returned `PASS_EXACT_RESPONSE_OPERATION_COUNTS` after 0.014742200000910088 seconds. It read JSON and used only standard-library exact rational parsing and integer counting. It imported no prior scientific module, ran no old main, and evaluated no trajectory, sampler, observation or query probability.

The [result](evidence/selected-hierarchy-response-cost/cost-maps.json) stores the full 176-case and 416-port counts, every (k,q) maximum, attaining cases, query schedule, interpreter flags, invocation and source hashes. [Standard output](evidence/selected-hierarchy-response-cost/stdout-stderr.txt) records the executed summary.

The script SHA-256 is `97bb402b73805557636fbe2cbd08b92df71ab76018617807044b720122c28a3f`; the result SHA-256 is `e09df074f0a3473f6cd8216fc8cba02214638e153aec298c992f4f407a04fb78`. Its source map is bound to response-maps SHA-256 `22bb9a9fa67adb7be128868718d79f47cf393fc619359f3b976191cd5c0131c9`. These identify the counted artifacts; the mathematical operation convention and row arrays determine the count.

No benchmark, scientific rerun, test suite, ODE, new prior, GPU, Lean, tamper check, new history enumeration or publication was performed. Only the assigned script, count result, standard output and this report were written.

The strongest supported result is the exact one-panel arithmetic catalog and the explicit conservative query/assembly schedules (4) and (6). Remaining costs require a specified workload and prices, including memory access, historical ports, normalization/evaluation and controller behavior. A numerical net-benefit claim or an operational merge threshold cannot be inferred from these operation counts alone.
