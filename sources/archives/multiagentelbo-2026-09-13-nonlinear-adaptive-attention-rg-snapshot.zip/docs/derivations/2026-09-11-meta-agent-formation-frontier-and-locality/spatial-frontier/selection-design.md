# Spatial accuracy/resource frontier from the retained observations

September 11, 2026. DEFERRED COMPARATOR, NOT THE SELECTED CONTINUATION. Design only; no learner, scoring run, simulation, test, or new observation was executed for this document. Source checkout: ed8f22a56df353b1535744509cc23fae46d5813c. This file is the bounded selection investigator's output; the coordinator owns integration and the daily change log.

The subsequently clarified target concerns independent dynamic gauge links at each base-manifold point, coalescence as K_ij tends to zero, and an induced connection. The saved four-spin parity experiment has fixed scalar couplings and no dynamic gauge-link field or induced-connection construction. This proposed frontier cannot test or resolve that mechanism. It is retained solely as a deferred finite-data comparator; no execution is authorized by this document.

A spatial exploratory frontier is legitimate without an accuracy tolerance. It identifies nondominated presentations within a declared finite family; it does not choose a useful parent or complete a hierarchy. The original revised plan, sections 5.5, 7, and 10, explicitly permits the frontier as the result when no task tolerance or resource preference exists. The original exact obligation remains separate: the completed deterministic admission retains every local state for all fifteen subsets, and the completed stochastic argument rules out smaller finite complete local carriers for proper blocks under its stated preparation and exterior conditions. This design does not reopen those results.

## Target, supplied conditions, and new modeling choices

The finite source is the saved four-child experiment, with child indices V={0,1,2,3}, state space Y={-1,+1}^4, two action ordinals, two record ordinals, uniform preparation, and four events per episode. Child labels, the full Cartesian carrier, and the supplied complete interaction graph are given structure. No Euclidean positions or learned geometry are given. Every nonempty child subset is therefore available without inventing an adjacency threshold.

The available observations are the nine archived datasets indexed by three seeds and three independently resampled budgets b in {32,128,512}. Each has 32b independently prepared row transitions, b four-event training episodes, 256 validation episodes, and 256 evaluation episodes in each of six environment/policy cells. The original protocol supplies separate RNG streams. During training the learner can read the observed fine source and destination labels. During prediction it receives only the retained initial state, actions, and emitted records. There is no observed time-zero sensor. All score comparisons use the same four binary record events.

The introduced choices are a local, deterministic, training-derived agglomeration ladder; every disjoint child partition; base transition models without an added previous-record row index; and componentwise validation dominance over explicitly reported costs. These are a restricted exploratory family and an operational record-prediction target. They are not exact strong-exterior admission, optimal hidden-state realization, universal experiment equivalence, or a new penalty. No tolerance is silently set to zero: zero is used only in the mathematical definition of strict dominance between recorded coordinates.

The question is: for each saved training dataset D, which members of the finite family C_D have no other member with both no larger validation record loss and no larger declared resource coordinates, with at least one strict improvement? There is no assertion that this family contains the best spatial map among all maps, or that its empirical frontier equals a population frontier.

## Joint laws and the precise approximation

Use counting base measures throughout. For environment xi, let K_xi^a(y',e|y) be the actual normalized emitted kernel and let pi_t(a|a_<t,e_1:t) be the common observed-history policy. Its source joint law is

$$
P_\xi(y_{0:H},a_{0:H-1},e_{1:H})
=\frac1{16}\prod_{t=0}^{H-1}
\pi_t(a_t|a_{<t},e_{1:t})K_\xi^{a_t}(y_{t+1},e_{t+1}|y_t),
\qquad H=4.
$$

Summing backward over destination, record, and action proves normalization. The original and reversed-coupling environments remain separate xi values. The random validation policy defines the validation target; the six archived evaluation cells are separate diagnostic targets. No cell weighting or distribution over environments is inferred.

For a disjoint partition P={A_1,...,A_m} of V and surjective maps h_j:Y_{A_j}->S_j, define

$$
F(y)=(h_1(y_{A_1}),...,h_m(y_{A_m})),
\qquad K_F=\prod_{j=1}^m |S_j|.
$$

The full-product support and disjointness prove surjectivity onto the product: choose one local preimage for each requested coordinate and concatenate them. The deterministic common channel is T_F(z|y)=1{z=F(y)} and has row sum one. It pushes the entire correlated source law; replacing that push by a product of local marginal laws is excluded.

A fitted parent has one emitted table Q_D^a(z',e|z), not one separately simulated kernel per child block. Its path law from retained preparation z_0 is

$$
Q_D(z_{1:H},a_{0:H-1},e_{1:H}|z_0)
=\prod_{t=0}^{H-1}\pi_t(a_t|a_{<t},e_{1:t})
Q_D^{a_t}(z_{t+1},e_{t+1}|z_t).
$$

This is a normalized working Markov family. The true F-pushed process need not be Markov, and its conditional transition can depend on the fine posterior within a fiber. Fitting Q_D is therefore a model replacement unless closure is separately shown. The base model still filters the entire record history; omission of a previous-record table index does not mean omission of filtering.

Condition on D when defining expected losses. Write W=(A_0:H-1,E_1:H), Z=F(Y_0), and let q_t be the parent filter's predictive record probability. Define

$$
R_\xi(Q_D,F)
=E_{P_\xi}\left[-\frac1H\sum_{t=0}^{H-1}
\log q_t(E_{t+1}|Z,A_{0:t},E_{1:t})\right].
$$

With the fine oracle initialized at Y_0, the already-derived identity specializes to

$$
H[R_\xi(Q_D,F)-R_\xi(P_\xi,\mathrm{id})]
=I_{P_\xi}(Y_0;W|Z)
+E_Z \operatorname{KL}(P_\xi(W|Z)\Vert Q_D(W|Z)).
$$

For completeness, the left side equals
sum_y (1/16) KL(P_xi(W|y)||Q_D(W|F(y))) because the common action-policy factors cancel. Insert P_xi(W|F(y)) into the logarithm; the first summand is the conditional mutual information and averaging the second over each preparation fiber gives the displayed conditional KL. This requires P_xi(W|Z)<<Q_D(W|Z) on policy-supported paths. The positive pseudocount fit below supplies that support, so all finite-alphabet expectations are finite. Zero-policy paths contribute nothing. The second term combines estimation, Markov closure, and environment mismatch; it has no established additive split into those causes.

This is a predictive-risk identity, not an ELBO optimization or a claim of Blackwell equivalence. No recognition factorization or variational family is used by this fitting procedure.

## Minimal local ladder and disjoint family

For each nonempty A, encode its local sign tuples in lexicographic order, using increasing child indices. Project only the independently prepared training rows to

(source_A, action, destination_A, record).

Call the current partition_ladder with size 2^|A|, actions=2, and the retained prior=1. Do not supply generator tables, coupling values, validation losses, evaluation losses, or a desired grouping. The projection pools b*2^(4-|A|) observations per local-source/action row. Since the original preparations are balanced, its population one-step row is the uniform-exterior mixture

$$
\widetilde K_A^a(x',e|x)
=2^{-|V\setminus A|}
\sum_{u\in Y_{V\setminus A}}\sum_{u'\in Y_{V\setminus A}}
K^a((x',u'),e|(x,u)).
$$

This equation describes the search statistic, not information passed to the learner. It explicitly averages exterior source contexts and discards exterior destinations. A state distinction invisible in this mixture may still matter for a particular exterior context or for several-step prediction. The ladder is consequently a task-oriented search heuristic, and it does not satisfy the strong exterior contract by construction.

The source routine starts with singleton local classes, smooths each row with total prior mass one, aggregates destinations to current local classes, averages source rows uniformly within each current class, and merges the pair with minimum worst-action total variation between centroids. It returns one map h_A,k for every k=2^|A|,...,1. Preserve its deterministic comparison key (computed floating distance, first class label, second class label), canonical state ordering, and every returned map. These are numerical search decisions; do not introduce a near-tie threshold or call a floating tie exact rational equality.

For A=V, this operation is the original global response ladder. Use the already saved ladder after confirming identical source/input conventions, and label it a whole-system comparator that bypasses spatial grouping. It is not evidence that a child partition was learned. Local ladders for proper A are new analyses of old training observations, not reproductions of the original sixteen-state ladder.

Enumerate all fifteen set partitions of the four child labels, ordered canonically by each block's smallest child index. For each partition, take the Cartesian product of the local ladder choices. A partition with block sizes n_1,...,n_m has exactly

$$
\prod_j 2^{n_j}=2^4=16
$$

tagged candidate presentations. Thus there are 240 presentations per saved dataset, before deduplicating equivalent global maps, and 2,160 across the nine datasets. This count is a direct enumeration formula, not a newly executed result. The partition shapes are 1+1+1+1, 2+1+1, 2+2, 3+1, and 4, with respective multiplicities 1,6,3,4,1.

Flatten F by a declared mixed-radix encoding or canonical global partition labels and retain the reverse coordinate dictionary. Equal fibers can occur in different presentations. Deduplicate the fitted numerical model by its canonical global fiber partition, but retain every child-partition/local-map presentation and its resource ledger. A numerical model must not become several independent statistical replicates merely because it has several presentations.

## Fit the full projected joint table

For each distinct F, use the same 32b row transitions and 4b training-episode transitions as the original base estimator. Form complete counts

$$
N_a(z,z',e)
=\sum_{\text{all training transitions}}
1\{a_t=a,F(y_t)=z,F(y_{t+1})=z',e_{t+1}=e\}.
$$

With K=K_F and N_a(z)=sum_(z',e) N_a(z,z',e), define

$$
Q_D^a(z',e|z)
=\frac{N_a(z,z',e)+1/(2K)}{N_a(z)+1}.
$$

The numerator sums to the denominator, and every entry is positive. This is exactly the current fit_parent(rows,training,F,2,False,Fraction(1)) base-table contract. It is also the posterior predictive mean under independent Dirichlet(1/(2K),...,1/(2K)) priors on the rows of the stated working Markov model. The likelihood includes each sequential training episode as a Markov path; its individual events are not asserted to be independent evaluation replicates. The Bayesian interpretation belongs to that working model, not to a claim that the true coarse process is Markov.

Initialize the filter at the observed F(y_0). At each event, compute

$$
v(z')=\sum_z b_t(z)Q_D^{a_t}(z',e_{t+1}|z),
\quad p_{t+1}=\sum_{z'}v(z'),
\quad b_{t+1}(z')=v(z')/p_{t+1}.
$$

There is one external record and one original-clock event. No marginal transition products, duplicated sensor factors, independent simultaneous parent updates, or post-preparation fine-state access are allowed. Export base-row occupancies because a large joint table can be data-limited even when each local alphabet is small.

The entire normalized correlated push exists exactly as a probability law. Its replacement by the fitted Markov table is the only transition-model approximation introduced here, in addition to the deliberately restricted search family and finite-sample estimation.

## Costs, validation dominance, and ties

For base-only candidates report K retained joint states, log2 K state bits, K-1 continuous filter coordinates, 4K^2 dense emitted-table entries, and 2K(2K-1) normalized-row coordinates. These count an explicitly dense joint implementation; they are not measured latency, effective degrees of freedom, Fisher rank, or minimal belief dimension. Generative memory is singleton; the stochastic state sample and its recognition/filter distribution are different objects.

Use the following declared presentation encoding if no implementation-specific packed representation is available:

$$
B_{\mathrm{enc}}
=4\lceil\log_2 m\rceil
+\sum_{A\in P}2^{|A|}\lceil\log_2 k_A\rceil.
$$

The first term stores each child's ordered block label; the second stores each local lookup table. The ambient child alphabet, m, and local cardinalities are supplied out of band. State this convention next to every table. It is not a minimal description length or all runtime memory. Constants need zero lookup bits under this convention; retaining an otherwise irrelevant membership presentation can still cost membership bits. Exact formulas or optimized encodings could change this coordinate, so they require a declared alternative ledger, not retrospective relabeling of the same frontier.

For presentation c let L_val(c) be event-normalized record NLL on the original random-policy validation episodes. Use the cost vector (K,B_enc), while exporting every resource above separately. Because all other listed dense base costs are monotone functions of K, this gives the same dominance relation as including them all. Candidate d dominates c when every coordinate of (L_val(d),K_d,B_enc(d)) is no larger, and at least one is strictly smaller. Compute dominance on the actual recorded numerical losses, without an invented accuracy tolerance. Retain all exactly tied coordinate rows with their presentation IDs. Canonical IDs only order display or an explicitly bounded diagnostic subset; they do not eliminate scientific ties.

The full joint-state filter uses K-1 coordinates, not the sum of local simplex dimensions. Complete child coverage means the central predictor has no additional raw exterior coordinate. This omits the strong exterior interface by an explicit change of task, not by forgetting its cost: if a proposed modular implementation also retains raw exterior states, add those states and their filter/interface costs before claiming an advantage. The previously admitted exact proper-block-plus-exterior models each retain the full sixteen-state carrier.

Report an all-family frontier, and identify the presentation shape on every row. Within-shape frontiers may be shown as diagnostics, visibly distinct from the all-family frontier. Whole-system candidates, constant local maps, and identity local maps are valid controls. On four children, a potential two-parent first level with two multi-child proper blocks necessarily has shape 2+2. For the stronger descriptive badge "both parents individually nonconstant and compressive," require 1<k_A<4 for both pairs. That badge changes no dominance test and grants no accuracy or modularity acceptance.

## Bounded reuse of the six evaluation cells

Freeze all ladders, fitted rows, validation losses, costs, and frontiers before computing new evaluation scores. Preserve the original archive byte-for-byte. Existing evaluation cells have already been inspected, so these are exploratory reanalyses even if the current candidate selection reads only training and validation.

For a limited report, always include fitted global identity and constant references. For each of the three pair-pair child partitions, include at most one candidate from its intersection with the all-family frontier having 1<k_A<4 for both pairs. Choose that diagnostic representative by ascending validation NLL, then K, B_enc, and canonical presentation ID. Keep all ties in the validation artifact; the last ordering merely bounds evaluation work. If that intersection is empty, record "no qualifying validation-frontier presentation" instead of substituting a preferred candidate. Deduplicate equal global maps across the three representatives. This gives at most five fitted models per dataset, hence at most 270 model/cell rows across nine datasets and six cells. It is not a heldout evaluation of the complete frontier.

Each selected model is evaluated in every original/reversed environment crossed with positive, alternating, and record-feedback policy. Report cellwise NLL and the existing binary Brier convention. Pair each complete four-event episode across models. For candidate c and reference r, the evaluation unit is

$$
\Delta_i(c,r)
=-\frac14\sum_{t=0}^3
\log\frac{q_c(e_{i,t+1}|\text{available history})}
{q_r(e_{i,t+1}|\text{available history})}.
$$

Report its mean, sample SD, and conditional descriptive SE=SD/sqrt(256), keeping signed differences. Do not treat four events, six cells, several candidate presentations, or budgets as independent replications of formation. The three seeds give only three fitted instances per budget; budget datasets are independently resampled rather than a paired learning curve. Retain every fit/cell row and use no favorable-seed aggregate as an acceptance test.

No confidence interval, multiplicity-adjusted superiority claim, population Pareto claim, or confirmation is supplied. There are many adaptive fits and comparisons, and evaluation reuse is historical. A future fixed-rule confirmation requires fresh independent evaluation and a separately justified precision/effect requirement. None is specified here, so no fresh sample size is invented.

## Exit and unresolved hierarchy obligation

The supported output of a later execution is the complete declared validation frontier plus the explicitly limited exploratory evaluation panel. The mathematical construction above proves that all proposed deterministic maps and fitted joint rows are normalized under their stated finite support. It does not prove useful compression, exact controlled closure, informative persistence, an autonomous local evaluator, or a second level.

A useful hierarchy remains unclosed until at least two proper first-level blocks have a justified accuracy/information and total-resource acceptance contract, and a compatible next parent is built from their actual joint first-level law. For approximate composition one must supply a joint approximation/error bound and then establish its propagation; summing separate fitted local errors is not justified. A whole-system one-step summary is a bypass, not two learned levels.

This design is deferred and is not the selected next action. If separately resumed, it could reveal the available finite-data tradeoffs and whether any pair-pair presentations survive, but it cannot manufacture a missing preference or establish the dynamic gauge-link mechanism. Without a justified tolerance or resource budget, its frontier would remain the comparator result and no unique hierarchy would be selected. The governing continuation must instead locate the clarified gauge-link/coalescence/induced-connection model and its actual assumptions before deciding which construction applies.

## Source basis and execution record

The primary design authority is the attached revised plan at C:/Users/chris and christine/.codex/attachments/be4e6f63-61a2-4b23-812a-608a92793312/pasted-text.txt, especially sections 5.2, 5.5, 7, and 10. The live [finite-data protocol](../../../research-plans/2026-09-11-finite-data-formation-protocol.md), [estimator and scorer](../../../../src/multiagent_elbo/rg_v2/finite_data_formation.py), [retrospective analysis](../frontier-analysis.md), and [analysis script](../evidence/frontier/analyze.py) fix access, data reuse, support, and score conventions. The retained [local admission](../local-admission.md), [stochastic local bound](../stochastic-local-admission.md), and [record](../RECORD.md) fix the unresolved exact/approximate boundary.

The Research wiki's [Coarse Graining](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Coarse Graining.md>) distinguishes common probability push, family restriction, and model replacement; [Statistical Experiment Comparison and Deficiency](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Statistical experiment comparison and deficiency.md>) distinguishes a selected predictive loss from uniform experiment comparison. Those scope distinctions are used here; no external theorem or deficiency bound is imported from the wiki.

Executed work was limited to read-only source/record inspection, live HEAD/status inspection, and writing this file. No scientific calculation, implementation, scoring, test, simulation, new collection, vault write, or second-level construction ran. The formulas and family-size count are analytical derivations. No formal ledger closure is asserted.

