# Normalized parents, induced variational costs, and inherited dynamics

September 12, 2026. This is the parent-reduction lane of the current six-step investigation. It addresses steps 4–6 at one base point, with no base transport. Its target is an exact accounting theorem and a quantitative dynamical bridge for the complete microscopic construction, followed by a second compatible reduction. It does not identify an equilibrium marginal with a projected sample path.

The strongest result is conditional but constructive. A parent can carry the **original normalized generative marginal**, its induced evaluator and child conditionals, and an **exact conditional-family ELBO** whose additional variational cost is derived by elimination. Reversible microscopic kinetics then determine the averaged parent mobility and force. A Poisson-corrector estimate bounds the retained trajectory error. These objects compose at a second step. A compact, continuous, non-Gaussian two-channel law-point model with moving independent links realizes the normalization and two averaging steps; Section 7.2 joins attraction and both reductions in one strictly positive-noise finite-horizon regime. Its microscopic rate separation is supplied; it is not a derivation of collective rate separation or formation in the unrestricted radial model.

## 1. Target, source boundary, and domains

The governing [problem contract](evidence/2026-09-12-dynamical-rg-goal/problem-contract.json) asks for an existential finite dynamical regime, with two nontrivial reductions, genuinely evolving links, distinct coupled belief/model channels, controlled approximation, and no inference from a finite example to an infinite hierarchy. This lane proves statements for every model satisfying the hypotheses below and supplies one non-Gaussian realization of the reduction hypotheses. Establishing that dynamically formed blocks of the unrestricted microscopic model satisfy those hypotheses remains a separate obligation. A supplied coarse map is not a proof of formation.

The reused source facts are the recognition-independent common channel and conditional-KL identities in [Theory/06](../../../Theory/06_general_coarsegraining.tex), the measure-pair RG of [Theory/07](../../../Theory/07_general_renormalization.tex), and the normalized adaptive graph, complete evaluator and downward-factor distinctions in [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex). The [September wiki synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>) was read alongside live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:cross_scale_shadows`, `app:augmented_joint`, `sec:meta_agent_rg`, `eq:rg_internal_hessian`, `eq:rg_slow_graph_metric`, and `eq:rg_schur_flow`. PIFB2 explicitly labels its configuration Gibbs ensemble hypothetical; the present microscopic lane supplies an actual sampler, but its target must still be typed correctly.

The existing [attraction derivation](coherence-attraction-and-dynamical-rg.md), [marked GL parent](gl-alignment-marked-parent.md), [native memory calculation](native-memory-and-local-parent-reduction.md), [moving-target calculation](pointwise-learning-parent-closure.md), [source/parent reconciliation](post-merge-source-and-gaussian-parent-bridge.md), and the actual [Gaussian](../2026-09-11-fast-slow-derived-hierarchy/gaussian-hierarchy-construction.md) and [scale-kernel](../2026-09-11-fast-slow-derived-hierarchy/scale-kernel-construction.md) proofs are inputs. In particular, conditional matching can be broken by model learning, graph pullback and metric Schur complement are different, and prior-predictive mixing is different from an expected-log mean-field message. No earlier calculation is rerun here.

Let $W$ be the complete microscopic law-point and link state on a standard Borel space, and $K$ the physical/model sample variables evaluated from it. The original normalized generative law is

\[
 P(dW,dK)=P_0(dW)P_{\rm in}(dK\mid W).
 \tag{1}
\]

At a fixed temperature $T>0$, the admitted correlated inner recognition family has a normalized kernel $R(dK\mid W)$. Define

\[
 d(W)=D\bigl(R(\cdot\mid W)\Vert P_{\rm in}(\cdot\mid W)\bigr),
 \qquad
 \mathcal F_T(Q)=T D(QR\Vert P).
 \tag{2}
\]

The microscopic lane derives, for its Gaussian physical evaluator, $d(W)=\sum_i\|u_i-C_i v_i\|^2/[2(1-a)]$, with $0<a<1$. Here $u_i,v_i$ are law parameters, $W$ is a random law-point configuration, and $Q$ is recognition over those configurations. They are three different probabilistic levels. No observation is imposed in the unforced setting. A fixed normalized future observation kernel can be appended without changing any prior normalization.

Added hypotheses for Sections 2–3 are $P_0$ proper, $d$ measurable and finite $P_0$-almost surely, and $0<c:=E_{P_0}e^{-d}<\infty$. Nonnegativity of $d$ gives $c\le1$, and finiteness almost surely gives $c>0$. Sections 4–6 additionally impose smooth dominated densities, regular fixed-rank coordinates, appropriate boundary conditions, and the displayed kinetic assumptions. These are not consequences of the general probability-law types.

## 2. The exact parent carries an induced conditional variational cost

The conditional relative-entropy chain rule gives

\[
 \frac{\mathcal F_T(Q)}T=D(Q\Vert P_0)+E_Qd
 =D(Q\Vert\Pi)+\log(1/c),
 \qquad
 \Pi(dW)=c^{-1}e^{-d(W)}P_0(dW).
 \tag{3}
\]

Thus $\Pi$ is the optimal outer law in this restricted inner-recognition family. It is generally **not** $P_0$, and it is not the unrestricted posterior of the original joint (1). The minimum full-family gap is $T\log(1/c)$. If $P_0=Z_0^{-1}e^{-U_0/T}\nu$, then $\Pi=Z^{-1}e^{-U/T}\nu$, where $U=U_0+Td$, $Z/Z_0=c$. The diffusion in the microscopic lane targets this $\Pi$.

Let $Y=C(W)$ be a measurable deterministic map, common to the generative and recognition laws. Put $P_1=C_\#P_0$, $Q_1=C_\#Q$, and use regular conditionals on their supported fibers. Define

\[
 A_1(y)=E_{P_0(\cdot\mid y)}e^{-d(W)},\qquad
 d_1(y)=-\log A_1(y),
 \qquad
 K_1^*(dW\mid y)=\frac{e^{-d(W)}}{A_1(y)}P_0(dW\mid y).
 \tag{4}
\]

These formulas hold $P_1$-almost everywhere, where $0<A_1\le1$. Kernels on null fibers are arbitrary versions and supply no physical prediction. The star labels the variationally optimal conditional; it is not a new generative prior.

**Exact elimination theorem.** On the finite-KL domain, and by nonnegative chain-rule extension when appropriate,

\[
 \boxed{\frac{\mathcal F_T(Q)}T
 =D(Q_1\Vert P_1)+E_{Q_1}d_1
   +E_{Q_1}D\bigl(Q(\cdot\mid Y)\Vert K_1^*(\cdot\mid Y)\bigr).}
 \tag{5}
\]

Consequently, for each supported parent recognition $r$,

\[
 \inf_{C_\#Q=r}\mathcal F_T(Q)
 =\mathcal F_{T,1}(r)
 :=T D(r\Vert P_1)+T E_r d_1,
 \qquad Q^*=rK_1^*.
 \tag{6}
\]

The minimizer is unique on supported fibers when the value is finite. The normalized outer target and its conditional lift are

\[
 \Pi_1(dy)=c^{-1}e^{-d_1(y)}P_1(dy)=C_\#\Pi,
 \qquad K_1^*=\Pi(dW\mid Y=y).
\tag{7}
\]

For the actual transient diffusion law $Q_t$, its hidden conditional $Q_t(dW\mid Y)$ need not equal $K_1^*(dW\mid Y)$. Equation (5) retains the resulting conditional KL exactly; the parent objective (6) is the minimized conditional-family objective, not automatically the full transient fine objective. The trajectory $W_1$ estimates below do not bound this dimensionless KL. Such an entropy statement would require an additional conditional equilibration estimate and is not claimed.

To prove (5), first disintegrate $D(Q\Vert P_0)$. On one fiber the log density identity is

\[
 \log\frac{dQ(\cdot\mid y)}{dP_0(\cdot\mid y)}+d(W)
 =\log\frac{dQ(\cdot\mid y)}{dK_1^*(\cdot\mid y)}+d_1(y).
 \tag{8}
\]

Integration proves the result, including its minimization and uniqueness. Equation (7) follows by disintegration of $e^{-d}P_0/c$. For extended values one uses (3) and the nonnegative KL chain rule rather than subtracting infinities.

There are two consistent ways to state the parent ELBO, and neither deletes a term. First, (6) is an exact **augmented conditional-family ELBO** of the unchanged model: generate $Y\sim P_1$, then $W\sim P_0(\cdot\mid Y)$, then $K\sim P_{\rm in}(\cdot\mid W)$. Use parent recognition $r(dy)K_1^*(dW\mid y)R(dK\mid W)$. Its conditional KL equals $d_1(y)$ by (8). The internal variables are integrated in the conditional kernel and do not remain independent evolving parent coordinates. No claim about evaluation cost is made.

Second, if one integrates $W$ out of both this joint and its recognition, the ordinary coarse ELBO on $(Y,K)$ is smaller by the nonnegative conditional KL of $W\mid Y,K$. That exact residual must remain if the original objective is to be reproduced. Calling the smaller coarse ELBO (6) without that residual is incorrect. Thus the retained $d_1$ is an induced variational operator, not an independently added child-parent penalty or a fabricated success observation.

More explicitly, split the complete retained presentation into belief coordinates $B_1$, model coordinates $M_1$, and required structural sources $\Xi_1$. On supported source rows the **augmented parent evaluator** is the normalized kernel

\[
 \operatorname{ev}_1(db,dW_{\rm int},dK\mid m,\xi)
 =P_1(db\mid m,\xi)P_0(dW_{\rm int}\mid b,m,\xi)
                         P_{\rm in}(dK\mid W).
 \tag{9a}
\]

Its source prior is $P_1(d m,d\xi)$. Its output includes the sampled belief presentation $b$, so dependence on $b$ in the subsequent conditional is an ordinary directed factorization, not access to a live recognition law. Parent recognition is $r(db,dm,d\xi)K_1^*(dW_{\rm int}\mid b,m,\xi)R(dK\mid W)$. Its full ELBO is exactly (6). The kernel $K_1^*$ is fixed by the microscopic model, evaluator restriction, and retained sample values; it is not an unrestricted hidden dynamic state. At the next step (9a) uses the composed conditional (11). Thus the exact-ELBO class is the same class of normalized, possibly correlated conditional presentations allowed by Theory/07c. Closure in the narrower *original Gaussian evaluator formula alone* is not claimed.

The true downward prior is $P_0(dW\mid Y)$. Its belief/model hyperprior factors follow by disintegration in the selected order and may depend on all retained marks. The conditional $K_1^*$ is instead the optimal recognition conditional for the original evaluator-constrained family. They agree exactly when $d(W)$ is constant on almost every retained fiber. Even then $P_1=\Pi_1$ additionally requires that fiberwise constant to be independent of $y$.

The parent generative evaluator is obtained from $P$, not from $\Pi$. For a fixed normalized output kernel $L(do\mid W,K)$,

\[
 L_1(do\mid y)=\int P_0(dW\mid y)P_{\rm in}(dK\mid W)L(do\mid W,K).
 \tag{9}
\]

Its integral over $o$ is one. A belief/model source ordering similarly disintegrates the induced joint into a parent-model prior and a normalized belief/observation evaluator. Dropping a retained source requires the corresponding conditional independence; it is not licensed by naming the remaining variable a model. Mixing (9) against a parent posterior is a predictive operation. It is not the expected-log mean-field update and does not create a second same-time generative arrow.

For nonstationary samples, an arbitrary hidden-dependent emission need not have conditional law (9). Exact retained path observations require a pointwise descended emission, or a separate conditional-averaging estimate for that emission. Normalization of (9) is an equilibrium/generative statement and does not erase this dynamic distinction.

## 3. A second elimination preserves both normalizers and conditional costs

Let $Z=D(Y)$ be a second fixed map, using the induced intermediate $P_1$, not a newly selected reference. Define

\[
 P_2=D_\#P_1,\qquad
 d_2(z)=-\log E_{P_1(\cdot\mid z)}e^{-d_1(Y)},
 \qquad
 K_2^*(dy\mid z)=e^{-d_1(y)+d_2(z)}P_1(dy\mid z).
 \tag{10}
\]

Conditional expectation gives the exact identities

\[
 e^{-d_2(z)}=E_{P_0(\cdot\mid z)}e^{-d(W)},\qquad
 K_2^*K_1^*(dW\mid z)
 =e^{-d(W)+d_2(z)}P_0(dW\mid z),
 \tag{11}
\]

\[
 \Pi_2=(DC)_\#\Pi=D_\#\Pi_1,
 \qquad E_{P_2}e^{-d_2}=E_{P_1}e^{-d_1}=c.
 \tag{12}
\]

For arbitrary fine recognition of finite free energy, write $Q_2=D_\#Q_1$. Applying (5) twice yields

\[
 \frac{\mathcal F_T(Q)}T
 =D(Q_2\Vert P_2)+E_{Q_2}d_2
 +E_{Q_2}D(Q_1(\cdot\mid Z)\Vert K_2^*)
 +E_{Q_1}D(Q(\cdot\mid Y)\Vert K_1^*).
 \tag{13}
\]

Direct and staged conditional-family minimization therefore agree. The corresponding *generative* downward kernels $P_1(dy\mid z)P_0(dW\mid y)$ also compose, separately, to $P_0(dW\mid z)$. No recognition kernel has been used as a prior. The evidence of the full model and the global gap $T\log(1/c)$ are unchanged.

This is closure in the class of complete normalized laws, induced evaluator kernels, and the scalar operators $d_\ell$. It is not closure in a prescribed sum of pairwise KL terms. Log conditional integrals generally induce multivariable and holonomy-dependent terms. They are retained here without a pairwise ansatz.

## 4. The generator and metric inherited by the parent

For this section let $W$ range over a finite-dimensional smooth manifold with reference measure $\nu$. Boundary conditions are either periodic/closed, reflecting with zero flux, or sufficient decay at infinity to justify every displayed integration by parts. Let $M(W)$ be the declared positive microscopic mobility. The actual reversible generator is

\[
 Lf=T\Pi^{-1}\operatorname{div}_{\nu}(\Pi M df).
 \tag{14}
\]

It has invariant probability $\Pi$, not $P_0$. Its density evolution dissipates (3): if $Q_t=q_t\nu$ is regular,

\[
 \frac{d}{dt}\mathcal F_T(Q_t)
 =-T^2\int \bigl\langle d\log(q_t/\pi),
          M d\log(q_t/\pi)\bigr\rangle q_t d\nu\le0.
 \tag{15}
\]

This is transport/Dirichlet kinetics for a density over law points. It is not the full-simplex Fisher flow of that density.

Suppose $C$ is a regular smooth retained map. Define $a(W)=DC(W)M(W)DC(W)^\top$, and use the conditional law of **$\Pi$**:

\[
 \overline M_1(y)=E_{\Pi(\cdot\mid y)}a(W).
 \tag{16}
\]

Let $\Pi_1=Z^{-1}e^{-F_1/T}\nu_1$. The conditionally averaged generator is

\[
 \overline L_1f
 =T\Pi_1^{-1}\operatorname{div}_{\nu_1}
       (\Pi_1\overline M_1df).
 \tag{17}
\]

In product Euclidean coordinates with reference Lebesgue measure this has diffusion matrix $2T\overline M_1$ and drift

\[
 \overline b_1=T\operatorname{div}\overline M_1
                    -\overline M_1\nabla F_1.
 \tag{18}
\]

The proof is the exact identity, for smooth retained $f,g$,

\[
 -\int(g\circ C)L(f\circ C) d\Pi
 =T\int dg^\top\overline M_1df d\Pi_1.
 \tag{19}
\]

Integration by parts proves the left equality; conditioning proves the right. A second integration by parts identifies (17). Smoothness identifies conditional expectations pointwise on regular support. Thus (17) is a determined averaged operator, not an arbitrarily selected parent Fisher metric. Its configuration metric is $\overline M_1^{-1}$ where nondegenerate, and its density mobility is $r\overline M_1$. A new Fisher metric computed from displayed parent parameters is not interchangeable with either object.

Equation (19) alone does not imply path closure. Exact closure for all initial states requires the stronger generator identity

\[
 L(f\circ C)=(L_1f)\circ C
 \quad\hbox{for all retained smooth }f,
 \tag{20}
\]

together with well-posedness of the retained martingale problem. In a regular diffusion chart, this requires its pushed drift and diffusion coefficients to be constant on each retained fiber. It is sufficient by applying the fine martingale equation to $f\circ C$; uniqueness identifies the retained law. Averaging (20) is not a proof of (20).

For two maps, let $P_C$ and $P_{DC}$ denote conditional expectation under the same $\Pi$. Their projections obey $P_{DC}P_C=P_{DC}$. Hence the two averaged generators agree on root functions:

\[
 P_{DC}(P_C L P_C)P_{DC}=P_{DC}LP_{DC}.
 \tag{21}
\]

Equivalently, the stage-two mobility is

\[
 \overline M_2(z)=E_{\Pi_1(\cdot\mid z)}
       [DD(Y)\overline M_1(Y)DD(Y)^\top]
 =E_{\Pi(\cdot\mid z)}[D(DC)M D(DC)^\top].
 \tag{22}
\]

This is exact coefficient and Dirichlet-form composition. Finite-time accuracy of two successively averaged processes requires the additional estimates below.

## 5. A quantitative conditional-averaging theorem

An elementary path estimate suffices in a useful product-coordinate regime. Let $W=(Y,X)$, let $Y$ be Euclidean or a periodic coordinate lifted continuously to Euclidean space, and assume

\[
 L^\epsilon=L_s+\epsilon^{-1}L_f,
 \qquad
 dY=b(Y,X)dt+\sqrt{2TA} dB_t,
 \tag{23}
\]

where $A$ is constant positive definite. $L_f$ acts only on $X$, and has invariant conditional $\Pi(dX\mid Y=y)$. $L_s$ includes the actual slow and other retained coordinate dynamics. The common reference and generator must give (14); then $\overline b(y)=E_\Pi[b(y,X)\mid y]=-A\nabla F_1(y)$. Cross derivatives, moving reference densities, and state-dependent retained diffusion need their corresponding terms; (23) does not omit them by assumption after the fact.

Assume a vector corrector $\chi(y,x)$ solves

\[
 L_f\chi=b-\overline b,\qquad E_{\Pi(\cdot\mid y)}\chi=0.
 \tag{24}
\]

For a horizon $H>0$, assume the fine trajectory remains in a domain on which

\[
 \|\chi\|\le C_\chi,\quad\|L_s\chi\|\le C_s,\quad
 \operatorname{tr}\Gamma_s(\chi)\le C_{\Gamma s},\quad
 \operatorname{tr}\Gamma_f(\chi)\le C_{\Gamma f},
 \tag{25}
\]

and $\overline b$ is $L_b$-Lipschitz. Here $\Gamma_j(\chi)$ is the quadratic-variation rate of the martingale part from $L_j$, including its factor $2T$. All constants concern the actual fine generator and the chosen regular region. Assume initial retained coordinates agree. Couple the averaged process

\[
 d\overline Y=\overline b(\overline Y)dt+\sqrt{2TA} dB_t
 \tag{26}
\]

using the same retained Brownian motion. Then

\[
 \boxed{E\sup_{0\le t\le H}\|Y_t-\overline Y_t\|
 \le e^{L_bH}\left[
 2\epsilon C_\chi+\epsilon H C_s
 +2\sqrt{\epsilon^2H C_{\Gamma s}
                 +\epsilon H C_{\Gamma f}}\right].}
 \tag{27}
\]

A nonzero initial difference adds $e^{L_bH}E\|Y_0-\overline Y_0\|$. No equilibrium preparation of $X_0$ is needed when (25) holds globally. A stopped local version uses stopped martingales and comparison trajectories admitted in the same coordinate neighborhood; removing stopping additionally requires an exit estimate.

For the proof, Itô's formula applied to (24) gives

\[
 \int_0^t(b-\overline b)(Y_s,X_s)ds
 =\epsilon[\chi(W_t)-\chi(W_0)]
   -\epsilon\int_0^t L_s\chi(W_s)ds-\epsilon N_t.
 \tag{28}
\]

The martingale $N$ has expected trace quadratic variation at most $H(C_{\Gamma s}+\epsilon^{-1}C_{\Gamma f})$. The elementary $L^2$ maximal martingale inequality gives $E\sup\|N_t\|\le2\sqrt{E\operatorname{tr}\langle N\rangle_H}$. Subtract (26) from (23); the Brownian terms cancel. The integral Lipschitz inequality and Gronwall's bound give (27). This proof states exactly which derivatives and moments control the approximation.

The method is consistent with the primary conditional-effective-dynamics work of [Legoll and Lelièvre, 2009/2010](https://arxiv.org/abs/0906.4865), and the pathwise-estimate work of [Legoll, Lelièvre and Olla, 2016/2017](https://arxiv.org/abs/1605.02644). No theorem from those papers is imported here: (24)–(28) are the proof used. In particular a positive Hessian gap alone does not establish all the corrector bounds.

If a second reduction admits its own estimate $B_2(H)$, and the first estimate is $B_1(H)$, then the Wasserstein-1 distance on retained continuous paths with supremum norm satisfies

\[
 W_1\bigl(\mathcal L(DY),\mathcal L(\overline Z)\bigr)
 \le \operatorname{Lip}(D)B_1(H)+B_2(H).
 \tag{29}
\]

Use the first coupling, the second coupling, and disintegrate over their common intermediate path to join them; the triangle inequality proves (29). Thus coefficient composition (21) and two actual approximation estimates are distinct ingredients.

## 6. Value, force, and zero-temperature statements remain separate

In product coordinates write $W=(y,x)$, with all Jacobian/reference factors included. Define

\[
 F_{0,1}(y)=-T\log\int e^{-U_0(y,x)/T}dx,\qquad
 F_1(y)=-T\log\int e^{-[U_0(y,x)+Td(y,x)]/T}dx.
 \tag{30}
\]

Then $F_1=F_{0,1}+Td_1$, including constants calibrated by the same unnormalized integrals, and differentiation under an admitted dominating function gives

\[
 \nabla F_1=E_{K_1^*}\nabla(U_0+Td),\qquad
 T\nabla d_1=E_{K_1^*}\nabla(U_0+Td)
                      -E_{P_0(\cdot\mid y)}\nabla U_0.
 \tag{31}
\]

The change in conditional weighting is part of the force. One cannot replace this expression by $T E_{P_0}\nabla d$.

For an explicitly normalized quadratic fiber, $U(y,x)=V(y)+\frac12x^TH(y)x$ with $H\succ0$, the exact potential is

\[
 F_1=V+\frac T2\log\det H-\frac{rT}2\log(2\pi T),\quad
 dF_1=dV+\frac T2\operatorname{tr}(H^{-1}dH).
 \tag{32}
\]

This reused Gaussian identity illustrates the fluctuation force. Deterministic slaving to $x=0$ follows $V$, not (32), at positive $T$. A non-Gaussian integral retains its full force (31), including all induced interactions.

Here is a sufficient error statement that actually separates value and force. On an entire admitted compact fiber, let $U=U_a+R$, with $|R|\le\eta_0$, $\|d_yR\|\le\eta_1$, and $\|d_yU_a\|\le B$. Let $F_a=-T\log\int e^{-U_a/T}$. Direct bounds on the integrands and conditional density ratios give

\[
 |F_1-F_a|\le\eta_0,\qquad
 \|dF_1-dF_a\|
 \le\eta_1+B\min\{2,e^{2\eta_0/T}-1\}.
 \tag{33}
\]

For the derivative, split the difference into $E_UdR+(E_U-E_a)dU_a$. The normalized likelihood ratio lies between $e^{-2\eta_0/T}$ and $e^{2\eta_0/T}$, bounding the $L^1$ difference of the conditionals as used in (33). Unbounded fibers require weighted moment/tail estimates instead of these uniform bounds. A small value error alone gives no derivative error: $R_\eta(y)=\eta\sin(y/\eta^2)$ has vanishing amplitude and unbounded derivative.

With unchanged constant mobility, a uniform force error $\eta_F$ contributes at most $H\|A\|\eta_F e^{L_bH}$ to the same-noise path comparison. A mobility error changes the drift and noise as well and requires their separate bounds. It cannot be charged to $\eta_0$.

For deterministic dynamics $\dot W=-\operatorname{grad}_G U$, an exactly invariant graph $i(y)=(y,s(y))$ with tangent vector field inherits $G_i=Di^T GDi$ and potential $U\circ i$. Indeed restriction of the gradient pairing to every tangent vector proves the gradient identity. An approximately invariant graph additionally needs its actual transverse and tangent residuals. This graph metric is different from (16), and the positive-temperature integrated potential is different from $U\circ i$. A simultaneous $T\to0$, stiffness-to-infinity, and time-separation limit requires uniform estimates; none is inferred by setting three symbols to zero.

## 7. A compact continuous non-Gaussian realization

This realization tests the bridge in the same law-point/physical-evaluator architecture as the microscopic lane. It introduces an explicit compact statistical subfamily and supplied local rate factors. It does **not** claim that the unrestricted quartic radial model remains on this subfamily, or that these rate factors have been derived from coalescence.

Take three agents $i=0,1,2$ on the directed cycle $0\leftarrow1\leftarrow2\leftarrow0$. Fix $r>0$, $0<a<1$, $T>0$, and strictly positive edge and same-agent coefficients. Let $n(t)=(\cos t,\sin t)$. The physical law points are

\[
 b_i=N(rn(\theta_i),I_2),\qquad
 m_i=N(rn(\psi_i),aI_2),\qquad
 R_e^b=R(\phi_e^b),\quad R_e^m=R(\phi_e^m)\in SO(2).
 \tag{34}
\]

There are twelve independent angles: six law angles and six link angles. The reference is normalized Haar measure on $\mathbb T^{12}$. Links are independent state coordinates, not vertex-ratio parameterizations. The two loop holonomies are the sums of their three link angles modulo $2\pi$. They can be nonzero and genuinely evolve.

With $e:j\to i$, use the normalized local-prior/edge-tilt action

\[
 U_0=\sum_e J_e^b[1-\cos(\theta_i-\theta_j-\phi_e^b)]
 +\sum_e J_e^m[1-\cos(\psi_i-\psi_j-\phi_e^m)]
 +\sum_i\lambda_{0,i}r^2[1-\cos(\theta_i-\psi_i)].
 \tag{35}
\]

The $J_e^b$ multiply actual transported Gaussian KL after absorbing its factor $r^2$; $J_e^m$ similarly absorb $r^2/a$. For one isolated node, $\psi_i$ has the uniform prior and

\[
 p_{0,i}(d\theta_i\mid\psi_i)
 =\frac{\exp[(\lambda_{0,i}r^2/T)\cos(\theta_i-\psi_i)]}
             {I_0(\lambda_{0,i}r^2/T)}\frac{d\theta_i}{2\pi},
 \quad I_0(s)=\frac1{2\pi}\int_0^{2\pi}e^{s\cos t}dt.
 \tag{36}
\]

Every row normalizes. The edge tilt is a positive bounded product and has finite positive normalizer, so $P_0=Z_0^{-1}e^{-U_0/T}\nu$ is proper. This is not an unspecified Gibbs lift: the following generator is part of the declared microscopic model.

Use exactly the physical evaluator $\zeta_i\sim m_i$, $k_i\mid\zeta_i\sim N(\zeta_i,(1-a)I_2)$. Its correlated inner recognition has

\[
 \zeta_i=rn(\psi_i)+\xi_i,\quad
 k_i=rn(\theta_i)+\xi_i+\varepsilon_i,
 \quad \xi_i\sim N(0,aI_2),\quad
 \varepsilon_i\sim N(0,(1-a)I_2),
 \tag{37}
\]

with independent noises and node product conditional on $W$. It has precisely marginals $m_i,b_i$. The conditional Gaussian shift ratio gives

\[
 d(W)=\sum_i\frac{r^2}{1-a}[1-\cos(\theta_i-\psi_i)],\quad
 U=U_0+Td.
 \tag{38}
\]

The physical model/evaluator is unchanged by this variational cost. The true generative prior is still $P_0$. The effective angular same-agent coefficient is $\lambda_{0,i}r^2+Tr^2/(1-a)$.

For fixed positive $\mu_b,\mu_m,\eta_e^b,\eta_e^m$, define local tangent diffusions

\[
 L^{\epsilon,\delta}
 =\sum_i s_i\{\mu_b[T\partial_{\theta_i}^2-U_{\theta_i}\partial_{\theta_i}]
             +\mu_m[T\partial_{\psi_i}^2-U_{\psi_i}\partial_{\psi_i}]\}
 +\sum_{e,x}\eta_e^x[T\partial_{\phi_e^x}^2-U_{\phi_e^x}\partial_{\phi_e^x}],
 \quad (s_2,s_1,s_0)=(\epsilon^{-1},\delta^{-1},1).
 \tag{39}
\]

Each derivative reads only incident edges and its same-agent evaluator term. The angular Fisher metric of (34) is a positive constant ($r^2$ or $r^2/a$); the $\mu$'s include its inverse and any declared microscopic clock coefficient. Thus (39) specifies its metric and noise completely. It has unique global paths because all coefficients are smooth and bounded on a compact torus, and has invariant $\Pi\propto e^{-U/T}$. All six independent links have nonzero diffusion and actual energy-dependent drift. No walls, external success observations, or frozen links are used.

Independent local frame changes add $\gamma_i$ to both $\theta_i,\psi_i$ and add $\gamma_i-\gamma_j$ to each link $j\to i$. The action, Haar reference and constant angular kinetic forms are invariant. These are fiberwise frame changes at $c_*$. Link holonomy is an agent-network quantity, not a path in the base.

Take $C_1$ to forget $(\theta_2,\psi_2)$ and $C_2$ to forget $(\theta_1,\psi_1)$. Every link angle is retained at both steps, equivalently its rooted tree marks and two cycle holonomies. These are proper reductions $\mathbb T^{12}\to\mathbb T^{10}\to\mathbb T^8$. The root belief and model law points remain nonconstant, and their physical evaluator (37) is a normalized, retained-dependent kernel. Sources needed by the induced evaluator (9) are not erased. A group-theoretic quotient of retained tree marks is not needed here.

The exact parent densities are the two integrals in (30), first over the two node-2 angles and then over the node-1 angles. They are not Gaussian. To see their content explicitly, collect the terms involving one eliminated pair $t=\theta_2,s=\psi_2$ into

\[
 U=U_{\rm rest}-\operatorname{Re}(\overline A_b e^{it})
                    -\operatorname{Re}(\overline A_m e^{is})
                    -\Lambda\cos(t-s),
 \tag{40}
\]

where $A_b,A_m$ are sums of the two incident edge phasors with their actual endpoints and link phases, and $\Lambda=\lambda_{0,2}r^2+Tr^2/(1-a)>0$. The fiber integral is exactly

\[
 e^{-F_1/T}=e^{-U_{\rm rest}/T}
 \sum_{n\in\mathbb Z}I_n(|A_b|/T)I_n(|A_m|/T)I_n(\Lambda/T)
                         e^{in(\arg A_b-\arg A_m)},
 \tag{41}
\]

with constants from (35) included in $U_{\rm rest}$. At $A_b=0$ or $A_m=0$, (41) is interpreted by the continuous integral (40), so no undefined phase is used. The definition $I_n(s)=(2\pi)^{-1}\int e^{s\cos t}e^{-int}dt$ and multiplication of Fourier series prove (41). Absolute convergence follows from smooth periodic exponential factors, or their factorial coefficient bounds. Its logarithm couples both channels, neighbors and links. These induced operators remain in $F_1$ and $d_1$; no pairwise closure is claimed.

For a simple load-bearing holonomy check, a single channel with equal $x=J/T$ has, after integrating its matter angles at fixed root and links,

\[
 \int\exp\{x(\cos A_0+\cos A_1+\cos A_2)\} d\theta_1d\theta_2/(2\pi)^2
 =1+\frac34x^2+\frac14x^3\cos h+O(x^4),
 \tag{42}
\]

where $A_e$ are the three directed mismatches and $h$ is their loop sum up to sign. Integration kills all nonzero matter Fourier modes; among the product of three cosines only the two consistently oriented cycle terms survive. The remainder is bounded in magnitude by $e^{3|x|}(3|x|)^4/4!$. This is an analytic small-coupling statement, not the approximation used to define the parent. Positive same-agent coupling gives the two-channel model (41); the nonzero loop term persists on a sufficiently small positive-coupling neighborhood by continuity. The exact model uses the full integrals at all admitted coefficients.

Both averaging steps are dynamically admitted. For fixed retained $y$, the node-2 fast operator is a smooth uniformly elliptic weighted Laplacian on the connected torus $\mathbb T^2$, with invariant conditional $K_1^*$. The node-1 operator after first averaging has exactly the same form with potential $F_1$: its constant mobility is inherited unchanged and its drift is the conditional mean of the original drift. It acts on another connected $\mathbb T^2$. All coefficients and their derivatives are uniformly bounded over compact parameter ranges with $T,r,\mu_b,\mu_m$ bounded away from zero.

For completeness, this gives the required Poisson solvability rather than merely naming a gap. On a $2\pi$-period angular torus, the uniform-measure inequality $\operatorname{Var}_\nu f\le\int|\nabla f|^2d\nu$ follows by Fourier modes. If the conditional potential oscillation is at most $O$, comparison of its maximum and minimum density gives

\[
 \operatorname{Var}_{K^*}f
 \le e^{O/T}\int|\nabla f|^2dK^*,\qquad
 \mathrm{gap}(-L_f)\ge T\min(\mu_b,\mu_m)e^{-O/T}>0.
 \tag{43}
\]

The period convention in (43) is $2\pi$, for which the first nonconstant Fourier eigenvalue is one. Minimize the coercive quadratic functional $\frac12T\int\nabla\chi^TM\nabla\chi dK^*+\int r\chi dK^*$ on the mean-zero $H^1$ space. Weak compactness, (43) and strict convexity give its unique minimizer, satisfying $L_f\chi=r$ for mean-zero $r$. Its equation has constant elliptic principal part. Fourier inversion puts the solution in $H^2$ when the drift times its $H^1$ gradient is in $L^2$; repeated differentiation and Fourier inversion bootstrap to every $H^k$, hence smoothness. Differentiating in the retained parameters gives the corresponding centered equations; the same coercivity bound controls them uniformly. This proves finiteness of all constants in (25) for each stage, without Gaussianity.

At stage one $L_s$ contains the node-1 factor $\delta^{-1}$. Its constants must not be reported as uniform in $\delta$. On a fixed compact parameter set, elliptic bounds just proved yield a constant $C$, independent of $\epsilon,\delta\le1$, such that

\[
 C_{\chi,1}\le C/\delta,\quad C_{s,1}\le C/\delta^2,\quad
 C_{\Gamma f,1}\le C/\delta^2,\quad C_{\Gamma s,1}\le C/\delta^3,
 \quad L_{b,1}\le C/\delta.
 \tag{44}
\]

The powers follow by counting the single retained node-1 rate in $b,L_s$, using linearity of the corrector equation and squaring its gradient for quadratic variation. At stage two the same constants are bounded independently of $\delta$, because its fast factor has been extracted and the retained root/link coefficients stay bounded. Equations (27) and (29), with $\operatorname{Lip}(C_2)=1$, therefore give for $0<\epsilon\le\delta\le1$

\[
 W_1(\mathcal L(Z^{\epsilon,\delta}_{[0,H]}),
                         \mathcal L(\overline Z_{[0,H]}))
 \le C_H e^{CH/\delta}\frac{\sqrt\epsilon}{\delta^2}
                                  +C_H\sqrt\delta.
 \tag{45}
\]

All norms can use the Euclidean lifts of the periodic SDEs, which upper bound torus path distance. This estimate holds for every initial law with the same retained initial coordinate; no equilibrium preparation is assumed. It proves the sequential limit $\epsilon\to0$ at fixed $\delta$, followed by $\delta\to0$. For example, the explicitly sufficient simultaneous choice $\epsilon(\delta)=\delta^6e^{-4CH/\delta}$ makes the first term at most $C_H\delta e^{-CH/\delta}$. The conservative bound is not a claimed optimal scaling or an empirically selected rate ratio.

Thus this continuous, nonlinear, dynamically linked example realizes **two actual averaging steps**, not just two stationary marginals or two formal Dirichlet forms. Its stationary/full-ELBO accounting is (5)–(13), its parent force includes $Td_\ell$, and its parent mobility is inherited from (39). The microscopic rates $s_i$ are declared modeling inputs. The following local argument joins this construction to coherence in this same compact model; it does not transplant the separate radial model's basin or claim a unique preferred grouping.

### 7.1 The same compact model has a coherent basin and restoring fibers

At zero noise the action is $U_0$. Its minimum set is

\[
 \mathcal S=\{\theta_i=\psi_i=\alpha_i,
       \ \phi_e^b=\phi_e^m=\alpha_i-\alpha_j
             \pmod {2\pi}\},
 \tag{46}
\]

with three freely varying $\alpha_i$. Every term in (35) is nonnegative and every coefficient is positive, so these are all zeroes. The nine scalar residuals are the six directed edge phase mismatches and the three same-agent phase mismatches. Their derivative has rank nine: the six link columns independently solve the six edge equations, and the remaining three equations are the independent $\delta\theta_i-\delta\psi_i$. Therefore $\mathcal S\cong\mathbb T^3$ is a compact smooth minimum manifold, and its Hessian is $R^T\operatorname{diag}(J_e^b,J_e^m,\lambda_{0,i}r^2)R$ with kernel exactly $T\mathcal S$. All nine normal modes have positive quadratic stiffness. This is an explicit hypothesis check for a Morse–Bott minimum, not an imposed equality of children.

Compactness and Taylor's theorem give a tubular sublevel neighborhood and constants $c_0,c_1,a,b>0$ such that $c_0\operatorname{dist}(W,\mathcal S)^2\le U_0(W)\le c_1\operatorname{dist}(W,\mathcal S)^2$ and $aU_0\le\|\operatorname{grad}_{G_{\epsilon,\delta}}U_0\|^2\le bU_0$. For every fixed positive $\epsilon,\delta$, its deterministic gradient flow has $\dot U_0\le-aU_0$, remains in the sublevel neighborhood and converges to a point of $\mathcal S$. The proof is the energy and finite-tail-length argument in the earlier attraction report, now with its rank and compactness hypotheses established for (35). The lower bound can be chosen uniformly when all microscopic mobilities have a common positive lower bound; an upper bound and the limiting point may depend on the rate factors. The basin is an open set of initial configurations.

The selected fibers are not discarded gauge or collective modes. With links and the other nodes fixed at a coherent configuration, the node-2 Hessian is

\[
 H_{22}=
 \begin{pmatrix}
  j_2^b+\lambda_{0,2}r^2&-\lambda_{0,2}r^2\\
  -\lambda_{0,2}r^2&j_2^m+\lambda_{0,2}r^2
 \end{pmatrix},\qquad
 j_2^x=\sum_{e\text{ incident to }2}J_e^x>0.
 \tag{47}
\]

Its quadratic form is $j_2^b u^2+j_2^m v^2+\lambda_{0,2}r^2(u-v)^2$, hence it is positive definite. Fixing the root and all links similarly pins the four node-1/node-2 matter directions. If $J_*$ is the least edge coefficient, their full Hessian satisfies $H_{\rm int}\succeq J_*I_4$: each channel contains the rooted triangle Dirichlet form $J_*[(x_1-x_2)^2+x_1^2+x_2^2]$, whose matrix has eigenvalues $J_*,3J_*$, and the same-agent terms are positive semidefinite. After eliminating node 2, its node-1 Schur Hessian obeys

\[
 H_{11}-H_{12}H_{22}^{-1}H_{21}\succeq J_*I_2.
 \tag{48}
\]

Indeed its quadratic form is the minimum of $(u,v)^TH_{\rm int}(u,v)$ over $v$, which is at least $J_*\|u\|^2$. Changing an omitted matter angle alone cannot be tangent to (46) while its root and incident links are held fixed. The retained link marks preserve the missing gauge coordinates.

The kinetic eigenvalue clusters follow from these matrices and the supplied rates. With $\epsilon\ll\delta\ll1$, the two node-2 rates have leading positive coefficients $\epsilon^{-1}\operatorname{spec}(M_2^{1/2}H_{22}M_2^{1/2})$. Eliminating that block in the eigenvalue equation leaves the two node-1 rates with leading coefficients $\delta^{-1}\operatorname{spec}(M_1^{1/2}(H_{11}-H_{12}H_{22}^{-1}H_{21})M_1^{1/2})$. For fixed $\delta$, multiplying the block characteristic equation by the appropriate powers of $\epsilon$ and taking $\epsilon\to0$ gives the first cluster; applying the same operation at the next level gives the second. The remaining normal rates are of order one or remain in the retained state, and the three tangent gauge directions are neutral in the unforced deterministic model. No rate is reset at the parent.

The connected block ${0,2\}$ may therefore retain node 0 as representative, node 1 as its exterior, and every boundary/link mark while its node-2 matter mismatches relax. The second step combines this parent with node 1 and eliminates the latter's restoring matter directions. Whole-network coherence in the displayed basin licenses both connected reductions. The dynamics do not thereby select a unique preferred partition, or prove a separate pair-only episode; the elimination order is justified by these restoring fibers and the supplied microscopic clock hierarchy.

### 7.2 A nonempty common small-noise and two-reduction regime

The fixed-$T$ bound (45) is not used to infer uniform persistence as $T\to0$: its coarse gap estimate (43) can deteriorate exponentially. A different, elementary comparison supplies an explicit common regime.

At a compatible retained configuration, each conditional minimizer of $U_0$ over node 2, or over nodes 1 and 2 together, is a **unique global** minimizer on its compact torus. Every positive term can vanish at the coherent completion and zero total energy forces that completion, because the fixed root and links pin all omitted angles. Equations (47)–(48) make it nondegenerate. Compactness gives a positive energy gap outside a small convex coordinate neighborhood of that completion. The implicit-function theorem and this gap give, on a smaller open retained neighborhood, a unique smooth global minimizer $s_1(y)$ and a unique smooth direct minimizer $s_{02}(z)$, with uniform positive internal Hessians. Their stage-two profiles agree: $\min_y\min_x U_0=\min_{x,y}U_0$. Other local minima at higher action do not invalidate this statement.

For one deterministic fast block, write $x=s(y)+e$, with fast mobility $B/\epsilon$, $B\succ0$, and suppose its fiber Hessian is bounded below by $mI$ in the admitted convex neighborhood. In the norm $\rho=\|e\|_{B^{-1}}$, the actual equation gives

\[
 D^+\rho\le-\gamma\rho/\epsilon+C\|\dot y\|,
 \qquad
 \rho(t)\le\rho(0)e^{-\gamma t/\epsilon}
                 +C\epsilon\sup_{s\le t}\|\dot y_s\|,
 \tag{49}
\]

where $\gamma>0$ follows from $m$ and the eigenvalues of $B$. Pair the error equation with $B^{-1}e$, use $e^T\nabla_x U_0(y,s+e)\ge m\|e\|^2$, and bound $Ds\dot y$ to obtain (49). Integrating the first term, rather than taking its supremum, controls the initial layer. The retained drift is Lipschitz in $x$; Gronwall then bounds its trajectory error. Applied first with retained speed bounds of order $\delta^{-1}$, and then to the node-1 profile, this gives

\[
 B_{\rm det}(H;\epsilon,\delta)
 \le C_H\left[\delta+
       \frac{\epsilon}{\delta^2}e^{CH/\delta}\right]
 \tag{50}
\]

for an open set of sufficiently close initial configurations, including nonzero initial internal mismatch. Constants include a fixed bound on that initial mismatch. A first-exit bootstrap using (49) and the positive basin margin ensures the trajectories stay in the stated neighborhoods. The limiting retained mobility is the retained block of (39); the fast graph metric contribution is order $\epsilon$ or $\delta$, not a new parent Fisher metric.

The exact normalized parent potentials also approach these same deterministic profiles **in force**, not only in value. Uniformly on the admitted retained neighborhood, if $V_1(y)=U_0(y,s_1(y))$,

\[
 F_{1,T}(y)
 =V_1(y)+T\left[d(y,s_1(y))+\tfrac12\log\det H_{22}(y)
                         -\tfrac{r_1}2\log(2\pi T)+r_1\log(2\pi)\right]+O(T^2),
 \quad
 \|dF_{1,T}-dV_1\|\le C T,
 \tag{51}
\]

with the product-Haar constant included consistently. The direct second parent has the corresponding formula with the four-dimensional internal Hessian and profile $V_2$. The derivative bound, rather than the displayed expansion order, is what is used below. To check it directly, write $x=s(y)+\sqrt T\xi$, factor $e^{-V_1/T}T^{r_1/2}$, and use stationarity to eliminate the linear term. The rescaled integral and its first two $y$-derivatives have Gaussian-polynomial dominators from the uniform positive Hessian. Its value is bounded away from zero. Hence the first derivative of the logarithm of that rescaled integral stays bounded. The exterior action gap makes the omitted integral and its derivatives exponentially small, even after the factors $1/T$ from differentiation. This proves the force estimate and a uniform local Lipschitz bound. The compact cosine action is smooth to all required orders. The normal determinant and $d(y,s(y))$ terms are retained at positive $T$.

For fixed $\epsilon,\delta>0$, compare the fine $T>0$ SDE to the deterministic $T=0$ equation using the same initial state. Its drift Lipschitz constant is at most $C/\epsilon$, its mobility trace is at most $C/\epsilon$, and the $Td$ drift correction has magnitude at most $CT/\epsilon$. The Brownian maximal inequality and Gronwall give

\[
 B_{\rm noise}(H;T,\epsilon)
 \le C_H e^{CH/\epsilon}
           \left[\sqrt{T/\epsilon}+T/\epsilon\right].
 \tag{52}
\]

The exact first and second averaged SDEs satisfy the same conservative bound when compared to their deterministic profile equations, by (51) and their smaller retained mobility traces. Stop the latter comparisons at the boundary of the admitted retained neighborhood. If the deterministic paths remain at distance at least $\rho_*>0$ from that boundary, the probability of a stopped exit is at most $B_{\rm noise}/\rho_*$. On the compact torus the path metric is bounded, so the contribution after an exit is bounded by that diameter times the exit probability. Combining these comparisons with (50) proves

\[
 W_1\bigl(\mathcal L(Z^{\epsilon,\delta,T}_{[0,H]}),
                   \mathcal L(\overline Z^T_{[0,H]})\bigr)
 \le C_H\left[\delta+
       \frac{\epsilon}{\delta^2}e^{CH/\delta}
       +(1+\rho_*^{-1})e^{CH/\epsilon}
            \left(\sqrt{T/\epsilon}+T/\epsilon\right)\right].
 \tag{53}
\]

The same comparison bounds deviation of the fine noisy trajectory from its coherent attracting deterministic trajectory. In particular, after its deterministic entry time into a narrower coherence tube, the probability of leaving a larger admitted tube before $H$ is bounded by (52) divided by the remaining tube margin. This is a finite-time probability statement, not permanent coherence at positive noise.

There is an explicit nonempty joint regime. After fixing the finite horizon and an inner basin neighborhood, take $\delta$ small, $\epsilon=\delta^4e^{-2CH/\delta}$, and then

\[
 0<T\le\epsilon^3e^{-4CH/\epsilon}.
 \tag{54}
\]

The deterministic term in (53) is $O(\delta)$, and its noise term tends to zero. All three rates and $T$ remain strictly positive. Strict versions of these inequalities give an open parameter regime; initial conditions range over the open inner basin just specified. This construction is intentionally conservative and establishes existence rather than useful numerical scales. It does not combine the incompatible limits of a crude $e^{O/T}$ mixing estimate with a small-noise exit estimate. It instead compares both actual stochastic processes to the same deterministic two-stage reduction. The exact original prior, augmented evaluator and induced variational costs remain (1)–(13) at every positive $T$.

### 7.3 Collective response and a scoped departure mechanism

Both can be realized by normalized observations in this same compact model. Let all node/channel heading observations equal an external angle $a_{\rm ext}$, with von Mises densities whose concentrations are $h/[T s_i\mu_x]$, $h>0$. Their normalizers $2\pi I_0(h/[T s_i\mu_x])$ are independent of the latent angles. The resulting angle-dependent potential is

\[
 E_{\rm ext}=-h\sum_i\left[
       (s_i\mu_b)^{-1}\cos(\theta_i-a_{\rm ext})
      +(s_i\mu_m)^{-1}\cos(\psi_i-a_{\rm ext})\right].
 \tag{55}
\]

These are external headings, not agreement-success records. On the synchronous coherent submanifold $\theta_i=\psi_i=w$, $\phi_e^b=\phi_e^m=0$, the specified microscopic equations give exactly

\[
 \dot w=-h\sin(w-a_{\rm ext}),\qquad \dot\phi_e^x=0.
 \tag{56}
\]

The synchronous pullback metric is $\sum_i[(s_i\mu_b)^{-1}+(s_i\mu_m)^{-1}]$; differentiating (55) and dividing by this metric gives the same rate. The observation precision choices are declared and the resulting rate is derived, not a claim of universal collective slowdown. More quantitatively, let $W_{\rm sync}(t)$ solve (56), let a neighboring initial configuration be within distance $\zeta$ in a common lifted chart, and let $L_h\le C_h/\epsilon$ bound the forced drift derivative. Coupling its fine SDE to the deterministic central solution gives

\[
 E\sup_{t\le H}d(W_t,W_{\rm sync}(t))
 \le e^{L_hH}\zeta+B_{{\rm noise},h}(H;T,\epsilon).
 \tag{56a}
\]

Here $B_{{\rm noise},h}$ is (52) with the forced derivative bounds; the central solution also has zero evaluator mismatch, so its extra $Td$ drift vanishes. Choose the right side smaller than the admitted tube margin to obtain the corresponding exit-probability bound by Markov's inequality. Equations (49)–(53) give the retained response error in addition. For sufficiently small fixed forcing, compactness and the implicit-function theorem preserve the conditional minimum/Hessian margins. These are explicit finite-horizon controls on an open neighborhood; the independent link states need not remain flat and their noises remain independent. The reference trajectory illustrates response, while its admitted neighborhood supplies moving-link configurations.

A stronger edge-relative heading provides a departure mechanism. For an edge $e:j\to i$, lift the gauge-invariant mismatch $\xi=\theta_i-\theta_j-\phi_e^b$ to $|\xi|\le\rho<\pi/2$. A normalized von Mises observation of this relative heading at $\pi/2$, with concentration $F/T$, adds the potential $-F\sin\xi$, up to its angle-independent normalizer. Its contribution to the mismatch velocity is

\[
 \dot\xi_{\rm ext}
 =F\cos\xi (s_i\mu_b+s_j\mu_b+\eta_e^b).
 \tag{57}
\]

The independent link responds in the same gradient equation and supplies the last positive term. All other terms in $\dot\xi$ have a finite global bound $B$ because the unforced deterministic drift is smooth on the compact torus. Choose $F$ so that $F\cos\rho(s_i\mu_b+s_j\mu_b+\eta_e^b)>B+v$, $v>0$. Then $\dot\xi\ge v$ until the mismatch exits the band, so its deterministic exit time $\tau_\rho$ satisfies $\tau_\rho\le(\rho-\xi(0))/v$. This is a normalized external relative-heading observation, introduced only in this departure experiment. For $|\xi(0)|<\rho_c<\rho$, couple the forced SDE to this deterministic trajectory. At $\tau_\rho$, failure of the noisy trajectory to have exited $|\xi|\le\rho_c$ requires a mismatch error at least $\rho-\rho_c$. Thus, for $H\ge(\rho-\xi(0))/v$,

\[
 {\mathbb P}(\tau_{\rho_c}^{T}>\tau_\rho)
 \le \frac{\|d\xi\| B_{{\rm noise},F}(H;T,\epsilon)}
              {\rho-\rho_c},
 \tag{57a}
\]

where $\|d\xi\|=\sqrt3$ for the product angular metric, and $B_{{\rm noise},F}$ is (52) with the forced drift constants. The bound compares departure from the smaller band with deterministic exit of the larger band, so it retains a strictly positive error margin. It tends to zero as $T\to0$ with fixed positive rates and fixed $F$.

The observation bookkeeping is explicit. The baseline generative $P_0$ and its marginal $P_1$ remain unchanged. For a fixed observed heading $o$, write $L_o(W)$ for its normalized likelihood, $p(o)=E_{P_0}L_o>0$, and $P_0^o=L_oP_0/p(o)$ for the selected posterior. Its first parent likelihood and induced conditional cost are

\[
 L_1(o\mid y)=E_{P_0(\cdot\mid y)}L_o(W),\qquad
 d_{1,o}(y)=-\log E_{P_0(\cdot\mid y,o)}e^{-d(W)}.
 \tag{58}
\]

With the corresponding posterior-tilted optimal conditional $K_{1,o}^*$, the exact observed objective is

\[
 \mathcal F_{T,o}(Q)/T
 =D(Q_1\Vert P_1)-E_{Q_1}\log L_1(o\mid Y)
       +E_{Q_1}d_{1,o}
       +E_{Q_1}D(Q(\cdot\mid Y)\Vert K_{1,o}^*).
 \tag{59}
\]

Equivalently this is $-\log p(o)+D(Q_1\Vert P_1^o)+E_{Q_1}d_{1,o}$ plus the last conditional KL. The same conditional tower proof composes (58) at stage two, with the same evidence. The sampler targets the tilt of this selected posterior, and its parent potentials integrate $U_0-T\log L_o+Td$ with every likelihood/evidence constant retained. A selected posterior has not been relabeled a generative prior.

Each forcing experiment uses a fixed observation and a time-independent posterior potential during the reported interval. Equations (49)–(53) apply anew to sufficiently weak fixed forcing after its normalizers and conditional minima are included. The strong departure experiment instead identifies exit of that regime; no reduction accuracy is claimed after exit. Turning a pulse on or off starts a new fixed-potential interval with the inherited initial distribution. A continuously time-dependent observation would add the corresponding target derivative and, in (28), a $\partial_t\chi$ term; no such extension is silently used here.

After departure the local reduction is no longer licensed by its Hessian/conditional-branch neighborhood; the exact common-channel law and conditional cost still exist. This establishes a concrete failure condition and a controllable departure mechanism. It does not assert that the old hierarchy remains valid through a merge, that every strong observation destroys coherence, or that the microscopic dynamics discover one uniquely preferred intermediate block.

## 8. Application to the unrestricted local law/link construction

For the microscopic lane's noncompact law means and compact $SO(d)$ links, (3)–(13) apply as soon as its proven normalizers and its evaluator-constrained $d$ are used. Equations (16)–(22) also identify the exact candidate inherited generator on any admitted smooth retained map. The original $P_0$, the variational target $\Pi$, generative child priors, and recognition-optimal internal conditionals remain distinct throughout.

Near a regular coherent stratum, a normal-coordinate chart must retain tangential root-law coordinates, the necessary independent-link/stabilizer holonomy, and any boundary dependencies. The prior marked-parent calculation supplies this static geometry. To apply (27) to a block formed by the actual microscopic diffusion, one still has to derive a scale-separated conditional operator from its full transformed mobility and drift, solve or bound (24) on its true fibers, and prove that the chosen region is occupied over the required interval. A Hessian gap by itself does not do this. The compact witness proves these analytic conditions are nonempty; it does not supply them for a different noncompact fiber or through a singular stratum.

If the actual geometric map has internal-dependent retained covariance, (23) is not its SDE. Formula (17) remains the averaged generator, but a quantitative weak/martingale estimate or an appropriate multiplicative-noise coupling must additionally average the diffusion matrix. If structural parameters evolve outside the sampled $W$, the conditional target moves and the terms already derived in [pointwise learning](pointwise-learning-parent-closure.md) must be included. Resetting those conditionals would change the microscopic process.

The scale direction here is increasing elimination depth $0\to1\to2$, at the same fixed $c_*$, temperature, observation experiment and native time. No time rescaling, common-carrier identification or beta-function convention is introduced. Consequently no fixed point, relevant direction, universality class or infinite hierarchy is asserted. The exact retained interaction class is the complete conditional-integral class, not a five-term closure ansatz.

For the unrestricted extension, the next decisive action is to insert the attraction lane's dynamically reached block map into (16), compute its pushed drift/covariance and conditional generator, and bound its first corrector. The same check at the next retained level is the remaining dynamical acceptance test for that extension. The compact realization in Section 7 already supplies both reductions with explicit finite-horizon controls. The normalization/evaluator accounting and two-step conditional-cost identity do not require another Gaussian calculation.

## 9. Evidence and scope of execution

The mathematical evidence is the explicit log-density calculation (8), the conditional tower calculation (11), the generator calculation (19), the Itô estimate (28), the compact realization with Poisson construction (34)–(45), and the joined finite-horizon construction (46)–(59). The standard-library script [fourier_terms_exact.py](evidence/dynamical-parent-rg-bridge/fourier_terms_exact.py) ran once under `C:/Python314/python.exe -I -B`, reporting Python 3.14.4 and exact `int`/`Fraction` arithmetic. Its [machine-readable result](evidence/dynamical-parent-rg-bridge/fourier-terms-result.json) and [stdout](evidence/dynamical-parent-rg-bridge/fourier-stdout-stderr.txt) record all four finite Fourier checks passing in 0.0008231 seconds. Those checks cover the zero linear cycle term, the quadratic coefficient $3/4$, the oriented cubic holonomy coefficients $1/8$ each, and the mixed-channel hidden-node coefficients $1/8$ each. They do not prove the general averaging theorem. No sampled trajectory, training run, GPU calculation, historical experiment, full suite, Lean proof, or tamper check is part of this lane. Only this assigned document and its uniquely prefixed evidence files are edited.
