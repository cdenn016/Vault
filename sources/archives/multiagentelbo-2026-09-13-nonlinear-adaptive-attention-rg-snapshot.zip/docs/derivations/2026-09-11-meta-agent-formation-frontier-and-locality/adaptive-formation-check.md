# Independent reconstruction of the adaptive cyclic formation witness

September 12, 2026. This document checks [the cyclic witness](adaptive-cyclic-witness.md) against contract `contract-sha256-e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90`, using [the normalized model](adaptive-normalized-model.md) and [the conditional interface](adaptive-conditional-bounds.md). The checker authored the conditional interface but did not author the cyclic witness. This is therefore an independent reconstruction of the formation, matrix, scaling, and witness-specific path arguments, not an independent review of every conditional theorem. No ledger closure state is assigned here.

The reconstruction supports the finite-dimensional Gaussian formation result at its stated quantifiers. The main load-bearing points are the weight-independent triangular bounds, the actual conditional-mean restoring equation, the additive Lyapunov bound for full time maxima, and the calibration comparison for independently learned parents. The calculations below reconstruct those steps. Exact normalized marked-parent geometry is a separate component; this check does not certify its entire presentation interface by reference alone.

## 1. Exact target and limitations of the checked statement

For every fixed integer `L>=2`, the witness constructs a graph with `2^(L-1)` triangles and dyadic bridges. There is an `epsilon_0(L)>0` such that every `0<epsilon<epsilon_0(L)` in its displayed family admits a proper normalized Gaussian model, the complete normalized model score, a positive correlated Gaussian initial recognition, and `L` ordered formation windows before `2/epsilon`. The model parameter changes by more than `1/2` over that horizon. At every stage the parent is initialized from the preceding actual Gaussian law and current parameter. Its parameter evolves from its own inherited objective and metric.

The checked formation statement is quantitative approximate coherence: the already formed original edges have small transported law-point KL, and future bridges have a separated larger value on each controlled window, outside an explicitly bounded exceptional event. It does not assert exact agreement at positive temperature, a unique grouping outside those windows, or the exact first hitting time of a coherence threshold. Earlier formed agreements persist; an intermediate partition does not remain the maximal coherent partition after its later bridges coalesce.

The total order-one model change occurs mainly after the short formation windows. The model update is active during those windows, and the conditional/path estimates continue through the remaining adaptation interval. The frozen contract requires appreciable change on the admitted interval; it does not require order-one model change separately inside every formation window. The witness meets that distinction, and its narrower timing statement should be preserved.

The admitted class is a Euclidean configuration diffusion on finitely many scalar Gaussian law/link coordinates at one base point. It is not full-law Fisher recognition flow. The model-parameter update uses the full generative Fisher metric with its calibration observation. The proper root reference, compatible heterogeneous observation, supplied microscopic contrasts, finite depth, and scalar common precision learning are explicit restrictions.

## 2. Exact carrier, rank, cycles, and the flag

Put `b=2^(L-1)`, `n=3b`, and `E=4b-1`. The full dimension is `d=2n+E=10b-1`. The full residual map contains `n` rows `u_i-v_i` and `E` rows `(Du)_e-alpha_e`. These `7b-1` rows are independent: the independent alpha columns kill every edge-row coefficient, and the remaining v columns kill the node-row coefficients. Its kernel therefore has dimension `3b=n` and is exactly the set in W5.

Inside each triangle, the two contrast rows in W3 are orthonormal and orthogonal to the constant edge vector. Since the triangle incidence sum is zero,

$$
 \sum_{e\in q}r_e=-h_q,\qquad
 |r_q|^2=|Q_\triangle r_q|^2+h_q^2/3.
 \tag{C1}
$$

The unit holonomy row `h_q/sqrt(3)` uses only that triangle's alpha coordinates. Its scalar product with any internal contrast row is zero by the contrast's zero sum; its scalar product with every other listed row is zero by disjoint alpha support or absence of alpha. Thus the witness's reduced residual map `B` has rank `6b-1`, its row range is orthogonal to the `b` holonomy directions, and

$$
 (6b-1)+b+3b=10b-1.
 \tag{C2}
$$

This proves the orthogonal decomposition W6. It also verifies that retaining all holonomies is compatible with eliminating the specified residual contrasts. The equality between `H_N+J_1P_Hh` and the sum of all original edge energies follows from (C1). No added loop penalty is needed.

Every flag layer is nonempty. There are `5b` rows at level 1, and for each `s=2,...,L` there is at least one bridge index with `2+v_2(j)=s`. Each subset of the independent rows increases rank by its row count. The final retained dimension is `4b`, containing the original holonomies and root modes. This dimension is not confused with the final graph's single agent count.

## 3. Weight-independent restoring bounds and their Schur inheritance

In an orthonormal flag basis, let `T_B=BO`. A row at level `j` annihilates every flag layer with index greater than `j`; hence `T_B` is block lower triangular. Rank increase at every step makes each diagonal block invertible, so its inverse is also block lower triangular.

For `D_J=diag(J_s I)` and descending positive weights, every nonzero block of `D_J^(1/2) T_B D_J^(-1/2)` is the original block multiplied by `sqrt(J_j/J_i)<=1`. The same statement holds for the inverse. Therefore

$$
 \|D_J^{1/2}T_BD_J^{-1/2}\|\le\|T_B\|_F,
 \qquad
 \|(D_J^{1/2}T_BD_J^{-1/2})^{-1}\|\le\|T_B^{-1}\|_F.
 \tag{C3}
$$

Applying (C3) to `D_J^(1/2)w` proves W15 with the explicit constants W14. They do not deteriorate as the weight ratios grow. Adding `kappa I`, with fixed `0<kappa<=1` and `J_s>=1`, and multiplying by `a in [1,2.1]` changes only finite graph-dependent constants.

The exact Schur form on a retained normal subspace is the minimum of the complete positive quadratic over its orthogonal complement. Minimizing the lower weighted bound and setting the eliminated variable to zero in the upper bound proves the same retained weighted inequalities. Repeated minimization equals minimization over the union, which proves normalized quadratic composition and the restoring lower bounds through all finitely many parents.

The cross-block estimate requires more than this spectral bound, and the witness supplies the extra argument. For `p<s`, in the original quadratic, every row of level at most `s` annihilates the future subspace `N_s`. The original eliminated-future and current-future blocks are consequently `O_L(J_(s+1))`. Every row of level at most `p` annihilates the current and future subspaces, so the eliminated-current block is `O_L(J_(p+1))`. The eliminated inverse is `O_L(1/J_p)`. Thus its Schur cross correction is

$$
 O_L(J_{p+1})O_L(J_p^{-1})O_L(J_{s+1})
 =O_L(J_{s+1}),
 \tag{C4}
$$

using `J_(p+1)<=J_p`. At `p=0` there is no previous elimination and no inverse term. The isotropic observation precision creates no original off-diagonal block. The retained-future principal block is bounded by setting the previously eliminated variable to zero in the variational characterization. This verifies W18, including the bound on the block `V` used in W23.

For parameter derivatives, put `X_a=[I;-D_a^{-1}B_a^T]` for one Schur split. The identity `K_aX_a=[S_a;0]` implies

$$
 \partial_a S_a=X_a^T(\partial_aK_a)X_a.
 \tag{C5}
$$

Since `0<=partial_aK_a<=K_a/a`, (C5) proves the relative derivative in W19. Differentiating the cross Schur formula retains the factors in (C4). Its inverse derivative is bounded by

$$
 A_{EE}^{-1}H_{EE}A_{EE}^{-1}\preceq a^{-1}A_{EE}^{-1},
 \tag{C6}
$$

which follows by congruencing `H_EE<=A_EE/a`. This proves the `O_L(J_(s+1))` cross derivative without inserting a largest-weight factor. The root and holonomy spectators are excluded from this normal-sector cross block because they are exactly decoupled, not because their large eigenvalues are being ignored in a bound where they enter.

## 4. Nondegenerate preparation and distinct formation windows

Each future form `b_eP_s` used in W20 is nonzero on `N`: otherwise the original edge row would lie in the span of earlier rows, contradicting row independence. For an internal triangle edge its projection on the internal contrast space is nonzero. With `D_N=dim N`, every such nonzero form applied to `(1,t,...,t^(D_N-1))` is a nonzero polynomial of degree at most `D_N-1`. If there are `m` forms, their union has at most `m(D_N-1)` real roots. The witness tests `m(D_N-1)+1` integers, so at least one works. After normalization this proves a strictly positive `m_L` in W20. The construction is finite and depends only on the graph/flag, not on the weights.

For any admitted source or independently learned ancestor, its normal mean obeys an unforced equation with symmetric positive precision. Its Euclidean norm cannot increase, and orthogonal activation cannot increase it either. Thus `|mu_N|<=A` throughout every branch. For the hidden/future split, variation of constants gives

$$
 |u(t)|\le A e^{-c_LJ_s(t-t_0)}
 +\frac{C_L A J_{s+1}}{c_LJ_s}.
 \tag{C7}
$$

The future block row is `O_L(J_(s+1))`, so its mean changes by at most `C_L A J_(s+1)t`. All earlier projections preserve `P_s mu`, proving that this bound survives actual sequential activations. These two calculations yield W24. At the final normal level the future space is zero, so its forcing term vanishes exactly.

This establishes genuine separation on the specified windows. To make the threshold explicit, let `M_B` bound the norms of all original edge rows. Require the deterministic error in W24 to be at most `m_L A/(8M_B)`, and the normal-plus-holonomy path fluctuation to be at most `m_L A/(8M_B)`. A formed edge then has absolute residual at most `m_L A/4`; a future bridge has absolute residual at least `3m_L A/4`. Their transported law-point KL values, equal to residual squared divided by two, lie on opposite sides of the resulting strict gap. Initial edge means are also separated by W20, so this is not an equilibrium preparation relabeled as formation.

The level-`s` subgraph is exactly the union of triangle edges and bridge levels at most `s`. The valuation rule W1 joins groups of `2^(s-1)` triangles at level `s>=2`. The component count in W27 follows. Earlier formed residuals remain small after their windows by (C7), the global fluctuation event, and the inherited conditional-statistic bound checked below. The proof does not locate every threshold crossing outside the controlled windows or claim a unique hierarchy under other microscopic data.

## 5. Reconstruction of the full path-maximum bound W26

Let `Z` be the centered process on normal and retained holonomy directions. Along every admitted branch it has covariance bounded by `C_LT I`, drift `-K_tZ`, and `K_t>=m_L^*I` for a positive graph-dependent `m_L^*`. Choose `c>0` with `c<2m_L^*` and sufficiently small for the initial Gaussian exponential moment. For

$$
 u=\frac{c|Z|^2}{4T},\qquad V=e^u,
 \tag{C8}
$$

direct differentiation gives

$$
 L_tV=\left[\frac{cd_t}{2}
 +\frac{c^2|Z|^2}{4T}-\frac{cZ^TK_tZ}{2T}\right]V
 \le\left[\frac{cd}{2}-(2m_L^*-c)u\right]e^u.
 \tag{C9}
$$

The right side has a finite supremum for `u>=0`. It depends on dimension and the lower drift bound, and not on the largest stiffness. The initial expectation satisfies

$$
 \mathbb E e^{c|Z_0|^2/(4T)}
 =\det\left(I-\frac c{2T}\Sigma_0\right)^{-1/2}\le C_L
 \tag{C10}
$$

when `c` is chosen below the reciprocal covariance bound. At an actual activation, `Z` is orthogonally projected, so `V` cannot increase. Stopping at the first threshold crossing and at finite localization levels, Ito's formula gives `E V_stop<=C_L+C_LH_*`. Positivity permits passage to the limit. On threshold crossing, `V>=exp(c rho^2 A^2/(4T))`. This proves W26, including for a sequential process with changing dimension.

This is a valid maximum-event argument. It uses the actual stochastic evolution and a stopped exponential Lyapunov function. A one-time covariance estimate alone would not prove it. It also applies after a restart from the actual Gaussian marginal because its covariance bound and mean projection have already been established.

## 6. Inherited original-edge statistics W26a–b

At stage `p>=1`, the cumulative optimizer conditional has hidden precision at least `c_LJ_p` and cross block at most `C_LJ_(p+1)`. Its second hidden moment at a retained normal point of size `C_LA` is consequently bounded by

$$
 C_L\left[A^2\left(\frac{J_{p+1}}{J_p}\right)^2+\frac T{J_p}\right].
 \tag{C11}
$$

The physical prior and physical observed posterior have a different hidden precision. Their evaluator subtraction is `-TR`, and the prior also lacks `kappa I`. Nevertheless the normalized-model bound `A_0>=aH/2+P_K` gives the same order of hidden lower bound. Every node bridge row belongs to the first eliminated layer, hence `R` annihilates `N_p` and introduces no hidden/future cross term. The root and holonomy directions have no such cross term either. This proves that (C11) holds for each specified physical conditional separately; the optimizer conditional has not been silently substituted for it.

The original edge residual differs from its retained-state value by a fixed row applied to the hidden variable. Cauchy–Schwarz turns (C11) into the normalized root-mean-square error in W26b. It tends to zero in the exhibited scales. Squaring after retaining the strict mean gap in Section 4 proves small expected original-edge KL for formed edges and a separated lower bound for future bridges under these inherited kernels.

This establishes an inherited statistic of the original edge experiment. It does not identify the KL between arbitrary complete parent presentation laws with a scalar Gaussian edge formula. The witness states that limitation, which is necessary for the conclusion to be correct.

## 7. Moving conditional mean, covariance, and actual-law restarts

The witness's covariance comparison W28 is the matrix barrier theorem in the conditional component. Its hypotheses hold for every ancestor by (C5), the actual scalar speed bound, and the inherited lower precision bound. Orthogonal marginalization preserves the covariance Loewner inequality, so no covariance reset is required.

The conditional mean calculation itself is independently checked as follows. With `R_F=F^{-1}G` and `e=mu_u+R_Fmu_y`, differentiating the mean equation yields

$$
 \dot e=-(F+R_FG^T)e+(\dot R_F-R_FS)\mu_y.
 \tag{C12}
$$

For `q=(e^TFe)^(1/2)`,

$$
 q\dot q=-e^TF^2e-|G^Te|^2
 +e^TF\dot R_F\mu_y-e^TGS\mu_y
 +\tfrac12e^T\dot Fe.
 \tag{C13}
$$

The signs and matrix order agree with W30–W31. The term `-|G^Te|^2` is additional damping, not an omitted forcing. From (C4)–(C6),

$$
 \|F^{1/2}\dot R_F\|\le C_L\epsilon J_{s+1}/\sqrt{J_s},
 \qquad
 \|F^{1/2}R_FS\|\le C_LJ_{s+1}^2/\sqrt{J_s}.
 \tag{C14}
$$

Combining (C13), `|mu_y|<=A`, and the relative `Fdot` bound proves W32, including its upper-Dini form at zero. Its integrated equilibrium forcing is of order `A(J_(s+1)^2+epsilon J_(s+1))/J_s^(3/2)`. Since the witness uses `J_(s+1)>=1` for `s<L`, the epsilon term can be absorbed. At the final normal step there is no future cross block, and both terms vanish.

The initial squared mean defect is bounded by the complete ancestor mean quadratic, at most `C_L A^2J_(p+1)<=C_L A^2J_1`. The conditional Gaussian KL is the sum of its mean quadratic divided by `2T` and its covariance contribution. The latter is bounded by the full covariance KL after subtracting the nonnegative retained covariance KL. This yields W33 directly. It is not inferred from the preceding path estimate.

At a new activation, all these statements apply to that process's actual current Gaussian law. The normalized parent precision and conditional are computed at its own current parameter. The model-parameter admission for that process is checked next; it is not imported from a prescribed fine parameter curve.

## 8. Independently learned parents and W37

At fixed parameter and retained law, completing the square gives

$$
 x^TK_ax=y^TS_ay+E^TF_aE,\qquad E=u+F_a^{-1}G_ay.
 \tag{C15}
$$

Under the optimizing lift, `E` is centered, independent of `y`, and has covariance `TF_a^{-1}`. Subtracting its expectation from that under the actual law proves W36. The full model score differs only in the expectation of `x^THx`, since the calibration and prior normalizer are shared at this fixed comparison state.

On the normal sector `H=(K_a-kappa I)/a`. The Euclidean-energy difference is obtained by expanding `x=(y,-F^{-1}Gy+E)`. Its mean cross term is bounded by `C_LA|e|`, its covariance difference by `C_LTr`, and its mean square term by `C_LT Delta_mean`, using the covariance barrier, the positive hidden lower bound, and `Delta_mean=e^TFe/(2T)`. This reconstructs W37, including its unbounded-score correction. It does not replace the score by the conditional KL itself.

The more conservative calibration feedback argument W37a–b is sufficient for long-horizon self-learning. Under an actual ancestor law, its mean energy obeys

$$
 E_s=m^TS_am,\qquad \dot E_s\le1.1\epsilon E_s,
 \tag{C16}
$$

and cannot increase at Schur projection. Under its own optimizing lift,

$$
 \mathbb E X^TK_aX
 =m^TS_am+\operatorname{tr}(S_a\Sigma_y)+Tp_{\rm hidden}
 \tag{C17}
$$

on learned normal directions. This gives the score and metric bounds used in conditional equations 42c–i. The derivative of the lift contributes zero: its conditional derivative integrates to zero against the retained-only variational derivative at matching. Thus each parent computes the complete inherited score from its own actual retained law and own parameter. The inherited microscopic model metric is also unchanged.

Equations (C16)–(C17) imply

$$
 \dot a=\epsilon(2-a)+\epsilon R_t,\qquad
 |R_t|\le\delta_L=O_L(A^2J_1+Tp).
 \tag{C18}
$$

The strict smallness in W37a closes the inward-boundary and speed bootstrap for every parent. Subtracting two equations (C18) with equal activation parameter proves W37b with the factor `2 delta_L`. This is an error estimate between two distinct endogenous parameter laws, not a prescription for either law.

The matrix derivative W19 also gives the bilinear bound in W37c. For two unforced parent means, differentiation of their squared difference and Young's inequality yields

$$
 \frac d{dt}|m_a-m_b|^2
 \le-(m_a-m_b)^TS_a(m_a-m_b)
 +C_L|a-b|^2m_b^TS_bm_b.
 \tag{C19}
$$

The integral of the last quadratic is at most `|m_b(tau)|^2/2`, because it is half the decrease of that mean's squared norm. This proves stiffness-independent mean sensitivity. The root forcing cancels because it is retained and parameter independent; the retained holonomy means are zero. Combining it with the deterministic force comparison at common parameter gives W37d.

For actual paths, apply the stopped maximum estimate from Section 5 separately to the source and self-learning parent. At `rho=epsilon^2`, each centered normal-plus-holonomy path is at most `A epsilon^2`, except with probability `C_L(1+2/epsilon)exp(-c_L/epsilon^2)`. Couple their initial retained states exactly and their root noise identically. The root paths then agree. The triangle inequality between the two actual centered paths and their controlled mean difference gives W37e. This proof does not require the two centered normal paths to be equal or have equal covariance.

Finite sequential comparison can be made precise by defining branch `j` to perform exactly the first `j` activations and then remain on its `j`th carrier. Branches `j` and `j+1` agree until activation `j+1`, where the latter starts from the former's actual retained state and parameter. Apply the single-replacement estimate through the common terminal horizon, project both into the final common carrier, and sum over the finite branch chain. Orthogonal projections have norm one. A union bound pays all exceptional events. This justifies the telescoping assertion following W37e without resetting a state, covariance, or parameter.

## 9. Explicit simultaneous scale checks

For `s<L`, the recursion `a_s=2a_(s+1)+16`, `a_L=0` gives

$$
 \frac{J_{s+1}}{J_s}=\epsilon^{a_{s+1}+16},\qquad
 \frac{J_{s+1}^2}{J_s}=\epsilon^{16},\qquad
 \frac{H_*J_{s+1}}{R\sqrt{J_s}}=2\epsilon^{10}.
 \tag{C20}
$$

At `s=L`, the witness defines `J_(L+1)=0`; the two expressions involving this zero are zero rather than the nonzero equalities in (C20). The final case has no plateau or cross force.

The normalized-model admission follows because

$$
 A^2J_1=\epsilon^4,\qquad
 T=\epsilon^{a_1+10},\qquad
 T/J_1=\epsilon^{2a_1+10},
 \tag{C21}
$$

and every dimension is fixed for fixed `L`. Thus initial mean energy, thermal trace, prior positivity, and the parent feedback condition all hold for sufficiently small epsilon. The slowest normal rate is bounded below by a graph-dependent constant because `J_L=1`, so covariance speed is also small relative to that rate.

The activation ordering follows from

$$
 \frac{\tau_{s-1}}{t_s}=2\epsilon^{a_{s-1}-a_s}\longrightarrow0,
 \qquad
 \frac{2t_L}{H_*}=k_L\epsilon\log(1/\epsilon)\longrightarrow0.
 \tag{C22}
$$

During `I_s`, the future displacement in W24 is `O_L(epsilon^(a_(s+1)+16) log(1/epsilon))`, hence tends to zero relative to `A`. The chosen `k_L` makes the transient conditional term bounded by a power strictly greater than `epsilon^4`, since

$$
 R^2J_1 e^{-c_LJ_s t_s/2}
 =\epsilon^{-6-a_1+c_Lk_L/2},
 \qquad c_Lk_L/2>a_1+10.
 \tag{C23}
$$

The conditional plateau is even smaller than the stated conservative bound:

$$
 R^2\frac{J_{s+1}^4}{J_s^3}
 =\epsilon^{2a_{s+1}+42}\le\epsilon^{42}\le\epsilon^{26}.
 \tag{C24}
$$

Consequently W43 is dominated by the `O_L(epsilon^2)` covariance lag. The omitted epsilon forcing in the general conditional interface contributes `epsilon^(4a_(s+1)+44)`, which is smaller than (C24). It is legitimate to absorb it here.

In the common-parameter path bound, the deterministic terms are at most `O_L(epsilon^16)+O_L(epsilon^15)`. With its separate probability parameter `delta=epsilon^2`, the thermal term is `O_L(epsilon^8)`. For independently learned parameters, `delta_L=O_L(epsilon^4)` and W37c gives a mean error `O_L(A epsilon^4)`. The actual-path tubes of radius `A epsilon^2` dominate both errors. Their exponent is

$$
 \rho^2R^2=\epsilon^4\epsilon^{-6}=\epsilon^{-2},
 \tag{C25}
$$

which checks the exceptional probability in W37e. Finally, the score bound after formation has terms `T epsilon=epsilon^(a_1+11)` and `A sqrt(T) epsilon=epsilon^(a_1+8)`, verifying the stated larger order.

For the changed conditional, the first hidden precision is `aF+kappa I`, with `lambda_min F>=c_LJ_1` and fixed `kappa<=c_L/2`. At `a>=3/2`, every eigenvalue of `(aF+kappa I)(F+kappa I)^{-1}` is at least `5/4`. The Gaussian covariance KL is therefore at least the positive dimension factor in W44; its mean term is nonnegative. This bound is independent of epsilon and temperature. The complete actual calibration update supplies `a(2/epsilon)>3/2`; the conditional target was not moved by an external schedule.

All required inequalities involve finitely many graph-dependent constants and powers with strict positive exponent margins. Their conjunction therefore defines a nonempty `0<epsilon<epsilon_0(L)` interval. No uniformity as `L` tends to infinity is proved or required.

## 10. Corrections observed and conclusion

During this reconstruction the displayed W7 microscopic precision initially lacked the plus sign between its node and edge sums. The parent corrected that formula. The individual alpha drift also initially omitted the proper-root force; the revised expression includes `-(P_Kx)_alpha` and distinguishes sampled drift from initial mean drift. At preparation the root mean is zero, while the fixed observation contributes `kappa z_alpha`; the correct nonzero-mean-drift discriminator is `A J_1 -> infinity`. In this family `a_1>=16`, so `A J_1=epsilon^(2-a_1/2)` does diverge. The revised statement is valid.

The W40 nonzero scale equalities require the index restriction `s<L`, with the final zero-cross-block case handled separately as in (C20). The parent added this restriction, and the revised text was read during the final check. This is a local range clarification, not a failed exponent or a new scientific assumption. The reconstruction records it explicitly so the final-layer convention is unambiguous.

No remaining formation, restoring-rank, actual-law restart, or independently learned path-comparison gap is identified in the checked Gaussian family after these local formula/range corrections. The strongest supported result is the finite-`L` theorem with its stated compatible observation, supplied contrasts, scalar learned precision, exact conditional kernels, and finite learning horizon. The next action that changes mathematical scope would be a controlled nonlinear remainder or a proved bound for incompatible normal observation forcing. A claim about either extension is outside this reconstruction.

No numerical experiment, symbolic package, test suite, GPU calculation, Lean work, tamper check, Git mutation, or Research-vault edit was used. The checking evidence is the displayed independent matrix, differential, Gaussian, and scale reconstruction. Only this assigned check document was written during this review task.
