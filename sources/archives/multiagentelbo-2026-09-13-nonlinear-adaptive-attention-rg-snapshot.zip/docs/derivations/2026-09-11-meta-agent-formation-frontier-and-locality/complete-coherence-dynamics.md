# Complete coherence dynamics, collective response, and departure

September 12, 2026. This is a conditional mathematical construction at one base point `c_*`. It supplies the complete-vector-field test missing from [the alignment-only attraction result](coherence-attraction-and-dynamical-rg.md), and instantiates that test in the normalized local mechanism developed in [the microscopic model](microscopic-vfe-dynamics-construction.md). The complete equations needed here are also given below. The construction does not certify arbitrary microscopic kinetics or complete recursive RG.

## 1. Target, assumptions, and source continuity

The target is to determine, for a specified smooth complete dynamics of belief laws, model laws, evaluators, and independently moving internal links, whether every trajectory initially in the zero transported two-channel KL set stays there, whether an open neighborhood approaches a coherent collective regime, and how bounded exterior forcing changes its collective motion or causes departure. Equivalence here means invariance or quantitative trajectory comparison for that very vector field. It does not mean equality of a deterministic trajectory with a stochastic sample path, or equality between a local kinetic flow and full-joint Fisher inference.

This supplies the coherence and response portions of the [six-obligation existential contract](evidence/2026-09-12-dynamical-rg-goal/problem-contract.json), `contract-sha256-e5dba6bac54379a2ad2d263508d099a3bbbff95ecfe99a3ad95130f9e8e8c9ad`. Its two successive reduction obligations are assigned to the parent construction and are not closed by this document.

The user supplies the fixed-base scope, law-valued agents, two channels on one principal bundle, independent dynamic links, and the requirement that all terms come from one normalized model. The finite-dimensional regular chart, positive definite kinetic metric, fixed graph during an interval, uniform normal contraction, and any compatibility of priors with the evaluator are additional hypotheses below. The explicit realization further chooses equal-dimensional isotropic Gaussian law fibers, `G=SO(d)`, a confining radial prior, fixed positive coupling strengths, and a declared local diffusion. These choices exhibit one admitted regime and do not redefine the general model.

The source [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), `thm:obs-local-global-potential`, equates a local conditional objective difference to the global difference only while the outside marginal is fixed. Its continuous local-gradient result also specifies the block metric. We therefore analyze a single assembled vector field, never a sum of overlapping local VFEs or independently replaced correlated conditionals. [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex) supplies the normalized full-state and retained-mark requirements. The existing [GL alignment calculation](gl-alignment-marked-parent.md), Sections 2–3, supplies regular mismatch geometry including link variations. The [Gaussian learned-link counterexample](pointwise-gaussian-link-learning.md), Section 7, and [conditional target-motion identity](pointwise-learning-parent-closure.md), Section 2, already prove that a decreasing VFE need not preserve alignment or conditional matching.

The live PIFB2 manuscript, `sec:timescales`, explicitly imposes microscopic mobilities; `sec:meta_agent_rg`, especially `eq:rg_internal_hessian`, `eq:rg_slow_graph_metric`, and `eq:rg_schur_flow`, distinguishes internal stiffness, inherited graph metric, and an independently required force residual. The [September wiki synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>) keeps probability, path, and geometry claims separate. Those are prior constructions. The new result here supplies a full-force tangency criterion, an admitted nonzero coherent basin with actual evaluator and priors, and quantitative forcing and finite-temperature qualifications.

## 2. Exact tangency is a full-force condition

Let `X` be a finite-dimensional smooth state manifold and let `f(t,W)` be continuous in `t`, `C^1` in `W`, and locally Lipschitz uniformly on compact time intervals. The state includes every recognition or structural coordinate on which the declared motion depends. Fix a regular mismatch chart

\[
W=\Psi(y,z),\qquad \mathcal M=\{z=0\},\qquad
\dot y=a(t,y,z),\quad \dot z=b(t,y,z). \tag{1}
\]

Here `z` is a set of independent local equations for zero transported belief and model KL; redundant edge equations can still be used to calculate it. Positive regular Fisher metrics make the sum of the edge KLs comparable to `|z|^2` locally. The statement excludes rank-changing strata and support boundaries. A finite time interval remains restricted to a chart unless compactness or a separate continuation argument is supplied.

**Tangency theorem.** For every initial time and every point of the regular coherent patch, its solution stays in `M` for as long as it stays in the patch if and only if

\[
b(t,y,0)=0. \tag{2}
\]

Necessity follows by differentiating the zero mismatch along such a solution. For sufficiency, solve `dot y=a(t,y,0)` and set `z=0`. Equation (2) makes this a solution of the complete equation (1); local uniqueness identifies it with the ambient solution. Tangency at one selected state alone is not sufficient.

For a Gaussian law edge with represented link `T_e`, the equations being tested include

\[
\begin{split}
v_e^\mu&=\dot\mu_i-\dot T_e\mu_j-T_e\dot\mu_j,\\
v_e^C&=\dot C_{ii}-\dot T_eC_{jj}T_e^\top
             -T_e\dot C_{jj}T_e^\top-T_eC_{jj}\dot T_e^\top.
\end{split} \tag{3}
\]

Both expressions must vanish in both channels at every coherent state under consideration. In a general smooth law family replace (3) by the differential of the law mismatch, including the differential of the link pushforward. A model evaluator contributes through the actual derivatives of its normalized factor. Any link or prior learning law contributes through its own velocity. If these are parameters learned against recognition, the conditional target-score term from the preceding closure derivation must also be retained.

For an exact scalar `F` with kinetic inverse metric `G^{-1}` and a supplied force `h`,

\[
f=-G^{-1}dF+h,\qquad
b|_{\mathcal M}=D z\big[-G^{-1}dF+h\big]\big|_{\mathcal M}. \tag{4}
\]

Writing `F=F_int+F_prior+F_eval+F_ext+F_norm+F_ent` is allowed only as an actual factorization of that exact objective. The defect in (4) is the sum of the resulting vector-field contributions with the same metric. Individual terms need not be tangent if their sum cancels. Conversely, positivity of the alignment Hessian cannot cancel a nonzero defect because the alignment gradient itself vanishes at zero KL. A normalizer depending on a learned structural parameter cannot be dropped; a global normalizer constant in a moving sample coordinate has zero derivative in that coordinate.

This also explains why `dD/dt=0` at `D=0` is not a tangency test: every smooth nonnegative mismatch has zero first differential there. If `R` is the mismatch differential and `H_D` its Fisher quadratic form, an initially coherent trajectory instead satisfies

\[
D(W(t))=\tfrac12t^2 H_D(f,f)+o(t^2). \tag{5}
\]

The positive second-order term detects immediate departure.

## 3. Normal stability, actual rates, and quantitative forcing

Under (2), the normal variational equation along a coherent trajectory `y(t)` is

\[
\dot\zeta=A(t)\zeta,\qquad
A(t)=\partial_z b(t,y(t),0). \tag{6}
\]

Tangency implies `partial_y b(t,y,0)=0`, so tangent variations do not enter this linear normal equation. The matrix includes all derivatives of the complete vector field, including mobility variation and evaluator forces. At a stationary coherent point of an unforced gradient flow, it is the induced normal part of `-G^{-1}H_F`; derivatives of `G^{-1}` disappear there because `dF=0`. Along a moving coherent trajectory they generally remain. A positive Hessian of only the alignment term or instantaneous eigenvalues of a time-varying `A` do not establish (6)'s uniform decay.

For a stationary coherent point, the exact necessary and sufficient linear exponential-stability test is that all eigenvalues of the normal matrix have strictly negative real parts. In the gradient case this is positive definiteness of the full normal Hessian in the inherited kinetic geometry. To check the equivalence, a Jordan decomposition shows that strictly negative real parts give exponential decay after bounding each finite polynomial prefactor; an eigenvector or generalized eigenspace with nonnegative real part prevents exponential decay. This linear test establishes local nonlinear attraction of an isolated normal equilibrium when its quadratic remainder is uniformly bounded, by the integral equation and a sufficiently small bootstrap. It does not assert global convergence.

For a moving coherent family the corresponding exact linear test is a uniform estimate on its evolution operator, `||Phi(t,s)||<=C exp[-alpha(t-s)]`. A useful sufficient check, with a non-Euclidean normal metric `P(t)>0`, is

\[
\dot P+A^\top P+PA\preceq-2\alpha P,
\qquad p_- I\preceq P\preceq p_+I. \tag{7}
\]

Differentiating `zeta^T P zeta` proves the estimate with `C=sqrt(p_+/p_-)`. Conversely, a uniformly exponentially stable bounded matrix equation admits

\[
P(t)=\int_t^\infty\Phi(s,t)^\top\Phi(s,t)ds,
\qquad \dot P+A^\top P+PA=-I. \tag{8}
\]

Exponential decay bounds the integral above. Bounded `A` makes `Phi(s,t)` uniformly close to the identity for a short interval, giving a positive lower bound. Differentiating the integral proves (8). Thus the evolution-operator criterion is not replaced by an instantaneous eigenvalue heuristic. Applying it to a nonlinear family still requires uniform chart, derivative, and orbit-control hypotheses; the direct estimate below states those needed for its nonlinear conclusion.

**Complete-force tube theorem.** On `|z|<=rho`, suppose the unforced complete vector field is tangent and obeys

\[
\langle z,b_0(t,y,z)\rangle\le-\lambda(t)|z|^2.
\tag{9}
\]

Suppose the changes caused by external evidence, exterior interactions, incompatible learning, or driven links obey

\[
|b-b_0|\le\eta(t)+\ell(t)|z|,\qquad
\alpha(t)=\lambda(t)-\ell(t)>0. \tag{10}
\]

The functions are locally integrable, the field remains locally Lipschitz, and all bounds hold on the actual trajectory tube, not only at its center. Then, up to exit from that tube,

\[
\begin{split}
r(t)&\le E(t,0)r(0)+\int_0^t E(t,s)\eta(s)ds=:R(t),\\
r&=|z|,\qquad
E(t,s)=\exp\left[-\int_s^t\alpha(v)dv\right].
\end{split} \tag{11}
\]

Indeed `(1/2)d|z|^2/dt<=-alpha|z|^2+eta|z|`. Dividing where `z!=0` and taking an upper right derivative at zero yields `D^+r<=-alpha r+eta`; the integrating factor gives (11). The same proof applies in a varying normal metric after including its derivative as in (7). A positive uniform margin `alpha>=alpha_*` and `eta<=eta_*` give

\[
r(t)\le e^{-\alpha_*t}r(0)
 +\frac{\eta_*}{\alpha_*}(1-e^{-\alpha_*t}). \tag{12}
\]

If `R(t)<rho` and the retained coordinate stays inside its admitted patch, a first-exit argument validates the estimate throughout the interval. On a tube around a compact boundaryless coherent manifold there is no lateral chart exit. Small forcing controls a finite mismatch, not exact invariance; unforced exponential coalescence is the special case `eta=0`.

The rates in (6)–(12) are rates of the supplied microscopic kinetics. The existing [Fisher dynamics proof](../2026-09-11-fast-slow-derived-hierarchy/dynamics-construction.md), Section 4, gives a useful contrast: at a represented posterior, `H_KL=G_Fisher`, and the full-joint Fisher linearization is `-I`. The proof differentiates normalization twice, eliminating the residual score term. Local block inverses give a different matrix and can retain interaction-dependent rates. This is why neither a scalar stiffness nor a newly assigned parent learning rate determines the present normal gap.

## 4. Inherited collective response and actual loss of coherence

Let `i(y)=Psi(y,0)`, `J=Di`, and assume the exact unforced field is tangent. If it is the gradient field of `F`, multiply `J dot y=-G^{-1}dF` by `J^T G` to obtain exactly

\[
G_{\mathcal M}=J^\top GJ,\qquad
\dot y=-G_{\mathcal M}^{-1}d(F\circ i). \tag{13}
\]

With a tangent non-gradient force add `G_M^{-1}J^T Gh`. With a general force, this formula is the tangent projection at `M`; the normal component belongs in (10). A normal tubular retraction can be chosen so that its differential is this metric projection. Erasing a coordinate of `M` further requires that the projected vector field be constant on its fibers; the scalar alone does not ensure that condition. A graph-slaved manifold `xi=xi_*(y)` has the full graph pullback metric, including derivatives of `xi_*`, as in PIFB2. It is not automatically the metric Schur complement.

For an explicit finite-interval comparison, let `Y(t)` solve the proposed retained equation `dot Y=a_*(t,Y)`. Assume, on the admitted patch,

\[
|a(t,y,z)-a_*(t,y)|\le K(t)|z|+\varepsilon(t),
\qquad |a_*(t,y)-a_*(t,Y)|\le L(t)|y-Y|. \tag{14}
\]

Then the integral equation, (11), and an integrating factor give

\[
|y(t)-Y(t)|\le e^{\int_0^tL}
\left[|y(0)-Y(0)|+
\int_0^t e^{-\int_0^sL}\{K(s)R(s)+\varepsilon(s)\}ds\right]. \tag{15}
\]

Here `epsilon` is an actual force-level closure residual or omitted tangent forcing. No bound on a scalar energy difference alone provides it. If the approximate and exact scalars use the same positive metric, the required bound is the dual-metric norm of the differential of their difference. A metric approximation adds its own inverse-metric error multiplied by the force.

Entrance into a basin and later membership have different quantifiers. A local basin theorem gives an open set of admitted initial states. To assert entrance from a prescribed larger set, one must either prove a trapping sublevel with no alternative limiting set and establish its inward flux, or integrate those initial trajectories with a proved enclosure until they enter the local basin. A plot of small KL or VFE descent alone gives neither statement. The explicit model below supplies an open basin without adding a parent to its microscopic equation.

The inequality `eta_*/alpha_*<rho` is a sufficient persistence condition. Its failure is not a breakup theorem. For an actual radial tube boundary `|z|=rho`, local forward invariance requires and, under the displayed smoothness and absence of lateral exit, is ensured by

\[
\langle z,b(t,y,z)\rangle\le0\quad\text{on }|z|=\rho. \tag{16}
\]

To prove sufficiency, bound the outward normal field at a nearby exterior point by its Lipschitz difference from the nearest boundary point; the positive part of the radial excess satisfies a Gronwall inequality with zero initial excess. A strictly positive left side at a boundary point gives immediate departure from that point by differentiation. A stronger finite-exit certificate is a fixed normal covector `e`, `|e|=1`, for which

\[
e^\top b(t,y,z)\ge v_*>0
\quad\text{throughout the relevant tube and interval}. \tag{17}
\]

Integration forces exit by time `(rho-e^T z(0))/v_*`, unless the trajectory exits earlier through another boundary. This is a true departure conclusion, unlike loss of the contraction bound. For the exact scalar normal model `dot z=-alpha z+f`, constant `f>alpha rho`, the exit time from `z(0)<rho` is

\[
t_{\rm exit}=\alpha^{-1}
\log\frac{f/\alpha-z(0)}{f/\alpha-\rho}. \tag{18}
\]

Turning the force off afterward makes the same mode re-enter. This illustrates temporary membership under a specified equation, not permanent nesting of blocks.

## 5. A normalized complete realization with nonzero coherent states

Take a finite connected graph with `N>=2`, one orientation of each of its `E` internal edge copies, and `d>=2`. Use the common-frame specialization of the two representations of `SO(d)`, with

\[
q_i^b=\mathcal N(u_i,I_d),\quad q_i^m=\mathcal N(v_i,aI_d),\quad 0<a<1,
\quad \Theta_e^b,\Theta_e^m\in SO(d). \tag{19}
\]

Each edge in each channel is an independent variable; reverse orientation is its inverse. Means parameterize law points. A density `Q` over the complete state `W=(u,v,Theta^b,Theta^m)` is a different probability object. Fix `mu_b,mu_m,eta_e^x,kappa_e^x,lambda_i,r_0>0`. At a selected temperature `T>0`, the evaluator below derives `lambda_i=lambda_{0,i}+T/(1-a)` from a fixed primitive `lambda_{0,i}>0`. The deterministic proof holds for every positive `lambda_i`, including the zero-temperature values `lambda_{0,i}`. Let

\[
\phi(s)=\tfrac12(s-r_0^2)^2,
\quad V_{\rm rad}=\sum_i\left[
\frac{\phi(|u_i|^2)}{2\mu_b}+
\frac{\phi(|v_i|^2)}{2\mu_m}\right], \tag{20}
\]

\[
U=V_{\rm rad}+\frac12\sum_i\lambda_i|u_i-v_i|^2
 +\frac12\sum_{e:j\to i}\left[
\kappa_e^b|u_i-\Theta_e^bu_j|^2+
\kappa_e^m|v_i-\Theta_e^mv_j|^2\right]. \tag{21}
\]

The belief edge term is `kappa_e^b` times its KL; the model edge term is `a kappa_e^m` times its KL. The evaluator term and radial terms arise from actual normalized local model factors, as follows. First use the primitive bridge `lambda_{0,i}` in a local joint on `(u_i,v_i)`. For temperature `T>0`, define

\[
\begin{split}
A_i(v)&=\int_{\mathbb R^d}
\exp\left[-\frac{\lambda_{0,i}|u-v|^2/2+\phi(|u|^2)/(2\mu_b)}{T}\right]du,\\
K_i(du\mid v)&=A_i(v)^{-1}
\exp\left[-\frac{\lambda_{0,i}|u-v|^2/2+\phi(|u|^2)/(2\mu_b)}{T}\right]du,\\
r_i(dv)&=z_i^{-1}A_i(v)
\exp\left[-\frac{\phi(|v|^2)}{2\mu_m T}\right]dv.
\end{split} \tag{22}
\]

Here `z_i` is the integral of the last numerator. The quartic tails make `A_i` and `z_i` finite and strictly positive. For example `A_i(v)` is bounded above uniformly by the integral of `exp[-phi(|u|^2)/(2mu_b T)]`. The product `r_i(dv)K_i(du|v)` cancels `A_i` exactly and gives the normalized local self/bridge density. This `K_i` is a bridge on law-parameter space; the physical model evaluator is the distinct kernel introduced next.

Take the product of these local joints and normalized Haar laws of all links, then tilt by the two nonnegative edge energies in (21). The relative partition lies in `(0,1]`. This constructs `p_{0,T}=Z_{0,T}^{-1}exp[-U_0/T]nu`, where `U_0` uses `lambda_{0,i}`. Complete this generative model at each node by

\[
\zeta_i\mid v_i\sim\mathcal N(v_i,aI),\qquad
k_i\mid\zeta_i\sim\mathcal N(\zeta_i,(1-a)I). \tag{22a}
\]

The second kernel is the normalized model evaluator in the common frame. A fixed orthogonal cross-frame matrix can be restored as in the companion construction. To realize the prescribed belief and model marginals, take the conditional recognition coupling

\[
\zeta_i=v_i+\xi_i,\qquad k_i=u_i+\xi_i+\epsilon_i,
\qquad \xi_i\sim\mathcal N(0,aI),\quad
\epsilon_i\sim\mathcal N(0,(1-a)I), \tag{22b}
\]

with independent noises. This coupling `R_{u_i,v_i}` has exactly the two law marginals (19). Compared with the generative conditional `P_i` in (22a), its log ratio is

\[
\log\frac{dR_{u,v}}{dP_i}
=\frac{(u-v)^\top(k-\zeta)-|u-v|^2/2}{1-a}.
\tag{22c}
\]

Every coupling `S` with those two marginals has `E_S(k-zeta)=u-v`. The KL chain obtained by adding (22c) therefore gives

\[
\operatorname{KL}(S\Vert P_i)
=\operatorname{KL}(S\Vert R_{u,v})+
\frac{|u-v|^2}{2(1-a)}. \tag{22d}
\]

The identity is first read on the finite-KL domain; the density-ratio expectation is finite under these Gaussian marginals, so its extended extension follows without subtracting infinities. Thus `R` is the unique minimizing coupling. For the admitted conditional recognition family `Q(dW) product_i R_{u_i,v_i}`, the exact temperature-scaled negative ELBO of the normalized augmented model is

\[
\begin{split}
\mathcal F_T^{\rm aug}(Q)
&=\mathbb E_Q U+T\int q\log q d\nu+T\log Z_{0,T}\\
&=T\operatorname{KL}(Q\Vert p_T)
 +T\log(Z_{0,T}/Z_T),
\end{split} \tag{22e}
\]

The energy-plus-entropy line in (22e) is asserted on the finite-energy, finite-entropy domain. On general probability laws its KL line is the extended-real definition, obtained directly from the augmented relative-entropy chain rule; one must not form an indeterminate difference of infinite energy and infinite negative differential entropy. Here (21) uses the derived `lambda_i=lambda_{0,i}+T/(1-a)` and

\[
p_T(dW)=Z_T^{-1}e^{-U(W)/T}d\nu(W),\qquad
0<Z_T<\infty, \tag{23}
\]

where `nu` is node Lebesgue times link Haar measure. The effective law `p_T` is the minimizer within the admitted recognition family; the generative marginal is `p_{0,T}`. They are not conflated. The baseline edge dependence is assembled before recognition. It contains no external observations and no conditioning on desired agreement records. An unobserved normalized record would integrate to one and cannot produce these couplings; the primitive edge tilt does. Its mechanism is an added admitted choice, not a derivation of intrinsic coupling from missing records. Conditional optimization (22d) is an explicit variational-family restriction, not a claim that this conditional remains optimal under every augmented microscopic kinetics.

Use the kinetic metric

\[
g=\sum_i(\mu_b^{-1}|du_i|^2+\mu_m^{-1}|dv_i|^2)
 +\sum_{e,x}(\eta_e^x)^{-1}
\langle (\Theta_e^x)^{-1}d\Theta_e^x,
 (\Theta_e^x)^{-1}d\Theta_e^x\rangle_{\mathfrak {so}},
\quad \langle A,B\rangle_{\mathfrak {so}}=-\tfrac12\operatorname{tr}(AB).
\tag{24}
\]

Its volume differs from `nu` by a constant. The deterministic equation studied next is exactly `dot W=-grad_g U`. Its node equations contain every incoming and outgoing residual. For channel `b`,

\[
\dot u_i=-(|u_i|^2-r_0^2)u_i-\mu_b\lambda_i(u_i-v_i)
-\mu_b\sum_{e:j\to i}\kappa_e^b(u_i-\Theta_e^bu_j)
-\mu_b\sum_{e:i\to k}\kappa_e^b(u_i-(\Theta_e^b)^\top u_k).
\tag{25}
\]

Replace `(u,b,mu_b)` by `(v,m,mu_m)` for the model equation, with evaluator term `-mu_m lambda_i(v_i-u_i)`. In spatial (right-trivialized) link coordinates `dot Theta=Omega Theta`, one edge has

\[
\dot\Theta_e^x=\eta_e^x\kappa_e^x
\left[w_i(\Theta_e^xw_j)^\top-(\Theta_e^xw_j)w_i^\top\right]\Theta_e^x,
\quad w=u\text{ or }v. \tag{26}
\]

To verify the sign and factor, vary `Theta` as `A Theta`. The edge differential is `-kappa w_i^T A Theta w_j`; pairing the negative gradient with `A` under `-tr(AB)/2` gives (26). Skew symmetry preserves `Theta^T Theta=I` and its connected component. Direct differentiation gives `dot U=-|grad_g U|_g^2`. Quartic coercivity and compact links make every sublevel compact, so this smooth deterministic flow is global: bounded state and derivatives on a sublevel prevent finite-time escape.

The coefficients of the two radial terms were deliberately chosen to compensate the different mobilities. This is explicit prior/kinetic compatibility. Replacing them by unrelated priors can invalidate the following invariant set.

Under a fixed passive common-frame change `u_i -> h_i u_i`, `v_i -> h_i v_i`, and `Theta_e^x -> h_i Theta_e^x h_j^{-1}`, both (21) and (24) are invariant. Therefore their gradient field and diffusion generator transform covariantly. Separate channel frames require carrying the evaluator cross-frame matrix as `C_i -> h_i^b C_i(h_i^m)^{-1}`; setting it back to identity after an independent reframe would change the model. The present calculation uses the common-frame specialization throughout. No base transport occurs. These are continuous equations; no numerical discretization or implementation of this model was run, and no finite-step descent guarantee is inferred from continuous descent.

## 6. Coherence in that model: what is invariant and what is not

Let `M` denote only zero belief and model edge KL. It is **not** generally invariant under (25). As an exact example, take two nodes, `Theta^b=I`, and a model link `Theta^m` rotating `e_1` to `e_2` by a quarter turn in their plane. Put `u_1=u_2=e_1`, `v_2=e_1`, `v_1=e_2`, and take equal evaluator strengths `lambda>0`. Both channels are edge aligned. Their edge and link forces vanish. The two belief radial forces agree, but the belief velocity difference from the evaluator is

\[
\dot u_1-\dot u_2=\mu_b\lambda(e_2-e_1)\ne0. \tag{27}
\]

Thus the admitted model refutes invariance of the original zero-two-channel-KL set without evaluator compatibility, even without observations. This is not the earlier learned-Gaussian-link counterexample.

Now introduce the stronger, explicitly restricted coherent sector

\[
\mathcal S_{r_0}=\{u_i=v_i=w_i,\ |w_i|=r_0,
\ \Theta_e^bw_j=w_i=\Theta_e^mw_j\text{ for every edge}\}. \tag{28}
\]

Every term in (21) vanishes there, and every point is a nonzero equilibrium. More generally the same relations with a common radius `r>0` are invariant and obey

\[
\dot w_i=-(r^2-r_0^2)w_i,\qquad
\dot r=-(r^2-r_0^2)r,\qquad \dot\Theta_e^x=0. \tag{29}
\]

These relations follow directly from (25)–(26); model compatibility has not been inferred from model KL alone. The radial rate near `r_0` is `2r_0^2`, inherited from the equations. It is independent of the number of children and hence supplies no size-dependent slowdown.

**Complete-model basin theorem.** For every graph and every choice of positive coefficients above, `S_r0` is a compact smooth minimum manifold of (21). It has an open neighborhood whose deterministic trajectories converge to it exponentially in normal distance. Each trajectory in a sufficiently small such neighborhood converges to a particular point of `S_r0`. All means at that limit have nonzero norm `r_0`. The conclusion permits independent dynamic links and surviving stabilizer holonomy.

Here is a proof including the normal-rank obligation. Choose arbitrary `w_i` on the radius-`r_0` sphere. For each oriented edge and channel, rotations carrying `w_j` to `w_i` form a smooth `SO(d-1)` fiber; local smooth choices follow from an orthonormal completion in a sphere chart. Thus (28) is a compact smooth manifold of dimension

\[
N(d-1)+2E\frac{(d-1)(d-2)}2. \tag{30}
\]

At a point of (28), write `delta Theta_e^x=A_e^x Theta_e^x` with skew `A_e^x`. The exact Hessian quadratic form is

\[
\begin{split}
H_U[\delta W,\delta W]
={}&\sum_{e:j\to i}\kappa_e^b
 |\delta u_i-\Theta_e^b\delta u_j-A_e^bw_i|^2\\
&+\sum_{e:j\to i}\kappa_e^m
 |\delta v_i-\Theta_e^m\delta v_j-A_e^mw_i|^2
 +\sum_i\lambda_i|\delta u_i-\delta v_i|^2\\
&+2\sum_i\left[\mu_b^{-1}(w_i^\top\delta u_i)^2
 +\mu_m^{-1}(w_i^\top\delta v_i)^2\right].
\end{split} \tag{31}
\]

Every coefficient is positive. Its kernel requires equal channel variations, each perpendicular to `w_i`, and the linearized edge equations. These are exactly the derivatives of (28). To check that there are no missing integrability conditions, the map `A -> A w_i` from skew matrices surjects onto `w_i^perp` and has kernel `so(d-1)`. Each independent edge equation can therefore be solved for its own `A`, leaving precisely the stabilizer fiber dimensions in (30). This is also the tangent space of the displayed local parameterization. Hence the kernel of (31) is exactly `T S_r0` and the normal form is positive definite.

Compactness and continuity give a positive minimum `a_0` of this Hessian on the `g`-unit normal bundle. Taylor expansion in a sufficiently small normal tube then gives, for positive constants `c_0,c_1,c_2,c_3`,

\[
c_0 d_g(W,S_{r_0})^2\le U(W)\le c_1 d_g(W,S_{r_0})^2,
\qquad c_2 U\le|\operatorname{grad}_gU|_g^2\le c_3 U. \tag{32}
\]

The lower gradient estimate follows because its normal derivative is invertible; the tangent gradient has no linear term. Consequently `U(t)<=U(0)e^{-c_2t}` and the remaining path length is at most `2 sqrt(c_3 U(0)) e^{-c_2t/2}/c_2`. Choose an inner tube and `U(0)` so this length is smaller than its margin to the outer tube. First exit is impossible, the tail length is finite, and the limit belongs to `S_r0`. This proves the asserted open basin for the complete deterministic dynamics, with actual self priors and evaluator still present.

The constants depend on the supplied couplings, mobilities, radius, and graph. Their positivity is proved; no universal separation from retained motion is asserted. In particular, tangential orientation and stabilizer directions are neutral before forcing. For `d>=3`, nonidentity `SO(d-1)` marks survive on graph loops. For `d>=4`, the stabilizer group itself has noncommuting elements. No loop is required to be flat.

Link motion in the basin is nontrivial. Start from the flat coherent state `u_i=v_i=r_0e_1`, and rotate just one belief link by an angle `theta` in the `e_1,e_2` plane, leaving all other links independent and initially unchanged. Equation (26) gives its initial angular velocity exactly as `dot theta=-eta_e^b kappa_e^b r_0^2 sin(theta)`. For every sufficiently small nonzero `theta`, this state is inside the proved basin and the link genuinely evolves; node laws evolve too. Nonvanishing of this velocity persists on an open neighborhood of that initial state. The existence theorem therefore does not achieve coherence by freezing or frame-factorizing its links.

The origin `u=v=0` is another stationary configuration (at positive energy). It is not in (28), so global attraction from every initial state is false. The basin theorem is a real open-set entrance result and does not rely on initializing exactly on a coherent set.

## 7. A nonzero collective response and its force separation

The preceding equilibria support collective response, rather than merely collapsing to zero. Consider the flat common-orientation subset `w_i=r_0 n`, `|n|=1`, with identity links. It is a convenient chart within (28), not a constraint on the nearby independent link dynamics. A collective tangent variation `delta w_i=r_0 delta n` with links held fixed has inherited metric

\[
g_{\rm coll}(\delta n,\delta n)
=N(\mu_b^{-1}+\mu_m^{-1})r_0^2|\delta n|^2. \tag{33}
\]

Suppose each node receives smooth tangent drift `omega(t) A(t)w_i` in both channels, where `A(t)` is skew, while link forcing is the commutator `omega[A,Theta_e^x]`. This is a declared driven interaction; it is not inferred from VFE. The complete forced solution starting coherently remains coherent, with

\[
\dot w_i=\omega A w_i,\qquad
\dot\Theta_e^x=\omega[A,\Theta_e^x],\qquad |w_i|=r_0. \tag{34}
\]

Indeed differentiation of `w_i-Theta w_j` gives `omega A(w_i-Theta w_j)`. The solution changes the law means in fixed external coordinates; to interpret it as an observable response, an external reference or measurement must be held fixed rather than co-rotated. Co-rotating every description and external reference would instead be passive reframing. The speed is nonzero whenever `A w_i!=0`; the internal unforced restoring gap remains the one derived from (31). On any fixed finite interval, sufficiently small smooth perturbations of this tangent forcing satisfy (10) and (14), hence (11) and (15). The gap versus collective forcing timescale is therefore a checkable inequality, not a parent rate assigned by scale.

A gradient-driven response relative to a fixed external vector is also exact. Take

\[
E(t,W)=-h(t)^\top\sum_i(\mu_b^{-1}u_i+\mu_m^{-1}v_i).
\tag{34a}
\]

On the flat synchronous sector `u_i=v_i=w` with identity links, the complete forced gradient equations reduce exactly to

\[
\dot w=-(|w|^2-r_0^2)w+h(t),\qquad \dot\Theta_e^x=0.
\tag{34b}
\]

The inherited metric is `N(mu_b^{-1}+mu_m^{-1})I` on `w`; the same factor multiplies the restricted self energy and external covector, giving (34b) with no reset of mobility. For constant `h=h_0n_*`, `h_0>0`, the equilibrium `w=r_*n_*` has the unique radius `r_*>r_0` satisfying `(r_*^2-r_0^2)r_*=h_0`. The radial derivative of the left side is positive on `r>=r_0`, proving uniqueness there. Linearizing (34b) gives the actual collective rates

\[
\lambda_{\rm radial}=3r_*^2-r_0^2,
\qquad \lambda_{\rm angular}=r_*^2-r_0^2=h_0/r_*.
\tag{34c}
\]

The angular rate tends to zero with `h_0`, while the normal gap (31) remains positive in a sufficiently small neighborhood of the unforced manifold. This realizes a nonzero finite response with a derived separated collective angular rate under a weak fixed external reference. It is a rate of this retained mode, not a universal clock for every tangent or model coordinate. Small nonsynchronous initial deviations, forces, or link perturbations are governed by (11) and (15) on the corresponding admitted finite interval. The physical external reference is unchanged by a passive coordinate comparison, but its components transform with the node frame: under a passive rotation `H_i`, its local components become `H_i h`. The response in (34b) changes the law relative to that reference, rather than merely changing their coordinate descriptions together.

For a general weak external potential `E(t,W)`, (13) with `U+E` gives the tangent projection at the coherent manifold. It is an exact retained trajectory equation only when the complete forced field is tangent. Otherwise (14)–(15) bound the trajectory error, and (10) bounds the incompatible normal component. At a nonzero coherent initial state with all links identity, a linear field acting only on `u_1`, `E=-f^T u_1`, immediately produces belief-edge KL

\[
D_{1j}^b(t)=\tfrac12\mu_b^2|f|^2t^2+o(t^2), \tag{35}
\]

because every unforced velocity and every initial link velocity is zero. Quartic confinement makes this forced instantaneous model proper. Equation (35) proves loss of exact coherence, whereas persistence within a finite tube remains governed by (11). For a time-dependent scalar, `d(U+E)/dt=-|grad_g(U+E)|_g^2+partial_t E`; external work removes the unforced descent assertion.

## 8. Finite temperature is a separate stochastic statement

For `T>0`, declare the local reversible diffusion with generator

\[
\mathcal L_T f=-\langle\operatorname{grad}_g U,
\operatorname{grad}_g f\rangle_g+T\Delta_g f. \tag{36}
\]

Node Brownian motions and link Brownian motions are independent in an orthonormal frame for (24). The group term is the intrinsic Laplace operator on each `SO(d)` factor, with no boundary; the Euclidean node domain has no finite boundary. Smooth quartic drift, compact links, and a quadratic Lyapunov bound on the Euclidean norm prevent explosion. For example `L_T sum_i(|u_i|^2+|v_i|^2)` has negative quartic leading terms and all remaining polynomial cross terms are bounded above by a constant plus a smaller quartic contribution. Stopping on growing compact balls and taking expectations gives a uniform bound, then the probability of finite-time escape tends to zero.

Integration by parts against (23) gives

\[
\int f\mathcal L_T h dp_T
=-T\int\langle\operatorname{grad}_g f,
\operatorname{grad}_g h\rangle_gdp_T. \tag{37}
\]

This identifies an invariant reversible law. For smooth positive density `Q_t=q_t nu` satisfying the associated Fokker–Planck equation and integrable boundary terms, its exact normalized objective satisfies

\[
\mathcal F_T^{\rm aug}(Q)=T\operatorname{KL}(Q\Vert p_T)
+T\log(Z_{0,T}/Z_T),\qquad
\frac{d\mathcal F_T^{\rm aug}}{dt}=-\int q_t
|\operatorname{grad}_g(U+T\log q_t)|_g^2d\nu. \tag{38}
\]

This follows by differentiating `int q(U+T log q+T log Z_{0,T})` and substituting `partial_t q=div_g(q grad_g(U+T log q))`. It is a transport/Dirichlet density kinetics. Full-joint Fisher kinetics would instead use the centered log-density-ratio reaction field; the two generators and their spectra differ. The deterministic equation (25)–(26) is the drift equation at the selected `T`, not an exact finite-temperature recognition Fisher trajectory. In the actual zero-temperature limit the derived bridge tends to `lambda_{0,i}`; the deterministic basin proof applies to that limiting positive coefficient too. No mixing-time claim follows from (37)–(38).

At any point of (28), a nontrivial edge mismatch has

\[
\mathcal L_T D=T\operatorname{tr}_g H_D>0. \tag{39}
\]

The drift part vanishes there. Thus `E D(W_t)=T tr_g(H_D)t+o(t)` for a diffusion started at that point, and exact coherent support is not invariant. Independent normal noise cannot be replaced by its mean. In the linear normal approximation in `g`-orthonormal coordinates, `dz=-H z dt+sqrt(2T)dB`, `H>0`, has exact stationary covariance `T H^{-1}`: substituting in `dot C=-HC-CH+2TI` proves it. This is a fluctuation floor for that linear model, not a claimed exact covariance of the nonlinear diffusion.

A finite-time stochastic tube statement needs no ergodic assumption. Let `V=|z|^2` on a compact regular tube, let `tau` be its first exit, and suppose the complete forced generator obeys

\[
\mathcal L_T V\le-aV+B,\qquad a>0,\quad B\ge0. \tag{40}
\]

For example (9)–(10) with constant margin `alpha_*` and force `eta_*`, together with `Delta_g V<=C`, give `a=alpha_*`, `B=eta_*^2/alpha_*+TC` by `2eta_*sqrt(V)<=alpha_* V+eta_*^2/alpha_*`. Killing the process at exit gives

\[
\mathbb E[V(W_t)1_{\{t<\tau\}}]
\le e^{-at}V(W_0)+\frac Ba(1-e^{-at}). \tag{41}
\]

To prove it, apply the integrating factor to the stopped Itô equation, then remove the nonnegative boundary contribution `E[e^{a tau}V(W_tau)1_{tau<=t}]`. Dropping the negative term in (40) before stopping also gives, when exit is through `V=rho^2`,

\[
\Pr(\tau\le t)\le\frac{V(W_0)+Bt}{\rho^2}. \tag{42}
\]

Compactness of (28) permits a full normal tube without lateral patch boundaries; otherwise such exits must be counted separately. These are bounded-time estimates, potentially weak for long intervals. Equation (41) is a killed moment, not the moment of the stopped process and not unconditional persistence. No claim that a positive-temperature group survives forever is made.

## 9. Supported result and remaining obligation

The complete normalized realization (19)–(26) admits a proved nonzero coherent minimum manifold and an open deterministic basin, with evaluator compatibility, radial prior forces, and independent link motion explicitly checked. The broader zero-two-channel-KL set fails tangency in the same model. Equations (11), (15), (16)–(18), and (40)–(42) give separate persistence, response, departure, and finite-temperature statements. The exact stochastic entropy objective and the zero-noise field dynamics are distinguished. All results are analytic; no new trajectory experiment, existing five-agent witness, suite, GPU job, or stochastic simulation ran in this lane.

This closes a conditional complete-dynamics formation bridge, not the general recursive target. The construction supplies its graph, couplings, self priors, and kinetic law. A later parent reduction must retain enough of the manifold and link/conditional state for the vector field to descend, and must derive rather than reset its mobility. The next action that changes the remaining answer is to construct the normalized coarse law and the pushed generator for this very admitted regime, or identify the smallest additional conditional state needed for closure. A finite second reduction must then show its inherited normal gap and response error. No perpetual nesting, arbitrary initial-state formation, universal complete-parent slowdown, or physical-time interpretation is established.
