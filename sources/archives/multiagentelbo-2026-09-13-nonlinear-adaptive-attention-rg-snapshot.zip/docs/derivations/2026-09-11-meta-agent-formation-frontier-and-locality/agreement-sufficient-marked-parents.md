# Agreement-sufficient marked parents: conditional closure, recursion, and cost

September 11, 2026. Continuation of [agreement-partition-selection-and-lineage.md](agreement-partition-selection-and-lineage.md), at fixed c_* and source HEAD ed8f22a56df353b1535744509cc23fae46d5813c. This is a derived, conditional result with explicit counterexamples and a small executed calculation. It is not a formal verification certificate or a completion claim for the full formation program.

The question is whether the agreement-derived partition admits complete parents that predict the original records, retain their required geometric marks, compose, and save resources. The answer separates three statements. A joint edge-probability coordinate closes agreement inference exactly for arbitrary correlated induced priors. A declared finite-mixture prior gives evaluable examples and two proper first-level parents with a smaller geometric sample representation. That representation does not in general close the actual trajectories of individually evolving links, even when it closes their full one-time Fisher laws. A two-link counterexample identifies the discarded angular information responsible for this last failure.

The original fifteen heterogeneous admissions and their negative conclusion are unchanged. The construction below belongs to the separate, normalized law/link agreement model already developed in the preceding papers. It neither changes that finite experiment nor obtains an externally justified approximation tolerance for it. Principal/associated fibers supply the types; no base-manifold transport is introduced.

## 1. Exact agreement sufficiency under a correlated prior

Let W be the complete standard-Borel law/model/link state at c_*, with proper fixed prior P_0. Its law-valued coordinates are random points of the corresponding associated fibers. A recognition Q is a joint probability on W, not one of those points. Let the finite catalog E contain every separately labeled agreement channel used by the experiment. It can contain belief and model channels separately, and oriented parallel edge copies. Define

\[
 p_e(W)=e^{-d_e(W)},\qquad 0\le p_e\le1,\qquad
 L_{s,f}(W)=\prod_{e\in E}p_e(W)^{s_e}[1-p_e(W)]^{f_e}.
 \tag{1}
\]

Each d_e is the actual nonnegative divergence energy of that labeled normalized binary record. A summed energy for several channels only suffices for a protocol that observes their combined success event; it cannot replace separate channel labels. The counts s,f summarize the likelihood of one ordered labeled record string. Its labels and order remain in the observation archive. No binomial multiplicity is inserted into an ordered-string likelihood. Common policies choosing the next label from observed history cancel in comparisons and can be included as normalized factors. Policies reading discarded W are outside this assertion.

Write p=(p_e) and let nu=p_#P_0 be its actual induced probability, with all correlations and compatibility constraints intact. Disintegration gives a fixed conditional law Psi(dw|p) such that

\[
 P_0(dw)=\nu(dp)\Psi(dw\mid p),\qquad
 \Pi_{s,f}(dw)=\nu_{s,f}(dp)\Psi(dw\mid p),\qquad
 \nu_{s,f}(dp)=\frac{L_{s,f}(p)\nu(dp)}{Z_{s,f}}.
 \tag{2}
\]

These are disintegration identities, with p(w)=p almost surely under Psi. Require positive evidence and the stated integrability whenever finite KL or derivatives are used. The proof is substitution in the joint integral: the likelihood is constant on a p-fiber, so Bayes changes the p marginal and leaves Psi fixed. On null fibers choose one normalized version. This theorem uses the actual prior, not independent fitted edge marginals.

For a recognition Q(dw)=rho(dp)q(dw|p), the KL chain yields

\[
 D(Q\Vert\Pi_{s,f})
 =D(\rho\Vert\nu_{s,f})
  +\int D\bigl(q(\cdot\mid p)\Vert\Psi(\cdot\mid p)\bigr)\rho(dp).
 \tag{3}
\]

Thus arbitrary recognition is not automatically lossless. The matched family Q=rho Psi is lossless for the entire agreement experiment, with no independence assumption among agents. All conditional record predictions are evaluated from the joint rho. Integrating each p_e separately and multiplying the answers generally changes the experiment.

This also identifies a lower bound on deterministic retention for arbitrary point preparations. If two states have different p_e, the single next record on label e distinguishes them. Any statistic preserving all such predictions must determine every p_e. For arbitrary mixing preparations, all repeated success panels give every mixed monomial moment of the joint p law. Equality of those moments determines the law on the compact cube: polynomials approximate continuous functions uniformly, and continuous integrals determine Borel probabilities. Consequently an average edge probability, a cut OR probability, or a list of partition masses cannot generally replace the joint p law. This is an information requirement, not a claim that every representation of that law must use an exponential number of parameters.

For example, cut vectors (1/4,3/4) and (3/4,1/4) have the same OR probability 13/16 but different probabilities for the first labeled record. Keeping a cut bundle's Boolean connectivity evaluator does not preserve its original labeled experiment.

## 2. One augmented channel and a complete marked parent

Use the preceding paper's fixed conditional Bernoulli panel B, component partition R, and declared root/tree randomization. Write their combined normalized kernel as K(dh|p,W), where h records the realized panel, component incidence, roots, trees, and any seed state required by the specified membership protocol. Uniform roots and uniform spanning trees among the active edge copies give one relabeling-natural choice. This choice is a definition, not a unique selection deduced from VFE.

For a chosen partition and trees, let g_i carry a block-root frame to child i. Retain its root law/model coordinates, every internal fundamental holonomy, every individual dressed cut link, required direction marks, and the original label/incidence registry. Denote this joint geometric mark by M_R. The parent is

\[
 Z=(p,M_R,h),\qquad
 C(w,dz)=\int K(dh\mid p(w),w)\delta_{(p(w),M_R(w,h),h)}(dz).
 \tag{4}
\]

The expression specifies a Markov channel from w to z; its integral over z is one. O is left unchanged. The same C pushes the fine generative joint, selected posterior, and full correlated recognition. A belief coordinate can be a root law point; the parent's recognition is the full law on Z. A model-presentation coordinate can index the fixed evaluator and mark rules, with p retained as its numerical likelihood parameter. This fixed-presentation example does not establish model learning. Shared p entries and shared records are stored once in a global incidence registry, not copied into independent parent factors. A local component may own internal rows and access its incident cut rows; prediction across components uses their joint law.

Under the augmented prior, disintegrate the remaining marks and histories conditional on p as J(dM,dh|p). Then

\[
 P_Z=\nu(dp)J(dM,dh\mid p),\qquad
 \Pi_Z=\nu_{s,f}(dp)J(dM,dh\mid p),\qquad
 Q_Z=\rho(dp)J(dM,dh\mid p)
 \tag{5}
\]

for matched fine recognition. The parent's normalized record evaluator is simply the original labeled Bernoulli product conditional on p. Its static joint evaluator is (5), not a product of block marginals. Its posterior-fiber conditional is common to prior, posterior, and every matched Q: conditioning further on (M,h) restricts the same Psi K in all of them, while their density ratio still depends only on p. Hence the common-channel conditional KL defect is exactly zero for this family. The equality holds even when J is complicated and correlated. Existence of J is not an efficient algorithm to evaluate or sample it; Section 6 supplies a separately priced example.

Gauge covariance is pointwise. If the child frame changes by S_i, then p is unchanged, root law/model points transform by their actual representations, internal H transforms by conjugation at its root, and a cut link V_IJ transforms as S_rI V_IJ S_rJ^{-1}. The root/tree rule acts on graph labels, not matrix components. These identities establish C equivariance under coherent reexpression of the fine law and its structural prior. They do not assert a gauge-invariant density with respect to an undeclared noncompact Haar measure.

All direction marks required by a particular singular-limit interface must be included in M_R and counted. The finite example below takes no singular limit and has no inherited critical mean-direction variable. Its sampled polar directions are hidden fine coordinates; discarding them is valid for (1)-(5), and their later dynamical relevance is tested in Section 8. These two kinds of direction data cannot be silently conflated.

## 3. Closed Fisher law and the missing partition term

Let T(p)=(log p_e,log(1-p_e))_e and introduce the actual exponential family relative to nu,

\[
 \nu_\eta(dp)=Z_\eta^{-1}e^{\eta\cdot T(p)}\nu(dp),\qquad
 Q_\eta(dw)=\nu_\eta(dp)\Psi(dw\mid p).
 \tag{6}
\]

Work in an open parameter region where Z and the required first and second log moments are finite. For positive interior p and nonnegative record counts this is satisfied by the beta-mixture admission below. Endpoint mass needs its own support conventions; a likelihood-zero target cannot be included in an unrestricted finite-log Fisher equation by notation alone.

Fix the observed target eta_*=(s,f). The full Fisher equation for KL to Pi_*=Q_eta* is solved by

\[
 \dot\eta=\eta_*-\eta,\qquad
 \eta(t)=\eta_*+e^{-t}(\eta(0)-\eta_*),\qquad
 \partial_t\log Q_\eta=-\left[\log\frac{Q_\eta}{\Pi_*}
                      -E_{Q_\eta}\log\frac{Q_\eta}{\Pi_*}\right].
 \tag{7}
\]

Indeed log(Q_eta/Pi_*)=(eta-eta_*) dot T-log Z_eta+log Z_*, and differentiating log Q_eta gives dot eta dot (T-E T). The common conditional Psi cancels. Exactly the same calculation applies to the joint marked parent (5); J cancels too. Thus the actual full one-time Fisher laws descend without a conditional error in this matched family. It is an inference-law evolution, not a microscopic particle ODE or a physical clock.

For the marginal partition, let K_R(p) be the connected-component probability from the preceding paper, with roots and trees integrated out, and set

\[
 Z_{\eta,R}=\int e^{\eta\cdot T(p)}K_R(p)\nu(dp),\qquad
 r_\eta(R)=Z_{\eta,R}/Z_\eta,\qquad
 m_{\eta,R}=\nabla_\eta\log Z_{\eta,R}.
 \tag{8}
\]

For positive Z_eta,R, the conditional KL appearing in the partition Fisher equation is

\[
 \Gamma_R=(\eta-\eta_*)\cdot m_{\eta,R}
                  -\log Z_{\eta,R}+\log Z_{\eta_*,R}.
 \tag{9}
\]

To prove this, divide the conditional p densities given R. Their common K_R and conditional geometric kernel cancel. Take the current conditional expectation. This is the KL of the complete conditional marked law as well, because all further conditionals match given p and R. In particular, selecting R couples edges through K_R even if nu was a product.

The actual update can be written either as the earlier marginal Fisher equation or as

\[
 \dot r_\eta(R)=r_\eta(R)(\eta_*-\eta)\cdot
     \left[m_{\eta,R}-\nabla_\eta\log Z_\eta\right].
 \tag{10}
\]

The equality follows by differentiating (8), or by inserting (9) into that Fisher equation. Keeping eta, nu, and an evaluator for Z_eta,R closes Gamma_R. Keeping only r_R does not generally do so. This closure has a cost: a symbolic integral is not automatically a small computable state.

## 4. An evaluable correlated admission

A concrete admitted base law is a fixed finite mixture

\[
 \nu(dp)=\sum_{\ell=1}^{L}\omega_\ell
         \prod_{e=1}^{m}\frac{p_e^{a_{\ell e}-1}(1-p_e)^{b_{\ell e}-1}}
                                  {\mathrm B(a_{\ell e},b_{\ell e})}dp_e,
 \quad \omega_\ell>0,\quad \sum_\ell\omega_\ell=1,
 \quad a_{\ell e},b_{\ell e}>0.
 \tag{11}
\]

The beta integral and its gamma-function expression are given in [NIST DLMF 5.12.1](https://dlmf.nist.gov/5.12.E1). Each component is normalized. The mixture generally correlates edges; all posterior calculations retain the component identity jointly. This is a sufficient prior class, not a replacement for a previously induced nu that fails to belong to it.

For eta=(u,v), direct integration gives

\[
 Z_\eta=\sum_\ell\omega_\ell
  \prod_e\frac{\mathrm B(a_{\ell e}+u_e,b_{\ell e}+v_e)}
                 {\mathrm B(a_{\ell e},b_{\ell e})}.
 \tag{12}
\]

The updated component weights are their contributions divided by Z_eta, and their beta shapes are a+u,b+v. Given a complete auxiliary panel b, use the additional exponents b,1-b in (12). This is conditioning on a coordinate of the one augmented law. It is not permission to count a sampled panel as newly observed external evidence. Unconditionally the panel sums to one and leaves the original evidence unchanged.

If only its components R are retained, sum these integrals over panels b with comp(b)=R. This yields Z_eta,R exactly and gives a mixture with at most L times the number of compatible panels. No claim is made that this expansion is minimal or that its worst-case exponential cost is unavoidable for every graph. Its direct cost can be exponential. Retaining the realized panel makes its conditional evaluator use L components, while the joint law still weights all panels correctly.

First log moments follow by differentiating the finite sum. Within one beta factor, they are psi(a+u)-psi(a+b+u+v) and psi(b+v)-psi(a+b+u+v), using psi=Gamma'/Gamma from [NIST DLMF 5.2](https://dlmf.nist.gov/5.2). These identities also follow by differentiating the beta integral; positivity and the beta tails justify it locally. Integer shapes reduce differences to finite harmonic sums. Thus (9)-(10) have an explicit evaluator for this admission.

The exact calculation uses two components of weights 1/3 and 2/3, with respective common shapes (1,2) and (3,1), on four edges. The shared mixture creates edge correlations. It checks all twelve supported component partitions, their conditional log moments, and the complete marginal Fisher derivative. The four-cycle cannot realize the three partitions containing an isolated diagonal pair; their selection probabilities are zero and no conditional logarithm is taken there. The independent-uniform example used for the closed-form hierarchy probability below is stated separately.

## 5. Recursive marked channels and a two-level event

Suppose R_1 is the component partition of B^(1). Keep the complete p catalog, each original cut copy, all inherited internal marks, and the joint law. Draw a fresh auxiliary panel only on the cut copies of R_1, conditionally Bernoulli(p_e), with a new declared seed. Let R_2 be its components on the quotient. This defines one normalized second channel on the actual first parent. Reusing B^(1) would produce no active cuts and is a different operation.

Let T_A carry a new root frame to an old block root. The new dressed links and inherited loop marks are

\[
 V_e^{(2)}=T_A^{-1}V_e^{(1)}T_B,\qquad
 H_{A,j}^{(2)}=T_A^{-1}H_{A,j}^{(1)}T_A.
 \tag{13}
\]

New fundamental loops come from the cotree cut copies, with the same multiplication order. The fine root path is g_i^(2)=g_i^(1)T_A. Substitution gives exactly (13), so direct transport along the flattened composite tree and staged transport agree. No flatness or commuting-loop premise is needed. Graph contraction gives the same final vertex components as the union of the first panel and the newly drawn cut flags. Internal unused second-panel flags, if generated, do not change those final components and integrate to one. This is equality to the specified composite channel, not equality to one original single-panel channel.

A grandparent may discard child root law points while retaining its chosen root, old loop marks transported to that root, all new cotree marks, and all p entries. Equations (2)-(5) still prove exact agreement inference because all density ratios depend on p. This does not identify the discarded child laws with the grandparent law. Their conditional fluctuations have been integrated, not set to zero. At finite strength, random components need not be exactly aligned.

On the four-cycle with edge labels 01,12,23,30, the event R_1={{0,1},{2,3}} requires the two outer edges 01,23 open and the two cuts 12,30 closed. Conditional on p, a second cut panel merges the pair precisely when at least one cut opens. With independent uniform p_e, its joint probability is

\[
 \begin{split}
 P(R_1=\{01,23\},R_2=\{0123\})
 &=E\left[p_{01}p_{23}(1-p_{12})(1-p_{30})
                \{1-(1-p_{12})(1-p_{30})\}\right]\\
 &=\frac14\left(\frac14-\frac19\right)=\frac5{144}>0.
 \end{split}
 \tag{14}
\]

No preferred pairing is supplied to the component kernel. The event is one of its possible outcomes. For any beta mixture with positive interior density, and any finite record string of positive evidence, the same event has positive probability by the positive integrand. The exact script also obtains 1944/26225 for its correlated, record-tilted example, whose current evidence is 1049/38880. This is a normalized two-level channel event. It is not selection of the most useful hierarchy, time persistence, or a trajectory of structural learning. The earlier non-nesting counterexample for actual Fisher partition marginals remains valid.

## 6. Full-GL realization and explicit resource accounting

For one active centered Gaussian law channel with unit weights, use the prior construction from the preceding paper with the present p law. Draw independent proper covariance factors L_i, setting Sigma_i=L_i L_i^T. Conditional on p, set d_e=-log p_e, draw a unit symmetric direction U_e and O_e from a proper probability on O(K), solve phi(exp(t_e U_e))=d_e, and put

\[
 A_e=\exp(-t_eU_e)O_e,\qquad
 \Theta_{ij}=L_iA_eL_j^{-1},\qquad
 \phi(B)=\tfrac12\operatorname{tr}(B^2)-\log\det B-K/2.
 \tag{15}
\]

The polar proof in the preceding paper gives a unique nonnegative t_e for each nonzero unit direction. Direct Gaussian substitution gives D(N(0,Sigma_i)||Theta_#N(0,Sigma_j))=phi(exp(t_eU_e))=d_e. Arbitrary nonsingular covariance factors work; a frame change can be represented coherently by L_i'=S_i L_i. This defines a proper joint prior by pushforward. With full support of the stated factors its link variables have full GL(K) support. Their loop values need not be identity. Their statistical dependence on law points does not make them transition cocycles or frame coboundaries.

This is a constructive prior within the one-channel model. With two active law channels using one principal link, arbitrary independent beta probabilities for both channels need not be jointly realizable. The general theorem instead uses their actual constrained nu. An evaluable two-channel prior remains a separate admission unless its compatibility is proved.

The cancellation of discarded covariance factors makes reduced sampling concrete. Along any tree path, L_i^{-1}L_i cancels. To sample the retained root laws and dressed links, one can draw p and membership first, then draw covariance factors only at retained roots. Draw the needed A_e factors, multiply their tree/cotree expressions, and sandwich them only by the retained root factors. The omitted L_i are independent of p,A and cancel from every retained expression, so integrating them out is exact. No conditional integration oracle over those omitted covariances is hidden in this sampler.

For a realized partition with b connected blocks on a graph of N vertices and m edges, there are m-N+b internal-cotree-plus-cut matrices in total. Let d_law count retained coordinates of each root's law/model tuple and let d_dir count separately required inherited direction data. An explicit sample representation therefore uses at most

\[
 D_R=b d_{\rm law}+(m-N+b)K^2+m+d_{\rm dir}
 \tag{16}
\]

real coordinates, with the last m for the original one-channel probabilities. This is a coordinate-storage upper bound, not a proof of intrinsic manifold dimension. Compare the corresponding explicit fine representation N d_law+mK^2 plus its inherited marks. The one-channel difference, when inherited direction cost is unchanged, is (N-b)(d_law+K^2)-m. Multiple separately labeled channels increase the probability-catalog term; no original record is removed to improve the count.

For the four-cycle, K=2 and centered covariance laws have d_law=3. No singular limit is used. The following counts include all p entries, holonomy, and cut matrices.

| Retention | Root covariance entries | Cut/cotree matrix entries | Original p entries | Total real entries |
| --- | ---: | ---: | ---: | ---: |
| Explicit fine law/link sample | 12 | 16 | Derived when queried | 28 |
| Two proper pair parents | 6 | 8 | 4 | 18 |
| Their grandparent | 3 | 4 | 4 | 11 |

For roots 0 and 2 in the pair stage and root 0 in the grandparent, orient the edges as 0<-1<-2<-3<-0. The retained matrices are

\[
 V_{12}=L_0A_{01}A_{12}L_2^{-1},\qquad
 V_{30}=L_2A_{23}A_{30}L_0^{-1},\qquad
 H=V_{12}V_{30}=L_0A_{01}A_{12}A_{23}A_{30}L_0^{-1}.
 \tag{17}
\]

The exact matrix calculation checks this with rational noncommuting matrices and nonidentity H. Uniform root choices give these roots positive probability; other choices obey (13) and have the same entry count. This example does not set the links flat.

There is also a limited explicit sampling saving. All three versions need the four scalar energy inversions, four polar directions, and four orthogonal factors in (15). Beyond forming the four A_e, the fine sampler uses four covariance factors and eight matrix multiplications for its four physical links. The displayed pair sampler uses two covariance factors and six multiplications; the displayed grandparent sampler uses one covariance factor and five multiplications. These are algebraic operation counts for (17), excluding scalar solve costs common to all versions. They are not measured speedups or universal optimal-algorithm bounds. Computing every p from a supplied fine sample still requires its fine divergences once; the savings apply after that initialization or during direct prior/posterior sampling.

Finite history is extra. In the event (14), a direct representation can retain four first-panel bits and two second-cut bits, three root-choice bits, and at most one second-tree-choice bit. The partitions themselves are derivable from the panels and fixed registry. Original graph labels, observations, model definitions, and record counts remain common stored data. Further retained seed state must be priced if the selected protocol reuses continuous seeds. A reduction in real-entry count is not a claim about exact real-number bit complexity or floating approximation accuracy.

Law and evaluation costs do not all shrink. The mixture template has 2Lm positive shapes and L weights, while recognition needs the same 2m exponents at every level. Normalizer evaluation uses Lm beta ratios; one new labeled observation updates L component contributions. The original likelihood still reads all queried original labels. Computing all partition masses or all Gamma_R by direct panel expansion can require L times 2^m terms. A fine implementation that already works in (p,eta) enjoys the same agreement-inference savings; blocking adds no further reduction of that minimal predictive catalog. The demonstrated benefit is fewer explicitly retained geometric sample coordinates and covariance/link assembly operations at identical agreement predictions. It is not a measured reduction in the entire inference workload.

## 7. Persistence of predictions and its access boundary

For any finite future labeled agreement panel under common record-history policies, (2) and (5) give identical fine and parent path probabilities. Consequently every declared vector of those response probabilities is preserved, and distinct p values can remain informative relative to a constant parent. In the beta-mixture example, a nondegenerate p_e yields Var(p_e)>0 and two repeated conditional-independent records on that edge have covariance Var(p_e)>0 after integrating p. A one-state evaluator with independent fixed-probability emissions cannot reproduce both its mean and this covariance. A one-state representation supplied with the full beta-mixture filter is a different, nontrivial memory representation and must have that cost counted.

This is exact prediction of the admitted fixed-latent record process. It does not show autonomous response persistence under an arbitrary physical link evolution, prove a general finite-memory forgetting rate, or reproduce hidden-state-aware policies. Nor does the auxiliary two-panel hierarchy event establish a learned preference or persistent microscopic identity. The preceding counterexample proves that even the one-time partition marginals of a decreasing-VFE Fisher flow may forbid a nested coupling.

## 8. A geometric trajectory obstruction despite Fisher-law closure

The previous paper constructs a nested energy/bond coupling when edge energies have independent tilted laws. Complete its fine trajectories by keeping each covariance, polar direction, and orthogonal factor fixed while its scalar energy follows that quantile coupling. This is one explicit full-state realization. It generally fails to descend to Z=(p,root laws,holonomy,panels), even though (7) descends at the level of one-time laws.

Take two vertices with two oppositely directed edge copies, both covariance matrices I, and retain the whole component rooted at vertex 0. Let D(x)=diag(x,x^{-1}) and choose the two initial links D(2),D(2)^{-1}, with H=I. Their unit-weight energies are both

\[
 d_0=\tfrac12(2^2+2^{-2})-1=9/8.
 \tag{18}
\]

A second fine state conjugates both links by

\[
 R=\begin{pmatrix}3/5&-4/5\\4/5&3/5\end{pmatrix}.
 \tag{19}
\]

It has the same p values, root covariance I, H=I, and any identical already-open panel/seed history. It is a distinct hidden polar orientation with exactly the same retained state. Both configurations belong to the full-GL support of the construction. The pointwise statement here admits these initial preparations; no almost-everywhere failure claim is inferred merely from two isolated points.

Use independent exponential energy priors with rates a_1=25/56 and a_2=49/275. Along their all-success quantile coupling, d_e(kappa)=a_e d_0/(a_e+kappa) when initialized at d_0. At kappa=1,

\[
 d_1=25/72=\tfrac12[(3/2)^2+(2/3)^2]-1,\qquad
 d_2=49/288=\tfrac12[(4/3)^2+(3/4)^2]-1.
 \tag{20}
\]

Keeping their original directions, the first state therefore has later links D(3/2),D(4/3)^{-1} and retained H'=D(9/8). The conjugated state has

\[
 \widetilde H'=R D(9/8)R^{-1},\qquad
 (\widetilde H')_{12}=17/150\ne0=(H')_{12}.
 \tag{21}
\]

All retained probabilities are still identical between the two trajectories, and monotonically opening bonds can keep the entire component present. Yet the retained holonomy differs. A deterministic parent evolution from their identical initial Z cannot output both results. Hence this specific native full-state quantile realization has no pointwise deterministic semiconjugacy through the proposed retained state for all admitted preparations. At a fixed all-success target with count n=2, kappa=1 is reached at the finite Fisher time log 2; the comparison does not change data between its endpoints.

Keeping the individual angular/link decomposition resolves this example but adds precisely the state whose removal supplied part of the sample savings. A minimal sufficient geometric memory for arbitrary graph trajectories has not been established here. Alternatively, a conditional resampling dynamics can preserve the correct one-time J conditional while changing trajectories; it is an additional declared dynamics, not a proof about the frozen-direction evolution above. The source's allowed parent-sensitive kernels must be specified and checked before using that alternative. Law-level Fisher closure, Markov path closure, and structural-parameter E/M closure remain different obligations.

## 9. Executed checks, result, and next obligation

[marked_parent_exact.py](evidence/marked-parent/marked_parent_exact.py) performs one small standard-library calculation. Exact Fraction arithmetic checks the normalized correlated beta-mixture panel/partition laws, conditional harmonic log moments, and the equality of the two partition Fisher derivatives for all twelve supported four-cycle partitions and all sixteen panels; evaluates the two-stage event; checks direct/staged noncommutative matrix composition; and checks every rational coefficient in (18)-(21). The [saved result](evidence/marked-parent/marked-parent-exact-result.json) records the values. It does not simulate trajectories, benchmark a GL implementation, run the earlier finite experiment, or prove the general theorems by enumeration.

The admitted positive result is an exact correlated agreement-statistic family, complete marked common-channel parents, computable conditional Fisher memory under a finite-mixture admission, and recursive two-level channels with a positive two-proper-block event and explicitly counted sample savings. The retained negatives are the full original p-catalog requirement, possible cost of partition conditioning, absence of automatic two-channel beta realizability, and the demonstrated geometric trajectory obstruction. A complete coupled belief/model/link hierarchy is still not obtained by these static and one-time-law results.

The next decisive obligation is to test the actual declared pointwise structural update against this memory boundary: determine whether its retained angular/conditional state has a finite closed form with useful resource cost, or supply a justified alternative normalized update and prove both its path intertwining and its information persistence. This must retain the actual correlated marked law and distinct belief/model channels, specify which dynamics is being claimed, and preserve the known non-nesting and trajectory counterexamples. Before expanding to further special cases, reconcile these results with the original completion requirements and identify which remaining gate needs an external operational choice. No base transport, new empirical data, approximation tolerance, curvature penalty, production change, or vault edit is authorized by this result.
