# Completion check of the original finite requirements

September 12, 2026. All mandatory first-session mathematical and empirical deliverables are present, and the subsequent fifteen-subset exact local-admission phase is complete with the explicitly permitted negative exit. Every exact local map is injective; every complete local-plus-exterior parent retains sixteen states. This does not complete original statistical spatial selection, a useful learned hierarchy, or general dynamic gauge-RG. Later Gaussian constructions cannot count as fresh confirmation of the unchanged four-spin experiment.

This is a bounded independent reconciliation, not another scientific execution or a formal ledger certificate. Authority is the original [attachment](<C:/Users/chris and christine/.codex/attachments/be4e6f63-61a2-4b23-812a-608a92793312/pasted-text.txt>), SHA256 `d9478cf27ee490b81d4c5bd89bb2c6117396621586a346cca56e88578974351e`, sections 1–8 and 10–12. Section 9 and subsequent general one-base-point directions belong to the coordinator's companion check. The attachment makes later phases conditional, permits a negative local admission, and permits proofs/direct evidence when verification tooling is unavailable. The later refusal to choose an arbitrary numeric tolerance is retained; it supplies no numerical specification.

Live source HEAD remains `ed8f22a56df353b1535744509cc23fae46d5813c`, branch `codex/neighborhood-cover-20260908`, in `C:/tmp/elbo-cover-20260908`. The worktree now contains later work and protected differences. Historical clean-worktree assertions describe the first session's start, not its present state. No remote synchronization claim is made.

## Target, model, and equivalence

The supplied finite carrier is the full product Y={-1,+1}^4 with counting measure. For actions a=±1/5 the emitted kernel is

K^a(y',e|y) = (1/4) sum_i 1{y'_-i=y_-i} [1+y'_i(a+sum_j J_ij y_j)]/2 [1+(3/4)e product_j y'_j]/2.

The symmetric edge values in order 12,13,14,23,24,34 are (1/16,1/12,1/10,1/8,1/7,1/6). The largest incident sum is 43/105, so the reset mean has absolute value at most 64/105<1. The record probabilities are 1/8 and 7/8. Summing each reset pair, record and reset-site probability proves normalization.

Empirical prediction uses uniform preparation, horizon four, saved policy/environment cells, and initial information h(Y0). The predictor receives subsequent actions and records, not subsequent fine states. Exact local admission instead seeks, for EVERY nonempty A, one exterior-independent h_A satisfying

sum_{u':h_A(u')=s'} K^a(u',x',e|u,x) = Kbar_A(s',x',e|h_A(u),x,a)

for EVERY local source u, exterior x, action a and joint target (s',x',e). Equivalence is equality of retained-state/action/record path laws at every finite horizon under pushed preparations and common retained-history policies, with initial-sensor descent separate. This is stronger than average record prediction. Complete exterior retention, a START code and singleton presentation/generative-memory marks are explicit introduced choices, not hidden model-learning or mean-field assumptions.

For a fixed finite experiment, the joint law is P(y_0:H,a_0:H-1,e_1:H)=mu(y0) product_t pi_t(a_t|retained past)K^(a_t)(y_(t+1),e_(t+1)|y_t). One normalized deterministic channel retains the declared latent state/path and observations once. At positive evidence o and full correlated Q_o << P(.|o), define F_I=E_(Q_o) log[Q_o(W)/P(W,o)], and F_A by the same expectation on the actual common push. Finite domination ensures integrability. Finite disintegration gives F_I-F_A=sum_z Q_A(z) KL(Q_o(.|z)||P(.|z,o)). For bijective G_A this is zero. A fitted replacement adds the signed correction in local-contract section 5. A singleton presentation does not establish model learning.

The Research wiki current-scope note in `Meta-agents and hierarchical emergence.md`, and live PIFB2 sections `meta_agent_formation` and `cross_scale_shadows` (1533–1698), were consulted read-only. They distinguish parent definition, conditional licensing, and shared-prior interpretation; their WIP status does not prove the finite claims. The governing evidence is the normalized finite law, explicit derivations and bound source code.

## First-session requirement matrix

“Complete” means the requested artifact or scoped result is present with the cited derivation/saved evidence. It is not a new science execution claim. Added subidentifiers only make the attachment's requirements traceable.

| Original requirement | Concrete location/evidence | Verdict |
| --- | --- | --- |
| 1a. Distinguish exact parent, useful approximation, learned child grouping and persistent recursion; preserve symmetric 16/9/5 and three pairings. | REPORT introduction/source/locality sections; local-admission conclusion. | Complete; configuration partitions are not mislabeled child partitions. |
| 1b. Preserve nine endpoint selections as scoped negative result, without tuning for intermediate success. | frontier/reconstruction.json; validation-frontier.csv; frozen cost 0.005 and REPORT's 0.020 charge versus approximately 0.006249 held-out advantage. | Complete. |
| 2a. Inspect live source/status, historical revisions, active inputs and preservation. | RECORD round 1; input-binding and completion-inspection; current hashes below. | Complete for retained source/input binding. Historical reading order is recorded rather than independently recoverable from file contents. |
| 2b. Existing worktree and read-only wiki context. | Same worktree, wiki current scope and live PIFB2 read in this check. | Complete for reconciliation; no vault edit. |
| 3a. Reproduction/frontier/matched-oracles/independent identity and obstruction/local ticket. | REPORT, frontier-analysis, reconstruction, local-contract, next-stage-contract and tables below. | Complete; no missing mandatory first-session calculation located. |
| 3b. One output tree, RECORD, actual-date log, preserved source/data and bounded rounds. | Existing directory, RECORD's first three rounds, docs/change-logs/2026-09-11.md; input hashes unchanged. | Complete as recorded; later authorization is separate. |
| 4a. Operational contract table with all requested fields and assumption origins. | RECORD “Operational contract”; local-contract section 1. | Complete: state, structure, record, action, preparation, access, policy, clock, horizon, both targets and costs. |
| 4b. Initial class only, no observed fair auxiliary initial symbol, matched oracle access. | REPORT; analyze.py `losses` initializes the oracle uniformly inside `initial_blocks` and reads only action/record thereafter. | Complete. |
| 4c. Both models filter history; previous-record rows are extra context; hidden-aware policy caveat. | frontier-analysis and reconstruction's explicit action-information counterexample. | Complete. |
| 5.1a. Match nine seed/budget datasets; reuse saved 16-partition ladders, rows, episodes, prior and both model choices. | analyze.py indexes saved results and calls fit_parent on saved tuples; no collecting runner or ladder regeneration. | Complete on code and retained execution. |
| 5.1b. All 288 rankings/scores, nine selections, exact rational selected rows, tolerance and ties. | reconstruction.json: max difference zero at 1e-12, nine index-30 selections; producer asserts Parent equality and complete ranking equality. Current CSV-to-results comparison has zero mismatches. | Complete. Reconstructed selected rows are compared in code, not duplicated in a second saved model file. |
| 5.1c. Runtime/input/source binding and ordinal discipline. | reconstruction/execution records; current matching hashes; emitted ordinal columns used directly rather than miscalling filter_step. | Complete with historical producer-byte qualification below. |
| 5.2a. All-candidate NLL/Brier, paired endpoint differences and all named resource coordinates. | 288 validation rows with classes, memory_bits, filter_coordinates, stored_entries, normalized_row_coordinates, partition_fixed_width_bits and paired statistics. | Complete; row coordinates are not called Fisher rank or effective degrees of freedom. |
| 5.2b. Searched family, nondominance/ties and nonnegative coefficient breakpoints. | frontier-analysis; pareto/lower_envelope/lambda columns; 20 interval rows; code checks all pairwise affine inequalities. | Complete for declared NLL/log2-cardinality frontier; no multidimensional optimum claimed. |
| 5.2c. Frontier/endpoints only on six visible held-out cells, exploratory status. | 294 unique heldout-frontier keys, all six cells and 256 episodes each. | Complete, no missing/duplicate/extra required key. |
| 5.2d. Conditional memory occupancy and 36b versus 3b scarcity. | 4,896 coverage rows, 144 summaries; b=512,k=16 mean 24 from 3b/(4k); prose derives pooled 32b+4b. | Complete; no intrinsic-memory-value conclusion. |
| 5.2e. Whole paired episodes, limited training seeds, conditional uncertainty and adaptive reuse. | frontier-analysis statistical definitions; paired SD/SE columns, no confirmatory interval. | Complete. Optional bootstrap/concentration calculations are not missing tasks. |
| 5.2f. Standalone plots and tables for resources, attribution and occupancy. | Three PDF/PNG pairs and plot.py; six hashes match; REPORT records visual inspection. | Complete as saved, not rerendered here. |
| 5.3a. Normalized joint, fixed training data, support/integrability, risk expectations, policy cancellation and information/KL decomposition. | frontier-analysis “Exact preparation identity” and reconstruction “Predictive loss decomposition” contain finite-mixture proof. | Complete proof; hidden-state-aware policy counterexample limits scope. |
| 5.3b. Full, matched-preparation and fitted comparisons on same episodes and actual evaluation environment. | analyze.py's environment-specific oracles/frozen fits; 58,368 paired triples. | Complete; shifted-environment discrepancy remains in mismatch. |
| 5.3c. Endpoints plus at most three distinct nonendpoint frontier partitions, chosen before oracle inspection. | RECORD rule; oracle-selection; analyze.py places complete reconstruction/choice gate before oracle loop. | Complete: 38 instances, 228 cells. |
| 5.3d. Normalization and tiny exact hidden sum; exact kernels distinguished from floating scoring. | filter-check.json retains 19682267/80281600, float 0.24516535544882015 and zero difference; code has normalization assertion. | Complete as retained evidence, not rerun. |
| 5.3e. Signed sample attribution and unresolved estimation/closure/memory split. | REPORT and frontier-analysis preserve negative differences and reject independent causal attribution. | Complete; population precision remains unresolved. |
| 5.4a. Intrinsic diameter and d/2 floor separate from fitted error and record prediction. | local-contract section 2; independent triangle proof; 76 structural rows over two environments. | Complete; half-diameter is a lower bound, not asserted universal equality. |
| 5.4b. First-response formula, 3/20 TV, 3/40 common-row floor and initialization/memory limit. | local-contract section 3; independent proof; response-certificate with 64 checked instances. | Complete proof plus retained exact instance checks. |
| 5.4c. Coupling-bound hypotheses, matched initial law and distinction of sufficient threshold from actual error. | Exact path proof states policy/initial hypotheses; no new acceptance bound or tolerance is promoted from historical bounds. | Complete scope discipline; no new approximate bound needed for first-session decision. |
| 5.5. Account for endpoint cost/preparation/mismatch/scarcity without inventing preference; finish local ticket. | REPORT decision and fully typed next-stage-contract. | Complete historical handoff; subsequent execution is in local-admission. |

## Every section 6 local-admission obligation

The L identifiers unpack the attachment's mandatory local outputs. Each applies to all fifteen subsets.

| Requirement | Concrete evidence | Verdict |
| --- | --- | --- |
| L1. All fifteen nonempty subsets, endpoints and declared graph structure. | Complete menu in next-stage-contract; admission.csv and filenames match every combination. | Complete: no missing/extra subset. |
| L2. One exterior-independent map valid for all inputs and outputs. | Local states, every (a,x) as adapter action, one coarsest_partition call per subset. | Complete in deterministic exact class. |
| L3. Reuse ControlledProcess/coarsest_partition/quotient_process. | run_admission.py imports and calls unchanged bound source APIs. | Complete. |
| L4. Original normalized joint emitted row, without marginal multiplication. | Adapter reassembles all target states, extracts exact source atom, asserts row sum one; quotient_process checks closure. | Complete construction; 480 saved source-row checks. |
| L5. Disjoint integer START/STEP typing and no time-zero exterior observation. | All codebooks and initial rows saved; START=0, unit initial, zero emitted mass asserted. | Complete. |
| L6. Every local map and class count. | Full local carrier/map/count in every subset JSON. | Complete: all identity. |
| L7. Source-fiber factorization. | global_map and 16 explicit source_fibers per certificate; code compares Cartesian reconstruction. | Complete: 240 fibers. |
| L8. Refinement trace and separating exact row discrepancies. | Trace labels/counts and witness action/target/record/probabilities/difference/previous_labels saved. | Complete: every local unordered pair represented, 272 total. |
| L9. Full normalized quotient rows, initial descent and exact emitted-row equality. | Each certificate has 32 quotient and 32 initial rows; producer compares every source aggregation and initial row to quotient. | Complete; flags backed by explicit rows and checking code. |
| L10. Complete response/model/interface/memory carrier; sample versus recognition law. | local-admission complete-parent paragraph; local-contract section 5. | Complete for S_A times {m_*} times Y_E times {h_*}; no model-learning claim. |
| L11. One normalized recognition-independent push of generative/posterior/full correlated recognition laws. | local-contract section 5 explicit channel and common-push identity; admitted G_A bijective. | Complete under joint/domination assumptions; discarded conditional KL zero. |
| L12. Access maps, static evaluator distinct from transition evaluator and null-fiber versions. | local-contract section 5 and next-stage-contract access/evaluator paragraphs. | Complete; parity predictor gains no undeclared exterior access. |
| L13. Fitted-model mismatch accounting. | Both signed corrections explicitly given in local-contract section 5. | Complete; actual admission substitutes no fitted model. |
| L14. Total carrier/interface/filter/storage cost; identity not useful compression. | admission.csv resource columns; fifteen-coordinate full filter is a representation, not minimality theorem. | Complete: every full carrier is 16. |
| L15. Finite proof or negative exit, weak-boundary counterexample and disjoint composition with correct schedule/record. | local-admission-reconstruction subset-sum/two-response proofs; local-contract sections 6–7 block replacement and normalized binary counterexample. | Complete negative exit. |

All subset files are under evidence/local-admission/. Each has 16 full fibers, 32 emitted rows and 32 initial rows. Maps are the identity index sequence on lexicographic local configurations. The following is direct parsing of every certificate, not an inference from one example per size.

| Subset | Local classes | Refinement trace | Unique separating pairs | Record alphabet including START | Emitted row width |
| --- | ---: | --- | ---: | ---: | ---: |
| 1 | 2 | 1,2 | 1 | 17 | 34 |
| 2 | 2 | 1,2 | 1 | 17 | 34 |
| 3 | 2 | 1,2 | 1 | 17 | 34 |
| 4 | 2 | 1,2 | 1 | 17 | 34 |
| 12 | 4 | 1,4 | 6 | 9 | 36 |
| 13 | 4 | 1,4 | 6 | 9 | 36 |
| 14 | 4 | 1,4 | 6 | 9 | 36 |
| 23 | 4 | 1,4 | 6 | 9 | 36 |
| 24 | 4 | 1,4 | 6 | 9 | 36 |
| 34 | 4 | 1,4 | 6 | 9 | 36 |
| 123 | 8 | 1,8 | 28 | 5 | 40 |
| 124 | 8 | 1,8 | 28 | 5 | 40 |
| 134 | 8 | 1,8 | 28 | 5 | 40 |
| 234 | 8 | 1,8 | 28 | 5 | 40 |
| 1234 | 16 | 1,13,16 | 120 | 3 | 48 |

The no-compression theorem does not rest solely on this table. For proper A, an exterior site's next-spin expectation contains the local signal (1/4)sum_(i in A)J_ji u_i. Each full incident weight list has eight distinct subset sums, explicitly listed in local-admission-reconstruction. Thus each sublist's signed sums are distinct, forcing equal local sources when strong-exterior rows agree. For the whole block, first-record means under both fields separate thirteen classes; the three remaining balanced complementary pairs have two-event record marginal TV 3/512, 3/896 and 9/6400 under the positive-positive action word. Every deterministic merge therefore loses an admitted experiment by horizon two. Memory initialized only from the merged class cannot recover that lost preparation distinction.

## Original conditional gates, sections 7–8 and 10–12

| Original requirement | Evidence/status | Verdict |
| --- | --- | --- |
| 7a. Choose an explicit approximation/retention/experiment target after exact identity admission. | No externally justified allowed-loss or resource requirement was supplied. Later one-base-point work is a redirected construction. | Original statistical phase is gated. “i have no idea” is not a numeric tolerance. |
| 7b. Learn actual subsets/local channels from training data without generator/desired-label access. | Retrospective ladder groups global configurations; local structural admission uses exact tables. | Not achieved; exact admission is not statistical spatial discovery. |
| 7c. Freeze candidate/estimator/access/preparation/alphabet/cost/tolerance/ties/policy/budget protocol before fresh collection. | No new original heterogeneous spatial protocol is certified here. | Conditional, unexecuted. |
| 7d. Independently motivated boundary enrichment, retained parity comparison, no post hoc port weights. | Original parity experiment is preserved; no enriched-sensor result claimed. | Conditional; not missing first-session/local work. |
| 7e. Fresh fixed-rule evaluation, paired episodes/replicate uncertainty, precision-based sample size within runner limits. | Existing held-out cells remain exploratory pilot evidence. | Not achieved. Gaussian exact calculations cannot substitute for fresh finite-data confirmation. |
| 7f. Positive/negative/inconclusive exits; positive accuracy/informativeness/total-resource advantage. | Original frozen learner has retained endpoint result; local phase has no exact reduction. | Negative exits supported. Positive learned spatial formation not established. |
| 8a. Named memory failure, initialized update and row bounds over reachable posteriors. | First-response/deterministic-memory obstruction proved; stochastic finite-carrier lower bound extends it. | Exact obstruction complete; original useful reachable-posterior approximation remains conditional. |
| 8b. Count posterior fallback; distinguish fixed-law projection from controlled forgetting. | Full filter cost and complete stochastic carrier are explicit; no forgetting theorem imported. | Scope respected; no general memory benefit proved. |
| 8c. Action-specific informative response stability instead of label survival. | First/two-event probe signatures establish preparation separation. | Separation complete, not a learned-organization persistence study. |
| 8d. Attempt/change/scheduler clocks distinct; stationary and lineage hypotheses. | One-site schedule preserved; no new stationary survival or lineage claim. | Conditional; no need to rerun lazy-clock calibration. |
| 10a. Useful proper first-level blocks before second-level learning; correlated joint/interfaces/schedule/one record. | All exact local full states remain 16. | Useful exact first-level gate fails in this model/class; valid negative completion. |
| 10b. Disjoint block-replacement proof, initial sensor separately. | local-contract section 6 and independent reconstruction; product-carrier/connected-fiber condition and constrained-carrier counterexample. | Complete conditional theorem. |
| 10c. Actual joint first-level kernel, direct/staged pushes and descended policies. | Conditional associativity/path proof exists; identity first level cannot permit smaller deterministic exact second level. | Composition proved; useful original learned two-level hierarchy not achieved. |
| 10d. Compatible approximate global kernels and composed error bound with separate initial errors. | No heterogeneous approximate two-stage model is admitted. | Conditional; unrelated local fitted errors cannot simply be summed. |
| 10e. Two proper blocks, informative resource reduction, admitted second parent, menu/tie/failure accounting. | No positive original finite-data outcome. Symmetric calibration remains a distinct source. | Not achieved by identity admission or later changed Gaussian example. |
| 10f. Overlap/event assignment/base descent are separate later extensions. | No such conclusion is inferred from the finite tables. | Outside completed finite scope. |
| 11. Bounded expert ownership, independent reconstruction, three shared rounds. | RECORD and reconstruction files give assignments, order and full proofs. | Complete as retained procedural record; agreement not used as proof. |
| 12a. Derivations/exact evidence, unavailable verifier fallback, scoped status. | Independent proofs and exact records; reports explicitly deny a formal certificate. | Complete; no missing Lean/ledger requirement. |
| 12b. Pinned serial CPU, no repeated successes, honest test counts/exclusions/preservation. | Saved execution records identify CPython 3.14.7 and no pytest in these phases; this lane only parsed/hashed. | Complete within inspected evidence; older JUnit not counted anew. |
| 12c. One record of target/assumptions/failures/rounds/next action; report/frontier/ticket handoff. | RECORD, REPORT and next-stage-contract with tables. | Complete historical handoff; navigation qualification below. |

The stochastic extension is separately scoped. The parity-annihilation proof gives all-horizon observable rank at most fifteen. Its saved independent minor compares 240 rational entries, has determinant 85 modulo prime 1009 with invertible denominators, and current witness bindings match. This proves every proper preparation-row subset independent, forcing at least 2^|A| finite stochastic initialization states for each fixed exterior under the common-predictor/complete-carrier contract. The global positive-realization bound remains 15–16. That one-state question is not a missing first-session/local requirement and supplies no missing useful proper first level.

## Binding, actual checks, and genuine qualifications

One read-only standard-library parser/hash inspection ran under the pinned `python.exe -I -B -` and exited zero. It imported no science module, did not decompress/resample observations, fit a model, construct a kernel, or rerun any test/producer. Results are saved in this report, with no second unassigned output. All 288 unique validation keys are present and their NLL/Brier/criterion values match the saved ranking table exactly. All 294 frontier/endpoint held-out keys and 228 attribution keys occur exactly once across original/reversed_couplings times positive/alternating/feedback. The 58,368 episode keys are unique, with 228 groups of 256. Coverage and certificate dimensions are recorded above.

Current hash inspection: first completion inventory 32/33 output entries match, with only subsequently extended RECORD differing; all 28 retained-input/receipt-source entries match. Local continuation inventory 58/60 match, with only extended RECORD and RG-COMPLETION differing. Every finite science table, proof, fifteen certificate, producer and execution record in these manifests matches. Frontier execution's two source/four final-script bindings and local execution's three source/one producer bindings match. All nine stochastic artifact hashes match, including the independent minor and its rank-witness binding. These are provenance checks, not new row-equality, fit, filter, determinant or plot executions.

Two limitations remain. The frontier's four scripts gained function annotations after science execution. The records bind final hashes and state calculation bodies were unchanged, but retain neither separately hashed pre-annotation producer bytes nor raw stdout. Exact historical producer-byte identity is documented rather than independently recoverable; no scientific discrepancy was found, and this is not permission to rerun passing science. Also REPORT/local-contract/next-stage-contract are deliberately frozen first-session artifacts whose future-tense local ticket is now historical. Current navigation should point to local-admission and the final reconciliation; their historical proofs should remain unchanged. The older whole-directory inventories cannot certify the later current RECORD/RG-COMPLETION contents.

No mandatory first-session calculation or local certificate is missing. The strongest supported original result is full retrospective coverage plus exact identity-only admission for all fifteen subsets, with the stated deterministic and stochastic proper-local no-compression scope. Original useful learned statistical formation, fresh confirmation and persistence remain conditional on a declared operational allowed-loss/resource target and corresponding protocol. The next material action is the coordinator's reconciliation with the later dynamic one-base-point directions, not another finite sweep, invented tolerance or optional positive-realization problem.
