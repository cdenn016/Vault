# Workload and accuracy frontier for the preserved collective responses

September 12, 2026. The actual-hierarchy response construction admits a complete conditional cost comparison for its frozen-query workload. The new directional interface must pay for its vector contrasts and decoders; the earlier scalar-probability assembly bound cannot be copied unchanged. This report supplies that missing price schedule and combines it with the existing response guarantee. No prices, required accuracy, query radius, or deployed workload are selected.

The [response construction](selected-hierarchy-response.md) fixes the law, actual ancestry-dependent geometry, historical input ports, and anchored Bernoulli experiment. The [common-prior episode](common-prior-native-hierarchy-episodes.md), Sections 4–7, supplies the normalized all-ancestry panel and the simultaneous late-window storage margin. The [earlier resource derivation](native-episode-resource-frontier.md), Sections 2–5, supplies the coupled fine completion and first-parent assembly. The [cost calculation](selected-hierarchy-response-cost-calculation.md) counts only the saved new maps, and the [workload proof](selected-hierarchy-response-cost-law.md) gives the quantifiers and finite-depth conditions below.

## What is priced

At a native learning state in the certified interval [35,40], draw and retain complete samples from either recognition or the current model posterior. Each sample remains frozen through its panel contractions and response queries. The fine comparator retains the full latent sample. The parent retains the original sufficient statistic, ancestry, current geometry, forest-response contrasts, and advertised interface. Both use the same residual-first accepted proposal and native normalizer/moment algorithms.

For one panel, the parent has 12+4(k+q) displayed real fields against 36+4k fine fields. The expected saving is greater than eighteen, uniformly on the same nonempty open full-positive-prior family that supports the native hierarchy episodes and the response bound. For J panels, the geometric block count cannot increase, and the count becomes 12+4(k0+kJ). Consequently the expected saving 24−4 E kJ is at least the one-panel saving for every finite J≥1. This is an expected field count, not a measured memory saving.

The workload evaluates the retained native density ratios and moments and answers anchored Bernoulli queries through the retained ports. The correlated reverse conditional remains part of the mathematical interface. Actual conditional microscopic reconstruction, an absolute-density oracle, a new filter, and moving individual samples need their own algorithms and costs if requested. Their execution is not silently supplied by retaining a kernel description.

## Arithmetic schedule

The exact count uses the same literal linear-row convention throughout: assignments and multiplication by +1 are free; every other nonzero coefficient, including −1, costs one multiplication; summing n nonzero terms costs n−1 additions. Copying fields, memory access, dispatch, metadata, and controller work are charged separately. This is an ideal real-arithmetic schedule, not a finite-bit bound or a benchmark.

A four-direction cut residual zB−zA−V costs eight multiplications and eight additions under this convention. Computing its two Gaussian agreement probabilities and their product adds seven multiplications, two additions, and two exponentials. The maximum four-cut panel therefore costs 60 multiplications, 40 additions, eight exponentials, four uniforms, and four comparisons. Direct machine subtraction can be cheaper; the old 28-multiplication panel allowance used that different instruction schedule.

The single exact counting pass covers all 176 saved augmented geometry maps and 416 old-cut decoder rows. The maximum four-direction map cost is 52 multiplications and 60 additions. Decoding one old cut in one two-dimensional channel costs at most eight multiplications and eight additions. With the earlier first-parent assembly bound of 52 multiplications and 80 additions, a conservative per-sample one-panel formation charge is

\[
 A_1=164c_{\times}
       +180c_+
       +8c_{\exp}+4c_U+4c_{\rm cmp}+c_{\rm case}.
\]

Given d, computing both norms, both exponentials, the signed anchored increment, clipping, and a Bernoulli answer costs another seven multiplications, six additions, two exponentials, one uniform, and three comparisons. Thus an uncached historical-port query is bounded by

\[
 Q_1=15c_{\times}
       +14c_+
       +2c_{\exp}+c_U+3c_{\rm cmp}+c_{\rm query}.
\]

The input is the already oriented relative displacement h. Converting two endpoint displacements to h costs another two multiplications and two additions under this convention. Here c_case and c_query include their actual per-call selection and access work; additional state-dependent controller work must also be bounded and charged. Identical controller code alone does not make its expected cost cancel when answer distributions differ. The fine comparator is granted its positive completion and query work for free in this upper bound on the parent's extra cost, so those omissions favor the fine side.

The same 176-case catalog covers every reachable flattened rooted geometry and its panel on this fixed graph. The per-panel map reads current geometry, so a conservative formation charge for J panels is

\[
 A_J=(52+112J)c_{\times}+(80+100J)c_+
       +J(8c_{\exp}+4c_U+4c_{\rm cmp})+C_{\rm formation}(J).
\]

The term C_formation(J) must include all remaining per-sample case selection, access, copying and history work; shared coefficient preparation and storage are charged below. For finite repeated contraction, charge every panel rather than only proper mergers. The at-most-three proper mergers bound the geometry changes, but idle rounds still consume work and history. A compiled historical decoder is a linear row in at most k0+kJ≤8 scalar-direction fields, hence its two-direction core costs at most sixteen multiplications and fourteen additions. The full anchored-query arithmetic core is at most 23 multiplications, 20 additions, two exponentials, one uniform, and three comparisons. This is a dimension bound from the decoder proof, not a new enumeration of all histories. Preparing and storing all compiled rows, locating ports, retaining history, copying older contrasts, and handling idle rounds remain charged.

## The joint license

Take N resident samples, L accounting ticks, and K queries per sample. Let c_w>0 price one displayed real field per tick. Let B0 be additional one-time setup, Bs additional shared static storage per tick, and d an upper bound on additional per-sample recurring cost per tick. Let A_J and Q_J include the formation and per-query bounds for the declared finite panel depth J. Preserve any different actual dependence of these charges rather than fitting it into this convenient form.

The expected fine-minus-parent cost satisfies

\[
 {\mathbb E}(C_{\rm fine}-C_{\rm parent})
 >
 L\left[N(18c_w-d)-B_s\right]
   -B_0-N(A_J+KQ_J).
\]

A strictly positive right side licenses this particular representation/workload comparison. For fixed finite K,J and finite charges, a nonempty retention region exists if d<18c_w: first choose N with N(18c_w−d)>Bs, then choose

\[
 L>\frac{B_0+N(A_J+KQ_J)}
           {N(18c_w-d)-B_s}.
\]

These ticks are accounting units. Increasing L does not extend the native certified interval, create a physical clock, or describe an individual-state trajectory.

Accuracy is a separate simultaneous condition. Put c_R=min(R,2 exp(−1/2)). For a common advertised-information policy making K adaptive queries of one frozen draw, the retained theorem gives

\[
 {\rm TV}\le\min(1,0.494 K c_R).
\]

For a specified target epsilon<1, the sufficient condition is 0.494 K c_R≤epsilon. An explicitly independent collection of N complete transcripts has the conservative bound min(1,0.494 N K c_R). Requiring that stronger batch criterion restricts N as well as K and R; it cannot be combined with an unrestricted instruction to increase N. With fixed R,K, the accuracy upper limit and resource lower limit on N must contain a common positive integer.

If queries occur at a fixed rate, K approximately rho L, then their cost reduces the recurring saving to 18c_w−d−rho Q_J. For fixed R>0, the transcript-error certificate also puts an upper bound on L. The two bounds may have no overlap. Failure of this sufficient certificate does not prove the actual response error or actual cost is unacceptable. Optional caches likewise consume their own fields and setup work; they cannot improve the query charge without entering the storage calculation.

## What this settles

The expanded response interface has a constructive arithmetic price schedule and a nonempty conditional region in which both its per-draw accuracy guarantee and its total-cost inequality hold. Existing evidence and VFE gains along the native learner are shared with the fine implementation. They are not counted again as a formation benefit, and no RAM-to-nats conversion or conjectured pairwise-KL replacement is derived.

This remains a selection problem. For the original and historical first-cut response contract, forcing the P branch to merge while retaining its vector response port saves another four fields whenever the original panel would split, without changing those queries or native sufficiency. This comparison does not preserve statewise separate first-parent means. A fine algorithm allowed to emit the same sufficient carrier also contains the parent algorithm. Therefore the new inequality neither proves an operational optimum nor supplies a reason to stop at the intermediate level.

The full RG objective remains incomplete. The original fifteen exact negative heterogeneous admissions remain intact; fresh-data parity selection has not been executed. The missing external requirements are an operational loss/access/workload criterion and, if that experiment resumes, its fresh-confirmation protocol. The pending qualitative question about active feedback and recovery is separate from this completed frozen-response cost calculation. No additional trajectory, tighter coefficient, or larger graph is required by the result here.

The new arithmetic count passed once under pinned CPython 3.14.7 in 0.0147422 seconds. It read saved rational matrices and ran no producer, trajectory, or sampling routine. The [separate reconstruction](selected-hierarchy-response-cost-reconstruction.md) checks the calculation and mathematical scope. The [inspection receipt](evidence/selected-hierarchy-response-cost/inspection.json) records source bindings and preservation. No earlier scientific calculation was rerun; no data, active configuration, production source, vault manuscript, canonical checkout, or publication state was changed.

