# Conditional lag, parent forces, and the transient VFE

September 12, 2026. This lane belongs to contract `contract-sha256-b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c` in [the existing four-step record](evidence/2026-09-12-endogenous-dynamical-rg-goal/problem-contract.json). It supplies an entropy estimate for the actual common-mobility compact diffusion, with its coordinate-interface flux retained. It also supplies an exact Gaussian memory calculation as a second mechanism family. Neither calculation independently establishes a subsequent formation episode.

The principal result is an ordinary, dimensionless conditional-KL bound, not an inference from path distance. In the compact construction below, at fixed positive temperature and sufficiently large microscopic internal stiffness, an open class of smooth positive, initially shifted recognition densities has small conditional KL after an explicit initial layer. The force defect and the scaled VFE defect are then bounded separately. The initial shifts may place the two strong-edge residuals in `(1/4,1/3)`, as required by the formation lane. The proof includes entropy carried outside the convex fiber region and probability current across its boundary.

## 1. Target, sources, and additional assumptions

The user-supplied target is existential: one finite-dimensional, single-base-point normalized two-channel law/link model, an open parameter and initial-data regime, and a finite horizon must realize the four obligations in the contract. Peer agents use the same microscopic prescription; fixed interaction strengths are physical inputs, while a desired grouping or node-specific clock hierarchy is not an assumption. This document addresses the conditional-relaxation, force, and VFE obligation for every datum in the explicitly admitted class. It does not weaken the remaining formation and second-episode obligations.

The source starting point is [the microscopic construction](microscopic-vfe-dynamics-construction.md), Sections 3–7 and 10, together with [the parent bridge](dynamical-parent-rg-bridge.md), Sections 2–4 and 7.1–7.3, [its independent reconstruction](parent-independent-check.md), especially the transient-KL counterexample, and [the assembly](dynamical-rg-assembly.md). The [earlier Gaussian construction](../2026-09-11-fast-slow-derived-hierarchy/gaussian-hierarchy-construction.md), G3–G5, already has exact spectral-sector paths and mean-lag VFE terms; those are prior results, not new proposals here. [Theory/03](../../../Theory/03_probability.tex), [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), and [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex) fix the normalized-joint, correlated-recognition, and downward-kernel types.

The live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) was consulted at `sec:cross_scale_shadows`, `app:augmented_joint`, and `sec:meta_agent_rg`, including `eq:rg_slow_graph_metric` and `eq:rg_schur_flow`, alongside the [September research synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>). The source already distinguishes a predictive child prior from an expected-log variational message, and a graph pullback metric from a metric or Hessian Schur complement. Its independent force-closure obligation is preserved.

The added assumptions in the principal theorem are the compact cosine specialization, a constant common microscopic mobility, the primitive fast-residual chart supplied by the rates lane, positive smooth initial density relative to the actual invariant law, and explicit bounds on that density and its first derivative. The conditional convexity estimate is verified below inside a cube. No reflecting boundary is added to the actual dynamics. The proof uses a reflecting diffusion only as an auxiliary way to prove a functional inequality on the restricted reference measure. All chart-interface fluxes of the actual dynamics remain in the calculation.

The method has primary-source precedent in conditional-expectation coarse dynamics and entropy estimates; see [Legoll and Lelièvre, *Effective dynamics using conditional expectations*](https://arxiv.org/abs/0906.4865). Their paper does not identify a useful reaction coordinate for this model. The entropy balance, truncation accounting, initialization constants, and matrix specialization below are written out independently. The curvature-to-log-Sobolev semigroup argument is also stated explicitly; compare [Bakry and Émery, *Diffusions hypercontractives*](https://eudml.org/doc/113511). No priority or exhaustive-literature claim is made.

## 2. Joint law and exact parent objective

Let the complete microscopic configuration be `W`, with normalized population prior `P_0(dW)` and normalized generative evaluator `P_in(dK|W)`. The joint is

$$
P(dW,dK)=P_0(dW)P_{\rm in}(dK\mid W).
\tag{1}
$$

The declared inner recognition kernel is `R(dK|W)`, and outer recognition `Q(dW)` may be arbitrarily correlated. Assume `R(.|W) << P_in(.|W)` and set

$$
d(W)=\mathbb E_{R(\cdot\mid W)}
 \log\frac{dR(\cdot\mid W)}{dP_{\rm in}(\cdot\mid W)},
\qquad
\mathcal F_T(Q)=T\mathbb E_{QR}\log\frac{d(QR)}{dP}.
\tag{2}
$$

Here `T>0`; the ordinary VFE is `F_T/T`. Assume `d` is finite `P_0`-almost everywhere. Then `c=E_{P_0}exp(-d)` lies in `(0,1]`, and

$$
\Pi=c^{-1}e^{-d}P_0,
\qquad
\frac{\mathcal F_T(Q)}T=D(Q\Vert\Pi)-\log c.
\tag{3}
$$

These equalities follow by adding the conditional log-density ratios. Their extended version uses the nonnegative KL chain rule; all subsequent differentiations assume finite entropy and smooth positive densities. In the compact realization every displayed density is positive and smooth, and the bounded initial-density conditions below ensure the required integrability for every finite time.

For a fixed Borel retention `Y=C(W)`, let `P_1=C_#P_0` and

$$
d_1(y)=-\log\mathbb E_{P_0(\cdot\mid y)}e^{-d(W)},
\qquad
k_y(dW)=e^{-d(W)+d_1(y)}P_0(dW\mid y).
\tag{4}
$$

Thus `k_y=Pi(.|y)` is the recognition-optimal conditional. It is generally different from the genuine downward generative prior `P_0(.|y)`. If `r=C_#Q` and `h_y=Q(.|y)`, then

$$
\frac{\mathcal F_T(Q)}T
=D(r\Vert P_1)+\mathbb E_r d_1+\Delta(Q),
\qquad
\Delta(Q)=\mathbb E_r D(h_y\Vert k_y).
\tag{5}
$$

The generative parent evaluator integrates `P_in` against `P_0(.|y)`, not `k_y`. No mean-field product is used. The entire target of the following estimate is the last term of (5).

## 3. Coordinates and the actual compact operator

Let `w` be the angular configuration on a finite torus with normalized Haar measure. The path specialization has ten angular coordinates; the triangle has twelve. All microscopic angular coordinates obey

$$
dw_t=-\nabla U(w_t)dt+\sqrt{2T}dB_t,
\qquad
\Pi(dw)=Z^{-1}e^{-U(w)/T}dw.
\tag{6}
$$

The evaluator contribution `Td` is included in `U=U_0+Td`, as in (3); this does not replace `P_0` by the optimizer. Independent compact link marks that do not enter `U` may be retained with their inherited Brownian generators. They do not create a fast clock or a conditional force.

Write the five fast residuals as `B_f w`: three same-agent channel gaps and the two strong-edge channel mismatches. Write the `m_s` weak/cut residuals as `B_s w`, with `m_s=2` for the path and `m_s=4` for the triangle. The potential is

$$
U(w)=\sum_{j=1}^{r}K_j[1-\cos(B_fw)_j]
 +k\sum_{a=1}^{m_s}[1-\cos(B_sw)_a],
\quad r=5,
\quad K\le K_j\le K_+.
\tag{7}
$$

The strong-edge coefficients are `K`; the bridge coefficients may be `K+T` times a fixed evaluator coefficient. Hence `K_+=K+c_d T` is admitted with fixed `c_d>=0`. Every rate difference below comes from (7) and its inherited metric, not a node-rate multiplier.

Put

$$
C=B_fB_f^T,
\quad R=B_f^TC^{-1},
\quad P=I-RB_f,
\quad A=B_sR.
\tag{8}
$$

The rates lane supplies full row rank and primitivity of `B_f`. With principal residual `z in [-pi,pi)^r`, the Borel chart is

$$
z=\operatorname{principal}(B_fw),
\qquad y=w-Rz\in S_f:=\ker(B_f:\mathbb T^n\to\mathbb T^r).
\tag{9}
$$

Haar measure factorizes into normalized Haar on `S_f` and `dz/(2pi)^r`. Within the chart, `w=y+Rz`, the metric is the ambient tangent metric on `S_f` plus `dz^TC^{-1}dz`, and the mobility is `diag(I_{TS_f},C)`. Thus the actual local generator is

$$
L=T\Delta_y-\nabla_yU\cdot\nabla_y
 +T\operatorname{tr}(C\nabla_z^2)-(C\nabla_zU)\cdot\nabla_z,
\tag{10}
$$

where

$$
U(y,z)=\sum_jK_j(1-\cos z_j)
 +k\sum_a[1-\cos(B_sy+Az)_a].
\tag{11}
$$

The tangent gradient is `P` applied to the ambient angular gradient. Equation (10) is not a global diffusion with independent Neumann faces. At a principal cut, the two faces glue after shifting `y` by a period of `R`; this matters below. The Borel retained variable need not even have a continuous or cadlag sample path at repeated Brownian cut crossings. All global reduced-dynamics conclusions in this document concern one-time laws and smooth test functions. Path comparisons must use the formation lane's retained chart before exit, or a separately defined path carrier with its history.

For the path and triangle,

$$
\operatorname{spec}C=
\left\{2,2,3,\frac{5-\sqrt{17}}2,\frac{5+\sqrt{17}}2\right\}.
\tag{12}
$$

The exact matrices are recorded in [the rates calculation](evidence/endogenous-rates/matrix-results.json). This lane does not claim to reexecute that calculation. The required dependence is through the actual matrices in (8).

## 4. Entropy inside a convex fiber cube

Fix `0<rho<pi/2` and let `I=[-rho,rho]^r`. All integrals below use the factorized Haar reference. Write `q_t` and `pi` for the full joint densities in (9), and define the unnormalized marginals

$$
r_I(y)=\int_Iq_t(y,z)dz,
\quad p_I(y)=\int_I\pi(y,z)dz,
\quad h_I= q_t/r_I,
\quad k_I=\pi/p_I.
\tag{13}
$$

The notation `dz` in (13) and subsequent conditional integrals includes the factor `(2pi)^(-r)`. The conditional densities integrate to one on `I`; `r_I` and `p_I` need not have mass one. Define

$$
\Delta_I(t)=\int r_I(y)\mathbb E_{h_I(\cdot\mid y)}
                 \log\frac{h_I}{k_I}dy.
\tag{14}
$$

This is a weighted conditional entropy of the actual full density, not the entropy of a process killed, reflected, or reset at `partial I`.

Let

$$
m_h=K\cos\rho-k\|A\|^2>0,
\quad \lambda=\lambda_{\min}(C)m_h,
\quad
\Gamma=k\|C^{1/2}A^T\|\|B_sP\|.
\tag{15}
$$

Indeed

$$
\nabla_z^2U\succeq m_hI,
\qquad
\|C^{1/2}\nabla_z\nabla_yU\|\le\Gamma
\quad\hbox{on }S_f\times I.
\tag{16}
$$

For every smooth conditional density `h` on `I`,

$$
D(h\Vert k_I)\le\frac{T}{2\lambda}
 \mathbb E_h\left|\nabla_z\log(h/k_I)\right|_C^2.
\tag{17}
$$

Here is a hypothesis-matched proof of the functional inequality. Whiten the constant mobility by `z=C^(1/2)x`. The resulting domain is a convex parallelepiped and the potential Hessian is at least `lambda I`. For the auxiliary reflecting reversible generator `T Delta-grad U grad`, integration by parts gives `H'=-TJ` and

$$
J'=-2T\mathbb E_h\|\nabla^2\log(h/k_I)\|_F^2
 -2\mathbb E_h[\nabla\log(h/k_I)^T\nabla^2U\nabla\log(h/k_I)]
 +\text{nonpositive convex-boundary contribution}
\le-2\lambda J.
\tag{18}
$$

Integrating `H(0)=T integral_0^infty J(t)dt` gives (17). The limit of `H` is zero: the connected compact convex domain has a positive smooth invariant density and an elliptic reflecting semigroup; alternatively the gradient contraction from the same curvature calculation gives convergence of bounded Lipschitz densities to their invariant mean. Corners can be rounded by convex domains and the inequality passed to the limit for positive smooth densities. An alternative whole-space proof extends the strongly convex potential by the supremum of its supporting quadratic functions, adds a convex penalty for leaving the parallelepiped, smooths, and passes to the normalized restricted measure. Thus the auxiliary boundary construction supplies (17) for arbitrary densities on `I`; it imposes no boundary condition on the actual `q_t`.

Let `s_I=grad_y log k_I`. Differentiation under the fixed-domain conditional integral gives

$$
s_I=-T^{-1}(\nabla_yU-\mathbb E_{k_I}\nabla_yU),
\qquad \mathbb E_{k_I}s_I=0.
\tag{19}
$$

The entropy inequality (17) implies, for each unit tangent vector `v`,

$$
\log\mathbb E_{k_I}e^{a v\cdot s_I}
 \le\frac{a^2\sigma^2}{2},
\qquad \sigma^2=\frac{\Gamma^2}{T\lambda}.
\tag{20}
$$

To check the constant, apply (17) to the exponential tilt of `v.s_I`. Its gradient has `C`-norm at most `Gamma/T`. If `H(a)=log E exp(a v.s_I)`, the result is `a H'(a)-H(a)<=a^2 Gamma^2/(2T lambda)`; integrate after dividing by `a^2`, using `H(0)=H'(0)=0`. The elementary variational inequality `a E_hF<=D(h||k)+log E_k exp(aF)` follows from nonnegativity of KL to this exponential tilt. Optimizing in `a` and then in `v` gives

$$
\left|\mathbb E_hs_I\right|
 \le\sigma\sqrt{2D(h\Vert k_I)}.
\tag{21}
$$

This is where the weak interaction enters the entropy production estimate. Using only the fast Hessian, without controlling (19), would omit motion of the conditional target as `y` evolves.

## 5. Exact conditional entropy balance, including current

Put `f_t=q_t/pi`, `v=grad_y log f_t`, `a=grad_y log(r_I/p_I)`, and `e=E_{h_I}s_I`. Normalization gives `E_{h_I}v=a-e`. Define

$$
I_{y,I}=\int_{S_f\times I}q_t|\nabla_y\log f_t|^2,
\quad
I_{z,I}=\int_{S_f\times I}q_t|\nabla_z\log f_t|_C^2.
\tag{22}
$$

The actual forward current inside the chart is

$$
J_y=-T\pi\nabla_y f_t,
\qquad J_z=-T\pi C\nabla_z f_t.
\tag{23}
$$

Differentiate (14). The variation of its integrand is `log(h_I/k_I) delta q`; the two normalization derivatives cancel because `r_I=integral_I q`. Integration by parts yields exactly

$$
\begin{split}
\dot\Delta_I={}&-T I_{z,I}
 -T\int r_I\operatorname{Var}_{h_I}(v)
 +T\int r_I e\cdot\mathbb E_{h_I}v
 +\mathcal B_I(t),\\
\mathcal B_I(t)={}&-\int_{S_f\times\partial I}
             J_z\cdot n\log(h_I/k_I).
\end{split}
\tag{24}
$$

The boundary integral uses `dS/(2pi)^r` and the Euclidean cube normal. The variance is the squared tangent-norm variance. This formula includes the motion of the fiber target through (19). In particular, it is not the frozen-fiber identity `dot Delta=-T I_z`.

Apply (17), (21), Cauchy–Schwarz, and
`T sigma sqrt(2 Delta_I I_y,I)<=lambda Delta_I+T^2 sigma^2 I_y,I/(2lambda)` to obtain

$$
\dot\Delta_I
\le-\lambda\Delta_I
 +\frac{T\Gamma^2}{2\lambda^2}I_{y,I}
 +|\mathcal B_I(t)|.
\tag{25}
$$

For the autonomous full reversible diffusion,

$$
H(t):=D(Q_t\Vert\Pi),
\qquad
\dot H=-T\int q_t|\nabla_w\log f_t|^2,
\qquad
T\int_0^t I_{y,I}(s)ds\le H(0).
\tag{26}
$$

Therefore, for every `0<=t<=H_*`,

$$
\boxed{\Delta_I(t)
 \le e^{-\lambda t}\Delta_I(0)
 +\frac{\Gamma^2}{2\lambda^2}H(0)
 +\int_0^t e^{-\lambda(t-s)}|\mathcal B_I(s)|ds.}
\tag{27}
$$

This estimate does not require a hierarchy of microscopic mobilities. It is an entropy-production budget driven by the actual retained motion.

## 6. Global density and tail control

Assume the initial likelihood ratio on the complete angular torus obeys

$$
0<m\le f_0\le M<\infty,
\qquad \|\nabla_w f_0\|_\infty\le L_0,
\qquad \mathbb E_\Pi f_0=1.
\tag{28}
$$

Necessarily `m<=1<=M`. The reversible forward equation for the ratio is `partial_t f=Lf`. Positivity and preservation of constants give `m<=f_t<=M`. The stochastic-flow derivative satisfies `dot D_wW_t=-Hess U(W_t) D_wW_t`, so

$$
\|\nabla_w f_t\|_\infty\le L_0e^{Lt},
\qquad
L=K_+\|B_f\|^2+k\|B_s\|^2.
\tag{29}
$$

Differentiating the semigroup expectation proves this bound; smooth coefficients on the compact torus justify the differentiation. Retained, independent mark diffusions are sup-norm contractions and do not worsen the angular bound. The full entropy dissipation includes their additional nonnegative term.

Let `R_*=M/m` and

$$
L_\phi=\max\{|1+\log m|,|1+\log M|\},
\qquad
C_{\rm tail}=M\log R_*+2L_\phi(M-m).
\tag{30}
$$

The exact inside/outside chain rule gives `Delta=Delta_I+Delta_O+Delta_label`. It also gives

$$
0\le\Delta(t)-\Delta_I(t)
 \le C_{\rm tail}\Pi(I^c).
\tag{31}
$$

For verification, conditional averaging puts each of `f`, its inside mean, its outside mean, and its full-fiber mean in `[m,M]`. Thus `Delta_O<=M log(R_*) Pi(I^c)`. With `phi(u)=u log u`, the label term on a fiber is the Jensen gap
`p_I phi(f_I)+p_O phi(f_O)-phi(p_I f_I+p_O f_O)`. This is at most `2 p_O L_phi(M-m)` by the mean-value inequality. Integrating proves (31). This bound uses only one factor of `M`; the dependence on the possibly very small `m` is logarithmic.

For explicit normalizer bounds set

$$
a_0=\min\{1,\sqrt{T/K_+}\},
\qquad
Z_{\rm low}=(a_0/\pi)^r
 \exp[-r/2-2km_s/T].
\tag{32}
$$

Integrating over `|z_j|<=a_0` and all `y` proves `Z>=Z_low`, since `1-cos z<=z^2/2` and the weak potential is at most `2km_s`. On `I^c`, at least one fast term is at least `K(1-cos rho)`. Hence

$$
\Pi(I^c)\le Z_{\rm low}^{-1}
          e^{-K(1-\cos\rho)/T}=:E_\rho.
\tag{33}
$$

Inside the chart `C grad_z f=B_f grad_w f`. The total absolute normal flux on the cube faces consequently satisfies

$$
\int_{S_f\times\partial I}|J_z\cdot n|
 \le T L_0e^{Lt}c_\rho E_\rho,
\qquad
c_\rho=\frac1\pi(\rho/\pi)^{r-1}
                      \sum_{j=1}^r\sqrt{C_{jj}}.
\tag{34}
$$

The factor includes both faces in each coordinate and the normalized Haar surface measure. Since `h_I/k_I=f_t/(r_I/p_I)` lies between `1/R_*` and `R_*`, equations (24) and (34) imply

$$
|\mathcal B_I(t)|
 \le T L_0e^{Lt}c_\rho E_\rho\log R_*.
\tag{35}
$$

Combining all terms gives the principal bound

$$
\boxed{\begin{split}
\Delta(t)\le{}&e^{-\lambda t}\Delta_I(0)
 +\frac{\Gamma^2}{2\lambda^2}H(0)
 +C_{\rm tail}E_\rho\\
 &+T L_0c_\rho E_\rho\log R_*
        \frac{e^{Lt}-e^{-\lambda t}}{L+\lambda},
 \qquad 0\le t\le H_*.
\end{split}}
\tag{36}
$$

Every term is an ordinary conditional KL in nats. The boundary and tail terms are present even when the local deterministic trajectory never leaves its tube.

## 7. Shifted, positive-density initial laws and a common regime

The first formation episode requires strong-edge mismatch initially separated from zero. An equilibrium preparation is insufficient. Let `J_e` be the two strong-edge rows and choose shifts `a_j in (1/4,1/3)`. Define the globally smooth periodic function

$$
\Psi(w)=\sum_{j\in J_e}
 [\cos((B_fw)_j-a_j)-\cos((B_fw)_j)],
\qquad
\vartheta=2\sum_{j\in J_e}\sin(a_j/2)
 <4\sin(1/6).
\tag{37}
$$

For any fixed smooth function `G` with `0<g_-<=G<=g_+`, set

$$
f_0(w)=\frac{G(w)e^{K\Psi(w)/T}}
                 {\mathbb E_\Pi[G e^{K\Psi/T}]},
\qquad Q_0=f_0\Pi.
\tag{38}
$$

The two selected fast von Mises factors are shifted to `a_j`; all densities remain positive on the full configuration space. `G` can localize weak, collective, and retained-mark variables, but any quantitative concentration required by the episode proof must be checked for the chosen `G`. This entropy theorem does not infer that concentration from positivity alone.

The product Haar integral of the fast factors is unchanged by the two shifts. The weak factor is between `exp(-2km_s/T)` and one. Consequently

$$
g_-e^{-2km_s/T}
\le\mathbb E_\Pi[G e^{K\Psi/T}]
\le g_+e^{2km_s/T}.
\tag{39}
$$

In (28) one may therefore take

$$
M=\frac{g_+}{g_-}e^{2km_s/T+\vartheta K/T},
\qquad
m=\frac{g_-}{g_+}e^{-2km_s/T-\vartheta K/T},
\tag{40}
$$

and

$$
L_0\le M\left[\|\nabla\log G\|_\infty
 +\frac K T\sum_{j\in J_e}2\sin(a_j/2)\|(B_f)_{j,:}\|\right],
\qquad H(0)\le\log M.
\tag{41}
$$

All large factors in (30), (35), and (36) are a polynomial in `K/T` times a single `exp(vartheta K/T)`, with `k,T,G` fixed. No second such exponential arises from dividing by `m`.

Choose `rho=7/5`. Then

$$
b_\rho:=1-\cos(7/5)>4\sin(1/6)=:\vartheta_*.
\tag{42}
$$

For a specified finite horizon `H_*>0`, write `L=K ell_f+ell_0`, with `ell_f=||B_f||^2` and `ell_0=c_dT||B_f||^2+k||B_s||^2`. Fix `k>0`, a positive temperature satisfying

$$
0<T<\frac{b_\rho-\vartheta_*}{2\ell_fH_*},
\tag{43}
$$

and then increase `K`, retaining `K cos rho>k||A||^2`. The tail and boundary terms in (36) decay exponentially in `K`; all omitted prefactors are explicitly present in (30)–(41). For `t>=t_K=2 log K/lambda` and `K>1`,

$$
\sup_{t_K\le t\le H_*}\Delta(t)
 =O\left(\frac1{KT}+\frac{k^2}{KT}\right)+o(1),
\qquad K\to\infty,
\tag{44}
$$

where `k,T,H_*,G,rho` are fixed, `t_K<H_*` eventually, and constants depend on the displayed matrices. More precisely the first term of (36) is at most `H(0)/K^2`, while the second is `Gamma^2 H(0)/(2lambda^2)`. These exact expressions should be used instead of (44) when units or parameter comparisons matter. Strict inequalities and bounded `C^1` perturbations of positive `G` give an open admitted parameter/initial-density regime. Any requirement that the distribution overwhelmingly occupy the episode's initial configuration neighborhood remains the formation lane's separate check.

Thus the shifted initial data need not have small conditional entropy at time zero. Their `O(K/T)` initial entropy is explicitly relaxed. Fixed positive temperature is chosen once using the barrier/derivative-growth margin; small path error is never used to infer entropy. For `H_*=Hbar/k`, (43) is an explicit fixed relation between temperature, the weak coefficient, and the finite horizon.

## 8. Parent-force, interface, and VFE consequences

Let `k_y` now denote the full supported conditional on the principal cube, not `k_I`. The microscopic retained drift and its averaged value are

$$
b(y,z)=-kPB_s^T\sin(B_sy+Az),
\quad
\bar b(y)=\mathbb E_{k_y}b,
\quad
b_*:=k\|PB_s^T\|\sqrt{m_s}.
\tag{45}
$$

The exact conditional-integral potential is

$$
F_1(y)=-T\log\int_{[-\pi,\pi)^r}e^{-U(y,z)/T}\frac{dz}{(2\pi)^r},
\quad \bar b=-\nabla_yF_1,
\quad \bar L=T\Delta_y+\bar b\cdot\nabla_y.
\tag{46}
$$

This is inherited mobility on the tangent space, with the same native time and temperature. Its invariant density is `C_#Pi`, while its generative parent remains `P_1`. There is no new parent learning-rate factor.

For the actual recognition conditional `h_y`, define `delta b=E_{h_y}b-E_{k_y}b`. Boundedness of (45) and the KL/total-variation inequality give

$$
\boxed{\int r_t(y)|\delta b_t(y)|^2dy
       \le2b_*^2\Delta(t).}
\tag{47}
$$

For completeness the scalar inequality `D(h||k)>=2 TV(h,k)^2` follows by reducing to the event attaining the total variation and using the Bernoulli relative entropy's second derivative `1/[p(1-p)]>=4`. The vector expectation defect is at most `2b_* TV`; squaring and integrating gives (47).

The global `Y`-marginal additionally has a principal-cut source. For a smooth test function `phi` on `S_f`, integration of the actual forward equation yields

$$
\frac d{dt}\mathbb E\phi(Y_t)
 =\mathbb E[\bar L\phi(Y_t)]
 +\mathbb E[\delta b_t(Y_t)\cdot\nabla\phi(Y_t)]
 +\mathcal J_\phi(t).
\tag{48}
$$

The last term is the paired current through `z_j=+pi` and `z_j=-pi`, multiplied by the change in `phi` under the corresponding gluing shift of `y`. With

$$
c_\pi=\pi^{-1}\sum_j\sqrt{C_{jj}},
\qquad
\mathfrak j(t)=T L_0e^{Lt}c_\pi Z_{\rm low}^{-1}e^{-2K/T},
\tag{49}
$$

one has the conservative bound `|J_phi(t)|<=2||phi||_infty mathfrak j(t)`. It follows from exactly the face-current calculation (34), now at the principal cut. This retained term is required even though its bound is smaller than the internal localization term. No Markov jump process is asserted for the repeatedly discontinuous Borel coordinate.

Let `bar r_t` solve the autonomous averaged equation with initial law `r_0`. The Hessian identity obtained by differentiating (46) gives a drift Lipschitz bound

$$
L_1\le k\|B_sP\|^2+b_*^2/T.
\tag{50}
$$

Variation of constants against its backward semigroup and its gradient bound `||grad bar P_t phi||_infty<=exp(L_1t)||grad phi||_infty` give the one-time-law estimate

$$
\begin{split}
|\mathbb E_{r_t}\phi-\mathbb E_{\bar r_t}\phi|
\le{}&\sqrt2 b_*\|\nabla\phi\|_\infty
 \int_0^t e^{L_1(t-s)}\sqrt{\Delta(s)}ds\\
 &+2\|\phi\|_\infty\int_0^t\mathfrak j(s)ds.
\end{split}
\tag{51}
$$

The initial entropy layer is integrable: its square-root contribution is at most `2 sqrt(Delta_I(0))/lambda`, before the harmless finite-horizon factor. For the shifted family this tends to zero like `1/sqrt(KT)`. Equations (36) and (51) therefore give actual finite-horizon weak marginal control at fixed positive `T`, including the initial layer.

Finally define the exact parent objective on the actual retained recognition by

$$
\mathcal F_{1,T}(r)=T[D(r\Vert P_1)+\mathbb E_r d_1].
$$

Equation (5) and (36) give

$$
\boxed{\mathcal F_T(Q_t)-\mathcal F_{1,T}(r_t)=T\Delta(t),
\qquad
\mathcal F_T(Q_t)/T-\mathcal F_{1,T}(r_t)/T=\Delta(t).}
\tag{52}
$$

This controls the eliminated VFE contribution. Replacing `r_t` by `bar r_t` in the scalar objective requires an additional entropy-continuity estimate; weak marginal control (51) alone does not establish that replacement. Constants such as `-log c` are constant in the recognition block only when the generative/evaluator parameters are fixed.

## 9. Moving targets, recursion, and failure tests

The links in (6) are sampled coordinates of the same autonomous model. Their motion is already included in the joint equation and in the retained score (19). It does not constitute externally prescribed time dependence of `Pi`.

If a structural parameter changes the target to `pi_t`, the exact additional term in (24) is

$$
-\int r_I(y)\mathbb E_{h_I}\partial_t\log k_{I,t}(z\mid y)dy.
\tag{53}
$$

The conditional reference average of `partial_t log k_I` is zero. A sub-Gaussian score bound therefore controls (53) by `tau_t sqrt(2Delta_I)`; without such a bound it remains a retained term. The total entropy budget (26) also becomes `H'=-TI-E_Q partial_t log pi_t`. A moving retention map introduces its transformed advection, Jacobian, and possibly mixed mobility in addition. Equations (25)–(44) are not asserted unchanged in either situation.

For compatible static retentions `Y=C(W)` and `Z=D(Y)`, the exact tower calculation gives

$$
\Delta_{02}(Q)=\Delta_{01}(Q)+\Delta_{12}(C_\#Q),
\tag{54}
$$

using the optimizer's respective conditional kernels. The ordinary and scaled VFE costs add with factors one and `T`. A second application of the entropy theorem must use the actual inherited potential and operator, its current initial law, and the first-stage force/interface perturbation if the actual marginal is used. Treating the first marginal as if it were exactly the autonomous averaged diffusion would omit (47)–(49). The rates and episode lanes must provide that second interface, or apply a direct joint estimate that controls both residuals. Equation (54) alone is not a second dynamical episode.

The principal theorem fails to license a reduction if `m_h<=0`, the initial density/gradient constants are unavailable, the barrier margin in (43) is nonpositive, an additional learned target varies without (53), or the actual transformed mobility contains unaccounted mixed terms. A local Hessian at one point is insufficient for (16). A small exit probability is insufficient for (31) or (35). A singular Dirac preparation violates (28) and has infinite positive-temperature KL. Finally, the theorem does not claim uniformity as `T` tends to zero at fixed `K`: a Gaussian hidden mean displacement `epsilon` with conditional covariance `T` has conditional KL `epsilon^2/(2T)`.

## 10. Second mechanism: an exact Gaussian retained memory

This is an alternative conditional model, not a proof for the compact nonlinear system. Let `x=(y,z)` on Euclidean space and take a proper quadratic effective potential with

$$
U(y,z)=\tfrac12 y^TH_{yy}y+y^TBz+\tfrac12z^TDz,
\quad
\mathsf H=\begin{pmatrix}H_{yy}&B\\B^T&D\end{pmatrix}\succ0,
\quad D\succeq d_*I>0.
\tag{55}
$$

The common microscopic mobility is the identity. A normalized two-channel Gaussian evaluator can be appended as in the microscopic source, with its quadratic cost included in `U`; alternatively any specified nonnegative quadratic `d` with `U-Td` positive definite gives the normalized baseline `P_0 proportional exp[-(U-Td)/T]`. The augmented joint then has exactly (1)–(5). All references are Lebesgue, and positive-definite Gaussian initial covariance gives absolute continuity and finite entropy.

The fine process satisfies

$$
dy_t=-(H_{yy}y_t+Bz_t)dt+\sqrt{2T}dW_t^y,
\quad
dz_t=-(B^Ty_t+Dz_t)dt+\sqrt{2T}dW_t^z.
\tag{56}
$$

Solving the second linear equation, with the actual initial `z_0`, gives the exact retained generalized Langevin equation

$$
\begin{split}
dy_t={}&\left[-H_{yy}y_t-B e^{-Dt}z_0
 +\int_0^t B e^{-D(t-s)}B^Ty_sds\right]dt\\
 &-\sqrt{2T}B\left[\int_0^t e^{-D(t-s)}dW_s^z\right]dt
 +\sqrt{2T}dW_t^y.
\end{split}
\tag{57}
$$

The memory kernel, colored noise, and initial hidden law are inherited. There is no independently assigned parent rate, no substitution of an equilibrium hidden sample, and no remainder in (57). The invariant conditional is
`k_y=N(-D^(-1)B^T y,T D^(-1))`; the invariant parent precision is the Hessian Schur complement `S=H_yy-BD^(-1)B^T`. A static marginal with precision `S` does not remove the memory in (57).

For a Gaussian recognition with mean `m=(m_y,m_z)` and covariance blocks `Sigma`, let

$$
C_q=\Sigma_{zy}\Sigma_{yy}^{-1},
\quad V_q=\Sigma_{zz}-\Sigma_{zy}\Sigma_{yy}^{-1}\Sigma_{yz},
\quad E_q=C_q+D^{-1}B^T,
\quad h_m=m_z+D^{-1}B^Tm_y.
$$

Direct expectation of the two Gaussian log densities yields

$$
\begin{split}
2\Delta={}&T^{-1}\operatorname{tr}(DV_q)-\dim z
 +\log\frac{\det(TD^{-1})}{\det V_q}\\
 &+T^{-1}\left[h_m^TDh_m+
              \operatorname{tr}(D E_q\Sigma_{yy}E_q^T)\right].
\end{split}
\tag{58}
$$

The exact retained calculation of this scalar uses

$$
\dot m=-\mathsf Hm,
\qquad
\dot\Sigma=-\mathsf H\Sigma-\Sigma\mathsf H+2TI.
\tag{59}
$$

Retaining these moments is a complete Gaussian memory representation, with zero dynamical or VFE remainder; it is not a dimension-saving theorem. If only the path-memory convolution is truncated to a lookback `tau`, while the colored noise and initialization are kept, the omitted force obeys

$$
\left|\int_0^{(t-\tau)_+}B e^{-D(t-s)}B^Ty_sds\right|
 \le\frac{\|B\|^2}{d_*}e^{-d_*\tau}
            \sup_{s\le t}|y_s|.
\tag{60}
$$

For the same noises, a Volterra Gronwall bound gives a path error at most `H_* exp[(||H_yy||+||B||^2/d_*)H_*]` times the supremum of the right side of (60). This is a force/path truncation estimate only. It supplies no entropy bound for a non-Gaussian or truncated recognition family, and discarding the colored noise would introduce another term. The exact scalar check with `B=0`, stationary hidden covariance `TD^(-1)`, and hidden mean `h_m(t)=exp(-Dt)h_m(0)` reduces (58) to `Delta(t)=h_m(t)^TDh_m(t)/(2T)`, recovering the earlier spectral-sector special case with its correct temperature factor.

## 11. Result, open interface, and evidence

The new artifact is (36), with the explicit shifted initialization (37)–(43), and its consequences (47), (51), and (52). It bounds full positive-temperature conditional KL for the actual compact process, including off-cube entropy and coordinate-interface current. It derives the fast relaxation constant from `C` and the internal potential, and the target-motion forcing from the weak mixed Hessian. This is stronger than the previous temperature-last path comparison and does not reuse it as entropy evidence.

The remaining interface is to join the episode lane's positive-density initial neighborhood and its actual first/second retention maps to these hypotheses, and then propagate the first-stage force and interface defects into the second inherited dynamics. This document does not close the full contract by judgment. The Gaussian alternative (57)–(59) has exact retained dynamical and VFE corrections but has no nonlinear two-episode claim.

The novelty fingerprint relative to the cited local records is: conditional entropy of an unnormalized convex-fiber restriction; an exact boundary-current term; a one-`M` bound for the discarded conditional/label entropy; and a shifted von Mises initialization whose exponential cost is dominated by the same model's barrier at fixed positive temperature. The classical ingredients are KL disintegration, logarithmic Sobolev dissipation, the exponential-tilt bound, and linear Gaussian elimination.

Only this document and [the lane evidence directory](evidence/conditional-lag/) are owned by this lane. The mathematical proof is the displayed derivation. The tiny standard-library calculation recorded there evaluates the explicit trigonometric margin and matrix constants; it does not prove the theorem. No full suite, trajectory experiment, GPU job, Lean construction, tamper check, historical rerun, Research-vault edit, or ledger closure was performed.
