# Gaussian GL(K) alignment, retained holonomy, and regular parent closure

September 11, 2026. This continues [the normalized agreement-record construction](normalized-alignment-parent-limit.md) at one fixed base point c_*. It replaces that example's translation action by the actual linear GL(K) action on nondegenerate Gaussian law points. Independent links remain random coordinates of the complete state. A regular coherent sector admits a proper limiting parent with its based loop marks, inherited cut records, evidence factor, and limiting Fisher inference. The marked parent class composes at any fixed admitted finite depth.

This is a conditional construction on stated regular regions. A centered Gaussian can carry more link symmetries than a nonzero-mean Gaussian; some centered configurations are regular and some are singular. An explicit noncommuting example has different normal ranks on neighboring aligned regions. Its unrestricted strong-record integral is not covered by one regular Hessian determinant. The unresolved singular integral, endogenous block choice, finite-strength closure, structural-parameter learning, and measured complete-interface savings remain separate obligations.

## 1. Source, conventions, and normalized model

[Theory/07c_full_graph_meta_agent_vfe.tex](../../../Theory/07c_full_graph_meta_agent_vfe.tex), Section `sec:full-graph-vfe-nonflat`, already retains rooted tree transports, based holonomies, and dressed boundary edges. It explicitly permits nonidentity holonomy when the compared law is stabilized. [Theory/09_coarsegraining.tex](../../../Theory/09_coarsegraining.tex), `cor:cg-compact-holonomy-barycenter`, already treats Gaussian laws stabilized by compact-closure holonomy. Those are prior results; the contribution here is the coherent-set rank, fluctuation measure, and its admission to the normalized alignment dynamics.

Let G=GL(K,R), let s_K=K(K+1)/2, and let d_K=K+s_K be the dimension of the Gaussian law manifold. A sample of the complete state contains

\[
 b_i=\mathcal N(\mu_i,\Sigma_i),\quad \Sigma_i\succ0,
 \qquad \Theta_e\in G,\quad e:j\longrightarrow i.
 \tag{1}
\]

Use the left action g#b=N(g mu,g Sigma g^T). Under a passive coordinate change A_i, b_i'=A_i#b_i and Theta_ij'=A_i Theta_ij A_j^{-1}. This is the source's convention with A_i=a_i^{-1}. Every edge copy is separate; opposite orientations are inverse only when they denote traversal of the same geometric edge. Extra parallel or directed edge copies remain independent variables.

Write W for these coordinates and any declared interfaces, and Q for recognition over W. In particular, b_i is a Gaussian law point sampled inside W; it is not the i-th marginal of Q. Take a proper smooth prior density p_0 on W and a fixed selected likelihood L_0. The reference density is rho_0=p_0 L_0. Positive edge weights w_e and binary kernels K_e(1|W)=exp[-w_e D_e(W)], K_e(0|W)=1-K_e(1|W), with

\[
 D_e=\frac12\left[
 \operatorname{tr}(T_e^{-1}\Sigma_i)
 +(\mu_i-\Theta_e\mu_j)^\top T_e^{-1}(\mu_i-\Theta_e\mu_j)
 -K+\log\frac{\det T_e}{\det\Sigma_i}\right],
 \quad T_e=\Theta_e\Sigma_j\Theta_e^\top,
 \quad D=\sum_e w_eD_e.
 \tag{2}
\]

These are the existing normalized agreement records. Conditioning on n successes for each internal edge gives the observed slice rho_0 exp(-nD), with evidence Z_n=integral rho_0 exp(-nD). No data are asserted to have been observed. The Gaussian formula follows by taking the expectation of the log density ratio; it uses invertible links and SPD covariances. The same pushforward and KL conventions are explicit in the live PIFB2 manuscript's `thm:glk_invariance`; no manuscript is edited here.

The prior is proper and is pushed with the coordinates. No invariant Haar probability on GL(K) is presumed. All group statements below concern the action on law points at c_*, not transport along the base manifold.

## 2. The coherent set and the surviving symmetries

Put r_i=Sigma_i^{-1/2} mu_i and O_e=Sigma_i^{-1/2} Theta_e Sigma_j^{1/2}. Equation (2) vanishes exactly when the two compared Gaussians are equal, so

\[
 D_e=0\quad\Longleftrightarrow\quad
 O_e\in O(K),\qquad r_i=O_e r_j.
 \tag{3}
\]

Consequently, on a connected coherent block all Mahalanobis radii rho_i=||r_i|| agree. Conversely, equal radii permit an orthogonal map between every pair of whitened means, hence a choice of each required invertible link. This is a feasibility statement for free links, not an assertion that every prior assigns positive density to those choices.

The radius is a complete invariant of a single Gaussian under the full GL(K) action. To prove this, whiten its covariance and rotate its whitened mean onto rho e_1. Thus a representative is N(rho e_1,I), and its stabilizer is

\[
 \operatorname{Stab}(b)
 =\Sigma^{1/2}\{O\in O(K):Or=r\}\Sigma^{-1/2},
 \qquad
 h_+=\frac{(K-1)(K-2)}2\quad(\rho>0),
 \qquad h_0=\frac{K(K-1)}2\quad(\rho=0).
 \tag{4}
\]

For rho>0 the group in braces is isomorphic to O(K-1); for rho=0 it is O(K). The dimensions are local manifold dimensions and do not erase disconnected components. These compact stabilizers are derived at a law state; the original free-link domain remains GL(K). Compactness up to conjugacy does not give a uniform Euclidean matrix bound over degenerating covariances.

Choose a fixed rooted spanning tree of a connected block with N vertices and E internal edge copies; beta=E-N+1 is its cycle rank. Let g_i be the ordered tree transport from the root to i, with g_root=I. For an internal edge define H_e=g_i^{-1} Theta_e g_j. The tree marks equal I by construction. For the beta non-tree copies, the coherent set is parameterized exactly by

\[
 b_i=(g_i)_\#b,\qquad
 \Theta_e=g_iH_eg_j^{-1},\qquad
 H_e\in\operatorname{Stab}(b),
 \qquad g_i\in G\quad(i\ne\mathrm{root}).
 \tag{5}
\]

Given the original configuration, the tree products determine every g_i uniquely. Conversely, these coordinates reconstruct all its laws and links. They do not identify configurations related by a gauge change. No link is replaced by a frame coboundary: only tree links have that form, while every non-tree H_e remains present.

For rho>0 the stabilizer family is a smooth bundle locally conjugate to O(K-1). Local smooth choices follow by whitening and choosing a smooth orthogonal completion of the unit mean direction in a sphere chart. Charts, not a global frame on the sphere, suffice. It follows from (5) that the nonzero-mean coherent set M_+ is a smooth embedded manifold with

\[
 \dim M_+=d_K+(N-1)K^2+\beta h_+,
 \qquad
 d_\perp^+=(N-1)d_K+\beta(d_K-1)
             =E(d_K-1)+N-1.
 \tag{6}
\]

The ambient dimension is N d_K+E K^2. A loop product belongs to Stab(b), so it can be nonidentity and noncommuting with another loop. Equality of law points does not imply equality of all vectors in their sample space.

## 3. The full normal Hessian, including link variations

At a coherent point use fixed coordinate changes to put every law at N(u,I), and every link at an orthogonal H_e fixing u. This can always be done using (5) and a whitening map at the root. Write the infinitesimal link variation as delta Theta_e=X_e H_e. All matrices X_e are independently variable in gl(K). Define

\[
 v_e=\delta\mu_i-H_e\delta\mu_j-X_eu,
 \qquad
 S_e=\delta\Sigma_i-H_e\delta\Sigma_jH_e^\top-X_e-X_e^\top.
 \tag{7}
\]

Differentiating the transported mean and covariance gives these residuals. The second-order Gaussian KL at equality is the Fisher quadratic form, hence

\[
 D(W+\delta W)=\frac12\sum_e w_e
       \left[\|v_e\|^2+\frac12\operatorname{tr}(S_e^2)\right]
       +O(\|\delta W\|^3).
 \tag{8}
\]

For example, the covariance term follows by expanding log det(I+S) to second order, and the mean term is one half the squared whitened mismatch. The symmetric Frobenius form is positive definite, including its off-diagonal multiplicities. Thus the full Hessian has exactly the rank of the linear residual map in (7). This avoids inferring a rank from a fixed-link or mean-only Hessian.

For u=rho e_1 with rho>0, the infinitesimal action X -> (Xu,X+X^T) has rank d_K-1. Indeed, the derivative of the radius is delta mu_1-(rho/2) delta Sigma_11, which vanishes on this image. Conversely, for a pair (v,S) with v_1=rho S_11/2, set the symmetric part of X to S/2 and choose X's skew entries in its first column so that Xu=v. The remaining skew entries on e_1's orthogonal complement form a kernel of dimension h_+.

Tree residual equations solve each child's law tangent successively in terms of the root tangent and tree-link tangents, imposing (N-1)d_K independent conditions. At each non-tree edge, variation of its own X_e maps onto the orbit tangent of dimension d_K-1. The residual contributed by varying the root law belongs to that same tangent: the stabilizer preserves the radius, so its tangent action is the identity on the one-dimensional orbit-invariant quotient. Each non-tree edge therefore adds exactly d_K-1 independent conditions and leaves h_+ link directions. This proves that the kernel of the Hessian is precisely T M_+, and proves (6) by linearization as well as parameter counting. Its restriction to any normal complement is positive definite.

The same argument gives a reusable conditional statement. If a smooth finite-dimensional law family of dimension d has positive Fisher metric, a G-action with dimension g, and a smooth constant-orbit-type stabilizer bundle of dimension h, then the corresponding regular coherent block has

\[
 \dim M=d+(N-1)g+\beta h,
 \qquad d_\perp=(N-1)d+\beta(g-h).
 \tag{9}
\]

Here one assumes a smooth local orbit quotient whose fibers are the orbits. This supplies the tangent-quotient step used above; a constant number written for h alone is insufficient. The statement concerns freely variable group links in that action and does not apply unchanged to tied links or a representation with additional constraints.

## 4. Centered sectors and a genuine singular junction

A centered aligned configuration can again be whitened so every law is N(0,I) and every link is orthogonal. Let

\[
 f=\dim\bigcap_{\ell=1}^{\beta}\ker(I-H_\ell).
 \tag{10}
\]

For a tree the intersection is the entire K-dimensional root space. At u=0 the mean residual in (7) is delta mu_i-H_e delta mu_j; its kernel consists of tree-parallel means whose root belongs to that common fixed space. Its rank is N K-f. The covariance residual has rank E s_K because each edge's independent symmetric X_e can realize any symmetric residual. The two residual blocks do not couple at u=0. Therefore

\[
 \operatorname{rank}\nabla^2D\big|_{\mu=0}
       =E s_K+N K-f.
 \tag{11}
\]

If f=0, injectivity of the stacked root map is open in the based orthogonal marks. Every nearby coherent mean must then be zero. The local coherent set is the smooth centered component M_0, parameterized by an SPD root covariance, arbitrary tree frames, and beta orthogonal root marks. It has

\[
 \dim M_0=s_K+(N-1)K^2+\beta h_0
          =N s_K+E h_0,
 \qquad d_\perp^0=E s_K+N K.
 \tag{12}
\]

The Hessian kernel has exactly this dimension, so this centered component has a positive normal Hessian. Centered does not automatically mean singular. Conversely, f>0 is a warning that needs a local analysis. A tree is smooth through zero mean, and a planar reflection with its persistent fixed line can also be smooth there; equation (11) alone does not classify every case.

A concrete singular example uses K=3, N=3, E=4, with two tree edges equal to I and the two non-tree marks

\[
 H_1=\begin{pmatrix}1&0&0\\0&-1&0\\0&0&1\end{pmatrix},
 \qquad
 H_2=\begin{pmatrix}1&0&0\\0&0&-1\\0&1&0\end{pmatrix}.
 \tag{13}
\]

They are orthogonal, do not commute, and have common fixed space span(e_1). With any u=rho e_1, rho>0, the Hessian rank is 34 by (6). At u=0 with the same marks it is 32 by (11). Conjugating H_1 by a sufficiently small nonzero rotation in the e_1,e_2 plane makes it fail to fix e_1; H_2's fixed space is still span(e_1), so the common fixed space is zero. Those centered nearby configurations have rank 33 and are clean by (12). The junction therefore has no neighborhood on which one constant-rank normal Hessian theorem applies.

For these clean regions, the geometry and prospective intrinsic parent dimensions differ:

| K=3, N=3, E=4 region | Ambient dimension | Coherent dimension | Normal codimension | Root-law plus two-loop dimension after tree-frame integration |
| --- | --- | --- | --- | --- |
| Nonzero common radius | 63 | 29 | 34 | 11 |
| Centered, no common fixed vector | 63 | 30 | 33 | 12 |

The entries count continuous coordinates and retain disconnected mark components separately. They do not count an arbitrary correlated density's parameters, numerical chart overhead, or evaluator/reconstruction storage. In particular, a smaller Gaussian mean sector can coexist with a larger surviving holonomy sector.

## 5. The regular fluctuation measure and its normalization

Here is the exact analytic admission used for a parent limit. On the finite-dimensional ambient configuration manifold, choose smooth coordinates and a reference volume. Assume rho_0 is continuous, nonnegative, compactly supported inside the domain of SPD covariances and invertible links. Every zero of D relevant to that support lies in a smooth coherent manifold M of one codimension d_perp, separated from rank-changing points, and its normal Hessian H_perp is positive definite. Assume the coherent integral below is positive. Compactness makes its normal eigenvalue lower bound uniform. Noncompact priors require a separate uniform tail argument; none is inferred from properness alone.

With Euclidean coordinates, H_perp means the Hessian restricted to an orthonormal normal frame and dvol_M is induced Euclidean surface measure. Define

\[
 \nu_0(dW)=\frac{\rho_0(W)}{\sqrt{\det H_\perp(W)}}d\operatorname{vol}_M(W),
 \qquad I_{\rm obs}=\int_M\nu_0(dW).
 \tag{14}
\]

The formula is a measure, not just a restriction of the old density. In a general chart with normal coordinates y and coherent coordinates z it contains the full Jacobian at y=0 divided by sqrt(det Hess_y D). Arbitrarily taking a nonzero principal minor of the ambient Hessian without the corresponding coordinate Jacobian would give the wrong measure.

Under this admission,

\[
 Z_n=(2\pi/n)^{d_\perp/2}[I_{\rm obs}+o(1)],
 \qquad \Pi_n\Rightarrow I_{\rm obs}^{-1}\nu_0,
 \qquad \mathbb E_{\Pi_n}D=\frac{d_\perp}{2n}+o(n^{-1}).
 \tag{15}
\]

This is the classical Laplace integral over a smooth minimum manifold; [Hashorva, Korshunov, and Piterbarg (2015), Theorem 3](https://api.unil.ch/iris/server/api/core/bitstreams/6ce1a9d2-fd62-4b96-bd61-29d1f4fa39df/content) gives the normal-Hessian leading coefficient. The present hypotheses supply its action gap away from M, compact localization, and nondegenerate normal directions.

For completeness, the leading argument is direct. Cover the relevant compact part of M by finitely many tubular charts and use a partition of unity. In each chart D(z,y)=y^T H_y(z)y/2+O(||y||^3), uniformly, and D>=c||y||^2 for small y. Substitute y=xi/sqrt(n). The rescaled integrand is dominated by an integrable Gaussian in xi, while its limit is rho_0(z,0) times the chart Jacobian and exp[-xi^T H_y(z)xi/2]. The Gaussian integral gives (14). Outside the tubular region compactness and the absence of other zeros give a positive action gap, so that contribution is exponentially small. Inserting nD uses nD exp(-nD)<=C exp(-nD/2) and the same bound; the limiting Gaussian quadratic moment is d_perp/2. This proves all the displayed constants. Marginalizing the normal coordinates also proves L1 convergence of the densities on M after tubular retraction.

A passive change of coordinates pushes both the prior measure and D. The original integral is unchanged, so its leading measure is pushed as well. This proves covariance of (14) with its volume and determinant factors together; neither a Euclidean surface measure nor the determinant alone is a gauge invariant.

If the prior is supported in finitely many separated regular regions of codimensions d_j, add their contributions before normalizing:

\[
 Z_n\sim\sum_{j:\ d_j=d_{\min}}(2\pi/n)^{d_{\min}/2}I_j,
 \qquad d_{\min}=\min_{I_j>0}d_j.
 \tag{16}
\]

Regions with larger codimension receive vanishing posterior weight in this specified separated-support experiment. For the two clean regions in the table, the centered one contributes n^{-33/2} and the nonzero-mean one n^{-17}. This comparison is not an asymptotic theorem for a prior also charging their singular junction. Extra powers or logarithms there require their own integral calculation; a zero prior probability of the singular set does not justify neglecting its neighborhoods.

## 6. The marked parent and its retained observations

For a fixed partition into connected blocks I, retain the root law b_I, every based non-tree loop mark H_{I,ell}, and every dressed cut-edge copy

\[
 V_e=g_i^{-1}\Theta_e g_j,
 \qquad e:j\in J\longrightarrow i\in I.
 \tag{17}
\]

Here g_i maps the root of I to i, and g_j maps the root of J to j. Denote this complete marked coarse map on M by C_M. Internal tree frames g_i may be integrated out only when the required remaining record kernels and model evaluators factor through C_M, together with any explicitly retained additional marks. By common-pushforward invariance of KL,

\[
 D_e(b_i,(\Theta_e)_\#b_j)
 =\mathrm{KL}(b_I\Vert(V_e)_\#b_J)
 \quad\text{on }M.
 \tag{18}
\]

Thus all cut agreement records factor exactly. Their edge copies, directions, weights, and outcomes remain present. Root-framed holonomy observations also factor, because every loop mark is kept. A child's untransformed mean, a particular internal frame, or a different evaluator may not factor; its frame or full induced conditional kernel must then remain in the interface. No minimum over trees or averaging of cut matrices is inserted.

Under the passive changes of Section 1,

\[
 b_I'=(A_{r_I})_\#b_I,\quad
 H_{I,\ell}'=A_{r_I}H_{I,\ell}A_{r_I}^{-1},\quad
 V_e'=A_{r_I}V_eA_{r_J}^{-1}.
 \tag{19}
\]

The rooted tree formulas prove these by cancellation of intermediate matrices. A different tree gives another description related by products of retained holonomies; the existence of this coordinate change does not authorize deleting those holonomies.

Apply (14) first with rho_0=p_0, before compatible observations, and call the measure nu_prior and its mass I_0. The normalized parent prior and its evidence relation are

\[
 \bar P_0=(C_M)_\#\nu_{\rm prior}/I_0,
 \qquad
 p_n(o,\mathbf1)=(2\pi/n)^{d_\perp/2}I_0\bar p(o)[1+o(1)].
 \tag{20}
\]

Appending all inherited normalized record kernels produces a normalized parent joint. In general its prior is a correlated density on a manifold of Gaussian law points and stabilizing loop marks. It is not Gaussian on all matrix entries, and no matrix-entry Gaussian ansatz closure is claimed.

There is a convergence distinction absent from the unmarked translation example. The finite-strength raw rooted marks need not stabilize the root law. Their pushforward can be absolutely continuous in the ambient mark space while its limiting law is supported on the lower-dimensional stabilization constraints. In that case their total-variation distance from the limiting law is one. Weak convergence of the raw marks does not become total-variation convergence by naming them a parent.

To compare densities on the admitted parent space, choose a smooth tubular retraction R onto M near the relevant support and set C_tube=C_M composed with R. Extend it measurably outside that neighborhood; the extension has exponentially small posterior weight. The preceding proof gives

\[
 (C_{\rm tube})_\#\Pi_n
       \longrightarrow(C_M)_\#\nu_0/I_{\rm obs}
       \quad\text{in total variation}.
 \tag{21}
\]

The retraction is an explicit finite-strength approximation. Distinct admitted retractions agree on M and have the same limit. Under a passive coordinate change push the chosen retraction with the coordinates; a coordinate-dependent nearest-point rule is not silently declared gauge invariant.

If a required normalized record kernel differs from its coherent value by at most L dist(W,M) in total variation on the compact admitted region, then the joint prediction error, using the same retracted finite-strength parent prior on both sides, is bounded by

\[
 L\mathbb E_{\Pi_n}\operatorname{dist}(W,M)
 \le L\sqrt{\mathbb E_{\Pi_n}D/c}=O(n^{-1/2}).
 \tag{22}
\]

The action gap lets c be chosen over the full compact support. Replacing the finite parent prior by its limit adds the total-variation error in (21). This is an observation-law bound under a stated regularity condition, not total-variation convergence of raw singularly collapsing state coordinates. Uniformly Lipschitz static-latent record sequences admit the corresponding finite-horizon telescoping bound. Arbitrary latent transitions or horizons are not included.

## 7. Parent inference and fine VFE accounting

Use full-law Fisher inference toward Pi_n with initial recognition proportional to rho_0 f(C_tube(W)), where f is continuous on the parent space and bounded above and below by positive constants. As in the previous derivation, with a=exp(-t) and kappa=n(1-a), the exact complete-state law is

\[
 Q_{n,t}(dW)\propto\rho_0(W)f(C_{\rm tube}(W))^a
          e^{-\kappa D(W)}dW.
 \tag{23}
\]

This is joint posterior inference of the random law and link coordinates. No deterministic structural-link gradient is substituted for it. Let nu_eff=(C_M)#nu_0 on the observed slice and pi_eff=nu_eff/I_obs. For each fixed t>0 the retracted parent law converges in total variation to

\[
 r_t(dx)=\frac{f(x)^a\nu_{\rm eff}(dx)}{\int f^a d\nu_{\rm eff}},
 \qquad
 \dot r_t=-r_t\left[\log\frac{dr_t}{d\pi_{\rm eff}}
       -\mathbb E_{r_t}\log\frac{dr_t}{d\pi_{\rm eff}}\right].
 \tag{24}
\]

The same uniform domination proves convergence on compact time intervals bounded away from zero. The equation follows by differentiating a log f and centering its expectation. The initial parent after the layer is proportional to f nu_eff, which need not equal the pushforward of the original initial recognition. No uniform statement at t=0 or arbitrary initial hidden conditional is made.

The compact regular normal integral retains exactly the same scalar correction as the translation calculation. With c_n=(d_perp/2)log[n/(2pi)],

\[
 \mathcal F_n(Q_{n,t})-c_n
 \longrightarrow
 \mathrm{KL}(r_t\Vert\pi_{\rm eff})-\log I_{\rm obs}
 +\frac{d_\perp}{2}\left[\frac{a}{1-a}+\log(1-a)\right].
 \tag{25}
\]

To check the constants, log[Q/(rho_0 exp(-nD))]=a log f+(n-kappa)D-log Z_{kappa,a}. Its expectation uses E D=d_perp/(2kappa)+o(kappa^{-1}) and Z_{kappa,a}=(2pi/kappa)^{d_perp/2}[integral f^a dnu_eff+o(1)]. Substitution gives (25). For the normalized parent model in (20), the first two terms equal its VFE minus log I_0. The normal correction is nonnegative and has derivative -(d_perp/2)a^2/(1-a)^2. It accounts for discarded inference modes; it is not zero at finite positive t.

Starting with f=1 also retains the exact monotonicity d E[D]/d kappa=-Var(D) from the preceding construction. Finite-strength exact alignment still has zero probability for an ambient absolutely continuous prior. Compatible subsequent observations in the limiting model preserve its coherent support. Their likelihoods factor through C_M, so the conditional law of discarded tree frames given the complete parent is unchanged. Recognition lifted with that conditional has the exact KL-chain equality and parent Fisher closure from [the conditional-parent calculation](pointwise-learning-parent-closure.md).

## 8. Recursive closure with inherited holonomy marks

The regular nonzero-radius parent class consists of Gaussian law points, finitely many internal based marks stabilizing each law, freely variable cut links, a proper correlated prior, and normalized record kernels with their declared interfaces. Its local node-state projection onto the Gaussian law is a submersion: a local whitening/rotation chart makes the stabilizer fiber O(K-1) for each retained mark. Thus inherited marks add tangent coordinates but do not change the rank of a new alignment residual on the law points and free cut links.

Take the parent prior from (20), with smooth compact support in an admitted regular region. The rooted parameterization in (5) makes C_M a smooth submersion; integration of a smooth compactly supported density along its tree-frame fibers yields a smooth compactly supported density on the marked parent manifold. Assume the next selected grouping has positive coherent mass and satisfies the same normal-rank admission. The argument in Sections 3 and 5 then applies on this parent manifold. The next prior need not factorize or be Gaussian on presentation coordinates.

At the next grouping, keep every new non-tree cut-edge loop and conjugate every inherited child loop into the new root frame. If g_{S<-I} is the tree transport from a child root I to its new root S, its inherited loop becomes

\[
 H_{I,\ell}^{S}
 =g_{S\leftarrow I}H_{I,\ell}g_{S\leftarrow I}^{-1}.
 \tag{26}
\]

It stabilizes b_S because g_{S<-I}#b_I=b_S on the next coherent set. Every new loop also stabilizes b_S. Nested rooted trees give exact cancellation in dressed cut edges and these conjugations. Hence the coarse maps compose on the common nested coherent set. The topological mark count agrees:

\[
 \beta_{\rm whole}
 =\sum_I\beta_I+\beta_{\rm contracted\ graph}.
 \tag{27}
\]

For a connected grouping this follows directly from beta=E-N+1 after separating internal and cut edges. The inherited and new loop generators form the based free-group presentation supplied by the nested tree. Retaining their matrices and joint law preserves the corresponding loop observables, including noncommuting products.

Induction proves normalized marked-parent closure at every fixed finite depth satisfying these hypotheses. Take the strong-record limits in their declared order and multiply the retained evidence factors at each stage. A different simultaneous limit has not been proved equivalent. Nor is the finite-n exact pushforward asserted to stay in this limiting family. This is a regular marked probability class, not a claim that a finite list of Gaussian precision matrices parameterizes every posterior.

For B blocks in the nonzero-radius regime, let L_I be the total number of based loop marks retained in block I, including inherited child marks and new internal cycles. Thus L_I=beta_I+sum of child mark counts; at the first unmarked level L_I=beta_I. With E_cut retained cut copies, the intrinsic parent-coordinate count is

\[
 B d_K+\sum_I L_Ih_++E_{\rm cut}K^2,
 \tag{28}
\]

provided all required tree-frame interfaces can be integrated. If they cannot, add their retained coordinates and kernels. Inherited marks at later levels remain in this count; they are not discarded merely because the number of graph vertices falls.

Centered clean parents admit a separate recursive route. Their means are exactly zero in the limiting model, and subsequent linear GL(K) actions and compatible reweightings preserve that support. The centered Gaussian law family has dimension s_K and is one GL(K) orbit with stabilizer O(K). For a later grouping entirely inside this family, (9) gives normal codimension E s_K, with all inherited marks retained. This later codimension differs from (12), where the original ambient model still had freely variable means. Mixed centered and nonzero-radius blocks require a fresh admission; positive-radius support bounded away from zero cannot align exactly with a centered law. One cannot change the ambient mean support while retaining the old evidence power.

If belief and model channels have independent full-GL link copies, the construction applies to both and their normal ranks add, while their prior and recognition can remain correlated. This is a specialization on the common principal bundle. If one group variable drives both channels through tied representations, the residual Jacobians must be stacked with that same variable; the stabilizer is their intersection and the independent-copy rank formula is inapplicable. Different representation dimensions or an arbitrary G require checking those actual action maps.

## 9. Executed discriminator and continuation boundary

[gl_rank_exact.py](evidence/gl-alignment/gl_rank_exact.py) constructs (7) column by column for every mean, symmetric covariance, and link variation. It computes exact rational ranks without a numerical threshold and checks the analytic formulas, orthogonality, stabilization, and the stated noncommutation. Its one execution under pinned CPython 3.14.7 returned:

| Configuration | Exact residual and Hessian rank | Common fixed-vector dimension |
| --- | --- | --- |
| K=2 triangle, nonzero mean, reflection loop | 14 | 1 |
| K=2 triangle, centered, reflection loop | 14 | 1 |
| K=2 triangle, centered, loop -I | 15 | 0 |
| K=3 two cycles, nonzero mean, marks (13) | 34 | 1 |
| K=3 two cycles, centered, marks (13) | 32 | 1 |
| K=3 two cycles, centered, perturbed H_1 | 33 | 0 |
| K=3 centered tree | 18 | 3 |

The perturbation used the rational plane rotation with cosine (1-t^2)/(1+t^2), sine 2t/(1+t^2), t=1/10. The nonzero mean was e_1/10. [The saved JSON](evidence/gl-alignment/gl-rank-exact-result.json) records all matrices and dimensions. The calculation checks the finite tangent examples; the coherent-manifold and Laplace conclusions rest on the proofs above. No sampling, nonlinear integral, simulation, model training, prior experiment replay, or pytest suite ran.

This advances the original pointwise formation problem beyond flat or translation-only links: the admitted parent carries nonidentity and noncommuting loop marks, inherits actual normalized observations, has an induced prior with its fluctuation measure, and supports the stated inference and recursive limits. The original fifteen heterogeneous local admissions remain an unchanged exact negative result for their own experiment.

The nearest unresolved analytic obligation is the unrestricted alignment integral near the rank-changing Gaussian junction, including priors with mass in its neighborhoods. A proper prior alone does not settle which regular or singular region controls that limit. Separately, choosing the blocks from the same data, retaining a useful full evaluator at finite record strength, measuring its resource cost, and coupling structural-model learning remain open. No base-manifold transport has been introduced.
