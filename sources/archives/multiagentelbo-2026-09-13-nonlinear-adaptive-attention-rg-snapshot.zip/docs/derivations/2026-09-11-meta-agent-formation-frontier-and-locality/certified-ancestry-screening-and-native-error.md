# Certified ancestry screening and native-flow error

September 12, 2026. The existing native crossing theorem leaves a resource problem: hard selection of the pair discards more than half the complete recognition mass near its crossing with one block. This continuation retains both competing ancestries and bounds the contribution of the remaining hypotheses before evaluating their full likelihood integrals. The original generator, structural prior, observations and seven-coordinate native flow remain the comparison target.

The bound controls unbounded primitive energies as well as ancestry probability. It therefore supplies a force-error certificate, a conditional finite-time approximation bound and a compatible open prior region for the previously established preference episode. A declared matrix evaluator requires 136 terms instead of 496. This is an evaluation saving under that charge, not a measured total resource benefit, an automatic selection rule or a second learned RG stage.

## 1. Existing construction and the remaining obligation

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, and the [operational wiki account](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) require complete parent overhead and a net benefit. The [transported-prior construction](transported-parent-priors-and-induced-couplings.md), Sections 2 and 4, supplies the normalized generator, primitive energies and actual complete-model Fisher metric. The [native crossing derivation](native-ancestry-crossings-and-selection-loss.md), Sections 5 and 6, supplies the exact support losses and direct matrix-oracle inventory. Earlier [shared-parent learning](shared-parent-native-learning-and-memory.md), Section 7, already bounds the original success/failure likelihood by positive functions; [native memory reduction](native-memory-and-local-parent-reduction.md), Section 3, already uses a finite-domain differential-inequality argument. Those methods are extended here to the current transported model and its omitted energy numerators.

All work remains at one base point. There are twelve connected ancestries R and forty-five root/tree decorations H, with a fixed positive prior pi_R and uniform conditional decorations shared between the two channels. The preparation has s=1 and a matched ancillary root; both conditions are invariant. The evolving state is x=(u_a,u_b,u_c,rho_a,rho_b,rho_c,omega). No numerical prior, tolerance, time horizon, new record or learned second-level interaction is selected.

Let v_j=1/rho_j for j=a,b,c. Use the fixed residual maps B,J_R,C_H from the transported model and put G_a=BB^T, G_b=J_R J_R^T and G_c=C_H C_H^T. Conditional on H, the normalized Gaussian reference at recognition precision rho has residual covariance

\[
 \Gamma_H=\sum_{j=a,b,c}v_jG_j,
 d_a=d_c=16, d_b=4k_R.
 \tag{1}
\]

Each channel has two coordinate directions. Define zeta_H=E_rho[L_o|H] and N_Hj=E_rho[E_j L_o|H], with E_j the complete primitive energy across both channels. Average these quantities over H conditional on R to obtain zeta_R,N_Rj. The normalized ancestry weights are proportional to y_R zeta_R, where y_R=pi_R exp(lambda k_R) and lambda=omega-2 log rho_b. Both conditional channels use the same H throughout.

## 2. One positive Gaussian envelope per covariance map

For the original success counts n=(8,1,8,1), every label also has one failure in each channel. For 0<=p<=1 and t=n/2, the maximum of p^t(1-p) occurs at p=t/(t+1). Consequently

\[
 p^n(1-p)\leq c_n p^{n/2},
 c_n=\frac{(n/2)^{n/2}}{(1+n/2)^{1+n/2}},
 C=\prod_{e=1}^4c_{n_e}^2
  =\frac{68719476736}{69522857666015625}.
 \tag{2}
\]

The square in C accounts for the two channels. With D=diag(n/2), the pointwise bound L_o<=C product_(e,x)(p_e^x)^(n_e/2) gives

\[
 0<\zeta_H\leq\bar\zeta_H
       :=\frac{C}{\det(I_4+\Gamma_HD)^2}.
 \tag{3}
\]

This is an envelope for the existing likelihood. It does not replace the failure observations with successes or temper the inferential target. The half power is a fixed algebraic choice used only for the bound.

Set S_H=Gamma_H+D^(-1). Gaussian conditioning under the positive envelope gives the expected complete energy

\[
 \bar m_{Hj}=d_jv_j-4v_j^2\operatorname{tr}(G_jS_H^{-1}),
 0<N_{Hj}\leq B_{Hj}:=\bar\zeta_H\bar m_{Hj}.
 \tag{4}
\]

To verify (4), express the residual as A_H times the independent primitive noises, with A_H=[B,J_R,-C_H,0]. Multiplication by the Gaussian envelope changes their per-coordinate covariance from V to V-V A_H^T S_H^(-1) A_H V. Taking the j block trace and multiplying by four gives the displayed formula. That covariance is positive definite for positive primitive variances and finite D, so every energy bound is positive. Multiplication of the pointwise likelihood inequality by E_j>=0 proves the numerator inequality. The ancillary root remains unchanged and needs no approximation error term.

Average (3) and (4) over the existing conditional distribution of H. This yields bar zeta_R and B_Rj without squaring a decoration average. One determinant and one solve for S_H suffice for all three energy bounds. The identity det(I+Gamma D)=det(D)det(S_H) avoids a separate inverse of Gamma.

There is a uniform comparison with the earlier full-success envelope L_o<=product(p_e^x)^n_e. If bar zeta_H^full and B_Hj^full denote that envelope's mass and energy bounds, then

\[
 \bar\zeta_H\leq256C\bar\zeta_H^{\rm full},
 B_{Hj}\leq512C B_{Hj}^{\rm full}, 512C<1.
 \tag{5}
\]

For the mass, conjugate Gamma by D^(1/2). Each of the four positive eigenvalues contributes less than two to det(I+2Gamma D)/det(I+Gamma D); two channels square that ratio. For the energy, the full-success primitive precision is V^(-1)+U and the half-success precision is V^(-1)+U/2. The latter is at least half the former in positive-semidefinite order, so its covariance is at most twice the full-success covariance. Taking positive block traces and applying the mass ratio proves (5). These bounds hold at all positive recognition precisions, not only at the exact unit calculation below.

## 3. Certified omission in the same native vector field

Fix a nonempty ancestry set A for an evaluation interval. Its exact retained mass and moments, and the bounds for its complement, are

\[
 Z_A=\sum_{R\in A}y_R\zeta_R,
 M_{Aj}=\sum_{R\in A}y_RN_{Rj},
 U=\sum_{R\notin A}y_R\bar\zeta_R,
 V_j=\sum_{R\notin A}y_RB_{Rj}.
 \tag{6}
\]

All summands are positive. Write m_Aj=M_Aj/Z_A and k_A=sum_(R in A)y_R k_R zeta_R/Z_A. The full recognition law Q_x and its conditional law Q_x^A=Q_x(.|R in A) satisfy

\[
 Q_x(A)\geq\frac{Z_A}{Z_A+U},
 \operatorname{TV}(Q_x,Q_x^A)\leq\varepsilon_A:=\frac{U}{Z_A+U},
 D(Q_x^A\Vert Q_x)\leq\log(1+U/Z_A).
 \tag{7}
\]

The exact identities behind (7) are TV=1-Q_x(A) and D=-log Q_x(A). Reverse KL remains infinite when any positive ancestry is removed. The certificate is meaningful even when conservative; it does not assert a prescribed tolerance was met.

For the full expected energies m_j=E_Qx E_j, a probability bound alone would not control the error, because the energies are unbounded. The numerator envelopes resolve that gap:

\[
 -m_{Aj}\varepsilon_A\leq m_j-m_{Aj}\leq V_j/Z_A.
 \tag{8}
\]

Indeed, if Z_out and M_out,j are the true omitted mass and moment numerators, then the difference is (M_out,j-m_Aj Z_out)/(Z_A+Z_out). Insert 0<=Z_out<=U and 0<=M_out,j<=V_j to obtain both sides. For omitted block counts between k_min and k_max,

\[
 \min(0,k_{\min}-k_A)\varepsilon_A
 \leq E_{Q_x}k-k_A
 \leq\max(0,k_{\max}-k_A)\varepsilon_A.
 \tag{9}
\]

This follows by expressing the difference as the omitted mass fraction times the difference of the omitted and retained conditional means. For A={O,P}, where O is one block and P={{0,1},{2,3}}, k_A lies between one and two, while the omitted k lie between two and four. Thus the lower count error is zero and the upper is (4-k_A)epsilon_A.

Let f be the original native vector field and f_A the evaluator obtained by substituting m_Aj,k_A for its moment inputs at the same x. In both use the original K_pi=sum_R pi_R k_R. The recognition filters remain dot rho_j=u_j-rho_j and dot omega=2 log u_b-omega. For j=a,c,

\[
 -\frac{u_j^2V_j}{16Z_A}\leq f_j-f_{Aj}
 \leq\frac{u_j^2m_{Aj}\varepsilon_A}{16}.
 \tag{10}
\]

If l_k,h_k are the two sides of (9), then

\[
 \frac{u_b l_k-u_b^2V_b/(4Z_A)}{K_\pi}
 \leq f_b-f_{Ab}
 \leq\frac{u_b h_k+u_b^2m_{Ab}\varepsilon_A/4}{K_\pi}.
 \tag{11}
\]

Equations (10) and (11) are direct substitutions in the accepted native equations. Their remaining four state components have zero same-state difference. The largest absolute endpoint supplies epsilon_f(x)>=||f(x)-f_A(x)||_infinity. Renormalizing pi on A inside K_pi would change the complete-model Fisher metric and invalidate this comparison. No unchanged full-objective dissipation theorem is asserted for the approximate flow.

## 4. Finite-time law and response error

Suppose x solves dot x=f(x), and x_hat solves dot x_hat=f_A(x_hat), with equal initial seven-coordinate states. Assume both paths and the straight state segments joining them remain in a compact positive-precision domain D through time T. The full field is smooth there and has a finite Lipschitz constant L_f. Subtract the equations, insert and subtract f(x_hat), and integrate the scalar differential inequality to obtain

\[
 \|x(t)-\hat x(t)\|_\infty
 \leq\int_0^t e^{L_f(t-s)}\varepsilon_f(\hat x(s))ds.
 \tag{12}
\]

The integrating-factor proof also applies to the upper right derivative of the norm. If epsilon_f<=epsilon uniformly along the approximate path, (12) is epsilon(exp(L_f t)-1)/L_f, with value epsilon t when L_f=0. An initial state error adds exp(L_f t) times that error. A pointwise certificate from one matrix evaluation is not a uniform trajectory certificate. No path or numerical Lipschitz constant is evaluated here.

For the full recognition family, differentiation of its normalized exponential density gives a score equal to the centered sufficient statistic. For the recognition coordinates the statistics are -E_a/2,-E_b/2,-E_c/2,k. Integrating along a straight segment and using E|T-E T|<=sqrt(Var T) proves

\[
 \operatorname{TV}(Q_x,Q_{\hat x})\leq C_Q\|x-\hat x\|_\infty,
 C_Q=\frac12\sup_D\sum_{T\in\{E_a/2,E_b/2,E_c/2,k\}}
       \sqrt{\operatorname{Var}_{Q}(T)}.
 \tag{13}
\]

The variances are finite on the compact domain; model-coordinate changes have no direct contribution at fixed recognition coordinates. Equations (7) and (13) give

\[
 \operatorname{TV}(Q_{x(t)},Q_{\hat x(t)}^A)
 \leq C_Q\|x(t)-\hat x(t)\|_\infty+\varepsilon_A(\hat x(t)).
 \tag{14}
\]

Both laws in (14) are on the same complete disjoint-union carrier, including ancestry. Equal initial parameter states do not make their initial laws equal: the conditional initialization has the omission loss in (7).

Every fixed complete coarse channel and the original normalized record kernel contracts total variation. For an event E, its pushed probability difference integrates a kernel value between zero and one against the signed law difference, hence is at most the original TV. Apply this twice to the existing composable parent channels. The bound covers their full output laws and the original hypothetical future record queries. It does not introduce a physical sample path, extend to a parameter-dependent reconstruction channel without an additional channel-error term, or guarantee newly defined parent-cut interactions. The preceding four-additional-coordinate obstruction for those new records remains intact.

## 5. Compatibility with the actual native crossing

The previous crossing result supplies a positive local time T_*, a uniform positive acceleration q_0, and bounded derivatives over a compact state domain and the fixed-prior family. Retain A={O,P}. In that result choose initial O/P log-odds gap d in a compact subinterval of (0,q_0 T^2/4), for some 0<T<=T_*. Before choosing d, decrease T if necessary using a uniform bound on f_A in an interior state box, so both flows remain in the common positive domain. The corresponding retained prior ratio lies in a compact interval near its exact initial tie ratio. Let gamma=sum_(R outside A)pi_R tend to zero while each omitted prior remains positive and the retained conditional prior ratio stays in that interval.

On a fixed positive-precision neighborhood containing the short paths, Z_A has a uniform positive lower bound: both retained prior weights stay bounded away from zero, and their evidence functions are positive and continuous. Every omitted envelope and energy coefficient is bounded there. Their weights are O(gamma), so

\[
 U+\sum_jV_j=O(\gamma),
 \varepsilon_A+\varepsilon_f=O(\gamma),
 \sup_{0\leq t\leq T}
 \operatorname{TV}(Q_{x(t)},Q_{\hat x(t)}^A)=O(\gamma).
 \tag{15}
\]

Uniform short-time existence on an interior domain follows from bounded smooth fields. The limiting two-ancestry mixture is used for bounds, not as an assertion that omitted prior weights actually vanish. K_pi remains at least one, and retained evidence keeps every denominator positive, so f and f_A extend smoothly to that limit. This justifies uniform constants without claiming a nonsingular full recognition Fisher matrix on the boundary of the prior simplex.

The initial gaps to the other ten ancestries diverge as their priors vanish. Therefore they satisfy the previous crossing theorem's finite lower margins for sufficiently small positive gamma. At the same time choose an inner interval [t_1,T] with t_1>2 sqrt(d/q_0). The true P/O log-odds advantage there is at least q_0 t_1^2/4-d>0. Its smooth dependence on recognition coordinates bounds its approximation error by a constant times ||x-x_hat||. Reduce gamma so this error is smaller than the positive margin. Conditional P/O odds equal the unconditioned P/O odds at the same parameters because both candidates are retained. Hence the approximate learner preserves P's preference over O on that inner interval.

The earlier conditional cut-response separation and conditional probability variances also have positive short-time lower margins. Their expectation functions depend smoothly on recognition coordinates. Reducing gamma again preserves those conditional distinctions. Equation (14) separately controls the unconditional mixture's output-law error. This does not transfer a conditional P-versus-O distinction into a claim that either ancestry has almost all the mixture mass.

Thus any positive error target admits a nonempty open region of strictly positive prior values satisfying the screen and the conditional native preference episode over a sufficiently short positive interval. No numerical prior has been chosen to create that outcome, and the result is not a prediction for every prior or for uniform priors. No supplied tolerance is needed to state this parameter-region theorem. It proves compatibility of the two requirements, not practical duration, convergence, or complete resource licensing.

## 6. Exact finite evidence and the declared work charge

The existing catalog has thirty-one distinct full covariance maps (G_b,G_c), with disjoint sets across ancestries. An ancestry R has d_R^map=5-k_R maps. For s=1, a direct exact likelihood integral expands the four failure factors into sixteen Gaussian terms per map. The half-power envelope uses one per omitted map. If D_A=sum_(R in A)d_R^map, the scheduled work is

\[
 N_{\rm screen}=16D_A+(31-D_A)=31+15D_A,
 N_{\rm full}=16\cdot31=496.
 \tag{16}
\]

For A={O,P}, D_A=4+3=7, giving 112 exact retained terms and 24 omitted-envelope terms, or 136 in total. This retains uncertainty between the two candidates near their crossing. Selecting P alone would use 76 terms, but the previous greater-than-half support-loss result still prevents claiming small complete-law error there.

The new [exact script](evidence/ancestry-screening/positive_envelope_exact.py) evaluates all forty-five decorated envelope coefficients at the saved unit precisions, reconstructs each energy bound from the full primitive covariance, and compares mass and all three moment numerators with the saved exact values. All inequalities hold coefficient by coefficient, so positivity proves the corresponding pooled statements for any fixed positive prior without choosing one.

The script also implements the sixteen-term exact integral for the seven retained covariance maps using the S=Gamma+D^(-1) identity, rather than the saved two-inverse residual-posterior implementation. If w_S=(-1)^|S|/det(I+Gamma diag(n+1_S)) and m_jS is the four-coordinate Gaussian energy mean, then

\[
 e_H=\sum_S w_S,
 N_{Hj}=e_H\sum_S w_Sm_{jS},
 \zeta_H=e_H^2.
 \tag{17}
\]

For the energy numerator, either channel supplies two of the four primitive coordinate directions while the other contributes its evidence e_H. Adding the two equal contributions proves (17). Each retained result agrees exactly with the previous fractions, including decoration pooling. No full 496-term science run was repeated.

The [saved result](evidence/ancestry-screening/positive-envelopes.json) reports PASS from one completed Fraction calculation under pinned CPython 3.14.7, with elapsed calculation time 0.07786849999683909 seconds. The executed validation used 143 distinct determinant/solve pairs: the 136 scheduled screened terms plus seven retained-envelope terms needed only to check the bound over all forty-five decorations. At the unit point the ancestry-level mass upper bounds are about 19.95 to 23.14 times their exact coefficients. They can therefore be useful for sufficiently small omitted weights but are not sharp evidence estimates.

The charge counts determinant/solve terms for these fixed four-dimensional matrices, not elapsed speed, bit complexity or total parent operation cost. Both the fine and coarse implementations can use this evaluator. It does not reduce their common seven evolving law coordinates, remove the retained structural catalog, or attribute mixture-evaluation savings to geometric aggregation. Bound aggregation, interface access, sampling or filtering when required, switch costs, exact law evaluation requirements and new interactions must still be charged in a complete comparison. A numerical implementation at nonrational states additionally needs controlled roundoff if it presents these inequalities as rigorous certificates.

The remaining task is to resolve that complete parent implementation cost and the actual recursive learning contract, retaining uncertainty or charging approximation and keeping the induced correlated parent prior. The fifteen-subset negative result, earlier positive specializations, current finite-time selection limitations and all saved data remain unchanged. There was no ODE, fitting, parameter search, new observation, sampling, GPU, suite, Lean, tamper check, production/configuration edit, vault change, publication or canonical synchronization.
