# Exact stochastic local admission for the unchanged heterogeneous experiment

September 11, 2026. Allowing a stochastic retained initialization does not permit a smaller finite complete parent for any proper child block in the saved heterogeneous experiment, provided its retained exterior is fixed at preparation and its future predictor is common across fine preparations. The complete preparation-dependent finite carrier must still have at least 2^|A| states for every proper nonempty block A. This extends the previous deterministic local-admission result without changing the experiment, collecting observations, choosing a loss tolerance, or fitting a new parent.

The global result is different and must remain separate. The all-preparation record experiment has exact linear observable rank fifteen, not sixteen. One signed mixture direction is invisible after the first reset even though every pair of deterministic preparations is distinguishable. A global finite stochastic realization needs at least fifteen states; the rank calculation alone does not establish a normalized positive fifteen-state realization. The original sixteen-state source supplies an upper bound of sixteen.

## S1. Fixed source and experimental interface

The source is the saved configuration in `docs/reports/data/2026-09-11-finite-data-formation/results.json`, at source revision `ed8f22a56df353b1535744509cc23fae46d5813c`. The six couplings in pair order are 1/16, 1/12, 1/10, 1/8, 1/7, and 1/6. The two actions are fields -1/5 and +1/5. The sensor has signal 3/4, and the saved horizon is four. The current `experiments/rg_v2/formation_data.py` THEORY dictionary was checked equal to the saved THEORY dictionary. No launch-profile or override change is part of this calculation.

A prepared state y is a vector of four signs. At each event, the scheduler selects one site uniformly, resets its sign with conditional mean a+sum_j J_ij y_j, and emits a noisy parity observation from the destination state. There is no informative time-zero record. `finite_data_formation.heterogeneous_process` constructs these exact rational emitted rows; `finite_formation.ControlledProcess` checks their normalization and defines their destination-major, record-minor layout.

Write T_a for the sixteen-by-sixteen reset transition and D_e for the diagonal destination sensor with entry (1+(3/4)e product_i y_i)/2. The substochastic record matrix is K_(a,e)=T_a D_e. For a word w=((a_1,e_1),...,(a_h,e_h)), define its column of probabilities by

v_w=K_(a_1,e_1)...K_(a_h,e_h) 1, and v_empty=1.

The y coordinate is the exact probability of that record word under its stated open-loop actions from preparation y. All four action/record symbols are admitted. History-dependent policies common to the compared preparations multiply a branch's record probability by action propensities determined from that branch's visible history. They do not introduce a new preparation-dependent factor. Hidden-state controllers would define another experiment and are excluded from this statement.

## S2. The exact invisible direction and rank certificate

Let p(y)=product_i y_i, viewed as a signed sixteen-vector. For a fixed reset site i and any function f, (T_(a,i)f)(y) depends only on y_-i: both the reset mean and the destination evaluation are independent of the old sign y_i. Consequently,

sum_y p(y)(T_(a,i)f)(y)=0,

because the two values of y_i have opposite parity and the same function value. Averaging over the four reset sites proves p^T T_a=0. Multiplication by the destination sensor proves p^T K_(a,e)=0. Also p^T 1=0, since eight preparations have each parity. Thus every word column lies in p-perpendicular, a fifteen-dimensional linear subspace. This upper bound holds at every horizon and for both fields. It uses the actual one-site reset and the noninformative time-zero protocol; a pre-reset parity observation would invalidate it.

The finite lower certificate is [observable-rank.json](evidence/local-admission/observable-rank.json), generated once by [check_observable_rank.py](evidence/local-admission/check_observable_rank.py). It retains fifteen independent ORIGINAL word-probability columns, their action/record words, all sixteen rational coordinates, and the exact elimination pivots. It also records all source/input bindings and the runtime. The arithmetic is Python Fraction; no tolerance or floating rank decision is used.

| Maximum word length | Number of words including shorter lengths | Exact rank |
| --- | ---: | ---: |
| 0 | 1 | 1 |
| 1 | 5 | 3 |
| 2 | 21 | 9 |
| 3 | 85 | 14 |
| 4 | 341 | 15 |

The selected columns form a matrix O with sixteen rows and fifteen columns, of rank fifteen. Every selected column is an admitted test within the saved four-event horizon. The program checks all sixty-four scalar entries of p^T K_(a,e)=0, all sixty images of selected columns under the four record matrices for membership in the selected span, and the rank fifteen of every matrix obtained by removing one preparation row. The separate [reconstruction](stochastic-realization-reconstruction.md) checks the derivation and independently recomputes the selected word vectors and a fifteen-by-fifteen minor modulo the predeclared prime 1009. The 240 rational coordinates match the saved witness, and the minor determinant is 85 modulo 1009. Every denominator is invertible modulo that prime. A nonzero modular determinant proves the rational minor is nonzero; this supplies an independent exact lower certificate without a floating-point rank decision.

The analytical upper bound and exact finite lower certificate give span{v_w : all finite words}=p-perpendicular. In particular, the left nullspace of O is exactly span{p}. Every coordinate of p is nonzero. Hence ANY proper subset of O's preparation rows is linearly independent: a dependence supported on such a subset, extended by zero on the omitted rows, would be a nonzero multiple of p with a zero coordinate, which is impossible. This consequence needs no separate theorem about optimal hidden-state models.

Two initial distributions mu and nu therefore yield the same complete future record experiment exactly when mu-nu=c p for some scalar c consistent with their nonnegativity. Necessity follows from the selected columns; sufficiency follows from the all-word annihilation. For example, the family mu_c(y)=1/16+c p(y), with |c|<=1/16, has identical future record laws but different initial parity expectation 16c. This is an equality among mixtures. It does not identify two deterministic preparations or license a deterministic state merge.

## S3. Why stochastic initialization cannot compress a proper local block

Fix any nonempty proper set A of children and any initial exterior value u. There are m=2^|A| fine preparations (x,u) with this same exterior. Their m rows form a proper subset of O, so the resulting matrix O_(A,u) has rank m.

Allow an arbitrary stochastic encoder E_(A,u)(s|x) on a finite complete parent carrier of size k. It may depend on the known exterior value, but the same encoder is fixed before the future action/record test is selected. Conditional on the sampled parent state s and that exterior, let the parent have any common normalized future predictor for the same action/record experiment. It may use subsequent records and memory; it need not be a first-order Markov model. Let G_(A,u)(s,w) denote its probability for each of the fifteen selected tests. Exactness for all local preparations requires the factorization

O_(A,u)=E_(A,u) G_(A,u).

This identity follows by conditioning on the sampled initial parent state. It does not assume a deterministic encoder, independent child recognition, or a Gaussian approximation. Matrix rank gives

2^|A|=rank O_(A,u)<=rank E_(A,u)<=k.

This proves the stated lower bound for all fourteen proper blocks. The identity initialization attains k=2^|A| when the unchanged source and exterior are retained, so there is no smaller finite preparation carrier within this class. The previous stronger emitted-row admission is consistent with this bound; only record-word probabilities were needed here. Summing over the disjoint retained exterior fibers gives at least sixteen complete local-plus-exterior initial states. This remains true if the local alphabet is allowed to vary with the exterior value.

The word COMPLETE matters. The retained JOINT initial law, including correlations with model, memory, and shared-randomness coordinates, must contain all preparation dependence that affects the future. A coordinate can have a preparation-independent marginal while carrying preparation information through its correlation with the encoded state. Such an accessible joint coordinate belongs in s or in an explicitly counted interface. Calling it a model, context, random seed, or cached prior cannot remove its information cost. Likewise, a future external oracle revealing omitted fine information would invalidate the common-predictor factorization. Keeping only a smaller named response alphabet while moving the missing information into another retained coordinate does not defeat the result.

The lower bound concerns an actual stochastic initialization followed by a common conditional predictor. It is not a bound on arbitrary nonlinear algorithms that are given the encoder's probability vector as additional preparation-dependent data, nor on unrestricted continuous-state representations. Those objects require their own representation and computational-cost contract. A finite latent-state model whose predictions marginalize that law through fixed normalized kernels does satisfy the factorization above.

## S4. Global limit, composition, and the continuation gate

For the whole block, the same factorization O=E G only proves k>=15. It cannot be upgraded to k>=16 from pairwise preparation distinguishability, and k=15 cannot be asserted merely because the linear rank is fifteen. A normalized positive realization must reproduce the entire compatible controlled process, not only a signed coordinate basis or one matrix factorization. That positive-realization question remains unresolved by this bounded calculation.

There is a sharper GLOBAL conclusion when the parent decoder is required to be a positive mixture of original fine-preparation continuation laws. All sixteen rows r_y of O are extreme points of their convex hull. Otherwise, expressing one r_y as a convex combination of the other rows would give a left-null vector with exactly one positive coefficient and no other positive coefficient. A nonzero multiple of p has eight positive and eight negative coefficients, so such a relation cannot exist. If decoder rows satisfy G=D O for a row-stochastic fine-lift D, every decoder row lies in that convex hull. Reconstructing every extreme r_y through the convex encoding O=E G requires at least one decoder row equal to each r_y. Consequently k>=16 in this positive fine-lift class, and the original source attains equality.

For example, a fixed full-support reference preparation mu and encoder E determine the Bayesian initial lift D_mu(y|s)=mu(y)E(s|y)/sum_z mu(z)E(s|z) on positive-mass parent states. If the parent continuation law is defined by conditioning that same reference path experiment on its initial encoded state, then G=D_mu O and the sixteen-state corollary applies whenever all-preparation exactness O=E G is also demanded. This extra decoder requirement is stated explicitly. The general fifteen-state positive-realization question permits continuation laws outside the convex hull and is not settled by the corollary.

The unresolved global one-state saving does not supply the missing first level of the requested local hierarchy. Each proper block, conditional on its fixed retained exterior, still requires its full preparation carrier. More generally, for a partition into at least two nonempty proper blocks, reducing any local finite alphabet below its original 2^|A| while leaving the others no larger makes the product carrier at most fourteen. Such a common joint finite predictor cannot realize the rank-fifteen preparation experiment. Additional shared interfaces or preparation-dependent memory must be counted and may restore the missing size. This is a statement about the declared finite carrier sizes, not about every imaginable coding scheme.

The revised attachment already makes identity-only admission a valid negative exit and requires an explicitly declared approximation target before statistical spatial selection. This new result strengthens that exit: stochastic proper-local encoding does not repair it under the unchanged all-preparation record experiment. A useful approximate parent still needs a justified allowed prediction loss or resource preference; changing preparation access, observations, or a reporting filtration changes the target. The separate PIFB2 predictive-clock construction explains a conditional information-response mechanism but does not alter this exact source certificate.

## Execution and preservation

The rank producer ran once in the existing isolated worktree under pinned CPython 3.14.7 with `-I -B`, using standard-library exact arithmetic. Its raw output is [observable-rank.log](evidence/local-admission/observable-rank.log). The calculation enumerated 341 finite words through horizon four and took approximately 0.31 seconds inside the script. It validated all entries in the existing frozen input-binding file before constructing the process. No observations were resampled, no score or penalty was changed, and no production or active-configuration file was edited. There was no pytest, training, historical producer, GPU work, Lean, tamper check, publication, or canonical-checkout synchronization.

The previous deterministic proofs, fifteen adapter certificates, predictive-clock derivations, and saved experiment remain preserved. This continuation adds a scoped rank theorem and its local consequence. It does not claim that the useful learned RG hierarchy has been achieved.