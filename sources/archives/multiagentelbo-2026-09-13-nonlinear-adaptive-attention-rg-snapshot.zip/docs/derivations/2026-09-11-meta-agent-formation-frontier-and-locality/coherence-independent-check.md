# Independent reconstruction of the complete coherence dynamics

September 12, 2026. This is a mathematical check of the microscopic and coherence portion of the [active existential contract](evidence/2026-09-12-dynamical-rg-goal/problem-contract.json). It assigns no ledger state and does not complete the recursive RG objective. The checked construction is [complete-coherence-dynamics.md](complete-coherence-dynamics.md), especially Sections 5–8. The companion `microscopic-vfe-dynamics-construction.md` was absent when this check was written, so the result below concerns the self-contained equations in the coherence document.

The deterministic basin theorem is reconstructed below, including its full normal kernel. The normalized evaluator reduction, SO(d) gradient, finite-time response, and killed stochastic bounds are also reconstructed. Four precision issues identified during this check were corrected in the source: the link trivialization label, the transformation of external-vector components, the energy/entropy domain, and the distinction between a tangent projection and an actual projected trajectory. Their mathematical reasons remain recorded below.

## 1. Exact target and source boundary

Fix one base point, a finite connected graph with N at least two, one orientation for each edge copy, d at least two, 0<a<1, r0>0, and positive coefficients μb, μm, ηe^x, κe^x, and λ0,i. At fixed T>0 set λi=λ0,i+T/(1−a). The configuration domain is

\[
X=(\mathbb R^d)^{2N}\times SO(d)^{2E}.
\]

For every such choice the claims checked are: existence of the normalized augmented law; the stated complete gradient and diffusion; a compact nonzero coherent equilibrium manifold with an open attracting neighborhood; exact response on the explicitly invariant forced sector; and finite-time mismatch or exit estimates under their displayed bounds. Neighborhoods and constants may depend on the graph and coefficients. Uniformity over coefficients approaching zero is not claimed.

The user supplies law-valued agents, distinct coupled belief/model channels, independent moving links, one common principal-bundle setting, one normalized model, and the fixed-base restriction. The isotropic Gaussian presentation, compact SO(d) representation, confining quartic prior, compatibility of radial coefficients with kinetic mobilities, fixed graph and positive couplings, restricted auxiliary recognition family, and selected diffusion are additional modeling assumptions. No coherence condition is imposed on the whole initial neighborhood. A smaller set of exactly coherent equilibria is constructed and its open basin is proved.

Equivalence means equality of the displayed normalized laws or vector fields on their stated spaces. A density Q on X, its stochastic configuration paths, and the Gaussian laws indexed by a point W in X are separate objects. A deterministic drift path is not a finite-temperature recognition trajectory. No base transport, infinite-depth result, arbitrary-initial-state result, or origin-only construction is used.

The relevant foundation was read directly: [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), `thm:obs-local-global-potential`, fixes the outside marginal for local/global differences; [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex) requires one normalized augmented joint and retained structural data. The live Research `PIFB2.tex`, `sec:timescales`, explicitly imposes primitive mobilities; `eq:rg_internal_hessian`, `eq:rg_slow_graph_metric`, and `eq:rg_schur_flow` distinguish stiffness, graph pullback metric, and force residual. The [moving-target conditional identity](pointwise-learning-parent-closure.md), Section 2, and [learned Gaussian link example](pointwise-gaussian-link-learning.md), Sections 6–7, already show why VFE descent alone does not imply coherence or conditional matching. The September Research wiki synthesis separately types law, path, and geometric closure. None of these sources is treated as proof of the new basin theorem.

## 2. Normalized augmented model and the evaluator calculation

Write φ(s)=(s−r0²)²/2 and

\[
U_0=\sum_i\left[\frac{\phi(|u_i|^2)}{2\mu_b}
+\frac{\phi(|v_i|^2)}{2\mu_m}
+\frac{\lambda_{0,i}}2|u_i-v_i|^2\right]
+\frac12\sum_{e:j\to i,x}\kappa_e^x|w_i^x-\Theta_e^xw_j^x|^2,
\]

where wb=u and wm=v. Lebesgue measure on node coordinates times normalized Haar measure on all links is ν. Each radial term grows quartically. Therefore exp(−U0/T) is bounded above by a product of integrable radial factors, and is strictly positive everywhere. Consequently 0<Z0,T<∞. This argument includes arbitrary finite interaction cycles because every edge energy is nonnegative.

The local factorization in source (22) is legitimate: its A_i(v) is positive, finite, and bounded above by the integral of the belief radial factor alone. Its z_i is then finite and positive. The A_i(v) appearing in the model-coordinate prior cancels its reciprocal in the conditional bridge. This cancellation constructs a proper local joint; it does not permit dropping a learned conditional normalizer in a different model. The physical evaluator is instead the normalized kernel

\[
P_i(d\zeta,dk\mid v)
=\mathcal N(v,aI)(d\zeta)
\mathcal N(\zeta,(1-a)I)(dk).
\]

The conditional recognition coupling R_{u,v} is ζ=v+ξ and k=u+ξ+ε, where ξ and ε are independent centered Gaussians with covariances aI and (1−a)I. Thus ζ has law N(v,aI), k has law N(u,I), and the joint is nonsingular because a(1−a)>0. Given ζ, its k-law is N(ζ+u−v,(1−a)I). Direct Gaussian density division gives

\[
\log\frac{dR_{u,v}}{dP_i}
=\frac{(u-v)^\top(k-\zeta)-|u-v|^2/2}{1-a}.
\]

For any coupling S with these fixed marginals, E_S(k−ζ)=u−v and the displayed logarithm is absolutely integrable. Hence the relative-entropy chain gives

\[
D(S\Vert P_i)=D(S\Vert R_{u,v})
+\frac{|u-v|^2}{2(1-a)}.
\]

On a singular S both relative entropies are infinite, since P_i and R_{u,v} have equivalent everywhere-positive Lebesgue densities. On their absolutely continuous domain the same identity extends by the integrable log ratio. R_{u,v} is therefore the unique minimizing coupling for those marginals. This result does not assert invariance of that conditional family under every conceivable joint kinetic operator; that family is explicitly selected here.

Let P_aug=p0,T(dW)∏i P_i(dζi,dki|vi), and restrict recognition to Q_aug=Q(dW)∏i R_{ui,vi}. The conditional chain rule yields, in the extended nonnegative sense,

\[
T D(Q_{\rm aug}\Vert P_{\rm aug})
=T D(Q\Vert p_{0,T})
+T\mathbb E_Q\sum_i\frac{|u_i-v_i|^2}{2(1-a)}.
\]

Put U=U0+T∑i|ui−vi|²/[2(1−a)] and pT=ZT^{-1}exp(−U/T)ν. A change of reference then gives

\[
T D(Q_{\rm aug}\Vert P_{\rm aug})
=T D(Q\Vert p_T)+T\log(Z_{0,T}/Z_T).
\]

The shift is nonnegative because U≥U0 implies ZT≤Z0,T. On the finite-energy, finite-entropy domain this also equals E_QU+T∫qlogq dν+TlogZ0,T. The generative W marginal is p0,T, whereas pT minimizes the restricted augmented variational objective. Those two laws need not coincide.

The domain qualification is necessary. Let one real coordinate x have density 2/[x(log x)²] on x≥e²; give the other node coordinates Gaussian laws and the links Haar laws. The one-coordinate density integrates to one by t=log x. Its differential entropy integral is negative infinite because the contribution −∫2∞2t/t² dt diverges. Its fourth moment is infinite, so E_QU=∞. Thus the energy-plus-entropy expression would be ∞−∞, while D(Q||pT)=∞ is well defined. The source now uses the KL expression as its extended definition.

## 3. Complete metric gradient and global deterministic solutions

The node metric is μb^{-1}∑i|dui|²+μm^{-1}∑i|dvi|². Each link carries η^{-1} times the bi-invariant metric with Lie-algebra pairing ⟨A,B⟩=−tr(AB)/2. The radial node energy is (|u|²−r0²)²/(4μb); its negative metric gradient is exactly −(|u|²−r0²)u. The evaluator/bridge force is −μbλi(ui−vi). Differentiating both receiver and source occurrences of every edge gives exactly source (25). In particular the outgoing contribution is −μbκ(ui−Θᵀuk); it is not discarded.

For one link put x=wi and y=Θwj, and vary Θ as AΘ, Aᵀ=−A. The edge differential is −κxᵀAy. For C=xyᵀ−yxᵀ,

\[
-\tfrac12\operatorname{tr}(CA)=x^\top Ay.
\]

Consequently its negative metric gradient is ηκCΘ, exactly source (26), with the stated sign and no additional factor of two. The velocity Ω=dotΘ Θ^{-1} is spatial/right-trivialized. The body/left-trivialized velocity is Θ^{-1}dotΘ. Bi-invariance lets the metric be evaluated in either, but the terminology matters when transporting later formulas.

Skewness preserves ΘᵀΘ=I, and continuous motion from SO(d) preserves determinant +1. The product manifold is complete and U has compact sublevels: all means are bounded by the radial terms and all link factors are compact. Along the actual full field,

\[
\dot U=-|\operatorname{grad}_g U|_g^2.
\]

An orbit stays in its compact initial sublevel. Local ODE existence and uniqueness, together with a finite coordinate covering of that compact set and bounded derivatives, extend it past every finite time. This proves global forward existence without an unproved boundary assumption.

The complete two-channel zero-edge-KL set is not invariant. On a two-node graph take Θb=I, Θm a quarter turn carrying e1 to e2, u1=u2=e1, v2=e1, and v1=e2. Both edge KLs and both link forces vanish. With equal λ, the belief evaluator gives dotu1−dotu2=μbλ(e2−e1). Therefore its initially zero edge KL becomes (μbλ)²t²+o(t²). This counterexample satisfies the normalized model assumptions and keeps all means nonzero.

## 4. Full kernel geometry and the nonzero open basin

Let S be the set ui=vi=wi, |wi|=r0, and Θe^xwj=wi on every edge in both channels. S is nonempty for arbitrary choices of wi on the sphere: SO(d) acts transitively on that sphere. For fixed nonzero endpoints, rotations carrying wj to wi form an SO(d−1) coset. Local orthonormal completions give smooth local product coordinates. Thus S is a compact embedded manifold of dimension

\[
N(d-1)+E(d-1)(d-2).
\]

Its full ambient dimension is 2Nd+Ed(d−1), so its normal dimension is N(d+1)+2E(d−1). These are full-state dimensions, including independent link variations; they are not dimensions after removing link degrees of freedom.

At W in S, with δΘe^x=Ae^xΘe^x, direct second differentiation gives

\[
\begin{split}
H_U[\delta W,\delta W]
={}&\sum_{e,x}\kappa_e^x
|\delta w_i^x-\Theta_e^x\delta w_j^x-A_e^xw_i|^2
+\sum_i\lambda_i|\delta u_i-\delta v_i|^2\\
&+2\sum_i\left[\mu_b^{-1}(w_i^\top\delta u_i)^2
+\mu_m^{-1}(w_i^\top\delta v_i)^2\right].
\end{split}
\]

All coefficients are positive. A vector in its kernel has δui=δvi tangent to the radius-r0 sphere and satisfies every linearized edge equation. Conversely every tangent vector to S satisfies these conditions. To check that the displayed linear conditions are integrable tangent data, observe that A↦Awi surjects from so(d) onto wi⊥: for a⊥wi, the skew matrix (awiᵀ−wiaᵀ)/r0² sends wi to a. Its kernel is so(d−1). Each edge has its own A, so solving one edge imposes no additional constraint on another. These are precisely the derivatives of the local coset parameterization. Hence ker HU=TS, and the Hessian is strictly positive on the g-normal bundle.

Compactness gives a strictly positive minimum Hessian eigenvalue on the unit normal bundle. Uniform Taylor expansion in a sufficiently small tubular neighborhood then gives constants cj>0 with

\[
c_0d_g(W,S)^2\le U(W)\le c_1d_g(W,S)^2,
\qquad c_2U\le|\operatorname{grad}_gU|_g^2\le c_3U.
\]

Here the normal derivative of the gradient is the invertible normal Hessian, and there is no linear tangent term because the Hessian annihilates TS. The normal bundle need not be globally trivial; the squared normal distance is a globally smooth scalar on a sufficiently small tube.

Before any exit, U(t)≤U(0)e^{-c2t}, and the remaining path length satisfies

\[
\int_t^\infty|\dot W(s)|_g ds
\le\frac{2\sqrt{c_3U(0)}}{c_2}e^{-c_2t/2}.
\]

Choose a smaller tube whose maximal U is sufficiently small that this bound is less than the margin to the outer tube. A first-exit contradiction makes the estimates valid for all positive times. Finite tail length makes each trajectory Cauchy; completeness gives a single limit, and U→0 places that limit in S. Normal distance decays exponentially. The allowed initial set is open and contains S, not merely S itself.

All limiting means have norm r0>0. Perturbing one belief link by a small angle θ in an e1,e2 plane at wi=r0e1 yields initial angular velocity −ηκr0²sinθ. Thus there are open subsets of the admitted basin with genuinely moving links and moving law means. Stabilizer directions survive: SO(d−1) permits nonidentity loop holonomy for d≥3 and noncommuting stabilizer elements for d≥4. None of this proves a preferred grouping, attraction from the origin, or global attraction from every initial state.

## 5. Response, actual projection, and a same-model finite exit

For an invariant embedding i(y) with Jacobian J, multiplication of Jdoty=−G^{-1}dF by JᵀG gives

\[
G_S=J^\top GJ,\qquad
\dot y=-G_S^{-1}d(F\circ i).
\]

This is exact only when the full vector field is tangent. With a general force it gives the tangent projection at S; its use for a nearby trajectory additionally needs a force residual bound. Source (14)–(15) provides that bound explicitly. Small scalar error alone is insufficient.

A minimal counterexample shows why the distinction is necessary. On R² take U(y,z)=z²/2 and E(y,z)=−εyz, with S={z=0}. The restricted potential vanishes, so its intrinsic gradient predicts doty=0. The full equations are doty=εz and dotz=−z+εy. Starting at (y0,0) with y0 nonzero gives

\[
y(t)=y_0+\tfrac12\epsilon^2 y_0t^2+o(t^2).
\]

The discrepancy is not removed by calling E weak. The source now states the required projection qualification.

For the actual microscopic model, E=−h(t)ᵀ∑i(μb^{-1}ui+μm^{-1}vi) preserves the flat synchronous sector. There dotw=−(|w|²−r0²)w+h(t) and links stay fixed. The metric on w is N(μb^{-1}+μm^{-1})I; the same factor multiplies the restricted self energy and the forcing covector, so it cancels exactly. No new parent mobility is assigned.

For constant h=h0n*, h0>0, the positive branch r*>r0 solves (r*²−r0²)r*=h0. Its radial derivative is 3r*²−r0²>0 on that branch. Linearization gives the rates 3r*²−r0² and r*²−r0²=h0/r* in the radial and angular directions. Thus a small physical forcing can produce a slow angular response while the previously proved normal gap remains positive by continuity. This statement concerns that retained mode, not every tangent coordinate or a universal size-dependent clock. Under passive frame changes the components of h must transform with the frame; keeping the physical external reference fixed does not mean freezing its numerical components in every coordinate system.

The tube inequalities in source (9)–(12) follow from D+|z|≤−α|z|+η and the integrating factor. The retained comparison (15) follows from the same calculation applied to |y−Y|, with forcing K|z|+ε and Lipschitz coefficient L. Loss of their sufficient bound alone is not a departure proof.

There is also an explicit finite-exit certificate within this microscopic model. Fix a full closed normal tube d_g(W,S)≤ρ small enough to be regular, and let

\[
R=r_0+\sqrt{\max(\mu_b,\mu_m)}\rho,
\qquad
B_1=(R^2+r_0^2)R
+2\mu_bR\left(\lambda_1+\sum_{e:1\in e}\kappa_e^b\right).
\]

Count each incidence when self-loop copies are present. Every mean in this tube has norm at most R: a minimizing point in the compact S exists, and the weighted product distance bounds each node displacement. Orthogonality of the links and the complete node equation then give |dotu1|≤B1 for the unforced drift throughout the tube.

Choose a constant unit vector e and the actual added potential E_F=−Feᵀu1 with F>B1/μb. The forced velocity satisfies

\[
e^\top\dot u_1\ge\mu_bF-B_1=:v_*>0
\]

throughout the tube. Since eᵀu1≤R there, every initial point strictly inside the tube exits by

\[
\tau\le\frac{R-e^\top u_1(0)}{v_*}.
\]

This follows by integration until first exit and contradiction if no exit has occurred at that time. The quartic tails dominate the linear tilt, so exp[−(U+E_F)/T] remains integrable and the constant-forcing gradient flow still has compact sublevels. This is actual finite departure for the same nonzero coherent model under sufficiently strong specified forcing. The bound is sufficient and deliberately conservative; it neither identifies a sharp threshold nor claims that failure of small-forcing persistence implies exit.

## 6. Finite temperature and killed-process bounds

At fixed T, the generator is L_T=−⟨grad_gU,grad_g·⟩+TΔg. Its metric volume is a constant multiple of ν, since node metric coefficients are constant and link metrics are invariant. A quadratic function of the node norm has generator bounded above by a constant plus itself: the drift has negative quartic leading terms, the cross terms are at most quadratic, and the noise trace is constant. Stopping on increasing compact balls and applying the integrating factor bounds the exit probability by a quantity tending to zero. Thus the smooth diffusion is nonexplosive.

For compactly supported smooth test functions, integration by parts gives

\[
\int fL_Th dp_T
=-T\int\langle\operatorname{grad}_gf,
\operatorname{grad}_gh\rangle_g dp_T.
\]

The conservative smooth diffusion consequently has the normalized stationary reversible law pT. On smooth positive density solutions with the stated finite-energy, entropy, and boundary integrability, the Fokker–Planck equation gives

\[
\frac{d\mathcal F_T^{\rm aug}}{dt}
=-\int q\left|\operatorname{grad}_g(U+T\log q)\right|_g^2d\nu.
\]

This is density transport/diffusion kinetics, not full-joint Fisher reaction kinetics. The deterministic equation at selected T is its drift with λi=λ0,i+T/(1−a). The actual limit T→0 changes this coefficient to λ0,i. Both deterministic drifts satisfy the basin proof because both coefficients are positive. One must not describe the fixed-T drift as the zero-temperature model without making this distinction.

For an edge KL D at S, dD=0 and its nonzero positive semidefinite Hessian gives L_TD=Ttr_g HD>0. Consequently exact coherent support is not invariant under independent positive-temperature noise. The linear normal Ornstein–Uhlenbeck covariance TH^{-1} is exact for that linear model only; it is not the exact nonlinear equilibrium covariance.

For the stated stochastic tube let V=d_g(W,S)², τ its first exit, and assume L_TV≤−aV+B. This scalar formulation avoids requiring a globally trivial normal bundle. Stopped Itô with integrating factor gives

\[
\mathbb E[e^{a(t\wedge\tau)}V(W_{t\wedge\tau})]
\le V(W_0)+B\mathbb E\int_0^{t\wedge\tau}e^{as}ds.
\]

Split the left side into the survival and boundary terms. The latter is nonnegative. Discarding it and bounding the integral by (e^{at}−1)/a proves

\[
\mathbb E[V(W_t)\mathbf 1_{t<\tau}]
\le e^{-at}V(W_0)+\frac Ba(1-e^{-at}).
\]

Alternatively L_TV≤B and ordinary stopping give E V(W_{t∧τ})≤V(W0)+Bt. Since V(Wτ)=ρ² on the radial exit boundary, this implies P(τ≤t)≤[V(W0)+Bt]/ρ². Compactness of S permits the full tube used here; a truncated chart would require counting its other exits. The first estimate is a killed moment. Neither estimate is an unconditional long-time survival guarantee.

## 7. Scope of the result and remaining obligation

The strongest supported local result is an exact normalized augmented construction with a nonzero smooth coherent minimum manifold, an open deterministic attracting basin, independent links that actually evolve in that basin, a derived collective response, and separate finite-time persistence and departure certificates. The actual finite-temperature diffusion has the stated invariant law and short-time noise leakage, together with killed-tube bounds under explicit generator inequalities. This is conditional on the supplied microscopic priors, couplings, and kinetics.

The minimal remaining obligation toward the full contract is to specify retained parent state, normalized parent evaluator and child conditionals, and an exact descended generator or a quantitatively bounded force error for this same microscopic system. A second reduction must use the inherited first-stage state and kinetics. Neither the basin proof nor a common Gibbs law establishes those facts. The next material action is that same-model parent construction, retaining its necessary stabilizer, boundary, and conditional data. No ledger closure is assigned here.

This lane ran read-only source searches, reads, Git status/revision inspection, and source hashing. No numerical or symbolic experiment, test suite, GPU calculation, stochastic simulation, Lean operation, or tamper check ran. The mathematical artifact is this file. At the final source check, repository HEAD was `de254119d370c983578228bae025455aa3280679`; the reviewed uncommitted coherence source SHA256 was `b63211fd85b12dcc1117bfef4b09aaed3f24e90ce2888249dd840bec99187150`. This hash records which text was checked and is not a mathematical acceptance criterion. Other workers' files were not edited.
