# Exact nonlinear coefficient memory and the cost of Gaussian parents

September 11, 2026 continuation. At the fixed base point c_*, the native Gaussian belief/model/link equations admit an exact nonlinear realization with twelve recognition coefficients and six structural links for the existing four-child example. Two stages of normalized Gaussian marginalization compose exactly, but retaining their native learning and response on the full admitted coefficient family requires all twelve recognition dimensions locally at a generic point. This is a preparation-dependent inference representation and a scoped obstruction to further smooth compression. It is not a learned meta-agent hierarchy.

## 1. Sources, question, and fixed experiment

The starting point is [pointwise-gaussian-link-learning.md](pointwise-gaussian-link-learning.md), equations (1)-(9), and its conditional-memory equations (10)-(14). The most recent [two-stage response calculation](local-interfaces-and-two-stage-response.md) retains first variations only and separates reference-score expectations from a normalized channel on random samples. The question here is whether the actual nonlinear information-coordinate dynamics admit smaller exact memory, and what remains after comparing with a fine implementation using the same preparation restriction.

The normalized directed two-channel source is [Theory/06a_generative_gaussian.tex](../../../Theory/06a_generative_gaussian.tex), equations eq:gen-lg-model through eq:gen-lg-spd. The ambient laws, independent graph links, common principal-bundle types, and fixed-point scope remain those in [STATUS.md](../../STATUS.md). The current Research [meta-agent concept](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) and [composition theme](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Staged hierarchy formation and RG composability.md>) require a joint law, evaluator, access, marks, and sufficient memory. Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), sections sec:meta_agent_variational and app:rigorous_rg, already distinguishes variational licensing, fitted-prior barycenters, and conditional dynamical closure. In particular, a reduction in a dense matrix representation is not the manuscript's unproved net licensing gain.

Keep the exact four-child model and sensor from the previous calculation. Let x=(m1,b1,m2,b2,m3,b3,m4,b4), c=1/2, and let the six positive links have order (m12,b12,m23,b23,m34,b34). The residuals are m1, b1-c m1, mi-theta_mi m_(i-1), and bi-c mi-theta_bi b_(i-1). Write their matrix as R(theta). It is unit lower triangular. The source joint is

\[
 p_\theta(o,x)=N(x;0,J_0(\theta)^{-1})N(o;Hx,s),
 \quad J_0=R(\theta)^\top R(\theta),\quad \det J_0=1.
 \tag{1}
\]

Here Hx=(m2+b2+m4+b4)/2, s=600923/46656, and the conditioning value is o=4. These values and the two candidate blocks A={1,2}, B={3,4} are retained supplied choices. They are not new observations or a learned sensor/grouping. Define L=H^T H/s, h=H^T o/s, and K(theta)=J0(theta)+L. The recognition law is q=N(J^{-1}h_q,J^{-1}). Its native equations are

\[
 \dot J=K(\theta)-J,\quad \dot h_q=h-h_q,
 \quad \dot\theta=-M(\theta)^{-1}g(J,h_q,\theta),
 \tag{2}
\]

\[
 g_a=\tfrac12\operatorname{tr}[(C+\mu\mu^\top-C_0)J_a],
 \quad M_{ab}=\tfrac12\operatorname{tr}(C_0J_aC_0J_b),
 \quad C=J^{-1},\ C_0=J_0^{-1},\ J_a=\partial_aJ_0.
 \tag{3}
\]

This is the previously derived product-Fisher flow. Both channel coordinates and all independently moving links remain. A fixed chart is used; no raw Euclidean Lie-algebra descent or base transport is introduced. Assertions about solutions are restricted to intervals on which the positive structural chart and the smooth ODE solution remain admitted.

## 2. Exact finite coefficient closure, with preparation explicit

The elementary general statement is useful. Suppose the posterior target precision has a finite affine representation

\[
 K(\theta)=B+\sum_{j=1}^r f_j(\theta)A_j,
 \quad J(0)=B+\sum_{j=1}^r z_j(0)A_j,\quad h_q(0)=h,
 \tag{4}
\]

where B,A_j are fixed symmetric matrices and the A_j are linearly independent. Then

\[
 J(t)=B+\sum_j z_j(t)A_j,\quad h_q(t)=h,
 \qquad \dot z_j=f_j(\theta)-z_j.
 \tag{5}
\]

Substitution proves equality with (2), and uniqueness of the linear precision equation proves invariance. The integral formula is an exponentially weighted average of the initial precision and the positive target precisions; consequently J remains SPD. Coupling theta through the actual (3) gives the same nonlinear E/M solution by uniqueness, not a linear approximation or an imposed slow equation. The independent-basis assumption establishes a one-to-one coordinate representation of this invariant family; it does not prove that every point in that family is reachable from the chosen autonomous preparation set.

For each residual involving a scalar link, write r_e(theta)=a_e-theta_e b_e as a row on the full x. Its contribution is

\[
 r_e^\top r_e=a_e^\top a_e+\theta_e A_e+\theta_e^2 B_e,
 \quad A_e=-(a_e^\top b_e+b_e^\top a_e),
 \quad B_e=b_e^\top b_e.
 \tag{6}
\]

The fixed bridge term is part of a_e. Distinct links occur in distinct residual rows, so there are no cross-link monomials in this displayed model. Let K_fixed=R(0)^T R(0)+L. The exact representation is

\[
 J=K_{\rm fixed}+\sum_{e=1}^6(\ell_e A_e+\nu_e B_e),
 \quad \dot\ell_e=\theta_e-\ell_e,
 \quad \dot\nu_e=\theta_e^2-\nu_e.
 \tag{7}
\]

The twelve matrices are independent: each A_e has a distinct source/receiver off-diagonal entry absent from the B_e and the other A_e; after their coefficients vanish, the six B_e are the distinct first-six-coordinate diagonal units. Thus twelve coefficients encode this precision family exactly.

Posterior preparation q(0)=pi_theta(0) gives ell(0)=theta(0), nu(0)=theta(0)^2, h_q(0)=h. More generally, define v_e=nu_e-ell_e^2. Direct differentiation yields

\[
 J=R(\ell)^\top R(\ell)+L+\sum_e v_eB_e,
 \qquad \dot v_e=(\theta_e-\ell_e)^2-v_e.
 \tag{8}
\]

Hence v(0)>=0 implies v(t)>=0. Since R(ell) is unit lower triangular, (8) proves SPD throughout that coefficient domain, including v=0. Positivity of ell is also preserved if ell(0)>0 and theta remains positive. The nonnegative v is an exact history variance; replacing nu by ell squared omits positive precision terms whenever a link changes. The extra terms are neither a chosen penalty nor a new likelihood.

This omission occurs on actual posterior-prepared native trajectories, not just with an arbitrarily driven theta. If the native initial velocity is u=dot theta(0), smoothness and (7)-(8) give

\[
 \ell(t)=\theta(0)+\tfrac12u t^2+O(t^3),\qquad
 v_e(t)=\tfrac13u_e^2 t^3+O(t^4).
 \tag{9}
\]

For the retained fixed sensor, start at theta(0)=theta_ref+(1/10,0,0,0,0,0), where theta_ref=(1/3,1/2,1/2,2/3,2/3,1/3), and q(0)=pi_theta(0). The exact calculation finds nonzero u from (3) and stores all its rational entries and the coefficients u_e^2/3. No trajectory was integrated. Equation (9) proves that at least one history-variance term is generated for sufficiently small positive t.

Arbitrary initial Gaussian recognition is a different contract. In general its exact solution contains

\[
 J(t)=B+\sum_j z_j(t)A_j+e^{-t}E,
 \qquad h_q(t)=h+e^{-t}d,
 \tag{10}
\]

where E is the component of J(0)-B outside the coefficient span and d=h_q(0)-h. For n=8, E requires 36-12=24 independent preparation constants and d requires eight. Storing them as a fixed recovery table does not discard their resource cost. Finite t never sets their nonzero contributions exactly to zero. The twelve-coefficient claim therefore cannot be exported to arbitrary initial Gaussian laws.

## 3. Actual learning, normalization, and resource comparison

The filtered precision does not replace the generative prior by R(ell)^T R(ell). The current model is still J0(theta), and its complete normalization and Fisher metric still determine learning. For the directed unit-variance factors, iterated conditioning makes the distinct prior scores orthogonal. Thus

\[
 M_{ef}=\delta_{ef}E_{p_\theta}[x_{p(e)}^2],\qquad
 g_e=-E_q[x_{p(e)}r_e(\theta)x],
 \tag{11}
\]

where p(e) denotes the source coordinate. This is equivalent to (3); the prior term vanishes here because det J0=1 and the prior expected residual score is zero. It must not be omitted in another normalized residual model with a nonconstant determinant. The exact calculation compares the trace metric and force with (11) at a nonstationary admitted coefficient point.

If the full VFE is needed, it is determined by these same quantities:

\[
 \mathcal F=\tfrac12\left[
 \operatorname{tr}(KC)+\mu^\top K\mu-2h^\top\mu+o^2/s
 +\log\det J-\log\det J_0+\log s-n+\log(2\pi)\right].
 \tag{12}
\]

This follows directly from E_q[log q-log p_theta(o,x)]. Consequently the coefficient realization preserves the full VFE and the existing dissipation identity along its admitted solutions, not merely current sensor moments. Formula (12) is for the one-dimensional fixed observation in (1).

The fair state comparison is therefore:

| Representation | Recognition coordinates | Structural coordinates | Total |
| --- | ---: | ---: | ---: |
| Unrestricted dense Gaussian | 44 | 6 | 50 |
| Native coefficient family, h_q=h | 12 | 6 | 18 |
| Same coefficient family used by the fine implementation | 12 | 6 | 18 |
| Either marginal stage with the complete coefficient memory retained | 12 | 6 | 18 |

The 50-to-18 representation change is exact for the admitted preparation class. It is available before forming a parent. The marginal laws are derived outputs of the eighteen coordinates; caching them adds storage. Both implementations still require the factor graph, bridge/noise/sensor specification, link labels, observation, and an evaluator for inverses or selected moments and normalizers. A hierarchical evaluator additionally needs grouping maps, elimination/recovery data, shared boundary factors, and communication. No timing, bandwidth, minimum-description-length advantage, or positive net organizational gain is established by the table.

For larger block chains, the pre-observation precision from (8) is block tridiagonal and this scalar sensor adds a rank-one matrix. Factorization/selected inversion or elimination can exploit that structure in a fine implementation as well as in a hierarchical one. Dense inversion is not the only admissible baseline. Extending this specialization to another graph, a nonlinear representation of G, variable covariances, or random latent links requires its actual coefficient-span and cost calculation.

## 4. Exact two-stage elimination, including the scalar normalizer

The static sample maps are unchanged: Y=(m2,b2,m4,b4) and Z=(Y_A+Y_B)/2. For a Gaussian written with unnormalized exponent -x^T Jx/2+h^T x+kappa, partition x=(y,u). Integrating u gives

\[
 J_y=J_{yy}-J_{yu}J_{uu}^{-1}J_{uy},\qquad
 h_y=h_y^{\rm full}-J_{yu}J_{uu}^{-1}h_u,
 \tag{13}
\]

\[
 \kappa_y=\kappa+\tfrac12h_u^\top J_{uu}^{-1}h_u
 +\tfrac{d_u}{2}\log(2\pi)-\tfrac12\log\det J_{uu}.
 \tag{14}
\]

Completing the square proves these statements. The discarded block is SPD, so the integral and Schur complement are admitted. These standard Gaussian identities are also given in [Rasmussen and Williams, Appendix A, A.4-A.6 and A.11-A.15](https://gaussianprocess.org/gpml/chapters/RWA.pdf), checked during this continuation. The dynamical memory and lower-bound results here do not follow from that citation alone.

The first elimination discards (m1,b1,m3,b3). The second uses coordinates (Z,D), with D=Y_B-Y_A. This four-dimensional coordinate change has determinant one. Integrate D using (13)-(14). Nonnegative integration, or direct completion of the full square, shows equality with direct reduction to Z. In particular,

\[
 C_Y=F_Y C F_Y^\top,\quad C_Z=F_Z C F_Z^\top,
 \quad \mu_Y=F_Y\mu,\quad\mu_Z=F_Z\mu,
 \tag{15}
\]

and the two eliminated determinants multiply with det J_Z to give det J. The quadratic shifts in (14) likewise add to the direct shift. The exact calculation checks these equalities, not only covariance agreement. In this fixed preparation class h has support in the sensor subspace, so after either reduction the information vector is the corresponding unchanged sensor information; in particular h_Z=(o/s,o/s).

The same sample channels push p_theta, its posterior, and every q in the family. Because the observation depends only on Z, the retained generative sensor is N(o;Z_m+Z_b,s), and its evidence equals the fine evidence. Conditional-KL disintegration gives

\[
 \mathcal F(q,\theta)=\mathcal F_Y(q_Y,\theta)
 +E_{q_Y}{\rm KL}(q(x\mid Y)\Vert p_\theta(x\mid Y)),
 \tag{16}
\]

with a second such term from Y to Z. These are correlated joint pushes; shared observations are not multiplied once per block. The hidden KLs need not vanish. Keeping (ell,nu,theta) evaluates them and their effect on learning exactly.

All these Gaussian marginalizations are smooth functions of the full coefficient state. Recomputing them as that state evolves therefore reproduces their nonlinear trajectories exactly. That statement retains the full coefficient memory; it does not say that (13) obeys the native equation with only a coarse posterior target. In general dot J_y has the extra conditional-mismatch term already derived in pointwise-gaussian-link-learning.md, equation (14).

The first-level eliminator for x3 needs factors crossing the A/B cut as well as the internal B factors. Its output is a joint boundary potential on x2 and x4. Independent block marginals cannot generate that factor. An implementation may pass potentials on a shared separator and retain recovery information for the six learning forces, but must count those messages and the common structural coordinates. The earlier six-scalar first-variation interface is not a proved complete nonlinear initializer here.

## 5. A differential obstruction to dropping this memory

The exact sample reduction has dimensions 8 to 4 to 2. This does not imply that its full learning-memory realization has those dimensions. We can test the latter without approximating the ODE. Fix theta at the interior coefficient point recorded in [result.json](evidence/nonlinear-filter/result.json). Let z=(ell,nu), C=J(z)^{-1}, and let Psi_F(z) collect the upper-triangular entries of C_F=F C F^T. Since h is fixed in the sensor subspace, C_F also determines the retained mean. For a coefficient direction dJ,

\[
 dC=-C(dJ)C,\qquad d\mu=(dC)h,
 \quad dg_a=\tfrac12\operatorname{tr}[
 (dC+d\mu\mu^\top+\mu d\mu^\top)J_a].
 \tag{17}
\]

For the actual native recognition field, independently of the simultaneous value of dot theta,

\[
 \dot C=C-CK(\theta)C,\qquad
 d\dot C=dC-(dC)KC-CK(dC),
 \tag{18}
\]

where the differential in (18) holds theta fixed. Thus the gradients of the current retained covariance, current learning forces, and its next covariance velocity are all explicit rational functions of z and theta. Exact elimination gives:

| Output differentiated with respect to the twelve coefficients | Rank |
| --- | ---: |
| Y covariance | 9 |
| Z covariance | 3 |
| Six current structural forces | 6 |
| Y covariance and current forces | 11 |
| Z covariance and current forces | 9 |
| Y covariance, current forces, and Y covariance velocity | 12 |
| Z covariance, current forces, and Z covariance velocity | 12 |

The missing current-output directions are consequential. [observability-result.json](evidence/nonlinear-filter/observability-result.json) stores the one-dimensional nullspace for (C_Y,g), the three-dimensional nullspace for (C_Z,g), and their nonzero next-response matrices. The latter has rank three. These are differential witnesses inside ell>0, v>0 and J SPD; sufficiently small signed perturbations stay in that admitted open domain.

For the resulting local lower bound, suppose a smooth exact realization over an open neighborhood encodes z into k additional real coordinates s(z), retains theta, and has smooth autonomous dynamics and decoders reproducing the retained Gaussian law and the native theta trajectory. Then g=-M dot theta and dot C_F are also smooth functions of (s,theta). At fixed theta the chain rule gives

\[
 \operatorname{rank}D_z(C_F,g,\dot C_F)
 \le \operatorname{rank}D_zs\le k.
 \tag{19}
\]

The rank-twelve witness therefore forces k>=12. Together with the six retained structural coordinates, the exact coefficient implementation attains this eighteen-dimensional lower bound locally at the displayed point, for this smooth realization contract. It applies to either stage. A nonzero rational minor remains nonzero on an open neighborhood and fails only on a proper algebraic locus in the admitted parameter domain. This is a finite exact algebraic witness supporting the written differential argument; it is not an empirical numerical rank estimate.

The qualification about the open invariant family matters. All autonomous trajectories starting from posterior preparation lie in it, but its full interior has not been shown reachable by those preparations with this one fixed observation. At fixed initial time, the posterior-prepared set has six parameters; adjoining elapsed time produces an image of dimension at most seven wherever the flow is smooth. The rank argument does not establish a twelve-memory lower bound on that smaller reachable image. Nor does it rule out nonsmooth encodings, changed preparation interfaces, changed observations or controls, restricted structural trajectories, approximate prediction, or a different normalized model.

One can always label such a prepared trajectory by its initial six links and elapsed time and recover it by solving the original ODE. That formal low-dimensional label can require the complete fine computation for every query. It supplies no local parent evaluator or useful computational saving by itself. A useful reduction on the actual reachable family would need a constructive, resource-counted evaluator and a compatible initialized update; counting initial labels is insufficient.

## 6. What is and is not a complete parent

The variables x,Y,Z are random samples. The quantities ell,nu are coefficients of the recognition law and its inference history. The independently learned theta is a structural model coordinate. Static kernels x to Y to Z are normalized and recognition-independent. A channel on x alone cannot emit ell,nu as deterministic marks that differ between equivalent positive Gaussian recognition laws: if its output is almost surely one constant under one such law, equivalence makes it the same constant under the other. This is the same distinction exposed by the prior score-mean construction.

A joint protocol could include fixed preparation/history access in an augmented source, but that augmented normalized experiment must actually be supplied and counted. Merely appending current recognition parameters to a claimed fixed generative mechanism does not construct it. The present result supplies exact nonlinear inference equations and normalized static marginal models separately. It does not certify a complete parent random carrier with inherited law-valued model presentations, endogenous membership, or a controlled sample path.

The scoped conclusion is therefore exact: the current Gaussian source supports an eighteen-coordinate nonlinear solver for its declared coefficient family and posterior-prepared trajectories; the same solver is available to the fine model. Its two supplied marginal stages compose, and their full smooth native learning/response over the open coefficient family cannot discard further memory near the demonstrated point. Neither the earlier first-order 50-to-26-to-17 response count nor the present static 8-to-4-to-2 sample maps establishes complete resource savings or formation.

## 7. Evidence and continuation boundary

Two distinct tiny standard-library Fraction calculations ran once each under pinned CPython 3.14.7 with -I -B. The first checks the coefficient basis and positivity identity, exact native precision vector, model Fisher/forces, two-stage marginal means/covariances, determinant and quadratic normalizers, current-output Jacobian ranks, and a nonstationary posterior-prepared learning velocity. The second addresses the newly exposed missing-memory question by adding the covariance-velocity derivatives and exact nullspace witnesses. Their result files, scripts, and stdout are in [evidence/nonlinear-filter/](evidence/nonlinear-filter/). The helper import is guarded and does not execute the preceding response experiment. No old scientific calculation, ODE trajectory, data collection, broad test suite, GPU work, Lean, or tamper check ran. No formal ledger certificate is issued.

The preceding goal turn was progress. This continuation made three sequential substantive passes: nonlinear coefficient invariance and preparation cost; normalized two-stage elimination; and the exact missing-memory response obstruction. The original fifteen heterogeneous admissions and all previous scoped negative results remain intact. The full hierarchy goal is incomplete.

The next decisive question is the intended formation mechanism, now against this exact nonlinear state: can a dynamically reached coherent sector supply a useful closed parent evaluator and persistent membership after its preparation, structural, observation, and recovery costs are counted? The full open coefficient family cannot do so by merely discarding hidden memory. A narrower native reachable or attracting sector must be derived, not imposed by deleting its transverse directions; the rank result does not exclude it. Before another example, reconcile that sector with the prior actual alignment-tangency counterexample and the manuscript's intermediate-coherence licensing condition. No new sensor, penalty, tolerance, preparation, or data collection is authorized by this continuation.
