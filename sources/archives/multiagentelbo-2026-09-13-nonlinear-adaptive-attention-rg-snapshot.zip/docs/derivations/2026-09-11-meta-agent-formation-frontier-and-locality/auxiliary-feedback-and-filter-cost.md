# Auxiliary feedback, response memory, and the two-stage filter cost

September 11, 2026 continuation at c_*. Conditioning a probability update on the existing auxiliary membership history produces a normalized feedback process and preserves the native recognition-law evolution. Complete marked parents still compose. The feedback acts on sampled probabilities; it does not change the native E/M parameter vector field or derive a new post-merge objective.

This construction also resolves a cost that the preceding rank-transport process left open: one auxiliary panel admits an exact eight-scalar filter for future original-label records, including during learning. Using the full two-stage history gives an explicit finite prediction carrier with 6,541 states. Its generic filter uses 6,540 probabilities; that is a construction, not a minimal filter-dimension theorem. At equilibrium the two-stage history chain contracts centered correlations by a factor at most (10-2 sqrt 2)/23, approximately 0.31180752, per declared sweep. It does not generate arbitrarily long correlation times in that clock.

## 1. Sources and the inference target

The [labeled model](learned-multilabel-membership-and-stopping.md), Sections 2–5, fixes the normalized translation-group realization, separate original belief/model labels, correlated conditional geometry Psi_p, native learning, and the complete marked channel. The [kinetic realization](kinetic-realization-and-response-persistence.md), Sections 2–4, supplies its beta-CDF transport H_t on explicit algorithm state a=(alpha,beta,u) and p. Its Sections 6–7 supply the comparison process and the transient beta-filter obstruction. Neither result is rerun or replaced.

[Theory/07e](../../../Theory/07e_inference_memory.tex), sec:rg-memory-parent-mechanism, already declares a parent-sensitive posterior update and its order. The [September 9 construction](../2026-09-09-parent-sensitive-rg/construction-or-strongest-theorem.md) retains the whole-clock and stationary-entrance comparisons. [Conditional matching](conditional-matching-dynamics-and-local-obstruction.md), Section 6, explains why state-transition and emission factors cannot be separated without checking their joint law. The present update uses those mechanisms as source context, while explicitly changing the retained statistic that conditions the refresh.

The live [research concept](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires joint laws, evaluators, access, marks and memory. Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), sec:meta_agent_variational, leaves the post-merge functional and organizational overhead unspecified. A Gibbs sampling choice is not a derivation of that functional. The revised attachment's original heterogeneous experiment and its fifteen negative local admissions remain unchanged.

Let b_j=beta_j+1 and write nu_a as the product of Beta(alpha_j,b_j) laws on all m=8 probabilities. Let h be the finite auxiliary flag history through d fixed RG levels, together with any discrete root/tree choices. It is not the geometric parent coordinate. The source samples one belief and one model flag on every first-level edge and subsequently only on surviving cuts. Let t_j(h) be the number of times label j was sampled and s_j(h) its successes. Thus 1<=t_j<=d. Conditional on a fixed history, root/tree probabilities and cut-selection consistency do not depend on p, so

\[
 K^{(d)}(h\mid p)=c_h\prod_j p_j^{s_j(h)}(1-p_j)^{t_j(h)-s_j(h)},\qquad
 J_a(dv\mid h)=\prod_j\operatorname{Beta}
    (dv_j;\alpha_j+s_j(h),b_j+t_j(h)-s_j(h)).
 \tag{1}
\]

Here c_h is a positive combinatorial/root-choice factor on the admitted support. Bayes normalization gives (1); all omitted histories have zero channel probability. Auxiliary successes are not added to the external training archive, n_j, or the native E/M parameters. The conditional is a sampling kernel at the explicit a.

At the finite learning equilibrium, nu_a is the posterior of the fixed labeled archive under the learned model prior, so J_a is that augmented posterior's conditional. During learning, it is the conditional of the current recognition law nu_a K^(d), generally different from the current model posterior. Its role is explicit. The original model, likelihood, and static common-channel prior/posterior/recognition pushes stay fixed.

## 2. The feedback row and its exact native-law marginals

One inference tick consists of one conditional probability draw, one unit of the native E/M flow, and the stated conditional geometry/panel draw. Given x=(a,W,h), sample v from J_a(.|h), set (a',p')=H_1(a,v), sample W' from Psi_(p'), and sample h' from K^(d)(.|p'). The normalized row is

\[
 T_d(x,da'dW'dh')=
  \int J_a(dv\mid h)\delta_{\Phi_1(a)}(da')
                \Psi_{H_1^p(a,v)}(dW')K^{(d)}(dh'\mid H_1^p(a,v)).
 \tag{2}
\]

Each factor has mass one. The previous p and geometric marks are refreshed rather than held fixed. This is not the old full-parent conditional refresh: a full parent retains p and therefore cannot change it by refreshing within its fiber. The present conditioning uses the auxiliary history while retaining the complete parent as the state on which the new row is evaluated.

For the prepared recognition law, the h marginal is mu_a(h)=integral nu_a(dp)K^(d)(h|p). Bayes gives sum_h mu_a(h)J_a(.|h)=nu_a. The CDF transport then sends that marginal exactly to nu_(Phi_1(a)), and the final factors install its correct conditional geometry and history. Hence every one-time recognition law is the original native one. This proof applies at any fixed finite d. It proves no simultaneous temporal transport of the generative prior family and does not put an unrecorded recognition law inside a fixed microscopic generative mechanism.

Different histories give different J_a and future probability forecasts: there is actual sample-path feedback. The deterministic parameter flow Phi is still unchanged. No law-level structural learning advantage, physical-time law, or derivation of this kinetic choice from the ELBO follows.

The complete source parent C retains a, every original p, the rooted law/model coordinates, dressed cuts and loops, and the auxiliary history. Its pushed row is obtained by replacing Psi K in (2) by the existing normalized marked sampler. It depends on the source only through Cx. Thus the strong joint state/record factorization holds for all consistent source states. Preparing the recognition family is needed only for the one-time marginal statement above.

For a label probe j after the update, multiply the integrand by (p'_j)^e(1-p'_j)^(1-e). This factorization preserves all original record paths and record-history-dependent probe policies that descend. The marked tree maps compose on the actual joint first-stage output, with the full history carried once and Phi_1 applied once per inference tick. No separate learning sweep is inserted at each RG level. Frame translations push the Gaussian conditional and roots together; p, flags and counts are invariant. This remains the admitted translation example, not a GL(K) extension.

## 3. Exact one-panel response dynamics and filtering

For d=1, h is the vector of eight binary flags. The next row depends on old a and h but not on old p. Define the transported conditional moments

\[
 m_{r,j}(a,h_j)=\int \operatorname{Beta}(dv;\alpha_j+h_j,b_j+1-h_j)
              [H_1^p(a,v)_j]^r,\qquad r=1,2.
 \tag{3}
\]

These one-dimensional normalized integrals suffice for the joint next flag and next external record on label j. With m_1,m_2 denoting the row moments, its two emitted matrices, whose columns are h'_j=0,1, are

\[
 E_j^0(h_j,\cdot)=(1-2m_1+m_2,m_1-m_2),\qquad
 E_j^1(h_j,\cdot)=(m_1-m_2,m_2).
 \tag{4}
\]

The entries are integrals of (1-p')^2, p'(1-p'), and p'^2, so they are nonnegative and sum over e and h' to one. Unprobed labels use the row (1-m_1,m_1). The external record and the new flag share p'; multiplying two independent Bernoulli rows with the same averaged mean would be wrong.

Start with the source's product flag law and observe only the original labeled records. Let theta_j=P(h_j=1|retained records). Conditional transitions factor by label; a probe contributes a factor only to its chosen label. Therefore the filter remains a product of eight Bernoulli laws, including for policies choosing labels from the observed history. Put M_r=(1-theta_j)m_(r,j)(a,0)+theta_j m_(r,j)(a,1). Then

\[
 \theta'_j=\begin{cases}
 M_2/M_1,& e=1,\\
 (M_1-M_2)/(1-M_1),& e=0,
 \end{cases}
 \qquad
 \theta'_i=M_{1,i}\quad\text{for unprobed }i.
 \tag{5}
\]

All denominators are positive on the admitted interior family. This is an exact eight-scalar future-record filter; it does not claim that the current p posterior is beta, or that eight numbers reconstruct every current geometric posterior. Predicting future complete states can use the mixture of rows (2). Reconstructing a current-state posterior requires the corresponding last-step conditional law. The eight filter variables supplement the known 24-coordinate native algorithm state and replace the unclosed rank-transport filter, because the path law has changed.

At equilibrium H_1^p is the identity. Write S_j=alpha_j+b_j and mu_j=alpha_j/S_j. The binary flag transition and its sole nonconstant eigenvalue are

\[
 D_j(h_j,1)=\frac{\alpha_j+h_j}{S_j+1},\qquad
 \lambda_j=\frac1{S_j+1},\qquad
 E[h'_j-\mu_j\mid h_j]=\lambda_j(h_j-\mu_j).
 \tag{6}
\]

Its stationary flag law is Bernoulli(mu_j), and detailed balance follows by direct multiplication. The eight-label transition is the tensor product of these two-state matrices, so its nonconstant eigenvalues are products of the lambda_j. They are approximately 0.05132079 for each internal label and 0.18469903 for each cut label in the retained example. For repeated probes of one label at lag l>=1,

\[
 \operatorname{Cov}(E_k,E_{k+\ell})=
             \lambda_j^{\ell}\operatorname{Var}_{\nu_*}(p_j).
 \tag{7}
\]

To prove (7), the current external record and current flag have covariance Var(p_j), since they are independent Bernoulli(p_j) draws conditional on p_j. The future record's conditional mean given the current flag is mu_j+lambda_j^l(h_j-mu_j). Taking covariance gives the result. The preceding rank-transport process instead retains Var(p_j) at every lag at equilibrium. The one-lag covariances here are approximately 0.00025413 internally and 0.00845334 on cuts. These are informative, but they decay; equal one-time recognition laws do not preserve the previous record paths.

Every binary history has positive stationary probability and the finite flag transition is strictly positive. Thus all flag states recur, and the current-state forecast in (6) does not converge almost surely to a fixed value along a stationary path. Convergence of the learned law and decay of correlations remain different notions of persistence. The full next-probe vector also separates all 256 flag states, so a deterministic quotient preserving every such row for all flag preparations cannot identify any of them. On an open product-filter family, its diagonal derivative with respect to theta has entries lambda_j>0; at least eight smooth filter coordinates are needed to preserve that vector there.

## 4. Same mean lifetime, different survival curve

Use the same first-level pair event R={{0,1},{2,3}}, the same equilibrium preparation and one complete sweep per native inference tick. Let P be the subset of flag vectors realizing that partition, let pi_P be the stationary row restricted to it, and let D_P be the killed flag matrix. Define V_n=pi_P D_P^n 1, so V_0 is occupancy and V_1 is the probability of two consecutive pair events. Stationary entrance survival is

\[
 J=V_0-V_1,\qquad
 S_n=\frac{V_n-V_{n+1}}J,\qquad
 E[T_P\mid\text{entrance}]=\frac{V_0}J.
 \tag{8}
\]

This follows from the source's entrance row pi_P(I-D_P) and its convergent killed series. At stationarity two consecutive flag panels under conditional feedback have law integral nu_*(dp)K(h|p)K(h'|p), exactly the two-panel marginal under the preceding fixed-rank process. Consequently V_0=A_1 and V_1=A_2 in that derivation: both constructions have occupancy 0.31071998, entrance flux 0.19951240, and mean pair duration 1.55739681 ticks. No waiting factor was inserted to force this equality.

The remaining survival law is inexpensive to evaluate exactly. The internal four flags must all remain one, contributing c=[(alpha_I+1)/(alpha_I+3)]^4 each tick. For either cut, restrict D_C tensor D_C to states 00,01,10, giving a 3 by 3 substochastic B. Let v=((1-mu_C)^2,(1-mu_C)mu_C,mu_C(1-mu_C)). Then

\[
 V_n=\mu_I^4 c^n(vB^n\mathbf1)^2.
 \tag{9}
\]

The saved exact results give the following comparison, with each process's stationary entrance preparation.

| Additional survived ticks | Conditional feedback | Previous rank transport |
| --- | ---: | ---: |
| 1 | 0.35688613 | 0.33586108 |
| 2 | 0.12834404 | 0.12598313 |
| 3 | 0.04619146 | 0.05151903 |
| 6 | 0.00215393 | 0.00512849 |

The survival curves cross; the unchanged mean does not establish dominance. At the first step the direction also has a proof. If s(p) is the pair-panel probability, conditional Jensen gives V_2=E[1_P(h)(E[s(p)|h])^2]<E[s(p)^3]=A_3, since the conditional variance is positive. Hence (A_2-V_2)/J exceeds the preceding (A_2-A_3)/J. Finite equal means force an eventual opposite difference; the exact calculation locates it by the third tick.

Partition labels alone do not give a closed process. Two current histories with the same pair partition, differing only by changing one cut's 00 flags to 01, have different next pair probabilities. Their gap is c a_0(a_1-a_0)(1-a_0^2)>0, where a_h=(alpha_C+h)/(alpha_C+3); it is approximately 0.04278521. Retaining the actual history in the complete parent is necessary for the claimed row closure.

At equilibrium the previous process changes no p values, while the new conditional draw changes all eight almost surely. Both redraw conditional geometry and panels. A sweep is one declared inference attempt, not one microscopic site update or one physical second. The additional eight beta draws are part of the new computation. The equality of lifetime means therefore comes from equal adjacent-panel laws, not equal microscopic work.

## 5. The complete two-stage prediction carrier

Adding feedback from a second level changes the first-level time kernel unless that higher-level history is added to its state. The d=1 chain above is a comparison process, not the unmodified first-level dynamics of d=2. For example, fix the same first pair panel and the same first-parent geometry and p. On one cut whose first flags are 00, second flags 00 versus 10 give next belief-label means alpha/(S+2) versus (alpha+1)/(S+2). Their positive gap 1/(S+2) proves that discarding the second history prevents a universal first-parent row for this feedback law. The fixed-d marked composition in Section 2 carries that history, or its sufficient counts, explicitly. It does not establish a projectively consistent family of time kernels as new feedback levels are appended.

For d=2, retain the actual second-panel cut selection. Let c=((t_j,s_j))_j be its label-count tuple. All auxiliary histories with the same c have the same J_a in (1); their root/tree factors cancel in that conditional. Thus c is sufficient for every future row of (2), even though the complete parent still retains its geometric and lineage marks. Write m(c) for the number of raw flag histories with that count tuple, with roots/trees marginalized. Then

\[
 k_c(p)=P(c\mid p)=m(c)\prod_jp_j^{s_j}(1-p_j)^{t_j-s_j},\qquad
 \sum_c k_c(p)=1.
 \tag{10}
\]

On a four-cycle there are either no surviving cut edges or at least two. With no cuts, the first panel has all four physical bonds open or exactly one closed bond. There are 1+4 times 3=13 raw/count states. If l>=2 bonds are closed, exactly those l edges are cuts. Each has three allowed first-channel pairs and four second-channel pairs: twelve histories. Their summed success pairs have eight possible values in {0,1,2}^2, excluding (2,2), with multiplicities 1,2,2,3,1,1,1,1. Noncuts have t=1 and both successes equal to one. Therefore

\[
 |\mathsf H_{\rm flags}|=13+6(12)^2+4(12)^3+(12)^4=28525,\qquad
 |\mathsf C|=13+6(8)^2+4(8)^3+(8)^4=6541.
 \tag{11}
\]

The [complete count carrier](evidence/auxiliary-feedback/two-stage-count-carrier.json) stores every c and multiplicity. The exact calculation checked (10) as a polynomial identity in all 6,561 product Bernstein coefficients of degree two in each of the eight probabilities. This checks every p, rather than normalization at a finite grid.

At equilibrium the count transition and its stationary law are explicitly

\[
 L(c,c')=m(c')\prod_j
  \frac{B(\alpha_j+s_j+s'_j,b_j+t_j+t'_j-s_j-s'_j)}
       {B(\alpha_j+s_j,b_j+t_j-s_j)},\qquad
 \pi(c)=m(c)\prod_j\frac{B(\alpha_j+s_j,b_j+t_j-s_j)}{B(\alpha_j,b_j)}.
 \tag{12}
\]

These beta integrals use the normalized definition in [NIST DLMF 5.12.1](https://dlmf.nist.gov/5.12.E1). Every entry is positive. Equation (10) gives row normalization, and multiplying (12) by pi(c) gives a symmetric expression in c,c', proving detailed balance. A label emission multiplies the integrand by p_j or 1-p_j. During learning insert H_1^p inside those monomials and integrate under J_a; the resulting products of bounded one-dimensional integrals define the exact time-dependent joint rows L_a^(j,e). A normalized filter is

\[
 \rho'(c')=\frac{\sum_c\rho(c)L_a^{j,e}(c,c')}
                   {\sum_{c,c'}\rho(c)L_a^{j,e}(c,c')}.
 \tag{13}
\]

Thus a generic explicit future-record filter exists with 6,540 probabilities, plus the native algorithm state. No dense 6,541 by 6,541 matrix was constructed or executed. The integral/product representation supplies its entries. The eight independent Bernoulli filter of Section 3 cannot be assumed here: for example, exactly one cut indicator t_e=2 has zero probability, although each cut indicator has both values with positive marginal probability. The count law is not a product over edges. This observation does not prove that all smaller correlated filter representations fail.

The count-state requirement itself has a sharp deterministic boundary at equilibrium b_j=2. The five possible local next-label means have strict order

\[
 \frac{\alpha}{\alpha+4}
 <\frac{\alpha}{\alpha+3}
 <\frac{\alpha+1}{\alpha+4}
 <\frac{\alpha+1}{\alpha+3}
 <\frac{\alpha+2}{\alpha+4},\qquad \alpha>0.
 \tag{14}
\]

They identify (t,s) for that label. Hence the complete next-label response vector separates all 6,541 count states. No deterministic further identification preserves that vector for all count preparations. This is a predictive-carrier lower bound, not a 6,540-dimensional lower bound on all reachable Bayesian filters or a theorem about the earlier heterogeneous experiment.

There is also an exact full-rank statement for (12). On one edge put A=xy and let V_B be the span of the eight degree-two product Bernstein monomials excluding x^2y^2. A has a nonzero coefficient on the excluded monomial, so span(A) and V_B form a direct sum of dimensions one and eight. The three first-panel closed-pair polynomials (1-x)(1-y), (1-x)y and x(1-y) lie in V_B and are independent, as seen from their respective unique coefficients on Bernstein indices (0,0), (0,2), (2,0). Across four edges the no-cut columns span one all-A tensor and twelve tensors with one of those three factors. Columns with l>=2 cuts span the full V_B factors at those l edges and A elsewhere. These tensor sectors form a direct sum of dimension 1+12+6 times 8^2+4 times 8^3+8^4=6541. Nonzero multiplicities do not change independence. Thus the k_c are linearly independent polynomials. Their Gram matrix under the positive beta density is positive definite; (12), obtained by positive row scaling of that Gram matrix, has full rank. This proof does not require computing its dense matrix or establish full observable-filter dimension.

## 6. A contraction bound for adaptive finite-depth feedback

The absence of a dense matrix does not prevent a quantitative memory bound. At equilibrium let R_d be the probability-state kernel p -> h -> p' induced by K^(d) and its posterior conditional. Conditional expectation gives, for every centered square-integrable f,

\[
 \langle f,R_df\rangle_{\nu_*}
       =E\{E[f(p)\mid h]^2\}\ge0.
 \tag{15}
\]

Pre-sample d independent Bernoulli flags per label and discard those not requested by the sequential cut rule. The retained history is a function of that full ordered flag array. Independent seeds for root/tree indices convey no further information about p given the flags. Conditional Jensen bounds (15) above by the same expression with all d flags retained. This is a comparison of the same normalized source experiment, not an extra observed record.

For one label with p~Beta(alpha,b), the full d-flag conditional sampler has binomial sufficient count B and p'|B~Beta(alpha+B,b+d-B). It is self-adjoint, its range is the polynomials of degree at most d, and it preserves each degree filtration. On degree r its leading coefficient is

\[
 \lambda_r=\frac{d(d-1)\cdots(d-r+1)}
                    {(S+d)(S+d+1)\cdots(S+d+r-1)},
 \qquad r=0,\ldots,d,\quad S=\alpha+b.
 \tag{16}
\]

Indeed E[(p')^r|B]=(alpha+B)_r/(S+d)_r, and the leading p^r coefficient after binomial averaging is the r-th falling factorial of d. Self-adjointness and the nested polynomial spaces identify their one-dimensional orthogonal degree complements as eigenspaces. The kernel has rank d+1, so its orthogonal complement has eigenvalue zero. The ratio lambda_(r+1)/lambda_r=(d-r)/(S+d+r) is less than one. Thus its largest nonconstant eigenvalue is d/(S+d).

For the product prior, the full-array kernel is a tensor product and its largest nonconstant eigenvalue is max_j d/(S_j+d). The conditional-expectation bound in (15) passes this norm bound to the adaptive sampler. The history and probability kernels are the two products of the same conditional-expectation operator and its adjoint; they have the same nonzero eigenvalues. Therefore the equilibrium history/count chain has centered L2 contraction at most

\[
 r_d=\max_j\frac{d}{S_j+d}<1.
 \tag{17}
\]

This applies to membership and future-response functions of the retained auxiliary history. It does not assert reversibility of the full systematically refreshed geometric process. No independent slow geometric variable acts in (2). For the source's two-stage example, S_min=3+sqrt 2 and r_2=2/(5+sqrt 2), approximately 0.31180752. For any n_j>=1 in this same equilibrium learning family the bound is no larger. Greater alignment concentration makes this bound smaller, not larger. Increasing d can raise the bound, but also supplies more conditioning flags and a larger retained experiment.

For an auxiliary membership event P with stationary mass pi(P) strictly between zero and one, (17) gives crossing flux J_P>= (1-r_d)pi(P)(1-pi(P)). Combining with the source entrance identity gives

\[
 E[T_P\mid\text{entrance}]
       \le \frac1{(1-r_d)(1-\pi(P))}.
 \tag{18}
\]

For the first-level pair event under full two-stage feedback, this is approximately 2.10811542 ticks. It is an upper bound, not an executed mean of the two-stage chain. For events whose mass approaches one the bound can grow; such near-certain membership is not evidence of a small metastable group. At the fixed example and depth, these kernels have no arbitrarily slow centered auxiliary-response mode. No user tolerance or criterion for acceptable finite persistence is selected.

## 7. Resource and formation boundary

The complete geometric sample arrays remain 32, 24 and 16 at the fine, paired and grandparent representations. The same native algorithm state adds 24, giving 56, 48 and 40, before the shared auxiliary history and observation filter are counted. The 280 generic fixed Gaussian conditional coefficients, original record labels, cuts, loops and training archive remain. These are array counts, not measured runtime or minimum memory.

For one-panel feedback the future-record filter adds eight probabilities on both fine and parent sides, giving 64, 56 and 48 in that particular sample-plus-algorithm-plus-filter accounting. It is shared memory rather than a saving generated by a chosen grouping. A two-stage generic count filter adds 6,540 instead, giving 6,596, 6,588 and 6,580, before finite lineage/root/tree marks. The original 28,525 flag histories can be indexed in fifteen bits; their 6,541 predictive count classes require thirteen bits. Those discrete state indices do not replace a general probability distribution over the classes. A more efficient reachable correlated filter remains a separate question; the full-state count and Gram-rank statements do not decide its dimension.

The conditional draw adds eight beta samples per tick. Including residual angles and Gaussian means, one fresh fine geometry requires 32 continuous random inputs; the pair and grandparent recipes require 24 and 20. All require the native flow and CDF/inverse evaluations during learning. At equilibrium those transport evaluations are identity. No runtime benchmark was run. The input count is not a claim that the large filter has been evaluated cheaply.

This feedback closes the previously missing sample-path dependence on the retained membership history. It also shows why such dependence alone is insufficient for formation: the one-panel model factorizes into eight fast channels, and two-stage adaptive conditioning has the uniform bound (17). All one-time native recognition laws and their VFE remain exactly those of the source. No positive post-merge model-selection gain is created by adding a normalized auxiliary channel. The complete marked representations reduce specified geometry arrays, but their resource benefit relative to the best joint inference implementation and the manuscript's unprovided net-gain criterion is not established.

The next research decision should be made against that boundary rather than by adding another arbitrary sampler. Reconcile the source's post-merge generative replacement with the retained common-data experiment: identify which interaction terms and shared parent variables actually change, prove normalization and the resulting objective, and price their complete interface. If the source does not determine that replacement or its organizational cost, retain the precise external specification requirement. Neither a new penalty nor a feedback sweep selected for a desired lifetime is authorized by the existing native flow alone.

## 8. Executed evidence

[feedback_exact.py](evidence/auxiliary-feedback/feedback_exact.py) passed once under pinned CPython 3.14.7 in 0.10631330000069283 seconds. [result.json](evidence/auxiliary-feedback/result.json) records the exact two-state emitted kernels, twelve filter-update identities, one- and two-flag eigenvalue coefficients, seven pair-survival comparisons, the same-partition row discrepancy, 28,525 enumerated flag histories, 6,541 count classes, and all 6,561 polynomial normalization coefficients. The saved carrier gives every class and multiplicity. The old rank-transport coefficients were read from their preserved result, not regenerated.

General normalization, native-law preservation, strong marked composition, filter closure, carrier separation, tensor/Gram rank and contraction are the written proofs above. The finite calculation supports its named coefficients and polynomial identity; it is not a trajectory experiment, a numerical dense-rank computation, or a formal ledger certificate. No ODE integration, random sampling, full matrix construction, new data, broad suite, GPU work, Lean or tamper check ran. Saved data, earlier negative results, configuration, production code, canonical Desktop WIP and the Research vault remain unchanged.
