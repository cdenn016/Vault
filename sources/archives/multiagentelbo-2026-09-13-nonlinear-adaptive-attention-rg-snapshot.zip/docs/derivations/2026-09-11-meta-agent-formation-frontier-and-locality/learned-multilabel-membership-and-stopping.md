# Learned labeled parents, membership persistence, and recursive stopping

September 11, 2026 continuation at one base point c_*. The previous finite learning example observed a combined flag. This derivation retains every belief/model label, realizes a proper correlated law/model/link model, and carries its native learned law through two marked reductions. It also establishes why a convergent membership distribution does not by itself yield persistent organization or select a stopping level.

The realization below is an explicit translation specialization of the existing law-valued branch. It does not modify the heterogeneous finite experiment or its fifteen negative admissions. The example record counts specify a mathematical conditional experiment; no observations were collected.

## 1. Sources and unrestricted learning

[learning-compatible-alignment-parents.md](learning-compatible-alignment-parents.md), equations (1)-(6), gives the native flow for a regular minimal exponential family with retained statistics T, log normalizer A, moment map m, Fisher G, and fixed record-count vector c:

\[
 \dot\eta=\theta+c-\eta,\qquad
 \dot\theta=G(\theta)^{-1}[m(\eta)-m(\theta)].
 \tag{1}
\]

Work in its convex natural-parameter domain, with the segment from theta to theta+c regular and G positive definite there. Require the effective likelihood c^T T to be nonconstant after removing statistic redundancies. A finite stationary point would have eta=theta+c, but

\[
 c^\top[m(\theta+c)-m(\theta)]
 =\int_0^1 c^\top G(\theta+s c)cds>0.
 \tag{2}
\]

Thus the structural update cannot vanish: there is no finite interior stationary point in this unrestricted family. Mixed outcomes do not avoid this conclusion. The preceding finite equilibrium restricts the learned prior to a smaller family. Constant likelihoods on the actual geometric support are excluded; (2) proves neither global existence nor a particular boundary limit.

[agreement-sufficient-marked-parents.md](agreement-sufficient-marked-parents.md), Sections 1-5, supplies the complete probability catalog, correlated conditional evaluator, shared incidence, and marked staged push. [agreement-partition-selection-and-lineage.md](agreement-partition-selection-and-lineage.md), Sections 2-4, supplies the normalized auxiliary panel and common-data restriction. The [Research concept](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires law, evaluator, boundary access, structural marks, and memory. Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), sec:meta_agent_variational, leaves the net post-merge functional unspecified. The present construction does not supply it by replacing likelihoods or deleting internal records.

## 2. Proper two-channel realization

Take a connected oriented graph with N vertices and M physical edges. Specialize the common principal group at c_* to G=R^2 times R^2; its two translation projections act on the belief and model fibers. Each agent has law points b_i=N(mu_i^b,I_2) and m_i=N(mu_i^m,I_2). Each physical link has two independent R^2 coordinates a_e^b,a_e^m within one G element. For label j=(e,x), x=b,m, and e oriented from k to i, set

\[
 r_j=\mu_i^x-\mu_k^x-a_e^x,\qquad
 D_j=\tfrac12\|r_j\|^2
 ={\rm KL}\bigl(N(\mu_i^x,I_2)\Vert N(\mu_k^x+a_e^x,I_2)\bigr),
 \qquad p_j=e^{-D_j}.
 \tag{3}
\]

There are m=2M distinct binary record labels. Each has success probability p_j and failure probability 1-p_j. Equal unit covariances give the displayed Gaussian KL; the two channel energies are never combined in the external likelihood.

Specify a normalized conditional law h(mu|p), fixed independently of learning. An evaluable correlated choice is

\[
 h(\mu\mid p)=N(\mu;a+Lp,\Sigma),\quad \Sigma>0,\qquad
 P_u(\mu,r)=h(\mu\mid p(r))
          \prod_{j=1}^{m}\frac{u_j}{2\pi}e^{-u_jD_j},\quad u_j>0.
 \tag{4}
\]

Here mu contains all 4N child mean coordinates; a, L, and Sigma are fixed. Both L and Sigma can couple the channels and vertices. The (mu,a_links) to (mu,r) Jacobian has absolute value one. Integrating h and each radial factor proves normalization. Since d^2r=dD dphi, D_j is Exp(u_j), p_j is Beta(u_j,1), and conditional angles are independent uniform variables.

This explicitly realizes independent labeled p coordinates using actual two-channel geometry. It does not claim every induced geometric prior factorizes. The complete fine law is correlated through h and the link transformation. Its conditional geometry given p is fixed; freely learning that conditional remains outside the admission. Under passive frame translations the full prior is pushed along with its coordinates; (3) stays invariant. No noncompact invariant probability density is asserted.

The p-dependent regression can make both child-law coordinate marginals move:

\[
 E\mu=a+L E p,\qquad
 {\rm Cov}(\mu)=\Sigma+L{\rm Cov}(p)L^\top.
 \tag{5}
\]

This is a specified prior correlation mechanism, not a derivation of L or an unconstrained update of the child presentations. Conditional fluctuations remain.

## 3. Native finite learning with every label

For each label fix an ordered string with n_j>=1 successes and one failure, retaining all labels and order in one archive. The likelihood is the product of p_j^{n_j}(1-p_j). Its normalized evidence is

\[
 e(u)=\prod_j\frac{u_j}{(u_j+n_j)(u_j+n_j+1)}.
 \tag{6}
\]

Let recognition have independent p_j distributed as Beta(alpha_j,beta_j+1), with alpha_j>0 and beta_j>=0 initially, and retain h and the uniform-angle conditional. This is one correlated recognition law on the complete fine state. All scores depend only on p. The model Fisher has diagonal entries 1/u_j^2, and recognition Fisher has the positive-definite two-statistic beta blocks. Native E/M therefore gives

\[
 \dot\alpha_j=u_j+n_j-\alpha_j,\qquad
 \dot\beta_j=1-\beta_j,\qquad
 \dot u_j=u_j-u_j^2[\psi(\alpha_j+\beta_j+1)-\psi(\alpha_j)].
 \tag{7}
\]

Each block is the exact system in learning-compatible-alignment-parents.md, Section 4. Its compactness/dissipation proof applies to each of the finitely many blocks: the exact -log evidence confines u_j, the stable alpha filter is bounded away from zero, beta stays regular, and dissipation vanishes only at

\[
 u_j^*=\sqrt{n_j(n_j+1)},\qquad
 \alpha_j^*=n_j+u_j^*,\qquad \beta_j^*=1.
 \tag{8}
\]

Thus every stated initial condition gives a global solution converging to (8). Correlated geometry adds no parameter-dependent score because its conditional is fixed. At equilibrium E D_j=1/u_j^*>0 and exact D_j=0 has zero probability. This is finite alignment strength with disagreement.

For nonnegative integer k, beta integration gives

\[
 E p_j^k=\frac{(\alpha_j)_k}{(\alpha_j+\beta_j+1)_k}.
 \tag{9}
\]

This is a ratio of the beta integrals in [NIST DLMF 5.12.1](https://dlmf.nist.gov/5.12.E1); log moments follow by differentiation. These product formulas apply to (4), not to an arbitrary correlated p law.

## 4. Learned membership and the second-stage conditional

Use the existing auxiliary channel: a physical edge opens if its newly sampled belief and model flags both succeed. Given W its bond probability is q_e=p_(e,b)p_(e,m). The conjunction is a membership readout; each external record remains separately labeled. Summing auxiliary flags gives one, so they add no observed evidence. Define

\[
 Q_e(k)=E q_e^k=\prod_{x=b,m}
       \frac{(\alpha_{e,x})_k}{(\alpha_{e,x}+\beta_{e,x}+1)_k},
 \qquad
 B_e(t)=E(1-q_e)^t
       =\sum_{k=0}^{t}(-1)^k{t\choose k}Q_e(k).
 \tag{10}
\]

Unconditionally the bonds are independent with means Q_e(1) in this factorized p admission. The component partition law is the sum over compatible bond panels. Conditioning on a general partition can destroy edge independence; the joint p law and its panel likelihood must then be retained.

On the cycle 01,12,23,30, the event R_1={{0,1},{2,3}} is the unique bond pattern (1,0,1,0):

\[
 P(R_1)=Q_{01}(1)Q_{23}(1)B_{12}(1)B_{30}(1).
 \tag{11}
\]

Draw the next panel only on its surviving cuts, conditionally independently given p. Then

\[
 P(R_1,R_2=\{0123\})=
 Q_{01}(1)Q_{23}(1)
 [B_{12}(1)B_{30}(1)-B_{12}(2)B_{30}(2)]>0.
 \tag{12}
\]

The second moments matter: closed first cuts change their conditional p distribution. Replacing them by independently reused unconditional cut means gives a different probability.

An exact heterogeneous witness takes n=8 on both labels of 01 and 23, and n=1 on both labels of 12 and 30, each with one failure. At equilibrium u_internal=6 sqrt(2), alpha_internal=8+6 sqrt(2), u_cut=sqrt(2), alpha_cut=1+sqrt(2). All finite-panel probabilities lie in Q(sqrt(2)). The component rule is unchanged across edges. These specified record histories do not constitute learned selection from fresh data or a preferred grouping claim.

The exact full partition law gives P(R_1)=(384+256 sqrt(2))/2401, approximately 0.31071998, while the whole-network block has mass (424+296 sqrt(2))/2401, approximately 0.35094011. Its excess over the pair event is (40+40 sqrt(2))/2401>0; inspection of the other ten masses shows the whole-network block is modal. The joint pair-then-merge probability is approximately 0.13921742. Given the pair, the correct next-stage merge probability is 0.44804786; ignoring first-panel conditioning gives 0.50876649. Stronger internal agreement in this witness therefore does not make its paired partition modal.

## 5. Complete marked parents and resource accounting

Use the existing uniform root/tree rule. Retain every p_j, all root belief/model coordinates, every original dressed cut copy, internal independent loop marks, and finite panel/root/tree/incidence history. For k blocks, M-N+k edge copies remain outside the block trees, counting internal loops and cuts together. With four real group coordinates and four root means, the storage array has

\[
 d_R=4k+4(M-N+k)+2M=6M-4N+8k.
 \tag{13}
\]

This counts the specified arrays, not independent dimensions or a minimal parametrization. For the four-cycle, the fine sample has 4N+4M=32 continuous coordinates. The two-block event gives 8 root coordinates, 8 cut-link coordinates, and 8 probabilities: 24. The one-block grandparent has 4 root coordinates, a four-coordinate loop, and 8 probabilities: 16. Internal records, all original cut labels, and loop marks persist. The finite histories occur on both sides of the common augmented experiment and must be priced if compared to a baseline that omits them.

Given p, h and the angles are fixed across all priors, posteriors, and recognition laws. Conditioning further on the retained marks and history restricts the same conditional in each case. The discarded conditional KL is therefore zero; all E/M scores are retained-measurable and the full/parent metrics and covectors coincide. Direct and staged channels agree on the flattened tree. This abelian specialization uses translation sums and does not prove a new noncommutative GL(K) case.

There is a concrete normalized sampling evaluator without constructing non-root child means. Let a tree path give g_i=mu_i-mu_root-h_i(r), where h_i is its signed residual sum. A dressed cut is

\[
 a_e+g_k-g_i=
 \mu_{\mathrm{root}(i)}-\mu_{\mathrm{root}(k)}
 +h_i(r)-h_k(r)-r_e.
 \tag{14}
\]

Loops similarly depend only on signed residual sums. Given p and the finite history, draw the angles and the selected root means from the corresponding Gaussian marginal of h; non-root means cancel. For the unconditional joint, draw p, auxiliary panel and root/tree choices first. Conditional sampling given a selected partition must tilt p by that panel/partition likelihood; forcing a preferred partition after an unconditional p draw is incorrect. This gives a normalized sampling kernel and a specified pushforward measure. A closed density for its geometric marks may still require angular integrals; the sampler is not a claim that those integrals have been eliminated. Within the admitted family all density ratios and E/M scores depend only on retained p, which is why the exact update remains evaluable.

The model/inference state is still (alpha,beta,u): 3m=24 evolving real coordinates on both fine and parent sides. For N=4,m=8, a general dense a,L,Sigma has 16+128+136=280 fixed real coefficients. The fixed description, record archive, conditional evaluator, and shared incidence remain part of both implementations. A concrete sampling implementation may generate eight residual angles even when the final array stores fewer coordinates. No runtime or bit-storage benchmark was run. The 32-to-24-to-16 sample decrease is explicit; it is not a measured total resource gain.

The entire partition law also admits exact cost accounting. For a four-cycle with independent unconditional open probabilities z_e, the number of components obeys k=4 minus the number of open edges, plus the indicator that all four edges open. Hence E k=4-sum_e z_e+product_e z_e. At the first stage z_e=Q_e(1), giving E k=(6634-1520 sqrt(2))/2401 and expected sample-array storage (72280-12160 sqrt(2))/2401, approximately 22.94175888. The all-singleton output uses 40 coordinates because it redundantly adds eight probabilities to the original geometry; it is not a saving on every draw. The two-stage cumulative output uses z_e=1-B_e(2) and has expected array count 18.78736554. These averages include every possible first partition, including singleton and direct-whole outcomes.

The normalized sampling recipe uses eight p variables, eight residual angles, and 4k Gaussian root coordinates: 16+4k continuous random variables. Their first- and second-stage expectations are 23.47087944 and 21.39368277, compared with 32 for the analogous fine sampler. This counts a mathematical sampling recipe, not an executed random generator or CPU work. The unchanged 24 model/filter coordinates, 280 generic fixed conditional coefficients, and finite shared history still travel with each comparison.

There is an operational memory lower bound on an open family. For p~Beta(a,b), the first two future-success moments recover both parameters:

\[
 s=\frac{m_1-m_2}{m_2-m_1^2},\qquad
 a=s m_1,\qquad b=s(1-m_1),\qquad
 \det\frac{\partial(m_1,m_2)}{\partial(a,b)}
 =-\frac{ab}{s^3(s+1)^2}\ne0,\quad s=a+b.
 \tag{15}
\]

For all m labels these moments have rank 2m. The model prior's next-record probability u_j/(u_j+1) independently recovers each u_j. A smooth parent preserving both current recognition predictions and the normalized model evaluator on the open (alpha,beta,u) family consequently needs at least 3m state dimensions. Equivalently, current recognition predictions and their first derivatives in (7) recover u_j because the alpha derivative of E p_j is positive. This does not prove minimality on a smaller posterior-prepared reachable image, rule out cheaper algorithms at equal dimension, or forbid the sample-array decrease.

## 6. Marginal convergence does not specify persistent identity

All finite panel/partition probabilities converge under (7): they are bounded continuous beta moments, and the parameters converge. At equilibrium every p_j and q_e is strictly between zero and one almost surely. Both an all-singleton panel and a connected panel have positive probability on a connected source graph.

Fix an equilibrium draw of p and independently redraw full auxiliary panels at integer times. Given p, the chance of avoiding either of those events forever after any fixed time is lim_(t->infinity)(1-c)^t=0 for its positive probability c. Taking the countable union over starting times proves that singleton and connected partitions each recur infinitely often almost surely. The partition is not eventually constant. Independently redrawing p itself before each panel gives the same nonpersistence conclusion.

Alternatively, draw p and a panel once, then keep them forever. This constant partition path has exactly the same equilibrium one-time marginal. These are different temporal protocols; the Fisher law does not choose one. Thus convergence of that law alone proves no temporal persistence. A frozen seed is a supplied memory rule, not evidence of a dynamically generated identity. The earlier geometric particle-trajectory counterexample is unchanged.

## 7. Cumulative recursion absorbs into the connected component

The existing staged protocol retains every merger and samples fresh flags only on current cuts. Conditional on a fixed interior p, pre-sample independent Bernoulli(q_e) flags for every original edge at every stage. Flags on already internal edges can be ignored without changing components. Stage-t blocks therefore equal components of the union of all flags through t.

Every edge first opens at a finite stage almost surely, because its absence probability is (1-q_e)^t. Finitely many edges imply that every source connected component becomes one block at a finite random stage almost surely. This produces nested lineage without a persistent intermediate stopping level. Stages are not physical time.

For the pair event of Section 4, let T be its number of additional cut-panel stages until merging. Then

\[
 P(T>t\mid R_1)=
 \frac{B_{12}(t+1)B_{30}(t+1)}
      {B_{12}(1)B_{30}(1)},\qquad t=0,1,\ldots.
 \tag{16}
\]

Bounded convergence sends the numerator to zero. At equilibrium each alpha_j>1. Choose any spanning tree solely for a bound on full-graph absorption: the maximum first-success time of its edges is at most their sum, so

\[
 E T_{\rm full}\le
 \sum_{e\ {\rm in\ tree}}E(1/q_e)
 =\sum_{e\ {\rm in\ tree}}\prod_{x=b,m}
       \frac{\alpha_{e,x}+\beta_{e,x}}{\alpha_{e,x}-1}<\infty.
 \tag{17}
\]

For a correlated p law, almost-sure absorption still follows from interior support, while this factorization and finite expectation require separate moment assumptions. A time-dependent learned p path requires its own joint path law and cumulative-hazard conditions; one-time laws do not provide them.

## 8. Outcome and next obligation

The combined-flag restriction is removed in a proper two-channel example: every external label is retained, correlated child-law coordinate marginals can change through the stated fixed regression, native finite-strength learning converges globally, and complete marked law reductions compose. On the two-proper-block event their sample arrays decrease 32 to 24 to 16, with 24 evolving model/filter coordinates on both sides. No group is exactly coherent at finite strength.

The same construction does not establish a persistent useful hierarchy. Fresh full panels change membership indefinitely; cumulative fresh-cut panels absorb each connected component. A fixed seed preserves a sampled group by an additional temporal rule. Equilibrium probabilities and a positive two-stage event do not supply the manuscript's missing net-gain/stopping functional. The unrestricted learned-prior family's boundary behavior also remains separate from its no-interior-equilibrium theorem.

Before constructing another witness, the next decisive action is source-level reconciliation of the path-and-stopping requirement: identify any specified post-merge objective or temporal protocol, then test whether it preserves useful proper blocks and permits further compression under the full record/interface/model-memory contract. Keep the unspecified post-merge functional and the finite experiment's external loss/resource gate explicit. Do not add an arbitrary threshold, coefficient, data stream, or changing hidden conditional to obtain intermediate groups.

The accompanying exact calculation checks beta moments, all elementary panels and partition probabilities, conditional two-stage composition, finite survival probabilities, a translation-loop composition witness, and the moment-recovery determinant. The general convergence, interior obstruction, and path conclusions are the written arguments, not finite enumeration certificates. No ODE integration, data collection, production optimizer, broad suite, GPU work, Lean, tamper check, base transport, manuscript/vault edit, publication, or canonical synchronization is claimed.

## Execution evidence

[learned_multilabel_exact.py](evidence/learned-multilabel/learned_multilabel_exact.py) passed once under pinned CPython 3.14.7 with -I -B in 0.05638189999990573 seconds. Its [result](evidence/learned-multilabel/result.json) records 100 beta-moment identities, 256 elementary first panels, 16 bond panels, 12 supported partitions, 63 elementary pair-then-merge refinements, seven conditional survival probabilities, nine rational moment-Jacobian checks, and the nonzero loop (-4,-6,-8,-10). The finite full-graph absorption expectation bound for the selected spanning tree is 8.37840871 stages.

[partition_cost_exact.py](evidence/learned-multilabel/partition_cost_exact.py) then addressed the separate full-partition cost obligation. It loads the first script's arithmetic definitions without running its main calculation, and checks the full saved partition-law expectation against the cycle formula. Its [result](evidence/learned-multilabel/cost-result.json) passed once in 0.01871939999909955 seconds and records stages zero through six. The later monotone costs are a finite check of the written union-of-panels argument, not a proof of absorption. Both results retain exact rational/sqrt(2) coefficients; decimals are display values.
