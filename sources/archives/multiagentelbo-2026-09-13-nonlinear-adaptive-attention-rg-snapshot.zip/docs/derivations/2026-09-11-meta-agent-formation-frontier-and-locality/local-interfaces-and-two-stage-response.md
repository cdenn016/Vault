# Local interfaces and a two-stage native response hierarchy

September 11, 2026. This continues the [native-memory derivation](native-memory-and-local-parent-reduction.md) at the same fixed base point and source HEAD ed8f22a56df353b1535744509cc23fae46d5813c. The preceding turn established a smaller global first-variation response system. Its unresolved issue was local access: a child block cannot initialize an omitted cross-correlation from its own marginal. The present derivation resolves that issue for an explicit two-channel, four-child Gaussian instance and distinguishes an inference-state saving from a sample-state saving.

There are two exact positive results at their stated scope. First, the native stationary first variation can be implemented through two proper blocks and then a root, retaining the same nonconstant sensor and all six learned links. Its evolving coordinate counts are 50, 26, and 17. Second, the necessary first-level interface is explicit: four retained cross moments and two cut-score statistics, in addition to communicated structural parameters. Local marginals alone fail. These statements are supported by written derivations and one exact rational matrix calculation.

This is not a completed nonlinear formation hierarchy. The blocks and sensor are declared for an analytic specialization of the existing normalized model. The stationary point has five neutral structural directions. Moreover, lifting the required score statistics to random sample coordinates yields an eight-dimensional sample carrier at both stages, equal to the fine carrier's local dimension. The parameter saving cannot therefore be reported as continuous compression of the full random parent.

## 1. Sources, types, and the question that changed

[Theory/06a_generative_gaussian.tex](../../../Theory/06a_generative_gaussian.tex), equations eq:gen-lg-model, eq:gen-lg-state, and eq:gen-lg-root-model through eq:gen-lg-spd, already supplies the two-channel directed Gaussian construction, including model-to-belief coupling. The fixed general Gaussian record in [pointwise-gaussian-link-learning.md](pointwise-gaussian-link-learning.md), equation (2), allows a sensor on multiple latent coordinates. [Theory/07c_full_graph_meta_agent_vfe.tex](../../../Theory/07c_full_graph_meta_agent_vfe.tex) requires one normalized joint, full correlated recognition, retained structural marks, and a common channel for generative, posterior, and recognition pushes. The [local contract](local-contract.md) requires exterior and memory information to be counted and forbids reconstructing a joint recognition law by multiplying local marginals.

The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) was rechecked at the variational licensing and adiabatic-elimination passages. Its fitted-prior barycenter, undefined net formation gain, and independent force-residual assumption are not replaced by the coordinate counts below. Its SHA-256 remains f80e6dabd9e5485649066e227e80beff1dd2b1082cf786bcdaeedb8cbd080ec4. The Research wiki's current Meta-agents and hierarchical emergence and Staged hierarchy formation and RG composability discussions distinguish operational parent closure from an imposed hierarchy. Their linked [finite formation record](<C:/Users/chris and christine/Desktop/Research/sources/manuscripts/multiagentelbo-2026-09-11-formation.md>) preserves the earlier exact finite results.

The working objects below are sample coordinates x=(m_i,b_i), one correlated Gaussian recognition Q over them, and independently learned positive scalar link parameters theta. A model sample m_i differs from the full generative kernel parameterized by theta. Both channels use representations of the common GL^+(1) principal group in this specialization. They do not introduce independent principal bundles. All frames are fixed during the calculation. A passive reexpression transforms links, bridge coefficients, noise covariances, sensor, metrics, and retained maps together; the ranks and intertwiners then remain invariant. The tree instance has no loop holonomy to test and does not impose flatness on the general theory.

The sole observation family is declared below before the exact calculation. Its conditioning value and noise are chosen to give an inspectable stationary point, not obtained from new data. This analytic instance is distinct from the unchanged heterogeneous parity experiment. The latter's fifteen identity-only admissions remain valid.

## 2. Why local Gaussian marginals do not determine cut learning

Fix an SPD Gaussian law on two nonempty blocks A and B. In a mean/raw-second-moment tangent chart, knowing the two complete marginal perturbations determines all within-block moments but leaves every cross-block covariance perturbation free. For any rectangular D, the symmetric perturbation
\[
 \delta\mu=0,\qquad
 \delta C=\begin{pmatrix}0&D\\D^\top&0\end{pmatrix}
 \tag{1}
\]
preserves both marginals. Since SPD is open, C+t delta C remains SPD for sufficiently small positive and negative t. This is a family of legitimate recognition laws, not merely an algebraic signed measure.

For a freely learned receiving residual x_i-Theta_e x_j with SPD weight W_e, the difference of its structural covectors between two such laws at the same theta is
\[
 \delta g_e=-W_e \delta E_Q[x_i x_j^\top],
 \tag{2}
\]
when the source second moment and means are fixed. The prior-normalizer contribution is identical and cancels in this difference. A fixed cross-channel bridge replaces x_i by its full residual coordinate and adds the corresponding cross moment; it does not make that moment locally observable. Thus the local marginals can agree while a cut update differs. An invertible structural metric cannot eliminate a nonzero complete covector difference.

More generally, let v be any finite tangent coordinate, L v the initialized accessible statistics, and F v a required response or force. Exact initialization from L v for all sufficiently small v is possible if and only if
\[
 \ker L\subseteq\ker F,
 \quad\text{equivalently}\quad F=B L
 \text{ for some linear }B.
 \tag{3}
\]
Necessity holds even for a proposed nonlinear decoder: a vector in ker L and its zero counterpart have the same input, so scaling it into the allowed neighborhood forces F v=0. For sufficiency, define B on range L by B(Lv)=Fv; the kernel condition makes this well-defined, then extend linearly. The number of additional independent scalar linear statistics needed is rank([L;F])-rank L. This is an access bound for the stated tangent experiment, not a universal lower bound for arbitrary coding or a different preparation class.

Consequently a global force-memory reduction must be distributed with its cross-block statistics. Calling those statistics a boundary model, a shared cache, or an initialization seed does not remove their information cost.

## 3. A response realization that uses local force statistics

At an interior stationary posterior pi_0, retain the preceding notation S=partial_theta log pi, P=E SS^T, A=Hess[-log e], and structural metric M. Let phi contain a finite vector of sufficient recognition statistics and let delta t=delta E_Q phi. In the full Gaussian family, phi contains every first and distinct raw second moment. Write S=C_s(phi-E phi), and set
\[
 D=\operatorname{Cov}_{\pi_0}(\phi,S),\qquad P=C_sD.
 \tag{4}
\]
The already derived native first variation becomes
\[
 \delta\dot t=-\delta t+D\vartheta,\qquad
 M\dot\vartheta=C_s\delta t-(A+P)\vartheta.
 \tag{5}
\]
The vector vartheta is the link perturbation. It is not an externally assigned schedule.

For a fixed linear sample map Y=F_Y x, its first/raw-second moments are t_Y=R_Y t for a fixed linear matrix R_Y. Define
\[
 k=C_s\delta t.
 \tag{6}
\]
This full force statistic differs from the earlier hidden-only memory by a linear combination of retained moments. Keeping k is convenient because each original factor score is local to its factor scope. Its closed response equations are
\[
 \delta\dot t_Y=-\delta t_Y+R_YD\vartheta,\qquad
 \dot k=-k+P\vartheta,\qquad
 M\dot\vartheta=k-(A+P)\vartheta.
 \tag{7}
\]
These follow by multiplying (5) by R_Y and C_s. The covariance of the full posterior remains in D and P. No block independence has been introduced.

If Z=F_ZY and its moment map is R_Z, then
\[
 (\delta t_Y,k,\vartheta)\longmapsto
 (R_Z\delta t_Y,k,\vartheta)
 \tag{8}
\]
intertwines the two response systems exactly. Direct and staged maps agree by matrix multiplication. The original k and all structural coordinates pass through unchanged; no new target conditional, metric, clock, or memory reset is inserted.

Equation (7) requires communicated structural drivers. A block's moment derivative may depend on a link outside that block because the exact posterior is correlated and conditioned on the common observation. Keeping only incident parameters is an additional autonomy claim and can fail. The interface specification below therefore includes communication of the retained theta vector. It does not assume that the already-global full-law Fisher update becomes local without messages.

This is a first-variation realization for every admissible initial Gaussian tangent. It is not a normalized random-sample state by itself: k is an initialized statistic of a recognition perturbation. Section 7 explicitly checks what happens when the score is instead retained as a random sample coordinate.

## 4. The coupled two-channel instance and its stationary reference

There are four children in a directed chain. In the fixed coordinate order
x=(m_1,b_1,m_2,b_2,m_3,b_3,m_4,b_4), set c=1/2 and use
\[
 m_1\sim N(0,1),\qquad b_1|m_1\sim N(c m_1,1),
 \tag{9}
\]
\[
 m_i|m_{i-1}\sim N(\theta^m_i m_{i-1},1),\qquad
 b_i|b_{i-1},m_i\sim
 N(\theta^b_i b_{i-1}+c m_i,1),\quad i=2,3,4.
 \tag{10}
\]
Every factor is normalized and every receiving variance is positive. The model and belief channels are actually coupled through c. The six links are independent positive structural coordinates; the reference values in edge order (m12,b12,m23,b23,m34,b34) are
\[
 \theta_0=(1/3,1/2,1/2,2/3,2/3,1/3).
 \tag{11}
\]
Let R(theta)x be the eight residuals in (9)-(10). Its determinant is one, so the proper prior covariance is C_0(theta)=R(theta)^{-1}R(theta)^{-T}. The prior density retains its exact determinant, even though it is constant in this parameterization.

The declared first-level candidates are A={1,2} and B={3,4}. Retain
\[
 Y_A=(m_2,b_2),\qquad Y_B=(m_4,b_4),\qquad
 Z=\tfrac12(Y_A+Y_B).
 \tag{12}
\]
These are fixed candidate maps, not learned membership. Their arithmetic averages are sample maps; they are not the manuscript's law-valued fitted-prior barycenter or its covariance-pooling convention.

Use the same nonconstant sensor at both levels:
\[
 O|x\sim N(Hx,\sigma_o^2),\qquad
 Hx=\tfrac12(m_2+b_2+m_4+b_4)=Z_m+Z_b.
 \tag{13}
\]
At the fixed reference theta_0, H C_0 H^T=145573/46656. Declare once and then hold fixed
\[
 o=4,\qquad \sigma_o^2=16-\frac{145573}{46656}
                         =\frac{600923}{46656}>0.
 \tag{14}
\]
The noise is not differentiated as a function of theta. The reference construction selects an analytic likelihood slice with o^2=Var(O). Both grouping and sensor are supplied choices for this conditional access calculation. They are not learned or independently justified by the saved data, and this construction is not evidence for heterogeneous discovery.

Put w=C_0(theta_0)H^T. Gaussian conditioning gives
\[
 \mu=\frac w4,\qquad C=C_0-\frac{ww^\top}{16},
 \qquad C+\mu\mu^\top=C_0.
 \tag{15}
\]
The evidence is N(o;0,s(theta)), with s=sigma_o^2+H C_0(theta)H^T. Since s(theta_0)=o^2=16, its score vanishes in all six directions. Thus Q=pi_theta0 is an actual native E/M stationary pair.

For each link, let e_a be its receiving residual and p_a its source sample coordinate. The posterior structural score at this stationary point is
\[
 S_a=p_a e_a,\qquad E_{\pi_0}S_a=0.
 \tag{16}
\]
The expectation vanishes by the second-moment identity in (15). Complete generative scores of distinct ordered conditional factors are orthogonal by iterated conditioning on the factor's parents and preceding variables. Their Fisher metric is therefore diagonal:
\[
 M=\operatorname{diag}
 \left(1,\frac54,\frac{10}{9},\frac{241}{144},
                   \frac{23}{18},\frac{1475}{648}\right).
 \tag{17}
\]
This is the actual model Fisher metric in the positive-link chart. Log-link coordinates require the corresponding pullback; no Euclidean Lie-algebra update is substituted.

Let v_a=partial_a s(theta_0). Differentiating the scalar Gaussian evidence and its posterior normalization gives
\[
 A=\frac{vv^\top}{512},\qquad P=M-A.
 \tag{18}
\]
For the second identity, differentiate the expected complete prior score: the negative complete Hessian is diagonal with entries E_Q p_a^2, equal to the prior values in M by (15); the posterior score covariance subtracts from it. The exact calculation independently checks this relation using Gaussian fourth moments and checks D using inverse-matrix differentiation.

A has rank one. Its sole nonzero eigenvalue after M-whitening is
\[
 a_*=\operatorname{tr}(M^{-1}A)
 =\frac{80708039077537}{5273247146803200},\qquad 0<a_*<1.
 \tag{19}
\]
Eliminating delta t from (5) gives the score-driven structural equation
M ddot vartheta+2M dot vartheta+A vartheta=0. Hence five structural directions have rates zero and two; the remaining direction has rates 1 plus or minus sqrt(1-a_*). Thirty-eight Gaussian tangent directions orthogonal to all six scores have rate one. The neutral directions matter: this reference does not establish an attracting isolated parent, persistent membership, or an asymptotically stable hierarchy.

The Gaussian identities used here are the same primary-source formulas in [Rasmussen and Williams, Appendix A](https://gaussianprocess.org/gpml/chapters/RWA.pdf). The stationary construction, access decomposition, and response intertwiners follow from the displayed normalized factors; the source citation is not evidence for a general hierarchy claim.


## 5. The exact first-level interface and local update access

A local initializer is assumed to receive the complete four-coordinate marginal Q_A or Q_B of its child block. It is not given only independent per-child marginals. That distinction already belongs to the correlated source model. At the reference, each block exports the five first/raw-second moments of its two retained coordinates and the two expectations of its internal reference factor scores:
\[
 \mathcal U_A=(\delta t_{Y_A},k_{m12},k_{b12}),\qquad
 \mathcal U_B=(\delta t_{Y_B},k_{m34},k_{b34}).
 \tag{20}
\]
Each export has rank seven as a linear statistic of that block's fourteen Gaussian moment coordinates. The internal scores are evaluated with theta_0, not with an untracked moving reference. Their initialization uses only the corresponding block marginal.

The complete first-level recognition moment vector has fourteen coordinates: five per parent plus the four cross moments E[Y_A Y_B^T]. The two cut-score expectations are additionally necessary. The six-scalar shared interface is
\[
 \mathcal I_{AB}=
 \left(\delta E[Y_A Y_B^\top], k_{m23}, k_{b23}\right).
 \tag{21}
\]
It is a joint correlation/force interface, not a product of parent marginals. The cut scores are
\[
 S_{m23}=m_2m_3-\tfrac12m_2^2,\qquad
 S_{b23}=b_2b_3-\tfrac23b_2^2-\tfrac12 b_2m_3.
 \tag{22}
\]
They cannot be initialized from Q_A and Q_B alone. The boundary interface must receive these two cross-score statistics of the fine joint. After initialization, their updates use the closed k equation in (7); no hidden evolving fine moments are queried.

The necessity is exact at first order. A covariance perturbation with delta C_{m2,m3}=1 and its symmetric counterpart, with all other entries and means zero, has zero local-marginal and retained-Y perturbation but k_{m23}=1. The native velocity perturbation is delta dot theta_{m23}=9/10. A second perturbation with delta C_{b2,b3}=1 gives k_{b23}=1 and velocity 144/241. Their small-amplitude realizations are SPD by (1). Thus even local parent laws and their four retained cross moments do not replace the cut-force information.

Given both complete local block marginals, the interface dimension six is minimal among linear statistics for preserving the specified full joint Y moments and all factor forces. Four independent cross coordinates are m2*m4, m2*b4, b2*m4, and b2*b4. The two cut cross functionals add m2*m3 and b2*b3-(1/2)b2*m3. These six coefficient vectors are linearly independent modulo within-block monomials. Equation (3) therefore requires six additional independent scalar coordinates. This is not minimality for the single sensor alone, whose output need not identify every joint Y coordinate.

The retained structural vector vartheta has six coordinates and is stored once in the joint count. To evaluate (7), blocks and the interface also need its communicated values or equivalent driver messages. This communication is not free and is not hidden in a model oracle. At the reference,
\[
 \frac{\partial \dot{\delta E[m_2]}}
      {\partial\vartheta_{m34}}
       =\frac{2432963}{35831808}\ne0.
 \tag{23}
\]
Thus an initializer with all moment perturbations zero and only the remote link vartheta_m34 perturbed has an immediate local mean response. An autonomous A update reading only A's state and the cut link would miss it. The declared implementation permits exchange of retained structural parameters across the two parents; a stricter incident-only protocol is not admitted by this calculation. For more parents, communication locality would need its own analysis.

The constant susceptibility matrices D and P are compiled from the complete normalized reference model and its common observation. They are not fitted independently per parent. Changing the reference, membership, or observation changes these coefficients and requires a new remainder analysis; (7) does not justify silently refreshing them.

## 6. Two stages, normalized static pushes, and finite-horizon scope

The fine Gaussian has 44 recognition moment coordinates and six structural coordinates. Combining (20)-(21) gives twenty recognition/force coordinates at the first level, plus the same six structural coordinates. Keeping Z's five moments, all six k values, and all six structural coordinates gives the root. Therefore
\[
 50\longrightarrow26\longrightarrow17
 \tag{24}
\]
is the evolving dimension sequence for this response experiment. The first-stage distributed statistics are a permutation of (delta t_Y,k,vartheta), not separate independently evolving marginal laws.

Let J_f,J_1,J_2 be the native fine and two response Jacobians. The exact calculation constructs the matrices T_1,T_2,T_dir and verifies
\[
 T_1J_f=J_1T_1,\qquad
 T_2J_1=J_2T_2,\qquad
 T_2T_1=T_{\rm dir},\qquad
 T_{\rm dir}J_f=J_2T_{\rm dir}.
 \tag{25}
\]
The maps have ranks 26,17,17. These identities prove equality at every inference time of the retained first variations, for every fine Gaussian initial tangent. They preserve moving cut-link perturbations and the same initialized k. They do not require choosing one relaxation eigenmode and calling it the whole parent.

The random sample maps x to Y to Z separately define normalized, recognition-independent deterministic channels. For the actual Gaussian generative law, posterior, and any Gaussian recognition, their static pushes compose exactly. Because the sensor factors through Z, the induced generative observation kernel is the same N(Z_m+Z_b,sigma_o^2), with the same evidence. The full correlated recognition pushes remain Gaussian. Their exact static VFE gaps obey the conditional-KL chain rule. This statement concerns the static sample channels; it does not assert that they alone close the native dynamics.

In particular, their static laws and the force-memory realization are different layers of the construction. Equation (25) closes the first variation of inference and predictions when k is kept as algorithm memory. It does not claim that the fourteen moments of Y and six force means determine the full random law of (Y,S), or that the corresponding nonlinear population dynamics is a quotient.

The finite-horizon remainder from [native-memory-and-local-parent-reduction.md](native-memory-and-local-parent-reduction.md), equations (24)-(25), applies in this model's smooth mean/raw-second-moment and positive-link chart. On a convex neighborhood with bounded second derivative of the native vector field, and while its stated small-amplitude denominator and domain conditions hold, the difference from the linear trajectory is bounded by the displayed constant times delta squared. Here moment retention itself is linear, so multiplying that bound by ||T_1|| or ||T_dir|| bounds the actual retained moment/force-coordinate error. A query mean is linear in those moments; its variance has the additional explicit conversion Var(Hx)=E[(Hx)^2]-(E[Hx])^2. No neighborhood radius or numerical remainder constant was evaluated, and no finite-amplitude trajectory was integrated.

For every sufficiently small admitted state, its retained Gaussian covariance is positive, so the query density is normalized. The linearized query reproduces the complete first-order density because a Gaussian density derivative is determined by its mean and covariance derivatives. No independently resampled time-series experiment, hidden sample path, or adaptive policy is inferred from these inference trajectories. The fixed observation and the common future single-query kernel are the declared record contract.

A bookkeeping comparison is possible for a compiled implementation of this linear response. It does not compare nonlinear matrix inversion against an unrelated linear model.

| Quantity | Fine response | First response | Root response |
| --- | ---: | ---: | ---: |
| Evolving recognition/force coordinates | 44 | 20 | 11 |
| Evolving structural coordinates, counted jointly | 6 | 6 | 6 |
| Total evolving coordinates | 50 | 26 | 17 |
| Coefficients under the storage convention below | 285 | 126 | 72 |

The fine convention stores the dense 44-by-6 target-moment derivative D, fifteen nonzero factor-score coefficients, and six diagonal metric entries. The first and root conventions store their dense 14-by-6 or 5-by-6 derivative, dense 6-by-6 P, and the same six metric entries. Identity decay terms and known zero entries are not stored. All descriptions additionally retain the source model specification, reference link values, fixed sensor/noise, reference output moments, fixed maps/membership labels, and initialization protocol. Distributed parameter copies and transmission costs are additional; the table is not a claim about minimum description length, memory bandwidth, measured wall time, or full sample-state entropy. Constructing D and P can require fine-model computations even when a compiled update does not.

## 7. The normalized score-sample lift has no continuous dimension saving

It is tempting to treat k=delta E_Q S as a new deterministic sample mark produced by the same microscopic channel. That does not work for a channel whose input is only the current sample x. If two positive Gaussian recognition laws Q_1 and Q_2 are equivalent, their pushes through any common normalized Markov channel are equivalent: a zero-mass output set means its nonnegative kernel probability vanishes Q_1-almost surely and hence Q_2-almost surely. Two distinct point masses are not equivalent. Therefore no such channel can output a deterministic, Q-dependent E_Q S for all positive Gaussian Q when that expectation varies. Adding the full recognition state or its history to the microscopic source changes the carrier and requires an explicit model and cost.

A valid common sample channel can instead retain the scores themselves:
\[
 C_1^+(x)=\bigl(Y(x),S_1(x),\ldots,S_6(x)\bigr),\qquad
 C_2^+(x)=\bigl(Z(x),S_1(x),\ldots,S_6(x)\bigr).
 \tag{26}
\]
These are polynomial deterministic maps, and their pushes of prior, posterior, and recognition are normalized. The score means can be read from their laws. That validity does not imply a smaller full random carrier or a twenty-parameter representation of the pushed law.

For the first block, the map (m1,b1,m2,b2) to (m2,b2,S_m12,S_b12) has full rank four whenever
\[
 m_2-2\theta^m_2m_1\ne0,\qquad
 b_2-cm_2-2\theta^b_2b_1\ne0.
 \tag{27}
\]
With the retained root fixed, each hidden coordinate is constrained by a quadratic equation and has at most two branches. The second block's analogous map has the same property with indices 3,4. These are finite branch ambiguities, not removal of continuous local dimensions or a claimed gauge symmetry.

The exact calculation evaluates the Jacobians of both maps in (26) at
x=(1,2,3,5,7,11,13,17), in the declared coordinate order. Both have rank eight; the square root-map Jacobian has determinant
\[
 \det D C_2^+(x)=\frac{1554175}{864}\ne0.
 \tag{28}
\]
Since this determinant is a nonzero polynomial, its zero set has Lebesgue measure zero and no open interior. This follows by induction on dimension from the finite zero set of a nonzero one-variable polynomial and Fubini, after separating the possible zero coefficient polynomials. The full-support Gaussian assigns that zero set mass zero. Thus the normalized root score-sample lift retains the fine local sample dimension almost surely. The first lift has a nonzero eight-by-eight minor and the same conclusion.

The strong limit is therefore explicit: the sample channel plus enough score samples to supply the memory has not produced continuous carrier compression. The response observer compresses which recognition perturbations matter to a fixed first-order output, while the common score-sample lift retains more of the random experiment. Neither construction can be relabeled as the other.

## 8. Evidence, remaining requirement, and next action

The single [exact calculation](evidence/local-response/local_response_exact.py) uses standard-library Fraction arithmetic under pinned CPython 3.14.7. Its [result](evidence/local-response/result.json) records the normalized prior/posterior identities, the actual six-link metric, an independent inverse-calculus reconstruction of all target-moment derivatives, the three response ranks, all four intertwining/composition identities, the two cut-force witnesses, the nonlocal parameter response, and both sample-lift Jacobian ranks. It completed in approximately 0.023 seconds. There was no nonlinear integration, new data collection, old-science rerun, pytest suite, GPU work, Lean work, tamper check, publication, or canonical synchronization.

The three substantive passes were the local-access obstruction, the distributed two-stage response construction, and exact reconstruction plus the sample-carrier check. They were sequential analytical work and an executed calculation, not independent agent review. Source hashes are provenance metadata, not proof or a formal verification certificate. The original saved observations, fifteen local admissions, all preceding derivations and evidence, active configuration, manuscripts, vault, and canonical Desktop WIP are preserved.

The next requirement is now more precise. A complete nonlinear parent must specify how its normalized random state, retained recognition law, and initialized inference memory are related, without treating a Q-dependent expectation as a recognition-independent sample channel. For the native Gaussian family, the next useful test is whether the actual reachable recognition family admits a smaller exact nonlinear memory under an explicitly stated preparation class, and whether that memory reduces complete resources relative to the corresponding fine implementation. The exact information-coordinate filter in pointwise-gaussian-link-learning.md is the starting point; restricted preparation must not be presented as a repair of the original all-preparation no-compression result. If only optimizer-state savings result, record them as such.

This addresses locality and composition for the admitted first variation. It does not establish spontaneous alignment, learned membership, finite-amplitude persistence, an attracting two-block hierarchy, or a complete nonlinear RG. The supplied map and observation are not admission to a new statistical-discovery experiment under the revised attachment. The full goal remains active and incomplete.

