# A second-merge regime and the native evidence barrier

September 12, 2026. The unchanged transported model admits a finite parameter region in which the two actual first parents favor merging and the original-data evidence improves over its unit preparation. The regime survives in a full mixture with every ancestry prior positive. This is a classification of a static family of exact posteriors; the native learner does not preserve that family, so the result does not assert entry into the regime or persistent formation.

The second result concerns the actual coupled native flow. Its decreasing free energy prohibits simultaneous collapse of all three model variances. For every fixed positive ancestry prior and every finite native time from the exact unit-posterior preparation, max(a,b,c) is at least a strictly positive prior-dependent number. A bound uniform over those priors is approximately 0.002861068282. This bounds the maximum, not each variance separately, and does not prove compactness or convergence.

## 1. Existing construction and the remaining question

The [previous second-level calculation](second-level-prior-learning-and-agreement.md) supplies inherited model and recognition learning, the exact correlated reverse kernel, the Gaussian reconstruction counterexample and the actual parent-cut agreement diagnostic. It proves a positive initial time interval on which the diagnostic increases but remains below one half. It leaves the later-time outcome open.

[Transported parent priors](transported-parent-priors-and-induced-couplings.md), Sections 6-7, already separates a zero-child-variance boundary at fixed b,c from actual coupled dynamics, and retains the induced grandparent/loop covariance. [The native learner](shared-parent-native-learning-and-memory.md), Section 4, derives descent of one normalized negative ELBO using the full recognition and complete-model Fisher metrics. Its conclusions transfer to the transported model with the corrected primitive energies as recorded in the transported-prior derivation. These are the dynamics used below.

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_variational`, already distinguishes a coherence detector from a free-energy and organizational-cost license. Its post-merge replacement is explicitly incomplete there; high coherence alone does not prove net savings. The [operational wiki definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires the joint law, evaluator, boundary access, marks and sufficient memory. Those requirements remain in force. The new calculation neither supplies a new higher-level observation nor assigns a formation penalty.

Work stays at the same base point. Keep the twelve connected ancestries, all forty-five root/tree decorations, the original two-channel ordered records with edge success counts n=(8,1,8,1) and one failure on every label, and arbitrary fixed positive normalized pi_R. The root variance remains v=1. The pair P={{0,1},{2,3}} retains all four decorations with their common-model prior weights of one quarter; posterior decoration weights are not replaced by uniform weights.

## 2. The common-scale family is a static question

Consider the already admitted parameter curve

\[
 a=b=c=\tau>0,
  v=1,
  Q_\tau=P_\tau(\cdot\mid o).
 \tag{1}
\]

No parameter point on this curve is fitted or selected. All positive tau are classified. In recognition coordinates this curve has rho_a=rho_b=rho_c=1/tau, omega=2 log(1/tau), s=1 and matched root coordinates. It is an exact-posterior curve, whereas the actual native flow has finite inference lag and unequal variance velocities.

For each decorated ancestry H, write Gamma_H for its already recorded unit residual covariance. On (1) the covariance is tau Gamma_H. The common root cancels from every residual. The two parent-cut residual rows for P are the previously established

\[
 \begin{pmatrix}\widetilde r_{12}\\\widetilde r_{30}\end{pmatrix}
 =T_Pr,
  T_P=\begin{pmatrix}1/2&1&1/2&0\\1/2&0&1/2&1\end{pmatrix}.
 \tag{2}
\]

For a subset A of the two cut rows, define the one-channel integral

\[
 e_{H,A}(\tau)
 =\sum_{S\subseteq E}(-1)^{|S|}
 \det\left[I+\tau\Gamma_H
 \left(\operatorname{diag}(n+1_S)+\sum_{e\in A}t_e^Tt_e\right)\right]^{-1}.
 \tag{3}
\]

Every determinant is strictly positive for tau>0: the exponent matrix is positive definite, and the product with Gamma_H is similar to a positive-definite symmetric matrix. Each determinant polynomial has positive coefficients, as also checked exactly. The signed expansion is an integration formula; its signs are not latent probabilities.

The pair evidence, activated-cut numerators and merge probability are

\[
 Z_P(\tau)=\frac14\sum_{H\mid P}e_{H,\varnothing}(\tau)^2,
  J_A(\tau)=\frac14\sum_{H\mid P}e_{H,A}(\tau)^2,
  M(\tau)=\frac{J_{12}+J_{30}-J_{\{12,30\}}}{Z_P}.
 \tag{4}
\]

Here J_12 denotes A={12} and similarly for the other single cut. The same H is shared by the two channels, which is why each e is squared before averaging. M is the normalized prospective auxiliary readout of the existing learned state. Conditional on that state, a cut is active with probability exp(-||r_tilde_e||_4^2/2), and either active cut connects the parents. No flag is observed or sampled in this calculation.

## 3. Exact classification on the full positive axis

There are two distinct algebraic thresholds, denoted tau_e and tau_m. The exact coefficient calculation and rational isolation give

\[
 0.0074390407191<\tau_e<0.0074390407195,
 
 0.1805859863466<\tau_m<0.1805859863469.
 \tag{5}
\]

The displayed decimal endpoints are rational outer bounds; the narrower exact dyadic intervals are saved in the [classification result](evidence/second-level-scale/scale-classification.json). The statements for every positive tau are

\[
 M(\tau)>1/2\iff 0<\tau<\tau_m,
 
 Z_P(\tau)>Z_P(1)\iff \tau_e<\tau<1.
 \tag{6}
\]

Equality in the first comparison occurs only at tau_m. Equality in the second occurs only at tau_e and 1. The comparisons reverse on all remaining positive intervals.

| Common variance | Parent merge readout | Pair evidence compared with unit preparation |
| --- | --- | --- |
| 0<tau<tau_e | Merge above one half | Lower |
| tau=tau_e | Merge above one half | Equal |
| tau_e<tau<tau_m | Merge above one half | Higher |
| tau=tau_m | Equal merge/split probabilities | Higher |
| tau_m<tau<1 | Split above one half | Higher |
| tau=1 | Merge approximately 0.2938789175 | Equal |
| tau>1 | Split above one half | Lower |

The proof is an exact polynomial sign argument, rather than a grid of variance values. After clearing its positive denominator and removing the zero factor tau^8, the numerator of J_12+J_30-J_{12,30}-Z_P/2 is a degree-482 polynomial p_m. Its coefficients in ascending order have exactly one sign change, from positive to negative. For Z_P(tau)-Z_P(1), the factor tau-1 is exact. The remaining degree-131 polynomial p_e has the same coefficient pattern. The complete integer coefficient lists are retained.

For completeness, this coefficient pattern itself proves uniqueness of a positive zero. Let m be the highest exponent with a positive coefficient. Then

\[
 \frac{p(\tau)}{\tau^m}
 =\sum_{i\le m}c_i\tau^{i-m}
       -\sum_{i>m}|c_i|\tau^{i-m},
  c_i\ge0(i\le m).
 \tag{7}
\]

Its derivative is strictly negative on tau>0: all derivative terms are nonpositive, and a negative higher-degree term is present. The positive constant and negative leading coefficient give a positive sign near zero and a negative sign for large tau. Thus p has exactly one positive zero and its sign on either side is fixed. Applying this to p_m and p_e, and retaining the sign of tau-1 for the evidence comparison, proves (6). Exact rational bisection isolates each root and proves 0<tau_e<tau_m<1. No sign is inferred from a floating-point polynomial evaluation.

## 4. The strong-agreement and diffuse limits

The endpoints clarify the meaning of the favorable interval. Write r=sqrt(tau)z in one channel and x_e=||z_e||_2^2/2. Every observed failure contributes

\[
 \frac{1-e^{-\tau x_e}}{\tau}\longrightarrow x_e,
 
 0\leq\frac{1-e^{-\tau x_e}}{\tau}\leq x_e.
 \tag{8}
\]

The success factors tend to one. Polynomial Gaussian integrability permits dominated convergence, including products over all four labels and both channels. For a one-channel Gaussian with covariance Gamma_H in each coordinate direction,

\[
 E\prod_{e=1}^4 x_e=\operatorname{perm}(\Gamma_H),
 
 Z_R(\tau)=A_R\tau^8+O(\tau^9),
 
 A_R=\frac1{N_R}\sum_{H\mid R}\operatorname{perm}(\Gamma_H)^2>0.
 \tag{9}
\]

One way to obtain the permanent identity is to set w=(z^(1)+i z^(2))/sqrt(2), so x_e=|w_e|^2 and E[w_i conjugate(w_j)]=Gamma_ij. Pairing each unbarred factor with one barred factor in the Gaussian moment expansion sums the products over permutations. The two channels are independent only after conditioning on H, giving the squared permanent in (9).

Unlike the earlier limit a to zero at fixed b,c, every residual variance now shrinks. All twelve ancestry evidences have the same power tau^8; their limiting relative weights are proportional to pi_R A_R. This curve therefore does not inherit the earlier singleton-concentration conclusion.

For the pair, the exact leading coefficients are

\[
 Z_P(\tau)=37640\tau^8+O(\tau^9),
 
 1-M(\tau)=\frac{466470}{941}\tau^2+O(\tau^3).
 \tag{10}
\]

To see the second order directly, each inactive parent cut has probability 1-exp(-tau Y_e), where Y_e is the squared four-dimensional parent residual divided by two in the standardized state. Both cuts must be inactive to split, so their product begins at tau^2 Y_12 Y_30. Taking the expectation under the limiting failure-weighted Gaussian gives a finite strictly positive coefficient. The calculation independently obtains the same coefficient from the signed determinant series through one-channel order six; the split numerator has zero coefficients at orders eight and nine and coefficient 18,658,800 at order ten. Division by 37,640 gives (10).

Thus very tight common priors make this diagnostic nearly certain to merge while making the original observed failure batch improbable. At the other endpoint, all Gamma_H are full rank and the rational functions give

\[
 \lim_{\tau\to\infty}M(\tau)=0.20158171396944818\ldots<1/2,
  Z_P(\tau)=O(\tau^{-8}).
 \tag{11}
\]

The exact limiting fraction is saved. The limiting signs agree with the full-axis classification, but the endpoint arguments alone would not prove uniqueness of its crossing.

## 5. A full positive-prior regime, without selecting a prior

The pair-conditioned statement is independent of pi. Its simultaneous evidence and merge advantage also extends to a full model with every pi_R positive. This does not require evaluating or discarding the other ancestry laws.

Let I be any compact interval strictly inside (tau_e,tau_m), and define

\[
 d=\min_{\tau\in I}[Z_P(\tau)-Z_P(1)]>0,
  z=\min_{\tau\in I}Z_P(\tau)>0,
  m=\min_{\tau\in I}M(\tau)>1/2.
 \tag{12}
\]

These minima exist by continuity. No numerical I or minima are selected. Let C_0=max_{R different from P} Z_R(1). The common ordered-batch likelihood is at most

\[
 L_{\max}
 =\left[\left(\frac{8^8}{9^9}\right)^2
               \left(\frac14\right)^2\right]^2
 =1.3737549762644743\times10^{-8}\ldots.
 \tag{13}
\]

This follows by maximizing each fixed Bernoulli factor p^n(1-p) on [0,1]. It is an upper bound even if those factor maximizers cannot occur jointly. Every Z_R(tau) is positive and at most L_max.

Write eta=1-pi_P. If all priors are positive and

\[
 0<\eta<\min\left\{
   \frac{d}{d+C_0},
   \frac{z(2m-1)}{L_{\max}+z(2m-1)}\right\},
 \tag{14}
\]

then throughout I the full-model evidence Z_pi(tau)=sum_R pi_R Z_R(tau) satisfies Z_pi(tau)>Z_pi(1). Indeed its improvement is at least (1-eta)d-eta C_0. This establishes a nonempty open family of positive priors; none is assigned a numerical value.

The same condition gives a sharper hierarchy-readout statement. Attach the existing common normalized parent-agreement channel and let B be the event that R=P and its two parents merge. Any normalized extension of that channel to the other ancestries gives

\[
 Q_\tau(B)=Q_\tau(P)M(\tau)
 \geq\frac{(1-\eta)zm}{(1-\eta)z+\eta L_{\max}}>1/2.
 \tag{15}
\]

Consequently P is also the unique first-level MAP ancestry in this static regime. All excluded alternatives together have less probability than the merged-P event. This is an auxiliary marked event in the same exact posterior, not a new observed hierarchy variable or a mechanism that changes the model.

Conditioning on B has TV loss 1-Q_tau(B) and forward conditioning KL -log Q_tau(B), now below one half and log 2 respectively. On this matched-posterior curve the fixed-model optimized free-energy penalty for restricting to B is the same -log Q_tau(B), because Q_tau is the exact model posterior. The equality need not hold during native inference lag. This improvement in the support-loss bound does not remove that positive cost or price organizational overhead.

## 6. The actual native flow cannot collapse every model variance

Return to the full finite-rate learner, not the static curve. Start at the unit model and its exact posterior with any fixed positive pi. Let F be its normalized negative ELBO. The source's descent identity and the exact ELBO decomposition give

\[
 F(t)\leq F(0)=-\log Z_\pi(1),
 
 F(t)=D(Q_t\Vert P_{u(t)}(\cdot\mid o))-\log Z_\pi(u(t)),
 
 Z_\pi(u(t))\geq Z_\pi(1)>0.
 \tag{16}
\]

The last inequality follows from F(t)>=-log Z_pi(u(t)); it does not assert that evidence is monotone between arbitrary later times when recognition is inexact. It is a lower bound relative to this exact-posterior initial condition.

For arbitrary positive model variances put epsilon=max(a,b,c). Each residual covariance is a positive linear combination of the three fixed Gram matrices, so Gamma_H(a,b,c) is at most epsilon Gamma_H(1,1,1) in the positive-semidefinite order. Dropping all success factors and using each failure bound in (8) without a limit gives

\[
 Z_R(a,b,c)\leq
 \frac1{N_R}\sum_{H\mid R}\operatorname{perm}(\Gamma_H(a,b,c))^2
 \leq\epsilon^8 A_R.
 \tag{17}
\]

The second inequality uses a monotonicity specific to positive-semidefinite covariance matrices, rather than entrywise comparison. For a 4 by 4 matrix Gamma, let v_sym be the normalized sum of the 24 permutations of e_1 tensor e_2 tensor e_3 tensor e_4. Then $\operatorname{perm}(\Gamma)=\langle v_{\rm sym},\Gamma^{\otimes4}v_{\rm sym}\rangle$. If 0<=Gamma<=D, the difference $D^{\otimes4}-\Gamma^{\otimes4}$ is a telescoping sum of positive tensor products, each containing D-Gamma in one slot. It is positive semidefinite, proving perm(Gamma)<=perm(D). Scaling D=epsilon Gamma_H(1,1,1) proves (17).

Writing A_pi=sum_R pi_R A_R and combining (16)-(17) yields the trajectory-wide model bound

\[
 \max(a(t),b(t),c(t))
 \geq\left(\frac{Z_\pi(1)}{A_\pi}\right)^{1/8}
 \geq\left(\min_R\frac{Z_R(1)}{A_R}\right)^{1/8}
 =0.0028610682823418322\ldots.
 \tag{18}
\]

The middle inequality follows because Z_pi(1)/A_pi is a convex combination of Z_R(1)/A_R with weights pi_R A_R/A_pi. The exact minimum is attained by the all-singleton ancestry; its fraction and all twelve ratios are saved. Equation (18) holds at every finite native time and excludes a sequence of times along which all three model variances tend to zero. Individual variances can still approach a boundary, and unbounded variances or noncompact ratios remain possible. The result is not a convergence theorem, a bound on every recognition variance or a proof that the learner reaches (14).

The first calculation also saved a weaker diagonal-moment bound, using perm(Gamma)<=24 times the product of its diagonal entries. Its uniform floor is approximately 0.001485122843. The tensor argument gives the sharper value in (18) without new Gaussian integrals; both valid bounds remain recorded. The sharper floor is strictly below tau_e, as checked exactly by raising the saved lower endpoint of tau_e to the eighth power. Therefore this necessary native barrier does not exclude the finite interval in (6).

## 7. What the interval does and does not license

The earlier unit-posterior result did not prove a universal second-merge obstruction. Equations (6) and (14)-(15) now give an explicit conditional positive regime for the same record model: original evidence improves, the pair is uniquely preferred, and its merged-parent event has more than half the marked recognition mass. All structures, covariances and record likelihoods remain those already admitted.

This region is not yet a native formation episode. The saved native initial response has dot a-dot c<0 for every positive prior, so the model immediately leaves a=b=c. Recognition initially stays fixed and then responds at second order with unequal precision accelerations. The static common-scale classification therefore cannot be substituted for the seven-coordinate coupled flow. In particular, the priors near P supplied by (14) are not claimed to be the near-O/P-tie priors of the earlier first-level crossing theorem. A trajectory connecting those conditions has not been established.

A complete selected parent still carries the original probability catalog, primitive energies, inherited geometry and any parent-cut entries required after contraction. Its posterior reverse conditional includes the original record information; the Gaussian prior reverse kernel alone remains invalid for reconstructing recognized children. Selecting B generally produces a non-Gaussian marked pushforward. The earlier sufficient 44-to-28-to-24 sample map with retained parent-cut entries and its lack of a minimality claim remain unchanged.

The next decisive obligation is native entry and persistence in a simultaneously favorable two-level regime for a stated open prior family, together with the complete resource comparison. The auxiliary agreement channel supplies no new likelihood or autonomous structural kinetics. A net cost advantage must still account for support restriction, native moments, density evaluation, generation, interfaces, retained data, filtering when required and organizational overhead against the fine implementation. The full goal remains incomplete.

## 8. Execution and preservation

Three distinct calculations completed once each. [scale_functions.py](evidence/second-level-scale/scale_functions.py), using the existing Anaconda Python 3.12.7/SymPy runtime, constructed twelve exact rational integrals from 192 degree-four determinant polynomials and their order-six series, plus the forty-five decorated permanent coefficients. It completed in 7.270967999997083 seconds. [classify_scale.py](evidence/second-level-scale/classify_scale.py) used pinned CPython 3.14.7 and the saved coefficients to prove the one-sign-change classifications, isolate both roots and compare them, completing in 0.14952409999386873 seconds. [native_barrier.py](evidence/second-level-scale/native_barrier.py) used that pinned runtime for the twelve scalar barrier ratios and likelihood bound, completing in 0.007579299999633804 seconds. The latter two performed no new Gaussian integrals.

Unit identities are checked against the previous exact results; earlier scientific mains and the full 496-term experiment were not rerun. The initial broad source glob was unsupported by Windows and was corrected to an rg directory/glob search before the calculation. No scientific execution failed. This is a written derivation with exact coefficient evidence, not a formal proof-system or independent-review certificate.

The 293-file preservation baseline permits changes only to STATUS.md, RG-COMPLETION.md, RECORD.md and the September 12 change log. Original data, earlier evidence, sources and protected WIP remain intact. No numerical ancestry prior, parameter-point search, fitting, ODE, sampled flags or states, new data, added likelihood or prior tilt, GPU, suite, Lean, tamper check, production/configuration edit, vault change, publication or canonical synchronization occurred.
