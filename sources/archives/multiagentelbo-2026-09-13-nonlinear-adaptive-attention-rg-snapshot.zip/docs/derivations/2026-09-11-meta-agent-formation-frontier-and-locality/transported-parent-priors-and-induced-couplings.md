# Transported parent priors, finite alignment, and induced couplings

September 12, 2026. This continuation supplies an explicit parent-predictive prior using the actual tree-link transport of the [complete parent channel](shared-parent-complete-channel-and-recursive-cost.md). It is a new declared Gaussian specialization on the same law-mean coordinates and original labeled record experiment. It does not overwrite the earlier untransported shared-parent prior, its fifteen ancestry comparisons, or the negative fifteen-subset admission experiment.

Three conclusions are established within this family. The downward kernel is normalized and yields a tractable Gaussian prior on transported barycenters and retained graph marks, with the existing native learning law applicable after changing the child-noise energy. A complete fixed-variance comparison over twelve connected partitions and forty-five root/tree decorations still favors one block. At zero child variance every nonsingleton partition loses evidence because the original internal-edge failures become impossible. Recursive barycenters also induce parent/loop correlations, so resetting independent factors at the next scale changes the model.

## 1. Source mechanism and the added modeling choice

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `app:augmented_joint`, supplies normalized Gaussian child kernels around transported parent coordinates. Its `sec:cross_scale_shadows` distinguishes the parent-predictive mixture from the strict mean-field message, and `sec:meta_agent_variational` leaves a post-merge model and full cost necessary for licensing. Its `sec:epistemic_collapse` expressly does not require perfect consensus for useful formation. The [current wiki entry](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires complete parent laws, evaluators, access, marks and memory.

[Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex), `eq:full-graph-generative-factorization` and `sec:full-graph-vfe-downward`, permits normalized downward kernels depending on retained structural information, with correlated recognition. The [root-prior correction](post-merge-source-and-gaussian-parent-bridge.md) remains in force. The [complete-channel derivation](shared-parent-complete-channel-and-recursive-cost.md) already supplies tree transports, barycenters and common-channel composition. Those constructions are reused.

The added choice is to use a component's actual independent-link tree paths as its cross-scale reference transports. The source's frame-factorized cross-scale maps do not uniquely imply this choice. It is admitted here as an explicit alternative downward kernel, at one fixed base point, using the already declared translation group and Gaussian law-mean coordinates. No principal transition cocycle is replaced, and no base path is introduced.

Let R be a connected-block partition of the four-cycle. In this new family the generative ancestry is R itself: there is no separate auxiliary component partition asserted to equal a latent T after inference. Decorate R by one root and one internal spanning tree per block, denoting the complete discrete structure by H. There are twelve connected partitions. Their four-cycle decoration counts are 16 for one block, 20 in total for two blocks, 8 for three blocks and 1 for four singleton blocks, for a total of 45. The three disconnected partitions remain in the previous model's retained results; this tree-path family cannot give them nonexistent connected internal trees.

Take any fixed positive partition prior pi_R. Its numerical values remain unspecified. Conditional on R, choose roots and internal spanning trees uniformly, with weight w(H|R)=1/N_R. Both channels share the same H. These are generative structural choices before the records, not posterior readouts, observed data, or a selected preferred grouping. Uniform root/tree weighting is a declared graph-label convention, not a theorem of VFE.

## 2. A normalized transported child-coordinate model

Each child carries the two unit-covariance Gaussian law points N(mu_i^b,I_2) and N(mu_i^m,I_2), with their means stacked in mu_i in R^4. Let g_i be the oriented tree-path sum of the independent four-vector links ell from the root of its R block to i. For positive a,b,c,v, generate

\[
 Y\sim N(0,vI_4),\quad Z_A\mid Y\sim N(Y,bI_4),\quad
 \ell_e\sim N(0,cI_4),\quad
 \mu_i\mid Z,\ell,H\sim N(Z_{R(i)}+g_i,aI_4).
 \tag{1}
\]

The primitive noises epsilon_i=mu_i-Z_R(i)-g_i, xi_A=Z_A-Y, ell_e and Y are independent Gaussian coordinates conditional on H. Child means and graph links are now correlated. Integrating the child densities, block densities, links and root, and then the finite structural prior, proves normalization. The change from (epsilon,xi,ell,Y) to (mu,Z,ell,Y) is triangular with determinant one. Thus this is one fixed generative joint with a normalized observation kernel; no current recognition law enters a generative factor.

The kernel acts on the coordinates of child law points. It does not equate a recognition distribution on these coordinates with a child's underlying Gaussian law. Integrating this kernel against a parent recognition gives a predictive mixture for its declared use; an existing child's posterior also includes its data and conditional correlations. The same observation is not inserted again as a second downward likelihood.

Under passive child-frame shifts, push the parent/root reference offsets and priors coherently. Then g_i'=g_i+h_i-h_rA and Z_A'=Z_A+h_rA, so the child conditional is pushed to mu_i'=mu_i+h_i. All residual probabilities below are invariant. The independent links retain nontrivial loop holonomy; selecting their tree paths for a downward reference does not set the remaining loop to zero.

Let B be the existing oriented four-cycle incidence, R the 4-by-k block indicator matrix, and P_H the 4-by-4 path matrix with g=P_H ell in each coordinate direction. Define

\[
 C_H=I_4-BP_H,\qquad J_R=BR,\qquad
 r=B\mu-\ell=B\epsilon+J_R\xi-C_H\ell.
 \tag{2}
\]

Every internal tree row of C_H is zero. On the q=k non-tree edge columns, its corresponding non-tree rows contain an identity submatrix, since P_H uses only internal tree edges. Thus these rows have rank k. Also 1^T C_H=1^T because 1^T B=0. The residual covariance in each of four coordinate directions is

\[
 \Gamma_H=aBB^T+bJ_RJ_R^T+cC_HC_H^T.
 \tag{3}
\]

It is positive definite. If a vector annihilates its a term, it lies in ker B^T=span(1); that vector cannot annihilate its c term because C_H^T1=1. This proves strict positivity for all a,c>0 and b>0. The original record probabilities remain p_e^x=exp(-||r_e^x||^2/2), with all eight labels retained. The common translation Y cancels and remains ancillary for these internal records. For one R block, xi cancels too. These are statements about this experiment, not about general parent observability.

## 3. Actual barycenter priors and normalized downward recovery

Let D_n=diag(n_A), n_A=|A|, and define the geometric barycenter from the complete channel. Equation (1) gives

\[
 z_A=\frac1{n_A}\sum_{i\in A}(\mu_i-g_i)
     =Z_A+\bar\epsilon_A,\qquad
 z\mid Y,H\sim N\left(1Y,\operatorname{diag}(b+a/n_A)\otimes I_4\right).
 \tag{4}
\]

The parent-predictive variance includes both block noise and averaged child noise. Dropping the latter would change the generator. The barycenter is a noisy measurement of the latent parent Z_A, rather than an identical copy of it. Marginalizing Y adds the v11^T covariance across blocks.

Let D_H be the k non-tree rows of C_H and V=D_H ell the complete individual cut/loop catalog. The Gaussian parent prior on (z,V) has

\[
 \operatorname{Cov}(z)=bI_k+aD_n^{-1}+v11^T,\qquad
 \operatorname{Cov}(V)=cD_HD_H^T,\qquad
 \operatorname{Cov}(z,V)=0
 \tag{5}
\]

in each coordinate direction. Both diagonal blocks are positive definite. This factorization is for this first-level generative prior conditional on H. Conditioning on records generally couples the blocks and channels.

For each component, write delta_i=epsilon_i-bar epsilon_A. The Gaussian mean/contrast decomposition gives a normalized downward kernel

\[
 \mu_i=g_i+z_A+\delta_i,\quad
 \sum_{i\in A}\delta_i=0,\quad
 \operatorname{Cov}(\delta_i,\delta_j)
    =a(\mathbf1_{i=j}-1/n_A)I_4\quad(i,j\in A).
 \tag{6}
\]

The contrasts are independent of z,V and the ancestor variables under the prior; different blocks' contrasts are independent. This is a proper Gaussian probability on the zero-sum subspace, not a nonsingular density on all child coordinates. For n_A=1 it is a point mass. For n_A>1, the negative cross covariance is required. A product of independent children with the same scalar marginals would violate the exact barycenter constraint.

When the discarded tree links are needed, their normalized conditional is

\[
 \ell\mid V,H\sim N\left(D_H^T(D_HD_H^T)^{-1}V,
    c[I_4-D_H^T(D_HD_H^T)^{-1}D_H]\otimes I_4\right),
 \tag{7}
\]

where the mean acts separately on the four coordinate directions. The first I_4 and matrix in (7) act on the four edge coordinates; the tensor factor acts on channel coordinates. The covariance is singular on the constraint D_H ell=V, as required. Together with (6) and ordinary Gaussian conditioning of (Y,Z) on z, (7) reconstructs the original prior. These kernels depend on the current model parameters, as the source permits. They are not a proof of a parameter-independent discarded conditional under arbitrary learning.

For example, at fixed Y, Z_A conditional on z_A has covariance ab/(a+n_Ab) I_4 and mean [aY+n_Ab z_A]/(a+n_Ab). This follows by adding the parent precision 1/b and measurement precision n_A/a. It retains both sources of uncertainty and supplies a concrete parent-predictive interpretation without inserting a posterior into (1).

## 4. Native inference, learning, and the required energy change

Use the actual primitive energies of (1): E_a now means sum_i||mu_i-Z_R(i)-g_i||^2. E_b,E_c,E_v retain their earlier primitive definitions. The previous untransported E_a is not substituted for this statistic. With H retained, all primitive counts are unchanged: 16 child, 4k block, 16 link and 4 root coordinates. Relative to the unit-variance reference for this new model,

\[
 \frac{dP_u}{dP_*}
 =u_a^8u_c^8u_v^2u_b^{2k}
   \exp[-\tfrac12\sum_j(u_j-1)E_j],\qquad
 \frac{dQ_\eta}{dP_*}
 =Z_\eta^{-1}\exp[-\tfrac12\sum_j(\rho_j-1)E_j+\omega k+s\log L_o].
 \tag{8}
\]

Consequently the [native-learning derivation](shared-parent-native-learning-and-memory.md), Sections 3-6, applies by an explicit change of the fixed residual map and E_a. Its required hypotheses hold: the coordinate change has unit determinant and is parameter independent; the structural catalog is finite; all priors normalize; (3) is positive definite; and Gaussian energy/log-likelihood moments are finite on compact positive-precision sets. The four energies, block count and log likelihood are nonredundant on the full structural family. No old result depending on the earlier Gamma or endpoint equivalence is transferred.

In particular, the full recognition natural flow remains dot rho_j=u_j-rho_j, dot omega=2 log u_b-omega, dot s=1-s. With K_pi=sum_R pi_R k(R), the complete-model Fisher matrix remains

\[
 G_P=\operatorname{diag}(8/u_a^2,2K_\pi/u_b^2,8/u_c^2,2/u_v^2).
 \tag{9}
\]

The native model precision equations use E_Q E_a/16, E_Q E_c/16 and E_Q E_v/4 as before, and dot u_b=(E_Q k/K_pi)u_b-u_b^2 E_Q E_b/(4K_pi). Thus the existing positive finite-time existence and VFE-dissipation proof carries over. The ancestry-normalizer memory lambda=omega-2 log rho_b remains required. The recognition mass of a decoration H is proportional to pi_R w(H|R) exp(lambda k) zeta_H(rho,s), where zeta_H is its normalized Gaussian likelihood-power integral using (3). The full structural law is therefore specified for any supplied fixed pi_R; it is not a collection of independently fitted parent posteriors. With a matched root, eight evolving law parameters suffice. This is a full law-level flow, not a simulated or physical link trajectory, and dissipation alone still proves no global convergence or useful formation.

The complete channel now retains (H,p,E_a,E_b,E_c,E_v,z,V), with the updated E_a. The common unit-reference conditional proof gives exact VFE and model/recognition Fisher closure again. Its local access and shared energy aggregation are those of the preceding construction. Removing p and energies merely because (z,V) has the simple prior (5) would change the inference problem and generally its metric.

At an exact posterior for a fixed H, let C_o denote the per-coordinate residual posterior second moment and Delta=Gamma_H^{-1}(C_o-Gamma_H)Gamma_H^{-1}. The accepted Gaussian M-energy coordinates are

\[
 a^+=a+\frac{a^2}{4}\operatorname{tr}(BB^T\Delta),\quad
 b^+=b+\frac{b^2}{k}\operatorname{tr}(J_RJ_R^T\Delta),\quad
 c^+=c+\frac{c^2}{4}\operatorname{tr}(C_HC_H^T\Delta),\quad v^+=v.
 \tag{10}
\]

They follow by Gaussian conditioning of all primitive noises, exactly as in the earlier M-coordinate derivation. For uncertain H, pool the expected primitive energies with their posterior structural weights before applying the appropriate coordinate-count denominator. The calculation below reports these quantities and initial derivatives at fixed R. It does not apply a finite M update or integrate the flow. Across different k, the complete native b equation retains its prior-count metric; averaging the fixed-R b velocities without that weighting would be wrong.

## 5. Complete same-record comparison

For the original ordered mathematical batch n=(8,1,8,1) successes and one failure at each label in each channel, define

\[
 e_H=\sum_{S\subseteq E}\frac{(-1)^{|S|}}
                   {\det[I_4+\Gamma_H\operatorname{diag}(n+1_S)]},\qquad
 P_R(o)=\sum_{H:R(H)=R}w(H\mid R)e_H^2.
 \tag{11}
\]

The determinant identity follows from the normalized Gaussian integral in each of the two coordinate directions of one channel. Although the two channels are independent conditional on H, they share H. The evidence is therefore the average of e_H squared. Squaring the average e_H incorrectly assigns independent geometry to the two channels. The difference is Var_H(e_H)>=0 and is recorded exactly. No binomial multiplicity is added to an ordered string.

At a=b=c=v=1, every connected partition and all its root/tree decorations were evaluated. Forty-five decorations give thirty-one distinct covariance matrices. The exact calculation also checks the full 256-outcome joint one-panel normalization for every R and reconstructs the energy coordinates from the complete primitive-noise posterior covariance.

| Partition | Evidence at the common unit variances |
| --- | ---: |
| One block {0,1,2,3} | 1.68645801539 x 10^-13 |
| Two blocks {0,1}, {2,3} | 6.83528670466 x 10^-14 |
| Each connected triple and its singleton | 3.79001698378 x 10^-14 |
| Two blocks {0,3}, {1,2} | 1.59888199355 x 10^-14 |
| Four singleton blocks | 5.32453323302 x 10^-15 |

The [result](evidence/transported-parent-prior/result.json) retains all twelve partitions, every decorated covariance, exact fractions and ties, posterior energy coordinates, and comparisons with the previous untransported model at the same parameters. One block remains the unique evidence maximizer. This is a comparison at one declared parameter point, not a fitted likelihood optimum, posterior over R without pi_R, new empirical confirmation, or a chosen resource-penalized objective.

The fixed-R native variance derivative at exact unit posterior is approximately (-0.48538157,0,-0.15689786) for one block and (-0.49647575,-0.20566181,-0.17023473) for {0,1},{2,3}, in the (a,b,c) coordinates. These are computed derivatives; no finite motion or stable outcome is inferred from them. All directions importing the old variance formulas were checked against the complete primitive covariance, including the new C_H link map.

## 6. Failure records impose a finite alignment boundary

Let m_H=4-k be the number of internal tree edges. At fixed b,c>0, their residuals are sqrt(a) times differences of standard child noises. For one channel,

\[
 e_H(a,b,c)=a^{m_H}M_H e_{{\rm cut},H}(b,c)+o(a^{m_H}),\qquad a\downarrow0.
 \tag{12}
\]

Here M_H is the positive Gaussian expectation of the product of squared two-dimensional internal residual norms divided by two, with unit child noise; e_cut,H is the strictly positive likelihood integral on the non-tree labels at a=0. The latter covariance is positive definite because the corresponding C_H rows have full rank.

To prove (12), divide each internal failure factor 1-exp(-a||d_e||^2/2) by a. It converges to ||d_e||^2/2 and is bounded above by that same polynomial. Internal success factors converge to one. The remaining bounded likelihood converges to the cut likelihood, whose limiting residuals depend only on xi and ell and are independent of the standardized child noises. Gaussian polynomial integrability justifies dominated convergence. The limiting coefficient is strictly positive. This proof does not require independence among internal edges.

The internal Gaussian moments are M_H=12 for a three-edge path, 5 for a two-edge path, 4 for two disjoint edges, 2 for one edge and 1 for no edges. For the path cases, the edge-difference covariance has diagonal 2 and adjacent off-diagonal -1. Expanding the two-coordinate Gaussian moments gives 4+1=5 for two adjacent edges and 8+2+2=12 for a three-edge path; disjoint edges factor. The independent exact Taylor check below verifies these coefficients against the original determinant expression.

Because the same H is shared by both channels, finite mixing gives

\[
 P_R(o;a,b,c)=a^{2(4-k)}
    \sum_{H:R(H)=R}w(H\mid R)M_H^2 e_{{\rm cut},H}(b,c)^2
    +o(a^{2(4-k)}).
 \tag{13}
\]

Every coefficient in the sum is positive. Thus each nonsingleton partition has evidence tending to zero at exact internal alignment. The all-singleton partition has a positive limit. For any fixed positive pi_R and fixed b,c>0, the structural posterior therefore concentrates on singletons as the shared a tends to zero. This is a conditional boundary statement, not the endpoint of the joint native learning flow. It says that this experiment's retained failures resist imposing exact internal consensus.

At a tending to infinity, every candidate evidence tends to zero too. Since every label has at least one success, L_o is bounded above by the all-success Gaussian factor. Its one-channel expectation is det(I+Gamma_H diag(n))^{-1}; Gamma_H contains aBB^T, whose three positive directions make this determinant diverge at least as a^3 while its remaining direction stays positive. Hence P_R(o)=O(a^-6). Continuity and positivity on a>0, together with the two zero limits for k<4, prove that at fixed b,c each nonsingleton candidate attains at least one interior maximum in a. Neither uniqueness nor full-parameter coercivity follows. For example, b can approach zero at fixed a,c with positive limiting evidence; the earlier general convergence gap persists.

A second [exact calculation](evidence/transported-parent-prior/boundary-result.json) expands the determinant rational functions at a=0 with b=c=1 for all forty-five decorations. Every coefficient below order 4-k vanishes exactly, and the leading coefficient equals the independently constructed M_H e_cut,H. This is a Taylor calculation at one boundary, not a sweep or a fit of nonzero a values.

## 7. Recursion induces a parent/loop coupling

The preceding complete-channel theorem already proves direct/staged barycenter and mark equality. Apply it to R={{0,1},{2,3}}, roots 0 and 2, and internal tree edges 01 and 23. With w=b+a/2, the first barycenters z_1,z_2 have conditional variance wI_4 around Y. They are independent of V_12=ell_01+ell_12 and V_30=ell_23+ell_30, each with variance 2cI_4.

Choose V_12 for the next tree. The actual grandparent barycenter and remaining loop are z_C=(z_1+z_2-V_12)/2 and H_loop=V_12+V_30. Their prior covariance in one coordinate direction is

\[
 \Sigma_C=
 \begin{pmatrix}
 v+w/2+c/2&-c\\
 -c&4c
 \end{pmatrix},\qquad
 \det\Sigma_C=4cv+2cw+c^2>0.
 \tag{14}
\]

Thus the next parent is correlated with its retained loop. A fresh one-block prior of form (5) at the same geometric barycenter would make that covariance zero for every choice of its positive variances, and cannot reproduce this law. At unit parameters the exact matrix is [[9/4,-1],[-1,4]], determinant 8. This failure is in the proposed independent-prior template, not in Gaussian marginalization or complete-channel composition.

The correct conditional parent law is explicit:

\[
 z_C\mid H_{\rm loop}\sim
 N\left(-H_{\rm loop}/4,
        [v+w/2+c/4]I_4\right),\qquad
 H_{\rm loop}\sim N(0,4cI_4).
 \tag{15}
\]

The loop-dependent conditional mean is an induced coupling, with its coefficient fixed by the original joint. No phenomenological curvature penalty or new tunable constant is introduced. A Gaussian innovation coordinate z_C+H_loop/4 is independent of the loop, but reconstructing the actual barycenter then requires the retained loop-dependent decoder. This reparameterization does not justify discarding the coupling or resetting the original barycenter law independently.

More general finite contractions are admitted by keeping the full correlated Gaussian prior on (z,V). For a full-row-rank linear stage A acting on a Gaussian parent coordinate W with covariance Sigma, the next covariance is A Sigma A^T and its reverse Gaussian has conditional mean Sigma A^T(A Sigma A^T)^(-1)w and the corresponding conditional covariance. This is the existing Gaussian marginal/conditional construction applied to the actual geometric map, not a new proof of arbitrary-family RG closure. The original nonlinear record catalog and native energy memory still travel with it. Independently fitting new Gaussian factors or introducing new interaction likelihoods requires a separate admitted model extension.

## 8. What is closed, what costs remain, and the next obligation

This family fixes the missing first downward kernel: ancestry R is generative, the transported barycenter has a proper prior, and the child recovery is an explicitly correlated normalized kernel. The native full-law update exists with the corrected energy, and the complete sufficient parent channel remains exact. Finite Gaussian prior composition is available if induced covariances and conditional decoders are retained. The simple independent parent/mark template does not reproduce itself at the second stage.

Continuous sample accounting remains 36+4k at fine level and 12+8q at a geometric q-block parent retaining the original probabilities and four energy totals. In the two-pair sector this permits the same 44-to-28-to-20 original-record sample maps, plus the required discrete structure. The earlier new-interaction rank witness belongs to its stated earlier prior/coordinate construction; no identical numerical rank is assumed here without recalculation. Its general requirement to retain new evaluators remains applicable. The new first-level Gaussian prior alone on (z,V) has 8k coordinates, but generating the original p and energy totals still involves hidden contrasts and ancestors. A reduced Gaussian prior is therefore not the complete native inference state.

The shared eight-coordinate law solver and its moment computations are available to the fine implementation too. This comparison evaluated 31 distinct four-dimensional Gaussian covariances to cover 45 structural decorations; it does not establish lower inference cost than the earlier model or a fine analytic solver. Proper density/conditional evaluators, original-record filtering, complete interface storage and generation must all be priced. No measured net resource advantage is claimed.

The next decisive question is finite-coherence structural learning in this declared model: whether its actual coupled native dynamics support an informative intermediate ancestry, with the induced correlated parent law and a complete resource advantage. The fixed-variance table and the exact a-to-zero boundary constrain that question but do not answer it. Do not tune parameters until the desired partition appears, transfer the old auxiliary kinetics, treat a posterior structure label as a physical persistent process, or reset the induced parent/loop covariance. A continuous-parameter theoretical classification must retain every candidate and tie rather than selecting favorable points.

## 9. Execution and preservation

[transported_exact.py](evidence/transported-parent-prior/transported_exact.py) ran once under pinned CPython 3.14.7, finishing in 0.32208950000131154 seconds. It evaluates all twelve connected candidates and forty-five decorations, checks thirty-one distinct positive residual covariances and posterior covariances, full joint panel normalization, complete primitive energy reconstruction, the shared-geometry channel mixture, and (14) at unit parameters. [boundary_exact.py](evidence/transported-parent-prior/boundary_exact.py) separately ran once in 0.3256108999994467 seconds, checking the new Taylor-coefficient obligation. Neither invokes earlier helper mains. Their exact outputs and source bindings are retained.

The preceding goal turn supplied the complete channel and was progress. This turn used three sequential substantive passes: source-based downward construction, exhaustive fixed-parameter comparison and native score reconstruction, then boundary/composition analysis. The original saved data, prior results, WIP and manuscript sources remain preserved. No finite M update, parameter search, optimization, new observations, sampling, ODE, GPU, suite, Lean, tamper checks, publication or synchronization occurred. No agents or formal ledger certificate were invoked. The full goal remains open.
