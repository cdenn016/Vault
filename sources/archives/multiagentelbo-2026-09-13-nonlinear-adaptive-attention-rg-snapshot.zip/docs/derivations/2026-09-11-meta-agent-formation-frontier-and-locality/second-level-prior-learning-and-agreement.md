# Second-level prior learning and parent agreement

September 12, 2026. The existing construction already transmits native learning through a complete finite hierarchy. What remained uncalculated was which second-level geometric prior and downward-kernel parameters actually change, whether that kernel reconstructs the recognized children, and how the parents' own agreement responds. This continuation resolves those questions for the existing transported pair sector and the unchanged original records.

The induced second-level model prior changes immediately under the full native learner, while its complete recognition law starts with the established inference lag. The parents' agreement readout increases initially for every positive ancestry prior, but its initial merge probability is only 0.2938789175. A positive interval exists on which it is increasing yet splitting remains more probable. The Gaussian prior reverse kernel also fails to reconstruct the actual posterior: it would retain relative-parent variance 3, whereas the exact recognized value is 1.149043688. Thus inherited learning is present; licensed, persistent selection of a second grouping is still unestablished.

## 1. What the sources already supply

[Transported parent priors](transported-parent-priors-and-induced-couplings.md), Section 7, already derives the correlated grandparent/loop prior, its innovation coordinate and the general Gaussian reverse kernel. [Complete parent channels](shared-parent-complete-channel-and-recursive-cost.md), Sections 4-5, already proves that the original probability catalog and primitive energies make the correlated native update descend through finite compositions. Neither result says that the coarse variables have an independently chosen update rate or that the next grouping is selected by the same ELBO.

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:cross_scale_shadows` and `app:augmented_joint`, distinguishes a parent-predictive mixture from a child's posterior and from a strict mean-field message. Its normalized hierarchical joint is the relevant precedent. The [operational wiki definition](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>) requires model, evaluator, access, marks and memory. The calculation here develops the existing conditional construction rather than introducing a new prior, observation likelihood, penalty or physical clock.

Keep all twelve connected ancestries and their fixed positive pi_R. Conditional on the pair P={{0,1},{2,3}}, average its four root decorations as in the original model. For the explicit Gaussian formulas in Sections 2-4, use the already studied canonical decoration H_* with roots 0,2, internal trees 01,23 and second geometric tree edge 12. Other decorations remain in the agreement and posterior calculations below. All coordinates are in the existing common reference frame, with priors and offsets pushed together under a passive frame change. Work stays at one base point.

## 2. The induced second-level model and its reverse kernel

Use a,b,c,v for the model variances. In the canonical sector define q=a+2b and h=v+(q+c)/4. The first barycenters z_1,z_2 have marginal variance v+q/2, cross covariance v, and are independent of the two marks V_12,V_30, each with variance 2c. Put

\[
 z_*=(z_1+z_2-V_{12})/2,
  W=V_{12}+V_{30},
  I=z_*+W/4.
 \tag{1}
\]

The source's correlated prior is equivalently I~N(0,h I_4), W~N(0,4c I_4), independently. Reconstructing z_* requires the retained W; independence in the innovation chart is not permission to reset the barycenter/loop law.

An explicit basis for the conditional Gaussian reverse kernel is useful. Let D_z=z_2-z_1 and D_V=V_12-V_30. Given I,W,

\[
 D_z\sim N(0,qI_4),
 
 D_V\sim N\left(-\frac{c}{h}I,
                   \left[4c-\frac{c^2}{h}\right]I_4\right),
 \tag{2}
\]

independently, and

\[
 z_1=I+D_V/4-D_z/2,
  z_2=I+D_V/4+D_z/2,
  V_{12}=(W+D_V)/2,
  V_{30}=(W-D_V)/2.
 \tag{3}
\]

To derive this, the first mean z_c=(z_1+z_2)/2 and D_z are independent Gaussians with variances v+q/4 and q. Similarly W and D_V are independent with variances 4c. Equation (1) gives I=z_c-D_V/4, so Cov(D_V,I)=-c and Var(I)=h. Gaussian conditioning proves (2); (3) is the inverse linear map. Both conditional variances are strictly positive because q>0 and h>c/4. This is a normalized probability on the affine fiber of (1), not four independent child-parent kernels.

The kernel is a generative conditional of first-parent geometry. Its use with a parent recognition law gives a proper predictive mixture. Equality with the original recognized first-parent state is a different question, settled negatively in Section 5 for the Gaussian kernel alone.

## 3. Actual native evolution of these model parameters

The unchanged complete-model Fisher flow, written in variance coordinates, is

\[
 \dot a=\langle E_a\rangle_Q/16-a,
 
 \dot b=\frac{\langle E_b\rangle_Q/4-\langle k\rangle_Q b}{K_\pi},
 
 \dot c=\langle E_c\rangle_Q/16-c,
  K_\pi=\sum_R\pi_Rk_R.
 \tag{4}
\]

The matched root has dot v=0. Equation (4) is obtained by differentiating a=1/u_a and the other inverse precisions in the already accepted native equations. The expected block count in the score is not interchangeable with K_pi in the metric. Therefore

\[
 \dot q=\dot a+2\dot b,
  \dot h=(\dot q+\dot c)/4,
 
 \frac{d}{dt}\frac{c}{h}=\frac{h\dot c-c\dot h}{h^2}.
 \tag{5}
\]

These formulas determine the changing prior variances and conditional mean/variance in (2). They are inherited parameter evolution in the same normalized joint. No new clock, natural metric or independently fitted second-level kernel has been assigned.

At the common unit model and exact posterior preparation, the [saved native calculation](evidence/finite-coherence-classification/native-jet.json) proves dot a,dot b,dot c<0 for every fixed positive pi_R. If m_a and m_c are its strictly positive minimum component decreases, then

\[
 \dot q(0)\leq-m_a<0,
 
 \dot h(0)\leq-(m_a+m_c)/4<0,
 
 \dot c(0)\leq-m_c<0.
 \tag{6}
\]

Thus the canonical second-level geometric model prior actually learns. Its squared Fisher speed is 2(dot h/h)^2+2(dot c/c)^2, because its innovation and loop are independent four-dimensional isotropic Gaussians. At the unit preparation the exact lower bound from (6) is approximately 0.05493013895. This is a conditional H_* prior statement under the global native velocity. It does not assert the same covariance formula for every root decoration, a new observed datum, or that the ancillary Y itself became identifiable.

The complete recognition law has a different startup. With s=1, its coordinates eta=(rho_a,rho_b,rho_c,omega) satisfy dot rho=u-rho and dot omega=2 log u_b-omega. At the exact unit posterior,

\[
 \dot\eta(0)=0,
 
 w:=\ddot\eta(0)
 =\big(\dot u_a(0),\dot u_b(0),\dot u_c(0),2\dot u_b(0)\big)\ne0.
 \tag{7}
\]

Let T=(-E_a/2,-E_b/2,-E_c/2,k). Exponential-family expansion gives, for each fixed positive prior,

\[
 D(Q_t\Vert Q_0)
 =\frac{t^4}{8}\operatorname{Var}_{Q_0}(w\cdot T)+O(t^5),
  \operatorname{Var}_{Q_0}(w\cdot T)>0.
 \tag{8}
\]

Indeed eta(t)-eta(0)=w t^2/2+O(t^3), and KL is one half of its Fisher quadratic to leading order. The variance is finite by the positive Gaussian envelope. It is strictly positive: dot u_a and dot u_c are positive, so w dot T contains a nonconstant negative quadratic in primitive noises on an open set of positive posterior density. Every complete parent retaining the original probabilities and four energies has this same KL expansion by the existing common-conditional identity. Its recognition therefore changes too. The order difference between (6) and (8) is the native inference lag; it is not a separately imposed slow clock.

## 4. The geometric Gaussian prior alone loses an identifiable model direction

The two geometric parameters h,c do not specify the original experiment. With v fixed, h depends on a,b only through q=a+2b. In the canonical H_* sector, the positive parameter choices

\[
 (a,b,c,v)=(1,1,1,1)
 \hbox{and} (3/2,3/4,1,1)
 \tag{9}
\]

have identical first-parent geometric priors, identical h=2,c=1 second-level priors and identical Gaussian reverse kernels (2). Yet the original internal edge 01 has residual epsilon_1-epsilon_0 and prior single-channel success probability

\[
 E p_{01}^x=\frac1{1+2a},
  \frac13\ne\frac14.
 \tag{10}
\]

The equality follows by integrating exp(-||r||^2/2) over a two-dimensional Gaussian with covariance 2a I_2. A common record channel acting on the same geometric prior law cannot produce both values. This is an exact counterexample to completeness of the geometric Gaussian law alone, not a parameter search or a comparison of fitted models. Supplying the missing a through model parameters can repair the generative specification, but that supplied information and its update must then be counted.

The Fisher calculation identifies the same loss locally. At unit parameters conditioned on H_*, the complete variance metric in (a,b,c) is diag(8,4,8). The geometric prior metric is

\[
 G_{\rm geom}=\frac2{h^2}(dh)(dh)^T+rac2{c^2}(dc)(dc)^T,
  dh=(1/4,1/2,1/4)^T.
 \tag{11}
\]

For the direction (da,db,dc)=(2,-1,0), the geometric norm is zero and the complete squared norm is 36. Consequently that Gaussian geometric projection is not Fisher sufficient for the original native model. This is a conditional-sector statement, not a rank-two claim about an arbitrary mixture of all geometries.

An exact model chart that retains the missing variable is (a,q,c), with 0<a<q and b=(q-a)/2. Pulling back the actual full-mixture metric yields

\[
 G_{(a,q,c)}=
 \begin{pmatrix}
 8/a^2+\kappa&-\kappa&0\\
 -\kappa&\kappa&0\\
 0&0&8/c^2
 \end{pmatrix},
 \kappa=\frac{2K_\pi}{(q-a)^2}.
 \tag{12}
\]

This is positive definite. In the conditional H_* unit case it is [[9,-1,0],[-1,1,0],[0,0,8]], reproduced exactly by the calculation. The off-diagonal term couples the internal variance to the second-level contrast variance. Assigning independent scalar natural gradients to them would change the update. This reparameterization adds no new model dimension and does not compress the existing seven-coordinate law solver.

## 5. A prior reverse kernel is not the recognized downward conditional

For every root decoration of P, D_z=z_2-z_1 is independent under the Gaussian prior of the first mean (z_1+z_2)/2 and of all V marks. Hence its variance per coordinate is q, and its conditional law given any prescribed second barycenter and loop is N(0,q I_4). This remains true for the appropriate Gaussian reverse kernel of each decoration, even when its mark variances differ from the canonical case.

Therefore mixing these Gaussian prior reverse kernels against any top recognition distribution, including uncertain H, would still give E||D_z||^2/4=q. The exact unit posterior for the original records instead gives

\[
 \frac14E_{Q_0(\cdot\mid P)}\|z_2-z_1\|^2
 =1.149043687725721\ldots\ne3=q.
 \tag{13}
\]

This value averages the original four decorations with their correct posterior weights. It proves that the naive predictive mixture fails to reconstruct even this one recognized second moment. The complete output distribution, not merely a chosen covariance convention, differs.

At an exact model posterior, the correct conditional on first geometry F and top geometry G has the form

\[
 P(F\mid G,o)
 =P(F\mid G)\frac{P(o\mid F,G)}{P(o\mid G)}.
 \tag{14}
\]

The likelihoods in (14) are conditional averages over any finer variables still hidden. The ratio accounts for the same original observation exactly once; it is not a newly observed parent interaction. Away from the instantaneous posterior, the recognition Gaussian reference and its likelihood tilt supply the corresponding identity, rather than substituting the current model conditional without checking the lag. Retaining the complete probability/energy carrier gives the existing common conditional and avoids this erroneous Gaussian reconstruction. The source's distinction between a proper parent-predictive prior and a recognized child law is therefore operational in this instance.

## 6. Exact agreement between the actual first parents

The source already defines a parent cut probability from its own transported Gaussian law points, p_tilde_e^x=exp(-||z_B^x-z_A^x-V_e^x||^2/2). These are distinct from the original child-edge observations. Here they are evaluated as a diagnostic of the learned state; no new likelihood or data are inserted.

For P with internal edges 01,23, the two parent residuals have a fixed expression in the original four residuals, valid for every root decoration:

\[
 \begin{pmatrix}\widetilde r_{12}\\\widetilde r_{30}\end{pmatrix}
 =T_P r,
 
 T_P=
 \begin{pmatrix}
 1/2&1&1/2&0\\
 1/2&0&1/2&1
 \end{pmatrix}.
 \tag{15}
\]

For example, internal residuals determine the two within-pair contrasts; substituting their half-differences into the parent means gives the first row of (15), and the other cut gives the second. The exact calculation checks this row identity against the complete primitive map in all four decorations.

Apply the already used agreement-panel convention prospectively at this parent level: a cut is active when both channel flags succeed, and the two parents connect when either cut is active. Conditional on the first-parent state, these auxiliary flags are independent and have probabilities A_e=p_tilde_e^b p_tilde_e^m. The merge readout is

\[
 F_2=1-(1-A_{12})(1-A_{30}),
  M(\rho)=E_{Q_\rho(\cdot\mid P)}F_2.
 \tag{16}
\]

This is a normalized possible readout of the existing laws, not a native posterior over a new generative hierarchy variable. No flag is sampled. Using it as a new prior term or observing its outcomes would require a separate model or experiment. If the readout is attached as a common normalized auxiliary channel to both prior and recognition, the original evidence and exact VFE do not change.

For each decoration let t_e be a row of T_P. The conditional one-channel integral with any subset A of the two parent probabilities is

\[
 e_{H,A}=\sum_{S\subseteq E}(-1)^{|S|}
 \det\left[I+\Gamma_H\left(\operatorname{diag}(n+1_S)
                     +\sum_{e\in A}t_e^Tt_e\right)\right]^{-1}.
 \tag{17}
\]

The shared decoration is retained across both channels. Thus an activation probability is the decoration average of e_H,A squared, divided by the original pair evidence. Equation (16) is the sum of the two single-cut activations minus their joint activation. The four resulting flag probabilities are positive and sum exactly to one. Their merge sum is

\[
 M(1,1,1)=0.2938789174991327\ldots<1/2.
 \tag{18}
\]

The probability of no active cut is about 0.7061210825. These are probabilities of a prospective auxiliary diagnostic conditional on P and the original records. They are neither observed frequencies nor a full posterior mass for the nested hierarchy.

## 7. Native agreement increases, but a second merge is not initially preferred

Because F_2 is a fixed function of the sample, exponential-family differentiation gives

\[
 \partial_{\rho_j}M=-\tfrac12\operatorname{Cov}_{Q(\cdot\mid P)}(F_2,E_j).
 \tag{19}
\]

The exact three derivatives at the unit posterior, in the (a,b,c) precision order, are approximately

\[
 (0.00626043293227, 0.01371084033494, 0.05411540469786).
 \tag{20}
\]

All are strictly positive. Conditioning on P makes its k constant, so omega drops out of M. Equations (7) and (19) imply

\[
 \dot M(0)=0,
  \ddot M(0)=\sum_{j=a,b,c}(\partial_{\rho_j}M)\dot u_j(0)>0.
 \tag{21}
\]

for every fixed positive full ancestry prior. The full prior-count Fisher denominator remains in dot u_b. Clearing Z_pi K_pi gives seventy-eight strictly positive quadratic coefficients in pi, all saved exactly. Their direct coefficient bound gives the positive lower bound 0.0005689497059876565 for (21); the positive a and c terms alone also give a sharper symbolic lower bound (partial_rho_a M)m_a+(partial_rho_c M)m_c. No prior is chosen in these arguments.

This favorable direction is insufficient for a second favored merge. On the compact positive state domain used by the [native crossing theorem](native-ancestry-crossings-and-selection-loss.md), the full vector field and M have uniformly bounded second and third flow derivatives over the closed prior simplex. Let B_2 exceed the absolute second derivative bound, B_3 exceed the third derivative bound, and let r_2>0 be a uniform lower bound in (21). For sufficiently small positive T_2, with

\[
 T_2\leq\min\left(T_*,\frac{r_2}{2B_3},
          \sqrt{\frac{1/2-M(0)}{B_2}}\right),
 \tag{22}
\]

integration gives, uniformly over the positive prior family,

\[
 M(0)+r_2t^2/4\leq M(t)
 \leq M(0)+B_2t^2/2<1/2
 (0<t\leq T_2).
 \tag{23}
\]

The upper inequality is strict because the chosen bound leaves half the initial gap. The state-domain condition is inherited from T_*; M has no small prior-weight denominator because it is conditioned on P. No numerical derivative bounds or useful duration are evaluated.

The earlier first-level O-to-P crossing theorem can be applied with its positive horizon decreased to T_2. Its open near-tie prior region then gives an interval on which P is the unique first-level MAP ancestry while the second-level agreement readout still favors keeping its two parents separate. This is a scoped separation of two formation conditions. It does not exclude a later merge, a different admitted readout, or a broader hierarchy.

If the auxiliary channel is explicitly attached, hard conditioning on its merged P branch carries the same exact support loss as before. Conditional on P, its mass is M(t), and the closest supported law has forward KL -log M(t) and TV 1-M(t). At the first O/P crossing, Q(P)=Q(O)<1/2 and M<1/2, so the joint merged-P event has mass less than 1/4: selecting it discards more than three quarters of the augmented recognition probability and costs more than log 4 in forward KL. This is recognition conditioning loss; the optimized fixed-model free-energy restriction uses the exact model posterior instead. The diagnostic cannot supply a free licensing rule.

## 8. Completion boundary and evidence

The current hierarchy has inherited model learning and inherited recognition learning at its complete geometric levels; it was too broad to describe the unresolved part simply as an absence of second-level learning. Equations (4)-(8) specify the existing learning and its lag. What remains unestablished is useful, persistent selection of the second grouping, a complete cost advantage and any newly introduced higher-level interaction model. The early disagreement between first-level MAP preference and second-level merge preference is retained as an exact negative result.

The first parents already compute all four p_tilde entries from their z and V. If later stages must continue to expose those entries after discarding their arguments, append them to the shared catalog before contraction. This gives a displayed pair-sector count 44 to 28 to 24 for that access requirement. It is a sufficient extension; the older untransported rank witness is not asserted to prove its minimality for this changed model. A sampled grouping mark or panel history must also be retained when it affects later access. Conditioning a Gaussian candidate prior on an agreement-based selection generally makes it non-Gaussian; use the full marked pushforward, not its unconditioned Gaussian covariance.

The [exact calculation](evidence/second-level-learning/second_level_exact.py) passed once under pinned CPython 3.14.7 in 0.05073199999606004 seconds. It checks the Gaussian reverse covariance, the two explicit prior-equivalence cases and their record discrepancy, the transformed Fisher metric, all four decorated parent-residual maps, exact auxiliary flag normalization, the relative-parent posterior moment, the three response covariances and all seventy-eight native-prior coefficients. Its 192 Gaussian terms cover three residual covariances and four masks: 144 terms for new parent activations, plus 48 original-mask terms needed for the new relative-parent moment and its consistency checks. The earlier full 496-term experiment and scientific mains were not rerun.

The continuous-family kernel, induced metric, KL startup, derivative-to-interval argument and selection-loss result are written proofs. The [saved output](evidence/second-level-learning/second-level-response.json) contains their exact finite coefficients and complete signs. No samples, new observations, added likelihood or prior tilt, numerical ancestry prior, fitting, parameter search, ODE, full suite, GPU, Lean, tamper check, production/configuration change, vault edit, publication or canonical synchronization occurred. Saved data, prior results and protected WIP remain intact.
