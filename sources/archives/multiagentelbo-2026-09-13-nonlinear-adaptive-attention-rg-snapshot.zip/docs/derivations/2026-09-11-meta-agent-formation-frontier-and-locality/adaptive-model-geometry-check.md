# Reconstruction of the adaptive normalized model and marked-parent geometry

September 12, 2026. This is a separate written reconstruction of the model and geometry components of the adaptive cyclic RG contract, target digest `e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90`. The calculations below establish these components on their stated finite Gaussian domain. They do not establish the companion successive-formation and conditional-tracking theorem. One defective display and one ambiguity in the application of the Gaussian formulas were corrected during this check with the coordinating agent's authorization. No ledger state is assigned here.

## 1. Exact target, premises, and source boundary

The frozen target quantifies over every prescribed finite integer `L>=2`: exhibit a nonempty admitted family with `L` successive formation levels on a weighted graph containing a cycle through coalescing agents, genuine model learning that changes an eliminated conditional by an amount bounded below independently of the separation parameter, exact normalized marked parents, and quantitative conditional-VFE and dynamical errors on the same appreciable adaptation interval. Equality means exact common-channel pushforward, ordered composition, and conditional-VFE identities. Dynamical replacement is a separately bounded approximation beginning with the actual retained law.

This assignment checks the normalized model, model score and Fisher metric, long-horizon learning inequality, law/link types, loop and cut retention, Gaussian marginalization, and inherited kinetic matrices. It does not claim to have reconstructed the companion formation windows or their joint parameter-selection argument. The smaller result here retains those original obligations rather than replacing the target.

The user supplies one fixed base point, agents as local sections of associated statistical bundles over a common principal bundle, independent interaction links, complete normalized generative and correlated recognition laws, preservation of loop/cut data, distinction of energy strengths from attention probabilities, and permission for a belief-dominant regime with absent inter-agent model alignment. No base path, identity-holonomy penalty, new parent rate, or externally prescribed learning schedule is admitted.

The proposed witness additionally declares the translation group, scalar fixed-variance Gaussian law points, a finite chain of triangles, strictly positive microscopic edge strengths, Euclidean unit configuration mobility, the correlated proper quadratic reference `P_K`, compatible Gaussian observations, a scalar learned coefficient `a`, and Gaussian initial recognition. These are modeling assumptions, not consequences of the original bundle ontology. Smooth Gaussian domination on compact positive parameter intervals supplies the differentiation and integrability used below.

The source consultation was read-only except for the explicitly authorized repairs described in Section 10. It included `docs/STATUS.md`, `Theory/SPEC.md`, [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex), its normalized full-graph and nonflat sections, [the microscopic model](microscopic-vfe-dynamics-construction.md), its evaluator, VFE, kinetic and parameter-learning sections, and [the GL marked-parent derivation](gl-alignment-marked-parent.md), its normal Hessian and exact mark sections. The live Research index, September research synthesis, Holonomy note, and `PIFB2.tex` lines 387–418 and 938–968 were consulted for continuity. Their status labels were not used as mathematical premises.

The proposed files checked in full were [adaptive-normalized-model.md](adaptive-normalized-model.md) and [adaptive-loop-parent-geometry.md](adaptive-loop-parent-geometry.md). The Gaussian conditional and block inverse identities also agree with the explicitly positive-definite hypotheses in [Rasmussen and Williams, Appendix A, equations A.4–A.6 and A.11–A.15](https://gaussianprocess.org/gpml/chapters/RWA.pdf), retrieved September 12. The derivations needed here are given below; that reference supplies no formation or adaptation theorem.

## 2. The evaluator minimum and all normalizers

Use `m=dim x` to avoid confusing the ambient dimension with the bridge residual `d=u-v`. Write `s=1-c`, where `0<c<1`. At one node the physical model/evaluator joint is

\[
P_v^{\rm ev}(d\zeta,dk)
=N(v,c)(d\zeta)N(\zeta,s)(dk).
\]

The candidate constrained joint has `zeta=v+xi`, `k=u+xi+epsilon`, with independent variances `c,s`. It has exactly the prescribed marginals `N(v,c)` and `N(u,1)`. Put `delta=u-v`. Directly dividing its conditional Gaussian density by the evaluator density gives

\[
\log\frac{dR_{u,v}}{dP_v^{\rm ev}}
=\frac{\delta(k-\zeta)-\delta^2/2}{s}.
\tag{C1}
\]

Every coupling `S` of these marginals has `E_S(k-zeta)=delta`. Consequently

\[
\operatorname{KL}(S\Vert P_v^{\rm ev})
=\operatorname{KL}(S\Vert R_{u,v})+\frac{\delta^2}{2s}.
\tag{C2}
\]

The affine ratio in (C1) is integrable under every such coupling because its marginals are Gaussian. Thus (C2) also holds with infinite KL; a singular coupling has infinite KL to both strictly positive Gaussian densities. Equality in the finite minimum forces `S=R`. For several nodes, dependence between their inner pairs contributes a further conditional KL to the product of the `R_i`. The claimed minimum is therefore over all admissible couplings, not only Gaussian ones. The bridge matrix is exactly `R=b_d^T b_d/(1-c)`.

Let `H` be the positive weighted residual stiffness, `K=ker H`, and `P_K` its orthogonal projector. Independent link columns and independent `v` columns make the residual rows linearly independent. Hence `H` is positive definite on `K` perpendicular. Also `R K=0`. The admission `T<=J_1(1-c)/2` gives

\[
TR\preceq H/2,\qquad
A_0(a)=aH+P_K-TR
\succeq(a-1/2)H+P_K
\succeq(a/2)H+P_K\succ0
\tag{C3}
\]

for every `a>=1`. The first inequality uses the bridge summand in `H`; the last uses `a>=1`. Therefore

\[
Z_0(a)=(2\pi T)^{m/2}\det A_0(a)^{-1/2}
\]

is finite and positive. The proper Gaussian reference is not an invariant Haar probability on the translation group.

For observations `O=z`, `Y=2`, put

\[
c_O=(\kappa/(2\pi T))^{m/2},\qquad
c_Y=(2\pi T)^{-1/2},\qquad f=\kappa z,
\]

\[
K_a=aH+P_K+\kappa I,\qquad
K_a^{\rm phys}=A_0(a)+\kappa I=K_a-TR,
\]

\[
\mathcal Z(K_*,f)=(2\pi T)^{m/2}\det K_*^{-1/2}
       \exp\left(\frac{f^TK_*^{-1}f}{2T}\right).
\tag{C4}
\]

Here `K_*` denotes an SPD matrix; it is distinct from the subspace `K`. Integrating the physical inner normalized kernels first and completing the square in `x` gives the actual evidence

\[
p_a(z,2)=\frac{c_Oc_Y}{Z_0(a)}
\exp\left[-\frac{\kappa\|z\|^2+(a-2)^2}{2T}\right]
\mathcal Z(K_a^{\rm phys},f).
\tag{C5}
\]

The constrained evaluator KL contributes `T x^T R x/2`, exactly canceling the subtraction in `A_0`. Thus, for the stated finite-entropy, finite-moment recognition domain,

\[
\begin{split}
F_T(Q,a)={}&T\int q\log q
 +E_Q\left[\frac12x^TK_ax-f^Tx\right]\\
&+T\log Z_0(a)-T\log(c_Oc_Y)
 +\frac{\kappa\|z\|^2+(a-2)^2}{2}.
\end{split}
\tag{C6}
\]

Equivalently,

\[
F_T(Q,a)=T\operatorname{KL}(Q\Vert\pi_a)+C_T(a),
\quad
\pi_a=N(K_a^{-1}f,TK_a^{-1}),
\tag{C7}
\]

where

\[
C_T(a)=T\log Z_0(a)-T\log(c_Oc_Y)
 +\frac{\kappa\|z\|^2+(a-2)^2}{2}
 -T\log\mathcal Z(K_a,f).
\tag{C8}
\]

Because `f in K`, both precisions have the same action `(1+kappa)I` on `f`. Their means agree, but their normal covariances differ. In particular

\[
C_T(a)=-T\log p_a(z,2)
 +\frac T2\log\frac{\det K_a}{\det K_a^{\rm phys}}.
\tag{C9}
\]

The last term is positive for this nontrivial bridge. It is the evaluator-restriction gap, not additional evidence. This derivation checks the physical posterior, the variational optimizer, and every observation and prior normalizer separately.

For any fixed deterministic retention `C_s`, the exact restricted parent objective is

\[
F_T^s(Q_s,a)=T\operatorname{KL}(Q_s\Vert\pi_a^s)+C_T(a),
\qquad \pi_a^s=(C_s)_\#\pi_a.
\tag{C10}
\]

Factoring `q/pi_a` into retained and conditional density ratios proves

\[
F_T(Q,a)-F_T^s(Q_s,a)
=T E_{Q_s}\operatorname{KL}(Q(\cdot\mid y)\Vert\pi_a(\cdot\mid y)).
\tag{C11}
\]

No new constant appears at the next retention. Applying (C11) repeatedly gives the ordered sum of conditional KLs with the same `C_T(a)`. The physical parent objective instead uses the pushforward of the physical posterior and `-T log p_a(z,2)`. Neither its posterior nor its prior reverse evaluator kernel may be replaced by the optimizer conditional without changing the experiment.

## 3. Complete model score, Fisher metric, and dissipation

Differentiate the normalized Gaussian prior while holding its sample `x` fixed:

\[
s_0(x,a)=\partial_a\log p_{0,a}(x)
=\frac12\operatorname{tr}(A_0^{-1}H)-\frac{x^THx}{2T}.
\tag{C12}
\]

Its mean under `P_0` is zero since `E x^T Hx=T tr(A_0^{-1}H)`. If `X` is centered Gaussian with covariance `C`, diagonalizing `C^{1/2}HC^{1/2}` gives `X^THX=sum lambda_j Z_j^2`, with independent standard normals. The identities `Var(Z_j^2)=2` and zero cross covariance therefore give

\[
\operatorname{Var}(X^THX)=2\operatorname{tr}[(CH)^2].
\tag{C13}
\]

This proves that the prior score variance is `tr[(A_0^-1 H)^2]/2`, without requiring `A_0` and `H` to commute. The calibration observation score is `(Y-a)/T`, with mean zero and variance `1/T`. It is independent of the prior sample in the complete generative experiment, so the cross term vanishes. The `O`, presentation, and evaluator factors have no explicit `a` derivative at fixed complete data. The complete-experiment Fisher is consequently exactly

\[
M(a)=\frac1T+\frac12\operatorname{tr}[(A_0^{-1}H)^2]>0.
\tag{C14}
\]

Differentiating (C6) at fixed `Q` gives

\[
g(a,Q)=a-2+\frac12E_Qx^THx
              -\frac T2\operatorname{tr}(A_0^{-1}H).
\tag{C15}
\]

The final term is indispensable. Dropping it would differentiate a different, unnormalized model. With metric `TM/epsilon`, the parameter equation is the stated natural-gradient equation `a'=-epsilon g/(TM)`. Setting the inter-agent model alignment to zero does not remove any factor in (C12)–(C15).

For the configuration diffusion, the Fokker–Planck equation is

\[
\partial_tq=\operatorname{div}\left(qT\nabla\log(q/\pi_a)\right).
\]

Gaussian tails justify integration by parts and differentiation of the entropy along the admitted Gaussian solution. The chain rule with (C15) proves

\[
\frac{dF_T}{dt}
=-T^2\int q\|\nabla\log(q/\pi_a)\|^2
 -\frac{\epsilon}{TM(a)}g(a,Q)^2.
\tag{C16}
\]

This combines the same complete VFE and the specified two metrics. It is not a claim that configuration diffusion is Fisher–Rao flow on the full density space, or that the Fisher metric of a marginal experiment can replace the complete-experiment parameter metric.

## 4. Long-horizon learning and physical conditional change

The initial conditions are `a(0)=1`, `mu_0` perpendicular to `K`, `Sigma_0=T K_1^-1`, with

\[
\frac12\mu_0^TH\mu_0\le\frac1{40},\qquad
Tp\le\frac1{40},\qquad p=\operatorname{rank}H.
\tag{C17}
\]

On a provisional interval `1<=a<=21/10`, `K_a` commutes with `H` and `P_K`. Hence

\[
\mu_N(t)=e^{-\kappa t}e^{-H\int_0^t a(s)ds}\mu_0.
\tag{C18}
\]

The normal mean energy decreases. The covariance remains diagonal in one fixed eigenbasis of `H`: a positive-eigenvalue variance satisfies `c_j'=-2(a lambda_j+kappa)c_j+2T`. At the proposed upper barrier `T/(lambda_j+kappa)` its derivative is nonpositive when `a>=1`; scalar comparison proves `tr(H Sigma)<=Tp`. The kernel process contributes no `H` energy.

By (C3), the positive eigenvalues of `A_0^-1 H` are at most `2/a`. This follows by conjugating on the normal space with `H^{1/2}`, not by treating nonsymmetric products as Loewner-ordered matrices. It yields

\[
-\frac1{40}\le g-(a-2)\le\frac3{80},\qquad
1\le TM(a)\le1+2Tp\le\frac{21}{20}.
\tag{C19}
\]

At `a=1`, `g<0`; at `a=21/10`, `g>0`. The derivative therefore points inward at both endpoints. A first-exit argument validates the provisional interval. The resulting finite moment ODE has smooth coefficients on this invariant interval; the displayed bounds prevent a finite-time blowup. Positive covariance persists through the explicit OU covariance integral.

Weaken `|g-(a-2)|` to `1/10` and `TM` to `11/10`. Until `a` reaches `19/10`,

\[
a'\ge\frac{10\epsilon}{11}(19/10-a).
\]

The vector field at `19/10` points upward, so comparison continues to give

\[
a(t)\ge\frac{19}{10}-\frac9{10}e^{-10\epsilon t/11}.
\tag{C20}
\]

At `t=2/epsilon`, the elementary inequality `e^{20/11}>1+20/11=31/11` already gives `a(t)>49/31>3/2`. Thus the model changes by more than one-half on a horizon that grows, rather than shrinks, as separation improves. This is a consequence of the normalized score equation, not a supplied schedule. Calibration by the normalized record `Y=2` is an explicit modeling input; unforced identification of a true parameter is not claimed.

Let `U` have orthonormal rows in the normal space and put `F=UHU^T` SPD. The optimizer hidden precision is `D_a=aF+kappa I`. If `kappa<=lambda_min(F)`, then for `a>=3/2`

\[
D_a\succeq\frac54D_1.
\]

For two nonsingular Gaussian conditionals at the same retained `y`, expanding their log-density ratio gives

\[
\operatorname{KL}(P_1(\cdot\mid y)\Vert P_a(\cdot\mid y))
=\frac12\sum_{j=1}^{r}(r_j-1-\log r_j)
 +\frac1{2T}(m_1-m_a)^TD_a(m_1-m_a),
\tag{C21}
\]

where `r_j` are the eigenvalues of `D_1^-1/2 D_a D_1^-1/2`. They are at least `5/4`; the scalar function `r-1-log r` is increasing for `r>=1`. Hence

\[
\operatorname{KL}(\pi_1(\cdot\mid y)\Vert\pi_a(\cdot\mid y))
\ge\frac{r}{2}\left(\frac14-\log\frac54\right)>0.
\tag{C22}
\]

This is uniform in `y`, `T`, and `epsilon` at fixed nonzero hidden dimension.

The physical posterior conditional satisfies the same bound. Indeed,

\[
D_1^{\rm phys}=F+\kappa I-TURU^T\preceq2F,
\]

\[
D_a^{\rm phys}=D_1^{\rm phys}+(a-1)F
\succeq D_1^{\rm phys}+F/2
\succeq\frac54D_1^{\rm phys}.
\tag{C23}
\]

Both physical precision matrices are SPD by (C3). Applying (C21) to their congruent ratio proves (C22) for the physical posterior conditionals too. This does not require `F` to commute with `URU^T`. It directly checks that the learned parameter changes a genuine physical hidden conditional, in addition to changing the optimizer conditional.

These are target-change bounds. They do not bound the actual conditional tracking error of `Q_t`. That separate obligation cannot be inferred from large parameter change or from (C16).

The compatible heterogeneous observation gives

\[
P_K\mu(t)=\frac\kappa{1+\kappa}
\left(1-e^{-(1+\kappa)t}\right)z.
\tag{C24}
\]

This follows by projecting the mean equation and using `P_K mu_0=0`. The record and prior remain fixed, so this is an active response. It is inherited by every retention below because `K` is contained in each retained subspace. The zero normal observation force is an admission. A general incompatible observation introduces a normal forcing term and requires an amended formation and tracking estimate.

## 5. Bundle actions and differential loop compatibility

For a right principal bundle and a left law action, `(u g,b)` and `(u,g_#b)` represent the same associated-bundle point. Replacing a local frame `u_i` by `u_i a_i` changes coordinates by `A_i=a_i^-1`. Thus `b_i'=A_i#b_i` and `Theta_ij'=A_i Theta_ij A_j^-1` have the required types. Unequal belief/model representations need their own action maps and do not become identified through a principal-frame ratio. The scalar translation witness chooses the same sample action in both channels, which is an allowed specialization.

For the rooted tree product `g_i`, cancellation gives `g_i'=A_i g_i A_r^-1`. Consequently

\[
H_e'=A_rH_eA_r^{-1},\qquad
V_e'=A_{r_I}V_eA_{r_J}^{-1}.
\tag{C25}
\]

With `a_i=g_i^-1 dot g_i`, differentiating `g_i^-1 Theta_e g_j` gives

\[
\dot H_e=-a_iH_e+g_i^{-1}\dot\Theta_e g_j+H_ea_j.
\tag{C26}
\]

This formula includes independent link velocities. A changing passive root frame adds its usual commutator by direct product differentiation; it is not transport over the contextual base.

Differentiate `H(t)_#b(t)=b(t)`. The product rule for the group action gives

\[
(H_\#-I)\dot b+(\dot H H^{-1})_{\mathcal B}(b)=0.
\tag{C27}
\]

The plus sign in (C27) was absent in the original displayed geometry equation (6). The adjacent Gaussian formulas correctly contained the sum, so this was a defective display rather than a counterexample to the intended compatibility law. It has been corrected. For linear Gaussian actions, (C27) becomes

\[
\zeta\mu+(H-I)\dot\mu=0,\qquad
\zeta\Sigma+\Sigma\zeta^T+H\dot\Sigma H^T-\dot\Sigma=0,
\quad\zeta=\dot H H^{-1}.
\tag{C28}
\]

Taking `H=diag(1,-1)`, `mu=(1,0)`, `Sigma=I`, `dot H=0`, and `dot mu=(0,1)` violates (C28) by `(0,-2)`. It starts on the stabilized sector and leaves it. Thus energy descent alone cannot be substituted for the normal tangency check.

For a regular moving zero set `R(W,theta)=0` with local embedding `iota_theta(y)`, differentiating its defining identity proves `D_W R J=0` and `D_W R partial_theta iota+partial_theta R=0`. Orthogonally decomposing `V-partial_theta iota dot theta` in metric `G_W` gives exactly the normal defect and retained velocity in geometry (9). For a gradient field, multiplying by `J^T G_W` gives its equation (10), including the moving-chart term. This checks the formula conditional on regularity and positive metric; it does not check a specific trajectory stays in the patch.

Given the admitted normal-coordinate equation (11), taking the upper right derivative of `||xi||` gives

\[
D^+\|\xi\|\le-\kappa\lambda\|\xi\|
 +\kappa C\|\xi\|^2+B_1\|\xi\|+B_0
\le-\frac{\kappa\lambda}{2}\|\xi\|+B_0.
\]

Multiplication by the scalar integrating factor proves the displayed tube bound. A compact regular tube, bounded coordinate derivatives, and continued tangential admission remain necessary. The theorem does not cover an unproved singular limit or a parameter horizon longer than the established patch persistence.

## 6. Nonidentity stabilizers and attention checks

For `b_phi,a=(1+a cos(2(x-phi)))/(2pi)`, the range `0<a_-<=a<=a_+<1` supplies strict positivity and a stabilizer exactly `{0,pi}`. Set `r=(1-sqrt(1-a^2))/a`; then `a=2r/(1+r^2)` and `r<1` uniformly. The convergent series for `log(1+r e^{it})` and its conjugate gives

\[
\log(1+a\cos t)=-\log(1+r^2)
 +2\sum_{k\ge1}\frac{(-1)^{k+1}r^k}{k}\cos kt.
\]

Only the first cosine survives integration against the law. Its self-minus-shifted expectation is `a r(1-cos(2delta))`, proving the proposed exact KL. Since `a r=1-sqrt(1-a^2)=c(a)`, its phase Fisher coefficient is `4c(a)`, and the normal Hessian is `4c(a) B^T diag(w) B`. Every edge has an independent link column, so `B` has full row rank. A triangle with two zero tree angles and one cotree angle `pi` has zero KL on every edge and nonidentity loop holonomy. The Taylor bound follows from `|1-cos t-t^2/2|<=|t|^4/24` with `t=2delta`. This reconstructs the compact regular geometry exactly; no dynamical learning law for this separate example was assumed.

For an interior attention row, differentiation on `sum beta_j=1` gives the full differential (15). Substituting `beta_j*=pi_j exp(-D_j/tau)/Z` makes the coefficient of every `d beta_j` equal, so that term vanishes while the prior and temperature derivatives remain. Differentiating the reduced scalar at fixed prior and temperature gives the negative covariance Hessian term in (17). At coherence every edge gradient is zero, so only the prior-weighted Hessian sum remains. The positive row floor follows from `D_j>=0`, `Z<=1`, and the stated bounded-energy and temperature assumptions.

The primary witness uses positive energy strengths `a J_e`; it does not learn row-normalized probabilities. Factoring them into a receiver strength and a normalized row preserves the strength and yields a row independent of `a`. Exactly zero model-channel energy is allowed even though no normalized probability row can have all entries zero.

Small coupling energy is not a force bound: `epsilon[2+sin(x/epsilon^2)]` lies in `[epsilon,3epsilon]` but its derivative at zero is `1/epsilon`. It is a positive multiple of the Gaussian KL to a mean `sqrt(2[2+sin(x/epsilon^2)])`, so it is an admissible smooth nonnegative-KL example. The geometry file's explicit gradient assumptions avoid this false inference.

For a common normalized channel, integration gives unchanged evidence and factorization of the density ratio gives geometry (22). Differentiating the retained observed density under domination gives its conditional expected score, proving (24) and (25). The bounded-score force estimate uses a separate boundedness hypothesis. One way to check its constant is to take an event attaining total variation, use the log-sum inequality to reduce KL to a Bernoulli KL, and note that its second derivative in its first probability is `1/[p(1-p)]>=4`. Taylor's formula about equality gives `KL>=2 TV^2`; bounded score integration contributes `2 M_s TV`, followed by Cauchy–Schwarz. The Gaussian score (C12) is unbounded, so this estimate is not its automatic force certificate.

## 7. Exact flag, Gaussian integration, and cut kernels

For `N=2^(L-1)` triangles there are `n=3N` vertices, `E=4N-1` edge copies, and ambient dimension `10N-1`. Let `Z` denote the matrix whose rows extract the normalized loop sums `h_b/sqrt(3)`; this renames the geometry file's matrix `H` to avoid collision with the stiffness. Its disjoint normalized link supports give `ZZ^T=I_N`.

The triangle contrasts have link coefficient sums zero and incidence annihilates triangle circulation. Therefore `Z B_s^T=0`. In a row dependence of `B_s`, the bridge link columns set every bridge coefficient to zero; each triangle's link columns set its two contrast coefficients to zero; the `v` columns set every remaining bridge-to-model coefficient to zero. Thus

\[
\operatorname{rank}B_s=3N+2N+N-N/2^{s-1}
=6N-N/2^{s-1}.
\tag{C29}
\]

The kernel spaces decrease with `s`, contain all loop rows as retained coordinate directions, and contain `K={(u,u,Du)}`. Choosing orthonormal bases yields

\[
C_{s+1}=A_sC_s,\qquad A_s=C_{s+1}C_s^T,\qquad A_sA_s^T=I.
\tag{C30}
\]

The final retained dimension is `(10N-1)-(6N-1)=4N`, exactly the `3N` kernel coordinates plus `N` loop coordinates. This count does not erase tangent frame variables. Zero triangle contrasts leave `r_e=-h_b/3`, so the retained holonomy contributes `a J_1 h_b^2/6` to the energy. It must be included in a formation estimate; projection to exact loop identity is not this retention.

With hidden orthonormal rows `U_s`, the matrix with rows `(C_s,U_s)` is orthogonal. Write a Gaussian precision in these coordinates as

\[
\begin{pmatrix}A&B\\B^T&D\end{pmatrix},\qquad
f=\begin{pmatrix}f_y\\f_z\end{pmatrix}.
\]

Completing the square produces

\[
\begin{split}
&z^TDz+2y^TBz-2f_z^Tz+y^TAy-2f_y^Ty\\
&\quad=(z-D^{-1}(f_z-B^Ty))^TD(z-D^{-1}(f_z-B^Ty))\\
&\qquad+y^T(A-BD^{-1}B^T)y
 -2(f_y-BD^{-1}f_z)^Ty-f_z^TD^{-1}f_z.
\end{split}
\tag{C31}
\]

This proves the precision, source, conditional covariance, and complete integration factor in geometry (44)–(45). Every inverse exists because a principal compression of an SPD matrix is SPD; its Schur complement is SPD by minimizing the positive quadratic form over hidden coordinates. Gaussian marginal covariance is `T C_s K_a^-1 C_s^T`, so (C30) proves direct and staged equality. The same channels push arbitrary actual recognition Gaussians. Exactness is not contingent on their already equaling the optimizer.

For any required tuple of raw translation marks `m=L_s x`, write `x=C_s^T y+U_s^T z` in (C31). This gives precisely the full conditional mean and covariance in geometry (51). It can be degenerate. A loop row annihilates `U_s^T`, so its conditional variance is zero and its actual loop value is retained. A cut row generally does not; its conditional variance and its correlations with other marks must remain. Separate redraws of different edge copies would replace this joint kernel by a product and would be a different model.

For the physical parent evaluator the reverse kernel is taken before observations under `P_0`. For an actual recognition mark history use the actual recognition conditional or a proved approximation with retained error/memory. Formula (51) with `K_a` gives the optimizer kernel for the specific normalized adaptive witness. The corrected source now says this explicitly and routes physical posterior calculations through `K_a-TR` and physical prior reverse calculations through `A_0`.

## 8. Inherited mobility and the remaining dynamical defect

Project a microscopic constant-mobility diffusion with drift `-M(K_a x-f)` and noise covariance `2TM`. Its quadratic variation on `y=C_s x` is exactly `2T C_s M C_s^T`; this proves the inherited instantaneous mobility. Gaussian conditioning gives

\[
E_{\pi_a}[x\mid y]=\mu+K_a^{-1}C_s^TS_s(y-C_s\mu),
\qquad\mu=K_a^{-1}f.
\tag{C32}
\]

Multiplication by `C_s M K_a` yields the averaged drift `-M_s(S_s y-j_s)`, with `M_s=C_s M C_s^T`. Substituting the actual conditional mean adds exactly

\[
-C_s M K_a\left(E_{Q_t}[x\mid y]-E_{\pi_a}[x\mid y]\right).
\tag{C33}
\]

This is a marginal conditional drift identity. It does not make the projected process Markov: conditioning on its entire history can preserve additional information about the hidden state. A path-law replacement requires the companion error estimate or auxiliary memory. For `M=I`, every `M_s=I`; no new parent multiplier appears. Pulling a metric back to a holonomic embedding is a different operation and need not invert this projected diffusion mobility.

On the retained loop subspace, the stiffness decomposition gives exact scalar equations

\[
dz_b=-(a(t)J_1+\kappa)z_bdt+\sqrt{2T}dB_b.
\tag{C34}
\]

The mean is zero for the stated preparation and source. Its variance solves `v'=-2(aJ_1+kappa)v+2T`. The constant `T/(J_1+kappa)` is an upper barrier when `a>=1`; this proves the stated bound and retains the nonequilibrium variance rather than replacing it with the changing equilibrium value. The deterministic `a(t)` here is generated by the coupled recognition/parameter equations, not externally assigned.

There is one locality qualification. The unit microscopic metric is block local, but the proper reference need not give incident-edge-only drift. If `G` is the matrix with blocks `(I,I,D)`, then

\[
P_K=G(2I+D^TD)^{-1}G^T.
\tag{C35}
\]

The inverse is generally dense. Thus this witness has a common local metric and a declared correlated reference, not a demonstrated strictly graph-local force implementation. The frozen contract allows declared proper references; a stronger incident-neighbor information restriction would be an additional obligation.

## 9. Concrete attack portfolio

The table records exact attacks and their scope. Failed shortcuts are not counterexamples to the admitted model when it explicitly excludes them.

| Attack | Explicit calculation or falsifier | Outcome for the checked construction |
| --- | --- | --- |
| Omit the prior partition derivative | Removing `-T tr(A_0^-1 H)/2` changes (C15). It is nonzero because `p>0` and `A_0` is SPD. | The term is present. |
| Optimize only independent evaluator couplings | At one node the product coupling adds `c/(1-c)+(1/2)log(1-c)>0`; its derivative with respect to `c` is positive and its value at zero is zero. | The optimizing correlated coupling is used. |
| Interpret zero model alignment as no model learning | At `a=1`, (C19) gives `g<=-77/80<0`, hence `a'>0`; (C20) gives a change greater than one-half. | Actual complete-model learning remains. |
| Infer a force bound from small coupling energy | The Gaussian-KL example `epsilon[2+sin(x/epsilon^2)]` has derivative `1/epsilon` at zero. | Explicit force assumptions or exactly absent coupling are used. |
| Infer loop identity from equal transported laws | The circle half-turn triangle in Section 6 has zero edge KL and loop `pi`. | General stabilizers are allowed; the translation witness's trivial stabilizer is a stated specialization. |
| Discard moving-holonomy tangency | The Gaussian reflection example violates (C28) by `(0,-2)`. | The missing display plus was repaired; the full sum is retained. |
| Replace marginalization by restriction | For precision `[[2,1],[1,2]]`, restricting to the first coordinate gives `2`, while integrating the second gives `3/2`. | The source uses the Schur complement and its determinant factor. |
| Use a posterior reverse kernel as a new physical likelihood | Let `X~N(0,1)` and `O|X~N(X,1)`, with coarse state constant. The correct evidence is `N(0,2)`. Using `X|O=o~N(o/2,1/2)` in the likelihood gives `(3pi)^(-1/2)exp(-o^2/12)`, whose integral over `o` equals `2`. | Physical and optimizer kernels are now explicitly distinguished. |
| Replace a raw cut mark by its conditional mean | If `L_s U_s^T` is nonzero, the conditional covariance `T L_s U_s^T D_s^-1 U_s L_s^T` is nonzero on its image. A point mass cannot equal that kernel. | The full possibly correlated kernel is required. |
| Replace actual loop variance by instantaneous equilibrium variance | If `v=T/(aJ_1+kappa)` at a time with `a'>0`, the actual variance derivative is zero there, while the derivative of that proposed equilibrium curve is negative. | The scalar variance ODE and barrier are used. |
| Infer path closure from projected quadratic variation | Formula (C33) persists for nonmatched conditional means even though the projected noise is exactly known. | Memory or quantitative replacement remains required. |
| Infer positive-temperature finite KL from a deterministic law-point trajectory | A Dirac outer recognition is singular relative to every full-support Gaussian here. | The witness uses positive Gaussian covariance from the outset. |
| Infer all finite-depth formation hypotheses from a full-rank flag | Rank proves existing inverses and normalized integration, but gives no formation margin or comparison of slow and fast relaxation times. | The joint dynamics proof remains the companion assignment. |

No valid counterexample was found to the normalized-model identities, the stated long-horizon learning bound, the exact loop flag, or the Gaussian projected-mobility identities under their displayed assumptions. This conclusion rests on the reconstructions above, not on absence of numerical failures or reviewer agreement.

## 10. Repairs, executed work, and scope of the result

The authorized source repairs were limited to the missing plus in geometry (6), explicit optimizer-versus-physical terminology around its Gaussian formulas, the full normalizers and unchanged parent offset in model (M10a)–(M10b), and the strengthened physical conditional comparison (M24a). A subsequent authorized wording correction describes (M11) as a configuration diffusion with common unit coordinate mobility, so it does not imply incident-edge-only drift. Prohibited LaTeX spacing macros were removed from the assigned geometry source and this report without changing equations. The source passages were read back after editing. The coordinating agent owns the shared daily change log and ledger.

The initially inspected model and geometry SHA-256 values were respectively `5AE6822ACC99359B632A1BDF31C4A86AC4D68ECED1EC5927F267CD371DA2BF0C` and `1737B723D99FF3CBD45A909C214FF15A01C8ABB8EC9FBD3BB54AAA03C6F47B44`. After the mathematical repairs and final wording/spacing cleanup they were `4BA59EB60C1AD1DB6B414B9712FDD4B1F95DA3A6E4EF42F745B311C7D6101D31` and `0D28B64C49C1200799024670A028EFBB51EEB716989E6BE7876717139E887080`. These identify source versions for this written reconstruction; they are diagnostic metadata, not mathematical acceptance criteria. Later source edits need a scoped reread of the changed formulas.

Executed work consisted of read-only source and primary-reference inspection, analytical differentiation and Gaussian integration recorded in this report, the authorized Markdown repairs, and read-back/source-version inspection. No numerical trajectory, symbolic algebra program, matrix experiment, unit suite, heavy science, GPU operation, Lean process, tamper check, Research-vault write, or Git publication was executed. The coordinating agent's matrix check was not rerun. This report is a separate written reconstruction in a shared filesystem, not an independent empirical replication.

The strongest supported component result is a well-defined normalized Gaussian law/link model with exact evaluator-constrained VFE, complete Fisher-preconditioned parameter learning, a parameter change exceeding one-half on `[0,2/epsilon]`, and an eliminated physical and optimizing conditional KL change bounded below independently of `epsilon` and `T`. Its fixed finite flag preserves every cycle coordinate, has exact normalized ordered Gaussian parents with all additive constants, and inherits the actual projected mobility with the explicit conditional drift defect.

The part of the original target outside this component reconstruction is proof that the formation episodes, actual conditional lag/force bounds, and every successive activation all occupy one nonempty parameter regime on that same interval, with raw cut kernels or required auxiliary marks carried through the actual retained-law construction. The additional joined-interface check below tests the model and geometry seams of that proposed proof. Repeating model normalization or a finite matrix check would not settle the other components.

## 11. Additional check of the joined theorem

At the coordinating agent's request, [adaptive-cyclic-completion.md](adaptive-cyclic-completion.md) was subsequently read in full against the frozen target. The source seams checked additionally were conditional Section 6.1, equations (42a)–(42i), and the witness's physical conditional statistic calculation (W26a)–(W26b). The formation and conditional investigators retain ownership of their complete estimates; the following checks do not duplicate or certify those assignments.

For `L=2`, there are two triangles, six nodes, seven links, and nineteen coordinates. At the first step `B_1` has ten independent rows; at the second it has eleven. The maps therefore have dimensions `19 -> 9 -> 8`. Their common retained loop row space has dimension two, and the final six-dimensional kernel plus two loops gives the eight coordinates. Formula (C30) proves exact direct/staged covariance equality; completing the square in either order proves equality of all raw integration factors. Both statements hold separately for the optimizer precision `K_a`, physical posterior precision `K_a-TR`, and prior precision `A_0`, using the proper source in each case. There is no common physical/optimizer conditional.

The own-parent learning claim has an exact variational calculation. Fix the retained law `r` and let `k_a` be the optimizer conditional. Differentiate `F_T(r k_a,a)` directly. The derivative through the conditional density pairs with

\[
T\log\frac{r(y)k_a(z\mid y)}{\pi_a(y,z)}+T
=T\log\frac{r(y)}{\pi_a^s(y)}+T.
\tag{C36}
\]

This is independent of `z`, and `integral partial_a k_a(z|y) dz=0`. The entire conditional-density derivative vanishes. What remains is (C15) evaluated in the parent's own optimizing lift, with the same prior normalizer and metric `h=TM`. This proof requires smooth normalized conditionals and finite moments, which the positive Gaussian matrices supply. It would fail if one dropped `C_T(a)` or silently changed to the Fisher metric of the marginal physical model.

The parent's learning admission also reconstructs without instantaneous equilibration. On the unforced learned normal sector, completing the square under its optimizing lift gives

\[
E_{Q^{\rm lift}}X^TK_aX
=m_y^TS_am_y+\operatorname{tr}(S_a\Sigma_y)+T p_{\rm hid}.
\tag{C37}
\]

The retained loop modes are included in the trace, and every hidden normal mode is counted in `p_hid`. If the covariance barrier is at most `r_*<=1/4`, the trace and hidden terms total at most `(1+r_*)Tp`. The mean energy obeys

\[
\frac d{dt}(m_y^TS_am_y)
=m_y^T\dot S_am_y-2m_y^TS_a^2m_y
\le(11\epsilon/10)m_y^TS_am_y.
\tag{C38}
\]

At each exact projection, the Schur mean energy is the minimum over discarded coordinates and cannot increase. Over total time `2/epsilon`, (C37)–(C38), `H<=K_a/a`, and the same normalizer bound used in (C19) yield

\[
a'=\epsilon(2-a)+\epsilon R_t,\qquad
|R_t|\le\delta_L
=\frac12e^{22/10}E_0+\frac{29}{8}Tp.
\tag{C39}
\]

If `delta_L<1/20`, the parameter endpoint and speed assumptions close by the same first-exit argument. In the joined scaling, `E_0<=C_L A^2J_1=C_L epsilon^4` and `Tp=C_L epsilon^(nu_1+10)`, so this condition is nonempty for each fixed finite depth. Integrating (C39) proves closeness to `2-exp(-epsilon t)` as a comparison solution; subtracting two such equations starting at the same activation parameter bounds their difference by `2 delta_L`. This reconstructs genuine own-law parent feedback. It does not prescribe a shared external coefficient trajectory.

The physical mark-statistic seam is also consistent. Every row of the bridge matrix `b_d` belongs to the first eliminated row space, so `R` annihilates every later retained normal subspace. Consequently replacing optimizer precision by physical posterior precision subtracts `TR` only in the hidden block, not in its cross block to later retained normal directions. Omitting the diagonal `kappa I` for the prior likewise does not change that cross block. Prior positivity (C3) preserves the hidden restoring lower bound. Thus the witness's conditional second-moment comparison may be applied with the separate physical prior and posterior kernels as written; it does not justify substituting the optimizer kernel into a physical evaluator.

The join accurately states that most appreciable adaptation occurs after the short formation episodes and claims the conditional control persists to `2/epsilon`. The frozen contract asks for appreciable hidden-conditional change over the admitted interval, not at every individual merger. The join's stated Gaussian, compatible-forcing, finite-depth, supplied-contrast and dense-reference scope therefore matches the model/geometry premises checked here. It also states that the translation loops are retained fluctuating frustrated modes and does not transfer the separate circle stabilizer example into the translation dynamics.

One wording issue was sent to the coordinating agent: model (M10a)–(M10b) give the physical evidence and the restricted-objective offset, not two physical evidences. A tilted optimizer normalization is not a second evidence for experiment (M7). Subject to that terminology correction, the joined normalizer, parent-feedback, two-level and loop-scope interfaces reconstruct. The remaining dependency for full-goal acceptance is the separately reconstructed formation and conditional-error estimates and their simultaneous all-level hypothesis map; this report assigns no closure by agreement.
