# Adaptive cyclic dynamical RG at one base point

September 12, 2026. This joins the [normalized microscopic model](adaptive-normalized-model.md), [moving-conditional theorem](adaptive-conditional-bounds.md), [marked loop geometry](adaptive-loop-parent-geometry.md), and [finite-depth formation proof](adaptive-cyclic-witness.md). The target is fixed by [the adaptive contract](evidence/2026-09-12-adaptive-cyclic-rg-goal/problem-contract.json), digest `e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90`. The result below is analytical. Its quantitative claims refer to the displayed construction, with its assumptions, rather than to all gauge-VFE systems.

## 1. What the construction establishes

For every prescribed finite integer L at least two, there is a positive-temperature cyclic Gaussian law/link model at one base point with L successive coalescence levels, exact normalized marked parents, and an actually learned generative parameter. Each parent starts from the preceding actual retained law and learns from its own current law. Over the common horizon `2/epsilon`, the learned parameter changes by more than one half and changes the eliminated conditional by a relative entropy bounded below independently of epsilon. Conditional-VFE loss and replacement of the retained dynamics have quantitative bounds on this same regime.

The theorem assumes supplied interaction contrasts, compatible heterogeneous observations, Gaussian laws and preparation, a scalar learned precision, a proper correlated prior, and one common microscopic configuration mobility. It proves formation under those inputs. It does not prove that learning creates the contrast, that normalized attention rows change, or that every merger contains an order-one model change. Most of the order-one adaptation occurs after the short formation episodes, while the formed hierarchy continues to satisfy the admitted approximation through the horizon.

The complete prior makes this a proper noncompact translation specialization. Its confinement projector is generally dense: with `G=[I;I;D]`, `P_K=G(2I+D^TD)^{-1}G^T`. The peer metric is block-local and equal for every microscopic coordinate. Strictly incident-edge-only evaluation of every prior force is not claimed. The original principal-bundle and associated-law types remain the ambient construction; all variables below lie over the fixed point c_*.

## 2. A reusable conditional theorem

Let a normalized observed model, with its declared restricted inner recognition kernel, have exact scaled VFE

\[
 F_T(Q,a)=T\operatorname{KL}(Q\Vert\pi_a)+C_T(a),
 \qquad \pi_a=N(K_a^{-1}f_a,TK_a^{-1}),\qquad K_a\succ0.
 \tag{A1}
\]

The scalar `C_T` includes all normalizers and restricted-family costs. Declare common unit configuration mobility and model metric `h(a)/epsilon`, so the complete coupled equations are

\[
 dX=(-K_aX+f_a)dt+\sqrt{2T}dW,
 \qquad \dot a=-\epsilon h(a)^{-1}\partial_aF_T(Q,a).
 \tag{A2}
\]

Assume Gaussian initial recognition with positive covariance, smooth finite coefficients, and a parameter interval on which `K>=mI`, `-rho K<=Kdot<=rho K`, and `2m>rho`. If the initial covariance is between `(1-r_0)TK_0^{-1}` and `(1+r_0)TK_0^{-1}`, define

\[
 r(t)=r_0e^{-(2m-\rho)t}
       +\frac{\rho}{2m-\rho}(1-e^{-(2m-\rho)t}).
 \tag{A3}
\]

Then `(1-r)TK^{-1}<=Sigma<=(1+r)TK^{-1}` while `r<1`. This holds without commutation. The proof differentiates the two matrix barriers and represents the difference from the Lyapunov solution as a positive congruence integral; it is given in conditional equations (10)–(16).

For a fixed orthogonal retention, write the precision in retained/hidden coordinates as `[[A,B],[B^T,D]]`. Its exact optimizer hidden conditional is `N(D^{-1}(f_z-B^Ty),TD^{-1})`. Put `e=m_z-D^{-1}(f_z-B^Tm_y)`. The conditional KL and force defect satisfy

\[
 \Delta=E_{Q_y}\operatorname{KL}(Q(dz\mid y)\Vert\pi_a(dz\mid y))
 \le\frac{d r^2}{4(1-r)^2}+\frac{e^TDe}{2T},
 \tag{A4}
\]

\[
 \|B(E_Q[z\mid y]-E_{\pi_a}[z\mid y])\|_{L^2(Q_y)}
 \le\sqrt{2T\|BD^{-1}B^T\|\Delta}.
 \tag{A5}
\]

Equation (A4) follows by the Gaussian KL formula and subtraction of the retained covariance KL; (A5) follows by a Gaussian exponential tilt, pointwise in y, and integration. Thus the entropy estimate is independent evidence from the path estimate. The exact restricted-parent scalar is `T KL(Q_y||pi_a^y)+C_T(a)`, and its loss from the fine scalar is exactly `T Delta`. Physical prior, physical posterior, optimizer, and actual recognition have their own conditional kernels.

The parent precision is the Schur complement `S=A-BD^{-1}B^T`, its source is `j=f_y-BD^{-1}f_z`, and its mobility is the inherited identity in orthonormal coordinates. At fixed retained recognition, differentiating the optimizing lift gives the parent covector by evaluating the original complete model covector in that lift. The derivative through the optimizing conditional integrates to zero because the remaining variational derivative is retained-only. The metric h is inherited; no new marginal Fisher metric or parent rate is inserted.

Marginalization preserves the covariance barriers, and differentiating the Schur minimization preserves the relative-speed bound. The theorem therefore applies to a finite sequence activated from actual laws without covariance resets. General own-law feedback estimates are conditional equations (35)–(42); they expose their contrast-dependent constants. The calibration family below instead has the stiffness-independent bounds (42a)–(42m). Exact retained paths follow the inherited Volterra memory and correlated noise of equations (43)–(44); quantitative Markov replacement pays the hidden thermal forcing separately. These are reusable implications for every admitted finite quadratic model and orthogonal flag. The following witness proves their nonempty simultaneous hypotheses and formation conditions.

## 3. A normalized cyclic witness and genuine learning

Set `b=2^(L-1)`. Use b triangles connected in a chain by b-1 bridge edges. There are `n=3b` vertices, `E=4b-1` independent links and `d=10b-1` configuration coordinates `x=(u,v,alpha)`. Belief laws are `N(u_i,1)`, model presentations are `N(v_i,c)`, and the evaluator variance is `1-c`, where `0<c<1`. Define `d_i=u_i-v_i` and `r_e=u_i-u_j-alpha_e`. Every triangle edge and every local bridge d_i has stiffness J_1. Intertriangle bridge j has level `2+v_2(j)` and stiffness at that level.

Let H be the sum of these weighted residual squares as a matrix. Its kernel is `K={(t,t,Dt)}`. The normalized prior has precision `A_0=aH+P_K-TR`, where `R=b_d^Tb_d/(1-c)`. For `a>=1` and `T<=J_1(1-c)/2`, this precision is SPD. The normalized observations are `O|x~N(x,T/kappa I)` and `Y|a~N(a,T)`, with selected records `O=z in K`, `Y=2`. Take fixed `z!=0` with unequal node entries and fixed `0<kappa<=1`. The microscopic model also includes the normalized model/evaluator kernels; the exact optimizing fixed-marginal coupling has cost `x^TRx/2`.

After including that evaluator cost, the exact restricted optimizer has `K_a=aH+P_K+kappa I` and `f=kappa z`. The physical outer posterior instead has precision `K_a-TR`. Equations M10a–M10b give the physical evidence, restricted optimizer normalizer, and unchanged restricted scalar explicitly. This distinction remains at every parent.

The complete model covector and full-model Fisher metric are

\[
 g=a-2+\frac12E_Qx^THx
       -\frac T2\operatorname{tr}(A_0^{-1}H),\qquad
 M(a)=\frac1T+\frac12\operatorname{tr}[(A_0^{-1}H)^2].
 \tag{A6}
\]

Use h=TM in (A2). Gaussian moment equations and integration by parts give

\[
 \dot F_T=-T^2E_Q|\nabla\log(q/\pi_a)|^2
             -\epsilon[TM(a)]^{-1}g^2\le0.
 \tag{A7}
\]

The calibration observation helps drive the appreciable change; its force and Fisher contribution are part of the same normalized VFE. The update is expectation-driven from the actual law, not an externally imposed schedule. The invariant-region calculation proves `1<=a<=2.1`, `|a'|<=1.1 epsilon`, and `a(2/epsilon)>1.5` for the preparation below. The identical estimates hold for every actual self-learning parent by the optimizing-lift energy identity, conditional equations (42f)–(42i).

For the first hidden block let `F=UHU^T`. Choosing `kappa<=lambda_min(F)` gives `D_a=aF+kappa I>=5D_1/4` when `a>=1.5`. Therefore, at every fixed retained y,

\[
 \operatorname{KL}(\pi_1(\cdot\mid y)\Vert\pi_a(\cdot\mid y))
 \ge\frac{\dim U}{2}\left(\frac14-\log\frac54\right)>0.
 \tag{A8}
\]

The same lower bound holds for the distinct physical posterior conditionals: `D_1^phys=F+kappa I-TR_U<=2F` and `D_a^phys=D_1^phys+(a-1)F>=5D_1^phys/4`. Congruencing gives the Gaussian precision-ratio bound without a commutation assumption. Thus the changed conditional is not merely a retained-only normalization or a passive frame motion.

The observable collective response is exactly `P_K mu(t)=kappa z(1-exp(-(1+kappa)t))/(1+kappa)`. References and observations stay fixed during that physical response. All parents retain K and its noise, so this component is shared exactly. Unrestricted incompatible normal forcing is outside this witness.

## 4. Loops and exact parent composition

On triangle q retain `z_q=h_q/sqrt(3)`, where `h_q=sum alpha_e`. The orthonormal two-row contrast `Q_triangle` in W3 satisfies `sum r_e^2=|Q_triangle r|^2+z_q^2`. Let B_s stack all d rows and internal contrasts and the bridge rows through level s. Its rows are independent, its rank is `6b-b/2^(s-1)`, and every holonomy row is orthogonal to it. Thus `W_s=ker B_s` gives a nested retention that preserves K and every original triangle holonomy. The retained dimension is `4b-1+b/2^(s-1)`; the final parent retains 4b coordinates.

Choose orthonormal C_s with row space W_s and set `A_s=C_{s+1}C_s^T`. Then `C_{s+1}=A_sC_s` and `A_sA_s^T=I`. For L=2 there are six agents and two loops, the agent counts are `6 -> 2 -> 1`, and the exact coordinate reductions are `19 -> 9 -> 8`. Both loop coordinates survive both steps. The direct covariance is `T C_2K_a^{-1}C_2^T`; applying the first and second parent in order gives this same covariance, the same mean, and the same normalization. This explicitly realizes the two-level interface.

All normalized physical kernels are pushed through these common maps using their physical prior conditionals. The exact restricted objectives instead use the optimizer conditional and retain `C_T(a)`. At a common time their losses obey

\[
 F_T(Q,a)-F_T^{(2)}(Q_2,a)
 =T\Delta_{0:1}+T\Delta_{1:2}.
 \tag{A9}
\]

Losses at different activation times are not summed as though they described one law. Generated correlations, conditional cut marks and nonlinear functions of those marks remain in their complete joint kernels. A cut covector not in the retained row space is not replaced by its value on `C_s^Ty`. Geometry equation (51) specifies its full possibly degenerate joint Gaussian conditional. If an operation requires a raw mark as a coordinate, the map must be enlarged; if it accepts the kernel, that auxiliary conditional data is retained.

The loop dynamics are `dz_q=-(aJ_1+kappa)z_q dt+sqrt(2T)dB_q`. Their finite-temperature laws are nonzero and are retained. In this translation representation small law mismatch implies small frustrated holonomy. This is not an identity-holonomy requirement on the general theory. The separate circle example in geometry equations (29)–(33) exhibits exact coherence with a nonidentity stabilizer loop, and the earlier GL marked-parent work remains valid in its stated scope. No Wilson term or additional flattening penalty is used.

## 5. Simultaneous formation, entropy and dynamic error bounds

For every fixed L define exponents `nu_L=0`, `nu_s=2nu_(s+1)+16`, and choose

\[
 J_s=\epsilon^{-\nu_s},\qquad
 A=\epsilon^{\nu_1/2+2},\qquad
 T=\epsilon^{\nu_1+10},\qquad H_*=2/\epsilon.
 \tag{A10}
\]

Thus `A^2J_1=epsilon^4`, `A/sqrt(T)=epsilon^-3`, and `J_(s+1)^2/J_s=epsilon^16`. Choose a generic unit normal mean direction v by the finite nonzero-polynomial procedure W20, set `mu_0=Av`, and use covariance `TK_1^{-1}`. This supplies smooth positive correlated recognition and initially separated future residuals. Every inequality has an open mean neighborhood; exact covariance preparation is sufficient, with the stated relative-covariance neighborhood also admitted by the reusable theorem. The graph and initial direction are fixed before the evolution; no desired grouping is fed back to the dynamics.

The weighted lower-triangular row calculation W14–W19 gives stiffness-independent finite-L constants for every Schur parent: a block eliminated through s has restoring rate at least `c_LJ_s`, while its coupling to later directions is at most `C_LJ_(s+1)`. The same estimate applies after every previous elimination. This proves recursive regularity. Normal mean contraction and variation of constants give

\[
 |\mu(t)-P_s\mu_0|\le C_LA
 \left[e^{-c_LJ_s(t-\tau_{s-1})}
       +J_{s+1}/J_s+J_{s+1}t\right],
 \tag{A11}
\]

in the active normal space; the final two terms vanish for the final normal elimination. Select `t_s=k_L log(1/epsilon)/J_s`, `I_s=[t_s,2t_s]`, and `tau_s=2t_s`, with k_L sufficiently large. These observation/activation intervals are ordered and occur before H_*. Equation (A11) and the initial nonzero residual margins prove that current components are coherent on I_s while future bridges remain separated. The actual agent counts are

\[
 3\cdot2^{L-1}\longrightarrow2^{L-1}
 \longrightarrow2^{L-2}\longrightarrow\cdots\longrightarrow1.
 \tag{A12}
\]

For the centered normal-plus-holonomy diffusion, an exponential quadratic Lyapunov function gives the maximum bound W26. Taking a fixed relative formation tolerance proportional to A yields exceptional probability at most `C_L(1+2/epsilon)exp(-c_L epsilon^-6)`. The inherited expected original edge KL has the same formation episodes under the physical prior and physical posterior conditionals by W26a–W26b. It is not equated to KL between full parent mixtures. A compatible hierarchy can therefore be observed in the original process and in the sequential parent descriptions.

The conditional mean defect satisfies the exact restoring equation W30. Its energy inequality W31–W33, combined with (A4), gives

\[
 \Delta_{p:s}(t)\le C_L\epsilon^2+
 C_L\frac{A^2}{T}
 \left[J_1e^{-c_LJ_s(t-t_0)}
             +\frac{J_{s+1}^4}{J_s^3}\right].
 \tag{A13}
\]

At and after the admitted formation/activation windows this is at most `C_L epsilon^2`; the plateau is at most `C_L epsilon^26`. The discarded scaled VFE is therefore at most `C_L T epsilon^2` at each active interface. The covariance barrier provides the larger term and is valid over the entire adaptation horizon. The initial transient is paid explicitly, not declared equilibrated.

For each actual source-to-parent replacement with equal retained state and parameter at activation, optimizing-lift energy and the full normalizer score give

\[
 \sup|a-\bar a|\le C_L\epsilon^4,
 \qquad
 \sup|P_s\mu_{\rm source}-\mu_{\rm parent}|
       \le C_L A\epsilon^4.
 \tag{A14}
\]

The mean sensitivity uses `0<=partial_a S<=S/a` and an integrated dissipation inequality; it has no exponential in the largest stiffness. Each process uses its own actual law and current coefficient. Sharing root noise and controlling both centered normal-plus-holonomy paths in tubes of radius `A epsilon^2` gives

\[
 \Pr\left\{\sup_{[\tau,H_*]}
 |P_sX_{\rm source}-X_{\rm parent}|>C_LA\epsilon^2\right\}
 \le C_L(1+2/\epsilon)e^{-c_L/\epsilon^2}.
 \tag{A15}
\]

Finite sums and union bounds propagate these estimates through L actual activations. The exact alternative is the inherited path-memory representation; an autonomous parent is the controlled approximation. None of these conclusions infers a conditional KL from a small path distance.

## 6. Relation to the existing loop and attention work

The [source reconciliation](adaptive-source-reconciliation.md) records the September 8 normalized curvature models, September 9 finite holonomy inference, September 11 GL regular/singular marked parents, and the live manuscript passages. Those sources already formulate loops, their conditional role, and exact marked coarse-graining. The present connection adds finite-depth actual formation during normalized model learning that changes an eliminated conditional, with independently learning parents and direct conditional-VFE control in a simultaneous regime.

The coefficients in the witness are positive real energy strengths `aJ_e`. Writing them as `lambda_i beta_ij`, where `lambda_i=sum_j aJ_ij`, preserves their meaning and gives fixed normalized rows. It does not supply a softmax evolution. The geometry component separately derives entropy and envelope terms for optimized attention and shows why small `gamma tilde_KL` values alone do not control model forces. The witness takes gamma exactly zero, preserving model evaluation and actual model learning.

Nonlinear changing-conditional formation, learned contrast formation, freely varying simplex attention, incompatible forcing, all gauge groups, and infinite depth are extensions. A finite cyclic example does not make any of them impossible. Base transport remains outside the phase. No capability, storage requirement, universal clock, or permanent intermediate hierarchy is needed for the result above.

## 7. Evidence and disposition

The model/geometry, formation and conditional components have separate reconstruction records: [model and geometry](adaptive-model-geometry-check.md), [formation](adaptive-formation-check.md), and [conditional bounds](adaptive-conditional-check.md). The [joined reconstruction and counterexample record](adaptive-independent-reconstruction.md) checks the dependency interfaces and distinguishes repaired formula defects from open scope extensions. The final release status is recorded in [the frozen report](evidence/2026-09-12-adaptive-cyclic-rg-goal/final-report.md).

The tiny exact two-triangle calculation verifies matrix ranks, loop retention, Schur composition and one normalized score derivative. It supplements the written all-L derivations and does not replace them. Its initial JSON export failure is preserved as a failed software invocation. No trajectory experiment, full suite, GPU run, Lean work, tamper check, vault edit, or publication action is part of this result.
