# Independent reconstruction of the adaptive conditional estimates

September 12, 2026. This checks [adaptive-conditional-bounds.md](adaptive-conditional-bounds.md), which this checker did not author, against the [frozen contract](evidence/2026-09-12-adaptive-cyclic-rg-goal/problem-contract.json), digest `e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90`, and the actual normalized model in [adaptive-normalized-model.md](adaptive-normalized-model.md). The result is a reconstruction of the displayed mathematical implications, not a ledger closure or a numerical certificate. The other reconstruction lane checks the cyclic witness that this checker authored.

The inspected conditional source has SHA-256 `1f11eee998e62281d27dbde01ba690a870bf70b266fbe7121a6e5322c4288ca4`; the normalized-model source has SHA-256 `bf76b7c465c99b8f5c6cbe0aca798f7d821e23613184759944e68f6558c10fa0`. These read-only source identifiers are diagnostic metadata. The proof below, not equality of fingerprints, is the mathematical evidence. Later edits require checking their effect on this reconstruction.

## 1. Exact scope and result

For every finite dimension and fixed finite orthogonal retention flag, the conditional source considers a positive-temperature Gaussian configuration diffusion coupled to a deterministic, expectation-driven generative-parameter update. The conditional result assumes a smooth positive precision K(a), an admitted positive parameter metric, positive initial covariance, the stated parameter region, and quantitative lower-rate and relative-speed bounds. It then derives covariance, conditional-KL, force, model-score, Schur, memory, and actual-law restart estimates. The cyclic family separately supplies the graph, exact physical marked kernels, formation means, and a nonempty parameter regime. Those are not consequences of a covariance inequality alone.

The supplied task constraints are fixed c_*, independent links, the complete normalized VFE, genuine model learning, actual retained initialization, and finite-horizon quantitative replacement. This check adds no stronger stochastic model and no equilibrium assumption. It reconstructs the source's declared deterministic exact-law model parameter; it does not interpret that parameter as a noisy one-particle gradient estimate. There is no discretization or finite-step descent claim.

No substantive algebraic defect was found in the checked implications. In particular, the noncommuting covariance barrier is valid; the conditional entropy includes regression error; the inherited parent score preserves the original normalizer and evidence offset; and the own-law parent calibration argument closes its speed and interval assumptions without resetting a covariance. The generic sensitivity constants are not uniform in diverging interaction contrast, as the source itself states. Its separate relative-form sensitivity argument is necessary for the cyclic scaling. Small conditional KL alone does not establish a small retained path error; the thermal contribution in its path bound is retained.

## 2. Noncommuting covariance comparison

Let C(t)=T K(t)^(-1), where K(t)>=m_* I and -rho K<=Kdot<=rho K. Congruence with K^(-1) gives -rho C<=Cdot<=rho C. Set beta=2m_*-rho>0 and solve

\[
r'=-(2m_*-\rho)r+\rho,
\qquad r(0)=r_0.
\tag{C1}
\]

The solution is exactly source equation (12). Define U=(1+r)C and L=(1-r)C. Since KC=CK=TI and 2TI>=2m_* C,

\[
U'+KU+UK-2TI
\succeq[r'-(1+r)\rho+2m_*r]C=0,
\tag{C2}
\]

\[
L'+KL+LK-2TI
\preceq[-r'+(1-r)\rho-2m_*r]C
=-2\rho rC\preceq0.
\tag{C3}
\]

For E'+KE+EK=R, the fundamental-matrix solution is

\[
E(t)=\Phi(t,0)E(0)\Phi(t,0)^T
+\int_0^t\Phi(t,s)R(s)\Phi(t,s)^Tds,
\qquad \partial_t\Phi=-K(t)\Phi.
\tag{C4}
\]

Every term is positive semidefinite when E(0) and R are. Apply this once to U-Sigma and once to Sigma-L. This proves source equation (13) for the actual Lyapunov solution Sigma'=-K Sigma-Sigma K+2TI. No products of unrelated positive matrices were declared positive, and no commutation of K at different times was used. The comparison remains valid on the full horizon provided r<1. For the cyclic model, a lower rate independent of epsilon and |a'|<=1.1 epsilon give r=O_L(epsilon) uniformly to 2/epsilon.

A relevant failure case is explicit in the hypotheses: if 2m_*<=rho, the displayed contraction floor cannot supply a small tracking error. Increasing only the largest internal precision does not repair a slowest rate that violates this condition. The witness chooses J_L=1 and proves a finite positive lower constant; it does not rely on the largest precision for this hypothesis.

## 3. Conditional KL and force retain the actual regression error

Use the source split x=(y,z), precision blocks A,B,D, conditional mean v+Cy with C=-D^(-1)B^T and v=D^(-1)f_z. Let Q have actual mean (m_y,m_z) and covariance Sigma. Define the comparison Gaussian Ptilde with covariance T K^(-1) and mean (m_y,v+C m_y). Its conditional z|y is the exact optimizer conditional. With e=m_z-v-Cm_y, disintegration gives

\[
\Delta=D(Q\Vert\widetilde P)-D(Q_y\Vert\widetilde P_y).
\tag{C5}
\]

The mean difference in the full KL is (0,e), so its contribution is e^TDe/(2T), without an omitted retained-mean term. If the covariance barrier holds, each eigenvalue lambda of K^(1/2) Sigma K^(1/2)/T belongs to [1-r,1+r]. Twice integrating the derivative of lambda-1-log lambda gives

\[
0\le\lambda-1-\log\lambda
\le\frac{(\lambda-1)^2}{2(1-r)^2}.
\tag{C6}
\]

The Gaussian KL formula, (C5), and nonnegativity of the retained KL now prove

\[
0\le\Delta\le\frac{d r^2}{4(1-r)^2}
+\frac{e^TDe}{2T}.
\tag{C7}
\]

This is the source's Theorem 2. Actual covariance cross blocks, hence errors in conditional regression on y, occur in the full covariance term of (C5); they have not been discarded. The bound is conservative because it drops the nonnegative retained covariance KL. It is not a comparison of hidden marginal laws alone.

At each y, the exact actual conditional mean displacement d(y)=E_Q[z|y]-v-Cy contributes d(y)^TDd(y)/(2T) to its Gaussian conditional KL. The actual drift defect is -B d(y). The matrix inequality

\[
|Bu|^2\le\|BD^{-1}B^T\|u^TDu
\tag{C8}
\]

therefore proves the source's conditional-averaged force bound (27). This remains distinct from the pathwise thermal force. In particular, Delta=0 does not imply B(z-v-Cy)=0 on an actual sample path.

## 4. Normalizers and the own-law parent score

The full restricted objective has exactly the form

\[
F_T(Q,a)=T\int q\log q+E_QU_a+T\log Z_0(a)
=T D(Q\Vert\Pi_a)-T\log c^{\rm eff}(a).
\tag{C9}
\]

The source defines c_eff by the normalized integral of exp(-U_a/T). It includes the selected observation likelihood, its evidence constant, and the evaluator restriction. It is not replaced by the physical evidence if the evaluator restriction changes the optimizing law. The physical prior and optimizer precision differ by the declared TR term in the normalized-model component. Its equations M10a–M10b write both constants explicitly.

For a fixed retained density r, exact conditional minimization gives
F_parent(r,a)=F_T(r k_a,a).
The derivative through the optimizing conditional k_a vanishes. Indeed the functional derivative of the density part of (C9), evaluated at r k_a, is T log(r/Pi_y)+T, a retained-only function; its pairing with partial_a k_a integrates to zero at each y. Thus

\[
\partial_aF_{\rm parent}(r,a)
=g(rk_a,a).
\tag{C10}
\]

The original prior-normalizer derivative and the common c_eff offset survive. This checks the envelope statement in source Section 6.1 without presuming a separate envelope theorem. Evaluating a new bare marginal physical-model score or dropping the common scalar would produce a different update, but neither is done in the checked equations.

For the cyclic normalized model,

\[
g(Q,a)=a-2+\tfrac12E_Qx^THx
-\tfrac T2\operatorname{tr}(A_0(a)^{-1}H),
\quad A_0=aH+P_K-TR.
\tag{C11}
\]

The last term is T partial_a log Z_0. The calibration observation N(a,T), observed at 2, contributes a-2. The complete Fisher metric is

\[
M(a)=T^{-1}+\tfrac12\operatorname{tr}[(A_0^{-1}H)^2],
\qquad h(a)=TM(a).
\tag{C12}
\]

The prior and calibration score cross term vanishes because the calibration score has conditional mean zero and the prior score has mean zero. The vector observation has no explicit a-score at fixed x. This reconstructs the actual h used in the source. It is retained as the microscopic parameter metric; a smaller marginal Fisher metric is not silently substituted.

For the conditional score, with w=z-v-Cy, differentiating the normalized conditional density gives

\[
\partial_a\log k_a
=\tfrac12\operatorname{tr}(D^{-1}D')
-\frac{w^TD'w}{2T}
+\frac{w^TD(v'+C'y)}{T}.
\tag{C13}
\]

The determinant derivative has the correct positive sign. Differentiating the exact KL chain at fixed Q yields g-g_parent=-T E_Q partial_a log k_a. Whitening the covariance of (y,w) by diag(T S^(-1),T D^(-1)) gives identity plus an operator perturbation of norm at most r. Its hidden block controls the D' quadratic term and its cross block controls C'. Trace duality between nuclear and operator norms then gives exactly the source's bound (32). In the pure scalar-precision case C'=v'=0, the expression reduces to its equation (33). This verifies the score bound as an expectation calculation for an unbounded quadratic score; no inference from a KL value alone is used.

## 5. Own-coefficient learning at actual sequential activations

The source's calibration lemma is stronger than a same-a comparison. It evaluates (C11) in each parent's own optimizer lift and evolves that parent's own a. On a provisional admitted interval, the actual normal parent mean obeys m'=-S_a m, and the relative precision derivative gives

\[
\frac d{dt}(m^TS_am)
=m^T\dot S_am-2m^TS_a^2m
\le\rho m^TS_am.
\tag{C14}
\]

At a reduction, the new Schur mean energy is the minimum over the discarded coordinate and is at most the preceding mean energy. Therefore all stages together obey m^TS_am<=exp(1.1c)E_0 on c/epsilon. This does not accumulate one exponential per stage; the bound uses the total elapsed time.

The optimizer lift of an actual retained Gaussian has the exact learned-normal energy

\[
E_{Q^{\rm lift}}x^TK_ax
=m_y^TS_am_y+\operatorname{tr}(S_a\Sigma_y)+T p_{\rm hidden}.
\tag{C15}
\]

The covariance barrier bounds the retained trace by (1+r_*)T p_retained. The last term is exactly the conditional target fluctuation energy; it is not an assumption that the current fine conditional has equilibrated. The parent objective is defined by that optimizing lift, whereas the actual fine conditional enters the separately bounded discarded cost and score defect.

Since H<=K_a/a and A_0>=aH/2+P_K, the source obtains

\[
|g-(a-2)|\le\tfrac12 e^{1.1c}E_0+\tfrac{13}{8}Tp,
\qquad 0\le h-1\le2Tp,
\tag{C16}
\]

when r_*<=1/4 and a>=1. These constants are conservative: the upper lift covariance contribution is 5Tp/8 in half-energy units, and adding the absolute prior-normalizer bound Tp gives 13Tp/8. Hence

\[
\left|-h^{-1}g-(2-a)\right|
\le\delta:=\tfrac12e^{1.1c}E_0+\tfrac{29}{8}Tp.
\tag{C17}
\]

If delta<1/20, a'=epsilon(2-a)+epsilon R_t with |R_t|<=delta points strictly inward at a=1 and a=2.1, and its magnitude is below 1.1 epsilon. These strict inequalities close the provisional interval and speed bounds by first exit. The covariance bootstrap closes simultaneously because the initial error is at most r_* and the invariant barrier remains r_* on every activated stage. This is not circular use of an unproved speed bound.

Integration of the scalar linear equation gives source (42d), including an order-one parameter change on 2/epsilon. Two separately evolved processes initialized at an activation with the same actual a have parameter difference at most 2delta(1-exp(-epsilon elapsed)). Their two errors R_t are computed from their respective laws; the comparison solution 2-exp(-epsilon t) is not prescribed as either trajectory.

A parent starts with the actual retained mean and covariance. Congruence of the previous covariance barrier gives its initial barrier at the same current a. Its next autonomous covariance follows the Lyapunov equation from those moments, with no equilibrium resampling. The argument is therefore compatible with every finite sequence of actual-law activations in the checked class.

## 6. Schur derivatives and restoring means

For one split let X=[I;-D^(-1)B^T]. Then KX=[S;0], and the retained rows of X' vanish. Consequently

\[
S=X^TKX,\qquad \dot S=X^T\dot KX.
\tag{C18}
\]

The terms involving Xdot vanish exactly. Thus the lower-rate inequality and both sides of the relative-speed inequality pass to every Schur parent. The lower-rate argument is y^TSy=min_z(y,z)^TK(y,z)>=m_*|y|^2. This also verifies that ordered elimination has the same precision as direct elimination and that positivity is not an additional recursive assumption.

The source's stiffness-independent mean sensitivity is valid. Integrating 0<=partial_a S<=S/a_- bounds intermediate quadratic forms by a finite parameter-range factor. Cauchy–Schwarz in partial_a S gives

\[
|v^T(S_a-S_b)w|
\le C|a-b|\sqrt{v^TS_av}\sqrt{w^TS_bw}.
\tag{C19}
\]

For u=m_a-m_b, equal initial means imply
(|u|^2)'<=-u^TS_au+C^2|a-b|^2m_b^TS_bm_b.
The last energy integrates to half the decrease of |m_b|^2. This proves source (42l) without a largest-eigenvalue or horizon multiplier. The covariance comparison (42m) is also valid: use factors C^(1/2) W^(1/2) of the whitened covariance and one standard Gaussian; the operator square-root displacement times sqrt(tr C) bounds the coupling distance. A covariance factor need not be the symmetric square root in the original coordinates for this coupling argument.

For source (52), e=D^(-1)(Km)_hidden follows by multiplying the block row. With hidden-first blocks F,G,A, put L=F^(-1)G. Differentiating e=z+Ly gives

\[
e'=-(F+F^{-1}GG^T)e+(\dot L-LS)y.
\tag{C20}
\]

Multiplication by e^TF yields the nonpositive terms -e^TF^2e and -e^TGG^Te. The latter is -|G^Te|^2 despite the nonsymmetry of F^(-1)GG^T in the raw equation. The metric derivative is bounded by rho e^TFe, so source (52c) follows. Its subsequent forcing estimates need the explicit cross-block derivative bounds (52d) and exclusion of decoupled root/holonomy columns. The source states these obligations rather than deriving them from a spectral gap alone. The cyclic witness supplies them; this check does not reclassify those geometric inputs as conclusions of the covariance theorem.

## 7. Retained paths, exact memory, and limits of the claim

Variation of constants for the actual hidden SDE gives source (44), with its actual correlated initial pair and orthogonally projected Brownian noises. Substitution into the retained equation yields an inherited Volterra kernel, an initialization term, and a colored-noise term. Keeping all of them produces the exact retained path law. Repeating substitution for two hidden blocks is substitution into the same unique finite linear SDE, so it is exactly compositional. This is not an autonomous Markov quotient, nor a claim that memory storage becomes smaller.

For a same-a autonomous Markov replacement driven by the same retained Brownian motion, let D_path be the path difference and E=z-v-Cy. Its equation is D_path'=-S D_path-BE. The source correctly includes

\[
E|BE|^2\le T(1+r)\operatorname{tr}(BD^{-1}B^T)+|Be|^2.
\tag{C21}
\]

Dissipativity gives

\[
(|D_{\rm path}|^2)'
\le-k_*|D_{\rm path}|^2+|BE|^2/k_*.
\tag{C22}
\]

Integrating, taking the supremum, and then expectation proves source (47). Minkowski's inequality in the propagator formula gives (46). These estimates do not require independence of BE from the retained state. They do require the explicit thermal integral to be small for a small uniform path error. Conditional KL equal to zero would leave its first term nonzero whenever B is nonzero.

The generic jointly learned parameter/law estimates (39)–(42) follow from the displayed two Dini inequalities and their integrating factors. Their factor is exp(epsilon C_* elapsed), which is harmless on c/epsilon only if the admitted C_* is controlled. The source explicitly declines contrast-uniformity for those generic constants and instead proves (42j)–(42m). A claimed path bound for the cyclic family must additionally use its actual thermal/path estimates or its exact memory description. The conditional document does not hide this final distinction. The cyclic witness's separate shrinking-tube argument is being checked by its other reviewer.

## 8. Outcome and the remaining joint checks

The checked source supports its Gaussian covariance, direct conditional-VFE, score, inherited-metric, Schur, actual-initialization, own-law learning, and stated memory/path implications. No correction to its displayed equations is required by this reconstruction. All relevant model normalizers remain present, and no positive-temperature conditional matching is assumed.

The source is an implication theorem plus a model-specific feedback lemma. Completion of the frozen construction additionally depends on the cyclic witness's finite-flag rank, mean formation, marked physical-kernel preservation, and simultaneous parameter choices. Those are named separate checks, not mathematical gaps in the implications reconstructed here. The next action is to combine this check with the independent witness and physical-kernel reconstructions, keeping their admitted Gaussian and compatible-observation scope.

This check used read-only source inspection and ordinary analytical reconstruction. No simulation, symbolic package, tests, numerical agreement, Git command, Lean work, base transport, or Research-vault edit was used as evidence. Only this assigned check document was written.

Coordinator's final delta inspection: after this reconstruction, the normalized-model intro to M11 was changed from an ambiguous local-diffusion description to common unit coordinate mobility. Its equations, physical/optimizer constants, and conditional comparisons are unchanged. The final model/geometry report records the new source identifier and explicitly checks the generally dense proper reference. This wording change does not alter any calculation C1–C22 above.
