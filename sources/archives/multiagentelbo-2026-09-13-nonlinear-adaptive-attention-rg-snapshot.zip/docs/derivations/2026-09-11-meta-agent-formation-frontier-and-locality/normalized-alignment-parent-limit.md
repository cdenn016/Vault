# Normalized alignment records and a conditional recursive parent construction

September 11, 2026. At one fixed base point, the existing interaction-record construction admits a regime in which inference concentrates independent latent links and agent law states onto a coherent block. For Gaussian law states acted on by translations, the coherent constraint, its fluctuation determinant, the limiting parent prior, and a recursive coarse model can all be calculated. A Gaussian prior on the law and link coordinates gives a closed Gaussian parent prior with an explicit information-vector shift.

This is a conditional construction under repeated agreement records, compatible retained observations, and specified blocks. It does not select those blocks, prove finite-strength exact alignment, or replace the original heterogeneous experiment. It uses the source's branch with links inside the random complete state; it does not silently substitute posterior inference for the separate structural-parameter learning analyzed in [the previous derivation](pointwise-gaussian-link-learning.md).

## 1. The normalized model and the two levels of probability

The source already provides the binary success kernel K_a(1|y)=exp[-E_a(y)] for nonnegative sample-level energies in [Theory/05b_local_collective_elbo.tex](../../../Theory/05b_local_collective_elbo.tex), immediately after `eq:obs-interaction-energy`. Its `hyp:local-interaction-kernels` explicitly permits an agent state to contain a belief-law point and a model-law point. The [full graph construction](../../../Theory/07c_full_graph_meta_agent_vfe.tex) permits links in the random complete state. The [August 16 report](../2026-08-16-multiscale-two-channel-graph-vfe-rg/REPORT-part1-vfe-and-construction.md), Section 1.1, already separates this reading from putting a recognition marginal into a fixed generative factor. We use those existing provisions rather than presenting the Gibbs representation itself as a new result.

Let W contain agent belief-law points b_i, model-law points m_i, independent link coordinates Theta_e, and all needed interfaces at c_*. Let P_0 be one proper correlated prior on this complete state. Independence of links means that they are independent coordinates rather than frame coboundaries; it does not require their posterior to factorize. Write Q for recognition over W. A sample law b_i inside W and the recognition marginal of Q are different objects.

For positive fixed record weights w_e, let D_e(W) be the transported KL of the incident sample laws, and set D=sum_e w_e D_e. The sum can include both channels with their separately typed representations and links. On a domain where these KL values are finite, declare independent binary records conditional on W by

\[
 K_e(1\mid W)=e^{-w_eD_e(W)},\qquad
 K_e(0\mid W)=1-e^{-w_eD_e(W)}.
 \tag{1}
\]

Both outcomes are included, so each kernel is normalized. Conditioning on n successes on every selected internal edge yields a factor exp[-nD]. No successes are manufactured or claimed to have been observed here. This is a conditional inference experiment, and n is a record count, not a learned penalty selected to make a benchmark succeed. The source's label/attention factors are not required for this submodel.

Other already selected records may supply a fixed likelihood L_0(W). Put rho_0=p_0 L_0, assume 0<integral rho_0<infinity, and retain its mass in the evidence. The selected joint slice and its posterior are

\[
 p_n(W,o_0,\mathbf 1)=\rho_0(W)e^{-nD(W)},\qquad
 Z_n=\int\rho_0 e^{-nD},\qquad
 \Pi_n(dW)=Z_n^{-1}\rho_0(W)e^{-nD(W)}dW.
 \tag{2}
\]

For finite nonnegative D, Z_n is positive and finite. Thus neither cycles nor noncompact link coordinates require an unnormalized Haar prior. Passive frame changes push P_0, the law states, and the link coordinates together; active invariance of a proper prior under every noncompact translation is not assumed.

## 2. An exact alignment-inference family

Fix the generative target Pi_n. Use the full-law Fisher E-flow already used in the conditional-parent derivation. Starting at the normalized baseline B_0=rho_0/integral rho_0 gives

\[
 Q_t=\Pi_{\kappa(t)},\qquad
 \kappa(t)=n(1-e^{-t}),\qquad
 \dot\kappa=n-\kappa.
 \tag{3}
\]

This follows directly from Q_t proportional to Q_0^{e^{-t}} Pi_n^{1-e^{-t}}. It describes changes of a probability law over complete configurations, not motion of a sampled configuration under a particle force. The links are inferred jointly with the law points and generally become correlated with them.

Where the second moment of D is finite, differentiating the normalized exponential tilt gives

\[
 \frac{d}{d\kappa}\mathbb E_{\Pi_\kappa}D
 =-\operatorname{Var}_{\Pi_\kappa}(D),\qquad
 \frac{d}{dt}\mathbb E_{Q_t}D
 =-(n-\kappa)\operatorname{Var}_{Q_t}(D)\le0.
 \tag{4}
\]

The proof differentiates numerator and denominator and subtracts their product. At positive kappa all polynomial moments of a nonnegative finite D are integrable under a finite baseline measure, since x^j exp(-kappa x) is bounded. An initial derivative at kappa=0 separately requires the stated moment. An individual edge instead has derivative -Cov(D_e,D); total expected mismatch decreasing does not imply every edge decreases at every instant. Arbitrary initial Q need not have this monotonicity.

If the baseline essential infimum of D is zero, then for 0<epsilon<delta and positive B_0(D<=epsilon),

\[
 \Pi_\kappa(D\ge\delta)
 \le\frac{e^{-\kappa(\delta-\epsilon)}}{B_0(D\le\epsilon)}.
 \tag{5}
\]

The numerator is at most exp(-kappa delta), and the normalizer is at least exp(-kappa epsilon) B_0(D<=epsilon). This proves alignment in probability as kappa grows. It does not give exact alignment at finite n. If B_0(D=0)=0, equivalence of the finite tilts to B_0 gives Pi_kappa(D=0)=0 at every finite kappa. At fixed n, the inference limit is Pi_n, not a law supported on D=0. A positive essential minimum is a separate obstruction to zero mismatch.

## 3. A regular coherent block with initially independent links

Use an explicit group/action admitted by [Theory/02_geometry.tex](../../../Theory/02_geometry.tex), `eq:geo-representations`: G is the additive translation group acting on the sample line by z -> z+a. No linear-vector representation is required at the general measurable-action tier. At c_* an agent law point is

\[
 b_i=\mathcal N(\mu_i,e^{2v_i}),\qquad
 a_e\in\mathbb R,\quad e=(i,j),\quad
 r_e=\mu_i-\mu_j-a_e.
 \tag{6}
\]

Here v_i=log sigma_i. Both mean and variance are part of the law point. The full recognition law over all mu_i, v_i, and a_e remains unrestricted and can be correlated; it is not being called a product of these Gaussian agent laws. With one orientation for each edge copy,

\[
 D_e=v_j-v_i+\tfrac12e^{2(v_i-v_j)}-\tfrac12
                 +\tfrac12e^{-2v_j}r_e^2.
 \tag{7}
\]

This is the exact univariate Gaussian KL, obtained by integrating the log density ratio; the multivariate formula is also recorded in [Rasmussen and Williams, Appendix A](https://gaussianprocess.org/gpml/chapters/RWA.pdf). It is nonnegative and vanishes precisely when v_i=v_j and r_e=0. Let a block contain N vertices and m internal edge copies, with positive w_e and connected underlying graph. All a_e are free before conditioning. Its coherent set is

\[
 \mathcal M:\quad v_i=s\ \text{for every }i,
 \qquad a_e=\mu_i-\mu_j\ \text{for every internal edge}.
 \tag{8}
\]

It has dimension N+1 inside a space of dimension 2N+m. The cycle sum of a_e on M is zero by telescoping. Thus trivial translation holonomy is derived on the aligned set in this example, rather than imposed on the original link coordinates. Translated nondegenerate Gaussian laws have trivial translation stabilizer. This implication does not extend to arbitrary groups and laws with nontrivial stabilizers.

Choose a root 1 and coordinates z=(mu_1,...,mu_N,s), with v_1=s. The discarded coordinates are r=(r_e) and delta=(v_2-s,...,v_N-s). The inverse coordinate map is a_e=mu_i-mu_j-r_e and v_i=s+delta_i, with delta_1=0. Its absolute Jacobian is one. Thus these coordinates fix the integration measure without an unspecified normal-volume convention.

Let B be the oriented vertex incidence matrix, W=diag(w_e), L=B^T W B, and L_red its root-deleted principal submatrix. For n_perp=(r,delta), Taylor expansion of (7) at n_perp=0 gives

\[
 D(z,n_\perp)=\tfrac12n_\perp^\top H(s)n_\perp
                         +O(\|n_\perp\|^3),\qquad
 H(s)=\operatorname{diag}(e^{-2s}W,2L_{\rm red}).
 \tag{9}
\]

Indeed, phi(d)=exp(2d)/2-d-1/2 has phi(d)=d^2+O(d^3); each mean residual contributes exp(-2s) r_e^2/2. The weight sum of squared variance differences is delta^T L_red delta. Connectivity and positive weights make L_red positive definite, because a vector with root value zero and zero edge differences must vanish. Therefore

\[
 d_\perp=m+N-1,\qquad
 \det H(s)=e^{-2ms}c_G,\qquad
 c_G=\det(W)2^{N-1}\det L_{\rm red}>0.
 \tag{10}
\]

The coordinate-rank calculation includes the link variations. Freezing them would give a different Hessian and a different parent measure.

The same construction can be applied to belief and model law points with separate link copies on the same principal translation bundle. Their alignment normal blocks are separate, but P_0 may correlate both channels. Determinants multiply and normal codimensions add. Equality of these two one-dimensional actions is an explicit example, not an assumption about the general program's representations.

## 4. The fluctuation integral and its precise admission

First assume rho_0 is continuous, nonnegative, bounded, and compactly supported in the displayed coordinates, with positive mass density on an open part of M. Its support keeps v_i finite. More generally, retain continuity and assume that, in the original finite coordinate vector w,

\[
 0\le\rho_0(w)\le C e^{-c\|w\|^2},\qquad C,c>0,
 \quad\text{and}\quad
 0<I:=\int\frac{\rho_0(z,0)}{\sqrt{\det H(s)}}dz<\infty.
 \tag{11}
\]

The Gaussian bound permits nonzero prior means after reducing c and changing C. It includes every proper nondegenerate Gaussian prior and that prior multiplied by bounded selected likelihoods. It also includes continuous compactly supported densities. Positivity and finiteness of I are part of the admission; they hold for a positive Gaussian prior in this example. No claim is made for a heavy-tailed baseline causing mass escape or an infinite I.

Define the unnormalized limiting density on coherent coordinates

\[
 \rho_{\rm coh}(z)=\frac{\rho_0(z,0)}{\sqrt{\det H(s)}}
 =c_G^{-1/2}e^{ms}\rho_0(z,0).
 \tag{12}
\]

Then

\[
 Z_n=(2\pi/n)^{d_\perp/2}[I+o(1)],\qquad
 (\operatorname{pr}_z)_\#\Pi_n
 \longrightarrow I^{-1}\rho_{\rm coh}(z)dz,
 \qquad
 \mathbb E_{\Pi_n}D=\frac{d_\perp}{2n}+o(n^{-1}).
 \tag{13}
\]

The convergence of the retained densities is in L1. It is a density limit after projection; the full ambient law has a singular weak limit on M.

Here is a direct proof, including the noncompact Gaussian-bound case. On a compact set, write n_perp=u/sqrt(n) in the integral. Equation (9) gives nD -> u^T H(s)u/2. Bounded v and connectivity give a uniform positive quadratic lower bound for D on the compact support, using phi(d)>0 away from d=0. A Gaussian in u dominates the rescaled integrand. Dominated convergence gives the Gaussian integral (2pi)^{d_perp/2}/sqrt(det H), and inserting nD into that integral gives d_perp/2 times the same value.

For (11), first truncate all coherent and variance-difference coordinates to a compact set, apply this argument, and control the tails uniformly. The change from original coordinates to (mu,s,delta,r) is invertible and linear, so its Gaussian upper bound remains of that form. For fixed v the integral over r is bounded by a constant times

\[
 n^{-m/2}\exp\left(\sum_{e=(i,j)}v_j\right).
 \tag{14}
\]

This follows by retaining exp[-c'||r||^2] from the density bound and integrating each exp[-n w_e exp(-2v_j)r_e^2/2]. The reciprocal square root of c'+n w_e exp(-2v_j)/2 is at most a fixed constant times n^{-1/2} exp(v_j). Completing squares with the remaining Gaussian density bounds the extra linear exponential in v. Also phi(d)>=c_1 min(d^2,|d|) for all real d, for some c_1>0: use its positive quadratic limit at zero, its linear negative tail, and its exponential positive tail. Connectivity of the finite graph then gives D_variance>=c_2 min(||delta||^2,||delta||). After delta=u/sqrt(n), the bound exp[-c_2 min(||u||^2,||u||)] is integrable uniformly for n>=1. The remaining coherent coordinates retain an integrable Gaussian bound. These estimates make the omitted tails uniformly small and justify removing the truncation. For the energy insertion use nD exp(-nD)<=C_1 exp(-nD/2), with the same estimates at n/2. This also proves the third limit in (13). Applying the argument to the pointwise nonnegative marginal integrals and their masses proves the stated L1 convergence.

Equation (12) is the factor that would be lost by simply restricting the energy to M. In particular, integrating mean/link fluctuations weights a common log scale s by exp(ms). This is a derived volume factor, not an optional alignment reward.

## 5. A parent agent and its complete retained interface

For a fixed partition into connected blocks I, choose one fixed root per block. On each coherent block write t_i=mu_i-mu_root(I). Its parent law point is b_I=N(mu_root(I),exp(2s_I)). For every cut-edge copy e=(i,j), define the retained effective translation

\[
 A_e=a_e+t_j-t_i.
 \tag{15}
\]

Substitution in (7) proves exactly on the coherent set that

\[
 D_e(b_i,(a_e)_\#b_j)
 =D_e(b_I,(A_e)_\#b_J).
 \tag{16}
\]

Every cut-edge copy and its weight and record remain present. There is no unjustified replacement of several different translations by one averaged edge. Under a fixed passive re-expression mu_i'=mu_i+g_i, a_e'=a_e+g_i-g_j, the parent variables obey mu_I'=mu_I+g_root(I) and A_e'=A_e+g_root(I)-g_root(J). The retained map is therefore covariant for the chosen roots. A canonical root or partition is not supplied by this calculation.

Internal relative frames t_i can be integrated out when all required retained likelihood kernels depend on the coherent configuration only through the parent law points, effective cut links, and explicitly retained marks. Cut-edge agreement kernels satisfy this by (16). A record reading an individual child's untransformed mean need not satisfy it. Such a record needs a retained frame/interface or its full induced conditional kernel; it cannot simply be dropped. Model-evaluation kernels obey the same requirement.

Let x collect these parent law coordinates and effective cut links, and let t collect the internal relative-frame coordinates. Their change from z is linear with constant unit absolute Jacobian for the displayed rooted coordinates. The complete parent prior is

\[
 \bar p_0(x)=I_0^{-1}\int p_0(w_{\rm coh}(x,t))
       \prod_I[\det H_I(s_I)]^{-1/2}dt,
 \quad
 I_0=\int p_0(w_{\rm coh}(x,t))
       \prod_I[\det H_I(s_I)]^{-1/2}dtdx.
 \tag{17}
\]

The products in this section refer to separately conditioned internal blocks, and d_perp is their total codimension. Equation (17) is normalized by definition and (11) proves that its mass is positive and finite in the admitted class. Appending the inherited normalized cut and model-evaluation record kernels gives an actual normalized parent joint. No generative factor reads Q.

There is a dimensional reduction in this scoped construction. For one channel on N original nodes and E edge copies, with B blocks and E_cut cut edges, the original sample-coordinate dimension is 2N+E and the parent dimension is 2B+E_cut. Before integrating relative frames, the coherent state has dimension N+B+E_cut. If the interface requires those frames, that larger count applies. These are sample-coordinate counts, not a measured runtime or a count of parameters in an arbitrary correlated density. Prediction and storage gains require an implementation and its actual interface costs.

The normalization of the removed records also survives. If o denotes compatible retained records, then

\[
 p_n(o,\mathbf1)
 =(2\pi/n)^{d_\perp/2}I_0\bar p(o)[1+o(1)].
 \tag{18}
\]

on admitted positive slices. Thus the parent evidence by itself is not the fine evidence. The scalar I_0 and the normal-volume power must remain in the VFE accounting.

On compact admitted domains, a finite-strength prediction bound is also available. Suppose the required record kernel differs in total variation by at most L||n_perp|| between a configuration and its coherent projection. For the same finite-strength retained prior,

\[
 \left\|P_n^{X,O}-P_n^X\bar K\right\|_{\rm TV}
 \le L\mathbb E_{\Pi_n}\|n_\perp\|
 \le L\sqrt{\mathbb E_{\Pi_n}D/c_D}=O(n^{-1/2}),
 \tag{19}
\]

where D>=c_D||n_perp||^2 on the compact support. This compares the true record kernel with the coherent one and keeps the same retained prior on both sides. Replacing that prior by its limiting prior adds their total-variation distance from (13). For H conditionally generated records with a uniform Lipschitz bound over an admitted policy class, coupling the same static latent state and using the same policy gives the bound HL E||n_perp|| by telescoping. No claim is made for arbitrary discontinuous evaluators, unbounded interfaces, dynamic latent transitions, or horizons growing without control.

## 6. Closed Gaussian parent priors, including the entropy shift

Take a proper Gaussian prior on all law and link coordinates, w~N(m_0,C_0), J_0=C_0^{-1}. For a single block let w_coh=Rz be the linear map described in Section 3. R has full column rank. With z=(mu_1,...,mu_N,s), (12) has Gaussian information form with

\[
 J_z=R^\top J_0R\succ0,\qquad
 h_z=R^\top J_0m_0+m e_s.
 \tag{20}
\]

The final term comes from exp(ms). It is not a fitted source term. Normalizing gives N(J_z^{-1}h_z,J_z^{-1}); marginalizing the internal frames gives the parent Gaussian on (mu_root,s). For multiple blocks and retained cut links, use the full coherent map R and add each internal edge count m_I in its block's s_I information coordinate. The same formula holds for a correlated two-channel Gaussian prior with the two normal-volume shifts. It does not replace the two associated bundles by independent principal bundles.

For one block with d_perp=m+N-1, the integral in (17), before any compatible observation likelihood, is explicit:

\[
 I_0=(2\pi)^{-d_\perp/2}c_G^{-1/2}
 \sqrt{\frac{\det J_0}{\det J_z}}
 \exp\left[\tfrac12h_z^\top J_z^{-1}h_z
                -\tfrac12m_0^\top J_0m_0\right].
 \tag{21}
\]

This follows by completing the square in rho_coh. It proves normalizability for this Gaussian example and retains every dimension and determinant factor. The limiting prior is Gaussian on presentation coordinates, including log standard deviations. A Gaussian law point sampled from that prior has positive variance exp(2s). The posterior over law points and its averaged predictive mixture are not thereby Gaussian.

A three-node cycle makes the formula concrete. Use internal weights (1,2,3), a zero-mean Gaussian prior with precision diagonal (1,...,9) in coordinate order (mu_1,mu_2,mu_3,v_1,v_2,v_3,a_12,a_23,a_31), and root 1. Then d_perp=5, det H=264 exp(-6s), and

\[
 J_z=\begin{pmatrix}
 17&-7&-9&0\\-7&17&-8&0\\-9&-8&20&0\\0&0&0&15
 \end{pmatrix},\quad
 h_z=(0,0,0,3)^\top.
 \tag{22}
\]

After integrating the two internal relative-frame coordinates,

\[
 (\mu_1,s)\sim\mathcal N\left(
 \begin{pmatrix}0\\1/5\end{pmatrix},
 \begin{pmatrix}276/1327&0\\0&1/15\end{pmatrix}\right),
 \quad
 Z_n\sim n^{-5/2}\sqrt{1008/14597}e^{3/10}.
 \tag{23}
\]

This is a 9-to-4 coherent-coordinate reduction and, for the specified compatible interface, a 4-to-2 parent marginalization. It is not a finite-n collapse. [gaussian_parent_exact.py](evidence/normalized-alignment/gaussian_parent_exact.py) reproduced the displayed matrix, shift, covariance, and scalar coefficients using rational arithmetic; [its output](evidence/normalized-alignment/gaussian-parent-exact-result.json) does not claim a numerical integration of the nonlinear finite-n model.

## 7. Limiting parent inference and the scalar normal-memory term

The generative construction has an exact asymptotic inference counterpart. Let C be the fixed parent-coordinate map used above, extended off M by the same rooted-coordinate formulas. Assume initial recognition has density proportional to rho_0(W) f(C(W)), with f continuous and bounded above and below by positive constants. This fixes its initial hidden conditional to the baseline conditional. It is a hypothesis on initial recognition, not an arbitrary-initial-state result.

Put a=e^{-t}, kappa=n(1-a). The exact full-law flow toward Pi_n is

\[
 q_{n,t}(W)=Z_{\kappa,a}^{-1}\rho_0(W)
                       f(C(W))^a e^{-\kappa D(W)},
 \qquad Z_{\kappa,a}=\int\rho_0 f(C)^a e^{-\kappa D}.
 \tag{24}
\]

Let rho_eff(x) be rho_coh integrated over the internal frame coordinates, with any fixed compatible record likelihood included in rho_0. The Laplace calculation gives, for every t>0,

\[
 C_\#q_{n,t}\longrightarrow
 r_t(x)=\frac{f(x)^a\rho_{\rm eff}(x)}{I_a},
 \qquad I_a=\int f^a\rho_{\rm eff},\quad
 \pi_{\rm eff}=\rho_{\rm eff}/I_0^{\rm obs}.
 \tag{25}
\]

Here I_0^obs means integral rho_eff on this fixed observed slice; it is distinct from the prior mass I_0 in (17). The convergence is in L1 and uniform on compact t-intervals bounded away from zero. The same dominating bounds apply uniformly because f and a stay in compact positive ranges.

The limiting family satisfies the actual parent Fisher equation

\[
 \dot r_t=-r_t\left[\log(r_t/\pi_{\rm eff})
                 -\mathbb E_{r_t}\log(r_t/\pi_{\rm eff})\right].
 \tag{26}
\]

To check it, log(r_t/pi_eff)=a log f plus a normalization constant, and dot a=-a. There is no inserted slower learning-rate coefficient. There is, however, an initial layer: r_{0+} is proportional to f rho_eff, whereas the finite-n initial parent is proportional to f C_#rho_0. These need not agree. The n->infinity and t->0 limits do not generally commute. Equation (26) is the limiting flow after this layer, not a claim of exact finite-n semiconjugacy or a statement about a sampled Markov path.

The discarded normal modes leave a calculable VFE term. Define c_n=(d_perp/2)log[n/(2pi)]. Directly from (24),

\[
 \mathcal F_n(q_{n,t})
 =a\mathbb E_q\log f+(n-\kappa)\mathbb E_qD-\log Z_{\kappa,a}.
 \tag{27}
\]

The integral proof in Section 4 with weight f^a gives E_q D=d_perp/(2 kappa)+o(kappa^{-1}). Substituting the normalizer asymptotic gives

\[
 \mathcal F_n(q_{n,t})-c_n
 \longrightarrow
 \mathrm{KL}(r_t\Vert\pi_{\rm eff})-\log I_0^{\rm obs}
       +\psi_{d_\perp}(a),
 \quad
 \psi_d(a)=\tfrac d2\left[\frac{a}{1-a}+\log(1-a)\right].
 \tag{28}
\]

The first two terms are the parent free energy against its unnormalized observed slice. Equivalently, the right-hand side is the VFE of the normalized parent model in (17), minus log I_0 from that prior normalization, plus psi_d(a). The normal-memory term is nonnegative and

\[
 \frac{d}{dt}\psi_d(e^{-t})
 =-\frac d2\frac{e^{-2t}}{(1-e^{-t})^2}.
 \tag{29}
\]

Thus the limiting parent dynamics and the fine VFE accounting are both available without carrying every normal coordinate. The normal term is a scalar determined by the declared inference clock and codimension. It is not zero except at equilibrium, and neither it nor the divergent evidence term c_n may be dropped. This is an asymptotic identity for the stated preparation and fixed positive t; it does not provide a uniform finite-n error certificate or arbitrary finite-step optimizer equivalence.

For f=1, (24) reduces to the monotonically aligning family (3)-(4). For general f, the extra covariance with log f can change the sign of the instantaneous expected-D rate. Its strong-record concentration and the limiting parent equation still follow from the same integral argument.

## 8. Recursive composition, persistence, and the remaining scope

After internal agreement has been taken to the admitted limit, the parent prior in Section 6 is again a proper Gaussian on law and link presentation coordinates. Its cut-edge records have exactly the original Gaussian-KL/translation form by (16), with all edge copies retained. Hence the same construction applies to any next specified connected grouping. A correlated two-channel prior remains admissible under the blockwise coherent restriction, entropy shift, and Gaussian marginalization. This proves an inductive construction at every fixed finite depth satisfying these conditions.

The rooted cut-link transformation composes on a nested coherent configuration: offsets add, so the two intermediate endpoint offsets cancel. With consistent inherited roots,

\[
 C_{\mathcal P_2}\circ C_{\mathcal P_1}
 =C_{\mathcal P_2\circ\mathcal P_1}.
 \tag{30}
\]

on the common nested coherent set. Pushforward of a fixed probability law is therefore associative. For the actual strong-record hierarchy, take the prescribed stage limits in their declared order and carry each determinant/evidence factor. This does not prove that a different simultaneous scaling of all record counts has the same limiting prior. A finite-n exact pushforward always exists, but its induced record kernels and action generally leave the simple displayed family; the limiting family closure must not be assigned to that finite push.

Compatible subsequent observations preserve support on the coherent set because Bayesian reweighting cannot create mass outside the prior support. Their likelihoods factor through the parent map, so the conditional law of discarded internal frames given the complete parent remains unchanged. Recognition lifted with that conditional then has the exact KL chain equality and the full-law Fisher parent closure from [the conditional-parent derivation](pointwise-learning-parent-closure.md). This is persistence under compatible inference in the limiting model. It is not persistence under an unspecified deterministic structural-link optimizer, a changed observation interface, or arbitrary latent transitions.

Two small exact checks accompany the proofs. [triangle_exact.py](evidence/normalized-alignment/triangle_exact.py) uses the fixed-unit-variance mean/link part on a three-node cycle, a proper heterogeneous Gaussian prior, and independent link coordinates. It computes the finite tilted Gaussians at strengths 0,1,4,16,64, verifies d E[D]/d strength=-Var(D), and obtains zero residual and cycle-holonomy mean and covariance in the constrained limit. Its [saved output](evidence/normalized-alignment/triangle-exact-result.json) is exact rational arithmetic, not sampled data. The initial cycle mean is one and its variance is 37/60, so flatness was not imposed initially. The separate parent-prior check verifies (22)-(23). Both ran once under pinned CPython 3.14.7, serially, without torch, pytest, fitting, or numerical integration. Neither computation proves the general limit theorem; its proof is the integral argument above.

This supplies a conditional positive formation construction from normalized interaction records: agreement inference, emergent coherent constraints, a volume-corrected parent prior, compatible retained records, an asymptotic parent Fisher flow, and finite-depth recursive closure. Its operational interface and record regime are explicit. Endogenous partition selection, a general non-translation G construction, finite-strength exact closure in the same sparse family, measured resource gains, and simultaneous structural-model learning remain open. The original fifteen local admissions and their negative result have not been changed or rerun. No base-manifold transport is involved.
