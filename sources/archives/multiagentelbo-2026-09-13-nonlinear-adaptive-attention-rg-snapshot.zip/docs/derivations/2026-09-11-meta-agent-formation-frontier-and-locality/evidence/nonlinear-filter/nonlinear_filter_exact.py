"""Exact native nonlinear-filter algebra; no trajectory or data collection."""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import time

BASE = Path(__file__).resolve().parent
HELPER = BASE.parent/'local-response/local_response_exact.py'
spec = importlib.util.spec_from_file_location('retained_matrix_helpers', HELPER)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)  # Main guard prevents the prior science run.
zeros, eye, tr, mm = helpers.zeros, helpers.eye, helpers.transpose, helpers.matmul
inverse, rank, det = helpers.inverse, helpers.rank, helpers.determinant
Matrix = list[list[F]]


def add(a: Matrix, b: Matrix, weight: F = F(1)) -> Matrix:
    return [[x+weight*y for x,y in zip(ar,br)] for ar,br in zip(a,b)]


def scale(a: Matrix, weight: F) -> Matrix:
    return [[weight*x for x in row] for row in a]


def block(a: Matrix, rows: list[int], cols: list[int]) -> Matrix:
    return [[a[i][j] for j in cols] for i in rows]


def schur(j: Matrix, h: Matrix, keep: list[int]) -> tuple[Matrix,Matrix,F,F]:
    """Integrate discarded Gaussian coordinates, retaining normalization data."""
    drop = [i for i in range(len(j)) if i not in keep]
    u,b = block(j,drop,drop),block(j,keep,drop)
    hu,ui = block(h,drop,[0]),inverse(u)
    return (add(block(j,keep,keep),mm(mm(b,ui),tr(b)),F(-1)),
            add(block(h,keep,[0]),mm(mm(b,ui),hu),F(-1)),
            det(u),mm(mm(tr(hu),ui),hu)[0][0])


def upper(a: Matrix) -> list[F]:
    return [a[i][j] for i in range(len(a)) for j in range(i,len(a))]


def trace_product(a: Matrix, b: Matrix) -> F:
    return sum((a[i][j]*b[j][i] for i in range(len(a)) for j in range(len(a))),F(0))


def main() -> None:
    start = time.perf_counter()
    n,c = 8,F(1,2)
    theta_ref = [F(1,3),F(1,2),F(1,2),F(2,3),F(2,3),F(1,3)]
    edges = [(i,i-2) for i in range(2,8)]
    r0 = eye(n)
    for i in range(1,n,2):
        r0[i][i-1] = -c

    def residual(theta: list[F]) -> Matrix:
        r = [row[:] for row in r0]
        for val,(i,j) in zip(theta,edges):
            r[i][j] = -val
        return r

    linear,quadratic = [],[]
    for i,j in edges:
        a = [r0[i]]
        b = [[F(k==j) for k in range(n)]]
        linear.append(scale(add(mm(tr(a),b),mm(tr(b),a)),F(-1)))
        quadratic.append(mm(tr(b),b))
    basis = linear+quadratic
    assert rank([upper(a) for a in basis]) == 12
    noise,obs = F(600923,46656),F(4)
    hrow = [[F(1,2) if i in (2,3,6,7) else F(0) for i in range(n)]]
    likelihood_precision = scale(mm(tr(hrow),hrow),1/noise)
    h = scale(tr(hrow),obs/noise)
    base = add(mm(tr(r0),r0),likelihood_precision)

    def precision(ell: list[F], nu: list[F]) -> Matrix:
        out = [row[:] for row in base]
        for a,val in zip(basis,ell+nu):
            out = add(out,a,val)
        return out

    # Interior point of an invariant family; autonomous reachability is unclaimed.
    ell = [F(2,5),F(3,5),F(4,7),F(5,8),F(3,4),F(2,7)]
    variance = [F(i+1,30) for i in range(6)]
    nu = [x*x+v for x,v in zip(ell,variance)]
    theta = [x+F(i+1,40) for i,x in enumerate(theta_ref)]
    j = precision(ell,nu)
    direct = add(mm(tr(residual(ell)),residual(ell)),likelihood_precision)
    for a,v in zip(quadratic,variance):
        direct = add(direct,a,v)
    assert j == direct
    assert all(det(block(j,list(range(k)),list(range(k)))) > 0 for k in range(1,n+1))
    target = precision(theta,[x*x for x in theta])
    dj = zeros(n,n)
    for a,val in zip(basis,[x-y for x,y in zip(theta,ell)]+[x*x-y for x,y in zip(theta,nu)]):
        dj = add(dj,a,val)
    assert dj == add(target,j,F(-1))
    for x,l,v,nv in zip(theta,ell,variance,nu):
        assert (x*x-nv)-2*l*(x-l) == (x-l)**2-v
    cov = inverse(j)
    mu = mm(cov,h)
    raw = add(cov,mm(mu,tr(mu)))
    rtheta = residual(theta)
    j0 = mm(tr(rtheta),rtheta)
    cov0 = inverse(j0)
    derivatives = [add(a,b,2*x) for a,b,x in zip(linear,quadratic,theta)]
    metric = [[trace_product(mm(mm(cov0,a),cov0),b)/2 for b in derivatives] for a in derivatives]
    expected_metric = [[cov0[edges[a][1]][edges[a][1]] if a==b else F(0) for b in range(6)] for a in range(6)]
    assert metric == expected_metric and det(j0) == 1
    g = [trace_product(add(raw,cov0,F(-1)),a)/2 for a in derivatives]
    local_g = [-sum((raw[parent][k]*rtheta[child][k] for k in range(n)),F(0)) for child,parent in edges]
    assert g == local_g
    FY = [[F(k==i) for k in range(n)] for i in [2,3,6,7]]
    jY,hY,d1,s1 = schur(j,h,[2,3,6,7])
    assert inverse(jY) == mm(mm(FY,cov),tr(FY))
    assert mm(inverse(jY),hY) == mm(FY,mu)
    T = [[F(1,2),0,F(1,2),0],[0,F(1,2),0,F(1,2)],[-1,0,1,0],[0,-1,0,1]]
    T = [[F(x) for x in row] for row in T]
    assert det(T) == 1
    Ti = inverse(T)
    jZD,hZD = mm(mm(tr(Ti),jY),Ti),mm(tr(Ti),hY)
    jZ,hZ,d2,s2 = schur(jZD,hZD,[0,1])
    FZ = mm(T[:2],FY)
    assert inverse(jZ) == mm(mm(FZ,cov),tr(FZ))
    assert mm(inverse(jZ),hZ) == mm(FZ,mu)
    assert det(j) == d1*d2*det(jZ)
    assert mm(mm(tr(h),cov),h)[0][0] == s1+s2+mm(mm(tr(hZ),inverse(jZ)),hZ)[0][0]
    assert hZ == [[obs/noise],[obs/noise]]
    columns_y,columns_z,columns_g = [],[],[]
    for a in basis:
        dc = scale(mm(mm(cov,a),cov),F(-1))
        dm = mm(dc,h)
        draw = add(add(dc,mm(dm,tr(mu))),mm(mu,tr(dm)))
        columns_y.append(upper(mm(mm(FY,dc),tr(FY))))
        columns_z.append(upper(mm(mm(FZ,dc),tr(FZ))))
        columns_g.append([trace_product(draw,d)/2 for d in derivatives])
    output_ranks = {
        'full_coefficient_basis':12,
        'Y_covariance':rank(tr(columns_y)),
        'Z_covariance':rank(tr(columns_z)),
        'current_forces':rank(tr(columns_g)),
        'Y_covariance_and_current_forces':rank(tr([a+b for a,b in zip(columns_y,columns_g)])),
        'Z_covariance_and_current_forces':rank(tr([a+b for a,b in zip(columns_z,columns_g)])),
    }
    initial_theta = theta_ref[:]
    initial_theta[0] += F(1,10)
    initial_j = precision(initial_theta,[x*x for x in initial_theta])
    initial_c = inverse(initial_j)
    initial_mu = mm(initial_c,h)
    initial_raw = add(initial_c,mm(initial_mu,tr(initial_mu)))
    ir = residual(initial_theta)
    initial_c0 = inverse(mm(tr(ir),ir))
    initial_g = [-sum((initial_raw[parent][k]*ir[child][k] for k in range(n)),F(0)) for child,parent in edges]
    initial_v = [-val/initial_c0[parent][parent] for val,(_,parent) in zip(initial_g,edges)]
    assert any(initial_v)
    result = {'status':'PASS','python':sys.version,'seconds':time.perf_counter()-start,
              'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'helper_sha256':hashlib.sha256(HELPER.read_bytes()).hexdigest(),
              'instance_kind':'admitted interior point, not an integrated trajectory',
              'ell':ell,'nu':nu,'variance':variance,'theta':theta,'output_ranks':output_ranks,
              'J':j,'h':h,'model_metric':metric,'structural_covector':g,
              'J_Y':jY,'h_Y':hY,'J_Z':jZ,'h_Z':hZ,
              'determinant_elimination_factors':[d1,d2,det(jZ)],
              'quadratic_elimination_shifts':[s1,s2],
              'posterior_prepared_initial_theta':initial_theta,
              'posterior_prepared_native_velocity':initial_v,
              'history_variance_t_cubed_coefficients':[v*v/3 for v in initial_v],
              'jacobian_Y_and_forces':tr([a+b for a,b in zip(columns_y,columns_g)])}
    (BASE/'result.json').write_text(json.dumps(helpers.jsonable(result),indent=2),encoding='utf-8')
    print(json.dumps({'status':'PASS','ranks':output_ranks,'seconds':result['seconds']}))


if __name__ == '__main__':
    main()
