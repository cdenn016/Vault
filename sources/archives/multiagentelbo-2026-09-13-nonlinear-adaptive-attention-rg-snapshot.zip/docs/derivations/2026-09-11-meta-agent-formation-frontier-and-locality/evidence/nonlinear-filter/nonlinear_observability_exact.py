"""Exact local differential test for omitted nonlinear filter memory."""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import time

BASE=Path(__file__).resolve().parent
SOURCE=BASE/'nonlinear_filter_exact.py'
spec=importlib.util.spec_from_file_location('nonlinear_filter_definitions',SOURCE)
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
Matrix=list[list[F]]


def nullspace(rows: Matrix) -> Matrix:
    work=[row[:] for row in rows]
    pivots=[]
    p=0
    for j in range(len(work[0])):
        at=next((i for i in range(p,len(work)) if work[i][j]),None)
        if at is None:
            continue
        work[p],work[at]=work[at],work[p]
        d=work[p][j]
        work[p]=[x/d for x in work[p]]
        for i in range(len(work)):
            if i!=p:
                d=work[i][j]
                work[i]=[x-d*y for x,y in zip(work[i],work[p])]
        pivots.append(j)
        p+=1
        if p==len(work):
            break
    vectors=[]
    for j in range(len(work[0])):
        if j not in pivots:
            v=[F(0) for _ in work[0]]
            v[j]=F(1)
            for i,pivot in enumerate(pivots):
                v[pivot]=-work[i][j]
            assert all(sum((x*y for x,y in zip(row,v)),F(0))==0 for row in rows)
            vectors.append(v)
    return vectors


def main() -> None:
    start=time.perf_counter()
    raw=json.loads((BASE/'result.json').read_text(encoding='utf-8'))
    j=[[F(x) for x in row] for row in raw['J']]
    h=[[F(x) for x in row] for row in raw['h']]
    theta=[F(x) for x in raw['theta']]
    c=a.inverse(j)
    n=len(j)
    r0=a.eye(n)
    for i in range(1,n,2):
        r0[i][i-1]=-F(1,2)
    linear,quadratic=[],[]
    r=[row[:] for row in r0]
    for value,i in zip(theta,range(2,n)):
        r[i][i-2]=-value
        u=[r0[i]]
        v=[[F(k==i-2) for k in range(n)]]
        linear.append(a.scale(a.add(a.mm(a.tr(u),v),a.mm(a.tr(v),u)),F(-1)))
        quadratic.append(a.mm(a.tr(v),v))
    hrow=[[F(1,2) if i in (2,3,6,7) else F(0) for i in range(n)]]
    k=a.add(a.mm(a.tr(r),r),a.scale(a.mm(a.tr(hrow),hrow),F(46656,600923)))
    FY=[[F(i==j) for j in range(n)] for i in [2,3,6,7]]
    FZ=[[F(1,2) if j in indices else F(0) for j in range(n)] for indices in [(2,6),(3,7)]]
    col_y,col_z,col_y_dot,col_z_dot=[],[],[],[]
    for b in linear+quadratic:
        dc=a.scale(a.mm(a.mm(c,b),c),F(-1))
        ddotc=a.add(a.add(dc,a.mm(a.mm(dc,k),c),F(-1)),a.mm(a.mm(c,k),dc),F(-1))
        col_y.append(a.upper(a.mm(a.mm(FY,dc),a.tr(FY))))
        col_z.append(a.upper(a.mm(a.mm(FZ,dc),a.tr(FZ))))
        col_y_dot.append(a.upper(a.mm(a.mm(FY,ddotc),a.tr(FY))))
        col_z_dot.append(a.upper(a.mm(a.mm(FZ,ddotc),a.tr(FZ))))
    current_y=[[F(x) for x in row] for row in raw['jacobian_Y_and_forces']]
    force_rows=current_y[-6:]
    current_z=a.tr(col_z)+force_rows
    y_dot_rows,z_dot_rows=a.tr(col_y_dot),a.tr(col_z_dot)
    ranks={'Y_and_forces':a.rank(current_y),'Z_and_forces':a.rank(current_z),
           'Y_forces_and_Y_velocity':a.rank(current_y+y_dot_rows),
           'Z_forces_and_Z_velocity':a.rank(current_z+z_dot_rows)}
    yn,zn=nullspace(current_y),nullspace(current_z)
    y_residual=a.mm(y_dot_rows,a.tr(yn))
    z_residual=a.mm(z_dot_rows,a.tr(zn))
    assert any(x for row in y_residual for x in row)
    assert a.rank(z_residual)==len(zn)
    assert ranks['Y_forces_and_Y_velocity']==12
    assert ranks['Z_forces_and_Z_velocity']==12
    result={'status':'PASS','python':sys.version,'seconds':time.perf_counter()-start,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'input_sha256':hashlib.sha256((BASE/'result.json').read_bytes()).hexdigest(),
            'ranks':ranks,'Y_current_nullspace':yn,'Y_velocity_on_nullspace':y_residual,
            'Z_current_nullspace':zn,'Z_velocity_on_nullspace':z_residual,
            'complete_root_jacobian':current_z+z_dot_rows,
            'scope':'smooth realizations over the open invariant coefficient family; not minimality over autonomous posterior-prepared reachable states'}
    (BASE/'observability-result.json').write_text(json.dumps(a.helpers.jsonable(result),indent=2),encoding='utf-8')
    print(json.dumps({'status':'PASS','ranks':ranks,'seconds':result['seconds']}))


if __name__=='__main__':
    main()
