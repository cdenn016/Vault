"""Exact integer-coordinate checks for the nonlinear entropy derivation."""

from fractions import Fraction
import json
from pathlib import Path


def inverse(matrix: list[list[int]]) -> list[list[Fraction]]:
    """Return an exact inverse by Gauss-Jordan elimination."""
    n = len(matrix)
    rows = [[Fraction(x) for x in row] +
            [Fraction(i == j) for j in range(n)]
            for i, row in enumerate(matrix)]
    for j in range(n):
        p = next(i for i in range(j, n) if rows[i][j])
        rows[j], rows[p] = rows[p], rows[j]
        pivot = rows[j][j]
        rows[j] = [x / pivot for x in rows[j]]
        for i in range(n):
            if i != j:
                scale = rows[i][j]
                rows[i] = [x - scale * y for x, y in zip(rows[i], rows[j])]
    return [row[n:] for row in rows]


def main() -> None:
    """Save exact matrix identities, not a numerical entropy claim."""
    # W = theta[3], phi_b[2], psi[3], phi_m[2].
    # X = theta[3], bridge[3], strong_b, strong_m, cut_b, cut_m.
    J = [
        [1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, -1, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, -1, 0, 0, 0],
        [0, 0, 1, 0, 0, 0, 0, -1, 0, 0],
        [1, -1, 0, -1, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 1, -1, 0, -1, 0],
        [0, 1, -1, 0, -1, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 1, -1, 0, -1],
    ]
    Ji = inverse(J)
    assert all(x.denominator == 1 for row in Ji for x in row)
    inverse_norm_squared = sum(x * x for row in Ji for x in row)
    keep = [0, 1, 2, 8, 9]
    E = [[row[j] for j in keep] for row in Ji]
    embedding_norm_squared = sum(x * x for row in E for x in row)
    assert inverse_norm_squared == 25
    assert embedding_norm_squared == 16
    payload = {
        "arithmetic": "Python int and Fraction, exact",
        "J": J,
        "J_inverse": [[int(x) for x in row] for row in Ji],
        "first_parent_embedding": [[int(x) for x in row] for row in E],
        "integer_inverse": True,
        "inverse_frobenius_norm_squared": int(inverse_norm_squared),
        "first_parent_embedding_frobenius_norm_squared": int(embedding_norm_squared),
        "fine_LSI_C_bound_from_circle_C_1000": 25000,
        "base_parent_LSI_C_bound_from_circle_C_1000": 16000,
        "scope": "Finite coordinate constants only; entropy proof is analytical.",
    }
    target = Path(__file__).with_name("matrix-results.json")
    target.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(target), "inverse_norm_squared": 25,
                      "embedding_norm_squared": 16}))


if __name__ == "__main__":
    main()
