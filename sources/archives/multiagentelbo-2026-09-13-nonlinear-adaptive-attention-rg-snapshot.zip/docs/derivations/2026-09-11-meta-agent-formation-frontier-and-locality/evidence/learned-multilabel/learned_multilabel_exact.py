"""Exact finite checks for the labeled learning and membership derivation."""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path
import hashlib
import json
import platform
import sys
import time


@dataclass(frozen=True)
class Radical:
    """Represent a + b sqrt(2) exactly."""
    a: F = F(0)
    b: F = F(0)

    def __add__(self, other: Radical | int | F) -> Radical:
        value = cast(other)
        return Radical(self.a + value.a, self.b + value.b)

    def __radd__(self, other: Radical | int | F) -> Radical:
        return self + other

    def __neg__(self) -> Radical:
        return Radical(-self.a, -self.b)

    def __sub__(self, other: Radical | int | F) -> Radical:
        return self + (-cast(other))

    def __rsub__(self, other: Radical | int | F) -> Radical:
        return cast(other) - self

    def __mul__(self, other: Radical | int | F) -> Radical:
        value = cast(other)
        return Radical(self.a * value.a + 2 * self.b * value.b,
                       self.a * value.b + self.b * value.a)

    def __rmul__(self, other: Radical | int | F) -> Radical:
        return self * other

    def __truediv__(self, other: Radical | int | F) -> Radical:
        value = cast(other)
        denominator = value.a**2 - 2 * value.b**2
        assert denominator != 0
        return self * Radical(value.a / denominator, -value.b / denominator)

    def __rtruediv__(self, other: Radical | int | F) -> Radical:
        return cast(other) / self

    def __pow__(self, exponent: int) -> Radical:
        assert exponent >= 0
        answer = cast(1)
        for _ in range(exponent):
            answer *= self
        return answer

    def sign(self) -> int:
        """Decide sign without approximate arithmetic."""
        if self.b == 0:
            return (self.a > 0) - (self.a < 0)
        if self.a == 0:
            return (self.b > 0) - (self.b < 0)
        if self.a * self.b > 0:
            return (self.a > 0) - (self.a < 0)
        difference = self.a**2 - 2 * self.b**2
        return ((difference > 0) - (difference < 0)) * ((self.a > 0) - (self.a < 0))

    def record(self) -> dict[str, str | float]:
        return {"rational": str(self.a), "sqrt2": str(self.b),
                "approximate_display": float(self.a) + float(self.b) * 2**0.5}


def cast(value: Radical | int | F) -> Radical:
    return value if isinstance(value, Radical) else Radical(F(value))


def multiply(values: list[Radical]) -> Radical:
    answer = cast(1)
    for value in values:
        answer *= value
    return answer


def beta_integral(alpha: Radical, beta: int) -> Radical:
    r"""Integrate p^(alpha-1) (1-p)^beta by binomial expansion."""
    return sum(((-1)**k * comb(beta, k) / (alpha + k)
                for k in range(beta + 1)), cast(0))


def moment(alpha: Radical, beta: int, order: int) -> Radical:
    r"""Compute E[p^order] from the beta rising-product ratio."""
    return multiply([(alpha + k) / (alpha + beta + 1 + k)
                     for k in range(order)])


def sequence_mass(alpha: Radical, successes: int, failures: int) -> Radical:
    r"""Integrate an ordered auxiliary flag string under Beta(alpha,2)."""
    return beta_integral(alpha + successes, 1 + failures) / beta_integral(alpha, 1)


EDGES = ((0, 1), (1, 2), (2, 3), (3, 0))


def components(flags: tuple[int, ...]) -> tuple[tuple[int, ...], ...]:
    labels = list(range(4))
    for (left, right), active in zip(EDGES, flags):
        if active:
            old, new = labels[right], labels[left]
            labels = [new if item == old else item for item in labels]
    return tuple(sorted(tuple(i for i in range(4) if labels[i] == label)
                        for label in set(labels)))


def main() -> dict[str, object]:
    started = time.perf_counter()
    zero, one = cast(0), cast(1)
    sqrt2 = Radical(F(0), F(1))
    alpha_internal, alpha_cut = 8 + 6 * sqrt2, 1 + sqrt2
    alphas = [alpha_internal, alpha_internal, alpha_cut, alpha_cut,
              alpha_internal, alpha_internal, alpha_cut, alpha_cut]
    alpha_cases = [cast(1), cast(2), cast(5), alpha_internal, alpha_cut]
    beta_checks = 0
    for alpha, beta, order in product(alpha_cases, range(4), range(5)):
        direct = beta_integral(alpha + order, beta) / beta_integral(alpha, beta)
        assert direct == moment(alpha, beta, order)
        assert direct.sign() > 0
        beta_checks += 1

    equilibrium = []
    for n, u in [(1, sqrt2), (8, 6 * sqrt2)]:
        alpha = u + n
        assert u**2 == cast(n * (n + 1))
        expected_D = 1 / alpha + 1 / (alpha + 1)
        assert expected_D == 1 / u
        assert u - u**2 * expected_D == zero
        derivative = 1 / u - 1 / (u + n) - 1 / (u + n + 1)
        assert derivative == zero
        curvature = 1 / u**2 - 1 / (u + n)**2 - 1 / (u + n + 1)**2
        assert curvature.sign() > 0
        equilibrium.append({"n": n, "u": u.record(),
                            "mean_mismatch": expected_D.record(),
                            "negative_log_evidence_curvature": curvature.record()})

    means = [moment(alpha, 1, 1) for alpha in alphas]
    q_means = [means[2*edge] * means[2*edge+1] for edge in range(4)]
    bond_law: dict[tuple[int, ...], Radical] = {}
    partition_law: dict[tuple[tuple[int, ...], ...], Radical] = {}
    pair = ((0, 1), (2, 3))
    first_panel_total = zero
    pair_mass = zero
    composite_mass = zero
    refined_merge_cases = 0
    for flags in product((0, 1), repeat=8):
        weight = multiply([means[j] if value else 1 - means[j]
                           for j, value in enumerate(flags)])
        bonds = tuple(flags[2*edge] * flags[2*edge+1] for edge in range(4))
        partition = components(bonds)
        first_panel_total += weight
        bond_law[bonds] = bond_law.get(bonds, zero) + weight
        partition_law[partition] = partition_law.get(partition, zero) + weight
        if partition != pair:
            continue
        pair_mass += weight
        for second in product((0, 1), repeat=4):
            if not (second[0] * second[1] or second[2] * second[3]):
                continue
            refined_merge_cases += 1
            full_weight = one
            for j, alpha in enumerate(alphas):
                values = [flags[j]]
                if j in (2, 3, 6, 7):
                    values.append(second[(2, 3, 6, 7).index(j)])
                full_weight *= sequence_mass(alpha, sum(values), len(values)-sum(values))
            composite_mass += full_weight
    assert first_panel_total == one
    assert sum(partition_law.values(), zero) == one
    assert len(bond_law) == 16 and len(partition_law) == 12
    for bonds, weight in bond_law.items():
        assert weight == multiply([q_means[e] if flag else 1-q_means[e]
                                   for e, flag in enumerate(bonds)])
        assert weight.sign() > 0

    def B(edge: int, steps: int) -> Radical:
        r"""Evaluate E[(1-p_b p_m)^steps] by exact expansion."""
        return sum(((-1)**k * comb(steps, k)
                    * moment(alphas[2*edge], 1, k)
                    * moment(alphas[2*edge+1], 1, k)
                    for k in range(steps+1)), zero)

    pair_formula = q_means[0]*q_means[2]*B(1, 1)*B(3, 1)
    composite_formula = q_means[0]*q_means[2]*(B(1, 1)*B(3, 1)-B(1, 2)*B(3, 2))
    assert pair_mass == pair_formula
    assert composite_mass == composite_formula
    correct_merge = composite_mass / pair_mass
    naive_merge = 1-(1-q_means[1])*(1-q_means[3])
    assert (naive_merge-correct_merge).sign() > 0
    survivals = [B(1, t+1)*B(3, t+1)/(B(1, 1)*B(3, 1)) for t in range(7)]
    assert survivals[0] == one
    assert survivals[1] == 1-correct_merge
    assert all((left-right).sign() > 0 for left, right in zip(survivals, survivals[1:]))
    tree_time_bound = sum((multiply([(alphas[2*e+x]+1)/(alphas[2*e+x]-1)
                                    for x in range(2)]) for e in (0, 1, 2)), zero)

    moment_rank_checks = 0
    for a, b in product((F(1), F(2), F(5)), (F(1), F(2), F(3))):
        s = a+b
        m1, m2 = a/s, a*(a+1)/(s*(s+1))
        recovered_s = (m1-m2)/(m2-m1*m1)
        assert recovered_s == s and m1*recovered_s == a
        denominator = s*(s+1)
        m1a, m1b = b/s**2, -a/s**2
        m2a = ((2*a+1)*denominator-a*(a+1)*(2*s+1))/denominator**2
        m2b = -a*(a+1)*(2*s+1)/denominator**2
        determinant = m1a*m2b-m1b*m2a
        assert determinant == -a*b/(s**3*(s+1)**2) and determinant != 0
        moment_rank_checks += 1

    # Four translation coordinates per physical edge; no commutative shortcut
    # is used to discard any labeled residual or the final loop.
    mu = [[F(4*i+j, 3) for j in range(4)] for i in range(4)]
    residual = [[F((e+1)*(j+2), 5) for j in range(4)] for e in range(4)]
    links = [[mu[i][j]-mu[k][j]-residual[e][j] for j in range(4)]
             for e, (i, k) in enumerate(EDGES)]
    g = [[F(0)]*4, [-x for x in links[0]], [F(0)]*4, [-x for x in links[2]]]
    cuts = [[links[e][j]+g[k][j]-g[i][j] for j in range(4)]
            for e, (i, k) in enumerate(EDGES) if e in (1, 3)]
    staged_loop = [cuts[0][j]+cuts[1][j] for j in range(4)]
    direct_loop = [sum((links[e][j] for e in range(4)), F(0)) for j in range(4)]
    assert staged_loop == direct_loop
    assert direct_loop == [-sum((residual[e][j] for e in range(4)), F(0))
                           for j in range(4)]
    assert any(direct_loop)
    mean_shift = (means[0]+means[6]) * F(3, 2) - F(3, 2)
    assert mean_shift.sign() > 0

    return {
        "status": "PASS",
        "runtime": {"version": platform.python_version(), "executable": sys.executable,
                    "elapsed_seconds": time.perf_counter()-started},
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "beta_moment_checks": beta_checks,
        "equilibria": equilibrium,
        "elementary_first_panels": 256,
        "bond_panels": len(bond_law),
        "supported_partitions": len(partition_law),
        "refined_composite_merge_cases": refined_merge_cases,
        "partition_law": {str(key): value.record() for key, value in sorted(partition_law.items())},
        "internal_bond_probability": q_means[0].record(),
        "cut_bond_probability": q_means[1].record(),
        "pair_probability": pair_mass.record(),
        "pair_then_merge_probability": composite_mass.record(),
        "conditional_next_merge_probability": correct_merge.record(),
        "incorrect_unconditioned_merge_probability": naive_merge.record(),
        "survival_probabilities_t0_to_t6": [value.record() for value in survivals],
        "full_absorption_tree_expectation_bound": tree_time_bound.record(),
        "moment_rank_checks": moment_rank_checks,
        "direct_and_staged_translation_loop": [str(value) for value in direct_loop],
        "example_conditional_regression_mean_shift": mean_shift.record(),
        "continuous_sample_arrays": [32, 24, 16],
        "model_filter_coordinates_each_level": 24,
        "fixed_dense_conditional_coefficients": 280,
        "limitations": "Finite exact checks; no ODE, empirical data, or general theorem certification."
    }


if __name__ == "__main__":
    result = main()
    target = Path(__file__).with_name("result.json")
    target.write_text(json.dumps(result, indent=2)+"\n", encoding="utf8")
    print(json.dumps(result, indent=2))

