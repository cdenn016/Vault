"""Complete partition-averaged coordinate counts; no preceding checks rerun."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import ast
import hashlib
import json
import platform
import runpy
import sys
import time

def main() -> dict[str, object]:
    started = time.perf_counter()
    directory = Path(__file__).parent
    support = runpy.run_path(str(directory / "learned_multilabel_exact.py"),
                            run_name="arithmetic_definitions_only")
    Radical, cast, moment = support["Radical"], support["cast"], support["moment"]
    source_result = json.loads((directory / "result.json").read_text(encoding="utf8"))
    assert source_result["status"] == "PASS"
    sqrt2 = Radical(F(0), F(1))
    alphas = [8+6*sqrt2, 1+sqrt2, 8+6*sqrt2, 1+sqrt2]
    expected_blocks = cast(0)
    for key, value in source_result["partition_law"].items():
        probability = Radical(F(value["rational"]), F(value["sqrt2"]))
        expected_blocks += len(ast.literal_eval(key)) * probability
    q = [moment(alpha, 1, 1)**2 for alpha in alphas]
    closed_form = 4 - sum(q, cast(0)) + support["multiply"](q)
    assert expected_blocks == closed_form
    costs = []
    previous = cast(40)
    for stage in range(7):
        opens = [
            1-sum(((-1)**k * comb(stage,k)*moment(alpha,1,k)**2
                   for k in range(stage+1)), cast(0))
            for alpha in alphas
        ]
        blocks = 4-sum(opens,cast(0))+support["multiply"](opens)
        sample_array = 8+8*blocks
        sampler_coordinates = 16+4*blocks
        assert (previous-sample_array).sign() >= 0
        previous = sample_array
        if stage == 1:
            assert blocks == expected_blocks
            assert (cast(32)-sample_array).sign() > 0
        costs.append({"stage":stage,"expected_blocks":blocks.record(),
                      "expected_continuous_sample_array":sample_array.record(),
                      "expected_continuous_sampler_variables":sampler_coordinates.record()})
    return {
        "status":"PASS",
        "runtime":{"version":platform.python_version(),"executable":sys.executable,
                   "elapsed_seconds":time.perf_counter()-started},
        "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "source_result_sha256":hashlib.sha256((directory/"result.json").read_bytes()).hexdigest(),
        "expected_blocks_from_full_partition_law":expected_blocks.record(),
        "stage_costs":costs,
        "fine_continuous_coordinates":32,
        "unchanged_model_filter_coordinates":24,
        "unchanged_fixed_dense_conditional_coefficients":280,
        "discrete_history":"Same finite panel/root/tree/incidence history in the compared augmented experiments.",
        "limitations":"Real-coordinate counts and a generative recipe, not bit cost or executed sampling/runtime."
    }

if __name__ == "__main__":
    result=main()
    Path(__file__).with_name("cost-result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(json.dumps(result,indent=2))

