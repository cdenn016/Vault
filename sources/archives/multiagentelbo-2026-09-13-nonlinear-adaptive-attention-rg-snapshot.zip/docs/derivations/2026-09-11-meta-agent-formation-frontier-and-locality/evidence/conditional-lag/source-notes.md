# Source and execution scope

September 12, 2026. The assigned contract is `contract-sha256-b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c`. The mathematical evidence is `../../conditional-lag-and-parent-vfe.md`; no claim-ledger closure is assigned here.

The repository and live-vault source sections consulted are listed in Section 1 of that document. The live source consultation was read-only. The exact fast Gram matrices are provided by the other lane's `../endogenous-rates/matrix-results.json`; this lane did not rerun its calculation.

The targeted primary-source search retrieved [Legoll and Lelièvre, Effective dynamics using conditional expectations, arXiv:0906.4865](https://arxiv.org/pdf/0906.4865). Its introductory assumptions and scope distinguish invariant coarse laws, dynamic closure, conditional entropy, and the choice of reaction coordinate. It does not select the present residual map. The paper is methodological context rather than a substitute for the displayed proof.

The curvature-to-log-Sobolev source is [Bakry and Émery, Diffusions hypercontractives](https://eudml.org/doc/113511). A separately retrieved [2002 lecture treatment](https://www.numdam.org/article/SPS_2002__36__1_0.pdf), Theorem 4.16 and the calculation on printed pages 45–48, was used to check the semigroup convention. The assigned derivation supplies the exact inequality, coefficient, convex-domain qualification, and entropy calculation itself. No quotation is reproduced.

The standard-library calculation `constants_check.py` evaluates the explicitly stated trigonometric margin and algebraic Gram eigenvalues. Its only numerical authority is those finite expressions. The exact margin also has an elementary rational check: for `rho=7/5`, `cos rho <= 1-rho^2/2+rho^4/24`, while `4 sin(1/6) < 2/3`. Consequently `1-cos rho > 2/3 > 4 sin(1/6)` because `rho^2/2-rho^4/24 = 12299/15000 > 2/3`. This rational lower bound is independent of floating-point rounding.

No trajectory experiment, full suite, GPU calculation, historical rerun, Lean proof, tamper check, or Research-vault modification is part of this evidence.
