"""Check one rational instance of the Gaussian lag identities."""

from fractions import Fraction
import json
from pathlib import Path
import sys


def main() -> None:
    """Write exact rational checks without a floating-point matrix solver."""
    c = Fraction(2)
    b = Fraction(1)
    a = Fraction(3)
    m_y = Fraction(1)
    m_z = Fraction(2)
    schur = c - b * b / a
    theta = m_z + b * m_y / a
    dot_m_y = -c * m_y - b * m_z
    dot_m_z = -b * m_y - a * m_z
    dot_theta_direct = dot_m_z + b * dot_m_y / a
    dot_theta_formula = -(a + b * b / a) * theta - b * schur * m_y / a
    energy_derivative_direct = a * theta * dot_theta_direct
    energy_derivative_formula = -(a * a + b * b) * theta * theta - theta * b * schur * m_y
    fine_energy = c * m_y * m_y + 2 * b * m_y * m_z + a * m_z * m_z
    completed_energy = a * theta * theta + schur * m_y * m_y
    checks = {
        "theta_equation": dot_theta_direct == dot_theta_formula,
        "weighted_energy_derivative": energy_derivative_direct == energy_derivative_formula,
        "schur_energy_completion": fine_energy == completed_energy,
        "positive_definite_instance": a > 0 and schur > 0,
    }
    result = {
        "scope": "One exact 2-by-2 rational instance; not proof of the general theorem",
        "python": sys.version,
        "arithmetic": "fractions.Fraction",
        "H": [[str(c), str(b)], [str(b), str(a)]],
        "mean": [str(m_y), str(m_z)],
        "schur": str(schur),
        "theta": str(theta),
        "dot_theta": str(dot_theta_direct),
        "half_weighted_energy_derivative": str(energy_derivative_direct),
        "fine_energy": str(fine_energy),
        "checks": checks,
    }
    Path(__file__).with_name("gaussian-check-result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))
    if not all(checks.values()):
        raise ArithmeticError("The displayed rational instance did not satisfy an identity")


if __name__ == "__main__":
    main()
