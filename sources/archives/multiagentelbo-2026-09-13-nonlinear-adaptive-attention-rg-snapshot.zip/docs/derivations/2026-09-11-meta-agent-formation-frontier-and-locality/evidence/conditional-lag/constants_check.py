"""Evaluate the displayed compact entropy constants; this is not a proof."""

import json
import math
from pathlib import Path
import sys


def main() -> None:
    """Record the barrier margin and exact-expression spectral constants."""
    rho = 7.0 / 5.0
    barrier = 1.0 - math.cos(rho)
    tilt_bound = 4.0 * math.sin(1.0 / 6.0)
    lambda_min_c = (5.0 - math.sqrt(17.0)) / 2.0
    lambda_max_c = (5.0 + math.sqrt(17.0)) / 2.0
    result = {
        "scope": "Floating-point evaluations of exact expressions in the derivation",
        "python": sys.version,
        "rho": rho,
        "barrier_1_minus_cos_rho": barrier,
        "two_edge_tilt_upper_4_sin_1_over_6": tilt_bound,
        "barrier_minus_tilt": barrier - tilt_bound,
        "cos_rho": math.cos(rho),
        "lambda_min_C": lambda_min_c,
        "lambda_max_C": lambda_max_c,
        "T_H_upper_from_equation_43": (barrier - tilt_bound) / (2.0 * lambda_max_c),
        "second_parent_proposed_tilt_4_sin_5_over_36": 4.0 * math.sin(5.0 / 36.0),
        "checks": {
            "convex_cube": 0.0 < rho < math.pi / 2.0,
            "strict_barrier_margin": barrier > tilt_bound,
            "positive_fast_gram": lambda_min_c > 0.0,
        },
        "not_claimed": [
            "A floating-point inequality proves the general entropy theorem",
            "The compact second-stage inherited entropy interface is completed",
        ],
    }
    output = Path(__file__).with_name("constants-result.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
