"""Exact native conditional predictions and full variance-map inventory."""
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform
import sys
import time

sys.set_int_max_str_digits(200000)
folder=Path(__file__).parent
helper_path=folder.parent/'shared-parent-record/shared_parent_exact.py'
spec=importlib.util.spec_from_file_location('existing_record_integral_definitions',helper_path)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)  # Definitions only; the guarded main is not executed.
h=g.helper
Matrix=list[list[F]]
Key=tuple[tuple[F,...],...]


def key(matrix: Matrix) -> Key:
    return tuple(tuple(row) for row in matrix)


@lru_cache(maxsize=None)
def moment(gamma: Key, powers: tuple[int,...]) -> F:
    r"""Return the exact Gaussian moment det(I + Gamma diag(powers))**(-1)."""
    return g.moment([list(row) for row in gamma],powers)


@lru_cache(maxsize=None)
def shifted_evidence(gamma: Key, edge: int, exponent: int) -> F:
    r"""Integrate p_edge**exponent times the original one-channel likelihood."""
    result=sum(((-1)**sum(bits)*moment(gamma,tuple(g.N[j]+bits[j]+exponent*(j==edge) for j in range(4)))
                for bits in product((0,1),repeat=4)),F(0))
    assert result>0
    return result


def main() -> None:
    start=time.perf_counter()
    source=folder.parent/'transported-parent-prior/result.json'
    data=json.loads(source.read_text(encoding='utf-8'))
    jet_path=folder.parent/'finite-coherence-classification/native-jet.json'
    jet=json.loads(jet_path.read_text(encoding='utf-8'))
    lap=h.multiply(g.B,h.transpose(g.B))
    full_maps={}
    unit_maps=set()
    rows=[]
    for original in data['rows']:
        labels=original['labels'];k=original['k']
        incidence=[[F(labels[i]==j) for j in range(k)] for i in range(4)]
        j_map=h.multiply(g.B,incidence)
        gb=h.multiply(j_map,h.transpose(j_map))
        first=[F(0)]*4;second=[F(0)]*4;cross=[F(0)]*4
        full_ids=[]
        base=F(original['evidence'])
        count=len(original['details'])
        assert sum((F(dec['one_channel_evidence'])**2 for dec in original['details']),F(0))/count==base
        for dec in original['details']:
            gamma=[[F(v) for v in line] for line in dec['Gamma']]
            c_map=[[F(v) for v in line] for line in dec['C']]
            gc=h.multiply(c_map,h.transpose(c_map))
            assert gamma==[[lap[i][j]+gb[i][j]+gc[i][j] for j in range(4)] for i in range(4)]
            gamma_key=key(gamma)
            unit_maps.add(gamma_key)
            full_key=(key(gb),key(gc))
            if full_key not in full_maps:
                full_maps[full_key]=len(full_maps)
            full_ids.append(full_maps[full_key])
            e0=F(dec['one_channel_evidence'])
            for edge in range(4):
                e1=shifted_evidence(gamma_key,edge,1)
                e2=shifted_evidence(gamma_key,edge,2)
                first[edge]+=e1*e0/count/base
                second[edge]+=e2*e0/count/base
                cross[edge]+=e1**2/count/base
        variances=[m2-m1*m1 for m1,m2 in zip(first,second)]
        cross_covariances=[mxy-m1*m1 for m1,mxy in zip(first,cross)]
        assert all(0<v<1 for v in first)
        assert all(v>0 for v in variances)
        assert all(v>=0 for v in cross_covariances)
        panels=[]
        for m1,m2,var in zip(first,second,variances):
            actual=[1-2*m1+m2,m1-m2,m1-m2,m2]
            iid=[(1-m1)**2,(1-m1)*m1,(1-m1)*m1,m1*m1]
            assert min(actual)>0 and sum(actual)==1
            tv=sum(abs(a-b) for a,b in zip(actual,iid))/2
            assert tv==2*var
            panels.append({'ordered_outcomes':['00','01','10','11'],'probabilities':[str(v) for v in actual],'tv_to_matched_iid':str(tv)})
        rows.append({'partition':original['partition'],'k':k,'evidence':str(base),
                     'conditional_mean_probabilities':[str(v) for v in first],
                     'conditional_mean_probabilities_float':[float(v) for v in first],
                     'conditional_second_moments':[str(v) for v in second],
                     'conditional_probability_variances':[str(v) for v in variances],
                     'conditional_probability_variances_float':[float(v) for v in variances],
                     'same_label_cross_channel_covariances':[str(v) for v in cross_covariances],
                     'two_repeated_record_laws':panels,
                     'decorated_full_covariance_map_indices':full_ids,
                     'distinct_full_covariance_maps':len(set(full_ids))})
    pair=next(row for row in rows if row['partition']==[[0,1],[2,3]])
    root=next(row for row in rows if row['k']==1)
    difference=[F(a)-F(b) for a,b in zip(pair['conditional_mean_probabilities'],root['conditional_mean_probabilities'])]
    separation=max(abs(v) for v in difference)
    assert separation>0
    root_jet=next(row for row in jet['rows'] if row['k']==1)
    ma=1+F(root_jet['velocity'][0]);mc=1+F(root_jet['velocity'][2])
    likelihood_max=F(1)
    for n in g.N:
        likelihood_max*=F(n**n,(n+1)**(n+1))**2
    assert 0<F(root['evidence'])<likelihood_max<1
    result={'status':'PASS','runtime':sys.executable,'python':platform.python_version(),
            'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':sha256(source.read_bytes()).hexdigest(),
            'jet_input_sha256':sha256(jet_path.read_bytes()).hexdigest(),'helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),
            'matrix_helper_sha256':sha256(g.HELPER.read_bytes()).hexdigest(),
            'scope':'All twelve unit-posterior conditional ancestries; future predictions use the same static latent probabilities and original record kernel. No observations were generated.',
            'connected_partitions':len(rows),'decorations':sum(len(row['decorated_full_covariance_map_indices']) for row in rows),
            'unit_covariances':len(unit_maps),'full_covariance_maps':len(full_maps),
            'full_map_coefficients':[{'index':index,'b_matrix':[[str(v) for v in line] for line in full_key[0]],'c_matrix':[[str(v) for v in line] for line in full_key[1]]} for full_key,index in full_maps.items()],
            'recognition_likelihood_power':'s=1 is invariant for the current exact-posterior preparation; moment integrals keep the sixteen-term finite expansion at every inference time.',
            'pair_minus_root_predictive_means':[str(v) for v in difference],
            'pair_minus_root_predictive_means_float':[float(v) for v in difference],
            'maximum_marginal_response_separation':str(separation),'maximum_marginal_response_separation_float':float(separation),
            'initial_pair_root_tie_prior_ratio_pi_pair_over_pi_root':str(F(root['evidence'])/F(pair['evidence'])),
            'initial_pair_root_tie_prior_ratio_float':float(F(root['evidence'])/F(pair['evidence'])),
            'finite_horizon_bounds':{'original_likelihood_supremum':str(likelihood_max),'root_evidence_at_unit':root['evidence'],
                                     'root_unit_energy_means_a_c':[str(ma),str(mc)],'root_jensen_constant_8_times_sum':str(8*(ma+mc)),
                                     'native_odds_acceleration_lower_bound':jet['log_ancestry_odds_second_derivative_lower_bound']},
            'rows':rows,'gaussian_moment_cache':{'hits':moment.cache_info().hits,'misses':moment.cache_info().misses},
            'elapsed_seconds':time.perf_counter()-start,
            'not_run':['ODE','parameter search','numerical ancestry prior selection','fitting','new observations','sampling','GPU','test suite','Lean','tamper checks','previous helper mains']}
    (folder/'predictive-moments.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','connected_partitions','decorations','unit_covariances','full_covariance_maps','pair_minus_root_predictive_means_float','maximum_marginal_response_separation_float','initial_pair_root_tie_prior_ratio_float','elapsed_seconds')},indent=2))
    print('pair predictive means',pair['conditional_mean_probabilities_float'])
    print('pair probability variances',pair['conditional_probability_variances_float'])
    print('full covariance count for pair/root',pair['distinct_full_covariance_maps'],root['distinct_full_covariance_maps'])


if __name__=='__main__':
    main()
