"""Inspect the response cost reports and source bindings without rerunning science."""
from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess
import sys
import time

ROOT = Path("C:/tmp/elbo-cover-20260908")
B = ROOT / "docs/derivations/2026-09-11-meta-agent-formation-frontier-and-locality"
OUT = B / "evidence/selected-hierarchy-response-cost"


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main() -> None:
    started = time.perf_counter()
    baseline = read(B / "evidence/completion-reconciliation/baseline.json")
    previous = read(B / "evidence/selected-hierarchy-response/inspection.json")
    native = read(B / "evidence/native-coherence-response/inspection.json")
    expected_reports = {}
    for name in ("completion-reconciliation", "coherence-response", "native-coherence-response", "selected-hierarchy-response"):
        receipt = read(B / f"evidence/{name}/inspection.json")
        for path, expected in receipt["new_report_sha256"].items():
            target = ROOT / path if path.startswith("docs") else B / path
            expected_reports[str(target)] = expected
    report_preservation = {p: digest(Path(p)) == h for p, h in expected_reports.items()}
    evidence_preservation = {}
    for directory, receipt in (("native-coherence-response", native), ("selected-hierarchy-response", previous)):
        for name, expected in receipt["new_evidence_sha256"].items():
            target = B / f"evidence/{directory}" / name
            evidence_preservation[str(target)] = digest(target) == expected
    changed = [p for p, h in baseline["files"].items() if digest(ROOT / p) != h]
    external = {p: digest(Path(p)) == h for p, h in baseline["external_sources"].items()}
    result = read(OUT / "cost-maps.json")
    sources = {p: digest(B / p) == h for p, h in result["source_sha256"].items()}
    cases = result["by_k_q"]
    checks = {
        "execution_status": result["status"] == "PASS_EXACT_RESPONSE_OPERATION_COUNTS",
        "executed_script_binding": digest(OUT / "cost_maps.py") == result["script_sha256"],
        "isolated_runtime": result["python"] == "3.14.7" and result["isolated"] == 1 and result["dont_write_bytecode"] == 1,
        "176_saved_maps": result["maps"] == sum(r["map_cases"] for r in cases) == 176,
        "416_saved_ports": result["decoder_port_cases"] == sum(r["old_port_decoder_cases"] for r in cases) == 416,
        "all_count_classes": [(r["k"],r["q"]) for r in cases] == [(k,q) for k in range(1,5) for q in range(1,k+1)],
        "reported_map_maxima": result["maxima"]["augmented_assembly_4d"] == {"multiply":52,"add":60},
        "reported_decoder_maxima": result["maxima"]["old_port_decoder_2d"] == {"multiply":8,"add":8},
    }
    reports = ["selected-hierarchy-response-cost.md", "selected-hierarchy-response-cost-law.md",
               "selected-hierarchy-response-cost-calculation.md", "selected-hierarchy-response-cost-reconstruction.md"]
    links, formatting = [], []
    for name in reports:
        content = (B / name).read_text(encoding="utf-8-sig")
        for number, line in enumerate(content.splitlines(), 1):
            if line.rstrip() != line or any(token in line for token in ("\\;", "\\,", "\\!")):
                formatting.append({"report":name,"line":number})
        for raw in re.findall(r"\]\(([^\n)]+)\)", content):
            target = raw.strip("<>")
            if target.startswith(("http://", "https://", "#")):
                continue
            path = Path(target.split("#", 1)[0])
            if not path.is_absolute():
                path = B / path
            links.append({"report":name,"target":target,"exists":path.exists(),
                          "inspection_output":path.resolve() == (OUT / "inspection.json").resolve()})
    reconstruction = (B / reports[-1]).read_text(encoding="utf-8-sig")
    reconstruction_bindings = {name:digest(B / name) in reconstruction for name in reports[:3]}
    reconstruction_bindings.update({f"evidence/selected-hierarchy-response-cost/{name}":digest(OUT / name) in reconstruction
                                    for name in ("cost_maps.py","cost-maps.json")})
    head = subprocess.check_output(["git","-C",str(ROOT),"rev-parse","HEAD"],text=True).strip()
    diff = subprocess.run(["git","-C",str(ROOT),"diff","--check"],capture_output=True,text=True)
    unexpected = sorted(set(changed) - set(previous["modified_existing"]))
    passed = (not unexpected and all(external.values()) and all(report_preservation.values())
              and all(evidence_preservation.values()) and all(sources.values()) and all(checks.values())
              and all(reconstruction_bindings.values()) and not formatting
              and all(r["exists"] or r["inspection_output"] for r in links)
              and head == baseline["head"] and diff.returncode == 0)
    receipt = {
        "status":"PASS" if passed else "FAIL",
        "scope":"Saved-output, source-hash, report-binding, preservation, link and formatting inspection. No scientific/counting script rerun, mathematical proof by test, or formal ledger certificate.",
        "runtime":sys.executable, "python":sys.version.split()[0], "head":head,
        "baseline_count":len(baseline["files"]), "unchanged_count":len(baseline["files"])-len(changed),
        "modified_existing":changed, "unexpected_changes":unexpected,
        "external_sources_unchanged":external, "earlier_reports_unchanged":report_preservation,
        "earlier_response_evidence_unchanged":evidence_preservation,
        "cost_result_source_bindings":sources, "checks":checks,
        "reconstruction_bindings":reconstruction_bindings, "local_links":links,
        "formatting_findings":formatting,
        "new_report_sha256":{name:digest(B / name) for name in reports},
        "new_evidence_sha256":{p.name:digest(p) for p in sorted(OUT.iterdir())
                               if p.is_file() and p.name not in ("inspection.json","inspection-stdout-stderr.txt")},
        "git_diff_check":{"exit_code":diff.returncode,"stdout":diff.stdout,"stderr":diff.stderr},
        "elapsed_seconds":time.perf_counter()-started
    }
    (OUT / "inspection.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:receipt[k] for k in ("status","baseline_count","unchanged_count","unexpected_changes","elapsed_seconds")}))
    print(json.dumps({"failed_checks":[k for k,v in checks.items() if not v],
                      "failed_reconstruction_bindings":[k for k,v in reconstruction_bindings.items() if not v],
                      "formatting_findings":formatting}))
    assert passed, "Inspect inspection.json for the specific unmet check."


if __name__ == "__main__":
    main()

