"""One mechanical operation count over saved exact response maps; no science replay."""
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys
import time

HERE = Path(__file__).resolve().parent
B = HERE.parents[1]
INPUT = B / "evidence/selected-hierarchy-response/response-maps.json"
OLD = B / "evidence/joint-native-episode/uniform-panel-geometry.json"
FIELDS = ("partition", "roots", "trees", "active_mask")
Cost = dict[str, int]

def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()

def case_key(row: dict) -> str:
    return json.dumps({k: row[k] for k in FIELDS}, sort_keys=True, separators=(",", ":"))

def linear_cost(rows: list[list[str]], repeats: int) -> Cost:
    r"""Literal scalar-coefficient matrix evaluation, independently per coordinate."""
    coefficients = [[Fraction(v) for v in row] for row in rows]
    return {
        "multiply": repeats * sum(v != 0 and v != 1 for row in coefficients for v in row),
        "add": repeats * sum(max(0, sum(v != 0 for v in row) - 1) for row in coefficients),
    }

def maximum(rows: list[dict], key: str) -> int:
    return max((row[key] for row in rows), default=0)

def main() -> None:
    start = time.perf_counter()
    data = json.loads(INPUT.read_text(encoding="utf-8"))
    old = json.loads(OLD.read_text(encoding="utf-8"))
    assert data["status"] == "PASS_SELECTED_HIERARCHY_RESPONSE_MAPS"
    assert old["status"] == "PASS_UNIFORM_SECOND_PANEL_GEOMETRY"
    source_rows = data["panel_response_maps"]
    old_by_key = {case_key(row): row for row in old["rows"]}
    assert len(source_rows) == len(old_by_key) == 176
    cases = []
    ports = []
    for index, row in enumerate(source_rows):
        k, q = row["k"], row["q"]
        source = old_by_key[case_key(row)]
        matrix = row["augmented_second_map"]
        assert len(matrix) == k + q and all(len(r) == 2*k for r in matrix)
        assert matrix[:2*q] == source["geometry_map"]
        assembly = linear_cost(matrix, 4)
        selected = row["stored_tree_response_edges"]
        assert len(selected) == k-q
        # This compares the newly counted augmented map with retained old metadata.
        assert assembly["multiply"] == source["geometry_multiply"] + 8*(k-q)
        assert assembly["add"] == source["geometry_add"] + 8*(k-q)
        identifiers = {f: row[f] for f in FIELDS}
        one = {"case_index": index, **identifiers, "k": k, "q": q,
               "input_width_per_coordinate": 2*k, "output_width_per_coordinate": k+q,
               "displayed_fields": row["displayed_fields"],
               "assembly_4d": assembly, "old_geometry_cost_from_saved_record": {
                   "multiply": source["geometry_multiply"], "add": source["geometry_add"]},
               "forest_additional_cost": {"multiply": 8*(k-q), "add": 8*(k-q)},
               "stored_tree_response_edges": selected, "decoder_2d_by_old_cut": {}}
        assert set(row["response_decoder"]) == {str(e) for e in source["cut_labels"]}
        for edge, coefficients in row["response_decoder"].items():
            assert len(coefficients) == k+q
            cost = linear_cost([coefficients], 2)
            values = [Fraction(v) for v in coefficients]
            item = {"case_index": index, "old_cut_label": int(edge), "k": k, "q": q,
                    **cost, "nonzero_coefficients": sum(v != 0 for v in values),
                    "nonunit_nonzero_coefficients": sum(v != 0 and v != 1 for v in values)}
            ports.append(item)
            one["decoder_2d_by_old_cut"][edge] = cost
        one["decoder_2d_componentwise_max"] = {
            "multiply": maximum(list(one["decoder_2d_by_old_cut"].values()), "multiply"),
            "add": maximum(list(one["decoder_2d_by_old_cut"].values()), "add")}
        cases.append(one)
    assert len(ports) == 416
    maxima = {
        "augmented_assembly_4d": {
            "multiply": max(r["assembly_4d"]["multiply"] for r in cases),
            "add": max(r["assembly_4d"]["add"] for r in cases)},
        "old_port_decoder_2d": {"multiply": maximum(ports, "multiply"), "add": maximum(ports, "add")},
    }
    by_k_q = []
    for k, q in sorted({(r["k"], r["q"]) for r in cases}):
        subset = [r for r in cases if (r["k"], r["q"]) == (k, q)]
        psubset = [r for r in ports if (r["k"], r["q"]) == (k, q)]
        by_k_q.append({"k": k, "q": q, "map_cases": len(subset), "old_port_decoder_cases": len(psubset),
                       "assembly_4d": {op: max(r["assembly_4d"][op] for r in subset) for op in ("multiply", "add")},
                       "decoder_2d": {op: maximum(psubset, op) for op in ("multiply", "add")}})
    witnesses = {
        "assembly_multiply": next(r["case_index"] for r in cases if r["assembly_4d"]["multiply"] == maxima["augmented_assembly_4d"]["multiply"]),
        "assembly_add": next(r["case_index"] for r in cases if r["assembly_4d"]["add"] == maxima["augmented_assembly_4d"]["add"]),
        "decoder_multiply": next(r for r in ports if r["multiply"] == maxima["old_port_decoder_2d"]["multiply"]),
        "decoder_add": next(r for r in ports if r["add"] == maxima["old_port_decoder_2d"]["add"]),
    }
    # Explicit new scalar schedule after decoding one two-coordinate residual.
    schedule = [
        {"step": "d_plus_h", "multiply": 0, "add": 2, "exp": 0, "uniform": 0, "compare": 0},
        {"step": "two_square_sums", "multiply": 4, "add": 2, "exp": 0, "uniform": 0, "compare": 0},
        {"step": "two_minus_half_scales", "multiply": 2, "add": 0, "exp": 0, "uniform": 0, "compare": 0},
        {"step": "two_exponentials", "multiply": 0, "add": 0, "exp": 2, "uniform": 0, "compare": 0},
        {"step": "minus_one_times_unshifted_phi", "multiply": 1, "add": 0, "exp": 0, "uniform": 0, "compare": 0},
        {"step": "sum_anchor_shifted_and_negative_unshifted", "multiply": 0, "add": 2, "exp": 0, "uniform": 0, "compare": 0},
        {"step": "clip_to_unit_interval", "multiply": 0, "add": 0, "exp": 0, "uniform": 0, "compare": 2},
        {"step": "draw_one_bernoulli", "multiply": 0, "add": 0, "exp": 0, "uniform": 1, "compare": 1},
    ]
    operations = ("multiply", "add", "exp", "uniform", "compare")
    remainder = {op: sum(s[op] for s in schedule) for op in operations}
    query = dict(remainder)
    for op in ("multiply", "add"):
        query[op] += maxima["old_port_decoder_2d"][op]
    first_bound = {"multiply": 52, "add": 80}
    # Per cut: 4-coordinate d row evaluation 8M8A, two phis 6M2A2exp,
    # then their product 1M, one uniform, one comparison.
    panel = {"multiply": 60, "add": 40, "exp": 8, "uniform": 4, "compare": 4}
    assembly_bound = dict(panel)
    for op in ("multiply", "add"):
        assembly_bound[op] += first_bound[op] + maxima["augmented_assembly_4d"][op]
    sources = [
        INPUT, OLD,
        B/"evidence/selected-hierarchy-response/response_maps.py",
        B/"evidence/joint-native-episode/uniform_panel_geometry.py",
        B/"selected-hierarchy-response-interface.md",
        B/"selected-hierarchy-response.md",
        B/"common-prior-native-hierarchy-episodes.md",
        B/"native-episode-resource-frontier.md",
    ]
    result = {
        "status": "PASS_EXACT_RESPONSE_OPERATION_COUNTS",
        "scope": "One new literal-operation count over saved 176 exact augmented maps and 416 old-cut decoders; no old module imported and no scientific main replayed.",
        "runtime": sys.executable, "python": platform.python_version(),
        "isolated": sys.flags.isolated, "dont_write_bytecode": sys.flags.dont_write_bytecode,
        "command": [sys.executable, "-I", "-B", str(Path(__file__).resolve())],
        "script_sha256": digest(Path(__file__)),
        "source_sha256": {str(p.relative_to(B)): digest(p) for p in sources},
        "convention": {
            "linear_forms": "Ignore zero coefficients; assignments and coefficient +1 are free; every other nonzero coefficient, including -1, costs one multiplication; n nonzero terms cost max(n-1,0) additions.",
            "coordinates": "Four-coordinate assembly; an old-port query decodes both coordinates of one selected channel.",
            "nonlinear": "A square costs one multiplication, coefficient -1/2 one multiplication, explicit minus-one scaling one multiplication, and clamp selection uses two comparisons with free assignments.",
            "sampling": "One ideal uniform and one comparison per valid Bernoulli answer; input h is already in the queried edge's target-minus-source orientation.",
            "excluded": "Memory traffic, labels, lookup/control, metadata, controller/transcript, rational coefficient storage, exponent implementation internals, reference-law evaluation and native solver costs are separately priced.",
        },
        "maps": len(cases), "decoder_port_cases": len(ports),
        "maxima": maxima, "maximum_witnesses": witnesses, "by_k_q": by_k_q,
        "anchored_query_remainder_schedule": schedule,
        "anchored_query_remainder": remainder,
        "complete_valid_one_channel_query_upper": query,
        "endpoint_input_conversion_extra": {"multiply": 2, "add": 2},
        "first_parent_assembly_inherited_upper": first_bound,
        "literal_panel_upper": panel,
        "composed_parent_only_assembly_upper": assembly_bound,
        "null_query": "No floating arithmetic, exponentials or Bernoulli random draw; dispatch/validity costs remain external.",
        "cases": cases, "ports": ports,
        "elapsed_seconds": time.perf_counter()-start,
        "not_run": ["old modules or mains", "old science", "new observations", "parameter fitting", "ODE", "test suite", "GPU", "Lean", "tamper checks", "history enumeration", "benchmark"],
    }
    (HERE/"cost-maps.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in (
        "status", "maps", "decoder_port_cases", "maxima", "by_k_q",
        "anchored_query_remainder", "complete_valid_one_channel_query_upper",
        "literal_panel_upper", "composed_parent_only_assembly_upper", "elapsed_seconds")}, indent=2))

if __name__ == "__main__":
    main()
