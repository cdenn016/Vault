"""Exact normal-Hessian determinant for the two-dimensional logarithmic sector."""
from fractions import Fraction as F
from pathlib import Path
import itertools
import json
import runpy
import sys

Matrix = list[list[F]]


def diagonal(values: list[F]) -> Matrix:
    return [[v if i == j else F(0) for j in range(len(values))] for i, v in enumerate(values)]


def normal_jacobian(edges: list[tuple[int, int]], signs: tuple[int, int],
                    radius: F, n: int) -> Matrix:
    r"""Linearize B-I, tree-relative means, and zeta_l=r*a_l at u=r*e1."""
    E = len(edges)
    beta = E - n + 1
    variables = ([('B', e, c) for e in range(E) for c in range(3)]
                 + [('delta', i, c) for i in range(1, n) for c in range(2)]
                 + [('zeta', j, 0) for j in range(beta)])
    columns = []
    for kind, index, component in variables:
        S = [[[F(0), F(0)], [F(0), F(0)]] for _ in edges]
        delta = [[F(0), F(0)] for _ in range(n)]
        zeta = [F(0) for _ in range(beta)]
        if kind == 'B':
            if component == 0:
                S[index][0][0] = F(1)
            elif component == 1:
                S[index][0][1] = S[index][1][0] = F(1)
            else:
                S[index][1][1] = F(1)
        elif kind == 'delta':
            delta[index][component] = F(1)
        else:
            zeta[index] = F(1)
        column = []
        for e, (i, j) in enumerate(edges):
            chord = e - (n - 1)
            sign = 1 if chord < 0 else signs[chord]
            column.append(delta[i][0] - delta[j][0] + radius * S[e][0][0])
            column.append(delta[i][1] - sign * delta[j][1] + radius * S[e][1][0]
                          - (F(0) if chord < 0 else zeta[chord]))
        columns.append(column)
    return [list(row) for row in zip(*columns)]


def main() -> None:
    r"""Verify Delta(r)=2^(3E)*tau*prod(w)^4*(1+r^2/2)^2 in Frobenius coordinates."""
    support = runpy.run_path(str(Path(__file__).parents[1] / 'normalized-alignment/triangle_exact.py'))
    mul, trans, add, det = [support[key] for key in ['mul', 'transpose', 'add', 'determinant']]
    n = 3
    edges = [(0, 1), (1, 2), (2, 0), (0, 2)]
    weights = [F(1), F(2), F(3), F(5)]
    E = len(edges)
    incidence = []
    for i, j in edges:
        row = [F(0) for _ in range(n - 1)]
        if i:
            row[i - 1] += 1
        if j:
            row[j - 1] -= 1
        incidence.append(row)
    scalar_gram = mul(mul(trans(incidence), diagonal(weights)), incidence)
    tau = det(scalar_gram)
    product_weights = F(1)
    for weight in weights:
        product_weights *= weight
    Delta0 = 2**(3 * E) * tau * product_weights**4
    assert tau == 26 and product_weights == 30 and Delta0 == 86261760000
    rows = []
    for signs in itertools.product([1, -1], repeat=2):
        for radius in [F(0), F(1, 2), F(2)]:
            J = normal_jacobian(edges, signs, radius, n)
            gram = mul(mul(trans(J), diagonal([w for w in weights for _ in range(2)])), J)
            cov_values = [v for w in weights for v in [2*w, 4*w, 2*w]] + [F(0)] * (2*(n-1)+2)
            Hessian = add(gram, diagonal(cov_values))
            det_raw = det(Hessian)
            det_frobenius = det_raw / 2**E
            expected = Delta0 * (1 + radius*radius/2)**2
            assert det_frobenius == expected
            if radius == 0:
                mean_only = [row[3*E:] for row in gram[3*E:]]
                assert det(mean_only) == tau * product_weights == 780
            rows.append({'signs': signs, 'radius': str(radius), 'raw_symmetric_coordinate_determinant': str(det_raw),
                         'frobenius_coordinate_determinant': str(det_frobenius), 'predicted_determinant': str(expected)})
    result = {'scope': 'Exact normal-Hessian coefficients for the full polar Gaussian-KL phase at its coherent states; no numerical alignment integration or sampling.',
              'runtime': sys.version, 'executable': sys.executable, 'edges': edges, 'weights': [str(w) for w in weights],
              'N': n, 'E': E, 'K': 2, 'cycle_rank': 2, 'normal_dimension': 18,
              'scalar_rooted_full_graph_laplacian': support['encoded'](scalar_gram),
              'tau': str(tau), 'product_weights': str(product_weights), 'Delta_zero': str(Delta0),
              'sqrt_Delta_zero': '57600 * sqrt(26)', 'rows': rows, 'all_assertions_passed': True}
    Path(__file__).with_name('critical-hessian-exact-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'tau': str(tau), 'Delta_zero': str(Delta0), 'sign_branches': 4, 'radii': ['0', '1/2', '2'],
                      'determinants_by_radius': [row['frobenius_coordinate_determinant'] for row in rows[:3]],
                      'all_assertions_passed': True}, indent=2))


if __name__ == '__main__':
    main()
