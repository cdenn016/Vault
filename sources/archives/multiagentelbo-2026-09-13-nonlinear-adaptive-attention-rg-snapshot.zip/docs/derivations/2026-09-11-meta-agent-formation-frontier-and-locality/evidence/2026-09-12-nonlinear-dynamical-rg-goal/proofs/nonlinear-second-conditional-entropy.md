# Global nonlinear control of both conditional entropy interfaces

September 12, 2026. This component addresses contract
`contract-sha256-1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617`.
It proves finite-time bounds for the actual fine conditional loss through two
retentions and, separately, for the second conditional loss of the autonomous
exact first parent. The bounds use the original compact cosine laws. They do
not require matched initial conditionals. Their relaxation interval can be
longer than the earlier geometric formation intervals.

The result is global in time for every fixed positive temperature and finite
couplings. Joining its relaxation time to the two-episode path bounds is the
remaining integration obligation of the parent investigation. This document
does not identify the discontinuous retained fine path with the autonomous
parent path.

## 1. Quantified target and existing sources

For every positive `T`, `k`, and `K`, every smooth strictly positive initial
angular density `q_0` on the compact model below, and every `t >= 0`, we bound
the sum of its actual first and second conditional KL losses. We also bound
the second conditional KL of the separate first-parent diffusion initialized
at the actual first marginal. The reference conditional in each term is the
conditional of the exact variational optimizer, not the generative prior.
Equivalence means exact normalized pushforward and KL disintegration on the
declared Borel retentions. The autonomous dynamics is an explicitly declared
approximation to the retained fine dynamics; its force and interface defects
are displayed separately.

The user supplies the two law channels, independent dynamic links, common
microscopic kinetics, one-base-point scope, and requirement of actual
successive formation. We specialize to the existing three-node path with
five strong residuals and two weak residuals. The inequality `K T >= 1` used
below is an introduced sufficient regime for a temperature-uniform parent
constant, not a hidden assumption of the all-parameter entropy theorem.
The geometric meaning of the retentions and the episode construction remain
those of the other lanes.

Source consultation includes [STATUS](../../STATUS.md),
[the contract](evidence/2026-09-12-nonlinear-dynamical-rg-goal/problem-contract.json),
[the previous first-interface theorem](conditional-lag-and-parent-vfe.md),
Sections 9–11, [the inherited metric calculation](endogenous-rates-and-coherence.md),
Sections 4–9, and [the existing compact model](successive-coalescence-construction.md),
Sections 2–3. The live
[PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>),
`sec:meta_agent_rg`, particularly `eq:rg_closure`,
`eq:rg_slow_graph_metric`, and `eq:rg_schur_flow`, was consulted read-only.
Exact fiber integration, inherited mobility, and conditional corrections
are existing constructions there. The present contribution is the global
entropy estimate that bypasses differentiation across the branch faces.

## 2. Joint law, reference measures, and objective

Use normalized Haar measure on every angle torus. In each law channel the
five angles are `(theta_1,theta_2,theta_3,phi_12,phi_23)`; the second channel
uses `psi` for its node angles. All four link angles are independent state
coordinates. Write the complete angular state in the order

$$
W=(\theta_1,\theta_2,\theta_3,\phi_{12}^b,\phi_{23}^b,
   \psi_1,\psi_2,\psi_3,\phi_{12}^m,\phi_{23}^m)\in\mathbb T^{10}.
\tag{1}
$$

Put `V(u)=1-cos u`. The five rows of `B_f` give the three differences
`d_i=theta_i-psi_i` and the two edge-12 residuals `x_b,x_m`; the two rows
of `B_s` give the edge-23 residuals `y_b,y_m`. Explicitly,

$$
x_b=\theta_1-\theta_2-\phi_{12}^b,\quad
x_m=\psi_1-\psi_2-\phi_{12}^m,\quad
y_b=\theta_2-\theta_3-\phi_{23}^b,\quad
y_m=\psi_2-\psi_3-\phi_{23}^m.
\tag{2}
$$

The effective angular potential is exactly

$$
U(W)=K\sum_{j=1}^5V((B_fW)_j)+k\sum_{j=1}^2V((B_sW)_j).
\tag{3}
$$

The normalized generative law is the prior `P_0=Z_0^{-1}exp(-U_0/T) nu`
times the normalized physical kernels, with
`n(u)=(cos u,sin u,0,0,0)` as in the current geometry source,

$$
\zeta_i\sim N(n(\psi_i),aI_5),\qquad
k_i\mid\zeta_i\sim N(\zeta_i,(1-a)I_5),\qquad 0<a<1.
\tag{4}
$$

The observation can be the previously declared singleton. The variational
family is `Q(dW) prod_i R_i(dzeta_i,dk_i|W)`, with the correlated Gaussian
conditional `zeta_i=n(psi_i)+xi_i`, `k_i=n(theta_i)+xi_i+epsilon_i`, where
`xi_i` and `epsilon_i` have the covariances in (4). Before simplification its
free energy is the expectation

$$
\mathcal F_T(Q)=T\mathbb E_{Q\prod_iR_i}
 \log\frac{q(W)\prod_iR_i(\zeta_i,k_i\mid W)}
 {p_0(W)\prod_iP_i^{\rm ev}(\zeta_i,k_i\mid W)}.
\tag{5}
$$

All conditional Gaussian laws have positive Lebesgue densities, and their
log density ratios are integrable under the prescribed Gaussian marginals.
The exact conditional minimization already proved in the model source gives
`d(W)=sum_i V(d_i)/(1-a)`. Choose the prior bridge coefficients to be
`K-T/(1-a)>0`, and its edge coefficients to be `K,k`. Then `U=U_0+Td` is (3)
and

$$
\mathcal F_T(Q)=T\operatorname{KL}(Q\Vert P_0)+T\mathbb E_Qd
 =T\operatorname{KL}(Q\Vert\Pi)-T\log c,
\qquad
\Pi=\frac{e^{-d}P_0}{c},\quad c=\mathbb E_{P_0}e^{-d}.
\tag{6}
$$

This parameter restriction ensures positive prior bridge coefficients when
that source convention is required. Every potential is bounded and smooth
on a compact carrier, so `0<c<infinity`, all normalizers are finite and
positive, and every smooth density has finite KL. More generally the
identities hold for `Q << Pi` with finite KL; extended nonnegative KL
disintegration handles infinite values. No independence of the seven
residuals is assumed for recognition.

The actual angular process is

$$
dW_t=-\nabla U(W_t)dt+\sqrt{2T}dB_t\pmod {2\pi}.
\tag{7}
$$

All ten angular mobilities are one. A smooth bounded periodic drift is
globally Lipschitz on its Euclidean lift, so the integral equation gives a
unique global strong solution. Its uniformly elliptic forward equation on
the torus preserves positivity and smoothness of positive smooth initial
data. These are the only regularity facts needed in the integrations below;
compactness supplies domination for all finite-order derivatives of the
parent fiber integrals.

## 3. The global functional inequality and its hypotheses

We use the following precise external input. On the unit circle with angular
length coordinate, let `mu_h(dx)` be proportional to `exp(h cos x) dx`,
`h>0`. Cheng, Mao, and Zhang prove
`Ent_mu_h(g²) <= 2 C_LS(mu_h) int |g'|² dmu_h`, where their Theorem 3.1
bounds the constant by `8 pi² log(2)+1` for `0<h<1`, and by
`max(32 e sqrt(pi),24 e³/h)+1` for `h>=1`. Thus the single choice

$$
C_{\rm circ}=1000
\tag{8}
$$

is valid for every `h>0`. It is also valid for Haar (`h=0`), by taking
`h` down to zero in the inequality for a fixed smooth function, using
uniform convergence of the densities. The source is the authors' original
[2020 Journal of Mathematics article, Theorem 3.1](https://sxzz.whu.edu.cn/html/2020/6/20200606.htm).
Its circle radius, normalized probability density, and gradient convention
match the present angles. No assertion about a reflected interval process
is imported from that theorem.

For completeness, tensorization here follows from the entropy chain rule.
For two independent reference factors and a density `f`, write
`f_1=int f dmu_2`. Then

$$
\operatorname{Ent}_{\mu_1\mu_2}(f)
 =\operatorname{Ent}_{\mu_1}(f_1)
  +\int f_1\operatorname{Ent}_{\mu_2}(f/f_1)d\mu_1.
\tag{9}
$$

Apply the one-factor inequality in density form to both terms and use
`|grad f_1|²/f_1 <= int |grad_1 f|²/f dmu_2`, which is Cauchy–Schwarz.
Induction gives the product inequality with the maximum factor constant.
Normalization is immaterial by homogeneity.

The integer coordinates

$$
X=(\theta_1,\theta_2,\theta_3,d_1,d_2,d_3,x_b,x_m,y_b,y_m)=JW
\tag{10}
$$

form a global torus automorphism. Indeed their inverse is

$$
\begin{aligned}
\psi_i&=\theta_i-d_i,\\
\phi_{12}^b&=\theta_1-\theta_2-x_b,
&\phi_{23}^b&=\theta_2-\theta_3-y_b,\\
\phi_{12}^m&=\theta_1-\theta_2-d_1+d_2-x_m,
&\phi_{23}^m&=\theta_2-\theta_3-d_2+d_3-y_m.
\end{aligned}
\tag{11}
$$

Both matrices have integer entries and are mutual inverses. Thus no fiber
component or finite label is lost in (10). It preserves normalized Haar,
and `Pi` is exactly the product of three Haar factors, five von Mises
factors of concentration `K/T`, and two of concentration `k/T` in these
coordinates. This product statement is about the reference law only.

If `g(X)=f(J^{-1}X)`, the chain rule gives
`grad_X g=J^{-T} grad_W f`. Counting the nonzero inverse entries in (11)
gives `||J^{-1}||_F²=25`. Consequently

$$
\operatorname{Ent}_{\Pi}(f^2)
 \le 2C_f\int|\nabla_Wf|^2d\Pi,
\qquad C_f=25000.
\tag{12}
$$

The constant is independent of `K,k,T`. This bound is deliberately coarse;
it makes no claim that the physical entropy relaxation rate is of order
`K`. With noise coefficient `T`, that rate below is of order `T`.

## 4. Exact first parent and a uniform parent inequality

Let `C=B_f B_f^T`, `R=B_f^T C^{-1}`, `P=I-RB_f`, `A=B_s R`, and
`M_f=ker(B_f: T^10 -> T^5)`. As in the geometric lane, the first Borel
retention uses

$$
z=\operatorname{princ}(B_fW)\in[-\pi,\pi)^5,\qquad
Y=\xi_1(W)=W-Rz\pmod {2\pi}.
\tag{13}
$$

This gives an exact Borel bijection with inverse `W=Y+Rz`, and Haar
disintegrates as normalized Haar on `M_f` times `prod dz_j/(2pi)`.
It is not a global smooth product: opposite fast faces are glued with
the accompanying shift `Y -> Y+2pi R e_j`.

The exact optimizing parent density and potential, up to an irrelevant
constant, are

$$
\begin{aligned}
\pi_1(Y)&\propto \int_{[-\pi,\pi)^5}
 \exp\left[-\frac{K\sum_jV(z_j)+kF(B_sY+Az)}{T}\right]dz,\\
F_1(Y)&=-T\log\mathbb E_{\rho_{K/T}}
 \exp[-kF(B_sY+AZ)/T],\qquad F(s)=V(s_1)+V(s_2).
\end{aligned}
\tag{14}
$$

Here `rho_h` is the product of five principal-interval von Mises laws.
All derivatives in `Y` can be passed through this fixed compact integral.
The resulting potential is a smooth global function on `M_f`, despite
the discontinuity of the map (13).

First compare it to the base parent `pi_b(Y) proportional exp[-kF(B_sY)/T]`.
The coordinates `u=(theta_1,theta_2,theta_3,s_b,s_m)` on `M_f` are global:

$$
Y=Eu=(\theta_1,\theta_2,\theta_3,\theta_1-\theta_2,
\theta_2-\theta_3-s_b,\theta_1,\theta_2,\theta_3,
\theta_1-\theta_2,\theta_2-\theta_3-s_m).
\tag{15}
$$

Its first three coordinates and two residuals recover `u`; hence there is
no finite covering multiplicity in this parameterization. The induced
metric is `G=E^T E` and the inherited coordinate mobility is `G^{-1}`.
The base reference in `u` is Haar cubed times two von Mises factors.
Since `grad_u f=E^T grad_M_f f` and `||E||_F²=16`, (8)–(9) give

$$
\operatorname{Ent}_{\pi_b}(f^2)
 \le 2C_b\int|\nabla_{M_f}f|^2d\pi_b,
\qquad C_b=16000.
\tag{16}
$$

The next elementary bound makes the perturbation uniform without applying
a Lipschitz pushforward theorem to the discontinuous map (13). Put

$$
c_0=2/\pi^2,\qquad
b=k\sqrt2\|A\|,\qquad
J_0=e^{1/2}\sqrt{\pi/c_0},\qquad
M=J_0^5\exp\left[\frac{5b^2}{4c_0KT}\right].
\tag{17}
$$

Assume `K/T>=1`. For one fast angle and `h=K/T`, its unnormalized
denominator is at least `2e^{-1/2}/sqrt(h)` by restricting to
`|z|<=1/sqrt(h)` and using `V(z)<=z²/2`. On the whole interval,
`V(z)>=c_0 z²`. Completing the square therefore gives, for every `beta>=0`,

$$
\begin{aligned}
\mathbb E_{\rho_h^{(1)}}e^{\beta|Z|}
&\le
\frac{2\int_0^\infty e^{-c_0hz^2+\beta z}dz}
     {2e^{-1/2}/\sqrt h}\\
&\le J_0\exp[\beta^2/(4c_0h)].
\end{aligned}
\tag{18}
$$

The numerator bound extends the translated half-line Gaussian integral to
the full line. The weak potential satisfies
`|kF(s+Az)-kF(s)| <= b |z| <= b sum_j |z_j|`. Independence of the reference
fast factors and (18) imply

$$
M^{-1}\le
R_1(s):=\mathbb E_{\rho_{K/T}}
 e^{-[kF(s+AZ)-kF(s)]/T}
\le M.
\tag{19}
$$

For the lower bound, Cauchy–Schwarz gives
`E e^{-X} >= 1/(E e^X)` for `X=(b/T) sum |Z_j|`. The normalized likelihood
ratio `pi_1/pi_b` has maximum-to-minimum ratio at most `M²`; its normalizing
constant cancels in that ratio.

Here is the required bounded-perturbation proof. For any nonnegative `v`,

$$
\operatorname{Ent}_{\mu}(v)
 =\inf_{a>0}\int[v\log(v/a)-v+a]d\mu.
\tag{20}
$$

The integrand is nonnegative. If `m <= dmu/dnu <= M'`, (20) and the
inequality for `nu` show
`Ent_mu(f²) <= 2 C_nu (M'/m) int |grad f|² dmu`.
Applying this to (19) proves

$$
\operatorname{Ent}_{\pi_1}(f^2)
 \le2C_1\int|\nabla_{M_f}f|^2d\pi_1,
\qquad C_1=16000M^2.
\tag{21}
$$

In particular, for `0<T<=1`, bounded `k`, and `KT>=1`, `C_1` has a finite
upper bound independent of `K,T`. The constants are large but explicit.
For arbitrary positive `K,T`, the simpler bound
`|kF(s+Az)-kF(s)|<=4k` gives the same argument with
`C_1=16000 exp(8k/T)`. Thus the finite-time conclusion holds without the
uniform regime. No reflecting actual dynamics has been introduced.

## 5. Two actual-law entropy bounds and the independent parent bound

Let `Q_t` solve (7), and let `q_t` denote its Haar density. Write
`H_f(t)=KL(Q_t||Pi)` and `f_t=q_t/pi`. Periodic integration by parts gives

$$
\dot H_f(t)=-T\int q_t|\nabla\log f_t|^2d\nu.
\tag{22}
$$

Apply (12) to `sqrt(f_t)`: its right-hand side is `(C_f/2)` times the
Fisher integral in (22). Therefore

$$
H_f(t)\le H_f(0)e^{-2Tt/C_f}.
\tag{23}
$$

The first parent is initialized at the actual marginal
`bar R_0=R_0=xi_1#Q_0` and evolves autonomously with its exact potential:

$$
\partial_t\bar r
 =\operatorname{div}_{M_f}(\bar r\nabla_{M_f}F_1
                         +T\nabla_{M_f}\bar r).
\tag{24}
$$

This is the inherited metric equation. In coordinates (15) its drift is
`-G^{-1} grad_u F_1` and its diffusion covariance is `2T G^{-1}`.
It includes all nonlinear interactions in (14) without a fitted new rate.
The same integration by parts and (21) imply

$$
\bar H_1(t):=\operatorname{KL}(\bar R_t\Vert\Pi_1)
 \le\operatorname{KL}(R_0\Vert\Pi_1)e^{-2Tt/C_1}
 \le H_f(0)e^{-2Tt/C_1}.
\tag{25}
$$

The final inequality is KL disintegration. The initial marginal has a
positive smooth density because it is the compact integral of
`q_0(Y+Rz)`. Thus (24) has the same positivity and regularity needed in (22).

For the second retention, let `S=B_s P B_s^T`, `L_2=P B_s^T S^{-1}`,
`M_0=ker B_f intersect ker B_s`, and use the corresponding second Borel map

$$
s=\operatorname{princ}(B_sY),\qquad
\xi_2(Y)=Y-L_2s\in M_0.
\tag{26}
$$

As in (13), all face identifications are part of this map. Its Haar
disintegration is Haar on `M_0` times `ds/(2pi)²`, and the parent potential
is a function only of `s`. Consequently the exact final reference `Pi_2`
is Haar and the second optimizing conditional is proportional to
`exp[-F_1(s)/T] ds`. No assumption on the actual second conditional follows
from this reference factorization.

Set `R_t=xi_1#Q_t`, `S_t=xi_2#R_t`, `bar S_t=xi_2#bar R_t`. Before any
bound, define the losses by their conditional expectations:

$$
\begin{aligned}
\Delta_1(t)&=\mathbb E_{R_t}
 \operatorname{KL}(Q_t(dW\mid Y)\Vert\Pi(dW\mid Y)),\\
\Delta_2^{\rm fine}(t)&=\mathbb E_{S_t}
 \operatorname{KL}(R_t(dY\mid Z)\Vert\Pi_1(dY\mid Z)),\\
\bar\Delta_2(t)&=\mathbb E_{\bar S_t}
 \operatorname{KL}(\bar R_t(dY\mid Z)\Vert\Pi_1(dY\mid Z)).
\end{aligned}
\tag{27}
$$

Here `Z` in a conditional denotes the final retained state, distinct from
the fast integration variable in (14). All conditional laws are regular
conditionals on compact standard Borel spaces; reference densities are
positive. Expanding the log density ratios under the expectations gives
the exact identities

$$
\begin{aligned}
H_f(t)&=\operatorname{KL}(S_t\Vert\Pi_2)
             +\Delta_1(t)+\Delta_2^{\rm fine}(t),\\
\bar H_1(t)&=\operatorname{KL}(\bar S_t\Vert\Pi_2)+\bar\Delta_2(t).
\end{aligned}
\tag{28}
$$

Nonnegativity and (23), (25) prove the promised result:

$$
\boxed{\begin{aligned}
\Delta_1(t)+\Delta_2^{\rm fine}(t)
 &\le H_f(0)e^{-2Tt/25000},\\
\bar\Delta_2(t)
 &\le H_f(0)e^{-2Tt/(16000M^2)}.
\end{aligned}}
\tag{29}
$$

These are bounds on actual positive-density laws. They remain valid for
every time, including times at which individual paths cross branch faces.
They do not differentiate a conditional entropy across a face and do not
set its current to zero. The first line concerns the actual fine law;
the second concerns the separately generated inherited process.

For any target `epsilon>0`, both losses in (29) are at most `epsilon` for

$$
t\ge t_{\rm ent}:=
 \frac{\max(25000,16000M^2)}{2T}
 \max\{0,\log(H_f(0)/\epsilon)\}.
\tag{30}
$$

If `H_f(0)=0`, set the right-hand side to zero. Equation (30) is a late
finite relaxation bound; it is not a claim that the second conditional is
already small when the weak cut first enters its coherence tolerance.

## 6. VFE error and the first force/interface correction

The generative first prior is `P_1=xi_1#P_0`, with its genuine conditional
`P_0(dW|Y)`. Define its effective evaluator cost by
`e^{-d_1(Y)}=E_{P_0(dW|Y)} e^{-d(W)}`. At the next stage use
`P_2=xi_2#P_1` and `e^{-d_2(Z)}=E_{P_1(dY|Z)}e^{-d_1(Y)}`. These definitions
are normalized conditional integrals, not substituted optimizing priors.
The associated parent objectives are

$$
\mathcal F_i(R)=T\mathbb E_R\log(dR/dP_i)+T\mathbb E_Rd_i
              =T\operatorname{KL}(R\Vert\Pi_i)-T\log c.
\tag{31}
$$

Consequently the exact omitted free energies and their bounds are

$$
\begin{aligned}
\mathcal F_T(Q_t)-\mathcal F_2(S_t)
 &=T(\Delta_1+\Delta_2^{\rm fine})
 \le TH_f(0)e^{-2Tt/C_f},\\
\mathcal F_1(\bar R_t)-\mathcal F_2(\bar S_t)
 &=T\bar\Delta_2
 \le TH_f(0)e^{-2Tt/C_1}.
\end{aligned}
\tag{32}
$$

This derivation controls dimensionless conditional KL before multiplying
by temperature; small physical energy alone is not used as KL evidence.

Inside a fast branch, the actual first marginal force has the correction

$$
g_t(Y)=\mathbb E_{Q_t(dz\mid Y)}\nabla_YU(Y,z)
       -\mathbb E_{\Pi(dz\mid Y)}\nabla_YU(Y,z),\qquad
\nabla_YU=kP B_s^T\sin(B_sY+Az).
\tag{33}
$$

Set `b_0=k ||P B_s^T|| sqrt(2)`. The force is bounded in norm by `b_0`.
The elementary total-variation/KL inequality gives

$$
\int|g_t(Y)|^2dR_t(Y)
 \le2b_0^2\Delta_1(t)
 \le2b_0^2H_f(0)e^{-2Tt/C_f}.
\tag{34}
$$

For reference, the needed inequality follows by applying the log-sum
inequality to an event attaining total variation, reducing to Bernoulli
KL. Its second derivative in the first argument is `1/[p(1-p)]>=4`;
integration from the minimum gives `KL>=2(p-q)²`. The difference of
expectations of a vector of norm at most `b_0` is at most `2b_0 TV`, which
proves (34). Thus this step has no unquoted transport-entropy assumption.

For a smooth test function `phi` on `M_f`, the exact weak retained equation
has, in addition to (33), the gluing term

$$
\frac d{dt}\mathbb E_{R_t}\phi
 =\mathbb E_{R_t}\left[T\Delta_{M_f}\phi
              -(\nabla F_1+g_t)\cdot\nabla\phi\right]
 +\mathcal J_t(\phi),
\tag{35}
$$

where, choosing the positive face of each fast coordinate once,

$$
\mathcal J_t(\phi)=\sum_{j=1}^5
 \int_{z_j=\pi}J_{z,j}(Y,z)
 [\phi(Y+2\pi R e_j)-\phi(Y)]dYd\sigma(z),\qquad
J_z=-T\pi C\nabla_z(q/\pi).
\tag{36}
$$

All measures in (36) use the same normalized Haar/fiber conventions as
(13); the normal is toward increasing `z_j`. The opposite face represents
the same current with the displayed translated arrival state. Equations
(35)–(36) follow by integrating the local continuity equation on the
cube and pairing its opposite faces. Diffusion paths need not have a
countable sequence of isolated face crossings for this weak formula.

The root-mean-square force contribution over `[t_0,H]` is explicitly
bounded by

$$
\int_{t_0}^H\left(\int|g_t|^2dR_t\right)^{1/2}dt
 \le\frac{C_f}{T}\sqrt2 b_0\sqrt{H_f(0)}e^{-Tt_0/C_f}.
\tag{37}
$$

The branch current in (36) is retained. Equation (29) controls the entropy
of the complete law including its branch information; it does not supply
a separate small bound for (36) in a parent path comparison. The localized
conditional-current estimate is strengthened to all time in Section 7.1
below. The geometric lane separately controls branch exits or the
integrated gluing current wherever dynamical approximation is claimed.

## 7. Initial-law regime and the finite-horizon joining condition

The entropy theorem allows every smooth positive initial density; in
particular it allows the correlated positive densities concentrated in the
strict two-episode initial open set. One explicit choice is
`q_0=(1-eta) b+eta pi`, where `0<eta<1` and `b` is a normalized smooth bump
supported inside that open set. This is strictly positive and need not
have either optimizing conditional. Convexity of KL gives the useful bound

$$
H_f(0)\le(1-\eta)\operatorname{KL}(b\Vert\Pi)
 \le\log\|b\|_\infty+\frac{10K+4k}{T}.
\tag{38}
$$

The last estimate uses `0<=U<=10K+4k` and `Z<=1` relative to normalized
Haar; `||b||_infinity>=1`. Alternatively the shifted product von Mises
initializations of the episode lane satisfy the same smooth-positivity
hypotheses directly. Strict finite choices admit an open neighborhood of
densities and parameters: positivity, concentration probability, and a
finite upper bound on the initial KL persist under sufficiently small
uniform perturbations.

For fixed `k` and `K=T^{-p}`, `p>1`, the uniform comparison (17) is bounded
as `T` tends to zero, while (38) is polynomial in `1/T`. Thus (30) is
`O(T^{-1} log(1/T))` for any fixed error target. This is a direct bound on
the horizon required by the entropy argument. A long-horizon tube estimate
whose failure is polynomial in the horizon times an activated factor
`exp(-c/T)` can therefore be joined to it. The earlier elementary
`exp(KH)` path estimate cannot make this inference; a stronger tube bound
must be supplied, with its own initial-law and boundary hypotheses.

Passive compact marks, if included, can remain in every retained state.
When their generator is independent of the angles and reversible with
respect to its reference Haar law, no uniform-in-temperature mark LSI is
needed for these conditional losses. Replace `H_f` by the angular
conditional entropy `KL(Q_t || Q_t^{marks} tensor Pi_angles)`. Its derivative
has the negative angular Fisher term in (22) and an additional nonpositive
mark term: subtracting marginal mark Fisher from joint mark Fisher is
nonnegative by conditional Cauchy–Schwarz. Apply (12) at each fixed mark.
The same reasoning works for (24). Since both retentions keep every mark,
KL disintegration bounds (27) by these angular conditional entropies.
This extension assumes the stated independent mark generator; it does not
add a hidden mark equilibration postulate.

### 7.1 The same shifted law has a uniformly small first loss after relaxation

The following application of the existing first-interface theorem supplies
more than a late equilibrium estimate. Fix `x_0 in (1/4,1/3)` and
`y_0 in (1/8,1/6)`, and in the global coordinates (10) let

$$
Q_0^*=\nu_{\mathbb T^3}\otimes
 \bigotimes_{j=1}^5\mu_{K/T}(dz_j-a_j)
 \otimes\bigotimes_{j=1}^2\mu_{k/T}(dr_j-y_0),
\qquad a=(0,0,0,x_0,x_0).
\tag{39}
$$

This is a smooth positive density on the full torus, whose residuals
concentrate at the formation initial slice. `r=B_sW` here is the actual
weak residual, so the horizontal initial cut is approximately
`y_0+x_0/3`, not `y_0`. Translation preserves every circle normalizer in
(39). Thus the likelihood ratio against `Pi` is exactly

$$
f_0^*=\exp[(K\Psi_a+k\Psi_b)/T],\qquad
\Psi_a=\sum_{j=4}^5[\cos(z_j-x_0)-\cos z_j],\quad
\Psi_b=\sum_{j=1}^2[\cos(r_j-y_0)-\cos r_j].
\tag{40}
$$

For an open class of preparations, set `Q_0=g Q_0^*/E_Q0* g`, where the
smooth function `g` has `0<g_-<=g<=g_+` and
`||grad log g||_infinity<=L_g`. Define

$$
\theta_a=4\sin(x_0/2),\quad \theta_b=4\sin(y_0/2),\quad
D=K\theta_a+k\theta_b,\quad
B=\log(g_+/g_-)+D/T.
\tag{41}
$$

Then `e^{-B}<=f_0<=e^B`, `H_f(0)<=B`, and direct differentiation gives

$$
\|\nabla f_0\|_\infty
 \le e^B[L_g+\sqrt3 D/T]=:L_0.
\tag{42}
$$

For `g=1` the sharper exact initial entropy is

$$
H_f(0)=\frac{2K}{T}V(x_0)c(K/T)+\frac{2k}{T}V(y_0)c(k/T)
 \le\frac{2K V(x_0)+2kV(y_0)}{T},
\quad c(h)=\mathbb E_{\mu_h}\cos Z\in[0,1].
\tag{43}
$$

Indeed `c(0)=0` and `c'(h)=Var_mu_h(cos Z)>=0`, while `cos Z<=1`.
The expectation of the shifted log ratio in each factor gives (43).

We now apply equation (36) of
[the first-interface derivation](conditional-lag-and-parent-vfe.md), with
its actual boundary current and outside/label entropy retained. Fix
`rho=7/5`, `c_-=lambda_min(C)`, `c_+=lambda_max(C)`, and put

$$
\begin{aligned}
\lambda&=c_-[K\cos\rho-k\|A\|^2]>0,\\
\Gamma&=k\|C^{1/2}A^T\|\|B_sP\|,\qquad L=Kc_++3k,\\
a_0&=\sqrt{T/K}\quad(K\ge T),\\
E_\rho&=(\pi/a_0)^5
 \exp[5/2+4k/T-K(1-\cos\rho)/T],\\
c_\rho&=\pi^{-1}(\rho/\pi)^4\sum_{j=1}^5\sqrt{C_{jj}}.
\end{aligned}
\tag{44}
$$

The exponentially growing gradient bound in that earlier theorem can be
replaced by the following all-time bound. Let `P_t` be the reversible
microscopic semigroup for likelihood ratios, and put `Lambda=L=Kc_++3k`.
The global Hessian satisfies `Hess U >= -Lambda I`. Differentiating its
additive-noise stochastic flow and applying Cauchy–Schwarz gives

$$
|\nabla P_uh|^2\le e^{2\Lambda u}P_u|\nabla h|^2.
\tag{44a}
$$

For a fixed `s>0`, differentiate
`P_u[(P_{s-u}h)²]` in `u`. The generator product rule leaves precisely
`2T P_u |grad P_{s-u}h|²`. Integrating and then applying (44a) with
`h` replaced by `P_{s-u}h` gives

$$
\begin{aligned}
P_sh^2-(P_sh)^2
 &=2T\int_0^sP_u|\nabla P_{s-u}h|^2du\\
 &\ge\frac{T}{\Lambda}(1-e^{-2\Lambda s})|\nabla P_sh|^2.
\end{aligned}
\tag{44b}
$$

Take `s=1/Lambda`. For every `t>=s`, apply (44b) to
`h=f_{t-s}`, whose supremum is at most `e^B` by the maximum principle.
The variance on the left is at most `e^{2B}`. For `0<=t<=s`, the direct
flow estimate bounds the gradient by `e L_0`. Thus

$$
\sup_{t\ge0}\|\nabla f_t\|_\infty\le\overline L,
\qquad
\overline L=\max\left\{eL_0,
 e^B\sqrt{\frac{\Lambda}{T(1-e^{-2})}}\right\}.
\tag{44c}
$$

All uses of differentiation are justified for smooth data and the
smooth compact elliptic semigroup. This is a variance calculation for
the actual microscopic process; it introduces no auxiliary boundary
condition. Substituting (44c) into the earlier actual-current estimate,
and integrating its exponential relaxation kernel, gives

$$
\begin{aligned}
\Delta_1(t)\le{}&B e^{-\lambda t}
 +\frac{\Gamma^2B}{2\lambda^2}
 +(2+4B)e^BE_\rho\\
 &+\frac{2TB\overline Lc_\rho E_\rho}{\lambda}
       (1-e^{-\lambda t}),\qquad t\ge0.
\end{aligned}
\tag{45}
$$

Every hypothesis of that theorem is now explicit. The first two terms use
the true initial entropy budget, while the last two bound respectively
the outside/label loss and the actual conditional boundary current.
Uniform convexity is used only for its local conditional functional
inequality; the actual process still satisfies (7).

Here is a simultaneous parameter check. Let
`delta=1-cos(7/5)-4sin(1/6)>0` and
`theta_b,max=4sin(1/12)`. Fix bounded `k,g_+/g_-,L_g` and
choose

$$
K\ge T,\qquad
K\ge\frac{2(4+\theta_{b,\max})k}{\delta},\qquad
K\cos\rho\ge2k\|A\|^2.
\tag{46}
$$

The positivity of `delta` can be checked without decimal arithmetic:
`cos(7/5)<=1-(7/5)²/2+(7/5)^4/24` and `sin(1/6)<1/6` give
`delta>2299/15000`.

The exponential part of either tail or current term in (45) is then
bounded by a constant times `exp[-delta K/(2T)]`: the weak exponential
cost is at most `delta K/(2T)` by the second inequality. All other
displayed factors are polynomial in `K,1/T` when the multiplier bounds
are fixed. There is no growing horizon factor in this estimate.

For `K=T^{-p}` with any fixed `p>1` and fixed `t_a>0`, (45)
therefore proves

$$
\sup_{t\ge t_a}\Delta_1(t)
 \le O(T^{p-1})
 +O\left(T^{-p-1}e^{-cT^{-p}t_a}\right)
 +\operatorname{poly}(T^{-1})e^{-\delta T^{-p-1}/2}
 \longrightarrow0.
\tag{47}
$$

The constants depend only on the fixed model matrices, weak coupling,
`t_a`, and multiplier bounds. In particular, `p=3` gives an `O(T²)`
first-conditional plateau for every `t>=1/64`, including the proposed
pair-only interval `[1/64,1/16]` and the entire later entropy horizon,
with exponentially small initial, tail, and current terms.
This early bound and the late two-stage bound (29) hold for the same
positive preparation (39), and both allow the stated multiplier
neighborhood. The all-time first bound includes the interval between
the first and second formation episodes.

The same estimate bounds the actual gluing current (36), not only the
localized conditional current. At a principal fast face the energy has a
fast contribution at least `2K`. Define
`E_pi=(pi/a_0)^5 exp[5/2+4k/T-2K/T]` and
`c_pi=pi^{-1} sum_j sqrt(C_jj)`. Since
`|C grad_z f|` in each normal component is bounded by
`sqrt(C_jj) overline L`, integration over the faces gives the safe bound

$$
|\mathcal J_t(\phi)|
 \le2\|\phi\|_\infty T\overline Lc_\pi E_\pi,
\qquad
\left|\int_0^H\mathcal J_t(\phi)dt\right|
 \le2H\|\phi\|_\infty T\overline Lc_\pi E_\pi.
\tag{47a}
$$

The sum over both faces overestimates the once-paired expression (36), so
the displayed factor is conservative. For the common polynomial horizon
and `K=T^{-p}`, its exponential factor is at most a polynomial times
`exp[-(2-theta_a)K/T+(4+theta_b)k/T]`, which tends to zero. This supplies
a weak integrated first-interface current estimate directly. A projected
path comparison remains a separate statement.

### 7.2 Autonomous final root and direct objective comparisons

Let `E_0` be (15) with `s_b=s_m=0`. Its three global coordinates on `M_0`
have the induced metric

$$
G_0=E_0^TE_0=
\begin{pmatrix}4&-2&0\\-2&6&-2\\0&-2&4\end{pmatrix},\qquad
\|E_0\|_F^2=\operatorname{tr}G_0=14.
\tag{48}
$$

The inherited final autonomous process has constant potential and generator
`T Delta_M0`, or noise covariance `2T G_0^{-1}` in these coordinates.
Write its law as `tilde S_t`, initialized at `S_0=xi_2#xi_1#Q_0`.
This law is distinct from both `S_t` and `bar S_t` defined above. Applying
(8)–(9) to its three Haar coordinates, followed by the metric comparison
in (48), yields

$$
\widetilde H_2(t):=\operatorname{KL}(\widetilde S_t\Vert\Pi_2)
 \le H_f(0)e^{-2Tt/C_2},\qquad C_2=14000.
\tag{49}
$$

The initial bound again follows from exact KL disintegration. Because the
same additive constant `-T log c` occurs in all three objectives (6), (31),
their values at the three independently evolved laws satisfy

$$
\begin{aligned}
|\mathcal F_T(Q_t)-\mathcal F_1(\bar R_t)|
 &\le TH_f(0)[e^{-2Tt/C_f}+e^{-2Tt/C_1}],\\
|\mathcal F_1(\bar R_t)-\mathcal F_2(\widetilde S_t)|
 &\le TH_f(0)[e^{-2Tt/C_1}+e^{-2Tt/C_2}].
\end{aligned}
\tag{50}
$$

These are late objective-value comparisons obtained directly from the
three entropy dissipations. They are additional to the exact elimination
costs (32). They do not assert KL closeness between `Q_t`, `bar R_t`, and
`tilde S_t`, which live on different spaces, or between their projections.
Until both residual branch exits, the root projections can be coupled to
the same inherited Brownian increment. After an exit their chart gluing
must be retained; (49) does not identify those actual projected processes
with the autonomous root process.

## 8. Route disposition, falsifiers, and executed evidence

Three routes were considered within this bounded assignment. The previous
restricted-convexity calculation becomes an all-time first-interface
bound with explicit flux after the semigroup variance estimate (44b).
Extending it directly to the weak second cube
requires controlling its initial marginal tilt and weak-face current on
the same horizon. A direct smooth-pushforward LSI argument from the fine
torus was rejected for the principal retention because (13) is not globally
Lipschitz. The completed route is global fine entropy dissipation plus a
static, proved parent likelihood comparison. It proves (29) without either
of those unproved steps.

The smallest remaining obligation is to join the finite time (30) to an
actual two-episode path regime and its second-interface path control.
The first weak gluing contribution has the explicit bound (47a). This
component supplies both required conditional entropies and their exact
VFE corrections already; path closeness is neither its premise nor its
proof. The full nonlinear contract is not closed by this component alone.

A proposed use fails if the prior does not produce (3), if a noninteger
coordinate quotient is silently treated as an automorphism, if recognition
independence is inferred from the reference product law, if the parent
mobility differs from the induced metric in (24), if a different parent
potential replaces (14) without a bound, or if current (36) is dropped
from a claimed dynamical identity. The entropy inequalities themselves
hold without any claimed second coalescence, so proving them alone does
not establish that episode.

The only executed calculation is the small exact integer/Fraction check
in [check_constants.py](evidence/nonlinear-conditional-entropy/check_constants.py).
It checks the invertible integer coordinates and squared Frobenius
constants `25` and `16`, and saves
[matrix-results.json](evidence/nonlinear-conditional-entropy/matrix-results.json).
The proof of the inequalities is the displayed argument and the precisely
matched circle theorem. No numerical entropy trajectory, GPU computation,
full suite, Lean construction, tamper check, Git operation, or Research
vault edit was performed. This lane changed only this document and its
assigned evidence directory; the parent owns the shared status and daily
change log.
