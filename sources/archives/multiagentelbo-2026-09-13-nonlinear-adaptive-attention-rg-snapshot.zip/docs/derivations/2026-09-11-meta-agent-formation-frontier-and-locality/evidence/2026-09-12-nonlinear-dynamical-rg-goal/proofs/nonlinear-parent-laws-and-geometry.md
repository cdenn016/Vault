# Exact nonlinear parent laws and global retained geometry

September 12, 2026. This is the geometry and normalized-law lane of [the nonlinear two-stage contract](evidence/2026-09-12-nonlinear-dynamical-rg-goal/problem-contract.json), digest `1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617`. It proves two exact measurable retentions, their normalized generative and optimizing laws, the generated interaction, and the inherited differential operators. The actual-law conditional-entropy and successive-episode arguments belong to the accompanying lanes. In particular, a Borel retained trajectory is not asserted to be a globally continuous diffusion.

The source construction is [endogenous-rates-and-coherence.md](endogenous-rates-and-coherence.md), Sections 2–4 and 8, with the global chart convention in [conditional-lag-and-parent-vfe.md](conditional-lag-and-parent-vfe.md), Sections 2–4. The live `Research/manuscripts/PIFB2.tex` passages surrounding `eq:rg_closure`, `eq:rg_laplace`, `eq:rg_slow_graph_metric`, and `eq:rg_schur_flow` motivate retention of the exact conditional normalizer, induced metric, and generated interactions. [Theory/03](../../../Theory/03_probability.tex), [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), and [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex) provide the normalized-joint and common-channel types. Those sources are prior work; the calculations below supply the explicit compact specialization and its global qualifications.

## 1. Target, model, and quantifiers

For every fixed `0<a<1`, `T>0`, `k>0`, and admissible positive strong coefficients, the target of this lane is an exact two-stage disintegration of the existing three-node path model. Equality means equality of normalized measures and kernels on the declared standard-Borel spaces, and equality of differential expressions in each coordinate interior together with their interface identifications. It does not mean equality between the actual Borel retained path law and a newly constructed Markov diffusion.

The user's supplied assumptions are the paired belief/model law sections at fixed `c_*`, independent dynamic links, normalized physical evaluators, correlated recognition, and common microscopic kinetics. The finite cosine family, path with strong edge `12` and weak edge `23`, and positive coefficients are the existing declared specialization. No base transport, grouping schedule, new parent mobility, Gaussian replacement, or new physical observation is introduced here.

Use angular state

\[
x=(\theta_1,\theta_2,\theta_3,\psi_1,\psi_2,\psi_3,
       \alpha_{12}^b,\alpha_{23}^b,\alpha_{12}^m,\alpha_{23}^m)
       \in\mathbb T^{10},\qquad \mathbb T=\mathbb R/(2\pi\mathbb Z).
\tag{1}
\]

The optional four independent `SO(3)` link marks of the source are retained at both stages. Write their product space as `H`; omit `H` for the permitted `SO(2)` specialization. All Haar measures below are normalized. Coordinates in (1) have the Euclidean flat metric. Marks have the source's fixed bi-invariant metric and independent Brownian drivers.

Define `F(u)=sum_j(1-cos u_j)`. Let `B_f x` be the five residuals

\[
(\theta_1-\psi_1,\theta_2-\psi_2,\theta_3-\psi_3,
  \theta_1-\theta_2-\alpha_{12}^b,
  \psi_1-\psi_2-\alpha_{12}^m),
\tag{2}
\]

and `B_s x` the two residuals

\[
(\theta_2-\theta_3-\alpha_{23}^b,
  \psi_2-\psi_3-\alpha_{23}^m).
\tag{3}
\]

The variational potential and evaluator cost are

\[
U(x)=\sum_{j=1}^5K_j(1-\cos(B_fx)_j)+kF(B_sx),\qquad
d(x)=\frac1{1-a}\sum_{i=1}^3(1-\cos(\theta_i-\psi_i)).
\tag{4}
\]

Set `U_0=U-Td`, require `K_i>T/(1-a)` for `i<=3`, and let `K_4,K_5>0`. The original matched family is `K_j=K`; the neighboring effective-coefficient family admitted in the entropy lane satisfies `K<=K_j<=K+c_d T`. Both use the same maps. The normalized prior and variational target are

\[
P_0(dx,dh)=Z_0^{-1}e^{-U_0(x)/T}dx dh,\qquad
\pi(dx,dh)=Z^{-1}e^{-U(x)/T}dx dh.
\tag{5}
\]

Here and below `dx dh` denotes the normalized product reference, not a new interaction. The continuous microscopic dynamics are

\[
dx_t=-\nabla U(x_t)dt+\sqrt{2T}dB_t\pmod {2\pi},\qquad
\mathcal L_H=T\Delta_H.
\tag{6}
\]

Smooth periodic drift is bounded and globally Lipschitz in a lift, so (6) has a unique global strong solution for every initial law. Its angular state has no boundary. A smooth positive initial density stays smooth and positive at positive finite times; the construction of the parent laws below also applies to any `Q<<pi`, using regular conditional probabilities. No discretization or simulation is used in this lane. Integration by parts gives the exact continuous identity `d KL(Q_t||pi)/dt=-T I(Q_t||pi)` when the density is smooth; it gives no claim about an unspecified numerical update.

## 2. The two Borel retentions are bijective coordinates

Put

\[
C=B_fB_f^T,\quad R=B_f^TC^{-1},\quad P=I-RB_f,\quad
A=B_sR,\quad \Gamma=B_sPB_s^T,\quad L_2=PB_s^T\Gamma^{-1}.
\tag{7}
\]

The exact matrices needed later are

\[
C=\begin{pmatrix}2&0&0&1&-1\\0&2&0&-1&1\\0&0&2&0&0\\
1&-1&0&3&0\\-1&1&0&0&3\end{pmatrix},\qquad
A=\begin{pmatrix}0&1/2&-1/2&-1/6&-1/6\\
0&-1/2&1/2&-1/6&-1/6\end{pmatrix},
\tag{8}
\]

\[
\Gamma=\begin{pmatrix}11/6&5/6\\5/6&11/6\end{pmatrix},\qquad
\Gamma^{-1}=\begin{pmatrix}11/16&-5/16\\-5/16&11/16\end{pmatrix},\qquad
AA^T=\begin{pmatrix}5/9&-4/9\\-4/9&5/9\end{pmatrix}.
\tag{9}
\]

Thus `C` and `Gamma` are positive definite. Their smallest eigenvalues are `(5-sqrt(17))/2` and `1`, respectively. Let

\[
M_f=\ker(B_f:\mathbb T^{10}\longrightarrow\mathbb T^5),\qquad
M_0=\ker\left(\begin{pmatrix}B_f\\B_s\end{pmatrix}:
                   \mathbb T^{10}\longrightarrow\mathbb T^7\right).
\tag{10}
\]

Both kernels are connected. Explicitly, on `M_f`, the three `psi_i` equal `theta_i`, both strong links equal `theta_1-theta_2`, and the two weak links are free. This identifies `M_f` with `T^5` by the three `theta_i` and the weak link angles. The two remaining residuals are obtained by subtracting those free link angles, so `B_s|M_f` has connected kernel `M_0`, identified with `T^3` by the three common node angles. This also proves the necessary integer-lattice primitivity without assuming it from real rank.

Let `pr` choose the half-open representative `[-pi,pi)` in each circle coordinate. Define

\[
z=\operatorname{pr}(B_fx),\qquad y=x-Rz\in M_f,\qquad
s=\operatorname{pr}(B_sy),\qquad r=y-L_2s\in M_0.
\tag{11}
\]

The maps are Borel. They are smooth off their stated faces. The identities `B_fR=I`, `B_fL_2=0`, and `B_sL_2=I` show that the inverse is exactly

\[
x=r+L_2s+Rz\pmod {2\pi}.
\tag{12}
\]

Consequently, (11) is a Borel bijection

\[
\mathbb T^{10}\longleftrightarrow
 M_0\times[-\pi,\pi)^2\times[-\pi,\pi)^5,
\tag{13}
\]

with every angle of `x` recovered by (12). The retentions themselves are `C_1(x,h)=(y,h)` and `C_2(y,h)=(r,h)`. They remove the conditional variables `z` and then `s`; their dimension counts are `10 -> 5 -> 3`, or `22 -> 17 -> 15` with all four three-dimensional marks retained. This is a conditional representation of a vector-valued parent, not closure inside a scalar Gaussian-agent ansatz.

The normalized reference factorization is exact:

\[
dx=dy\frac{dz}{(2\pi)^5}
   =dr\frac{ds}{(2\pi)^2}\frac{dz}{(2\pi)^5}.
\tag{14}
\]

To prove it, Haar pushforward by the surjective homomorphism `B_f` is Haar on `T^5`; its conditional fiber law is translated Haar on the connected kernel `M_f`. The translation `x -> x-Rz` in (11) therefore produces the same normalized Haar law for `y` for each `z`. Apply the identical argument to `B_s|M_f`. This measure identity does not impose product topology or reflecting boundaries on the right side of (13).

## 3. Global faces and the inherited metric

In an interior chart, `dr`, `L_2 ds`, and `R dz` are pairwise orthogonal because they belong to the nested normal spaces in (7). Hence

\[
|dx|^2=|dr|^2+ds^T\Gamma^{-1}ds+dz^TC^{-1}dz.
\tag{15}
\]

Write `r=E_0 q`, with `q in T^3`, where the rows of `E_0q` are

\[
(q_1,q_2,q_3,q_1,q_2,q_3,
       q_1-q_2,q_2-q_3,q_1-q_2,q_2-q_3).
\tag{16}
\]

Then

\[
G_0=E_0^TE_0=\begin{pmatrix}4&-2&0\\-2&6&-2\\0&-2&4\end{pmatrix},\qquad
G_0^{-1}=\begin{pmatrix}5/16&1/8&1/16\\1/8&1/4&1/8\\1/16&1/8&5/16\end{pmatrix}.
\tag{17}
\]

The faces encode nontrivial shifts. When `z_j` crosses from `+pi` to `-pi`, the same microscopic point has `y^+=y^-+2pi R e_j` in `M_f`. If this is written in the triple coordinates, let

\[
s^+=\operatorname{pr}(s^-+2\pi Ae_j),\qquad
n=\frac{s^-+2\pi Ae_j-s^+}{2\pi}\in\mathbb Z^2.
\tag{18}
\]

The simultaneous root change is

\[
r^+=r^-+2\pi(R e_j-L_2Ae_j+L_2n)\in M_0.
\tag{19}
\]

For a second-stage face alone, `s_a:+pi -> -pi` entails `r^+=r^-+2pi L_2e_a`. Both columns of `L_2` induce the same root-angle shift modulo integer link coordinates:

\[
q^+=q^-+\frac{2\pi}{16}(1,2,-3)\pmod {2\pi}.
\tag{20}
\]

These equations define the global chart identifications. Smooth microscopic test functions have matching values and derivatives under them; probability currents match under the same translations. There is no reflecting condition. Applying a smooth function of `y` or `r` alone generally produces a discontinuous microscopic test function at these faces. Its current terms therefore cannot be dropped in a weak evolution identity.

All marks are carried through unchanged. A fixed passive gauge change adds the appropriate node angles to both channels and the node-angle differences to each link. It lies in `M_0`, preserves every residual, and translates `y` and `r` accordingly. The maps and kernels below are equivariant for these fixed changes. Marks transform by the original left/right rotations and retain their independent geometry. No quotient by these transformations is silently taken.

## 4. Exact first and second nonlinear potentials

In (12), the complete potential becomes

\[
U(r,s,z)=W_f(z)+kF(s+Az),\qquad
W_f(z)=\sum_{j=1}^5K_j(1-\cos z_j).
\tag{21}
\]

It is independent of `r`. Define the unnormalized first-fiber integrals and effective potentials by

\[
I_1(s)=\int_{[-\pi,\pi)^5}e^{-[W_f(z)+kF(s+Az)]/T}
                     \frac{dz}{(2\pi)^5},\qquad f_1(s)=-T\log I_1(s),
\tag{22}
\]

and define `I_1^0,f_1^0` with `U_0` in place of `U`. Every integral is finite and strictly positive. The functions are smooth and `2pi` periodic in each `s_a`; all derivatives can be passed under the integral because the domain is fixed, finite, and the differentiated integrands are bounded. This remains true although `z` is not a periodic normal coordinate. The first parent laws are

\[
P_{0,1}(dy,dh)=Z_0^{-1}e^{-f_1^0(B_sy)/T}dy dh,\qquad
\pi_1(dy,dh)=Z^{-1}e^{-f_1(B_sy)/T}dy dh.
\tag{23}
\]

There is no retained root dependence beyond the weak residuals. In particular, the second-fiber integral is independent of `r`:

\[
I_2=\int_{[-\pi,\pi)^2}I_1(s)\frac{ds}{(2\pi)^2}=Z,\qquad
I_2^0=Z_0,
\tag{24}
\]

and the second potentials are constants `f_2=-T log Z`, `f_2^0=-T log Z_0`. Thus

\[
P_{0,2}(dr,dh)=\pi_2(dr,dh)=dr dh.
\tag{25}
\]

For an explicit normalization check, let

\[
J(v)=\frac1{2\pi}\int_{-\pi}^{\pi}e^{-v(1-\cos u)/T}du.
\tag{26}
\]

Integrating the two full `s` periods in (21) removes the shift `Az`, yielding

\[
Z=\left(\prod_{j=1}^5J(K_j)\right)J(k)^2,\qquad
Z_0=\left(\prod_{j=1}^3J(K_j-T/(1-a))\right)J(K_4)J(K_5)J(k)^2.
\tag{27}
\]

This exact normalization is compatible with the nonseparable first parent (22): integrating out both weak residuals is a further operation, not a factorization of `I_1(s)`.

The optimizing recognition conditionals are

\[
\kappa_1(dz|y)=\frac{e^{-U(y+Rz)/T}}{I_1(B_sy)}\frac{dz}{(2\pi)^5},\qquad
\kappa_2(ds|r)=\frac{I_1(s)}{Z}\frac{ds}{(2\pi)^2}.
\tag{28}
\]

The genuine downward priors `G_1(dz|y)` and `G_2(ds|r)` replace `U,I_1,Z` by `U_0,I_1^0,Z_0`. Every one is normalized and strictly positive. Their composition gives respectively the exact optimizer and generative conditional of `(s,z)` given `r`. Marks are fixed in these conditionals, because they were retained.

## 5. Physical parent channels and exact VFE composition

Use `u_i=(cos theta_i,sin theta_i,0,0,0)` and `v_i` with `psi_i`. The source's conditional laws are `b_i=N(u_i,I_5)`, `m_i=N(v_i,aI_5)`, and the normalized physical evaluator is `ev_i(zeta_i,dk_i)=N(zeta_i,(1-a)I_5)(dk_i)`. Let `M_x` be the product of the three `m_i`, and let `E(dk|zeta)` be the product of these three evaluators. The latter depends on `zeta`, not on the hidden coordinate or recognition.

The exact first parent model-presentation law and evaluator are

\[
M_{1,y}(d\zeta)=\int G_1(dz|y)M_{y+Rz}(d\zeta),\qquad
P_{{\rm in},1}(d\zeta,dk|y)=M_{1,y}(d\zeta)E(dk|\zeta).
\tag{29}
\]

The exact second parent is

\[
M_{2,r}(d\zeta)=\int G_2(ds|r)\int G_1(dz|r+L_2s)
                         M_{r+L_2s+Rz}(d\zeta),\qquad
P_{{\rm in},2}=M_{2,r}E.
\tag{30}
\]

Tonelli's theorem applies to nonnegative probability kernels and proves normalization directly. The formulas preserve the full three-node physical vector and the independent-link conditional reconstruction. These compact mixtures are generally correlated and non-Gaussian. They are not Gaussians at mean angles. The corresponding recognition physical law uses the actual recognition conditional, or `kappa_1 kappa_2` in the conditional optimizer, followed by the original correlated inner recognition kernel. In that kernel `zeta_i=v_i+xi_i`, `k_i=u_i+xi_i+epsilon_i`, with independent `xi_i~N(0,aI_5)` and `epsilon_i~N(0,(1-a)I_5)`. Substituting the optimizing conditional for a genuine downward prior would change (29)–(30).

For every `Q<<pi`, let `Q_1=(C_1)_#Q` and `Q_2=(C_2)_#Q_1`. The exact dimensionless chain rule is

\[
\operatorname{KL}(Q\Vert\pi)=\operatorname{KL}(Q_2\Vert\pi_2)
+\mathbb E_{Q_2}\operatorname{KL}(Q_1(ds|r,h)\Vert\kappa_2)
+\mathbb E_{Q_1}\operatorname{KL}(Q(dz|y,h)\Vert\kappa_1).
\tag{31}
\]

It follows by factoring the Radon–Nikodym ratio into its retained and conditional ratios and integrating their logarithms. For infinite KL the nonnegative extended-value identity follows by the usual increasing finite partitions, or by applying the conditional relative-entropy chain rule first at one stage and then the other. No mean-field independence of `Q` is required.

The scaled original constrained objective is `F_T(Q)=T KL(Q||pi)+T log(Z_0/Z)`. Therefore each conditional loss in (31) is charged exactly once, multiplied by `T`, and the two-stage minimized objective is

\[
\mathcal F_{T,2}(Q_2)=T\operatorname{KL}(Q_2\Vert dr dh)+T\log(Z_0/Z).
\tag{32}
\]

The first effective evaluator cost in this conditional objective is

\[
d_1(y)=-\log\mathbb E_{G_1(.|y)}e^{-d(y+Rz)}
       =\frac{f_1(B_sy)-f_1^0(B_sy)}{T},
\tag{33}
\]

and its second effective cost is `d_2=log(Z_0/Z)`. Since `d>=0`, both are nonnegative. This is the exact inherited conditional objective for the declared augmented family. It does not assert that an arbitrary new parent inner-recognition ansatz has this same objective.

## 6. The generated interaction is nonzero

Under `kappa_1(.|s)`, differentiate (22) twice to obtain

\[
\nabla f_1(s)=k\mathbb E_s\sin(s+Az),
\qquad
\nabla^2 f_1(s)=k\mathbb E_s\operatorname{diag}\cos(s+Az)
-\frac{k^2}{T}\operatorname{Cov}_s(\sin(s+Az)).
\tag{34}
\]

The covariance subtraction is required; it changes curvature and generates coupling between the weak channels. The change `z -> -z` proves `f_1(-s)=f_1(s)`, hence `grad f_1(0)=0` exactly.

Here is an explicit nonzero interaction certificate for the matched subfamily `K_j=K`. Fix `T,k>0` and send `K` to infinity. Uniformly in `s`, including two `s` derivatives,

\[
f_1(s)=c_K+kF(s)+\frac1{2K}\left[
Tk\sum_{a=1}^2(AA^T)_{aa}\cos s_a
-k^2\sin(s)^TAA^T\sin(s)\right]+O(K^{-2}).
\tag{35}
\]

The constant `c_K=-T log product_j J(K)` is independent of `s`. To check the expansion, use the product even base law proportional to `exp[-K F(z)/T]`. Its odd moments vanish, `E z_i z_j=delta_ij T/K+O(K^-2)`, and `E|z|^4=O(K^-2)`. These moment statements follow by setting `z=sqrt(T/K)u` on `|z|<=K^-2/5`, expanding `1-cos z=z^2/2+O(z^4)`, and bounding the complement by `1-cos z>=2z^2/pi^2`; the complement is exponentially small in `K^1/5`. Taylor expansion of `g_s(z)=exp[-kF(s+Az)/T]` through degree three then gives `E g_s=g_s(0)+(T/(2K))Delta_z g_s(0)+O(K^-2)`. The same argument applies after up to two `s` derivatives because all required derivatives are bounded on the compact domain. Finally, `g_s(0)>=exp(-4k/T)>0` permits the logarithm and yields (35). The constants here depend on fixed `T,k`; this is not a claimed uniform low-temperature expansion.

Since `(AA^T)12=-4/9`, (35) gives

\[
\partial_{s_1}\partial_{s_2}f_1(0)=\frac{4k^2}{9K}+O(K^{-2})>0
\quad\hbox{for every sufficiently large finite }K.
\tag{36}
\]

The generated leading cross term is `4k^2 sin(s_1)sin(s_2)/(9K)`, equivalently a difference of the `cos(s_1-s_2)` and `cos(s_1+s_2)` harmonics. There are also second harmonics in each coordinate. A parent retaining only `k F(s)` therefore changes the exact law at finite `K`. The construction uses (22) throughout, not this expansion.

The fixed-temperature expansion also locates a nonzero interaction inside any nonempty open joined regime; it need not be uniform along its low-temperature defining curve. Freeze positive `T_*,k_*,a_*` at an interior point of that regime and vary only the matched coefficient `K`. The scalar `h(K)=partial_1 partial_2 f_1(0;T_*,k_*,K)` is real analytic on the connected interval `K>0`. Indeed, the finite compact integral and all its `s` derivatives extend holomorphically in `K` near each real positive value by a locally uniform integrable bound; its strictly positive real value gives a nonvanishing neighborhood and analytic logarithmic derivatives. By (36), `h` is not identically zero. A real-analytic function on a connected interval which vanishes on a nonempty open interval vanishes everywhere: its power-series derivatives vanish there, and successive overlapping intervals of analyticity continue that identity along any compact subinterval. Therefore every open admissible `K` interval contains a value with `h(K)!=0`. Continuity then gives an open neighborhood in all the model parameters with a nonzero mixed Hessian, while all previously strict formation and error inequalities remain valid. This is an existence statement inside the open finite regime, not a claim that every point of `K=T^-3` has the fixed-temperature asymptotic remainder.

For a separate elementary fixed-temperature curvature bound, suppose `K_j>=K>=T`. Define

\[
C_* =e^{1/2}\pi^{7/2}/2^{7/2},\quad
M_2=e^{4k/T}5C_*T/K,\quad
\varepsilon_1=k\|A\|\sqrt{M_2},\quad
\varepsilon_2=\varepsilon_1+(k^2/T)\|A\|^2M_2.
\tag{37}
\]

Then, uniformly in `s`,

\[
\|\nabla f_1-k\sin s\|\le\varepsilon_1,\qquad
\|\nabla^2f_1-k\operatorname{diag}\cos s\|\le\varepsilon_2.
\tag{38}
\]

Indeed, for one von Mises coordinate with coefficient `kappa=K_j/T>=1`, integration on `|z|<=kappa^-1/2` lower-bounds its normalized denominator by `e^-1/2/(pi sqrt(kappa))`; extending the numerator to the real line under `1-cos z>=2z^2/pi^2` gives `E z^2<=C_*/kappa`. The weak tilt has ratio at most `e^(4k/T)`, proving `E_s|z|^2<=M_2`. Lipschitz continuity of sine and cosine gives the first error and the diagonal Hessian error. The covariance norm is at most `E_s|sin(s+Az)-sin s|^2<=||A||^2M_2`, proving the second error.

Consequently the actual second conditional potential satisfies

\[
\nabla^2 f_1(s)\succeq[k\cos\rho_s-\varepsilon_2]I
\quad\hbox{on }|s|_\infty\le\rho_s<\pi/2.
\tag{39}
\]

This proves positive curvature for fixed positive `T` and sufficiently large `K`. Its exponential constant is deliberately not used to select the joined polynomial regime `K=T^-p`; the formation lane's restricted-convexity plus tail estimate supplies the sharper bound for that regime. The exact potential and Hessian (22), (34) are the same in both estimates.

## 7. Inherited operators and the precise dynamical qualification

The microscopic generator in the interior of the triple chart is

\[
\mathcal L=T\Delta_{M_0}+T\Gamma:\nabla_s^2+TC:\nabla_z^2
 -(\Gamma\nabla_s U)\cdot\nabla_s-(C\nabla_z U)\cdot\nabla_z
 +T\Delta_H.
\tag{40}
\]

Its global domain obeys (18)–(20). There is no root force because (21) is independent of `r`; there are also no mixed kinetic blocks in this chart. Both facts concern the actual inherited metric, not assigned parent rates.

The constructed first-parent diffusion on the smooth torus `M_f` has generator

\[
\overline{\mathcal L}_1=T\Delta_{M_f}
 -\operatorname{grad}_{M_f} f_1(B_sy)\cdot\operatorname{grad}_{M_f}
 +T\Delta_H.
\tag{41}
\]

It is globally well posed, reversible with respect to (23)'s `pi_1`, and uses exactly the restricted microscopic metric. The conditional averaged interior fine drift equals its drift, since (34) gives `E_kappa1[-P B_s^T k sin(B_sy+Az)]=-grad_Mf f_1(B_sy)`. The actual retained fine law additionally has conditional-force and chart-current corrections; (41) alone is not its exact pushforward generator.

In contrast, the smooth torus homomorphism `y -> B_sy mod 2pi` is legitimate for the diffusion (41), and its residual dynamics close exactly:

\[
ds_t=-\Gamma\nabla f_1(s_t)dt+\sqrt{2T\Gamma}d\beta_t
                          \pmod {2\pi}.
\tag{42}
\]

The second optimizing conditional (28) is independent of `r,h`. On a cube interior, its potential is `f_1(s)` and its diffusion metric is `Gamma^-1`. Thus (39) is a bound on the actual second conditional curvature; there is no derivative of this conditional with respect to a root coordinate and no hidden root-driven score term.

The constructed final parent has constant potential and inherited generator

\[
\overline{\mathcal L}_2=T\Delta_{M_0}+T\Delta_H
=T\operatorname{div}_q(G_0^{-1}\nabla_q)+T\Delta_H.
\tag{43}
\]

It is global Brownian motion with stationary law (25), and not an inserted learning-rate convention. The actual Borel root of (41), however, jumps by (20) at residual cuts and carries their current. Therefore its law need not equal (43)'s law. A derivation replacing it by (43) must include the second interface correction, even though its interior drift is exactly zero. This is the precise remaining dynamical interface to the entropy and comparison lane.

For smooth positive densities under either constructed diffusion, the corresponding entropy obeys `d KL/dt=-T I` with its inherited metric, by integration by parts on its compact smooth torus and mark manifold. Local potential convexity does not imply global conditional entropy convergence on the cut coordinates; the separate global estimates or explicit face-current bounds are needed.

## 8. A concrete failure of an unrecorded smooth quotient

The Borel convention cannot silently be replaced by quotienting by the normal subtorus `N=im(B_f^T:T^5->T^10)`. Because `B_f^T` is injective as a torus map and `det C=24`, its restriction `B_f|N` has degree `24`; hence `N intersect M_f` has 24 points. The map from `M_f` to `T^10/N` forgets those points. It is not (11).

For a direct check, take `x=0` and `g=2pi R e_4 mod 2pi`. Both lie in `M_f`, and both have the same image in that normal quotient. Yet

\[
B_sg=2\pi Ae_4=(-\pi/3,-\pi/3),\qquad U(0)=0,\qquad U(g)=k.
\tag{44}
\]

Thus this forgotten label distinguishes actual weak residuals and physical transported-law discrepancies. For example, node 2's model mean is rotated by `-pi/3` while node 3 and the weak model link have zero angles, giving a nonzero weak model KL; it is zero at `x=0`. It is not merely a forgotten passive gauge angle. A valid alternative quotient could average those conditional branches and explicitly alter its generated potential and physical kernels. Retaining or charging the information of the lost label is required. This example rejects only the unrecorded substitution, not all quotient-based constructions.

## 9. Executed check and delivered scope

The script [check_geometry.py](evidence/nonlinear-parent-geometry/check_geometry.py) was executed with `C:/anaconda/python.exe`. Its output is [geometry-results.json](evidence/nonlinear-parent-geometry/geometry-results.json): eleven exact rational matrix checks establish the right inverses, orthogonal splitting, the inherited root projector, and nonzero cross covariance coefficient. It ran no stochastic dynamics, discretization, GPU work, or tamper scenario. An initial check incorrectly expected the cross coefficient to be positive and failed; the exact value is `-4/9`, and the corrected nonzero assertion produces the positive mixed Hessian in (36). The failed assertion was a sign expectation in this new algebra script, not a scientific-run retry.

The supported result is exact two-stage normalized-law and physical-kernel composition, complete Borel geometry with all branches, inherited local differential expressions, an exact final Haar potential, a nonzero finite-`K` generated interaction, and an explicit actual second conditional-curvature bound. The minimal outside obligation is quantitative control of both actual-law conditional losses and both current corrections on the same horizon as the successive formations. The next material step is to join the accompanying entropy and formation estimates to (11), (20), (28), (34), and (42), preserving the distinction between the actual Borel root and (43).
