<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617","target_digest":"1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617"} -->

# Counterexamples and route boundaries

The normal-subtorus quotient forgets 24 points of the fast coherent torus. The configurations 0 and 2pi R e4 have the same quotient, but their actual weak energies are 0 and k. This rules out an unrecorded smooth quotient substitution, not all explicitly averaged quotient models.

The actual Borel final root changes by 2pi(1,2,-3)/16 when a cut residual crosses a principal face. Its globally pushed path law is therefore not the autonomous Brownian law merely because the local root force is zero. The proof retains this distinction and controls the exceptional event.

A small path distance alone has no general dimensionless KL consequence. The proof uses actual conditional entropy and separate autonomous entropy dissipation. The fixed-temperature mixed-Hessian expansion also does not prove uniform nonvanishing on a low-temperature curve; analytic nonvanishing in a strict open finite-parameter neighborhood supplies the exact claim used.

The crude global Gronwall bound and the e^(4k/T) bulk-moment bound do not join the polynomial horizon. They are retained as insufficient alternative estimates; the completed proof uses contraction, a sharp bulk/tail separation and exponential stopping. These are mathematical counterexamples and scope checks, not file corruption or tamper scenarios.
