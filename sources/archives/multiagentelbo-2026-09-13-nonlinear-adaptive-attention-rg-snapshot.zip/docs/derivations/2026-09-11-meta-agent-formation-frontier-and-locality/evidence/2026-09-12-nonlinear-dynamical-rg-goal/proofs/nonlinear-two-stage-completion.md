<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617","target_digest":"1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617"} -->

# A joined nonlinear two-stage construction

September 12, 2026. This is the integration proof for the [nonlinear contract](evidence/2026-09-12-nonlinear-dynamical-rg-goal/problem-contract.json). The component derivations and [independent reconstruction](nonlinear-independent-reconstruction.md) form part of the proof. The [release record](evidence/2026-09-12-nonlinear-dynamical-rg-goal/final-report.md) states its disposition and frozen revision bindings.

## 1. Model, scope, and what must be joined

Use the compact three-node path model in Sections 2–5 of [common local kinetics](endogenous-rates-and-coherence.md). Its ten angular coordinates specify two Gaussian law points at each node and four independent moving link angles. The main witness uses the allowed angular specialization without additional stabilizer marks. If independent compact stabilizer marks are included, both reductions retain them, and the angular conditional-entropy extension in the entropy derivation applies. The normalized generative energy is the declared node/edge energy with the evaluator correction subtracted; adding the exact optimizing physical-coupling KL gives

\[
 U(x)=K\sum_{j=1}^{5}(1-\cos(B_fx)_j)
       +k\sum_{j=1}^{2}(1-\cos(B_sx)_j).
\]

The proper generative law is denoted by \(P_0\); the variational optimizer is \(\pi\propto e^{-U/T}\). They are different laws. The common microscopic rule is \(dx=-\nabla Udt+\sqrt{2T}dB\), with the same unit angular mobility at every node and link. The supplied contrast is an interaction-energy ratio \(K/k\). Neither node rates nor new parent rates are prescribed. All assertions concern one base point and this finite compact specialization.

Set \(C=B_fB_f^T\), \(R=B_f^TC^{-1}\), \(P=I-RB_f\), \(A=B_sR\), and \(S=B_sPB_s^T\). On the principal fast chart, \(z=B_fx\), \(y=x-Rz\), and \(s=B_sy\). The fast and cut dimensions are five and two. The known exact positive cut eigenvalues are \(1,8/3\); the microscopic common angular kernel has dimension three. These neutral directions are retained, not assigned restoring rates.

The [parent geometry](nonlinear-parent-laws-and-geometry.md) specifies both global Borel retentions and their face identifications. Within their residual charts they are the orthogonal stable-fiber projections, with metric

\[
 |dx|^2=|dy|^2+dz^TC^{-1}dz,
 \qquad |dy|^2=|dr_0|^2+ds^TS^{-1}ds.
\]

The notation \(r_0\) here denotes the retained final root coordinate, not an initial density. The exact first potential is the full compact integral

\[
 F_1(s)=-T\log\int_{[-\pi,\pi)^5}
 \exp\left[-\frac{K\sum_j(1-\cos z_j)
 +k\sum_j(1-\cos(s+Az)_j)}T\right]dz,
\]

up to an irrelevant constant. Normalized Haar factors in every integral are understood as specified in the geometry derivation. The inherited first drift is \(-PB_s^T\nabla F_1(s)\), its cut mobility is \(S\), and its temperature is the original \(T\). The second potential is constant on the retained root. The conditional kernels, generated interactions, physical presentation/evaluator kernels and scalar conditional VFE costs are retained as exact integrals. No quadratic or pairwise truncation defines either parent.

The generated cross interaction is nonzero on a nonempty open subset of the joined regime. The geometry derivation proves, at fixed positive \(T,k\),

\[
 \partial_{s_1}\partial_{s_2}F_1(0)=\frac{4k^2}{9K}+O(K^{-2}).
\]

This fixed-temperature expansion is not substituted into the low-temperature bounds. Instead, at any interior \(T,k\) of the strict joined regime, the left side is a real-analytic function of \(K>0\), nonidentically zero by the expansion. It cannot vanish on an open \(K\) interval: a zero interval forces its Taylor coefficients to vanish and analytic continuation along overlapping intervals then forces it to vanish on the connected positive axis. Every admissible open \(K\) interval therefore contains a nonzero point, with a nonempty open neighborhood by continuity. This proves compatibility of a generated interaction with the common regime without an unproved uniform asymptotic claim on every point of \(K=T^{-3}\).

Three distinct estimates are needed. First, a dynamic path comparison justifies using the first parent while the second cut is still noncoherent. Second, an actual conditional-entropy estimate justifies its VFE correction without interpreting a path distance as KL. Third, late entropy control must hold separately for the actual fine law and for the independently evolved first parent. The two laws are not identified.

## 2. A long finite horizon is compatible with coherence

Here is a stopped diffusion estimate used twice. Let \(X_t\) and its deterministic comparison have the same initial point. Project their lifted difference onto the normal space of the common angular kernel, whose dimension is \(n\). Suppose their whole stopped line segment remains in a convex residual tube where the normal Hessian of the potential is at least \(mI\). The projected error \(E_t\) then satisfies

\[
 E_t\mathbin{\cdot}b_E(t)\le-m|E_t|^2,
 \qquad d\langle E\rangle_t=2TI_n dt.
\]

With \(V(E)=\exp(m|E|^2/(4T))\) and \(u=m|E|^2/(4T)\), direct differentiation gives

\[
 LV\le m(n/2-u)e^u
 \le C_n,\qquad C_n=m\max\{n/2,e^{n/2-1}\}.
\]

Stop at the first radius-\(\rho\) exit or at \(H\). The stopped stochastic integral has mean zero, because its integrand is bounded on this finite interval. Optional stopping and \(V\ge0\) give

\[
 \Pr[\tau_\rho\le H]
 \le (1+C_nH)\exp[-m\rho^2/(4T)].
 \tag{1}
\]

The deterministic trajectory must have a residual margin larger than the image of the radius-\(\rho\) ball. This makes a chart exit impossible before the error exit. Neutral Brownian directions need not remain in a bounded angular lift: the tube restricts residuals only. The fine model uses \(n=7\) and a lower bound \(m\) independent of large \(K\). The parent uses whitened cut coordinates, \(n=2\), and the locally inherited normal lower bound. This proves an exponentially small exit bound over any fixed polynomial horizon in \(1/T\). It makes no all-time, zero-noise, or exact finite-temperature coherence claim.

For the stated fine preparation the required all-horizon deterministic margin is explicit. The nominal invariant two-channel slice has bridge residuals zero, strong residual \(0<x(t)<1/3\), and weak residual \(0<r_{\rm weak}(t)<5/18\) for every time. The source's smaller-cut ODE calculation proves these bounds, not only the two crossing intervals. The full residual cube of radius \(1/2\) therefore has a margin at least \(1/6\). Equations (24)–(26) of the rates derivation give the normal Hessian lower bound \(m=(k/2)\cos(1/2)\) once

\[
 K\ge\frac k2\left(2\|A\|^2+\frac1{c_-}\right).
\]

Same-parameter initial normal perturbations contract until exit, so a sufficiently small initial neighborhood stays within that fixed tube for all times by first exit. The parent ellipsoid and its all-horizon margin are proved in the formation derivation. Small coefficient changes are taken only after fixing the finite horizon, so ordinary continuous dependence preserves its strict margins without claiming a parameter-neighborhood radius uniform over infinite time.

## 3. Uniform first-parent path error

The following argument uses the actual fine process until its residual-chart exit. Introduce an auxiliary adapted finite-variation process \(z^d\), driven by the actual continuous cut path \(s_t\):

\[
 \dot z^d=-KC\sin z^d-kCA^T\sin(s_t+Az^d),
 \qquad z^d(0)=z(0).
\]

This auxiliary equation is a comparison device, not replacement dynamics. Bounded smooth coefficients give its pathwise solution. In the fast tube \(|z_j|<\rho_f<\pi/2\), the existing inward estimate yields

\[
 |C^{-1/2}z^d_t|\le e^{-K\alpha t}R_*+
 \frac{k\beta}{K\alpha},\qquad
 \alpha=c_-\frac{\sin\rho_f}{\rho_f},
 \quad \beta=\sqrt2\|C^{-1/2}B_fB_s^T\|,
\]

where \(c_-=\lambda_{\min}(C)\) and \(R_*\) bounds the initial fast norm. The weak input is bounded for every cut path; no cut equilibrium is used. The condition placing this bound strictly inside the fast tube is part of the joined regime.

For \(\xi=C^{-1/2}(z-z^d)\), both drift evaluations have the same \(s_t\). The whitened fast potential has Hessian at least

\[
 m_f=Kc_-\cos\rho_f-k\|C^{1/2}A^TAC^{1/2}\|.
\]

The noise covariance is exactly \(2TI_5dt\). For large \(K\), \(m_f\ge c_fK>0\). Applying (1) to \(\xi\), stopped also at the fine chart boundary, gives

\[
 \Pr\left[\sup_{t\le H}|\xi_t|\ge\ell
 \text{ before chart exit}\right]
 \le (1+m_fe^{3/2}H)e^{-m_f\ell^2/(4T)}.
 \tag{2}
\]

Consequently, outside this event,

\[
 |z_t|\le\sqrt{c_+}\left[e^{-K\alpha t}R_*+
 \frac{k\beta}{K\alpha}+\ell\right].
 \tag{3}
\]

Initialize the autonomous parent at the actual retained initial point and couple it using the same projected Brownian motion. The [formation derivation](nonlinear-formation-and-common-regime.md) supplies constants \(\delta_K\to0\) and \(m_1>0\), uniform in the regime below, such that

\[
 \|\nabla F_1(s)-k\sin s\|\le\delta_K,
 \qquad \nabla^2F_1(s)\succeq m_1I
\]

on the relevant convex cut tube. Write \(\lambda_1=m_1s_-\), \(s_-=\lambda_{\min}(S)\), \(s_+=\lambda_{\max}(S)\). For \(u=S^{-1/2}(s-\bar s)\), the noise cancels and strong monotonicity gives

\[
 \frac d{dt}|u|\le-\lambda_1|u|
 +\sqrt{s_+}\left(k\|A\||z_t|+\delta_K\right).
\]

Because the two retained paths have exactly the same component in the common kernel, \(|y-\bar y|=|u|\) in these compatible lifts. Integration of (3) gives the uniform bound

\[
 \sup_{t\le H}|y_t-\bar y_t|\le E_K,
\]

\[
 E_K=\sqrt{s_+}\left\{
 \frac{k\|A\|\sqrt{c_+}R_*}{K\alpha}
 +\frac{k\|A\|\sqrt{c_+}[k\beta/(K\alpha)+\ell]
 +\delta_K}{\lambda_1}\right\}.
 \tag{4}
\]

This bound is stopped at either residual-tube exit. The independent fine and parent bounds (1) control those exits; their probabilities and (2) are added, without assuming independence. For any fixed failure tolerance \(\varepsilon>0\), choose

\[
 \ell=\left\{\frac{4T}{m_f}
 \log\frac{1+m_fe^{3/2}H}{\varepsilon}\right\}^{1/2}.
\]

Then \(E_K\to0\) for the polynomial regime below. This is a probability bound for coupled residual-chart paths. Global principal-branch retentions can have repeated discontinuities; no global continuous or cadlag path is asserted for those Borel variables. For bounded path observables defined on the chart, the bad-event contribution is at most twice their sup norm times the stated failure probability.

For a vanishing total failure probability along the limiting family, take the tolerance in (2) to be \(\varepsilon=T\). The same order \(\ell=O(T^2\sqrt{\log(1/T)})\) below holds. A fixed tolerance instead gives the explicitly stated fixed-probability comparison. Bounded chart path observables are understood to have a specified bounded measurable extension on exit, or to be observables of the process sent to a cemetery state on exit.

## 4. Exact entropy costs and the distinct late estimates

Let \(Q_t\) be the fine law, \(Q_{1,t}=C_{1\#}Q_t\), and \(\bar Q_{1,t}\) the law of the autonomous first parent initialized at \(Q_{1,0}\). Let \(\pi_1=C_{1\#}\pi\), \(\pi_2=C_{2\#}\pi_1\). Define \(\Delta_1\) as the fine conditional KL to \(\pi(\cdot|C_1)\), and \(\Delta_2\) as the conditional KL of \(Q_1\) to \(\pi_1(\cdot|C_2)\). The exact KL chain rule gives

\[
 D(Q_t\Vert\pi)=D(Q_{2,t}\Vert\pi_2)+\Delta_2(Q_{1,t})+\Delta_1(Q_t).
 \tag{5}
\]

The scaled eliminated VFE cost is exactly \(T(\Delta_1+\Delta_2)\), when the inherited generative laws and conditional evaluator costs are retained. Separately,

\[
 D(\bar Q_{1,t}\Vert\pi_1)
 =D(C_{2\#}\bar Q_{1,t}\Vert\pi_2)+\Delta_2(\bar Q_{1,t}).
 \tag{6}
\]

The [entropy derivation](nonlinear-second-conditional-entropy.md) proves uniform compact log-Sobolev constants \(C_f,C_p\) for the fine optimizer and exact nonlinear parent in their actual metrics, with the parent uniformity assuming \(K/T\ge1\), \(KT\ge1\), and bounded \(k\). The chosen regime below satisfies both inequalities. It follows that

\[
 \Delta_1(Q_t)+\Delta_2(Q_{1,t})\le H_0e^{-2Tt/C_f},
 \qquad
 \Delta_2(\bar Q_{1,t})\le H_0e^{-2Tt/C_p},
 \tag{7}
\]

where \(H_0=D(Q_0\Vert\pi)\); initial data processing bounds the first-parent entropy by \(H_0\). These are two separate estimates. Neither transfers entropy by path closeness. For a desired \(\eta>0\), their common sufficient time is

\[
 H\ge\frac{\max(C_f,C_p)}{2T}
 \max\{0,\log(H_0/\eta)\}.
 \tag{8}
\]

Denote the right-hand side of (8) by \(t_{\rm ent}\), and choose the total comparison horizon \(H=\max\{3/k,t_{\rm ent}\}+1/k\). The nondegenerate interval \(I_2=[\max\{3/k,t_{\rm ent}\},H]\) then has both whole-block coherence and the two small second conditional losses. The earlier geometric entry and this later entropy-controlled reduction interval are distinct. Adding \(1/k\) does not change any asymptotic horizon estimate below.

The same derivation retains the actual face current and off-tube entropy in the first conditional loss. Its refined all-time gradient estimate gives \(\sup_{t\ge t_a}\Delta_1(t)=O(T^2)\) plus exponentially small terms for \(K=T^{-3}\) and every fixed \(t_a>0\). In particular this includes the pair-only interval \(I_1=[1/(64k),1/(16k)]\), uniformly for \(k\) in a fixed neighborhood of one, and the entire later finite horizon. The barrier margin is verified at fast radius \(7/5\) for the shifted preparation below.

The refinement follows from a direct semigroup calculation. For \(\Lambda=Kc_++3k\), the full flat potential has Hessian at least \(-\Lambda I\). The gradient estimate and variance identity imply

\[
 |\nabla P_s f|^2\le
 \frac{\Lambda[P_s(f^2)-(P_sf)^2]}{T(1-e^{-2\Lambda s})}.
\]

If \(m\le f_t=q_t/\pi\le M\) and \(\|\nabla f_0\|_\infty\le L_0\), use \(s=1/\Lambda\) for later times and the direct gradient estimate for earlier times. Then

\[
 \|\nabla f_t\|_\infty\le
 L_*:=\max\left\{eL_0,M\sqrt{\frac{\Lambda}{T(1-e^{-2})}}\right\}
 \quad\text{for every }t\ge0.
\]

Substituting this into the exact localized entropy balance bounds the boundary contribution by \(T L_*c_\rho E_\rho\log(M/m)/\lambda\), with the explicit positive curvature \(\lambda\), face constant \(c_\rho\), and barrier factor \(E_\rho\) in the entropy derivation. Its exponential dependence is dominated by the strict barrier margin. The integrated retained Fisher budget is the original total entropy \(H_0\); it is not charged afresh on every interval. This gives the uniform first bound without erasing a boundary term or restarting the microscopic process. Equation (7) separately supplies small second conditional losses at the later time (8).

The entropy derivation also gives the actual first principal-face current bound \(|\mathcal J_t(\varphi)|\le2\|\varphi\|_\infty T L_*c_\pi E_\pi\), where \(E_\pi\) includes the barrier \(e^{-2K/T}\). Its time integral through the chosen \(H\) is explicitly bounded by that right-hand side times \(H\), and is exponentially small in the joined regime. The second interface uses the separate residual-chart exit bound; no estimate of its current is inferred from path closeness.

There is also a direct bound for replacement of scalar objectives. Let \(\widetilde Q_{2,t}\) be the autonomous final Brownian law with the inherited root metric, initialized at \(C_{2\#}C_{1\#}Q_0\). Its Haar log-Sobolev constant is at most \(14000\), by the explicit root embedding and the same product argument, so its KL is at most \(H_0e^{-2Tt/14000}\). Every stage objective has the same additive constant: \(\mathcal F_i(Q)=T D(Q\Vert\pi_i)-T\log c\), where \(c=E_{P_0}e^{-d}\). Nonnegativity gives

\[
 |\mathcal F_T(Q_t)-\mathcal F_1(\bar Q_{1,t})|
 \le TH_0(e^{-2Tt/C_f}+e^{-2Tt/C_p}),
\]

\[
 |\mathcal F_1(\bar Q_{1,t})-\mathcal F_2(\widetilde Q_{2,t})|
 \le TH_0(e^{-2Tt/C_p}+e^{-2Tt/14000}).
 \tag{8a}
\]

These are direct late-entropy bounds for the separately evolved laws. They do not identify \(\widetilde Q_{2,t}\) with either actual Borel second marginal. The time (8) also suffices for its entropy bound because \(C_f=25000>14000\).

The parent-force defect is bounded from conditional KL by the bounded microscopic retained force and Pinsker's inequality. The final root drift is zero in each residual chart, because the potential has no derivative in the retained kernel direction. The finite-chart root Brownian motion is inherited with its projected metric and the original temperature. Branch identifications remain in the exact global laws, while (1) controls the exceptional path event on which the local description fails. This separates entropy accounting from interface path accounting.

## 5. One nonempty parameter and initial-law regime

Choose \(k\) in a fixed small interval about one, \(0<a<1\) in a compact subinterval, and nominal initial strong and weak residuals \(x_0\in(1/4,1/3)\), \(y_0\in(1/8,1/6)\). In the global integer coordinates

\[
 (\theta_1,\theta_2,\theta_3;z=B_fx;r=B_sx),
\]

define a smooth positive initial density by independent Haar node angles, five von Mises factors with concentration \(K/T\) and centers \((0,0,0,x_0,x_0)\), and two von Mises factors with concentration \(k/T\) and centers \((y_0,y_0)\). Retained stabilizer marks may have Haar law. This is a law on full configurations; law points are evaluated at configurations, not at mean angles. The integer coordinate change is bijective on the torus. Shifting its factors preserves their normalizers, so direct integration gives

\[
 H_0=2\frac KT(1-\cos x_0)\frac{I_1(K/T)}{I_0(K/T)}
 +2\frac kT(1-\cos y_0)\frac{I_1(k/T)}{I_0(k/T)}
 \le 2\frac KT(1-\cos x_0)+2\frac kT(1-\cos y_0).
 \tag{9}
\]

The inequality follows from \(I_1/I_0=E\cos z\le1\). Concentration outside any fixed neighborhood of these residual centers tends to zero as \(T\downarrow0\). This follows directly by bounding the integral outside that neighborhood by its strictly positive cosine-energy gap and the normalizer below by a cube of side proportional to \(\sqrt{T/K}\) or \(\sqrt{T/k}\).

For an explicit nonempty limiting choice, set \(K=T^{-3}\) and then take a sufficiently small positive \(T\). The formation derivation gives \(\delta_K=O(\sqrt{T/K}+1/K)\) plus a displayed exponentially small tail, and a positive \(m_1\) bounded away from zero. The entropy constants in (7) remain bounded independently of \(T,K\). Thus (8) requires only \(H=O(T^{-1}\log(1/T))\), while (1) tends to zero exponentially. Equation (2) gives \(\ell=O(T^2\sqrt{\log(1/T)})\), and (4) tends to zero. Initial concentration and the early conditional-entropy estimate also hold in this same regime. The cancellation \(K-T/(1-a)>0\) in the declared positive generative node coefficient is automatic for these parameters.

The nominal fine residual ODE has an initially separated strong edge, a pair-only interval, and a later whole-block interval. The exact nonlinear first-parent cut field has the later interval under its inherited metric. The formation derivation supplies strict margins for both. Its convexity argument preserves the later residual bounds for all subsequent times until the specified chart exit. Equations (1)–(4) therefore keep both actual stochastic episodes and the parent comparison valid through the entropy time (8). The grouping is read from those trajectories; it is not a time-dependent model input.

Finally fix one sufficiently small positive \(T\) and one sufficiently large finite \(K\) making every required inequality strict. Continuity gives an open neighborhood in the declared model parameters and residual centers. Multiplication by a positive \(C^1\) factor \(g\), followed by normalization, preserves the density-ratio/derivative bounds and changes the initial bad mass by a bounded factor. If \(g_-\le g\le g_+\), the perturbed entropy has the sufficient budget

\[
 H_0\le \log(g_+/g_-)+
 \frac{4K\sin(x_0/2)+4k\sin(y_0/2)}{T}.
 \tag{10}
\]

This follows by bounding the complete initial log likelihood ratio pointwise. The exact nominal equality (9) is not asserted for the perturbed law. The actual \(H_0\), or the budget (10), is used in (8). A sufficiently small relative \(C^1\) neighborhood gives an open class of full smooth positive correlated densities without initial conditional matching. The one-parameter limiting curve proves nonemptiness of this open finite-parameter regime; the theorem does not restrict parameters to that curve.

## 6. Limits of the construction

The result is a finite nonlinear witness with two stages, fixed microscopic interaction contrast, common local kinetics, and controlled positive-temperature errors. It is not arbitrary-depth closure, learned scale structure, a universal physical clock, a bare-physical-marginal ELBO identity, or permanent finite-temperature agreement. Nonlinear parent integrals and their conditional costs are retained. Exact static pushforwards, approximate path reduction and entropy relaxation are different claims with the bounds above. Compact branch information is declared and is never replaced by reflecting dynamics.
