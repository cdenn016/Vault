"""Check document links and frozen source bytes, not mathematical validity."""

import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote


RUN = Path(__file__).resolve().parent
SOURCE = RUN.parent.parent
SNAPSHOT = json.loads((RUN / "source-snapshot.json").read_text(encoding="utf-8"))
errors: list[str] = []
link_count = 0


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


for entry in SNAPSHOT["proofs"]:
    original = Path(entry["source"])
    frozen = RUN / entry["snapshot"]
    for path in (original, frozen):
        if not path.is_file() or digest(path) != entry["sha256"]:
            errors.append("Proof binding mismatch: " + str(path))
for entry in SNAPSHOT["sources"]:
    path = Path(entry["path"])
    if not path.is_file() or digest(path) != entry["sha256"]:
        errors.append("Source binding mismatch: " + str(path))

new_documents = [Path(entry["source"]) for entry in SNAPSHOT["proofs"]
                 if Path(entry["source"]).name.startswith("nonlinear-")]
for path in new_documents:
    content = path.read_text(encoding="utf-8-sig")
    if re.search(r"\\[,;!]", content):
        errors.append("Excluded LaTeX spacing macro: " + path.name)
    for match in re.finditer(r"\[[^\]\n]+\]\(([^\n]+?)\)", content):
        target = match.group(1).strip().strip("<>")
        if target.startswith(("https://", "http://", "mailto:", "#")):
            continue
        target = unquote(target.split("#", 1)[0])
        if not target:
            continue
        candidate = Path(target)
        if not candidate.is_absolute():
            candidate = path.parent / candidate
        link_count += 1
        if not candidate.exists():
            errors.append("Missing document target in " + path.name + ": " + target)

root_hash = digest(SOURCE / "nonlinear-two-stage-completion.md")
checks = ["nonlinear-geometry-independent-check.md", "nonlinear-entropy-independent-check.md",
          "nonlinear-formation-independent-check.md", "nonlinear-independent-reconstruction.md"]
for filename in checks:
    if root_hash not in (SOURCE / filename).read_text(encoding="utf-8-sig").lower():
        errors.append("Missing final root binding in " + filename)
result = dict(scope="Non-mutating document/provenance checks; no mathematical theorem is established by this script.",
    proof_bindings=len(SNAPSHOT["proofs"]), source_bindings=len(SNAPSHOT["sources"]),
    new_documents=len(new_documents), local_link_occurrences=link_count,
    independent_final_bindings=len(checks), frozen_root=root_hash, errors=errors)
(RUN / "document-validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result))
raise SystemExit(bool(errors))
