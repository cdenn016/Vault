# Actual successive coalescence with an inherited parent equation

September 12, 2026. This is the successive-formation lane for contract
`contract-sha256-b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c`.
It supplies an actual proper-pair interval and a later whole-block interval in
one autonomous microscopic model, with a common kinetic rule. It also supplies
the inherited deterministic parent equation that makes the later episode.
Exact normalized parent laws and conditional VFE identities are stated
separately. A quantitative small-noise path bound is proved. This file does
not claim that those path bounds control conditional relative entropy, or
that the constrained parent diffusion is the exact finite-temperature
marginal process.

## 1. Target, source continuity, and introduced assumptions

The assigned target is existential: there should be a finite law/link
specialization, an open set of parameters and full initial states, and two
ordered finite time intervals on which a proper subset first becomes a
dynamically licensed collective and then that inherited collective interacts
with another node and coalesces again. All statements here concern one base
point \(c_*\), finite horizons, and the same autonomous microscopic equations.
No universal claim about arbitrary graphs, gauge groups, or indefinite
recursion is made.

The user supplies the paired law channels, normalized generative and
recognition distinction, a physical evaluator, independent dynamic links,
common peer-node kinetics, and the need to derive episodes and inherited
equations. The specialization below introduces three nodes on a path,
\(SO(2)\), fixed-covariance Gaussian physical law fibers, compact mean-angle
coordinates, one large internal edge coefficient, a weak cut coefficient,
and equal unit angular mobilities for every node and link. The strong-edge
hierarchy is a disclosed physical input. The episode times, residual bounds,
normal-mode rates, and parent mobility are derived. The observation space can
be a singleton; no observation is needed to create these intrinsic
interactions. Normalized nonconstant evaluators remain present.

Source consultation began with [STATUS](../../STATUS.md) and the current
[problem contract](evidence/2026-09-12-endogenous-dynamical-rg-goal/problem-contract.json).
The [microscopic model](microscopic-vfe-dynamics-construction.md), Sections
3–7 and 10, fixes the evaluator and exact VFE construction.
[Complete coherence](complete-coherence-dynamics.md), Sections 2–3,
requires the full force and distinguishes a restoring mismatch from a
gauge direction. The [parent bridge](dynamical-parent-rg-bridge.md), Sections
2–4 and 7–7.2, already supplies common-channel conditional accounting but
uses selected node rates and an initially whole-network coherent basin.
The [assembly](dynamical-rg-assembly.md) explicitly excludes an earlier
pair-only episode from its conclusion.

The [earlier Gaussian construction](../2026-09-11-fast-slow-derived-hierarchy/gaussian-hierarchy-construction.md),
G1–G5, and its [report](../2026-09-11-fast-slow-derived-hierarchy/final-report.md)
already derive scales from a graph and common local kinetics, but their
witness has different law/link content.
[Common-prior native episodes](common-prior-native-hierarchy-episodes.md),
Sections 2 and 5–6, concern ancestry posterior modes.
[Native boundary attraction](native-boundary-attraction-and-second-merge-limit.md),
Sections 6–7, gives a scoped split-favored boundary regime.
[The second-merge barrier](second-merge-scale-regime-and-native-barrier.md),
Sections 2 and 5, distinguishes a favorable static variance curve from
actual learning trajectories. None is being imported as a general
capability or resource gate.

The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>),
`sec:meta_agent_formation`, `sec:cross_scale_shadows`,
`sec:meta_agent_rg` (especially `eq:rg_internal_hessian`,
`eq:rg_slow_graph_metric`, and `eq:rg_schur_flow`), and
`sec:scale_dependent_time`, and the
[September synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>)
were consulted read-only. Internal restoring modes, inherited graph metrics,
exact conditional laws, and covariance-dependent information clocks are
existing ideas in those sources. The calculation below supplies a missing
trajectory-level instance; it makes no literature-priority claim.

Two mechanisms were considered. A strongly coupled compact path has a
closed two-residual equation whose first decisive lemma is an actual
pair-only interval followed by a later cut relaxation. A globally quadratic
translation-link model would instead permit explicit Gaussian conditional
and spectral calculations; that route is being handled by the parent task,
so this lane does not duplicate it. The compact route is developed here.

## 2. One normalized two-channel model and one kinetic prescription

Write \(V(t)=1-\cos t\), \(n(t)=(\cos t,\sin t)\), and take
\(W=(w^b,w^m)\in\mathbb T^{10}\), where each five-coordinate channel is

\[
w=(\theta_1,\theta_2,\theta_3,\phi_{12},\phi_{23}).
\]

In the model channel replace \(\theta\) by \(\psi\). The edge \(12\) maps
node 2 into node 1; edge \(23\) maps node 3 into node 2. All four link
angles are independent coordinates. With fixed \(0<a<1\), the physical laws
and evaluator are

\[
b_i=N(n(\theta_i),I_2),\qquad
m_i=N(n(\psi_i),aI_2),\qquad
\zeta_i\sim m_i,\quad k_i\mid\zeta_i\sim N(\zeta_i,(1-a)I_2).
\tag{1}
\]

They are probability laws on their stated Euclidean fibers. Orthogonal
link pushforward gives transported KL \(V(x_b)\) in the belief channel and
\(V(x_m)/a\) in the model channel, where

\[
a_0=(1,-1,0,-1,0),\quad b_0=(0,1,-1,0,-1),\qquad
x_x=a_0w^x,\quad y_x=b_0w^x.
\tag{2}
\]

The row names \(a_0,b_0\) are unrelated to the covariance scalar \(a\).
Fix positive coefficients and define

\[
U_0=
 A_bV(x_b)+A_mV(x_m)+B_bV(y_b)+B_mV(y_m)
 +\sum_{i=1}^3\lambda_{0,i}V(\theta_i-\psi_i),\qquad
P_0=Z_0^{-1}e^{-U_0/T}\nu ,
\tag{3}
\]

where \(T>0\) and \(\nu\) is normalized Haar measure on
\(\mathbb T^{10}\). Every exponential is positive and bounded, so
\(0<Z_0<\infty\). A normalized same-node conditional is the von Mises
kernel proportional to
\(\exp[(\lambda_{0,i}/T)\cos(\theta_i-\psi_i)]d\theta_i/(2\pi)\),
with uniform \(\psi_i\); multiplying its product by the bounded edge
tilt and renormalizing gives (3). Thus the intrinsic edge dependence is
part of a declared normalized population prior.

For any outer recognition density \(q(W)\), use the correlated conditional
recognition

\[
\zeta_i=n(\psi_i)+\xi_i,\qquad
k_i=n(\theta_i)+\xi_i+\epsilon_i,\qquad
\xi_i\sim N(0,aI_2),\quad
\epsilon_i\sim N(0,(1-a)I_2).
\tag{4}
\]

Its two marginals are exactly (1). If \(P_i^{\rm ev}=m_i\operatorname{ev}_i\)
and \(R_i\) denotes (4), then for every coupling \(S_i\) with these
marginals,

\[
\operatorname{KL}(S_i\Vert P_i^{\rm ev})
=\operatorname{KL}(S_i\Vert R_i)
 +\frac{\|n(\theta_i)-n(\psi_i)\|^2}{2(1-a)}.
\tag{5}
\]

Indeed the log density ratio \(R_i/P_i^{\rm ev}\) is affine in
\(k_i-\zeta_i\), with expectation fixed by the marginals; adding log
density ratios proves the identity. Its finite expectation is guaranteed
by the Gaussian marginals. The singular case has infinite KL to both
positive densities. Therefore the exact optimized conditional evaluator
cost and restricted outer VFE are

\[
d(W)=\frac1{1-a}\sum_iV(\theta_i-\psi_i),\qquad
U=U_0+Td,\qquad
\mathcal F_T(q)=T\operatorname{KL}(q\Vert P_0)+T\mathbb E_qd.
\tag{6}
\]

The generative augmented law is \(P_0\prod_iP_i^{\rm ev}\); it is
normalized. Its physical evaluator is not replaced by recognition.
The variational optimizer is
\(\Pi=Z^{-1}e^{-U/T}\nu\), which need not equal \(P_0\).

Every one of the ten microscopic angles uses the same prescription

\[
dW=-\nabla U(W)dt+\sqrt{2T}dB\pmod{2\pi}.
\tag{7}
\]

There are ten independent Brownian coordinates, including four independent
link noises. Unit angular mobility is an explicit positive multiple of
each Gaussian angular Fisher inverse; no node-specific multiplier occurs.
The deterministic equations below are the drift of (7) at fixed \(T\),
not a claim that a Dirac outer law has finite entropy.

The drift is a bounded smooth periodic vector field. Its lift to
\(\mathbb R^{10}\) is globally Lipschitz, giving unique global deterministic
solutions and, by the same integral-equation estimates, global strong
solutions of (7). The torus forward equation is
\(\partial_tq=\operatorname{div}(q\nabla U+T\nabla q)\). For positive
smooth \(q\), integration by parts gives

\[
\frac{d}{dt}\mathcal F_T(q)
=-T^2\int q|\nabla\log(q/\Pi)|^2d\nu\le0.
\tag{8}
\]

Smooth initial densities have finite VFE because \(\Pi\) is bounded above
and below on the compact carrier. Ordinary parabolic smoothing also
permits a smooth compactly supported initial density at positive times.
The conditional-lag lane is responsible for any stronger entropy
quantification needed for a parent approximation.

A passive common local frame change adds \(\gamma_i\) to
\(\theta_i,\psi_i\), and \(\gamma_i-\gamma_j\) to both links \(j\to i\).
All seven residuals and (3)–(8) are invariant, and the physical kernels
push forward under the corresponding rotations. These statements
concern frames at \(c_*\); they do not introduce base paths.

## 3. Exact residual equations and actual separated episode windows

Take the nominal coefficient subfamily

\[
A_b=A_m=A\ge256,\qquad B_b=B_m=1,\qquad
\lambda_{0,i}=\lambda_0>0.
\tag{9}
\]

The deterministic channel-symmetric slice
\(w^b=w^m=w\) is invariant: all bridge gradients vanish, and the two
channel equations coincide. Each channel then has the exact equation

\[
\dot w=-A a_0^\top\sin x-b_0^\top\sin y.
\]

Because \(|a_0|^2=|b_0|^2=3\) and \(a_0b_0^\top=-1\),

\[
\boxed{\dot x=-3A\sin x+\sin y,\qquad
       \dot y=A\sin x-3\sin y.}
\tag{10}
\]

The link drifts are \(\dot\phi_{12}=A\sin x\) and
\(\dot\phi_{23}=\sin y\). In particular the strong link is not frozen
while its two incident law points align.

Use lifted initial states

\[
x_0\in(1/4,1/3),\qquad y_0\in(1/2,2/3),\qquad
w_0=(x_0+y_0,y_0,0,0,0).
\tag{11}
\]

Initial lifts differing by a common gauge shift are also admissible.
Define the horizontal residual

\[
z=y+x/3,\qquad c=8/3.
\]

Direct substitution, without an approximation, gives

\[
\boxed{\dot z=-c\sin(y)=-c\sin(z-x/3).}
\tag{12}
\]

**Trajectory theorem.** For every \(A\ge256\) and every (11), the
deterministic solution of (7) on the nominal symmetric slice has

\[
\begin{array}{ll}
t\in I_1=[1/64,1/16]:&
0<x(t)<1/512,\qquad y(t)>11/36,\\[2mm]
t\in I_2=[3,4]:&
0<x(t)<1/512,\qquad 0<y(t)<1/256 .
\end{array}
\tag{13}
\]

Its channel bridge residuals vanish throughout. Thus a graph joining an
edge only when both transported phase residuals have absolute value below
\(1/32\) has three singleton components initially, components
\(\{1,2\}\) and \(\{3\}\) throughout \(I_1\), and the whole path
throughout \(I_2\). This threshold reports already-proved mismatch
bounds; it does not cause an update, alter an edge, or schedule a merge.

**Proof.** The positive quadrant is invariant, since the vector field
points inward at \(x=0\) and \(y=0\). While \(x,y\ge0\) and
\(z\le7/9<1\), (12) makes \(z\) nonincreasing.
At \(x=x_0\), (10) points inward because
\(3A\sin x_0>1\). A first-exit argument therefore gives, for all
positive times,

\[
0<x\le x_0<1/3,\qquad 0<y\le z\le z_0<7/9.
\tag{14}
\]

Strict positivity follows either from uniqueness at a boundary or the
bounds \(\dot x\ge-3Ax\) and \(\dot y\ge-3y\).
On \([0,1]\), Taylor's alternating estimate gives
\(\sin s\ge s-s^3/6\ge5s/6\). Hence

\[
x(t)\le \frac13 e^{-(5A/2)t}+\frac{2}{5A}.
\tag{15}
\]

For \(t\ge1/64\) and \(A\ge256\), this is at most
\(e^{-10}/3+1/640<1/512\). The exponential inequality can be
verified directly from the positive Taylor series for \(e^{10}\);
the accompanying exact check uses rational partial sums.

Also \(\dot z\ge-8/3\), so for \(t\le1/16\),

\[
y=z-x/3
 >7/12-(8/3)(1/16)-1/9=11/36.
\tag{16}
\]

For the later interval set \(k=20/9\), \(h=5A/2\). Equations
(12), (14), and (15) imply

\[
\dot z\le-kz+(k/3)x,
\]

and direct integration yields

\[
z(t)\le
\left[\frac79+\frac{k}{9(h-k)}\right]e^{-kt}
+\frac{2}{15A}
<e^{-kt}+\frac{2}{15A}.
\tag{17}
\]

Here \(h>k\) and the bracket is less than one for \(A\ge256\).
For \(t\ge3\), \(e^{-kt}\le e^{-20/3}<1/512\):
indeed \(e>8/3\) and \(e^{2/3}>5/3\) imply
\(e^{20/3}>(8/3)^6(5/3)>512\).
Thus \(z<1/512+1/1920<1/256\).
Since \(0<y\le z\), this proves (13). All estimates remain in the
single residual chart (14), so there is no unexamined chart exit. \(\square\)

The first strong-edge threshold crossing occurs strictly before \(1/64\);
the cut remains outside that threshold through \(1/16\) and crosses
before time 3. Continuity proves existence of these crossings. No claim
of unique crossing times is needed.

### 3.1 A smaller-cut initial interval for the common entropy regime

The same proof also applies when (11)'s cut interval is replaced by

\[
x_0\in(1/4,1/3),\qquad y_0\in(1/8,1/6).
\tag{17a}
\]

Now \(z_0<5/18\), the initial cut is still strictly outside the
\(1/32\) coherence threshold, and (15) still proves the strong-edge
bound on \(I_1\). The lower differential bound
\(\dot y\ge-3y\) gives

\[
y(t)\ge y_0e^{-3t}>\frac18e^{-3/16}
>\frac{13}{128}>\frac1{10},\qquad t\in I_1.
\tag{17b}
\]

For the middle inequality, the positive exponential series gives
\(e^s<\sum_{n\ge0}s^n=(1-s)^{-1}\) for \(0<s<1\);
take \(s=3/16\). The late-time calculation (17) has the smaller
initial coefficient \(5/18\) in place of \(7/9\), so the same
\(I_2\) upper bounds follow unchanged. The inherited parent begins
with a cut residual above \(13/128\) and still passes below
\(1/256\) by time 3. All parameter, initial-state, and noise
perturbation arguments below apply with the same \(\rho\):
\(13/128-2/4096>1/10\), so the pair-only margin survives.

The smaller interval (17a) is the preferred candidate for joining
the separate conditional-entropy estimate. Its horizontal initial
cut mismatch is below \(5/18\). This geometric bound does not itself
prove any likelihood-ratio or conditional-entropy estimate. The
larger interval (11) remains an independently proved trajectory
regime.

## 4. Inherited collective variables, graph metric, and second episode

This section distinguishes a local horizontal coordinate useful for the
proof from a globally defined normalized coarse channel.

For one channel let

\[
P=I-\frac{a_0^\top a_0}{3},\quad v=Pb_0^\top,\quad
Y=Pw,\quad |v|^2=8/3.
\tag{18}
\]

The exact projected fine equation and its constrained parent are

\[
\dot Y=-v\sin(b_0Y-x/3),\qquad
\boxed{\dot{\bar Y}=-v\sin(b_0\bar Y).}
\tag{19}
\]

The latter is the Euclidean graph-metric gradient of
\(V(b_0Y)\) on \(\ker a_0\). It is obtained by restricting the original
potential and the original kinetic metric to the strong constraint,
not by assigning a new parent rate. At the first formation time
\(t_1=1/64\), initialize \(\bar Y(t_1)=Pw(t_1)\).

In coordinates

\[
q=(\alpha,\theta_3,\phi_{12},\phi_{23}),\qquad
w=(\alpha+\phi_{12},\alpha,\theta_3,\phi_{12},\phi_{23}),
\]

the inherited metric and drift are explicitly

\[
G=
\begin{pmatrix}
2&0&1&0\\
0&1&0&0\\
1&0&2&0\\
0&0&0&1
\end{pmatrix},
\qquad
\begin{pmatrix}\dot\alpha\\\dot\theta_3\\
\dot\phi_{12}\\\dot\phi_{23}\end{pmatrix}
=
\begin{pmatrix}-2/3\\1\\1/3\\1\end{pmatrix}
\sin(\alpha-\theta_3-\phi_{23}).
\tag{20}
\]

This follows from \(G=S^\top S\) for the displayed embedding \(S\);
its \((\alpha,\phi_{12})\) inverse block is
\(\frac13\left(\begin{smallmatrix}2&-1\\-1&2\end{smallmatrix}\right)\).
The internal link therefore continues to move with velocity
\(\sin(y)/3\) after reduction. Its reaction to the exterior force is
part of the inherited model. The retained parent is a joint
belief/model/link object, not an isolated scalar mean.

The parent cut residual \(\bar z=b_0\bar Y\) solves

\[
\dot{\bar z}=-(8/3)\sin\bar z,\qquad
\tan\frac{\bar z(t)}2=
\tan\frac{\bar z(t_1)}2 e^{-(8/3)(t-t_1)}.
\tag{21}
\]

At \(t_1\), \(\bar z=z>11/36\). At time 3,
\(\bar z\le(7/9)e^{-k(3-t_1)}<1/256\), because
\(k(3-t_1)>6\) and \(e^6>(8/3)^6>256\).
Thus this first inherited parent itself has a subsequent cut-coalescence
episode. Its initial state is the first actual trajectory's retained
state; its interactions and metric are (20). No separate parent system
or new learning-rate choice enters.

There is a quantitative comparison. On the residual interval \([0,1]\),
the function \(-c\sin s\) is decreasing. Pairing the scalar error
equation with its sign therefore gives

\[
D^+|z-\bar z|\le(c/3)x,\qquad
|z(t)-\bar z(t)|
\le \frac c3\int_{t_1}^t x(s)ds.
\tag{22}
\]

The vector counterpart follows by pairing the error in (19) with its
unit direction, using monotonicity of
\(Y\mapsto v\sin(b_0Y)\):

\[
\|Y(t)-\bar Y(t)\|
\le\frac{\sqrt c}{3}\int_{t_1}^t x(s)ds
\le\frac{\sqrt c}{3}
 \left[\frac{2}{15A}+\frac{2(t-t_1)}{5A}\right].
\tag{23}
\]

These are finite-time \(O(A^{-1})\) estimates with stated norms. They
do not assert equality of fine and coarse path laws.

The fast directions are genuine restoring directions. On the coherent
strong-edge set, changing \(w\) along \(a_0^\top\) changes \(x\) with
derivative 3. Its Hessian-normal stiffness is \(3A\); it is not tangent
to the gauge directions, all of which are annihilated by \(a_0\).
The coupled residual linearization at full coherence has positive
decay rates

\[
\lambda_\pm=
\frac{3(A+1)\pm\sqrt{9(A-1)^2+4A}}2,\qquad
\lambda_+=3A+O(1),\quad \lambda_-\longrightarrow8/3.
\tag{24}
\]

The second rate equals (21)'s inherited rate. Large \(A\) was supplied
as a coupling strength, not as a local update coefficient. In the full
two-channel local Hessian, the two strong-edge directions have stiffness
at least \(3\min(A_b,A_m)\cos(1)\) in the admitted residual neighborhood;
all bridge contributions are positive semidefinite there. The remaining
stiffness is bounded in terms of the weak and bridge coefficients.
This establishes the first restoring-band separation for the complete
state.

For the second reduction use the projection on the first retained space

\[
Q=P-\frac{vv^\top}{c}
 =I-C^\top(CC^\top)^{-1}C,\qquad
C=\begin{pmatrix}a_0\\b_0\end{pmatrix},\quad
CC^\top=\begin{pmatrix}3&-1\\-1&3\end{pmatrix}.
\tag{25}
\]

Thus \(Q\) annihilates both residual rows and is exactly the direct
two-constraint orthogonal projection. Along the nominal inherited
parent, \(Q\bar Y\) is constant because \(Qv=0\). The second discarded
direction \(v\) has positive stiffness \(c\) at the cut minimum, so it
is a restoring cut mismatch, not a passive gauge coordinate.
At \(t\ge3\),

\[
\|\bar Y-Q\bar Y\|=|\bar z|/\sqrt c<1/(256\sqrt c).
\tag{26}
\]

Both channels undergo these same operations. Their bridge interaction,
when off the symmetric slice, is restricted with the original metric
and is retained in full; it is not dropped by the reduction.

There is no claim of a second parametrically large separation between
every remaining bridge mode and the cut mode. The second reduction here
is licensed by its actually relaxed restoring direction, a small
finite-time residual, and the inherited subsequent trajectory. A
uniform stochastic autonomous second parent for general transverse
states needs the separate conditional-dynamics estimates.

## 5. Full open initial and parameter regime; independently moving links

The nominal symmetric slice is used to obtain formulas, not as the
final initial-data hypothesis.

Fix a nominal \(A\ge256\), \(\lambda_0>0\), \(T>0\), and (11).
For the full ten-angle potential, collect the seven residual rows
\(r_j\): four edge rows of norm \(\sqrt3\) and three bridge rows
of norm \(\sqrt2\). On the convex lifted set
\(|r_jW|<1\) for every \(j\), all coefficients are positive and

\[
\nabla^2U(W)=\sum_j k_j\cos(r_jW)r_j^\top r_j\succeq0.
\tag{27}
\]

The nominal trajectory has edge residuals bounded by \(7/9\) and bridge
residuals zero. Let \(p\) perturb the four positive edge coefficients
and the three positive effective bridge coefficients
\(\lambda_i=\lambda_{0,i}+T/(1-a)\), with the common unit kinetic
prescription fixed. Define the explicit force discrepancy bound

\[
D=
\sqrt3\left(|\Delta A_b|+|\Delta A_m|
           +|\Delta B_b|+|\Delta B_m|\right)
+\sqrt2\sum_i|\Delta\lambda_i|.
\tag{28}
\]

The sine bound gives
\(\sup_W\|\nabla U_p(W)-\nabla U_*(W)\|\le D\).
For the same lift, let
\(\epsilon_0=\|W_p(0)-W_*(0)\|\) and choose

\[
\rho=\frac1{4096\sqrt3},\qquad
\boxed{\epsilon_0+4D<\rho.}
\tag{29}
\]

Before the error reaches \(\rho\), both paths and their joining segment
remain in (27)'s convex region. If \(E=W_p-W_*\), then

\[
\frac12\frac d{dt}\|E\|^2
=-E^\top[\nabla U_*(W_p)-\nabla U_*(W_*)]
 -E^\top[\nabla U_p(W_p)-\nabla U_*(W_p)]
\le D\|E\|.
\]

Consequently \(D^+\|E\|\le D\), and a first-exit argument gives

\[
\sup_{0\le t\le4}\|W_p(t)-W_*(t)\|
\le\epsilon_0+4D<\rho.
\tag{30}
\]

This proves the full open extension, including independent perturbations
of all matter angles and all four link angles. The parameter and
initial-state inequalities are strict and nonempty. Positivity of the
coefficients survives after shrinking the coefficient neighborhood.
They are open within the declared specialization with fixed common
unit kinetics. No selected node acceleration is allowed or needed.

Every edge residual changes by less than \(\sqrt3\rho=1/4096\), and
every bridge residual by less than \(\sqrt2\rho\). Therefore the
initial, \(I_1\), and \(I_2\) classifications with threshold \(1/32\)
all persist. In \(I_1\) the weak cut remains larger than \(1/4\);
in \(I_2\) all edge mismatches remain below \(1/32\), with small
same-node bridge mismatch.

At nominal time zero both link drifts in both channels are strictly
nonzero:
\(A\sin x_0>A/5\) and \(\sin y_0>1/3\).
These strict signs persist on a full open initial and parameter
neighborhood for a nonzero initial interval. Independent link
perturbations generally make the two channels' link trajectories
different. At positive noise, all four links also have independent
nondegenerate driving noises. Equality on the nominal reference slice
does not turn the links into vertex-ratio variables.

For the perturbed deterministic parent use the same constraint
embedding and the full restricted weak-plus-bridge potential
\(V_p|_{\ker R}\), where \(R\) consists of the two strong-edge rows.
Its induced metric is the block version of (20). The same monotonicity
argument bounds its deviation from the nominal parent by its initial
projection error plus \(4D\), as long as the smaller residual tube is
used. It therefore retains the strict later episode after a further,
still open shrinking of (29). This is an actual inherited parent field
with its transverse bridge forces, not an assumption of exact
channel equality for all admitted initial data.

## 6. A finite positive-noise path statement

Let a fine initial density place probability at least \(1-\varepsilon_{\rm init}\)
inside the initial neighborhood in (29). Conditional on an initial point
there, compare (7) with the deterministic solution with that same initial
point and coefficients. Stop at the first time their Euclidean lifted
difference has norm \(\rho\), or at \(H=4\). The whole stopped segment
remains in the convex residual chart. Itô's formula and (27) give

\[
d\|E_t\|^2\le 20Tdt+2\sqrt{2T}E_t^\top dB_t.
\]

The stopped stochastic integral has expectation zero because the
integrand is bounded and the time is bounded. At an exit the squared
norm is exactly \(\rho^2\). Therefore

\[
\boxed{\Pr\left[\sup_{t\le4}
 \|W_t^T-W_t^{\rm det}\|\ge\rho\right]
 \le\frac{80T}{\rho^2},}
\tag{31}
\]

where the left event uses the initial convex-chart comparison and its
first exit. A exit from that chart cannot happen before the
\(\rho\)-difference exit, by the previously established margins.
Including the initial failure probability gives

\[
\Pr[\text{all initial, pair-only, and later whole-block
mismatch bounds survive}]
\ge1-\varepsilon_{\rm init}-80T/\rho^2.
\tag{32}
\]

The deterministic-to-nominal and noise-to-deterministic errors together
change an edge residual by at most \(2/4096\), well within every strict
margin in (13). For any specified failure tolerance, a positive
temperature interval satisfies (32). This is deliberately conservative.

Smooth bump initial densities inside (29) have finite outer entropy
and can be correlated. For a condition requiring
\(0<m\le q_0/\Pi\le M<\infty\) on the entire torus, one may instead
mix such a smooth normalized bump with \(\varepsilon_{\rm init}\Pi\).
For each fixed positive \(T\), the mixture is smooth, positive,
has ratio bounded above and below, and has finite ratio-gradient
bounds by compactness. Those constants depend on \(T\), the bump
radius, and the mixture weight. They must be carried in an entropy
estimate; this file does not claim uniformity as \(T\downarrow0\).

A fixed smooth multiplier of \(\Pi_T\) does not by itself keep a weak
cut concentrated at nonzero \(y_0\) as \(T\downarrow0\), since the
weak-edge Gibbs factor favors zero mismatch. Any such initialization
proposal requires its actual temperature-dependent tilt or mixture
constants. Path concentration alone gives no dimensionless KL bound.

## 7. Global normalized parents and exact conditional VFE composition

The projection \(P\) in (18) involves thirds of lifted angles. It is
not a globally well-defined homomorphism of the original torus, and
is not used as the global probability channel.

Instead define the global, recognition-independent coordinate-forgetting
maps

\[
C_1:\mathbb T^{10}\longrightarrow\mathbb T^8
\quad\hbox{forget }(\theta_1,\psi_1),\qquad
C_2:\mathbb T^8\longrightarrow\mathbb T^6
\quad\hbox{forget }(\theta_2,\psi_2).
\tag{33}
\]

All four link marks and both root law angles survive. On the first
constraint, \(\theta_1=\theta_2+\phi_{12}\) and
\(\psi_1=\psi_2+\phi_{12}^m\), so these retained coordinates determine
the coherent pair. On the second constraint, the surviving node-3
laws and the actual link marks determine all three coherent law
points. They are ordinary normalized Gaussian laws as in (1);
general finite-strength parent mixtures are not asserted Gaussian.

In one channel the coordinates of \(Pw\) retained by \(C_1\) differ
from \(C_1w\) only by \(x/3\) in \(\theta_2\) and \(\phi_{12}\);
their norm discrepancy is \(\sqrt2|x|/3\). Thus (23) and (15)
transfer to the globally defined retained variables after the first
layer. Initializing the parent at \(C_1w(t_1)\), rather than
\(C_1Pw(t_1)\), adds precisely this bounded initialization error.
It does not change any mobility. The strict subsequent-episode margin
survives it. The second map similarly differs from the horizontal
second projection by an explicitly linear quantity bounded by a
constant times the already small cut residual.

For any one of these maps \(C\), define the true generative parent
\(P_0^c=C_\#P_0\) and the original generative child conditional
\(P_0(dW\mid z)\). Compact positive smooth densities make all fiber
integrals finite, positive, and smooth; differentiation under an
integral is justified by bounded derivatives on the compact fiber.
Define

\[
h_1(z)=\mathbb E_{P_0(\cdot\mid z)}e^{-d(W)},\quad
d_1(z)=-\log h_1(z),\quad
K_1^*(dW\mid z)=h_1(z)^{-1}e^{-d(W)}P_0(dW\mid z).
\tag{34}
\]

For every finite-KL outer law \(Q\), the exact identity is

\[
\frac{\mathcal F_T(Q)}T=
\operatorname{KL}(Q_1\Vert P_1)
+\mathbb E_{Q_1}d_1
+\mathbb E_{Q_1}\operatorname{KL}
       (Q(\cdot\mid Z)\Vert K_1^*(\cdot\mid Z)),
\quad P_1=C_{1\#}P_0,\ Q_1=C_{1\#}Q.
\tag{35}
\]

To check it, split the marginal and conditional log-density ratios
in \(\operatorname{KL}(Q\Vert P_0)\), then use
\(\log(K_1^*/P_0(\cdot\mid z))=-d+d_1(z)\).
All three terms in (35) are nonnegative; its extended interpretation
does not subtract infinite quantities.

At the second stage, use the actual \(P_1,d_1\):

\[
h_2(z_2)=\mathbb E_{P_1(\cdot\mid z_2)}e^{-d_1(Z_1)},\qquad
d_2=-\log h_2.
\tag{36}
\]

Conditional expectation gives
\(h_2=\mathbb E_{P_0(\cdot\mid z_2)}e^{-d(W)}\).
The fine conditional-KL residual and the stage-one conditional-KL
residual add to the direct fine-to-final conditional-KL residual,
because \(K_1^*\) is exactly the conditional of the optimizer
\(\Pi\), and its stage-one marginal has tilt \(e^{-d_1}\).
Thus neither the evidence normalization nor any induced interaction
is discarded at either step.

A parent physical evaluator is obtained from the same original
generative law by

\[
\operatorname{Ev}_1(d\zeta,dk\mid z)
=\int\prod_iP_i^{\rm ev}(d\zeta_i,dk_i\mid W)
                  P_0(dW\mid z).
\tag{37}
\]

Its integral is one. Required retained source dependence and all
four link marks remain in the conditioning argument. A second
integration using the induced \(P_1\) agrees with direct integration,
by Tonelli and the tower property. These formulas retain the complete
generated interactions; no pairwise ansatz replaces their logarithms.
Predictive child priors use mixtures of the true
\(P_0(dW\mid z)\), not \(K_1^*\), unless an additional equality has
been proved.

The deterministic graph-metric limit (20), the exact probability
marginals (33)–(37), and finite-temperature marginal kinetics are
different assertions. The finite-\(A\) retained coordinate process
has its original microscopic quadratic variation; identifying it
with an autonomous diffusion having inverse metric \(G^{-1}\)
requires a genuine limiting or conditional-memory argument.
Equations (31)–(32) do not provide that argument or a bound on the
last term of (35).

## 8. Checkable result, falsifier, and remaining interface

The strongest result of this lane is the explicit open-family
successive-trajectory theorem: common microscopic angular kinetics,
initially mismatched proper nodes, a strict pair-only interval,
a later whole-block interval, nontrivial moving independent links,
and a first inherited parent equation that itself undergoes the
later episode. The collective coefficient \(8/3\) and internal-link
reaction \(1/3\) are calculated from the same microscopic metric.
The normalized global law/evaluator channels and exact conditional
VFE corrections compose without approximation.

The result would be falsified by a sign error in (10), failure of the
invariant residual region (14), violation of an inequality in
(15)–(17), failure of the graph-metric calculation (20), or failure
of the convexity/first-exit argument supporting the full open
extension. None of these claims depends on a numerical trajectory.
The tiny check in `evidence/successive-coalescence/` verifies the
rational projector identities and elementary constants only.

The command
`C:/anaconda/python.exe evidence/successive-coalescence/exact_check.py`
(with the script path resolved from this document's directory) ran once
and completed successfully. Its standard-library `Fraction` assertions
and computed matrices are saved in
[exact-check.json](evidence/successive-coalescence/exact-check.json).
The [script](evidence/successive-coalescence/exact_check.py) does not
integrate an ODE or stand in for the analytical proof.

The minimal unresolved interface is quantitative compatibility of
the normalized conditional law in (34), its moving transient
recognition conditional, and the inherited stochastic parent
kinetics through both episodes. In particular the conditional
force correction and dimensionless conditional KL must be bounded
in the same initial-law and temperature regime, or retained as a
controlled dynamical term. The parent task's conditional-lag lane
addresses that obligation. This file does not assign any ledger
state or assert completion of the entire existential goal.

The novelty fingerprint relative to the consulted local sources is:
a fixed three-node compact path with stiffness hierarchy instead
of selected node rates; the exact horizontal cancellation
\(z=y+x/3\); strict initially-singleton, pair-only, and whole-block
time windows; inherited graph mobility with an internal link still
moving by the cut reaction; and an explicit full-state transverse
perturbation and small-noise extension. The next decisive action is
to join the conditional-lag estimate to the initialization and the
same positive-temperature window in (32).

Only this document and its assigned tiny-check directory are owned
by this lane. No production/configuration edit, scientific sweep,
GPU job, suite, Lean work, tamper scenario, Research-vault edit,
shared-record edit, or Git publication was performed.
