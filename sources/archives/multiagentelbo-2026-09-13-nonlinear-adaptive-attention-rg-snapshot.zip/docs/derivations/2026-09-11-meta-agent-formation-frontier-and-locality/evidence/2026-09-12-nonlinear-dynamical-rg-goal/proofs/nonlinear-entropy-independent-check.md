# Independent reconstruction of the nonlinear entropy interfaces

September 12, 2026. Scope: Sections 4–5 of
[the joined nonlinear construction](nonlinear-two-stage-completion.md), its
early first-conditional estimate, and the distinction between the actual
fine marginal and the autonomous inherited laws. This is a reconstruction
of the mathematical arguments. It assigns no ledger closure and does not
certify the separate geometric tube proof.

The target is conditional on the exact model and retentions specified in
[the entropy component](nonlinear-second-conditional-entropy.md): for every
smooth positive initial full angular density, every finite positive `K,k,T`,
and every time, derive conditional KL bounds for the actual fine law and,
separately, for the independently evolved first parent. On the explicit
common low-temperature family, also check early first-conditional decay
and the finite late entropy horizon. No equivalence of the two stochastic
laws is assumed.

## 1. Borel retentions do preserve the exact entropy accounting

Let `Pi` be the positive optimizing probability law on the fine torus.
For a positive smooth recognition law write `f=dQ/dPi`. For the first
retention `Y=xi_1(W)` and second `Z=xi_2(Y)`, set

$$
m(Y)=\mathbb E_\Pi[f\mid Y],\qquad
n(Z)=\mathbb E_{\Pi_1}[m\mid Z],\qquad \Pi_1=\xi_{1\#}\Pi.
\tag{1}
$$

These are the marginal density ratios `dQ_1/dPi_1` and `dQ_2/dPi_2`.
The conditional density ratios are exactly `f/m` and `m/n`. Since the
carrier is compact and both original densities are smooth positive,
`f`, `m`, and `n` are bounded above and away from zero, so every logarithm
below is integrable. Directly expanding the defining expectation yields

$$
\begin{aligned}
\operatorname{KL}(Q\Vert\Pi)
 &=\mathbb E_Q\log f\\
 &=\mathbb E_Q\log n
   +\mathbb E_Q\log(m/n)+\mathbb E_Q\log(f/m)\\
 &=\operatorname{KL}(Q_2\Vert\Pi_2)
   +\mathbb E_{Q_2}\operatorname{KL}(Q_1(dY\mid Z)\Vert\Pi_1(dY\mid Z))
   +\mathbb E_{Q_1}\operatorname{KL}(Q(dW\mid Y)\Vert\Pi(dW\mid Y)).
\end{aligned}
\tag{2}
$$

No derivative of a retention map appears here. The principal-residual
maps are Borel maps between compact standard Borel spaces, which admit
regular conditional probabilities. Their half-open-face conventions fix
the maps everywhere, while boundaries themselves have zero probability
under the smooth laws. Thus their lack of continuity does not invalidate
(2). Conversely, this observation says nothing about the continuity or
Markov property of a projected path.

For the autonomous first-parent law `bar Q_1`, repeat the last two terms
of this argument with its own density ratio against `Pi_1`. One obtains
the second, separate identity

$$
\operatorname{KL}(\bar Q_1\Vert\Pi_1)
 =\operatorname{KL}(\xi_{2\#}\bar Q_1\Vert\Pi_2)
 +\mathbb E_{\xi_{2\#}\bar Q_1}
  \operatorname{KL}(\bar Q_1(dY\mid Z)\Vert\Pi_1(dY\mid Z)).
\tag{3}
$$

Replacing the final term of (3) by the second term of (2) would be an
unjustified law identification. The integration draft keeps them separate.

## 2. Reconstruction of the two uniform constants

The coordinate transformation
`W -> (theta_1,theta_2,theta_3,d_1,d_2,d_3,x_b,x_m,y_b,y_m)` has the integer
inverse displayed in the component. Its inverse rows contain respectively
`1,1,1,3,3,2,2,2,5,5` squared unit entries in the order of the fine state,
whose sum is `25`. This is an exact torus automorphism, not a map of a
nontrivial finite cover. The reference law becomes three Haar factors and
seven von Mises factors. It imposes no factorization on recognition.

The original
[Cheng–Mao–Zhang circle theorem, Theorem 3.1](https://sxzz.whu.edu.cn/html/2020/6/20200606.htm),
uses `Ent(g²)<=2 C int |g'|²` and implies `C<=1000` uniformly in its
concentration parameter; its zero-concentration Haar limit follows by
uniform convergence. Tensorizing and applying
`|grad_X g|²<=||J^{-1}||² |grad_W f|²` gives `C_f=25000` in the actual
unit-mobility microscopic metric.

For the base first parent, global coordinates
`(theta_1,theta_2,theta_3,s_b,s_m)` have the embedding (15) of the component.
Its squared row counts sum to `16`. Hence its induced metric `G=E^T E`
gives `C_b=16000` from the same product inequality. In particular, the
Dirichlet form is `grad_u f^T G^{-1} grad_u f`; using independent unit
coordinate noise would change the kinetic model.

The exact parent law differs from this base law by the unnormalized ratio

$$
R(s)=\mathbb E_{\rho_{K/T}}
 \exp\{-k[F(s+AZ)-F(s)]/T\}.
\tag{4}
$$

The weak difference obeys
`|k[F(s+AZ)-F(s)]|<=k sqrt(2)||A|| sum |Z_j|`. The elementary Gaussian
upper bound on each principal fast factor and a central interval lower
bound on its normalizer give exactly equations (17)–(19) of the component:

$$
M^{-1}\le R(s)\le M,\quad
M=\left(e^{1/2}\sqrt{\pi/(2/\pi^2)}\right)^5
\exp\left[\frac{5(k\sqrt2\|A\|)^2}{4(2/\pi^2)KT}\right].
\tag{5}
$$

The normalized ratio has supremum-to-infimum ratio at most `M²`, not
`M^4`: its common normalizer cancels. Applying the nonnegative entropy
integrand `v log(v/a)-v+a` proves the bounded-perturbation estimate
`C_p=16000 M²`. This argument integrates a discontinuous retained map
statically; it does not apply a smooth Lipschitz-map theorem to it.
For `K=T^{-3}` and `0<T<=1`, both needed inequalities `K/T>=1` and `KT>=1`
hold, and `C_p` is bounded independently of temperature. The constant can
be very large; the argument asserts finite asymptotic control, not a
practical simulation time.

## 3. Entropy dissipation and the late horizon

For either actual diffusion, or any one of the autonomous inherited
diffusions in its own metric, let `mu` denote its invariant density and
`f_t=q_t/mu`. Its forward equation is
`partial_t q=T div(mu grad f)`. Differentiating the expectation
`H=int q log f` and integrating by parts gives

$$
H'=-T\int q|\nabla\log f|^2.
\tag{6}
$$

The circle theorem convention matters: applying
`Ent_mu(g²)<=2 C int |grad g|²` to `g=sqrt(f)` gives
`H <= (C/2) int q |grad log f|²`. Thus

$$
H(t)\le H(0)e^{-2Tt/C}.
\tag{7}
$$

It is `2T/C`, not `T/C`, and not a concentration-`K` rate. Initializing
the autonomous first parent at the actual initial marginal gives its
initial entropy at most the full initial entropy, by (2). Applying
(7) separately, then dropping the nonnegative final marginal entropies in
(2)–(3), proves exactly the two inequalities in Section 4 of the
integration draft. None uses a path comparison.

The autonomous final root has three Haar coordinates with metric matrix
`[[4,-2,0],[-2,6,-2],[0,-2,4]]`. Its trace is `14`, giving `C_2=14000`
by the same calculation. Its initialization is the twice-pushed initial
law, so its entropy also obeys (7) with initial upper bound `H_0`.
The actual twice-pushed fine law and twice-pushed autonomous-parent law
need not equal this autonomous root law after branch exits.

For an error tolerance `eta>0`, the common sufficient relaxation time is
`max(C_f,C_p)/(2T) max(0,log(H_0/eta))`; `C_2` is already smaller than
`C_f`. The generative evaluator recursion produces the common objective
offset `-T log c`. Hence exact elimination errors are `T` times the
conditional entropies in (2)–(3), and differences of independently evolved
objective values are bounded by `T` times the corresponding sums of total
entropies. These two statements concern different comparisons and must
both retain their stated laws.

## 4. Uniform first entropy after relaxation for the same preparation

The shifted product preparation in Section 5 of the integration draft
has exactly the same partition function as the reference product law.
If its two strong residuals have center `x_0` and its two weak residuals
center `y_0`, its likelihood ratio is
`exp[(K Psi_a+k Psi_b)/T]` with the cosine differences in component (40).
Expectation under each shifted factor gives

$$
H_0=2(K/T)V(x_0)c(K/T)+2(k/T)V(y_0)c(k/T),
\quad c(h)=\mathbb E_{\mu_h}\cos Z\in[0,1].
\tag{8}
$$

This confirms the nominal initial-entropy formula and upper bound in
the draft. For a positive multiplier `g`, the uniform budget is instead

$$
B=\log(g_+/g_-)
 +[4K\sin(x_0/2)+4k\sin(y_0/2)]/T,
\tag{9}
$$

and the gradient of the ratio is bounded by component (42). The nominal
formula (8) cannot be silently reused for an arbitrary correlated
multiplier; (9) is sufficient and has the same polynomial order.

To check the early estimate, the prior compact theorem gives a sum of
the initial exponential relaxation, the driven plateau
`Gamma² H_0/(2 lambda²)`, the outside/label entropy, and the convolution
of the actual boundary current. Its exponentially growing derivative
bound can be improved. Writing `Lambda=K lambda_max(C)+3k`, the stochastic
flow gives `|grad P_u h|²<=exp(2Lambda u) P_u|grad h|²`. On the other hand,
differentiating `P_u[(P_{s-u}h)²]` and integrating gives

$$
P_sh^2-(P_sh)^2
 =2T\int_0^sP_u|\nabla P_{s-u}h|^2du
 \ge\frac{T}{\Lambda}(1-e^{-2\Lambda s})|\nabla P_sh|^2.
\tag{10}
$$

The inequality direction follows by applying the gradient estimate to
`P_{s-u}h` for time `u` and rearranging it. With `s=1/Lambda`, the left
side is at most `e^{2B}` for every evolved density ratio; before that
time the flow bounds its gradient by `e L_0`. This proves the all-time
gradient constant in component (44c). The current convolution is then
bounded by its constant amplitude divided by `lambda`, giving component
(45). There is one exponential `e^B` in the tail and current factors;
the lower likelihood-ratio bound occurs only through a logarithm.

With `rho=7/5`, the barrier margin is strictly positive:
`1-cos(rho)-4sin(1/6)>2299/15000`, using the fourth-order alternating
cosine bound and `sin x<x`. For every `t>=t_a>0`, large `K`, and small
`T`, the tail/current exponent is at most `-delta K/(2T)` up to a
constant, as checked in component (46), with no growing time factor.
Since `lambda` is proportional to `K`, the plateau is `O(1/(KT))` and
the first term is bounded by `O(K/T) exp(-cKt_a)`. For `K=T^{-3}` the
first conditional loss is consequently `O(T²)` plus exponentially small
terms for all `t>=1/64`, including the first episode, the interval between
the episodes, and the late entropy horizon. This verifies conditional
equilibration after fast relaxation without matched initial conditionals
and without erasing the first current correction. At the actual principal
fast faces the energy barrier is `2K`; substituting the same uniform
gradient bound gives component (47a), a directly controlled weak
integrated first gluing current over any polynomial horizon.

The same parameter curve has `H_0=O(T^{-4})` and bounded parent LSI
constant, so its late entropy horizon is `O(T^{-1}log(1/T))`. This
arithmetic establishes compatibility with a proved tube bound of the
form `poly(H) exp(-c/T)`. It does not prove that tube bound or its
deterministic geometric margins; those are separate hypotheses to be
checked in the formation reconstruction.

## 5. Result and revision qualification

Within the checked entropy scope, the component supplies a complete
derivation: global static Borel disintegration is exact; the nonlinear
parent LSI follows from a proved likelihood comparison in the induced
metric; the two actual-law entropy estimates come from separate
diffusions; and the common positive preparation has both the early
first-conditional estimate and a finite late second-stage estimate.
The autonomous-root estimate additionally supports the direct late
objective-value comparisons.

The final integration explicitly retains both qualifications identified
in this reconstruction: the uniform parent constant uses `K/T>=1` and
`KT>=1`, and the open multiplier class uses its actual initial entropy or
the pointwise budget rather than the nominal shifted-product formula.
Its final Section 4 also includes the all-time semigroup estimate, the
first principal-face current bound, and a nondegenerate second interval
`[max(3/k,t_ent),max(3/k,t_ent)+1/k]`. On that interval the entropy bounds
are small; the first loss is already small after its fast relaxation.
This removes an otherwise possible ambiguity between initial geometric
entry and the later entropy-controlled second reduction.

No unresolved algebraic or analytic step remains within this checked
entropy scope. The actual two-episode tube and branch comparison through
the late horizon is outside this assigned reconstruction; it must have
its own mathematical check. Agreement with another writer supplies no
evidence for that separate obligation.

This reconstruction was finalized after rereading the frozen integration
Sections 4–5 and checking the current file digests. The source revisions
are:

- `nonlinear-two-stage-completion.md`: SHA-256
  `4f3d840dc8b078ea1f764fc39c33685b561ec343aada97a3c092164c475c27f3`.
- `nonlinear-second-conditional-entropy.md`: SHA-256
  `0477874217fe99ee517f56bc729aa60b25d95573fc485a27614aceaa308000d5`.

These digests locate the reconstructed artifacts; the mathematical
evidence is the argument above, not fingerprint equality. Any change to
those sources requires checking whether it affects this scope before
reusing the reconstruction. The exact finite coordinate calculation
was run under `C:/Python314/python.exe` and is retained in
[matrix-results.json](evidence/nonlinear-conditional-entropy/matrix-results.json).
It corroborates the finite constants only; no numerical entropy test,
full suite, GPU run, Lean proof, or tamper check was performed.
