<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617","target_digest":"1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617"} -->

# Rigorous theory search report

## Frozen contract

The unchanged existential target in problem-contract.json asks for a nonlinear two-stage construction in the existing compact law/link model, with both normalized parents, inherited operators, actual conditional losses and successive formation in one open positive-temperature regime. The Gaussian predecessor is an analytic reference, not this witness.

## Terminal status

COMPLETE_AFFIRMATIVE within that finite contract. Written analytical derivations and their independent reconstruction support the result. The structural validator checks the record and file bindings, not mathematical truth.

## Certificate

Target claim `target` depends on the normalized nonlinear parents, first and second interfaces, successive formation and joined regime. proofs/nonlinear-two-stage-completion.md integrates the three component derivations. The ledger records eleven claims with current evidence artifacts and explicit assumptions A1–A5. The dependency graph and complete independent reconstruction cover their full closure.

## Strongest verified result

A compact cosine model with ten angular coordinates, independent moving links and one common microscopic mobility has a coherent pair interval before whole-block coherence. Its exact five-coordinate nonlinear first parent undergoes the later coalescence with its inherited metric. Both normalized integrations, physical vector kernels, genuine downward priors and optimizing conditional costs compose through dimensions 10, 5 and 3.

In a nonempty open regime centered near K=T^-3, the first actual conditional KL is uniformly O(T^2) after a fixed initial time, with explicit initial-layer and boundary terms. The actual fine second conditional loss, the autonomous first-parent second loss and the autonomous final-root entropy have separate finite-time bounds. The required late horizon is O(T^-1 log(1/T)); exponential residual-tube bounds and contraction keep both the episodes and the path approximation valid through it. The first approximation error tends to zero, and final-root path equality holds inside the controlled chart with the branch-exit event retained. A generated nonlinear cross interaction is nonzero on an open subset of this same regime.

## Dependency closure

The ledger separates normalized physical kernels, global Borel geometry, generated interaction, inherited dynamics and independent objective replacement from the five original target obligations. The proofs retain current terms, nonlinear covariance corrections, normalization constants and the actual versus autonomous law distinctions. No hidden conditional-matching or global-Brownian assumption closes a dependency.

## Independent reconstruction

Three construction specialists supplied narrower root-integration checks. A separate fourth expert reconstructed the full theorem, including the [Cheng–Mao–Zhang circle log-Sobolev theorem](https://sxzz.whu.edu.cn/html/2020/6/20200606.htm), its coordinate and metric applicability, the uniform-gradient first-entropy estimate, dissipative path coupling and exact normalized-law composition. The full record is proofs/nonlinear-independent-reconstruction.md; the other check documents retain their assigned scopes and source bindings. The exact matrix checks are supplementary identities, not stochastic simulations or substitutes for proof.

## Oracle erasure

reconstruction-and-erasure.md removes the requested outcome from the premises. Supplied inputs remain visible: microscopic energy contrast, the normalized law family, a common kinetic rule, the initial preparation and finite tolerances. The derived equations, integrations and inequalities still imply the claimed two stages. Neither a desired grouping nor a new parent clock is a premise.

## Unresolved obligations

None within the frozen finite existential target. General gauge groups, learned scales or covariances, arbitrary merger histories, infinite depth and permanent positive-temperature coherence are outside this target, not claims settled by this construction.

## Scope and limitations

The result is a finite mathematical construction, not an empirical discovery or a universal hierarchy theorem. The declared model inputs are not derived. Parent states are correlated marked vector laws with augmented conditional costs. The final Borel root is not globally identical to Brownian motion; the theorem includes its boundary correction and finite-chart error. The second KL guarantee can occur later than geometric coalescence. No production model change, full suite, GPU job, Lean proof, tamper test, historical rerun, vault edit or Git publication was part of this continuation.
