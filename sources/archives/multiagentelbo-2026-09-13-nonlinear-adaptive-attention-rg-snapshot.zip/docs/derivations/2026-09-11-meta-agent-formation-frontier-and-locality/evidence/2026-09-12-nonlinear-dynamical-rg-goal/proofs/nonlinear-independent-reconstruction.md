# Independent reconstruction of the nonlinear two-stage theorem

September 12, 2026. This record checks the existential target in [the frozen contract](evidence/2026-09-12-nonlinear-dynamical-rg-goal/problem-contract.json), digest `1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617`. It is an independent mathematical reconstruction, not a ledger closure. Its conclusion rests on the calculations below and the stated primary-source functional inequality, rather than on another reviewer's verdict. A source-version addendum at the end records the final files inspected.

## 1. Target, quantifiers, and scope

The target is the existence of a nonempty open finite-parameter and smooth positive initial-density regime of the existing compact three-agent, two-channel cosine law/link model at one base point. Every datum in the regime must admit two compatible nontrivial retentions, exact normalized generative and optimizing parent laws, inherited operators, quantitative conditional-entropy and dynamical errors, and an actual proper-pair episode preceding whole-block coalescence. The intended stochastic conclusion is a finite-horizon high-probability statement with explicit exceptional events; positive temperature does not give permanent exact agreement on every realization.

The user supplies the law-section ontology, independent links, normalized physical evaluators, correlated recognition, one common microscopic update prescription, and the finite-depth goal. The witness supplies the path graph, compact circle parameters, positive cosine energies with strong/weak contrast `K/k`, the unit angular Dirichlet mobility, the initial law, and reporting thresholds. The energy contrast is physical input. Neither the retentions' restoring rates nor a merger schedule are independently assigned. The main checked witness omits optional stabilizer factors; independent compact stabilizer marks can be retained, but the numerical entropy constants below concern the ten-dimensional angular witness.

More explicitly, fix the phase-agreement reporting threshold `1/32`, a desired conditional-KL tolerance `eta>0`, and a desired path failure probability `p>0`. The argument below gives sufficiently small finite `T>0`, sufficiently large finite `K`, `k` near one, and an open set of positive smooth initial laws for which there are an early interval `I_1=[1/(64k),1/(16k)]`, a later interval beginning by `3/k`, and a finite horizon `H` beyond the entropy time. Proper-pair and whole-path agreement hold on an event of probability at least `1-p`; the two distinct late conditional-KL bounds hold for the full laws without an exceptional event. The path error can be made arbitrarily small by further decreasing `T` in the displayed regime.

Exact equality is asserted for normalized measure pushforwards, physical kernels, and conditional VFE composition. The first autonomous parent is a quantitatively controlled approximation to the retained microscopic dynamics. The autonomous final Brownian process equals the local root projection under the coupled chart description until exit, with an explicit exit exception. No global smooth or cadlag interpretation of the Borel projections is assumed.

The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:meta_agent_rg`, `eq:rg_laplace`, `eq:rg_slow_graph_metric`, and `eq:rg_schur_flow`, distinguishes exact pushforward, conditional closure, inherited graph metric, and force errors. The read-only [September RG synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>) locates those prior investigations. The proof below respects those distinctions; the manuscript is contextual input, not proof of this witness.

## 2. Normalized microscopic law and common kinetics

Order the angular coordinates as

\[
x=(\theta_1,\theta_2,\theta_3,\psi_1,\psi_2,\psi_3,
\alpha_{12}^b,\alpha_{23}^b,\alpha_{12}^m,\alpha_{23}^m)\in\mathbb T^{10}.
\]

The five fast rows `B_f` are the three node differences `theta_i-psi_i` and the two edge-12 differences. The two rows `B_s` are the edge-23 differences. Let `V(u)=1-cos u`, and put

\[
U=K\sum_{j=1}^5V((B_fx)_j)+k\sum_{a=1}^2V((B_sx)_a),
\qquad d=\frac{1}{1-a}\sum_{i=1}^3V(\theta_i-\psi_i),
\quad 0<a<1.
\]

Set `U_0=U-Td`, require `K>T/(1-a)`, and use normalized Haar `nu`. Then

\[
P_0=Z_0^{-1}e^{-U_0/T}\nu,\qquad
\pi=Z^{-1}e^{-U/T}\nu,\qquad
c=E_{P_0}e^{-d}=Z/Z_0.
\]

Compactness makes both normalizers finite and strictly positive. The physical conditional model is `zeta_i~N(n(psi_i),aI_5)` followed by `k_i|zeta_i~N(zeta_i,(1-a)I_5)`, with `n(theta)=(cos theta,sin theta,0,0,0)`. The constrained recognition coupling shifts only the conditional mean of `k_i` by `n(theta_i)-n(psi_i)` while keeping its covariance and the `zeta_i` marginal. Its conditional Gaussian KL is

\[
\frac{|n(\theta_i)-n(\psi_i)|^2}{2(1-a)}
=\frac{V(\theta_i-\psi_i)}{1-a}.
\]

This follows directly from the conditional Gaussian log-density ratio. Optimality under the fixed marginals follows by translating `k_i` back by that mean difference: the remaining KL is minimized uniquely by the original Gaussian conditional joint, and the mean contribution is fixed. Therefore the exact augmented objective is

\[
\mathcal F_T(Q)=T D(Q\Vert P_0)+T E_Qd
=T D(Q\Vert\pi)-T\log c.
\tag{R1}
\]

The microscopic SDE is `dx=-grad U dt+sqrt(2T)dB` on the torus. Its smooth bounded periodic drift is globally Lipschitz on a Euclidean lift. It consequently has a unique global strong solution, and its positive smooth initial density remains smooth and positive. Its divergence-form equation and periodic integration by parts give

\[
\frac{d}{dt}D(Q_t\Vert\pi)
=-T\int q_t|\nabla\log(q_t/\pi)|^2d\nu.
\tag{R2}
\]

This is the declared common transport/Dirichlet kinetics. It is not a claim that the scalar VFE uniquely specifies kinetics. Independent fixed passive node frame changes translate both node-channel angles and shift each link by the endpoint difference. They preserve all residuals and the metric. The common kernel directions are neutral, and are not counted as restoring modes.

## 3. Exact retained geometry and parent laws

Define

\[
C=B_fB_f^T,\quad R=B_f^TC^{-1},\quad P=I-RB_f,
\quad A=B_sR,\quad S=B_sPB_s^T,\quad L_2=PB_s^TS^{-1}.
\]

The relevant matrices are

\[
C=\begin{pmatrix}2&0&0&1&-1\\0&2&0&-1&1\\0&0&2&0&0\\
1&-1&0&3&0\\-1&1&0&0&3\end{pmatrix},
\quad A=\begin{pmatrix}0&1/2&-1/2&-1/6&-1/6\\0&-1/2&1/2&-1/6&-1/6\end{pmatrix},
\]

\[
S=\begin{pmatrix}11/6&5/6\\5/6&11/6\end{pmatrix},
\quad AA^T=\begin{pmatrix}5/9&-4/9\\-4/9&5/9\end{pmatrix}.
\tag{R3}
\]

The eigenvalues of `C` are `2,2,3,(5-sqrt(17))/2,(5+sqrt(17))/2`: its nontrivial two-dimensional difference block is `[[2,2],[2,3]]`. The cut eigenvalues are `1,8/3`. Independent link columns give full row rank of the stacked seven-row matrix. Thus `C>0`, `S>0`, and the common kernel has dimension three.

The torus kernels `M_f=ker B_f` and `M_0=ker(B_f,B_s)` are connected. On `M_f`, set `psi=theta` and both strong links equal to `theta_1-theta_2`; the two weak links remain free. On `M_0` set both weak links equal to `theta_2-theta_3`. These give global parametrizations by five and three angles, and establish lattice primitivity in addition to real rank.

For half-open principal representatives define

\[
z=\operatorname{pr}(B_fx),\quad y=x-Rz,\quad
s=\operatorname{pr}(B_sy),\quad r=y-L_2s.
\]

Since `B_fR=I`, `B_fL_2=0`, and `B_sL_2=I`, the inverse is exactly

\[
x=r+L_2s+Rz\pmod{2\pi}.
\tag{R4}
\]

This is a Borel bijection with `M_0 x [-pi,pi)^2 x [-pi,pi)^5`. Haar disintegration under each surjective homomorphism gives

\[
d\nu=dr\frac{ds}{(2\pi)^2}\frac{dz}{(2\pi)^5}.
\tag{R5}
\]

This product identity concerns measure, not global product topology. At `z_j:+pi -> -pi`, `y` changes by `2pi R e_j`. If `s'=pr(s+2pi A e_j)` and `n=(s+2pi A e_j-s')/(2pi)`, then `r` changes by `2pi(R e_j-L_2A e_j+L_2n)`. At `s_a:+pi -> -pi`, `r` changes by `2pi L_2e_a`. These translations preserve the same microscopic point. In particular they cannot be dropped from dynamics of a test function of `y` or `r` alone.

The three summands in the differential of (R4) are orthogonal. Consequently

\[
|dx|^2=|dr|^2+ds^TS^{-1}ds+dz^TC^{-1}dz.
\tag{R6}
\]

For the root embedding by its three node angles,

\[
G_0=\begin{pmatrix}4&-2&0\\-2&6&-2\\0&-2&4\end{pmatrix}.
\]

The first exact optimizer potential is

\[
F_1(s)=-T\log I_1(s),\qquad
I_1(s)=\int e^{-[K\sum_jV(z_j)+k\sum_aV(s_a+(Az)_a)]/T}
\frac{dz}{(2\pi)^5}.
\tag{R7}
\]

The analogous generative integral uses `U_0`. Integrating a full period of each `s_a` removes `Az`; hence, with `J(v)=int exp[-vV(u)/T]du/(2pi)`,

\[
Z=J(K)^5J(k)^2,\quad
Z_0=J(K-T/(1-a))^3J(K)^2J(k)^2.
\tag{R8}
\]

The second parent is therefore Haar on `M_0` for both generative and optimizing laws. The normalized downward generative kernels use `U_0`, whereas the optimizing kernels are

\[
\kappa_1(dz|y)=I_1(B_sy)^{-1}e^{-U(y+Rz)/T}\frac{dz}{(2\pi)^5},
\quad \kappa_2(ds|r)=Z^{-1}I_1(s)\frac{ds}{(2\pi)^2}.
\]

All integrands are positive and their derivatives are bounded on the fixed compact domain. Differentiation under the integrals and Tonelli integration of physical probability kernels are justified. Mixing the original model-presentation Gaussian laws by the genuine downward generative kernels, then using the unchanged normalized evaluator, gives the physical parents. These mixtures need not be Gaussian and retain the full declared physical vector. The optimizing kernels are not substituted for the generative kernels.

For every finite-KL `Q`, factoring its density ratio into the two conditional ratios proves

\[
D(Q\Vert\pi)=D(Q_2\Vert\pi_2)+\Delta_2(Q_1)+\Delta_1(Q).
\tag{R9}
\]

The costs are ordinary conditional KL in nats. The corresponding omitted VFE is exactly `T(Delta_1+Delta_2)` by (R1), and the same additive constant `-T log c` occurs at every stage.

## 4. The nonlinear operator and generated interaction

Direct differentiation of (R7) yields

\[
\nabla F_1=kE_s\sin(s+Az),\qquad
\nabla^2F_1=kE_s\operatorname{diag}\cos(s+Az)
-\frac{k^2}{T}\operatorname{Cov}_s(\sin(s+Az)).
\tag{R10}
\]

Inversion `z -> -z` proves `F_1(-s)=F_1(s)` and `grad F_1(0)=0`. The negative covariance term is load-bearing. At fixed positive `T,k`, the product even fast law has `E ZiZj=delta_ij T/K+O(K^-2)` and `E|Z|^4=O(K^-2)`. Local rescaling `z=sqrt(T/K)u` proves these facts; outside `|z|<=K^-2/5`, the bound `V(z)>=2z^2/pi^2` makes the contribution exponentially small. Taylor expansion through degree three, with the odd terms integrating to zero, then gives in `C^2(s)`

\[
F_1=c_K+k\sum_aV(s_a)
+\frac{Tk\sum_a(AA^T)_{aa}\cos s_a
-k^2\sin(s)^TAA^T\sin(s)}{2K}+O(K^{-2}).
\]

Thus `partial_1 partial_2 F_1(0)=4k^2/(9K)+O(K^-2)>0` at sufficiently large finite `K`. This is a fixed-temperature certificate, not a uniform low-temperature expansion. For fixed positive `T,k`, that mixed derivative is real analytic in `K>0`: compact integrals extend holomorphically locally and their positive real denominators remain nonzero locally. Since the function is not identically zero, it cannot vanish on an open `K` interval. Every admissible open interval therefore contains a nonzero point; continuity gives a nonempty open joined subregime with this generated interaction. This correctly avoids using a fixed-temperature remainder uniformly along `K=T^-3`.

The first autonomous generator is

\[
\bar L_1=T\Delta_{M_f}-\operatorname{grad}_{M_f}F_1(B_sy)\cdot\operatorname{grad}_{M_f}.
\tag{R11}
\]

Its cut process closes exactly as `ds=-S grad F_1 dt+sqrt(2TS)dB`. The local second root generator is `T Delta_M0`, or `T div(G_0^-1 grad)` in its node-angle coordinates. These mobilities follow from (R6). The fine retained drift averages to (R11) under `kappa_1`, but its actual marginal also has conditional-force and face-current corrections.

## 5. Actual first conditional entropy, including its interfaces

Fix `rho=7/5`, `I=[-rho,rho]^5`. Let `r_I=int_I q`, `p_I=int_I pi`, `h_I=q/r_I`, `k_I=pi/p_I`, and `Delta_I=int r_I D(h_I||k_I)`. Put

\[
\lambda=c_-[K\cos\rho-k\|A\|^2]>0,\qquad
\Gamma=k\|C^{1/2}A^T\|\|B_sP\|.
\]

Whitening the `C` mobility turns the fiber cube into a convex parallelepiped, with Hessian at least `lambda I`. For its normalized restricted density, integration of the entropy and Fisher dissipations of an auxiliary reflecting diffusion gives

\[
D(h\Vert k_I)\le\frac{T}{2\lambda}
E_h|\nabla_z\log(h/k_I)|_C^2.
\tag{R12}
\]

For clarity, the auxiliary Fisher derivative is at most `-2lambda I_F`, because the Hessian term has that sign and the convex-boundary term is nonpositive. Its entropy tends to zero as follows. The auxiliary ratio stays bounded above and below, while its Fisher integral tends to zero by this differential inequality. A finite weighted Poincare constant follows by comparing the positive bounded reference density to uniform measure on the parallelepiped; the latter inequality follows from the one-dimensional fundamental theorem of calculus, tensorization on a cube, and the invertible linear coordinate change. Thus the ratio's variance tends to zero, and boundedness makes its entropy tend to zero. Integration proves (R12). Convex smooth domains inside the parallelepiped preserve its Hessian lower bound; their normalized measures converge to the restricted measure, passing the inequality to its corners. This is a functional inequality for a restricted reference measure; the actual process has no reflecting condition at `partial I`.

The conditional score is `s_I=-(grad_y U-E_kI grad_y U)/T`. Applying (R12) to exponential tilts shows that every unit-direction score has centered log moment-generating function bounded by `a^2 Gamma^2/(2Tlambda)`. The relative-entropy variational inequality then gives

\[
|E_hs_I|\le\frac{\Gamma}{\sqrt{T\lambda}}\sqrt{2D(h\Vert k_I)}.
\tag{R13}
\]

Here is an independent check of the moving-conditional calculation. Write `f=q/pi`, `v=grad_y log f`, and `e=E_hI s_I`. Differentiating the conditional marginal gives `grad_y log(r_I/p_I)=E_hI v+e`. The variation of `Delta_I` with respect to `q` is exactly `log(h_I/k_I)`. Integration by parts in the actual forward equation therefore gives

\[
\dot\Delta_I=-TI_{z,I}-T\int r_I\operatorname{Var}_{h_I}(v)
+T\int r_I e\cdot E_{h_I}v+\mathcal B_I,
\quad \mathcal B_I=-\int_{\partial I}J_z\cdot n\log(h_I/k_I).
\tag{R14}
\]

The sign and presence of the last two terms are essential. Using (R12), (R13), and Young's inequality gives

\[
\dot\Delta_I\le-\lambda\Delta_I+
\frac{T\Gamma^2}{2\lambda^2}I_{y,I}+|\mathcal B_I|.
\tag{R15}
\]

Equation (R2) supplies the single total budget `T int_0^infinity I_y,I dt<=H_0`; it is not restarted on successive time intervals.

For the shifted initial family below, let `e^-B<=f_0<=e^B`, `||grad f_0||inf<=L_0`, and write `M=e^B`. The positive Markov semigroup preserves the same pointwise bounds. A uniform-in-time gradient bound follows on the original smooth torus. If `Hess U>=-Lambda I`, stochastic-flow differentiation and Jensen give `|grad P_t g|^2<=e^(2Lambda t)P_t|grad g|^2`. The semigroup variance identity is

\[
P_s(g^2)-(P_sg)^2=2T\int_0^sP_u|\nabla P_{s-u}g|^2du.
\]

Apply the gradient estimate to `P_u(P_{s-u}g)` to lower-bound each integrand by `e^(-2Lambda u)|grad P_sg|^2`. Therefore

\[
|\nabla P_sg|^2\le
\frac{\Lambda[P_s(g^2)-(P_sg)^2]}{T(1-e^{-2\Lambda s})}.
\tag{R16}
\]

Taking `s=1/Lambda` after that time and using the direct bound before it proves

\[
\sup_{t\ge0}\|\nabla f_t\|_\infty\le
L_*:=\max\left(eL_0,M\sqrt{\frac{\Lambda}{T(1-e^{-2})}}\right),
\quad \Lambda=Kc_++3k.
\tag{R17}
\]

There is no growing exponential in the final horizon in (R17).

For `a_0=sqrt(T/K)` and `K>=T`, compact normalizer and barrier bounds give

\[
E_\rho=(\pi/a_0)^5e^{5/2+4k/T-K(1-\cos\rho)/T},\qquad
c_\rho=\pi^{-1}(\rho/\pi)^4\sum_j\sqrt{C_{jj}}.
\]

The outside/inside-label conditional chain rule bounds `0<=Delta_1-Delta_I<=(2+4B)e^B E_rho`. This follows by applying the mean-value bound for `u log u` to conditional averages of `f`, all between `e^-B` and `e^B`. On a face, `C grad_z f=B_f grad_x f`; hence `int_boundary |J_z.n|<=T L_* c_rho E_rho`. Also `|log(h_I/k_I)|<=2B`. Integrating (R15) yields the all-time bound

\[
\Delta_1(t)\le B e^{-\lambda t}+\frac{\Gamma^2B}{2\lambda^2}
+(2+4B)e^BE_\rho+\frac{2BTL_*c_\rho E_\rho}{\lambda}.
\tag{R18}
\]

This independently reconstructs the refinement needed by the joined proof. It retains actual flux and off-cube entropy. At the principal faces, the same calculation uses barrier `2K` and `c_pi=pi^-1 sum sqrt(Cjj)`; its integrated current over a polynomial horizon is exponentially small in the common regime. The source weak equation pairs the face flux with `phi(y+2pi R e_j)-phi(y)`. Its inclusion is correct.

## 6. Global entropy of the fine process and the separately evolved parent

The primary external input is Cheng, Mao, and Zhang, [Theorem 3.1, Journal of Mathematics 40(6), 673–682 (2020)](https://sxzz.whu.edu.cn/html/2020/6/20200606.htm). On the unit circle with angular metric and probability density proportional to `exp(h cos x)`, it states `Ent_mu(g^2)<=2 C_LS int |g'|^2dmu`, with upper bounds `8pi^2 log(2)+1` for `0<h<1` and `max(32e sqrt(pi),24e^3/h)+1` for `h>=1`. Thus `C_circ=1000` is valid uniformly in `h`; Haar follows by bounded convergence as `h` decreases to zero. The primary page's definitions and theorem were inspected directly. No claim about a reflected actual process is drawn from it.

The global integer coordinates `(theta_1,theta_2,theta_3,B_fx,B_sx)` are a torus automorphism: `psi_i=theta_i-d_i`, and the link coordinates are recovered by subtracting their residuals from the corresponding endpoint differences. The inverse has squared Frobenius norm `25`. In these coordinates, `pi` is exactly a product of three Haar and seven von Mises factors. Tensorizing the one-factor entropy inequality by conditional entropy decomposition and applying the gradient chain rule gives `C_f=25000` for the actual angular metric.

For the first parent, its global five-angle parametrization by `(theta_1,theta_2,theta_3,s_1,s_2)` has embedding `E` with `||E||_F^2=16`. The reference with potential `k sum V(s)` thus has constant `16000` in the inherited metric. Let `c_0=2/pi^2`, `b=k sqrt(2)||A||`, and `J_0=e^(1/2)sqrt(pi/c_0)`. For one principal fast angle with concentration `h>=1`, elementary Gaussian majorization and a denominator integral over `|z|<=1/sqrt(h)` give

\[
E e^{\beta|Z|}\le J_0 e^{\beta^2/(4c_0h)}.
\]

Since the weak-potential change is bounded by `b sum_j |Zj|`, both that exponential and its inverse expectation are bounded by

\[
M_1=J_0^5e^{5b^2/(4c_0KT)}.
\]

Thus the actual-to-base parent density's maximum/minimum ratio is at most `M_1^2`. The bounded-perturbation argument is elementary: use
`Ent_mu(v)=inf_a int[v log(v/a)-v+a]dmu`, whose integrand is nonnegative, then compare the two measures in the entropy and Dirichlet integrals. It gives `C_p=16000 M_1^2`. This is uniform when `K/T>=1`, `KT>=1`, and `k` is bounded. The proof compares actual smooth parent densities; it does not apply a smooth-pushforward theorem to a discontinuous Borel map.

For the autonomous first parent initialized at `Q_1,0`, integration by parts in its own inherited metric and initial data processing yield

\[
D(Q_t\Vert\pi)\le H_0e^{-2Tt/C_f},\qquad
D(\bar Q_{1,t}\Vert\pi_1)\le H_0e^{-2Tt/C_p}.
\]

Using (R9) and its separate first-parent version proves

\[
\Delta_1(Q_t)+\Delta_2(Q_{1,t})\le H_0e^{-2Tt/C_f},\qquad
\Delta_2(\bar Q_{1,t})\le H_0e^{-2Tt/C_p}.
\tag{R19}
\]

These are distinct actual-law bounds. No entropy is transferred using weak or path convergence. The final autonomous root has constant `C_2=14000`, from `tr G_0=14` and the Haar product inequality, and its initial entropy is also at most `H_0`. Therefore the same-constant formula (R1) bounds objective differences between separately evolved stages by the sums of their decaying entropy bounds, as in the joined proof's (8a).

The instantaneous actual first force correction obeys

\[
\int|E_{Q(dz|y)}\nabla_yU-E_{\kappa_1}\nabla_yU|^2dQ_1(y)
\le2b_*^2\Delta_1,\qquad b_*=k\|PB_s^T\|\sqrt2.
\tag{R20}
\]

Indeed the force is bounded by `b_*`, expectation differences are at most `2b_* TV`, and Bernoulli reduction gives `KL>=2TV^2`. A naive integral of this force bound over the long horizon need not vanish; the independent contraction argument below supplies the required path comparison.

## 7. Nonlinear force estimates and actual formation

On a smaller fast cube of radius `rho_f<pi/2`, set

\[
m_f=K\cos\rho_f-k\|A\|^2,\quad g=k\sqrt2\|A\|.
\]

The conditional Hessian is at least `m_f I`. Integrating `div(z exp(-U/T))` over the cube has nonnegative outward boundary integrand. It follows that `E[z.grad U]<=5T`. Strong convexity gives `z.grad U>=m_f |z|^2-g|z|`, and hence

\[
\sqrt{E_I|z|^2}\le q_K:=g/m_f+\sqrt{5T/m_f}.
\]

The full-fiber tail is bounded by

\[
\epsilon_K\le (\pi/a_0)^5
e^{5/2+[4k-K(1-\cos\rho_f)]/T},
\quad E|z|\le q_K+\pi\sqrt5\epsilon_K=:d_K.
\]

The local Poincare inequality, obtained by linearizing (R12), bounds the variance of `v.k sin(s+Az)` by `Tk^2||A||^2/m_f`. Outside the cube, its deviation from the restricted mean is at most `2k sqrt2`. Thus (R10) gives the global bounds

\[
\|\nabla F_1-k\sin s\|\le\delta_K:=k\|A\|d_K,
\]

\[
\|\nabla^2F_1-k\operatorname{diag}\cos s\|
\le\eta_K:=\delta_K+k^2\|A\|^2/m_f+8k^2\epsilon_K/T.
\tag{R21}
\]

The weak exponential cost occurs only in a tail dominated by the strong barrier. It does not multiply the bulk moment. In particular the actual parent has Hessian at least `m_1=k cos(1/2)-eta_K>0` on `|s|infinity<=1/2` for the regime below.

The nominal channel-symmetric fine dynamics, in time `tau=kt` and with `A_*=K/k`, are exactly

\[
x'=-3A_*\sin x+\sin y_w,\quad
y_w'=A_*\sin x-3\sin y_w,\quad
(y_w+x/3)'=-(8/3)\sin y_w.
\tag{R22}
\]

For `x_0 in (1/4,1/3)`, `y_w,0 in (1/8,1/6)`, positivity, the inward field at `x=x_0`, and the last identity give `0<x<1/3`, `0<y_w<5/18` for all time. On `[0,1]`, `sin u>=5u/6`, so

\[
x(\tau)\le\tfrac13e^{-5A_*\tau/2}+\tfrac{2}{5A_*}.
\]

At `A_*>=256` and `tau>=1/64`, this is below `1/512`. Also `y_w'>=-3y_w` gives `y_w>(1/8)e^(-3/16)>13/128` through `tau=1/16`. The source's integrated inequality for `z_w=y_w+x/3` gives `z_w<e^(-20tau/9)+2/(15A_*)<1/256` after `tau=3`. These are explicit separate formation windows in the actual nonlinear fine ODE, with independent nonzero initial link drifts. The bridge residuals vanish on this reference slice, but are not constrained to vanish in its open extension.

For the actual integrated parent, the nominal cut starts at `s=(s_0,s_0)`, `s_0=y_w,0+x_0/3 in (5/24,5/18)`. Since `sqrt(s_+) |S^-1/2 s|=sqrt2 s_0<1/2`, this initial state lies strictly in the invariant ellipsoid of the locally strongly convex parent potential. Its radius contracts at rate `lambda_1=s_-m_1`. The comparison cut equation has diagonal solution

\[
u(t)=2\arctan(\tan(s_0/2)e^{-(8/3)kt}).
\]

Contracting the actual parent against this comparison, using (R21), bounds the Euclidean cut error by `s_+ delta_K/lambda_1`, uniformly in time. If this is less than `1/1024`, the actual parent residual stays above `1/10` through `1/(16k)` and below `1/256` after `3/k`. It consequently undergoes the later coalescence under its own exact nonlinear integrated potential. The use of the comparison does not replace that potential.

The actual fine normal Hessian on the residual cube of radius `1/2` is uniformly bounded below by `(k/2)cos(1/2)` on the seven-dimensional normal space once `K` exceeds the explicit matrix threshold in the rates source. To check the bound, for `x=y+Rz` orthogonal to the common kernel,

\[
|x|^2\le2|B_sx|^2/s_-
+(2\|A\|^2/s_-+1/c_-)|B_fx|^2.
\]

Combine it with `K|B_fx|^2+k|B_sx|^2`. The nominal residual margins above are strict. Same-parameter perturbations contract until exit, and first exit then preserves a sufficiently small full initial neighborhood for all time. Small coefficient perturbations preserve the strict bounds on the selected finite horizon by continuous dependence. This supplies openness beyond the nominal symmetric slice, without a uniform-in-infinite-time coefficient-neighborhood assertion.

## 8. Long-horizon stochastic and first-parent path errors

For a projected error with drift satisfying `E.b_E<=-m|E|^2` and noise covariance `2TI_n`, set `u=m|E|^2/(4T)` and `V_E=e^u`. Ito's formula gives

\[
LV_E\le m(n/2-u)e^u\le C_n,
\qquad C_n=m\max(n/2,e^{n/2-1}).
\]

Stopping at radius `rho_e` or time `H` and taking expectations gives

\[
\Pr(\tau_{\rho_e}\le H)\le(1+C_nH)e^{-m\rho_e^2/(4T)}.
\tag{R23}
\]

The stopped stochastic integral is integrable because both the horizon and the stopped integrand are bounded. The initial error is zero. A deterministic margin containing the stopped error ball ensures that chart exit cannot precede the specified error exit. For the fine process this uses the normal Hessian just checked and `n=7`; neutral Brownian directions do not affect residuals. For the parent use whitened cut coordinates, its invariant ellipsoid, `m=lambda_1`, and `n=2`. Add initial bad mass separately. This argument remains valid for a polynomial times logarithmic horizon.

For the sharper fast estimate, drive the adapted finite-variation comparison by the actual cut path:

\[
\dot z^d=-KC\sin z^d-kCA^T\sin(s_t+Az^d),\qquad z^d(0)=z(0).
\]

Bounded weak forcing yields
`|C^-1/2 z^d|<=e^(-Kalpha t)R_*+k beta/(Kalpha)` with the source's `alpha=c_- sin(rho_f)/rho_f` and `beta=sqrt2 ||C^-1/2 B_fB_s^T||`. For `xi=C^-1/2(z-z^d)`, the shared `s_t` leaves a dissipative drift of strength

\[
\widehat m_f=Kc_-\cos\rho_f-k\|C^{1/2}A^TAC^{1/2}\|\ge cK.
\]

The comparison is adapted, so subtracting it leaves exactly the original fast martingale, with covariance `2TI_5`; no independence between it and the cut path is required. Applying (R23) gives fast fluctuation at most

\[
\ell=\sqrt{\frac{4T}{\widehat m_f}
\log\frac{1+\widehat m_f e^{3/2}H}{\varepsilon}}
\]

except with probability `epsilon`, before chart exit. Thus `|z|<=sqrt(c_+)[e^(-Kalpha t)R_*+k beta/(Kalpha)+ell]` there.

Couple the autonomous parent to the same projected Brownian motion and actual retained initial point. In the convex cut tube, `v=S^-1/2(s-bar s)` satisfies

\[
D^+|v|\le-\lambda_1|v|+
\sqrt{s_+}(k\|A\||z|+\delta_K).
\]

The kernel components coincide exactly; the full retained lift distance is `|y-bar y|=|v|`. Integrating the dissipative inequality yields

\[
\sup_{t\le H}|y_t-\bar y_t|\le
\sqrt{s_+}\left[
\frac{k\|A\|\sqrt{c_+}R_*}{K\alpha}
+\frac{k\|A\|\sqrt{c_+}(k\beta/(K\alpha)+\ell)+\delta_K}{\lambda_1}
\right].
\tag{R24}
\]

The estimate is stopped at either residual-tube exit. The fine, parent, and fast exceptional probabilities are added by the union bound, not multiplied. For bounded Lipschitz chart-path observables, (R24) controls the good-event difference and twice the sup norm times the exceptional probability controls the remaining contribution. General bounded measurable observables only receive the latter exceptional-event bound.

The common orthogonal root projector is `(I-L_2B_s)P`. It annihilates every force and leaves exactly the projected Brownian increment, the same for fine and first-parent paths. Therefore the final root chart paths can be coupled exactly until either residual cut. After a cut, the Borel root must use the translations in Section 3. Equation (R23) bounds that exceptional event on the stated horizon; it does not manufacture a global exact Brownian pushforward.

## 9. Simultaneous finite positive-temperature regime

In the global integer residual coordinates choose Haar node angles, five independent shifted von Mises factors of concentration `K/T` centered at `(0,0,0,x_0,x_0)`, and two of concentration `k/T` centered at `(y_0,y_0)`, with the intervals in Section 7. Their physical weak residual is `B_sx`; the horizontal retained cut is shifted by `x_0/3`. This distinction is necessary and is present in the component proofs.

A bounded positive smooth multiplier `g`, followed by normalization, gives an open class of correlated laws. For fixed bounds on `g_+/g_-` and `||grad log g||`, set

\[
B=\log(g_+/g_-)+[4K\sin(x_0/2)+4k\sin(y_0/2)]/T.
\]

Then `e^-B<=q_0/pi<=e^B`, `H_0<=B`, and `L_0<=e^B[||grad log g||+sqrt3(B-log(g_+/g_-))]`. For `g=1`, integrating each shifted factor gives the sharper exact entropy

\[
H_0=2(K/T)V(x_0)E_{\mu_{K/T}}\cos Z
+2(k/T)V(y_0)E_{\mu_{k/T}}\cos Z.
\tag{R25}
\]

Each cosine expectation belongs to `[0,1]`: it is zero at concentration zero and its derivative is the variance of cosine. Initial concentration in any fixed residual neighborhood follows by the elementary bound `P(|Z-center|>=d)<=pi e^(1/2)max(1,sqrt(h)) e^[-hV(d)]`, with a union bound over seven factors. This also controls the full normal initial error because the stacked residual matrix has a bounded right inverse. No Dirac law or conditional match is assumed.

Now set `K=T^-3`, with bounded positive `k` and `a` bounded away from one, and decrease `T` through positive values. Then `H_0=O(T^-4)`, `delta_K=O(T^2)`, `eta_K=O(T^2)`, `KT=T^-2`, and the two global LSI constants remain bounded. For fixed `eta>0`, choose

\[
H=\max\left(3/k,\frac{\max(C_f,C_p)}{2T}\max\{0,\log(H_0/\eta)\}\right)+1/k.
\tag{R26}
\]

This is `O(T^-1 log(1/T))`. Equations (R19) provide both late conditional losses throughout the nondegenerate interval `I_2=[H-1/k,H]`, while (R23) and the initial concentration show that the two formation episodes survive with probability tending to one through this horizon. Taking `epsilon=T` in the fast bound gives `ell=O(T^2 sqrt(log(1/T)))`; thus (R24) tends to zero.

For the early and intervening first conditional loss, `1-cos(7/5)-4sin(1/6)>0`. Indeed the alternating cosine bound and `sin(1/6)<1/6` give the rational lower bound `2299/15000`. In (R18), the only large exponential is therefore dominated by the negative strong barrier: the combined exponent is at most `-[1-cos(7/5)-4sin(x_0/2)]K/T+O(1/T)`. All remaining factors are polynomial in `1/T`. Since `B/lambda^2=O(1/(KT))=O(T^2)`,

\[
\sup_{t\ge t_a}\Delta_1(t)=O(T^2)+o(1)
\quad\text{for every fixed }t_a>0.
\tag{R27}
\]

In particular the first conditional is already small during the proper-pair interval and stays controlled until the late entropy time. The uniform gradient argument, not a fixed-horizon `exp(Lambda H)` bound, is what makes this join valid.

Finally fix one sufficiently small positive `T` and sufficiently large finite `K` at which all inequalities are strict. Continuity of compact integrals, coefficients, density-ratio bounds, and finite-horizon dynamics gives an open parameter and relative `C^1` initial-density neighborhood. The neighborhood may shrink with the selected finite parameters. No radius uniform as `T` tends to zero is required. If independent positive coefficient perturbations are included, retain their minimum and maximum in the fast estimates and shrink the finite-horizon neighborhood; the cosine product argument and positivity persist. The matched family alone already supplies an open regime in its explicitly declared parameters. The analytic argument in Section 4 selects a nonempty open part with a nonzero generated interaction.

## 10. Verdict and remaining scope

The reconstructed result is a complete finite nonlinear two-stage witness with exact normalized parent laws, generated interactions, inherited mobility, actual conditional-KL bounds at both levels, an independently evolved first-parent second conditional bound, and two successive high-probability finite-horizon coalescence episodes. The all-time first-conditional refinement (R16)–(R18) is necessary to justify the strengthened joined statement and has been independently derived here. The final component contains the same refinement in (44a)–(47), and its (47a) retains the first principal-face current. No counterexample or unresolved mathematical interface remains within this stated angular witness.

The argument does not establish learned microscopic energy contrast, a uniquely selected hierarchy, arbitrary depth, permanent positive-temperature agreement, exact global Borel-root Brownian dynamics, or closure into scalar Gaussian parent laws. Those are outside this contract's finite witness. Treating any of them as an established conclusion would exceed this proof. The bounded assignment has no remaining mathematical obligation. The parent can now incorporate this revision-bound proof check into its existing closure workflow; reviewer agreement itself supplies no substitute for the derivation.

No numerical dynamics, suite, GPU work, Lean work, tamper scenario, Git mutation, or Research-vault edit was performed. Primary-source inspection and the displayed analytical calculations are the evidence. No existing numerical matrix check was rerun merely to obtain agreement.

## Source-version addendum

The frozen final sources were read after the parent announced that its mathematical edits were settled. SHA256 values were checked before and after this final read; all four were unchanged and matched the announced values. These hashes bind the scope of this review; they are metadata, not mathematical evidence.

| Source | SHA256 before and after |
| --- | --- |
| [Joined proof](nonlinear-two-stage-completion.md) | `4f3d840dc8b078ea1f764fc39c33685b561ec343aada97a3c092164c475c27f3` |
| [Entropy component](nonlinear-second-conditional-entropy.md) | `0477874217fe99ee517f56bc729aa60b25d95573fc485a27614aceaa308000d5` |
| [Geometry component](nonlinear-parent-laws-and-geometry.md) | `07691fda6228f11791e89329fe7ac3754ad0cadc1f17c39a867fee229ebdf7be` |
| [Formation component](nonlinear-formation-and-common-regime.md) | `a3aa9ac425c3c09d4bab545dbe6f61a4a0fea35de0b284c1a7a92e3243b5a51e` |

The changed-section check explicitly re-read the final root's Section 4 and the entropy component's Section 7.1. The new nondegenerate late interval, uniform semigroup-gradient argument, and integrated principal-face-current bound agree with Sections 5, 8, and 9 above. The read-only hash check output is saved in [source-revision.json](evidence/nonlinear-independent/source-revision.json). No source document, shared ledger, shared log, or previous numerical evidence was edited by this lane.
