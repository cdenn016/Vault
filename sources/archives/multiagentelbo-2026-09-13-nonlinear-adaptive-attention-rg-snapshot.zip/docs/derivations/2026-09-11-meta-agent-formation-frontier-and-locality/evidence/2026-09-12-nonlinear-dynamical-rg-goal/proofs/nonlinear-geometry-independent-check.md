# Reconstruction of the nonlinear integration geometry and initialization

September 12, 2026. This bounded reconstruction checks Sections 1, 3–4, and 5 of [nonlinear-two-stage-completion.md](nonlinear-two-stage-completion.md) for global retained type, inherited metric, normalized-parent and root statements, and the initial-law coordinate/entropy calculation. The integration document was read with SHA-256 `ca8befe7f2fc2f2af4bd43aa224089d11552df700ff6888599a7fd984177ff63` both before and after the read. It is a mutable integration draft; subsequent revisions require rechecking affected statements. This report does not certify the separate log-Sobolev, early interface-current, or two-episode arguments by agreement.

The exact geometry component read for the interface is [nonlinear-parent-laws-and-geometry.md](nonlinear-parent-laws-and-geometry.md), SHA-256 `07691fda6228f11791e89329fe7ac3754ad0cadc1f17c39a867fee229ebdf7be`. Its fixed-temperature generated-interaction argument includes the analytic-slice connection to an open joint regime. The component was written by this lane; this report independently reconstructs its use by the integration document, not an independent authorship claim for that component. All checks are at fixed `c_*` in the three-node angular specialization; retained marks require the separately stated extension.

## 1. Complete integer coordinates and global retained type

The global coordinates in Section 5 are a torus bijection. To verify this without relying on a real-rank argument, write `z_1,z_2,z_3` for the bridge residuals, `z_4,z_5` for the two strong-edge residuals, and `w_1,w_2` for the two weak residuals. Their integer inverse is

\[
\psi_i=\theta_i-z_i,\qquad
\alpha_{12}^b=\theta_1-\theta_2-z_4,\qquad
\alpha_{12}^m=\psi_1-\psi_2-z_5,
\]

\[
\alpha_{23}^b=\theta_2-\theta_3-w_1,\qquad
\alpha_{23}^m=\psi_2-\psi_3-w_2.
\tag{1}
\]

Thus both the forward and inverse maps are integer linear maps on ten circles. Haar factorizes in these coordinates. In particular, the independent residual von Mises factors used in the initialization are a proper density on complete configurations, and not a density on a many-to-one real chart.

This integer coordinate fact is distinct from the Borel orthogonal retention. The latter uses `z=pr(B_fx)`, `y=x-Rz`, `s=pr(B_sy)`, and `r_0=y-L_2s`. It has the unique inverse `x=r_0+L_2s+Rz`. The three remaining root coordinates and every face shift are retained. The second-stage cut shift is `r_0 -> r_0+2pi L_2e_a`, inducing root-angle shift `2pi(1,2,-3)/16`; the first-stage face changes `y -> y+2pi Re_j`. These are nontrivial torus translations, so the integration document correctly refrains from calling its global principal-branch paths continuous or cadlag. There is no finite normal-subtorus quotient in that proof.

## 2. Metric, stochastic coupling, and root operator

The identities `B_fR=I`, `B_fL_2=0`, and `B_sL_2=I` follow directly from the definitions. Orthogonality gives

\[
R^TL_2=0,\qquad R^TR=C^{-1},\qquad L_2^TL_2=S^{-1}.
\tag{2}
\]

For a vector `v` in the final common kernel, `v^TR=v^TL_2=0`. This proves both metric splittings in Section 1. In the root-angle coordinates, `G_0=E_0^TE_0` has diagonal `(4,6,4)` and neighboring off-diagonal entries `-2`; its inverse is the matrix in the geometry component. The final constructed operator is therefore `T div(G_0^-1 grad)`, with the original temperature. Its eigenvalues are positive, and `||E_0||^2<=tr(G_0)=14`; the stated root Haar LSI bound of `14000` follows if the entropy lane's circle bound is `1000`. This last inference checks the metric factor, not the source theorem proving the circle bound.

The path comparison in Section 3 couples projected Brownian motions consistently. In a chart with no residual cut, the fine `y` noise is `sqrt(2T)P dB`. Its final-kernel component agrees with the coupled parent's component, because both potentials have zero derivative along that kernel. Their difference therefore lies in `range(L_2)` and equals `L_2(s-bar s)`. Equation (2) gives

\[
|y-\bar y|^2=(s-\bar s)^TS^{-1}(s-\bar s).
\tag{3}
\]

This validates the norm equality used in the path bound; no independent root-noise term is missing. It is a stopped-chart statement. At a cut it no longer licenses a global root-path identification.

For the fast comparison, `z` has noise `sqrt(2T)B_f dB`; multiplying by `C^-1/2` makes its covariance exactly `2TI_5`. The whitened potential Hessian is

\[
K C^{1/2}\operatorname{diag}(\cos z)C^{1/2}
+k C^{1/2}A^T\operatorname{diag}(\cos(s+Az))A C^{1/2}.
\tag{4}
\]

Its lower bound is exactly the displayed `m_f` in Section 3. This confirms that the fast stochastic comparison uses the inherited noise and preconditioning. The positivity and tube-margin conditions are still necessary.

The root potential is constant because the exact integrand depends only on `s,z`. This gives zero interior root drift and a constructed Brownian parent. The integration document explicitly distinguishes that law from both actual Borel second marginals. Its late scalar-objective bounds use separate entropy decay, and hence do not omit a global root-current term by pretending exact path equality.

## 3. Normalization and the scalar VFE identity

Haar disintegration of the Borel bijection gives `dx=dr_0 ds dz/(2pi)^7`. The exact first potential is `F_1(s)=-T log I_1(s)` with the full `z` integral. Integrating the full `s` periods removes the shift `Az`, so

\[
\int I_1(s)\frac{ds}{(2\pi)^2}=Z,
\qquad P_{0,2}=\pi_2=\text{normalized Haar}.
\tag{5}
\]

Replacing `U` by `U_0` gives the genuine first and second downward priors. The physical parent presentation uses these priors to mix the original three-node model-presentation kernel. Its evaluator remains the same normalized product Gaussian evaluator. The optimizing conditionals instead use `U`; their conditional costs are kept in the inherited objective. Therefore Section 4's additive scalar constant is indeed common to both stages:

\[
-T\log c=T\log(Z_0/Z),\qquad c=\mathbb E_{P_0}e^{-d}=Z/Z_0.
\tag{6}
\]

For any `Q<<pi`, factoring the Radon–Nikodym derivative into the root marginal, weak conditional, and fast conditional gives exactly the three nonnegative KL terms in the integration equation (5). Applying the first two factors to the independently evolved parent gives its equation (6). These two chain rules concern different recognition laws. They do not require conditional matching, independence, smooth Borel paths, or a memoryless exact reduction.

If `D(Q_t||pi)<=H_0e^-a` and `D(bar Q_1,t||pi_1)<=H_0e^-b`, nonnegativity yields

\[
|\mathcal F_T(Q_t)-\mathcal F_1(\bar Q_{1,t})|
\le T H_0(e^{-a}+e^{-b}).
\tag{7}
\]

Thus the integration's scalar replacement bound is a valid consequence of its two separate entropy estimates. It does not infer entropy continuity from weak or path convergence. Exactly the same calculation applies to the constructed final Brownian law with its separately bounded entropy.

## 4. Initial entropy and the matching of nominal coordinates

For a circle density `q_h(u)` proportional to `exp(kappa cos(u-h))` and target `p(u)` proportional to `exp(kappa cos u)`, their equal normalizers give

\[
D(q_h\Vert p)=\kappa\mathbb E_{q_h}[\cos(u-h)-\cos u]
=\kappa A_\kappa(1-\cos h),\quad
A_\kappa=\mathbb E_p\cos u=I_1(\kappa)/I_0(\kappa).
\tag{8}
\]

Here `E_p sin u=0` by evenness and `A_kappa<=1`. Applying (8) to the two shifted fast and two shifted weak coordinates in (1) proves the nominal entropy equality and upper bound in the integration equation (9). The other three bridge factors are unshifted; the neutral Haar factors contribute zero. The normalizers do not depend on the residual centers.

The nominal first retained weak residual is not the raw weak residual center. With `z_0=(0,0,0,x_0,x_0)` and raw weak center `(y_0,y_0)`, the explicit `A` gives

\[
s_0=(y_0+x_0/3,y_0+x_0/3).
\tag{9}
\]

For the stated intervals this lies in `(5/24,5/18)` in each coordinate, exactly as in the formation component. Since this is the eigenvector `(1,1)` of `S` with eigenvalue `8/3`, its squared `S^-1` norm is `3s_0^2/4`; the enclosing Euclidean radius bound is `sqrt(2)s_0<1/2`. Thus the initialization and the parent invariant ellipsoid use the same actual retained state.

For a relative-density perturbation `g`, normalization gives the ratio factor `g/E_Qg` between `g_-/g_+` and `g_+/g_-`. Each shifted factor's log ratio is pointwise at most `2kappa sin(h/2)` for the positive centers used here. Summing the two fast and two weak shifts yields

\[
D(Q^g\Vert\pi)\le\log(g_+/g_-)
+\frac{4K\sin(x_0/2)+4k\sin(y_0/2)}{T},
\tag{10}
\]

which is the integration's perturbed budget. It remains polynomial on `K=T^-3`, so its logarithm is `O(log(1/T))`. This validates the stated entropy-time order once the uniform entropy constants have been established in the separate lane. The same bounded ratio multiplies the nominal initial bad mass. At fixed positive parameters, a sufficiently small relative `C^1` neighborhood remains a class of smooth positive correlated densities; no uniform neighborhood radius as `T` tends to zero is claimed.

## 5. Generated interaction and the open regime

The geometry component's fixed-positive-temperature expansion gives `partial_1 partial_2 F_1(0)=4k^2/(9K)+O(K^-2)`. Its remainder is explicitly fixed-temperature, so it cannot alone prove this coefficient is nonzero at every point of `K=T^-3`. The component supplies the missing existential connection: at any interior finite joined-regime point, freeze `T,k,a` and vary `K` in a small admissible interval. The mixed Hessian is real analytic in `K` and is not the zero function by its large-`K` asymptotic. It cannot vanish on the whole interval. Selecting a nonzero point and taking a small neighborhood preserves all strict joined inequalities and gives an open subset with a nonzero generated interaction. No uniform low-temperature asymptotic is used.

## 6. Verdict within the assigned scope

The checked integration revision has no outstanding geometry, normalization, root-law identification, or initial-density coordinate mismatch in these assigned interfaces. The exact compound Borel retained type, inherited metric, conditional VFE constants, and matched nominal preparation are supported by the calculations above. The one finite-temperature generated-interaction conclusion requires the analytic-slice paragraph in the geometry component when selecting the final open regime.

The unresolved outside obligation is the independent reconstruction of the conditional LSI/current estimates and the joined fine/parent formation inequalities, including their common horizon. This report does not close that obligation or the overall contract. The next material action is a separate reconstruction of those component interfaces against the finalized integration revision. Only exact rational matrix checks were executed by this lane, with output in [geometry-results.json](evidence/nonlinear-parent-geometry/geometry-results.json); no stochastic simulation, suite, GPU run, or tamper check was performed.

## 7. Final frozen integration binding

The finalized integration document was reread on September 12, 2026, with SHA-256 `4f3d840dc8b078ea1f764fc39c33685b561ec343aada97a3c092164c475c27f3` both before and after the read. The geometry component remains at SHA-256 `07691fda6228f11791e89329fe7ac3754ad0cadc1f17c39a867fee229ebdf7be`. This section supersedes the mutable integration binding in the opening paragraph for the assigned scope; it does not alter the scope or turn the component's authorship into independent evidence.

Sections 1 and 3–5 retain the exact Borel maps and inherited metrics reconstructed above. The added Section 1 analytic-slice argument now explicitly proves that every admissible open `K` interval at fixed positive `T,k` contains a point with nonzero generated mixed Hessian. Its analyticity and fixed-temperature nonidentity premises match the component derivation. It does not apply the fixed-temperature remainder uniformly on `K=T^-3`.

Section 3 now distinguishes a fixed failure tolerance from the vanishing choice `epsilon=T` and specifies bounded measurable extensions, or a cemetery state, for chart observables after exit. These additions preserve the stopped metric and Brownian coupling identities (2)–(4) above and do not identify a Borel retained trajectory with a global continuous path. Section 4 still distinguishes the autonomous root Brownian law from both actual second marginals, retains both conditional KL costs, and uses the common scalar constant `T log(Z_0/Z)`. Its new nondegenerate late interval and refined entropy/current estimates do not change these geometry or normalization identities. Their quantitative analytic proofs remain the responsibility of the separate full reconstruction.

Section 5 retains the bijective integer initialization, the nominal retained center `s_0=y_0+x_0/3`, the exact nominal entropy formula, and the separate perturbed pointwise budget. Equations (1) and (8)–(10) of this report therefore apply unchanged at the frozen revision. The specified open parameter neighborhood, rather than only the curve `K=T^-3`, is what permits the analytic-slice selection.

The strongest conclusion of this final binding is that the frozen integration revision has no unresolved inconsistency in the assigned global geometry, inherited kinetic metric, normalization, root-law qualification, generated-interaction existence, or initialization interfaces. It makes no additional claim about the new semigroup/current estimates, the full episode proof, or ledger closure. The remaining action belongs to the separately assigned full reconstruction and release record; no component, integration document, or ledger was edited in this binding step.
