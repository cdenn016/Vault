"""Assemble a frozen written-proof record after independent reconstruction."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess


RUN = Path(__file__).resolve().parent
SOURCE = RUN.parent.parent
REPO = SOURCE.parents[2]
CONTRACT = json.loads((RUN / "problem-contract.json").read_text(encoding="utf-8-sig"))
META = {key: CONTRACT[key] for key in ("schema_version", "contract_id", "target_digest")}
HEADER = "<!-- rigorous-theory-search-metadata " + json.dumps(META, separators=(",", ":")) + " -->\n\n"
FROZEN_ROOT = "4f3d840dc8b078ea1f764fc39c33685b561ec343aada97a3c092164c475c27f3"
PROOFS = {
    "joined": "nonlinear-two-stage-completion.md",
    "geometry": "nonlinear-parent-laws-and-geometry.md",
    "entropy": "nonlinear-second-conditional-entropy.md",
    "formation": "nonlinear-formation-and-common-regime.md",
    "geometry-check": "nonlinear-geometry-independent-check.md",
    "entropy-check": "nonlinear-entropy-independent-check.md",
    "formation-check": "nonlinear-formation-independent-check.md",
    "independent": "nonlinear-independent-reconstruction.md",
    "source-rates": "endogenous-rates-and-coherence.md",
    "source-lag": "conditional-lag-and-parent-vfe.md",
    "source-episodes": "successive-coalescence-construction.md",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name: str, value: dict) -> None:
    (RUN / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def write_markdown(name: str, body: str) -> None:
    (RUN / name).write_text(HEADER + body.strip() + "\n", encoding="utf-8")


assert digest(SOURCE / PROOFS["joined"]) == FROZEN_ROOT, "Freeze only after reconstruction."
for key in ("geometry-check", "entropy-check", "formation-check", "independent"):
    assert FROZEN_ROOT in (SOURCE / PROOFS[key]).read_text(encoding="utf-8-sig"), key
(RUN / "proofs").mkdir(exist_ok=True)
for filename in PROOFS.values():
    shutil.copyfile(SOURCE / filename, RUN / "proofs" / filename)

assumptions = [
    ("A1", "One fixed-base-point compact three-agent path, paired Gaussian law means on a circle, four independent dynamic link angles, and the normalized physical evaluator of the existing model."),
    ("A2", "Positive supplied microscopic interaction contrast K/k and the declared positive generative node coefficient K-T/(1-a); channel covariance a remains fixed during each run."),
    ("A3", "The same unit microscopic angular mobility with matched temperature T>0, and exactly inherited parent metrics; no node acceleration or new parent rate."),
    ("A4", "The explicit shifted positive initial density and a relative C1 neighborhood, strict finite parameter inequalities, residual error tolerances and a finite comparison horizon."),
    ("A5", "Both principal-branch Borel retentions, their complete face identifications, full generated parent integrals and augmented conditional-family VFE costs are retained."),
]
ledger = json.loads((RUN / "claim-ledger.json").read_text(encoding="utf-8-sig"))
ledger["assumptions"] = [dict(id=key, kind="MODELING_POSTULATE", statement=value) for key, value in assumptions]
ledger["evidence"] = [dict(id="proof-" + key, kind="DERIVATION", supports=True,
    scope="The written analytical argument in " + filename,
    side_conditions=[value for _, value in assumptions], artifact_path="proofs/" + filename,
    artifact_sha256=digest(RUN / "proofs" / filename)) for key, filename in PROOFS.items()]
extra_claims = {
    "normalized-physical": "Both induced generative presentation/evaluator kernels and their optimizing conditional-family VFE costs are normalized and compose exactly.",
    "global-geometry": "The two declared retentions have exact Borel inverses with Haar disintegration and all nontrivial face identifications retained.",
    "generated-interaction": "The exact first parent has a nonzero generated cross interaction on a nonempty open subset of the same admitted regime.",
    "inherited-dynamics": "The first nonlinear parent and final Brownian parent use the microscopic induced metrics and approximate the corresponding retained paths with the stated finite-horizon corrections.",
    "objective-replacement": "The objectives of the separately evolved fine, first-parent and final-parent laws have the stated direct late-entropy difference bounds.",
}
ledger["claims"] = [claim for claim in ledger["claims"] if claim["id"] not in extra_claims]
for key, value in extra_claims.items():
    ledger["claims"].append(dict(id=key, statement=value, kind="MATHEMATICAL",
        quantifiers="For every datum in the final nonempty open witness regime.",
        target_digest=META["target_digest"], falsifier="Failure of its displayed normalization, geometric identity, entropy estimate, or strict common-regime inequality."))
support = {
    "target": ["joined", "independent"],
    "nonlinear-parents": ["geometry", "geometry-check", "independent"],
    "first-interface": ["entropy", "entropy-check", "joined", "independent"],
    "second-interface": ["entropy", "joined", "independent"],
    "successive-formation": ["formation", "formation-check", "source-episodes", "joined", "independent"],
    "joined-regime": ["joined", "formation", "entropy", "independent"],
    "normalized-physical": ["geometry", "geometry-check", "independent"],
    "global-geometry": ["geometry", "geometry-check", "independent"],
    "generated-interaction": ["geometry", "geometry-check", "joined", "independent"],
    "inherited-dynamics": ["joined", "geometry", "formation-check", "independent"],
    "objective-replacement": ["entropy", "entropy-check", "independent"],
}
for claim in ledger["claims"]:
    claim.update(state="EVIDENCE_VERIFIED", assumption_ids=[key for key, _ in assumptions],
        evidence_ids=["proof-" + key for key in support[claim["id"]]], bridge_premise_ids=[])
write_json("claim-ledger.json", ledger)
claim_ids = [claim["id"] for claim in ledger["claims"]]
dependencies = {
    "target": ["nonlinear-parents", "first-interface", "second-interface", "successive-formation", "joined-regime"],
    "nonlinear-parents": ["normalized-physical", "global-geometry", "generated-interaction"],
    "first-interface": ["global-geometry", "inherited-dynamics"],
    "second-interface": ["first-interface", "inherited-dynamics", "objective-replacement"],
    "successive-formation": ["inherited-dynamics"],
    "joined-regime": ["nonlinear-parents", "first-interface", "second-interface", "successive-formation"],
    "inherited-dynamics": ["global-geometry"],
}
write_json("dependency-dag.json", dict(META, nodes=claim_ids,
    edges=[dict(**{"from": parent, "to": child}) for parent, children in dependencies.items() for child in children]))

families = [
    ("localized-conditional", "Restricted-convexity conditional entropy with explicit actual boundary current", "Principal residual fibers and shifted positive densities", "Fast curvature and the complete entropy budget", "Control current uniformly in time without modifying actual dynamics", "Reverse-Poincare semigroup estimate bounds the full density gradient uniformly", "A missing face term, wrong gradient inequality, or nonpositive barrier margin", ["Uniform first conditional KL after the initial layer", "Actual first gluing-current bound"], [], "selected"),
    ("global-entropy", "Global compact entropy dissipation and a static bounded likelihood perturbation", "Integer residual coordinates and exact nonlinear parent integrals", "Uniform circle log-Sobolev inequality and KL chain rule", "Prove separate fine and autonomous-parent second losses", "Product factorization, inherited metric comparison and exponential fast moments", "Treating the Borel map as a smooth Lipschitz projection or inferring KL from paths", ["Both second losses and all three independent objective estimates"], [], "selected"),
    ("dissipative-path", "Residual contraction and exponential stopped diffusion bounds", "Actual compact paths with complete branch information", "Uniform normal curvature and inherited cut metric", "Join actual two episodes to the entropy horizon", "Adapted fast comparator and contracting nonlinear parent", "An unproved all-horizon margin, lost branch, or new parent rate", ["Finite-horizon first path approximation and second chart coupling", "Nonempty open regime with generated interaction"], [], "selected"),
    ("unrecorded-quotient", "Smooth quotient by the full fast normal subtorus", "A torus quotient that forgets 24 branch labels", "Distinct omitted labels can have different weak energies", "Retain or explicitly average every lost physical branch", "No such replacement is used in the completed theorem", "The x=0 and x=2pi R e4 example has the same quotient but energies 0 and k", ["The unrecorded substitution is invalid"], ["A separately declared averaged quotient would be a different construction"], "not_selected"),
]
write_json("approach-registry.json", dict(META, mechanism_families=[dict(family_id=f[0], core_mechanism=f[1],
    target_obligation_ids=["target"], representation=f[2], invariant_or_obstruction=f[3], obligations=[f[4]],
    bridge=f[5], failure_test=f[6], verified_results=f[7], open_gaps=f[8], disposition=f[9],
    novelty_fingerprint="No priority claim. Existing compact source mechanisms are joined through the explicit entropy, topology and path interfaces stated here.") for f in families]))

write_markdown("reconstruction-and-erasure.md", """# Independent reconstruction and premise erasure

Three specialists constructed the geometry, entropy and formation components and separately reconstructed the root's integration. A fourth expert, who did not construct these components, reconstructed the complete theorem against the live source derivations and the circle-inequality primary source. The complete calculations are frozen in proofs/nonlinear-independent-reconstruction.md. The other three checking documents preserve their narrower scopes, corrections and final bindings. Agreement is not the evidence; the displayed derivations are.

Erase the requested result and the preferred search direction. The remaining inputs are a compact local law/evaluator family, independent links, positive microscopic interaction weights, one common update metric, a smooth positive preparation and fixed tolerances. Integer matrices still prove the complete retained geometry. Exact integration still produces both normalized priors, physical kernels and conditional costs. The nominal nonlinear ODE still has its distinct crossings. Conditional entropy follows from its actual balance and uniform semigroup derivative bound; separate second losses follow from the global log-Sobolev bounds. The polynomial horizon and exponentially small exit probabilities use those same parameters. No desired grouping, conditional matching, autonomous first marginal, global Brownian Borel root, new clock, or storage criterion is an input.

The independent reconstruction checks every target dependency through these calculations. The first all-time conditional estimate retains the face current; the second law estimates are distinct for fine and autonomous dynamics; the final Brownian approximation is restricted to the controlled chart and its exceptional event. The generated-interaction claim uses an analytic finite-parameter slice and never imports a fixed-temperature asymptotic as a uniform low-temperature expansion. This is a semantic mathematical premise check, not an artifact-corruption test.
""")
attacks = [
    ("compact-topology", ["target", "global-geometry", "nonlinear-parents"], "A fractional orthogonal projection may be treated as a global smooth retraction or erase finite branches.", "Exact Borel inverses and both face shifts are retained; the 24-label quotient counterexample is explicit.", "geometry"),
    ("generative-optimizer", ["normalized-physical", "nonlinear-parents"], "The optimizing conditional may replace the actual generative child prior or alter the evaluator.", "Separate U0/U integrals define normalized generative and optimizing kernels; the same physical evaluator is retained under both integrations.", "geometry-check"),
    ("nonlinear-replacement", ["generated-interaction", "joined-regime"], "A harmonic approximation or fixed-temperature remainder may masquerade as a nonlinear common-regime theorem.", "Exact integrals drive the parents; uniform moment/tail bounds prove the common regime, and analytic nonvanishing proves a generated interaction within its open set.", "independent"),
    ("conditional-current", ["first-interface", "target"], "Conditional entropy may omit moving-target score, off-tube entropy or actual boundary current.", "The local balance retains all terms; the full entropy budget and uniform semigroup gradient control them without reflection or process restart.", "entropy"),
    ("second-law-substitution", ["second-interface", "objective-replacement"], "A path distance may be used as KL evidence or the actual first marginal may be replaced by its autonomous parent.", "Fine and autonomous first and final laws have separately derived entropy bounds and common objective constants.", "entropy-check"),
    ("kinetic-reset", ["inherited-dynamics", "successive-formation"], "A new parent learning rate or prescribed merger schedule may supply the desired hierarchy.", "The metric is the nested orthogonal split of the common microscopic metric; exact residual ODEs and nonlinear parent contraction produce the episodes.", "formation-check"),
    ("incompatible-horizon", ["joined-regime", "target"], "A long entropy horizon may destroy stochastic coherence or amplify the parent error exponentially.", "The normal exponential stopping estimate and cut contraction remain compatible with K=T^-3 and H=O(T^-1 log(1/T)); initial law, tails and all margins are explicit.", "independent"),
    ("global-root", ["inherited-dynamics", "second-interface"], "A zero root force may be mistaken for an exact global Brownian pushforward.", "Actual Borel root crossings shift the retained state; only the chart coupling and controlled exceptional event justify the final Brownian approximation.", "independent"),
]
adversarial = dict(META, attacks=[dict(id=key, claim_ids=ids, attack=attack, disposition="REJECTED", response=response,
    artifact_path="proofs/" + PROOFS[proof], artifact_sha256=digest(RUN / "proofs" / PROOFS[proof]))
    for key, ids, attack, response, proof in attacks])
for field in ("independent_reconstruction", "oracle_erasure"):
    adversarial[field] = dict(claim_ids=claim_ids, method="Direct complete analytical reconstruction and premise erasure against the unchanged finite contract.",
        result="PASS", conclusion="Every target dependency has a current written proof within its explicit assumptions and error bounds.",
        artifact_path="reconstruction-and-erasure.md", artifact_sha256=digest(RUN / "reconstruction-and-erasure.md"))
write_json("adversarial-report.json", adversarial)

write_markdown("counterexample-register.md", """# Counterexamples and route boundaries

The normal-subtorus quotient forgets 24 points of the fast coherent torus. The configurations 0 and 2pi R e4 have the same quotient, but their actual weak energies are 0 and k. This rules out an unrecorded smooth quotient substitution, not all explicitly averaged quotient models.

The actual Borel final root changes by 2pi(1,2,-3)/16 when a cut residual crosses a principal face. Its globally pushed path law is therefore not the autonomous Brownian law merely because the local root force is zero. The proof retains this distinction and controls the exceptional event.

A small path distance alone has no general dimensionless KL consequence. The proof uses actual conditional entropy and separate autonomous entropy dissipation. The fixed-temperature mixed-Hessian expansion also does not prove uniform nonvanishing on a low-temperature curve; analytic nonvanishing in a strict open finite-parameter neighborhood supplies the exact claim used.

The crude global Gronwall bound and the e^(4k/T) bulk-moment bound do not join the polynomial horizon. They are retained as insufficient alternative estimates; the completed proof uses contraction, a sharp bulk/tail separation and exponential stopping. These are mathematical counterexamples and scope checks, not file corruption or tamper scenarios.
""")
write_markdown("construction-or-strongest-theorem.md", """# Nonlinear finite construction

The theorem is proofs/nonlinear-two-stage-completion.md with its three component derivations. One compact cosine model with common microscopic kinetics and supplied interaction contrast has actual pair-then-whole coalescence, two exact normalized parent integrations and inherited dynamics with explicit finite-horizon errors. Its configuration dimensions are 10, 5 and 3. Every principal face identification remains in the global retained laws.

The first conditional loss is uniformly O(T^2), plus displayed exponentially small terms, after any fixed positive initial time in the witness regime K=T^-3. The actual fine second loss and the autonomous first-parent second loss have separate exponential entropy estimates; the final Brownian law also has its own entropy bound. A horizon O(T^-1 log(1/T)) makes the second losses small while the dissipative path bounds preserve coherence with high probability. Both generated nonlinear integrals and all physical evaluator/conditional costs are retained. An analytic-slice argument supplies a nonempty open subset with a nonzero generated cross interaction.

The same equations and preparation enter every proof. No Gaussian replacement, conditional matching, rate reset, erased branch, storage condition, or infinite-depth conclusion is used. The complete independent reconstruction is proofs/nonlinear-independent-reconstruction.md.
""")
limitations = [
    "A finite compact three-node specialization at one base point, with supplied microscopic interaction contrast and fixed law covariances; no learned architecture or arbitrary-depth closure.",
    "Common local flat kinetics are declared physical input, not determined uniquely by scalar VFE; neutral gauge directions are not restoring clocks.",
    "First-parent approximation and final-root chart approximation retain nonzero errors and branch corrections; positive temperature gives finite-horizon probabilistic coherence only.",
    "Second conditional entropy becomes small at a later finite relaxation interval, not necessarily at the first geometric weak-cut crossing.",
    "Parent presentations are correlated vector mixtures with exact augmented conditional-family costs, not a newly postulated scalar-agent or bare-physical-marginal ELBO.",
]
write_json("release.json", dict(META, checkpoint="nonlinear compact two-stage construction", target_claim="target",
    terminal_status="COMPLETE_AFFIRMATIVE", certificate_claim="target",
    strongest_result="One nonlinear compact law/link family has actual successive coalescence, normalized inherited parents, controlled conditional VFE and finite-horizon dynamical errors in a nonempty open positive-temperature regime.",
    unresolved_obligations=[], limitations=limitations))
write_markdown("final-report.md", """# Rigorous theory search report

## Frozen contract

The unchanged existential target in problem-contract.json asks for a nonlinear two-stage construction in the existing compact law/link model, with both normalized parents, inherited operators, actual conditional losses and successive formation in one open positive-temperature regime. The Gaussian predecessor is an analytic reference, not this witness.

## Terminal status

COMPLETE_AFFIRMATIVE within that finite contract. Written analytical derivations and their independent reconstruction support the result. The structural validator checks the record and file bindings, not mathematical truth.

## Certificate

Target claim `target` depends on the normalized nonlinear parents, first and second interfaces, successive formation and joined regime. proofs/nonlinear-two-stage-completion.md integrates the three component derivations. The ledger records eleven claims with current evidence artifacts and explicit assumptions A1–A5. The dependency graph and complete independent reconstruction cover their full closure.

## Strongest verified result

A compact cosine model with ten angular coordinates, independent moving links and one common microscopic mobility has a coherent pair interval before whole-block coherence. Its exact five-coordinate nonlinear first parent undergoes the later coalescence with its inherited metric. Both normalized integrations, physical vector kernels, genuine downward priors and optimizing conditional costs compose through dimensions 10, 5 and 3.

In a nonempty open regime centered near K=T^-3, the first actual conditional KL is uniformly O(T^2) after a fixed initial time, with explicit initial-layer and boundary terms. The actual fine second conditional loss, the autonomous first-parent second loss and the autonomous final-root entropy have separate finite-time bounds. The required late horizon is O(T^-1 log(1/T)); exponential residual-tube bounds and contraction keep both the episodes and the path approximation valid through it. The first approximation error tends to zero, and final-root path equality holds inside the controlled chart with the branch-exit event retained. A generated nonlinear cross interaction is nonzero on an open subset of this same regime.

## Dependency closure

The ledger separates normalized physical kernels, global Borel geometry, generated interaction, inherited dynamics and independent objective replacement from the five original target obligations. The proofs retain current terms, nonlinear covariance corrections, normalization constants and the actual versus autonomous law distinctions. No hidden conditional-matching or global-Brownian assumption closes a dependency.

## Independent reconstruction

Three construction specialists supplied narrower root-integration checks. A separate fourth expert reconstructed the full theorem, including the [Cheng–Mao–Zhang circle log-Sobolev theorem](https://sxzz.whu.edu.cn/html/2020/6/20200606.htm), its coordinate and metric applicability, the uniform-gradient first-entropy estimate, dissipative path coupling and exact normalized-law composition. The full record is proofs/nonlinear-independent-reconstruction.md; the other check documents retain their assigned scopes and source bindings. The exact matrix checks are supplementary identities, not stochastic simulations or substitutes for proof.

## Oracle erasure

reconstruction-and-erasure.md removes the requested outcome from the premises. Supplied inputs remain visible: microscopic energy contrast, the normalized law family, a common kinetic rule, the initial preparation and finite tolerances. The derived equations, integrations and inequalities still imply the claimed two stages. Neither a desired grouping nor a new parent clock is a premise.

## Unresolved obligations

None within the frozen finite existential target. General gauge groups, learned scales or covariances, arbitrary merger histories, infinite depth and permanent positive-temperature coherence are outside this target, not claims settled by this construction.

## Scope and limitations

The result is a finite mathematical construction, not an empirical discovery or a universal hierarchy theorem. The declared model inputs are not derived. Parent states are correlated marked vector laws with augmented conditional costs. The final Borel root is not globally identical to Brownian motion; the theorem includes its boundary correction and finite-chart error. The second KL guarantee can occur later than geometric coalescence. No production model change, full suite, GPU job, Lean proof, tamper test, historical rerun, vault edit or Git publication was part of this continuation.
""")

source_paths = [REPO / "Theory" / filename for filename in ("02_geometry.tex", "03_probability.tex", "05b_local_collective_elbo.tex", "07c_full_graph_meta_agent_vfe.tex")]
source_paths += [Path("C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex"),
    Path("C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md")]
write_json("source-snapshot.json", dict(META,
    canonical_base_commit=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
    note="The base commit does not contain these uncommitted derivations. These hashes identify the read sources and frozen proof artifacts; they are not mathematical evidence by themselves.",
    proofs=[dict(source=str(SOURCE / filename), snapshot="proofs/" + filename, sha256=digest(SOURCE / filename)) for filename in PROOFS.values()],
    sources=[dict(path=str(path), sha256=digest(path)) for path in source_paths],
    primary_web_source=dict(url="https://sxzz.whu.edu.cn/html/2020/6/20200606.htm", theorem="3.1", retrieved="2026-09-12", applicability="Unit circle von Mises density, Ent(f^2)<=2C integral|grad f|^2, uniform positive concentration; limit at zero gives Haar.")))
print(json.dumps(dict(claims=len(claim_ids), proofs=len(PROOFS), attacks=len(attacks), frozen_root=FROZEN_ROOT)))
