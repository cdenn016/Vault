# Independent reconstruction of the nonlinear trajectory join

September 12, 2026. Assigned scope: Sections 2, 3, and 5 of
[the joined nonlinear proof](nonlinear-two-stage-completion.md). This is
a written reconstruction, not a ledger closure. The initial inspected
integration snapshot had SHA-256
`54cef48cbfb9349f298a4ea3a395085ea970a1b05625ee93ca81df91365c15e2`.
A final binding is recorded in Section 7 after rereading the frozen
trajectory and regime sections.
The hash is provenance metadata; the following calculations are the
mathematical evidence.

The target checked is conditional and quantified: for every sufficiently
small finite positive `T`, sufficiently large finite `K` in the declared
common regime, and every initial configuration in a specified open
residual neighborhood, the two compact processes admit the stated finite-
horizon coupled-path error, with explicitly bounded bad events. The
positive-density preparation must put arbitrarily high probability in
that neighborhood while having polynomial initial entropy. No entropy
conclusion is inferred from the coupled paths. The independent global
entropy and geometry proofs are dependencies, not results certified by
this trajectory reconstruction.

## 1. Reconstruction of the exponential stopped-tube inequality

Let `E` be an `n`-dimensional continuous semimartingale with drift `b_E`,
quadratic covariance `2T I_n dt`, and `E_0=0`. Assume, until a stopping
time, that `E.b_E<=-m|E|^2`, with `m,T>0`. For
`V(E)=exp(m|E|^2/(4T))`, put `u=m|E|^2/(4T)`. Direct differentiation gives

\[
\nabla V=\frac{m}{2T}EV,
\qquad T\Delta V=\left(\frac{mn}{2}
                  +\frac{m^2|E|^2}{4T}\right)V,
\]

\[
b_E\cdot\nabla V+T\Delta V
\le m(n/2-u)e^u.
\tag{1}
\]

For `u>=0`, the positive maximum of `(n/2-u)e^u` is at zero or at
`u=n/2-1`. Therefore the constant
`C_n=m max(n/2,exp(n/2-1))` in the joined proof is a valid upper bound.
Stop at the radius-`rho` exit and at a finite `H`. On the stopped ball,
the martingale integrand is bounded; Ito's expectation identity gives
`E V(E_{tau cap H})<=1+C_n H`. At an exit, continuity gives
`V=exp(m rho^2/(4T))`. Nonnegativity gives exactly

\[
\mathbb P(\tau\le H)
\le(1+C_nH)e^{-m\rho^2/(4T)}.
\tag{2}
\]

The estimate remains valid for adapted random drifts. It does not require
a Markov drift for the error. A second stopping time at a chart boundary
is legitimate, provided the deterministic chart margin shows that this
boundary cannot be reached before the chosen error radius. This last
condition must be checked in the concrete model.

## 2. The fine process has an actual margin for all finite horizons

The previously proved smaller-cut nominal residual ODE is, after writing
`x` for the strong edge and `r` for the weak edge,

\[
\dot x=-3K\sin x+k\sin r,\qquad
\dot r=K\sin x-3k\sin r,
\quad x_0\in(1/4,1/3),\quad r_0\in(1/8,1/6).
\tag{3}
\]

The positive quadrant is invariant. Its horizontal cut `h=r+x/3`
satisfies `dot h=-(8/3)k sin r`. A first-exit argument at `x=x_0`
and the decreasing `h` therefore gives

\[
0<x(t)<1/3,\qquad 0<r(t)\le h(t)<5/18,
\qquad t\ge0,
\tag{4}
\]

when `K/k>=256`. Bridge residuals are zero on the symmetric nominal
trajectory. These inequalities hold beyond the originally displayed
late window `[3/k,4/k]`. That proof's bound
`h(t)<exp(-(20/9)kt)+2k/(15K)` also holds for every `t>=3/k`, so the
strong and weak coherence bounds persist for all later deterministic
times.

Every original residual in (4) lies strictly inside the convex tube
`|D x|_infty<1/2`, where `D` stacks the five fast and two weak rows. Its
margin is at least `1/6`. The source's elementary estimate for vectors
`v` perpendicular to the common kernel is

\[
|v|^2\le2|B_sv|^2+(2\|A\|^2+1/c_-)|B_fv|^2.
\]

Thus, if `K>=(k/2)(2||A||^2+1/c_-)`, the actual Hessian on that normal
space throughout this tube satisfies

\[
\nabla^2 U|_N\succeq m_N I_N,
\qquad m_N=(k/2)\cos(1/2)>0.
\tag{5}
\]

This lower bound is independent of increasing `K`. For two deterministic
solutions with the same coefficients, whose joining segment lies in the
convex residual tube, their normal difference obeys
`d|e|^2/dt<=-2m_N|e|^2`. The field and Hessian vanish in the common
kernel, so arbitrary neutral displacements do not enter this estimate.
Choose the initial normal error smaller than the residual margin divided
by the largest row norm of `D` (at most `sqrt3`). First exit and contraction
then prove that the perturbed deterministic solution remains in the tube
for every `t>=0`.

For the stronger episode margins, choose that error much smaller, as in
the prior source's `1/(4096 sqrt3)` neighborhood. This preserves both
the first pair-only window and the later whole-block bounds. It also
leaves room for the stochastic error radius in (2). The rank-seven noise
in this normal space has exactly covariance `2T I_7 dt`; neutral Brownian
motion does not affect a residual and need not stay in a bounded root
lift. Hence the joined use of (2) for the fine diffusion has a verified
all-horizon geometric margin, rather than an assumed one.

Parameter openness is also compatible with the margin. On the same
tube a change `delta w` in the seven interaction coefficients perturbs
the drift by at most `||D|| |delta w|`. Comparing to the nominal field
adds at most `||D|| |delta w|/m_N` to the normal distance, after slightly
reducing the positive lower bound if necessary. Sufficiently small
absolute coefficient perturbations therefore preserve a strict margin
uniformly in time. The admitted family need not have a uniform relative
width in its large coefficient `K`.

## 3. The adapted fast comparator is legitimate

Until the chart exit, the actual transformed fast equation is

\[
dz=-KC\sin zdt-kCA^T\sin(s_t+Az)dt
 +\sqrt{2T}C^{1/2}dB^f_t.
\tag{6}
\]

For each continuous adapted cut path `s_t`, the equation with the same
drift and no noise has a unique adapted finite-variation solution `z^d`
from `z^d_0=z_0`: its drift is globally Lipschitz in `z^d` and continuous
in time. Its coefficients are bounded at each finite `K`. Define
`R_d=|C^{-1/2}z^d|`. The direct scalar-product calculation gives

\[
\frac12\frac d{dt}R_d^2
=-K z^d\cdot\sin z^d
 -k z^d\cdot A^T\sin(s_t+Az^d)
\le-K\alpha R_d^2+k\beta R_d,
\tag{7}
\]

where `alpha=c_- sin(rho_f)/rho_f` and
`beta=sqrt2 ||C^{1/2}A^T||`. Regularization at `R_d=0` or scalar
comparison gives

\[
R_d(t)\le e^{-K\alpha t}R_d(0)+k\beta/(K\alpha).
\tag{8}
\]

There is an explicit nonempty fast-margin choice. The exact matrices
have `c_+<5`, and the symmetric initial vector gives
`R_d(0)=sqrt(2/3)x_0<1/3`. Set `rho_f=7/5` and take `K` large enough
that `k beta/(Kalpha)<1/6`. Then

\[
\sqrt{c_+}(R_*+k\beta/(K\alpha))
<\sqrt5/2<7/5.
\tag{9}
\]

Small initial perturbations preserve (9). A sufficiently small additional
noise radius also fits it. Thus the bound does not assume the fast
comparator's continued existence inside its convexity chart.

Subtract (6) and its adapted comparator. In
`xi=C^{-1/2}(z-z^d)` the noise has identity covariance times `2T`.
At fixed `s_t`, the drift is the negative gradient of the fast potential
in whitened coordinates. Its Hessian on the joining segment is bounded
below by

\[
m_f=Kc_-\cos\rho_f
 -k\|C^{1/2}A^TAC^{1/2}\|.
\tag{10}
\]

The irregular dependence of `s_t` on time produces no derivative in
this subtraction: both drift evaluations use the same current `s_t`.
Consequently `xi.b_xi<=-m_f|xi|^2`. Equation (2) at rank five gives the
joined probability bound with constant `m_f exp(3/2)`, since
`exp(3/2)>5/2`. The resulting pointwise fast estimate is precisely the
joined equation (3).

## 4. Parent contraction and the complete retained path norm

In a common cut lift the exact inherited parent is
`d bar s=-S grad F_1(bar s)dt+sqrt(2T)S^{1/2}dB^s`, with the same
initial retained point and the same projected noise as the microscopic
retention. Its force has the finite-stiffness error `delta_K` and the
local Hessian lower bound `m_1` proved in the formation component.
For `u=S^{-1/2}(s-bar s)`, noise cancels exactly. Adding and subtracting
`grad F_1(s)` gives

\[
\frac d{dt}|u|\le-\lambda_1|u|
 +\sqrt{s_+}\big(k\|A\||z|+\delta_K\big),
\qquad\lambda_1=m_1s_-.
\tag{11}
\]

The vector `y-bar y` lies in `range(PB_s^T)`: its initial value is zero,
both noise terms cancel, and both drifts lie in that range. Accordingly

\[
y-\bar y=PB_s^TS^{-1}(s-\bar s),
\qquad |y-\bar y|^2=(s-\bar s)^TS^{-1}(s-\bar s)=|u|^2.
\tag{12}
\]

This checks the complete retained angular norm, including its neutral
component. Integrating (11), the initial fast transient satisfies
`integral_0^t exp(-lambda_1(t-v))exp(-Kalpha v)dv<=1/(Kalpha)`.
The forcing floor integrates to at most `1/lambda_1`. These two elementary
inequalities give exactly the joined equation (4), with no growing
Gronwall factor and no omitted initial fast layer.

All these statements are stopped at the fine or parent tube exit. The
fine exit is controlled by Section 2 above, and the parent exit by the
invariant ellipsoid and rank-two estimate in the formation component.
The bad probabilities are added by the union bound. Independence is not
required. Principal-branch discontinuities outside those events remain
part of the exact global Borel law, so the path argument does not silently
replace either process by a globally reflected or globally continuous
coarse process.

## 5. The common polynomial regime

The declared integer coordinates `(theta_1,theta_2,theta_3;z;r)` are a
torus isomorphism. They reconstruct `psi_i=theta_i-z_i`, then each strong
and weak link by its defining residual. This checks the normalized
product preparation used in the joined proof. Haar `theta` conditional
on residuals is Haar on the common kernel; it need not concentrate.

The exact initial entropy formula can be checked without relying on a
Bessel identity. For a single factor of concentration `h` shifted by
`a`, the likelihood ratio to its unshifted factor is
`h[cos(v-a)-cos v]`. Under the shifted law, put `w=v-a`.
The odd integral of `sin w` vanishes, so its KL is

\[
h(1-\cos a)
\frac{\int_{-\pi}^{\pi}\cos w\exp(h\cos w)dw}
     {\int_{-\pi}^{\pi}\exp(h\cos w)dw}.
\tag{13}
\]

Both integrals are finite and the denominator is positive. The ratio is
at most one; summing two shifted strong and two shifted weak factors
gives the joined equation (9). The unshifted bridge factors contribute
zero. Product normalizers are unchanged by shifts.

For any fixed residual neighborhood, the one-coordinate tail estimate
is `(pi/a_h)exp(1/2-h(1-cos d_0)/T)`, where here `h` denotes its energy
coefficient and `a_h=min(1,sqrt(T/h))`. This is obtained by integrating
near the shifted minimum for the denominator and using the positive
energy gap outside the neighborhood. A union bound gives the explicit
seven-coordinate concentration bound in the formation component.

Now set `K=T^{-3}`, keep positive `k` in a bounded interval, and let
`T` decrease. The following are deductions from displayed bounds, not
numerical observations:

\[
H_0=O(T^{-4}),\quad m_f\asymp T^{-3},\quad
\delta_K=O(T^2),\quad\eta_K\longrightarrow0,
\quad\lambda_1\ge\lambda_*>0.
\tag{14}
\]

The companion entropy theorem has constants bounded independently of
`K,T` in this regime; using that result, its sufficient horizon is
`H=O(T^{-1}log(1/T))`. The fine and parent tube estimates are a polynomial
prefactor times `exp(-c/T)` and tend to zero. If the fast comparison
failure tolerance is chosen to be `epsilon=T`, then

\[
\ell=O(T^2\sqrt{\log(1/T)}),\qquad
E_K=O(T^2\sqrt{\log(1/T)})\longrightarrow0.
\tag{15}
\]

The same scale of `ell` holds for a fixed positive failure tolerance,
but then that particular bad-event upper bound stays fixed. This is a
distinction about the probability claim, not a defect in the path
estimate. Taking `epsilon=T` makes every displayed bad probability
vanish simultaneously. The initial concentration errors also vanish.

Fixing one sufficiently small positive `T` turns all asymptotic choices
into finite strict inequalities. Smooth parameter dependence on compact
charts and the preceding contraction margins yield a nonempty open
parameter neighborhood. A normalized relative `C^1` multiplier near one
preserves positivity and changes the initial bad mass by at most its
bounded supremum. Its log-density ratio and gradient are finite, so it
also preserves the needed finite initial entropy and early density
bounds. This proves openness at each chosen finite parameter point;
there is no assertion of a temperature-independent neighborhood radius.

## 6. Result, executed check, and remaining dependency

The calculations above establish the joined noise bound, adapted fast
comparator, contraction-based full retained path estimate, and compatible
polynomial parameter regime within their stated stopped-chart scope.
No counterexample was found in this reconstruction, and no correction to
the constants in Sections 2–3 is needed. The explicit all-horizon margin
and the optional choice `epsilon=T` make two otherwise implicit hypothesis
checks concrete.

The only executed mathematical check was the tiny
[Fraction script](evidence/nonlinear-formation/check_constants.py), using
`C:/Python314/python.exe`. Its
[JSON output](evidence/nonlinear-formation/constants-output.json) records
nine true exact checks for matrices and scalar episode inequalities. It
is supplementary arithmetic evidence; the differential and asymptotic
arguments are the proofs above. No model experiment, GPU computation,
test suite, Lean work, or tamper check was run.

The independent entropy theorem and global parent geometry remain
separate proof dependencies outside this assigned reconstruction. Their
mathematical verification belongs to their independent checkers; their
presence alone is not an inference of correctness here. This report
assigns no ledger status.

## 7. Final inspected revision

The final joined proof was read again at SHA-256
`4f3d840dc8b078ea1f764fc39c33685b561ec343aada97a3c092164c475c27f3`.
The matching formation component was read at SHA-256
`a3aa9ac425c3c09d4bab545dbe6f61a4a0fea35de0b284c1a7a92e3243b5a51e`.
The final root explicitly includes the all-horizon fine margin, the
vanishing-error choice `epsilon=T`, and the interval

\[
I_2=[\max\{3/k,t_{\rm ent}\},
      \max\{3/k,t_{\rm ent}\}+1/k].
\]

On this nondegenerate interval the established coherence persists and
the companion entropy bounds have already reached their tolerance.
Adding `1/k` leaves the polynomial horizon argument unchanged. The
optional-mark scope is also explicit: the main witness has the ten
angular variables, while additional retained marks use the stated
conditional extension. These edits do not alter any checked formula in
Sections 2–3. No unresolved trajectory or common-regime step remains in
this assigned reconstruction; complete RG acceptance additionally uses
the separate geometry and entropy evidence.
