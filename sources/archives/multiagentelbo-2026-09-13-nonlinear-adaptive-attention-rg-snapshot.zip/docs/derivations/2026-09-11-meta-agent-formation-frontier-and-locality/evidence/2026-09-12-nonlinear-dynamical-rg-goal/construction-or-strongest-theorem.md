<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617","target_digest":"1c36068291f88161b4aea705bb225bcd1fc75ad05db06148e0f86bb6cc91a617"} -->

# Nonlinear finite construction

The theorem is proofs/nonlinear-two-stage-completion.md with its three component derivations. One compact cosine model with common microscopic kinetics and supplied interaction contrast has actual pair-then-whole coalescence, two exact normalized parent integrations and inherited dynamics with explicit finite-horizon errors. Its configuration dimensions are 10, 5 and 3. Every principal face identification remains in the global retained laws.

The first conditional loss is uniformly O(T^2), plus displayed exponentially small terms, after any fixed positive initial time in the witness regime K=T^-3. The actual fine second loss and the autonomous first-parent second loss have separate exponential entropy estimates; the final Brownian law also has its own entropy bound. A horizon O(T^-1 log(1/T)) makes the second losses small while the dissipative path bounds preserve coherence with high probability. Both generated nonlinear integrals and all physical evaluator/conditional costs are retained. An analytic-slice argument supplies a nonempty open subset with a nonzero generated cross interaction.

The same equations and preparation enter every proof. No Gaussian replacement, conditional matching, rate reset, erased branch, storage condition, or infinite-depth conclusion is used. The complete independent reconstruction is proofs/nonlinear-independent-reconstruction.md.
