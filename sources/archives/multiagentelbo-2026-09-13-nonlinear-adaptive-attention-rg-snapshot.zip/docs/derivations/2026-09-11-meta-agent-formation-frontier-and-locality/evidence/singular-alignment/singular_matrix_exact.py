"""Exact polar-KL, Gaussian mean-integral, and cycle determinant identities."""
from fractions import Fraction as F
from pathlib import Path
import json
import runpy
import sys

Matrix = list[list[F]]


def determinant(a: Matrix) -> F:
    rows = [[F(v) for v in row] for row in a]
    value = F(1)
    for j in range(len(rows)):
        pivot = next((i for i in range(j, len(rows)) if rows[i][j]), None)
        if pivot is None:
            return F(0)
        if pivot != j:
            rows[j], rows[pivot] = rows[pivot], rows[j]
            value *= -1
        v = rows[j][j]
        value *= v
        for i in range(j + 1, len(rows)):
            scale = rows[i][j] / v
            rows[i] = [x - scale * y for x, y in zip(rows[i], rows[j])]
    return value


def diagonal(values: list[F]) -> Matrix:
    return [[v if i == j else F(0) for j in range(len(values))] for i, v in enumerate(values)]


def mean_residual(edges: list[tuple[int, int]], links: list[Matrix], n: int, k: int) -> Matrix:
    rows = []
    for (i, j), H in zip(edges, links):
        for a in range(k):
            row = [F(0) for _ in range(n * k)]
            row[i * k + a] += 1
            for b in range(k):
                row[j * k + b] -= H[a][b]
            rows.append(row)
    return rows


def main() -> None:
    r"""Check KL polar coordinates, the Gaussian tilt, and det(L)=det(A)det(W)det(R)det(S)."""
    support = runpy.run_path(str(Path(__file__).parents[1] / 'normalized-alignment/triangle_exact.py'))
    mul, trans, inv, add = [support[key] for key in ['mul', 'transpose', 'inverse', 'add']]
    quadratic, trace, encoded = [support[key] for key in ['quadratic', 'trace', 'encoded']]
    I = diagonal([F(1)] * 3)
    Si = [[F(v) for v in row] for row in [[2, 1, 0], [1, 2, 0], [0, 0, 1]]]
    Sj = diagonal([F(1), F(2), F(3)])
    B = [[F(v) for v in row] for row in [[2, 1, 0], [1, 3, 0], [0, 0, 1]]]
    O = [[F(v) for v in row] for row in [[1, 0, 0], [0, 0, -1], [0, 1, 0]]]
    ui, uj = [[[F(v)] for v in values] for values in [[1, 2, -1], [-1, 0, 2]]]
    Sigma_i, Sigma_j = mul(Si, Si), mul(Sj, Sj)
    Theta = mul(mul(mul(Si, inv(B)), O), inv(Sj))
    T = mul(mul(Theta, Sigma_j), trans(Theta))
    residual_raw = add(mul(Si, ui), mul(Theta, mul(Sj, uj)), F(-1))
    residual_polar = add(mul(B, ui), mul(O, uj), F(-1))
    raw_trace = trace(mul(inv(T), Sigma_i))
    raw_mean = quadratic(inv(T), residual_raw)
    assert raw_trace == trace(mul(B, B))
    assert raw_mean == mul(trans(residual_polar), residual_polar)[0][0]
    assert determinant(T) / determinant(Sigma_i) == 1 / determinant(B)**2
    assert mul(B, O) != mul(O, B)
    polar = {'trace_term': str(raw_trace), 'mean_quadratic': str(raw_mean),
             'covariance_determinant_ratio': str(determinant(T) / determinant(Sigma_i)),
             'polar_logdet_argument_det_B': str(determinant(B)), 'noncommuting_B_and_O': True}

    edges = [(0, 1), (1, 2), (2, 0), (0, 2)]
    weights = [F(1), F(2), F(3), F(5)]
    reflection = diagonal([F(1), F(-1), F(1)])
    t = F(1, 10)
    rotation = [[(1-t*t)/(1+t*t), -2*t/(1+t*t), F(0)],
                [2*t/(1+t*t), (1-t*t)/(1+t*t), F(0)], [F(0), F(0), F(1)]]
    perturbed = mul(mul(rotation, reflection), trans(rotation))
    cases = []
    for name, H1 in [('singular_common_fixed_line', reflection), ('centered_no_common_fixed_vector', perturbed)]:
        links = [I, I, H1, O]
        Rall = mean_residual(edges, links, 3, 3)
        W = diagonal([v for v in weights for _ in range(3)])
        L = mul(mul(trans(Rall), W), Rall)
        tree_rows = [row[3:] for row in Rall[:6]]
        A = mul(mul(trans(tree_rows), diagonal([v for v in weights[:2] for _ in range(3)])), tree_rows)
        D = [row[3:] for row in Rall[6:]]
        C = [row for H in [H1, O] for row in add(I, H, F(-1))]
        Wc = diagonal([v for v in weights[2:] for _ in range(3)])
        R = add(inv(Wc), mul(mul(D, inv(A)), trans(D)))
        S = mul(mul(trans(C), inv(R)), C)
        decomposed = determinant(A) * determinant(Wc) * determinant(R) * determinant(S)
        assert determinant(L) == decomposed
        assert determinant(A) * determinant(Wc) == F(27000)
        J0 = diagonal([F(i + 1) for i in range(9)])
        C0 = inv(J0)
        m0 = [[F(i % 3 - 1, i + 1)] for i in range(9)]
        h0 = mul(J0, m0)
        tilts = []
        for n in [0, 1, 4, 16]:
            Jn = add(J0, L, F(n))
            InCL = add(diagonal([F(1)] * 9), mul(C0, L), F(n))
            complete_exponent = (quadratic(inv(Jn), h0) - quadratic(J0, m0)) / 2
            tilted_exponent = -F(n, 2) * quadratic(mul(L, inv(InCL)), m0)
            assert complete_exponent == tilted_exponent
            assert determinant(InCL) == determinant(Jn) / determinant(J0)
            tilts.append({'n': n, 'det_I_plus_n_C_L': str(determinant(InCL)), 'evidence_exponent': str(complete_exponent)})
        cases.append({'name': name, 'det_L': str(determinant(L)), 'det_R': str(determinant(R)),
                      'det_root_S': str(determinant(S)), 'weight_factor': '27000',
                      'cycle_matrix_dimension': 6, 'root_matrix_dimension': 3, 'full_mean_dimension': 9,
                      'mean_tilts': tilts, 'H1': encoded(H1), 'H2': encoded(O)})
    assert cases[0]['det_L'] == '0'
    assert F(cases[1]['det_L']) > 0
    result = {'scope': 'Exact finite matrix identities supporting the written singular-integral argument. No nonlinear alignment integration or simulation.',
              'runtime': sys.version, 'executable': sys.executable, 'polar_identity': polar,
              'edges': edges, 'weights': [str(v) for v in weights], 'cases': cases, 'all_assertions_passed': True}
    Path(__file__).with_name('singular-matrix-exact-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'polar_identity': polar, 'cases': [{'name': c['name'], 'det_L': c['det_L']} for c in cases], 'all_assertions_passed': True}, indent=2))


if __name__ == '__main__':
    main()
