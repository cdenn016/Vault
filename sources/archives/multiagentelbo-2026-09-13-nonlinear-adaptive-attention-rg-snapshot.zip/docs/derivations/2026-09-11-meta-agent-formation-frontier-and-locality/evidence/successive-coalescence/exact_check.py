"""Tiny exact checks for the written successive-coalescence construction.

This checks rational matrix identities and elementary constant bounds.
It does not integrate trajectories or prove general theorem hypotheses.
"""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json


def transpose(a: list[list[F]]) -> list[list[F]]:
    return [list(row) for row in zip(*a)]


def matmul(a: list[list[F]], b: list[list[F]]) -> list[list[F]]:
    return [[sum((x * y for x, y in zip(row, col)), F(0))
             for col in zip(*b)] for row in a]


def subtract(a: list[list[F]], b: list[list[F]]) -> list[list[F]]:
    return [[x-y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def scale(a: list[list[F]], c: F) -> list[list[F]]:
    return [[c*x for x in row] for row in a]


def encoded(a: list[list[F]]) -> list[list[str]]:
    return [[str(x) for x in row] for row in a]


def main() -> None:
    a = [[F(x) for x in (1, -1, 0, -1, 0)]]
    b = [[F(x) for x in (0, 1, -1, 0, -1)]]
    identity = [[F(i == j) for j in range(5)] for i in range(5)]
    p = subtract(identity, scale(matmul(transpose(a), a), F(1, 3)))
    v = matmul(p, transpose(b))
    c = matmul(transpose(v), v)[0][0]
    q = subtract(p, scale(matmul(v, transpose(v)), 1/c))
    rows = a+b
    inverse = [[F(3, 8), F(1, 8)], [F(1, 8), F(3, 8)]]
    direct = subtract(identity, matmul(matmul(transpose(rows), inverse), rows))
    zero = [[F(0) for _ in range(5)]]
    assert matmul(p, p) == p
    assert matmul(a, p) == zero
    assert c == F(8, 3)
    assert q == direct
    assert matmul(q, q) == q
    assert matmul(rows, q) == zero+zero

    embedding = [[F(x) for x in row] for row in (
        (1, 0, 1, 0), (1, 0, 0, 0), (0, 1, 0, 0),
        (0, 0, 1, 0), (0, 0, 0, 1))]
    graph_metric = matmul(transpose(embedding), embedding)
    graph_inverse = [[F(x) for x in row] for row in (
        (F(2,3), 0, F(-1,3), 0), (0, 1, 0, 0),
        (F(-1,3), 0, F(2,3), 0), (0, 0, 0, 1))]
    identity4 = [[F(i == j) for j in range(4)] for i in range(4)]
    assert matmul(graph_metric, graph_inverse) == identity4
    weak_row = matmul(b, embedding)
    parent_velocity = scale(matmul(graph_inverse, transpose(weak_row)), F(-1))
    assert parent_velocity == [[F(-2,3)], [F(1)], [F(1,3)], [F(1)]]

    exponential_lower = sum((F(10)**n/F(factorial(n))
                              for n in range(35)), F(0))
    assert exponential_lower > 20000
    first_bound = F(1,60000)+F(1,640)
    assert first_bound < F(1,512)
    later_exponential_lower = F(8,3)**6*F(5,3)
    assert later_exponential_lower > 512
    later_bound = F(1,512)+F(1,1920)
    assert later_bound < F(1,256)
    k, h = F(20,9), F(640)
    assert F(7,9)+k/(9*(h-k)) < 1
    assert k*(3-F(1,64)) > 6
    assert F(8,3)**6 > 256
    assert F(13,128)-F(2,4096) > F(1,10)
    result = {
        "scope": "Exact rational identities and sufficient scalar inequalities only",
        "projector_first": encoded(p),
        "projector_composed_equals_direct": q == direct,
        "projector_second": encoded(q),
        "inherited_cut_mobility": str(c),
        "graph_metric": encoded(graph_metric),
        "graph_metric_inverse": encoded(graph_inverse),
        "parent_velocity_per_sine": encoded(parent_velocity),
        "first_interval_x_upper": str(first_bound),
        "later_interval_y_upper": str(later_bound),
        "small_cut_perturbed_lower": str(F(13,128)-F(2,4096)),
        "all_assertions_passed": True,
    }
    out = Path(__file__).with_name("exact-check.json")
    out.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"output": str(out), "all_assertions_passed": True}))


if __name__ == "__main__":
    main()

