# A reusable compact parent class

September 12, 2026. This is the typed exact-law component of the [finite-depth contract](evidence/2026-09-12-finite-depth-dynamical-rg-goal/problem-contract.json), digest `d15c9f5a5a810b76900ea496929ff4a5c6832d4553a379d5da43ce2f1f7e3bd9`. The construction below is exact. Quantitative dynamical admissibility and actual formation are separate obligations; neither follows merely from integration closure.

The sources are [the nonlinear parent geometry](nonlinear-parent-laws-and-geometry.md), Sections 1–7, [the joined two-stage proof](nonlinear-two-stage-completion.md), and Theory/03, Theory/05b and Theory/07c. The live PIFB2 passages `eq:rg_internal_hessian`, `eq:rg_reduced_hessian`, `eq:rg_slow_graph_metric` and `eq:rg_schur_flow` supply the earlier distinctions among internal stiffness, generated interactions, inherited geometry and force accuracy. Everything here is at one fixed base point. No base path or connection descent is used.

## 1. Microscopic family and exact objective

Fix an integer L >= 3 and n=2^L. Take the path with vertices 1,...,n and oriented edges e=(i,i+1). Write ell(e)=1+v_2(i), so the edge groups have n/2, n/4,...,1 members. This is a supplied microscopic pattern of interaction weights, not a supplied trajectory or merger schedule.

The configuration has angles theta_i, psi_i and two independent link angles alpha_e^b, alpha_e^m. Thus X_0=T^(4n-2), with normalized Haar measure and the common unit metric on all angular coordinates. The residual matrix B has rows

\[
d_i=\theta_i-\psi_i,\qquad
r_e^b=\theta_i-\theta_{i+1}-\alpha_e^b,\qquad
r_e^m=\psi_i-\psi_{i+1}-\alpha_e^m.
\tag{1}
\]

There are m=3n-2 rows. They have full real row rank. More strongly, the coordinates (theta,d,r^b,r^m) give a torus automorphism with the integer inverse

\[
\psi_i=\theta_i-d_i,\quad
\alpha_e^b=\theta_i-\theta_{i+1}-r_e^b,\quad
\alpha_e^m=\theta_i-\theta_{i+1}-d_i+d_{i+1}-r_e^m.
\tag{2}
\]

In particular every residual assignment occurs and there is no missing finite label in these global microscopic coordinates. The inverse matrix has squared Frobenius norm 11n-8.

Let V(t)=1-cos(t), J_1 >= ... >= J_L > 0, and give all d_i the coefficient J_1. The actual nonlinear energy is

\[
U(x)=J_1\sum_i V(d_i)+
\sum_e J_{\ell(e)}[V(r_e^b)+V(r_e^m)].
\tag{3}
\]

Fix 0<a<1. At each node use u_i=(cos theta_i,sin theta_i) and v_i=(cos psi_i,sin psi_i), belief N(u_i,I_2), model presentation N(v_i,a I_2), and evaluator N(zeta_i,(1-a)I_2). The fixed-marginal optimizing coupling is zeta_i=v_i+xi_i, k_i=u_i+xi_i+epsilon_i, with independent centered Gaussian noises of covariances a I_2 and (1-a)I_2. The affine log-density-ratio identity in the source proves, over all couplings with these two marginals,

\[
\min D(S_i\Vert m_i\operatorname{ev}_i)
=d_i^{\rm ev}=\frac{V(d_i)}{1-a}.
\tag{4}
\]

Here d_i in V is the angle residual, whereas d_i^ev is the scalar cost. Define d^ev=sum_i d_i^ev and U_0=U-Td^ev, with J_1>T/(1-a). The normalized generative experiment is

\[
P_0(dx)\prod_i m_i(d\zeta_i)\operatorname{ev}_i(\zeta_i,dk_i),
\qquad P_0=Z_0^{-1}e^{-U_0/T}\nu_0.
\tag{5}
\]

Every factor is normalized and has full support. The observation is a singleton, and the generative evidence equals one. Correlated outer recognition Q followed by the optimizing inner couplings gives

\[
\mathcal F(Q)=T D(Q\Vert P_0)+T E_Qd^{\rm ev}
=T D(Q\Vert\pi)-T\log c,
\quad \pi=c^{-1}e^{-d^{\rm ev}}P_0,
\quad c=E_{P_0}e^{-d^{\rm ev}}.
\tag{6}
\]

Compactness makes both normalizers finite and positive. Formula (2) also gives them as products of the corresponding one-dimensional von Mises integrals. No sum of overlapping local ELBOs defines (6). The common microscopic dynamics are dx=-grad U dt+sqrt(2T)dW on X_0. Smooth periodic coefficients give a global strong solution. The density objective decreases by dD(Q_t||pi)/dt=-T I(Q_t||pi); this is the declared diffusion contract, not every possible local Fisher update.

The passive gauge action theta_i -> theta_i+g_i, psi_i -> psi_i+g_i and alpha_e^{b,m} -> alpha_e^{b,m}+g_i-g_{i+1} fixes (1). It acts by flat translations and preserves the law family, metric and reference. The state is a specialization of paired associated statistical fibers with independent links. The tree has no nontrivial loop sector; this witness proves nothing about general non-Abelian holonomy.

## 2. Primitive flags and exact coordinates

Put B_1 equal to the n node-residual rows and the two-channel edge rows with ell=1. For s>1, B_s contains the two-channel edge rows with ell=s. Define

\[
M_s=\ker(B_1,\ldots,B_s:X_0\longrightarrow
\mathbb T^{\sum_{j\le s}m_j}),\qquad M_0=X_0.
\tag{7}
\]

Each kernel is connected. Its free global coordinates are the n theta_i and the two link angles on edges with ell>s; all psi_i equal theta_i and links on eliminated edges equal the corresponding theta differences. The restriction B_s:M_{s-1}->T^{m_s} is surjective with connected kernel M_s: for s>1 the free current-edge links give each residual independently; for s=1 use (2). This proves primitivity, not just real rank.

Let P_s be the Euclidean orthogonal projection onto the real tangent space W_s of M_s. Set P_0=I and

\[
C_s=B_sP_{s-1}B_s^T,
\quad R_s=P_{s-1}B_s^TC_s^{-1},
\quad P_s=P_{s-1}-R_sB_sP_{s-1}.
\tag{8}
\]

Surjectivity makes C_s positive definite. The ranges of R_s for distinct s are orthogonal, B_s R_s=I, and the earlier rows annihilate R_s. All these identities follow by substituting (8) and using the nested kernels.

Choose principal representatives in [-pi,pi). Recursively put

\[
z_s=\operatorname{pr}(B_s y_{s-1}),\qquad
y_s=y_{s-1}-R_s z_s\pmod {2\pi},\qquad y_0=x.
\tag{9}
\]

Denote the retention y_{s-1}->y_s by the script symbol mathcal C_s, distinct from the positive matrix C_s in (8).

This is a Borel bijection M_{s-1}<->M_s x [-pi,pi)^{m_s}, with inverse y_{s-1}=y_s+R_s z_s. It is not a global topological product. Translation of Haar disintegrations on the compact group gives exactly

\[
\nu_{s-1}(dy_{s-1})=\nu_s(dy_s)
\prod_{j=1}^{m_s}\frac{dz_{s,j}}{2\pi}.
\tag{10}
\]

The complete inverse is x=y_L+sum_s R_s z_s. Off faces the induced metric is

\[
|dx|^2=|dy_L|^2+\sum_s dz_s^T C_s^{-1}dz_s.
\tag{11}
\]

At a positive-to-negative z_s face crossing, y_s gains 2pi R_s e_j in M_s. To obtain the later coordinates, apply (9) again to that translated y_s, retaining every ensuing integer carry. This explicit recursion fixes all higher face identifications; there is no unexplained loss of a sheet or winding label. The coarse maps compose as the stated Borel maps. Their composition need not equal a freshly chosen principal representative of one stacked residual matrix.

For n=8 the agent counts are 8 -> 4 -> 2 -> 1 and the configuration dimensions are 30 -> 14 -> 10 -> 8. In general, dim M_s=n+2(n/2^s-1) for s>=1. The remaining n coordinates retain the node frame origins and correlated vector presentations. Counting one meta-agent does not mean replacing those marked laws by a single scalar mean.

## 3. The integration-closed class and all conditional costs

The parent class consists of the compact tori M_s with their primitive flag, restricted metric, strictly positive smooth densities relative to normalized Haar, and complete normalized presentation/evaluator kernels. It is an infinite-dimensional law class, not a finite pairwise energy ansatz. Given smooth positive p_{s-1}, define

\[
p_s(y)=\int p_{s-1}(y+R_s z)\nu_{z_s}(dz).
\tag{12}
\]

The domain of integration is fixed and compact. Positivity and normalization follow from (10), and differentiating under the integral in any fixed torus chart proves smoothness of every order. Periodicity on M_s follows because a lattice period of M_s is already a lattice period of M_{s-1}. Thus the class is closed exactly under (12), while derivatives and conditional inequalities require quantitative bounds of their own.

Apply (12) separately to P_0 and pi. Write the resulting laws as P_s and pi_s, and the genuine generative conditionals as G_s. Let the optimizing conditionals be kappa_s. The inherited scalar cost is

\[
d_s(y)=-\log E_{P_0(\cdot\mid y_s=y)}e^{-d^{\rm ev}},
\qquad \pi_s=c^{-1}e^{-d_s}P_s.
\tag{13}
\]

Every conditional is the displayed positive density divided by its positive compact integral, so the version is fixed at each retained point. Fubini proves the tower identity for both families and all physical kernels. In particular, the parent presentation is the original full n-node Gaussian vector mixture under the composed G_s, followed by the original evaluator kernel. The optimizer instead uses the composed kappa_s and the original correlated inner coupling. Replacing G_s by kappa_s would change the generative model.

For Q_s=(mathcal C_s composed ... composed mathcal C_1)_#Q, the exact chain rule is

\[
\mathcal F(Q)=T D(Q_s\Vert\pi_s)-T\log c
+T\sum_{j=1}^s E_{Q_j}
D\bigl(Q_{j-1}(\cdot\mid y_j)\Vert\kappa_j(\cdot\mid y_j)\bigr).
\tag{14}
\]

Regular disintegration exists on these compact standard-Borel spaces; positive smooth densities make all terms finite for the preparations used below. The identity also has the usual extended nonnegative interpretation. Infimizing at fixed retained law attains the exact parent objective by the optimizing conditional lift. No bare physical-marginal ELBO identification is asserted.

Write F_s=-T log(dpi_s/dnu_s), up to its declared constant. The inherited autonomous parent generator is

\[
\overline L_s=T\Delta_{M_s}
-\operatorname{grad}_{M_s}F_s\cdot\operatorname{grad}_{M_s}.
\tag{15}
\]

Its force equals the conditional average of the tangential projection of the previous interior force: b_s(y)=E_{kappa_s}[P_s b_{s-1}(y+R_s z)]. Differentiating (12) in a tangent direction proves this identity. The projection cannot be omitted: opposite fiber faces can be glued at different retained points, so an averaged normal derivative need not vanish. Its temperature and metric come from (11). All higher derivatives of log integrals include their full conditional covariance and cumulant terms; none is dropped. The actual Borel projected process may also have conditional-force and face-current corrections. Equation (15) is an autonomous comparison process, whose approximation requires the separate bounds.

## 4. A useful global fiber bound

At a cumulative stage the original eliminated residuals have the form t=T_s z, where T_s is block lower triangular with identity diagonal and z is the stack of principal coordinates. Put A_s=|T_s-I| entrywise and K_s=||(I-A_s)^{-1}||; the inverse is a finite sum because A_s is strictly block triangular. If delta_i=dist(t_i,2pi Z), then |z_i|<=delta_i+sum_{j<i}|(T_s)_{ij}||z_j|. Induction gives |z|<=K_s|delta|. Consequently

\[
\sum_i(1-\cos t_i)\ge\frac{2}{\pi^2K_s^2}|z|^2.
\tag{16}
\]

This is a global bound on the principal fiber cube, not an assumed convexity outside the small central chart. It proves that the eliminated-energy zero in that cube is unique and supplies an explicit positive tail barrier. The [nonlinear comparison](finite-depth-nonlinear-comparison.md) uses it to derive central conditional estimates and the quantitative effect of the remaining weak terms. The [joined construction](finite-depth-completion.md) then establishes dynamical admissibility and formation in the common finite-depth regime.
