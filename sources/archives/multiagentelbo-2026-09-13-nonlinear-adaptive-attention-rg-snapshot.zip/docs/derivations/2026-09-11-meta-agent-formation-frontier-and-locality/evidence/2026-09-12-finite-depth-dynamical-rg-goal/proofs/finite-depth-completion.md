# Finite-depth nonlinear dynamical renormalization

September 12, 2026. Completed finite-depth construction, with a separate [independent reconstruction](finite-depth-independent-reconstruction.md). The frozen target is [the finite-depth contract](evidence/2026-09-12-finite-depth-dynamical-rg-goal/problem-contract.json). The proof uses the [Gaussian reference](finite-depth-gaussian-reference.md) and [nonlinear compact comparison](finite-depth-nonlinear-comparison.md), including their compact corrections.

## The construction and its quantifiers

For each prescribed finite integer L>=3, take n=2^L agents on a path at one fixed base point. Each agent has the paired law presentations and each path edge has the two independent moving links in [the parent-class construction](finite-depth-parent-class.md). Every original angle has the same unit kinetic metric. The microscopic energy is the full cosine energy (3) of that construction, and the normalized generative law with its evaluator correction gives exactly the stated correlated VFE. The actual dynamics is the resulting fixed gradient diffusion at positive temperature T. No rate, interaction or graph changes at a scheduled merger time.

Here is an ordered, nonempty parameter choice. For 0<epsilon<1 set

\[
a_s=6(2^{L-s}-1),\quad J_s=\epsilon^{-a_s},\quad
R=\epsilon^{-1},\quad
t_s=\kappa_L J_s^{-1}\log(1/\epsilon),\quad H=2t_L.
\tag{1}
\]

Choose kappa_L>2(a_1+6)/c_L, using the final positive decay constant in the Gaussian reference. This also leaves the half-interval margin needed for successive parent activation below. Choose epsilon sufficiently small for that reference's strict formation, path and entropy bounds. Then fix all those finite parameters. Choose A sufficiently small, put T=A^2/R^2, and use the wrapped stationary-covariance Gaussian preparation specified in the nonlinear comparison. Its mean edge residuals equal A, while its mean node residuals vanish. It is a smooth positive correlated density on the full compact configuration, not a Dirac measure. Decrease A until the nonlinear comparison errors satisfy the finite list of strict inequalities below. Each is possible because its power of A is positive after the fixed epsilon choice. The generative positivity condition J_1>T/(1-a) is then automatic for fixed 0<a<1.

For L=3 this specializes to eight agents, weights (epsilon^-18,epsilon^-6,1), and three separated intervals I_s=[t_s,2t_s]. The graph components in those intervals are respectively four pairs, two four-agent blocks and one eight-agent block. The retained configuration dimensions are 30,14,10,8; the corresponding agent counts are 8,4,2,1. Complete marked law presentations account for the difference between an agent count and a coordinate count.

## Actual formation and the inherited parents

Set the residual coherence threshold eta=A/(100n). Declare a link coherent when both of its transported channel residuals have absolute principal value at most eta, and require the within-node bridge residuals to obey the same bound. In this angular Gaussian presentation, each transported KL is exactly a fixed positive multiple of 1-cos(residual). Thus this is a precise finite transported-law tolerance, with a strict margin to the initially separated edge residuals. The threshold is part of this finite witness; the claim does not require an externally fixed numerical tolerance.

The Gaussian reference proves that, with probability tending to one as epsilon decreases, all edges at levels <=s are coherent throughout I_s and all future edges remain separated from zero by a fixed multiple of A. At t=0 every edge is separated. It proves these conclusions both for the fine process and for every autonomous inherited Gaussian parent on its remaining stages. Its proof uses actual trajectories, the restoring flag, and the positive constrained residual system with a controlled Schur correction. The grouping is read from the connected coherent components of these trajectories. The supplied microscopic weight pattern helps determine which components appear; the chronology is a conclusion of the equations.

The exact nonlinear parents are the full compact integrals pi_s, not Gaussian replacements. By nonlinear comparison (2)-(6), their paths can be coupled with the Gaussian references with additional displacement at most H d_A and additional exceptional probability E_A, where

\[
d_A\le K_{L,\epsilon} A^{5/2}
+K_{L,\epsilon} A^{-p}e^{-c_{L,\epsilon}A^{-1/5}},
\quad
E_A\le K_{L,\epsilon} A^{-p}e^{-c_{L,\epsilon}A^{-1/5}}.
\tag{2}
\]

Choose A so that the residual image of H d_A is smaller than one quarter of the strict Gaussian coherence margin. This is possible because d_A/A tends to zero. A union bound over the finite number of processes and stages gives all L actual nonlinear coalescence intervals together. Previously coalesced components remain coherent over subsequent intervals up to H on that event. Positive temperature leaves a stated exceptional probability; there is no assertion of permanent exact agreement.

At each reduction the same exact primitive Borel map integrates the eliminated coordinates, preserves the global face identifications, retains the distinct generative and optimizer conditionals, and inherits the restricted metric. The exact parent has every generated interaction contained in its log integral. Its normal Hessian differs from the Gaussian Schur precision by at most K_{L,epsilon} A^{7/5}+E_A. The finite Gaussian restoring lower bounds therefore survive at every subsequent stage. In particular no next-parent admissibility assumption is inserted recursively.

There is a necessary distinction in the meaning of parent agreement. The full parent presentation is a correlated marked mixture; its KL is not asserted to equal a single cosine residual. The inherited physical edge statistic is instead exactly the conditional expectation under G_{0:a} of the original transported edge KL. The optimizer has the separately defined statistic under kappa_{0:a}. Both follow from the existing normalized kernels, and do not add an external task or selection cost. These statistics share the same strict coherent/separated episodes. To see this quantitatively, let z be the eliminated normal lift at a retained point with |y|<=C_L A. Gaussian conditioning and the same central-integral comparison give

\[
E|z|^2\le C_L\left[(J_{a+1}/J_a)^2 A^2+T/J_a\right]
+K_{L,\epsilon}A^{17/5}+E_A
\tag{2a}
\]

for a>=1, with J_{L+1}=0. The Gaussian mean is -H_ff^{-1}H_fy y and its covariance is T H_ff^{-1}. On the comparison region, changing its conditional density costs at most C b^2(b^4/T), which is O(A^{17/5}); tails are exponential. Under the generative conditional the further tilt is exp(d^ev), whose central oscillation is O(b^2), adding at most O(b^4)=O(A^{18/5}); it leaves (2a) valid after increasing the constant. Every original edge residual differs from the retained-state residual by a fixed linear function of z. Consequently its conditional root-mean-square difference, divided by A, is bounded by C_L[J_{a+1}/J_a+1/(R sqrt(J_a))]+K_{L,epsilon}A^{7/10}+an exponential term. First decreasing epsilon, then A, makes this smaller than the strict residual margin. Taylor's inequality for 1-cos, or its quadratic upper and lower bounds on the central chart, now puts the coherent expected KL below a fixed multiple of eta^2 and the unmerged expected KL above a fixed positive multiple of A^2. The nonlinear tail is included. This verifies agreement in the inherited physical statistic while retaining the full parent law.

## Conditional VFE and dynamical errors through depth L

Write Q_{a,t} for the actual autonomous parent at stage a, with a=0 denoting the microscopic process. For a<s, let Delta^N_{a:s} be its cumulative conditional KL under the exact further Borel retentions. The Gaussian calculation and nonlinear comparison (9) give, throughout t_s<=t<=H,

\[
\Delta^N_{a:s}(t)\le
C_L R^2\left[J_1e^{-c_LJ_st}
+\frac{J_{s+1}^2}{J_s}\right]
+K_{L,\epsilon}A^{7/5}+E_A,
\qquad J_{L+1}=0.
\tag{3}
\]

After substituting (1), the Gaussian terms are at most C_L epsilon^4. A further decrease of A makes the nonlinear terms as small as desired, simultaneously for the finitely many (a,s). These are bounds for each actual evolving law; they are not deductions from path distance. The exact chain rule makes the sum of the adjacent conditional costs equal the appropriate cumulative cost. Multiplication by T gives the conditional VFE lost in that reduction, with the same evidence constant at every stage.

For a<s, the Gaussian path error p_s can be taken explicitly as

\[
p_s=C_L A\left[\frac{J_{s+1}}{J_s}
+H\frac{J_{s+1}^2}{J_s}
+\frac{HJ_{s+1}}{R\sqrt{J_s}}
\sqrt{\log\frac{C_L(1+HJ_s)}{\delta}}\right].
\tag{3a}
\]

Set delta=epsilon^2 for each of the finitely many comparisons. This gives p_s/A=O_L(epsilon^6 log(1/epsilon)+epsilon^4[log(1/epsilon)]^{3/2}); the probability cost is delta. For r reductions the exact nonlinear processes inherit

\[
\text{path error}\le\sum_a p_a+2rH d_A,
\qquad
\text{exception probability}\le\sum_a z_a+rE_A.
\tag{4}
\]

The instantaneous projected force mismatch also has a scale-sensitive bound. On the same event, with b_a=-grad F_a and y_s=C_{a:s}Y_a,

\[
|P_s b_a(Y_a(t))-b_s(y_s(t))|
\le C_L A J_{s+1}\left[e^{-c_LJ_st}
+\frac{J_{s+1}}{J_s}
+\frac{1}{R\sqrt{J_s}}
\sqrt{\log\frac{C_L(1+HJ_s)}{\delta}}\right]
+K_{L,\epsilon}d_A.
\tag{4a}
\]

For the Gaussian reference this is exactly its cross block times the random conditional defect, using (G27)-(G30). At the actual nonlinear point, (2) of the nonlinear comparison bounds the difference of each force from its Gaussian linear force. Its coupled displacement contributes at most the fixed Gaussian matrix norm times H d_A. These terms give the final K_{L,epsilon}d_A term. For t>=t_s, division by A makes the bound tend to zero by first choosing epsilon small and then A small. This is an interior pathwise force estimate with a controlled exceptional event; the separate averaged force/conditional-entropy bound remains valid as stated in the nonlinear comparison.

The retentions have operator norm one within the common normal chart; the exit probability includes every event on which a principal-coordinate face could invalidate that local comparison. The full nonlinear integral remains exact on those faces. Thus (4) is a finite-horizon approximation of dynamics, whereas the normalized laws and conditional identities are exact globally. It does not assert exact Markov closure or globally identify the final Borel projection with autonomous Brownian motion.

The local restoring rate at each conditional interface is at least its Gaussian lower bound minus K_{L,epsilon}A^{7/5}-E_A. A conservative positive global spectral gap is also recorded in nonlinear comparison (11). The two rates have different meanings: the local estimate controls the declared formation tube, and the global estimate is not advertised as a fast conditional logarithmic-Sobolev rate.

All finite-depth constants have a defined provenance: finite flag-matrix norms, their inverse bounds, Gaussian Schur matrices and quotient lattice radii. The exponents a_s grow as 2^{L-s}, and the admissible A neighborhood can shrink with all those constants. This proves a construction for every prescribed finite L. It supplies neither a uniform infinite-depth estimate nor a useful depth-independent computational cost bound.

## Successive activation at actual reduction times

The reductions can also be applied successively. Put tau_0=0 and tau_s=2t_s. Evolve the microscopic process until tau_1, apply the exact first Borel retention to its current law, and evolve that retained law under the exact first-parent generator until tau_2. Repeat through tau_L. These times choose when to use an approximation inside the proved formation windows; the original microscopic dynamics and its fixed coefficients remain unchanged. This is a sequential reduced description with quantified error.

For its Gaussian reference, each transition is an orthogonal projection. A stationary covariance T H_{s-1}^{-1} projects exactly to T H_s^{-1}, so the newly activated Gaussian parent's covariance remains stationary under its inherited generator. Each projection and each positive symmetric Gaussian semigroup is a contraction; hence its mean norm stays at most C_L A throughout. The conditional-defect proof (G11)-(G13) therefore applies on every active interval using elapsed time from tau_{s-1}. For small epsilon, tau_{s-1}<=t_s/2, so that elapsed time is at least t_s/2 on I_s. The larger kappa_L in (1) makes the exponential term at most C_L epsilon^4 there, while the plateau is unchanged.

This sequential Gaussian process has the same actual formation windows. Couple its active stage a to the separately initialized autonomous stage-a process already considered, using the common projected Brownian motion. At activation its discrepancy is at most the preceding discrepancy plus p_a from (3a). During that stage the same Gaussian semigroup contracts the discrepancy. Induction bounds it by sum_{j<=a}p_j, with probability cost at most a delta. This is o_L(A), so the strict coherent and separated margins of the autonomous process survive after decreasing epsilon. A reduction does not manufacture a new coherent interval.

Next couple the sequential nonlinear process with this sequential Gaussian reference. Between transitions the comparison (2) gives cumulative displacement at most the elapsed time times d_A. At a transition inside the good normal chart, both maps are the same norm-one orthogonal projection, so the discrepancy cannot increase. Gaussian stationary-covariance bounds on each of the finitely many active intervals give the same exponential b-chart exit bound. Thus the total additional path displacement is at most H d_A and the total additional exceptional probability is at most L E_A. On the good event the next parent starts from the actual retained nonlinear state, rather than from an independently prescribed nominal state.

The relative entropy can also be propagated at these transitions. If e is the current compact entropy to its Gaussian reference, data processing gives D(Cq^N||Cq^G)<=e. Changing Cq^G to the orthogonally marginalized wrapped Gaussian adds E_{Cq^N}log(Cq^G/g_new). The central Gaussian Borel lemma (N21)-(N23) makes this term exponentially small on the b chart, while its global logarithmic bound C/T times the actual exit probability bounds the complement. Each subsequent finite diffusion interval adds at most K_{L,epsilon} A^3+E_A by the stopped change-of-drift argument. The initial entropy at stage a is therefore bounded by a K_{L,epsilon} A^3+a E_A. The strong coupling just proved supplies the required exit bound at every restart; no total-variation-to-exit shortcut is used. In the entropy lift, a nonprincipal Gaussian winding has exponentially small conditional probability on the central chart. Combine this with the compact strong-coupling exit event, rather than replacing it by a maximal-coupling error of order sqrt(e). Uniform conditional-winding moments then justify the same Euclidean lift at each restart.

Finally apply the exact conditional-entropy identity (10) of the nonlinear comparison with this active Gaussian mean, its stationary covariance and the current nonlinear law. The active-interface loss throughout I_s is bounded by C_L epsilon^4+K_{L,epsilon} A^{7/5}+L E_A, increasing the finite constant to absorb L. These are costs of the respective current laws. Losses at different times are not presented as one telescoping objective. The global normalized parent and kernel identities remain exactly compositional. Sequential path errors retain the finite sums above. The instantaneous force bound (4a) uses elapsed time t-tau_{s-1} on the active stage; its proof uses that stage's Gaussian conditional defect directly, rather than multiplying accumulated path errors by a large Hessian. This proves repeatability of the reduction under the inherited dynamics, in addition to the separately initialized comparisons.

## Why the regime is open

After selecting one strictly positive finite epsilon and A with strict margins, all parameters and all time intervals are fixed. Smooth periodic diffusion coefficients, the exact compact parent integrals and their derivatives vary continuously under sufficiently small finite parameter changes. Coupling estimates preserve the strict path margins with slack in their exceptional probabilities. No graph or flag changes are needed.

There is also a neighborhood of the initial density, rather than only one Gaussian formula. Since the compact nominal density is strictly positive, a sufficiently small smooth perturbation has a uniformly small relative error. Positivity of each Markov semigroup and of each normalized fiber integral preserves that relative-error bound in the evolved and retained laws. At the fixed positive temperature, log density ratios against the positive compact priors are bounded. The entropy and conditional-entropy functionals therefore vary continuously, uniformly over the finite time interval. The probability of the nominal coupling event changes by at most the initial total-variation distance. Consequently the strict formation, entropy and dynamical conclusions persist in an open neighborhood of smooth positive initial densities, including densities without exact channel or gauge invariance. The special invariant preparation is used to prove one interior point, not imposed on the entire neighborhood.

Quantitatively, one may take the normalized smooth densities with ||q'_0/q_0-1||_infinity<epsilon_A, where 0<epsilon_A<exp(-k b^2/T)/4. Equations (N44)-(N45) of the [independent nonlinear reconstruction](finite-depth-nonlinear-reconstruction.md) add at most epsilon_A/2 to the initial coupling failure probability and C epsilon_A/T+C epsilon_A^2 to each conditional-entropy estimate. These additions are absorbed into E_A. This is an open neighborhood in the ordinary uniform topology restricted to smooth normalized densities at the chosen finite parameters.

The given graph, interaction contrast, local kinetic rule, channel covariances and preparation are microscopic inputs. They do not establish learned interaction strengths, a unique hierarchy, general gauge groups or loop sectors, a physical-clock identity, a universal model family, or base transport. Those are outside this finite-depth target. No capability requirement, storage charge or preferred permanent stopping level enters the construction.
