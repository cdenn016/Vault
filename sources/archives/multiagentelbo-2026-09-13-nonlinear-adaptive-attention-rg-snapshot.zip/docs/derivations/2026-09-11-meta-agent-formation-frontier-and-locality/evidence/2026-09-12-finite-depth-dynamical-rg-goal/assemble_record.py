"""Package the written finite-depth proof after its independent checks finish.

This is a document assembler, not a mathematical validator or a science run.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    run = Path(__file__).resolve().parent
    source = run.parent.parent
    contract = json.loads((run / 'problem-contract.json').read_text(encoding='utf-8'))
    binding = {key: contract[key] for key in ('schema_version', 'contract_id', 'target_digest')}
    header = '<!-- rigorous-theory-search-metadata ' + json.dumps(binding, separators=(',', ':')) + ' -->\n'

    def put_json(name: str, body: dict) -> None:
        (run / name).write_text(json.dumps(binding | body, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

    def put_md(name: str, body: str) -> None:
        (run / name).write_text(header + body, encoding='utf-8')

    names = {
        'parent': 'finite-depth-parent-class.md',
        'geometry': 'finite-depth-geometry-reconstruction.md',
        'gaussian': 'finite-depth-gaussian-reference.md',
        'nonlinear': 'finite-depth-nonlinear-comparison.md',
        'nonlinear-check': 'finite-depth-nonlinear-reconstruction.md',
        'joined': 'finite-depth-completion.md',
        'independent': 'finite-depth-independent-reconstruction.md',
    }
    missing = [name for name in names.values() if not (source / name).is_file()]
    if missing:
        raise RuntimeError(f'Written evidence is missing: {missing}')
    proofs = run / 'proofs'
    proofs.mkdir(exist_ok=True)
    for name in names.values():
        shutil.copyfile(source / name, proofs / name)

    assumptions = [
        ('A1', 'One fixed-base-point path with 2^L paired angular law presentations and independent two-channel links; L is any prescribed finite integer at least three.'),
        ('A2', 'Fixed supplied positive microscopic weights, common unit angular mobility, matched positive temperature and fixed physical Gaussian channel covariance; no scheduled rate or graph change.'),
        ('A3', 'Complete compact Borel retentions, all face identifications, separate generative and optimizer conditionals, exact marked parent integrals and inherited metrics.'),
        ('A4', 'The explicit ordered epsilon-then-amplitude preparation, finite horizon, finite coherence tolerance and an open neighborhood of smooth positive initial densities.'),
    ]
    assumptions = [{'id': key, 'kind': 'MODELING_POSTULATE', 'statement': value} for key, value in assumptions]
    evidence = [{'id': 'proof-' + key, 'kind': 'DERIVATION', 'supports': True,
                 'scope': 'Written analytical proof in ' + name,
                 'side_conditions': [item['statement'] for item in assumptions],
                 'artifact_path': 'proofs/' + name, 'artifact_sha256': digest(proofs / name)}
                for key, name in names.items()]
    ledger = json.loads((run / 'claim-ledger.json').read_text(encoding='utf-8'))
    evidence_map = {
        'target': ['joined', 'independent'],
        'typed-parent-class': ['parent', 'geometry', 'independent'],
        'finite-depth-admissibility': ['gaussian', 'nonlinear', 'nonlinear-check', 'independent'],
        'actual-coalescence': ['gaussian', 'joined', 'independent'],
        'conditional-entropy': ['gaussian', 'nonlinear', 'nonlinear-check', 'joined', 'independent'],
        'dynamical-error': ['gaussian', 'nonlinear', 'nonlinear-check', 'independent'],
        'joined-regime': ['joined', 'nonlinear-check', 'independent'],
    }
    for claim in ledger['claims']:
        claim.update(state='EVIDENCE_VERIFIED', assumption_ids=[a['id'] for a in assumptions],
                     evidence_ids=['proof-' + key for key in evidence_map[claim['id']]], bridge_premise_ids=[])
    put_json('claim-ledger.json', {'assumptions': assumptions, 'evidence': evidence, 'claims': ledger['claims']})
    components = [claim['id'] for claim in ledger['claims'] if claim['id'] != 'target']
    put_json('dependency-dag.json', {'edges': [{'from': 'target', 'to': key} for key in components]})

    portfolio = [
        ('exact-compact-flag', 'Primitive compact kernel flags and complete Borel disintegration',
         'Integer residual coordinates and restricted Euclidean metrics',
         'Fractional orthogonal projection can lose finite compact information',
         'Explicit inverses, primitive kernels, Haar fibers and every face carry prove integration closure.',
         ['typed-parent-class'], [], 'completed'),
        ('coercive-gaussian-reference', 'Common-kinetics weighted restoring flag and exact Schur reference',
         'Stationary-covariance Gaussian laws, conditional mean energy and constrained Stieltjes residual dynamics',
         'An exact Schur parent need not have a cooperative residual drift',
         'Bound its difference from the cooperative constrained process; derive all finite-L margins and errors.',
         ['actual-coalescence', 'conditional-entropy', 'dynamical-error'], [], 'completed'),
        ('nonlinear-entropy-transfer', 'Ordered amplitude limit with full nonlinear compact parents retained',
         'Global fiber barrier, local quartic/cubic estimates, lifted path entropy and exact conditional-entropy identity',
         'Path convergence alone cannot bound conditional KL; compact folds cannot be omitted',
         'Separate initial winding, drift-energy, conditional reference and bad-chart terms all vanish with positive powers or exponential tails.',
         ['finite-depth-admissibility', 'conditional-entropy', 'dynamical-error', 'joined-regime'], [], 'completed'),
        ('direct-total-entropy-budget', 'Charge the original fine entropy at every deeper conditional interface',
         'A global initial entropy bound dominated by the strongest interaction',
         'The crude budget scales with J1 and loses the weaker-level estimate',
         'Retired as a sufficient proof route; exact conditional mean energies avoid that charge.',
         [], ['This failed bound does not imply nonexistence.'], 'retired'),
        ('late-global-relaxation-only', 'Wait for global equilibrium before all reductions',
         'Compact spectral or entropy relaxation',
         'It cannot by itself certify distinct intermediate formation intervals',
         'Retained only as a conservative positive global-gap bound, not as the formation proof.',
         [], ['Early-stage conditional costs require the separate reference argument.'], 'retired'),
    ]
    put_json('approach-registry.json', {'mechanism_families': [
        {'family_id': key, 'core_mechanism': mechanism, 'target_obligation_ids': verified or ['target'],
         'representation': representation, 'invariant_or_obstruction': obstruction,
         'obligations': ['Prove the stated interface under the unchanged finite contract.'],
         'bridge': bridge, 'failure_test': obstruction, 'verified_results': verified,
         'open_gaps': gaps, 'novelty_fingerprint': representation, 'disposition': disposition}
        for key, mechanism, representation, obstruction, bridge, verified, gaps, disposition in portfolio]})

    attacks = [
        ('geometry-faces', ['target', 'typed-parent-class'],
         'A fractional orthogonal map may silently discard compact sheets or miss Haar factors.',
         'The primitive-kernel proof, explicit Borel inverse and recursive face carries preserve the complete configuration.', 'geometry'),
        ('force-projection', ['typed-parent-class', 'dynamical-error'],
         'Averaging the full preceding force is invalid when opposite fiber faces attach at different retained points.',
         'The explicit counterexample is retained; the current proof uses the projected conditional force and verifies the corrected identity.', 'geometry'),
        ('parent-cooperativity', ['actual-coalescence', 'finite-depth-admissibility'],
         'Schur integration need not preserve a cooperative residual vector field, so deeper mergers may be assumed.',
         'The exact Schur flow is compared quantitatively with a separately proved Stieltjes constrained flow; weighted flag bounds hold at every finite level.', 'gaussian'),
        ('quadratic-substitution', ['target', 'finite-depth-admissibility', 'joined-regime'],
         'A Gaussian reference could replace the actual nonlinear parent or assume recursive admissibility.',
         'Cumulative compact integrals retain the full nonlinear law and have explicit force and Hessian remainders tending to zero after the finite weight choice.', 'nonlinear-check'),
        ('path-is-not-kl', ['conditional-entropy', 'dynamical-error'],
         'Path proximity or total variation by itself does not prove dimensionless conditional entropy.',
         'A path relative-entropy bound, the exact conditional identity, central affine Gaussian log ratios and independent tail bounds prove the displayed KL estimate.', 'nonlinear-check'),
        ('winding-and-initialization', ['conditional-entropy', 'dynamical-error', 'typed-parent-class'],
         'Compact initialization or nonprincipal Borel branches could contribute an uncontrolled entropy term.',
         'Initial entropy continuity, conditional winding lifts, Haar-preserving bad-submeasure bounds and fixed boundary distances bound all discrepancies.', 'nonlinear-check'),
        ('physical-agreement', ['actual-coalescence', 'target'],
         'A scalar residual could be mislabeled as KL between full marked parent mixtures.',
         'The joined proof defines the inherited expected original edge KL and separately bounds its conditional hidden second moments under both physical and optimizing kernels.', 'joined'),
        ('nonempty-open-regime', ['target', 'joined-regime', 'finite-depth-admissibility'],
         'Several separate asymptotic estimates might have no common finite positive parameter regime or no open initial-law family.',
         'Choose epsilon first, then A; every remaining inequality has a positive power or exponentially decaying remainder. Relative-uniform density perturbations preserve strict margins.', 'independent'),
        ('sequential-restarts', ['target', 'actual-coalescence', 'conditional-entropy', 'dynamical-error'],
         'Independently initialized parents might not justify activating successive parents from the actual retained law at their reduction times.',
         'Deterministic projections preserve the Gaussian stationary covariance, elapsed-time conditional estimates hold after each activation, and exact Borel data processing plus strong exit control propagates nonlinear entropy and paths across every restart.', 'independent'),
    ]
    attack_records = [{'id': key, 'claim_ids': ids, 'attack': attack, 'disposition': 'REJECTED',
                       'response': response, 'artifact_path': 'proofs/' + names[artifact],
                       'artifact_sha256': digest(proofs / names[artifact])}
                      for key, ids, attack, response, artifact in attacks]
    all_claims = ['target'] + components
    independent = {'claim_ids': all_claims, 'method': 'Independent reconstruction of the complete finite target and its dependencies from the frozen contract.',
                   'result': 'PASS', 'conclusion': 'The written derivations establish each recorded finite-scope claim under its explicit inputs and errors.',
                   'artifact_path': 'proofs/' + names['independent'], 'artifact_sha256': digest(proofs / names['independent'])}
    erasure = independent | {'method': 'Erase the affirmative prior and inspect every premise and dependency for direct or paraphrased use.',
                             'conclusion': 'The construction uses supplied microscopic inputs and derived inequalities, with no assumed hierarchy or recursive admissibility.'}
    put_json('adversarial-report.json', {'attacks': attack_records, 'independent_reconstruction': independent, 'oracle_erasure': erasure})
    limitations = [
        'Each finite L has its own parameter neighborhood and constants; no uniform infinite-depth statement.',
        'Fixed dyadic path weights, angular group, law covariances and common kinetic metric are supplied microscopic inputs, not learned structure.',
        'Actual nonlinear parent laws and conditional identities are exact; dynamical reduction is finite-horizon and probabilistic with explicit compact corrections.',
        'Parent agreement is an inherited expected edge-KL statistic; no equality with KL between full correlated parent mixtures is asserted.',
        'No general gauge group, loop sector, physical-clock identity, base transport or numerical simulation claim.',
    ]
    strongest = 'For every prescribed finite L>=3, one open positive-temperature compact nonlinear family has L successive coalescence levels, exact normalized marked parents, inherited dynamics and controlled conditional VFE and path errors; L=3 gives 8 -> 4 -> 2 -> 1.'
    put_json('release.json', {'checkpoint': 'finite-depth nonlinear construction', 'target_claim': 'target',
                            'terminal_status': 'COMPLETE_AFFIRMATIVE', 'certificate_claim': 'target',
                            'strongest_result': strongest, 'unresolved_obligations': [], 'limitations': limitations})
    put_md('counterexample-register.md', '# Counterexamples and retired routes\n\nThe original unprojected force sentence was false; the gauge-invariant counterexample and corrected projected identity are retained in proofs/finite-depth-geometry-reconstruction.md. Exact Schur parent cooperativity was not assumed after its obstruction was identified; the constrained comparison supplies the replacement proof. A direct repeated global entropy budget and late-equilibrium-only argument did not prove the required intermediate intervals and were retired. None is a nonexistence theorem for the frozen target. Compact mixture KL was never substituted for the inherited expected physical statistic in the final result.\n')
    put_md('construction-or-strongest-theorem.md', '# Finite-depth construction\n\n' + strongest + '\n\nThe complete theorem and proof join are in proofs/finite-depth-completion.md. The exact-law, Gaussian-reference and nonlinear-comparison derivations and their independent reconstructions are retained alongside it. The ordered parameter choice, all constants and the scope restrictions belong to the theorem. Hashes identify the recorded text; they are not mathematical evidence.\n')
    put_md('final-report.md', '# Rigorous theory search report\n\n## Frozen contract\n\n' + contract['target']['quantifiers'] + '\n\n## Terminal status\n\nCOMPLETE_AFFIRMATIVE for the finite target.\n\n## Certificate\n\nTarget claim `target`, under modeling postulates A1-A4, is established by the seven written proof artifacts listed in claim-ledger.json. The target depends on all six component claims in dependency-dag.json.\n\n## Strongest verified result\n\n' + strongest + '\n\n## Dependency closure\n\nExact geometry and laws, recursive quantitative admissibility, actual formation, conditional entropy, dynamical errors and one common open regime each have a recorded analytical derivation. The independent reconstruction checks their join.\n\n## Independent reconstruction\n\nSee proofs/finite-depth-independent-reconstruction.md, supported by the separate geometry and nonlinear checks. Agreement is not evidence; the displayed proofs and repaired counterexamples are.\n\n## Oracle erasure\n\nThe independent reconstruction removes the favorable prior and checks every load-bearing premise. No assumed formation, parent admissibility or target truth remains in the argument. The structural validator cannot detect paraphrased prior use or establish mathematics.\n\n## Unresolved obligations\n\nNone within the frozen finite-depth target.\n\n## Scope and limitations\n\n' + ' '.join(limitations) + ' This is an analytical construction, with no new trajectory simulation, production-code change, full suite, GPU run, Lean proof, tamper check, vault ingest or Git publication.\n')
    print(json.dumps({'proof_snapshots': len(names), 'claims': len(ledger['claims']), 'attacks': len(attacks), 'target_digest': binding['target_digest']}))


if __name__ == '__main__':
    main()
