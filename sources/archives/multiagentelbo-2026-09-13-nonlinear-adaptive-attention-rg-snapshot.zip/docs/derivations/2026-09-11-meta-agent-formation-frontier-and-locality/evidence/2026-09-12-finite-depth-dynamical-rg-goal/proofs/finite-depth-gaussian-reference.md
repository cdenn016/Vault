# Exact finite-depth Gaussian reference

September 12, 2026. Independent mathematical reference for [the finite-depth contract](evidence/2026-09-12-finite-depth-dynamical-rg-goal/problem-contract.json), digest `d15c9f5a5a810b76900ea496929ff4a5c6832d4553a379d5da43ce2f1f7e3bd9`. This document proves the Gaussian reference estimates requested by the parent. It does not prove the nonlinear compact target. Transferring these statements to the exact nonlinear laws, their actual dynamics, and their Borel branch conventions requires the separate nonlinear comparison.

The model matrices and flag are those of [the compact parent class](finite-depth-parent-class.md). The source [translation-link bridge](translation-link-conditional-bridge.md), Sections 2–6, already distinguishes exact Gaussian marginalization from finite-time dynamical approximation and supplies a two-level conditional-defect calculation. The [nonlinear two-stage construction](nonlinear-two-stage-completion.md) supplies the preceding compact example and its chart qualifications. The previously consulted live PIFB2 equations `rg_internal_hessian`, `rg_reduced_hessian`, `rg_slow_graph_metric`, and `rg_schur_flow` distinguish stiffness, generated interactions, inherited metric, and force error. The present calculation extends the Gaussian reference to every prescribed finite depth without assuming that later Schur parents remain admissible.

## 1. Exact statement and introduced assumptions

Fix a finite integer `L>=3`, put `n=2^L`, and use the path and two-channel residual matrix `B` in the parent-class source. The microscopic angular dimension is `d=4n-2`; the residual dimension is `m=3n-2`. Edge `i=(i,i+1)` has level `ell(i)=1+v_2(i)`. Group the bridge residuals and level-one edge residuals into `B_1`; group the later edge residuals into `B_2,...,B_L`. Let `W_s=ker(B_1,...,B_s)` in the real tangent space, `P_s` its orthogonal projector, `G=ker B=W_L`, and `N=G^perp`.

The user-supplied constraint is the common unit microscopic metric and unchanged inherited metrics. This reference introduces a quadratic energy, stationary-covariance shifted Gaussian preparations, and the descending coefficients

\[
J_1\ge\cdots\ge J_L=1,\quad
D=\operatorname{diag}(J_j I_{m_j}),\quad H=B^TDB|_N>0.
\tag{G1}
\]

The reference carrier is the product of the Euclidean normal space `N` and the root torus with normalized Haar measure and the restricted root metric. It is not the original microscopic torus: mapping an unbounded Gaussian normal variable into that torus introduces covering and branch issues that this reference does not remove. All statements below concern the product reference, at one base point.

Choose an amplitude `A>0`, set every initial bridge residual to zero and both channel residuals on every edge to `A`, and denote this residual vector by `r_0`. Put

\[
x_0=B^T(BB^T)^{-1}r_0\in N,\qquad
T=A^2/R^2,\qquad
X_0\sim N(x_0,TH^{-1})
\tag{G2}
\]

in the normal space, independently of the Haar root. The normal dynamics are `dX=-HX dt+sqrt(2T)dW_N`; the root evolves by its inherited Brownian motion. The mean is `mu(t)=exp(-Ht)x_0`, the normal covariance remains exactly `TH^-1`, and the root stays Haar. This preparation is positive and has finite entropy; its nonzero conditional means are not assumed equilibrated.

For every ancestral index `0<=a<L`, define `N_a=W_a cap N` and the exact marginal precision

\[
H^{(a)}=\left(P_aH^{-1}P_a|_{N_a}\right)^{-1},\qquad H^{(0)}=H.
\tag{G3}
\]

Its autonomous process starts at the actual projected reference law, with mean `P_a x_0`, covariance `T(H^(a))^-1`, and inherited unit metric on `N_a`. Its mean is `mu^(a)(t)=exp(-H^(a)t)P_a x_0`. These processes are distinct from the actual fine projections. Their covariance agreement at each fixed time does not imply agreement of temporal correlations.

For each fixed `L` there are positive finite constants `c_L,C_L,kappa_L`, determined below by the fixed matrices, such that a nonempty regime has all of the following properties. Every ancestral process has actual coherence windows at every remaining level. Every cumulative conditional KL has the displayed quantitative bound, and hence every individual conditional cost is bounded. Every actual ancestral projection has a finite-horizon coupled-path comparison to its exact autonomous marginal. No estimate loses a factor `1/A` after normalization by the formation amplitude.

## 2. Uniform matrix bounds through every Schur parent

Choose once and for all orthonormal matrices `Q_j` spanning `W_{j-1} cap W_j^perp`. Their concatenation `O=[Q_1 ... Q_L]` is an orthonormal basis of `N`. The matrix

\[
\mathsf T=BO
\]

is block lower triangular with invertible diagonal blocks. The lower-triangular property follows because `B_j` annihilates `W_j`, which contains every later `Q_i`. Its diagonal rank follows from the full row rank of each restricted residual map. Consequently `mathsf T^-1` is also block lower triangular.

Let `mathsf J=diag(J_j I_mj)`. A block in position `(j,i)` of `mathsf J^1/2 mathsf T mathsf J^-1/2` is multiplied by `sqrt(J_j/J_i)<=1` whenever it can be nonzero. The identical statement holds for `mathsf T^-1`. Thus, with explicit finite choices

\[
c_L=\|\mathsf T^{-1}\|_F^{-2},\qquad C_L^{(0)}=\|\mathsf T\|_F^2,
\]

one has, in flag coordinates `v=O^T x`,

\[
c_L\sum_jJ_j|v_j|^2\le x^THx
\le C_L^{(0)}\sum_jJ_j|v_j|^2.
\tag{G4}
\]

Constants denoted by `C_L` below may increase by finite products and sums of these constants, `||B||`, `||B^T(BB^T)^-1||`, and dimensions. They depend on `L`, but not on `A,R,T` or the ordered coefficients. This provides a computable dependence on finite depth, rather than an asserted uniform infinite-depth constant.

For `y in N_a`, Gaussian completion of the square gives

\[
y^TH^{(a)}y=\min_{u\in W_a^\perp} (u+y)^TH(u+y).
\tag{G5}
\]

Minimizing the lower bound in (G4), and using `u=0` for its upper bound, proves the same two-sided weighted inequality on the blocks `j>a`. Repeating the minimization in any order proves that a further Schur complement from `a` to `s` is exactly `H^(s)`. This also proves associativity of the Gaussian marginalizations; it is not an extra closure assumption.

For `a<s<=L`, split `N_a=F_{a,s} direct-sum N_s`, where `F_{a,s}=W_a cap W_s^perp`, and write

\[
H^{(a)}=\begin{pmatrix}F&G_{a,s}\\G_{a,s}^T&V\end{pmatrix},
\qquad K_s=V-G_{a,s}^TF^{-1}G_{a,s}=H^{(s)}.
\tag{G6}
\]

Set `J_{L+1}=0`; when `s=L`, the retained normal space is zero and the corresponding cross blocks vanish. The bounds required later are

\[
F\succeq c_LJ_sI,\quad \|F\|\le C_LJ_{a+1},\quad
\|G_{a,s}\|\le C_LJ_{s+1},\quad
0\prec K_s\preceq C_LJ_{s+1}I\quad(s<L).
\tag{G7}
\]

The first two follow from (G4)–(G5). Here is a check that the cross bound survives previous elimination. Split the original matrix into already eliminated space `E=W_a^perp`, current space `F_{a,s}`, and future space `N_s`. Every row of level at most `s` annihilates the future space. Thus the original current-future and eliminated-future blocks have norms at most `||B||^2 J_{s+1}`. Every row of level at most `a` annihilates the current space, so the eliminated-current block has norm at most `||B||^2 J_{a+1}`. Also `H_EE>=c_L J_a I` for `a>0`. The Schur correction to the cross block is therefore at most

\[
\frac{\|B\|^4}{c_L}\frac{J_{a+1}}{J_a}J_{s+1}\le C_LJ_{s+1}.
\]

For `a=0` no correction occurs. The final bound in (G7) follows by using zero eliminated variable in the variational formula: `K_s<=V<=C_L J_{s+1}I`. This calculation checks the later-parent hypothesis directly.

The normal mean of every ancestor satisfies

\[
|\mu^{(a)}(t)|\le|P_ax_0|\le C_LA,
\tag{G8}
\]

because each matrix exponential is a contraction and `|r_0|=sqrt(2(n-1))A`. In particular there is no growth of its mean bound with `J_1`.

## 3. Exact laws, conditional entropy, and its propagation

Gaussian integration on the orthogonal normal spaces gives exact parent laws `pi_a=N(0,T(H^(a))^-1)`, times Haar on the retained root. Their Lebesgue normalizing integral is `(2pi T)^(dim N_a/2)/sqrt(det H^(a))`; the eliminated determinants are retained constants in a normalized marginal. For the split (G6), the optimizing conditional is

\[
\pi_a(du|y)=N(-F^{-1}G_{a,s}y,TF^{-1}).
\tag{G9}
\]

The shifted recognition has the same covariance, so its conditional covariance is also exactly `TF^-1`, and its conditional mean differs from (G9) by the constant

\[
e(t)=\mu_u^{(a)}(t)+F^{-1}G_{a,s}\mu_y^{(a)}(t).
\]

Thus its cumulative conditional loss is exactly

\[
\Delta_{a\to s}^{G}(t)=\frac{e(t)^TF e(t)}{2T}.
\tag{G10}
\]

This identity concerns either the fine reference (`a=0`) or a separately evolved autonomous ancestor. It is not obtained by transferring entropy through a path-distance estimate.

The exact mean equations imply

\[
\dot\mu_y=-K_s\mu_y-G_{a,s}^Te,\quad
\dot e=-(F+F^{-1}G_{a,s}G_{a,s}^T)e-F^{-1}G_{a,s}K_s\mu_y.
\tag{G11}
\]

Put `r=|F^1/2 e|`. Multiplying the second equation by `e^T F` yields the exact identity

\[
\tfrac12(r^2)'=-e^TF^2e-|G_{a,s}^Te|^2-e^TG_{a,s}K_s\mu_y.
\]

Equations (G7)–(G8) therefore give, including the upper right derivative at `r=0`,

\[
D^+r\le-c_LJ_s r+C_LA\frac{J_{s+1}^2}{\sqrt{J_s}},\quad
r(0)\le C_LA\sqrt{J_{a+1}}.
\]

Integrating and squaring proves the stronger bound

\[
\Delta_{a\to s}^{G}(t)\le C_LR^2\left[
J_{a+1}e^{-c_LJ_st}+\frac{J_{s+1}^4}{J_s^3}\right].
\tag{G12}
\]

The constant and the positive decay constant can be decreased or increased once to absorb the factor two from squaring. In particular, because `J_{s+1}<=J_s` and `J_{a+1}<=J_1`,

\[
\boxed{\Delta_{a\to s}^{G}(t)\le C_LR^2\left[
J_1e^{-c_LJ_st}+\frac{J_{s+1}^2}{J_s}\right].}
\tag{G13}
\]

This verifies the proposed common bound with the required index convention. At the final stage, its plateau is exactly zero. The conditional chain rule gives
`Delta_a->s=sum_{j=a+1}^s Delta_j` for the actual marginals of that same ancestor law. Every individual cost is nonnegative and bounded by the appropriate cumulative cost (G12) or (G13). The scaled eliminated VFE is exactly `T` times this sum for the Gaussian conditional objective.

A useful law-stability version is also exact. For any law `Q` with `D(Q||Q_t^G)<=zeta^2`, its conditional KL to (G9) obeys

\[
\Delta_{a\to s}(Q)\le
\left(\zeta+\sqrt{\Delta_{a\to s}^{G}(t)}\right)^2.
\tag{G14}
\]

To prove it, disintegrate the KL to `Q_t^G`; the averaged conditional part is at most `zeta^2`. The log ratio between its Gaussian conditional and (G9) is affine, with linear coefficient `F e/T`. The Gaussian exponential-tilt inequality bounds its centered expectation by `sqrt(2J e^TFe/T)`, where `J` is that conditional KL. Adding its reference expectation `e^TFe/(2T)` and using Cauchy–Schwarz gives (G14). This is a direct entropy calculation, not a conclusion from total variation. For the same OU evolution, initial KL to the reference contracts by Jensen's inequality for the Markov kernel, so (G14) applies to an initial relative-entropy neighborhood as well.

The same Gaussian variational inequality controls the actual averaged force correction for any finite-entropy law, without requiring the linear force to be bounded. Pointwise in the retained coordinate it gives
`|F^1/2(E[u|y]+F^-1G_a,s y)|^2<=2T D(Q(du|y)||pi_a(du|y))`. Therefore

\[
\|G_{a,s}^T(E[u|y]+F^{-1}G_{a,s}y)\|_{L^2(Q_y)}
\le\sqrt{2T}\|G_{a,s}^TF^{-1/2}\|\sqrt{\Delta_{a\to s}(Q)}
\le C_LJ_{s+1}\sqrt{T/J_s}\sqrt{\Delta_{a\to s}(Q)}.
\tag{G14a}
\]

Together with the exact conditional VFE factor `T`, this supplies the reference force and scalar-objective error, separately from its path comparison.

## 4. Coherence of the fine mean and every autonomous ancestor

First, for any ancestor and further split, its current mean solves `dot mu_u=-F mu_u-G_{a,s}mu_y`. Variation of constants, (G7), and (G8) give

\[
|\mu_u^{(a)}(t)|\le C_LA
\left[e^{-c_LJ_st}+\frac{J_{s+1}}{J_s}\right].
\tag{G15}
\]

Every residual of level at most `s` annihilates `N_s`. Hence all active past residual means of that ancestor are bounded by the right side of (G15), after another fixed matrix factor. Earlier eliminated residuals are exactly zero on its retained state. This proves persistence of their smallness for all `t>=t_s`; an eigenvalue count alone would not prove it.

Future residuals require a separate argument. The channel swap is an orthogonal symmetry of `H`, of all flag projectors, and of `x_0`. Thus all reference means remain on the symmetric-channel slice, with zero bridge means. In one channel let `D_path` be the oriented path incidence matrix. Its residual row Gram is

\[
\mathcal C=I+D_{\rm path}D_{\rm path}^T
=\operatorname{tridiag}(3,-1,-1).
\tag{G16}
\]

The fine residual equation is `dot r=-mathcal C D_edge r`. Its off-diagonal generator entries are nonnegative. The exponential preserves the positive cone: add a sufficiently large scalar multiple of the identity to make every entry nonnegative and use the exponential series. Consequently, with `r_i(0)=A`,

\[
r_i(t)\ge A e^{-3J_{\ell(i)}t}.
\tag{G17}
\]

The exact Schur parent does not generally have this cooperative residual generator. Treating its potential as a diagonal residual energy would be incorrect. The following comparison supplies the missing step.

For ancestor `a>=1`, partition the one-channel edges into eliminated `E={ell<=a}` and retained `R={ell>a}`. Orthogonal projection gives the retained residual

\[
s=r_R-Mr_E,\qquad M=\mathcal C_{RE}\mathcal C_{EE}^{-1},
\]

with inherited residual mobility

\[
S_a=\mathcal C_{RR}-\mathcal C_{RE}\mathcal C_{EE}^{-1}\mathcal C_{ER}.
\tag{G18}
\]

Every principal `mathcal C_EE` is `3I` minus the adjacency matrix of a union of paths. Its inverse is the nonnegative convergent series `(1/3)sum_k(Adj/3)^k`. Therefore `M<=0` entrywise, and

\[
s(0)=A(\mathbf1-M\mathbf1)\ge A\mathbf1.
\tag{G19}
\]

The matrix `S_a` is positive definite with nonpositive off-diagonal entries, `1<=lambda_min(S_a)<=lambda_max(S_a)<=5`, and diagonal entries at most three. The eigenvalue bounds follow from `I<=mathcal C<=5I` and its variational Schur formula; the entry signs follow directly from (G18). In particular the constrained flow

\[
\dot s^c=-S_aD_Rs^c,\qquad s^c(0)=s(0),
\tag{G20}
\]

is cooperative and satisfies `s_i^c(t)>=A exp(-3J_i t)`.

The exact Gaussian marginal potential, in these same retained residuals, has precision

\[
Q_a=\left(D_R^{-1}+MD_E^{-1}M^T\right)^{-1}.
\tag{G21}
\]

This follows because the microscopic equilibrium residuals have independent covariances `T D_edge^-1`; applying the linear map `s=r_R-Mr_E` gives (G21). In the symmetric two-channel subspace an overall factor two in energy and metric cancels from its mean equation. The antisymmetric subspace and bridges decouple by channel-swap symmetry, so their Gaussian integration does not change this symmetric mean equation. Thus the exact autonomous ancestor obeys `dot s^G=-S_a Q_a s^G` on that slice.

Resolvent multiplication proves

\[
0\preceq D_R-Q_a\preceq D_RMD_E^{-1}M^TD_R,
\quad \|Q_a-D_R\|\le C_LJ_{a+1}^2/J_a.
\tag{G22}
\]

For the first inequality conjugate by `D_R^-1/2` and use `0<=(I+K)^-1<=I` and `I-(I+K)^-1<=K` for the positive semidefinite matrix `K=D_R^1/2MD_E^-1M^TD_R^1/2`; these inequalities follow by diagonalizing that symmetric matrix. The norm bound uses `D_E>=J_a I`, `||D_R||<=J_{a+1}`, and `||M||<=5`.

The error `e_s=s^G-s^c` obeys
`dot e_s=-S_aD_R e_s-S_a(Q_a-D_R)s^G`. The first term contracts in the `S_a^-1` norm at rate at least one, while (G8) bounds `|s^G|<=C_LA`. Hence

\[
|s^G(t)-s^c(t)|\le
C_L A\min\{t,1\}\frac{J_{a+1}^2}{J_a}.
\tag{G23}
\]

This is stronger than the corresponding `C_L A H J_{a+1}^2/J_a` bound over a horizon `H`. Combining it with (G20) proves the future-residual lower bound for the exact parent, without assuming cooperativity of its Schur drift.

Every proper ancestor has a nonzero generated quadratic correction: the dyadic eliminated set has a neighbor of each retained edge, so `M` is nonzero and `D_R-Q_a` is nonzero. If `a<=L-2`, the retained edges form a chain with at least three members. Each eliminated path segment between two consecutive retained edges gives a strictly positive nearest-neighbor entry of `MD_E^-1M^T`; no column connects nonconsecutive retained edges. Its sum with `D_R^-1` is consequently positive definite tridiagonal with strictly positive nearest-neighbor entries. Conjugating it by `diag((-1)^i)` gives an irreducible matrix with negative nearest-neighbor entries; its inverse has strictly positive entries by the convergent nonnegative-series argument after diagonal normalization. Therefore `Q_a` has nonzero alternating-sign off-diagonal entries. At `a=L-1` only one symmetric retained edge remains: (G22) proves a nonzero stiffness correction, not a cross term in that one-dimensional sector. The final root potential is constant.

## 5. Stationary noise preserves the finite collection of episodes

The centered fluctuation `Z_a=X_a-mu^(a)` of every ancestor is a stationary OU process with covariance `T(H^(a))^-1`. Equation (G4) implies `H^(a)>=c_L I`, since `J_L=1`. Let `c` be a fixed positive lower bound no larger than this `c_L`, and define

\[
V(z)=e^{c|z|^2/(4T)}.
\]

Ito's formula in dimension `d_a=dim N_a` gives

\[
LV\le c(d_a/2-u)e^u\le C_L,
\qquad u=c|z|^2/(4T).
\]

The stationary initial expectation is at most `2^(d_a/2)`, because its covariance is at most `T c^-1 I`. Stopping at radius `rho A` therefore gives

\[
\Pr\left(\sup_{0\le t\le H}|Z_a(t)|\ge\rho A\right)
\le C_L(1+H)e^{-c_L\rho^2R^2}.
\tag{G24}
\]

The argument uses a bounded stopped integrand and finite horizon, and the initial Gaussian exponential moment was explicitly checked. No largest eigenvalue or `J_1 H` factor enters this bound. Choose `rho` so that `||B||rho A<=eta/4`, where

\[
\eta=A/(100n).
\tag{G25}
\]

Then all raw active residual fluctuations are at most `eta/4` on this event. A union bound over the finite family of ancestors controls their episodes simultaneously; independence of these events is unnecessary. Gaussian states do not have exact coherent support at positive temperature.

## 6. A coupled-path bound with no inverse-amplitude loss

Fix any `a<s`. Construct all ancestor processes from a common initial fine Gaussian and the same orthogonally projected Brownian motion. Their initial laws are the required exact marginals, and their future noises are independent of the common initial state. Compare the actual projection of ancestor `a` onto `N_s` with the autonomous ancestor `s`.

For the split (G6), let the random conditional defect be `E=u+F^-1G_a,s y`. The actual projected equation and the autonomous equation have the same noise and satisfy

\[
dy=-K_sy dt-G_{a,s}^TE dt+\sqrt{2T}dW_s,
\qquad d\bar y=-K_s\bar y dt+\sqrt{2T}dW_s.
\]

The Brownian covariance is the inherited Euclidean covariance on `N_s`. The difference starts at zero and therefore

\[
|y_t-\bar y_t|\le\|G_{a,s}\|\int_0^t|E_v|dv.
\tag{G26}
\]

For its mean, (G15) and `||F^-1G_a,s||<=C_LJ_{s+1}/J_s` give

\[
|E E_t|\le C_LA[e^{-c_LJ_st}+J_{s+1}/J_s].
\tag{G27}
\]

The centered process `E_t^0` is stationary Gaussian. The block inverse of (G6) gives exactly

\[
\operatorname{Cov}(E_t^0)=TF^{-1}\preceq C_LTJ_s^{-1}I.
\tag{G28}
\]

It is not being asserted that this process is a frozen conditional OU process. For the stationary full ancestor fluctuation and `mathcal A=(I,F^-1G_a,s)`, its increment covariance is

\[
\operatorname{Cov}(E_t^0-E_v^0)
=2T\mathcal A(H^{(a)})^{-1}(I-e^{-H^{(a)}|t-v|})\mathcal A^T
\preceq C_LT|t-v|I.
\tag{G29}
\]

The last inequality follows by diagonalizing the positive matrix and using `(1-e^-lambda h)/lambda<=h`; the norm of `mathcal A` is bounded by a constant depending only on `L`.

For completeness, (G28)–(G29) imply the following elementary continuous-time maximum bound, for `0<delta<1`:

\[
\Pr\left(\sup_{t\le H}|E_t^0|>
C_L\sqrt{\frac{T}{J_s}}
\sqrt{\log\frac{C_L(1+HJ_s)}{\delta}}\right)\le\delta.
\tag{G30}
\]

One proof uses a grid of mesh at most `1/J_s`, then its successive dyadic refinements. The initial grid has at most `2+HJ_s` points, each with coordinate variance at most `C_LT/J_s`. At refinement `q`, there are at most `C(1+HJ_s)2^q` increments of variance at most `C_LT 2^-q/J_s`. Apply the Gaussian tail bound to every coordinate, allocate failure probability `delta 2^(-q-1)` to this refinement, and use increment thresholds proportional to
`sqrt(T/J_s) 2^(-q/2) sqrt(log(C_L(1+HJ_s)/delta)+C_L(q+1))`.
Their sum is bounded by the right-side threshold in (G30), because both `sum 2^(-q/2)` and `sum sqrt(q+1)2^(-q/2)` converge. Continuity of the OU process passes from the nested grids to the entire interval. This proves the bound without an unexamined supremum-over-time substitution of a one-time covariance.

Integrating (G27), and using (G30) in (G26), proves, outside an event of probability `delta`,

\[
\boxed{\frac1A\sup_{t\le H}|P_sX_a(t)-X_s(t)|
\le C_L\left[
\frac{J_{s+1}}{J_s}+H\frac{J_{s+1}^2}{J_s}
+\frac{HJ_{s+1}}{R\sqrt{J_s}}
\sqrt{\log\frac{C_L(1+HJ_s)}{\delta}}
\right].}
\tag{G31}
\]

This verifies the proposed form. The estimate concerns full retained normal paths, not only their edge residuals. The retained root Brownian motions can be coupled identically and add no error. For `s=L`, the retained normal space is empty and this product-reference root projection is exact. No such global conclusion is automatically transferred to the compact Borel root.

There are finitely many ordered pairs `(a,s)`. Choosing their failure tolerances with total at most `delta_tot` gives a simultaneous family of path comparisons. Chaining successive errors yields their finite sum; every factor in that sum is already controlled by (G31). No new parent speed is introduced and no covariance equality is interpreted as equality of path laws.

## 7. Explicit nonempty regime and all formation windows

Take `0<epsilon<1`, and define

\[
a_L=0,\quad a_s=2a_{s+1}+6
=6(2^{L-s}-1),\quad
J_s=\epsilon^{-a_s},\quad R=\epsilon^{-1}.
\tag{G32}
\]

Then, for `s<L`,

\[
J_{s+1}^2/J_s=\epsilon^6,\quad
J_{s+1}/J_s=\epsilon^{a_{s+1}+6},\quad
J_{s+1}/(R\sqrt{J_s})=\epsilon^4.
\tag{G33}
\]

Choose `kappa_L>(a_1+6)/c_L` using the final decay constant in (G13), and set

\[
t_s=\kappa_L\log(1/\epsilon)/J_s,\qquad
H=2t_L,\qquad I_s=[t_s,2t_s].
\tag{G34}
\]

For sufficiently small `epsilon`, these are ordered nonoverlapping nondegenerate intervals, since `t_s/t_{s+1}=J_{s+1}/J_s` tends to zero. The final interval is exactly `[t_L,H]`. No time-dependent coefficient or merger schedule appears in the dynamics; these intervals report properties of the fixed system.

Equations (G13), (G32), and the choice of `kappa_L` give, for every ancestor `a<s`,

\[
\sup_{t\ge t_s}\Delta_{a\to s}^{G}(t)\le C_L\epsilon^4.
\tag{G35}
\]

The stronger (G12) also holds. Every individual elimination cost is therefore small at its corresponding level for the actual fine marginals and separately evolved ancestors. The bounds remain valid after the listed interval.

Equation (G15) makes every active residual with level at most `s` smaller than `eta/2` throughout `I_s`, after decreasing `epsilon`. For every future edge `ell>s` and `t in I_s`,

\[
3J_{\ell}t\le6\kappa_L\log(1/\epsilon)J_{s+1}/J_s\longrightarrow0.
\]

The constrained lower bound is consequently at least `3A/4` for sufficiently small `epsilon`. For an exact ancestor the correction (G23) is at most `C_LA epsilon^6`, so its future residual means remain at least `5A/8`, after another decrease. On the noise event (G24) their actual values exceed `A/2`, whereas their already formed residuals remain below `eta`. This establishes the distinct coalescence episodes for every remaining stage of every ancestor, with one common finite-parameter choice.

With `H=O_L(log(1/epsilon))`, the simultaneous formation failure probability is at most `C_L(1+H) exp(-c_L epsilon^-2)` after the fixed `eta/A` factors are absorbed into `c_L`. Taking `delta=epsilon^2` in each finite path comparison yields from (G31)

\[
\frac1A\sup_{t\le H}|P_sX_a(t)-X_s(t)|
\le O_L(\epsilon^6\log(1/\epsilon)
+\epsilon^4[\log(1/\epsilon)]^{3/2})=o_L(1)
\tag{G36}
\]

outside total probability `O_L(epsilon^2)`. These estimates are exactly homogeneous in amplitude: first select a sufficiently small finite `epsilon`, and then take any `A>0` with `T=A^2epsilon^2`. Decreasing `A` further does not change (G35), (G36), the normalized formation thresholds, or the reference exceptional probabilities. This supports an ordered nonlinear comparison in which amplitude is selected after the finite Gaussian hierarchy.

For `L=3`, `n=8`, the edge levels in order are `(1,2,1,3,1,2,1)`, and

\[
(J_1,J_2,J_3)=(\epsilon^{-18},\epsilon^{-6},1).
\]

During `I_1`, only edges `1,3,5,7` satisfy the small-residual criterion, giving four adjacent pairs. During `I_2`, the added edges `2,6` give two blocks of four. During `I_3`, edge `4` joins those blocks. Thus the actual counts are `8 -> 4 -> 2 -> 1`. In general `ell(i)<=s` exactly when `i` is not divisible by `2^s`; the components are the consecutive blocks of length `2^s`, so there are `n/2^s` of them. An ancestor at level `a` starts with these earlier blocks represented by its retained variables and undergoes each remaining merger under its own exact marginal potential.

At any fixed finite choice with strict margins, small changes of positive coefficients and initial means preserve the finite-horizon inequalities by the matrix-exponential integral formula and continuity of inverses on positive definite matrices. Common unit kinetics remain fixed. An initial smooth law in a sufficiently small uniform relative-density neighborhood of the reference is positive and has small initial KL. Markov data processing, (G14), and total variation of the common initialized path construction then preserve the entropy and probability conclusions with the stated additional errors. This supplies an open-law extension for the reference. It does not by itself prove an open-law theorem for a different nonlinear target or erase a compact branch discrepancy.

## 8. Result and the precise remaining obligation

The Gaussian reference obligation is proved. Every prescribed finite `L` admits the same concrete descending hierarchy, exact normalized Gaussian parent family and inherited geometry, separate actual-law conditional-KL estimates at all levels, actual `n -> n/2 -> ... -> 1` formation intervals under the fine and every ancestral autonomous process, and vanishing relative path errors. The potentially false shortcut was treating each Schur parent as a diagonal residual flow; (G21)–(G23) replace that shortcut with its exact generated precision and a controlled comparison.

No Gaussian calculation here closes the nonlinear compact contract. Its remaining obligation is an explicit transfer to the exact compact parent laws and nonlinear processes, including initial-law discrepancies, conditional-entropy target changes, generated operators, and the Borel face/covering event. The parent is separately constructing that transfer. There is no counterexample to the requested Gaussian bounds, and no Gaussian-reference defect requiring a change of the proposed coefficient exponents.

No numerical experiment, previous science rerun, suite, GPU job, Lean construction, tamper check, Git operation, or Research-vault edit was performed. The evidence is the displayed finite-dimensional algebra, Gaussian integration, entropy calculation, and explicit probability estimates. This lane edited only this reference document.
