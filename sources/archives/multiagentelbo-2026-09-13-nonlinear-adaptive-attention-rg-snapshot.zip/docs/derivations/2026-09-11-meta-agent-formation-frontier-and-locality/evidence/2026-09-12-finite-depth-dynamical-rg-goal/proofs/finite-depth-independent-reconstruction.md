# Independent complete reconstruction of the finite-depth theorem

September 12, 2026. The frozen finite-depth target reconstructs for the declared compact two-channel path family. The conclusion is an existence theorem for every prescribed finite depth, with exact normalized parent laws and explicit finite-horizon approximation of their dynamics. It is not exact Markov closure, an infinite-depth theorem, or a statement about arbitrary microscopic interactions. The proof below closes the mathematical join left outside the earlier geometry and nonlinear component reports. It does not assign a ledger closure state.

The previously sustained force-projection and Gaussian-normalizer wording defects are corrected in the inspected versions. Neither correction is silently reclassified as an originally correct statement. The present reconstruction uses the projected force and normalized Gaussian densities throughout.

## 1. Frozen statement, source versions, and claim coverage

The [contract](evidence/2026-09-12-finite-depth-dynamical-rg-goal/problem-contract.json) has digest `d15c9f5a5a810b76900ea496929ff4a5c6832d4553a379d5da43ce2f1f7e3bd9`. Its quantified target is: for each finite integer `L>=3`, construct a nonempty compact two-channel law/link family and an open positive-temperature parameter and smooth-positive initial-law regime admitting `L` actual successive coalescence levels under one common microscopic kinetic rule, including a three-level witness, with reusable exact normalized parents and quantitative conditional-VFE and dynamical error propagation. Constants may deteriorate with `L`; no uniform infinite-depth limit is required.

The inspected ledger contains `target` and six components: `typed-parent-class`, `finite-depth-admissibility`, `actual-coalescence`, `conditional-entropy`, `dynamical-error`, and `joined-regime`. Its DAG makes each component a direct dependency of `target`. The ledger was still in candidate form without evidence links when read. This report supplies a derivation for those entries; agreement among reports is not used as evidence.

The following hashes identify the text checked. They are diagnostic version bindings, not mathematical acceptance criteria.

| File, relative to this folder | SHA-256 |
| --- | --- |
| `finite-depth-parent-class.md` | `0463625bbd9ecff9dbb0bcfb1c60abbfd34ebce7fe6a159e83e6bb9a9912f60e` |
| `finite-depth-gaussian-reference.md` | `5f1f000b120a2aae1c567ae8f4e4e08732cdc5d61822b9e62e95c618a823fcdc` |
| `finite-depth-nonlinear-comparison.md` | `d810e90911b4fc84e4dc8b58f629a7cafdedbacd539ae400cf7edf79e10c4436` |
| `finite-depth-completion.md` | `274b4ea83aa10ed5f20e21a67373d28edf8edc9d899b8bd9b347897f12bb527b` |
| `finite-depth-geometry-reconstruction.md` | `a84e05ea61ae48e155b8ce0745e96f2c926aec896976989637d69db81e4f5338` |
| `finite-depth-nonlinear-reconstruction.md` | `c0d2453593fe6d63d197166899364a08fb01d8506e161b1e4038108db99bb65e` |
| `evidence/2026-09-12-finite-depth-dynamical-rg-goal/problem-contract.json` | `5ae6b7900c0df32b82e2054555b8dcd4594f2454413929b14ea4c4de6ae6a91a` |
| `evidence/2026-09-12-finite-depth-dynamical-rg-goal/claim-ledger.json` | `9427fe911b9ef2517473f6440665996665fe7c3e6a2a42bee464a5116f9e3d67` |
| `evidence/2026-09-12-finite-depth-dynamical-rg-goal/dependency-dag.json` | `98c4991aa74c211b97ba635e05f31d3783c988b3b7ad10cd18b0bf7b33fc2e86` |

Source continuity is the one already documented in the geometry reconstruction: `docs/STATUS.md`, Theory/03 and Theory/05b, the preceding nonlinear parent proof, and live PIFB2's graph-metric and reduced-force passages. The mathematical interfaces were reconstructed from the frozen assumptions before comparing the completed nonlinear reconstruction. Its detailed compact-density and stopped-path derivations are also checked below, rather than accepted from its concluding verdict.

The final source check directly read the joined document's completed-status introduction and the parent-class document's closing links to the completed comparison and join. Those final status and cross-reference edits replace the previously inspected hashes `96d70d355e8fa4bf8a72ecfaa50d97b04b911a9f9e5fd19a05515ff2748e3d6b` and `bdc188361cc3c71954c48ce6ff786ba1442e1bb4665bcedcd01328cbb458a0b5`, respectively. They do not change the mathematical formulas reconstructed here. All other source hashes in the table were reconfirmed unchanged, including the candidate ledger and dependency DAG.

## 2. Exact scope of the constructed theorem

Fix `L>=3`, put `n=2^L`, and let the entire finite system be the path on vertices `1,...,n`. There is no fluctuating exterior or omitted external force. The observation space is the declared singleton. The state is `X_0=T^{4n-2}`, with two angular node channels and two independent angular coordinates on every edge. Link independence here means independent configuration coordinates, not an assertion that the interacting probability law factorizes.

The user's assumptions are the fixed base point, paired law channels, independent links, normalized generative and recognition types, common kinetic prescription, and permission to introduce finite microscopic interactions and an initial preparation. The path, the angular group, the dyadic interaction pattern, Gaussian physical presentations, the unit microscopic metric, and the prepared initial density are the construction's declared choices. No assumption says that a merger occurs, that a parent is already equilibrated, or that later parents satisfy the required estimates.

Coalescence has the finite positive-temperature meaning specified in the join: with probability arbitrarily close to one, throughout each reported interval the designated earlier edges have both channel residuals below `eta=A/(100n)`, later edges remain at distance at least a fixed positive multiple of `A` from zero, and node bridge residuals remain below the same tolerance. The parent physical meaning is the conditional expectation of the original transported edge KL under its genuine downward prior; the optimizer has a distinct conditional expectation under its optimizing kernel. A KL between two full parent mixtures is not substituted for either statistic.

For every fixed `L` and sufficiently small requested error tolerance, the choices below give positive finite parameters, a finite horizon, and an open neighborhood in which all these conclusions hold. The error budgets include initial winding mismatch, compact-face events, conditional entropy, force and path errors. The exact laws retain the full marked physical presentation and every generated interaction.

## 3. Exact parent construction and inherited geometry

Let `D_path theta` be the vector `theta_i-theta_{i+1}`. The integer map

\[
x\longmapsto(\theta,d,r^b,r^m), 
d=\theta-\psi,  r^b=D_{\rm path}\theta-\alpha^b,
  r^m=D_{\rm path}\psi-\alpha^m
\tag{I1}
\]

has integer inverse `psi=theta-d`, `alpha^b=D_path theta-r^b`, and `alpha^m=D_path theta-D_path d-r^m`. Thus every selected residual assignment is attained and every residual kernel in the flag is connected. The kernels do not acquire an unrecorded finite sheet from a real-rank argument.

For the flag `M_s=ker(B_1,...,B_s)`, the real projections and normal right inverses are

\[
C_s=B_sP_{s-1}B_s^T, 
R_s=P_{s-1}B_s^TC_s^{-1}, 
P_s=P_{s-1}-R_sB_sP_{s-1}.
\tag{I2}
\]

The minimum-norm construction gives `B_sR_s=I`, mutually orthogonal ranges of the `R_s`, and `R_s^TR_s=C_s^{-1}`. The explicit full residual right inverse obtained by setting `theta=0` in (I1) has norm at most `3`, and `||B||<=sqrt(10)`. Restricting that inverse to each residual block proves

\[
I/9\preceq C_s\preceq10I.
\tag{I3}
\]

Principal residuals `z_s=pr(B_sy_{s-1})` and `y_s=y_{s-1}-R_sz_s` give Borel bijections with inverse `y_{s-1}=y_s+R_sz_s`. Translated Haar disintegration gives exactly

\[
\nu_{s-1}(dy_{s-1})=\nu_s(dy_s)\frac{dz_s}{(2\pi)^{m_s}}, 
|dx|^2=|dy_L|^2+\sum_s dz_s^TC_s^{-1}dz_s
\tag{I4}
\]

in chart interiors. A positive-to-negative face change of `z_s` shifts `y_s` by the corresponding `2pi R_s` column; recomputing subsequent principal residuals carries every ensuing integer shift. The maps are not asserted to be smooth global projections. Gauge translations belong to `M_L` and commute with every retention. The remaining root torus contains the passive gauge directions; the surviving normal residual modes at intermediate levels are the restoring and collective variables used below.

Every parent density is the full compact integral of its preceding density under (I4). A strictly positive smooth density has a positive minimum and bounded derivatives on its compact torus, so differentiation under that fixed integral proves positive smooth closure. The exact parent drift is

\[
b_s(y)=E_{\kappa_s}[P_sb_{s-1}(y+R_sz)], 
\overline L_s=T\Delta_{M_s}+b_s\cdot\nabla.
\tag{I5}
\]

This is the corrected projected identity. It inherits the restricted metric and the same temperature, without a new parent time factor. The complete nonlinear integral, including its conditional covariance terms in the Hessian, defines the drift.

The physical coupling is also exact. At a node put `delta=u-v`, with `u=(cos theta,sin theta)` and `v=(cos psi,sin psi)`. Relative to `m(dzeta)ev(zeta,dk)`, the proposed fixed-marginal optimizing coupling has log density ratio

\[
\frac{\delta\cdot(k-\zeta)}{1-a}-\frac{|\delta|^2}{2(1-a)}.
\tag{I6}
\]

Its expectation under every admissible coupling with those marginals is `|delta|^2/[2(1-a)]`. Subtracting this affine ratio leaves the nonnegative KL to the optimizer, proving the exact cost `d^ev=sum_i(1-cos d_i)/(1-a)`, including correlated candidate couplings. With `U_0=U-Td^ev`,

\[
\mathcal F(Q)=T D(Q\Vert\pi)-T\log c, 
\pi=c^{-1}e^{-d^{\rm ev}}P_0,  c=E_{P_0}e^{-d^{\rm ev}}>0.
\tag{I7}
\]

The singleton observation has evidence one; `c` is the variational tilt normalizer. The full parent presentation mixes the original Gaussian vector under the composed genuine priors `G`; its common evaluator can then be applied because it depends only on that presentation. The optimizing lift instead uses the composed `kappa`. These are different kernels. Their normalized tower identities and the KL chain rule give, for every stage,

\[
\mathcal F(Q)=T D(Q_s\Vert\pi_s)-T\log c
+T\sum_{j=1}^s E_{Q_j}D(Q_{j-1}(\cdot\mid Y_j)\Vert\kappa_j(\cdot\mid Y_j)).
\tag{I8}
\]

The component `typed-parent-class` is therefore supported globally as an identity of normalized laws and kernels. It does not rely on later path approximations.

## 4. Gaussian reference: deriving every later parent's estimates

Let `N=(ker B)^perp`, take an orthonormal basis adapted to the flag, and let `T_flag=BO`. This matrix and its inverse are block lower triangular. If `J_1>=...>=J_L=1`, conjugation by the square roots of the block weights multiplies each possible block by `sqrt(J_j/J_i)<=1`. The same holds for the inverse. Hence

\[
c_L\sum_jJ_j|v_j|^2\le v^THv\le C_L\sum_jJ_j|v_j|^2,
  H=O^TB^TDBO,
\tag{I9}
\]

with positive constants obtained from the finite Frobenius norms of `T_flag` and its inverse. Minimization over previously eliminated variables proves the same bounds for every exact Schur parent `H^{(a)}`. Repeated minimization proves associativity rather than assuming it.

For any `a<s`, split that parent into current fast variables `u` and retained normal variables `y`:

\[
H^{(a)}=\begin{pmatrix}F&G\\G^T&V\end{pmatrix}, 
H^{(s)}=K=V-G^TF^{-1}G.
\tag{I10}
\]

The checked bounds are

\[
F\succeq c_LJ_sI, \|F\|\le C_LJ_{a+1}, 
\|G\|\le C_LJ_{s+1},  0\prec K\preceq C_LJ_{s+1}I
\tag{I11}
\]

when the retained normal space is nonzero. The cross bound survives earlier elimination because the original blocks coupling to the future involve only rows beyond level `s`; the additional Schur term is at most `C_L(J_{a+1}/J_a)J_{s+1}`. Thus no later-parent cross estimate is imported as an assumption.

Prepare a shifted stationary-covariance normal Gaussian with edge mean residuals `A`, bridge mean residuals zero, covariance `TH^{-1}`, and independent root Haar law. Each ancestor starts with its actual orthogonal Gaussian marginal and evolves under its own exact Schur precision. Its normal mean remains bounded by `C_LA`, since the symmetric positive matrix exponential contracts.

For that ancestor, the conditional law of `u` has covariance `TF^{-1}`; its mean differs from the invariant conditional mean `-F^{-1}Gy` by

\[
e(t)=\mu_u(t)+F^{-1}G\mu_y(t), 
\Delta^G_{a:s}(t)=\frac{e(t)^TF e(t)}{2T}.
\tag{I12}
\]

The exact mean equations give

\[
\dot e=-(F+F^{-1}GG^T)e-F^{-1}GK\mu_y.
\tag{I13}
\]

Multiplication by `e^TF` yields a dissipative term `-e^TF^2e-|G^Te|^2`. For `r=|F^{1/2}e|`, (I11) therefore implies

\[
D^+r\le-c_LJ_s r+C_LA J_{s+1}^2/\sqrt{J_s}, 
r(0)\le C_LA\sqrt{J_{a+1}}.
\tag{I14}
\]

Integration, squaring, and `T=A^2/R^2` prove

\[
\Delta^G_{a:s}(t)\le C_LR^2
\left[J_1e^{-c_LJ_st}+J_{s+1}^2/J_s\right].
\tag{I15}
\]

The stronger plateau `J_{s+1}^4/J_s^3` also follows. At `s=L`, put `J_{L+1}=0`; the retained normal space and cross force are empty. This is a direct entropy proof, valid for the fine law and each separately evolved ancestor.

Variation of constants in the fast mean equation also gives

\[
|\mu_u(t)|\le C_LA[e^{-c_LJ_st}+J_{s+1}/J_s].
\tag{I16}
\]

Every past residual annihilates the future subspace, so (I16) makes all past residual means small and preserves that smallness at later times.

Future residuals require more than this upper bound. On the symmetric-channel slice the one-channel row Gram is `C=tridiag(3,-1,-1)`. The fine residual equation `dot r=-C D_edge r` preserves the positive cone, because its off-diagonal generator entries are nonnegative, and gives `r_i(t)>=A exp(-3J_i t)`. For an ancestor, partition eliminated and retained edges and set

\[
M=C_{RE}C_{EE}^{-1},  S=C_{RR}-C_{RE}C_{EE}^{-1}C_{ER}, 
Q=(D_R^{-1}+MD_E^{-1}M^T)^{-1}.
\tag{I17}
\]

Here `C_EE^{-1}` is entrywise nonnegative by its convergent adjacency series, so `M<=0`, `s(0)=A(1-M1)>=A1`, and `S` has nonpositive off-diagonal entries, diagonal at most three, and eigenvalues in `[1,5]`. The constrained flow `dot s^c=-S D_R s^c` is cooperative and retains the same lower bound. The actual Schur parent instead has drift `-SQs`; it is not assumed cooperative. Resolvent multiplication gives

\[
0\preceq D_R-Q\preceq D_RMD_E^{-1}M^TD_R,
 \|Q-D_R\|\le C_L J_{a+1}^2/J_a.
\tag{I18}
\]

Contraction of the constrained flow in the `S^{-1}` norm then proves

\[
|s^G(t)-s^c(t)|\le C_LA\min\{t,1\}J_{a+1}^2/J_a.
\tag{I19}
\]

This supplies actual future-edge separation for every ancestor without deleting its generated interaction.

The centered fluctuation of every ancestor is stationary with covariance `T(H^{(a)})^{-1}`. For `c_L` below its least normal eigenvalue, Ito's formula for `exp(c_L|z|^2/(4T))`, stopped at a radius, bounds its generator above by a finite dimension-dependent constant. Its initial expectation is at most `2^{dim N_a/2}`. Hence

\[
\Pr\{\sup_{t\le H}|Z_a(t)|>\rho A\}
\le C_L(1+H)e^{-c_L\rho^2R^2}.
\tag{I20}
\]

This controls entire time intervals, not only one-time covariances.

## 5. Nonlinear parents, chart tails, and entropy

Fix the finite Gaussian hierarchy before choosing `A`. Every rational normal quotient has a full discrete projected lattice, because its projection matrix is rational with a finite common denominator. Choose a common radius smaller than all relevant injectivity radii, Gaussian Voronoi radii, and principal-residual chart radii. This is possible for the finite family; its possible deterioration with the fixed weights is allowed. Root Haar is attached along cosets, so no global orthogonal product of tori is assumed.

Set `b=A^{9/10}` and `T=A^2/R^2`. In cumulative principal fiber coordinates the eliminated residuals are `T_a z`, where `T_a` is lower triangular with identity diagonal. Distance to `2pi Z` is 1-Lipschitz, giving

\[
|z|\le(I-|T_a-I|)^{-1}\delta, 
U_{\rm el}(z)\ge\frac{2J_a}{\pi^2K_a^2}|z|^2,
\tag{I21}
\]

where the inverse is a finite nilpotent sum and `K_a` is its norm. For example,

\[
K_a\le\sum_{j=0}^{a-1}
[\sqrt{q_a}(3\sqrt{10}+1)]^j,  q_a=\sum_{j\le a}m_j.
\tag{I22}
\]

The actual conditional denominator on `|y|<=b` is at least `c(T/J_1)^{q_a/2} exp(-CJ_{a+1}b^2/T)`, by integrating over a ball of radius proportional to `sqrt(T/J_1)`. Taking a fixed `D` large enough that the coefficient of `J_aD^2` in (I21) exceeds this exponent coefficient makes the conditional mass of `|z|>Db` at most

\[
E_A=K_{L,\epsilon}A^{-p}e^{-c_{L,\epsilon}b^2/T}.
\tag{I23}
\]

Thus a small denominator does not cancel the tail barrier. The comparison uses this global bound, not global convexity of cosine.

On the central region, the potential, force, and Hessian Taylor remainders are respectively `O(b^4)`, `O(b^3)`, and `O(b^2)`. The normalizer ratio is `1+O(T)`: integrate `C|x|^4 T^{-1} exp(-c|x|^2/T)` in a fixed central neighborhood and use the positive energy gap outside it. The wrapped Gaussian includes its actual volume and determinant normalizer. Consequently, for every exact generated parent,

\[
|\log(\pi_a/\pi_a^G)|\le K b^4/T+E_A,
\]

\[
|\nabla F_a-H_ay|\le K(b^3+b^5/T)+E_A=:d_A,
\]

\[
\|\nabla^2F_a-H_a\|\le K(b^2+b^4/T+b^6/T^2)+E_A=:h_A.
\tag{I24}
\]

The terms involving inverse temperature come from the full conditional covariance in the Hessian. They are not dropped. Substitution gives `d_A=O(A^{5/2})+E_A` and `h_A=O(A^{7/5})+E_A`, with constants independent of `A` after fixing `L,epsilon`. These are cumulative integrals of the original energy; no new inverse-temperature factor is introduced merely by naming another stage. Taking `h_A` below half the least of the finitely many Gaussian fast eigenvalues proves later nonlinear parent admissibility.

The actual Borel initial push and the wrapped orthogonal Gaussian initial law agree under their common fine Gaussian coupling unless the fine normal sample crosses a fixed-radius chart boundary. Their total variation is `O(exp(-c/T))`. This alone would not control KL. Both compact densities have an upper bound `CT^{-p}`, and the reference has lower bound `cT^p exp(-C/T)`. Decomposing two bounded densities into their common part and residual parts gives an entropy difference at most `C delta log(M/delta)+C h(delta)`. Adding the bounded-reference-log term proves initial KL `O(A^{-p}exp(-c/A^2))`.

A separate central relative-density estimate handles the actual Borel Gaussian push. The two maps agree on a fixed-radius good Gaussian submeasure. The periodized bad submeasure has density at most `CT^{-p}exp(-c/T)`, and Haar-preserving Borel integration cannot increase that upper bound. Conditional Gaussian tails give the same bound for the bad orthogonal push. On `|y|<=b`, the retained Gaussian density is at least `cT^p exp(-Cb^2/T)`. Division leaves `exp(-c/(2T))` for small `A`. This is the needed relative estimate; total variation is not substituted for it.

For path entropy, lift a compact density `q` by the Gaussian conditional winding law:

\[
\widetilde q(x)=\gamma(x)\frac{q(\operatorname{wrap}x)}{g(\operatorname{wrap}x)}.
\tag{I25}
\]

Its KL to the unwrapped Gaussian equals `D(q||g)`, and its total variation discrepancy also equals the compact discrepancy. The winding fourth moments are uniformly finite: outside finitely many lattice images the Gaussian exponent exceeds the zero-image exponent by `c|ell|^2`, uniformly on a bounded fundamental domain. The actual periodic parent drift is globally bounded by the maximum original force through (I5).

Use identical Brownian increments in a maximal initial coupling. Before exiting the `b` chart, contraction of the symmetric Gaussian drift gives path difference at most `H d_A`. The Gaussian maximum estimate gives exit probability at most (I23), and `H d_A=o(b)` transfers it to the actual process. The process in the conclusion remains the full process.

The change-of-drift entropy step can be proved without assuming finite path entropy. Switch the nonlinear drift to the linear reference after first exit from a radius-`j` Euclidean ball. The difference is bounded, its exponential change of measure is normalized, and integration of its log gives the stopped identity with coefficient `1/(4T)`. The switched paths converge to the actual nonexplosive paths; their energies are bounded by the full expected drift energy. Lower semicontinuity of relative entropy gives

\[
D(\mathcal P^N\Vert\mathcal P^G)
\le e_0+\frac1{4T}E_N\int_0^H|b_a(Y_t)+H_aY_t|^2dt.
\tag{I26}
\]

The primary source [Léonard, Theorem 2.3](https://arxiv.org/pdf/1101.3958) states the entropy identity under uniqueness once entropy is finite; the bounded stopped argument establishes finiteness here. The reference linear diffusion is unique. Finite fourth moments and Cauchy–Schwarz put the exit-event energy into (I23). Endpoint projection and wrapping therefore yield

\[
\sup_{t\le H}D(Q_{a,t}\Vert G_{a,t})
\le K H d_A^2/T+E_A=O(A^3)+E_A=:e_A.
\tag{I27}
\]

This is a statement about lifted path comparison followed by compact endpoint laws. It does not call a wrapped OU process a Markov torus diffusion.

For the direct conditional entropy comparison, write `q=Q_{a,t}`, `g=G_{a,t}`, and let subscripts `s` denote their actual Borel pushes. The exact density identity is

\[
\Delta^N_{a:s}=D(q\Vert g)-D(q_s\Vert g_s)+E_q f,
  f=\log(g/\pi_a)-\log(g_s/\pi_s)\circ C_{a:s}.
\tag{I28}
\]

The first difference is at most `e_A`. On the common chart, matching Gaussian covariances make the reference log ratio affine, with slope `O(A/T)` and constant `O(A^2/T)`. The projected mean used here is the projection of the current ancestor mean, not the mean of a separately evolved later parent. Equations (I24)–(I25) and the Borel relative-density estimate give `|f|<=K(1+b/A)+Kb^4/T` centrally and `|f|<=K/T+K|log T|` globally. Pinsker's inequality on the central region and the proved tail probabilities on its complement give

\[
\Delta^N_{a:s}(t)\le\Delta^G_{a:s}(t)
+e_A+K(1+b/A)\sqrt{e_A}+Kb^4/T+E_A
\le\Delta^G_{a:s}(t)+K A^{7/5}+E_A.
\tag{I29}
\]

Every conditional cost in an iterated chain is nonnegative, so it is bounded by the relevant cumulative loss and is charged once by (I8). This establishes `conditional-entropy` directly, including initialization and compact corrections.

## 6. Checking the physical and optimizing hidden moments

This is the joined equation (2a), not an assertion about KL between mixtures. At a retained point with normal `|y|<=C_LA`, the Gaussian eliminated mean is `-F^{-1}Gy`, and its covariance is `TF^{-1}`. From (I11), and the fixed conversion between orthonormal and principal normal coordinates,

\[
E_{\kappa^G}|z|^2\le C_L[(J_{a+1}/J_a)^2A^2+T/J_a].
\tag{I30}
\]

On the central fiber, `|z|^2<=C b^2`; multiplying by conditional density error `O(b^4/T)` gives `O(b^6/T)=O(A^{17/5})`. The noncentral contribution is exponential by (I21)–(I23). The genuine prior is the normalized tilt of the optimizer by `exp(d^ev)`. Its central oscillation is `O(b^2)`, and its global bound is finite because `0<a<1` is fixed. This adds at most `O(b^4)=O(A^{18/5})` plus the same exponential tail. Consequently (I30) holds for both exact conditionals with an additional `K A^{17/5}+E_A`.

For any original edge let `r(y)` be its retained-state residual and `xi=r(y)+ell z` its real residual lift. Its conditional root-mean-square perturbation `sigma` obeys

\[
\frac\sigma A\le C_L\left[\frac{J_{a+1}}{J_a}
+\frac1{R\sqrt{J_a}}\right]+K A^{7/10}+\text{exponential term}.
\tag{I31}
\]

This also applies to an already eliminated edge, for which `r(y)=0`, and to node bridge residuals. If a retained edge is coherent with slack and `sigma` is smaller than that slack, then

\[
E[1-\cos\xi]\le\tfrac12E\xi^2
\le\tfrac12(|r(y)|+\sigma)^2.
\tag{I32}
\]

For an unmerged edge, `|r(y)|>=A/2` and `|r(y)|=O_L(A)`. Taylor's formula, valid globally since `|V''|<=1`, gives

\[
|E V(\xi)-V(r(y))|\le|r(y)|\sigma+\sigma^2/2.
\tag{I33}
\]

Taking `sigma/|r(y)|` sufficiently small preserves a lower bound `c_LA^2`, because `V(r)>=2r^2/pi^2` centrally. Thus both genuine-prior and optimizer expected transported KL statistics have separated coherent and noncoherent ranges. The fixed channel covariance factors merely multiply these bounds by positive constants. Equations (I30)–(I33) check the physical interpretation without changing the complete marked parent law or claiming a false scalar formula for mixture KL.

## 7. One parameter regime and actual successive intervals

Set

\[
a_s=6(2^{L-s}-1),  J_s=\epsilon^{-a_s},  R=\epsilon^{-1},
  t_s=\kappa_LJ_s^{-1}\log(1/\epsilon),  H=2t_L.
\tag{I34}
\]

Choose `kappa_L>2(a_1+6)/c_L` with the final Gaussian decay constant. The factor two is only needed for the successive-activation corollary below; it leaves every earlier estimate valid. For `s<L`, direct substitution gives

\[
J_{s+1}^2/J_s=\epsilon^6, 
J_{s+1}/J_s=\epsilon^{a_{s+1}+6}, 
J_{s+1}/(R\sqrt{J_s})=\epsilon^4.
\tag{I35}
\]

Also `R^2J_1 exp(-c_LJ_st_s)<=epsilon^4`. Thus (I15) is `O_L(epsilon^4)` for every `a<s` and all `t>=t_s`. The intervals `[t_s,2t_s]` are disjoint for sufficiently small `epsilon`, because `t_s/t_{s+1}=J_{s+1}/J_s` tends to zero.

Take `epsilon` small enough that (I16) is below `eta/2` for past residual means and choose the radius in (I20) so every residual fluctuation is below `eta/4`. On an interval for stage `s`, every future edge has `3J_i t<=6 kappa_L log(1/epsilon) J_{s+1}/J_s=o(1)`. Its fine or constrained mean is therefore at least `3A/4`. The actual ancestor correction (I19) is at most `C_LA epsilon^6`, so the future ancestor mean exceeds `5A/8`; its actual residual exceeds `A/2` on the same noise event. Past residuals stay below `3eta/4`, providing strict slack for the nonlinear comparison.

Now hold this `epsilon`, all weights, `R`, and `H` fixed. Choose `A>0` so small that `T=A^2epsilon^2`, the generative inequality `J_1>T/(1-a)` holds, `Db` lies inside every chart, `h_A` is below half every required Gaussian fast eigenvalue, and `||B||H d_A` is below the remaining coherence slack. The last requirement is possible because `d_A/A=O(A^{3/2})+E_A/A` tends to zero. Also choose `A` so the nonlinear conditional entropy term in (I29) is below the desired budget.

Finally, (I31) is uniformly small relative to `A`: its first terms tend to zero when `epsilon` does, including at the final stage where `J_{L+1}=0`, and its remaining terms tend to zero with `A`. Taking them below the fixed residual slack proves the physical expected-KL assertions in the same regime. There is no conflicting amplitude requirement. Each smallness condition is a strict inequality in a finite list after fixing `L`.

The formation failure probability is bounded by a finite union of (I20) and (I23). It tends to zero in the prescribed order. For `L=3`, the seven edge levels are `(1,2,1,3,1,2,1)` and the weights are `(epsilon^-18,epsilon^-6,1)`. On the first interval only edges `1,3,5,7` are coherent; on the second, edges `2,6` join them; on the third, edge `4` joins the two remaining blocks. The component counts are therefore `8 -> 4 -> 2 -> 1`. At time zero every edge is separated on the same noise event. Each autonomous ancestor has its remaining distinct intervals by (I17)–(I19). A second marginalization of an already coherent state is not used as an episode proof.

The supplied static interaction pattern determines a candidate restoring flag, but all coefficients and the microscopic update remain unchanged in time. The intervals are proved properties of those equations; they are not a programmed merger schedule.

## 8. Force, paths, and compact-face accounting

For a Gaussian split (I10), the projected microscopic equation differs from the autonomous parent drift by `-G^T E_t`, where `E_t=u_t+F^{-1}Gy_t`. Its mean is bounded by (I16) and its centered covariance is exactly `TF^{-1}`. The centered increment covariance is bounded by `C_LT|t-v|I`, by diagonalizing the symmetric ancestor precision and using `(1-exp(-lambda h))/lambda<=h`. A mesh of size `1/J_s` with dyadic refinements and Gaussian tails therefore gives, outside probability `delta`,

\[
\sup_{t\le H}|E_t-E E_t|
\le C_L\sqrt{T/J_s}
\sqrt{\log\frac{C_L(1+HJ_s)}\delta}.
\tag{I36}
\]

The refinement thresholds are summable because they are proportional to `2^{-q/2} sqrt(log(C(1+HJ_s)/delta)+Cq)`. This checks the continuous-time maximum step.

Use common projected Brownian increments and actual projected initial Gaussian samples at all stages. The path difference starts at zero and solves a contractive linear equation forced by `-G^T E_t`. Integrating (I16) and (I36) yields

\[
\frac{p_s}{A}\le C_L\left[
\frac{J_{s+1}}{J_s}+H\frac{J_{s+1}^2}{J_s}
+\frac{HJ_{s+1}}{R\sqrt{J_s}}
\sqrt{\log\frac{C_L(1+HJ_s)}\delta}\right].
\tag{I37}
\]

This is joined (3a). With `delta=epsilon^2`, it is `O_L(epsilon^6 log(1/epsilon)+epsilon^4[log(1/epsilon)]^{3/2})`. The failure probabilities sum over only finitely many comparisons. No factor `1/A` remains hidden after using `T=A^2/R^2`.

For the exact nonlinear processes the two endpoint comparisons each contribute at most `H d_A` on the common chart. The retentions have norm one there. A chain of `r` reductions consequently has path error at most `sum p_s+2rH d_A` and exceptional probability at most the sum of the Gaussian tolerances plus `rE_A`, enlarging the finite envelope if necessary. A common coupling exists: use the common fine Gaussian initial sample and Brownian family, and couple the finitely many actual initial marginals to their Gaussian marginals using conditional maximal couplings. The total initial mismatch probability is bounded by the sum of their proved exponential discrepancies.

The joined instantaneous force formula (4a) also follows. At the Gaussian point, the magnitude is `|G^TE_t|`. At the coupled actual point, add the two nonlinear force remainders from (I24) and the fixed Gaussian linear-operator norm times the `H d_A` displacement. Thus

\[
|P_sb_a(Y_a(t))-b_s(C_{a:s}Y_a(t))|
\le C_LAJ_{s+1}\left[e^{-c_LJ_st}+\frac{J_{s+1}}{J_s}
+\frac1{R\sqrt{J_s}}\sqrt{\log\frac{C_L(1+HJ_s)}\delta}\right]
+K_{L,\epsilon}d_A.
\tag{I38}
\]

For `t>=t_s`, its ratio to `A` tends to zero first with `epsilon` and then with `A`. The exponential term remains small after multiplication by `J_{s+1}`, because the chosen `kappa_L` dominates `a_1`. The other terms are `epsilon^6` and `epsilon^4 sqrt(log(1/epsilon))`. This is a pathwise interior estimate with an explicit exceptional event. The separate conditional-mean force bound using its actual bounded force diameter and the square root of conditional KL remains valid but is not substituted for this sharper scaling.

The good event keeps all normal paths in a fixed subchart where every Borel retention equals its orthogonal lift. Its complement includes every face, winding, and initial branch event needed by the comparison. Exact normalized laws and their face identifications hold everywhere, including that complement. No reflection, quotient that forgets a sheet, or global Brownian identification of the final Borel root has been introduced.

## 9. Openness and the remaining quantifiers

At the selected positive finite parameters, choose all inequalities with slack. For initial laws, let `q_0` be the nominal smooth strictly positive compact density and impose

\[
\|q'_0/q_0-1\|_\infty<\delta_0, 
q'_0>0, \int q'_0d\nu=1,
\tag{I39}
\]

with `delta_0` sufficiently small. This is open in the uniform topology restricted to smooth normalized densities, because `q_0` has a positive minimum. It permits correlations and non-gauge-invariant perturbations. The nominal law is correlated: at low temperature the bridge residual has positive cosine expectation, whereas its separately Haar node marginals would give zero under independence. That strict statistic also persists in a sufficiently small neighborhood.

Every initialization retention, evolution semigroup, and subsequent retention is a positive Markov kernel. Hence the relative measure bounds `1-delta_0 <= q'/q <= 1+delta_0` persist through all these operations. The initial path coupling changes an event probability by at most its initial total variation, and subsequent common noise preserves equality when the initial states agree. For a nominal source or retained law, compact positivity and invariance bound `||log(q_t/pi)||_infinity` uniformly on `[0,H]` by `C/T+C|log T|`. The density-ratio identity gives

\[
|D(q'_t\Vert\pi)-D(q_t\Vert\pi)|
\le C\delta_0^2+C\delta_0(T^{-1}+|\log T|).
\tag{I40}
\]

Apply this to both terms of each cumulative conditional entropy. Choosing `delta_0` below the finite slack budgets proves an open initial-law regime. If the same asymptotic exponential envelope is desired, take `delta_0` exponentially small in `b^2/T`, as the nonlinear reconstruction does. At each fixed positive parameter choice this remains a nonempty open neighborhood. The quotient-Haar entropy cancellation is used only at the nominal point; (I40) handles noninvariant perturbations on the full compact space.

For physical parameters, the covariance and energy matrices, inverses, compact integrals, and their required derivatives vary continuously on a sufficiently small compact neighborhood of the chosen strictly positive values. The previously strict hierarchy inequalities and Gaussian time-interval margins persist. Exact nonlinear estimates are uniform on that small neighborhood, by the same compact integral bounds and a slightly smaller common chart. Equivalently, finite-horizon same-noise coupling with bounded smooth coefficient differences preserves the strict path margins. Temperature is allowed to vary in a positive neighborhood; the relation `R=A/sqrt(T)` is then a continuously varying derived ratio, not a restriction to a zero-width parameter hypersurface. A sufficiently small initial-density neighborhood can be chosen simultaneously.

This proves `joined-regime`. The open neighborhood can be very small and its constants can depend badly on `L`, the weights, and temperature. The frozen target expressly allows that deterioration. It supplies no depth-independent runtime or infinite-depth claim.

## 9a. Successive activation of the actual retained laws

The final joined revision adds a corollary that actually activates parents at `tau_s=2t_s`, starting with `tau_0=0`. The microscopic process remains unchanged; the choice of activation times concerns when to use a reduced description inside the already proved coherence windows. It is a stronger reuse statement than the separately initialized comparisons and is not used to make the microscopic mergers occur.

At a Gaussian activation, orthogonal projection sends covariance `T H_{s-1}^{-1}` to exactly `T H_s^{-1}`. Future Brownian increments remain independent of that projected Gaussian initial state, so the covariance stays stationary under the newly active inherited generator. Gaussian linearity and deterministic activation times preserve the Gaussian law, while every projection and positive symmetric semigroup contracts the mean norm. The bound `|mu|<=C_LA` therefore persists. For `t in I_s`, the active elapsed time satisfies

\[
t-\tau_{s-1}\ge t_s/2
\tag{I41}
\]

for sufficiently small `epsilon`, because `2t_{s-1}/t_s` tends to zero. Applying (I14)–(I15) with this elapsed time and the doubled `kappa_L` retains the `O_L(epsilon^4)` conditional-KL bound. No equilibrium mean is assumed at activation.

Use the common Brownian family from Section 8 to compare the sequential Gaussian stage `a` with the separately initialized autonomous stage `a`. At activation its initial discrepancy is at most the previous discrepancy plus the adjacent comparison `p_a`; it contracts during that stage. Induction gives a bound `sum_{j<=a}p_j=o_L(A)` outside total probability `a delta`. This preserves the strict previously proved coherent and separated margins. The centered sequential Gaussian law also has its own stationary covariance on each active interval, so its `b`-chart exit probability follows directly from (I20), with a finite union bound. It is not inferred from the weaker `O(epsilon^2)` path-comparison event.

Couple the sequential nonlinear process directly to that sequential Gaussian process. Between activations the displacement increases by at most elapsed time times `d_A`; inside the common chart, an activation is the same norm-one projection for both processes and cannot increase displacement. The total additional displacement is at most `H d_A`, with additional failure probability bounded by a finite multiple of `E_A`. In particular the nonlinear initial state of each active parent is the actual retained preceding state.

For entropy at an activation, let `q^N,q^G` be the current compact nonlinear and Gaussian laws and let `g_new` be the wrapped orthogonal Gaussian marginal. Then

\[
D(C_\#q^N\Vert g_{\rm new})
=D(C_\#q^N\Vert C_\#q^G)
+E_{C_\#q^N}\log\frac{C_\#q^G}{g_{\rm new}}
\le D(q^N\Vert q^G)+E_A.
\tag{I42}
\]

Data processing gives the first inequality term. The second is bounded by the central Borel relative-density estimate and the global `O(T^{-1}+|log T|)` bound times the actual strong-coupling exit probability. Each active diffusion interval adds at most `K A^3+E_A` via (I26)–(I27). Thus the current full-law entropy is at most `L K A^3+L E_A`.

The Euclidean entropy lift at a restart needs an explicit qualification: one must not use a new initial maximal coupling with failure `O(sqrt(e))` to deduce exponential exit control. Instead, the sequential strong coupling already gives the compact exit event. On its central chart the conditional Gaussian probability of a nonprincipal winding is exponentially small. A continuous lift initialized on the principal sheet cannot reach another sheet while its compact path remains in the central chart. This gives the necessary exponential exit bound for the entropy lift itself. The conditional winding fourth moments remain uniformly finite, so the same stopped drift-energy argument applies at every restart. These facts justify (I42) without assuming that compact KL controls exit probabilities.

Finally (I28)–(I29) apply with the active Gaussian mean and stationary covariance. The current active-interface conditional loss is `O_L(epsilon^4)+K_{L,epsilon}A^{7/5}+L E_A`. Losses at different times are not telescoped as if they belonged to a single law. Sequential instantaneous interface force uses (I38) with `t` replaced by `t-tau_{s-1}`, derived directly from the active conditional defect and its covariance. It does not multiply the summed path discrepancy by a possibly large Gaussian Hessian. The doubled `kappa_L` again gives the claimed normalized force decay.

The corollary therefore reconstructs: the exact current retained law can initialize each next parent, with covariance, conditional entropy, force, paths, and branch errors all propagated. The same relative-density argument in Section 9 applies to the finite composition of evolution and activation kernels, preserving an open initial-law regime. The bound remains finite-depth and does not assert an arbitrary random-hitting-time activation theorem.

## 10. Substantive attacks and falsification conditions

Every attack below is against the target or one of its transitive dependencies at the source versions in Section 1. The cited proof steps, not a reviewer vote, supply the responses.

| ID | Affected claim IDs | Attack and disposition | Response and condition that would overturn it |
| --- | --- | --- | --- |
| FD-01 | `typed-parent-class` | Rank might hide disconnected kernels or lost sheets. Rejected. | Integer inverse (I1), exact Borel inverse and Haar disintegration (I4). A nonprimitive residual block or an omitted face carry would overturn the response. |
| FD-02 | `typed-parent-class`, `dynamical-error` | Averaging an unprojected force or dropping the Gaussian normalizer could falsify the formulas. Historical defects, corrected in the inspected sources. | (I5) includes the tangent projection; normalized density comparison in (I24) includes the Gaussian volume/determinant constant. Reintroducing either original omission would invalidate the corresponding identity. |
| FD-03 | `finite-depth-admissibility` | Later Schur parents might be assumed to retain the needed cross bounds. Rejected. | Weighted triangular conjugation, minimization, and explicit cross-block Schur estimate (I9)–(I11). A cross correction larger than `C_L J_{s+1}` would invalidate the downstream estimates. |
| FD-04 | `actual-coalescence` | A Schur parent might be incorrectly treated as cooperative or as diagonal in residual energy. Rejected. | The actual precision `Q` is retained in (I17); (I18)–(I19) compare it to a separate cooperative system. Failure of the resolvent or contraction estimate would reopen future-edge separation. |
| FD-05 | `conditional-entropy` | Covariance lag or a wrong parent mean might be omitted. Rejected. | Each reference has stationary covariance by its specified initialization; its own conditional mean defect is (I12), and the projected current ancestor mean is used in (I28). Substituting an independently evolved later mean would invalidate the entropy calculation. |
| FD-06 | `finite-depth-admissibility`, `joined-regime` | Small conditional denominators or noncentral wells might defeat the Taylor expansion. Rejected. | Global principal-distance barrier, denominator lower bound, and finite choice of `D` in (I21)–(I24). An additional eliminated zero on the principal cube would falsify that argument. |
| FD-07 | `conditional-entropy`, `dynamical-error` | Rare initial mismatch could have large KL, or the Borel Gaussian push could have a large relative error. Rejected for this preparation. | Compact density bounds, common-part entropy estimate, and the separate good/bad density comparison in Section 5. Removing the density bounds would make TV insufficient. |
| FD-08 | `conditional-entropy`, `dynamical-error` | Girsanov might assume the entropy being proved, or replace the wrapped process by a Markov torus OU. Rejected. | Winding lift (I25), bounded stopped change of drift, finite fourth moments, and lower semicontinuity prove (I26)–(I27). A nonfinite drift energy or an unbounded winding moment would invalidate the stated localization. |
| FD-09 | `conditional-entropy` | Path convergence might be substituted for conditional KL. Rejected. | The exact density identity (I28), affine reference ratio, and direct expectation estimate prove (I29). No continuity of KL in path distance is invoked. |
| FD-10 | `typed-parent-class`, `actual-coalescence`, `joined-regime` | A scalar residual might be passed off as KL between correlated mixtures, or the physical prior might be replaced by the optimizer. Rejected. | (I30)–(I33) treat inherited original-edge statistics under both distinct kernels, including the `exp(d^ev)` tilt. A physical model requiring mixture-KL equality would be a different, unsupported conclusion. |
| FD-11 | `dynamical-error`, `joined-regime` | A hidden inverse amplitude or wrong epsilon power might leave the error larger than the signal. Rejected. | (I35), (I37), and (I38) display all powers after division by `A`; nonlinear corrections contribute `d_A/A=O(A^{3/2})`. A bound uniform in simultaneously growing contrast and shrinking amplitude is not claimed. |
| FD-12 | `actual-coalescence`, `target` | The dyadic flag might merely rename an already coherent block or insert a merger schedule. Rejected. | Initially separated residuals, past-residual upper bounds and future-residual lower bounds establish distinct intervals in Section 7 under one unchanged generator. Time-dependent coefficients would change the construction. |
| FD-13 | `joined-regime`, `target` | One Gaussian preparation or one parameter curve might be called an open regime. Rejected. | Relative-density neighborhood (I39)–(I40) and finite positive parameter continuity in Section 9. Requiring a depth-uniform neighborhood would exceed this proof's quantifiers. |
| FD-14 | `finite-depth-admissibility`, `dynamical-error`, `target` | Local curvature might imply an unproved global fast entropy rate, or a lost compact branch might be ignored. Rejected. | Local eigenvalue perturbation is separate from the conservative global spectral gap; entropy uses (I29), and all branch events remain in (I23). Replacing the actual Borel map by a smooth global quotient without an error term would invalidate the comparison. |
| FD-15 | `conditional-entropy`, `dynamical-error`, `actual-coalescence`, `joined-regime`, `target` | Activating a parent at the actual reduction time might spoil covariance, entropy, or exponential exit control. Rejected for the stated deterministic activation times. | Section 9a proves projected stationary covariance, the half-interval mean estimate, the entropy restart identity (I42), and strong-coupling plus conditional-winding exit control. Using `O(sqrt(e))` maximal-coupling failure as an exponential bound, or asserting arbitrary random activation without a new proof, would invalidate that extension. |

## 11. Independent reconstruction and oracle erasure

The independent reconstruction result is **PASS for the stated finite-depth construction**, with the following explicit coverage.

| Claim ID | Proof dependency discharged |
| --- | --- |
| `typed-parent-class` | Sections 3 and 6: primitive Borel geometry, exact normalized physical/prior/optimizer kernels, VFE chain, and the correct physical statistic. |
| `finite-depth-admissibility` | Sections 4–5: all Gaussian Schur bounds, global fiber barrier, full nonlinear derivative estimates and positive local restoring modes. |
| `actual-coalescence` | Sections 4, 6–7 and 9a: cooperative comparison with the actual Schur correction, uniform noise bounds, physical moment transfer, explicit three-stage intervals and sequential activation. |
| `conditional-entropy` | Sections 3–5, 7 and 9a: exact chain, direct Gaussian defect, actual-law KL comparison, compact corrections, entropy at activation and finite parameter substitution. |
| `dynamical-error` | Sections 5, 8 and 9a: initial-law entropy, full lifted path estimate, adjacent path and force bounds, common coupling, actual-law activation and all exceptional events. |
| `joined-regime` | Sections 6–9a: compatible epsilon powers, ordered amplitude choice, finite-depth constants and open initial-law/parameter neighborhoods. |
| `target` | All six rows, with the exact finite-horizon and normalized-law notions of equivalence in Section 2. |

Oracle erasure was performed by omitting the favorable search prior entirely from the logical premises. The remaining premise list consists of the integer path geometry, explicit normalized law/evaluator definitions, positive finite coefficients, common microscopic unit metric, a chosen positive initial density, and ordinary finite-dimensional and stochastic identities whose hypotheses are checked above. Each potentially conclusion-shaped premise was inspected separately. The flag is a candidate coordinate decomposition justified by subsequent trajectory inequalities, not an assumed trajectory partition. The static interaction contrast is an allowed microscopic input and is never altered at a merger time. Gaussian stationarity of covariance follows from the declared preparation and its OU equation; nonlinear stationarity is not assumed. Future-parent admissibility follows from Schur and compact-integral estimates. Conditional equilibration follows from (I12)–(I15) and (I28)–(I29). Openness follows from explicit perturbation bounds rather than being assigned to a single prepared density. Physical agreement uses its declared inherited statistic and both normalized conditional families. No capability, storage, permanent stopping level, or physical-clock assumption appears.

The sequential-activation corollary was also checked after removal of the favorable prior. Its activation times select when to use an already justified approximation; they neither alter the original microscopic generator nor supply the proof that its edges first cohere. Projected stationary covariance is an algebraic consequence of the Gaussian law, and nonlinear covariance stationarity is never assumed. Entropy at each activation follows from (I42), rather than being reset to zero.

Removing the favorable prior therefore leaves the same derivation for `target`, `typed-parent-class`, `finite-depth-admissibility`, `actual-coalescence`, `conditional-entropy`, `dynamical-error`, and `joined-regime`, including Section 9a's sequential use of actual retained laws. The oracle-erasure result is **PASS at this scope**. This records a substantive premise check; it is not evidence that an arbitrary broader hierarchy theorem follows.

## 12. Result and remaining scope

The strongest supported result is the requested reusable finite-depth nonlinear compact construction for each prescribed finite `L`, including actual `8 -> 4 -> 2 -> 1` episodes, all exact normalized parent and conditional-VFE identities, inherited metrics and physical kernels, quantitative actual-law entropy, force, path, initialization, and compact-face corrections in one nonempty open regime, and the sequential activation of actual retained laws proved in Section 9a. No mathematical obligation within that frozen construction remains unresolved by the displayed join and its checked component derivations.

The next mathematical action that would change the scope of the answer is to supply an additional proof for a genuinely broader claim, such as learned microscopic interaction scales, arbitrary merger histories, non-Abelian loop sectors, a depth-uniform regime, or a mixture-KL criterion. None is certified here or needed for the frozen finite-depth target. Source inspection, source hashing, primary retrieval of the Girsanov paper, and this analytical report are the only work performed in this pass. No experiment, suite, GPU task, Lean work, tamper check, prior scientific rerun, vault edit, or Git mutation was performed.
