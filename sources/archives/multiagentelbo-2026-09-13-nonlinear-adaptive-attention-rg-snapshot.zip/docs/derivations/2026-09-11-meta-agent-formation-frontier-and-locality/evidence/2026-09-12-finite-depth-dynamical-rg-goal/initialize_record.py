"""Freeze the finite-depth research contract; this script proves no theorem."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def main() -> None:
    run = Path(__file__).resolve().parent
    previous = json.loads((run.parent / '2026-09-12-nonlinear-dynamical-rg-goal/problem-contract.json').read_text(encoding='utf-8'))
    target = previous['target']
    target.update({
        'statement': 'Construct a reusable finite-depth nonlinear dynamical RG family at one base point, with exact normalized parent laws and inherited geometry, three actual successive coalescence levels, and quantitative propagation of conditional VFE and dynamical errors through every admitted finite depth.',
        'quantifier_class': 'MIXED',
        'quantifiers': 'For each prescribed finite integer L >= 3, construct a nonempty finite compact two-channel law/link family and an open positive-temperature parameter and smooth positive initial-law regime supporting L successive coalescence levels under one common microscopic kinetic rule. Exhibit L=3 explicitly, with agent counts 8 -> 4 -> 2 -> 1 or another explicitly equivalent three-level interacting construction. State and prove a reusable exact parent construction and quantitative finite-L error bounds, including the dependence of its admissibility constants on L. No uniform infinite-depth limit is requested.',
        'domains': ['Finite compact configurations of two belief/model law channels and independent dynamic links at fixed c_*; a dyadically weighted path on 2^L nodes is an admissible specialization, not a restriction of the ambient research ontology.', 'Correlated smooth positive recognition densities on complete compact configurations, with explicit global Borel retentions, connected kernels, references, physical/evaluator presentations and boundary identifications.'],
        'codomains': ['An exactly integration-closed class of normalized marked parent laws, evaluator kernels, downward priors, conditional variational costs and inherited local kinetic operators.', 'L actual coalescence levels and explicit conditional-KL, force, path, initialization and exceptional-event bounds for actual fine projections and separately evolved parents in a common nonempty finite-parameter regime.'],
        'regularity': 'Prove the finite-dimensional rank and lattice statements, regularity of compact integrals, stability and normalization of generated parents, and the hypotheses of every probability or perturbation estimate. Approximation by a quadratic reference is permitted only with an explicit vanishing remainder for the actual nonlinear dynamics and full nonlinear parent laws.',
        'equivalence': 'Exact equality of normalized common-channel pushforwards and conditional-family VFE identities, with inherited geometry and all generated interactions. Dynamical equivalence is an explicit finite-horizon comparison, not an assertion of exact Markov closure. Conditional KL must be bounded directly; path or weak convergence alone is insufficient. Any compact chart, winding, covering or initial-law discrepancy remains in the estimate.',
        'premises': previous['target']['premises'][:6] + ['The published nonlinear two-stage theorem is a source result. Extending its notation or replacing its model by a quadratic process does not prove finite-depth nonlinear closure.', 'A fixed finite graph, microscopic interaction contrasts, channel covariances, common kinetic metric and an open initial preparation may be stated as model inputs. The exact dynamical formation episodes and inherited parent admissibility must then be derived.', 'A generated parent may occupy a larger correlated marked law class than a microscopic scalar agent. Keep that full class and its conditional kernels; do not reset a parent to a preferred Gaussian or pairwise ansatz.', 'The result may have constants and parameter neighborhoods that deteriorate with L. Establish a nonempty regime for each prescribed finite L instead of assuming all recursive hypotheses hold.', 'Microscopic interaction learning, arbitrary merger histories, general gauge groups, infinite depth, permanent positive-temperature agreement, physical-clock identification and base transport are outside this target.'],
        'negative_certificate_kind': 'NONEXISTENCE_PROOF',
        'falsification_criterion': 'The mixed target is refuted only by a nonexistence proof for some prescribed finite L throughout the admitted construction class. A proposed route fails if it assumes the next parent remains admissible, inserts parent rates or a merger schedule, loses compact information without its correction, uses a quadratic replacement without error control, or cannot supply the common parameter regime and actual conditional-entropy bounds.',
    })
    digest = hashlib.sha256(json.dumps(target, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    binding = {'schema_version': 'rigorous-theory-search/v1', 'contract_id': 'contract-sha256-' + digest, 'target_digest': digest}
    for path in run.glob('*.json'):
        data = json.loads(path.read_text(encoding='utf-8'))
        data.update(binding)
        if path.name == 'problem-contract.json':
            data['target'] = target
        elif path.name == 'claim-ledger.json':
            data['claims'][0].update({'statement': target['statement'], 'quantifiers': target['quantifiers'], 'target_digest': digest, 'falsifier': target['falsification_criterion']})
            children = [
                ('typed-parent-class', 'The finite primitive nested-kernel construction gives normalized exact parent laws, physical kernels, conditional costs and inherited metrics, preserving all global identifications.'),
                ('finite-depth-admissibility', 'For every prescribed finite depth, the exact generated nonlinear parents satisfy the quantitative hypotheses used by the next reduction in a proved nonempty regime.'),
                ('actual-coalescence', 'The same microscopic and inherited parent equations yield actual successive coalescence levels, including a three-level witness.'),
                ('conditional-entropy', 'Actual fine and autonomous-parent conditional VFE losses obey derived finite-depth bounds including all reference and boundary corrections.'),
                ('dynamical-error', 'Inherited parent forces and paths obey derived finite-depth comparison and exceptional-event bounds.'),
                ('joined-regime', 'One nonempty open finite-parameter and positive initial-law regime satisfies all previous conclusions at each prescribed finite depth.'),
            ]
            data['claims'] += [{'id': name, 'statement': statement, 'quantifiers': target['quantifiers'], 'kind': 'MATHEMATICAL', 'target_digest': digest, 'state': 'CANDIDATE', 'assumption_ids': [], 'evidence_ids': [], 'bridge_premise_ids': [], 'falsifier': 'A failed typed identity, quantitative estimate or common-regime hypothesis.'} for name, statement in children]
        elif path.name == 'dependency-dag.json':
            data['edges'] = [{'from': 'target', 'to': name} for name in ['typed-parent-class', 'finite-depth-admissibility', 'actual-coalescence', 'conditional-entropy', 'dynamical-error', 'joined-regime']]
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    header = '<!-- rigorous-theory-search-metadata ' + json.dumps(binding, separators=(',', ':')) + ' -->'
    for path in run.glob('*.md'):
        text = path.read_text(encoding='utf-8').split('\n', 1)[1]
        path.write_text(header + '\n' + text, encoding='utf-8')
    print(json.dumps(binding))


if __name__ == '__main__':
    main()
