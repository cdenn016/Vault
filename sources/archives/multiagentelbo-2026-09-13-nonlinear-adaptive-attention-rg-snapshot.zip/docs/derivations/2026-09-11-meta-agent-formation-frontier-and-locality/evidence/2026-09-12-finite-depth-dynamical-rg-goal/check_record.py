"""Check documents and save the results; hashes do not prove mathematics."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


def main() -> int:
    run = Path(__file__).resolve().parent
    source = run.parent.parent
    validator = Path('C:/Users/chris and christine/.codex/skills/rigorous-theory-search/scripts/validate_run.py')
    checked = subprocess.run([sys.executable, '-B', str(validator), str(run), '--mode', 'release'],
                             capture_output=True, text=True, encoding='utf-8', check=False)
    errors = []
    if checked.returncode:
        errors.append(checked.stdout + checked.stderr)
    ledger = json.loads((run / 'claim-ledger.json').read_text(encoding='utf-8'))
    reconstruction = (source / 'finite-depth-independent-reconstruction.md').read_text(encoding='utf-8')
    sources = []
    links = 0
    for item in ledger['evidence']:
        snapshot = run / item['artifact_path']
        original = source / snapshot.name
        if original.read_bytes() != snapshot.read_bytes():
            errors.append('Source differs from its proof snapshot: ' + snapshot.name)
        source_hash = hashlib.sha256(original.read_bytes()).hexdigest()
        sources.append({'path': original.name, 'sha256': source_hash})
        if original.name != 'finite-depth-independent-reconstruction.md' and source_hash not in reconstruction:
            errors.append('Current source binding absent from the complete reconstruction: ' + original.name)
        text = original.read_text(encoding='utf-8')
        for match in re.finditer(r'\[[^\]\n]*\]\((?:<([^>]+)>|([^\)]+))\)', text):
            target = (match.group(1) or match.group(2)).split('#', 1)[0]
            if not target or re.match(r'^https?://', target):
                continue
            links += 1
            if not (original.parent / target).is_file():
                errors.append(original.name + ': missing linked file ' + target)
    for helper in run.glob('*.py'):
        ast.parse(helper.read_text(encoding='utf-8'), filename=str(helper))
    outcome = {'structural_validator_exit_code': checked.returncode,
               'proof_snapshots': len(sources), 'claim_count': len(ledger['claims']),
               'local_links_checked': links, 'source_bindings': sources, 'errors': errors,
               'limitations': 'Document structure, current bytes, local links and Python syntax only; analytical proofs are not mechanically certified.'}
    (run / 'release-validation.json').write_text(json.dumps(outcome, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(outcome, indent=2))
    return int(bool(errors))


if __name__ == '__main__':
    raise SystemExit(main())
