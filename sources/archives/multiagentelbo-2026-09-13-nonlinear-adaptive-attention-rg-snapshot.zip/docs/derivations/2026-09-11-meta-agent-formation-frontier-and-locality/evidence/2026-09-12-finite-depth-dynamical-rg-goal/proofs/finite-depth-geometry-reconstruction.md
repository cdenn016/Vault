# Independent reconstruction of finite-depth laws and geometry

September 12, 2026. This report checks the exact-law component of the frozen [finite-depth contract](evidence/2026-09-12-finite-depth-dynamical-rg-goal/problem-contract.json), contract digest `d15c9f5a5a810b76900ea496929ff4a5c6832d4553a379d5da43ce2f1f7e3bd9`. The inspected [parent-class draft](finite-depth-parent-class.md) had SHA-256 `48188facdab44a1c108a186d80b127aaf85de47599bb65d2d3c979665580e1a7`; the contract file had SHA-256 `5ae6b7900c0df32b82e2054555b8dcd4594f2454413929b14ea4c4de6ae6a91a`. These identify the inspected artifacts, not mathematical acceptance criteria.

The coordinate, normalized-law, conditional-VFE, and fiber-barrier statements reconstruct. One sentence after draft equation (15) requires a projection: the parent force equals the average of the retained component of the preceding force. The unprojected reading is false, as the explicit counterexample below shows. This correction does not change the displayed parent generator. No conclusion about actual formation episodes or dynamical approximation is certified here.

The source consultation covered `docs/STATUS.md`, [nonlinear-parent-laws-and-geometry.md](nonlinear-parent-laws-and-geometry.md), Sections 1–7, [Theory/03_probability.tex](../../../Theory/03_probability.tex), its kernel, reference, and regular-conditional conventions, and [Theory/05b_local_collective_elbo.tex](../../../Theory/05b_local_collective_elbo.tex), the conditional VFE and posterior KL chain identities. The live Research manuscript [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) at `eq:rg_slow_graph_metric` and `eq:rg_schur_flow` distinguishes a slow-manifold pullback from a quotient metric and an energy estimate from a force estimate. The Research wiki's [Staged hierarchy formation and RG composability](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Staged hierarchy formation and RG composability.md>) supplies the earlier scope distinctions. No source's status label is used as a proof premise.

## 1. Exact target and assumptions

For each fixed integer `L >= 3`, put `n=2^L`, `N=4n-2`, and `m=3n-2`. On `X_0=T^N`, with period `2pi`, normalized Haar reference, and the unit angular metric, use the residual rows

\[
d_i=\theta_i-\psi_i,\qquad
r_i^b=\theta_i-\theta_{i+1}-\alpha_i^b,\qquad
r_i^m=\psi_i-\psi_{i+1}-\alpha_i^m.
\tag{R1}
\]

Edges have levels `ell(i)=1+v_2(i)`. The first row block consists of every `d_i` and both residuals on level-one edges; subsequent blocks contain both edge residuals at their level. The claim checked is that this flag gives exact Borel coordinate bijections, normalized parent densities and kernels, inherited restricted metrics, and iterated conditional KL identities for every finite `L`. Equality of measures and kernels is exact; differential identities are local expressions with the stated global face identifications. It is not exact Markov closure of the Borel projection.

The user supplies the fixed-base-point ontology, two law channels, independent links, common microscopic kinetics, normalized physical channels, and permission to introduce a finite family. The dyadic path, angular group, cosine energies, Gaussian presentation family, and common unit metric are declared specializations in the draft. They are not universal assumptions of the program. This reconstruction introduces no new scientific assumption. The norm estimates below use Euclidean operator norms and explicitly stated finite-dimensional inequalities.

## 2. Primitive kernels and quantitative rank

Let `D` be the oriented path incidence matrix, `(Dtheta)_i=theta_i-theta_{i+1}`. The transformation

\[
x\longmapsto (\theta,d,r^b,r^m)
\tag{R2}
\]

has the integer inverse

\[
\psi=\theta-d,\qquad
\alpha^b=D\theta-r^b,\qquad
\alpha^m=D\theta-Dd-r^m.
\tag{R3}
\]

Both compositions are the identity over the integers, so this is a torus automorphism, not just a real invertible change of variables. Counting the squared coefficients in its inverse gives `n+2n+3(n-1)+5(n-1)=11n-8`, agreeing with the draft.

Setting any selected residual coordinates to zero in (R2) leaves a product torus in the other coordinates. In particular,

\[
M_s=\ker(B_1,\ldots,B_s)
\tag{R4}
\]

is connected, and `B_s:M_{s-1}->T^{m_s}` is onto with connected kernel `M_s`. This proves the requisite lattice primitivity. Real row rank alone would not prove it.

There are also elementary bounds that make the finite-dimensional admissibility quantitative. Set `theta=0` in (R3) and denote the resulting right inverse of the full residual matrix by `H`. Then `BH=I`. Since `||D|| <= 2`,

\[
\|H(d,r^b,r^m)\|^2
=\|d\|^2+\|r^b\|^2+\|Dd+r^m\|^2
\leq9\|d\|^2+\|r^b\|^2+2\|r^m\|^2
\leq9\|(d,r^b,r^m)\|^2.
\tag{R5}
\]

Also,

\[
\|Bx\|^2
=\|\theta-\psi\|^2+\|D\theta-\alpha^b\|^2
 +\|D\psi-\alpha^m\|^2
\leq10\|x\|^2.
\tag{R6}
\]

For a vector supported only in residual block `s`, `H` maps it into `W_{s-1}=T_0M_{s-1}` and is a right inverse of `B_s` there. The minimum-norm right inverse

\[
C_s=B_sP_{s-1}B_s^T,\qquad
R_s=P_{s-1}B_s^TC_s^{-1}
\tag{R7}
\]

therefore satisfies `||R_s|| <= 3`. Since `R_s^T R_s=C_s^{-1}`, while `||C_s|| <= ||B_s||^2 <= 10`,

\[
\frac19 I\preceq C_s\preceq10I.
\tag{R8}
\]

This holds for every stage and every `n=2^L`; no favorable numerical rank is assumed. These constants concern geometry, not the interaction-weight spectrum or dynamical separation.

## 3. Borel bijections, Haar reference, and faces

The projection update is

\[
P_s=P_{s-1}-R_sB_sP_{s-1}.
\tag{R9}
\]

The matrix subtracted is the orthogonal projection in `W_{s-1}` onto the orthogonal complement of `W_s`. Consequently `P_s` is precisely the projection onto `W_s`, `B_sR_s=I`, earlier row blocks annihilate `R_s`, and the ranges of the `R_s` are mutually orthogonal.

For each `y_{s-1} in M_{s-1}`, take the unique half-open representative

\[
z_s=\operatorname{pr}(B_sy_{s-1}),\qquad
y_s=y_{s-1}-R_sz_s\pmod{2\pi}.
\tag{R10}
\]

The earlier rows vanish on both terms and `B_sy_s=0` modulo `2pi`, so `y_s in M_s`. Conversely, given any `y_s in M_s` and any `z_s in [-pi,pi)^{m_s}`, the point `y_{s-1}=y_s+R_sz_s` satisfies `pr(B_sy_{s-1})=z_s`. This proves surjectivity and injectivity, including boundary conventions. Every operation is Borel. Iteration gives

\[
x=y_s+\sum_{j\leq s}R_jz_j\pmod{2\pi}.
\tag{R11}
\]

The reference identity can be proved directly without assuming a product topology. Haar measure on `M_{s-1}` pushes forward to Haar on its quotient `T^{m_s}`. A translated normalized Haar measure on the kernel is the conditional measure on each fiber. The translation by `-R_sz_s` takes each such measure to the same normalized Haar measure on `M_s`. Thus

\[
\nu_{s-1}(dy_{s-1})=\nu_s(dy_s)\frac{dz_s}{(2\pi)^{m_s}}.
\tag{R12}
\]

Equivalently, the right side transported by the inverse in (R10) is translation invariant and normalized, which characterizes Haar. This justifies the normalizing factor without confusing Riemannian volume constants with unnormalized ambient Lebesgue measures.

Off the cuts, orthogonality gives

\[
|dx|^2=|dy_L|^2+\sum_{s=1}^L dz_s^TC_s^{-1}dz_s.
\tag{R13}
\]

At a face change `z_s^+=z_s^- -2pi e_j`, equality of the represented microscopic point requires `y_s^+=y_s^-+2pi R_se_j`. This point lies in `M_s` as a torus element: its current residual is an integer multiple of `2pi` and every earlier residual vanishes. It need not be represented by a vector in `W_s` before lattice reduction.

An explicit recursion removes any ambiguity in the later carries. Given a torus displacement `Delta_{t-1}` of `y_{t-1}`, choose any real representative, and define

\[
z_t'=\operatorname{pr}(z_t+B_t\Delta_{t-1}),\qquad
a_t=z_t+B_t\Delta_{t-1}-z_t'\in2\pi\mathbb Z^{m_t},
\]

\[
\Delta_t=\Delta_{t-1}-R_t(z_t'-z_t)
 =\Delta_{t-1}-R_tB_t\Delta_{t-1}+R_ta_t
 \pmod{2\pi}.
\tag{R14}
\]

Start this at `Delta_s=2pi R_s e_j`. Integer row matrices make the resulting torus point independent of the chosen representative. This reproduces the draft's recursive prescription and retains all carries. Smooth test functions of `x` obey the resulting matching conditions. A smooth function solely of `y_s` need not pull back to a continuous function of `x`, so these identities do not remove current corrections in projected dynamics.

The dimension is `dim M_s=n+2(n/2^s-1)`. For `n=8`, the dimensions are `30,14,10,8`. The connected components of the graph containing edges through level `s` are its dyadic blocks, with counts `8,4,2,1`. These are the candidate partitions associated with the flag; actual coalescence at distinct times is an additional dynamical statement.

The passive gauge translation lies in `M_L`, fixes every `z_s`, and translates every `y_s` by the same group element. Hence these retentions and their measure constructions are equivariant. No quotient by the remaining node origins is taken, and no base transport is involved.

## 4. Smooth integration closure and normalized kernels

Let `p_{s-1}` be strictly positive and smooth on the compact torus `M_{s-1}` and define

\[
p_s(y)=\int p_{s-1}(y+R_sz)\frac{dz}{(2\pi)^{m_s}}.
\tag{R15}
\]

The positive minimum and finite maximum of `p_{s-1}` bound `p_s` from below and above. Equation (R12) proves normalization. For a tangent direction `v in W_s`, translations by `y` are smooth and the compact domain supplies a uniform integrable bound for every derivative. Thus

\[
D_vp_s(y)=\int D_vp_{s-1}(y+R_sz)\frac{dz}{(2\pi)^{m_s}},
\tag{R16}
\]

and repeated differentiation proves smoothness of every order. The same calculation in overlapping charts gives the same derivative, because it differentiates a function on `M_s`; equivalently, its lattice is already a period lattice for `p_{s-1}`. The cuts belong to the integration coordinates and do not create a moving integration domain when `y` varies on `M_s`.

The conditional density

\[
g_s(z\mid y)=\frac{p_{s-1}(y+R_sz)}{p_s(y)}
\tag{R17}
\]

is positive, normalized, and a specified version at every `y`. Apply this separately to the generative density and the optimizing density. Keeping the same symbols as the draft, the resulting downward kernels are `G_s` and `kappa_s`. Fubini for the finite compact integrals proves composition in either family. For arbitrary physical probability kernels, Tonelli applied to their nonnegative set probabilities proves normalization and composition. Such kernels need only be measurable; a smoothness claim for them would need its own assumptions.

For `U_0=U-Td^ev`, `T>0`, and `0<a<1`, the stated strict coefficient inequality gives positive original coefficients, although compactness alone would already ensure finite positive normalization for any finite coefficients. The parent class is closed as a class of complete smooth densities and normalized kernels. It is not claimed to preserve a cosine, Gaussian, or pairwise-only ansatz.

## 5. Physical evaluator and conditional VFE identity

Fix one node and let `delta=u-v`, `a in (0,1)`. The generative reference is `P(dzeta,dk)=N(v,aI)(dzeta)N(zeta,(1-a)I)(dk)`. The proposed coupling `S_*` has the same first marginal and conditional `N(zeta+delta,(1-a)I)` for `k`. Its second marginal is `N(u,I)`. Its log likelihood ratio is

\[
\log\frac{dS_*}{dP}(\zeta,k)
=\frac{\delta\cdot(k-\zeta)}{1-a}
-\frac{|\delta|^2}{2(1-a)}.
\tag{R18}
\]

For every joint coupling `S` with these two Gaussian marginals, the right side is integrable and has expectation `|delta|^2/[2(1-a)]`, because `E_S(k-zeta)=delta`. The density-ratio identity therefore yields

\[
D(S\Vert P)=D(S\Vert S_*)+\frac{|\delta|^2}{2(1-a)}.
\tag{R19}
\]

If `S` is singular, both relative entropies are infinite, since `P` and `S_*` have everywhere positive mutually equivalent densities; the same extended-value conclusion holds. Otherwise the finite affine expectation in (R18) makes the displayed subtraction legitimate. Since `|u-v|^2=2(1-cos(theta-psi))`, the exact minimum is `V(d)/(1-a)`. The product version of (R18) proves the sum identity over all couplings with the prescribed per-node marginals, including couplings that correlate nodes. The product optimizing coupling attains the minimum. Thus no independence assumption about arbitrary candidate inner couplings is hidden in the minimization.

For any outer recognition `Q`, the augmented joint KL splits into `D(Q||P_0)` plus the expectation of the inner KL. Restricting to the optimizing inner family gives

\[
\mathcal F(Q)=T D(Q\Vert P_0)+T E_Qd^{\rm ev}
=T D(Q\Vert\pi)-T\log c,
\qquad c=E_{P_0}e^{-d^{\rm ev}}>0.
\tag{R20}
\]

The observation is the declared singleton, so evidence is one; `c` is the variational tilt normalizer and is not relabeled as that observational evidence. Since `d^ev >= 0`, `0<c<=1`.

The full retained generative physical law is the original `n`-node model-presentation law mixed by the composed `G_s`, followed by the common original evaluator `E(dk|zeta)`. The evaluator has no dependence on the eliminated configuration or the recognition law once `zeta` is given, so pulling it outside the mixture is exact. The retained optimizing recognition instead uses the composed `kappa_s` and the original optimizing correlated inner kernel. Mixing generally creates non-Gaussian and correlated laws; these are included in the retained class.

Let `P_s` and `pi_s` be the pushforwards and write `Y_s` for the retained state. The tilt identity gives

\[
\pi_s(dy)=c^{-1}h_s(y)P_s(dy),\qquad
h_s(y)=E_{P_0}[e^{-d^{\rm ev}}\mid Y_s=y],\qquad d_s=-\log h_s.
\tag{R21}
\]

The positive conditional densities in (R17) fix the versions everywhere. Furthermore `h_s=E_{G_s}(h_{s-1}|Y_s)` by the tower property, and `0<h_s<=1`. This is the exact inherited scalar cost, with no replacement of a prior conditional by an optimizer conditional.

For finite `D(Q||pi)`, factor its density ratio into the retained ratio and the conditional ratios in the Borel coordinates (R11). Integrating the logarithm yields

\[
D(Q\Vert\pi)=D(Q_s\Vert\pi_s)
 +\sum_{j=1}^s E_{Q_j}D(Q_{j-1}(\cdot\mid Y_j)\Vert\kappa_j(\cdot\mid Y_j)).
\tag{R22}
\]

For completeness, this is also a nonnegative extended-value identity. The negative part of the integrand `r log r` relative to a probability reference is bounded in integral by `1/e`. The retained and conditional likelihood ratios satisfy the same bound, with the conditional reference integrated against `Q_j`. Consequently no negative infinite term occurs when integrating the logarithmic factorization, and the identity extends to infinite relative entropy by integrating the positive parts monotonically. On the smooth-positive compact preparations every term is finite. Multiplication by `T` and use of (R20) prove the draft's exact VFE formula. The optimizing conditional lift attains its infimum at fixed `Q_s`. The statement is about the declared augmented family, not an arbitrary new physical-marginal ELBO.

## 6. The force projection is necessary

Let `F_{s-1}=-T log p_{s-1}`, `F_s=-T log p_s`, and define the preceding drift `b_{s-1}=-grad_{M_{s-1}}F_{s-1}`. Equation (R16) proves the exact identity

\[
-\operatorname{grad}_{M_s}F_s(y)
=\int P_s b_{s-1}(y+R_sz)\kappa_s(dz\mid y).
\tag{R23}
\]

Here `kappa_s` is formed from `p_{s-1}`, and `P_s` means the projection from `W_{s-1}` to `W_s`. The normal part of the full average is generally nonzero. In the normal coordinates it is proportional to the integral of `partial_z p_{s-1}`, whose endpoints are not values at the same retained point because of (R14).

There is an explicit counterexample within the smooth-positive, gauge-invariant class at `n=8`. Let `k` denote the ambient integer covector for the weak belief residual on edge `(2,3)`:

\[
k\cdot x=\theta_2-\theta_3-\alpha_2^b,\qquad
p_0(x)=1+\epsilon\sin(k\cdot x),\qquad0<\epsilon<1.
\tag{R24}
\]

This is normalized, smooth, positive, and gauge invariant. For a level-one dyad `(i,i+1)`, minimization of the Euclidean norm at fixed `(d_i,d_{i+1},r_i^b,r_i^m)` gives

\[
\theta_i=\frac{d_i}{2}+\frac{r_i^b+r_i^m}{6},\qquad
\theta_{i+1}=\frac{d_{i+1}}2-\frac{r_i^b+r_i^m}{6}.
\tag{R25}
\]

The minimum has zero mean of the two common node coordinates; substitution in the four constraints verifies the displayed right-inverse rows. Therefore `k^TR_1` has coefficients `1/2,-1/2` on `d_2,d_3`, and four coefficients `-1/6` on the belief/model residuals of edges `(1,2)` and `(3,4)`, with all other coefficients zero. Integration of the Fourier character over the fiber cube gives

\[
\phi=\left(\frac2\pi\right)^2\left(\frac3\pi\right)^4
=\frac{324}{\pi^6}>0,\qquad
p_1(y)=1+\epsilon\phi\sin(k\cdot y).
\tag{R26}
\]

At `y=0`, cancellation of the density in the conditional average gives

\[
E_{\kappa_1}[b_0\mid y=0]=T\epsilon\phi k,\qquad
b_1(0)=T\epsilon\phi P_1k.
\tag{R27}
\]

But `B_1k` is nonzero (its `d_2,d_3` entries are `1,-1`), so `P_1k != k`. The full average and the parent force differ. This refutes only the literal unprojected reading of the sentence after draft equation (15), not the normalized integration construction or its displayed generator. Replace that sentence by (R23), or by “Its force equals the conditional average of the retained interior force.”

The generator `T Delta_{M_s}-grad F_s dot grad` is otherwise well defined on the smooth compact torus and uses the restricted metric (R13). Integration by parts with `p_s` gives reversibility, and the smooth bounded coefficients give its global diffusion. This is the autonomous comparison process. No graph of a nonlinear conditional minimizer has been identified with `M_s`; hence (R13) is not an unproved identification with PIFB2's slow-manifold graph metric. No force approximation or Borel path closure follows from reversibility alone.

## 7. Global triangular barrier and an explicit tail estimate

At stage `s`, stack the eliminated coordinates into `z` of dimension `q_s=sum_{j<=s}m_j`, and let `T_s` have blocks `B_iR_j` for `j<=i<=s`. Since the later right inverses are annihilated by earlier rows,

\[
t=(B_1x,\ldots,B_sx)=T_sz\pmod{2\pi},
\tag{R28}
\]

where `T_s` is block lower triangular with identity diagonal. It is legitimate to use the real vector `T_sz` inside the cosine. Define `A_s=|T_s-I|` entrywise and `delta_i=dist((T_sz)_i,2pi Z)`. Distance to a closed set is 1-Lipschitz, and for every principal coordinate `z_i in [-pi,pi)` its distance to `2pi Z` is exactly `|z_i|`. Hence, coordinatewise,

\[
|z|\leq\delta+A_s|z|,\qquad
|z|\leq (I-A_s)^{-1}\delta.
\tag{R29}
\]

The second inequality follows by substitution exactly `s` times, because `A_s^s=0`; no contraction assumption on `A_s` is needed. Let `K_s=||(I-A_s)^{-1}||`. On `[-pi,pi]`, `1-cos u>=2u^2/pi^2`, so

\[
\sum_i[1-\cos((T_sz)_i)]
\geq\frac2{\pi^2}\|\delta\|^2
\geq\frac2{\pi^2K_s^2}\|z\|^2.
\tag{R30}
\]

This proves the claimed global inequality, including near noncentral wrapping surfaces. Its zero is uniquely `z=0` on the principal cube. The proof would fail if principal representatives were replaced by arbitrary real lifts without recording their integer shifts.

One explicit depth dependence follows from (R5)–(R8). The block right inverse with columns `(R_1,...,R_s)` has norm at most `3`, because its ranges are orthogonal. Thus `||T_s||<=3sqrt(10)`. Entrywise absolute value preserves the Frobenius norm, so

\[
\|A_s\|\leq\sqrt{q_s}(3\sqrt{10}+1),\qquad
K_s\leq\sum_{j=0}^{s-1}
 [\sqrt{q_s}(3\sqrt{10}+1)]^j.
\tag{R31}
\]

Every constant is explicit and finite for each prescribed `L`. This conservative estimate is sufficient for geometric admissibility, with no assertion of an infinite-depth bound.

For clarity about the word “tail,” (R30) alone is an energy barrier. An actual conditional probability bound must also bound the denominator and remaining terms. Here is a valid, possibly crude bound for the specified cosine energy. Write `U=U_el(z)+U_rem(y,z)` and let `J_min` and `J_max` be the smallest and largest eliminated coefficients. Let `D_s` bound the oscillation of `U_rem(y,.)` uniformly in `y`; the valid choice `D_s=2 sum_remaining J_i` includes both channels. Set

\[
\rho_* =\min\left\{\pi,\sqrt{\frac{T}{q_sJ_{\max}\|T_s\|^2}}\right\},\qquad
\beta_s=\frac{2J_{\min}}{\pi^2K_s^2}.
\tag{R32}
\]

On the box `|z_i|<=rho_*`, the inequality `1-cos u<=u^2/2` gives `U_el<=T/2`. The normalized reference mass of this box is `(rho_*/pi)^{q_s}`. Combining that denominator lower bound with `U_el>=beta_s|z|^2` gives, for every retained `y` and `r>=0`,

\[
\kappa_{\leq s}(\|z\|\geq r\mid y)
\leq\min\left\{1,
e^{1/2}\left(\frac\pi{\rho_*}\right)^{q_s}
\exp\left(\frac{D_s-\beta_sr^2}{T}\right)\right\}.
\tag{R33}
\]

Here `kappa_{<=s}` is the composed optimizing conditional. Replacing eliminated coefficients by their positive generative values gives the analogous prior bound. This estimate explicitly shows the remaining interaction penalty; it does not prove a useful low-temperature error bound in the dynamics regime without a parameter choice. Local convexity, direct conditional KL control, and exit probabilities remain separate obligations.

## 8. Attack record and scope of the result

The attack portfolio concerns the exact-law dependency only. Each attack is bound to the inspected draft hash above, and its response is a derivation in this report. These are mathematical dispositions, not ledger closure states.

| ID | Affected statement | Attack | Disposition and evidence |
| --- | --- | --- | --- |
| GEO-01 | Draft (7)–(10) | Real rank could conceal disconnected kernels or lost finite sheets. | Rejected: the integer automorphism (R2)–(R3) proves connected kernels and surjectivity at every level. |
| GEO-02 | Draft (9)–(11) | Rational normal directions might not define invertible global coordinates. | Rejected: the Borel inverse in (R10)–(R11), rather than a torus map in the normal variables, is exact. |
| GEO-03 | Draft face recursion | A face translation may leave the real tangent space or acquire unrecorded later carries. | Rejected: (R14) works with torus points and explicitly retains every integer carry. |
| GEO-04 | Draft (12) | Cuts could spoil smoothness or normalization of the parent density. | Rejected: translation in the retained group keeps the integration domain fixed; (R12), (R15), and (R16) prove the assertions. |
| GEO-05 | Draft (4)–(6), (13)–(14) | Correlations, evaluator mixing, or a prior/optimizer substitution could invalidate VFE closure. | Rejected: (R18)–(R22) prove the constrained coupling and full conditional identities with distinct `G_s` and `kappa_s`. |
| GEO-06 | Sentence after draft (15) | Full conditional force averaging can retain a nonzero normal component. | Sustained for the literal unprojected reading: the gauge-invariant `n=8` counterexample (R24)–(R27). Correct it to (R23). |
| GEO-07 | Draft (16) | Wrapped residuals might have nonzero zeros on the principal fiber cube. | Rejected: the distance inequality and finite nilpotent inverse in (R29)–(R30) control every wrap. |
| GEO-08 | Exact law component versus frozen full target | Integration closure and candidate block counts might be used as proof of actual successive formations. | Unresolved outside this assignment: the law construction supplies neither episodes nor the required quantitative conditional-KL and dynamical comparisons. |

The independent method was an integer-coordinate reconstruction, orthogonal right-inverse calculation, compact-kernel integration argument, affine Gaussian density-ratio calculation, KL factorization, and a principal-distance barrier argument. These steps use no search prior or presumed existence of the desired dynamical hierarchy. Removing that premise changes none of (R1)–(R33); it also does not fill the dynamics gap.

Only read-only source inspection, Git-status inspection, file hashes, and writing this report ran. No simulation, symbolic package, test suite, GPU task, tamper scenario, scientific rerun, publication, or vault edit was performed. The report itself contains the analytical evidence; no numerical agreement is used as proof.

The strongest supported result is exact reusable finite-depth law and geometry closure with the projected force identity (R23), explicit rank constants (R8), and the finite-depth fiber barrier (R30)–(R31). The minimal correction to this component is the force sentence after draft (15). The remaining full-target obligation is a common nonempty parameter and initial-law regime giving actual successive nonlinear formations and quantitative conditional-VFE, force, path, and exceptional-event propagation through every admitted finite level. The next action that changes that answer is to join an explicit dynamical proof to these same retained maps and conditionals, retaining every face correction.

## 9. Bounded correction verification

Later on September 12, 2026, the corrected `finite-depth-parent-class.md` was read at SHA-256 `4cef6c32eea460b787fdf70b22f487d051a27042181b7563e89556219726941d`. Its paragraph immediately after equation (15) now states `b_s(y)=E_{kappa_s}[P_s b_{s-1}(y+R_s z)]`, identifies `P_s` as the tangential projection in its prose, and explains why the averaged normal derivative need not vanish. This is exactly (R23), derived by differentiating (R15) in `W_s`; the placement after the displayed parent generator makes the formula's referent explicit.

GEO-06 remains a sustained attack on the originally inspected unprojected sentence, with counterexample (R24)–(R27). That local defect is corrected in the revision identified above, and the earlier statement that its repair remains necessary is superseded by this addendum. This was only a check of the corrected paragraph and its hash, not a new review of the full draft or an adjudication of the developing nonlinear dynamics argument. The unresolved full-target scope stated above is unchanged by this bounded verification.
