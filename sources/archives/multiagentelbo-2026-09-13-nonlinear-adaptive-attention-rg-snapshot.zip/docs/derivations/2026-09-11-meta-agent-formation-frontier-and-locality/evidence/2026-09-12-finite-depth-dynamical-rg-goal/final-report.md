<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-d15c9f5a5a810b76900ea496929ff4a5c6832d4553a379d5da43ce2f1f7e3bd9","target_digest":"d15c9f5a5a810b76900ea496929ff4a5c6832d4553a379d5da43ce2f1f7e3bd9"} -->
# Rigorous theory search report

## Frozen contract

For each prescribed finite integer L >= 3, construct a nonempty finite compact two-channel law/link family and an open positive-temperature parameter and smooth positive initial-law regime supporting L successive coalescence levels under one common microscopic kinetic rule. Exhibit L=3 explicitly, with agent counts 8 -> 4 -> 2 -> 1 or another explicitly equivalent three-level interacting construction. State and prove a reusable exact parent construction and quantitative finite-L error bounds, including the dependence of its admissibility constants on L. No uniform infinite-depth limit is requested.

## Terminal status

COMPLETE_AFFIRMATIVE for the finite target.

## Certificate

Target claim `target`, under modeling postulates A1-A4, is established by the seven written proof artifacts listed in claim-ledger.json. The target depends on all six component claims in dependency-dag.json.

## Strongest verified result

For every prescribed finite L>=3, one open positive-temperature compact nonlinear family has L successive coalescence levels, exact normalized marked parents, inherited dynamics and controlled conditional VFE and path errors; L=3 gives 8 -> 4 -> 2 -> 1.

## Dependency closure

Exact geometry and laws, recursive quantitative admissibility, actual formation, conditional entropy, dynamical errors and one common open regime each have a recorded analytical derivation. The independent reconstruction checks their join.

## Independent reconstruction

See proofs/finite-depth-independent-reconstruction.md, supported by the separate geometry and nonlinear checks. Agreement is not evidence; the displayed proofs and repaired counterexamples are.

## Oracle erasure

The independent reconstruction removes the favorable prior and checks every load-bearing premise. No assumed formation, parent admissibility or target truth remains in the argument. The structural validator cannot detect paraphrased prior use or establish mathematics.

## Unresolved obligations

None within the frozen finite-depth target.

## Scope and limitations

Each finite L has its own parameter neighborhood and constants; no uniform infinite-depth statement. Fixed dyadic path weights, angular group, law covariances and common kinetic metric are supplied microscopic inputs, not learned structure. Actual nonlinear parent laws and conditional identities are exact; dynamical reduction is finite-horizon and probabilistic with explicit compact corrections. Parent agreement is an inherited expected edge-KL statistic; no equality with KL between full correlated parent mixtures is asserted. No general gauge group, loop sector, physical-clock identity, base transport or numerical simulation claim. This is an analytical construction, with no new trajectory simulation, production-code change, full suite, GPU run, Lean proof, tamper check, vault ingest or Git publication.
