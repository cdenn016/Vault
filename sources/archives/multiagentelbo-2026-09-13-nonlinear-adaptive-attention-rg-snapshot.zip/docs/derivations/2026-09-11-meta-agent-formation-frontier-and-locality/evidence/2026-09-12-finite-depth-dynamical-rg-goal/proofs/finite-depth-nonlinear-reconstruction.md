# Independent reconstruction of the finite-depth nonlinear comparison

September 12, 2026. This report reconstructs Sections 1–5 of [finite-depth-nonlinear-comparison.md](finite-depth-nonlinear-comparison.md) against the frozen [finite-depth contract](evidence/2026-09-12-finite-depth-dynamical-rg-goal/problem-contract.json), contract digest `d15c9f5a5a810b76900ea496929ff4a5c6832d4553a379d5da43ce2f1f7e3bd9`. The nonlinear comparison reconstructs after making its Gaussian additive constant explicit, supplying the compact Gaussian pushforward and localized path-entropy arguments below, and adding an open initial-law neighborhood. The Gaussian formation estimates remain an explicit external premise of this bounded reconstruction.

The argument is analytical. No numerical agreement, reviewer verdict, or presumed existence of a hierarchy is used as a premise. Exact law identities, asymptotic estimates, and the remaining formation premise are distinguished throughout.

## 1. Claim, domains, assumptions, and inspected sources

Fix an arbitrary finite integer `L>=3`, let `n=2^L`, and use the compact two-channel path family, residual matrix `B`, nested connected subgroups `M_a`, Borel retentions `mathcal C_a`, normalized Haar measures `nu_a`, and complete generative and optimizing kernels in [finite-depth-parent-class.md](finite-depth-parent-class.md). The microscopic energy is `U=sum_i D_ii(1-cos(Bx)_i)`, where the positive weights obey `J_1>=...>=J_L`. The configuration dimension is `4n-2`, the residual dimension is `m=3n-2`, and every node and link has the same unit microscopic mobility. All statements concern one base point.

The user supplies the two law channels, independent dynamic links, common microscopic kinetics, normalized physical model, permission to specialize to a finite family, and finite-depth target. The path, angular group, fixed heterogeneous weights, common flat metric, and prepared Gaussian normal law are declared modeling choices in the inspected construction. This report introduces a small relative-uniform neighborhood of that preparation; it does not introduce a parent mobility, merger schedule, global convexity assumption, or exact Markov-closure assumption.

For each fixed `L`, fixed positive `J`, fixed `R>1`, and fixed `H<infinity`, let `A` decrease to zero and set

\[
T=A^2/R^2,\qquad b=A^{9/10}.
\tag{N1}
\]

There is an `A_*>0`, depending on these fixed data and their finite geometry, such that every result below holds for `0<A<A_*`, uniformly over all finitely many stages and `0<=t<=H`. The comparison is between the actual compact nonlinear diffusion at each stage, initialized by the actual Borel pushforward, and a wrapped Gaussian reference obtained from an unwrapped Ornstein–Uhlenbeck process. Equality of normalized parent laws and conditional VFE identities is exact. Dynamical equality is replaced by explicit finite-horizon error and exceptional-event bounds. No uniform infinite-depth or all-time statement is claimed.

The source consultation included the current `docs/STATUS.md`, [nonlinear-two-stage-completion.md](nonlinear-two-stage-completion.md), Sections 1 and 4–5, [nonlinear-parent-laws-and-geometry.md](nonlinear-parent-laws-and-geometry.md), Sections 1–6, and [finite-depth-geometry-reconstruction.md](finite-depth-geometry-reconstruction.md). The Research wiki pages [Coarse Graining](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Coarse Graining.md>) and [Staged hierarchy formation and RG composability](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Staged hierarchy formation and RG composability.md>) preserve the distinction between exact marginalization and dynamical closure. The live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) passages at `eq:rg_internal_hessian`, `eq:rg_reduced_hessian`, `eq:rg_slow_graph_metric`, and `eq:rg_schur_flow` explicitly separate stiffness, covariance corrections, graph versus quotient metrics, and force accuracy. Those passages motivate the interfaces; their status labels do not prove them.

Initial inspected SHA-256 values were:

| Source | SHA-256 |
| --- | --- |
| Frozen problem-contract JSON | `5ae6b7900c0df32b82e2054555b8dcd4594f2454413929b14ea4c4de6ae6a91a` |
| finite-depth-parent-class.md | `4cef6c32eea460b787fdf70b22f487d051a27042181b7563e89556219726941d` |
| finite-depth-nonlinear-comparison.md | `0db253ad3ea7c631d9c23ac5b0242a231c6bbb5826fb61b1b72360c9ad83c6d3` |
| finite-depth-geometry-reconstruction.md | `6c4f0e5d4a629c5bbe326a3ebfc77cf66c79fdc5c136cfb5536867edab0798e7` |
| nonlinear-two-stage-completion.md | `4f3d840dc8b078ea1f764fc39c33685b561ec343aada97a3c092164c475c27f3` |
| nonlinear-parent-laws-and-geometry.md | `07691fda6228f11791e89329fe7ac3754ad0cadc1f17c39a867fee229ebdf7be` |
| Live PIFB2.tex | `f80e6dabd9e5485649066e227e80beff1dd2b1082cf786bcdaeedb8cbd080ec4` |

These record the inspected inputs, not mathematical acceptance conditions. A subsequent direct read confirmed the corrected Gaussian-normalizer wording in comparison-file revision `ccdc2ed9ed499b794aea7bd0ad68cee9125ee3b21e7a3f1cdb56403fd840cbe8`. The attack dispositions below are against the initial inspected text and the reconstructed statements here; this observation does not rebind a ledger.

## 2. Quotient lattices, Haar roots, and local coordinates

Write `K=ker B` for the real kernel when discussing tangent spaces and for its connected torus image when discussing groups. Let `N=K^perp`, `W_a=T_0M_a`, and `N_a=W_a intersect N`. The integer coordinate transformation

\[
x\longmapsto(\theta,d,r^b,r^m)
\]

has the integer inverse

\[
\psi=\theta-d,\quad
\alpha^b=D_{\rm path}\theta-r^b,\quad
\alpha^m=D_{\rm path}\theta-D_{\rm path}d-r^m.
\tag{N2}
\]

Consequently the residual kernels are connected, their period lattices are primitive, and `B_a:M_{a-1}->T^{m_a}` is onto with connected kernel. This is an integer statement, stronger than real row rank.

Every `W_a` and `K` is a rational subspace. Their orthogonal projections are rational matrices: a full-rank rational basis expresses each projection through the inverse of its rational Gram matrix. If `Lambda(W_a)=W_a intersect 2pi Z^{4n-2}`, the normal quotient is

\[
M_a/K\cong N_a/\Lambda_a,\qquad
\Lambda_a=\operatorname{Pr}_{N_a}\Lambda(W_a).
\tag{N3}
\]

The projected generators have a common finite rational denominator, so their group is discrete; their real span is `N_a`, so `Lambda_a` is a full lattice. There is no dense projected-lattice pathology. Haar measure along a `K` coset is independent of its chosen representative. Thus a normal law on (N3), together with Haar on each `K` coset, defines a unique `K`-invariant law without requiring a global orthogonal product of tori. At `a=L`, `N_L={0}` and the nominal final law is exactly Haar on `K`.

The right inverses and projections obey

\[
C_a=B_aP_{a-1}B_a^T,\quad
R_a=P_{a-1}B_a^TC_a^{-1},\quad
P_a=P_{a-1}-R_aB_aP_{a-1}.
\tag{N4}
\]

Their normal ranges are mutually orthogonal and `R_a^TR_a=C_a^{-1}`. A full residual right inverse obtained by setting `theta=0` in (N2) has norm at most `3`, while `||B||<=sqrt(10)`. Restriction gives

\[
\frac19 I\preceq C_a\preceq10I,\qquad \|R_a\|\le3.
\tag{N5}
\]

The Borel map uses `z_a=pr(B_a y_{a-1})` and `y_a=y_{a-1}-R_a z_a`. Its inverse is `y_{a-1}=y_a+R_a z_a`. Translating Haar conditionals on the kernel proves the exact reference identity

\[
\nu_{a-1}(dy_{a-1})=
\nu_a(dy_a)\frac{dz_a}{(2\pi)^{m_a}}.
\tag{N6}
\]

In particular each retention and every composition pushes normalized Haar to normalized Haar. Its face identifications remain those of the source. Choose `rho>0` smaller than the injectivity and Gaussian Voronoi radii of the finitely many normal quotient lattices, and small enough that all residuals appearing in the successive retentions remain strictly inside their principal intervals on the normal `4rho` ball. The retentions are then exactly the orthogonal projections in that ball. Along `K` they remain equivariant, so no bound on a free root Brownian lift is needed for this chart condition.

Let `H_0=B^T D B|N`. Then

\[
\frac{J_L}{9}I\preceq H_0\preceq10J_1I.
\tag{N7}
\]

At stage `a<L`, integrating the orthogonal Gaussian coordinates gives the positive Schur complement `H_a`. Equivalently, `H_a^{-1}` is the compression of `H_0^{-1}` to `N_a`, so (N7) also bounds every `H_a`. A restriction to any conditional fast subspace remains positive. These are elementary spectral bounds; no formation estimate is assumed here.

## 3. Exact parent integrals and their derivatives

The exact optimizer parent is obtained from the complete compact integral of `exp(-U/T)`, not by replacing `U` with a quadratic. Positivity and smoothness follow from its fixed compact fiber domain and differentiation under the integral. The parent force is the conditional average of the **projected** source force. Consequently it is globally bounded, independently of `T`, by `max|grad U|`. The same integral identity gives

\[
\nabla F_a=E_{\kappa}[\nabla_yU],\qquad
\nabla^2F_a=E_{\kappa}[\nabla_y^2U]
-T^{-1}\operatorname{Cov}_{\kappa}(\nabla_yU,\nabla_yU).
\tag{N8}
\]

All derivatives are in orthonormal retained directions. The covariance subtraction is retained.

At a cumulative stage write `x=y+sum_{j<=a}R_jz_j` and let `T_a` be the lower triangular residual matrix in these coordinates. Its diagonal blocks are identity. If `A_a=|T_a-I|` entrywise and `K_a=||(I-A_a)^{-1}||`, the distance inequality

\[
|z_i|\le\operatorname{dist}((T_az)_i,2\pi\mathbb Z)
+\sum_{j<i}|(T_a)_{ij}||z_j|
\]

and nilpotence of `A_a` imply

\[
\sum_{j\le a}J_j\sum_i[1-\cos(B_jx)_i]
\ge\frac{2J_a}{\pi^2K_a^2}|z|^2.
\tag{N9}
\]

This holds throughout the principal fiber cube, including wrapping regions. The eliminated-energy zero is unique there. If `q_a=sum_{j<=a}m_j`, an explicit finite depth bound is

\[
K_a\le\sum_{j=0}^{a-1}
\left[\sqrt{q_a}(3\sqrt{10}+1)\right]^j.
\tag{N10}
\]

For `|y|<=b`, integrate over a `z` ball of radius proportional to `sqrt(T/J_1)`. The full energy there is at most `C J_{a+1}b^2+CT`, with the remaining-energy term omitted when `a=L`. The conditional denominator is therefore at least

\[
c(T/J_1)^{q_a/2}\exp[-C J_{a+1}b^2/T].
\tag{N11}
\]

Outside `|z|<=Db`, (N9), nonnegativity of the remaining energy, and the finite cube volume bound the numerator by `C exp[-cJ_aD^2b^2/T]`. Choose the fixed `D` so that `cJ_aD^2>CJ_{a+1}+1`, and then enlarge it to contain twice the Gaussian conditional mean coefficient. This proves, uniformly in `|y|<=b`, a conditional tail bound `C T^{-p}exp(-c'b^2/T)`. All weights were fixed before taking `A` small. Thus the denominator in (N11) does not erase the exponent. Gaussian conditional tails obey the same bound by completing the square. Polynomial factors and derivative tails will be denoted

\[
E_A=C A^{-p}\exp(-c b^2/T),
\tag{N12}
\]

where the constants may be enlarged a finite number of times.

On the central fiber `|z|<=Db`, ordinary Taylor bounds for cosine give

\[
|U-U^G|\le Cb^4,\quad
|\nabla U-\nabla U^G|\le Cb^3,\quad
\|\nabla^2U-\nabla^2U^G\|\le Cb^2.
\tag{N13}
\]

It follows by comparing the two positive integrands and their normalizers that the conditional total variation and central conditional log-density error are bounded by

\[
\omega_A=C b^4/T+E_A.
\tag{N14}
\]

For the complete normalizer, the normal quotient has a unique zero at the identity and a positive energy gap outside any fixed neighborhood. In a sufficiently small fixed neighborhood, `U^G>=lambda|x|^2/2` and the quartic remainder is at most `lambda|x|^2/4`. The inequality

\[
|e^{-U/T}-e^{-U^G/T}|
\le C|x|^4T^{-1}e^{-c|x|^2/T}
\]

shows after `x=sqrt(T)u` that the relative normalizer error is `O(T)`. Its complement is exponentially small. This matches the product von Mises normalizers without appealing to an unexamined asymptotic formula. Local volume constants match because (N6) is the exact disintegration of normalized Haar; they cannot be discarded individually.

For precision `H_a` on `N_a`, the normalized wrapped Gaussian density is

\[
\pi_a^G(y)=\operatorname{covol}(\Lambda_a)
\frac{\sqrt{\det H_a}}{(2\pi T)^{d_a/2}}
\sum_{\ell\in\Lambda_a}
\exp[-(y+\ell)^TH_a(y+\ell)/(2T)].
\tag{N15}
\]

Therefore its free energy is `y^TH_ay/2+c_a(T)` plus exponentially small image corrections, where

\[
c_a(T)=\frac{d_aT}{2}\log(2\pi T)
-\frac T2\log\det H_a-T\log\operatorname{covol}(\Lambda_a).
\tag{N16}
\]

The initial comparison text omitted this additive constant when describing the raw free-energy difference; its derivative claims do not have that problem. The normalized density comparison does keep (N16). Equations (N11)–(N15) yield

\[
\left|\log\frac{\pi_a(y)}{\pi_a^G(y)}\right|
\le Cb^4/T+E_A,\qquad |y|\le b.
\tag{N17}
\]

For the force, the Gaussian conditional force integrand is linear with size `O(b)` on the central fiber. Its conditional-law change contributes `O(b omega_A)`, and the Taylor force remainder contributes `O(b^3)`. Thus

\[
|\nabla F_a(y)-H_ay|\le
C(b^3+b^5/T)+E_A=:d_A.
\tag{N18}
\]

For the Hessian, the direct Hessian remainder in (N8) is `O(b^2)`. A covariance cross term between an `O(b)` linear force and an `O(b^3)` remainder is `O(b^4)`. Changing the conditional law in the linear-force covariance costs `O(b^2 omega_A)`. Division by `T` gives

\[
\|\nabla^2F_a(y)-H_a\|\le
C(b^2+b^4/T+b^6/T^2)+E_A=:h_A.
\tag{N19}
\]

The noncentral nonlinear force is bounded; Gaussian first- and second-moment tails and every fixed inverse power of `T` are absorbed into (N12). At `a=0` the same bounds hold directly, and at `a=L` the normal statement is empty and the exact force on `K` is zero. With (N1),

\[
d_A\le CA^{5/2}+E_A,\quad
h_A\le CA^{7/5}+E_A,\quad
b^4/T=R^2A^{8/5}.
\tag{N20}
\]

This reconstruction uses cumulative integrals of the original energy. It incurs no additional inverse-temperature factor merely because another stage is named.

## 4. A central comparison for the actual Borel Gaussian push

This lemma is needed separately from total variation. Let `Z` on `N_a` be Gaussian with mean `mu=O(A)` and covariance `T H_a^{-1}`, and let `g` be its wrapped density with Haar on `K` cosets. Let `g_s^B` be its actual pushforward by `mathcal C_{a:s}`, and let `hat g_s` be the wrapped orthogonal Gaussian marginal. Then, uniformly for `|y|<=b`,

\[
\left|\log\frac{g_s^B(y)}{\widehat g_s(y)}\right|
\le C A^{-p}e^{-c/T}.
\tag{N21}
\]

To prove this, split the unwrapped Gaussian into the good submeasure `|Z|<rho` and its complement, with `rho` fixed as in Section 2. The two maps agree exactly on the good submeasure. Periodizing the bad submeasure gives a compact density bounded everywhere by

\[
C T^{-p}e^{-c/T}.
\tag{N22}
\]

Indeed `|mu|<rho/2` for small `A`; factor a fixed `exp(-c rho^2/T)` out of the lattice Gaussian sum over `|z|>=rho`, and bound the remaining, wider Gaussian sum uniformly on a compact fundamental domain. Lattice discreteness makes that sum uniformly bounded for `0<T<=T_0`. By (N6), the actual Borel push of a density bounded by (N22) is still bounded by (N22). No fold multiplicity can amplify it.

For the orthogonal push of the bad submeasure, complete the square at a retained normal value `y`. The conditional mean of the eliminated coordinates is a fixed linear function of `y` and `mu`, hence is smaller than `rho/2` for `|y|<=b` and small `A`. Its fixed positive Gaussian conditional covariance times `T` gives a tail `exp(-c/T)` outside the good ball. Nonzero retained lattice images have a fixed positive distance from zero and satisfy the same bound. Thus the other bad pushed density is also bounded by (N22) on `|y|<=b`.

The full retained Gaussian density satisfies

\[
\widehat g_s(y)\ge cT^p\exp[-C(|y|+|\mu|)^2/T]
\ge cT^p e^{-Cb^2/T}.
\tag{N23}
\]

Dividing the two absolute bad-density bounds by (N23) gives `CT^{-p}exp[-(c-Cb^2)/T]`. Since `b->0`, the exponent is at most `-c/(2T)` for small `A`. The logarithmic bound (N21) follows. This proves the central relative comparison without assuming that the global Borel push is an orthogonal Gaussian marginal. It applies to centered and shifted Gaussian laws and to any pair `a<s`.

## 5. Compact initialization, lifting, and full path entropy

Choose `v_0 in N` with the residuals specified in the source. Let `Q_0` be the wrapped Gaussian with normal mean `A v_0`, covariance `T H_0^{-1}`, and Haar along `K` cosets. Let `Q_{a,0}` be its actual Borel pushforward. The Gaussian comparator starts with the orthogonal normal marginal `G_{a,0}`. Under the common fine Gaussian coupling, their retained initial points agree whenever the fine normal sample lies in the fixed good ball. Hence

\[
\|Q_{a,0}-G_{a,0}\|_{\rm TV}\le Ce^{-c/T}.
\tag{N24}
\]

Both compact densities are at most `M=CT^{-p}`: for the actual one, integrate the bounded fine density using (N6). The Gaussian comparator is at least `cT^p e^{-C/T}` on its compact normal torus.

Here is the entropy step explicitly. For two densities `f,g<=M` on a probability reference, put `delta=TV(f,g)` and `r=min(f,g)`. Decompose them into the common part of mass `1-delta` and two residual densities of mass `delta`. Each normalized residual has entropy between zero and `log(M/delta)`. The entropy error in replacing a mixture entropy by its weighted component entropies lies between `-h(delta)` and zero, by the pointwise log-sum identity. It follows that

\[
\left|\int f\log f-\int g\log g\right|
\le\delta\log(M/\delta)+2h(\delta).
\tag{N25}
\]

Adding `|integral(f-g)log g|<=2delta||log g||_infinity` gives

\[
D(Q_{a,0}\Vert G_{a,0})\le
C A^{-p}e^{-c/A^2}=:e_{a,0}.
\tag{N26}
\]

This proves the needed entropy estimate for the actual initialization, rather than replacing rare mismatch by an unjustified KL bound.

Let `gamma` be the unwrapped Gaussian density and `g` its wrapped density. Lift an arbitrary compact initial density `q` using the Gaussian conditional distribution of its winding. In Euclidean coordinates this lifted density is exactly

\[
\widetilde q(x)=\gamma(x)\frac{q(\operatorname{wrap}x)}{g(\operatorname{wrap}x)}.
\tag{N27}
\]

Integrating over each lattice fiber proves both normalization and

\[
D(\widetilde q\Vert\gamma)=D(q\Vert g),\qquad
\|\widetilde q-\gamma\|_{\rm TV}=\|q-g\|_{\rm TV}.
\tag{N28}
\]

The conditional winding fourth moments are bounded uniformly in the compact point and small `T`. To see this, fix a bounded fundamental domain. For sufficiently large lattice vector `ell`, its Gaussian quadratic exponent exceeds the exponent of the zero image by at least `c|ell|^2`, uniformly in the domain and `mu=O(A)`. Divide by the zero-image lower bound in the conditional denominator. The finitely many remaining images have bounded coordinates, and the Gaussian sum of the distant images has uniformly finite fourth moment. This proves the assertion without retaining a useless `exp(C/T)` moment estimate.

Evolve (N27) with the full periodic nonlinear drift `b_a=-grad F_a`. Compare it with the unwrapped linear process

\[
dZ_t=-H_aZ_tdt+\sqrt{2T}dW_t,
\quad E Z_t=e^{-H_at}\operatorname{Pr}_{N_a}(A v_0),
\quad\operatorname{Cov}(Z_t)=T H_a^{-1}.
\tag{N29}
\]

Use a maximal coupling of the lifted initial laws and the same subsequent Brownian motion. Outside an event of probability (N24), the initial points agree. Until the nonlinear path exits `|x|<b`, variation of constants and `||e^{-H_at}||<=1` give

\[
\sup_{t\le H}|Y_t-Z_t|\le H d_A.
\tag{N30}
\]

For the Gaussian exit bound, diagonalize `H_a`. On a time interval of length at most `1/||H_a||`, a centered coordinate is the sum of its initial centered Gaussian and `sqrt(2T)e^{-lambda t}integral_0^t e^{lambda u}dW_u`. The latter martingale has quadratic variation at most `C/||H_a||` on that interval before multiplication by `2T`. The elementary reflection bound for Brownian motion, a Gaussian initial tail, and a union bound over coordinates and at most `1+H||H_a||` intervals give

\[
\Pr\left[\sup_{t\le H}|Z_t|>b/2\right]
\le C A^{-p}e^{-c b^2/T}.
\tag{N31}
\]

The deterministic mean is `O(A)=o(b)`. Since `H d_A=o(b)`, first exit in (N30) is impossible on the Gaussian good event for sufficiently small `A`. Therefore the actual nonlinear exit probability obeys (N31), with the exponentially smaller initialization error added. The process is not stopped or reflected in the asserted law.

The path-entropy upper bound used here is

\[
D(\mathcal P^N_{[0,H]}\Vert\mathcal P^G_{[0,H]})
\le e_{a,0}+\frac1{4T}
E_N\int_0^H|b_a(Y_t)+H_aY_t|^2dt.
\tag{N32}
\]

For a direct justification without assuming the unknown full-path entropy is finite, switch the nonlinear drift to the linear drift after the first exit from a radius-`j` Euclidean ball. The stopped drift difference is bounded. Its stochastic exponential has mean one, and integration of its log under the changed law gives the initial entropy plus `(4T)^{-1}` times the stopped quadratic drift energy. The switched law agrees with the actual nonlinear law up to that exit. As `j->infinity`, nonexplosion gives convergence of the switched path laws to the actual path law, while their stopped energies are bounded by the full energy on the right of (N32). Relative entropy is lower semicontinuous under that convergence: its variational formula is the supremum of continuous functionals `E_P f-log E_R e^f` for bounded continuous `f`. This proves (N32).

The factor is `1/(4T)` because the diffusion covariance is `2T I`. A primary reference for the density and entropy identity is [Christian Léonard, Girsanov theory under a finite entropy condition, Theorem 2.3](https://arxiv.org/pdf/1101.3958). That theorem states equality under uniqueness after finite entropy is established; the preceding stopped argument establishes the required finiteness here. The linear reference has a unique strong solution, and every stopped drift is bounded relative to it.

Inside the central chart the integrand in (N32) is at most `d_A^2`. Globally `b_a` is bounded uniformly in `T`, and `H_aY_t` grows linearly. The bounded drift, finite horizon, conditional-winding fourth moment, and Brownian fourth moment give a uniform bound on `E sup_{t<=H}|Y_t|^4`. Cauchy–Schwarz and (N31) consequently bound the energy on the exit event by another polynomial times `exp(-c b^2/T)`, after reducing `c`. Thus (N32), endpoint projection, and wrapping give

\[
\sup_{t\le H}D(Q_{a,t}\Vert G_{a,t})
\le C H d_A^2/T+E_A
\le C A^3+C A^{-p}e^{-cA^{-1/5}}=:e_A.
\tag{N33}
\]

All nominal laws are `K`-invariant, so their complete compact entropy equals their normal-quotient entropy; the Haar conditional along `K` cancels exactly. The root case has zero normal entropy. The free `K` Brownian motions can be coupled identically on the good lift event. Neither (N29) nor this proof asserts that a wrapped Ornstein–Uhlenbeck process is an autonomous torus diffusion.

## 6. Direct conditional-entropy comparison

For `a<s`, denote the actual map by `C=mathcal C_{a:s}` and define

\[
\Delta^N_{a:s}(t)=D(Q_{a,t}\Vert\pi_a)
-D(C_\#Q_{a,t}\Vert\pi_s).
\tag{N34}
\]

This is exactly the nonnegative conditional KL under the Borel disintegration. At a fixed time write `q=Q_{a,t}`, `g=G_{a,t}`, `q_s=C_#q`, and `g_s=C_#g`. Density factorization gives the exact identity

\[
\Delta^N_{a:s}
=D(q\Vert g)-D(q_s\Vert g_s)+E_q f,
\quad
f=\log(g/\pi_a)-\log(g_s/\pi_s)\circ C.
\tag{N35}
\]

The first two terms have sum at most `e_A`. This is the direct entropy step; path closeness alone would not give it.

The unwrapped Gaussian with mean `mu_a(t)` and its invariant Gaussian have identical covariance. Their log-density ratio is

\[
\ell_a(x)=T^{-1}\mu_a(t)^T H_ax
-\frac1{2T}\mu_a(t)^TH_a\mu_a(t).
\tag{N36}
\]

The orthogonally projected Gaussian has mean `P_s mu_a(t)` and precision `H_s`. This projected mean must not be replaced by the generally different mean of the independently evolved stage-`s` process. Let `ell_s` be (N36) for that marginal. On the common central chart, (N17), (N21), and exponentially small Gaussian image errors give

\[
f=\ell_a-\ell_s\circ P_s+O(b^4/T)+E_A,
\quad
|f|\le C(1+b/A)+Cb^4/T+E_A.
\tag{N37}
\]

Globally every compact Gaussian density, invariant density, and normalized fiber integral in (N35) has upper and lower bounds between `cT^p e^{-C/T}` and `CT^{-p}e^{C/T}`. Hence `|f|<=C/T+C|log T|`. The actual and Gaussian central-complement probabilities obey (N31).

The total variation bound `TV(q,g)<=sqrt(D(q||g)/2)` follows by coarse-graining to the event `{q>=g}` and the binary inequality `D(Ber(p)||Ber(r))>=2(p-r)^2` (differentiate twice in `p`, then integrate from its minimum at `p=r`). Therefore

\[
|E_qf-E_gf|
\le C(1+b/A+b^4/T)\sqrt{e_A}+E_A.
\tag{N38}
\]

Here (N37) is used on the central event, and the global bound times (N31) on its complement. Under the Gaussian law, (N36) gives exactly

\[
\Delta^G_{a:s}(t)=\frac1{2T}
\left[\mu_a(t)^TH_a\mu_a(t)
-(P_s\mu_a(t))^TH_s(P_s\mu_a(t))\right]\ge0.
\tag{N39}
\]

The sign follows from the Schur variational formula. Gaussian moment tails, (N17), and (N21) compare `E_g f` with (N39), with error `Cb^4/T+E_A`. Combining (N33), (N35), and (N38) proves

\[
\Delta^N_{a:s}(t)
\le\Delta^G_{a:s}(t)
+e_A+C(1+b/A)\sqrt{e_A}+Cb^4/T+E_A
\le\Delta^G_{a:s}(t)+C A^{7/5}
+C A^{-p}e^{-cA^{-1/5}}.
\tag{N40}
\]

The additional `(b^4/T)sqrt(e_A)` is smaller than the retained terms. This bound applies separately to the fine process (`a=0`) and every independently evolved parent (`a>0`), each with its own actual initialization. Every individual loss inside the cumulative reduction is bounded by its nonnegative cumulative loss. Multiplication by `T` gives the conditional VFE correction in the original normalized experiment. Root Haar conditionals and compact face corrections have not been dropped.

## 7. Rates, propagation, and open initial-law regimes

For symmetric matrices `E` and `H`, the variational formula for ordered eigenvalues gives `|lambda_j(H+E)-lambda_j(H)|<=||E||`. Apply this to (N19) and to its restrictions to every fast conditional subspace. For example, `h_A<J_L/18` makes every local normal eigenvalue at least half the conservative lower bound in (N7). This proves local restoring-mode admissibility for the exact generated parents. It does not convert local convexity into a fast global logarithmic-Sobolev constant.

There is also the separate, conservative global gap. If `lambda_a^Haar` is the first nonzero eigenvalue of the inherited torus Laplacian, the Rayleigh quotient and the ratio of maximum to minimum invariant density give

\[
\operatorname{gap}(-\overline L_a)
\ge T\lambda_a^{\rm Haar}e^{-\operatorname{osc}(F_a)/T}
\ge T\lambda_a^{\rm Haar}e^{-2\sum_iD_{ii}/T}>0.
\tag{N41}
\]

Indeed `Var_pi(f)=inf_c integral(f-c)^2dpi` is at most `p_max Var_Haar(f)`, while the Dirichlet form is at least `T p_min integral|grad f|^2dnu`. The exact compact integral lies between `exp(-max U/T)` and `exp(-min U/T)`, so its free-energy oscillation is at most `osc U`. This proves (N41) directly.

Suppose the Gaussian reference supplies compatible Brownian couplings for adjacent stages with path error `p_a` and exceptional probability `z_a` over the same horizon. Apply (N30) to the two nonlinear endpoints and use norm-one orthogonal projection on their common good chart. The corresponding nonlinear error is at most `p_a+2H d_A`; its exceptional probability is at most `z_a+E_A`. A chain of `r<=L` reductions therefore has

\[
\text{path error}\le\sum p_a+2rH d_A,
\qquad
\text{exceptional probability}\le\sum z_a+rE_A.
\tag{N42}
\]

Only a union bound is used, not independence of exceptional events. Formula (N40) controls the conditional entropies directly for each needed source law; the conditional chain identity charges each exact interface loss once.

For any fixed conditional and vector force `b`, let `osc b=sup_{x,x'}|b(x)-b(x')|`. The scalar total-variation bound in every unit direction gives

\[
|E_qb-E_\kappa b|
\le\operatorname{osc}(b)\sqrt{D(q\Vert\kappa)/2}.
\tag{N43}
\]

Averaging and Jensen give the same expression with the square root of the averaged conditional KL. The finite force coefficient remains in this estimate. Instantaneous Gaussian fast-fluctuation estimates and (N18) provide the sharper interface comparison when available; small conditional KL by itself is not a parameter-free force bound.

The inspected preparation is a single law. To obtain an open class, fix any sufficiently small positive `A` and choose

\[
0<\epsilon_A<\tfrac14e^{-k b^2/T}.
\]

Consider every normalized smooth positive microscopic density `q'_0` with

\[
\left\|q'_0/q_0-1\right\|_\infty<\epsilon_A.
\tag{N44}
\]

This is a nonempty open neighborhood in the relative-uniform topology on smooth probability densities. It permits arbitrary small correlations and non-`K`-invariant perturbations. Since `q_0` has a positive minimum at fixed `A`, it is also open in the ordinary uniform topology restricted to smooth normalized densities.

Every actual retention and every diffusion semigroup is a positive Markov kernel. Consequently `(1-epsilon_A)Q< Q'<(1+epsilon_A)Q` as measure inequalities is preserved by initialization, time evolution, and later retentions. Initial maximal coupling adds at most `epsilon_A/2` to any exceptional probability, and identical subsequent noise then preserves equality of coupled paths off that event. This proves the path and chart claims for (N44) with that explicit addition.

For the entropy correction, the nominal initial ratio to each invariant law lies between `exp(-C/T)T^p` and `exp(C/T)T^{-p}`. Invariance and positivity preserve these bounds at all times, and the Borel push preserves them relative to the corresponding pushed invariant. Thus `||log(q/pi)||_infinity<=C/T+C|log T|` for every nominal source and retained law. If `q'/q` lies between `1-epsilon` and `1+epsilon`, then

\[
|D(q'\Vert\pi)-D(q\Vert\pi)|
\le D(q'\Vert q)+\epsilon\|\log(q/\pi)\|_\infty
\le C\epsilon^2+C\epsilon(T^{-1}+|\log T|).
\tag{N45}
\]

The last quadratic bound follows from the second derivative of `u log u` on `[1-epsilon,1+epsilon]` and cancellation of the first-order integral. Apply (N45) to both terms of (N34). The extra conditional-KL error is at most `C epsilon_A/T+C epsilon_A^2`, which is absorbed into (N12). This establishes the open initial-law part without incorrectly applying the nominal quotient entropy cancellation to a noninvariant perturbation.

For each fixed finite `L`, the matrices, lattice radii, tail constants, and chosen `D` are finite. Choose `A_*` so that `Db<rho`, `Hd_A<b/4`, `h_A<J_L/18`, and every required error is below the fixed strict Gaussian margin. The powers in (N20), (N33), and (N40) make these finitely many inequalities simultaneous for a nonempty interval `0<A<A_*`. The path correction is `O(A^{5/2})=o(A)`, so it preserves strict Gaussian signal margins of order `A`. It preserves a fixed strict conditional-entropy tolerance as well. Small parameter neighborhoods follow from the same estimates uniformly on compact neighborhoods of the fixed positive weights and `R`; there is no assertion uniform over growing contrast or `L`.

The local second-moment estimate also has a useful precise scope. On a central fiber,

\[
|E_{\kappa^N}|z|^2-E_{\kappa^G}|z|^2|
\le Cb^2\omega_A+E_A
=O(A^{17/5})+E_A=o(A^2).
\tag{N46}
\]

The genuine prior conditional differs from the optimizer conditional by the normalized tilt `exp(d^ev)`. On this fiber `d^ev=O(b^2)`, while its global bound is finite, so that additional second-moment error is `O(b^4)+E_A=o(A^2)`. Thus inherited expectations of microscopic residual observables can be compared to their Gaussian conditional moments. This does not identify residual coherence with the KL between full correlated parent mixtures; such a physical interpretation must be stated separately.

## 8. Attack record and remaining obligation

| ID | Interface attacked | Result |
| --- | --- | --- |
| NL-01 | A rational kernel might yield a dense projected lattice or lose root Haar types. | Rejected by (N2)–(N6); root Haar is exact for the nominal law, and arbitrary small noninvariant preparations are handled separately by (N44)–(N45). |
| NL-02 | Noncentral fiber wells or a small denominator might invalidate Laplace bounds. | Rejected by the global triangular barrier (N9), denominator (N11), and fixed finite choice of `D`. |
| NL-03 | Normalized Gaussian free energy might differ from its quadratic by more than an exponential. | Sustained for the initial literal wording: the explicit constant (N16) is required. The derivative and normalized-ratio estimates reconstruct. |
| NL-04 | Differentiation might omit generated covariance terms or compound inverse-temperature losses. | Rejected by the exact identity (N8) and cumulative-integral derivation (N18)–(N20). |
| NL-05 | Rare initial branch mismatch might control TV but fail to control KL. | Rejected for this preparation by the density bounds, common-part entropy proof (N25), and (N26). |
| NL-06 | A wrapped OU might be treated as a Markov torus diffusion, or finite path entropy assumed circularly. | Rejected by the exact winding lift (N27) and stopped full-path proof (N32). The reference remains a wrapped unwrapped process. |
| NL-07 | The actual Borel Gaussian push might have a large central relative error despite small TV. | Rejected by the good/bad submeasure argument (N21)–(N23); Haar preservation bounds the bad pushed density, and the denominator retains a fixed exponent gap. |
| NL-08 | Path convergence might be substituted for conditional KL, or an autonomous parent mean substituted for a projected mean. | Rejected by the exact density identity (N35), the specified projected mean in (N39), and the direct estimate (N40). |
| NL-09 | Small local Hessian error might be used as an unproved global fast entropy inequality. | Rejected: local admissibility and the distinct conservative global gap are proved separately in (N41); entropy uses (N40). |
| NL-10 | A single specially prepared law might be called an open initial-law regime. | Additional proof required and supplied in (N44)–(N45), including noninvariant correlated perturbations. |
| NL-11 | Finite-depth comparison might silently assume actual Gaussian formation or identify residuals with mixture KL. | Not discharged by this lane. The Gaussian strict episode margins and its sharper force/path bounds remain an explicit premise; residual observables require the separate physical interpretation stated after (N46). |

Only source reads, source hashes, targeted retrieval of the primary Girsanov paper, and creation of this report were performed. No simulation, symbolic package, test suite, GPU computation, tamper scenario, prior scientific rerun, Git mutation, or Research-vault edit ran. The equations in this report are the saved analytical evidence.

The strongest supported result is a reconstructed nonlinear comparison theorem for every prescribed finite depth, conditional only on the separately stated Gaussian formation and adjacent-stage estimates: exact compact parent laws have the force, Hessian, initialization, full-law entropy, conditional-entropy, and path propagation bounds above, in a nonempty small-amplitude regime and an open smooth-positive initial-law neighborhood. The remaining full-target obligation is to join actual Gaussian merger and nonmerger margins, the physical meaning of parent coherence, and the required Gaussian interface estimates to these same maps and laws. The next action that materially changes the overall answer is that explicit join, not another nonlinear simulation or an appeal to agreement among reviewers.
