# Quantitative nonlinear comparison on the complete compact parents

September 12, 2026. Nonlinear comparison for the frozen finite-depth contract. The [independent reconstruction](finite-depth-nonlinear-reconstruction.md) supplies the complete compact Gaussian and winding arguments used below. The [Gaussian reference](finite-depth-gaussian-reference.md) separately proves its formation estimates; their common-regime join is in [finite-depth-completion.md](finite-depth-completion.md).

Use the model, flag, Borel maps, Haar references and exact integrals in [finite-depth-parent-class.md](finite-depth-parent-class.md). All parameters below are finite. Fix L, positive weights J_1 >= ... >= J_L, R>1, and a finite horizon H. Only then decrease A>0 and put T=A^2/R^2. Constants in this document can depend on L, the displayed finite matrices, J, R and H, but not on A. This ordered choice is part of the construction. It asserts no estimate uniform in depth or interaction contrast.

## 1. Reference laws and the central chart

Let K=ker B, N=K-perp, and H_0=B^T D B restricted to N, with D the diagonal residual weights. This H_0 is positive definite. At stage a put N_a=W_a intersect N. The Gaussian marginal precision H_a on N_a is the Schur complement obtained by integrating the orthogonal complement of N_a in N. It is positive definite for a<L; N_L has dimension zero. Prepare the fine reference with mean A v_0, where Bv_0 has zero node residuals and unit edge residuals in both channels, and covariance T H_0^{-1}. Give the K directions independent Haar law and wrap to the microscopic torus. Denote this smooth positive law by Q_0. It is also the actual nonlinear initial law. Initialize each autonomous nonlinear parent with the stated Borel pushforward Q_{a,0}; initialize its Gaussian reference with the orthogonal Gaussian marginal. The latter covariance is T H_a^{-1}.

These definitions make sense without a global orthogonal product of tori. K is a connected rational subtorus. The normal quotient is the flat torus N/Pr_N(2pi Z^{4n-2}); the projected lattice is discrete because K is rational. Haar along each K coset defines the stated invariant density. At every parent the same construction uses N_a and its quotient lattice. All actual drifts and initial laws are K-invariant. Thus the normal quotients carry all density and entropy calculations; free K directions can be coupled by the same Brownian motion.

Choose a positive rho smaller than the injectivity radii of these finitely many quotient tori and so small that every principal residual and every successive principal residual in (9) stays strictly between -pi and pi on the normal ball of radius 4rho. Such rho exists because the finitely many relevant maps are linear near zero. Below it, every stated Borel retention is exactly the orthogonal projection in the normal lift. Outside it, the original compact maps and all their face identifications remain in force.

Put gamma=9/10 and b=A^gamma. All assertions below require b<rho/C, where the finite geometric constant C accommodates the fiber coordinates. Constants can be obtained using the matrix norms of B, R_s, the inverses in (16), the extreme eigenvalues of H_0 and its Schur complements, the quotient lattice radii, and ordinary finite-dimensional Gaussian integrals. None is a hypothesis about a future parent.

## 2. Uniform comparison of all exact parent integrals

Let F_a=-T log pi_a, using the normalized Haar density, and let F_a^G be the corresponding wrapped, centered Gaussian free energy on the normal quotient. On the central chart it equals y^T H_a y/2 plus the temperature-dependent Gaussian normalizing constant and an exponentially small image correction. Its derivatives have the corresponding exponentially small corrections. Normalizing constants are retained in comparisons of densities.

For every a, uniformly for normal |y|<=b, there are positive finite C,c and an integer p, independent of A, for which

\[
|\log(\pi_a/\pi_a^G)(y)|\le C b^4/T+E_A,
\tag{1}
\]

\[
|\nabla F_a(y)-H_a y|\le
C(b^3+b^5/T)+E_A=:d_A,
\tag{2}
\]

\[
\|\nabla^2F_a(y)-H_a\|\le
C(b^2+b^4/T+b^6/T^2)+E_A=:h_A,
\tag{3}
\]

where E_A=C A^{-p} exp(-c b^2/T). Increasing C,p and decreasing c when needed makes one envelope work at all the finitely many stages. In particular d_A<=C A^{5/2}+E_A and h_A<=C A^{7/5}+E_A.

Here is a proof including the noncentral fibers. In the cumulative orthogonal coordinates x=y+sum_{j<=a}R_j z_j, every eliminated original residual is T_a z. Equation (16) bounds its nonlinear energy below by c J_a |z|^2 throughout the principal fiber cube. The remaining weak energy is nonnegative and at z=0 is at most C J_{a+1}|y|^2. Integration over a ball of radius sqrt(T/J_1) supplies a denominator lower bound c(T/J_1)^{k/2} exp(-C J_{a+1}b^2/T). Choose a fixed D large enough that c J_a D^2 exceeds twice this last coefficient. Integration over |z|>Db is then at most a polynomial in T^{-1} times exp(-c' b^2/T), relative to that denominator. Gaussian conditional tails satisfy the same estimate: their conditional mean is a fixed linear function of y and their covariance is T times a fixed positive matrix. Increase D to contain that mean. This argument uses the global triangular bound, not global convexity of cosine.

On |y|<=b, |z|<=Db, Taylor's formula gives |U-U^G|<=C b^4, |grad U-grad U^G|<=C b^3 and |Hess U-Hess U^G|<=C b^2. Therefore the two normalized conditional densities differ in total variation by at most C b^4/T+E_A, since b^4/T tends to zero. Their local log density ratios have that same bound. The original full normalizers have ratio 1+O(T): split their normal integral into a fixed central neighborhood and its complement, use (16) for the complement, then rescale by sqrt(T) and integrate the quartic Taylor bound. A fixed smaller central neighborhood absorbs the remainder by the Gaussian quadratic. This also follows directly from the product von Mises normalizers given in the parent-class proof. The O(T) term is bounded by C b^4/T for the chosen gamma. This proves (1).

Differentiate the exact compact integral, with the tangent projection specified after (15) of the parent-class proof. The Gaussian force is H_a y. Its conditional integrand is linear and has size at most C b on the central region. The cubic force remainder and the conditional total-variation bound give (2); Gaussian first-moment tails are absorbed in E_A. For (3), use the exact identity Hess F=E Hess U - T^{-1} Cov(grad U,grad U) in retained tangent directions. The first difference is O(b^2). The cross covariance involving a cubic force remainder is O(b^4/T); changing the conditional law in the covariance of the linear Gaussian force costs O(b^2 (b^4/T)/T). Second-moment tails give E_A after enlarging p. This proves the stated bound and retains, rather than drops, the generated covariance term.

These estimates are cumulative integrals from the original U. Thus the nonlinear bound does not get an extra factor T^{-1} for every additional level. Finite depth changes C,c,p through explicitly finite matrices and the finite number of charts. The exact nonlinear F_a, rather than its quadratic comparison, defines every parent generator.

## 3. Initial compact discrepancy and path relative entropy

Let G_{a,t} be the wrapped Gaussian law with mean exp(-H_a t)Pr_{N_a}(A v_0) and stationary covariance T H_a^{-1}. For a=0 its initial law is Q_0. For a>0 the difference between Q_{a,0} and G_{a,0} is supported, in their common fine Gaussian coupling, on an initial principal-coordinate or quotient-lattice crossing. That event has probability at most C exp(-c/T), because the initial mean is O(A) and all relevant boundaries have a fixed positive distance from zero.

This probability also controls initial relative entropy, rather than merely total variation. On each compact normal torus both densities are bounded above by C T^{-p}; the Gaussian reference is bounded below by c T^p exp(-C/T). The first upper bound follows by integrating the bounded fine wrapped density over normalized compact fibers. If two probability densities bounded above by M have total variation delta, decomposing them into their common part and two residual densities proves

\[
|\int f\log f-\int g\log g|\le
C\delta\log(M/\delta)+C h(\delta).
\tag{4}
\]

Here h is binary entropy; the reference measure has mass one. Adding |integral(f-g)log g|<=2delta||log g||_infinity gives D(f||g)<=C A^{-p}exp(-c/A^2) for this preparation. This proves an entropy estimate for the actual Borel initialization.

Let Q_{a,t} now mean the law of the autonomous nonlinear parent on M_a, or the fine dynamics when a=0. There is a coupling with its Gaussian reference such that, up to the first exit from the b chart,

\[
\sup_{t\le H}|Y^N_a(t)-Y^G_a(t)|\le H d_A
\tag{5}
\]

apart from the exponentially rare initialization discrepancy. Indeed the difference equation is -H_a times the difference plus a perturbation bounded by d_A. The symmetric nonnegative matrix H_a gives a contraction. The free K Brownian motions are identical. A stationary Gaussian Ornstein-Uhlenbeck process on a finite interval has

\[
\Pr(\sup_{t\le H}|Y^G_a(t)|>b/2)
\le C A^{-p}\exp(-c b^2/T).
\tag{6}
\]

For completeness one can subdivide the interval into lengths at most the reciprocal of the largest eigenvalue, diagonalize H_a, and write each Ornstein-Uhlenbeck coordinate as an exponentially weighted Brownian martingale. The reflection bound for that martingale and a union bound give (6). The deterministic mean is O(A)=o(b). Since H d_A=o(b), the stopped coupling proves the same exit bound for the actual nonlinear process, with enlarged constants. No stopped process replaces the actual law in the conclusion.

The following relative-entropy estimate holds uniformly for 0<=t<=H:

\[
D(Q_{a,t}\Vert G_{a,t})\le
C H d_A^2/T+C A^{-p}e^{-c b^2/T}
\le C A^3+C A^{-p}e^{-c A^{-1/5}}=:e_A.
\tag{7}
\]

To justify (7), lift the initial compact law using the Gaussian reference's conditional winding distribution. Its relative entropy with respect to the unwrapped Gaussian equals the compact initial relative entropy. Evolve its lift with the periodic nonlinear drift, and compare with the linear Gaussian drift using noise sqrt(2T) in orthonormal normal coordinates. The path entropy is bounded by initial entropy plus (4T)^{-1} times the expected time integral of the squared drift difference. This is the usual change-of-drift identity, first applied on bounded stopping domains and then extended by localization and lower semicontinuity. Smooth periodic nonlinear drifts are bounded by max|grad U|, since the exact parent force is a projected conditional average. The linear comparison has at most linear growth. Both lifted processes have finite moments of every fixed order on the finite interval, so localization is legitimate and no unverified global exponential-integrability assumption is needed.

Inside the chart use d_A. On the exit event use Cauchy-Schwarz, the finite fourth moment of the lifted position, and (6); its contribution divided by T is absorbed in the exponential term. The conditional Gaussian winding lift has the required moments: on a fixed fundamental domain its winding tails are bounded by C T^{-p}exp(C/T-c|w|^2/T), and on the central domain the nonprincipal winding mass is exponentially small. Together with the initial density bounds and initial Gaussian coupling, these give uniform finite fourth moments and the same central-tail estimate. Finally, mapping the lifts to their compact tori decreases relative entropy. This proves (7) for the actual compact law. It does not assert that a wrapped Ornstein-Uhlenbeck process is itself an autonomous diffusion on the torus.

## 4. Conditional entropy survives the compact comparison

For a<s, let C_{a:s} be the actual composition of the Borel retentions and define the cumulative conditional cost

\[
\Delta^N_{a:s}(t)=D(Q_{a,t}\Vert\pi_a)
-D((C_{a:s})_\#Q_{a,t}\Vert\pi_s).
\tag{8}
\]

This is the nonnegative conditional relative entropy from the chain rule. Individual interface costs are bounded by it. Let Delta^G_{a:s} be the analogous Gaussian quantity using orthogonal projection and the exact Gaussian marginal precisions. Both the Gaussian process law and its Gaussian invariant law have the same covariance; hence Delta^G is the conditional mean energy divided by 2T, with no missing covariance-lag term.

The Gaussian Borel push requires its own relative-density argument. Split an unwrapped Gaussian into its fixed-radius good ball, where both maps agree, and its complement. Periodizing the bad submeasure gives a compact density at most C T^{-p}exp(-c/T): factor the fixed-radius Gaussian exponent out of the lattice sum. Every exact Borel retention pushes normalized Haar to normalized Haar, so it cannot increase this density upper bound. The orthogonal push of the bad submeasure has the same bound on the b ball by conditional Gaussian tails and nonzero lattice-image bounds. The retained Gaussian density there is at least c T^p exp(-C b^2/T). Division preserves exp(-c/(2T)) for small A because b tends to zero. Thus the central relative error is exponentially small, as proved in (N21)-(N23) of the independent reconstruction. A small total-variation error alone would not establish this statement.

The exact bound is

\[
\Delta^N_{a:s}(t)\le\Delta^G_{a:s}(t)
+e_A+C(1+b/A)\sqrt{e_A}+C b^4/T
+C A^{-p}e^{-c b^2/T}
\le\Delta^G_{a:s}(t)+C A^{7/5}
+C A^{-p}e^{-c A^{-1/5}}.
\tag{9}
\]

This is not inferred from path convergence. To prove it put q=Q_{a,t}, g=G_{a,t}, pi=pi_a and denote actual Borel pushforwards with a subscript s. The identity

\[
\Delta_\pi(q)=D(q\Vert g)-D(q_s\Vert g_s)
+E_q f,\quad
f=\log(g/\pi)-\log(g_s/\pi_s)
\tag{10}
\]

gives the first term at most e_A. On the common central chart, the Gaussian density ratio log(g/pi^G) is affine in the normal coordinate, because the covariances coincide. Its slope is O(A/T), and its constant is O(A^2/T). The same is true after linear projection. Gaussian tails in the fiber show that the Borel pushed Gaussian density differs there from the linearly marginalized wrapped Gaussian by an exponentially small relative error; use the same conditional Gaussian tail argument as in Section 2, increasing its constant D if necessary. Equation (1) then yields |f|<=C(1+b/A)+C b^4/T on the central region. Globally |f|<=C/T+C|log T|, since the four positive compact densities and their normalized fiber integrals have the upper and lower bounds used in Section 3. Thus Pinsker's inequality on the central region, followed by (6) for both q and g on its complement, controls |E_q f-E_g f| by the error terms in (9).

Lastly, on the central region the same formulas compare E_g f with the ordinary Gaussian conditional mean energy. Outside it, the compact log ratios have the global bound just stated, while the unwrapped affine Gaussian log ratios have Gaussian moment tails. Consequently E_g f<=Delta^G+C b^4/T+the exponential term. This proves (9). It accounts separately for nonlinear invariant conditionals, the actual evolving law, the initial compact discrepancy and every principal-coordinate face. Multiplication by T converts (9) to the conditional VFE cost in the original normalized experiment.

## 5. Restoring rates, full dynamics and finite-depth propagation

Every local positive restoring eigenvalue of H_a, or of its fast conditional block for a subsequent stage s, changes by at most h_A in (3). Once A is small enough that h_A is below half the least of those finitely many positive eigenvalues, every such local nonlinear restoring rate is at least half its Gaussian value. This proves local quantitative admissibility of the exact generated parents. It does not assume a globally convex cosine potential or equate a local Hessian with a global logarithmic-Sobolev constant.

For clarity, a conservative global spectral gap also exists at every positive T. If lambda_a is the first nonzero eigenvalue of the inherited flat-torus Laplacian, comparison with normalized Haar gives

\[
\operatorname{gap}(-\overline L_a)
\ge T\lambda_a\exp[-\operatorname{osc}(F_a)/T]
\ge T\lambda_a\exp[-2\sum_iD_{ii}/T]>0.
\tag{11}
\]

The comparison follows directly from the variational formula for variance and the maximum-to-minimum ratio of the invariant density. It is deliberately weaker than the local fast rates used for the finite formation intervals. The nonlinear dynamics' conditional-entropy conclusion is (9), not an unsupported fast global gap.

Suppose a Gaussian adjacent-stage path comparison, on a common Brownian coupling, has error p_a over [0,H] and exceptional probability z_a. Equations (5)-(6), applied to the two exact nonlinear parents, give their corresponding error p_a+2H d_A and probability z_a+C A^{-p}exp(-c b^2/T). Orthogonal retentions have norm one on the common chart. Thus a chain of r reductions has error at most sum_a p_a+2rH d_A and exceptional probability at most sum_a z_a+r C A^{-p}exp(-c b^2/T), on the common event. A one-shot cumulative comparison is also available by the same proof. No exponential loss from an arbitrary ambient Lipschitz bound is inserted.

The instantaneous interior force discrepancy at an interface has two distinct terms: the actual Gaussian fast fluctuation or conditional mean mismatch, as bounded in the Gaussian reference, and at most C d_A from the nonlinear force comparisons. In law-averaged form the exact force/conditional-entropy inequality is available directly: for any retained point and conditional q, a bounded projected vector force b with image diameter osc b satisfies |E_q b-E_kappa b|<=osc(b) sqrt(D(q||kappa)/2). Averaging and Jensen give the same bound with sqrt(Delta/2). This bound includes its actual finite force coefficient; it is not declared small merely because Delta is small. The Gaussian fast-force estimates and the time-integrated path estimates retain the sharper scale dependence.

For each fixed finite Gaussian regime, all additional nonlinear errors in (1)-(11) tend to zero as A decreases, while the reference trajectory signal has size A and the path correction is O(A^{5/2})=o(A). Thus the nonlinear estimates preserve strict Gaussian merger and nonmerger margins of order A. They also preserve any fixed strict conditional-entropy tolerance. The separate Gaussian reference establishes those margins; the joined proof makes the ordered parameter choice. This comparison component does not assume formation as a hypothesis about the nonlinear process.

The primary source for the change-of-drift entropy identity used in Section 3 is Christian Leonard, [Girsanov theory under a finite entropy condition](https://arxiv.org/abs/1101.3958), Theorem 2.3 and its stopped-density proof. The noise covariance here is 2T I, giving the factor 1/(4T). The displayed upper bound is first proved for bounded stopped changes of drift, then extended using the finite drift-energy and nonexplosion estimates above; finite relative entropy is not assumed as its own conclusion. The Gaussian, compact-integral and conditional-entropy comparisons are derived in this document.
