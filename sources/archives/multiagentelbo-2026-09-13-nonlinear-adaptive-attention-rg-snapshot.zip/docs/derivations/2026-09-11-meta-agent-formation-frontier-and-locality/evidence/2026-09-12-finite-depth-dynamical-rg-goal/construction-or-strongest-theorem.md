<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-d15c9f5a5a810b76900ea496929ff4a5c6832d4553a379d5da43ce2f1f7e3bd9","target_digest":"d15c9f5a5a810b76900ea496929ff4a5c6832d4553a379d5da43ce2f1f7e3bd9"} -->
# Finite-depth construction

For every prescribed finite L>=3, one open positive-temperature compact nonlinear family has L successive coalescence levels, exact normalized marked parents, inherited dynamics and controlled conditional VFE and path errors; L=3 gives 8 -> 4 -> 2 -> 1.

The complete theorem and proof join are in proofs/finite-depth-completion.md. The exact-law, Gaussian-reference and nonlinear-comparison derivations and their independent reconstructions are retained alongside it. The ordered parameter choice, all constants and the scope restrictions belong to the theorem. Hashes identify the recorded text; they are not mathematical evidence.
