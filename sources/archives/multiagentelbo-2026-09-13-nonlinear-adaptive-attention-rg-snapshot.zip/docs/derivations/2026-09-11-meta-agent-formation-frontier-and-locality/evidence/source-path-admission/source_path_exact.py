"""Exact checks for the source-based path admission; no historical runs."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json
import platform
import sys
import time

Matrix = list[list[F]]
Vector = list[F]


def matmul(left: Matrix, right: Matrix) -> Matrix:
    """Multiply finite row-oriented rational matrices."""
    assert len(left[0]) == len(right)
    return [[sum((left[i][k]*right[k][j] for k in range(len(right))), F(0))
             for j in range(len(right[0]))] for i in range(len(left))]


def apply(row: Vector, matrix: Matrix) -> Vector:
    """Apply a row law without renormalizing."""
    return matmul([row], matrix)[0]


def encode(matrix: Matrix) -> list[list[str]]:
    return [[str(value) for value in row] for row in matrix]


def main() -> dict[str, object]:
    started = time.perf_counter()
    states = tuple(product(range(2), repeat=3))
    r_values = [F(1,4),F(3,4)]
    prior_r = [F(3,5),F(2,5)]
    posterior_r = [F(1,3),F(2,3)]
    recognition_r = [F(3,4),F(1,4)]
    kappa = [[F(1,4),F(3,4)],[F(1,5),F(2,5)]]

    def conditional(state: tuple[int, int, int]) -> F:
        r,w,h = state
        return F(1,2)*(kappa[r][w] if h else 1-kappa[r][w])

    generative = [prior_r[state[0]]*conditional(state) for state in states]
    evidence = sum((weight*r_values[state[0]] for weight,state in zip(generative,states)),F(0))
    assert sum(generative,F(0)) == 1 and evidence == F(9,20)
    pi = [weight*r_values[state[0]]/evidence for weight,state in zip(generative,states)]
    assert pi == [posterior_r[state[0]]*conditional(state) for state in states]
    q = [recognition_r[state[0]]*conditional(state) for state in states]
    assert sum(q,F(0)) == 1
    M = [[F(0)]*8 for _ in states]
    C = [[F(int(j==2*state[0]+state[2])) for j in range(4)] for state in states]
    for i,state in enumerate(states):
        r,w,h = state
        j = states.index((r,w,1-h))
        M[i][j] = F(1,2)*min(F(1),pi[j]/pi[i])
        M[i][i] = 1-M[i][j]
    pi_H = apply(pi,C)
    q_H = apply(q,C)
    J = [[pi[i]/pi_H[parent] if C[i][parent] else F(0) for i in range(8)]
         for parent in range(4)]
    D = matmul(C,J)
    T = matmul(M,D)
    L = matmul(matmul(J,M),C)
    expected_L = [[F(3,4),F(1,4),F(0),F(0)],
                  [F(1,4),F(3,4),F(0),F(0)],
                  [F(0),F(0),F(11,14),F(3,14)],
                  [F(0),F(0),F(1,2),F(1,2)]]
    assert L == expected_L
    assert pi_H == [F(1,6),F(1,6),F(7,15),F(1,5)]
    assert q_H == [F(3,8),F(3,8),F(7,40),F(3,40)]
    identity = [[F(int(i==j)) for j in range(4)] for i in range(4)]
    assert matmul(J,C) == identity
    assert matmul(J,T) == matmul(L,J)
    assert apply(q_H,J) == q
    for K in (M,D,T):
        assert all(sum(row,F(0))==1 for row in K)
        assert all(value>=0 for row in K for value in row)
        assert apply(pi,K) == pi and apply(q,K) == q
        assert all(value==0 or states[i][0]==states[j][0]
                   for i,row in enumerate(K) for j,value in enumerate(row))
    assert apply(pi_H,L) == pi_H and apply(q_H,L) == q_H
    assert all(pi_H[i]*L[i][j]==pi_H[j]*L[j][i] for i in range(4) for j in range(4))
    assert T[0][3] == F(1,8)
    q_prediction = sum((mass*r_values[state[0]] for mass,state in zip(q,states)),F(0))
    pi_prediction = sum((mass*r_values[state[0]] for mass,state in zip(pi,states)),F(0))
    assert q_prediction == F(3,8) and pi_prediction == F(7,12)
    assert pi_prediction-q_prediction == F(5,24)

    inside = (1,3)
    outside = (0,2)
    flux = sum((pi_H[i]*L[i][j] for i in outside for j in inside),F(0))
    reverse_flux = sum((pi_H[i]*L[i][j] for i in inside for j in outside),F(0))
    assert flux == reverse_flux == F(17,120)
    occupancy = sum((pi_H[i] for i in inside),F(0))
    assert occupancy == F(11,30)
    entry = [sum((pi_H[i]*L[i][j] for i in outside),F(0))/flux for j in inside]
    assert entry == [F(5,17),F(12,17)]
    killed = [[L[i][j] for j in inside] for i in inside]
    surviving = list(entry)
    survival = []
    for n in range(7):
        actual = sum(surviving,F(0))
        formula = F(5,17)*F(3,4)**n + F(12,17)*F(1,2)**n
        assert actual == formula
        survival.append(str(actual))
        surviving = apply(surviving,killed)
    entrance_mean = entry[0]/(1-L[1][1])+entry[1]/(1-L[3][3])
    conditional_mean = sum((pi_H[i]/occupancy/(1-L[i][i]) for i in inside),F(0))
    assert entrance_mean == occupancy/flux == F(44,17)
    assert conditional_mean == F(32,11)

    q1,q2,weight = F(1,5),F(1,17),F(7,24)
    mixture = weight*q1+(1-weight)*q2
    phi1,phi2,phi_mix = F(1,3),F(1,5),F(1,4)
    for initial,evolved in ((q1,phi1),(q2,phi2),(mixture,phi_mix)):
        assert (evolved/(1-evolved))**2 == initial/(1-initial)
    assert mixture == F(1,10)
    affine = weight*phi1+(1-weight)*phi2
    assert affine == F(43,180) and phi_mix-affine == F(1,90)
    return {
        "status":"PASS",
        "runtime":{"version":platform.python_version(),"executable":sys.executable,
                   "elapsed_seconds":time.perf_counter()-started},
        "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "fine_states":[list(s) for s in states],
        "generative_prior":[str(v) for v in generative],
        "observed_success_evidence":str(evidence),
        "target":[str(v) for v in pi],
        "different_stationary_recognition":[str(v) for v in q],
        "M":encode(M),"D":encode(D),"T":encode(T),"C":encode(C),"J":encode(J),"L":encode(L),
        "target_parent":[str(v) for v in pi_H],
        "recognition_parent":[str(v) for v in q_H],
        "nontrivial_transition_T_0_3":str(T[0][3]),
        "recognition_next_record":str(q_prediction),
        "target_next_record":str(pi_prediction),
        "prediction_gap_unchanged_by_sweep":str(pi_prediction-q_prediction),
        "stationary_entry_and_exit_flux":str(flux),
        "stationary_event_occupancy":str(occupancy),
        "entrance_survival_n0_to_n6":survival,
        "entrance_mean":str(entrance_mean),
        "stationary_conditional_mean":str(conditional_mean),
        "fisher_affinity_counterexample":{"mixture_weight":str(weight),"q1":str(q1),"q2":str(q2),
          "mixture":str(mixture),"phi1":str(phi1),"phi2":str(phi2),"phi_mixture":str(phi_mix),
          "affine_prediction":str(affine),"gap":str(phi_mix-affine)},
        "checks":"Exact normalization, invariant laws, prepared intertwining, reversibility, nontrivial move, killed survival, flux balance, and positive-preparation Fisher nonaffinity.",
        "scope":"New eight-state illustration. No production or historical scientific run; universal conclusions use the written proofs."
    }


if __name__ == "__main__":
    result=main()
    Path(__file__).with_name("result.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
    print(json.dumps({key:value for key,value in result.items()
                      if key not in ("M","D","T","C","J","fine_states","generative_prior","target","different_stationary_recognition")},indent=2))

