"""Exact equilibrium-sector alignment and identifiability calculations."""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import time

BASE=Path(__file__).resolve().parent
SOURCE=BASE.parent/'nonlinear-filter/nonlinear_filter_exact.py'
spec=importlib.util.spec_from_file_location('nonlinear_definitions',SOURCE)
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
Matrix=list[list[F]]


def main() -> None:
    start=time.perf_counter()
    prior=BASE.parent/'local-response/result.json'
    raw=json.loads(prior.read_text(encoding='utf-8'))
    theta=[F(raw['theta_reference'][key]) for key in ('m12','b12','m23','b23','m34','b34')]
    mu=[[F(x)] for x in raw['posterior_mean']]
    c=[[F(x) for x in row] for row in raw['posterior_covariance']]
    metric=[F(x) for x in raw['generative_metric_diagonal']]
    noise=F(raw['noise_variance'])
    obs=F(raw['observation'])
    n=8
    r=a.eye(n)
    for i in range(1,n,2):
        r[i][i-1]=-F(1,2)
    r0=[row[:] for row in r]
    for val,i in zip(theta,range(2,n)):
        r[i][i-2]=-val
    hrow=[[F(1,2) if i in (2,3,6,7) else F(0) for i in range(n)]]
    ri=a.inverse(r)
    innovation=a.mm(hrow,ri)[0]
    w=a.mm(ri,[[x] for x in innovation])
    ds=[2*innovation[i]*w[i-2][0] for i in range(2,n)]
    assert all(x>0 for x in innovation+ds)
    tangent=[F(1),F(0),F(0),F(0),F(0),-ds[0]/ds[5]]
    assert sum((x*y for x,y in zip(ds,tangent)),F(0))==0
    deriv=[]
    for val,i in zip(theta,range(2,n)):
        u=[r0[i]]
        v=[[F(k==i-2) for k in range(n)]]
        linear=a.scale(a.add(a.mm(a.tr(u),v),a.mm(a.tr(v),u)),F(-1))
        quadratic=a.mm(a.tr(v),v)
        deriv.append(a.add(linear,quadratic,2*val))
    cov_deriv=[a.scale(a.mm(a.mm(c,j),c),F(-1)) for j in deriv]
    mean_deriv=[a.scale(a.mm(a.mm(c,j),mu),F(-1)) for j in deriv]
    mean_gaps=[]
    variance_ratios=[]
    kl_lower_bounds=[]
    kl_deriv=[]
    for e,(val,i) in enumerate(zip(theta,range(2,n))):
        parent=i-2
        gap=mu[i][0]-val*mu[parent][0]
        predicted=innovation[i]/4
        if i%2:
            predicted+=mu[i-1][0]/2
        assert gap==predicted and gap>0
        transported=val*val*c[parent][parent]
        ratio=c[i][i]/transported
        mean_gaps.append(gap)
        variance_ratios.append(ratio)
        kl_lower_bounds.append(gap*gap/(2*transported))
        grad=[]
        for f,(dc,dm) in enumerate(zip(cov_deriv,mean_deriv)):
            dt=F(e==f)
            dgap=dm[i][0]-val*dm[parent][0]-dt*mu[parent][0]
            dv=val*val*dc[parent][parent]+2*val*dt*c[parent][parent]
            dr=dc[i][i]/transported-c[i][i]*dv/(transported*transported)
            grad.append(((1-1/ratio)*dr+2*gap*dgap/transported-gap*gap*dv/(transported*transported))/2)
        kl_deriv.append(sum((x*y for x,y in zip(grad,tangent)),F(0)))
    assert all(x>0 for x in kl_lower_bounds)
    assert any(kl_deriv)
    FY=[[F(k==i) for k in range(n)] for i in [2,3,6,7]]
    FZ=[[F(1,2) if j in indices else F(0) for j in range(n)] for indices in [(2,6),(3,7)]]
    yjac=a.tr([a.upper(a.mm(a.mm(FY,dc),a.tr(FY))) for dc in cov_deriv])
    zjac=a.tr([a.upper(a.mm(a.mm(FZ,dc),a.tr(FZ))) for dc in cov_deriv])
    ranks={'Y_covariance_on_stationary_tangent':a.rank(yjac+[ds])-1,
           'Z_covariance_on_stationary_tangent':a.rank(zjac+[ds])-1}
    dc_t=a.zeros(n,n)
    dm_t=a.zeros(n,1)
    for value,dc,dm in zip(tangent,cov_deriv,mean_deriv):
        dc_t=a.add(dc_t,dc,value)
        dm_t=a.add(dm_t,dm,value)
    assert a.mm(hrow,dm_t)==[[F(0)]]
    assert a.mm(a.mm(hrow,dc_t),a.tr(hrow))==[[F(0)]]
    information=sum((m*v*v for m,v in zip(metric,tangent)),F(0))
    assert information>0
    query_mean=a.mm(hrow,mu)[0][0]
    latent_variance=a.mm(a.mm(hrow,c),a.tr(hrow))[0][0]
    assert query_mean==obs-noise/obs
    assert latent_variance==noise-noise*noise/(obs*obs)
    query_variance=latent_variance+noise
    result={'status':'PASS','python':sys.version,'seconds':time.perf_counter()-start,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'input_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),
            'helper_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'theta_reference':theta,'innovation_sensor_loadings':innovation,'evidence_variance_gradient':ds,
            'stationary_tangent':tangent,'mean_alignment_gaps':mean_gaps,
            'variance_ratios':variance_ratios,'exact_KL_mean_lower_bounds':kl_lower_bounds,
            'KL_derivatives_along_stationary_tangent':kl_deriv,
            'complete_model_fisher_along_tangent':information,'retained_covariance_tangent_ranks':ranks,
            'query_mean':query_mean,'query_latent_variance':latent_variance,'query_variance':query_variance,
            'alignment_bounds_positive':True,'nonlinear_trajectory_integrated':False}
    (BASE/'result.json').write_text(json.dumps(a.helpers.jsonable(result),indent=2),encoding='utf-8')
    print(json.dumps(a.helpers.jsonable({k:result[k] for k in ('status','seconds','mean_alignment_gaps','retained_covariance_tangent_ranks','query_mean','query_variance')})))


if __name__=='__main__':
    main()
