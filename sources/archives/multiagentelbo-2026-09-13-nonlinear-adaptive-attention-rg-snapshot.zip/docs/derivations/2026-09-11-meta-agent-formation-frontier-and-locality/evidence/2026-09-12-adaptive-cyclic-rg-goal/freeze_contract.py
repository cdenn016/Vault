"""Bind the newly scaffolded adaptive research package to its declared target."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def main() -> None:
    """Freeze the target before any construction or certification claims."""
    run = Path(__file__).resolve().parent
    target_path = run / "target-input.json"
    target = json.loads(target_path.read_text(encoding="utf-8"))
    canonical = json.dumps(target, ensure_ascii=False, sort_keys=True,
                           separators=(",", ":"), allow_nan=False).encode("utf-8")
    digest = hashlib.sha256(canonical).hexdigest()
    contract_id = "contract-sha256-" + digest
    old = json.loads((run / "problem-contract.json").read_text(encoding="utf-8"))
    for path in run.iterdir():
        if path.suffix not in {".json", ".md"} or path == target_path:
            continue
        text = path.read_text(encoding="utf-8")
        text = text.replace(old["contract_id"], contract_id)
        text = text.replace(old["target_digest"], digest)
        if path.name == "problem-contract.json":
            value = json.loads(text)
            value["target"] = target
            text = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
        path.write_text(text, encoding="utf-8")
    target_path.unlink()
    print(json.dumps({"contract_id": contract_id, "target_digest": digest}))


if __name__ == "__main__":
    main()
