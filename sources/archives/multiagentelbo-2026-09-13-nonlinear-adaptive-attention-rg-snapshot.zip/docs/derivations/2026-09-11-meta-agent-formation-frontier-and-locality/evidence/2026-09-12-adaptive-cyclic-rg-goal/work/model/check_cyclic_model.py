"""Tiny exact matrix and high-precision score checks for two joined triangles."""

from __future__ import annotations

import hashlib
import json
import platform
import sys
from pathlib import Path

import mpmath as mp
import sympy as sp


def row_for_edge(i: int, j: int, edge_index: int, n: int, dimension: int) -> sp.Matrix:
    """Return the actual independent-link residual u_i-u_j-alpha_e."""
    row = sp.zeros(1, dimension)
    row[0, i], row[0, j], row[0, 2 * n + edge_index] = 1, -1, -1
    return row


def as_mp(value: sp.Matrix) -> mp.matrix:
    """Convert exact rational entries without passing through binary floats."""
    return mp.matrix([[mp.mpf(str(value[i, j].p)) / mp.mpf(str(value[i, j].q))
                       for j in range(value.cols)] for i in range(value.rows)])


def trace(value: mp.matrix) -> mp.mpf:
    """Return the trace of a square high-precision matrix."""
    return sum(value[i, i] for i in range(value.rows))


def main() -> None:
    """Execute only the named small scientific identities; no production runner."""
    mp.mp.dps = 75
    n = 6
    edges = [(0, 1), (1, 2), (2, 0), (3, 4), (4, 5), (5, 3), (2, 3)]
    d = 2 * n + len(edges)
    bridges = sp.zeros(n, d)
    for i in range(n):
        bridges[i, i], bridges[i, n + i] = 1, -1
    edge_rows = sp.Matrix.vstack(*(row_for_edge(i, j, k, n, d)
                                  for k, (i, j) in enumerate(edges)))
    full = bridges.col_join(edge_rows)
    first_rows = [bridges]
    for start in [0, 3]:
        first_rows.extend([edge_rows[start, :] - edge_rows[start + 1, :],
                           edge_rows[start, :] + edge_rows[start + 1, :]
                           - 2 * edge_rows[start + 2, :]])
    first = sp.Matrix.vstack(*first_rows)
    final = first.col_join(edge_rows[6, :])
    identity = sp.eye(d)
    p_kernel = identity - full.T * (full * full.T).inv() * full
    p_first = identity - first.T * (first * first.T).inv() * first
    p_final = identity - final.T * (final * final.T).inv() * final
    h_rows = sp.zeros(2, d)
    for loop, start in enumerate([0, 3]):
        for edge_index in range(start, start + 3):
            h_rows[loop, 2 * n + edge_index] = 1
    p_h = h_rows.T * h_rows / 3
    j1, j2 = sp.Integer(100), sp.Integer(1)
    h = full.T * sp.diag(*([j1] * (n + 6) + [j2])) * full
    r_eval = 2 * bridges.T * bridges
    t = sp.Rational(1, 10000)
    kappa = sp.Rational(1, 10)
    a = sp.Rational(3, 2)
    a0 = a * h + p_kernel - t * r_eval
    k_a = a * h + p_kernel + kappa * identity
    covariance = t * k_a.inv()
    checks = {
        "full_residual_rank": full.rank() == n + len(edges),
        "first_eliminated_rank": first.rank() == 10,
        "last_eliminated_rank": final.rank() == 11,
        "kernel_dimension": p_kernel.rank() == 6,
        "first_parent_dimension": p_first.rank() == 9,
        "last_parent_dimension": p_final.rank() == 8,
        "normalized_loop_gram": h_rows * h_rows.T == 3 * sp.eye(2),
        "loop_first_orthogonality": h_rows * first.T == sp.zeros(2, 10),
        "loop_last_orthogonality": h_rows * final.T == sp.zeros(2, 11),
        "loop_eigenmode": h * h_rows.T == j1 * h_rows.T,
        "loop_retained_first": h_rows * p_first == h_rows,
        "loop_retained_last": h_rows * p_final == h_rows,
        "nested_projections": p_final * p_first == p_final,
        "last_carrier_is_kernel_plus_loops": p_final == p_kernel + p_h,
        "covariance_composition": p_final * p_first * covariance * p_first * p_final
                                  == p_final * covariance * p_final,
        "loop_variance": h_rows * covariance * h_rows.T
                         == 3 * t / (a * j1 + kappa) * sp.eye(2),
        "prior_spd_bound_coefficients": a - t * 2 / j1 >= a / 2,
    }
    checks = {name: bool(value) for name, value in checks.items()}
    assert all(checks.values()), checks

    h_mp, pk_mp, rev_mp = as_mp(h), as_mp(p_kernel), as_mp(r_eval)
    t_mp, a_mp = mp.mpf(1) / 10000, mp.mpf(3) / 2
    sigma = as_mp(covariance)
    mu_exact = (identity - p_kernel) * sp.Matrix([sp.Rational(i + 1, 10000) for i in range(d)])
    mu = as_mp(mu_exact)

    def a0_at(parameter: mp.mpf) -> mp.matrix:
        return parameter * h_mp + pk_mp - t_mp * rev_mp

    def varying_objective(parameter: mp.mpf) -> mp.mpf:
        # Constants in entropy, evaluator, and O likelihood are a-independent.
        precision = a0_at(parameter)
        return (trace(precision * sigma) + (mu.T * precision * mu)[0]) / 2 \
            - t_mp * mp.log(mp.det(precision)) / 2 + (parameter - 2) ** 2 / 2

    a0_inverse = a0_at(a_mp) ** -1
    score = a_mp - 2 + (trace(h_mp * sigma) + (mu.T * h_mp * mu)[0]) / 2 \
        - t_mp * trace(a0_inverse * h_mp) / 2
    step = mp.mpf("1e-22")
    finite_difference = (varying_objective(a_mp + step) - varying_objective(a_mp - step)) / (2 * step)
    residual = abs(score - finite_difference)
    fisher = 1 / t_mp + trace((a0_inverse * h_mp) ** 2) / 2
    assert residual < mp.mpf("1e-40")
    assert 1 <= t_mp * fisher <= mp.mpf("1.1")
    result = {
        "scope": "One n=6 cyclic matrix example and high-precision normalized-model score check; not a finite-L proof or dynamical simulation.",
        "environment": {"python": sys.version, "executable": sys.executable,
                        "platform": platform.platform(), "sympy": sp.__version__, "mpmath": mp.__version__},
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "configuration": {"nodes": n, "edges": edges, "dimension": d, "J1": 100, "J2": 1,
                          "T": "1/10000", "kappa": "1/10", "a": "3/2", "evaluator_c": "1/2"},
        "exact_identities": checks,
        "score": mp.nstr(score, 50),
        "finite_difference": mp.nstr(finite_difference, 50),
        "absolute_score_residual": mp.nstr(residual, 20),
        "scaled_model_fisher": mp.nstr(t_mp * fisher, 50),
        "status": "observed identities hold",
    }
    output = Path(__file__).with_name("cyclic-model-check.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "status": result["status"],
                      "absolute_score_residual": result["absolute_score_residual"]}))


if __name__ == "__main__":
    main()
