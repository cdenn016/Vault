"""Check current document bindings and local links without executing scientific tests."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote


RUN = Path(__file__).resolve().parent
FRONTIER = RUN.parent.parent


def digest(path: Path) -> str:
    """Identify one local artifact without changing it."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    """Validate the document package; the result does not certify mathematics."""
    bindings = json.loads((RUN / "document-bindings.json").read_text(encoding="utf-8"))
    errors = []
    source_paths = []
    for binding in bindings["proof_bindings"]:
        source = FRONTIER / binding["source"]
        snapshot = RUN / binding["snapshot"]
        for candidate in (source, snapshot):
            if not candidate.is_file() or digest(candidate) != binding["sha256"]:
                errors.append("Source/snapshot drift: " + str(candidate))
        source_paths.append(source)
    source_paths.append(FRONTIER / "adaptive-source-reconciliation.md")
    links_checked = 0
    for source in source_paths:
        content = source.read_text(encoding="utf-8")
        if re.search(r"\\[,;!]", content):
            errors.append("Prohibited spacing macro: " + source.name)
        for target in re.findall(r"\]\((<[^>]+>|[^)]+)\)", content):
            target = target.strip("<>").split("#", 1)[0]
            if not target or re.match(r"https?://|app://|codex://", target):
                continue
            path = Path(unquote(target))
            if not path.is_absolute():
                path = source.parent / path
            links_checked += 1
            if not path.exists():
                errors.append("Missing local link in " + source.name + ": " + target)
    example_path = RUN / "work/model/cyclic-model-check.json"
    example = json.loads(example_path.read_text(encoding="utf-8"))
    script = RUN / "work/model/check_cyclic_model.py"
    if digest(script) != example["source_sha256"]:
        errors.append("Current symbolic-check script differs from its retained output binding.")
    failure_path = RUN / "work/model/initial-export-failure.json"
    if not failure_path.is_file():
        errors.append("The initial export-failure record is missing.")
    result = {
        "scope": "Document bindings, local links and retained tiny-check provenance only; no mathematical or experimental certification.",
        "proof_bindings": len(bindings["proof_bindings"]),
        "source_documents": len(source_paths),
        "local_link_occurrences": links_checked,
        "tiny_check_identity_count": len(example["exact_identities"]),
        "tiny_check_script_bound": digest(script) == example["source_sha256"],
        "initial_failed_export_retained": failure_path.is_file(),
        "errors": errors,
    }
    (RUN / "document-check.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))
    return int(bool(errors))


if __name__ == "__main__":
    raise SystemExit(main())
