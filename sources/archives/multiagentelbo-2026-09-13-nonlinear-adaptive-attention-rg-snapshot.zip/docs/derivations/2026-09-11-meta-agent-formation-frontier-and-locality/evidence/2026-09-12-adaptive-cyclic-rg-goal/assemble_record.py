"""Bind the completed written adaptive construction; this does not prove mathematics."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


RUN = Path(__file__).resolve().parent
FRONTIER = RUN.parent.parent
CONTRACT = json.loads((RUN / "problem-contract.json").read_text(encoding="utf-8"))
META = {key: CONTRACT[key] for key in ("schema_version", "contract_id", "target_digest")}
HEADER = "<!-- rigorous-theory-search-metadata " + json.dumps(META, separators=(",", ":")) + " -->\n"


def digest(path: Path) -> str:
    """Identify the exact retained document bytes."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name: str, value: dict) -> None:
    """Write one reviewable record with common contract metadata."""
    (RUN / name).write_text(json.dumps(META | value, indent=2) + "\n", encoding="utf-8")


def write_markdown(name: str, value: str) -> None:
    """Write one required report with its explicit contract binding."""
    (RUN / name).write_text(HEADER + value, encoding="utf-8")


def main() -> None:
    """Snapshot the final derivations and record their scoped adjudication."""
    filenames = {
        "model": "adaptive-normalized-model.md",
        "geometry": "adaptive-loop-parent-geometry.md",
        "conditional": "adaptive-conditional-bounds.md",
        "witness": "adaptive-cyclic-witness.md",
        "model-check": "adaptive-model-geometry-check.md",
        "conditional-check": "adaptive-conditional-check.md",
        "formation-check": "adaptive-formation-check.md",
        "joined": "adaptive-cyclic-completion.md",
        "reconstruction": "adaptive-independent-reconstruction.md",
    }
    proof_dir = RUN / "proofs"
    proof_dir.mkdir(exist_ok=True)
    assumptions = [
        {"id": "A1", "kind": "MODELING_POSTULATE", "statement": "One fixed base point, independent translation links, scalar Gaussian law presentations, and a chain of 2^(L-1) triangles for each prescribed finite L>=2."},
        {"id": "A2", "kind": "MODELING_POSTULATE", "statement": "The proper normalized prior A0=aH+P_K-TR, normalized evaluator and Gaussian observations, compatible fixed heterogeneous record z in K, and calibration record Y=2."},
        {"id": "A3", "kind": "MODELING_POSTULATE", "statement": "Common unit configuration mobility, exact-law deterministic expectation-driven model learning with inherited full-model Fisher metric, positive Gaussian recognition and scalar precision a."},
        {"id": "A4", "kind": "MODELING_POSTULATE", "statement": "Supplied descending microscopic energy strengths, positive epsilon-family amplitude and temperature in A10, explicit generic initial normal mean, covariance TK1^-1, and horizon 2/epsilon."},
        {"id": "A5", "kind": "MODELING_POSTULATE", "statement": "Fixed orthogonal marked retentions, complete correlated conditional kernels and evidence scalars, gamma=0, and exact memory or explicitly bounded autonomous-parent replacement from actual retained laws."},
    ]
    evidence = []
    bindings = []
    for key, filename in filenames.items():
        source = FRONTIER / filename
        snapshot = proof_dir / filename
        snapshot.write_bytes(source.read_bytes())
        evidence.append({"id": "proof-" + key, "kind": "DERIVATION", "supports": True,
                         "scope": "Written analytical derivation in " + filename,
                         "side_conditions": [entry["statement"] for entry in assumptions],
                         "artifact_path": snapshot.relative_to(RUN).as_posix(),
                         "artifact_sha256": digest(snapshot)})
        bindings.append({"source": filename, "snapshot": snapshot.relative_to(RUN).as_posix(),
                         "sha256": digest(source)})
    example = RUN / "work/model/cyclic-model-check.json"
    evidence.append({"id": "small-example", "kind": "SYMBOLIC_CHECK", "supports": True,
                     "scope": "One 19-coordinate two-triangle matrix and high-precision score check only; not an all-L proof or a trajectory experiment.",
                     "side_conditions": ["The exact configuration and runtime are recorded in the JSON output."],
                     "artifact_path": example.relative_to(RUN).as_posix(), "artifact_sha256": digest(example)})
    specifications = [
        ("model", "The declared microscopic Gaussian generative joint is normalized and its exact evaluator-restricted VFE generates the displayed coupled descent with its full-model Fisher metric.", ["model", "model-check"], "For every finite admitted graph and positive parameter satisfying M5.", "A missing normalizer, invalid evaluator minimum, or different score/metric refutes the identity."),
        ("learning", "The actual fine and inherited-parent model updates change a by more than one half over 2/epsilon and change both physical and optimizer hidden conditionals by the stated positive KL lower bound.", ["model", "conditional", "model-check", "conditional-check"], "For every fixed finite L and sufficiently small positive epsilon in the exhibited family.", "A parameter exit, externally prescribed update, or vanishing conditional change refutes this claim."),
        ("geometry", "The fixed nested retentions preserve every cycle coordinate and all required joint conditional marks, and their normalized physical and restricted-parent laws compose exactly with inherited mobility.", ["geometry", "model-check", "joined"], "At every level of each prescribed finite triangle-chain flag, with distinct physical and optimizer kernels.", "An erased loop, wrong reverse kernel, missing determinant, or failed normalized composition refutes the claim."),
        ("conditional", "The noncommuting covariance barriers and direct conditional KL and force bounds hold and survive actual-law Schur activation under the displayed rate and speed hypotheses.", ["conditional", "conditional-check"], "For every finite quadratic model and orthogonal flag satisfying conditional Theorems 1 and 2 on the declared finite horizon.", "Violation of the covariance comparison or the Gaussian conditional-KL subtraction under these hypotheses refutes the theorem."),
        ("feedback", "Parents learn from their own actual laws with inherited full scores and metrics, with O_L(epsilon^4) parameter error and O_L(A epsilon^2) coupled path error at the stated exceptional probability; exact retained memory remains available.", ["conditional", "witness", "conditional-check", "formation-check"], "For each actual source-to-parent activation and every finite sequence in the exhibited regime, through 2/epsilon.", "A reset, a borrowed parameter schedule, an uncontrolled stiffness multiplier or missing thermal path force refutes the claim."),
        ("formation", "Actual microscopic and sequential-parent dynamics exhibit L distinct ordered coherence windows with separated future bridges and the stated inherited original-edge KL statistics.", ["witness", "formation-check"], "For every finite L>=2, all sufficiently small positive epsilon and the stated nondegenerate Gaussian preparation.", "Failure of a current/future residual margin, a restoring layer, or the stopped path maximum bound refutes the formation result."),
        ("joint-regime", "The explicit finite-L epsilon family satisfies learning, exact-parent, formation, conditional-VFE and dynamic-error requirements simultaneously through the complete adaptation horizon.", ["joined", "witness", "reconstruction", "formation-check"], "For every prescribed finite L>=2 there exists epsilon0(L)>0 for all 0<epsilon<epsilon0(L); constants need not be uniform in L.", "An incompatible scale inequality, missing finite-L activation or shrinking adaptation horizon refutes the joint regime."),
    ]
    claims = []
    for claim_id, statement, proofs, quantifiers, falsifier in specifications:
        claims.append({"id": claim_id, "statement": statement, "quantifiers": quantifiers,
                       "kind": "MATHEMATICAL", "target_digest": META["target_digest"],
                       "state": "EVIDENCE_VERIFIED", "assumption_ids": [a["id"] for a in assumptions],
                       "evidence_ids": ["proof-" + item for item in proofs], "bridge_premise_ids": [],
                       "falsifier": falsifier})
    target = CONTRACT["target"]
    claims.append({"id": "target", **{key: target[key] for key in ("statement", "quantifiers", "kind")},
                   "target_digest": META["target_digest"], "state": "EVIDENCE_VERIFIED",
                   "assumption_ids": [a["id"] for a in assumptions],
                   "evidence_ids": ["proof-joined", "proof-reconstruction", "proof-model-check", "proof-conditional-check", "proof-formation-check"],
                   "bridge_premise_ids": [], "falsifier": target["falsification_criterion"]})
    write_json("claim-ledger.json", {"assumptions": assumptions, "evidence": evidence, "claims": claims})
    dependencies = {"target": [entry[0] for entry in specifications],
                    "learning": ["model", "conditional"], "feedback": ["model", "geometry", "conditional", "learning"],
                    "formation": ["model", "geometry", "learning"],
                    "joint-regime": ["model", "learning", "geometry", "conditional", "feedback", "formation"]}
    write_json("dependency-dag.json", {"edges": [{"from": source, "to": destination} for source, destinations in dependencies.items() for destination in destinations]})
    family = {"family_id": "ACRG-GAUSSIAN-TRANSPORT-MOVING-PRECISION-v1",
              "core_mechanism": "Common-kinetics weighted normal attraction with loop-preserving Schur parents, normalized precision learning and matrix covariance tracking.",
              "target_obligation_ids": [c["id"] for c in claims],
              "representation": "Proper translation-Gaussian law/link configurations on chains of triangles.",
              "invariant_or_obstruction": "Full-rank residual flag, retained cycle space, relative Schur precision bounds and actual-law conditional energy.",
              "obligations": [c["statement"] for c in claims],
              "bridge": "Explicit finite-L epsilon scales satisfy every quantitative interface on 2/epsilon.",
              "failure_test": target["falsification_criterion"],
              "verified_results": [c["id"] for c in claims], "open_gaps": [],
              "novelty_fingerprint": "Extends the existing fixed-coefficient formation and loop-parent sources through a changing-conditional adaptive interface; priority is unassessed.",
              "disposition": "completed within the admitted Gaussian class"}
    alternatives = [
        {"family_id": "regular-circle-stabilizer-route", "core_mechanism": "Exact cosine-law KL and nonidentity half-turn stabilizer on a cycle.", "target_obligation_ids": ["geometry"], "representation": "Positive circle laws with S1 links.", "invariant_or_obstruction": "Nonidentity stabilizer with positive regular normal Hessian.", "obligations": ["Geometry is reconstructed; adaptive nonlinear finite-L bounds are not supplied."], "bridge": "Shows nonidentity stabilized holonomy is compatible with the retained geometry.", "failure_test": "The normal gap vanishes as amplitude goes to zero.", "verified_results": ["geometry, only its separate stabilizer possibility"], "open_gaps": ["Changing-conditional adaptive nonlinear formation remains an extension."], "novelty_fingerprint": "A scoped geometric example, not an alternative full-target certificate.", "disposition": "retained supporting geometry"},
        {"family_id": "conditional-preserving-full-law-learning", "core_mechanism": "Existing exact full-law matching preserved by a compatible model update.", "target_obligation_ids": ["learning"], "representation": "Earlier exponential-family full-law constructions.", "invariant_or_obstruction": "The hidden conditional is fixed along the admitted learning submanifold.", "obligations": ["The new target requires appreciable hidden conditional change."], "bridge": "Prior source supplies score and closure context but not the changing-conditional certificate.", "failure_test": "A conditional-preserving update cannot satisfy A8 with positive right side.", "verified_results": [], "open_gaps": ["Does not close the current learning target."], "novelty_fingerprint": "Existing retained source, not a newly discovered failure of the general theory.", "disposition": "not used for target closure"},
    ]
    write_json("approach-registry.json", {"mechanism_families": [family, *alternatives]})
    reconstruction = proof_dir / filenames["reconstruction"]
    proof_reference = {"artifact_path": reconstruction.relative_to(RUN).as_posix(), "artifact_sha256": digest(reconstruction)}
    attack_specs = [
        ("normalization", ["model", "geometry"], "A bare energy derivative or wrong posterior reverse kernel changes the normalized model.", "M10a-M10b and the model reconstruction retain physical evidence, optimizer offset and distinct kernels; the draft ambiguity is repaired."),
        ("prescribed-learning", ["learning", "feedback"], "An external a(t) schedule or conditional-preserving update cannot satisfy the adaptive target.", "Actual complete scores, optimizing-lift envelopes and physical/optimizer covariance-ratio lower bounds are derived."),
        ("erased-cycles", ["geometry", "target"], "Spanning-tree reduction or mean-only cut marks could discard loop and generated conditional information.", "Every circulation row is retained and full correlated cut kernels remain; nonidentity stabilizers are allowed in their separate representation."),
        ("assumed-matching", ["conditional", "feedback"], "Conditional equilibration or a covariance reset could manufacture the entropy and parent-learning conclusion.", "Actual Lyapunov barriers, nonzero moving mean defects, direct conditional KL and actual-law activations are retained."),
        ("long-horizon", ["feedback", "joint-regime"], "Largest-stiffness sensitivity or hidden thermal noise could invalidate the 2/epsilon path bound.", "Relative Schur sensitivity, own-law calibration and stopped shrinking path tubes supply separate estimates; exact memory is distinguished."),
        ("scheduled-hierarchy", ["formation", "joint-regime", "target"], "Desired activation times or incompatible scales could insert successive formation rather than derive it.", "The unchanged microscopic dynamics yields separated residual windows, all scale inequalities hold jointly, and finite branches start from actual retained states."),
        ("repaired-draft-formulas", ["geometry", "formation", "target"], "Missing plus signs, omitted root drift and the final-layer scale equality could invalidate printed formulas.", "The reconstruction preserves these sustained draft findings and checks their local source repairs; the current formulas include the full drift and s<L range."),
    ]
    attacks = [{"id": key, "claim_ids": claim_ids, "attack": attack, "response": response,
                "disposition": "REJECTED", **proof_reference} for key, claim_ids, attack, response in attack_specs]
    all_claims = [c["id"] for c in claims]
    write_json("adversarial-report.json", {"attacks": attacks,
        "independent_reconstruction": {"claim_ids": all_claims, "method": "Separate nonauthor analytical reconstructions of model/geometry, conditional estimates and formation, joined by an explicit hypothesis and scale map.", "result": "PASS", "conclusion": "Displayed derivations support every component and the joined finite-L target under the recorded postulates; corrected draft defects are preserved.", **proof_reference},
        "oracle_erasure": {"claim_ids": all_claims, "method": "Remove favorable expectations and all author verdicts; reconstruct from finite graph, normalized laws, metrics, initial data and explicit inequalities.", "result": "PASS", "conclusion": "No assumed formation, matching, future grouping, model schedule or recursive admission remains; modeling postulates stay explicit.", **proof_reference}})
    strongest = "For every finite L>=2, an admitted cyclic Gaussian family has L actual coalescence levels, appreciable normalized model learning that changes physical and optimizing hidden conditionals, exact marked parents and finite-horizon conditional-VFE and independently learned dynamic bounds."
    write_json("release.json", {"checkpoint": "completed finite adaptive cyclic construction", "target_claim": "target", "terminal_status": "COMPLETE_AFFIRMATIVE", "certificate_claim": "target", "strongest_result": strongest, "unresolved_obligations": []})
    write_markdown("construction-or-strongest-theorem.md", "# Completed adaptive cyclic construction\n\n" + strongest + "\n\nThe complete theorem and proof interface are in proofs/adaptive-cyclic-completion.md. The nine proof snapshots supply the analytical evidence; claim-ledger.json records each component. Exact normalized laws are distinguished from controlled autonomous dynamics.\n")
    write_markdown("counterexample-register.md", "# Counterexamples, attacks and repaired defects\n\nSee proofs/adaptive-independent-reconstruction.md, Section 2, and the three separate component checks. Small weighted KL does not control its gradient; matched law points need not stay matched under learning; posterior substitution can produce an unnormalized likelihood; mean-only cut marks lose conditional covariance; and zero conditional KL does not imply exact Markov path closure. These refute stronger shortcuts, not the admitted construction.\n\nThe draft missing plus signs, individual-link root-force omission, physical-versus-optimizer ambiguity and final-layer range defect were sustained and repaired. The retained initial symbolic-check export failure was a software serialization error and remains recorded in work/model/initial-export-failure.json. No general nonexistence result is asserted.\n")
    write_markdown("final-report.md", """# Rigorous theory search report

## Frozen contract

Construct adaptive pointwise dynamical RG on a weighted cyclic law/link network, for every prescribed finite L>=2, with actual successive coalescence, genuine model learning that appreciably changes an eliminated conditional, exact normalized marked parents and controlled conditional-VFE and dynamic errors over a meaningful adaptation interval. The original target and quantifiers are unchanged in problem-contract.json.

## Terminal status

COMPLETE_AFFIRMATIVE for the admitted finite Gaussian target.

## Certificate

Target claim `target` depends on seven component claims and nine written proof snapshots. Modeling postulates A1-A5 state the supplied graph, proper prior, observations, microscopic metrics, Gaussian preparation, contrasts and complete marked kernels.

## Strongest verified result

Every finite L>=2 has a nonempty positive-temperature family with L actual formation levels on a chain of triangles. For L=2, the agent counts are 6 -> 2 -> 1 and exact configuration dimensions are 19 -> 9 -> 8, retaining both loops. Over 2/epsilon the actual learned parameter changes by more than one half and both physical and optimizer hidden conditionals change by a fixed positive KL. Each parent uses its own evolving law and inherited complete score. Conditional KL is O_L(epsilon^2); separately learned parameter error is O_L(epsilon^4); retained path error is O_L(A epsilon^2) outside an explicit exponentially small maximum event.

## Dependency closure

The normalized joint, complete score and Fisher metric, loop flag, Gaussian conditional comparison, actual-law feedback, formation windows and common parameter regime each have a direct derivation. The complete theorem maps every hypothesis to the finite witness. No conditional matching, future merger or recursively admissible parent is assumed.

## Independent reconstruction

The conditional author reconstructed the independent formation witness; the witness author reconstructed the conditional bounds; a separate checker reconstructed model and geometry. Their equations and the combined reconstruction support the result. Agreement and fingerprints do not establish mathematics. Local printed defects were repaired and preserved in the record.

## Oracle erasure

The combined reconstruction removes the favorable expectation and investigator verdicts and rebuilds all claims from the normalized model, finite row ranks, differential equations and explicit epsilon inequalities. Supplied modeling choices remain premises, not physical conclusions.

## Unresolved obligations

None within this frozen finite Gaussian construction. Nonlinear adaptive extension, learned interaction contrasts, evolving simplex attention, incompatible observations, strict incident-edge-only implementation and infinite depth are outside the proved target.

## Scope and limitations

Fixed c_* only. Positive real energy strengths are distinguished from row-normalized attention; gamma is exactly zero while model evaluation and model learning remain. No curvature penalty is inserted. The translation witness retains small fluctuating holonomies; nonidentity stabilizers have a separate regular geometric example. The microscopic metric is common and local, but the proper correlated reference can generate dense forces. Calibration helps drive the order-one model change, mostly after the short formation episodes. All parents start from actual laws; physical prior/posterior, optimizer and recognition kernels remain distinct. Constants depend on finite L. A tiny two-triangle symbolic/score check supplements the proof and its initial export failure is retained. No trajectory experiment, full suite, GPU, Lean, tamper check, vault ingest or Git publication was run. Structural validation checks document consistency, not mathematical truth.
""")
    write_json("document-bindings.json", {"proof_bindings": bindings,
        "scope": "Source/snapshot equality identifies the written evidence and is not a mathematical acceptance test."})
    print(json.dumps({"claims": len(claims), "proof_snapshots": len(bindings), "attacks": len(attacks), "terminal_status": "COMPLETE_AFFIRMATIVE"}))


if __name__ == "__main__":
    main()
