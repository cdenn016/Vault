<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90","target_digest":"e7c8e112db2f8f093025ce0d71bb83c12c8a9f9028f4006cb73db0b03ce88d90"} -->
# Counterexamples, attacks and repaired defects

See proofs/adaptive-independent-reconstruction.md, Section 2, and the three separate component checks. Small weighted KL does not control its gradient; matched law points need not stay matched under learning; posterior substitution can produce an unnormalized likelihood; mean-only cut marks lose conditional covariance; and zero conditional KL does not imply exact Markov path closure. These refute stronger shortcuts, not the admitted construction.

The draft missing plus signs, individual-link root-force omission, physical-versus-optimizer ambiguity and final-layer range defect were sustained and repaired. The retained initial symbolic-check export failure was a software serialization error and remains recorded in work/model/initial-export-failure.json. No general nonexistence result is asserted.
