"""Exact positive ancestry envelopes and a retained-mixture matrix evaluator."""
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform
import sys
import time

sys.set_int_max_str_digits(200000)
folder = Path(__file__).parent
helper_path = folder.parent/'shared-parent-record/shared_parent_exact.py'
spec = importlib.util.spec_from_file_location('existing_record_definitions', helper_path)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)  # Definitions only; the guarded main is not executed.
h = g.helper
Matrix = list[list[F]]
Key = tuple[tuple[F, ...], ...]


def key(matrix: Matrix) -> Key:
    return tuple(tuple(row) for row in matrix)


def gram(matrix: Matrix) -> Matrix:
    return h.multiply(matrix, h.transpose(matrix))


def trace_product(a: Matrix, b: Matrix) -> F:
    return sum((a[i][j]*b[j][i] for i in range(len(a)) for j in range(len(a))), F(0))


@lru_cache(maxsize=None)
def gaussian_term(gamma: Key, powers: tuple[F, ...]) -> tuple[F, Key]:
    r"""Return det(I+Gamma D)^(-1) and (Gamma+D^(-1))^(-1)."""
    s = [[gamma[i][j]+(1/powers[i] if i == j else 0) for j in range(4)] for i in range(4)]
    determinant = h.determinant(s)
    assert determinant > 0
    for power in powers:
        determinant *= power
    return 1/determinant, key(h.inverse(s))


def energy_means(inv_s: Key, grams: list[Matrix], counts: list[int]) -> list[F]:
    r"""Return E[E_j] = d_j - 4 tr(G_j S^(-1)) at unit primitive variances."""
    result = [F(d)-4*trace_product(gj, inv_s) for gj, d in zip(grams, counts)]
    assert min(result) > 0
    return result


def main() -> None:
    start = time.perf_counter()
    source = folder.parent/'transported-parent-prior/result.json'
    catalog_path = folder.parent/'native-ancestry-crossing/predictive-moments.json'
    data = json.loads(source.read_text(encoding='utf-8'))
    catalog = json.loads(catalog_path.read_text(encoding='utf-8'))
    catalog_rows = {tuple(tuple(b) for b in r['partition']): r for r in catalog['rows']}
    constant = F(1)
    for n in g.N:
        constant *= F(4*n**n, (n+2)**(n+2))
    assert 0 < 512*constant < 1
    half = tuple(F(n, 2) for n in g.N)
    lap = gram(g.B)
    retained = {((0, 1, 2, 3),), ((0, 1), (2, 3))}
    rows = []
    detail_count = 0
    all_ids = set()
    retained_ids = set()
    for original in data['rows']:
        partition = tuple(tuple(b) for b in original['partition'])
        k = original['k']
        labels = original['labels']
        incidence = [[F(labels[i] == j) for j in range(k)] for i in range(4)]
        j_map = h.multiply(g.B, incidence)
        gb = gram(j_map)
        counts = [16, 4*k, 16]
        pooled = [F(0)]*4
        details = []
        exact_pool = [F(0)]*4
        ids = set(catalog_rows[partition]['decorated_full_covariance_map_indices'])
        assert not (ids & all_ids)
        all_ids |= ids
        if partition in retained:
            retained_ids |= ids
        for dec in original['details']:
            gamma = [[F(v) for v in row] for row in dec['Gamma']]
            c_map = [[F(v) for v in row] for row in dec['C']]
            gc = gram(c_map)
            grams = [lap, gb, gc]
            assert gamma == [[sum(gj[i][j] for gj in grams) for j in range(4)] for i in range(4)]
            w, inv_s = gaussian_term(key(gamma), half)
            means = energy_means(inv_s, grams, counts)
            # Independent block-trace reconstruction in all primitive coordinates.
            noise_map = [g.B[i]+j_map[i]+[-v for v in c_map[i]]+[F(0)] for i in range(4)]
            subtracted = h.multiply(h.multiply(h.transpose(noise_map), inv_s), noise_map)
            covariance = [[F(i == j)-subtracted[i][j] for j in range(9+k)] for i in range(9+k)]
            boundaries = [(0, 4), (4, 4+k), (4+k, 8+k)]
            assert means == [4*sum((covariance[i][i] for i in range(a, b)), F(0)) for a, b in boundaries]
            assert covariance[-1][-1] == 1
            upper_z = constant*w*w
            upper_n = [upper_z*v for v in means]
            true_z = F(dec['joint_evidence'])
            true_n = [true_z*d*F(m) for d, m in zip(counts, dec['M_energy_coordinates'])]
            assert upper_z >= true_z > 0
            assert all(upper >= true > 0 for upper, true in zip(upper_n, true_n))
            bounds = [upper_z]+upper_n
            pooled = [a+b/len(original['details']) for a, b in zip(pooled, bounds)]
            if partition in retained:
                e = F(0)
                energy_integrals = [F(0)]*3
                for bits in product((0, 1), repeat=4):
                    powers = tuple(F(n+bit) for n, bit in zip(g.N, bits))
                    moment, exact_inv = gaussian_term(key(gamma), powers)
                    signed = (-1)**sum(bits)*moment
                    e += signed
                    values = energy_means(exact_inv, grams, counts)
                    energy_integrals = [a+signed*b for a, b in zip(energy_integrals, values)]
                exact = [e*e]+[e*v for v in energy_integrals]
                assert e == F(dec['one_channel_evidence'])
                assert exact == [true_z]+true_n
                exact_pool = [a+b/len(original['details']) for a, b in zip(exact_pool, exact)]
            details.append({'roots': dec['roots'], 'trees': dec['trees'],
                            'mass_upper': str(upper_z), 'energy_numerator_upper': [str(v) for v in upper_n],
                            'mass_bound_ratio': str(upper_z/true_z),
                            'energy_bound_ratios': [str(a/b) for a, b in zip(upper_n, true_n)]})
            detail_count += 1
        true_z = F(original['evidence'])
        true = [true_z]+[true_z*d*F(m) for d, m in zip(counts, original['posterior_M_energy_coordinates'])]
        assert all(a >= b > 0 for a, b in zip(pooled, true))
        if partition in retained:
            assert exact_pool == true
        row = {'partition': original['partition'], 'k': k, 'retained': partition in retained,
               'decorations': len(details), 'distinct_full_maps': len(ids),
               'mass_upper': str(pooled[0]), 'energy_numerator_upper': [str(v) for v in pooled[1:]],
               'mass_bound_ratio_float': float(pooled[0]/true_z),
               'energy_bound_ratios_float': [float(a/b) for a, b in zip(pooled[1:], true[1:])],
               'saved_exact_mass': str(true_z), 'saved_exact_energy_numerators': [str(v) for v in true[1:]],
               'details': details}
        if partition in retained:
            row['new_exact_mass'] = str(exact_pool[0])
            row['new_exact_energy_numerators'] = [str(v) for v in exact_pool[1:]]
        rows.append(row)
    assert len(rows) == 12 and detail_count == 45
    assert len(all_ids) == 31 and len(retained_ids) == 7
    assert gaussian_term.cache_info().misses == 143
    costs = {'full_direct_matrix_terms': 16*len(all_ids),
             'retained_exact_matrix_terms': 16*len(retained_ids),
             'omitted_envelope_matrix_terms': len(all_ids)-len(retained_ids),
             'screened_evaluation_matrix_terms': 16*len(retained_ids)+len(all_ids)-len(retained_ids),
             'validation_only_retained_envelope_terms': len(retained_ids),
             'executed_unique_matrix_terms': gaussian_term.cache_info().misses}
    result = {'status': 'PASS', 'runtime': sys.executable, 'python': platform.python_version(),
              'command': [sys.executable, '-I', '-B', str(Path(__file__).resolve())],
              'script_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
              'input_sha256': sha256(source.read_bytes()).hexdigest(),
              'catalog_sha256': sha256(catalog_path.read_bytes()).hexdigest(),
              'helper_sha256': sha256(helper_path.read_bytes()).hexdigest(),
              'matrix_helper_sha256': sha256(g.HELPER.read_bytes()).hexdigest(),
              'scope': 'Unit-precision exact coefficients for all positive prior mixtures. No numerical partition prior is chosen. Retained A consists of the root and the pair, as an approximation for evaluation, not a selected generative ancestry.',
              'half_power_likelihood_constant': str(constant),
              'mass_improvement_over_full_success_bound_at_most': str(256*constant),
              'energy_improvement_over_full_success_bound_at_most': str(512*constant),
              'connected_partitions': len(rows), 'decorations': detail_count, 'costs': costs,
              'rows': rows, 'elapsed_seconds': time.perf_counter()-start,
              'not_run': ['ODE', 'numerical prior selection', 'parameter search', 'fitting', 'new data', 'sampling', 'GPU', 'test suite', 'Lean', 'tamper checks', 'old scientific mains', 'full 496-term reevaluation']}
    (folder/'positive-envelopes.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('status', 'half_power_likelihood_constant', 'mass_improvement_over_full_success_bound_at_most', 'energy_improvement_over_full_success_bound_at_most', 'connected_partitions', 'decorations', 'costs', 'elapsed_seconds')}, indent=2))
    print('Ancestry mass-bound ratios:', [r['mass_bound_ratio_float'] for r in rows])


if __name__ == '__main__':
    main()
