"""Inspect new response reports and preservation; execute no science."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path('C:/tmp/elbo-cover-20260908')
B = ROOT / 'docs/derivations/2026-09-11-meta-agent-formation-frontier-and-locality'
OUT = B / 'evidence/coherence-response'


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    baseline = json.loads((B / 'evidence/completion-reconciliation/baseline.json').read_text())
    earlier = json.loads((B / 'evidence/completion-reconciliation/inspection.json').read_text())
    allowed = set(earlier['modified_existing'])
    changed = [p for p, h in baseline['files'].items() if digest(ROOT / p) != h]
    unexpected = sorted(set(changed) - allowed)
    external = {p: digest(Path(p)) == h for p, h in baseline['external_sources'].items()}
    reconciliation = {p: digest(ROOT / p) == h for p, h in earlier['new_report_sha256'].items()}
    reports = ['coherence-and-collective-response.md', 'coherence-response-access.md',
               'coherence-response-bound.md', 'coherence-response-reconstruction.md']
    links = []
    formatting = []
    for name in reports:
        content = (B / name).read_text(encoding='utf-8')
        for n, line in enumerate(content.splitlines(), 1):
            if line.rstrip() != line or any(token in line for token in ('\\;', '\\,', '\\!')):
                formatting.append({'report': name, 'line': n})
        for raw in re.findall(r'\]\(([^\n)]+)\)', content):
            target = raw.strip('<>')
            if target.startswith(('https://', 'http://', '#')):
                continue
            path = Path(target.split('#', 1)[0])
            if not path.is_absolute():
                path = B / path
            links.append({'report': name, 'target': target, 'exists': path.exists(), 'output_of_this_inspection': path.resolve() == (OUT / 'inspection.json').resolve()})
    witness = json.loads((B / 'evidence/coherence-response-access/result.json').read_text())
    witness_sources = {p: digest(Path(p)) == h for p, h in witness['source_sha256'].items()}
    witness_script = B / 'evidence/coherence-response-access/response_access_exact.py'
    if not witness_script.exists():
        candidates = list((B / 'evidence/coherence-response-access').glob('*.py'))
        assert len(candidates) == 1, candidates
        witness_script = candidates[0]
    script_match = digest(witness_script) == witness['script_sha256']
    diff = subprocess.run(['git', '-C', str(ROOT), 'diff', '--check'], capture_output=True, text=True)
    head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    passed = (not unexpected and all(external.values()) and all(reconciliation.values())
              and all(x['exists'] or x['output_of_this_inspection'] for x in links) and not formatting
              and all(witness_sources.values()) and script_match
              and witness['status'] == 'PASS' and diff.returncode == 0 and head == baseline['head'])
    result = {
        'status': 'PASS' if passed else 'FAIL', 'scope': 'Read-only preservation, source binding and document inspection; no science rerun or proof certificate.',
        'runtime': sys.executable, 'python': sys.version.split()[0], 'head': head,
        'baseline_count': len(baseline['files']), 'unchanged_count': len(baseline['files']) - len(changed),
        'modified_existing': changed, 'unexpected_changes': unexpected,
        'external_sources_unchanged': external, 'completion_reports_unchanged': reconciliation,
        'new_report_sha256': {n: digest(B / n) for n in reports}, 'local_links': links,
        'formatting_findings': formatting, 'witness_sources_unchanged': witness_sources,
        'witness_script_matches_saved_result': script_match,
        'git_diff_check': {'exit_code': diff.returncode, 'stdout': diff.stdout, 'stderr': diff.stderr},
    }
    (OUT / 'inspection.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('status', 'baseline_count', 'unchanged_count', 'unexpected_changes', 'formatting_findings')}))
    assert passed, 'Inspect inspection.json for unresolved findings.'


if __name__ == '__main__':
    main()
