"""Exact witnesses for conditional-matching dynamics, with no production imports."""
from __future__ import annotations

from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import platform
import time


def mul(a: tuple, b: tuple) -> tuple:
    """Multiply compatible exact matrices."""
    assert len(a[0]) == len(b)
    return tuple(tuple(sum((a[i][k] * b[k][j] for k in range(len(b))), F(0))
                       for j in range(len(b[0]))) for i in range(len(a)))


def trace(a: tuple) -> F:
    """Trace of an exact square matrix."""
    return sum((a[i][i] for i in range(len(a))), F(0))


def inv2(a: tuple) -> tuple:
    """Inverse of an exact nonsingular 2-by-2 matrix."""
    det = a[0][0] * a[1][1] - a[0][1] * a[1][0]
    assert det != 0
    return ((a[1][1] / det, -a[0][1] / det),
            (-a[1][0] / det, a[0][0] / det))


def subtract(a: tuple, b: tuple) -> tuple:
    """Subtract equal-sized exact matrices."""
    return tuple(tuple(x - y for x, y in zip(ar, br)) for ar, br in zip(a, b))


def gaussian_moment(order: int, variance: F) -> F:
    """Moment of a centered scalar Gaussian from its variance."""
    if order % 2:
        return F(0)
    value = variance ** (order // 2)
    for k in range(1, order, 2):
        value *= k
    return value


def expectation(polynomial: dict, variance_y: F, variance_epsilon: F) -> F:
    """Integrate a bivariate polynomial under independent centered Gaussians."""
    return sum((coefficient * gaussian_moment(i, variance_y)
                * gaussian_moment(j, variance_epsilon)
                for (i, j), coefficient in polynomial.items()), F(0))


def polynomial_product(a: dict, b: dict) -> dict:
    """Multiply sparse bivariate polynomials exactly."""
    output = {}
    for (i, j), av in a.items():
        for (k, l), bv in b.items():
            key = (i + k, j + l)
            output[key] = output.get(key, F(0)) + av * bv
    return output


def stochastic(a: tuple) -> bool:
    """Check all exact row normalizations and nonnegativity."""
    return all(sum(row) == 1 and min(row) >= 0 for row in a)


def encode(value: object) -> object:
    """Serialize exact numbers without scientific rounding."""
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(key): encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(item) for item in value]
    return value


def main() -> None:
    """Execute the small independent algebraic witnesses once."""
    start = time.perf_counter()
    # Two scalar nodes, variable amplitudes: this is not the four-spin admission run.
    grid = tuple(product((-2, -1, 1, 2), repeat=2))
    statistic_classes, ratio_classes = {}, {}
    for x1, x2 in grid:
        key = (x1 * x1, x1 * x2)
        exponents = tuple((theta * theta - 1) * x1 * x1
                          - 2 * (theta - 1) * x1 * x2
                          for theta in (F(1, 2), F(2)))
        statistic_classes.setdefault(key, []).append((x1, x2))
        ratio_classes.setdefault(exponents, []).append((x1, x2))
    groups = {frozenset(v) for v in statistic_classes.values()}
    assert groups == {frozenset(v) for v in ratio_classes.values()}
    assert len(groups) == 8 and all(len(g) == 2 for g in groups)
    assert all((-x1, -x2) in g for g in groups for x1, x2 in g)
    for exterior in (-2, -1, 1, 2):
        assert len({(x1 * x1, x1 * exterior) for x1 in (-2, -1, 1, 2)}) == 4
        assert len({(exterior * exterior, exterior * x2) for x2 in (-2, -1, 1, 2)}) == 4
    # Derive the base metric and covector from the normalized source Gaussian.
    theta = F(1, 2)
    j0 = ((1 + theta * theta, -theta), (-theta, F(1)))
    ja = ((2 * theta, -F(1)), (-F(1), F(0)))
    k = ((j0[0][0], j0[0][1]), (j0[1][0], F(2)))
    c0, c = inv2(j0), inv2(k)
    model_metric = trace(mul(mul(mul(c0, ja), c0), ja)) / 2
    g = trace(mul(subtract(c, c0), ja)) / 2
    assert model_metric == 1 and g == F(2, 9)
    variance_y = c[1][1]
    conditional_variance = 1 / (1 + theta * theta)
    conditional_variance_derivative = -2 * theta / (1 + theta * theta) ** 2
    regression_derivative = (1 - theta * theta) / (1 + theta * theta) ** 2
    score = {(1, 1): regression_derivative / conditional_variance,
             (0, 2): conditional_variance_derivative / (2 * conditional_variance ** 2),
             (0, 0): -conditional_variance_derivative / (2 * conditional_variance)}
    assert expectation(score, variance_y, conditional_variance) == 0
    information_direct = expectation(polynomial_product(score, score), variance_y,
                                     conditional_variance)
    information_formula = (regression_derivative ** 2 * variance_y / conditional_variance
                           + (conditional_variance_derivative / conditional_variance) ** 2 / 2)
    assert information_direct == information_formula == F(12, 25)
    parent_mean_score = {(1, 0): 1 / variance_y}
    parent_variance_score = {(2, 0): 1 / (2 * variance_y ** 2),
                            (0, 0): -1 / (2 * variance_y)}
    for parent_score in (parent_mean_score, parent_variance_score):
        assert expectation(polynomial_product(score, parent_score), variance_y,
                           conditional_variance) == 0
    constrained_metric = model_metric + information_direct
    original_velocity, constrained_velocity = -g / model_metric, -g / constrained_metric
    assert constrained_metric == F(37, 25)
    assert constrained_velocity == -F(50, 333)
    assert model_metric * (original_velocity - constrained_velocity) - information_direct * constrained_velocity == 0
    dissipation = g * constrained_velocity
    assert dissipation == -F(100, 2997)
    # Direct 2D conditional score versus staged scalar conditional-score sum.
    covariance = ((F(11, 4), F(3, 2)), (F(3, 2), F(3)))
    derivative = ((F(3), F(3)), (F(3), F(0)))
    precision = inv2(covariance)
    covariance_part = trace(mul(mul(mul(precision, derivative), precision), derivative)) / 2
    mean_vector = ((F(2),), (F(2),))
    mean_part = mul(mul(((F(2), F(2)),), precision), mean_vector)[0][0] * 5
    information_nested_direct = covariance_part + mean_part
    first_conditional, second_conditional = F(4), F(20, 3)
    assert information_nested_direct == first_conditional + second_conditional == F(32, 3)
    # Four-state refresh model, including the complete post-refresh emission.
    fine_states = tuple(product((0, 1), repeat=2))
    proposal = []
    for z, u in fine_states:
        switch = F(1, 4) if u == 0 else F(1, 8)
        proposal.append(tuple((switch if zp != z else 1 - switch) if up == u else F(0)
                              for zp, up in fine_states))
    proposal = tuple(proposal)
    refresh = tuple(tuple(F(1, 2) if z == zp else F(0) for zp, up in fine_states)
                    for z, u in fine_states)
    fine_step = mul(proposal, refresh)
    eta = tuple(tuple(F(3, 4) if e == u else F(1, 4) for e in (0, 1))
                for z, u in fine_states)
    parent_states = tuple(product((0, 1), repeat=2))  # (z,current observed e)
    fine_marked = tuple(product(range(4), (0, 1)))
    lift = tuple(tuple(eta[w][e] if fine_states[w][0] == z and ep == e else F(0)
                       for w, ep in fine_marked) for z, e in parent_states)
    projection = tuple(tuple(F(int(fine_states[w][0] == z and ep == e))
                             for z, e in parent_states) for w, ep in fine_marked)
    marked_step = tuple(tuple(fine_step[w][wp] * eta[wp][ep]
                             for wp, ep in fine_marked) for w, e in fine_marked)
    parent_step = mul(mul(lift, marked_step), projection)
    assert all(stochastic(matrix) for matrix in
               (proposal, refresh, fine_step, lift, projection, marked_step, parent_step))
    assert proposal == tuple(zip(*proposal))
    assert mul(lift, marked_step) == mul(parent_step, lift)
    switch_by_record = tuple(sum(parent_step[parent_states.index((0, e))][j]
                                 for j, (zp, ep) in enumerate(parent_states) if zp == 1)
                             for e in (0, 1))
    assert switch_by_record == (F(7, 32), F(5, 32))
    assert sum(switch_by_record) / 2 == F(3, 16)
    same_original = sum((F(1, 4) * eta[w][e] * proposal[w][wp] * eta[wp][e]
                         for w in range(4) for wp in range(4) for e in (0, 1)), F(0))
    same_refreshed = sum((F(1, 4) * eta[w][e] * fine_step[w][wp] * eta[wp][e]
                          for w in range(4) for wp in range(4) for e in (0, 1)), F(0))
    assert same_original == F(5, 8) and same_refreshed == F(1, 2)
    result = dict(status='passed', interpreter=platform.python_version(),
                  arithmetic='Python int and Fraction', elapsed_seconds=time.perf_counter()-start,
                  scope='Small exact witnesses; no earlier science replay, no dynamics simulation.',
                  nonlinear_statistic=dict(amplitude_grid_states=16, global_sign_classes=8,
                                           every_class_exactly_global_sign=True,
                                           each_fixed_exterior_grid_injective=True),
                  projected_flow=dict(model_metric=model_metric, covector=g,
                                      conditional_score=score, conditional_information=information_direct,
                                      parent_conditional_cross_blocks_zero=True,
                                      constrained_metric=constrained_metric,
                                      original_velocity=original_velocity,
                                      constrained_velocity=constrained_velocity,
                                      constrained_dissipation=dissipation,
                                      projection_orthogonality_exact=True),
                  nested_information=dict(first=first_conditional,second=second_conditional,
                                          direct_covariance_part=covariance_part,
                                          direct_mean_part=mean_part,total=information_nested_direct),
                  record_refresh=dict(proposal=proposal,refresh=refresh,fine_step=fine_step,
                                      emission=eta,parent_states=parent_states,parent_step=parent_step,
                                      conditional_lift=lift,exact_intertwining=True,
                                      switch_by_record=switch_by_record,
                                      record_ignored_switch=F(3,16),
                                      original_same_record_probability=same_original,
                                      refreshed_same_record_probability=same_refreshed),
                  not_run=['Earlier scientific replays','New observations','Pytest','GPU',
                           'Dynamics simulation','Benchmarks','Lean','Tamper checks','Base transport'])
    path=Path(__file__).with_name('conditional-matching-exact-result.json')
    path.write_text(json.dumps(encode(result),indent=2)+'\n',encoding='utf-8')
    print(json.dumps(encode(dict(status=result['status'],conditional_information=information_direct,
                                 constrained_velocity=constrained_velocity,nested_information=information_nested_direct,
                                 record_conditioned_switch=switch_by_record,
                                 record_change=(same_original,same_refreshed),
                                 elapsed_seconds=result['elapsed_seconds']))))


if __name__ == '__main__':
    main()
