"""One exact Fraction calculation for transported-parent response access."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import time

N = 44
Row = list[F]
BASE = Path(__file__).resolve().parents[2]

def unit(i: int) -> Row:
    return [F(j == i) for j in range(N)]

def total(rows: list[Row]) -> Row:
    return [sum(c, F(0)) for c in zip(*rows)]

def scale(row: Row, a: F) -> Row:
    return [a*v for v in row]

def dot(a: Row, b: Row) -> F:
    return sum((u*v for u, v in zip(a, b)), F(0))

def sub(a: Row, b: Row) -> Row:
    return [u-v for u, v in zip(a, b)]

def grad(rows: list[Row], x: Row) -> Row:
    r"""Gradient of the exact sum of squared linear forms."""
    return total([scale(r, 2*dot(r, x)) for r in rows])

def eliminate(rows: list[Row]) -> tuple[int, list[int]]:
    a = [r[:] for r in rows]
    pivots = []
    for col in range(N):
        k = len(pivots)
        i = next((i for i in range(k, len(a)) if a[i][col]), None)
        if i is None:
            continue
        a[k], a[i] = a[i], a[k]
        a[k] = scale(a[k], 1/a[k][col])
        for j in range(k+1, len(a)):
            a[j] = sub(a[j], scale(a[k], a[j][col]))
        pivots.append(col)
        if len(pivots) == len(a):
            break
    return len(pivots), pivots

def determinant(matrix: list[Row]) -> F:
    a = [r[:] for r in matrix]
    d = F(1)
    for k in range(len(a)):
        i = next((i for i in range(k, len(a)) if a[i][k]), None)
        if i is None:
            return F(0)
        if i != k:
            a[i], a[k] = a[k], a[i]
            d = -d
        pivot = a[k][k]
        d *= pivot
        for i in range(k+1, len(a)):
            c = a[i][k]/pivot
            for j in range(k+1, len(a)):
                a[i][j] -= c*a[k][j]
            a[i][k] = F(0)
    return d

def main() -> None:
    start = time.perf_counter()
    p = [[unit(4*j+d) for d in range(4)] for j in range(11)]
    zero = [F(0)]*N
    ell = p[6:10]
    paths = [[zero]*4, ell[0], [zero]*4, ell[2]]
    # Correct transported generator: mu = epsilon + xi + Y + g.
    mu = [[total([p[i][d], p[4+i//2][d], p[10][d], paths[i][d]]) for d in range(4)] for i in range(4)]
    edges = [(0,1), (1,2), (2,3), (3,0)]
    r = [[sub(sub(mu[j][d],mu[i][d]),ell[e][d]) for d in range(4)] for e,(i,j) in enumerate(edges)]
    z = [[scale(total([sub(mu[i][d],paths[i][d]) for i in block]),F(1,2)) for d in range(4)] for block in ((0,1),(2,3))]
    v12 = [total([ell[0][d],ell[1][d]]) for d in range(4)]
    v30 = [total([ell[2][d],ell[3][d]]) for d in range(4)]
    d12 = [sub(sub(z[1][d],z[0][d]),v12[d]) for d in range(4)]
    d30 = [sub(sub(z[0][d],z[1][d]),v30[d]) for d in range(4)]
    t = [scale(total([r[0][d],r[2][d]]),F(1,2)) for d in range(4)]
    assert r[1] == [sub(d12[d],t[d]) for d in range(4)]
    assert r[3] == [sub(d30[d],t[d]) for d in range(4)]
    assert [sub(r[1][d],r[3][d]) for d in range(4)] == [sub(d12[d],d30[d]) for d in range(4)]
    qrows = [e[2*c:2*c+2] for e in r for c in range(2)]
    erows = [[row for item in p[a:b] for row in item] for a,b in ((0,4),(4,6),(6,10),(10,11))]
    linear = [row for a in z for row in a] + v12 + v30
    def carrier(x: Row) -> Row:
        return [sum((dot(row,x)**2 for row in group), F(0)) for group in qrows+erows] + [dot(row,x) for row in linear]
    def residual_values(x: Row) -> list[Row]:
        return [[dot(row,x) for row in group] for group in r]
    # Exactly one generic rational rank point, declared before execution.
    x = [F((17*j+3*j*j)%97-48,17) for j in range(N)]
    j1 = [grad(rows,x) for rows in qrows+erows] + linear
    jr = r[1]+r[3]
    rank1, pivots = eliminate(j1)
    rank_aug, _ = eliminate(j1+jr)
    minor = determinant([[row[j] for j in pivots] for row in j1]) if rank1 == len(j1) else None
    transverse = [dot(r[1][2*c],x)*dot(r[3][2*c+1],x)-dot(r[1][2*c+1],x)*dot(r[3][2*c],x) for c in range(2)]
    # Four explicit states, reflecting each channel independently.
    blocks2 = [(-1,-1),(1,1),(-1,0),(1,0),(-1,-1),(2,-1),(1,1),(0,-1),(1,-1),(-3,1),(1,1)]
    w0 = [F(v) for a in blocks2 for v in (*a,*a)]
    witness = []
    common = carrier(w0)
    for mask in range(4):
        w = w0[:]
        for c in range(2):
            if mask & (1<<c):
                for i in range(4):
                    w[4*i+2*c+1] *= -1
        assert carrier(w) == common
        witness.append({'mask':mask,'primitive':[str(v) for v in w],'residuals':[[str(v) for v in rr] for rr in residual_values(w)]})
    assert len({tuple(s['residuals'][1]) for s in witness}) == 4
    # Nearby query h=(0,1/10) on edge 12: record squared distances distinguish reflection.
    h = [F(0),F(1,10)]
    response_q = [[sum((dot(r[1][2*c+d], [F(v) for v in s['primitive']])+h[d])**2 for d in range(2)) for c in range(2)] for s in witness]
    sources = [BASE/'transported-parent-priors-and-induced-couplings.md', BASE/'shared-parent-complete-channel-and-recursive-cost.md', BASE/'evidence/shared-parent-channel/channel_exact.py',Path('C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex'),Path('C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md')]
    out = {
        'status':'PASS', 'runtime':platform.python_version(),
        'scope':'One generic rational Jacobian calculation and four algebraically prescribed reflection witnesses; no search.',
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_sha256':{str(s):sha256(s.read_bytes()).hexdigest() for s in sources},
        'primitive_order':['epsilon_0','epsilon_1','epsilon_2','epsilon_3','xi_A','xi_B','ell_01','ell_12','ell_23','ell_30','Y'],
        'coordinate_order_per_primitive':['belief_1','belief_2','model_1','model_2'],
        'rank_point':[str(v) for v in x], 'rank_point_carrier':[str(v) for v in carrier(x)],
        'ranks':{'F1':rank1,'F1_and_cut_residuals':rank_aug},
        'F1_minor_columns_zero_based':pivots,'F1_minor_determinant':str(minor),
        'cut_residual_determinants':[str(v) for v in transverse],
        'F1_jacobian':[[str(v) for v in row] for row in j1],
        'cut_residual_jacobian':[[str(v) for v in row] for row in jr],
        'coefficient_identities':{'r12_equals_d12_minus_half_internal_sum':True,'r30_equals_d30_minus_half_internal_sum':True,'cut_difference_retained':True},
        'witness_common_carrier':[str(v) for v in common],'witnesses':witness,
        'query_h':['0','1/10'],'query_squared_residuals':[[str(v) for v in row] for row in response_q],
        'dimensions':{'fine':44,'F1':28,'F1_plus_r12':32},
        'elapsed_seconds':time.perf_counter()-start,
        'not_run':['old helper','grid or parameter search','ODE','new observations','new objective','full suite','torch/GPU','Lean','tamper checks']}
    assert rank1 == rank_aug == 28 and minor and all(transverse)
    target = Path(__file__).with_name('result.json')
    target.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ('status','runtime','ranks','F1_minor_determinant','cut_residual_determinants','query_squared_residuals','elapsed_seconds')},indent=2))

if __name__ == '__main__':
    main()
