"""One exact Gaussian-variance M-coordinate per fixed ancestry; no iterative fitting."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform
import sys
import time

folder = Path(__file__).parent
source_script = folder.parent/'shared-parent-record/shared_parent_exact.py'
spec = importlib.util.spec_from_file_location('record_definitions',source_script)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)  # Neither this module's main nor its matrix helper's main is called.
h = g.helper
Matrix = list[list[F]]


def add(a: Matrix, b: Matrix, coefficient: F = F(1)) -> Matrix:
    return [[x+coefficient*y for x,y in zip(row_a,row_b)] for row_a,row_b in zip(a,b)]


def trace(a: Matrix) -> F:
    return sum((a[i][i] for i in range(len(a))),F(0))


def main() -> None:
    start = time.perf_counter()
    prior_result_path = folder.parent/'shared-parent-record/result.json'
    previous = json.loads(prior_result_path.read_text(encoding='utf-8'))
    assert previous['status'] == 'PASS'
    rows = []
    b = g.B
    n = m = 4
    laplacian = h.multiply(b,h.transpose(b))
    for old in previous['rows']:
        labels = tuple(old['restricted_growth_labels'])
        k = len(old['partition'])
        incidence = [[F(label == group) for group in range(k)] for label in labels]
        h_block = h.multiply(b,incidence)
        block_gram = h.multiply(h_block,h.transpose(h_block))
        gamma = [[F(x) for x in line] for line in old['residual_covariance']]
        gamma_inv = h.inverse(gamma)
        posterior_cov = h.mat([[0]*4]*4)
        evidence = F(0)
        for bits in product((0,1),repeat=4):
            powers = tuple(count+bit for count,bit in zip(g.N,bits))
            weight = (-1)**sum(bits)*g.moment(gamma,powers)
            precision = [[gamma_inv[i][j]+F(powers[i] if i == j else 0) for j in range(4)] for i in range(4)]
            posterior_cov = add(posterior_cov,h.inverse(precision),weight)
            evidence += weight
        assert evidence == F(old['one_channel_evidence'])
        posterior_cov = [[x/evidence for x in line] for line in posterior_cov]
        for size in range(1,5):
            assert h.determinant([line[:size] for line in posterior_cov[:size]]) > 0
        correction = h.multiply(h.multiply(gamma_inv,add(posterior_cov,gamma,F(-1))),gamma_inv)
        a_new = 1+trace(h.multiply(laplacian,correction))/n
        b_new = 1+trace(h.multiply(block_gram,correction))/k
        c_new = 1+trace(correction)/m
        assert min(a_new,b_new,c_new) > 0
        # Reconstruct the complete primitive-noise posterior independently of block-trace formulas.
        # Primitive ordering: child epsilon (4), block xi (k), links ell (4), root Y (1).
        link_negative = [[-x for x in line] for line in h.eye(4)]
        a_map = [b[i]+h_block[i]+link_negative[i]+[F(0)] for i in range(4)]
        complete_cov = add(h.eye(9+k),h.multiply(h.multiply(h.transpose(a_map),correction),a_map))
        assert sum(complete_cov[i][i] for i in range(n))/n == a_new
        assert sum(complete_cov[i][i] for i in range(n,n+k))/k == b_new
        assert sum(complete_cov[i][i] for i in range(n+k,n+k+m))/m == c_new
        assert complete_cov[-1][-1] == 1
        assert all(complete_cov[-1][i] == 0 for i in range(8+k))
        if k == 1:
            assert b_new == 1
        if k == 4:
            assert a_new == b_new
        next_gamma = g.covariance(labels,a_new,b_new,c_new)
        next_evidence = g.evidence(next_gamma)
        assert next_evidence >= evidence
        total_evidence = evidence**2
        rows.append({'partition':old['partition'],'labels':list(labels),'k':k,
            'old_variances':{'a':'1','b':'1','c':'1','v':'1'},
            'new_variances':{'a':str(a_new),'b':str(b_new),'c':str(c_new),'v':'1'},
            'new_variances_float':[float(a_new),float(b_new),float(c_new)],
            'posterior_residual_covariance_per_coordinate':[[str(x) for x in line] for line in posterior_cov],
            'old_evidence':str(total_evidence),'new_evidence':str(next_evidence**2),
            'evidence_ratio':str((next_evidence/evidence)**2),
            'new_evidence_float':float(next_evidence**2),
            'symbolic_prior_mixture_coefficients':{
                'ancestry_weight':str(total_evidence),
                'a_numerator':str(total_evidence*a_new),'a_denominator':str(total_evidence),
                'b_numerator':str(total_evidence*k*b_new),'b_denominator':str(total_evidence*k),
                'c_numerator':str(total_evidence*c_new),'c_denominator':str(total_evidence)}})
    ordered = sorted(rows,key=lambda row:F(row['new_evidence']),reverse=True)
    best = F(ordered[0]['new_evidence'])
    result = {'status':'PASS','runtime':sys.executable,'python':platform.python_version(),
        'command':[sys.executable,'-I','-B',str(Path(__file__).resolve())],
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_script_sha256':sha256(source_script.read_bytes()).hexdigest(),
        'matrix_helper_sha256':sha256(g.HELPER.read_bytes()).hexdigest(),
        'prior_result_sha256':sha256(prior_result_path.read_bytes()).hexdigest(),
        'steps_per_partition':1,'partitions':15,'all_exact_evidences_nondecreasing':True,
        'maximizers_after_one_step':[row['partition'] for row in ordered if F(row['new_evidence']) == best],
        'rows':ordered,
        'symbolic_prior_note':'For any supplied positive ancestry prior pi_T, sum pi_T times each numerator and denominator to obtain the shared exact M-coordinate at the old posterior. No pi_T is selected here.',
        'scope':'Exact posterior moments and one accepted M-coordinate; no finite-time trajectory or convergence claim.',
        'elapsed_seconds':time.perf_counter()-start,
        'not_run':['previous scientific mains','iterative fit','parameter search','tempered series','ODE integration',
                   'sampling','pytest','GPU','Lean','tamper checks']}
    (folder/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('status','partitions','steps_per_partition','all_exact_evidences_nondecreasing','maximizers_after_one_step','elapsed_seconds')},indent=2))
    for row in ordered:
        print(row['partition'],row['new_variances_float'],row['new_evidence_float'])


if __name__ == '__main__':
    main()
