# Read-only input preservation and output-completeness inspection.
$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '../../../..')).Path
$outputRoot = Split-Path $PSScriptRoot -Parent
$frontierRoot = Join-Path $PSScriptRoot 'frontier'
$binding = Get-Content -Raw (Join-Path $PSScriptRoot 'input-binding.json') | ConvertFrom-Json
$preserved = foreach ($item in $binding.inputs) {
    $actual = (Get-FileHash -LiteralPath (Join-Path $repoRoot $item.path) -Algorithm SHA256).Hash.ToLower()
    if ($actual -ne $item.sha256) { throw "Input changed: $($item.path)" }
    [pscustomobject]@{path=$item.path; sha256=$actual; unchanged=$true}
}
$receipt = Get-Content -Raw (Join-Path $repoRoot 'docs/reports/data/2026-09-11-finite-data-formation/launch-receipt.json') | ConvertFrom-Json
$sourceChecks = foreach ($entry in $receipt.source_sha256.PSObject.Properties) {
    $actual = (Get-FileHash -LiteralPath (Join-Path $repoRoot $entry.Name) -Algorithm SHA256).Hash.ToLower()
    if ($actual -ne $entry.Value) { throw "Receipt source changed: $($entry.Name)" }
    [pscustomobject]@{path=$entry.Name; sha256=$actual; matches_retained_receipt=$true}
}
$choices = (Get-Content -Raw (Join-Path $frontierRoot 'oracle-selection.json') | ConvertFrom-Json).runs
$validation = @(Import-Csv (Join-Path $frontierRoot 'validation-frontier.csv'))
$heldout = @(Import-Csv (Join-Path $frontierRoot 'heldout-frontier.csv'))
$attribution = @(Import-Csv (Join-Path $frontierRoot 'preparation-attribution.csv'))
$structural = @(Import-Csv (Join-Path $frontierRoot 'structural-diagnostics.csv'))
$triples = @(Import-Csv (Join-Path $frontierRoot 'attribution-episodes.csv'))
$coverage = @(Import-Csv (Join-Path $frontierRoot 'coverage-rows.csv'))
$environments = @('original','reversed_couplings')
$policies = @('positive','alternating','feedback')
$expectedHeldout = 0
$expectedAttribution = 0
foreach ($run in $choices) {
    $v = @($validation | Where-Object { [int]$_.seed -eq $run.seed -and [int]$_.budget -eq $run.budget })
    if ($v.Count -ne 32 -or @($v.index | Select-Object -Unique).Count -ne 32) { throw 'Validation candidate coverage incomplete' }
    $indices = @(@($run.frontier) + @(0,30) | Sort-Object -Unique)
    $expectedHeldout += 6*$indices.Count
    $expectedAttribution += 6*$run.oracle_indices.Count
    foreach ($index in $indices) {
        foreach ($environment in $environments) {
            foreach ($policy in $policies) {
                $cell = @($heldout | Where-Object { [int]$_.seed -eq $run.seed -and [int]$_.budget -eq $run.budget -and [int]$_.index -eq $index -and $_.environment -eq $environment -and $_.policy -eq $policy })
                if ($cell.Count -ne 1 -or [int]$cell[0].episodes -ne 256) { throw 'Held-out cell missing or duplicated' }
            }
        }
    }
    foreach ($index in $run.oracle_indices) {
        foreach ($environment in $environments) {
            $s = @($structural | Where-Object { [int]$_.seed -eq $run.seed -and [int]$_.budget -eq $run.budget -and [int]$_.index -eq $index -and $_.environment -eq $environment })
            if ($s.Count -ne 1) { throw 'Structural cell missing or duplicated' }
            foreach ($policy in $policies) {
                $cell = @($attribution | Where-Object { [int]$_.seed -eq $run.seed -and [int]$_.budget -eq $run.budget -and [int]$_.index -eq $index -and $_.environment -eq $environment -and $_.policy -eq $policy })
                if ($cell.Count -ne 1 -or [int]$cell[0].episodes -ne 256) { throw 'Attribution cell missing or duplicated' }
            }
        }
    }
}
if ($heldout.Count -ne $expectedHeldout -or $attribution.Count -ne $expectedAttribution -or $triples.Count -ne 256*$expectedAttribution) { throw 'Output row totals disagree with frozen menu' }
$execution = Get-Content -Raw (Join-Path $frontierRoot 'execution.json') | ConvertFrom-Json
foreach ($entry in $execution.script_sha256.PSObject.Properties) {
    $actual=(Get-FileHash -LiteralPath (Join-Path $frontierRoot $entry.Name) -Algorithm SHA256).Hash.ToLower()
    if ($actual -ne $entry.Value) { throw "Analysis script binding changed: $($entry.Name)" }
}
$manifest = @(Get-ChildItem -LiteralPath $outputRoot -Recurse -File | Where-Object { $_.Name -ne 'completion-inspection.json' } | ForEach-Object {
    [pscustomobject]@{path=[IO.Path]::GetRelativePath($outputRoot,$_.FullName); bytes=$_.Length; sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLower()}
})
$inspection = [pscustomobject]@{
    inspected_utc=[DateTime]::UtcNow.ToString('o')
    source_revision=(& git -C $repoRoot rev-parse HEAD)
    canonical_revision=(& git -C 'C:/Users/chris and christine/Desktop/MultiAgentELBO' rev-parse HEAD)
    retained_inputs=$preserved
    receipt_sources=$sourceChecks
    coverage=[pscustomobject]@{datasets=$choices.Count; validation_rows=$validation.Count; heldout_rows=$heldout.Count; attribution_rows=$attribution.Count; attribution_episode_triples=$triples.Count; structural_rows=$structural.Count; conditional_coverage_rows=$coverage.Count; missing_or_duplicate_required_cells=0}
    final_script_hashes_match=$true
    pytest_run=$false
    formal_ledger_certificate=$false
    output_manifest=$manifest
}
$inspection | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'completion-inspection.json') -Encoding utf8
$inspection.coverage | ConvertTo-Json
Write-Output "Preserved $($preserved.Count) inputs; $($sourceChecks.Count) receipt source hashes match; all required cells present."
