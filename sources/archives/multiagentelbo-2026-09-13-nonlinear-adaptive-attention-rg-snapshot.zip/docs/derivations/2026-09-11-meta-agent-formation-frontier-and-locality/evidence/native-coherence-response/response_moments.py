"""Exact new collective-response moment numerators for the saved native law."""
from fractions import Fraction as F
from hashlib import sha256
from itertools import permutations
import json
from pathlib import Path
import platform
import sys
import time

HERE = Path(__file__).parent
B = HERE.parent.parent
SOURCE = HERE.parent / 'joint-native-episode/determinant-polynomials.json'
Poly = dict[tuple[int, int, int], F]
PERMS = [(p, (-1) ** sum(p[i] > p[j] for i in range(4) for j in range(i+1, 4))) for p in permutations(range(4))]
Q = [F(1), F(0), F(1), F(0)]


def multiply(a: Poly, b: Poly) -> Poly:
    result = {}
    for u, x in a.items():
        for v, y in b.items():
            p = tuple(i+j for i, j in zip(u, v))
            result[p] = result.get(p, F(0)) + x*y
    return {p: x for p, x in result.items() if x}


def determinant(a: list[list[Poly]]) -> Poly:
    result = {}
    for p, sign in PERMS:
        term = {(0, 0, 0): F(sign)}
        for i in range(4):
            term = multiply(term, a[i][p[i]])
        for power, value in term.items():
            result[power] = result.get(power, F(0)) + value
    return {p: x for p, x in result.items() if x}


def inverse(a: list[list[F]]) -> list[list[F]]:
    n = len(a)
    work = [row[:] + [F(i == j) for j in range(n)] for i, row in enumerate(a)]
    for j in range(n):
        k = next(k for k in range(j, n) if work[k][j])
        work[j], work[k] = work[k], work[j]
        pivot = work[j][j]
        work[j] = [x/pivot for x in work[j]]
        for i in range(n):
            if i != j:
                scale = work[i][j]
                work[i] = [x-scale*y for x, y in zip(work[i], work[j])]
    return [row[n:] for row in work]


def main() -> None:
    start = time.perf_counter()
    data = json.loads(SOURCE.read_text())
    rows = []
    numerator = F(0)
    normalizer = F(0)
    all_positive = True
    for row in data['rows']:
        grams = [[[F(x) for x in line] for line in gram] for gram in row['grams']]
        gamma = [[sum(gram[i][j] for gram in grams) for j in range(4)] for i in range(4)]
        gamma_inverse = inverse(gamma)
        terms = []
        e = F(0)
        nu = F(0)
        coherence_nu = F(0)
        for term in row['determinants']:
            diag = [F(n+b) for n, b in zip((8, 1, 8, 1), term['bits'])]
            entries = [[{(0, 0, 0): F(i == j), **{tuple(int(k == v) for k in range(3)): grams[v][i][j]*diag[j] for v in range(3)}} for j in range(4)] for i in range(4)]
            response = {}
            lengths = {}
            # d/ds det[I+Gamma(D+s qq^T)] at s=0 = det(A) q^T A^-1 Gamma q.
            for column in (0, 2):
                changed = [[entry.copy() for entry in line] for line in entries]
                for i in range(4):
                    changed[i][column] = {tuple(int(k == v) for k in range(3)): sum(grams[v][i][j]*Q[j] for j in range(4)) for v in range(3)}
                for power, value in determinant(changed).items():
                    response[power] = response.get(power, F(0)) + value
                # Diagonal selector gives C00+C22 for the retained-length certificate.
                for i in range(4):
                    changed[i][column] = {tuple(int(k == v) for k in range(3)): grams[v][i][column] for v in range(3)}
                for power, value in determinant(changed).items():
                    lengths[power] = lengths.get(power, F(0)) + value
            response = {p: x for p, x in response.items() if x}
            lengths = {p: x for p, x in lengths.items() if x}
            assert all(x > 0 for x in response.values()), 'Response polynomial lost positivity'
            assert all(x > 0 for x in lengths.values()), 'Length polynomial lost positivity'
            denominator = sum(F(v[3]) for v in term['coefficients'])
            precision = [[gamma_inverse[i][j] + F(i == j)*diag[j] for j in range(4)] for i in range(4)]
            covariance = inverse(precision)
            quadratic = sum(Q[i]*covariance[i][j]*Q[j] for i in range(4) for j in range(4))
            trace = covariance[0][0] + covariance[2][2]
            assert sum(response.values())/denominator == quadratic
            assert sum(lengths.values())/denominator == trace
            sign = F(term['sign'])
            e += sign/denominator
            nu += sign*sum(response.values())/(2*denominator**2)
            coherence_nu += sign*2*sum(lengths.values())/denominator**2
            terms.append({**term, 'response_numerator': [[*p, str(v)] for p, v in sorted(response.items())],
                          'length_numerator': [[*p, str(v)] for p, v in sorted(lengths.items())],
                          'unit_quadratic': str(quadratic), 'unit_trace': str(trace)})
        assert e > 0 and nu > 0 and coherence_nu > 0
        # coherence_nu/e = E(||r01||^2+||r23||^2); half of it bounds E epsilon^2.
        weight = F(row['weight'])
        numerator += weight*e*nu
        normalizer += weight*e*e
        rows.append({**row, 'determinants': terms, 'unit_e': str(e), 'unit_nu': str(nu),
                     'unit_coherence_nu': str(coherence_nu), 'unit_M_conditional': str(nu/e)})
    expected_normalizer = sum(F(p)*F(z) for p, z in zip(data['prior_exact'], data['unit_evidence_exact']))
    assert normalizer == expected_normalizer
    result = {
        'status': 'PASS_EXACT_RESPONSE_MOMENT_COEFFICIENTS',
        'scope': 'New rank-one and diagonal moment numerators; all seven covariance maps and 112 failure terms. Original evidence denominator coefficients reused. Independent unit covariance-inverse identities checked for every term.',
        'runtime': sys.executable, 'python': platform.python_version(),
        'script_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_sha256': {str(p.relative_to(B)): sha256(p.read_bytes()).hexdigest() for p in (SOURCE, B/'transported-parent-priors-and-induced-couplings.md', B/'coherence-response-bound.md', B/'coherence-response-access.md')},
        'prior_exact': data['prior_exact'], 'K_pi_exact': data['K_pi_exact'], 'rows': rows,
        'unit_full_law_M_exact': str(numerator/normalizer), 'unit_full_law_M_float': float(numerator/normalizer),
        'unit_normalizer_exact': str(normalizer), 'term_count': sum(len(r['determinants']) for r in rows),
        'elapsed_seconds': time.perf_counter()-start,
    }
    (HERE/'moment-polynomials.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('status', 'term_count', 'unit_full_law_M_float', 'elapsed_seconds')}), flush=True)


if __name__ == '__main__':
    main()
