"""Inspect saved native response evidence; do not execute scientific producers."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path('C:/tmp/elbo-cover-20260908')
B = ROOT / 'docs/derivations/2026-09-11-meta-agent-formation-frontier-and-locality'
OUT = B / 'evidence/native-coherence-response'


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))


def main() -> None:
    baseline = read(B / 'evidence/completion-reconciliation/baseline.json')
    completion = read(B / 'evidence/completion-reconciliation/inspection.json')
    previous = read(B / 'evidence/coherence-response/inspection.json')
    allowed = set(previous['modified_existing'])
    changed = [p for p, h in baseline['files'].items() if digest(ROOT / p) != h]
    external = {p: digest(Path(p)) == h for p, h in baseline['external_sources'].items()}
    prior_reports = {p: digest(ROOT / p) == h for p, h in completion['new_report_sha256'].items()}
    prior_reports.update({str((B / p).relative_to(ROOT)): digest(B / p) == h for p, h in previous['new_report_sha256'].items()})
    coefficients = read(OUT / 'moment-polynomials.json')
    windows = read(OUT / 'moment-window-enclosures.json')
    sources = {p: digest(B / p) == h for result in (coefficients, windows) for p, h in result['source_sha256'].items()}
    script_match = digest(OUT / 'response_moments.py') == coefficients['script_sha256']
    checks = {
        'coefficient_result_pass': coefficients['status'] == 'PASS_EXACT_RESPONSE_MOMENT_COEFFICIENTS',
        'seven_maps_112_terms': len(coefficients['rows']) == 7 and coefficients['term_count'] == 112,
        'window_result_pass': windows['status'] == 'PASS_NATIVE_RESPONSE_MOMENT_WINDOWS',
        'order_10': windows['jet_order'] == 10,
        'path_coordinate_error_factor': windows['coordinate_error_multiplier'] == 2,
    }
    display = [
        {'recognition': {'M': ('0.1812','0.1964'), 'T': ('0.3648','0.3967')}, 'model_posterior': {'M': ('0.1747','0.1903'), 'T': ('0.3515','0.3837')}},
        {'recognition': {'M': ('0.1194','0.1217'), 'T': ('0.2374','0.2422')}, 'model_posterior': {'M': ('0.1194','0.1216'), 'T': ('0.2373','0.2420')}},
    ]
    for i, (window, target, count, coefficient) in enumerate(zip(windows['results'], [(F(5),F(7)),(F(35),F(40))], [17,41], [F('0.628'),F('0.494')], strict=True)):
        rows = window['covered_intervals']
        checks[f'window_{i}_inventory'] = window['interval_count'] == len(rows) == count and tuple(map(F,window['window'])) == target
        ordered = sorted((F(row['left']),F(row['right'])) for row in rows)
        cursor = target[0]
        coverage = True
        for left, right in ordered:
            coverage = coverage and left <= cursor and left < right
            cursor = max(cursor,right)
        checks[f'window_{i}_coverage'] = coverage and cursor >= target[1]
        for law in ('recognition','model_posterior'):
            summary = window['summary'][law]
            moment_upper = F(summary['ranges']['M'][1])
            root_upper = F(summary['root_2M_upper'])
            checks[f'{i}_{law}_sqrt_encloses'] = root_upper**2 >= 2*moment_upper
            checks[f'{i}_{law}_strict_TV_coefficient'] = root_upper < coefficient
            for key in ('M','T','P'):
                lo,hi=map(F,summary['ranges'][key])
                checks[f'{i}_{law}_{key}_summary'] = lo == min(F(row[law][key][0]) for row in rows) and hi == max(F(row[law][key][1]) for row in rows) and 0 <= lo <= hi
                if key in ('M','T'):
                    d_lo,d_hi=map(F,display[i][law][key])
                    checks[f'{i}_{law}_{key}_outward_display'] = d_lo <= lo <= hi <= d_hi
            if i == 1:
                early = windows['results'][0]['summary'][law]['ranges']['M']
                checks[f'{law}_strict_moment_improvement'] = moment_upper < F(early[0])
                checks[f'{law}_strict_storage_saving'] = 16+4*F(summary['ranges']['P'][0]) > F('19.76')
    reports = ['native-coherence-response-episodes.md','native-coherence-response-law.md','native-response-parent-interface.md','native-coherence-response-reconstruction.md']
    links, formatting = [], []
    for name in reports:
        content = (B / name).read_text(encoding='utf-8')
        for n,line in enumerate(content.splitlines(),1):
            if line.rstrip() != line or any(token in line for token in ('\\;', '\\,', '\\!')):
                formatting.append({'report':name,'line':n})
        for raw in re.findall(r'\]\(([^\n)]+)\)',content):
            target = raw.strip('<>')
            if target.startswith(('https://','http://','#')):
                continue
            path=Path(target.split('#',1)[0])
            if not path.is_absolute():
                path=B/path
            links.append({'report':name,'target':target,'exists':path.exists(),'output_of_this_inspection':path.resolve()==(OUT/'inspection.json').resolve()})
    diff=subprocess.run(['git','-C',str(ROOT),'diff','--check'],capture_output=True,text=True)
    head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
    passed = (not (set(changed)-allowed) and all(external.values()) and all(prior_reports.values()) and all(sources.values()) and script_match and all(checks.values()) and not formatting and all(x['exists'] or x['output_of_this_inspection'] for x in links) and diff.returncode==0 and head==baseline['head'])
    result = {
        'status':'PASS' if passed else 'FAIL',
        'scope':'Read-only preservation, source binding, saved-result parsing, exact display inequalities, interval coverage and document checks. No scientific producer rerun or formal proof certificate.',
        'runtime':sys.executable,'python':sys.version.split()[0],'head':head,
        'baseline_count':len(baseline['files']),'unchanged_count':len(baseline['files'])-len(changed),
        'modified_existing':changed,'unexpected_changes':sorted(set(changed)-allowed),
        'external_sources_unchanged':external,'earlier_reports_unchanged':prior_reports,
        'saved_result_source_bindings':sources,'coefficient_script_binding':script_match,
        'saved_result_and_display_checks':checks,'local_links':links,'formatting_findings':formatting,
        'new_report_sha256':{name:digest(B/name) for name in reports},
        'new_evidence_sha256':{p.name:digest(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='inspection.json'},
        'git_diff_check':{'exit_code':diff.returncode,'stdout':diff.stdout,'stderr':diff.stderr},
    }
    (OUT/'inspection.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','baseline_count','unchanged_count','unexpected_changes','formatting_findings')}))
    print(json.dumps({'failed_checks':[k for k,v in checks.items() if not v]}))
    assert passed,'Inspect inspection.json for unresolved checks.'


if __name__ == '__main__':
    main()
