"""Enclose new response moments on the already certified native path; no ODE."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from math import comb, isqrt
from pathlib import Path
import platform
import sys
import time

HERE = Path(__file__).parent
B = HERE.parent.parent
OLD = HERE.parent / 'joint-native-episode'
KERNEL = HERE.parent / 'native-transient/native_interval_model.py'
spec = importlib.util.spec_from_file_location('response_interval_kernel', KERNEL)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
d, I = m.d, m.I
ORDER = 10


def log_jets(coefficients: list[list[F]], box: bool, perturb: I) -> list[list[I]]:
    result = []
    for row in coefficients:
        jet = []
        for j in range(ORDER+1):
            terms = [I.q(comb(k, j)*row[k]) for k in range(j, len(row))]
            value = d.evaluate(terms, I(-d.SCALE, d.SCALE)) if box else (terms[0] if terms else d.ZERO)
            jet.append(value+perturb if j == 0 else value)
        result.append(jet)
    return result


def compile_rows(rows: list[dict]) -> list[dict]:
    result = []
    for row in rows:
        terms = []
        for source in row['determinants']:
            polys = {}
            for key, name in (('D', 'coefficients'), ('N', 'response_numerator'), ('T', 'length_numerator')):
                polys[key] = [(tuple(v[:3]), int(F(v[3])) if F(v[3]).denominator == 1 else I.q(F(v[3]))) for v in source[name]]
            terms.append({'sign': source['sign'], **polys})
        result.append({'weight': I.q(F(row['weight'])), 'k': row['k'], 'terms': terms})
    return result


def normalizers(groups: list[dict], r: list[list[I]]) -> list[dict]:
    zero = d.constant(0, ORDER)
    powers = []
    for coordinate in r:
        values = [d.constant(1, ORDER)]
        for _ in range(4):
            values.append(d.mul(values[-1], coordinate))
        powers.append(values)
    monomials = {(a, b, c): d.mul(d.mul(powers[0][a], powers[1][b]), powers[2][c])
                 for a in range(5) for b in range(5-a) for c in range(5-a-b)}
    result = []
    for group in groups:
        e, nu, length = zero[:], zero[:], zero[:]
        for term in group['terms']:
            value = {}
            for key in ('D', 'N', 'T'):
                total = zero[:]
                for power, coefficient in term[key]:
                    total = d.add(total, d.scale(monomials[power], coefficient))
                value[key] = total
            inv = d.inv(value['D'])
            inv2 = d.mul(inv, inv)
            e = d.add(e, d.scale(inv, term['sign']))
            nu = d.add(nu, d.scale(d.mul(value['N'], inv2), I.q(F(term['sign'], 2))))
            length = d.add(length, d.scale(d.mul(value['T'], inv2), term['sign']))
        result.append({'e': e, 'nu': nu, 'T': length})
    return result


def mixture(groups: list[dict], values: list[dict], lam: list[I]) -> dict:
    zero = d.constant(0, ORDER)
    totals = {key: zero[:] for key in ('Z', 'M', 'T', 'P')}
    exponential = d.exponential(lam)
    for group, row in zip(groups, values):
        weight = d.scale(exponential if group['k'] == 2 else d.constant(1, ORDER), group['weight'])
        mass = d.mul(weight, d.mul(row['e'], row['e']))
        totals['Z'] = d.add(totals['Z'], mass)
        if group['k'] == 2:
            totals['P'] = d.add(totals['P'], mass)
        for name, moment in (('M', 'nu'), ('T', 'T')):
            totals[name] = d.add(totals[name], d.mul(weight, d.mul(row['e'], row[moment])))
    inverse = d.inv(totals['Z'])
    return {key: d.mul(totals[key], inverse) for key in ('M', 'T', 'P')}


def bound(groups: list[dict], coefficients: list[list[F]], error: F, model: bool) -> dict:
    radius = I.q(2*error)
    perturb = I(-radius.hi, radius.hi)
    selected = coefficients[:3]+[[F(0)]] if model else coefficients[3:6]+[coefficients[6]]
    center = log_jets(selected, False, perturb)
    box = log_jets(selected, True, perturb)
    if model:
        center[3] = box[3] = d.constant(0, ORDER)
    ec = normalizers(groups, [d.exponential(v) for v in center[:3]])
    eb = normalizers(groups, [d.exponential(v) for v in box[:3]])
    eb = m.tighten_time(ec, eb, ORDER)
    mc = mixture(groups, ec, center[3])
    mb = mixture(groups, eb, box[3])
    result = {}
    for key in mc:
        reach = sum(x.abs_hi() for x in mc[key][1:ORDER]) + mb[key][ORDER].abs_hi()
        value = I(max(mc[key][0].lo-reach, mb[key][0].lo, 0), min(mc[key][0].hi+reach, mb[key][0].hi))
        result[key] = value
    return result


def verify_candidate(row: dict, segments: list[dict]) -> None:
    left, right = F(row['left']), F(row['right'])
    segment = next(s for s in segments if F.from_float(s['t_old']) <= left and F.from_float(s['t']) >= right)
    coordinates = []
    for j in range(7):
        values = [F(0)]
        for k, coefficient in enumerate(reversed(segment['F'])):
            values[0] += F.from_float(coefficient[j])
            values = [F(0)]+values if k % 2 == 0 else [values[0]]+[values[i]-values[i-1] for i in range(1, len(values))]+[-values[-1]]
        values[0] += F.from_float(segment['y_old'][j])
        alpha = ((left+right)/2-F.from_float(segment['t_old']))/F.from_float(segment['h'])
        beta = (right-left)/(2*F.from_float(segment['h']))
        restricted = [sum((c*comb(k, q)*alpha**(k-q)*beta**q for k, c in enumerate(values) if k >= q), F(0)) for q in range(len(values))]
        coordinates.append([str(v) for v in restricted])
    assert coordinates == row['coefficients'], 'Saved response interval is not the certified path polynomial'


def square_root(value: I) -> I:
    assert value.lo >= 0
    lower = isqrt(value.lo*d.SCALE)
    upper = isqrt(value.hi*d.SCALE)
    upper += int(upper*upper < value.hi*d.SCALE)
    return I(lower, upper)


def main() -> None:
    start = time.perf_counter()
    source = HERE/'moment-polynomials.json'
    candidates = OLD/'readout-window-candidates.json'
    path = OLD/'path-enclosure.json'
    previous = OLD/'regime-window-enclosures.json'
    trajectory = OLD/'reference-trajectory.json'
    data = json.loads(source.read_text())
    certificate = json.loads(path.read_text())
    earlier = json.loads(previous.read_text())
    assert data['status'] == 'PASS_EXACT_RESPONSE_MOMENT_COEFFICIENTS'
    assert certificate['status'] == 'PASS_FULL_NATIVE_PATH_ENCLOSURE'
    assert earlier['status'] == 'PASS_TWO_NATIVE_REGIME_WINDOWS'
    for receipt in (data, certificate, earlier):
        for name, expected in receipt['source_sha256'].items():
            assert sha256((B/name).read_bytes()).hexdigest() == expected, name
    assert data['script_sha256'] == sha256((HERE/'response_moments.py').read_bytes()).hexdigest()
    groups = compile_rows(data['rows'])
    assert len(groups) == 7
    raw_trajectory = json.loads(trajectory.read_text())
    segments = raw_trajectory['dense_segments']
    windows = json.loads(candidates.read_text())
    error = F(certificate['weighted_uniform_error'])
    results = []
    for name, left, right in (('split_window', F(5), F(7)), ('merge_window', F(35), F(40))):
        chosen = [r for r in windows if F(r['right']) > left and F(r['left']) < right]
        assert F(chosen[0]['left']) <= left and F(chosen[-1]['right']) >= right
        assert all(F(a['right']) == F(b['left']) for a, b in zip(chosen, chosen[1:]))
        output = []
        for index, row in enumerate(chosen):
            verify_candidate(row, segments)
            coefficients = [[F(x) for x in line] for line in row['coefficients']]
            values = {law: bound(groups, coefficients, error, model) for law, model in (('recognition', False), ('model_posterior', True))}
            output.append({'left': row['left'], 'right': row['right'], **{law: {key: v.strings() for key, v in value.items()} for law, value in values.items()}})
            if (index+1) % 10 == 0:
                print(json.dumps({'window': name, 'covered_intervals': index+1}), flush=True)
        summary = {}
        for law in ('recognition', 'model_posterior'):
            ranges = {key: I.q(0) for key in ('M', 'T', 'P')}
            for key in ranges:
                ranges[key] = I(I.q(min(F(row[law][key][0]) for row in output)).lo, I.q(max(F(row[law][key][1]) for row in output)).hi)
            root = square_root(ranges['M'])
            sqrt2 = square_root(ranges['M']*2)
            decay = d.exp(I.q(F(-1, 2)))
            summary[law] = {'ranges': {key: v.strings() for key, v in ranges.items()},
                            'range_summary_float': {key: v.floats() for key, v in ranges.items()},
                            'root_M_upper': str(F(root.hi, d.SCALE)),
                            'root_2M_upper': str(F(sqrt2.hi, d.SCALE)),
                            'barycenter_fixed_channel_per_query_upper': str(F((decay*root).hi, d.SCALE)),
                            'barycenter_adaptive_channel_per_query_upper': str(F((decay*sqrt2).hi, d.SCALE))}
        results.append({'window': [str(left), str(right)], 'name': name, 'interval_count': len(output), 'summary': summary, 'covered_intervals': output})
    files = (Path(__file__), source, HERE/'response_moments.py', candidates, path, previous, trajectory, KERNEL, KERNEL.with_name('dyadic_interval.py'))
    result = {'status': 'PASS_NATIVE_RESPONSE_MOMENT_WINDOWS', 'runtime': sys.executable, 'python': platform.python_version(),
              'scope': 'New frozen-response moment readouts of the existing certified native law, with fixed geometric P candidate on every O/P ancestry draw. No ODE, prior choice, sampled dynamics or old science rerun.',
              'source_sha256': {str(p.relative_to(B)): sha256(p.read_bytes()).hexdigest() for p in files},
              'jet_order': ORDER, 'global_weighted_path_error': str(error), 'coordinate_error_multiplier': 2,
              'results': results, 'elapsed_seconds': time.perf_counter()-start}
    (HERE/'moment-window-enclosures.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'results': [{k: row[k] for k in ('name', 'interval_count', 'summary')} for row in results], 'elapsed_seconds': result['elapsed_seconds']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
