"""Exact arithmetic for coupled agreement-prior learning; no ODE simulation."""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
from math import comb,factorial
import hashlib
import json
import sys
import time

BASE=Path(__file__).resolve().parent
S=tuple[F,F]  # a+b*sqrt(2)


def add(x: S, y: S) -> S:
    return x[0]+y[0],x[1]+y[1]


def neg(x: S) -> S:
    return -x[0],-x[1]


def mul(x: S, y: S) -> S:
    return x[0]*y[0]+2*x[1]*y[1],x[0]*y[1]+x[1]*y[0]


def inv(x: S) -> S:
    den=x[0]*x[0]-2*x[1]*x[1]
    return x[0]/den,-x[1]/den


def scalar(x: int) -> S:
    return F(x),F(0)


def div(x: S, y: S) -> S:
    return mul(x,inv(y))


def lower_bound(x: S) -> F:
    lo,hi=F(7,5),F(10,7)
    assert lo*lo<2<hi*hi
    return x[0]+x[1]*(lo if x[1]>=0 else hi)


def jsonable(x: object) -> object:
    if isinstance(x,F):
        return str(x)
    if isinstance(x,dict):
        return {str(k):jsonable(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):
        return [jsonable(v) for v in x]
    return x


def main() -> None:
    start=time.perf_counter()
    success_rows=[]
    for n in (1,3,5):
        for rho in (F(1,2),F(2),F(7)):
            for delta in (F(0),F(n,2),F(n)):
                alpha=rho+delta
                mr,ma=1/(1+rho),1/(1+alpha)
                vr=1/(1+rho)**2
                rdot=(mr-ma)/vr
                closed=delta*(1+rho)/(1+rho+delta)
                assert rdot==closed
                adot=n-delta
                ddot=adot-rdot
                assert rdot>=0 and adot>=0
                if delta==0:
                    assert ddot==n
                if delta==n:
                    assert ddot<0
                success_rows.append({'n':n,'rho':rho,'delta':delta,'rho_dot':rdot,'alpha_dot':adot})
    beta_rows=[]
    for alpha in (F(1),F(2),F(5)):
        for beta in range(4):
            z=sum((F((-1)**j*comb(beta,j))/(alpha+j) for j in range(beta+1)),F(0))
            z1=sum((F((-1)**j*comb(beta,j))/(alpha+j)**2 for j in range(beta+1)),F(0))
            z2=sum((F(2*(-1)**j*comb(beta,j))/(alpha+j)**3 for j in range(beta+1)),F(0))
            product=F(factorial(beta))
            for j in range(beta+1):
                product/=alpha+j
            mean=sum((1/(alpha+j) for j in range(beta+1)),F(0))
            variance=sum((1/(alpha+j)**2 for j in range(beta+1)),F(0))
            assert z==product and z1/z==mean and z2/z-mean*mean==variance
            zp=sum((F((-1)**j*comb(beta,j))/(alpha+j+1) for j in range(beta+1)),F(0))
            prediction=alpha/(alpha+beta+1)
            assert zp/z==prediction
            beta_rows.append({'alpha':alpha,'beta':beta,'normalizer':z,'mean_D':mean,'variance_D':variance,'next_agreement':prediction})
    one,two=scalar(1),scalar(2)
    u=(F(0),F(1))
    alpha=add(u,one)
    assert mul(u,u)==two
    mean=add(inv(alpha),inv(add(alpha,one)))
    variance=add(mul(inv(alpha),inv(alpha)),mul(inv(add(alpha,one)),inv(add(alpha,one))))
    metric=inv(mul(u,u))
    curvature=add(metric,neg(variance))
    assert mean==inv(u)
    assert variance==(F(9,2),F(-3))
    assert curvature==(F(-4),F(3))
    assert lower_bound(variance)>0 and lower_bound(curvature)>0
    assert add(u,neg(mul(mul(u,u),mean)))==scalar(0)
    normalized_curvature=div(curvature,metric)
    assert normalized_curvature==(F(-8),F(6))
    discriminant=add(one,neg(normalized_curvature))
    assert discriminant==(F(9),F(-6)) and lower_bound(discriminant)>0
    assert lower_bound(add(one,neg(discriminant)))>0
    query=div(alpha,add(alpha,two))
    assert query==(F(1,7),F(2,7))
    prior_query=div(u,add(u,one))
    assert prior_query==(F(2),F(-1))
    evidence=div(u,mul(add(u,one),add(u,two)))
    score=add(inv(u),neg(mean))
    assert score==scalar(0)
    # Same combined energy, distinct separate channel energies.
    residuals=((F(1),F(2)),(F(2),F(1)))
    energies=[tuple(x*x/2 for x in row) for row in residuals]
    assert sum(energies[0])==sum(energies[1]) and energies[0]!=energies[1]
    result={'status':'PASS','python':sys.version,'seconds':time.perf_counter()-start,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'success_vector_field_cases':success_rows,'beta_integral_cases':beta_rows,
            'quadratic_field_convention':'[a,b] means a+b*sqrt(2)',
            'mixed_record_stationary':{'u':u,'alpha':alpha,'beta':1,'mean_D':mean,'variance_D':variance,'model_fisher':metric,'evidence_curvature':curvature,'normalized_evidence_curvature':normalized_curvature,'rate_discriminant':discriminant,'next_agreement':query,'prior_agreement':prior_query,'evidence':evidence},
            'separate_label_counterexample_energies':energies,
            'nonlinear_trajectory_integrated':False}
    (BASE/'result.json').write_text(json.dumps(jsonable(result),indent=2),encoding='utf-8')
    print(json.dumps(jsonable({'status':'PASS','seconds':result['seconds'],'success_cases':len(success_rows),'beta_cases':len(beta_rows),'stationary':result['mixed_record_stationary']})))


if __name__=='__main__':
    main()
