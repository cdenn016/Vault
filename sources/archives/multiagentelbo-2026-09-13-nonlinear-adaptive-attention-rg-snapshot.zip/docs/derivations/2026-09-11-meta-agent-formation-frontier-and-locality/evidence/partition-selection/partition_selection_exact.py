"""Exact finite checks for the agreement-record partition construction."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import sys

Partition = tuple[tuple[int, ...], ...]
Edge = tuple[int, int]


def components(n: int, edges: list[Edge], mask: int) -> Partition:
    """Return connected components of the undirected active edge copies."""
    parent = list(range(n))

    def find(i: int) -> int:
        while parent[i] != i:
            i = parent[i]
        return i

    for e, (i, j) in enumerate(edges):
        if mask & (1 << e):
            parent[find(i)] = find(j)
    blocks: dict[int, list[int]] = {}
    for i in range(n):
        blocks.setdefault(find(i), []).append(i)
    return tuple(sorted(tuple(block) for block in blocks.values()))


def probability(probabilities: list[F], mask: int) -> F:
    """Multiply the normalized conditional Bernoulli probabilities."""
    result = F(1)
    for e, p_e in enumerate(probabilities):
        result *= p_e if mask & (1 << e) else 1 - p_e
    return result


def partition_law(n: int, edges: list[Edge], probabilities: list[F]) -> dict[Partition, F]:
    """Push the complete bond law through its connected-component map."""
    result: dict[Partition, F] = {}
    for mask in range(1 << len(edges)):
        key = components(n, edges, mask)
        result[key] = result.get(key, F(0)) + probability(probabilities, mask)
    assert sum(result.values()) == 1
    return result


def all_partitions(n: int) -> list[Partition]:
    """Enumerate labeled set partitions once using restricted growth strings."""
    labels = [0] * n
    result: list[Partition] = []

    def visit(i: int, maximum: int) -> None:
        if i == n:
            result.append(tuple(tuple(j for j in range(n) if labels[j] == k)
                                for k in range(maximum + 1)))
            return
        for label in range(maximum + 2):
            labels[i] = label
            visit(i + 1, max(maximum, label))

    visit(1, 0)
    return result


def connected_probability(block: tuple[int, ...], edges: list[Edge], probabilities: list[F]) -> F:
    """Sum internal bond configurations that connect every vertex of the block."""
    if len(block) == 1:
        return F(1)
    lookup = {i: j for j, i in enumerate(block)}
    selected = [e for e, (i, j) in enumerate(edges) if i in lookup and j in lookup]
    inner_edges = [(lookup[edges[e][0]], lookup[edges[e][1]]) for e in selected]
    inner_probabilities = [probabilities[e] for e in selected]
    return sum((probability(inner_probabilities, mask)
                for mask in range(1 << len(selected))
                if len(components(len(block), inner_edges, mask)) == 1), F(0))


def factored_probability(partition: Partition, edges: list[Edge], probabilities: list[F]) -> F:
    """Use closed cross edges times internal connected-graph probabilities."""
    labels = {i: k for k, block in enumerate(partition) for i in block}
    result = F(1)
    for e, (i, j) in enumerate(edges):
        if labels[i] != labels[j]:
            result *= 1 - probabilities[e]
    for block in partition:
        result *= connected_probability(block, edges, probabilities)
    return result


def quotient_union(n: int, edges: list[Edge], first: int, second: int) -> Partition:
    """Contract first-stage components and apply second-stage edges exactly."""
    partition = components(n, edges, first)
    labels = {i: k for k, block in enumerate(partition) for i in block}
    coarse_edges = [(labels[i], labels[j]) for i, j in edges]
    coarse = components(len(partition), coarse_edges, second)
    return tuple(sorted(tuple(sorted(i for k in block for i in partition[k]))
                        for block in coarse))


def encoded_law(law: dict[Partition, F]) -> list[dict]:
    return [{'partition': partition, 'probability': str(value)}
            for partition, value in sorted(law.items())]


def main() -> None:
    """Check normalization, aggregation, common-data accounting, and non-nesting."""
    n = 4
    edges = [(0, 1), (1, 2), (2, 3), (0, 3)]
    probabilities = [[F(1, 2), F(1, 3), F(1, 4), F(2, 5)],
                     [F(3, 4), F(2, 3), F(1, 2), F(1, 5)]]
    masses = [F(1, 3), F(2, 3)]
    partitions = all_partitions(n)
    assert len(partitions) == 15
    laws = [partition_law(n, edges, ps) for ps in probabilities]
    for ps, law in zip(probabilities, laws):
        for partition in partitions:
            assert law.get(partition, F(0)) == factored_probability(partition, edges, ps)
    mixture = {partition: sum((m * law.get(partition, F(0))
                              for m, law in zip(masses, laws)), F(0)) for partition in partitions}
    mean_probabilities = [sum((m * ps[e] for m, ps in zip(masses, probabilities)), F(0))
                          for e in range(len(edges))]
    plugged = partition_law(n, edges, mean_probabilities)
    singletons = tuple((i,) for i in range(n))
    assert mixture[singletons] == F(13, 180)
    assert plugged[singletons] == F(77, 1215)
    assert mixture[singletons] - plugged[singletons] == F(43, 4860)
    bundle_probability = sum((m * (1 - (1 - ps[1]) * (1 - ps[3]))
                              for m, ps in zip(masses, probabilities)), F(0))
    plugged_bundle = 1 - (1 - mean_probabilities[1]) * (1 - mean_probabilities[3])
    assert bundle_probability == F(31, 45) and plugged_bundle == F(91, 135)

    first_ps = probabilities[0]
    second_ps = [F(2, 3), F(1, 2), F(3, 4), F(1, 5)]
    union_ps = [1 - (1 - p) * (1 - q) for p, q in zip(first_ps, second_ps)]
    staged: dict[Partition, F] = {}
    for first, second in product(range(16), repeat=2):
        direct = components(n, edges, first | second)
        assert quotient_union(n, edges, first, second) == direct
        staged[direct] = staged.get(direct, F(0)) + probability(first_ps, first) * probability(second_ps, second)
    assert staged == partition_law(n, edges, union_ps)

    # Three admissible law/link configurations: d/log(2) = (0,2), (1,0), (0,0).
    chain = [(0, 1), (1, 2)]
    state_ps = [[F(1), F(1, 4)], [F(1, 2), F(1)], [F(1), F(1)]]
    state_prior = [F(9, 10), F(9, 100), F(1, 100)]
    tilt = [p[0] * p[1] for p in state_ps]
    evidence_one = sum((q * ell for q, ell in zip(state_prior, tilt)), F(0))
    posterior_one = [q * ell / evidence_one for q, ell in zip(state_prior, tilt)]
    together_zero = sum((q * p[0] for q, p in zip(state_prior, state_ps)), F(0))
    together_one = sum((q * p[0] for q, p in zip(posterior_one, state_ps)), F(0))
    energy_zero = 2 * state_prior[0] + state_prior[1]
    energy_one = 2 * posterior_one[0] + posterior_one[1]
    assert evidence_one == F(7, 25)
    assert together_zero == F(191, 200) and together_one == F(103, 112)
    assert together_zero - together_one == F(99, 2800)
    assert energy_zero == F(189, 100) and energy_one == F(99, 56)
    assert energy_one < energy_zero
    counterexample_laws = []
    for weights in [state_prior, posterior_one]:
        mixture_row: dict[Partition, F] = {}
        for mass, ps in zip(weights, state_ps):
            for key, value in partition_law(3, chain, ps).items():
                mixture_row[key] = mixture_row.get(key, F(0)) + mass * value
        counterexample_laws.append(encoded_law(mixture_row))

    # Same two observations are retained under both representations.
    common_observation_evidence = F(1, 2) * F(1, 2)
    assert common_observation_evidence == F(1, 4)
    # For iid Exp(1) edge-energy priors: three initially closed bonds, then outer edges first.
    two_proper_blocks_probability = (1 - F(1, 2))**3 / 3
    assert two_proper_blocks_probability == F(1, 24)
    result = {
        'scope': 'Finite rational probability identities. No data collected, no nonlinear GL integration, no lineage simulation.',
        'runtime': sys.version, 'executable': sys.executable,
        'edges': edges, 'partitions_checked_per_state': len(partitions),
        'conditional_states_checked': 2, 'quotient_union_pairs_checked': 256,
        'mixture_singletons': str(mixture[singletons]), 'plugged_mean_singletons': str(plugged[singletons]),
        'mixture_minus_plugged': str(mixture[singletons] - plugged[singletons]),
        'mixture_cut_bundle_probability': str(bundle_probability),
        'plugged_cut_bundle_probability': str(plugged_bundle),
        'mixture_partition_law': encoded_law(mixture),
        'union_probabilities': [str(p) for p in union_ps],
        'counterexample': {'prior': [str(p) for p in state_prior],
                          'posterior_after_one_agreement_panel': [str(p) for p in posterior_one],
                          'evidence': str(evidence_one),
                          'pair_01_probability_before': str(together_zero),
                          'pair_01_probability_after': str(together_one),
                          'unavoidable_pair_split_mass_lower_bound': str(together_zero - together_one),
                          'expected_energy_in_units_log2_before': str(energy_zero),
                          'expected_energy_in_units_log2_after': str(energy_one),
                          'partition_laws': counterexample_laws},
        'same_two_record_evidence_all_representations': str(common_observation_evidence),
        'iid_exp1_chain_two_proper_blocks_probability': str(two_proper_blocks_probability),
        'all_assertions_passed': True}
    Path(__file__).with_name('partition-selection-exact-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in
                     ['partitions_checked_per_state', 'conditional_states_checked', 'quotient_union_pairs_checked',
                      'mixture_singletons', 'plugged_mean_singletons', 'counterexample',
                      'iid_exp1_chain_two_proper_blocks_probability', 'all_assertions_passed']}, indent=2))


if __name__ == '__main__':
    main()
