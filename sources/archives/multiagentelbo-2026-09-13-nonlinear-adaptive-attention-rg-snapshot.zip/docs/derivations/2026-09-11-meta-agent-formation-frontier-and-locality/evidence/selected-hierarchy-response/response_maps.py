"""Exact new response contrasts and forest decoders on the saved hierarchy maps."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys
import time

HERE = Path(__file__).parent
B = HERE.parent.parent
GEOMETRY = HERE.parent / 'joint-native-episode/uniform-panel-geometry.json'
PRIOR = HERE.parent / 'transported-parent-prior/result.json'
EDGES = ((0, 1), (1, 2), (2, 3), (3, 0))
Vector = list[F]
Matrix = list[Vector]


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def multiply(a: Matrix, b: Matrix) -> Matrix:
    return [[sum((x*b[k][j] for k, x in enumerate(row)), F(0)) for j in range(len(b[0]))] for row in a]


def key(partition: list, roots: list, trees: list) -> str:
    return json.dumps([partition, roots, trees], separators=(',', ':'))


def strings(matrix: Matrix) -> list[list[str]]:
    return [[str(x) for x in row] for row in matrix]


def main() -> None:
    start = time.perf_counter()
    prior = json.loads(PRIOR.read_text())
    geometry = json.loads(GEOMETRY.read_text())
    assert geometry['status'] == 'PASS_UNIFORM_SECOND_PANEL_GEOMETRY'
    assert geometry['source_sha256'] == digest(PRIOR)
    assert geometry['script_sha256'] == digest(GEOMETRY.with_name('uniform_panel_geometry.py'))
    residual = [[F(t == j)-F(t == i) for t in range(4)]+[-F(t == e) for t in range(4)] for e, (i,j) in enumerate(EDGES)]
    catalog = {}
    contrast_rows = []
    for row in prior['rows']:
        blocks, labels, k = row['partition'], row['labels'], row['k']
        cuts = [e for e,(i,j) in enumerate(EDGES) if labels[i] != labels[j]]
        for dec in row['details']:
            paths = [[F(x) for x in line] for line in dec['path_matrix']]
            marks = [[F(x) for x in line] for line in dec['C']]
            cotree = [e for e,mark in enumerate(marks) if any(mark)]
            first = [[F(i in block,len(block)) for i in range(4)]+[-sum(paths[i][e] for i in block)/len(block) for e in range(4)] for block in blocks]
            first += [[F(0)]*4+marks[e] for e in cotree]
            cut_maps, contrasts = {}, {}
            distinct = set()
            for e in cuts:
                i,j = EDGES[e]
                a,b = labels[i],labels[j]
                d = [F(t == b)-F(t == a) for t in range(k)]+[-F(other == e) for other in cotree]
                d_fine = multiply([d],first)[0]
                eta_fine = [x-y for x,y in zip(residual[e],d_fine)]
                coefficient = [paths[j][f]-sum(paths[v][f] for v in blocks[b])/len(blocks[b])-paths[i][f]+sum(paths[v][f] for v in blocks[a])/len(blocks[a]) for f in range(4)]
                assert multiply([coefficient],residual)[0] == eta_fine
                assert all(not coefficient[f] for f in cuts), 'Omitted contrast uses a cut instead of internal tree residuals'
                if any(coefficient):
                    sign = 1 if next(x for x in coefficient if x) > 0 else -1
                    distinct.add(tuple(sign*x for x in coefficient))
                cut_maps[e],contrasts[e] = d,coefficient
            if blocks == [[0,1],[2,3]]:
                assert cuts == [1,3]
                assert all(v == [F(-1,2),F(0),F(-1,2),F(0)] for v in contrasts.values())
            if k == 4:
                assert all(not any(v) for v in contrasts.values())
            unique = sorted(distinct)
            quadratic = [[sum((v[i]*v[j] for v in unique),F(0)) for j in range(4)] for i in range(4)]
            ident = key(blocks,dec['roots'],dec['trees'])
            assert ident not in catalog
            catalog[ident] = (row,dec,first,cotree,cut_maps)
            contrast_rows.append({'partition':blocks,'roots':dec['roots'],'trees':dec['trees'],'k':k,'cut_labels':cuts,'eta_residual_coefficients':{str(e):[str(x) for x in v] for e,v in contrasts.items()},'unique_up_to_sign':strings(unique),'quadratic_majorant':strings(quadratic)})
    outputs = []
    for branch in geometry['rows']:
        ident = key(branch['partition'],branch['roots'],branch['trees'])
        row,dec,first,cotree,cut_maps = catalog[ident]
        k,q = branch['k'],branch['q']
        labels,blocks = row['labels'],row['partition']
        selected,keep = branch['chosen_new_tree_edges'],branch['retained_nontree_edges']
        transform = [[F(x) for x in line] for line in branch['geometry_map']]
        augmented = transform+[cut_maps[e] for e in selected]
        width = 2*q+len(selected)
        assert len(selected) == k-q and len(augmented) == width
        new_labels = [next(c for c,component in enumerate(branch['second_partition']) if block[0] in component) for block in blocks]
        assert all(all(v in branch['second_partition'][new_labels[a]] for v in block) for a,block in enumerate(blocks))
        raw = [[F(0)]*width for _ in range(k)]
        xi = [[F(0)]*width for _ in range(k)]
        for c in range(q):
            component = [a for a in range(k) if new_labels[a] == c]
            root = min(component,key=lambda a:dec['roots'][a])
            seen,todo = {root},[root]
            while todo:
                a = todo.pop()
                for f,e in enumerate(selected):
                    u,w = (labels[i] for i in EDGES[e])
                    if a not in (u,w):
                        continue
                    b = w if a == u else u
                    if b in seen:
                        continue
                    raw[b] = raw[a][:]
                    raw[b][2*q+f] += 1 if a == u else -1
                    seen.add(b)
                    todo.append(b)
            assert seen == set(component)
            mass = sum(len(blocks[a]) for a in component)
            center = [sum((F(len(blocks[a]),mass)*raw[a][j] for a in component),F(0)) for j in range(width)]
            for a in component:
                xi[a] = [x-y for x,y in zip(raw[a],center)]
            assert all(sum((F(len(blocks[a]))*xi[a][j] for a in component),F(0)) == 0 for j in range(width))
        decoders = {}
        for e in branch['cut_labels']:
            a,b = (labels[i] for i in EDGES[e])
            ca,cb = new_labels[a],new_labels[b]
            decoded = [F(j == cb)-F(j == ca) for j in range(q)]+[-F(e == mark) for mark in keep]+[F(0)]*len(selected)
            decoded = [v+xb-xa for v,xa,xb in zip(decoded,xi[a],xi[b])]
            assert multiply([decoded],augmented)[0] == cut_maps[e]
            assert multiply(multiply([decoded],augmented),first) == multiply([cut_maps[e]],first)
            decoders[str(e)] = [str(x) for x in decoded]
        fields = 12+4*(k+q)
        assert fields == 12+4*width
        assert 12+8*k-fields == 4*(k-q)
        assert 36+4*k-fields == 24-4*q >= 8
        outputs.append({'partition':blocks,'roots':dec['roots'],'trees':dec['trees'],'active_mask':branch['active_mask'],'second_partition':branch['second_partition'],'k':k,'q':q,'stored_tree_response_edges':selected,'response_decoder':decoders,'augmented_second_map':strings(augmented),'displayed_fields':fields,'original_scalar_augmented_fields':branch['parent_fields'],'fine_fields':36+4*k,'split_to_parent_saving':4*(k-q),'fine_to_parent_saving':24-4*q})
    assert len(catalog) == len(contrast_rows) == 45 and len(outputs) == 176
    assert sum(len(x['cut_labels']) for x in contrast_rows) == 68
    summaries = sorted({(x['k'],x['q'],x['displayed_fields'],x['fine_to_parent_saving']) for x in outputs})
    files = (PRIOR,GEOMETRY,GEOMETRY.with_name('uniform_panel_geometry.py'),B/'common-prior-native-hierarchy-episodes.md',B/'native-response-parent-interface.md',B/'native-coherence-response-law.md')
    result = {'status':'PASS_SELECTED_HIERARCHY_RESPONSE_MAPS','scope':'New omitted-residual identities on all 45 decorations and new forest-response decoders on all 176 saved panel maps. Reads existing geometry; does not rerun its main program or any trajectory. No samples, tamper cases, or global minimality claim.',
              'runtime':sys.executable,'python':platform.python_version(),'script_sha256':digest(Path(__file__)),
              'source_sha256':{str(p.relative_to(B)):digest(p) for p in files},
              'decorations':len(catalog),'panel_cases':len(outputs),'cut_contrast_count':sum(len(x['cut_labels']) for x in contrast_rows),
              'counts_by_k_q':[{'k':k,'q':q,'displayed_fields':n,'fine_saving':saving} for k,q,n,saving in summaries],
              'contrasts':contrast_rows,'panel_response_maps':outputs,'elapsed_seconds':time.perf_counter()-start}
    (HERE/'response-maps.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','decorations','panel_cases','cut_contrast_count','counts_by_k_q','elapsed_seconds')},indent=2))


if __name__ == '__main__':
    main()
