"""Inspect selected-hierarchy reports and saved evidence without rerunning science."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import re
import subprocess
import sys

ROOT = Path('C:/tmp/elbo-cover-20260908')
B = ROOT / 'docs/derivations/2026-09-11-meta-agent-formation-frontier-and-locality'
OUT = B / 'evidence/selected-hierarchy-response'


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))


def main() -> None:
    baseline = read(B/'evidence/completion-reconciliation/baseline.json')
    completion = read(B/'evidence/completion-reconciliation/inspection.json')
    coherence = read(B/'evidence/coherence-response/inspection.json')
    native = read(B/'evidence/native-coherence-response/inspection.json')
    allowed = set(native['modified_existing'])
    changed = [p for p,h in baseline['files'].items() if digest(ROOT/p) != h]
    external = {p:digest(Path(p)) == h for p,h in baseline['external_sources'].items()}
    old_reports = {p:digest(ROOT/p) == h for p,h in completion['new_report_sha256'].items()}
    for receipt in (coherence,native):
        old_reports.update({str((B/p).relative_to(ROOT)):digest(B/p) == h for p,h in receipt['new_report_sha256'].items()})
    old_evidence = {p:digest(B/'evidence/native-coherence-response'/p) == h for p,h in native['new_evidence_sha256'].items()}
    result = read(OUT/'response-maps.json')
    source_bindings = {p:digest(B/p) == h for p,h in result['source_sha256'].items()}
    checks = {
        'response_map_status':result['status'] == 'PASS_SELECTED_HIERARCHY_RESPONSE_MAPS',
        'script_matches_execution':digest(OUT/'response_maps.py') == result['script_sha256'],
        '45_decorations':result['decorations'] == len(result['contrasts']) == 45,
        '68_cut_contrasts':result['cut_contrast_count'] == sum(len(r['cut_labels']) for r in result['contrasts']) == 68,
        '176_panel_cases':result['panel_cases'] == len(result['panel_response_maps']) == 176,
    }
    expected_counts = [(k,q,12+4*(k+q),24-4*q) for k in range(1,5) for q in range(1,k+1)]
    actual_counts = [(r['k'],r['q'],r['displayed_fields'],r['fine_saving']) for r in result['counts_by_k_q']]
    checks['all_reported_counts'] = actual_counts == expected_counts
    checks['all_branch_counts'] = all(r['displayed_fields'] == 12+4*(r['k']+r['q']) and r['split_to_parent_saving'] == 4*(r['k']-r['q']) and len(r['stored_tree_response_edges']) == r['k']-r['q'] for r in result['panel_response_maps'])
    previous_maps = read(B/'evidence/joint-native-episode/uniform-panel-geometry.json')['rows']
    def ident(row: dict) -> str:
        return json.dumps([row['partition'],row['roots'],row['trees'],row['active_mask']])
    checks['exact_previous_case_inventory'] = {ident(r) for r in previous_maps} == {ident(r) for r in result['panel_response_maps']}
    windows = read(B/'evidence/native-coherence-response/moment-window-enclosures.json')
    for i,constant in enumerate((F('0.628'),F('0.494'))):
        for law in ('recognition','model_posterior'):
            summary=windows['results'][i]['summary'][law]
            upper=F(summary['root_2M_upper'])
            checks[f'{i}_{law}_strict_transferred_coefficient'] = upper < constant and upper**2 >= 2*F(summary['ranges']['M'][1])
    regimes=read(B/'evidence/joint-native-episode/regime-window-enclosures.json')['results'][1]
    storage={}
    for law in ('recognition','model_posterior'):
        upper=max(F(r[law]['P_split'][1]) for r in regimes['covered_intervals'])
        lower=20-4*upper
        storage[law]={'P_split_upper':str(upper),'new_reference_storage_lower':str(lower)}
        checks[f'{law}_new_storage_over_18'] = lower > 18
    reports=['selected-hierarchy-response.md','selected-hierarchy-response-law.md','selected-hierarchy-response-interface.md','selected-hierarchy-response-reconstruction.md']
    links,formatting=[],[]
    for name in reports:
        text=(B/name).read_text(encoding='utf-8')
        for number,line in enumerate(text.splitlines(),1):
            if line.rstrip() != line or any(token in line for token in ('\\;','\\,','\\!')):
                formatting.append({'report':name,'line':number})
        for raw in re.findall(r'\]\(([^\n)]+)\)',text):
            target=raw.strip('<>')
            if target.startswith(('https://','http://','#')):
                continue
            path=Path(target.split('#',1)[0])
            if not path.is_absolute(): path=B/path
            links.append({'report':name,'target':target,'exists':path.exists(),'output_of_this_inspection':path.resolve() == (OUT/'inspection.json').resolve()})
    diff=subprocess.run(['git','-C',str(ROOT),'diff','--check'],capture_output=True,text=True)
    head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
    passed=(not (set(changed)-allowed) and all(external.values()) and all(old_reports.values()) and all(old_evidence.values()) and all(source_bindings.values()) and all(checks.values()) and all(r['exists'] or r['output_of_this_inspection'] for r in links) and not formatting and diff.returncode == 0 and head == baseline['head'])
    receipt={'status':'PASS' if passed else 'FAIL','scope':'Read-only preservation, result/source binding, reported scalar inequalities and case inventory, document/link checks. No scientific producer rerun, proof-by-test, or formal ledger certificate.',
             'runtime':sys.executable,'python':sys.version.split()[0],'head':head,'baseline_count':len(baseline['files']),'unchanged_count':len(baseline['files'])-len(changed),
             'modified_existing':changed,'unexpected_changes':sorted(set(changed)-allowed),'external_sources_unchanged':external,'earlier_reports_unchanged':old_reports,'native_response_evidence_unchanged':old_evidence,
             'new_result_source_bindings':source_bindings,'checks':checks,'fresh_storage_inequalities':storage,'local_links':links,'formatting_findings':formatting,
             'new_report_sha256':{name:digest(B/name) for name in reports},'new_evidence_sha256':{p.name:digest(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'inspection.json'},
             'git_diff_check':{'exit_code':diff.returncode,'stdout':diff.stdout,'stderr':diff.stderr}}
    (OUT/'inspection.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:receipt[k] for k in ('status','baseline_count','unchanged_count','unexpected_changes','formatting_findings')}))
    print(json.dumps({'failed_checks':[k for k,v in checks.items() if not v]}))
    assert passed,'Inspect inspection.json for unresolved findings.'


if __name__ == '__main__':
    main()
