"""Check current proof bindings and document links, not mathematical truth."""

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote

run = Path(__file__).resolve().parent
source = run.parent.parent
repo = source.parents[2]
snapshot = json.loads((run / 'source-snapshot.json').read_text(encoding='utf-8'))
errors = []
for item in snapshot['proofs']:
    for path in (Path(item['source']), run / item['snapshot']):
        if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
            errors.append('changed proof: ' + str(path))
for item in snapshot['sources']:
    if hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() != item['sha256']:
        errors.append('changed source: ' + item['path'])
names = [Path(item['source']).name for item in snapshot['proofs']]
names += ['endogenous-rates-and-coherence.md', 'successive-coalescence-construction.md', 'conditional-lag-and-parent-vfe.md']
link_count = 0
for name in names:
    path = source / name
    text = path.read_text(encoding='utf-8-sig')
    if any(ord(c) < 32 and c not in '\n\r\t' for c in text):
        errors.append('control character: ' + name)
    if re.search(r'\\[,;!]', text):
        errors.append('forbidden LaTex spacing macro: ' + name)
    for match in re.finditer(r'\]\((<[^>]+>|[^\s)]+)\)', text):
        target = match.group(1).strip('<>')
        if target.startswith(('https:', 'http:', '#', 'mailto:')):
            continue
        target = unquote(target.split('#', 1)[0])
        if not target:
            continue
        linked = Path(target)
        if not linked.is_absolute():
            linked = path.parent / linked
        link_count += 1
        if not linked.exists():
            errors.append('missing link in ' + name + ': ' + target)
validator = Path('C:/Users/chris and christine/.codex/skills/rigorous-theory-search/scripts/validate_run.py')
checked = subprocess.run([sys.executable, '-I', '-B', str(validator), str(run), '--mode', 'release'], capture_output=True, text=True)
if checked.returncode:
    errors.append('release validator: ' + checked.stdout + checked.stderr)
diff = subprocess.run(['git', 'diff', '--check'], cwd=repo, capture_output=True, text=True)
if diff.returncode:
    errors.append('git diff --check: ' + diff.stdout + diff.stderr)
result = dict(scope='Written-proof metadata and document inspection; not mathematical proof or scientific tests.',
    proof_bindings=len(snapshot['proofs']), source_bindings=len(snapshot['sources']), documents=len(names),
    local_link_occurrences=link_count, release_validator_exit_code=checked.returncode,
    git_diff_check_exit_code=diff.returncode, errors=errors, passed=not errors)
(run / 'validation.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result))
raise SystemExit(bool(errors))
