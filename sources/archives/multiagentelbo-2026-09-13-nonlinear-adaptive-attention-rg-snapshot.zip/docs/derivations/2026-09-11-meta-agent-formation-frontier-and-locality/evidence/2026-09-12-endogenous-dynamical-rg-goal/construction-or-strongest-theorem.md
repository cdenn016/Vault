<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c","target_digest":"b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c"} -->

# Finite construction

The complete theorem and proof are in proofs/translation-link-conditional-bridge.md, Sections 1–8. With common local mobility, positive fixed channel variances, independent translation links and a proper reference prior, the supplied local contrast K/k induces restoring scales. Three separated nodes form a pair before the remaining cut relaxes. The inherited first parent has the same later episode at finite K.

The 10-to-5 Schur parent has explicit path, conditional-force and transient-VFE error bounds. The 5-to-3 root projection is exact. Gaussian conditional log ratios give entropy control for an open class of non-Gaussian positive-density preparations. Conditional costs and normalized augmented kernels compose through the same two maps. Small positive T, a finite logarithmic entropy horizon and then sufficiently large K satisfy all hypotheses together.

This is the frozen existential result, not a universal hierarchy theorem. The three independent calculations in proofs/ reconstruct its rates/normalization, formation, and conditional entropy interfaces.
