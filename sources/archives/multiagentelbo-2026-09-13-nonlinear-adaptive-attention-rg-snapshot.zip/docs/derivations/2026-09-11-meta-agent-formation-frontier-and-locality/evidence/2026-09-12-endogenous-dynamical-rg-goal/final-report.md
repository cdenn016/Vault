<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c","target_digest":"b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c"} -->

# Rigorous theory search report

## Frozen contract

The four-step existential target is unchanged in problem-contract.json: derived rates under common local kinetics, dynamical grouping, controlled hidden conditional effects, and an actual subsequent coalescence using inherited parents. Scope is one base point and one nonempty finite family, with declared model inputs.

## Terminal status

COMPLETE_AFFIRMATIVE for that finite target. This status rests on written derivations and their reconstruction, not on a schema validator or agent agreement.

## Certificate

The exact construction is proofs/translation-link-conditional-bridge.md. Sections 1–2 establish types, normalization and the common update; Section 3 proves fine formation; Section 4 derives parent laws and kinetics; Sections 5–7 prove conditional KL, force, VFE, paths, inherited second formation and a compatible parameter regime.

## Strongest verified result

A normalized Gaussian translation-link model with ten coordinates and one common microscopic mobility has five fast normal modes and two slower cut modes from its specified energy weights. A pair forms first and later joins the third node. Its inherited five-coordinate first parent has a quantified nonzero approximation error and an actual later merger at finite strength. The three-coordinate final root is an exact projection. Both fine and inherited-parent conditional VFE costs are controlled for a nonempty open positive-density family at positive temperature.

## Dependency closure

The ledger separates the target, rates, grouping, conditional lag, subsequent episode, joined regime, microscopic normalization, parent laws, first dynamics and final projection. Every entry is supported by a written derivation bound to the current proof snapshot. No unproved compact-interface claim is an ancestor of the target.

## Independent reconstruction

Three experts investigated parallel compact/dynamical/entropy routes, then reconstructed separate aspects of the joined Gaussian proof. Their complete rate/parent, formation and conditional-lag derivations are in proofs/. Corrections included the delta-dependent early exponent, both retained cut modes, the hidden-mean projection term, explicit initial-law topology, parent presentation types and exact-root versus approximate-first scope.

## Oracle erasure

reconstruction-and-erasure.md removes the desired outcome and checks the remaining premises. The model inputs remain explicit; matrix identities, ODE crossings, Gaussian normalizers and entropy estimates do not assume a preferred grouping, a new parent rate, or conditional matching.

## Unresolved obligations

None within the frozen finite existential target. The compact angular route's second conditional-entropy interface is an unresolved alternative-route obligation, not evidence for the Gaussian witness. Generalizing the result requires a new scoped question.

## Scope and limitations

The microscopic interaction contrast, fixed law covariances, coherent proper reference and flat kinetics are supplied. Parent laws retain correlated vector presentations and structural marks. The result neither learns those inputs nor selects a unique or permanent hierarchy, proves infinite depth, or identifies a universal physical clock. The first reduction remains approximate with explicit errors. No GPU, full suite, historical rerun, Lean, tamper check, vault edit or Git publication is part of this continuation.
