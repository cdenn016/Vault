# Independent check of Gaussian translation-link formation

September 12, 2026. This document checks the proposed global Gaussian
extension for the current endogenous dynamical-RG contract. It owns no
other derivation or evidence file. The deterministic episode bounds are
valid after one small correction: the lower cut comparison uses
\(e^{-(3+\delta)t}\), not \(e^{-3t}\). The correction preserves the
required strict margin. The complete constrained parent has two cut
rates, \(8/3\) and \(1\); the \(8/3\) formula alone describes its
channel-symmetric sector.

## 1. Exact scope and checked source

The question is whether there exists a nonempty open finite-dimensional
parameter and initial-data regime for the specified normalized
translation-link model, with common microscopic mobility, an actual
proper-pair formation interval, and a later whole-path formation
interval. This check concerns the proposed finite graph at one point
\(c_*\), with finite-time deterministic and positive-noise bounds. It
does not claim arbitrary-graph formation, active translation invariance
of a proper prior, or general nonlinear parent closure.

The checked source is
[normalized-alignment-parent-limit.md](normalized-alignment-parent-limit.md),
Sections 1 and 3: its additive translation action is admitted on the
general measurable-action tier; link coordinates are independent before
alignment; a proper prior transforms passively rather than being
actively invariant under all translations.
[microscopic-vfe-dynamics-construction.md](microscopic-vfe-dynamics-construction.md),
Sections 2–7, supplies the normalized physical evaluator, correlated
conditional recognition, exact evaluator cost, and the distinction
between local law-point sampling and full-joint Fisher inference.
The earlier [successive compact construction](successive-coalescence-construction.md)
supplies a comparison target, not evidence for the Gaussian equations.
The live PIFB2 source sections and September research synthesis consulted
for that construction retain their same source-first role here.

The user supplies the two normalized law channels, independent dynamic
links, common peer-node update prescription, fixed-base restriction,
and requirement that episodes follow actual dynamics. The proposed
specialization adds a finite path, fixed Gaussian variances, quadratic
intrinsic couplings and pinning, a coherent prior reference, and unit
Euclidean mobility. A large microscopic coupling \(K\), small pinning
\(\delta\), and separated initial residuals are explicit model inputs.
No desired grouping is inserted into a state update.

## 2. Normalization, evaluator, and translation types

Use the coordinate order

\[
W=(u_1,u_2,u_3,v_1,v_2,v_3,
       \ell_{12}^b,\ell_{23}^b,\ell_{12}^m,\ell_{23}^m)\in\mathbb R^{10}.
\]

The four links act on the sample line by translation. For \(0<a<1\),

\[
b_i=N(u_i,1),\quad m_i=N(v_i,a),\qquad
\zeta_i\sim m_i,\quad k_i\mid\zeta_i\sim N(\zeta_i,1-a).
\tag{1}
\]

The edge residuals are \(x_b=u_1-u_2-\ell_{12}^b\),
\(x_m=v_1-v_2-\ell_{12}^m\),
\(y_b=u_2-u_3-\ell_{23}^b\), and
\(y_m=v_2-v_3-\ell_{23}^m\). Let \(D\) have rows \(u_i-v_i\);
let \(B_f\) consist of the three rows of \(D\) and the rows \(x_b,x_m\);
let \(B_s\) consist of \(y_b,y_m\).

Assume explicitly

\[
B_fW_{\rm ref}=0,\qquad B_sW_{\rm ref}=0,
\tag{2}
\]

and put \(w=W-W_{\rm ref}\). The proposed prior is

\[
H_0=\delta I+K B_f^\top B_f+kB_s^\top B_s,\qquad
P_0=N(W_{\rm ref},T H_0^{-1}),
\quad \delta,K,k,T>0.
\tag{3}
\]

Since \(H_0\succeq\delta I\), this is proper, nondegenerate, and has
Lebesgue normalizer
\((2\pi T)^5/\sqrt{\det H_0}\).
Condition (2) is load-bearing: it identifies the quadratic edge and
bridge residuals in \(w\) with those of the actual physical laws.
An arbitrary incoherent reference would add residual offsets and
change the displayed drift.

The correlated inner recognition
\(\zeta_i=v_i+\xi_i,\ k_i=u_i+\xi_i+\epsilon_i\), with independent
\(\xi_i\sim N(0,a)\), \(\epsilon_i\sim N(0,1-a)\), has marginals (1).
The Gaussian density ratio calculation gives the exact optimized
conditional evaluator cost

\[
d(W)=\frac{\|DW\|^2}{2(1-a)}
=\frac{\|Dw\|^2}{2(1-a)},\qquad
H=H_0+\frac{T}{1-a}D^\top D.
\tag{4}
\]

Thus the outer optimizer is \(\Pi=N(W_{\rm ref},TH^{-1})\), generally
different from the generative prior. The full generative experiment
\(P_0\prod_i m_i\operatorname{ev}_i\) is normalized by conditional
integration. The evaluator remains a physical generative kernel;
(4) is its variational restriction cost. For every finite-KL outer
law \(Q\),

\[
\mathcal F_T(Q)
=T\operatorname{KL}(Q\Vert P_0)+T\mathbb E_Qd
=T\operatorname{KL}(Q\Vert\Pi)
  +\frac T2\log\frac{\det H}{\det H_0}.
\tag{5}
\]

All inverse matrices are justified by their positive lower bound.

The microscopic kinetic postulate is

\[
dw=-Hwdt+\sqrt{2T}dB_t.
\tag{6}
\]

Every one of the ten coordinates uses the same mobility. Each drift
reads only its pinning term, same-node bridge, and incident edge
residuals. This is an admitted local Langevin realization. It is
not full-joint Fisher flow for the Gaussian recognition mean: the
latter has a different inverse metric. No kinetic conclusion follows
from (5) alone.

For common passive node-frame translations \(g_i\), define

\[
u_i'=u_i+g_i,\quad v_i'=v_i+g_i,\quad
\ell_{ij}^{x\prime}=\ell_{ij}^x+g_i-g_j,\quad
W_{\rm ref}'=W_{\rm ref}+Gg,
\tag{7}
\]

where \(Gg\) collects those ten shifts. All residual rows annihilate
\(Gg\), and \(w'=w\). Lebesgue measure and unit mobility are unchanged.
The sample variables \(k_i,\zeta_i\) translate by \(g_i\), so (1)
pushes forward covariantly. Therefore (3)–(6) are covariant under
(7). Holding \(W_{\rm ref}\) fixed while translating the state is
an active change and does not preserve the pinning energy.

Separate belief/model frame translations require an affine
cross-channel offset in the evaluator and bridge, transformed along
with those frames. The formula \(u_i-v_i\) is the common-frame
specialization. It is not covariant under two unrelated frame shifts
while the cross-channel map is kept fixed. No nontrivial translation
holonomy is exhibited on this path graph, which has no cycles.

## 3. Exact nominal dynamics and formation bounds

Take \(k=1\), \(K\ge256\), and \(0<\delta\le1/100\).
Use the symmetric initial slice

\[
u_i=v_i,\qquad \ell_{12}^b=\ell_{12}^m,\qquad
\ell_{23}^b=\ell_{23}^m.
\]

Here the equalities refer to centered coordinates, equivalently
absolute coordinates after using a common coherent reference.
This slice is invariant, because every bridge residual vanishes
and the two channel fields agree. One five-coordinate channel
\(w_c=(u_1,u_2,u_3,\ell_{12},\ell_{23})\) obeys

\[
\dot w_c=-\delta w_c-Ka^\top x-b^\top y,\qquad
a=(1,-1,0,-1,0),\quad b=(0,1,-1,0,-1).
\]

Since \(|a|^2=|b|^2=3\) and \(ab^\top=-1\), the proposed residual
equations are exactly

\[
\boxed{\dot x=-(3K+\delta)x+y,\qquad
       \dot y=Kx-(3+\delta)y.}
\tag{8}
\]

For \(z=y+x/3\), the cancellation is also exact:

\[
\boxed{\dot z=-\delta z-\frac83 y
       =-\left(\delta+\frac83\right)z+\frac89x.}
\tag{9}
\]

Choose

\[
x_0\in(1/4,1/3),\qquad y_0\in(1/8,1/6),\qquad
w_{c,0}=(x_0+y_0,y_0,0,0,0).
\tag{10}
\]

**Formation statement.** Every nominal deterministic solution from
(10) satisfies

\[
\begin{array}{ll}
t\in I_1=[1/64,1/16]:&
0<x<1/512,\qquad y>1299/12800>1/10,\\
t\in I_2=[3,4]:&
0<x<1/512,\qquad 0<y<5/4608<1/256.
\end{array}
\tag{11}
\]

**Proof.** The off-diagonal coefficients in (8) are nonnegative.
At either positive-quadrant boundary the field points inward.
Moreover \(\dot x\ge-(3K+\delta)x\) and
\(\dot y\ge-(3+\delta)y\), proving strict positivity for positive
initial data. Equation (9) makes \(z\) nonincreasing. The boundary
\(x=x_0\) points inward, because \(y\le z<5/18\) whereas
\((3K+\delta)x_0>192\). A first-exit argument gives

\[
0<x\le x_0<1/3,\qquad 0<y\le z\le z_0<5/18.
\tag{12}
\]

Using only \(y<1\) in (8),

\[
x(t)\le\frac13e^{-3Kt}+\frac1{3K}.
\tag{13}
\]

At \(t\ge1/64\), \(3Kt\ge12\). Since
\(e^{10}>20000\), proved from the positive exponential series,
\(x<1/60000+1/768<1/512\).

For the early cut lower bound,

\[
y(t)\ge y_0e^{-(3+\delta)t}
>\frac18e^{-301/1600}
>\frac18\left(1-\frac{301}{1600}\right)
=\frac{1299}{12800}.
\tag{14}
\]

Here \(e^{-s}>1-s\) for \(s>0\) follows by convexity of the
exponential, or its integral remainder. This corrects the
\(e^{-3t}\) comparison, which would omit the pinning contribution.

Put \(c=8/3\). From (9), dropping the nonpositive
\(-\delta z\) term and integrating (13),

\[
z(t)\le
\left[\frac5{18}+\frac{8}{27(3K-c)}\right]e^{-ct}
+\frac1{9K}
<\frac13e^{-ct}+\frac1{9K}.
\tag{15}
\]

The bracket is less than \(1/3\) for \(K\ge256\). For \(t\ge3\),
\(e^{-ct}\le e^{-8}<1/512\), since
\(e>8/3\) gives \(e^8>(8/3)^8>512\).
Hence \(y\le z<1/1536+1/2304=5/4608\).
This proves (11) globally, without a localization argument. \(\square\)

For physical laws (1), transported edge KL is \(x_b^2/2\) or
\(x_m^2/(2a)\), and similarly for the cut. Thus joining an edge
when both channel residuals have magnitude below \(1/32\) is a
gauge-invariant scaled-KL criterion. Initially both edges fail.
Throughout \(I_1\), only edge 12 passes, giving
\(\{1,2\}\mid\{3\}\). Throughout \(I_2\), both pass.
These groups are consequences of (8), (10), and (11). The supplied
coupling hierarchy makes their order possible; the argument does
not derive that hierarchy from an arbitrary graph.

The small pinning is not the explanation for the cut relaxation:
at \(\delta=0\), (9)'s cut coefficient is still \(8/3\).
Positive \(\delta\) supplies a proper global population law and
slow collective drift. Exact alignment is a limit or a constrained
description, not a finite-time equality for the open noisy family.

## 4. The full fast and cut mode content

The complete fast-row Gram matrix, in row order
\((D_1,D_2,D_3,x_b,x_m)\), is

\[
B_fB_f^\top=
\begin{pmatrix}
2&0&0&1&-1\\
0&2&0&-1&1\\
0&0&2&0&0\\
1&-1&0&3&0\\
-1&1&0&0&3
\end{pmatrix}.
\tag{16}
\]

The \(D_1+D_2\), \(D_3\), and \(x_b+x_m\) normalized row-index
directions have eigenvalues \(2,2,3\). The remaining normalized
difference directions give the block
\(\left(\begin{smallmatrix}2&2\\2&3\end{smallmatrix}\right)\).
Therefore

\[
\operatorname{spec}(B_fB_f^\top)
=\left\{2,2,3,\frac{5-\sqrt{17}}2,
                  \frac{5+\sqrt{17}}2\right\}.
\tag{17}
\]

In particular \(B_f\) has rank five and nonzero fast stiffness
at least \(K(5-\sqrt{17})/2\). The evaluator term adds a positive
semidefinite matrix on this same fast complement and cannot remove
that gap.

Let \(S=\ker B_f\) and let \(P_S\) be its Euclidean orthogonal
projector. On \(S\), the nodes have \(u_i=v_i\), both strong links
equal \(u_1-u_2\), and the two cut links remain independent.
The symmetric weak row \((y_b+y_m)/\sqrt2\) is orthogonal to all
\(D_i\), has squared norm 3, and overlap \(-1\) with the normalized
strong symmetric row of squared norm 3. Its projection therefore
has squared norm \(3-1/3=8/3\). The antisymmetric weak row has,
after restriction to \(S\), only the normalized difference of the
two cut links and has squared norm 1. These two projected directions
are orthogonal. Consequently

\[
B_sP_SB_s^\top=
\begin{pmatrix}11/6&5/6\\5/6&11/6\end{pmatrix},
\qquad
\operatorname{spec}(B_sP_SB_s^\top)=\{8/3,1\}.
\tag{18}
\]

This is a necessary cross-channel correction when the first
elimination includes all five rows of \(B_f\). Two uncoupled copies
of \(8/3\) would miss the cut-link difference mode.

The constrained first parent has inherited drift

\[
\dot Y=-\delta Y-kP_SB_s^\top B_sY,\qquad Y\in S,
\tag{19}
\]

with the original Euclidean metric restricted to \(S\). Its two
cut relaxation rates are \(\delta+8k/3\) and \(\delta+k\); its
remaining three modes have rate \(\delta\). No rate is reset.
The channel-symmetric trajectory occupies the \(8/3\) cut mode.
A full parent description must retain the other cut mode until
it is actually eliminated or quantitatively controlled.

Both weak rows remain independent after restriction, so
\(\operatorname{rank}(B_f;B_s)=7\) and the final coherent kernel
has dimension three. Its coordinates can be expressed as three
node-law shifts with the corresponding coherent link shifts.
With fixed physical prior reference these are collective
displacements relative to that reference. They should not be
called physical relaxation of a passive change that simultaneously
moves \(W_{\rm ref}\): that operation leaves \(w\) unchanged.

The discarded rows are genuine mismatch coordinates. Varying a
node with its incident links fixed, or varying a link with its
endpoints fixed, changes the relevant residual and incurs strictly
positive quadratic action. Their elimination is not deletion of
the three kernel/gauge directions. The choice of a spectral
parent at finite \(K\), versus the strict-constraint parent (19),
must be stated: the former has exact Gaussian modal closure, while
(19) is a large-\(K\) constrained limit with finite-\(K\) corrections.

On the symmetric slice alone, the two nontrivial decay rates are
exactly

\[
\delta+
\frac{3(K+1)\pm\sqrt{9(K-1)^2+4K}}2.
\tag{20}
\]

They follow from the characteristic polynomial of (8), and the
smaller tends to \(\delta+8/3\).
This is an explicit check that the rate in (19) comes from the
microscopic equations.

## 5. Full open perturbations and a global noise bound

The symmetric slice is not the final initial-data restriction.
Fix \(K_*>256\), \(0<\delta_*<1/100\), \(k_*=1\), a positive
temperature, and one nominal centered initial state (10).
Its norm is bounded by

\[
\|w_{*,0}\|^2
=2[(x_0+y_0)^2+y_0^2]<5/9<1.
\]

For perturbed positive parameters write
\(\Delta_H=\|H_p-H_*\|_{\rm op}\), and
\(\epsilon_0=\|w_{p,0}-w_{*,0}\|\).
The explicit sufficient coefficient bound is

\[
\Delta_H\le
|\Delta\delta|+12|\Delta K|+6|\Delta k|
+6\left|\Delta\left(\frac T{1-a}\right)\right|.
\tag{21}
\]

The constants use row norm sums, so they are conservative operator
bounds. All positive nearby parameter choices give \(H_p\succ0\).

The reference solution has
\(\|w_*(t)\|\le\|w_{*,0}\|<1\).
For \(E=w_p-w_*\),

\[
\dot E=-H_pE-(H_p-H_*)w_*,\qquad
D^+\|E\|\le\Delta_H .
\]

Thus, globally,

\[
\sup_{t\le4}\|w_p(t)-w_*(t)\|
\le\epsilon_0+4\Delta_H.
\tag{22}
\]

Choose \(\rho=1/(4096\sqrt3)\) and require the strict inequality
\(\epsilon_0+4\Delta_H<\rho\).
This is a nonempty full-dimensional open neighborhood of all
ten initial coordinates and a relative-open neighborhood of
the declared microscopic parameters. It includes transverse
channel differences and independent perturbations of every
link. Every edge residual changes by less than \(1/4096\), so
all episode inequalities retain strict threshold margins.
For two such error budgets,
\(1299/12800-2/4096>1/10\).

For the stochastic solution of (6), compare with the deterministic
solution from the same initial point and stop when their difference
first has norm \(\rho\), or at \(H=4\). Since \(H_p\succ0\),
Itô's formula gives

\[
d\|E_t\|^2
\le20Tdt+2\sqrt{2T}E_t^\top dB_t.
\]

The stopped integral has expectation zero. At an exit the squared
norm is \(\rho^2\), whence

\[
\Pr\left[\sup_{t\le4}
  \|w_t-w_t^{\rm det}\|\ge\rho\right]
\le80T/\rho^2.
\tag{23}
\]

No chart, boundary-flux, or localization error is present on
\(\mathbb R^{10}\). Add the initial probability outside the
chosen neighborhood to obtain the unconditional bound.
For example, \(Q_0=N(m_0,TH^{-1})\) is a proper correlated
recognition law whose covariance remains \(TH^{-1}\) under
(6), as the covariance equation
\(\dot\Sigma=-H\Sigma-\Sigma H+2TI\) shows.
Its initial fluctuation obeys

\[
\Pr[\|W_0-m_0\|\ge\rho]\le
\frac{T\operatorname{tr}(H^{-1})}{\rho^2}
\le\frac{10T}{\delta\rho^2}.
\tag{24}
\]

The exact Gaussian conditional entropy can be calculated without
a bounded density-ratio assumption; a shifted Gaussian generally
has unbounded \(q_0/\Pi\). Importing a compact-model bounded-ratio
constant into this global Gaussian example would therefore be
incorrect. Equations (23)–(24) are path/concentration bounds and
are not themselves entropy estimates.

The independent link drift in centered coordinates is

\[
\dot\ell_{12}^x=-\delta\ell_{12}^x+Kx_x,\qquad
\dot\ell_{23}^x=-\delta\ell_{23}^x+ky_x.
\tag{25}
\]

At the initial reference (10) these are \(Kx_0>0\) and
\(y_0>0\). They remain nonzero on a nonzero initial interval
under small full perturbations. Each link also has its own
nondegenerate Brownian driver. Correlation, or equality on the
nominal comparison slice, does not remove their independent
coordinate or dynamical status.

## 6. Conclusion and exact boundaries

The proposed Gaussian trajectory witness is sound in the stated
specialization. Equations (8)–(15) prove actual initially split,
proper-pair, and later whole-path episodes. Equations (21)–(24)
supply full open transverse and positive-noise extensions.
The graph and coupling hierarchy are supplied; their realized
coherent groups are derived from the evolving residuals. The
reference pinning is a covariant prior datum, not an actively
translation-invariant probability law.

The two corrections to carry into the parent construction are
the \((3+\delta)\) early cut exponent and the full two-cut
mobility matrix (18). The generative/variational distinction in
(5), the affine cross-channel-frame qualification, and the
difference between spectral and strict-constraint parents also
remain load-bearing.

This file does not prove the parent's complete finite-\(K\)
Gaussian conditional-memory identity; that belongs to the
parent's bridge artifact. The next decisive check is that its
retained matrices, conditional Gaussian kernels, VFE corrections,
and two successive channels use the same full \(H\), including
the antisymmetric cut mode. A sign/rank error in (8), (16), or
(18), an incoherent unaccounted reference, or a missing conditional
correction would invalidate the corresponding construction.
No agreement among agents substitutes for those calculations.

No numerical integration, code test, new evidence file, suite,
GPU operation, Lean work, tamper scenario, vault edit, or Git
action was performed for this independent check. Its evidence
is the explicit calculation above.


## 7. Reconstruction of the final Gaussian bridge

The completed source
[translation-link-conditional-bridge.md](translation-link-conditional-bridge.md)
was read in full after its final corrections. This reconstruction is bound
to SHA-256

`19999cf85c9f47e01a946e7bc9401b4a9ad887815d879ff30396718eb0a8f9a7`.

The hash identifies the checked artifact; it is not mathematical evidence
for its claims. The calculations below address its final Gaussian route,
not the earlier compact angular route. The earlier statement in Section 6
that the finite-\(K\) bridge had not yet been checked is superseded by
this section.

### 7.1 Actual finite-\(K\) second formation under the inherited parent

The source retains \(y=E^\top w\), with \(E\) an orthonormal basis of
\(\ker B_f\). Its first parent uses the exact conditional precision
\(S=C-BA^{-1}B^\top\), not just the limiting constrained precision.
The fast coordinate complement is generally not an invariant eigenspace
of the finite-\(K\) microscopic \(H\); the cross block \(B\) is retained
in both \(S\) and the error estimate.

To reconstruct the parent's actual episode, choose channel-symmetric
orthonormal coordinates. The same-node \(D\) block vanishes on this
sector, so the relevant five-coordinate precision is exactly

\[
H_{\rm sym}=\delta I+Ka^\top a+b^\top b.
\]

Let \(P_a=I-a^\top a/3\), \(v=P_ab^\top\), and use the unit fast
column \(f=a^\top/\sqrt3\). Then

\[
A_{\rm sym}=f^\top H_{\rm sym}f=\delta+3K+1/3,\quad
B_{\rm sym}=-v/\sqrt3,\quad
C_{\rm sym}=\delta I+vv^\top,\quad |v|^2=8/3.
\]

Consequently the exact Schur parent is

\[
S_{\rm sym}
=\delta I+\left(1-\frac1{3A_{\rm sym}}\right)vv^\top,
\]

and its physical per-channel cut mean is

\[
\bar z_c(t)=
\left(y_0+\frac{x_0}{3}\right)e^{-\lambda_p t},\qquad
\lambda_p=
\delta+\frac83\left(1-\frac1{3A_{\rm sym}}\right).
\tag{26}
\]

No limit is taken in (26). The initial value is exactly
\(bP_aw_0=y_0+x_0/3\), obtained from the first retained map.
The stochastic parent initialized from \(E^\top_\#Q_0^*\) has this
mean; it does not receive a newly prepared state.

For \(K\ge256\), \(3A_{\rm sym}>9K+1\), giving
\(\lambda_p>5/2\). Also \(\lambda_p\le\delta+8/3\).
Since \(5/24<y_0+x_0/3<5/18\), for \(t\le1/16\),

\[
\bar z_c(t)>
\frac5{24}
 \left(1-\frac{803}{4800}\right)
=\frac{19985}{115200}>\frac16.
\]

For \(t\ge3\),

\[
0<\bar z_c(t)<\frac5{18}e^{-15/2}<\frac1{256}.
\]

For the last inequality,
\(e^{15/2}=e^6e^{3/2}>(8/3)^6(5/2)>512\).
Thus the actual inherited parent has a noncoherent cut during the first
pair episode and a small cut later. This is stronger than noting that
the final projection exists algebraically at time zero.

The antisymmetric cut mode, of limiting mobility \(1\), is retained in
the full first parent. It vanishes at the symmetric witness center and
is admitted as a small transverse perturbation. The same finite-horizon
continuity argument applies to its nonzero perturbations. No kinetic
coefficient changes between these equations and the microscopic model.

### 7.2 The first covariance is already the inherited one

In the orthogonal \((y,z)\) coordinates, block inversion gives

\[
(H^{-1})_{yy}=S^{-1},\qquad
z\mid y\ \hbox{under }\Pi
\sim N(-A^{-1}B^\top y,TA^{-1}).
\]

Thus the specified fine preparation
\(Q_0^*=N(m_0,TH^{-1})\) has first marginal

\[
Q_{0,y}^*=N(E^\top m_0,TS^{-1}).
\]

This is exactly the stationary covariance of the autonomous first
parent \(d\bar y=-S\bar ydt+\sqrt{2T}dB^y\).
It is inherited by marginalization. It is not a separately chosen
parent covariance or a claim that the fine hidden conditional mean is
equilibrated. That mean differs from the optimizer by
\(\theta=m_z+A^{-1}B^\top m_y\), which is nonzero at the displayed
noncoherent preparation.

For the joint fine/parent coupling, use the same random \(y_0\)
and Brownian \(B^y\). With
\(\xi=z+A^{-1}B^\top y\), the fine Gaussian covariance gives
\(\operatorname{Cov}(\xi)=TA^{-1}\) and
\(\mathbb E\xi=\theta\). Integrating

\[
y_t-\bar y_t
=-\int_0^t e^{-S(t-s)}B\xi_sds
\]

and using \(\|e^{-St}\|\le1\) proves the source's path estimate.
In particular its first term is
\(L\|B\|\sqrt{5T/a_*}\), and integration of the mean bound supplies
the stated \(r(0)/a_*^{3/2}\) and \(O(L/a_*^2)\) terms.

The source now also retains the needed hidden-mean correction

\[
\|m_z\|
\le \frac r{\sqrt{a_*}}
   +\frac{\|B\|\|m_0\|}{a_*}.
\tag{27}
\]

Controlling \(\xi\) alone would not bound \(z\).
On the global noise event, (27) plus \(2\rho\) bounds the hidden
path, and therefore both \(B_fFz\) and the cut correction \(B_sFz\).
This closes the previously identified transfer omission.

### 7.3 Exact generative versus variational conditional accounting

Write the generative blocks as \(C_0,B_0,A_0\). Because \(DE=0\),
the current model has \(C_0=C\), \(B_0=B\), and
\(A=A_0+\tau F^\top D^\top DF\). Put
\(S_0=C-BA_0^{-1}B^\top\). Completing the square gives the explicit
retained evaluator cost

\[
d_1(y)=
\frac12\log\frac{\det A}{\det A_0}
+\frac1{2T}y^\top(S-S_0)y.
\tag{28}
\]

Both terms are nonnegative:
\(A\succeq A_0\) implies
\(A^{-1}\preceq A_0^{-1}\), hence \(S\succeq S_0\).
The true generative parent is \(N(0,TS_0^{-1})\), while its
variational optimizer is \(N(0,TS^{-1})\). Equation (28) accounts
for both the determinant and quadratic difference. They cannot
be interchanged without changing the objective.

Let \(R_W\) be the original correlated inner recognition.
For a retained density \(r(y)\), the lifted family is

\[
\widehat Q_r(dy,dz,d\zeta,dk)
=r(dy)k_1(dz\mid y)R_W(d\zeta,dk).
\]

Its KL against the unchanged augmented generative law is exactly

\[
T\operatorname{KL}(\widehat Q_r\Vert P_{\rm aug})
=T\operatorname{KL}(r\Vert P_{01})+T\mathbb E_r d_1.
\tag{29}
\]

This follows by the log chain rule and
\(\log(k_1/P_0(\cdot\mid y))+d=d_1(y)\).
For arbitrary fine \(Q\), replacing its hidden conditional by
\(k_1\) drops exactly the conditional KL stated in the source.

This is the precise augmented conditional-family interpretation.
It does not assert that simply discarding hidden \(z\) from the
physical joint \((y,z,\zeta,k)\) leaves its KL unchanged.
That additional marginalization generally loses another
conditional relative entropy.

The physical generative presentation can nevertheless be integrated
exactly. If \(V\) selects the three model means and
\(L_0=E-FA_0^{-1}B^\top\), then

\[
\zeta\mid y\sim
N\left(v_{\rm ref}+VL_0y,
aI_3+TVFA_0^{-1}F^\top V^\top\right),\qquad
k\mid\zeta\sim N(\zeta,(1-a)I_3).
\tag{30}
\]

The latter kernel is independent of hidden \(W\) once \(\zeta\)
is known. This verifies the source's explicit correlated parent
model/presentation and output laws. Recognition uses the optimizer
conditional \(k_1\), which is a different kernel.

The maps \(w\mapsto E^\top w\mapsto J^\top E^\top w=R^\top w\)
are global linear maps. Augment them by retaining \((\zeta,k)\)
when the original physical labels are needed. The dimensions
\(10\to5\to3\) count configuration coordinates; the complete
augmented carriers then have dimensions \(16\to11\to9\).
Their normalized generative marginals, induced evaluator kernels,
and specified lifted recognition families all use those same maps.

The chart
\(u=v=(\alpha+t,\alpha,\beta)\),
\(\ell_{12}^b=\ell_{12}^m=t\), with independent
\((s_b,s_m)\), shows that the first five retained coordinates
contain the pair root, its internal relative mark, the untouched
third root, and two cut links. Its Gram metric is

\[
G=
\begin{pmatrix}
4&2&0&0&0\\2&4&0&0&0\\
0&0&2&0&0\\0&0&0&1&0\\0&0&0&0&1
\end{pmatrix}.
\tag{31}
\]

The two weak covectors against \(G^{-1}\) reproduce (18).
This checks the parent-versus-exterior typing of the first
reduction. It does not require a product prior between those
retained components.

Since \(H_0R=HR=\delta R\), the final root is independent of its
normal complement under both centered Gaussian laws, and its
generative and variational marginal are both
\(N(0,T\delta^{-1}I_3)\).
The final evaluator cost is the constant
\(d_2=\frac12\log(\det H/\det H_0)\), consistent with (5).
Sequential conditional integration and direct integration agree
by the tower property, including this nonzero constant.
The root stochastic equation is the exact common projection
\(dq=-\delta qdt+\sqrt{2T}dB^q\).

### 7.4 Conditional mean lag, force, and entropy really use one family

Differentiating
\(\theta=m_z+A^{-1}B^\top m_y\), with fixed \(A,B,S\), gives

\[
\dot\theta=
-(A+A^{-1}B^\top B)\theta-A^{-1}B^\top S m_y.
\]

With \(r^2=\theta^\top A\theta\),

\[
\frac12\frac d{dt}r^2
=-\theta^\top A^2\theta-\|B\theta\|^2
-\theta^\top B^\top S m_y.
\]

The last term is at most
\(r\|B\|\|S\|\|m_0\|/\sqrt{a_*}\), proving the source's
Dini inequality and its \(a_*^{-3/2}\) plateau.
The reference hidden conditional covariance is \(TA^{-1}\);
therefore its exact conditional KL is \(r^2/(2T)\).

For \(Q_0\) in the stated KL neighborhood, the same OU Markov
kernel gives
\(\operatorname{KL}(Q_t\Vert Q_t^*)\le\eta^2\).
Its conditional part \(J_t\) is at most \(\eta^2\). A Gaussian
entropy bound yields

\[
\mathbb E_{Q_y}
\left\|A^{1/2}
 \left(\mathbb E_Q[z\mid y]-\mathbb E_{Q_t^*}[z\mid y]\right)
\right\|^2
\le2TJ_t .
\]

Expanding the affine log ratio of the two Gaussian conditional
targets and applying Cauchy–Schwarz gives

\[
\Delta_1(Q_t)
\le J_t+\frac{r^2}{2T}
       +2\sqrt{J_t}\frac r{\sqrt{2T}}
\le\left(\eta+\frac r{\sqrt{2T}}\right)^2.
\tag{32}
\]

The same entropy bound against \(k_1\), without the mean shift,
gives the parent's \(L^2(Q_y)\) force defect

\[
\left\|B\left(\mathbb E_Q[z\mid y]+A^{-1}B^\top y\right)\right\|_{L^2(Q_y)}
\le\|BA^{-1/2}\|\sqrt{2T\Delta_1(Q_t)}.
\tag{33}
\]

These estimates concern the actual fine recognition conditional.
They do not infer dimensionless entropy from small path distance.

At the second stage, the normal complement of the final root is
orthogonal and invariant for \(H\), so the reference conditional
normal covariance is \(TH_N^{-1}\), independent of the root.
The same shifted-Gaussian argument gives the source's second
conditional entropy bound. The autonomous first parent has its
own inherited mean \(e^{-St}E^\top m_0\) and the already inherited
covariance \(TS^{-1}\). Its normal entropy is bounded separately
by applying that same calculation to \(S\). For general \(Q_0\),
data processing puts its first initial marginal within the same
KL radius of \(Q_{0,y}^*\), and common parent evolution contracts
that relative entropy. Thus the fine and autonomous first-parent
second-stage claims do apply to one shared initial-law family.

### 7.5 A genuinely simultaneous finite open regime

The final source identifies the complete seven-row Gram spectrum.
It can be checked by channel symmetry. Its symmetric edge block
is the two-edge Gram matrix
\(\left(\begin{smallmatrix}3&-1\\-1&3\end{smallmatrix}\right)\),
giving eigenvalues \(2,4\). In the antisymmetric sector, the
three bridge rows give a residual eigenvalue \(2\) and couple to
the two nonzero path-incidence singular modes. For path Laplacian
values \(\ell=1,3\), the two blocks are

\[
\begin{pmatrix}2&\sqrt{2\ell}\\
\sqrt{2\ell}&1+\ell\end{pmatrix}.
\]

Their eigenvalues are \(2\pm\sqrt2\) and \(3\pm\sqrt7\).
This proves \(b_*=3-\sqrt7>0\).

For \(K\ge k\), every vector normal to the final kernel has
quadratic energy at least
\((\delta+kb_*)\|w\|^2\).
If \(y\) is in the first parent's root-normal plane, then
\(Ey+Fz\) is normal to the final kernel for every \(z\).
Minimizing over \(z\) proves the same lower bound for \(S\).
The source's uniform full and first-parent normal gap is therefore
an exact quadratic-form consequence, not just an asymptotic
eigenvalue prediction.

Fix positive interior \(\delta,k,a\) and bounded means near the
nominal center. On \(0<T\le T_0\) and sufficiently large \(K\),
\(B,C,S\) are uniformly bounded, \(a_*\) grows linearly in \(K\),
and \(r(0)^2=O(K)\). Thus
\(e^{-2a_*t_b}r(0)^2\) is uniformly bounded and tends to zero
for fixed \(t_b=1/64\).
The decomposition
\(m^\top Hm=m_y^\top Sm_y+r^2\) gives the claimed uniform
post-burn-in normal energy bound \(C_0\).
The autonomous parent initial normal energy is bounded directly
by \(\|S\|\|E^\top m_0\|^2\).

For any target final entropy tolerance, a horizon satisfying

\[
L\ge
\max\left\{4,
1+t_b+\beta_0^{-1}
 \log\frac{2\sqrt{C_0/(2T)}}{\sqrt{\varepsilon_{\rm KL}}}
\right\}
\tag{34}
\]

makes the decaying reference contribution below half the
square-root tolerance. Hence \(L=O(1+\log(1/T))\).
The microscopic noise failure is bounded by
\(20TL/\rho^2+10T/(\delta\rho^2)\), which tends to zero with \(T\).
Choose a positive \(T\) and the resulting finite \(L\) first;
then choose small \(\eta\), and finally finite large \(K\).
At this fixed \(T,L\), the first conditional lag and the path
bound both tend to zero with increasing \(K\).
There is no requirement to change \(T\) or the kinetic rule after
the first episode.

The final validation interval may be later than \([3,4]\):
geometry becomes small before its dimensionless KL necessarily
does. The source explicitly uses \([L-1,L]\) for the latter.
Both intervals belong to the same trajectory and parameters.

For explicit openness, take normalized
\(Q_0=fQ_0^*\) with
\(\|f-1\|_\infty<\nu<1\).
Taylor's bound
\(\operatorname{KL}(Q_0\Vert Q_0^*)
\le\nu^2/[2(1-\nu)]\)
places a nonempty weighted-\(L^\infty\) open neighborhood inside
the KL ball. It contains correlated non-Gaussian densities.
Finite-time matrix exponential and Schur-complement continuity
then preserve all strict inequalities under small positive
parameter and mean perturbations.
For horizon \(L\), the explicit deterministic perturbation
condition is
\(\epsilon_0+L\|\Delta H\|\|m_0\|<\rho\);
the earlier factor 4 is replaced by that actual horizon.
A neighborhood of positive residual weights preserves the
kernel used for exact final closure. Arbitrary anisotropic
pinning is excluded, as the source now states, because it
would generally destroy \(HR=\delta R\).

## 8. Final checked result and boundary

For the source SHA recorded in Section 7, the normalization,
common kinetic prescription, strict first-pair interval, actual
finite-\(K\) inherited-parent second episode, full open
initial-law family, conditional force/VFE control, and second
conditional entropy estimate have the calculations needed for
the stated finite Gaussian specialization. The same positive
\(T\), finite \(K\), and finite \(L\) support the joined result.

The corrections raised during reconstruction are present in
that source: pinning in the early exponent; both cut modes;
the hidden conditional-mean transfer term; a specified
density topology for openness; finite-\(K\) parent decay;
the augmented dimensions; and explicit nonzero first-stage
approximation error. No unresolved mathematical defect was
identified in the reconstructed claims at that SHA. This is
not a ledger closure or a claim about arbitrary models.

The remaining scope is substantive but explicit: the interaction
hierarchy and common flat metric are supplied, the reference is
passively transformed prior data, the gauge group is additive
and the graph a finite tree, and coarse physical kernels may
retain the original presentation/output labels. A stronger
claim about ordinary single-law-point parents, active
translation-invariant proper priors, unrestricted pinning,
or arbitrary/infinite hierarchies would require new arguments.
The next action that changes the answer is either checking a
changed source revision or relaxing one of these stated
specialization assumptions; merely repeating this calculation
would not add evidence.

Only this assigned document was changed for the final
independent reconstruction. The primary source was read and
hashed, not edited. No numerical experiment, suite, GPU job,
Lean work, tamper scenario, or publication was performed.

## 9. Binding after spacing-only cleanup

The current primary source is now bound to SHA-256
`f966e62c8875eac523cbbfaf6f54c23e7ab98d489dce073d97b639068cbf72a5`.
An executed read-only byte comparison against
`evidence/2026-09-12-endogenous-dynamical-rg-goal/proofs/translation-link-conditional-bridge.md`
confirmed that it equals the previously checked source with exactly three
LaTeX thin-space commands removed: each command is the two-byte sequence
92, 44 in decimal. The saved source hash is
`19999cf85c9f47e01a946e7bc9401b4a9ad887815d879ff30396718eb0a8f9a7`;
the total difference is exactly six deleted bytes, with no other change.

Before adding this binding paragraph, the same read-only comparison
confirmed that this check document equaled its saved proof snapshot after
only thirteen thin-space commands and four negative-thin-space commands
were removed; the latter command has byte sequence 92, 33. No medium-space
commands were present. The difference was exactly 34 deleted bytes.
The saved check hash was
`328d1686d7b24a864cf2ec5b68d53fb9e9c8aeba3c498f31af23c665c0cf5714`,
and the current check hash before this append was
`10698e2263de7f9c85b7285778b7d1cccb14db6a0bb2e908437daf992643e301`.

These commands affect displayed spacing only. Their removal changes no
mathematical symbol, coefficient, assumption, domain, kinetic equation,
probability kernel, bound, or conclusion. The derivations in Sections 7–8
therefore apply unchanged to the newly bound primary source. The executed
comparison used byte equality after precisely those deletions; no research
claim was inferred from hash equality alone, and no scientific test or
new mathematical investigation was run.
