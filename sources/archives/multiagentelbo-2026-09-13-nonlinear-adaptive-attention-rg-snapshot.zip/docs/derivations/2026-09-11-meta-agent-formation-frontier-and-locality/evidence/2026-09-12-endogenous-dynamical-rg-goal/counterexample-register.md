<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c","target_digest":"b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c"} -->

# Counterexamples and unresolved alternative routes

For H=[[C,B],[B^T,A]], initialize hidden means at -A^-1 B^T Y0. Fine and averaged first derivatives agree, but their second derivatives differ by B A^-1 B^T S Y0. Thus exact first-stage projectability is false generically. The construction keeps a controlled approximation.

A hidden Gaussian mean displacement epsilon with variance T has KL epsilon^2/(2T); small geometric distance alone does not control dimensionless entropy. The completed route uses the exact conditional shift identity instead.

Principal residual coordinates on the compact torus have identification boundaries, so replacing them by a globally reflecting cube discards actual interface current. The compact second-entropy interface remains open. The global Gaussian witness has no such boundary.

An active translation of state while holding a proper reference prior fixed is not a gauge re-expression. Passive covariance requires transforming the reference. The construction states this explicitly. These are analytic counterexamples/scope checks, not artifact corruption or adversarial-packet tests.
