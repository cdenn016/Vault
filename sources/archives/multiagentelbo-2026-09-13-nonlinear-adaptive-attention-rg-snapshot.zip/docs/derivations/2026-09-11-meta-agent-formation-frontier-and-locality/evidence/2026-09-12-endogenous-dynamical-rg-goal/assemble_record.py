"""Assemble the frozen written-proof record; this does not prove mathematics."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess


RUN = Path(__file__).resolve().parent
SOURCE = RUN.parent.parent
REPO = SOURCE.parents[2]
CONTRACT = json.loads((RUN / 'problem-contract.json').read_text(encoding='utf-8-sig'))
META = {key: CONTRACT[key] for key in ('schema_version', 'contract_id', 'target_digest')}
HEADER = '<!-- rigorous-theory-search-metadata ' + json.dumps(META, separators=(',', ':')) + ' -->\n\n'
FROZEN = 'f966e62c8875eac523cbbfaf6f54c23e7ab98d489dce073d97b639068cbf72a5'


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name: str, data: dict) -> None:
    (RUN / name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def write_markdown(name: str, text: str) -> None:
    (RUN / name).write_text(HEADER + text.strip() + '\n', encoding='utf-8')


assert digest(SOURCE / 'translation-link-conditional-bridge.md') == FROZEN
proof_names = {
    'construction': 'translation-link-conditional-bridge.md',
    'rates': 'gaussian-rates-parent-independent-check.md',
    'formation': 'gaussian-formation-independent-check.md',
    'lag': 'gaussian-lag-independent-check.md',
}
for name in list(proof_names.values())[1:]:
    assert FROZEN in (SOURCE / name).read_text(encoding='utf-8-sig'), name
(RUN / 'proofs').mkdir(exist_ok=True)
for name in proof_names.values():
    shutil.copyfile(SOURCE / name, RUN / 'proofs' / name)

assumptions = [
    ('A1', 'Fixed-point three-node translation-link family, Gaussian channel variances 1 and a in (0,1), coherent reference pushed under passive frame changes, and proper common reference precision delta>0.'),
    ('A2', 'Independent positive microscopic residual energy weights, with internal contrast K/k large; these weights are supplied and are not derived from scalar VFE.'),
    ('A3', 'One common unit flat Riemannian mobility with matched positive-temperature noise for every law/link coordinate; not full-joint Fisher reaction kinetics.'),
    ('A4', 'Finite horizon and open positive-density initial preparation near a noncoherent mean Gaussian with stationary covariance, with explicit weighted-L-infinity and KL radii.'),
    ('A5', 'Parents retain normalized augmented conditional-family kernels, structural marks, generative versus optimizing conditional distinctions, and all induced scalar VFE costs.'),
]
ledger = json.loads((RUN / 'claim-ledger.json').read_text(encoding='utf-8-sig'))
ledger['assumptions'] = [dict(id=i, kind='MODELING_POSTULATE', statement=s) for i, s in assumptions]
ledger['evidence'] = [dict(id='proof-' + key, kind='DERIVATION', supports=True,
    scope='Written analytical proof in ' + name, side_conditions=[s for _, s in assumptions],
    artifact_path='proofs/' + name, artifact_sha256=digest(RUN / 'proofs' / name))
    for key, name in proof_names.items()]
extra_claims = {
    'normalized-model': 'The specified microscopic augmented generative law and exact constrained VFE are normalized and retain the evaluator cost.',
    'parent-laws': 'Both normalized generative parent laws and their conditional-family VFE costs compose by the same Gaussian disintegration.',
    'first-dynamics': 'The first inherited autonomous parent approximates the actual retained process with the stated finite-horizon force, path-event and entropy errors.',
    'final-projection': 'The final three-coordinate root process is exactly the same projection of the fine process and first inherited parent.',
}
known = {c['id'] for c in ledger['claims']}
for key, statement in extra_claims.items():
    if key not in known:
        ledger['claims'].append(dict(id=key, statement=statement,
            quantifiers='For all data in the admitted family and bounds of the frozen target.', kind='MATHEMATICAL',
            target_digest=META['target_digest'], falsifier=CONTRACT['target']['falsification_criterion']))
support = {
    'target': ['construction', 'rates', 'formation', 'lag'],
    'derived-rates': ['construction', 'rates'], 'dynamic-grouping': ['construction', 'formation'],
    'conditional-lag': ['construction', 'lag'], 'subsequent-episode': ['construction', 'rates', 'formation', 'lag'],
    'joined-regime': ['construction', 'formation', 'lag'], 'normalized-model': ['construction', 'rates'],
    'parent-laws': ['construction', 'rates', 'lag'], 'first-dynamics': ['construction', 'lag'],
    'final-projection': ['construction', 'rates'],
}
for claim in ledger['claims']:
    claim.update(state='EVIDENCE_VERIFIED', assumption_ids=[i for i, _ in assumptions],
        evidence_ids=['proof-' + key for key in support[claim['id']]], bridge_premise_ids=[])
write_json('claim-ledger.json', ledger)
ids = [c['id'] for c in ledger['claims']]
write_json('dependency-dag.json', dict(META, nodes=ids, edges=[{'from': 'target', 'to': i} for i in ids if i != 'target']))

families = [
    ('compact-angular', 'Compact nonlinear common-mobility residual dynamics and localized conditional entropy.',
     'SO(2) angle/link variables, with retained stabilizer factors in the rate lane.',
     'Positive fast Gram and inherited cut Gram; exact boundary-current and tail entropy retained.',
     'Derive two episodes and close both compact conditional entropy stages on the same initialization.',
     'First entropy and two geometric episodes are written; second inherited conditional interface remains open.',
     'Treating the principal-residual cube as globally reflecting loses interface flux.',
     ['Derived compact restoring bands', 'Open first and second geometric episodes', 'Conditional entropy with explicit boundary current'],
     ['Second compact conditional-entropy interface under the inherited first marginal'], 'open'),
    ('gaussian-translation', 'Global Gaussian conditional geometry with common local OU kinetics and energy-derived bands.',
     'Ten real law/link coordinates, five retained pair/singleton coordinates, three final root/mark coordinates.',
     'Positive residual Grams, Schur completion, Gaussian conditional shift, invariant final root.',
     'Join actual two episodes, normalized laws, conditional force/VFE errors, and inherited paths in one open regime.',
     'The construction and three independent reconstructions establish every finite target obligation.',
     'Dropping the evaluator tilt, first-stage finite-K cross block, or reference covariance invalidates closure.',
     ids, [], 'complete'),
    ('exact-memory', 'Exact elimination with retained initial hidden law, convolution memory and colored noise.',
     'Linear Gaussian retained coordinate plus its derived memory and Gaussian moments.',
     'Solving the hidden linear equation gives an exact generalized Langevin equation.',
     'Retain complete conditional-VFE moments or bound an explicit memory truncation remainder.',
     'The conditional-lag lane gives exact memory and moments; this is an alternative to the chosen approximate first parent.',
     'Discarding the colored noise or initial hidden law breaks the exact path identity.',
     ['Exact linear memory kernel and Gaussian moment VFE'], ['Memory alone does not prove formation'], 'not_selected'),
]
write_json('approach-registry.json', dict(META, mechanism_families=[dict(family_id=f[0], core_mechanism=f[1],
    target_obligation_ids=['target'], representation=f[2], invariant_or_obstruction=f[3], obligations=[f[4]],
    bridge=f[5], failure_test=f[6], verified_results=f[7], open_gaps=f[8], disposition=f[9],
    novelty_fingerprint='No priority claim. Distinction from prior records is the explicit kinetic and conditional interface stated here.') for f in families]))

write_markdown('reconstruction-and-erasure.md', '''# Reconstruction and search-prior erasure

The three expert investigators developed compact-rate, entropy and episode routes, then independently reconstructed separate aspects of the root's global Gaussian translation-link proof. These are calculations, not votes. The frozen construction and the three full reconstructions are preserved in proofs/.

The rates reconstruction derives both residual Grams, the exact first Schur spectrum, the normalized physical presentation, the constant final evaluator cost, and the counterexample to an exact first projection. The formation reconstruction derives the coupled residual ODE, strict intervals, transverse/noise bounds, finite-strength inherited cut decay, and the actual pair/singleton chart and metric. The lag reconstruction derives the weighted conditional residual equation, Gaussian log-ratio transfer to open full densities, actual force and VFE errors, reference path comparison, separate fine and autonomous-parent second entropy bounds, and a uniform-stiffness finite horizon.

The joined target uses the same H,H0, E,F,R, T and initial family throughout. The first reduction is approximate and its finite-K coupling stays in the proof. The final projection is exactly invariant. The scalar conditional cost is not identified with a bare marginalized physical ELBO. All component claims in the ledger have these written derivations as evidence.

Erase the affirmative search preference and every requested conclusion. What remains as inputs is the local law family, coherent reference prior, positive microscopic interaction contrast, one common metric, and a finite initial-law neighborhood. Matrix ranks and eigenvalues still follow from explicit rows. The two residual crossings still follow from the fixed ODE. The parent normalizers follow from Gaussian integration. Conditional error follows from a log-density ratio and a quadratic inequality. The second parent rate follows from the first Schur matrix, and the common regime follows from T log(1/T) tending to zero followed by K tending large at fixed T. No desired grouping, rate reset, initial conditional matching, or second merger is a premise.

The admitted microscopic contrast and reference are visible inputs, not purported universal consequences. Nonlinear compact second entropy, learned coefficients, physical-clock universality and infinite depth are not imported as conclusions. This analytical erasure exercise changes no artifact or scientific data and is not a tamper test.
''')
attacks = [
    ('kinetics', ['target','derived-rates'], 'A node-speed hierarchy might be supplied under another name.', 'All coordinate mobilities equal one; only admitted microscopic energy weights differ. Spectra follow from the finite residual Grams.', 'rates'),
    ('normalization', ['normalized-model','parent-laws'], 'The variational optimizer might be substituted for the generative model.', 'H0 and H differ by the exact evaluator term; Gaussian generative conditionals and d1,d2 retain all normalizers.', 'rates'),
    ('gauge', ['target','normalized-model'], 'A proper prior might be claimed invariant under noncompact active translations.', 'The reference is pushed under passive changes; active invariance is explicitly excluded. The group/action was already admitted by the local theory.', 'formation'),
    ('exact-first', ['first-dynamics','final-projection'], 'Static Gaussian marginalization might be called exact first-stage dynamics.', 'The checking report gives a nonzero second-derivative discrepancy; the target claims approximation with explicit bounds at the first stage and exactness only at the invariant root.', 'rates'),
    ('entropy', ['conditional-lag','first-dynamics'], 'A path distance might be used to certify conditional entropy.', 'The Gaussian conditional log ratio directly proves the square-root KL bound; force and VFE consequences follow from that bound separately.', 'lag'),
    ('second-episode', ['dynamic-grouping','subsequent-episode'], 'A second projection might erase a block that was already coherent at initialization.', 'Both fine and finite-K first-parent cuts have strict early noncoherence followed by later coherence under fixed inherited equations.', 'formation'),
    ('common-regime', ['target','joined-regime','subsequent-episode'], 'Temperature and stiffness limits might require incompatible horizons or initial laws.', 'Uniform post-initial-layer normal energy and a common Schur gap allow L=O(log(1/T)); choose small positive T then large K. Weighted density-ratio neighborhoods transfer the results.', 'lag'),
    ('parent-types', ['parent-laws','normalized-model','final-projection'], 'The retained scalar cost might be treated as a new bare single-agent ELBO or omitted evaluator labels.', 'The primary proof gives explicit correlated parent presentations and augmented conditional-family scope, with relative-frame marks retained.', 'construction'),
]
report = dict(META, attacks=[dict(id=i, claim_ids=claims, attack=attack, disposition='REJECTED', response=response,
    artifact_path='proofs/' + proof_names[key], artifact_sha256=digest(RUN / 'proofs' / proof_names[key]))
    for i, claims, attack, response, key in attacks])
for field in ('independent_reconstruction', 'oracle_erasure'):
    report[field] = dict(claim_ids=ids, method='Direct analytical reconstruction and premise erasure against the frozen finite contract.',
        result='PASS', conclusion='Every target dependency has direct written derivational support within the stated model and bounds.',
        artifact_path='reconstruction-and-erasure.md', artifact_sha256=digest(RUN / 'reconstruction-and-erasure.md'))
write_json('adversarial-report.json', report)
write_markdown('counterexample-register.md', '''# Counterexamples and unresolved alternative routes

For H=[[C,B],[B^T,A]], initialize hidden means at -A^-1 B^T Y0. Fine and averaged first derivatives agree, but their second derivatives differ by B A^-1 B^T S Y0. Thus exact first-stage projectability is false generically. The construction keeps a controlled approximation.

A hidden Gaussian mean displacement epsilon with variance T has KL epsilon^2/(2T); small geometric distance alone does not control dimensionless entropy. The completed route uses the exact conditional shift identity instead.

Principal residual coordinates on the compact torus have identification boundaries, so replacing them by a globally reflecting cube discards actual interface current. The compact second-entropy interface remains open. The global Gaussian witness has no such boundary.

An active translation of state while holding a proper reference prior fixed is not a gauge re-expression. Passive covariance requires transforming the reference. The construction states this explicitly. These are analytic counterexamples/scope checks, not artifact corruption or adversarial-packet tests.
''')
write_markdown('construction-or-strongest-theorem.md', '''# Finite construction

The complete theorem and proof are in proofs/translation-link-conditional-bridge.md, Sections 1–8. With common local mobility, positive fixed channel variances, independent translation links and a proper reference prior, the supplied local contrast K/k induces restoring scales. Three separated nodes form a pair before the remaining cut relaxes. The inherited first parent has the same later episode at finite K.

The 10-to-5 Schur parent has explicit path, conditional-force and transient-VFE error bounds. The 5-to-3 root projection is exact. Gaussian conditional log ratios give entropy control for an open class of non-Gaussian positive-density preparations. Conditional costs and normalized augmented kernels compose through the same two maps. Small positive T, a finite logarithmic entropy horizon and then sufficiently large K satisfy all hypotheses together.

This is the frozen existential result, not a universal hierarchy theorem. The three independent calculations in proofs/ reconstruct its rates/normalization, formation, and conditional entropy interfaces.
''')
limitations = [
    'Microscopic interaction contrast and common flat kinetics are supplied; no learned architecture or scalar-VFE uniqueness of kinetics.',
    'Fixed-variance Gaussian law points with additive links and a proper pushed reference; no nontrivial holonomy assertion for this tree.',
    'Finite two-episode regime and correlated augmented parents; no unique threshold, permanent hierarchy or infinite-depth RG.',
    'The compact angular second conditional-entropy interface remains open and is not certified by the Gaussian construction.',
]
write_json('release.json', dict(META, checkpoint='finite common-kinetics and conditional-VFE closure', target_claim='target',
    terminal_status='COMPLETE_AFFIRMATIVE', certificate_claim='target',
    strongest_result='One normalized common-mobility law/link model has actual successive coalescence, derived collective rates, controlled transient conditional VFE and two compatible inherited reductions.',
    unresolved_obligations=[], limitations=limitations))
write_markdown('final-report.md', '''# Rigorous theory search report

## Frozen contract

The four-step existential target is unchanged in problem-contract.json: derived rates under common local kinetics, dynamical grouping, controlled hidden conditional effects, and an actual subsequent coalescence using inherited parents. Scope is one base point and one nonempty finite family, with declared model inputs.

## Terminal status

COMPLETE_AFFIRMATIVE for that finite target. This status rests on written derivations and their reconstruction, not on a schema validator or agent agreement.

## Certificate

The exact construction is proofs/translation-link-conditional-bridge.md. Sections 1–2 establish types, normalization and the common update; Section 3 proves fine formation; Section 4 derives parent laws and kinetics; Sections 5–7 prove conditional KL, force, VFE, paths, inherited second formation and a compatible parameter regime.

## Strongest verified result

A normalized Gaussian translation-link model with ten coordinates and one common microscopic mobility has five fast normal modes and two slower cut modes from its specified energy weights. A pair forms first and later joins the third node. Its inherited five-coordinate first parent has a quantified nonzero approximation error and an actual later merger at finite strength. The three-coordinate final root is an exact projection. Both fine and inherited-parent conditional VFE costs are controlled for a nonempty open positive-density family at positive temperature.

## Dependency closure

The ledger separates the target, rates, grouping, conditional lag, subsequent episode, joined regime, microscopic normalization, parent laws, first dynamics and final projection. Every entry is supported by a written derivation bound to the current proof snapshot. No unproved compact-interface claim is an ancestor of the target.

## Independent reconstruction

Three experts investigated parallel compact/dynamical/entropy routes, then reconstructed separate aspects of the joined Gaussian proof. Their complete rate/parent, formation and conditional-lag derivations are in proofs/. Corrections included the delta-dependent early exponent, both retained cut modes, the hidden-mean projection term, explicit initial-law topology, parent presentation types and exact-root versus approximate-first scope.

## Oracle erasure

reconstruction-and-erasure.md removes the desired outcome and checks the remaining premises. The model inputs remain explicit; matrix identities, ODE crossings, Gaussian normalizers and entropy estimates do not assume a preferred grouping, a new parent rate, or conditional matching.

## Unresolved obligations

None within the frozen finite existential target. The compact angular route's second conditional-entropy interface is an unresolved alternative-route obligation, not evidence for the Gaussian witness. Generalizing the result requires a new scoped question.

## Scope and limitations

The microscopic interaction contrast, fixed law covariances, coherent proper reference and flat kinetics are supplied. Parent laws retain correlated vector presentations and structural marks. The result neither learns those inputs nor selects a unique or permanent hierarchy, proves infinite depth, or identifies a universal physical clock. The first reduction remains approximate with explicit errors. No GPU, full suite, historical rerun, Lean, tamper check, vault edit or Git publication is part of this continuation.
''')
source_paths = [REPO / 'Theory' / name for name in ('02_geometry.tex','05b_local_collective_elbo.tex','07c_full_graph_meta_agent_vfe.tex')]
source_paths += [Path('C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex')]
write_json('source-snapshot.json', dict(META, canonical_base_commit=subprocess.check_output(['git','rev-parse','HEAD'], cwd=REPO, text=True).strip(),
    note='The base commit does not contain these uncommitted research derivations. Hashes identify read sources and proof copies, not mathematical truth.',
    proofs=[dict(source=str(SOURCE / name), snapshot='proofs/' + name, sha256=digest(SOURCE / name)) for name in proof_names.values()],
    sources=[dict(path=str(path), sha256=digest(path)) for path in source_paths]))
print(json.dumps({'written_claims': len(ids), 'proofs': len(proof_names), 'attacks': len(attacks), 'frozen_source': FROZEN}))
