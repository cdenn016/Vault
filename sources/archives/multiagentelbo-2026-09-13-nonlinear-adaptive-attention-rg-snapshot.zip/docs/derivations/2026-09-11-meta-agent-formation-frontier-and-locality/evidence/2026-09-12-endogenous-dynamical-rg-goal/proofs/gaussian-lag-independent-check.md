# Independent reconstruction of Gaussian conditional lag

September 12, 2026. This bounded check reconstructs the Gaussian conditional-lag proposal for contract `contract-sha256-b729cd06d3b1bc842c9a3ccea9729bb5deb2ecf6e2f4e81f2fb2c3398894518c`. It checks the residual dynamics, an open class of recognition laws, parent forces, transient VFE, and final-root entropy. It does not assign a ledger state or establish the separate episode geometry.

Substantive review binding: [the preserved primary snapshot](evidence/2026-09-12-endogenous-dynamical-rg-goal/proofs/translation-link-conditional-bridge.md), byte SHA-256 `19999cf85c9f47e01a946e7bc9401b4a9ad887815d879ff30396718eb0a8f9a7`, read in full and matched by `Get-FileHash -Algorithm SHA256` on September 12, 2026. Section 9 records the final comparison of that frozen revision with the reconstruction. This preserves the reviewed bytes and supersedes the earlier mutable-draft reads discussed in Section 7.1.

Current final binding: [translation-link-conditional-bridge.md](translation-link-conditional-bridge.md), byte SHA-256 `f966e62c8875eac523cbbfaf6f54c23e7ab98d489dce073d97b639068cbf72a5`. A direct byte comparison proved that it equals the reviewed snapshot after removing exactly three occurrences of the two-byte LaTeX spacing macro, hexadecimal `5C 2C`, and no other bytes. The six-byte formatting-only change is recorded at the end of Section 9; the mathematical review remains the review of the preserved snapshot.

The result is that the proposed residual dynamics and square-root conditional-KL bound are correct under their stated stationary-covariance Gaussian reference. The reference path bound is also correct. For an arbitrary law in the KL neighborhood, that path bound needs the explicitly derived additional dependence on the neighborhood radius in Section 5. The final-root conditional bound must use the actual fine law or its actual first marginal; it cannot be transferred from a separately evolved parent by path closeness.

## 1. Precisely stated model and scope

The requested original target remains the four-step existential construction with one common peer kinetic rule, actual formation episodes, inherited parents, and ordinary conditional-KL control. This check concerns a proposed global finite-dimensional translation-link specialization. Its sources are the normalized evaluator and outer objective in [the microscopic construction](microscopic-vfe-dynamics-construction.md), Sections 3–7, the existing additive-link model in [normalized alignment](normalized-alignment-parent-limit.md), Section 3, and the exact Gaussian contrast accounting in [the previous hierarchy](../2026-09-11-fast-slow-derived-hierarchy/gaussian-hierarchy-construction.md), G3–G5. The additional stationary-covariance reference is an explicit mathematical preparation, not an assertion about all recognition laws.

At the fixed base point, center all variables at a coherent `W_ref`. Let `x=W-W_ref in R^n` include the belief/model Gaussian means and independent translation links. Let the fixed baseline be

$$
P_0(dx)=Z_0^{-1}e^{-x^TH_0x/(2T)}dx,
\quad H_0\succ0,
\quad T>0.
\tag{1}
$$

The normalized physical evaluator and its fixed-marginal recognition projection are the same Gaussian kernels as in the microscopic source. For scalar physical channels with `0<a<1`, their conditional cost is

$$
d(x)=\sum_i\frac{(u_i-v_i)^2}{2(1-a)}.
\tag{2}
$$

Write `D_e x=(u_i-v_i)_i`. The complete generative joint and the variational family are

$$
P(dx,d\zeta,dk)=P_0(dx)P_{\rm in}(d\zeta,dk\mid x),
\qquad
Q^{\rm aug}=Q(dx)R(d\zeta,dk\mid x).
\tag{3}
$$

Both inner kernels are normalized, `R<<P_in`, and the expectation defining the objective is

$$
\mathcal F_T(Q)=T\mathbb E_{QR}\log\frac{d(QR)}{dP}
 =T D(Q\Vert P_0)+T\mathbb E_Qd
 =T D(Q\Vert\Pi)-T\log c,
\tag{4}
$$

where

$$
H=H_0+\frac{T}{1-a}D_e^TD_e,
\quad
\Pi=N(0,TH^{-1}),
\quad
c=\mathbb E_{P_0}e^{-d}\in(0,1].
\tag{5}
$$

The Gaussian integrals are finite because `H_0` and `H` are positive definite. All base measures are Lebesgue. For finite `D(Q||Pi)`, quadratic moments exist: apply the entropy variational inequality to truncated `alpha|x|^2` with `alpha` below the Gaussian exponential-moment threshold, then take monotone limits. Thus the Gaussian log-ratio expectations below are well-defined. Their extended KL chain-rule versions remain valid where a finite log-density split is not available.

The actual common local prescription is

$$
dx_t=-Hx_tdt+\sqrt{2T}dB_t.
\tag{6}
$$

It has globally Lipschitz coefficients and explicit unique solution `x_t=exp(-Ht)x_0+sqrt(2T) integral_0^t exp[-H(t-s)]dB_s`. The microscopic mobility is the identity on every coordinate. The matrices in `H_0=delta I+K B_f^TB_f+k B_s^TB_s` are interaction and prior data. They do not assign node or parent learning-rate multipliers. Translation gauge changes must act on `W_ref` as well as `W`; that is the declared passive-coordinate covariance of the anchored specialization.

Choose a fixed orthonormal decomposition into retained `y` and eliminated `z`. In these coordinates,

$$
H=\begin{pmatrix}C&B\\B^T&A\end{pmatrix}\succ0,
\quad A\succeq a_*I>0,
\quad S=C-BA^{-1}B^T\succ0.
\tag{7}
$$

All matrices in this document are fixed in time. `C` is the retained Hessian block, not the coarse map. Orthogonality is load bearing: it gives independent standard coordinate Brownian motions and identity retained mobility. A nonorthogonal reduction requires the transformed mobility and noise covariance.

Completing the square in the Gaussian density gives

$$
\Pi_Y=N(0,TS^{-1}),
\qquad k_y=\Pi(dz\mid y)=N(-A^{-1}B^Ty,TA^{-1}).
\tag{8}
$$

The generative marginal and downward conditional use `H_0`, not `H`. Equations (7)–(8) concern the optimizer and its kinetics.

## 2. Reference recognition and exact lag dynamics

For any reference mean `m_0`, choose

$$
Q_t^*=N(m_t,TH^{-1}),
\qquad m_t=e^{-Ht}m_0.
\tag{9}
$$

This is an exact solution of the full forward equation because `dot m=-Hm` and `dot Sigma=-H Sigma-Sigma H+2TI=0` at `Sigma=TH^{-1}`. Its conditional on `Y=y` is

$$
Q_t^*(dz\mid y)=N(-A^{-1}B^Ty+\theta_t,TA^{-1}),
\qquad \theta_t=m_{z,t}+A^{-1}B^Tm_{y,t}.
\tag{10}
$$

The displacement `theta_t` is independent of `y`. This is exactly what makes the open-law entropy estimate in Section 3 possible.

Substituting `m_z=theta-A^{-1}B^Tm_y` into the two mean equations yields

$$
\dot m_y=-Sm_y-B\theta,
\qquad
\dot\theta=-(A+A^{-1}B^TB)\theta-A^{-1}B^TSm_y.
\tag{11}
$$

The matrix multiplying `theta` is generally nonsymmetric. Its correct dissipative metric is `A`: with `r=|A^{1/2}theta|`,

$$
\begin{split}
\frac12\frac d{dt}r^2
 &=-\theta^TA^2\theta-|B\theta|^2-\theta^TB^TSm_y\\
 &\le-a_*r^2+
       r\|A^{-1/2}B^TS\||m_y|.
\end{split}
\tag{12}
$$

Since `H` is symmetric positive definite, `|m_t|<=|m_0|`. Therefore the upper right derivative, including at `r=0`, obeys

$$
D^+r\le-a_*r+c_*,
\quad
c_*:=\|A^{-1/2}B^TS\||m_0|
\le\frac{\|B\|\|S\||m_0|}{\sqrt{a_*}}.
\tag{13}
$$

Multiplying by `exp(a_*t)` and integrating proves

$$
r(t)\le e^{-a_*t}r(0)+\frac{c_*}{a_*}(1-e^{-a_*t}).
\tag{14}
$$

The conditional entropy and its bound are exactly

$$
\Delta_1^*(t)=\mathbb E_{Q_{Y,t}^*}D(Q_t^*(\cdot\mid Y)\Vert k_Y)
 =\frac{r(t)^2}{2T},
\tag{15}
$$

$$
\sqrt{\Delta_1^*(t)}
\le\frac{e^{-a_*t}r(0)}{\sqrt{2T}}
 +\frac{\|B\|\|S\||m_0|}{\sqrt{2T}a_*^{3/2}}.
\tag{16}
$$

If `a_*` grows proportionally to `K` while `||B||` and `||S||` are `O(k)` at fixed remaining data, the squared stationary bound in (16) is `O(k^4/(K^3T))`. The actual lag need not approach a nonzero plateau because `m_y` itself relaxes; the displayed plateau is a uniform forcing envelope. No statement about a finite-step natural-gradient optimizer is implied by this OU calculation.

## 3. An exact open-law entropy transfer

Let `Q_0` be any law with

$$
D(Q_0\Vert Q_0^*)<\eta^2.
\tag{17}
$$

Evolve `Q_0` and `Q_0^*` through the same Markov kernel. The joint laws of `(x_0,x_t)` have KL equal to the initial KL because their conditional transition kernels coincide. Dropping `x_0` and applying the conditional chain rule gives

$$
D(Q_t\Vert Q_t^*)\le D(Q_0\Vert Q_0^*)<\eta^2.
\tag{18}
$$

This is a direct entropy-contraction argument, not a Wasserstein estimate.

Write `h_y=Q_t(dz|y)` and `h_y^*=Q_t^*(dz|y)`. Define the centered reference residual

$$
\epsilon=z+A^{-1}B^Ty-\theta_t.
$$

Under `Q_t^*`, it is independent of `Y` and has law `N(0,TA^{-1})`. Dividing the two conditional Gaussian densities gives

$$
\log\frac{h_y^*}{k_y}
 =T^{-1}\theta_t^TA\epsilon+
                       \frac{\theta_t^TA\theta_t}{2T}.
\tag{19}
$$

The conditional chain rule consequently yields

$$
\Delta_1(Q_t)
=\mathbb E_{Q_{Y,t}}D(h_Y\Vert h_Y^*)
 +\Delta_1^*(t)+T^{-1}\theta_t^TA\mathbb E_{Q_t}\epsilon.
\tag{20}
$$

Let `D_t=D(Q_t||Q_t^*)`. The first term is at most `D_t`. The exact Gaussian moment-generating function and nonnegative KL to its exponential tilt imply

$$
\frac{|A^{1/2}\mathbb E_{Q_t}\epsilon|^2}{2T}\le D_t.
\tag{21}
$$

Explicitly, for every vector `v`, the variational inequality gives `v.E_Q epsilon<=D_t+(T/2)v^TA^{-1}v`; optimizing in `v` proves (21). Thus the last term of (20) is at most `2 sqrt(Delta_1^* D_t)`, and

$$
\boxed{\sqrt{\Delta_1(Q_t)}
\le\sqrt{D_t}+\sqrt{\Delta_1^*(t)}
<\eta+\sqrt{\Delta_1^*(t)}.}
\tag{22}
$$

The bound is sharp for a same-covariance conditional mean shift in the direction of `theta_t`, with unchanged retained marginal. It does not hold merely because the two laws are close in path distance. The reference's stationary covariance and the resulting `y`-independent conditional shift are load-bearing assumptions.

For an explicit open initial-law class, write `dQ_0=f dQ_0^*`, require `E_{Q_0^*}f=1`, and use the relative `L^infty(Q_0^*)` topology on this normalized affine hyperplane. If `||f-1||_infty<epsilon<1`, then `f` is positive and

$$
D(Q_0\Vert Q_0^*)
=\mathbb E[f\log f-f+1]
\le\frac{\mathbb E(f-1)^2}{2(1-\epsilon)}
<\frac{\epsilon^2}{2(1-\epsilon)}.
\tag{23}
$$

The second derivative of `u log u-u+1` is `1/u`, proving the inequality. Choose `epsilon` so the right side is below `eta^2`. This provides a nonempty open neighborhood of full-dimensional positive densities, including non-Gaussian correlated perturbations. Varying `m_0` in the episode lane's open mean neighborhood produces an open parameter-and-density preparation class. A KL ball is not silently claimed to be open in weak convergence or in total variation.

## 4. Parent force and the precise VFE contribution

The true retained mean drift conditional on the actual current law is

$$
\mathbb E[-Cy-BZ\mid Y=y]=-Sy+\delta b_t(y),
\quad
\delta b_t(y)=-B\left[\mathbb E(Z\mid y)+A^{-1}B^Ty\right].
\tag{24}
$$

For every supported `y`, the same Gaussian exponential-tilt argument used in (21) gives

$$
\left|A^{1/2}\left[\mathbb E(Z\mid y)+A^{-1}B^Ty\right]\right|^2
\le2T D(h_y\Vert k_y).
$$

Therefore

$$
\boxed{\|\delta b_t\|_{L^2(Q_{Y,t})}
\le\|BA^{-1/2}\|\sqrt{2T\Delta_1(Q_t)}.}
\tag{25}
$$

This controls the force under the inherited unit retained mobility. A new parent Fisher metric or time rescaling would change the dynamics and is not part of (25).

Disintegrate the original baseline as `P_0=P_1 P_0(.|y)`, and put

$$
d_1(y)=-\log\mathbb E_{P_0(\cdot\mid y)}e^{-d}.
$$

The optimizing kernel in (8) is `exp[-d+d_1(y)]P_0(.|y)`. Consequently

$$
\boxed{\mathcal F_T(Q_t)
 =T[D(Q_{Y,t}\Vert P_1)+\mathbb E_{Q_{Y,t}}d_1]
          +T\Delta_1(Q_t).}
\tag{26}
$$

The eliminated ordinary VFE is `Delta_1`; the eliminated scaled VFE is `T Delta_1`. This controls the difference at the actual retained marginal. Replacing that marginal by a separately evolved parent law requires an additional argument; Section 6 supplies the relevant Gaussian conditional formulas instead of inferring entropy from a path estimate.

## 5. Reference and open-law path estimates

Couple the actual retained process to the averaged parent

$$
d\bar Y_t=-S\bar Y_tdt+\sqrt{2T}dB_t^y,
\qquad \bar Y_0=Y_0,
\tag{27}
$$

using the same retained Brownian motion. Under the reference preparation,

$$
d(Y_t-\bar Y_t)=-S(Y_t-\bar Y_t)dt-B(\theta_t+\epsilon_t)dt.
$$

Since `S` is symmetric positive definite, `||exp(-St)||<=1`. Let `d_z=dim z`. At every time under `Q^*`, `epsilon_t` is centered with covariance `TA^{-1}`; independence across times is not needed. Therefore

$$
\begin{split}
\mathbb E_*\sup_{t\le H_*}|Y_t-\bar Y_t|
\le\|B\|\left[
 H_*\sqrt{\frac{d_zT}{a_*}}
 +\frac{r(0)}{a_*^{3/2}}
 +\frac{H_*\|B\|\|S\||m_0|}{a_*^2}
\right].
\end{split}
\tag{28}
$$

To verify the deterministic terms, integrate (14) and use `|theta|<=r/sqrt(a_*)`. The stochastic term follows from `E|epsilon_t|<=sqrt(T tr A^{-1})`. For the five-dimensional eliminated block, (28) is exactly the proposed `sqrt(5T/a_*)` reference bound.

For an arbitrary law satisfying (17), its covariance need not equal the reference covariance. The reference fluctuation term in (28) must then be changed. Under `Q_t^*`,

$$
\log\mathbb E_*\exp\left[\frac{\epsilon_t^TA\epsilon_t}{4T}\right]
=\frac{d_z}{2}\log2.
$$

Using (18) in the entropy variational inequality gives

$$
\mathbb E_Q\epsilon_t^TA\epsilon_t
\le T(4\eta^2+2d_z\log2).
\tag{29}
$$

Thus the rigorously valid open-law version of (28) is

$$
\boxed{\begin{split}
\mathbb E_Q\sup_{t\le H_*}|Y_t-\bar Y_t|
\le\|B\|\left[
 H_*\sqrt{\frac{T}{a_*}(4\eta^2+2d_z\log2)}
 +\frac{r(0)}{a_*^{3/2}}
 +\frac{H_*\|B\|\|S\||m_0|}{a_*^2}
\right].
\end{split}}
\tag{30}
$$

Here `theta_t` is still the deterministic reference displacement; (29) controls the actual law's residual around it. The coupling has the same actual `Y_0` on both processes. The less sharp coefficient `2d_z log 2` is deliberate and follows from an elementary exact Gaussian moment rather than a separate transport theorem.

## 6. The second conditional and the final root

Let

$$
E_0=\ker B_f\cap\ker B_s,
\qquad E_N=E_0^\perp,
\tag{31}
$$

and assume the evaluator rows lie in the row span of `B_f`. Then all interaction and evaluator quadratic forms vanish on `E_0`, while the anchor contributes `delta I`. Symmetry gives an invariant orthogonal decomposition

$$
H=\delta I_{E_0}\oplus H_N,
\qquad H_N\succeq\beta I>0.
\tag{32}
$$

For `H_0=delta I+K B_f^TB_f+k B_s^TB_s`, with `K>=k>0`, one may take

$$
\beta\ge\delta+k\lambda_{\min}^{+}(B_f^TB_f+B_s^TB_s).
\tag{33}
$$

The positive eigenvalue is evaluated on `E_N`; it is positive by the definition of `E_0`. The finite matrix should be included in the construction evidence if a numerical bound is reported. No positive lower bound is asserted on the null space.

The retained root `R=P_{E_0}x` satisfies the exact autonomous equation

$$
dR_t=-\delta R_tdt+\sqrt{2T}dB_t^0
\tag{34}
$$

for every initial law. Its dynamics are a projection of the original operator and are unaffected by hidden initial dependence. The normal conditional of `Pi` is `N(0,TH_N^{-1})`, independent of the root. Under the reference law, the entire discarded conditional displacement is `m_N(t)=exp(-H_Nt)m_N(0)`, so

$$
\Delta_{02}^*(t)=\frac{m_N(t)^TH_Nm_N(t)}{2T}
\le e^{-2\beta t}\Delta_{02}^*(0).
\tag{35}
$$

Apply the proof of (22) with the full normal block to get the actual fine-to-root bound

$$
\boxed{\sqrt{\Delta_{02}(Q_t)}
\le\eta+e^{-\beta t}\sqrt{\Delta_{02}^*(0)}.}
\tag{36}
$$

This is a direct conditional-entropy bound on the actual fine law. It controls all eliminated normal directions at once and does not depend on the accuracy of an intermediate autonomous approximation.

For explicit bookkeeping split the first retained space as `E_0 plus E_U`, where `E_U=ker B_f intersect E_N`. The first Schur complement is `S=delta I_{E_0} plus S_U`, because the root has no cross Hessian with any coordinate. For the actual reference first marginal, its covariance is `TS^{-1}`, its mean is `m_y(t)`, and

$$
\Delta_{12}^*(t)=\frac{m_U(t)^TS_Um_U(t)}{2T},
\quad
\Delta_{02}^*(t)=\Delta_1^*(t)+\Delta_{12}^*(t).
\tag{37}
$$

The second equality is the quadratic completion identity

$$
m^THm=\theta^TA\theta+m_y^TSm_y,
$$

after subtracting the root energy. It is also the KL tower rule. For every admitted actual law,

$$
\Delta_{02}(Q_t)=\Delta_1(Q_t)+\Delta_{12}(Q_{Y,t}),
\tag{38}
$$

so `Delta_12(Q_Y,t)<=Delta_02(Q_t)`. A sharper comparison follows by marginalizing (18) and repeating (22):

$$
\sqrt{\Delta_{12}(Q_{Y,t})}
\le\eta+\sqrt{\Delta_{12}^*(t)}.
\tag{39}
$$

The autonomous first parent is a different law. Its Gaussian reference mean is `bar m_y(t)=exp(-St)m_y(0)`, whereas the actual mean solves (11). Its own second conditional cost is

$$
\bar\Delta_{12}^*(t)=
 \frac{\bar m_U(t)^TS_U\bar m_U(t)}{2T}.
\tag{40}
$$

The autonomous parent, initialized with the actual marginal `Q_Y,0`, contracts KL to that parent Gaussian reference and satisfies the analog of (39) with bars. These are two separately derived entropy statements; they are not obtained by replacing one law with another in (38). Their scalar reference difference can be bounded exactly by

$$
|\Delta_{12}^*-\bar\Delta_{12}^*|
\le\frac{\|S_U\|}{2T}
 |m_U-\bar m_U|(|m_U|+|\bar m_U|),
\tag{41}
$$

if a comparison is wanted. This uses their known Gaussian means and common conditional covariance. It is not a general continuity theorem for entropy under a path metric.

## 7. Parameter order and a finite acceptance horizon

Suppose the selected geometric episode proof supplies a bounded open set of initial means, fixed `k,delta,T>0`, a later geometric coalescence time, and constants such that `a_*>=cK`, `||B||<=c_B k`, and `||S||<=c_S(k+delta)` for sufficiently large `K`. The first entropy estimate (16) and path estimate (30) then improve by increasing the internal interaction stiffness; the node update rule is unchanged.

For target final conditional entropy `epsilon_F^2`, choose `eta<epsilon_F` and wait until

$$
t\ge t_{\rm ent}:=
 \frac1\beta\left[\log\frac{\sqrt{\Delta_{02}^*(0)}}
                             {\epsilon_F-\eta}\right]_+.
\tag{42}
$$

If bounded means make the initial normal energy `O(K+k+delta+T)`, this sufficient bound has growth `O(k^{-1}log(K/T))` at fixed tolerances. It may occur later than the first small geometric residual. The observation interval must honestly include both formation episodes and this entropy relaxation time; no entropy claim is made at an earlier geometric crossing without evaluating (35).

There is no adverse order-of-limits obstruction from the conservative logarithmic horizon. With `H_*(K)=O(log K/k)`, the first path error in (30) is

$$
O\left(\log K\sqrt{T/K}\right)+O(K^{-1})
 +O(\log K/K^2)
\to0
\tag{43}
$$

at fixed `k,delta,T,eta` and bounded initial means. The first lag plateau also tends to zero, and its initial layer is much shorter than this horizon. A target entropy smaller than `eta^2` is not licensed by (22) or (36); the initial-law neighborhood radius must be chosen accordingly. Uniformity over an open bounded mean neighborhood is obtained by replacing its initial energies and norms with their finite suprema in (14), (30), and (42).

The statement that a geometric second episode persists through this longer horizon still belongs to the model's trajectory proof. In the linear anchored model all normal modes continue to decay, but a claimed pairing or membership threshold must be checked against its actual selected residuals, not the entropy bound alone.

### 7.1 The written bridge's stronger uniform-stiffness horizon

The completed [translation-link bridge](translation-link-conditional-bridge.md), Sections 5–7, was then inspected directly. It uses a fixed positive time `t_b=1/64` before the final entropy estimate, removing the initial `O(K)` energy from the horizon choice. That refinement is correct. Here is an explicit bound establishing the claimed uniformity.

Fix a bounded mean set `|m_0|<=M_0`, `T<=T_0`, `K>=K_0>=k>0`, and fixed remaining coefficients. Suppose the actual finite matrices give

$$
a_*\ge c_-K,
\quad \|A\|\le c_+K+A_0,
\quad \|B\|\le B_0,
\quad \|C\|\le C_0^{\rm ret}.
\tag{44}
$$

One can take `c_-` and `c_+` to be the extreme positive eigenvalues of `B_f^TB_f` on the hidden normal space, `A_0=delta+k||B_s||^2+[T_0/(1-a)]||D_e||^2`, `B_0=k||E^T B_s^T B_s F||`, and `C_0^ret=delta+k||B_s E||^2` for the bridge's orthonormal bases `E,F`. Since `0<S<=C`, these also bound `S`.

The initial weighted lag satisfies

$$
r(0)^2\le D_1K+D_0+D_{-1}/K,
\quad
D_1=2c_+M_0^2,
\quad D_0=2A_0M_0^2,
\quad D_{-1}=2B_0^2M_0^2/c_-.
\tag{45}
$$

This follows from `|A^(1/2)m_z+A^(-1/2)B^Tm_y|^2<=2|A^(1/2)m_z|^2+2|A^(-1/2)B^Tm_y|^2`. Put `u=2c_-t_b` and `F_0=B_0 C_0^ret M_0`. Equation (14), `(a+b)^2<=2a^2+2b^2`, and `sup_{x>0}x exp(-ux)=1/(eu)` give

$$
r(t_b)^2\le
\frac{2D_1}{eu}+2D_0+\frac{2D_{-1}}{K_0}
 +\frac{2F_0^2}{c_-^3K_0^3}=:R_b^2.
\tag{46}
$$

All constants in (46) are independent of `K>=K_0` and `T in (0,T_0]`. Completing the square now yields

$$
m_N(t_b)^TH_Nm_N(t_b)
\le m(t_b)^THm(t_b)
\le C_0^{\rm ret}M_0^2+R_b^2=:\mathcal C_0.
\tag{47}
$$

The autonomous first parent's normal energy is at most `C_0^ret M_0^2`, so the same `mathcal C_0` bounds it.

The common normal gap can also be bounded without an asymptotic Schur argument. Let `beta_0=delta+k lambda_min^+(B_f^TB_f+B_s^TB_s)`. For `y in E_U` and any hidden `z`, `(y,z)` lies in `E_N`, so

$$
y^TS_Uy=\min_z (y,z)^TH(y,z)
\ge\beta_0|y|^2.
\tag{48}
$$

Thus both the full and first-parent normal gaps are at least the same `beta_0>0`, uniformly in `K>=k` and `T>0`.

For a final interval `[L-1,L]`, equations (36), (47), and (48) give the explicit sufficient condition

$$
\eta+e^{-\beta_0(L-1-t_b)}\sqrt{\mathcal C_0/(2T)}
\le\epsilon_F,
\qquad L\ge1+t_b.
\tag{49}
$$

This allows `L=O(1+log(1/T))` independently of `K`. The bridge's order is therefore compatible: choose `T>0` sufficiently small for the fixed-mean geometric noise bound over this logarithmic horizon; choose `eta` below the probability and entropy margins; then choose `K` sufficiently large for (16), (28), and the deterministic comparison, now at fixed `T,L`. The Brownian stopped-energy bound has coefficient proportional to `TL`, which tends to zero as `T` tends to zero. No entropy is inferred from that geometric noise estimate: the entropy follows separately from (49).

The written bridge explicitly restricts its expectation estimate to the reference preparation and transfers path-event probabilities to the KL neighborhood. This is valid: the whole fine/parent coupled-path kernel is the same for both initial laws, so its KL is at most the initial KL and its total-variation distance is at most `eta/sqrt(2)`. An arbitrary unbounded path expectation cannot be transferred this way; the bridge does not claim that. Equation (30) above is an optional stronger direct estimate, not a required repair to the written bridge.

## 8. Falsification conditions and evidence

The check would fail if the actual covariance reference were not `TH^{-1}`, the matrix were time-dependent, the selected coordinates were nonorthogonal without transformed mobility, a supposedly retained root were not an invariant `delta` eigenspace, the original baseline were improper, or the actual recognition law lay outside the finite-KL class. Using (28) unchanged for arbitrary KL-ball preparations would be an unsupported scope extension; the written bridge avoids it by using event probabilities, while (30) supplies a direct expectation alternative. Treating (40) as the actual first-marginal cost in (38) is also incorrect.

The mathematical evidence consists of the density division (19), the quadratic identity (12), the Gaussian moment calculations (21) and (29), and the invariant-subspace calculation (32). A tiny rational example in [the lane evidence](evidence/conditional-lag/gaussian-check-result.json) checks the signs in (11)–(12); it supports that instance only. No sampled trajectory, training run, GPU job, full suite, Lean proof, tamper check, or source-vault edit was used.

The strongest supported result is an exact conditional Gaussian lag identity and a quantitative transfer to a nonempty open class of correlated positive-density initial laws, with inherited force and ordinary/scaled VFE bounds. The direct final-root estimate controls both stages' total conditional cost for the actual fine law. The remaining obligation is the construction lane's actual initial-mean episode geometry and the explicit finite matrices used in its parameter bounds. No ledger closure is assigned by this independent reconstruction.

## 9. Final comparison with the frozen primary revision

The source bound above was reread in full after its final revisions. Its explicit weighted `L-infinity` preparation agrees with (23), including normalization in the affine density space. Its path expectation is restricted to the Gaussian reference; the transfer to arbitrary nearby laws is a path-event probability bound obtained by the same coupled Markov kernel and total variation. This is precisely the admissible distinction established in Section 7.1. No unbounded expectation is inferred from total variation.

The corrected physical hidden-mean estimate follows directly from `m_z=theta-A^{-1}B^Tm_y`:

$$
|m_z(t)|\le r(t)/\sqrt{a_*}+\|B\||m_0|/a_*.
\tag{50}
$$

Thus the frozen source does not omit the moving conditional center. On its full-process deviation event, orthogonal projection gives `sup|z_t-m_z(t)|<=2rho`; the resulting uniform strong/weak residual comparison uses (50) and the first path estimate. Pointwise stationary covariance alone would not have justified that supremum. The written revision now uses the full deviation event.

The finite-`K` parent cut calculation can also be reconstructed without an asymptotic substitution. On the symmetric-channel slice, let `b` and `c` be the strong and weak residual rows in the five effective coordinates. Their Euclidean inner products are `|b|^2=|c|^2=3` and `b.c=-1`. The hidden unit row is `b/sqrt(3)`, and the retained weak row is `v=c+b/3`, with `|v|^2=8/3`. At `k=1`, the hidden Hessian, cross block, and retained Hessian are respectively

$$
A_{\rm sym}=\delta+3K+1/3,
\qquad B_{\rm sym}=-v/\sqrt3,
\qquad C_{\rm sym}=\delta I+vv^T.
\tag{51}
$$

Completing the square therefore gives exactly

$$
S_{\rm sym}=\delta I+
       \left(1-\frac1{3A_{\rm sym}}\right)vv^T,
\qquad
\lambda_p=\delta+\frac83
       \left(1-\frac1{3A_{\rm sym}}\right).
\tag{52}
$$

The inherited cut at time zero is `v.w_0=y_0+x_0/3`, as stated in the frozen source. For `K>=256` and `0<delta<=1/100`, `5/2<lambda_p<=delta+8/3`. Its initial value is between `5/24` and `5/18`. On the first interval its lower bound is `(5/24)exp[-(1/100+8/3)/16]>1/6`; from time three its upper bound is `(5/18)exp(-15/2)<1/256`. These strict inequalities verify a subsequent cut crossing under the first parent's own finite-`K` inherited dynamics. The antisymmetric cut remains another retained positive mode. The calculation does not assert that the five-dimensional hidden subspace is an exact finite-`K` eigenspace; the frozen conclusion explicitly preserves this distinction.

The full and Schur normal-gap statement in the final source is the quadratic minimum argument (48). Its common scalar reference precision preserves the exact root invariant space. Arbitrary coordinatewise perturbations of that precision would not preserve the result; the final source restricts openness to its declared common-precision and positive-residual-weight parameter family. This is an open set in the admitted model parameter space and does not pretend to be open in a larger, unspecified class of pinning metrics.

The added generative parent presentation is also correct. If `V` selects model means, the baseline conditional is `w|y=L_0y+F epsilon`, where `epsilon~N(0,T A_0^{-1})` and `L_0=E-F A_0^{-1}B_0^T`. Adding the independent presentation noise of covariance `aI_3` gives

$$
\zeta\mid y\sim N\left(v_{\rm ref}+VL_0y,
          aI_3+TVFA_0^{-1}F^TV^T\right).
\tag{53}
$$

Since the original `k|zeta` evaluator does not read hidden `w`, it survives that integration unchanged and remains normalized. The root formula follows by replacing the hidden block with the complete normal space of `H_0`. Recognition uses the optimizer conditional instead. The final source explicitly keeps the augmented conditional-family objective, original physical labels, and any extra conditional KL from further marginalization. It does not claim that the five evolving parent coordinates are the complete dimension of all physical presentation/output variables.

For the assigned Gaussian conditional-lag scope, no algebraic, normalization, initial-law, force, entropy, or parameter-order discrepancy remains in the frozen source. The finite-`K` parent crossing added there is consistent with (51)–(52). This conclusion rests on the calculations above, not the number of reviewers or the earlier numerical example. It does not bind the separate compact cosine theorem, and it assigns no ledger state. Only this independent-check file was changed during the final rebind; no new experiment or research search was run.

### Formatting-only final binding

After the substantive review, the primary author removed three forbidden LaTeX spacing macros. A read-only standard-library byte comparison under `C:/Python314/python.exe -I -B -` checked the preserved snapshot and current primary file. It returned old SHA-256 `19999cf85c9f47e01a946e7bc9401b4a9ad887815d879ff30396718eb0a8f9a7`, new SHA-256 `f966e62c8875eac523cbbfaf6f54c23e7ab98d489dce073d97b639068cbf72a5`, occurrence count `3`, and byte-length decrease `6`. The exact comparison `new == old.replace(bytes((92, 44)), b'')` returned `True`.

This establishes the stated formatting relation without replacing the historical review trace. The current final binding inherits the substantive calculations above because those are the only changed bytes. No theorem was reworked, and no numerical experiment or test was added during this formatting rebind. Only this independent-check file was edited.
