# Independent check of Gaussian translation-link rates and inherited reductions

September 12, 2026. This is a bounded analytical check of the Gaussian route supplied by the parent task. It owns no shared ledger or completion status. The translation-action admission was read in [normalized-alignment-parent-limit.md, Section 3](normalized-alignment-parent-limit.md); the compact rate derivation's [matrix evidence](evidence/endogenous-rates/matrix-results.json) supplies the same finite incidence matrices, not a theorem transferring compact dynamics to this Gaussian system.

The checked result is: common microscopic mobility produces five strong restoring modes, two weaker cut modes, and three exact pinning modes; the first Schur parent has two explicitly derived cut rates and three exact root rates; the final root process is an exact path-law projection of both the microscopic OU process and the first Schur parent. The first parent process is a conditionally averaged replacement and is generally not an exact projection. A second coalescence episode occurs in that same inherited parent for an open initial regime. Transferring the episode to a nonequilibrium fine law requires the separately assigned conditional-lag estimate.

## 1. Exact object and assumptions

The input model has three nodes and the path edges `12` and `23`, oriented from the second index to the first. Its full law/link coordinate is

\[
W=(u_1,u_2,u_3,v_1,v_2,v_3,
            a_{12}^b,a_{23}^b,a_{12}^m,a_{23}^m)\in\mathbb R^{10}.
\tag{1}
\]

The node laws are `b_i=N(u_i,1)` and `m_i=N(v_i,a)`, with `0<a<1`. The physical model presentation and evaluator are `zeta_i~m_i`, `k_i|zeta_i~N(zeta_i,1-a)`. The additive group acts on the sample line by translation, at the general measurable-action tier of the source. Every `a_e^x` is an independent real link coordinate.

Let `D` have rows `u_i-v_i`, `B_f` have those three rows followed by `u_1-u_2-a_12^b` and `v_1-v_2-a_12^m`, and `B_s` have rows `u_2-u_3-a_23^b` and `v_2-v_3-a_23^m`. Thus `D` consists of the first three rows of `B_f`. The same five-row Gram matrix as the compact calculation is

\[
B_fB_f^T=C_f=
\begin{pmatrix}
2&0&0&1&-1\\0&2&0&-1&1\\0&0&2&0&0\\
1&-1&0&3&0\\-1&1&0&0&3
\end{pmatrix},
\tag{2}
\]

with spectrum `2,2,3,(5-sqrt(17))/2,(5+sqrt(17))/2`. The full residual matrix `[B_f;B_s]` has rank seven because the independent link columns supply their four edge rows and the same-node rows are independent.

The supplied positive parameters are `delta,k,K,T`, with `tau=T/(1-a)`. Define

\[
H_0=\delta I+KB_f^TB_f+kB_s^TB_s,\qquad
H=H_0+\tau D^TD.
\tag{3}
\]

Both matrices are positive definite, with least eigenvalue at least `delta`. The generative configuration prior and effective variational target are the different normalized laws

\[
P_0=N(0,TH_0^{-1}),\qquad \Pi=N(0,TH^{-1}).
\tag{4}
\]

Completing the square gives their finite normalizers `(2 pi T)^5 det(H_0)^(-1/2)` and `(2 pi T)^5 det(H)^(-1/2)`. The scalar physical evaluator projection cost is

\[
d(W)=\frac{|DW|^2}{2(1-a)}.
\tag{5}
\]

This follows by the source's fixed-marginal Gaussian coupling, or directly by integrating its affine log-density ratio. Therefore `Pi` is proportional to `exp(-d) P_0`. An arbitrary correlated outer recognition law, augmented with the optimizer of the physical fixed-marginal coupling, has scaled objective

\[
\mathcal F_T(Q)=T\operatorname{KL}(Q\Vert\Pi)
                         +T\log(Z_0/Z).
\tag{6}
\]

These are configuration laws; they are not the Gaussian node law points themselves. The augmented generative law is `P_0(dW) product_i m_i(dzeta_i) ev_i(zeta_i,dk_i)`, normalized by kernel integration. Positive Gaussian outer recognition gives a correlated finite-entropy example; no Dirac recognition is used.

The common microscopic kinetic prescription is exactly

\[
dW_t=-HW_tdt+\sqrt{2T}dB_t,
\tag{7}
\]

with ten independent standard Brownian drivers. The deterministic comparison removes the noise. The state space has no finite boundary. The explicit solution
`W_t=exp(-Ht)W_0+sqrt(2T) integral_0^t exp[-H(t-s)]dB_s`
establishes global existence and uniqueness. The invariant covariance is `TH^-1`, because `H(TH^-1)+(TH^-1)H=2TI`. Under a fixed Gaussian initial law, the mean obeys `mdot=-Hm` and the covariance obeys `Sigmadot=-H Sigma-Sigma H+2TI`. For sufficiently decaying smooth densities, direct integration by parts gives VFE dissipation as in the microscopic source. This kinetic choice is additional data; scalar VFE does not single it out.

Large `K/k` is needed for the first strong/weak separation. A further large separation of root relaxation from cut relaxation requires `delta/k` small. Neither follows just from positive parameters. To state five rates as `O(K)`, also bound `tau/K`; otherwise their upper scale is `K+tau`. The exact closure calculations below do not need any of these asymptotic ratios.

## 2. Microscopic spectral bands

Put `P=I-B_f^T C_f^-1 B_f` and `Gamma=B_s P B_s^T`. Exact multiplication gives

\[
\Gamma=\begin{pmatrix}11/6&5/6\\5/6&11/6\end{pmatrix},
\qquad\operatorname{spec}\Gamma=\{1,8/3\},\qquad
B_sB_s^T=3I_2.
\tag{8}
\]

Let `c_-=(5-sqrt(17))/2` and `c_+=(5+sqrt(17))/2`. If `R` is any orthonormal basis of the three-dimensional space `ker[B_f;B_s]`, then

\[
HR=H_0R=\delta R.
\tag{9}
\]

The three eigenvalues `delta` are exact. On `ker B_f`, also `D=0`; the remaining restricted quadratic form is bounded above by `delta+3k`. For a real symmetric matrix with increasing eigenvalues, the finite-dimensional variational identity is `lambda_j=min_(dim V=j) max_(0!=v in V) v^THv/|v|^2`. Applying it to the five-dimensional kernel of `B_f` puts the first five eigenvalues below `delta+3k`, including the three exact root eigenvalues. The same identity shows that adding positive semidefinite terms to `K B_f^TB_f` gives five eigenvalues at least `delta+Kc_-`. All eigenvalues are no greater than

\[
\delta+Kc_++3k+2\tau,
\tag{10}
\]

because `||D||^2=2`. These are exact finite-parameter estimates.

The full seven-row Gram spectrum can also be evaluated exactly:

\[
\operatorname{spec}\left(\begin{bmatrix}B_f\\B_s\end{bmatrix}
                        \begin{bmatrix}B_f\\B_s\end{bmatrix}^T\right)
=\{4,2,2,3-\sqrt7,3+\sqrt7,2-\sqrt2,2+\sqrt2\}.
\tag{10a}
\]

Here is a derivation. Channel symmetrization gives two alignment rows whose Gram matrix is `[[3,-1],[-1,3]]`, with eigenvalues `2,4`. In the antisymmetric sector the three bridge rows have Gram matrix `2I_3`. The ordinary path incidence matrix has squared singular values `1,3`; its bridge/edge coupling reduces to the two blocks `[[2,sqrt(2)],[sqrt(2),2]]` and `[[2,sqrt(6)],[sqrt(6),4]]`. They give `2+-sqrt(2)` and `3+-sqrt(7)`. The remaining constant bridge direction has eigenvalue `2`. Thus for `K>=k`, every full normal rate is at least `delta+k(3-sqrt(7))`, uniformly for all `tau>=0`.

For an alternative lower bound on the two weak modes, take `x` perpendicular to the full residual kernel and decompose `x=y+Lz`, where `L=B_f^T C_f^-1`, `z=B_fx`, and `y=Px`. Let `A_c=B_sL`. Since `Gamma` has least eigenvalue one, the restriction of `B_s` to the tangent complement of the full kernel gives

\[
|x|^2\le 2|B_sx|^2+(2\|A_c\|^2+1/c_-)|B_fx|^2.
\tag{11}
\]

Consequently, if `K/(2||A_c||^2+1/c_-)>=k/2`, all seven eigenvalues above `delta` are at least `delta+k/2`. This proves the `5 O(K), 2 O(k), 3 delta` decomposition in the regime `tau=O(K)`, `delta=O(k)`, `K/k` sufficiently large; the three distinct slowest pinning rates are separated from the weak cut rates only if `delta/k` is small. The inequalities do not assign rates according to node labels.

The channel-symmetric five-dimensional sector gives an independent exact check. Write `u_+=(u+v)/sqrt(2)` and `a_+=(a^b+a^m)/sqrt(2)`. Its precision is

\[
H_+=\delta I_5+K h_{12}h_{12}^T+k h_{23}h_{23}^T,
\quad |h_{12}|^2=|h_{23}|^2=3,\quad h_{12}^Th_{23}=-1.
\tag{12}
\]

It has three `delta` eigenvalues and two additional eigenvalues

\[
\delta+\frac{3(K+k)\pm\sqrt{9(K-k)^2+4Kk}}2.
\tag{13}
\]

In particular the smaller one tends to `delta+8k/3` as `K/k` tends to infinity. The other weak mode lies in the channel-antisymmetric sector and tends to `delta+k`. The first-parent calculation next makes both limiting rates explicit without diagonalizing its entire normal block.

## 3. First static reduction and evaluator correction

Choose matrices `E in R^(10 x 5)` and `F in R^(10 x 5)` with orthonormal columns spanning `ker B_f` and its orthogonal complement, so `[E F]` is orthogonal. Put `Y=E^T W`, `Z=F^T W` and

\[
C=E^THE,\quad B=E^THF,\quad A=F^THF,
\qquad S=C-BA^{-1}B^T.
\tag{14}
\]

Both `A` and `S` are positive definite. To prove the second assertion, complete the square:

\[
W^THW=Y^TSY+(Z+A^{-1}B^TY)^TA(Z+A^{-1}B^TY).
\tag{15}
\]

The left side is strictly positive away from zero. Minimizing it over `Z` proves `Y^TSY>0` for nonzero `Y`. Integrating the Gaussian square gives exactly

\[
\Pi_1=N(0,TS^{-1}),\quad
\Pi(dZ\mid Y)=N(-A^{-1}B^TY,TA^{-1}).
\tag{16}
\]

The true generative prior uses `H_0` and its own blocks `A_0,B_0,C_0,S_0`, giving
`P_01=N(0,T S_0^-1)` and `P_0(dZ|Y)=N(-A_0^-1 B_0^T Y,T A_0^-1)`.
Since `DE=0`,

\[
C=C_0,\quad B=B_0,\quad
A=A_0+\tau F^TD^TDF,\quad S\succeq S_0.
\tag{17}
\]

The exact conditional contraction of the evaluator cost is

\[
d_1(Y):=-\log\mathbb E_{P_0(dZ\mid Y)}e^{-d(W)}
=\frac12\log\frac{\det A}{\det A_0}
                      +\frac1{2T}Y^T(S-S_0)Y.
\tag{18}
\]

To check every constant, insert the normalized generative conditional density, add `d`, complete the `A` square, and integrate. Its determinant multiplier is `(det A_0/det A)^(1/2)`. Its remaining exponential is `exp[-Y^T(S-S_0)Y/(2T)]`. Taking minus the logarithm yields (18). Thus `d_1>=0`, including the determinant term, and `Pi_1` is proportional to `exp(-d_1)P_01`. Dropping that constant preserves a force but changes the objective normalization.

For arbitrary outer `Q` the exact nonnegative disintegration is

\[
\operatorname{KL}(Q\Vert\Pi)
=\operatorname{KL}(Q_Y\Vert\Pi_1)
 +\mathbb E_{Q_Y}\operatorname{KL}(Q(dZ\mid Y)\Vert\Pi(dZ\mid Y)).
\tag{19}
\]

It holds as an extended identity without subtracting infinities. It does not say that the conditional term is initially small or dynamically negligible.

## 4. Exact first-parent rates

The declared conditional-average OU parent is

\[
d\bar Y=-S\bar Ydt+\sqrt{2T}dB^Y.
\tag{20}
\]

Both its identity mobility and noise amplitude are inherited from orthogonal projection of (7); no new local Fisher metric is assigned. The conditional mean in (16) turns the fine drift `-CY-BZ` into `-SY`. Its invariant law is precisely (16).

The spectrum of `S` is exactly

\[
\operatorname{spec}S=\{\delta,\delta,\delta,s_-,s_+\}.
\tag{21}
\]

The channel-symmetric cut rate is

\[
\boxed{s_+=\delta+\frac{8k(\delta+3K)}{3\delta+9K+k}.}
\tag{22}
\]

Proof: in (12), let `f=h_12/sqrt(3)` be the unit fast vector. The projection of `h_23` perpendicular to `h_12` has squared length `8/3`. With that normalized retained cut vector, its `C` entry is `delta+8k/3`, its off-diagonal `B` entry is `-sqrt(8)k/3`, and its normal `A` entry is `delta+3K+k/3`. Their scalar Schur complement is (22).

For the antisymmetric sector, put

\[
p=\delta+2(K+\tau),\qquad
q=\frac2p-\frac{K}{p^2[1+K(2/p+1/\delta)]}.
\tag{23}
\]

Then

\[
\boxed{s_-=\delta+\frac{k}{1+kq}.}
\tag{24}
\]

Proof: `B_f=0` forces all three antisymmetric node coordinates and the internal antisymmetric link coordinate to zero. Its sole retained coordinate is the antisymmetric cut link. On the four omitted coordinates, set `h=(1,-1,0,-1)^T`, `d=(0,1,-1,0)^T` and
`G=diag(p,p,p,delta)+Khh^T`. The Schur complement of the cut link is `delta+k-k^2 d^T(G+kdd^T)^-1d`. Applying the rank-one inverse identity twice gives `d^TG^-1d=q`, then `d^T(G+kdd^T)^-1d=q/(1+kq)`, proving (24). The identity `(M+vv^T)^-1=M^-1-M^-1vv^TM^-1/(1+v^TM^-1v)` is checked by multiplying the right side by `M+vv^T`; all denominators here are positive.

Since `G>0`, `q>0`; also `q<=2/p<=1/K`. Thus

\[
\delta+\frac{k}{1+k/K}\le s_-<\delta+k,
\qquad
\delta<s_+<\delta+8k/3.
\tag{25}
\]

For `K>=k`, the bounds sharpen to `s_->=delta+k/2` and `s_+>=delta+12k/5`: for the second bound, set `t=delta+3K>=3k` in `8kt/(3t+k)`, which is increasing in `t`. Therefore the full normal gap and the first-parent cut gap both exceed `beta_0=k(3-sqrt(7))`, uniformly for every `K>=k` and `tau>=0`. This supplies a concrete positive gap for the parent construction's final parameter-order argument.

For fixed `delta/k` and `tau/K` bounded, the two rates tend to `delta+k` and `delta+8k/3` as `K/k` tends to infinity. Their dependence on `K,k,delta,tau` is explicit. Calling them independent parent learning-rate inputs would be incorrect.

## 5. First-step dynamics is not exact projection

The exact fine equations in these coordinates are

\[
dY=-(CY+BZ)dt+\sqrt{2T}dB^Y,\qquad
dZ=-(B^TY+AZ)dt+\sqrt{2T}dB^Z,
\tag{26}
\]

with independent projected Brownian motions. Since `B` is generally nonzero, the drift of `Y` is not constant on fibers. Consequently (20) is not an exact autonomous projection for arbitrary fine initial laws.

Even initialization on the conditional-mean graph does not repair that defect. In the deterministic case set `Z_0=-A^-1 B^T Y_0`. Both fine and parent velocities then equal `-SY_0` at time zero, and the fine normal velocity is zero. At second order,

\[
\ddot Y_{\rm fine}(0)=CSY_0,\qquad
\ddot Y_{\rm parent}(0)=S^2Y_0,
\quad\ddot Y_{\rm fine}(0)-\ddot Y_{\rm parent}(0)
=BA^{-1}B^TSY_0.
\tag{27}
\]

For generic `Y_0` this is nonzero. Equation (27) also applies to means of Gaussian initial laws prepared with the conditional mean. A claim of exact first-stage path-law equivalence is therefore refuted. A quantitative conditional-lag/averaging theorem can support an approximation, but it must retain its time interval and errors. The separate conditional-bridge derivation owns that obligation.

## 6. Exact second root projection and compatible composition

Set `J=E^T R`, where `R` is as in (9). Then `J^TJ=I_3`, `B^TJ=0`, and

\[
CJ=SJ=\delta J.
\tag{28}
\]

The first identity follows from `F^THR=delta F^TR=0`, the second from `E^THR=delta J`, and the Schur correction vanishes on `J`. Therefore the same three-coordinate root

\[
X=R^TW=J^TY
\tag{29}
\]

obeys, **both for the actual fine process and for the first parent (20)**,

\[
dX=-\delta Xdt+\sqrt{2T}dB^X.
\tag{30}
\]

This is exact for every initial distribution for which the SDE is initialized, including arbitrary correlations with discarded coordinates. The projected Brownian motion is standard since `R^TR=I_3`. Its transition kernel has mean `exp(-delta t)X_0` and covariance `(T/delta)(1-exp(-2delta t))I_3`, which directly verifies normalization and semigroup composition. Thus direct and staged root projections preserve all root finite-dimensional path distributions in the original time coordinate. This stronger second-stage fact does not turn the first stage into an exact projection.

Both generative and effective root configuration laws equal `N(0,(T/delta)I_3)`. Under either fine Gaussian law, root coordinates are independent of the other seven orthogonal coordinates by (9). Under the first parent they are independent of the two cut coordinates by (28). Consequently direct Gaussian disintegration and the two consecutive disintegrations agree exactly, including all Gaussian determinant factors and conditional covariance contributions.

The induced evaluator cost at the final root is constant. Writing `R`'s orthogonal complement as `N`, its direct expression is

\[
d_2=\frac12\log\frac{\det(N^THN)}{\det(N^TH_0N)}.
\tag{31}
\]

This constant is also `-log E_[P_01(dY|X)] exp[-d_1(Y)]`. The equality follows by the tower property using the same normalized generative law. It does not require equality of the two first-stage conditional kernels. Thus the root density is unchanged by the evaluator tilt, while its retained objective still contains the constant cost. If that scalar cost or physical evaluator is claimed to vanish, the claim would be false.

## 7. A real second episode in the inherited first parent

Let `v_+` and `v_-` be the unit channel-symmetric/antisymmetric cut directions used above, inside the first retained space. Write the parent state as

\[
\bar Y=JX+v_+c_++v_-c_-.
\tag{32}
\]

Here the names `c_+`, `c_-` denote cut amplitudes only in this section. Their deterministic dynamics are exactly `cdot_+=-s_+c_+`, `cdot_-=-s_-c_-`, while `Xdot=-delta X`. The physical cut residuals satisfy

\[
\begin{pmatrix}r_b\\r_m\end{pmatrix}
=\frac1{\sqrt2}
\begin{pmatrix}\sqrt{8/3}c_++c_-\\
                \sqrt{8/3}c_+-c_-\end{pmatrix}.
\tag{33}
\]

Thus the inherited parent starts with nonzero inter-parent links and law mismatch; the second projection has not already been applied.

For an explicit open regime choose `b>0`, `0<eta<1/4`, and initial cut amplitudes with `sqrt(8/3)c_+(0)` strictly between `b` and `2b` and `|c_-(0)|<eta b`. Let `s_max=max(s_+,s_-)` and `s_min=min(s_+,s_-)`, both positive. On
`0<=t<=t_b=log(4/3)/s_max`, the symmetric amplitude is at least `3b/4`, while the absolute antisymmetric amplitude is at most `eta b`. Hence both cut residuals remain strictly larger than `b/(2sqrt(2))`.

On the other hand,

\[
\sqrt{r_b(t)^2+r_m(t)^2}
\le\sqrt{4+\eta^2}b e^{-s_{\min}t}.
\tag{34}
\]

For any `epsilon<b/(4sqrt(2))`, choose
`t_2=s_min^-1 log[sqrt(4+eta^2)b/epsilon]`.
Then `t_2>t_b`, and both cut residuals are below `epsilon` for all `t>=t_2`. This is an actual later coalescence episode of (20), driven by its inherited coefficients (22)-(24). It is not a second algebraic marginalization of already coherent cut variables. If desired, requiring `delta t_2` small preserves a nontrivial root amplitude through this episode, which explicitly requires small `delta/k`.

For positive noise the same decomposition gives independent OU noises in `X,c_+,c_-`. The cut covariance contributions at time `t`, conditional on a deterministic initial state, are `T(1-exp(-2s_+t))/s_+` and `T(1-exp(-2s_-t))/s_-`. A finite-horizon event can be obtained without a point-mass recognition claim: take a smooth positive Gaussian initial law concentrated in a smaller open set with strict episode margins and apply Brownian maximal bounds to its OU solution. For example comparison to the deterministic parent with identical initial state gives the conservative probability bound `40TH exp(2||S||H)/rho^2` for a deviation larger than `rho` on `[0,H]`, by the five-dimensional Brownian maximal estimate. Integrating over a concentrated positive initial Gaussian adds its initial outside probability. Sufficiently small positive `T` therefore preserves the two strict finite-time inequalities with any prescribed probability below one. Exact zero-KL support is not invariant at positive temperature.

What this section does not establish is that a nonequilibrium fine `Y` has already become this autonomous parent by a particular first-formation time. Equation (27) forbids that exact assertion. A same-regime conditional-lag estimate can bound the discrepancy and then preserve the strict inequalities above. The linear spectra alone cannot replace that estimate.

## 8. Types, gauge reference, and scope checks

The prior pinning term has physical data: a fixed origin/reference in the full coordinate space. Under a passive local translation, `W` shifts by the vector whose node entries are `g_i` and link entries are `g_i-g_j`; the prior reference must shift by the same vector. The quadratic pinning energy is then invariant as a re-expression. Holding that reference fixed while moving only `W` is an active change and is why the root directions can relax at rate `delta`. There is no normalized prior invariant under arbitrary active translation on this noncompact space. Conflating these two actions would erase the mechanism that gives a finite root covariance.

The source explicitly states that translated nondegenerate Gaussian laws have trivial translation stabilizer. This path also has no graph cycle. The present witness therefore does not establish a nontrivial stabilizer-holonomy example. It preserves all existing independent link coordinates up to its declared conditional reduction and does not generalize translation conclusions to arbitrary groups. If nonidentity stabilizer holonomy is required as a positive feature of the witness, an additional admitted compact factor or the compact construction is needed.

The retained linear spaces have useful explicit types. A point in `ker B_f` has `u_i=v_i=t_i`, `a_12^b=a_12^m=t_1-t_2`, and two independent cut links. It may be presented as a pair-parent root, singleton root, internal relative-frame mark, and two separate effective cut links. The induced metric comes from `E`; those chart variables are not five independently reinitialized microscopic agents. The final kernel has three node means, with every link determined by their differences; it is a root law coordinate plus two relative-frame marks. Retaining those marks avoids falsely labeling a three-coordinate output as one scalar law point.

The now-written [parent bridge](translation-link-conditional-bridge.md), Sections 1-4 and 6-8, keeps the physical presentation/state labels in an augmented conditional-family model, and distinguishes its generative conditional from the variational one. That admission is compatible with a correlated vector-valued parent. It can be checked with an explicit kernel: let `V` select the three model coordinates from `W`, and set `L_0=E-F A_0^-1 B_0^T`. At first-parent state `Y=y`, the inherited generative presentation law is

\[
M_y=N\left(v_{\rm ref}+V L_0y,
             aI_3+T V F A_0^{-1}F^TV^T\right),
\qquad k\mid\zeta,y\sim N(\zeta,(1-a)I_3).
\tag{36}
\]

The evaluator in (36) is unchanged because the original physical evaluator depends on `W` only through its sampled presentation `zeta`. Integrating `P_0(dW|y)` affects the presentation distribution and its induced correlations, not the normalization of the conditional evaluator. Its covariance is strictly positive because `a>0`; the evaluator covariance is strictly positive because `a<1`. At the final root replace `L_0y` by `Rq` and `F A_0^-1 F^T` by `N(N^TH_0N)^-1N^T`. Both orders give the same kernel by Gaussian conditioning and the tower property. This supplies paired normalized physical-law marginals and an evaluator, with all physical labels retained. The recognition's corresponding physical marginals are instead formed from its own conditional and must remain distinguished from (36).

For structural links, let `L_link` select their four coordinates. The exact first generative reconstruction is the Gaussian with mean `l_ref+L_link L_0y` and covariance `T L_link F A_0^-1F^T L_link^T`; the full joint conditional with node coordinates, rather than a product of link marginals, retains their correlations. Those kernels express the declared statistical reconstruction; they do not assert recovery of the fine sample path or erase finite-`K,T` link fluctuations. The two independent retained cut combinations remain components of the dynamic `Y` state. The final root retains conditional internal link data and relative-frame marks, as described above.

If additional physical variables are subsequently marginalized from both generative and recognition laws, their additional conditional KL must be retained. It is not justified to identify (18) with a fresh simple Gaussian mismatch penalty or to let a generative evaluator depend on `Q`. Equation (36) completes the normalization/type check under the parent bridge's explicit vector-valued augmented admission; it does not prove a scalar Gaussian law-point representation or a stricter local-interface result.

Exact root closure is stable under perturbing residual weights that still annihilate `V_2` and under changing the common scalar `delta`. It is not generally stable under arbitrary coordinatewise pinning precisions: such a perturbation can create a root/normal cross block. Openness should therefore be asserted within the parent's displayed parameter family, or an explicitly enlarged family preserving `V_2`, rather than over all positive prior precision matrices.

## 9. Executed check and disposition

Two small exact SymPy calculations ran under `C:/anaconda/python.exe` through standard input. The first used the matrices in Section 1 and `K=30`, `k=1`, `delta=1/20`, `tau=1/7`. It independently formed `H^-1` and computed the Schur-parent rates as `|w|^2/(w^T H^-1 w)` for `w=P B_s^T(1,1)` and `w=P B_s^T(1,-1)`. It returned respectively

\[
293583/108460,\qquad903444457349/887532343380.
\tag{37}
\]

Both equal (22)/(24) exactly. It also returned residual ranks `5,7`, root dimension `3`, and exact equality `H R=delta R`. The second calculation returned exactly the seven-row spectrum (10a). The arithmetic output is recorded here because this lane owns only this report. No simulation, suite, GPU, Lean, tamper check, Git operation, production-code edit, prior-source edit, or shared-ledger mutation ran. The finite calculations corroborate their specific matrix identities; Sections 2-7 contain the general analytical argument.

Supported disposition: the Gaussian rate and two-stage static-composition statements hold under the stated model; the final root path projection is exact; the first path projection is generally approximate, with an explicit counterexample to exactness. The parent bridge now supplies first-stage force/VFE/path error formulas and a compatible parameter-order argument; their independent conditional-analysis check belongs to that assigned lane. This report supplies the previously unspecified common positive normal gap and the explicit normalized physical kernel (36), and confirms compatibility of the second episode and exact final invariance with those interfaces. The assembly must retain the vector-valued augmented-parent and translation-stabilizer scope. Agreement among checking lanes is not a replacement for the recorded analytical estimates.

## 10. Final source binding and remaining check ownership

The final read used `translation-link-conditional-bridge.md` with SHA-256 `19999cf85c9f47e01a946e7bc9401b4a9ad887815d879ff30396718eb0a8f9a7`, obtained directly by `Get-FileHash -Algorithm SHA256`. The source was read in full, with the assigned comparison concentrated on Sections 1-4 and 6-8. The hash identifies the checked text; it does not supply mathematical evidence by itself.

The final source incorporates the exact physical presentation/evaluator kernel, separates generative and variational conditionals, uses the common seven-row normal gap, restricts openness to the displayed parameter family, and makes its first-parent metric explicit. The chart `u=v=(alpha+t,alpha,beta)` has metric block `[[4,2],[2,4]]` on `(alpha,t)`, followed by diagonal `2,1,1`; differentiating its embedding into the original ten coordinates verifies that matrix. Pulling its two cut covectors through the inverse gives (8). Its `10 -> 5 -> 3` configuration counts and `16 -> 11 -> 9` augmented counts with all six physical labels retained are therefore consistent with the stated coordinates.

The source's finite-`K` symmetric parent rate `delta+(8/3)(1-1/(3 A_sym))`, `A_sym=delta+3K+1/3`, is exactly (22) at `k=1`. For `K>=256`, its stated `5/2<lambda_p<=delta+8/3` bound follows immediately. With initial projected cut in `(5/24,5/18)`, it remains above `1/6` through time `1/16` and is below `1/256` from time three, by direct substitution of these rate bounds. Hence the final text uses an actual inherited-parent episode, not only an asymptotic limiting flow or a static second projection. The final root remains exact independently of the first approximation error.

No unresolved construction interface remains **within this report's assigned spectral, static-normalization, typed-kernel, and inherited-episode scope** for that source revision. The conditional lane owns independent reconstruction of the primary source's transient entropy, force, and path inequalities (25)-(29), final conditional bounds (31)-(32), and their shared parameter order. The formation lane owns the independent reconstruction of its microscopic comparison bounds and positive-noise episode event. Those are remaining check assignments, not claims that the primary document lacks the formulas. This report neither substitutes agreement for those checks nor upgrades the approximate first projection to exact equality.

### Formatting-only final binding

The final source SHA-256 is `f966e62c8875eac523cbbfaf6f54c23e7ab98d489dce073d97b639068cbf72a5`. A direct byte comparison under `C:/anaconda/python.exe` verified that the current source equals the snapshot read from `evidence/2026-09-12-endogenous-dynamical-rg-goal/proofs/translation-link-conditional-bridge.md` after deleting exactly its three backslash-comma spacing macros. Those snapshot bytes had hash `19999cf85c9f47e01a946e7bc9401b4a9ad887815d879ff30396718eb0a8f9a7`; the revision removes six bytes and changes no other byte. The comparison returned `exact_formatting_relation=True`. The analytical scope and conclusions above therefore apply to the final source with that verified formatting-only relation. No new theorem calculation or test ran for this rebinding.
