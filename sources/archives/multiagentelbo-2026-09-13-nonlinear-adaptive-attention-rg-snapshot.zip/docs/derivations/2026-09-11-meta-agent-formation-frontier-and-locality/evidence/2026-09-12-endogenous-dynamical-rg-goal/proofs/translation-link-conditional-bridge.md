# Common kinetics, successive coalescence, and controlled conditional VFE

September 12, 2026. This construction addresses the [four-step target](evidence/2026-09-12-endogenous-dynamical-rg-goal/problem-contract.json) in one global Gaussian translation-link family. It derives two restoring scales from a supplied microscopic interaction-energy ratio while every coordinate uses the same kinetic rule. A first pair forms before the remaining cut relaxes. The two parent laws, their kinetics, their conditional free-energy errors, and the second episode are calculated in that same family. No chosen node speed, renewed parent speed, agreement observation, or conditional-equilibrium initialization is inserted.

This is an existential specialization, not an assertion that arbitrary VFE models produce a hierarchy. The microscopic energy ratio, positive reference precision, fixed law covariances, and common flat metric are model inputs. A scalar VFE does not select this metric. The compact angular construction in [the rate lane](endogenous-rates-and-coherence.md) and [the episode lane](successive-coalescence-construction.md) is a separate result. Its unresolved second conditional-entropy interface is not used below.

## 1. Source and probability types

The source-first starting points are [Theory/02_geometry.tex](../../../Theory/02_geometry.tex), `eq:geo-representations`; [Theory/05b_local_collective_elbo.tex](../../../Theory/05b_local_collective_elbo.tex), the law-valued local-state convention; [Theory/07c_full_graph_meta_agent_vfe.tex](../../../Theory/07c_full_graph_meta_agent_vfe.tex), random independent links and common-channel parents; [the earlier translation construction](normalized-alignment-parent-limit.md), Section 3; and [the exact evaluator calculation](microscopic-vfe-dynamics-construction.md). The read-only [live PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:timescales`, `sec:adiabatic_hierarchy`, and `sec:meta_agent_rg`, motivates internal Hessians, inherited metrics, and repeated formation. Its imposed timescales and tentative RG claims are not proofs of this result. The [prior Gaussian hierarchy](../2026-09-11-fast-slow-derived-hierarchy/gaussian-hierarchy-construction.md) already distinguishes common local kinetics from full-law Fisher kinetics; that distinction remains in force.

Fix one base point and the additive translation group acting on a sample line. Use three nodes and two oriented edges, `12` and `23`. Define

\[
 W=(u_1,u_2,u_3,v_1,v_2,v_3,l_{12}^b,l_{23}^b,l_{12}^m,l_{23}^m)\in\mathbb R^{10},
 \qquad b_i=N(u_i,1),\quad m_i=N(v_i,a),\quad 0<a<1.
 \tag{1}
\]

Each link translates the neighboring sample law. Its transported KL is the squared residual divided by twice the channel variance. Positive weights absorb the fixed model variance. The four links are independent state coordinates, not differences of node frames. The outer recognition `Q` is a law on the full `W`; it is not the product of the conditional laws `b_i,m_i`.

The normalized physical presentation is `zeta_i~m_i`, followed by `k_i|zeta_i~N(zeta_i,1-a)`. Recognition uses `zeta_i=v_i+xi_i`, `k_i=u_i+xi_i+epsilon_i`, with independent `xi_i~N(0,a)`, `epsilon_i~N(0,1-a)`. For every coupling with the prescribed two marginals,

\[
 \operatorname{KL}(S_i\Vert m_i\operatorname{ev}_i)
 =\operatorname{KL}(S_i\Vert R_i)+d_i,
 \qquad d_i=\frac{(u_i-v_i)^2}{2(1-a)}.
 \tag{2}
\]

Indeed `log(dR_i/d(m_i ev_i))=[(u_i-v_i)(k_i-zeta_i)-(u_i-v_i)^2/2]/(1-a)`, whose expectation under any such coupling is `d_i`. This proves the optimizing coupling over all couplings, not merely Gaussian ones.

Choose a coherent reference `W_ref`: its paired means are `h_i`, and both edge references are `h_i-h_j`. Put `w=W-W_ref`. Define the five-row matrix `B_f` by the residual vector

\[
 B_fw=(u_i-v_i)_{i=1}^3\mathbin\oplus
 (u_1-u_2-l_{12}^b,v_1-v_2-l_{12}^m),
 \qquad B_sw=(u_2-u_3-l_{23}^b,v_2-v_3-l_{23}^m).
 \tag{3}
\]

Let `D` be the first three rows of `B_f`. References cancel in (3). For `delta,K,k,T>0`, declare the proper configuration prior and effective target

\[
 H_0=\delta I+K B_f^TB_f+kB_s^TB_s,\quad
 H=H_0+\tau D^TD,\quad \tau=T/(1-a),
 \quad P_0=N(W_{\rm ref},T H_0^{-1}),\quad
 \pi=N(W_{\rm ref},T H^{-1}).
 \tag{4}
\]

Lebesgue measure is the reference. The prior is obtained from independent normalized Gaussian node/link reference factors, multiplied by the declared local node and incident-edge factors and normalized once. `H_0>=delta I` proves integrability. In energy notation `U_0=w^TH_0w/2`, `Z_0=(2 pi T)^5/sqrt(det H_0)`, and similarly `Z` uses `H`. The full generative joint is `P_0(dW) product_i m_i(dzeta_i) ev_i(zeta_i,dk_i)`; every conditional integrates to one. The observation space can be a singleton. Thus no success record is fabricated. Equations (2)–(4) give the exact scaled constrained VFE

\[
 \mathcal F_T(Q)=T\operatorname{KL}(Q\Vert P_0)+T E_Qd
 =T\operatorname{KL}(Q\Vert\pi)+T\log(Z_0/Z),
 \qquad d=\sum_i d_i.
 \tag{5}
\]

The evaluator contribution `tau D^TD` is retained; it has not been canceled by tuning the generative prior. The independent positive parameters in (4), and initial means near the episode below, define the admitted parameter family.

Under a passive frame translation `g_i`, both local means gain `g_i` and each link gains `g_i-g_j`; `W_ref` transforms by the same affine translation. Then `w`, the residuals, Lebesgue measure, and (4)–(5) are unchanged in components. This is covariance under re-expression. There is no finite prior invariant under all active translations with its reference held fixed. The coherent reference pins a physical comparison relative to specified prior data. The tree example has no loop; it neither rules out nor establishes nontrivial stabilizer holonomy in other families.

## 2. One common microscopic rule and derived bands

Give all ten coordinates the same unit flat metric and use its gradient and matched diffusion:

\[
 dw_t=-Hw_tdt+\sqrt{2T}dB_t,\qquad
 \frac{d\mathcal F_T}{dt}=-\int q_t\left|\nabla(U+T\log q_t)\right|^2dw.
 \tag{6}
\]

This is flat Riemannian gradient/Dirichlet kinetics with identity preconditioner, not the full-joint Fisher reaction equation. Each force reads only its reference, its same-node evaluator term, and incident edges. In particular
`dot l_12^b=K(u_1-u_2-l_12^b)-delta(l_12^b-l_ref_12^b)` and analogously for the other independent links. They move during formation. Global solutions follow from the linear coefficients; Gaussian tails justify the integration by parts in (6), and finite-entropy laws follow by the explicit Markov kernel. Deterministic comparison paths solve `dot w=-Hw`; they are not identified with finite-entropy Dirac recognition densities at `T>0`.

The matrix `B_f B_f^T` is positive definite with eigenvalues

\[
 2,2,3,(5-\sqrt{17})/2,(5+\sqrt{17})/2.
 \tag{7}
\]

Let `E` and `F` be orthonormal bases for `ker B_f` and its orthogonal complement, respectively. Each has five columns. Let `P=EE^T=I-B_f^T(B_fB_f^T)^{-1}B_f`. The inherited cut Gram matrix is

\[
 B_sPB_s^T=\begin{pmatrix}11/6&5/6\\5/6&11/6\end{pmatrix},
 \qquad \operatorname{spec}(B_sPB_s^T)=\{1,8/3\}.
 \tag{8}
\]

The seven stacked rows are independent. Their row-Gram spectrum is `4,2,2,3+sqrt(7),3-sqrt(7),2+sqrt(2),2-sqrt(2)`, so their least squared singular value is `b_*=3-sqrt(7)>0`. On their seven-dimensional normal space, `H>=delta I+min(K,k)b_*I`. On their common kernel `V_2`, of dimension three, `H=delta I` exactly. For `K/k` large, the five fast eigenvalues are order `K`, and the remaining two normal eigenvalues tend to `delta+k` and `delta+8k/3`. To see this without assuming separation, use the blocks

\[
 y=E^Tw,\ z=F^Tw,\quad
 H=\begin{pmatrix}C&B\\B^T&A\end{pmatrix},\quad
 A\succeq a_*I,\quad a_*\ge\delta+K(5-\sqrt{17})/2,
 \quad S=C-BA^{-1}B^T.
 \tag{9}
\]

Here `C=delta I+k E^TB_s^TB_sE` and `B=k E^TB_s^TB_sF`; neither contains `K` or `tau`, since `B_f E=D E=0`. Thus `A^{-1}=O(K^{-1})` and `S=C+O(k^2/K)`. Standard finite block elimination, or substitution of `z=-(A-lambda I)^{-1}B^Ty` into the eigenvalue equation for bounded `lambda`, proves these limits. No eigenvalue is declared a clock merely because it is a coordinate. The three `delta` rates describe motion relative to the supplied reference; without that reference they become neutral frame directions as `delta` tends to zero.

The ratio `K/k` is a supplied interaction-energy contrast. The restoration bands, their coefficients, and their induced parent metric follow from it and the common microscopic rule. They are not consequences of an unqualified scalar VFE alone.

## 3. Actual first and subsequent formation

Take `k=1`, `K>=256`, `0<delta<=1/100`. In the symmetric-channel deterministic preparation choose paired means `(x_0+y_0,y_0,0)` relative to `W_ref`, with all link deviations zero,

\[
 1/4<x_0<1/3,\qquad 1/8<y_0<1/6.
 \tag{10}
\]

This invariant slice has paired channels equal; it is a witness center, not a restriction on the final open initial-law family. The strong and weak edge residuals `x,y` satisfy

\[
 \dot x=-(3K+\delta)x+y,\qquad
 \dot y=Kx-(3+\delta)y,\qquad
 z_c=y+x/3,\quad \dot z_c=-\delta z_c-(8/3)y.
 \tag{11}
\]

Positive initial `x,y` remain positive by the inward vector field on the quadrant. Hence `z_c` is decreasing and `z_c(0)<5/18`. The comparison estimates

\[
 x(t)\le e^{-3Kt}/3+5/(54K),\qquad
 y(t)\ge y_0e^{-(3+\delta)t},
 \tag{12}
\]

give `x<1/512` and `y>1/10` throughout `[1/64,1/16]`. For the later interval substitute (12) into

\[
 \dot z_c=-(\delta+8/3)z_c+(8/9)x.
 \tag{13}
\]

Integration gives the convenient bound, dropping the helpful `delta`,

\[
 z_c(t)\le\frac5{18}e^{-8t/3}
 +\frac8{27}\frac{e^{-8t/3}-e^{-3Kt}}{3K-8/3}
 +\frac5{162K}(1-e^{-8t/3}).
 \tag{14}
\]

At `t>=3`, this is less than `1/256`; (12) gives the same bound for `x`. Therefore a residual threshold `1/32` produces a first pair `{1,2}` with singleton `{3}`, followed by the whole group, while the energy and update rule are fixed. Initially both edge residuals exceed that threshold. A whole interval of thresholds separates the strict margins; no unique threshold or permanent preferred partition is claimed. Grouping is read from the trajectory, not supplied to its equations.

For equal parameters, arbitrary transverse deterministic perturbations obey
`|w(t)-w_*(t)|<=exp(-delta t)|w(0)-w_*(0)|`. Every residual row has norm at most `sqrt(3)`. For any finite horizon, sufficiently small open perturbations of the positive residual weights, the common reference precision, and the initial mean preserve the strict margins by the explicit matrix exponential and Duhamel formula. This provides openness in the actual ten-dimensional initial means and independent positive residual weights, rather than only in the symmetric slice. The matrices, rates, and reductions are then taken from those perturbed coefficients; the displayed scalar constants describe the witness center. In particular the independent parameters of (4), with `k` near one, form an open admitted family and are the operative parameter space below. Arbitrary coordinatewise changes to the pinning metric are outside this exact-root-closure claim. No exact equality of the evaluator coefficient and an edge coefficient is required.

For the stochastic process started at a fixed comparison point, the difference `e` from its deterministic path satisfies `de=-He dt+sqrt(2T)dB`. Stopping at `|e|=rho` and applying Ito to `|e|^2` gives

\[
 \Pr\{\sup_{t\le L}|e_t|\ge\rho\}\le 20TL/\rho^2.
 \tag{15}
\]

For the stationary-covariance Gaussian preparation used below, add the initial-tail bound `T tr(H^{-1})/rho^2<=10T/(delta rho^2)` and use radius `2rho`. An initial law within KL `eta^2` of that preparation changes any path-event probability by at most `eta/sqrt(2)`, by the likelihood-ratio contraction and the elementary Pinsker bound. With `rho` below the strict residual margins and sufficiently small positive `T,eta`, the two formation episodes therefore hold with explicitly high probability. Positive temperature does not give exact support on a coherent set.

## 4. Exact normalized parents and inherited kinetic rule

Use the global orthogonal map `w -> (y,z)` in (9); its Jacobian has absolute value one. There is no chart, fiber boundary, wrapping choice, or discarded boundary flux. The first parent retains `y in R^5`. Conditional Gaussian integration gives

\[
 \pi_1=N(0,T S^{-1}),\qquad
 k_1(dz|y)=N(-A^{-1}B^Ty,T A^{-1})(dz).
 \tag{16}
\]

The true generative parent is `P_{01}=E^T_#P_0`, with the Schur complement of `H_0`, not `S`. Define

\[
 d_1(y)=-\log E_{P_0(\cdot|y)}e^{-d(w)},\qquad
 \mathcal F_{1,T}(r)=T\operatorname{KL}(r\Vert P_{01})+T E_r d_1.
 \tag{17}
\]

Since `d>=0`, the conditional integral lies in `(0,1]`. Gaussian integration is finite and explicit, including determinant constants. Disintegration proves for every finite-VFE `Q`

\[
 \mathcal F_T(Q)=\mathcal F_{1,T}(Q_y)+T\Delta_1(Q),\qquad
 \Delta_1(Q)=E_{Q_y}\operatorname{KL}(Q(dz|y)\Vert k_1(dz|y)).
 \tag{18}
\]

One way to check every constant is `pi_1=(Z_0/Z)e^{-d_1}P_{01}`. The minimizing hidden conditional in (18) is `k_1`, whereas the generative downward prior is `P_0(dz|y)`. They are different objects.

All physical evaluator/presentation kernels at the parent are the pushforward or conditional integration of the same augmented joint. For example the generative parent presentation is `E_{P_0(dw|y)} product_i m_i ev_i`; it integrates to one and retains any induced dependence. The constrained recognition lift uses `k_1(dw|y) product_i R_i`. This is an exact augmented conditional-family model; it does not assert that a single ordinary Gaussian law point reproduces every child evaluator. Conditional reconstruction retains structural link information statistically, and coarse link observables are inherited functions or conditional laws. No link value is silently set to a node-frame difference at finite `K,T`.

An explicit presentation makes this type enlargement concrete. Let `V` select the three model means, let `A_0,B_0` be the generative blocks of `H_0`, and set `L_0=E-F A_0^{-1}B_0^T`. The parent presentation is the correlated vector Gaussian `zeta|y~N(v_ref+V L_0 y,a I_3+T V F A_0^{-1}F^T V^T)`, followed by the original normalized evaluator `k|zeta~N(zeta,(1-a)I_3)`. The latter is independent of hidden `W` once `zeta` is given. At the final root, replace `L_0 y` by `R q` and the hidden covariance factor by `N(N^T H_0 N)^{-1}N^T`. Recognition uses its own specified conditional, not this generative conditional. These formulas exhibit normalized correlated parent model/presentation and belief-output laws with the original physical labels retained.

The Dirichlet form conditional on `y` gives inherited mobility `E^T I E=I_5`, and potential `y^TSy/2`. Thus the first autonomous approximation is

\[
 d\bar y=-S\bar ydt+\sqrt{2T}dB^y.
 \tag{19}
\]

This metric is the restriction of the microscopic product metric. In nonorthogonal common-node/link coordinates it is a nontrivial Gram inverse; assigning the original coordinatewise identity after deleting a child would give a different dynamics. The first stage eliminates the five actual fast normal combinations, including same-node evaluator relaxation, while retaining the slow cut. It is therefore more than deletion of one node's raw variables.

An explicit chart on `ker B_f` is `u=v=(alpha+t,alpha,beta)`, `l_12^b=l_12^m=t`, with independent cut links `s_b,s_m`. It consists of a pair-parent root `alpha`, internal relative-frame mark `t`, singleton root `beta`, and the two cuts. In the order `(alpha,t,beta,s_b,s_m)` the metric is the block matrix with upper-left block `[[4,2],[2,4]]` and remaining diagonal entries `2,1,1`. Pulling the cut covectors through its inverse gives (8). Thus `10 -> 5 -> 3` counts evolving configuration coordinates, not the number of physical evaluator labels. If all six original physical presentation/output coordinates are also carried, the corresponding augmented dimensions are `16 -> 11 -> 9`. The objective (17) belongs to the specified lifted conditional family; further marginalizing its physical variables would introduce an additional conditional KL, not a free equality of ELBOs.

Let `V_2=ker B_f intersect ker B_s`, and let `R` have orthonormal columns spanning it. As `V_2` is contained in `ker B_f`, write `R=EJ`, `J^TJ=I_3`. The second map is `q=J^Ty=R^Tw`. Equations (4) and (9) imply `HR=delta R`, `SJ=delta J`, and hence

\[
 dq=-\delta qdt+\sqrt{2T}dB^q
 \tag{20}
\]

is the exact projected process from both the fine process and (19). The two remaining cut modes are eliminated only when the later formation and entropy estimates license that interpretation. Algebraic availability of the projection at time zero is not called prior formation.

The second generative law is `P_{02}=R^T_#P_0`, and
`d_2(q)=-log E_{P_{01}(dy|q)}exp[-d_1(y)]` equals `-log E_{P_0(dw|q)}exp[-d(w)]` by the tower rule. Both orders therefore give the same normalized law, augmented kernels, generative child conditionals, and retained objective. Conditional relative entropy also obeys the exact tower

\[
 \Delta_{\rm final}(Q)=\Delta_1(Q)+
 E_{Q_q}\operatorname{KL}(Q(dy|q)\Vert\pi_1(dy|q)).
 \tag{21}
\]

This identity alone gives no smallness; the next sections supply that missing dynamical estimate.

## 5. Conditional lag on an open family of full densities

First take the noncoherent Gaussian reference preparation

\[
 Q_0^*=N(m_0,T H^{-1}),\quad Q_t^*=N(m(t),T H^{-1}),\quad
 m(t)=e^{-Ht}m_0.
 \tag{22}
\]

Its covariance is stationary but its conditional mean is not at equilibrium. Put

\[
 \theta=m_z+A^{-1}B^Tm_y,\quad r=|A^{1/2}\theta|,\quad
 \Delta_1(Q_t^*)=\frac{r(t)^2}{2T}.
 \tag{23}
\]

The exact mean equations yield

\[
 \dot m_y=-Sm_y-B\theta,\qquad
 \dot\theta=-(A+A^{-1}B^TB)\theta-A^{-1}B^TSm_y.
 \tag{24}
\]

Multiplication by `theta^T A` shows that the first two terms dissipate `r^2`: they are `-theta^T A^2 theta-|B theta|^2`. Since `|m(t)|<=|m_0|`, the upper Dini derivative at `r=0` included,

\[
 \dot r\le-a_*r+\frac{\|B\|\|S\||m_0|}{\sqrt{a_*}},\qquad
 r(t)\le e^{-a_*t}r(0)+
 \frac{\|B\|\|S\||m_0|}{a_*^{3/2}}.
 \tag{25}
\]

Thus the conditional lag, including moving-retained-mean forcing, is quantitatively small after a derived burn-in, with a squared plateau of order `1/(K^3 T)` at fixed other inputs. This is a dimensionless KL statement, stronger than state-path closeness.

Now allow any initial density in the strict relative-entropy neighborhood

\[
 \operatorname{KL}(Q_0\Vert Q_0^*)<\eta^2.
 \tag{26}
\]

Markov contraction gives `KL(Q_t||Q_t^*)<=eta^2`. The reference conditional equals `k_1` translated by the same `theta(t)` for every `y`. Write `J_t=E_{Q_y}KL(Q(dz|y)||Q_t^*(dz|y))<=eta^2`. The log ratio of the two Gaussian conditionals is affine in `z`; the Gaussian exponential-tilt inequality bounds its centered conditional mean by `sqrt(2T J_t)` in the `A` metric. Expanding that log ratio and applying Cauchy–Schwarz gives

\[
 \Delta_1(Q_t)\le(\sqrt{J_t}+r(t)/\sqrt{2T})^2
 \le(\eta+r(t)/\sqrt{2T})^2.
 \tag{27}
\]

For clarity, the exponential-tilt inequality follows from
`KL(h||N(mu,T A^{-1}))>=sup_v[v^T(E_hz-mu)-T v^TA^{-1}v/2]`; optimizing the finite vector `v` yields the required mean bound. Finite Gaussian-reference KL ensures the necessary moments. The family (26) includes non-Gaussian correlated densities and need not have the optimal hidden conditional. For an explicit topology witnessing openness, write `Q_0=f Q_0^*`, with `E_{Q_0^*}f=1` and `ess sup |f-1|<nu<1`. This is open in the weighted `L-infinity` density-ratio norm within the normalized affine space. Taylor's theorem for `f log f`, with the zero-mean linear term removed, gives `KL(Q_0||Q_0^*)<=nu^2/[2(1-nu)]`; choose `nu` to put the neighborhood inside (26). Open mean and parameter neighborhoods are allowed as well. Equation (27) is not an assumption that the fine law stays conditionally matched.

The true parent marginal forward equation has drift
`-Sy-B(E[z|y]+A^{-1}B^Ty)`. Its conditional-force error relative to (19) satisfies

\[
 \|\text{force defect}\|_{L^2(Q_y)}
 \le\|BA^{-1/2}\|\sqrt{2T\Delta_1(Q_t)}.
 \tag{28}
\]

Together, (18), (25), (27), and (28) bound the actual parent force and actual transient scaled VFE defect `T Delta_1`, and the ordinary unscaled defect `Delta_1`. Nothing infers entropy smallness from a transport distance.

## 6. Finite-path approximation and the actual inherited second episode

For (22), couple (19) to the fine process using the same `y_0` and Brownian motion `B^y`. Put `xi=z+A^{-1}B^Ty`. Its covariance at every time is `T A^{-1}` and its mean is `theta`. Variation of constants in the `y` equation yields

\[
 E\sup_{t\le L}|y_t-\bar y_t|
 \le\|B\|\left[L\sqrt{5T/a_*}
 +\frac{r(0)}{a_*^{3/2}}
 +\frac{L\|B\|\|S\||m_0|}{a_*^2}\right].
 \tag{29}
\]

Here `S` is positive definite, so `||exp(-St)||<=1`; integrate the square-root second moment of `xi`, and then (25) divided by `sqrt(a_*)`. This proves (29) without a pathwise-equilibrium substitution. For (26), use the identical joint Markov construction of the fine/parent coupling: probabilities of its events differ from the reference coupling by at most `eta/sqrt(2)`. Consequently a path tolerance `epsilon` fails with probability at most the right side of (29) divided by `epsilon`, plus `eta/sqrt(2)`. We do not assert an expectation bound for arbitrary (26) merely from total variation.

The microscopic strong residual is `B_fFz`; the mean bound `|m_z|<=r/sqrt(a_*)+||B||||m_0||/a_*`, the stationary covariance, and (15) make it small on the first episode with high probability. In particular on the global deviation event, `sup|z_t|<=sup|m_z(t)|+2rho`, with the supremum starting at `t_b`. The retained weak residual is `B_s E y`, while the actual weak residual is `B_s E y+B_sFz`. Thus this mean bound, the same covariance/path control, and (29) transfer the strict pair-only and later whole-group margins to the inherited first parent. In the symmetric limit `K` tends to infinity the surviving cut satisfies

\[
 \dot z_c=-(\delta+8/3)z_c,
 \tag{30}
\]

with its rate from (8). There is also a direct finite-`K` calculation: put `A_sym=delta+3K+1/3`. The symmetric-channel Schur block is `delta I+(1-1/(3 A_sym))vv^T`, where `v` is the projected cut row and `|v|^2=8/3`. Its actual cut therefore satisfies `bar z_c(t)=(y_0+x_0/3)exp(-lambda_p t)`, with `lambda_p=delta+(8/3)(1-1/(3 A_sym))`. For `K>=256`, `5/2<lambda_p<=delta+8/3`. Since `5/24<y_0+x_0/3<5/18`, the parent cut is greater than `1/6` on the first interval and less than `1/256` from time three. The antisymmetric cut is retained as the other positive mode in (8); it vanishes only at the witness center and is allowed in the open neighborhood. This proves the second episode directly under the inherited first parent, with its inherited initial value. Equation (29) additionally compares it with the fine motion. No parent clock is reset. Equation (20) makes the final retained-path comparison exact.

## 7. Second conditional entropy and a compatible order of parameters

Choose an orthonormal basis `N` of `V_2^perp` and write `n=N^Tw`. Since `V_2` is invariant, `H_N=N^THN` has no cross block with `q`. Its smallest eigenvalue satisfies `beta>=delta+min(K,k)b_*>0`. For (22),

\[
 \Delta_{\rm final}(Q_t^*)=
 \frac{m_n(t)^TH_Nm_n(t)}{2T},\qquad
 m_n(t)=e^{-H_N(t-t_b)}m_n(t_b).
 \tag{31}
\]

For (26), the same Gaussian-shift proof as (27) gives

\[
 \sqrt{\Delta_{\rm final}(Q_t)}
 \le\eta+
 e^{-\beta(t-t_b)}
 \sqrt{m_n(t_b)^TH_Nm_n(t_b)/(2T)}.
 \tag{32}
\]

In particular the second conditional term in (21) is bounded by (32), and the final VFE defect is exactly `T Delta_final`. The fine final-parent force defect is zero because the normal-to-root block vanishes. Applying the same argument to the actual autonomous first parent (19), whose stationary covariance is `T S^{-1}`, controls its second conditional entropy from its own inherited initial mean. For an arbitrary (26), its initial parent marginal is within KL `eta^2` of that Gaussian parent marginal by data processing. Thus both the fine law and the first inherited parent have explicit second conditional control; (21) is not being used as a substitute for that proof.

A very small geometric residual need not yet be small compared with `sqrt(T)`. Therefore choose a later finite validation interval if a specified entropy tolerance demands it. The following parameter order proves simultaneous nonemptiness and avoids incompatible limits.

For `K>=k` the same lower bound `beta_0=delta+k b_*` applies to the two normal modes of `S`: if `y` is orthogonal to the root in `ker B_f`, then every `(y,z)` lies in `V_2^perp`, and `y^T S y=min_z (y,z)^TH(y,z)>=beta_0|y|^2`. Thus the uniform full and parent gaps used below are proved by the same quadratic form, not presumed from an asymptotic spectrum.

Fix `delta` strictly between zero and `1/100`, `k=1`, `a` in `(0,1)`, an interior mean in (10), a small geometric radius `rho`, and a desired positive error probability and entropy tolerance. Fix `t_b=1/64`. From the exact energy decomposition
`m^THm=m_y^TSm_y+r^2`, (25), and bounded `C,B,S`, there is a constant `C_0` independent of all sufficiently large `K` and all `0<T<=T_0` such that `m_n(t_b)^TH_Nm_n(t_b)<=C_0`. The term `exp(-a_*t_b)r(0)` is uniformly bounded and tends to zero; `r(0)=O(sqrt(K+tau))`. The autonomous first parent's corresponding normal energy is also bounded independently of `K`. Choose `C_0` for both.

Set the final observation horizon at least four and large enough that
`exp[-beta_0(L-1-t_b)]sqrt(C_0/(2T))` is below half the required square-root entropy tolerance, where a fixed `beta_0>0` bounds the normal gaps of both full and first parent for all sufficiently large `K`. It suffices to take `L=O(1+log(1/T))`. Choose `T>0` small enough that (15), the initial-tail term, and the geometric noise estimates through `L` meet the probability tolerance; this is possible because `T log(1/T)` tends to zero. Choose `eta>0` below both entropy and probability margins. Finally choose `K` large enough that (25)–(29) meet the first conditional and inherited-path tolerances at this fixed `T,L`, and the Schur normal gap is at least `beta_0`. This order is compatible: the earlier constants were uniform in large `K`, whereas `T,L` are fixed when `K` is increased.

The first episode remains `[1/64,1/16]`; geometric whole-group coherence holds from time three through the finite horizon. On the final interval `[L-1,L]`, both (32) and the parent version hold. Strict inequalities persist in a neighborhood of the selected parameters and means, and in a sufficiently small entropy neighborhood (26). Thus the joined result is an open, positive-temperature family, not an isolated deterministic path or a limit distribution.

## 8. What the construction establishes

Within (1)–(6), common microscopic kinetics and a specified local energy contrast yield five fast restoring modes, two slower cut modes, and three reference-relative retained modes. Their actual trajectory has a pair-only episode followed by a whole-group episode. The first reduction uses the limiting fast restoring subspace, retaining its finite-`K` coupling through the Schur complement and the explicit error bounds; it is not called a finite-`K` invariant eigenspace. The second coalescence occurs under that inherited system. Both generations retain the normalized generative law, the physical evaluator kernels, the variational conditional costs, and exact composition. Equations (27)–(29) and (31)–(32) supply transient force, entropy, VFE, and path bounds in one compatible regime.

The result does not derive the microscopic contrast `K/k`, learn an architecture, select a unique grouping threshold, prove a permanent hierarchy, or construct infinite-depth RG. Fixed channel variances and additive translation links are specializations. In this tree family no nontrivial loop holonomy is needed. The physical prior reference makes the collective root meaningful relative to prior data; passive gauge motion alone is not a physical slow clock. Coarse evaluators can be correlated conditional kernels rather than ordinary single-Gaussian agents. Exact retained memory is available by eliminating the linear `z` equation, as recorded in [the conditional-lag lane](conditional-lag-and-parent-vfe.md); the present autonomous approximation instead retains the explicit nonzero error bounds above.
