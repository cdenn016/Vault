"""Bind written derivations and their reviewed disposition, without proving mathematics."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


RUN = Path(__file__).resolve().parent
FRONTIER = RUN.parent.parent
CONTRACT = json.loads((RUN / "problem-contract.json").read_text(encoding="utf-8"))
META = {key: CONTRACT[key] for key in ("schema_version", "contract_id", "target_digest")}
HEADER = "<!-- rigorous-theory-search-metadata " + json.dumps(META, separators=(",", ":")) + " -->\n"


def digest(path: Path) -> str:
    """Identify the retained evidence bytes; this is not a scientific pass criterion."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name: str, data: dict) -> None:
    """Write one structurally bound record."""
    (RUN / name).write_text(json.dumps(META | data, indent=2) + "\n", encoding="utf-8")


def write_markdown(name: str, content: str) -> None:
    """Write a required narrative record with target metadata."""
    (RUN / name).write_text(HEADER + content + "\n", encoding="utf-8")


def main(release: bool) -> None:
    """Record a checkpoint or the explicitly reviewed terminal disposition."""
    sources = {
        "model": FRONTIER / "nonlinear-endpoint-attention-model.md",
        "conditional": FRONTIER / "nonlinear-adaptive-conditional-route.md",
        "formation": FRONTIER / "nonlinear-cyclic-formation-route.md",
        "joined": FRONTIER / "nonlinear-adaptive-attention-completion.md",
        "model-check": FRONTIER / "nonlinear-attention-model-check.md",
        "alternate": FRONTIER / "nonlinear-attention-model-route.md",
        "normalized-predecessor": FRONTIER / "adaptive-normalized-model.md",
        "flag-predecessor": FRONTIER / "adaptive-cyclic-witness.md",
        "entropy-predecessor": FRONTIER.parent.parent / "reviews/2026-09-13-program-review-next-phase/dynamics-frontier-review.md",
        "entropy-check": FRONTIER.parent.parent / "reviews/2026-09-13-program-review-next-phase/independent-verification.md",
    }
    reconstruction = FRONTIER / "nonlinear-adaptive-attention-reconstruction.md"
    if reconstruction.exists():
        sources["reconstruction"] = reconstruction
    if release and not reconstruction.exists():
        raise RuntimeError("The separate reconstruction is required before release.")
    proof_dir = RUN / "proofs"
    proof_dir.mkdir(exist_ok=True)
    assumptions = [
        {"id": "A1", "kind": "MODELING_POSTULATE", "statement": "At fixed c_*, a chain of 2^(L-1) triangles for each prescribed finite L>=2, independent translation links, belief/model laws and the declared evaluator family."},
        {"id": "A2", "kind": "MODELING_POSTULATE", "statement": "Proper correlated prior aH+P_K-TR, coherent-coordinate Gaussian observation, calibration Y=2, internal-neighbor categorical choices and strictly positive normalized Bernoulli success observations."},
        {"id": "A3", "kind": "MODELING_POSTULATE", "statement": "Common unit continuous mobility on each retained source-assignment sheet, zero categorical mobility, and exact-law deterministic model learning with the inherited complete microscopic Fisher metric; no Gaussian recognition closure."},
        {"id": "A4", "kind": "MODELING_POSTULATE", "statement": "Fixed delta=10^-4/n, supplied descending interaction contrasts, temperature and amplitude in N37/F37, and the specified nonempty initial-law neighborhood; constants may depend on finite L."},
        {"id": "A5", "kind": "MODELING_POSTULATE", "statement": "Nested orthogonal common-channel retentions with complete conditional source, occupancy, evaluator and loop marks; every parent activates from the preceding actual law and parameter."},
    ]
    evidence, bindings = [], []
    for key, source in sources.items():
        snapshot = proof_dir / source.name
        snapshot.write_bytes(source.read_bytes())
        evidence.append({"id": "proof-" + key, "kind": "DERIVATION", "supports": True,
                         "scope": "Written derivation with its own stated scope in " + source.name,
                         "side_conditions": [a["statement"] for a in assumptions],
                         "artifact_path": snapshot.relative_to(RUN).as_posix(), "artifact_sha256": digest(snapshot)})
        bindings.append({"source": str(source.relative_to(FRONTIER.parent.parent)),
                         "snapshot": snapshot.relative_to(RUN).as_posix(), "sha256": digest(source)})
    specifications = [
        ("c1", "The complete source/evaluator generative experiment is normalized and has the exact full marked restricted VFE, complete covector and inherited generative Fisher metric E24-E29; E5-E23 supply the model and collapsed comparison.", ["model", "model-check", "normalized-predecessor"], "For all finite admitted parameter values.", "A missing normalizer, invalid kernel or incomplete score refutes the identity."),
        ("c2", "The fixed source deformation is non-Gaussian on the hidden physical coordinates, and all exact optimizing parents satisfy the stated global relative Hessian, dual-force and mixed-scale bounds.", ["model", "formation", "conditional", "flag-predecessor"], "For every fixed finite L and sufficiently small epsilon, with delta=10^-4/n fixed.", "A missing source covariance term, loss of positive curvature, or uncontrolled hidden mixed derivative refutes the bound."),
        ("c3", "The coupled fine and own-law parent dynamics are well posed on the common horizon, stay in [1,2.1], have O_L(epsilon) model speed and achieve a(2/epsilon)>1.5.", ["conditional", "formation", "model"], "For every member of the specified initial-law neighborhood and sufficiently small epsilon at each finite L.", "An externally supplied coefficient path, circular bootstrap or parameter exit refutes the claim."),
        ("c4", "The finite cyclic family has L actual coherence episodes with separated future bridges, retained loop dynamics, and the stated actual activation-energy and initial-neighborhood bounds, including 6-to-2-to-1.", ["formation", "conditional", "joined"], "For every fixed L>=2 with the stated exceptional probability, on the specified disjoint windows and through 2/epsilon.", "An assumed merger, missing residual margin, discarded loop or reset at activation refutes formation."),
        ("c5", "Actual discarded marked conditional KL is O_L(epsilon^2) and the complete same-state model covector discrepancy is O_L(T epsilon) after entrance, uniformly through 2/epsilon.", ["conditional", "entropy-predecessor", "entropy-check"], "At each successive active interface in the one common regime.", "An unproved LSI, missing moving-score term, incorrect activation entropy or divergent ratio refutes the estimate."),
        ("c6", "Complete physical, optimizing and recognition parent laws retain all required marks and compose exactly through the fixed common channels with the stated same-time conditional KL tower.", ["model", "joined", "conditional"], "For every finite retention and positive admitted parameter, with separate physical and optimizing kernels.", "A product of separately averaged event weights, missing conditional mark, or false Markov closure refutes the statement."),
        ("c7", "Actual model learning changes one model-posterior source row averaged under the actual continuous law by TV>0.37 and both first eliminated physical and optimizing conditionals by KL>1/200, uniformly in retained input and assignment; recognition assignment masses remain fixed.", ["model", "model-check", "alternate", "conditional"], "Between initialization and the actual learned endpoint at 2/epsilon for each finite L.", "Vanishing posterior-row variation, zero nonlinear deformation or failure of the uniform affinity bound refutes this change discriminator."),
        ("c8", "Independently learning parents have O_L(r_epsilon) parameter discrepancy and a separate O_L(A epsilon^2) retained-path coupling, outside the displayed vanishing exceptional event.", ["conditional", "formation", "joined"], "For each actual activation and every finite sequential replacement through 2/epsilon.", "Borrowed model schedules, a largest-stiffness exponential, missing retained initial-law error or noise mismatch refutes the coupling."),
    ]
    claims = []
    for key, statement, proofs, quantifiers, falsifier in specifications:
        if release:
            proofs = [*proofs, "reconstruction"]
        claims.append({"id": key, "statement": statement, "quantifiers": quantifiers,
                       "kind": "MATHEMATICAL", "target_digest": META["target_digest"],
                       "state": "EVIDENCE_VERIFIED" if release else "CANDIDATE",
                       "assumption_ids": [a["id"] for a in assumptions],
                       "evidence_ids": ["proof-" + p for p in proofs],
                       "bridge_premise_ids": [], "falsifier": falsifier})
    target = CONTRACT["target"]
    claims.append({"id": "target", **{k: target[k] for k in ("statement", "quantifiers", "kind")},
                   "target_digest": META["target_digest"], "state": "EVIDENCE_VERIFIED" if release else "CANDIDATE",
                   "assumption_ids": [a["id"] for a in assumptions],
                   "evidence_ids": ["proof-joined", "proof-reconstruction"] if release else ["proof-joined"],
                   "bridge_premise_ids": [], "falsifier": target["falsification_criterion"]})
    write_json("claim-ledger.json", {"assumptions": assumptions, "evidence": evidence, "claims": claims})
    dependencies = {"target": [s[0] for s in specifications], "c2": ["c1"], "c3": ["c1", "c2"],
                    "c4": ["c2", "c3"], "c5": ["c2", "c3", "c4", "c6"],
                    "c6": ["c1"], "c7": ["c1", "c3"], "c8": ["c2", "c3", "c4", "c6"]}
    write_json("dependency-dag.json", {"edges": [{"from": a, "to": b} for a, ds in dependencies.items() for b in ds]})
    all_claims = [c["id"] for c in claims]
    common = {"obligations": [c["statement"] for c in claims], "failure_test": target["falsification_criterion"],
              "novelty_fingerprint": "Continuation of existing normalized-source, nonlinear and adaptive cyclic research; priority unassessed."}
    families = [
        common | {"family_id": "NAR-J1", "core_mechanism": "Retain each source assignment as a static discrete sheet, with nonlinear continuous diffusion and complete own-law model learning, preserving actual full marked activation.", "target_obligation_ids": all_claims, "representation": "Finite disjoint union of non-Gaussian law/link carriers on triangle chains with dynamic loops.", "invariant_or_obstruction": "Uniform per-sheet curvature and entropy bounds, exact label retention and complete categorical model score.", "bridge": "E24-E29 and the final conditional/formation sections apply N20-N51 and F14-F44 uniformly per sheet and sum actual positive label masses; same-label path coupling has zero categorical error.", "verified_results": all_claims if release else [], "open_gaps": [] if release else ["Separate full reconstruction pending."], "disposition": "completed within stated admission" if release else "construction under review"},
        common | {"family_id": "NAR-E1", "core_mechanism": "Conditionally optimize source rows, then evolve the collapsed continuous nonlinear law.", "target_obligation_ids": ["c1", "c2", "c3", "c4", "c5"], "representation": "Non-Gaussian continuous law with exact posterior source readouts.", "invariant_or_obstruction": "Actual marked source conditional at activation differs from the optimizing marginal source kernel.", "bridge": "Its continuous proofs transfer uniformly to NAR-J1 after retaining assignments and adding the categorical score.", "verified_results": ["continuous subresults only"] if release else [], "open_gaps": ["Does not by itself activate the full actual marked recognition law under its collapsed generator."], "disposition": "retained continuous comparison; full-target shortcut rejected"},
        common | {"family_id": "NAR-S1", "core_mechanism": "Independent scalar contrast deformation with separable normalized source experiment.", "target_obligation_ids": ["c1", "c7"], "representation": "Nonlinear scalar factor times cyclic Gaussian complement.", "invariant_or_obstruction": "The nonlinear factor is removed at the first unmarked retention.", "bridge": "Bounded-tilt affinity discriminator transfers after explicit covariance comparison.", "verified_results": ["c7 affinity lemma only"] if release else [], "open_gaps": ["Does not supply the selected loop-coupled full target."], "disposition": "retained limited alternate"},
        common | {"family_id": "NAR-MIXED-SOURCE", "core_mechanism": "Source choices allowed to mix internal and bridge scales.", "target_obligation_ids": ["c2", "c5"], "representation": "General mixed-level posterior rows.", "invariant_or_obstruction": "Source covariance can give a square-root mixed scale; the current normal-only cross proof does not apply.", "bridge": "Requires a new mixed-derivative estimate or a different common regime.", "verified_results": [], "open_gaps": ["No quantitative closure supplied for mixed-level rows."], "disposition": "unresolved extension, not a refutation"},
    ]
    write_json("approach-registry.json", {"mechanism_families": families})
    if release:
        ref = {"artifact_path": "proofs/" + reconstruction.name, "artifact_sha256": digest(reconstruction)}
        attacks = [
            ("normalization", ["c1", "c6"], "Posterior source substitution, omitted q0 constants or a wrong reverse kernel could change the normalized parent.", "Reconstruct E5-E10 and E24-E29 with complete categorical model score and exact marked common-channel laws."),
            ("marked-activation", ["c1", "c6", "c8", "target"], "The collapsed continuous parent would replace the actual source kernel by its optimizing kernel at activation.", "The sustained draft defect is resolved by NAR-J1: retain static source assignments, initialize the full actual joint law, use its full score, and couple identical categorical paths."),
            ("nonlinearity", ["c2", "c7"], "A coefficient sent to zero, erased covariance or separable first-stage factor could fake nonlinear adaptive completion.", "Check fixed delta, E11-E15, exact generated parent integrals and retained loop coupling."),
            ("bootstrap", ["c3", "c4"], "Assumed learning or assumed retained moments could make the formation argument circular.", "Rebuild local solutions, conditional interval estimates, weighted moment comparison and the inward-velocity continuation."),
            ("actual-entropy", ["c5", "c6"], "Gaussian path proximity or conditional resets could manufacture small actual hidden KL.", "Reconstruct the nonlinear entropy floor, actual retention bound, larger fast-block chain rule and moving-score inequality."),
            ("long-horizon", ["c8", "c5"], "A hidden largest-stiffness multiplier or borrowed parameter schedule could invalidate the common adaptation horizon.", "Check all exponents and separate own-law parameter and path estimates through 2/epsilon."),
            ("quantifiers", ["c4", "c7", "target"], "The two-level example, preparation or shrinking physical scale might not satisfy the stated all-finite-L target.", "Check the generic initial direction, specified neighborhood, explicit two-stage carrier and all simultaneous ratios against the frozen admissions."),
        ]
        write_json("adversarial-report.json", {"attacks": [{"id": k, "claim_ids": cs, "attack": a, "response": r, "disposition": "REJECTED", **ref} for k, cs, a, r in attacks],
            "independent_reconstruction": {"claim_ids": all_claims, "method": "Separate nonauthor reconstruction from the frozen target and exact component derivations, with explicit interface attacks.", "result": "PASS", "conclusion": "Written derivations support the finite admitted target; scope restrictions remain assumptions.", **ref},
            "oracle_erasure": {"claim_ids": all_claims, "method": "Remove favorable expectations and author verdicts, then inspect premises and every dependency for literal and paraphrased dependence.", "result": "PASS", "conclusion": "Only the declared model, initial class and proved inequalities are load-bearing.", **ref}})
    strongest = "For every finite L>=2, the admitted nonlinear cyclic family has L actual formation levels, order-one learned source-row and hidden-conditional changes, exact marked parents and vanishing conditional, score and independently learned path errors on 2/epsilon."
    write_json("release.json", {"checkpoint": "reviewed construction" if release else "joined construction awaiting reconstruction", "target_claim": "target", "terminal_status": "COMPLETE_AFFIRMATIVE" if release else None, "certificate_claim": "target" if release else None, "strongest_result": strongest if release else "Written joined construction is under independent review.", "unresolved_obligations": [] if release else ["Independent full reconstruction and source-bound release checks."]})
    write_markdown("construction-or-strongest-theorem.md", "# Nonlinear adaptive cyclic construction\n\n" + strongest + "\n\nThe exact statement, initial-law neighborhood, construction and hypothesis map are in proofs/nonlinear-adaptive-attention-completion.md. Component derivations are copied alongside it. This record distinguishes exact probabilities, conditional approximation and separate path approximation.")
    write_markdown("counterexample-register.md", "# Route failures and substantive attacks\n\nThe collapsed continuous construction did not preserve the full actual marked recognition kernel at activation. This was a sustained defect in the proposed full-target completion. The final NAR-J1 construction retains each source assignment as a discrete coordinate with zero mobility, initializes the exact actual joint law and includes the categorical model score. It preserves the posterior-row meaning while explicitly keeping actual recognition assignment masses fixed.\n\nMixed-level source rows can violate the normal mixed-scale estimate. A removed scalar nonlinear factor does not prove continuing loop-coupled nonlinear dynamics. A fixed source prior cannot supply the recorded learned-row discriminator by itself. Gaussian path proximity does not control conditional entropy; exact marginal probabilities do not establish Markov path closure. These refute shortcuts or remove a route, not the existential target. See the separate reconstruction for sustained draft defects and their resolutions. No tamper, corruption or forgery scenario was run.")
    report_status = "COMPLETE_AFFIRMATIVE within the frozen finite-family target." if release else "Checkpoint: construction awaits independent reconstruction."
    write_markdown("final-report.md", f"""# Rigorous theory search report

## Frozen contract

For every prescribed finite L>=2, construct nonlinear adaptive cyclic formation at fixed c_*, with positive source-attention and hidden-conditional changes, exact normalized marked parents, actual-law activation, and vanishing conditional, complete-score and separate path errors on a common 1/epsilon horizon. The target remains unchanged in problem-contract.json, digest {META['target_digest']}.

## Terminal status

{report_status}

## Certificate

Target `target` depends on c1-c8 and assumptions A1-A5. Eleven written snapshots retain the current construction, its separate R1-R50 reconstruction, and scoped predecessor evidence. The combined theorem is proofs/nonlinear-adaptive-attention-completion.md. The quantifiers are every fixed finite L>=2 and all sufficiently small positive epsilon in the exhibited family; constants need not be uniform in L.

## Strongest verified result

{strongest} Posterior-row total variation exceeds 0.37; physical and optimizing hidden conditional KL exceeds 1/200. Actual recognition assignment masses are fixed. Conditional KL is O_L(epsilon^2), complete same-state score error O_L(T epsilon), and the full marked path has continuous error O_L(A epsilon^2) and exactly zero categorical error under the coupling.

## Dependency closure

The normalized experiment, relative curvature and exact marginal bounds, local coupled existence, actual weighted moments, inward model interval, formation, conditional entropy and complete scores are derived in that order. The moment estimate N16a-N16d needs only the candidate parameter interval, removing a circular use of the later speed bound. Static common-channel identities and dynamic path approximations remain distinct.

## Independent reconstruction

A separate nonauthor reconstructed c1-c8 and target from the frozen contract in R1-R50. The collapsed source-row proposal had a sustained marked-activation defect: actual and optimizing retained source kernels can differ. NAR-J1 repairs it by retaining static source assignments, the full joint VFE and categorical score, and exact actual joint initialization. The historical E1-E23 component check covers only its stated earlier scope.

## Oracle erasure

The reconstruction removes favorable expectations, author verdicts and predecessor conclusions as premises, then checks every dependency from the normalized model, finite flag, exact integrals and differential inequalities. The explicit modeling admissions remain. Agreement among agents and a matching fingerprint do not prove a claim.

## Unresolved obligations

None within the stated frozen target. Nonzero source-label mobility and adaptive recognition assignment masses require a new kinetic proof. Arbitrary nonlinear strength, learned creation of contrasts, arbitrary forcing and unbounded depth are outside this construction.

## Scope and limitations

Material admissions are supplied contrasts, calibration-assisted learning, the coherent-coordinate observation, a proper correlated prior, internal-neighbor source support, zero categorical mobility, small fixed standardized nonlinearity, and a parameter-dependent initial-law neighborhood in a shrinking amplitude/temperature regime. The changing attention row is a model posterior, not the actual recognition conditional used by the marginal force. All original loops remain dynamic. The two-level example has 6-to-2-to-1 agents and 19-to-9-to-8 continuous dimensions on 64 retained source sheets.

Mathematical evidence is the displayed derivation. No test total or trajectory experiment is claimed. No production/configuration edit, full suite, GPU job, heavy replay, Lean work or prohibited tamper check ran. Structural validation checks the record, not mathematical truth. The scalar-factor and collapsed continuous alternatives retain their limitations. Publication and the subsequent phase investigation are separate from this mathematical release.
""")
    write_json("document-bindings.json", {"proof_bindings": bindings, "scope": "Source/snapshot identity documents evidence provenance and is not a mathematical acceptance condition."})
    print(json.dumps({"claims": len(claims), "snapshots": len(bindings), "release": release}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", action="store_true", help="Record the separately reviewed terminal disposition.")
    main(parser.parse_args().release)
