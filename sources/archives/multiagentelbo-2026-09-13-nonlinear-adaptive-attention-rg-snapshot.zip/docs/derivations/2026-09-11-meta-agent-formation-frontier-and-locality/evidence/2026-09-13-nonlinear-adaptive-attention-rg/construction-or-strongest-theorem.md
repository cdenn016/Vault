<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a","target_digest":"3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a"} -->
# Nonlinear adaptive cyclic construction

For every finite L>=2, the admitted nonlinear cyclic family has L actual formation levels, order-one learned source-row and hidden-conditional changes, exact marked parents and vanishing conditional, score and independently learned path errors on 2/epsilon.

The exact statement, initial-law neighborhood, construction and hypothesis map are in proofs/nonlinear-adaptive-attention-completion.md. Component derivations are copied alongside it. This record distinguishes exact probabilities, conditional approximation and separate path approximation.
