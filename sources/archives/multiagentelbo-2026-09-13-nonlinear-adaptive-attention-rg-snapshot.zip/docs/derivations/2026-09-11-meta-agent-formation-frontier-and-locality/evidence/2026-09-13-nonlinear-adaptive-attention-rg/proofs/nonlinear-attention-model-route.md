# A normalized nonlinear source factor and a bounded-tilt discriminator

September 13, 2026. This lane owns only this document. It addresses the model component of [the nonlinear adaptive attention target](nonlinear-adaptive-attention-target.md), frozen as contract `3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a`. Route **NAR-S1** is an independent exact-factor construction. Lemma **BT-HC** is a separate bounded-likelihood result applicable to the endpoint-local route being developed in parallel.

The exact result is a proper nonlinear normalized experiment, a nonconstant source posterior with fixed positive variation during actual complete-model Fisher learning, distinct physical and optimizing hidden kernels, and one scalar and metric inherited by all exact parents. The construction has a limitation: its nonlinear source factor reads a common belief/model contrast. That contrast is orthogonal to the independent link sector and is eliminated at the first retention. Later unmarked configuration marginals are Gaussian, while their full conditional source/evaluator marks retain the nonlinear factor. This is an exactly tractable alternative, not a proof of the stronger endpoint-local nonlinear formation join or of the complete frozen target.

## 1. Source continuity and quantifiers

The source inspection used [STATUS](../../STATUS.md), the frozen target, [the adaptive normalized model](adaptive-normalized-model.md), [the adaptive cyclic witness](adaptive-cyclic-witness.md), [attention admission R1–R11](../../reviews/2026-09-13-program-review-next-phase/attention-admission.md), and [the conditional bridge D1–D26](../../reviews/2026-09-13-program-review-next-phase/dynamics-frontier-review.md). The live [PIFB2 manuscript](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:mixture_derivation`, `thm:belief_configuration_gibbs_lift`, and `eq:rg_reduced_hessian`, distinguishes a consensus ansatz, a normalized configuration lift, and the negative attention-gradient covariance. The live [staged hierarchy synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Staged hierarchy formation and RG composability.md>) records the separate Gaussian adaptive and nonlinear fixed-parameter results. [Theory/05b, lines 529–711](../../../Theory/05b_local_collective_elbo.tex:529) supplies the normalized source-label and posterior/recognition distinction; [Theory/07b, lines 1982–2142](../../../Theory/07b_agent_network_rg.tex:1982) requires joint event/occupancy/mark pushforward. Those distinctions are retained below.

The supplied target asks, for every finite integer L at least two, for one admitted cyclic family at fixed c_* with actual formation, learned hidden-conditional change, changing normalized source attention, exact marked parents, and vanishing dynamic errors. This model component proves the following conditional part of that request for every graph in the existing triangle-chain family. For sufficiently small positive temperature T and small but nonzero initial normal energy, and for every epsilon>0, the normalized model below has a unique coupled fine evolution through 2/epsilon, an invariant learned-parameter interval, parameter change greater than one half, a source-row total-variation change bounded below independently of epsilon and T, and exact parent scalar/score identities. It supplies global curvature bounds and a quantitative hidden-conditional discriminator. It does not assert formation merely from those bounds.

The introduced specializations are scalar translation fibers, the existing supplied triangle-chain contrast, a compatible observation, a proper correlated Gaussian reference, one calibration-assisted coefficient a, a fixed evaluator variance split, one binary source record, and product preparation between one common contrast and its orthogonal complement. The source record is allowed to read that common contrast. Endpoint-only source evaluation would be an additional restriction and is not proved by this route. No base path or base transport is introduced.

Exact equality means equality of the full normalized joint, its fixed-channel pushforwards, its conditional kernels, and its restricted variational scalar. An independently evolving parent's replacement of a projected fine process remains a separate dynamic approximation. In particular, the actual fine recognition law below is never replaced by its equilibrium.

## 2. A common contrast in the cyclic carrier

Use the triangle-chain graph of the adaptive witness: b=2^(L-1) triangles, n=3b vertices, E=4b-1 independent oriented translation links, and x=(u,v,alpha) in R^d with d=2n+E. Let d_i=u_i-v_i and r_e=(Du)_e-alpha_e. With J_1 at least all other positive edge strengths, write

\[
 H=J_1 b_d^T b_d+\sum_eJ_{\ell(e)}b_e^Tb_e,
 \quad K=\ker H,
 \quad R=\frac{b_d^Tb_d}{1-c},
 \quad 0<c<1.
 \tag{S1}
\]

The independent link columns and the v columns make all residual rows independent. Hence H is positive on K perpendicular. The graph has b independent loop sums, and every link coordinate remains an independent microscopic coordinate. Put

\[
 w=\frac{(\mathbf 1_n,-\mathbf 1_n,0_E)}{\sqrt{2n}},
 \quad \lambda=2J_1,
 \quad r_0=\frac2{1-c}.
 \tag{S2}
\]

Direct multiplication gives

\[
 \|w\|=1,\quad Hw=\lambda w,\quad Rw=r_0w,
 \quad P_Kw=0.
 \tag{S3}
\]

Indeed all edge incidence rows annihilate the constant u component, and b_d^Tb_dw=2w. The covector w lies in the span of the first-level model-bridge rows. Consequently every retention P_s, s at least one, from the adaptive witness annihilates w. The scalar xi=w^Tx is orthogonal to every loop-sum covector. Symmetry of H, R, and P_K makes their w/w-perpendicular blocks exactly diagonal.

These identities explain the tractability and its limit: the source nonlinearity will act on a real eliminated belief/model contrast, but it will not feed the link or loop coordinates directly.

Under a passive independent translation g_i at every node, u_i and v_i both gain g_i, and alpha_ij gains g_i-g_j. Every residual, xi, and loop sum is unchanged. The proper root reference, observation, and coordinates are pushed together; holding their numerical centers fixed would instead define an active displacement. This gives typed endpoint covariance at c_* without asserting a finite invariant Haar probability for the noncompact translation group. Inter-agent model alignment is absent, gamma=0, while model evaluation and learning remain active.

## 3. Full normalized experiment and selected record

Fix a nonzero heterogeneous z in K and 0<kappa<=1. The parameter domain is the open interval a in (1/2,5/2); the proved evolution stays in [1,21/10]. The contrasts, T, kappa, c, and z are fixed within any one experiment. Assume

\[
 T R\preceq H/4,
 \quad A_0(a)=aH+P_K-TR,
 \quad P_{0,a}=N(0,T A_0(a)^{-1}).
 \tag{S4}
\]

The displayed assumption holds if T<=J_1(1-c)/4. It implies A_0(a) is positive on the entire open parameter domain. In particular, for a in [1,21/10], A_0(a)>=aH/2+P_K. Its Lebesgue normalizer is

\[
 Z_0(a)=(2\pi T)^{d/2}\det A_0(a)^{-1/2}.
 \tag{S5}
\]

Use normalized Gaussian observations O|x~N(x,T kappa^(-1)I) and Y|a~N(a,T). At each node use the normalized model/evaluator kernels zeta_i|v_i~N(v_i,c) and k_i|zeta_i~N(zeta_i,1-c). These are exactly the evaluator data of the adaptive model.

Add one label J in {-1,+1}, independent under its fixed prior pi_J=1/2. The two labels name two declared source mechanisms. Let B in {0,1} be a binary interaction record with

\[
 s=\sqrt{\lambda/T}\xi,\quad h(s)=1-\cos s,
 \quad t(a,s)=a-1+\delta h(s),\quad
 p_j(a,s)=q_*\exp[jt(a,s)],
 \tag{S6}
\]

\[
 B\mid x,J=j,a\sim\operatorname{Bernoulli}(p_j(a,s)),
 \qquad q_*=1/16,\qquad \delta=1/100.
 \tag{S7}
\]

Since 0<=h<=2 and |t|<1.52 on the open parameter domain, 0<p_j<1 everywhere. Thus both records B=0 and B=1 have positive probability. The full model is

\[
 \begin{split}
 P_a(dx,dj,dB,dO,dY,d\zeta,dk)
 ={}&P_{0,a}(dx)\pi(dj)L_B(dB\mid x,j,a)
 L_O(dO\mid x)L_Y(dY\mid a)\\
 &\times\prod_i m_i(d\zeta_i\mid v_i)
 \operatorname{ev}_i(dk_i\mid\zeta_i).
 \end{split}
 \tag{S8}
\]

The base measure is Lebesgue measure on every continuous coordinate and counting measure on J and B. The support is the full product. The selected record is O=z, Y=2, B=1, using the positive smooth density versions of the Gaussian observations. No other factor reads J. All kernels, including their values away from the selected record, have been specified.

For fixed contrasts and positive T, the nonlinear factors and all their spatial derivatives are bounded by constants depending on T and lambda. Parameter derivatives are uniformly bounded on compact subintervals of the parameter domain except for the explicitly quadratic prior score. Gaussian tails dominate every required parameter derivative and finite-order spatial derivative. Thus normalizers are finite, smooth, and differentiable under their integrals. Uniform-in-contrast estimates below use relative curvature rather than those unscaled derivative bounds.

## 4. Recognition, its exact ELBO, and the two posterior kernels

Allow any positive correlated outer recognition density Q(dx)=q(x)dx with finite relative entropy to P_{0,a} and finite second moment. Conditionally on x, take independent node evaluator couplings

\[
 \zeta_i=v_i+\eta_i,\quad k_i=u_i+\eta_i+\nu_i,
 \quad \eta_i\sim N(0,c),\quad\nu_i\sim N(0,1-c).
 \tag{S9}
\]

The prescribed marginals are N(v_i,c) and N(u_i,1). Subtracting its log density from the physical model/evaluator joint leaves an affine function whose expectation is fixed by those marginals. For any competing coupling, subtracting the resulting constant from its KL leaves its KL to (S9). Hence (S9) is the unique minimizing coupling and

\[
 d^{\rm ev}(x)=\frac12x^TRx.
 \tag{S10}
\]

For the source label use its exact conditional posterior given x and the selected record:

\[
 \beta_j(a,s)=\frac{e^{jt(a,s)}}{2\cosh t(a,s)}.
 \tag{S11}
\]

This is conditional posterior attention; it is not a row required to be constant in x. Before minimization, for a conditional row b_j(x)>0, sum_j b_j=1, its contribution to the scaled VFE is the expectation

\[
 T E_Q\sum_j b_j(x)
 \left[\log\frac{b_j(x)}{\pi_j}-\log p_j(a,s)\right].
 \tag{S12}
\]

Lagrange multiplication on each source simplex gives
log(b_j/pi_j)+1-log p_j=constant; strict convexity on the simplex gives the unique interior minimizer (S11). The attained contribution is -T log q_*-T E_Q log cosh t. A general row has the additional term T E_Q KL(b(.|x)||beta(.|x)). A forced constant row would minimize expected source costs instead, and is a different family. There is one categorical entropy and one outer joint entropy, with no marginal-entropy double counting.

For the admitted family, the complete scaled restricted negative ELBO is

\[
 \begin{split}
 F_T(Q,a)={}&T E_Q\log\frac{q(x)}{p_{0,a}(x)}
 T E_Q d^{\rm ev}(x)
 T E_Q\sum_j\beta_j\log\frac{\beta_j}{\pi_jp_j}\\
 &-T E_Q\log L_O(z\mid x)-T\log L_Y(2\mid a).
 \end{split}
 \tag{S13}
\]

Every expectation is finite under the conditions above. Define f=kappa z, K_a=aH+P_K+kappa I and

\[
 \begin{split}
 U_a^{\rm opt}(x)&=\tfrac12x^TK_ax-f^Tx-T\log\cosh t(a,s),\\
 U_a^{\rm phys}(x)&=\tfrac12x^T(A_0(a)+\kappa I)x-f^Tx
                  -T\log\cosh t(a,s),\\
 Z_*(a)&=\int e^{-U_a^*(x)/T}dx,\qquad
 \pi_a(dx)=Z_{\rm opt}(a)^{-1}e^{-U_a^{\rm opt}(x)/T}dx.
 \end{split}
 \tag{S14}
\]

The second line gives the physical outer posterior; the first gives the optimizer of the restricted evaluator family. They differ by T d^ev. The physical prior reverse kernel comes from P_{0,a}; the physical posterior reverse kernel comes from the second line; the optimizing reverse kernel comes from pi_a. None is identified with the current Q reverse kernel.

Let c_O=(kappa/(2 pi T))^(d/2), c_Y=(2 pi T)^(-1/2). Direct integration of (S8) gives the selected evidence and the exact common scalar:

\[
 \begin{split}
 p_a(z,2,1)&=\frac{c_Oc_Yq_*}{Z_0(a)}
 e^{-[\kappa\|z\|^2+(a-2)^2]/(2T)}Z_{\rm phys}(a),\\
 C_T(a)&=T\log Z_0(a)-T\log(c_Oc_Yq_*)
 +\tfrac\kappa2\|z\|^2+\tfrac12(a-2)^2-T\log Z_{\rm opt}(a),\\
 F_T(Q,a)&=T\operatorname{KL}(Q\Vert\pi_a)+C_T(a),\\
 C_T(a)&=-T\log p_a(z,2,1)
          +T\log\frac{Z_{\rm phys}(a)}{Z_{\rm opt}(a)}.
 \end{split}
 \tag{S15}
\]

The last logarithm is nonnegative and is the evaluator-restriction gap. It is no longer purely a determinant ratio. Every term remains in parameter learning, including q_*, the evidence, the prior normalizer, and the nonlinear conditional partition. Constants independent of a still remain in the scalar even when their derivatives vanish.

## 5. Exact nonlinear factor and global curvature

Write x=xi w+x_perp. Equations (S3) and f in K give an exact product in both outer posterior families. On the optimizing scalar factor,

\[
 k_a^{\rm opt}(ds)
 =I(a,\rho)^{-1}e^{-(a+\rho)s^2/2}
       \cosh[a-1+\delta(1-\cos s)]ds,
 \quad\rho=\kappa/\lambda,
 \tag{S16}
\]

where I is the displayed positive integral. The physical scalar factor has rho=(kappa-Tr_0)/lambda. In x coordinates,

\[
 Z_*(a)=Z_{*,\perp}(a)\sqrt{T/\lambda}I(a,\rho_*),
 \tag{S17}
\]

and Z_{*,perp} is the exact Gaussian partition on w perpendicular, including f. These one-dimensional integrals are retained exactly; no Laplace or Gaussian substitution is made.

Put phi_a(s)=(a+rho)s^2/2-log cosh t. Direct differentiation gives

\[
 \begin{split}
 \phi_a'(s)&=(a+\rho)s-\delta\tanh t\sin s,\\
 \phi_a''(s)&=a+\rho-\delta\tanh t\cos s
                   -\delta^2\operatorname{sech}^2t\sin^2s,\\
 a+\rho-\delta-\delta^2&\le\phi_a''(s)\le a+\rho+\delta.
 \end{split}
 \tag{S18}
\]

The negative last term is precisely the source-gradient covariance correction. It has been included. Globally in x,

\[
 K_a-(\delta+\delta^2)\lambda ww^T
 \preceq\nabla^2U_a^{\rm opt}
 \preceq K_a+\delta\lambda ww^T.
 \tag{S19}
\]

Since lambda ww^T<=H, these bounds control curvature relative to H independently of its largest eigenvalue. The physical bound replaces K_a by A_0+kappa I. Both have strictly positive curvature throughout the admitted parameter interval. This proves global normal curvature for this model, including at source switching points. The coefficient delta=1/100 is fixed and nonzero as epsilon and T change. The nonlinear argument uses the declared thermal normal scale sqrt(T/lambda); the resulting standardized density (S16) retains its nonquadratic factor as T decreases. This scale dependence is an introduced part of the family, not a claim that a fixed spatial-frequency perturbation remains visible in a concentrating law.

The factor is nonquadratic for every a in [1,21/10]. If log cosh[a-1+delta(1-cos s)] were quadratic, its bounded periodicity would force it to be constant. Its values at s=0 and s=pi differ because cosh is strictly increasing on the nonnegative half-line and delta>0. Hence the continuous posterior and optimizer laws are genuinely non-Gaussian before this factor is eliminated.

## 6. Complete score, Fisher metric, and actual fine learning

Differentiate (S13) with the current outer Q held fixed. The conditional label family is optimized, so its explicit row derivative cancels by the simplex stationarity calculation. The complete covector is

\[
 g(a,Q)=a-2+\tfrac12E_Qx^THx
 -\tfrac T2\operatorname{tr}(A_0^{-1}H)
 -T E_Q\tanh t(a,s).
 \tag{S20}
\]

The prior-normalizer derivative and the source term cannot be discarded. The complete generative-experiment score is the sum of

\[
 S_0=\tfrac12\operatorname{tr}(A_0^{-1}H)
             -\frac{x^THx}{2T},\quad
 S_Y=\frac{Y-a}{T},\quad
 S_B=j\frac{B-p_j}{1-p_j}.
 \tag{S21}
\]

The label prior is fixed. The O and evaluator kernels have no explicit a derivative at fixed x. Each conditional observation score has conditional mean zero, so its covariance with S_0 and with the other observation score vanishes. Gaussian quadratic-form integration gives Var(S_0)=tr[(A_0^(-1)H)^2]/2. A direct two-point Bernoulli sum gives E[S_B^2|x,j]=p_j/(1-p_j). Therefore the full Fisher metric is exactly

\[
 M(a)=\frac1T+\frac12\operatorname{tr}[(A_0^{-1}H)^2]
 +E_{P_{0,a}\otimes\pi}\frac{p_J(a,s)}{1-p_J(a,s)}.
 \tag{S22}
\]

It is positive, finite, smooth, and includes the experiment's unobserved B=0 outcomes. Replacing its last term by the posterior categorical variance would give another metric. Let m(a)=T M(a). Declare the common microscopic coordinate mobility to be the identity and the parameter metric to be m(a)/epsilon for F_T. The actual coupled equations are

\[
 dX_t=-\nabla U_{a_t}^{\rm opt}(X_t)dt+\sqrt{2T}dW_t,
 \qquad \dot a_t=-\epsilon m(a_t)^{-1}g(a_t,Q_t),
 \quad Q_t=\mathcal L(X_t).
 \tag{S23}
\]

For any reparameterization a=a(theta) with nonzero derivative, the covector becomes g_theta=g_a da/dtheta and the metric becomes m_theta=m_a(da/dtheta)^2; the natural-gradient vector transforms accordingly. There is one parameter tangent direction, all real multiples of da in the open interval. No raw coordinate gradient is substituted.

The outer diffusion is a configuration-law dynamics, not a full-law Fisher replicator. Integration by parts against its Gaussian-tail density gives

\[
 \frac{dF_T}{dt}
 =-T^2E_{Q_t}|\nabla\log(q_t/\pi_{a_t})|^2
 -\epsilon m(a_t)^{-1}g(a_t,Q_t)^2.
 \tag{S24}
\]

For the smooth preparations below, the drift is globally Lipschitz for each fixed positive T and fixed finite contrasts, has uniform dissipative tails on the admitted interval, and has a bounded nonlinear perturbation of a linear drift. Parameter dependence is smooth on compact subintervals. For two candidate continuous parameter paths coupled with the same noise, the usual difference-square calculation bounds their state-law W2 distance by a finite constant times their parameter-path difference on a short interval. The quadratic expectation in g is locally Lipschitz in W2 under the resulting uniform second-moment bound, by Cauchy–Schwarz applied to x^THx-y^THy. The tanh expectation is Lipschitz as well. Integrating the parameter equation therefore gives a contraction for sufficiently short intervals. Repetition and the second-moment bounds continue this unique solution; the parameter first-exit argument below prevents escape from the compact interval. No compact-face current occurs.

For a concrete nonempty admission start a_0=1. On w perpendicular, use a Gaussian with mean mu_perp and covariance T(K_1|w_perp)^(-1). Independently, take xi=mu_w+eta, where eta is the even scalar law in (S16) at a=1, in xi coordinates. This density is positive and non-Gaussian. Require mu_0=mu_w w+mu_perp to have zero K component and

\[
 E_0=\mu_0^TH\mu_0\le1/20,
 \qquad T(p+1)\le1/100,
 \qquad p=\operatorname{rank}H.
 \tag{S25}
\]

Strict versions permit an open neighborhood of means and scalar preparation parameters inside this declared product family. This is not a claim of an arbitrary-density neighborhood for the full formation theorem.

The scalar drift is

\[
 d\xi_t=\left[-(a_t\lambda+\kappa)\xi_t
 +\delta\sqrt{T\lambda}\tanh t(a_t,s_t)\sin s_t\right]dt
 +\sqrt{2T}dW_t^w.
 \tag{S26}
\]

Since |sin s|<=|s|, its second moment obeys

\[
 \frac d{dt}E\xi_t^2
 \le-2[(a_t-\delta)\lambda+\kappa]E\xi_t^2+2T.
 \tag{S27}
\]

The initial nonlinear scalar tilt is between 1 and exp(2delta) relative to its unnormalized Gaussian factor. Its normalized second moment is at most exp(2delta)T/(lambda+kappa). Thus while a is in [1,21/10], scalar comparison yields lambda E xi_t^2<=lambda mu_w^2+2T. All other positive H-eigenmode variances have the Gaussian upper barrier T/(lambda_j+kappa), and their means contract. The K forcing contributes no H-energy. Hence

\[
 E_{Q_t}x^THx\le E_0+(p+1)T.
 \tag{S28}
\]

The prior bound gives tr(A_0^(-1)H)<=2p and tr[(A_0^(-1)H)^2]<=4p. The Bernoulli Fisher contribution in (S22) is at most one since p_j<1/2 on the domain. Consequently

\[
 |g-(a-2)|\le\tfrac12E_0+\tfrac32(p+1)T<1/10,
 \qquad1\le m(a)\le1+2Tp+T<11/10.
 \tag{S29}
\]

At a=1 the score is negative; at a=21/10 it is positive. This closes the first-exit argument and proves the bounds without assuming them. Also |a'|<=11epsilon/10. While a<=19/10,

\[
 \dot a\ge\frac{10\epsilon}{11}(19/10-a),\qquad
 a(t)\ge19/10-(9/10)e^{-10\epsilon t/11}.
 \tag{S30}
\]

The boundary at 19/10 cannot be crossed downward under this inequality. In particular a(2/epsilon)>3/2. All expectations in this proof use Q_t, not pi_a. Learning is not a prescribed schedule.

## 7. Fixed positive source change and hidden change

The posterior source row has beta_+(a,s)=sigmoid(2t(a,s)). At a=1 it is at most sigmoid(4delta), for every s. At any a>=3/2 it is at least sigmoid(1), for every s. Therefore, for any two probability laws R_0 and R_f on the scalar coordinate, including the two actual recognition marginals,

\[
 \operatorname{TV}\left(E_{R_0}\beta(1,s),
                         E_{R_f}\beta(a_f,s)\right)
 \ge\operatorname{sigmoid}(1)-\operatorname{sigmoid}(4\delta)>1/5.
 \tag{S31}
\]

For the last strict bound, e>8/3 gives sigmoid(1)>8/11, while sigmoid'(x)<=1/4 gives sigmoid(4delta)<=1/2+delta=51/100; their difference is greater than 1/5. This is a normalized recognition source marginal, obtained by averaging the actual conditional posterior row. It is not a softmax of averaged costs. Its law/force coupling is retained in (S20), (S22), and (S26). The same uniform separation holds pointwise at a common s. The initial source mechanisms are not identical as functions of s even though the row at s=0 is initially uniform.

A first hidden space has dimension k=rank B_1=5b. It contains w and k-1 other directions. Since w is a common eigenvector, its conditional is independent of both retained coordinates and the other hidden coordinates in each target law. On the other k-1 hidden coordinates, the optimizer is conditionally Gaussian with precision D_a=aF+kappa I. Choose kappa<=lambda_min(F), which is a nonempty fixed admission by the witness's row independence. For a_f>=3/2,

\[
 D_{a_f}\succeq(5/4)D_1.
 \tag{S32}
\]

The physical Gaussian complement has D_a^phys=aF+kappa I-TURU^T. It is positive by (S4), D_1^phys<=2F, and D_af^phys-D_1^phys>=(1/2)F, so it obeys the same inequality without a commutation assumption. Gaussian conditional KL, including its nonnegative mean term, then gives for every retained input y

\[
 \begin{split}
 \operatorname{KL}(\pi_1(\cdot\mid y)\Vert\pi_{a_f}(\cdot\mid y))
 &\ge\frac{k-1}{2}\left[\frac14-\log\frac54\right]>0,\\
 \operatorname{KL}(P_1^{\rm phys}(\cdot\mid y,z,2,1)
             \Vert P_{a_f}^{\rm phys}(\cdot\mid y,z,2,1))
 &\ge\frac{k-1}{2}\left[\frac14-\log\frac54\right]>0.
 \end{split}
 \tag{S33}
\]

The nonlinear scalar's KL is another nonnegative summand. Source labels can either be included as conditional marks, when the KL chain adds a nonnegative label term, or integrated in both target kernels. The bound is independent of T, epsilon, y, and the actual retained input law. It establishes changed hidden targets, not the small tracking error of the actual recognition conditional.

## 8. Parents inherit the complete scalar and metric

For any fixed nested retention C_s=P_s, let pi_a^s=(C_s)_#pi_a and r=(C_s)_#Q. Define the restricted parent objective with exactly the same scalar from (S15):

\[
 F_T^s(r,a)=T\operatorname{KL}(r\Vert\pi_a^s)+C_T(a).
 \tag{S34}
\]

Conditional disintegration of positive densities gives

\[
 F_T(Q,a)=F_T^s(r,a)
 +T E_r\operatorname{KL}(Q(\cdot\mid y)\Vert\pi_a(\cdot\mid y)).
 \tag{S35}
\]

All source/evaluator/cut-edge/loop marks are pushed with that same joint. A physical-parent experiment is instead the pushforward of (S8), with its physical evidence and physical reverse kernel. Its ordinary VFE is not relabeled as (S34).

For a convenient exact score formula define

\[
 A_a(x)=\tfrac12x^THx-T\tanh t(a,s),\qquad
 \bar A_a=E_{\pi_a}A_a.
 \tag{S36}
\]

Differentiation under the fixed retention integral gives

\[
 \partial_a\log\pi_a^s(y)
 =\frac{\bar A_a-E_{\pi_a}[A_a\mid y]}{T}.
 \tag{S37}
\]

Differentiating C_T, including all terms of (S15), cancels bar A_a and yields

\[
 g_s(a,r)=a-2-\tfrac T2\operatorname{tr}(A_0^{-1}H)
              +E_rE_{\pi_a}[A_a\mid y].
 \tag{S38}
\]

Every independently evolving parent uses its own current law r_t in (S38), its current parameter a_s, and the inherited m(a_s)=T M(a_s) from (S22):

\[
 \dot a_s=-\epsilon m(a_s)^{-1}g_s(a_s,r_t).
 \tag{S39}
\]

The new Fisher metric of the marginal experiment is not substituted. The instantaneous score defect at a common a and r is exactly

\[
 g(a,Q)-g_s(a,r)
 =E_QA_a-E_rE_{\pi_a}[A_a\mid y]
 =-T E_Q\partial_a\log\pi_a(\cdot\mid y).
 \tag{S40}
\]

For s>=1 the nonlinear coordinate is hidden and independent of y. Its contribution to (S38) is the exact scalar

\[
 T\left[\tfrac12E_{k_a^{\rm opt}}s^2-E_{k_a^{\rm opt}}\tanh t\right]
 =-T\partial_a\log I(a,\kappa/\lambda).
 \tag{S41}
\]

It survives every later retention. Omitting it because the unmarked parent state law is Gaussian would change learning. The corresponding nonlinear score defect is T times the difference between this expectation and its actual evolving scalar expectation. A quantitative estimate of that defect requires the scalar's actual conditional relaxation; normalization alone does not set it to zero.

On the retained state space use the projected identity metric, and the diffusion with invariant density pi_a^s. At activation its initial law is the preceding actual retained law. Because w is eliminated first, the later unmarked target is the Gaussian marginal of the w-perpendicular sector. The conditional source and evaluator law remains nonlinear in its marks. This factorization makes a possible dynamic completion economical, but it is an introduced restricted architecture.

For event accounting, take any fixed positive receiver occupancy alpha_i summing to one, assign (S11) to the declared source receiver, and use fixed positive rows at other receivers. Then eta_ij(x)=alpha_i beta_ij(x) is a normalized marked event law. Under deterministic membership its parent is the conditional expectation of the block-summed eta. If membership is a random mark M, use the single joint expectation

\[
 \eta^c_{IJ}(y)=E\left[\sum_{i,j}
 1_{\{i\in I(M),j\in J(M)\}}\eta_{ij}(X,M)\mid y\right].
 \tag{S42}
\]

Occupancy is its row sum and the source row is the ratio on positive occupancy. This is never replaced by a product of separate membership and event averages. Physical, optimizing, and actual recognition event laws use their respective conditional kernels. The tower property proves exact nested composition in each case. All original loop sums remain retained as in the cyclic witness.

## 9. BT-HC: hidden change under bounded likelihood tilts

This lemma is independent of the common-contrast restriction above and applies directly to endpoint-local source records.

**Lemma BT-HC.** Fix k>=1 and a retained input y. Let G_1^y and G_f^y be Gaussian probability laws on R^k with arbitrary means and covariances T D_1(y)^(-1), T D_f(y)^(-1), where both precisions are positive and

\[
 D_f(y)\succeq r D_1(y),\qquad r>1.
 \tag{B1}
\]

Let P_i^y have density proportional to exp[-V_i(u,y)/T] with respect to G_i^y, i in {1,f}. Suppose |V_i(u,y)|<=BT uniformly in u,y. Then, in either KL direction,

\[
 \operatorname{KL}(P_1^y\Vert P_f^y)
 \ge k\log\frac{1+r}{2\sqrt r}-4B.
 \tag{B2}
\]

If instead 0<=V_i<=BT, replace 4B by 2B. More generally replace 4B by osc(V_1/T)+osc(V_f/T). A negative right side merely gives a vacuous bound; the KL remains nonnegative.

**Proof.** Write the Hellinger affinity as A(P,Q)=integral sqrt(pq). Under an invertible affine whitening of G_1, the second precision has eigenvalues rho_j>=r. Completing the Gaussian square gives

\[
 A(G_1^y,G_f^y)
 =\prod_{j=1}^k\left(\frac{2\sqrt{\rho_j}}{1+\rho_j}\right)^{1/2}
 e^{-\frac18(m_1-m_f)^T[(\Sigma_1+\Sigma_f)/2]^{-1}(m_1-m_f)}.
 \tag{B3}
\]

The mean factor is at most one. The derivative of the logarithm of each product factor is (1-rho)/(4rho(1+rho)), so the factor decreases for rho>=1. Put q_r=[2sqrt(r)/(1+r)]^(1/2); then A(G_1,G_f)<=q_r^k.

Let omega_i=osc(V_i/T). Normalization of the bounded tilt implies dP_i/dG_i<=exp(omega_i). Therefore

\[
 A(P_1^y,P_f^y)
 \le e^{(\omega_1+\omega_f)/2}A(G_1^y,G_f^y)
 \le e^{(\omega_1+\omega_f)/2}q_r^k.
 \tag{B4}
\]

Jensen's inequality under P_1 gives

\[
 -\tfrac12\operatorname{KL}(P_1\Vert P_f)
 =E_{P_1}\log\sqrt{p_f/p_1}
 \le\log A(P_1,P_f).
 \tag{B5}
\]

The means are finite and the tilt is bounded, so this use is integrable. Combining (B3)–(B5) proves (B2), and symmetry of affinity proves the same bound for the reverse KL. No commutation or equality of conditional means was used.

The Hellinger triangle alternative is also explicit. With H(P,Q)=[1-A(P,Q)]^(1/2), density-ratio bounds give

\[
 H(P_i,G_i)\le\frac{e^{\omega_i/2}-1}{\sqrt2},
 \quad
 H(P_1,P_f)\ge
 \left[\sqrt{1-q_r^k}
 -\frac{e^{\omega_1/2}+e^{\omega_f/2}-2}{\sqrt2}\right]_+.
 \tag{B6}
\]

Then KL>=2H^2, by (B5) and -log(1-u)>=u. The direct affinity bound (B2) gives a simpler positive threshold for the present application.

For r=5/4,

\[
 \log\frac{1+r}{2\sqrt r}=\frac12\log\frac{81}{80}.
 \tag{B7}
\]

Taking B=1/10000 and k>=1 gives the exact rational lower estimate

\[
 \operatorname{KL}(P_1^y\Vert P_f^y)
 \ge\frac{k}{2}\log\frac{81}{80}-\frac1{2500}
 \ge\frac1{162}-\frac1{2500}>\frac1{200}.
 \tag{B8}
\]

The middle inequality uses log(1+x)>=x/(1+x) for x>=0, obtained by differentiating their difference. Thus no decimal approximation is needed for this positive amount. Under 0<=V_i<=BT the bound is stronger.

To apply the lemma to the endpoint-local nonlinear source construction, its marginalized likelihood multiplier is exp(-Phi_a(x)) with 0<=Phi_a<=B. For every fixed hidden/retained split, the physical and optimizing conditional densities are the corresponding Gaussian conditional densities tilted by the same bounded Phi, with their separate conditional normalizers. For the optimizer baseline D_a=aF+kappa I, and for the physical baseline D_a^phys=aF+kappa I-TURU^T. If kappa I<=F and both physical endpoints are positive, then

\[
 D_1^*\preceq2F,\qquad
 D_f^*-D_1^*=(a_f-1)F\succeq F/2,
 \qquad D_f^*\succeq(5/4)D_1^*,
 \tag{B9}
\]

for a_f>=3/2 and either star. This proves the hypotheses in precisely the two distinct families. The prior evaluator adjustment is not silently omitted, and no matrix commutation is needed. If the nonlinear likelihood is a product of N_att terms each with exponent in [0,delta_L], choosing delta_L=B/N_att gives B independently of epsilon, T, and contrast. For every prescribed finite L, this is a fixed strictly positive nonlinear coefficient; its possible dependence on L is explicit.

The later endpoint-local variant observes only the K component: O|x is a Gaussian law on K with mean P_Kx and variance T/kappa, at record z in K. Its normal optimizer precision is aF, and its physical normal precision is aF-TURU^T. In that variant replace the normal kappa I above by zero. Then D_1^*<=F and D_f^*>=3D_1^*/2; (B8) still applies with the conservative r=5/4 and can be sharpened by using r=3/2. The observation-density constants change with dim K and remain in that model's evidence scalar; they have no effect on this conditional affinity proof.

Finally, because (B8) is uniform in y, for any actual retained input probability law R,

\[
 E_R\operatorname{KL}(P_1^y\Vert P_f^y)>1/200.
 \tag{B10}
\]

No equilibrium or common endpoint input distribution is required. This compares the two target hidden kernels at the same input y and then integrates against any chosen actual input law. It does not compare two actual conditional recognition laws, nor prove that their tracking error is small. Additional retained source labels require applying the KL chain to the full marked conditional; they must not be silently discarded from an asserted marked-law equality.

## 10. Scope, failure tests, and remaining obligations

NAR-S1 passes a concrete normalization, complete-score, complete-Fisher, nonlinearity, positive-curvature, source-variation, and changed-hidden-target test. Its fine recognition law evolves by (S23), and the a-change proof uses its actual moments. Its parents inherit the same C_T and m and evaluate the complete inherited score under their own actual law. The parameter update remains different from one based only on the marginal observed-model Fisher matrix.

The route fails an endpoint-local source test: its nonlinear source likelihood reads the common contrast w^Tx. It also fails any strengthened requirement that every unmarked parent configuration density remain nonlinear after the first retention. Those conditions are not erased by retaining nonlinear conditional marks. This is why the endpoint-local construction remains a distinct route rather than being declared proved here.

For this exact-factor route itself, the minimal unproved dynamic obligations are an actual nonlinear-scalar conditional-lag bound through 2/epsilon, its complete score contribution in (S40), and a joined formation/path proof from an admitted initial-law neighborhood. The Gaussian orthogonal complement and the exact factorization simplify those obligations but do not discharge them by declaration. No application of D1–D26 is claimed without checking its model dependence: this source likelihood has additional non-affine a dependence after label integration. Its bounded derivative must be retained separately, as (S20) does.

BT-HC closes a narrower obligation for any bounded-likelihood route: once a_f>=3/2 and the displayed baseline precision comparison hold, a fixed sufficiently small nonzero nonlinear coefficient preserves a uniform positive hidden-conditional change in both the physical and optimizing families. If either the oscillation bound, positive physical precision, or common-input comparison fails, (B8) is not licensed. The next action that materially changes the full answer is to join this discriminator to the endpoint-local route's actual own-law parameter movement and its independent conditional/path bounds.

Only source reads and the written analytical calculations above were performed. No numerical experiment, simulation, symbolic-software run, test suite, GPU calculation, Lean work, tamper check, old-science rerun, production/configuration edit, vault edit, or Git action was performed. This document is the only file written by this lane; shared status and the daily change log belong to the parent.
