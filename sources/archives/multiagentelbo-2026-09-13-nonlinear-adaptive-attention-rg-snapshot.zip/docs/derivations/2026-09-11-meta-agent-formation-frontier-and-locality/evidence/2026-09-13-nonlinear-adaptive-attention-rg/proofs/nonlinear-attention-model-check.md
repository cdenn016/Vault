# Independent reconstruction of the endpoint-attention model

September 13, 2026. This is a bounded independent check of E1–E23 in [nonlinear-endpoint-attention-model.md](nonlinear-endpoint-attention-model.md), not a completion of the full formation target. The normalized model, conditional source envelope, physical and optimizing constants, complete generative Fisher metric, global curvature bounds, hidden nonlinearity, and conditional change discriminators reconstruct under the hypotheses below. The actual parameter excursion, successive formation, parent feedback, and common-regime error bounds remain separate obligations.

Coordinator scope note: this component check records the E1–E23 source snapshot before the full marked kinetic extension E24–E29 was added. Its source digest below identifies that earlier snapshot. The final [complete reconstruction](nonlinear-adaptive-attention-reconstruction.md) checks the current source, the explicit retained-source kinetics, and all remaining interfaces. This component is retained for its stated model calculations, not presented as a current full-target certificate.

## 1. Target and evidence boundary

The frozen contract is [problem-contract.json](evidence/2026-09-13-nonlinear-adaptive-attention-rg/problem-contract.json), target digest `3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a`. Its quantifiers require, for every fixed finite L>=2, an admitted nonlinear cyclic family and initial-law neighborhood with L successive formation levels, exact marked parents, and quantitative conditional, score and path errors vanishing in one regime. Nonlinear coefficients must stay nonzero, and an actual learned parameter must produce positive hidden-conditional and source-row change on the common interval. It is an existence statement in a declared family, not a universal assertion about every normalized cyclic model.

The present component introduces the triangle/bridge graph, scalar translation coordinates, positive supplied strengths, the evaluator split 0<c<1, a proper correlated Gaussian prior, K-only compatible observation, normalized binary source-success observations, a single learned generative parameter, and the specific configuration diffusion/model metric. The user permits these specializations but does not supply their conclusions. The base remains fixed at c_*. Exact equivalence here means equality of normalized laws and fixed-channel pushforwards; it does not mean equality of fine projected paths and autonomous parent paths.

The reconstructed domain is finite L, fixed T>0 and positive strengths J_1>=...>=J_L=1, a in [1,2.1], T<=J_1(1-c)/2, kappa>0, B0=1/10000 and delta=B0/n. At a fixed finite parameter choice, all derivatives below are on the specified Euclidean carriers. Higher derivative bounds need not be uniform as T goes to zero unless separately proved. Recognition statements requiring entropy differentiation retain smoothness, finite entropy and moments, and vanishing integration-by-parts boundary terms. Those analytic hypotheses are not supplied merely by the word “normalized.”

The checker read the frozen contract and target note, the complete E1–E23 model, the predecessor M1–M16 and W1–W7 geometry, the current Theory/05b source-label formulas, and the live PIFB2 reduced-Hessian passage. The bounded-affinity lemma in Section 9 of [nonlinear-attention-model-route.md](nonlinear-attention-model-route.md) was reconstructed separately below. Current parallel formation and conditional-dynamics drafts were not used to close this component. The earlier program review is shared source continuity, not independent evidence for the new construction.

The contract's target digest was reproduced using canonical JSON of its `target` field with sorted keys, compact separators and UTF-8. Its file hash is different because the file includes schema and digest fields. Source bytes used for this check are recorded at the end. These identifiers bind the statements; they are not the proofs.

## 2. Normalized source experiment and restricted evaluator

For an oriented internal edge, write b_ij x=r_ij and s_ij=sqrt(J1/T)r_ij. Since the two compared scalar Gaussian beliefs have covariance one,

\[
 \operatorname{KL}(N(u_i,1)\Vert N(u_j+\alpha_{ij},1))=r_{ij}^2/2,
 \qquad s_{ij}^2/2=(J_1/T)\operatorname{KL}.
 \tag{C1}
\]

The record energy delta f(s), with f(s)=1-exp(-s^2/2), is a bounded declared function of that mismatch. It is not itself the Gaussian KL. Every source set has two actual within-triangle neighbors; no recognition density occurs in its definition. The changing positive source prior is an ordinary generative categorical law at fixed a.

In the checked final E3, q0=1/2 and the success probability is q0 exp(-delta f). Consequently success lies between q0 exp(-delta) and q0, and failure lies between 1-q0 and 1-q0 exp(-delta). Both outcomes are strictly positive for every x,j, including zero residual. Their sum is one. Thus the full discrete/continuous experiment has neither an undefined failure score nor an unnormalized omitted outcome. Its success-slice negative log includes the constant -log q0.

For completeness, the evaluator restriction used in E5 is also an exact coupling calculation. The physical node joint is zeta=v+xi, k=zeta+epsilon, with independent xi~N(0,c), epsilon~N(0,1-c). The permitted optimizing coupling replaces k by u+xi+epsilon while preserving the prescribed N(u,1) and N(v,c) marginals. Its log density ratio to the physical joint is affine in k-zeta plus a constant. Its expectation is (u-v)^2/[2(1-c)]. For any other coupling with the same marginals, subtracting this log-ratio identity from its physical KL leaves its KL to the displayed coupling. This is nonnegative, proving the optimizing coupling and value M2–M3. No product approximation of the two prescribed marginals was made.

Because H contains J1 b_d^T b_d, the stated T admission gives TR<=H/2. R and H both annihilate K. Therefore A0=aH+P_K-TR >=(a/2)H+P_K is SPD on the full carrier. The Gaussian prior has the finite normalizer Z0=(2 pi T)^(d/2)det(A0)^(-1/2). The kernel O|x is a Gaussian probability on K, with dimension n from W5, mean P_Kx and covariance T/kappa. Its reference volume is the n-dimensional Euclidean volume on K. Calling it a full-space Lebesgue density would be incorrect; the model explicitly uses the correct smaller observation carrier. The calibration Gaussian and all evaluator kernels are normalized. Sequential integration of these kernels proves E5 is a normalized joint.

At fixed x and the all-success record, label exclusivity holds: each label J_i is read only by its own source observation. The posterior row is therefore E6. More explicitly, for any conditional recognition row b_i, its contribution is

\[
 \sum_j b_{ij}\log\frac{b_{ij}}{\pi_{ij}}+
       \delta\sum_j b_{ij}f(s_{ij})-\log q_0
 =\operatorname{KL}(b_i\Vert\beta_i)+\Phi_i-\log q_0.
 \tag{C2}
\]

This proves both the pointwise conditional optimizer and E8 after integration under any admitted correlated outer law Q. Arbitrary conditional dependence between label rows adds KL to their product posterior; it cannot improve C2. A constant-in-x recognition row would solve another restricted problem and is not used here. This matches the hypotheses of Theory/05b `eq:obs-attention-posterior`, including its off-record normalization requirement, rather than substituting an ansatz depending on live peer recognition laws.

## 3. Physical evidence, optimizing target and complete constants

Summing all source labels on the selected success record multiplies the physical outer density by q0^n exp(-Phi_a). Each row sum in Phi lies in [exp(-delta),1], so 0<=Phi<=n delta=B0. Integrating the normalized evaluator kernels removes them from physical evidence. Adding their restricted recognition cost cancels -TR in the optimizing quadratic only. The resulting precisions are exactly

\[
 K_a^{\rm phys}=aH+(1+\kappa)P_K-TR,
 \qquad K_a=aH+(1+\kappa)P_K.
 \tag{C3}
\]

The linear source is f0=kappa z in K. Expanding kappa|P_Kx-z|^2/2 gives the constant kappa|z|^2/2 and the quadratic/linear terms in C3. Calibration contributes (a-2)^2/2. Thus direct integration gives the evidence and scalar C_T in E10, with c_O=(kappa/(2 pi T))^(n/2), c_Y=(2 pi T)^(-1/2), and the factor q0^n explicitly retained. The q0 term contributes -nT log q0 to F_T and C_T, but no a derivative.

The bounds exp(-B0)Z_G<=Z_Phi<=Z_G prove finiteness and positivity. On compact admitted a intervals, derivatives are bounded by finite Gaussian moments times bounded derivatives of the categorical row, so differentiating the displayed normalization integrals is justified. The physical-versus-optimizing gap is

\[
 C_T(a)+T\log p_a(z,2,\mathbf1)
 =T\log\frac{Z_\Phi(K_a^{\rm phys},f_0,a)}{Z_\Phi(K_a,f_0,a)}\ge0.
 \tag{C4}
\]

Its sign follows also directly from K_a^phys=K_a-TR. It is not generally the old Gaussian determinant ratio. The complete integral ratio is required once Phi is present. Conditional source rows agree in the two targets, while their outer and hidden physical/evaluator laws need not agree.

Both quadratic targets split K orthogonally from its complement, and every residual is invariant under addition of K. Hence Phi has no K dependence. The optimizing target on K is the same independent Gaussian for every a. The K drift is -(1+kappa)P_Kx+kappa z and its noise is the projected Brownian motion. Its marginal dynamics is autonomous; identifying its paths across parent comparisons additionally chooses the shared projected noise and actual carried initial coordinate. This does not imply autonomy of the other retained coordinates.

## 4. Curvature, force and hidden nonlinearity

For g_j=delta f(s_ij), finite-sum differentiation of -log sum_j pi_ij exp(-g_j) gives its mean Hessian minus its gradient covariance. This reconstructs E11 with its minus sign, rather than assuming a frozen row. Here f'(s)=s exp(-s^2/2) and f''(s)=(1-s^2)exp(-s^2/2). Their absolute values are at most one. In particular the negative part of f'' attains magnitude 2exp(-3/2)<1, while its positive maximum is one.

For any v,

\[
 T|D^2g_j[v,v]|\le\delta J_1(b_{ij}v)^2,
 \qquad T(dg_j[v])^2\le\delta^2J_1(b_{ij}v)^2.
 \tag{C5}
\]

Using Var<=E square proves E12. Each undirected internal edge appears in only two receiver rows, with each beta<=1. Since H contains J1 times the sum of these undirected residual squares, summation proves E13. The full optimizing Hessian is consequently bounded by

\[
 (a-2\delta-2\delta^2)H+(1+\kappa)P_K
 \preceq D^2U_a
 \preceq(a+2\delta)H+(1+\kappa)P_K.
 \tag{C6}
\]

The lower bound is positive definite under the stated delta and a admission. The same calculation for the physical potential subtracts TR and leaves the positive lower coefficient a-1/2-2delta-2delta^2 on H. These are global fixed-parameter curvature bounds. They do not require an unproved near-coherence tube, but neither do they by themselves imply a multiscale formation history.

The force is R_a=delta sqrt(TJ1)sum_ij beta_ij f'(s_ij)b_ij^T. It annihilates K. Weighted Cauchy–Schwarz uses sum_ij beta_ij=n and at most two occurrences of each undirected edge to give

\[
 |R_a\cdot v|\le\delta\sqrt{2nT}\sqrt{v^THv},
 \qquad |H^{\dagger/2}R_a|\le\delta\sqrt{2nT}.
 \tag{C7}
\]

The second inequality is duality on range H. This explicitly supplies one permissible constant C_L=sqrt(2n) for E14. It is independent of T and the magnitudes of the descending strengths. It would not automatically remain valid in a changed model that reads additional differently scaled residual combinations.

The flag dependence follows from W3–W6, rather than from a locality slogan. Internal residuals decompose into Q_triangle r and their holonomy sum. The internal contrast rows belong to B1, so they annihilate W1 and every later flag layer. Holonomy lies in H_h and is retained. Thus Phi depends on the first contrast block and retained holonomies, while being independent of future normal flag coordinates and K. It can still couple that first block to retained holonomies; retaining the latter is essential.

For a straight line through zero with s_ij(h)^2=A_j h^2, A_j>=0, Taylor expansion gives

\[
 e^{-\delta f(s_j(h))}
 =1-\frac\delta2A_jh^2+\frac{\delta+\delta^2}{8}A_j^2h^4+O(h^6).
 \tag{C8}
\]

Taking the weighted sum and then its negative logarithm gives exactly E15. The quartic coefficient is minus [delta E_pi A_j^2+delta^2 Var_pi(A_j)]/8. The first hidden space contains a direction with nonzero internal contrast residual: B1 has independent nonzero internal contrast rows. All source priors are positive, so at least one row has E_pi A_j^2>0 in such a direction. All remaining row quartic coefficients are nonpositive and cannot cancel it.

At zero retained coordinates, conditional normalization is constant in the hidden direction. The quadratic Gaussian part has zero fourth derivative, while -Phi has a nonzero fourth derivative. This proves that both optimizing and physical hidden conditional log densities are nonquadratic in the stated physical linear coordinates. Rescaling that direction by sqrt(T/J1) fixes its dimensionless slopes A_j, so the delta-dependent quartic coefficient remains nonzero in thermal coordinates when T and contrasts vary. This is the precise fixed nonlinearity assertion. It does not assert invariance under arbitrary nonlinear coordinate reparameterizations or non-Gaussianity of every possible marginal.

## 5. Complete covector, Fisher metric and dissipation

For the single changing categorical row, let t_+=4 and t_-=0. Then partial_a log pi_j=t_j-E_pi t, so differentiation of its finite likelihood sum gives

\[
 \partial_a\Phi=-(E_\beta t-E_\pi t),\qquad |\partial_a\Phi|\le4.
 \tag{C9}
\]

The other rows contribute zero a derivative. The source posterior's own derivative does not add another force: C2 is minimized pointwise and its row entropy cancels that derivative. Holding the actual outer Q fixed, direct differentiation of E8 now gives E17, including the prior-normalizer term -T tr(A0^(-1)H)/2. The K observation has no explicit a score at fixed x; the changed q0 constant has none either.

For the full unconditioned normalized experiment, its a score is the sum of

\[
 S_0=\frac12\operatorname{tr}(A_0^{-1}H)-\frac{x^THx}{2T},
 \quad S_Y=(Y-a)/T,
 \quad S_J=t_{J_{i_0}}-E_\pi t.
 \tag{C10}
\]

Every conditional success/failure kernel is a-independent at fixed x,j. The O and evaluator kernels are also a-independent at their fixed conditioning variables. Thus none supplies another score. Under the full generative law before success conditioning, x, Y and the categorical draws are independent at fixed a, and each displayed score has zero mean. Their cross products therefore average to zero. The Gaussian quadratic-form identity gives Var(S0)=tr[(A0^(-1)H)^2]/2, Var(SY)=1/T and Var(SJ)=Var_pi t. This proves E18 with all factors. For the active row Var_pi t=16 pi_+(1-pi_+), not its posterior variance and not the Fisher information of the success-conditioned marginal experiment.

The declared model metric is m(a)/epsilon with m=T M; using that metric for the scaled objective is an explicit kinetic choice inherited from the predecessor. The covector/metric transformation under a smooth scalar reparameterization preserves the natural-gradient velocity. The configuration drift is the Euclidean gradient of U_a for the declared unit configuration mobility. Given sufficient decay, the Fokker–Planck equation is partial_t q=T div(q grad log(q/pi_a)). Multiplication by T log(q/pi_a) and integration by parts produces -T^2 E_q|grad log(q/pi_a)|^2. The a term is g a'=-epsilon m^(-1)g^2. This reconstructs E20 for the actual law of E19, without a Gaussian-closure assumption.

C6 gives a globally Lipschitz, linearly growing configuration drift for every fixed finite T and graph on a compact a interval. This supplies the fixed-parameter diffusion estimates, but continuation of the coupled law/parameter equation through the claimed 1/epsilon horizon still needs actual moment control and an inward parameter bound. E19–E20 do not alone prove that a reaches 1.5, remains in the admitted interval, or that independently evolving parents do so. Those statements remain outside this check.

## 6. Exact parent accounting and positive row change

The nested P_s are fixed orthogonal retentions from W7 and preserve K and all holonomies. Apply each to the physical joint and its posterior, to the optimizing outer law, and to the actual recognition separately. For the restricted optimizer, the density chain q(x)=q_s(y)q(x|y), pi_a(x)=pi_a^s(y)pi_a(x|y) gives

\[
 F_T(Q,a)=T\operatorname{KL}(Q_s\Vert\pi_a^s)+C_T(a)
 +T E_{Q_s}\operatorname{KL}(Q(\cdot\mid y)\Vert\pi_a(\cdot\mid y)).
 \tag{C11}
\]

This proves E21 and its same-time composition. Finite KL is needed for ordinary differences, although the additive chain itself has an extended nonnegative formulation. Its common C_T survives every retention. The physical-parent objective has the physical target and evidence of E10; C11 is not a replacement for that different objective.

The final model also declares normalized receiver occupancy alpha_i=1/n. Drawing I with that law and returning (I,J_I) is one normalized readout channel of the full labeled state. Under recognition its measure is Q(dx)alpha_i beta_ij(x,a), of total mass one. Joint event and membership averages must be taken together through subsequent structural kernels. No product of separately averaged random event and assignment quantities is used.

For hidden-condition comparisons before marginalization, the weighting factor relative to the Gaussian reference is exp(-Phi) in [exp(-B0),1]. After previous coordinates are integrated, the weighting factor is the Gaussian conditional expectation of exp(-Phi) on the smaller carrier. It remains in the same interval. Dividing either factor by its conditional normalizer gives a density ratio in [exp(-B0),exp(B0)] uniformly in the retained input. This preserves the exact nonlinear integrals and does not identify their values with Gaussian recognition.

At a=1, beta_+<=sigmoid(-2+delta) pointwise. At a_f>=1.5, beta_+>=sigmoid(-delta) pointwise. These two inequalities apply under any actual outer laws, even different laws at the two times. Since sigmoid'<=1/4 and e^2>7,

\[
 E\beta_+(a_f)-E\beta_+(1)
 >\frac38-\frac\delta2>\frac{37}{100}.
 \tag{C12}
\]

For the strict exponential inequality, the terms of exp(2)'s series through order four sum exactly to seven and later terms are positive. Thus C12 needs no floating-point comparison. For a binary row its total variation is the absolute difference of the positive-coordinate probabilities, so this proves E22's stated constant. Its hypothesis remains the actual parameter excursion. The row changes because a generative prior is learned; its bounded x dependence and feedback force remain in the model. It is not a separately scheduled row.

## 7. Independent bounded-tilt hidden-change proof

Fix a nonempty hidden linear space of dimension k, the same retained input y at both parameter values, and the corresponding Gaussian conditional references G1,Gf. Suppose their precisions satisfy Df>=rD1 for r>1. Whitening by D1 and diagonalizing the relative SPD matrix produces eigenvalues rho_j>=r. Completing the Gaussian square gives their affinity

\[
 A(G_1,G_f)=\prod_{j=1}^k
 \left(\frac{2\sqrt{\rho_j}}{1+\rho_j}\right)^{1/2}
 \exp\left[-\frac18(m_1-m_f)^T
       \left(\frac{\Sigma_1+\Sigma_f}{2}\right)^{-1}(m_1-m_f)\right].
 \tag{C13}
\]

The mean factor is at most one. The log derivative of the displayed eigenvalue factor is (1-rho)/[4rho(1+rho)], so its maximum on [r,infinity) is at r. Therefore A(G1,Gf)<=[2sqrt(r)/(1+r)]^(k/2). Neither equal means nor commuting original precisions are required.

Let P1,Pf be the corresponding target conditionals. Their weights relative to their respective Gaussian laws have oscillation at most B0, whether they are fine conditional weights or the conditional expectations obtained after prior marginalization. Thus dPi/dGi<=exp(B0), and

\[
 A(P_1,P_f)\le e^{B_0}A(G_1,G_f),\qquad
 \operatorname{KL}(P_1\Vert P_f)\ge-2\log A(P_1,P_f).
 \tag{C14}
\]

The second statement follows from Jensen under P1 applied to log sqrt(pf/p1). Log-ratio integrability follows from Gaussian quadratic logs and bounded weights. The argument is symmetric in the affinity and supplies the same lower bound for reverse KL. It reconstructs the stronger one-sided-bounded version of Section 9's BT-HC lemma; general weights of oscillations omega_1 and omega_f replace 2B0 below by omega_1+omega_f.

In the K-only observation construction, for a hidden orthonormal coordinate map U contained in K perpendicular, write F=UHU^T>0. Before previous marginalizations the optimizing hidden precision is aF. The physical hidden precision is aF-TURU^T. Positivity follows from TR<=H/2. At a1=1 and a_f>=1.5,

\[
 D_1^{\rm phys}\preceq F,
 \quad D_f^{\rm phys}-D_1^{\rm phys}=(a_f-1)F\succeq F/2,
 \quad D_f^{\rm phys}\succeq(3/2)D_1^{\rm phys}.
 \tag{C15}
\]

The optimizing comparison is immediate. For later normal parent coordinates, the same order survives Schur marginalization: v^T Schur(A)v is the minimum of the corresponding full quadratic over eliminated coordinates, so A_f>=r A_1 implies Schur(A_f)>=r Schur(A_1). Restriction to the next hidden block preserves that order. K itself is retained and decoupled; its unchanged precision is not included in the positive hidden-order claim. Conditional means may vary in the physical family, which only decreases the affinity in C13.

Using the weaker r=5/4 in C13–C15 gives exactly

\[
 \operatorname{KL}(P_1^y\Vert P_f^y)
 \ge\frac{k}{2}\log\frac{81}{80}-2B_0>\frac1{200}.
 \tag{C16}
\]

To verify the final strict numerical threshold analytically, log(1+x)>=x/(1+x) implies the right side is at least 1/162-1/5000. Its difference from 1/200 is 197/202500>0. This holds for k>=1 and B0=1/10000. Section 9's more conservative subtractive 4B0 bound also exceeds 1/200, but E23 correctly uses the stronger 2B0 appropriate to its nonnegative Phi.

C16 is uniform in y, and therefore can be averaged against any actual retained-input law. It compares the two target hidden kernels at the same retained input. It does not compare actual recognition conditionals or establish that either actual conditional tracks its target. If source or evaluator labels are included among hidden marks, the KL chain gives at least the marginal hidden-configuration KL proved here. The full marked law must still be retained for any claim of exact marked-law equality.

## 8. Conclusion, attacks and remaining obligations

The normalization, exact constants, score, metric and E11–E18 calculations reconstruct for the final model. The q0 factor ensures strict positivity of both record outcomes and is present in both physical evidence and the restricted scalar. The full generative Fisher uses unconditioned source draws, not posterior attention. The curvature covariance is retained and controlled globally in the actual H norm. Nonlinearity is present in an eliminated conditional with a fixed nonzero standardized quartic coefficient. E22 and E23 have the advertised strict constants once a genuinely moves from one to at least 1.5.

The attempted attacks identify scope boundaries rather than a remaining algebraic defect in this component. A full-space density for O would be inadmissible, but O is explicitly K-valued. Treating source rows as independent of x in recognition, discarding q0's evidence factor, dropping the prior normalizer from g, or replacing generative Fisher by posterior categorical variance would change the model; the checked version does none of these. Treating a previously marginalized tilt as the original Phi would use a function on the wrong carrier; the checked version instead retains its conditional expectation. Positivity of the E13 Hessian does not establish actual merger times, and the conditional change bounds do not establish a parameter excursion. These implications are not claimed as proved here.

The minimal unresolved interface is actual-law continuation on the admitted parameter interval with an excursion to a>=1.5 in the intended common regime. Beyond that, the complete target still needs actual sequential formation, conditional relaxation with retained holonomy coupling, stagewise initialization from the actual retained law, independent own-law parent feedback, path comparison, and the requested initial-law neighborhood. These cannot be supplied by the static normalized-parent identities or the affinity lower bound. The next action is to join those separate dynamical proofs to this specific source model and check their constants against its fixed delta and K-only observation. No universal formation or nonexistence conclusion is supported by this component alone.

## Source and execution record

The final checked model SHA-256 is `60c420d092d5b7d4f60da3bb9b397a849519677d5931f72e57556665ee79bef5`. Additional inspected source hashes are:

| Source | SHA-256 |
| --- | --- |
| frozen problem-contract.json, whole file | `f676ba9691cd48358a91115e9fc5d58d2e59c5919e998c9dcfaa12715d7150ea` |
| nonlinear-adaptive-attention-target.md | `30518725d102da7a3b14d61bc0400d40831bf1733f4626ad84498884765c2034` |
| nonlinear-attention-model-route.md, Section 9 affinity source | `3da7f88f6769d4621df49613db7d33b6566789744b75e31f436417bf9306dc89` |
| adaptive-normalized-model.md | `4ba59eb60c1ad1db6b414b9712fdd4b1f95da3a6e4ef42f745b311c7d6101d31` |
| adaptive-cyclic-witness.md | `03c85f03ea7d7b9c848aa5c85252bc7f4ba245681aa8d5075c30c94e0660a92a` |
| Theory/05b_local_collective_elbo.tex | `b0ef14dbe891d7890740d6f1e27ced56a6d05c2512804d2de672891a98aab84b` |
| live Research/manuscripts/PIFB2.tex | `f80e6dabd9e5485649066e227e80beff1dd2b1082cf786bcdaeedb8cbd080ec4` |

The only Python execution in this check used C:/Python314/python.exe with the standard json, pathlib and hashlib modules to reproduce the target digest. The analytical calculations above were not inferred from a numerical test. Read-only source inspection and file hashing also ran. This file is the checker's sole written artifact. No production, configuration, Theory, Research-vault, historical evidence or Git content was edited. No simulation, symbolic-software calculation, full suite, GPU work, old science rerun, Lean work, or tamper check ran. A change to a bound source requires assessing its actual mathematical delta before reusing this component check.
