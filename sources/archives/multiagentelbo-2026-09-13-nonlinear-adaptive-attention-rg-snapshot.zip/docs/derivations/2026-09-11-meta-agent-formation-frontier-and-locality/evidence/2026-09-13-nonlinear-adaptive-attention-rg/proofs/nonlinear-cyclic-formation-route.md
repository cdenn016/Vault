# Nonlinear cyclic formation under a bounded standardized source deformation

September 13, 2026. Formation component for the [frozen nonlinear adaptive target](nonlinear-adaptive-attention-target.md), contract digest `3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a`. This document proves a dynamical interface and instantiates its configuration-potential assumptions for the source-label family below. The complete normalized generative construction, complete model score, inherited model metric, positive conditional changes, and conditional-entropy estimates are separate interfaces; their assumptions are stated explicitly rather than supplied by the formation conclusion.

The prior constructions are the [adaptive cyclic witness](adaptive-cyclic-witness.md), [adaptive completion](adaptive-cyclic-completion.md), [finite-depth Gaussian reference](finite-depth-gaussian-reference.md), [compact nonlinear comparison](finite-depth-nonlinear-comparison.md), and [two-stage nonlinear regime](nonlinear-formation-and-common-regime.md). The live Research theme `wiki/themes/Staged hierarchy formation and RG composability.md` already records successive actual-law activation and its finite-depth scope. In `Research/manuscripts/PIFB2.tex`, lines 938–968 supply a fast/slow prescription rather than deriving all formation rates; lines 387–418 distinguish independent network loops from an optional loop penalty; equation `eq:rg_reduced_hessian` retains the negative attention covariance in the Hessian. The present proof retains that covariance and supplies a global Euclidean comparison. It makes no compact-face approximation or base-transport claim.

## 1. Quantified statement and exact model interface

For every fixed integer $L\ge2$, take the cyclic graph and orthogonal flag defined in Section 2. There exists $\delta_L>0$ such that, for each fixed $0<\delta<\delta_L$, the nonlinear potentials in Section 3 admit $L$ successive coherence episodes for all sufficiently small positive $\epsilon$ in the simultaneous regime of Section 8. The same conclusion holds for the fine diffusion, for every exact marginal diffusion, and for a lineage of exact marginal diffusions activated from the preceding actual retained law. All loops survive every retention. Strict current-coherence and future-noncoherence inequalities are proved on disjoint intervals; final coherence persists through $2/\epsilon$ outside an explicit vanishing exceptional event.

The user supplies finite depth, independent dynamic links, one fixed base point, common microscopic kinetics, exact normalized parents, actual-law activation, and the need to join learning and formation. This proof introduces the triangle-chain specialization, supplied positive energy contrasts, compatible root forcing, and a small fixed standardized nonlinear source deformation. It does not assert universal formation or creation of those contrasts by learning.

Here is the precise learning interface. On each active level $p$, the actual model update must produce a deterministic absolutely continuous coefficient $a_p(t)$ satisfying

\[
1\le a_p(t)\le2.1,\qquad |\dot a_p(t)|\le C_L\epsilon.
\tag{F1}
\]

The fine microscopic coefficient starts at $a(0)=1$. At a transition, its initial coefficient equals the preceding actual coefficient. These inequalities may be proved from the complete normalized expectation-driven score and inherited metric; they are not permission to prescribe a coefficient schedule. A normalized-model route must additionally show smooth positive densities, the exact potential below including every evidence/normalizer contribution relevant to its score, and local well-posedness of that coupled score equation. For independently learning path replacement, Section 9 states the further parameter-discrepancy interface. Positive attention and hidden-conditional changes are not inferred from (F1).

The continuous configuration process on level $p$ is

\[
dX^{(p)}=-\nabla V_p(X^{(p)},a_p(t))dt+\sqrt{2T}dW^{(p)},
\tag{F2}
\]

in orthonormal coordinates of the retained Euclidean space. The noise is standard Brownian motion in that space and independent of the initial state. Every microscopic configuration coordinate has unit mobility; orthogonal retention inherits it. There are no physical boundaries. The parameter $t$ is the declared algorithmic flow parameter. No discretization or implementation is asserted.

The display in (F2) uses the usual stochastic differential notation; throughout the argument the diffusion covariance is $2T I$. Exact equivalence means normalized common-channel pushforward and composition. Independent marginal diffusions provide a controlled path approximation, not an exact Markov representation of the projected fine process.

## 2. Cyclic graph and weighted flag

Put $b=2^{L-1}$, take $b$ cyclically oriented disjoint triangles, and connect their portal vertices in a chain by $b-1$ independent bridge links. Thus $n=3b$, $E=4b-1$, and the configuration $x=(u,v,\alpha)\in\mathbb R^{10b-1}$ records belief means, model-presentation means, and independent translation links. Define

\[
d_i=u_i-v_i,\qquad r_e=u_i-u_j-\alpha_e.
\tag{F3}
\]

Each triangle edge and each $d_i$ has level one; portal bridge $j$ has level $2+v_2(j)$. All triangle-edge transported belief KLs are $r_e^2/2$, with unit belief variances. The positive coefficients $J_s$ are energy strengths, not source-attention probabilities.

For triangle $q$, retain $z_q=h_q/\sqrt3$, where $h_q$ is the oriented sum of its three links. Resolve its residuals by

\[
Q_\triangle=\begin{pmatrix}1/\sqrt2&-1/\sqrt2&0\\1/\sqrt6&1/\sqrt6&-2/\sqrt6\end{pmatrix},
\qquad |r_q|^2=|Q_\triangle r_q|^2+z_q^2.
\tag{F4}
\]

Let $B_1$ stack all $d_i$ and all internal contrast rows $Q_\triangle r_q$; $B_s$, $s\ge2$, stacks the bridge rows of that level. Their stack $B$ has independent rows: the independent link columns kill every contrast/bridge coefficient in a proposed dependence, and the model columns then kill the remaining $d_i$ coefficients. Each loop row is orthogonal to $B$. With $N=\operatorname{range}B^T$, $H_h=\operatorname{span}\{z_q\}$, and $K=\{(t,t,Dt)\}$,

\[
\mathbb R^{10b-1}=N\mathbin\oplus H_h\mathbin\oplus K,
\quad H=B^T\operatorname{diag}(J_s I)B+J_1P_{H_h}.
\tag{F5}
\]

The loop term in this equality is an orthogonal decomposition of the original edge energies, not an added loop penalty. Put $W_s=\ker(B_1,\ldots,B_s)$, with orthogonal projector $P_s$. Every $P_s$ preserves $H_h\oplus K$, and $P_sP_p=P_s$ for $p<s$. Write $N_s=W_s\cap N$, $M_s=N_s\oplus H_h$.

Choose orthonormal flag columns $Q_s$ spanning $N_{s-1}\cap N_s^\perp$. The matrix $\mathsf B=B[Q_1\cdots Q_L]$ and its inverse are block lower triangular. Conjugation by $\operatorname{diag}(\sqrt{J_s}I)$ multiplies each permitted lower block $(j,i)$ by $\sqrt{J_j/J_i}\le1$. Consequently constants $c_L,C_L>0$, independent of the descending stiffnesses, satisfy

\[
c_L\sum_sJ_s|w_s|^2\le x_N^THx_N\le C_L\sum_sJ_s|w_s|^2.
\tag{F6}
\]

For example $c_L=\|\mathsf B^{-1}\|_F^{-2}$ and $C_L=\|\mathsf B\|_F^2$ suffice. Fix $0<\kappa\le1$, root observation $z\in K$, and Gaussian comparison potential

\[
G_a(x)=\tfrac12x^T[aH+(1+\kappa)P_K]x-\kappa z^Tx.
\tag{F7}
\]

This uses the compatible normalized observation on the root space only, $O\mid x\sim N_K(P_Kx,T\kappa^{-1}I_K)$, with observed $O=z$. Write the full precision as $\widehat K_a=aH+(1+\kappa)P_K$ and its normal/loop restriction as $K_a=aH|_{K^\perp}$; root forcing decouples. Denote its exact marginal precision on $M_p$ by $S_p(a)=aH_p$, where $H_p$ is the Schur complement of $H|_{K^\perp}$. Completing the square gives

\[
y^TS_p(a)y=\min_{u\in W_p^\perp}(u+y)^TK_a(u+y).
\tag{F8}
\]

Minimizing (F6) proves the same weighted bounds for every $S_p$, with all retained loop weights still $J_1$. Differentiating the minimization gives

\[
0\preceq\partial_aS_p\preceq S_p/a.
\tag{F9}
\]

For a further split $M_p=F_{p:s}\oplus M_s$, the normal current/future blocks of $S_p$ obey

\[
F\succeq c_LJ_sI,\qquad \|G_{\mathrm{current,future}}\|\le C_LJ_{s+1}.
\tag{F10}
\]

Here $F_{p:s}=N_p\cap N_s^\perp$, while retained loops are separate from the future normal block. To check the cross bound, original rows through $s$ annihilate $N_s$; original eliminated-future and current-future blocks are therefore $O_L(J_{s+1})$. The eliminated-current block is $O_L(J_{p+1})$, and the eliminated inverse is $O_L(J_p^{-1})$. Its Schur correction is at most $C_LJ_{p+1}J_{s+1}/J_p\le C_LJ_{s+1}$. For $p=0$ there is no correction. Put $J_{L+1}=0$.

## 3. A fixed nonlinear source deformation

Each node $i$ has two candidate sources, its two internal triangle neighbors. No source choice selects a portal bridge. Let $\pi_{ij}(a)>0$ be smooth normalized rows on $a\in[1,2.1]$, with bounded derivatives there. At fixed $T,J$, set

\[
f(s)=1-e^{-s^2/2},\qquad s_{ij}=\sqrt{J_1/T}r_{ij},
\]

\[
\Phi_a(x)=-\sum_i\log\left(\sum_{j\in\mathcal N_i^\triangle}\pi_{ij}(a)e^{-\delta f(s_{ij})}\right),
\qquad R_a=T\Phi_a,\qquad V_0=G_a+R_a.
\tag{F11}
\]

Opposite edge orientation changes the residual sign and leaves $f$ unchanged. The source posterior is the normalized row inside (F11). This formula is the configuration contribution obtained by summing the normalized source labels and their selected Bernoulli-success likelihoods. By itself it is not a derivation of the full model-parameter score; that score also includes the declared normalized base model and source priors.

The nonlinear coefficient $\delta>0$ stays fixed as $\epsilon\downarrow0$. Although $R_a$ has magnitude $O(T)$, the standardized density tilt $e^{-\Phi_a}$ has fixed nonzero magnitude. It is not a deformation coefficient being sent to zero. In particular $f$ is bounded, smooth and nonquadratic on the thermal residual scale.

For example choose one row prior $\pi_{i1}(a)=\sigma(4(a-1.5))$, $\pi_{i2}=1-\pi_{i1}$, where $\sigma(t)=(1+e^{-t})^{-1}$. Its posterior log odds differ from its prior log odds by $-\delta[f(s_{i1})-f(s_{i2})]\in[-\delta,\delta]$. Since $\sigma'\le1/4$, every state satisfies $|\beta_{i1}(x,a)-\pi_{i1}(a)|\le\delta/4$. Consequently, if the actual normalized-model calculation proves $a(0)=1$ and $a(H_*)\ge1.5$, the recognition-averaged posterior row satisfies

\[
\operatorname{TV}(E_{Q_{H_*}}\beta_i(\cdot,a(H_*)),E_{Q_0}\beta_i(\cdot,1))
\ge\tfrac12-\sigma(-2)-\delta/2>0
\tag{F11a}
\]

for sufficiently small fixed $\delta$, regardless of how the state law changes. The posterior still depends on the residuals whenever its two source costs differ; its force and covariance contributions are exactly those differentiated in (F12). Thus the formation interface is compatible with a fixed positive attention change, while the learned endpoint in (F11a) remains a normalized-model obligation.

Since $0\le f\le1$, $0\le\Phi_a\le n\delta$. Also $f'(s)=se^{-s^2/2}$, $|f'|\le1$, and $|f''|\le1$. Differentiating (F11) gives the exact Hessian of each row,

\[
\nabla^2R_i=T\left[\delta E_{\beta_i}\nabla^2f(s_{ij})-\delta^2\operatorname{Cov}_{\beta_i}(\nabla f(s_{ij}),\nabla f(s_{ij}))\right].
\tag{F12}
\]

Every directed internal residual row occurs at most twice, and $H\succeq J_1\sum_{e\text{ internal}}b_e^Tb_e$. Thus, increasing finite graph constants if necessary,

\[
|H^{-1/2}\nabla R_a|\le B_L\sqrt T,\qquad
|v^T\nabla^2R_aw|\le\eta_L\sqrt{v^THv}\sqrt{w^THw},
\tag{F13}
\]

on $M_0=K^\perp$, where $B_L=C_L\delta$ and $\eta_L=C_L(\delta+\delta^2)$. For the first inequality, write the gradient as $\delta\sqrt T\sum_{ij}\beta_{ij}f'(s_{ij})\sqrt{J_1}b_{ij}$, use $\|H^{-1/2}\sqrt{J_1}b_{ij}^T\|\le1$, and sum the finite rows. For the second, bound the expectation Hessian by the sum of squared directional residuals, and apply Cauchy–Schwarz to the covariance. These calculations include the negative covariance term; they do not assume that attention preserves convexity automatically.

The perturbation depends only on $N_0\cap N_1^\perp$ and $H_h$, and is independent of $N_1\oplus K$. With $\delta_L$ small enough that $\eta_L+B_L^2<1/2$, all exact parents below are globally strongly convex on their non-root coordinates. Every instance has smooth densities bounded above and below by fixed factors times a proper Gaussian. Hence all fixed-order polynomial moments and the scores used in differentiation are integrable. Finite $T,J$ derivatives can grow with $J/T$; no uniform unweighted derivative bound is assumed.

## 4. Exact marginal bounds, including the generated Hessian

Let $V_p$ be the exact negative-temperature-log marginal of $e^{-V_0/T}$, with its actual normalization. Split the original normal/loop coordinates into eliminated $u$ and retained $y\in M_p$. Write the Gaussian conditional as $u=-F_p^{-1}G_py+\zeta$, $\zeta\sim N(0,TF_p^{-1})$, and set

\[
L_py=(-F_p^{-1}G_py,y),\qquad
\Psi_p(y,a)=-T\log E_\zeta e^{-R_a(L_py+\zeta)/T}.
\tag{F14}
\]

Then $V_p=G_p+\Psi_p$, exactly up to the normalizing constant retained in the density. The root term is unchanged. Since $L_p^TK_aL_p=S_p$ and $H\preceq K_a/a$,

\[
L_p^THL_p\preceq S_p/a.
\tag{F15}
\]

Differentiation under the fixed centered Gaussian is justified by (F13) and Gaussian domination. In the tilted conditional measure $\nu_{p,y}$,

\[
\nabla\Psi_p=E_{\nu_{p,y}}L_p^T\nabla R_a,
\]

\[
\nabla^2\Psi_p=E_{\nu_{p,y}}L_p^T\nabla^2R_aL_p-T^{-1}\operatorname{Cov}_{\nu_{p,y}}(L_p^T\nabla R_a,L_p^T\nabla R_a).
\tag{F16}
\]

Consequently, uniformly over every retained state, all levels, and descending contrasts,

\[
|S_p^{-1/2}\nabla\Psi_p|\le B_L\sqrt T,
\quad
-\theta_L S_p\preceq\nabla^2\Psi_p\preceq\theta_L S_p,
\quad \theta_L=\eta_L+B_L^2<1/2.
\tag{F17}
\]

The covariance bound uses $|v^TL_p^T\nabla R_a|\le B_L\sqrt{T/a}\sqrt{v^TS_pv}$; its second moment bounds its variance. Thus

\[
(1-\theta_L)S_p\preceq\nabla^2V_p\preceq(1+\theta_L)S_p.
\tag{F18}
\]

This establishes global restoring bounds for the actual nonlinear marginal potential, not only for its Gaussian comparison. In particular its conditional hidden-normal Hessian is at least $c_LJ_sI$ for a further elimination through $s$. The weighted quadratic form (F6), the loop weights, and (F18) put each ordered Hessian eigenvalue between fixed finite multiples of the corresponding ordered list of $J_s$'s and retained $J_1$ loop weights. The elementary variational formula $\lambda_k(A)=\min_{\dim E=k}\max_{v\in E,|v|=1}v^TAv$ gives this claim directly. Distinct normal bands are therefore separated when successive contrasts diverge.

For every finite parameter instance (F18) bounds the actual drift's global Lipschitz constant, and (F17) bounds its additive nonlinear force. After subtracting the Brownian path, integral Picard iteration gives a unique pathwise solution on short intervals; the linear-growth estimate extends it over every finite horizon. More explicitly, the squared distance from the compatible root equilibrium has generator at most $-c_L|x-x_*|^2+C_L(T+|z|^2)$ after using (F17) and Young's inequality. This proves nonexplosion and finite second moments; applying the calculation to higher even powers gives finite fixed-order moments. For the coupled own-law equation this extends any locally well-posed model route once (F1) is verified. At fixed finite parameters the nonlinear force and its derivatives are bounded, so bounded change of drift relative to the Gaussian diffusion also has finite drift energy on every finite horizon. The proof never imposes reflection or removes a tail region.

The normal current/future cross bound also survives. For $p\ge1$, $R_a$ ignores the direct retained normal coordinate, so a normal derivative in direction $v\in N_p$ acts only through $-F_p^{-1}G_pv$. If $v$ lies in the current normal block through $s$, respectively in $N_s$,

\[
|H_{EE}^{1/2}F_p^{-1}G_pv|\le
C_L J_{p+1}|v|/\sqrt{J_p},\quad\text{respectively}\quad
C_LJ_{s+1}|v|/\sqrt{J_p}.
\tag{F19}
\]

Indeed $H_{EE}\preceq F_p/a$, $F_p\succeq c_LJ_pI$, and the original cross columns have the stated weights. Applying (F16) in these two directions gives

\[
\|\nabla^2\Psi_p|_{\mathrm{current,future}}\|
\le C_L(\eta_L+B_L^2)J_{p+1}J_{s+1}/J_p
\le C_LJ_{s+1}.
\tag{F20}
\]

For $p=0$ this nonlinear cross block is zero because the source perturbation depends only on the first normal layer and loops. In particular the complete normal current/future block remains $O_L(J_{s+1})$. Loop/normal couplings are retained and need not satisfy this normal-only estimate. The actual force bound needed for paths is (F17), which covers them all. Also, for $p\ge1$,

\[
|\nabla_{N_p}\Psi_p|\le C_LB_L\sqrt T J_{p+1}/\sqrt{J_p}.
\tag{F21}
\]

No force or covariance term was dropped in deriving these inequalities.

## 5. Uniform path and energy comparison without a largest-stiffness exponential

On each active level couple (F2) synchronously to its Gaussian comparison driven by the same actual $a_p(t)$, the same Brownian motion, and the corresponding projected initial Gaussian reference. The Gaussian reference is an analytical device; its coefficient is the actual nonlinear model coefficient. It is not supplied to an independently learning parent as a schedule. For the path difference $e=X^{(p)}-X_G^{(p)}$, noise cancels and

\[
\dot e=-S_p(a_p(t))e-\nabla\Psi_p(X^{(p)},a_p(t)).
\tag{F22}
\]

The root difference separately contracts. By (F17) and $2ab\le a^2+b^2$,

\[
\frac d{dt}|e|^2\le-e^TS_pe+B_L^2T.
\tag{F23}
\]

At a transition project both paths; the Euclidean difference cannot increase. For a lineage of total duration $H_*$,

\[
\sup_{t\le H_*}|e_t|\le |e_0|+B_L\sqrt{TH_*}.
\tag{F24}
\]

This is a deterministic bound on each synchronous coupling, including actual-law activations. It does not use concentration, conditional KL, or an ambient Lipschitz exponential.

The sharper energy estimate needed for subsequent conditional calculations follows below without even requiring commutation. In the present root-observation specialization the parent precisions are $S_p(a)=aH_p$ and do commute. On one stage abbreviate $S(t)=S_p(a_p(t))$, and let $U(t,s)$ solve $\partial_tU=-S(t)U$. Equations (F1) and (F9) imply, for sufficiently small $\epsilon$,

\[
mI\preceq S(t)\preceq MI,\qquad
-\rho S\preceq\dot S\preceq\rho S,\qquad
\rho\le m,\quad m=c_L,\quad M=C_LJ_1.
\tag{F25}
\]

For $w(t)=U(t,s)v$, the Euclidean energy satisfies $(|w|^2)'=-2w^TSw$, while

\[
\frac d{dt}(w^TSw)\le-(2m-\rho)w^TSw\le0.
\]

Thus $\|S(t)^{1/2}U(t,s)\|\le[2(t-s)]^{-1/2}$. Apply the identical argument to the reversed coefficient $S(t-r)$, whose relative derivative has the same bound, to get $\|U(t,s)S(s)^{1/2}\|\le[2(t-s)]^{-1/2}$. Splitting the propagator into thirds and using Euclidean contraction in the middle gives

\[
\|S(t)^{1/2}U(t,s)S(s)^{1/2}\|
\le\min\left\{Me^{-m(t-s)},\frac{3e^{-m(t-s)/3}}{2(t-s)}\right\}.
\tag{F26}
\]

The integral of the right side is at most $C[1+\log(M/m)]$: split at $1/M$ and $1/m$, integrate $M$, then $1/u$, then the exponential tail. Writing the force in (F22) as $S(t)^{1/2}v_t$, $|v_t|\le B_L\sqrt T$, Duhamel's formula proves

\[
\sup_t|S(t)^{1/2}e_t|
\le |S(t_0)^{1/2}e_{t_0}|+C_LB_L\sqrt T[1+\log J_1].
\tag{F27}
\]

The homogeneous initial-energy term contracts by the calculation preceding (F26). At a retention the Schur variational formula gives $(P_se)^TS_s(P_se)\le e^TS_pe$. Applying (F27) through at most $L$ stages therefore only multiplies its finite constant. Put $\Lambda_J=1+\log J_1$; the actual lineage has a uniform energy error $C_LB_L\sqrt T\Lambda_J$, independent of horizon.

The loop estimate is sharper. The Gaussian comparison loop has scalar rate $aJ_1$. Equation (F17) implies $|\nabla_{H_h}\Psi_p|\le C_LB_L\sqrt{TJ_1}$. Its scalar variation-of-constants formula, unchanged at all retentions, gives

\[
\sup_t|z_q(t)-z_q^G(t)|\le C_LB_L\sqrt{T/J_1},
\qquad J_1E|z_q(t)|^2\le C_LT
\tag{F28}
\]

for the centered Gaussian preparation below. The loops are coupled nonlinear dynamic coordinates; (F28) does not claim they remain independent Ornstein–Uhlenbeck processes.

## 6. Actual retained energy at activation

Choose a unit $v\in N$ as in Section 7 and initialize the Gaussian reference by mean $Av$ and full covariance $T\widehat K_1^{-1}$. Its coefficient path satisfies (F1), so its normal/loop covariance obeys

\[
(1-r)TS_p(a)^{-1}\preceq\Sigma_G^{(p)}\preceq(1+r)TS_p(a)^{-1},\qquad r\le C_L\epsilon.
\tag{F29}
\]

For completeness, substitution of the two barriers into $\dot\Sigma=-S\Sigma-\Sigma S+2TI$ shows they are preserved when $\dot r=-(2m-\rho)r+\rho$, $r(0)=0$. The residual covariance equation preserves matrix order because its source solution is an integral of positive congruences. Orthogonal marginalization preserves (F29), using the exact Schur inverse identity. No covariance reset occurs at activation.

The unforced Gaussian normal mean has norm at most $A$; projection cannot increase it. Its loop mean is zero. At any actual transition through level $s$, the projected Gaussian mean therefore has $S_s$-energy at most $C_LA^2J_{s+1}$, and its covariance contributes at most $C_LT$. Equations (F27) and (F8) imply for the actual retained law

\[
E[Y_{N_s}^TS_s|_{N_s}Y_{N_s}]+J_1E|Y_{H_h}|^2
\le C_L\left[A^2J_{s+1}+T(1+B_L^2\Lambda_J^2)\right].
\tag{F30}
\]

At $s=L$ the first term on the right is zero. This is the retained-energy estimate; replacing $J_{s+1}$ by the microscopic $J_1$ would erase the useful scale information. It is valid at actual-law activation and does not assume a new equilibrium law. In fact (F30) holds whenever the current retained level is $s$, since its Gaussian normal mean stays bounded by $A$. Equation (F28) gives the separate $O(T)$ loop-energy bound.

## 7. Actual formation intervals and persistence

For every original internal triangle edge include its residual covector on $N$ in a finite list. For each future bridge $e$, include $b_eP_s|_N$ for $s<\ell(e)$. Every listed functional is nonzero by the residual-row independence. In a fixed orthonormal basis of $N$, its value on $(1,t,\ldots,t^{\dim N-1})$ is a nonzero polynomial. If there are $m_0$ functionals, at most $m_0(\dim N-1)$ integers can be roots. Pick the first nonroot in $0,\ldots,m_0(\dim N-1)$ and normalize the vector. This constructs $v$ with fixed margin

\[
\min_{e,s<\ell(e)}|b_eP_sv|=:m_L>0.
\tag{F31}
\]

The list includes internal edges only at $s=0$. The same strict margin, decreased by a factor two, holds in an open neighborhood of this initial direction. It is a preparation in a fixed graph, not a merger instruction to the dynamics.

For a Gaussian reference on active level $p<s$, decompose its current normal mean into $u\in F_{p:s}$ and future $y\in N_s$. Equations (F10) and $\|\mu_G\|\le A$ give

\[
|u(t)|\le C_LA\left[e^{-c_LJ_s(t-t_0)}+J_{s+1}/J_s\right].
\tag{F32}
\]

The entire future block row has norm $O_L(J_{s+1})$, so $|P_s\mu_G(t)-AP_sv|\le C_LAJ_{s+1}t$. Earlier projections preserve $P_s\mu_G$. For a sequential process activated at $\tau_{s-1}$,

\[
|\mu_G(t)-AP_sv|\le C_LA\left[e^{-c_LJ_s(t-\tau_{s-1})}+J_{s+1}/J_s+J_{s+1}t\right].
\tag{F33}
\]

The future terms vanish at the last normal elimination. Smallness of (F33) makes past/current residuals small and keeps future bridges above $m_LA/2$. The retained loops have zero Gaussian means and are included in the fluctuation estimate.

The centered Gaussian normal/loop reference $Z_G$ has drift precision at least $c_LI$ and initial covariance at most $C_LT I$, including all actual projected covariances. For $V(Z)=\exp(c|Z|^2/(4T))$, choose a fixed $c>0$ smaller than the drift lower bound and the inverse covariance constants. Direct Ito differentiation bounds $\mathcal L_tV\le C_L$: after putting $u=c|Z|^2/(4T)$, the expression is at most $c(d/2-u)e^u$, bounded above. Initial $EV$ is bounded by a finite Gaussian integral. Stopping at radius $rA$, projecting at transitions, and then removing bounded localizations gives

\[
\Pr\{\sup_{t\le H_*}|Z_G(t)|>rA\}
\le C_L(1+H_*)e^{-c_Lr^2A^2/T}.
\tag{F34}
\]

The actual nonlinear path differs by (F24), deterministically. Thus the Gaussian strict formation margins imply actual nonlinear margins whenever

\[
|e_0|/A+B_L\sqrt{TH_*}/A=o(1).
\tag{F35}
\]

This proves pathwise episodes rather than just a statement about eigenvalues or one-time moments. After a level $s$ forms, (F32) keeps its already formed normal residuals small while the future mean remains bounded; after level $L$ there is no future normal forcing. Final coherence therefore persists to $H_*$ on the same event.

The inherited physical edge statistic has the same interpretation under exact conditional marks. The physical and optimizing hidden conditional densities in this candidate are bounded tilts of their respective Gaussian conditionals, with ratio at most $e^{n\delta}$. For a cumulative elimination through $p$, Gaussian hidden precision is at least $c_LJ_p$, its hidden/future cross norm is $O_L(J_{p+1})$, and its loop cross block is zero. At a retained normal state of norm at most $C_LA$,

\[
E[|u_{\mathrm{hidden}}|^2\mid y]
\le C_Le^{n\delta}\left[A^2(J_{p+1}/J_p)^2+T/J_p\right].
\tag{F36}
\]

The Gaussian physical precision may contain the evaluator correction of the normalized-model construction. For (F36), that route must check its hidden block remains at least $c_LJ_p$, and the correction has no hidden/future block; the existing correction $-TR$, with every evaluator row in the first normal layer, has exactly this property. Applying each original residual row to the hidden displacement transfers current/future residual margins to its conditional root-mean-square original mismatch. It does not identify a complete parent-mixture KL with one scalar residual KL.

## 8. A simultaneous regime and the explicit two-level example

For each fixed $L$, set

\[
\nu_L=0,\qquad\nu_s=2\nu_{s+1}+20,\qquad
J_s=\epsilon^{-\nu_s},\qquad
A=\epsilon^{3\nu_1/2+10},\qquad T=\epsilon^{3\nu_1+26},\qquad H_*=2/\epsilon.
\tag{F37}
\]

Fix $\delta\in(0,\delta_L)$ independently of $\epsilon$. Then

\[
A^2J_1=\epsilon^{2\nu_1+20},\qquad A/\sqrt T=\epsilon^{-3},\qquad
J_{s+1}^2/J_s=\epsilon^{20},\qquad
B_L\sqrt{TH_*}/A=O_L(\epsilon^{5/2}),
\tag{F38}
\]

and the energy discrepancy is $O_L(T\log^2(1/\epsilon))$. Choose fixed $k_L$ sufficiently large for (F33), and define

\[
t_s=k_L\log(1/\epsilon)/J_s,\qquad I_s=[t_s,2t_s],\qquad\tau_s=2t_s.
\tag{F39}
\]

For small $\epsilon$, these intervals are disjoint, $\tau_{s-1}<t_s/2$, and $2t_L<H_*$. Also $J_{s+1}t_s\to0$, so (F33) has the requisite strict margins. Choose a fixed residual tolerance $\eta_LA$, small compared with $m_LA$. On each $I_s$ every already formed edge has mismatch below that tolerance while every future bridge has mismatch at least $m_LA/3$, outside an event bounded by

\[
C_L(1+2/\epsilon)\exp(-c_L\epsilon^{-6}).
\tag{F40}
\]

Finite sums cover the separately considered ancestors. Every instance has positive finite $T$, finite contrasts, and nonzero widths. The vanishing limit only establishes a nonempty simultaneous parameter regime. The times in (F39) select actual already formed objects for description; no coefficient, generator, or grouping force switches there.

For $L=2$, use triangles $(1,2,3)$ and $(4,5,6)$, each cyclically oriented, joined by the portal edge $(3,4)$. Then $B_1$ has six $d_i$ rows and four triangle-contrast rows, and $B_2$ is the single bridge residual row. The coordinate dimensions and agent counts are

\[
19\xrightarrow{P_1}9\xrightarrow{P_2}8,\qquad
6\longrightarrow2\longrightarrow1.
\tag{F41}
\]

Both loop coordinates survive both maps. The first window is

\[
I_1=[k_2\epsilon^{20}\log(1/\epsilon),2k_2\epsilon^{20}\log(1/\epsilon)],
\]

when both triangles are coherent and their bridge is still separated. The second is $I_2=[k_2\log(1/\epsilon),2k_2\log(1/\epsilon)]$, when the two actual first parents cohere under their inherited nonlinear equations. Here $A=\epsilon^{40}$, $T=\epsilon^{86}$. The two exact parents are the full integrals (F14), with all source and loop conditional marks retained. Their direct and sequential normalized laws agree by ordinary iterated integration of a positive integrable density; their independently evolved trajectories have the separate bounds above.

For general $L$, the first level makes each triangle one coherent component, and later level $s$ joins consecutive groups of $2^{s-1}$ triangles. Thus the actual counts are $3\cdot2^{L-1}\to2^{L-1}\to\cdots\to1$.

The exact Gaussian initial law used in the proof can be enlarged. One explicit admitted neighborhood consists of smooth positive finite-entropy laws admitting an initial coupling to that Gaussian with $|\widehat K_1^{1/2}(X_0-X^G_0)|<\epsilon\sqrt T$ almost surely, and with bounded smooth log-density ratios. Take the interior in the associated weighted $W_\infty$ and bounded-log-density topology. Small smooth compactly supported transport perturbations with sufficiently small Jacobian belong to it, so it is nonempty for every finite parameter instance. The initial error terms in (F24) and (F27) are then $O(\epsilon\sqrt T)$, and all moment and formation bounds persist. This is a specified neighborhood of the admitted initial laws, not a depth- or temperature-uniform neighborhood in every possible topology.

## 9. Independently learning replacements and exact limits of this component

Suppose the normalized-model/feedback calculation proves for an actual source-to-parent replacement, initialized with the same actual retained state and coefficient,

\[
\sup_{[\tau,H_*]}|a_{\mathrm{source}}-a_{\mathrm{parent}}|\le\chi_\epsilon,\qquad\chi_\epsilon\to0,
\tag{F42}
\]

as well as (F1) for both own-law updates. Compare each nonlinear path with its own Gaussian reference using (F24). At common parameter path, the Gaussian source-to-parent mean comparison from the split equations gives relative error

\[
C_L[J_{s+1}/J_s+H_*J_{s+1}^2/J_s].
\tag{F43}
\]

To compare Gaussian parent means at different parameters, (F9) implies the relative form bound

\[
|v^T(S_a-S_b)w|\le C_L|a-b|\sqrt{v^TS_av}\sqrt{w^TS_bw}.
\]

For their difference $d$, Young's inequality yields $(|d|^2)'\le-d^TS_ad+C_L\chi_\epsilon^2m_b^TS_bm_b$. The integral of $m_b^TS_bm_b$ is half the decrease of $|m_b|^2$. Hence the different-parameter mean discrepancy is at most $C_LA\chi_\epsilon$, with no factor $J_1$ or exponential in $J_1H_*$.

Apply (F34) to both centered Gaussian paths with radius $A\epsilon^2$. Coupling root noise and including their exact retained initial coupling gives

\[
\Pr\left\{\sup_{[\tau,H_*]}|P_sX_{\mathrm{source}}-X_{\mathrm{parent}}|
>C_LA[\epsilon^2+\epsilon^{5/2}+\chi_\epsilon+\epsilon^{19}]\right\}
\le C_L(1+2/\epsilon)e^{-c_L/\epsilon^2}.
\tag{F44}
\]

For initial nonlinear activations, the reference retained coupling also contains the inherited nonlinear/Gaussian discrepancy from (F24); its contribution is another $C_LA\epsilon^{5/2}$, already included in (F44). One may realize this by continuing the projected Gaussian comparison from before activation and initializing the nonlinear parent at the actual retained path. No law is reset to its optimizer. Finite sequential replacements telescope with a finite sum of errors and a union of events. If the feedback calculation gives $\chi_\epsilon=O_L(\epsilon^4\operatorname{polylog}(1/\epsilon))$, (F44) is $O_L(A\epsilon^2)$.

The strongest unconditional conclusion of this component is the exact marginal force/Hessian interface (F14)–(F21), the dissipative path and energy comparisons (F24), (F27), actual retained-energy bound (F30), and $L$ nonlinear cyclic formation episodes under the explicit actual-learning bounds (F1). These inequalities prove the remaining formation/restoring assumptions for the standardized source family. They do not derive conditional KL from path proximity, or complete-model-score control from a bounded configuration perturbation. The full target still requires the companion normalized-model proof of (F1), fixed positive physical/optimizer conditional changes, changing normalized source attention, and an own-law feedback bound such as (F42), with its direct conditional-entropy proof. These are the minimal unresolved integration obligations here; a failure of one would be a failure of this interface, not a nonexistence theorem for the frozen target.

There are concrete failure tests. If the source perturbation is allowed to select bridge levels, the normal-only cross estimate (F20) no longer follows from its stated support and must be replaced or proved separately. If $\theta_L\ge1$, the curvature proof loses its positive lower bound. If $|H^{-1/2}\nabla R|/\sqrt T$ is unbounded in the regime, neither (F24) nor (F27) follows. If the model coefficient leaves its positive interval or loses its relative-speed bound, the covariance and smoothing arguments must be revisited. None of those route-specific failures refutes finite-depth formation in other admitted families.

No simulation, symbolic package, test suite, GPU job, Lean work, tamper check, Git operation, or Research-vault edit ran for this component. The executed tools read the named sources and wrote this assigned document; C:/Python314/python.exe performed a formatting-only pass on its inline math. Its mathematical evidence is the displayed finite-dimensional algebra, exact integrals, differential inequalities, and explicit common regime. The parent owns shared status, the daily change log, and the final integration record.

## 10. Full marked formation with retained source sheets

This section is an additional realization of the frozen target, using the full retained source state and a declared constrained recognition kinetic. It leaves F1–F44 and their source-integrated realization unchanged. Its input is the marked-state amendment of [the normalized endpoint model](nonlinear-endpoint-attention-model.md): the model and physical posterior contain the normalized source prior and success kernels, every source label is retained as an actual state coordinate, and the recognition kinetic leaves these discrete coordinates constant. The positive posterior-attention change still has the physical/optimizing posterior meaning of E6. It is not identified with the evolving recognition conditional.

### 10.1. Full state, kinetics, and exact retentions

For the fixed finite graph in Section 2 let

\[
\mathcal J=\prod_{i=1}^n\mathcal N_i^\triangle,\qquad
\mathbf j=(j_1,\ldots,j_n),\qquad |\mathcal J|=2^n,
\]

\[
\varphi_{\mathbf j}(x)=\delta\sum_{i=1}^n
 f\left(\sqrt{J_1/T}r_{ij_i}(x)\right),\qquad
V_{0,\mathbf j}(x,a)=G_a(x)+T\varphi_{\mathbf j}(x).
\tag{M1}
\]

The carrier is the finite disjoint union
$\mathbb R^{10b-1}\times\mathcal J$, with Lebesgue measure times counting measure. On its sheet $\mathbf j$ the configuration generator is

\[
\mathcal L_{a,\mathbf j}h
=T\Delta_xh-\nabla_xV_{0,\mathbf j}\cdot\nabla_xh,
\qquad d\mathbf J_t=0.
\tag{M2}
\]

There are no jumps between sheets and no boundaries in their continuous coordinates. This is one common microscopic prescription: unit configuration mobility on every sheet, Brownian covariance $2T I$, zero source-label mobility, and the previously declared common model metric. Zero label mobility is a restriction of the admissible recognition dynamics, not a parent-specific rule. Its consequence is that positive initial sheet masses $\rho_{\mathbf j}$ remain fixed. If

\[
Q_t(dx,\mathbf j)=\rho_{\mathbf j}q_{\mathbf j,t}(x)dx,\qquad
\rho_{\mathbf j}>0,\qquad \sum_{\mathbf j}\rho_{\mathbf j}=1,
\tag{M3}
\]

each normalized $q_{\mathbf j,t}$ evolves by (M2), with the same deterministic coefficient $a(t)$ learned from the complete joint $Q_t$. The source prior $\pi_{\mathbf j}(a)=\prod_i\pi_{ij_i}(a)$ and its derivatives enter the complete normalized model score. They are constant with respect to $x$ on each sheet and therefore produce no additional configuration force in (M2). No independently prescribed parameter trajectory is introduced.

Every reduction is the fixed map

\[
\mathcal C_s(x,\mathbf j)=(P_sx,\mathbf j),\qquad
\mathcal C_s\mathcal C_p=\mathcal C_s\quad(p<s).
\tag{M4}
\]

The exact parent physical, optimizing, and recognition measures are their own common-channel pushforwards through (M4). In particular the full source vector, every loop coordinate, and their joint dependence on retained continuous coordinates survive. This retains labels as actual coordinates, rather than reconstructing them by a newly drawn conditional kernel. Integration over eliminated continuous coordinates commutes with the finite source sum, but retaining the source means one does not take that sum in the parent configuration generator.

Writing $\Pi_a$ for the full normalized optimizing law, its exact marked marginal and reverse conditional are

\[
\Pi_a^{(s)}(dy,\mathbf j)
=\int\Pi_a(dy,du,\mathbf j),\qquad
\Pi_a(du\mid y,\mathbf j).
\tag{M5}
\]

They have positive densities on every sheet. Iterated continuous integration proves exact sequential composition, with the original source-prior factors, evidence, and normalization retained. The full conditional KL of discarded normals is

\[
\Delta_s(Q,a)=\sum_{\mathbf j}\rho_{\mathbf j}
\int q_{\mathbf j}^{y}(y)
D\left(q_{\mathbf j}(du\mid y)\Vert
\Pi_a(du\mid y,\mathbf j)\right)dy.
\tag{M6}
\]

This is the ordinary joint relative-entropy chain rule for (M4). There is no discarded categorical KL term because the categorical state is retained. Mismatch between actual masses $\rho_{\mathbf j}$ and the optimizer's sheet masses remains in the retained joint objective. Conditional relaxation of (M6) does not assert convergence of those fixed masses to the unconstrained optimizer.

### 10.2. Uniform nonlinear bounds on every sheet and parent

Set $B_0=n\delta$. Then $0\le\varphi_{\mathbf j}\le B_0$, uniformly over all sheets. There is a useful explicit improvement of F13. Orient each internal undirected edge once and let $k_e\in\{0,1,2\}$ count how often it was selected in $\mathbf j$. Since $f$ is even, an opposite edge orientation gives the same gradient in the fixed oriented coordinate. Also $\sum_e k_e=n$. If $D_{\mathrm{int}}$ has rows $\sqrt{J_1}b_e$, then $D_{\mathrm{int}}^TD_{\mathrm{int}}\preceq H$ and

\[
\nabla(T\varphi_{\mathbf j})
=\delta\sqrt T D_{\mathrm{int}}^Tc,\qquad
c_e=k_ef'\left(\sqrt{J_1/T}r_e\right),\qquad
|c|^2\le2n.
\]

Thus, on $K^\perp$,

\[
|H^{-1/2}\nabla(T\varphi_{\mathbf j})|
\le B_*\sqrt T,\qquad B_*=\delta\sqrt{2n},
\]

\[
-2\delta H\preceq\nabla^2(T\varphi_{\mathbf j})
\preceq2\delta H.
\tag{M7}
\]

The Hessian formula follows from $|f''|\le1$ and $k_e\le2$. There is no source covariance in (M7), because $\mathbf j$ is fixed. The source correction remains nonlinear: every selected internal residual has nonzero contrast projection, and the fourth derivative of $f(\lambda t)$ at zero is $-3\lambda^4$ when $\lambda\ne0$. Every sheet therefore has a nonzero quartic derivative in some first-hidden-normal direction for fixed $\delta>0$.

Let $G_s$ be the exact Gaussian marginal potential and use the Gaussian conditional lift and centered Gaussian $\zeta$ from F14. The marked parent's actual configuration potential on sheet $\mathbf j$ is

\[
V_{s,\mathbf j}(y,a)=G_s(y,a)+\Psi_{s,\mathbf j}(y,a),\qquad
\Psi_{s,\mathbf j}
=-T\log E_\zeta\exp[-\varphi_{\mathbf j}(L_sy+\zeta)].
\tag{M8}
\]

Its joint density also contains the retained factor $\pi_{\mathbf j}(a)$ and the full common normalization. Those terms must be differentiated in the model score even though they are constant in $y$. Formula (M8) is the continuous-coordinate potential at fixed mark, not the logarithm of a sum over marks.

Differentiate (M8) exactly as in F16. With $R_{\mathbf j}=T\varphi_{\mathbf j}$, the derivatives are the conditional expectations of $L_s^T\nabla R_{\mathbf j}$ and $L_s^T\nabla^2R_{\mathbf j}L_s$, together with the negative continuous-hidden covariance
$-T^{-1}\operatorname{Cov}(L_s^T\nabla R_{\mathbf j})$.
Using F15 and (M7) proves, uniformly in $\mathbf j,s,y,a$,

\[
|S_s^{-1/2}\nabla\Psi_{s,\mathbf j}|\le B_*\sqrt T,
\]

\[
-\theta_*S_s\preceq\nabla^2\Psi_{s,\mathbf j}\preceq\theta_*S_s,
\qquad \theta_*=2\delta+2n\delta^2.
\tag{M9}
\]

Choose the fixed coefficient so that $\theta_*<1/2$; the shared choice $\delta=10^{-4}/n$ satisfies this for every finite $n$. All hidden normal restoring rates and separated weighted normal bands from F18 remain valid uniformly on all sheets. Because $\varphi_{\mathbf j}$ still depends only on the first normal layer and retained loops, the normal current/future cross estimate F20 and future-force estimate F21 apply with the same uniform constants. The only covariance created in (M9) is from exact continuous hidden marginalization; it is included rather than omitted.

### 10.3. Actual sheetwise activation, energy, and formation

Assume the companion complete-score calculation supplies F1 for the marked model and every independently evolving marked parent, starting the fine coefficient at $a(0)=1$. Initialize every conditional sheet law by the Gaussian with covariance $T\widehat K_1^{-1}$ and normal mean $Av_{\mathbf j}$. Require all $v_{\mathbf j}$ to lie in a fixed sufficiently small neighborhood of the direction $v$ constructed in F31, so their norms have a common bound and all finitely many residual margins remain at least $m_L/2$. The simple choice $v_{\mathbf j}=v$ on every sheet is admitted. Any positive vector $\rho$ is admitted, including an open neighborhood of a fixed strictly positive vector. The mean neighborhoods and sheet masses can be chosen independently before evolution.

For each sheet couple its actual continuous process to the Gaussian reference driven by the same learned $a(t)$ and Brownian motion. Conditional on $\mathbf J=\mathbf j$, that reference is Gaussian. The mixture over marks need not be Gaussian, and no Gaussian assertion is made about the unconditional continuous law. At each activation project both reference and actual paths and retain the identical mark. Initialize the actual parent from the exact law $\mathcal C_{s\#}Q_{\tau_s}$, including its sheet masses and its full within-sheet conditional density; do not replace it by the Gaussian reference or by its optimizer.

The difference equation on every sheet is F22 with $\Psi_{p,\mathbf j}$ in place of $\Psi_p$. M9 supplies its uniform force bound. Consequently the path and energy inequalities F24 and F27 hold simultaneously in the form

\[
\sup_{t\le H_*}|X_{\mathbf j}(t)-X_{\mathbf j}^G(t)|
\le |e_{\mathbf j,0}|+B_*\sqrt{TH_*},
\]

\[
\sup_t|S_p(a(t))^{1/2}e_{\mathbf j,t}|
\le C_L\left[|K_1^{1/2}e_{\mathbf j,0}|
+B_*\sqrt T(1+\log J_1)\right].
\tag{M10}
\]

The second expression concerns normal/loop coordinates; root errors follow their unchanged contracting equation. Both estimates survive all activations by Euclidean and Schur contraction. Since the selected label never changes, no additional force discontinuity, jump error, or sheet-switching term enters. These estimates also admit smooth positive within-sheet perturbations with the initial coupling and bounded-log-density conditions stated after F41, uniformly over the finite collection of sheets.

F29 applies to each conditional Gaussian reference. Its normal mean norm stays at most $C_LA$; its loop mean is zero. Therefore F30 gives, at each actual marked activation and subsequently on active level $s$,

\[
E\left[
Y_{N_s}^TS_s|_{N_s}Y_{N_s}
+J_1|Y_{H_h}|^2\mid\mathbf J=\mathbf j
\right]
\le C_L\left[A^2J_{s+1}+T(1+\log J_1)^2\right],
\]

\[
J_1E[|Y_{H_h}|^2\mid\mathbf J=\mathbf j]\le C_LT.
\tag{M11}
\]

These constants are independent of $\mathbf j$ and of the sheet mass. Multiplying by $\rho_{\mathbf j}$ and summing proves the same estimates for the full actual joint law. Thus actual retained energy, not a reinitialized target energy, supplies the companion marked conditional-entropy calculation.

The deterministic Gaussian mean argument F31–F33 uses only the common $H$, the actual coefficient bound, and the prepared strict residual margin. It applies on each sheet. The maximum-event estimate F34 also holds conditionally on every sheet. Integrating the uniform conditional failure probability against $\rho$ preserves that bound; it does not require independence of different sheets or multiply it by $|\mathcal J|$. With the common parameters F37 and the observation/activation times F39, one obtains $L$ actual successive formation episodes on the full marked process, with failure probability at most

\[
C_L(1+2/\epsilon)e^{-c_L\epsilon^{-6}}.
\tag{M12}
\]

The actual nonlinear path correction remains $O_L(A\epsilon^{5/2})$. On the good event every current and past edge is coherent at its stated tolerance, future bridges remain separated, and final coherence persists through $H_*=2/\epsilon$. Each exact continuous hidden conditional at fixed $(y,\mathbf j)$ is a bounded tilt of its corresponding Gaussian conditional, with normalized ratio in $[e^{-B_0},e^{B_0}]$. Hence F36 and its physical-precision admission transfer the same original-edge mismatch interpretation to the full marked parents. There is no averaging of separate membership and source laws in this operation.

For $L=2$, the full retentions are

\[
(\mathbb R^{19}\times\mathcal J)
\xrightarrow{(P_1,\mathrm{id}_{\mathcal J})}
(\mathbb R^9\times\mathcal J)
\xrightarrow{(P_2,\mathrm{id}_{\mathcal J})}
(\mathbb R^8\times\mathcal J),\qquad |\mathcal J|=64.
\tag{M13}
\]

The actual coherent-agent counts remain $6\to2\to1$. All six source choices and both continuous loop coordinates survive both reductions. Every original bridge remains in the interaction energy, including the bridge responsible for the second actual episode.

### 10.4. Own-law parent coupling and the attention meaning

Suppose the companion marked feedback proof establishes F42 from each parent's complete score evaluated at its own current full joint law. There is one learned coefficient per process, shared by its sheets; it is not chosen separately to make a conditional-sheet comparison work. The two processes start with the same actual marked state and coefficient at activation. Couple their initial mark exactly and keep it unchanged thereafter. On every realized sheet, repeat the two Gaussian comparisons and the relative-precision mean comparison F42–F44, now using (M9)–(M10). Their hypotheses and constants are uniform in that mark.

For the full retained-state metric
$d((y,\mathbf j),(\bar y,\bar{\mathbf j}))=|y-\bar y|+\mathbf1_{\{\mathbf j\ne\bar{\mathbf j}\}}$,
the coupled label discrepancy is identically zero at every time. Averaging the continuous comparison over $\rho$ therefore gives

\[
\Pr\left\{\sup_{[\tau_s,H_*]}
d(\mathcal C_s(X_{\rm source},\mathbf J_{\rm source}),
(\bar X_s,\bar{\mathbf J}_s))
>C_LA[\epsilon^2+\epsilon^{5/2}+\chi_\epsilon+\epsilon^{19}]
\right\}
\le C_L(1+2/\epsilon)e^{-c_L/\epsilon^2}.
\tag{M14}
\]

Actual-law initialization is essential: the initial continuous discrepancy between an actual parent and its Gaussian comparison is the inherited (M10) discrepancy, whereas the source and actual parent themselves start with exactly the same retained continuous state and mark. That inherited error is already included in (M14). Finite sequential replacements telescope as in F44. With the companion $\chi_\epsilon=O_L(A^2J_1+T(1+\log J_1)^2)$, the shared regime makes (M14) an $O_L(A\epsilon^2)$ approximation of the entire retained marked path. Exact equality is claimed for the source-label path and for the static normalized common-channel identities, not for projected versus autonomous continuous paths.

For clarity, the full normalized optimizing and physical observed joints have source posterior

\[
\beta_{ij}(x,a)
=\frac{\pi_{ij}(a)e^{-\delta f(s_{ij}(x))}}
{\sum_k\pi_{ik}(a)e^{-\delta f(s_{ik}(x))}},
\tag{M15}
\]

the E6 row. At any fixed $x$ this is derived by conditioning the normalized marked experiment. Its fixed positive variation bound F11a/E22, including the strict $0.37$ lower bound for the shared small $\delta$, applies after averaging against any actual continuous marginal at the two endpoints once the actual learned endpoint exceeds $1.5$. This includes the present mixture $\sum_{\mathbf j}\rho_{\mathbf j}q_{\mathbf j,t}$.

The actual recognition conditional is instead

\[
Q_t(\mathbf j\mid x)
=\frac{\rho_{\mathbf j}q_{\mathbf j,t}(x)}
{\sum_{\mathbf k}\rho_{\mathbf k}q_{\mathbf k,t}(x)}.
\tag{M16}
\]

It need not equal the optimizing conditional (M15), and no entropy or force proof here makes that substitution. The actual configuration force on a realized sheet is the nonzero selected-source force $-T\nabla\varphi_{\mathbf j}$. After forgetting the label, its conditional averaged force uses the actual row $Q_t(j_i=j\mid x)$:

\[
b_Q(x,a)=-\nabla G_a(x)
-T\delta\sum_i\sum_jQ_t(j_i=j\mid x)\nabla f(s_{ij}(x)).
\tag{M17}
\]

At the physical/optimizing source posterior that same conditional-force formula uses $\beta_{ij}$ and equals the source-integrated envelope force. During the constrained recognition evolution its correct weights are (M16). The source-dependent physical coupling and the corresponding inherited marked conditional forces thus remain present; changing posterior attention is not an independently imposed drift or a claim of posterior resampling along the actual path. This distinction is the modeling scope of the marked kinetic.

Under the companion complete marked-score and conditional-entropy results, this section supplies the missing full-mark formation, actual activation-energy, and own-law path interface. The remaining external hypotheses are precisely the actual parameter bounds and endpoint, the complete-score discrepancy bound, and the direct full marked conditional-entropy estimates. It adds no new formation, restoring-mode, source-resampling, or sheet-equilibration hypothesis. No numerical computation or prohibited execution was needed for the extension; the proof is the uniform sheetwise inequalities above and their finite probability mixture.
