"""Read-only source binding and link checks; these do not prove the recorded theorem."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote


RUN = Path(__file__).resolve().parent
DOCS = RUN.parents[3]


def main() -> None:
    """Check the exact written artifacts and emit a machine-readable result."""
    record = json.loads((RUN / "document-bindings.json").read_text(encoding="utf-8"))
    errors, links = [], 0
    sources = []
    for binding in record["proof_bindings"]:
        source = DOCS / binding["source"]
        snapshot = RUN / binding["snapshot"]
        for path in (source, snapshot):
            if not path.exists():
                errors.append("Missing bound document: " + str(path))
            elif hashlib.sha256(path.read_bytes()).hexdigest() != binding["sha256"]:
                errors.append("Document binding changed: " + str(path))
        sources.append(source)
    frontier = RUN.parent.parent
    current = [p for p in sources if p.parent == frontier and p.name.startswith("nonlinear-")]
    current.append(frontier / "nonlinear-adaptive-attention-target.md")
    for source in current:
        content = source.read_text(encoding="utf-8")
        if re.search(r"\\[,!;]", content):
            errors.append("Forbidden LaTeX spacing macro: " + source.name)
        content = re.sub(r"\\\[[\s\S]*?\\\]", "", content)
        for match in re.finditer(r"\[[^\]\n]*\]\((<[^>]+>|[^)\n]+)\)", content):
            raw = match.group(1).strip("<>")
            if raw.startswith(("https://", "http://", "#", "mailto:", "codex:")):
                continue
            raw = unquote(raw.split("#", 1)[0])
            raw = re.sub(r":\d+$", "", raw)
            path = Path(raw)
            if not path.is_absolute():
                path = source.parent / path
            links += 1
            if not path.exists():
                errors.append("Missing link in " + source.name + ": " + raw)
    result = {"scope": "Read-only current source/snapshot identity, local links and edited-document spacing.",
              "proof_bindings": len(sources), "current_documents": len(current),
              "local_links": links, "errors": errors,
              "mathematical_truth_certified_by_this_check": False,
              "unrun": ["trajectory simulation", "full suite", "GPU", "heavy replay", "Lean", "tamper checks (user-excluded)"]}
    (RUN / "document-validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
