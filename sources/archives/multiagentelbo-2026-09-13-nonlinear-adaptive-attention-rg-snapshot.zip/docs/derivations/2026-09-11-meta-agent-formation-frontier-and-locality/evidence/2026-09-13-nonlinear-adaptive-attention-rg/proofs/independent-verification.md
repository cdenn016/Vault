# Independent reconstruction of the program review and next-phase bounds

September 13, 2026. This checker reconstructed the decisive claims from their stated mathematical inputs and inspected their source contexts. Two PIFB2 statements need correction: a proper reference cannot have a non-sigma-finite pushforward, and a ratio of expected squared Fisher increments does not determine the ratio of expected arc lengths. The adaptive event formula needs an explicit conditional interpretation or joint averaging. The attention identities and the nonlinear moving-conditional bounds below follow under their displayed assumptions. They do not establish the proposed nonlinear adaptive cyclic formation hierarchy.

## Scope, inputs, and source binding

The assignment is a bounded verification of the claims in [foundations-review.md](foundations-review.md), [attention-admission.md](attention-admission.md), and [dynamics-frontier-review.md](dynamics-frontier-review.md), against the [scope](scope.md) and the source manifest. It is not an independent proof of every chapter. The full Theory specification was read before writing. The source checks also read the current STATUS opening, the adaptive and finite-depth completion statements, the actual conditional-lag identities (24)–(27) and (53), and the relevant Theory and live PIFB2 sections. The live and repository PIFB2 copies have identical bytes in the manifest.

The user-supplied restrictions fix one base point c_*, preserve the ambient principal/associated-bundle types and independent cyclic links, and exclude base transport. They do not require universal formation, a unique hierarchy, learned creation of every contrast, physical-clock equivalence, or infinite depth. The proposed nonlinear/adaptive/attention target introduces additional acceptance conditions; these are recommendations for the next construction, not retrospective conditions on the completed Gaussian result.

The precise proposed existence target is: for every prescribed finite integer L at least two, construct an admitted normalized nonlinear cyclic law/link family and an initial-data neighborhood, with actual successive formation and actual-law parent activation; retain exact normalized marked-law composition and prove conditional-KL, score and path errors tending to zero in one specified common parameter regime. Constants may depend on L. If order-one attention change is chosen, the target must additionally prescribe a positive lower bound on its total-variation change while a positive restoring margin holds. This is an existence target in a declared family, not a claim about every descent trajectory. Exact equality refers to pushed laws and kernel composition; the autonomous parent paths are only to be compared with a quantitative approximation, not asserted to be equal.

A non-mutating check read all 150 entries in [source-manifest.json](source-manifest.json) and found no missing file or changed hash. The manifest identifies repository HEAD `03240a7fa7941400a36c74fef8d5e479dddffe31`; it does not supply mathematical evidence. At completion of this reconstruction, the reviewed report hashes were:

| Report | SHA-256 |
| --- | --- |
| foundations-review.md | `07fdc8cbe59f653be81de1d3e9e143646d7f483f980c70719c6efd1c63e6af18` |
| attention-admission.md | `aeaf7a531b248138ad30d3c6c6ef0b62b71d1e2782851eb862c520361fbef8ba` |
| dynamics-frontier-review.md | `b6ef865f815d46ad9aa8a14fa3bb515e70e9de97712edd72db9ccf59596e808f` |

The formal verification skill is unavailable as recorded in scope.md. This document is an independently reconstructed mathematical report, not a certificate from that skill. No missing investigator report is treated as evidence.

## 1. Random event mass and membership

Let Y be a random fine input with law mu. Conditional on Y=y, let eta_ij(y) be a normalized law of an ordered fine event (i,j). Let M(I,J|i,j,y) be its normalized conditional endpoint assignment, including any structural randomness that has already been integrated conditionally on y. The unconditional coarse event law is necessarily

\[
 p_{IJ}=\sum_{i,j}\int\eta_{ij}(y)M(I,J\mid i,j,y)\mu(dy).
 \tag{V1}
\]

Indeed, integrate the conditional probability of (I,J) under the joint law mu(dy)eta_ij(y)M(I,J|i,j,y). Summing V1 over I,J gives one. There is no independence premise in this calculation.

Take three fine vertices and two equiprobable input states. In state zero the only event is (1,2), and the hard membership sends 1,3 to A and 2 to B. In state one the only event is (1,3), and membership sends 1,2 to A and 3 to B. The conditional coarse event is (A,B) in both states, so p_AB=1. Both mean fine event masses are 1/2, and each relevant membership indicator has mean 1/2. Multiplying those means gives 1/2. Deterministic memberships satisfy conditional endpoint independence. Thus the difference cannot be repaired by that independence hypothesis alone.

Theory/07c, `eq:full-graph-closed-scale-datum`, includes eta in the random fine input, and `eq:full-graph-edge-pushforward` and `eq:full-graph-correlated-edge-pushforward` describe mu as the input law being pushed. Under that unconditional reading their displayed placement of eta outside the expectation is invalid. Under a different, defensible reading, fix y first and use the conditional structural kernel C(y,dr,dy'). Then eta(y) is deterministic and

\[
 p_{IJ}(y)=\sum_{i,j}\eta_{ij}(y)\int M(I,J\mid i,j,r)C(y,dr,dy')
 \tag{V2}
\]

is correct. I retract the algebraic defect for V2's explicitly conditioned domain. Its unconditional version is E_mu p_IJ(Y), not the product of the two unconditional means. Independence of each eta_ij from its corresponding assignment indicator is another sufficient restricted repair. The manuscript should state which object it means. The full common-structural-channel definition and its common pushforward theorem are unaffected; the displayed counterexample does not refute those theorems or the completed fixed-row adaptive witness.

## 2. Proper reference pushforward in PIFB2

The live PIFB2 paragraph beginning “Exact pushforward RG,” at lines 3634–3639, specifies a proper or explicitly normalized quotient reference nu_s, then says its barycenter pushforward fails sigma-finiteness because affine fibers have infinite Lebesgue mass. These statements are incompatible when the reference is proper.

For any finite measure nu on a measurable space S and any measurable map R:S to Y, beta=R_*nu satisfies beta(Y)=nu(S)<infinity. This identity alone proves sigma-finiteness. Fiber dimension does not enter. For a standard-Borel probability space, a nonnegative integrable weight g and rho=R_*(g nu), one also has rho absolutely continuous with respect to beta: beta(B)=0 implies nu(R^{-1}B)=0 and hence rho(B)=0. Conditional expectation gives the exact density

\[
 \frac{d\rho}{d\beta}(y)=E_\nu[g\mid R=y],\qquad\beta\text{-almost everywhere}.
 \tag{V3}
\]

To check V3, multiply either side by an arbitrary bounded measurable test function f(y) and integrate; both expressions equal the integral of f(R(x))g(x) under nu. A finite nonprobability nu can first be normalized, with its total mass canceling in the same formula. For g=exp(-F_s/T), integrability is exactly the admitted finite-partition condition. Neither a smooth submersion nor a positive-dimensional-fiber argument is needed for V3.

If beta has a density J relative to a separately chosen parent reference nu_{s+1}, the corresponding density is J(y)E_nu[g|R=y]. An intrinsic parent reference remains an allowed modeling choice. Its stated absolute-continuity and coarea hypotheses can justify its fiber formula; the false reason for rejecting R_*nu does not refute partition-function preservation or observable pushforward. An unweighted infinite Lebesgue reference under a noninjective affine projection is a different hypothesis and can exhibit the described obstruction. It does not describe the proper reference in the quoted paragraph. The minimal correction is to restrict that obstruction to the improper reference and retain V3 for the proper case.

## 3. Expected bit production and arc length

PIFB2 `prop:meta_clock_slowdown` concerns the ratio of expected per-step KL increments. Its following paragraph identifies the corresponding primary arc-clock ratio with its square root. That implication fails even in its uniform mean-update and averaging-covariance setting.

Use two independent fair signs epsilon_1,epsilon_2 in {-1,1}, no coherent component, and scalar covariance one. On one update, let child i follow N(t epsilon_i,1), 0<=t<=1, and let the averaging-covariance parent follow N(t(epsilon_1+epsilon_2)/2,1). These are explicit pure-mean curves. Their Fisher speeds and arc lengths are the absolute values of their mean changes. Each child's length is one and KL increment is 1/2. The parent length is one with probability 1/2 and zero with probability 1/2. Therefore

\[
 \frac{E[ds_I]}{E[ds_i]}=\frac12,
 \qquad
 \frac{E[\Delta I_I]}{E[\Delta I_i]}=\frac12,
 \qquad
 \sqrt{\frac{E[ds_I^2]}{E[ds_i^2]}}=\frac1{\sqrt2}.
 \tag{V4}
\]

The square root of the expected-KL ratio is the ratio of root-mean-square lengths in this setting. It is not the ratio of expected lengths. The example satisfies the stated uncorrelated idiosyncratic-update assumptions and the manuscript's averaging covariance convention. Repeating independent updates also gives these distinct rates in expectation. The proposition's expected quadratic increment can remain valid while its prose conversion to the primary arc clock is corrected. No physical-clock claim follows from either statistic. Extra assumptions relating the two distributions of update lengths would be needed to identify their mean-length and RMS ratios.

## 4. Attention Hessian, normalized witness, and finite-rate lag

For finite C2 source energies E_j(x), positive fixed priors pi_j summing to one, and fixed tau>0, define A and b by R1. Direct finite-sum differentiation gives

\[
 db_j=-\frac{b_j}{\tau}(dE_j-\overline{dE}),\qquad
 dA=\overline{dE},\qquad
 D^2A=\overline{D^2E}-\frac1\tau\operatorname{Cov}_b(dE,dE).
 \tag{V5}
\]

The negative covariance is not a newly discovered mechanism: PIFB2 `eq:rg_reduced_hessian` and the existing coherence-attraction proof already formulate it. A fixed-chart calculation alone is not a metric-invariant normal gap away from critical points. A statement about the declared metric requires its covariant Hessian and the correct normal projection.

The R5 witness is a normalized joint: X is N(0,tau/kappa), J is a fair sign independent of X, and O given x,j is N(x-ja,tau). Convolution makes O conditional on j equal to N(-ja,tau(1+1/kappa)), proving R7. At O=0 its posterior density is proportional to

\[
 \exp\left[-\frac{(\kappa+1)x^2+a^2}{2\tau}\right]\cosh(ax/\tau).
 \tag{V6}
\]

It is integrable by its negative quadratic tails, and its scaled negative log has second derivative kappa+1-a^2/tau at zero. The value -2 at (kappa,a,tau)=(1,2,1) follows exactly. Thus positive curvature of every frozen-source term does not imply positive envelope curvature. This example has incompatible source centers and is not a counterexample to local attraction at exact simultaneous agreement, nor a cyclic formation example.

For R9, subtract the two logarithmic derivatives of the strictly positive b_j and b_k. The common centering term cancels and yields R10. If d=z-z* with z*=-(e_j-e_k)/tau, then

\[
 d(t)=e^{-\nu t}d(0)+\int_0^t e^{-\nu(t-s)}\frac{\dot e_j(s)-\dot e_k(s)}{\tau}ds.
 \tag{V7}
\]

Taking absolute values proves R11. Finite continuously differentiable costs on a finite horizon keep these log odds finite; reconstructing b by normalization preserves interior probabilities. The actual coupled process must supply the derivative bound. The result does not apply to raw Brownian cost paths by formal differentiation, and changing priors or temperatures alters z* and its derivative.

For completeness, if each relative-to-reference logit error u_j satisfies |u_j|<=delta, set its reference value to zero. Then b_j=b*_j exp(u_j)/sum_k b*_k exp(u_k), so |log(b_j/b*_j)|<=2delta and KL(b||b*)<=2delta. This finite comparison uses positivity, not a uniform probability floor over an entire asymptotic regime. Posterior label integration and finite-rate recognition-row dynamics remain distinct probability objects.

The saved [attention-admission-check.json](attention-admission-check.json) records four symbolic residuals equal to zero and the scalar value -2, with Python 3.14.4, SymPy 1.14.0 and the script hash. I inspected that output; I did not rerun it. The derivations above are the general argument, and the finite diagnostic is supporting output only.

## 5. Nonlinear partition-ratio entropy budget

The D1 assumptions are a nonnegative measurable V, fixed reference mu, positive T, positive a in a compact interval, finite nonzero partitions at a and a/2, and their uniform ratio at most R. Nonnegativity implies R>=1. Fix an a-independent normalized channel C and let pi_a=p_a C. Differentiating its normalized joint under the declared differentiation hypotheses gives the score

\[
 T\partial_a\log\pi_a=\bar V_a-m_a,\qquad
 m_a=E[V\mid Y],\quad\bar V_a=E_{p_a}V.
 \tag{V8}
\]

The required reference for a dominated score chart can be an actual pi_{a_0}; the positive tilt family has common support. This does not require that the pushforward of the possibly infinite raw reference mu itself be sigma-finite.

Conditional Jensen yields E_pi exp(a m_a/(2T))<=R. The entropy inequality at lambda=a/(2T) gives E_r m_a<=(2/a)H+(2T/a)log R, with H=T KL(r||pi_a), and the same bound at r=pi_a gives bar V_a<=(2T/a)log R. Truncation of the nonnegative m_a followed by monotone convergence justifies these bounds even before integrability under r is known. Hence

\[
 |T E_r\partial_a\log\pi_a|\le\frac2aH+\frac{4T}{a}\log R.
 \tag{V9}
\]

For the actual reversible diffusion D7, integration by parts under the stated boundary and regularity assumptions gives H'=-T^2 I-T a' E_r partial_a log pi_a. Set B'=|a'|/a and Y=H+2T log R. Then

\[
 (e^{-2B}Y)'\le-T^2e^{-2B}I.
 \tag{V10}
\]

Integration proves both lines of D10, since H>=0 and B is nondecreasing. There is no derivative of the model metric in this calculation: a_t is an absolutely continuous actual input path here, which may be generated by that parent's own law. D10 does not prove a bound on that path's relative variation. If the complete learning equation supplies |a'|<=epsilon V_a on a c/epsilon horizon and a>=a_-, then B<=cV_a/a_- as stated.

At an exact activation with unchanged a, push both the actual recognition and its current target through the same fixed a-independent channel; the new target must be exactly that pushforward, not a newly fitted reference. Data processing then decreases H. Adding the nonnegative constant 2T log R preserves that jump inequality. Applying V10 on each active interval and summing therefore proves the stated sequential budget. A parameter reset, changed reference, or differently fitted channel would require its own jump correction. For a stochastic channel the entropy drop is the reverse conditional divergence on the augmented input/output joint; for deterministic retention it is the usual discarded conditional KL. These are different-time energy accounts, not one same-time chain of all losses.

The D11 curvature hypotheses imply c x^THx/2<=V(x)<=C x^THx/2 by Taylor integration from the stationary origin. The Gaussian envelopes then give D12. Diagonalize the fixed SPD H: each determinant-ratio factor (aC lambda_j+kappa)/(ac lambda_j/2+kappa) is at most 2C/c, so the bound is independent of its largest eigenvalue. The cosine perturbation in the report has Hessian H^(1/2)[I+delta diag(cos(H^(1/2)x))]H^(1/2), proving the advertised relative bounds. This is a nonquadratic witness for D1, not a constructed cyclic record model. Summing a finite source label preserves the tilt argument when the original joint tilt is admitted, but it does not automatically preserve D12 or a restoring gap.

## 6. Moving conditional balance, score tails, and constants

Adopt exactly the D13–D16 product-domain hypotheses: pi_a(y,z)=s_a(y)k_a(z|y), q=rh, constant configuration mobility diag(I,C), sufficient smoothness and decay or a genuine periodic product, conditional LSI with constant T/(2lambda), mixed derivative bound Gamma, scalar model metric m(a)>0, and the two-sided sub-gamma estimate for xi=m^(-1/2) partial_a log k_a. A principal-coordinate domain with glued faces is not this product-domain assumption.

Write D=KL(h||k_a). The entropy inequality for either sign of xi gives

\[
 |E_h\xi|\le\inf_{0<u<1/b}\left\{\frac D u+\frac{vu}{2(1-bu)}\right\}
 =\sqrt{2vD}+bD.
 \tag{V11}
\]

Substitution of u=sqrt(2D/v)/(1+b sqrt(2D/v)) proves the equality for D>0; D=0 follows from equality of the laws. The two-sided exponential moment implies the integrability needed under a finite-KL h. No bounded-score assumption has been inserted.

The conditional LSI applied to each unit projection of grad_y log k_a gives a centered exponential bound with variance proxy Gamma^2/(T lambda). The hidden gradient bound is Gamma/T; integrating the exponential-tilt inequality uH'(u)-H(u)<=u^2 Gamma^2/(2Tlambda) gives that constant. V11 with b=0 then bounds e_y=E_h grad_y log k_a by Gamma sqrt(2D/(Tlambda)). This is the earlier conditional-lag score argument, with the constants explicitly matched.

Let A=grad_y log(r/s_a), w=grad_y log(q/pi_a), and e_a=E_h partial_a log k_a. Conditional normalization gives E_h w=A-e_y. The full relative entropy derivative is -T(I_y+I_z)-a' E_q partial_a log pi_a. The retained marginal continuity equation gives the retained entropy derivative -T E_r[A dot E_h w]-a'E_r partial_a log s_a. Their difference is

\[
 \Delta'=-TI_z-T E_r\operatorname{Var}_h(w)
       +T E_r[e_y\cdot E_hw]-a'E_r e_a.
 \tag{V12}
\]

This verifies the cross-term sign in D19 and directly reconstructs the extension of conditional-lag (24) and (53). In particular it retains the motion of the hidden conditional as y evolves; it is not frozen-conditional relaxation.

Conditional LSI gives -TI_z<=-2lambda Delta. Jensen and Cauchy–Schwarz bound the two forcing terms by

\[
 T|E_r[e_y\cdot E_hw]|\le\frac\lambda2\Delta+\frac{T\Gamma^2}{\lambda^2}I_y,
 \qquad
 |a'E_re_a|\le\frac\lambda2\Delta+\frac v\lambda\omega^2+b\omega\Delta,
 \tag{V13}
\]

where omega=sqrt(m)|a'|. Dropping the nonpositive conditional-variance term yields -(lambda-b omega)Delta plus the displayed forcing terms. The admission b omega<=lambda/2 proves D20. Variation of constants and B_y=T^2 integral I_y give D21: the initial term has rate lambda/2, the budget coefficient is Gamma^2/(Tlambda^2), and the constant forcing plateau is 2v omega_*^2/lambda^2. These factors of T and two agree with the report.

For the fixed-mean Gaussian conditional with precision aD_*, the whitened quadratic score is (k-|Z|^2)/(2a sqrt(m)). Put x=u/(a sqrt(m)). Its log moment is k[x-log(1+x)]/2. For |x|<1, the absolutely convergent power series bounds x-log(1+x) by x^2/[2(1-|x|)]. This gives exactly v=k/(2a^2m), b=1/(a sqrt(m)) in D23. Thus b omega=|a'|/a and v omega^2=k(a'/a)^2/2. These constants cover the unbounded quadratic score; they do not cover arbitrary moving conditional means without additional terms.

The KL chain at fixed q and fixed coordinate retention gives F-F_parent=T Delta and hence g-g_parent=-T E_q partial_a log k_a. Average V11 under r, use concavity of the square root, and divide by sqrt(m) to obtain D25. The claimed velocity error additionally uses the same inherited metric m at the same a and the same retained r. It does not compare already separated parent and fine parameter trajectories. Similarly, the retained drift difference equals T e_y, so its squared L2(r) norm is at most 2T Gamma^2 Delta/lambda, proving D26.

## 7. What these proofs leave unresolved

The next-phase recommendation is supported by the source sequence. The nonlinear finite-depth construction supplies exact nonlinear parents and actual sequential formation with fixed coefficients. The Gaussian adaptive construction supplies changing discarded conditionals and parents learning from their own current laws, while normalized attention rows remain fixed and the contrasts are supplied. The present lemmas join reusable analytical estimates, but neither predecessor nor D10/D20 instantiates all hypotheses in one nonlinear adaptive cyclic source-attention model.

The minimal remaining constructive obligation is to exhibit one normalized joint and its exact retained parents for which the same regime controls: a positive transverse restoring margin after the attention covariance term; conditional LSI and sub-gamma constants; the actual relative model variation and stagewise activation entropies; and the law/parameter stability constants for separately evolving parents. A Markov parent path still requires its own history-sensitive or path-coupling estimate. Vanishing instantaneous conditional KL alone is insufficient. On the compact cosine carrier, boundary currents, off-tube conditional entropy, and the growing-horizon barrier estimate must also be paid. Their omission would invalidate a direct application of V12; the dynamics report correctly preserves these obligations.

The strongest supported new result is the conditional partition-ratio budget D10, together with D20–D26 under the displayed product, regularity, LSI, score-tail and feedback-speed admissions. It remains a conditional theorem. A concrete next action is to write the proposed source-label cyclic joint, derive its exact normalized parent potential and transverse Hessian, and prove one invariant formation-and-learning tube with those constants. Success at that step would change the assessment from a source-grounded research direction to an admitted construction. Merely taking the two completed predecessor theorems together, or merely making a row nonconstant by a vanishing perturbation, would not discharge the proposed stronger target.

This lane performed read-only source inspection, source-hash comparison, and the analytical reconstructions displayed here. It inspected the existing tiny symbolic output without rerunning it. Its only written artifact is this report. No Theory, Research-vault, executable, config, historical claim record, or Git state was edited. No full suite, GPU work, prior science rerun, Lean work, or tamper check ran.
