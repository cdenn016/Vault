<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a","target_digest":"3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a"} -->
# Rigorous theory search report

## Frozen contract

For every prescribed finite L>=2, construct nonlinear adaptive cyclic formation at fixed c_*, with positive source-attention and hidden-conditional changes, exact normalized marked parents, actual-law activation, and vanishing conditional, complete-score and separate path errors on a common 1/epsilon horizon. The target remains unchanged in problem-contract.json, digest 3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a.

## Terminal status

COMPLETE_AFFIRMATIVE within the frozen finite-family target.

## Certificate

Target `target` depends on c1-c8 and assumptions A1-A5. Eleven written snapshots retain the current construction, its separate R1-R50 reconstruction, and scoped predecessor evidence. The combined theorem is proofs/nonlinear-adaptive-attention-completion.md. The quantifiers are every fixed finite L>=2 and all sufficiently small positive epsilon in the exhibited family; constants need not be uniform in L.

## Strongest verified result

For every finite L>=2, the admitted nonlinear cyclic family has L actual formation levels, order-one learned source-row and hidden-conditional changes, exact marked parents and vanishing conditional, score and independently learned path errors on 2/epsilon. Posterior-row total variation exceeds 0.37; physical and optimizing hidden conditional KL exceeds 1/200. Actual recognition assignment masses are fixed. Conditional KL is O_L(epsilon^2), complete same-state score error O_L(T epsilon), and the full marked path has continuous error O_L(A epsilon^2) and exactly zero categorical error under the coupling.

## Dependency closure

The normalized experiment, relative curvature and exact marginal bounds, local coupled existence, actual weighted moments, inward model interval, formation, conditional entropy and complete scores are derived in that order. The moment estimate N16a-N16d needs only the candidate parameter interval, removing a circular use of the later speed bound. Static common-channel identities and dynamic path approximations remain distinct.

## Independent reconstruction

A separate nonauthor reconstructed c1-c8 and target from the frozen contract in R1-R50. The collapsed source-row proposal had a sustained marked-activation defect: actual and optimizing retained source kernels can differ. NAR-J1 repairs it by retaining static source assignments, the full joint VFE and categorical score, and exact actual joint initialization. The historical E1-E23 component check covers only its stated earlier scope.

## Oracle erasure

The reconstruction removes favorable expectations, author verdicts and predecessor conclusions as premises, then checks every dependency from the normalized model, finite flag, exact integrals and differential inequalities. The explicit modeling admissions remain. Agreement among agents and a matching fingerprint do not prove a claim.

## Unresolved obligations

None within the stated frozen target. Nonzero source-label mobility and adaptive recognition assignment masses require a new kinetic proof. Arbitrary nonlinear strength, learned creation of contrasts, arbitrary forcing and unbounded depth are outside this construction.

## Scope and limitations

Material admissions are supplied contrasts, calibration-assisted learning, the coherent-coordinate observation, a proper correlated prior, internal-neighbor source support, zero categorical mobility, small fixed standardized nonlinearity, and a parameter-dependent initial-law neighborhood in a shrinking amplitude/temperature regime. The changing attention row is a model posterior, not the actual recognition conditional used by the marginal force. All original loops remain dynamic. The two-level example has 6-to-2-to-1 agents and 19-to-9-to-8 continuous dimensions on 64 retained source sheets.

Mathematical evidence is the displayed derivation. No test total or trajectory experiment is claimed. No production/configuration edit, full suite, GPU job, heavy replay, Lean work or prohibited tamper check ran. Structural validation checks the record, not mathematical truth. The scalar-factor and collapsed continuous alternatives retain their limitations. Publication and the subsequent phase investigation are separate from this mathematical release.

