# A normalized endpoint-attention deformation of the cyclic model

September 13, 2026. This is route NAR-E1 for the [frozen nonlinear adaptive attention target](nonlinear-adaptive-attention-target.md), contract digest `3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a`. It supplies an actual nonlinear normalized model, its complete parameter score, and a source-row change mechanism. Formation and independently evolving parent bounds are separate interfaces. The deformation coefficient is small and fixed at each finite depth; it is not sent to zero with the approximation parameter.

The source-label record and the distinction between posterior and restricted recognition rows are already derived in [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), `eq:obs-attention-posterior` and the surrounding source-label proposition. The graph and evaluator below are those of [adaptive-cyclic-witness.md](adaptive-cyclic-witness.md), W1–W7, and [adaptive-normalized-model.md](adaptive-normalized-model.md), M1–M16. The [September 13 attention calculation](../../reviews/2026-09-13-program-review-next-phase/attention-admission.md) explains why a moving row needs its full covariance correction. This construction keeps that correction.

## 1. Fixed graph, source events and physical variables

Fix L>=2. The graph has b=2^(L-1) triangles, n=3b vertices and E=4b-1 independent oriented links. Triangle edges have strength J1. The bridges carry the descending level strengths J_s of the predecessor, with J_L=1. The configuration x=(u,v,alpha) lies in R^(2n+E). Its original transported belief mismatch is r_e=u_i-u_j-alpha_e, and its belief/model discrepancy is d_i=u_i-v_i. Belief and model laws and the evaluator are exactly M2–M3 of the normalized predecessor, with evaluator variance split c in (0,1).

Write H for the positive semidefinite quadratic form in W7, K=ker H, P_K for its orthogonal projector, and R=b_d^T b_d/(1-c). Independent link coordinates and all triangle holonomies are retained as in that construction. No edge is replaced by a frame-factorized link. The eventual retentions P_s are its nested orthogonal projections; they preserve every holonomy and the full coherent kernel K.

For each receiver i, let N_i consist of its two neighbors inside its own triangle. The added source record selects between those two actual neighbors. Bridge edges retain their original interaction energy but do not acquire a mixed-level source row in this admitted family. This restriction prevents a source Hessian from mixing an internal scale J1 with a bridge scale through a square-root contrast. It does not remove any original bridge or loop.

For a directed receiver/source pair, orient its r_ij consistently, using the negative residual when the stored edge orientation is reversed. Only its square enters below. Define

\[
s_{ij}(x)=\sqrt{J_1/T}r_{ij}(x),\qquad
f(s)=1-e^{-s^2/2}.
\tag{E1}
\]

The exact relation is s_ij^2/2=(J1/T) KL(N(u_i,1)||N(u_j+alpha_ij,1)). The bounded function f is part of a specified additional observation experiment, not an assertion that it is itself the original KL. Put B0=10^(-4) and delta=B0/n. These are fixed nonzero numbers for each prescribed finite L. A neighborhood of these values with the strict bounds below is also admitted.

Choose one receiver i0. For its two neighbors set

\[
\pi_{i_0,+}(a)=\operatorname{sigmoid}(4(a-3/2)),\qquad
\pi_{i_0,-}(a)=1-\pi_{i_0,+}(a).
\tag{E2}
\]

Other source priors are fixed positive rows, for example (1/2,1/2). At each receiver draw J_i with law pi_i(a). Conditional on x and J_i=j, draw a binary observation S_i with

\[
P(S_i=1\mid x,J_i=j)=q_0\exp[-\delta f(s_{ij}(x))],\qquad q_0=1/2.
\tag{E3}
\]

The complementary probability defines S_i=0. Both outcomes have strictly positive smooth probabilities for every configuration; the success probability lies in [q0 e^(-delta),q0]. Work with the positive density of the success slice S_i=1 for every i. No recognition law enters E1–E3. The constant q0 affects evidence and VFE constants and is retained explicitly below.

## 2. The complete normalized joint and VFE

Keep the predecessor's prior

\[
P_{0,a}=N(0,T A_0(a)^{-1}),\qquad
A_0(a)=aH+P_K-TR,
\tag{E4}
\]

the calibration Y|a~N(a,T), and a normalized observation only of the coherent coordinate: O|x~N_K(P_Kx,(T/kappa)I_K), with fixed record O=z in K and Y=2. This declared compatible observation changes the predecessor's full-coordinate observation. It leaves no artificial normal observation precision and makes the optimizing normal precision exactly aH. It is a normalized density on the n-dimensional Euclidean carrier K, not a singular density on the whole configuration space. On a in [1,2.1], T sufficiently small gives A0 positive definite by M5. All source priors and success/failure kernels are multiplied into this same normalized generative joint, along with every node's model/evaluator kernels. Thus the full law is

\[
P_{0,a}(dx)L_O(dO\mid x)L_Y(dY\mid a)
\prod_i\left[\pi_i(dJ_i\mid a)P(dS_i\mid x,J_i)
m_i(d\zeta_i\mid v_i)\operatorname{ev}_i(dk_i\mid\zeta_i)\right].
\tag{E5}
\]

At the selected source-success record, the exact posterior source row is

\[
\beta_{ij}(x,a)=
\frac{\pi_{ij}(a)e^{-\delta f(s_{ij}(x))}}
{\sum_{k\in N_i}\pi_{ik}(a)e^{-\delta f(s_{ik}(x))}}.
\tag{E6}
\]

Recognition consists of a smooth positive correlated outer law Q(dx), the optimizing evaluator coupling M2, and these exact conditional source rows. They are integrated conditionally. This is not a separate finite-rate constant recognition row, and it is not softmax of averaged costs.

Define

\[
\Phi_a(x)=-\sum_i\log\sum_{j\in N_i}
\pi_{ij}(a)e^{-\delta f(s_{ij}(x))},\qquad
0\le\Phi_a(x)\le B_0.
\tag{E7}
\]

Expanding the complete joint and minimizing the conditional source recognition gives the exact scaled restricted VFE

\[
F_T(Q,a)=F_T^{G}(Q,a)+T E_Q\Phi_a-nT\log q_0.
\tag{E8}
\]

Here F_T^G is the exact M8 calculation with the explicitly changed K-observation kernel, including its entire prior normalizer, observation constants, calibration and evaluator restriction. The additive correction is the actual success-record negative log likelihood after summing source labels.

For a positive-definite K' set

\[
Z_\Phi(K',f_0,a)=\int_{\mathbb R^d}
\exp[-x^TK'x/(2T)+f_0^Tx/T-\Phi_a(x)]dx,
\quad f_0=\kappa z.
\tag{E9}
\]

The bounds e^(-B0) Z_G<=Z_Phi<=Z_G imply finiteness and positivity. They also justify parameter differentiation on each compact admitted interval by Gaussian domination. Put K_a=aH+(1+kappa)P_K and K_a^phys=A0(a)+kappa P_K. The optimizing outer law pi_a has density proportional to the E9 integrand with K'=K_a; the physical outer posterior uses K_a^phys. Their conditional source rows are both E6, but their outer and reverse conditional laws remain distinct. The K process is autonomous and common to every parent. In the normal/holonomy subsystem, each Gaussian reference parent precision is a times the corresponding H Schur complement, and its conditional center is independent of a.

Let Z0(a) be the exact prior normalizer, c_O=(kappa/(2 pi T))^(n/2), and c_Y=(2 pi T)^(-1/2). The actual evidence and common restricted scalar are

\[
\begin{split}
p_a(z,2,\mathbf1)&=\frac{c_Oc_Yq_0^n}{Z_0(a)}
e^{-[\kappa|z|^2+(a-2)^2]/(2T)}Z_\Phi(K_a^{\rm phys},f_0,a),\\
C_T(a)&=T\log Z_0(a)-T\log(c_Oc_Yq_0^n)
+\frac{\kappa|z|^2+(a-2)^2}{2}
-T\log Z_\Phi(K_a,f_0,a),\\
F_T(Q,a)&=T\operatorname{KL}(Q\Vert\pi_a)+C_T(a).
\end{split}
\tag{E10}
\]

The difference C_T+T log p_a is the exact evaluator-restriction gap. Its Gaussian determinant formula need not survive the nonlinear source observation, so the complete integral ratio in E10 is retained.

## 3. Curvature and a nonvanishing nonlinear conditional

For one row put g_j=delta f(s_ij). Differentiating E7 gives

\[
T D^2\Phi_i=T E_{\beta_i}D^2g_j
-T\operatorname{Cov}_{\beta_i}(dg_j,dg_j).
\tag{E11}
\]

For all real s, |f'(s)|<=1 and |f''(s)|<=1. Applying E11 to any vector v, and using Var(X)<=E X^2, gives

\[
-(\delta+\delta^2)J_1\sum_{j\in N_i}
\beta_{ij}(b_{ij}v)^2
\le T D^2\Phi_i[v,v]
\le\delta J_1\sum_{j\in N_i}\beta_{ij}(b_{ij}v)^2.
\tag{E12}
\]

Every undirected internal edge occurs in at most two rows. Consequently

\[
-2(\delta+\delta^2)H\preceq T D^2\Phi_a
\preceq2\delta H.
\tag{E13}
\]

The full U_a=x^TK_a x/2-f_0^Tx+T Phi_a therefore has a global positive normal Hessian, bounded above and below by fixed multiples of H, and the untouched positive root precision. These bounds include the covariance correction. No entrance-tube positivity is assumed from a frozen row.

The perturbing force R_a=T grad Phi_a is in range H. Writing it as the sum of its bounded edge coefficients and using H's original edge-energy decomposition gives

\[
|H^{\dagger/2}R_a|\le C_L\delta\sqrt T.
\tag{E14}
\]

Here H dagger is its inverse on range H and zero on K. For example, Cauchy–Schwarz against any v gives |R_a dot v|<=delta sqrt(T)(2n)^(1/2)(v^THv)^(1/2), after increasing the constant for repeated orientations. This proves E14 by duality. The constants are independent of the strengths and T. Because the source rows use only internal edges, Phi depends on the first internal contrast rows and all triangle holonomies; it is independent of future normal coordinates and K in the predecessor's flag split.

The correction is nonlinear in the actual belief/link coordinates. Along any direction whose selected internal residuals have dimensionless squared slopes A_j>=0, expand at zero:

\[
\Phi_i(h)=\frac\delta2 E_{\pi_i}A_j h^2
-\frac{\delta E_{\pi_i}A_j^2+\delta^2\operatorname{Var}_{\pi_i}(A_j)}8 h^4
+O(h^6).
\tag{E15}
\]

The fourth derivative is strictly negative if some A_j>0. Such directions exist in the first eliminated normal space: the internal contrast residual map has positive rank. The other row contributions have the same nonpositive sign. Thus at zero retained coordinates the full optimizing and physical hidden log densities have a nonzero fourth derivative; they are not Gaussian conditionals in these fixed physical coordinates. In standardized thermal coordinates the delta coefficient remains fixed as epsilon and T vary. The argument does not claim that arbitrary laws lack nonlinear coordinate representations.

## 4. Complete learning covector and Fisher metric

For the changing source row write t_+=4,t_-=0, so partial_a log pi_j=t_j-E_pi t. Other rows have t=0. Differentiating the finite source sum gives

\[
\partial_a\Phi_a=-\sum_i(E_{\beta_i}t-E_{\pi_i}t),
\qquad |\partial_a\Phi_a|\le4.
\tag{E16}
\]

A sharper bound is proportional to delta, but is not needed for well-posedness or the learning interval. Holding the actual outer Q fixed, the envelope theorem or direct expansion of E8 gives

\[
g(a,Q)=a-2+\frac12E_Q x^THx
-\frac T2\operatorname{tr}(A_0^{-1}H)
+T E_Q\partial_a\Phi_a.
\tag{E17}
\]

The complete generative experiment E5 has Fisher metric

\[
M(a)=\frac1T+\frac12\operatorname{tr}[(A_0^{-1}H)^2]
+\sum_i\operatorname{Var}_{\pi_i(a)}t_i.
\tag{E18}
\]

To prove E18, differentiate the normalized full joint before conditioning on observations. The prior, categorical and calibration score terms each have mean zero. The categorical draws are independent of x and of Y at fixed a, so all cross terms vanish. The conditional Bernoulli, vector-observation and evaluator kernels have no explicit a dependence at fixed conditioning variables and labels. Thus they add no conditional score term. This does not replace complete model Fisher by posterior Fisher or by the Fisher metric of a later marginal model.

Declare m(a)=T M(a) and use the inherited microscopic model metric m(a)/epsilon. The actual coupled process is

\[
dX_t=(-K_{a_t}X_t+f_0-R_{a_t}(X_t))dt+\sqrt{2T}dW_t,
\qquad
\dot a_t=-\epsilon m(a_t)^{-1}g(a_t,Q_t).
\tag{E19}
\]

The outer density Q_t is the law of this configuration diffusion; it need not be Gaussian. Gaussian initial preparation is admissible but is not propagated as a Gaussian ansatz. The conditional source rows are integrated exactly. At each compact a interval, E13 implies a globally Lipschitz drift with linear growth, while E16 and quadratic Gaussian domination give finite parameter scores. The usual moment estimates and the inward parameter bound must be applied to the actual Q_t.

When the solution has the stated finite entropy and moments, integration by parts gives the exact dissipation

\[
\frac{dF_T}{dt}
=-T^2 E_{Q_t}|\nabla\log(q_t/\pi_{a_t})|^2
-\epsilon m(a_t)^{-1}g(a_t,Q_t)^2\le0.
\tag{E20}
\]

This is configuration diffusion with expectation-driven model learning, as in the predecessor. It is not the full-law Fisher replicator. Later parent processes inherit this realization and the same m(a).

## 5. Exact marked parents and quantitative change

For every fixed retention P_s put pi_a^s=(P_s)_#pi_a and Q_s=(P_s)_#Q. Disintegrate the same full physical joint, the optimizing law and the actual recognition separately. To specify one normalized directed-event law, take receiver occupancies alpha_i=1/n and apply the readout channel that draws I with these probabilities and returns (I,J_I). Its recognition event measure is Q(dx) alpha_i beta_ij(x,a); the generative and physical versions use their own complete input laws through that same readout. These joint measures and every remaining mark are integrated inside the conditional expectation, not multiplied by separately averaged event mass and membership. Keep all loop coordinates and the complete physical/evaluator/source kernels needed by a later reduction.

The exact restricted parent scalar is

\[
F_T^s(Q_s,a)=T\operatorname{KL}(Q_s\Vert\pi_a^s)+C_T(a).
\tag{E21}
\]

The ordinary physical-parent VFE instead uses the physical posterior and evidence in E10. The KL chain gives the fine-to-parent discarded conditional term exactly; nested deterministic retentions give its same-time tower. These static identities do not assert equality of projected and independently evolving parent paths.

Before earlier coordinates are marginalized, every optimizing or physical conditional is the corresponding Gaussian conditional multiplied by exp(-Phi_a) and normalized. After a previous marginalization, the weighting function is the Gaussian conditional expectation of exp(-Phi_a) on that smaller carrier. It still lies in [e^(-B0),1]. Thus each normalized conditional density ratio to its Gaussian reference lies in [e^(-B0),e^(B0)], uniformly in the retained input. This provides uniform integrability and an explicit small fixed likelihood-tilt comparison without replacing the nonlinear law by its Gaussian reference.

The source row has a direct actual-law change discriminator. From E6, its log odds are 4(a-3/2)-delta[f(s_+)-f(s_-)], so for every x they lie within delta of 4(a-3/2). If a starts at 1 and later exceeds 1.5, then, for any two actual outer laws at those times,

\[
E\beta_+(t_f)-E\beta_+(0)
\ge\operatorname{sigmoid}(-\delta)
-\operatorname{sigmoid}(-2+\delta)>0.37.
\tag{E22}
\]

Thus its total-variation change is fixed positive, irrespective of the transient configuration law. This change comes from a learned generative source prior and the success-record posterior, not a prescribed row schedule. Its x-dependent correction and its force in E19 remain present.

For an elementary strict constant, sigmoid has derivative at most 1/4, sigmoid(-2)<1/8 because e^2>7, and delta<=10^(-4). The E22 difference is therefore larger than 3/8-delta/2>0.37. No floating-point comparison is needed for this bound.

The [independent model route](nonlinear-attention-model-route.md) supplies a uniform bounded-tilt affinity discriminator for the hidden conditionals. When a increases from 1 to at least 1.5, both underlying Gaussian conditional precisions increase by a factor at least 5/4. In the K-only observation model their factor is at least 3/2: the optimizing precision scales by a, while the physical initial hidden precision is at most its H block and the increment is at least half that H block. Positive definiteness still follows from the prior admission. The weaker factor 5/4 suffices. For hidden dimension k>=1, Gaussian affinity is at most [2 sqrt(5/4)/(1+5/4)]^(k/2), irrespective of the means. The two bounded success tilts multiply affinity by at most e^(B0). Jensen's inequality for the likelihood ratio then gives

\[
\operatorname{KL}(k_1\Vert k_f)
\ge\frac k2\log(81/80)-2B_0>1/200.
\tag{E23}
\]

This applies to both the physical and optimizing hidden conditionals, uniformly in every retained input and hence after integration against any actual retained-input law. The needed precision and parameter inequalities must be established in the common regime. E22–E23 do not supply that regime by themselves.

## Remaining interfaces

The model supplies global normal curvature, bounded nonlinear force in the energy-dual norm, exact source and physical normalization, complete own-law score/metric and nonzero source/hidden change once the actual parameter bound holds. The formation and conditional routes must still prove that parameter bound and one simultaneous regime, actual stagewise retained energy and entropy, conditional tracking, parent feedback and separate path errors. The direct source correction couples normal contrasts to retained loop coordinates. Keeping every loop in the true parent while using a larger fast block only for entropy analysis must be justified by the conditional chain rule. A generic source row mixing different edge levels is outside this explicit admission.

No simulated trajectory, production implementation or approximation of a nonlinear density by Gaussian recognition is used here. This is a perturbative construction with fixed small standardized nonlinearity and order-one attention-row change, not a theorem for arbitrary nonlinear couplings or source priors.

## 6. Complete marked kinetic realization without a source-label reset

E8 and E17–E20 describe the conditionally optimized source-row realization. Its exact marked pushforward need not have optimizing conditional source rows after a reduction: in general $E_{Q(dx_{\rm hidden}\mid y)}\beta(j\mid x)$ differs from $E_{\pi_a(dx_{\rm hidden}\mid y)}\beta(j\mid x)$. Thus the collapsed parent E21 cannot be called an exact activation of that full marked recognition law. The completion uses the following explicit finite-sheet realization instead. The normalized model E5, physical posterior, optimizer, exact marginal probabilities, and complete generative Fisher E18 are unchanged. Its recognition class and its actual kinetics are specified here, rather than identified with E19.

Let $\mathcal J=\prod_i N_i$ be the finite set of all source assignments, and put $\pi_j(a)=\prod_i\pi_{i,j_i}(a)$. The actual state is $(x,j)\in\mathbb R^d\times\mathcal J$. Take fixed positive recognition masses $\lambda_j$ summing to one and smooth positive conditional densities $q_j(x)$. The full recognition law is $Q(dx,j)=\lambda_jq_j(x)dx$, with the same optimizing evaluator coupling as before. Define

\[
\phi_j(x)=\delta\sum_i f(\sqrt{J_1/T}r_{i,j_i}),
\qquad 0\le\phi_j\le B_0,
\qquad U_{a,j}(x)=G_a(x)+T\phi_j(x).
\tag{E24}
\]

On the full joint carrier, the optimizing density is proportional to $\pi_j(a)e^{-U_{a,j}(x)/T}$. Its marginal in $x$ is exactly the optimizing outer density of E9. Its physical counterpart replaces $K_a$ by $K_a^{\rm phys}$, as before. The same common scalar $C_T(a)$ in E10 gives the exact joint restricted VFE

\[
\mathcal F_T(Q,a)=T\operatorname{KL}(Q\Vert\Pi_a)+C_T(a).
\tag{E25}
\]

Equivalently, expand the joint entropy and the expectation of $G_a+T\phi_j-T\log\pi_j(a)$, retaining the common raw normalizer from E10. The conditional-source KL between $Q(j\mid x)$ and $\beta(j\mid x,a)$ is present in E25. It is not set to zero. At fixed full $Q$, its complete model covector is

\[
\mathfrak g(Q,a)=a-2+\frac12E_Qx^THx
-\frac T2\operatorname{tr}(A_0^{-1}H)
-T\sum_j\lambda_j\partial_a\log\pi_j(a).
\tag{E26}
\]

The last absolute score is at most $4T$, since only one categorical row changes. Unlike E17, E26 has no $E_Q\partial_a\Phi_a$ term: the finite labels are retained rather than optimized away. Both formulas belong to the same normalized model but to different specified recognition realizations.

The common microscopic kinetic prescription is unit continuous mobility on every sheet, zero mobility of the categorical masses, and the same inherited model metric $m(a)/\epsilon$. Thus

\[
dX_t=-\nabla U_{a_t,J}(X_t)dt+\sqrt{2T}dW_t,
\qquad J_t=J_0,
\qquad \dot a_t=-\epsilon m(a_t)^{-1}\mathfrak g(Q_t,a_t).
\tag{E27}
\]

This is VFE descent within the declared recognition class of fixed positive sheet masses. Zero label mobility is a modeling admission, not an inferred time-scale separation or instantaneous categorical relaxation. For each $j$, integration by parts gives

\[
\frac{d\mathcal F_T}{dt}
=-T^2\sum_j\lambda_j E_{q_{j,t}}
|\nabla\log(q_{j,t}/\Pi_{a_t}(dx\mid j))|^2
-\epsilon m(a_t)^{-1}\mathfrak g(Q_t,a_t)^2\le0.
\tag{E28}
\]

There is no missing categorical dissipation; its mobility is zero. The full model still learns its categorical prior through E26, and every source-dependent configuration force $T\nabla\phi_j$ is retained. If the continuous marginal is written alone, its force averages those terms using the actual recognition conditional $Q_t(j\mid x)$. That conditional is not generally $\beta(j\mid x,a_t)$.

The source-attention discriminator is the model-posterior row E6, evaluated under the actual marginal $Q_t(dx)$. This is a posterior row in the normalized model, not a claim that the marginal recognition masses $\lambda_j$ change. The frozen target permits a posterior or recognition meaning. E22 gives the same total-variation change greater than $0.37$ for the actual endpoints once the model parameter reaches $1.5$, independent of the recognition law. The source likelihood couples labels to the true belief/link residuals in E24 and E27; it is not an unrelated diagnostic likelihood.

Retain $(P_sx,j)$ through the same fixed channel at every level. Keep the exact evaluator, physical, optimizing, occupancy, and other conditional records as before. The exact optimizing joint parent is $\Pi_a^s=(P_s,\operatorname{id})_\#\Pi_a$, and its complete VFE is

\[
\mathcal F_T^s(r,a)=T\operatorname{KL}(r\Vert\Pi_a^s)+C_T(a).
\tag{E29}
\]

Every actual parent initializes $r(dy,j)$ from the full actual projected joint law, including its actual conditional source kernel. It then evolves with the exact sheet potential obtained by integrating $e^{-U_{a,j}/T}$ over hidden continuous coordinates, zero categorical mobility, and the full E29 covector from its own law. All Gaussian determinant derivatives, source-prior scores, and the prior scalar remain. Retaining the same $j$ on a coupled source/parent pair makes their categorical path discrepancy exactly zero. Subsequent retentions compose on the complete joint state; no source label or conditional source kernel is reset.

For fixed retained $j$, the hidden optimizing and physical conditional densities are bounded tilts with potential $\phi_j$, or its exact earlier Gaussian conditional integral. The categorical factor cancels from that conditional. Their Gaussian precision comparison in E23 is unchanged, giving KL greater than $1/200$ uniformly in $(y,j)$ for the first hidden block. The fourth-order coefficient of $\phi_j$ along any selected nonzero internal contrast is negative. Since every assignment selects an internal edge, such a hidden direction exists on every sheet. Thus non-Gaussian hidden laws remain in the actual marked realization.

The dual-force and Hessian estimates are at least as strong on each fixed sheet: the initial Hessian has the expectation term without the categorical covariance subtraction. Exact continuous marginalization generates its usual conditional covariance, bounded by the same $G_0^2$ term. The conditional and formation components supply the uniform finite-sheet extensions of their moment, entropy, learning, and path arguments. This resolves full marked activation within the frozen target, while retaining E1–E23 as the normalized-model and collapsed-comparison calculations rather than mislabeling their kinetics as E27.
