# Nonlinear adaptive cyclic formation with changing source attention

September 13, 2026. This integrates the [normalized endpoint model](nonlinear-endpoint-attention-model.md), [conditional and own-law construction](nonlinear-adaptive-conditional-route.md), and [cyclic formation proof](nonlinear-cyclic-formation-route.md) against the [frozen target](nonlinear-adaptive-attention-target.md), contract digest `3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a`. The statement and its interfaces are checked in the separate [reconstruction](nonlinear-adaptive-attention-reconstruction.md). Its evidence record and final disposition are maintained in [the bound run](evidence/2026-09-13-nonlinear-adaptive-attention-rg/final-report.md).

## Statement and scope

For every prescribed finite integer $L\ge2$, the explicit triangle-chain family below admits $L$ successive coherence episodes, exact normalized marked parents, and independently evolving parents activated from the preceding actual retained joint law. Over the same horizon $H_*=2/\epsilon$, its actual expectation-driven model learning changes one model-posterior source-attention row by total variation greater than $0.37$, and changes both a physical and an optimizing eliminated conditional by relative entropy greater than $1/200$. The nonlinear source coefficient is fixed and positive as $\epsilon\downarrow0$. Discarded conditional KL, the complete same-state model-score discrepancy, and a separate retained-path approximation all tend to zero in the one regime specified below.

This is an existence construction at one fixed base point. It admits supplied microscopic contrasts, a compatible coherent-coordinate observation, a proper correlated prior, calibration-assisted model learning, a small fixed standardized source deformation, and zero mobility for retained discrete source assignments. The model-posterior attention changes; the fixed recognition masses of those assignments do not. It does not establish creation of all contrasts by learning, arbitrary nonlinear coupling, universal formation, physical time, or an unbounded-depth limit. The small physical amplitude and temperature are explicit. The proof does not assert a temperature-independent open ball of initial laws or nonlinearity at a fixed macroscopic displacement scale.

## Construction and exact probabilities

Take $b=2^{L-1}$ triangles, joined through their portal vertices in a chain. There are $n=3b$ vertices and $4b-1$ independent links. Configuration coordinates $x=(u,v,\alpha)$ record belief means, model-presentation means, and link translations. The original transported belief mismatches are $r_e=u_i-u_j-\alpha_e$, with original Gaussian belief KL $r_e^2/2$. The link variables are independent degrees of freedom. Each triangle holonomy is their oriented loop sum. All loops remain in every retained parent.

The weighted form $H$, first normal block, future blocks, root kernel $K$, and nested orthogonal retentions $P_s$ are constructed in F3–F10. Triangle and belief/model discrepancies carry strength $J_1$; bridge levels carry descending strengths $J_s$. The loop term in the orthogonal expression for $H$ comes from the original edge energy. No separate loop-flattening penalty is added.

Each receiver selects between its two internal triangle neighbors. Let $B_0=10^{-4}$, $\delta=B_0/n$, and $f(s)=1-e^{-s^2/2}$. A normalized Bernoulli observation has success probability $(1/2)e^{-\delta f(\sqrt{J_1/T}r_{ij})}$ conditional on the selected source. Both outcomes have positive probability. One receiver has prior row $\pi_+(a)=\operatorname{sigmoid}(4(a-3/2))$; all other rows are fixed positive. Conditioning the source observations on success gives the exact posterior row

\[
\beta_{ij}(x,a)=\frac{\pi_{ij}(a)e^{-\delta f(\sqrt{J_1/T}r_{ij})}}
{\sum_k\pi_{ik}(a)e^{-\delta f(\sqrt{J_1/T}r_{ik})}}.
\]

These are conditional model-posterior rows. The reported statistic averages them under the actual continuous recognition marginal. The actual conditional recognition row need not equal this posterior. In the full marked realization E24–E29, source assignments are retained discrete coordinates with zero mobility. The actual force contains the selected nonlinear source likelihood on each sheet; after forgetting the discrete coordinate it averages using the actual recognition conditional. No posterior row is substituted for that conditional. The negative source covariance remains in the exactly marginalized optimizing potential below.

The prior is $N(0,T[aH+P_K-TR]^{-1})$, with the same evaluator correction $R$ as the normalized Gaussian predecessor. Observe $O=z\in K$ under $O\mid x\sim N_K(P_Kx,(T/\kappa)I_K)$, and observe $Y=2$ under $Y\mid a\sim N(a,T)$. The complete joint includes all normalized evaluator, model, categorical, and Bernoulli kernels in E5. Its evidence, optimizing outer law, physical posterior, and restricted-family scalar are the complete integrals in E9–E10. In particular the observation lives on $K$, and physical precision differs from optimizing precision by $-TR$.

Writing

\[
\Phi_a=-\sum_i\log\sum_j\pi_{ij}(a)e^{-\delta f(\sqrt{J_1/T}r_{ij})},
\qquad 0\le\Phi_a\le B_0,
\]

the optimizing configuration potential is $U_a=x^T[aH+(1+\kappa)P_K]x/2-\kappa z^Tx+T\Phi_a$. Its fourth-order term along a first hidden contrast direction is nonzero by E15. Therefore the hidden law is nonlinear in the declared physical coordinates. Its standardized thermal tilt retains the fixed positive coefficient $\delta$.

For the actual marked realization, write $j=(j_i)_i$ and $\phi_j=\delta\sum_i f(\sqrt{J_1/T}r_{i,j_i})$. The optimizing joint density is proportional to $\pi_j(a)e^{-[G_a+T\phi_j]/T}$. Each parent is its exact pushforward by $(P_s,\operatorname{id}_{\mathcal J})$, with the same restricted scalar $C_T(a)$. Its sheet potential contains the complete negative logarithm of the Gaussian conditional expectation of $e^{-\phi_j}$, not a fitted quadratic. All physical, optimizing, and actual reverse kernels are disintegrated separately. Receiver occupancy $1/n$ and the selected-source readout are applied to the complete retained assignment. Random event weights and conditional marks are integrated jointly. Exact direct/sequential equality follows from normalized common-channel composition and iterated integration; the conditional KL tower is a same-time identity. The separately collapsed $\Phi_a$ formulas describe the optimizer after forgetting assignments, not the actual marked kinetic state.

The ambient bundle and local-section types are unchanged. This model uses the translation-fiber specialization at $c_*$. Passive changes of presentation push forward the complete laws, means, kernels, retentions, and metrics together; KL and the probability diagrams are preserved. A fixed centered prior is not asserted invariant under an active translation that leaves its parameters fixed. No base path, connection, or spatial descent is used.

## Actual dynamics and closing the coupled bounds

Use common unit continuous mobility and covariance $2TI$ on every sheet, with zero mobility of the discrete assignment. The model metric is the inherited microscopic scaled Fisher metric $m(a)=TM(a)$, with $M$ in E18. The actual joint law $Q_t(dx,j)=\lambda_jq_{j,t}(x)dx$ drives

\[
dX_t=-\nabla [G_{a_t}+T\phi_J](X_t)dt+\sqrt{2T}dW_t,
\qquad J_t=J_0,\qquad
\dot a_t=-\epsilon m(a_t)^{-1}\mathfrak g(Q_t,a_t),
\]

where E26 gives the complete normalized joint covector. It includes $-T\sum_j\lambda_j\partial_a\log\pi_j(a)$, whose absolute value is at most $4T$. Every independently activated parent uses its own current joint law and the exact E29 covector, including the source-prior score and every eliminated determinant derivative, with the same inherited metric. The full joint VFE decreases according to E28. The model trajectory is determined by the law; no coefficient schedule is supplied to the actual dynamics. The actual continuous marginal generally does not follow the collapsed E19 equation.

Here is the dependency order of the proof. First, E11–E14 establish global relative curvature and a force of size $C_L\delta\sqrt T$ in the energy-dual norm; the sheet potential E24 has the same bounds, with no initial categorical covariance subtraction. For the explicit coefficient, one can use $\eta=2(\delta+\delta^2)$ and $G_0^2\le2n\delta^2$, so $\eta+G_0^2<1/2$ at every finite $n\ge6$. N20–N26 and F14–F21 propagate the bounds through every exact continuous marginal, including the generated covariance term. The finite-sheet extensions in the final sections of both component proofs apply these bounds uniformly in the retained assignment. The first-layer source support gives the stronger mixed derivative $C_LJ_{s+1}$ in N30–N34 even when retained loops are included in the analysis fast block.

Next, local coupled solutions are considered on the candidate parameter interval $[1,2.1]$. The commuting-propagator estimate N16a–N16d gives actual moments and retained activation energy using only this interval, without an assumed bound on $\dot a$. The argument uses the same actual parameter in an analytical linear companion; it does not give that parameter to an independently learning parent. The complete covector and inherited metric then give

\[
\dot a=\epsilon(2-a)+\epsilon R_t,
\qquad |R_t|\le r_\epsilon=C_L[A^2J_1+T\ell^2],
\qquad \ell=1+|\log T|+\log J_1+|\log A|.
\]

For $r_\epsilon<0.1$ the two endpoint velocities point into $[1,2.1]$. This closes the continuation argument and yields $|\dot a|\le C_L\epsilon$. Variation of constants gives $a(2/\epsilon)\ge2-e^{-2}-r_\epsilon>1.5$. Two processes learning from their own laws after a common activation value differ in parameter by at most $2r_\epsilon$; a finite sequence multiplies the constant only. Thus formation moments close the learning bootstrap before the entropy and formation conclusions use it. Neither a small conditional KL nor a hoped-for merger supplies this parameter bound.

The initial-law neighborhood is a deliberately specified intersection of the admitted classes in the two component proofs. Choose positive sheet masses in an open neighborhood of, for example, the uniform distribution on the finite set $\mathcal J$. On every sheet start from a Gaussian with mean $Av'$ in the strict formation-direction neighborhood F31 and covariance $T\widehat K_1^{-1}$, with a common product root sector. Admit sufficiently small smooth transport perturbations that have bounded smooth log-density ratio and a coupling displacement less than $\epsilon\sqrt T$ in the $\widehat K_1$ norm. Small compactly supported smooth transports with sufficiently small Jacobian provide nonempty examples. Use the finite product of the induced weighted transport and bounded-log-density topologies and the ordinary open simplex of positive masses. This class preserves the entropy floor, weighted moments, exponential moments, and strict formation margin uniformly over the finite sheets. It does not assume initial optimizing conditionals, and it allows nonzero discarded conditional KL. No unaccounted initial root-normal correlation is included.

## One regime for formation, conditional control, learning, and paths

For fixed $L$, define

\[
q_L=0,\qquad q_s=2q_{s+1}+20,\qquad J_s=\epsilon^{-q_s},
\qquad A^2=\epsilon^{3q_1+20},\qquad T=A^2\epsilon^6,
\qquad H_*=2/\epsilon.
\]

Take $\epsilon>0$ sufficiently small and retain fixed $\delta=10^{-4}/n$. All parameters are finite and all temperatures positive for every member of the family. The ratios are $A/\sqrt T=\epsilon^{-3}$, $J_{s+1}^2/J_s=\epsilon^{20}$ for $s<L$, and $A^2J_1=\epsilon^{2q_1+20}$. No largest-stiffness exponential appears in the estimates.

Let $t_s=k_L\log(1/\epsilon)/J_s$, $I_s=[t_s,2t_s]$, and $\tau_s=2t_s$, with a fixed sufficiently large $k_L$. The intervals are disjoint, earlier activations satisfy $\tau_{s-1}<t_s/2$, and $\tau_L<H_*$. F31–F40 prove that on $I_s$ all current and earlier edge mismatches are below a fixed small multiple of $A$, while all future bridge mismatches exceed another fixed multiple of $A$. The exceptional probability is at most $C_L(1+2/\epsilon)e^{-c_L\epsilon^{-6}}$. Final coherence persists to $H_*$. The original conditional physical edge statistics inherit the same separation by F36. Retention times select actual formed objects for subsequent description; no generator or parameter switches at those times.

For $L=2$, the two triangles joined by one bridge have

\[
19\xrightarrow{P_1}9\xrightarrow{P_2}8
\quad\hbox{configuration dimensions},\qquad
6\longrightarrow2\longrightarrow1
\quad\hbox{coherent-agent counts}.
\]

Both loops and all $2^6=64$ source-assignment sheets survive both maps; the dimensions count continuous coordinates only. Here $J_1=\epsilon^{-20}$, $J_2=1$, $A=\epsilon^{40}$, and $T=\epsilon^{86}$. Triangle coherence occurs on $[k_2\epsilon^{20}\log(1/\epsilon),2k_2\epsilon^{20}\log(1/\epsilon)]$; the next parent episode occurs on $[k_2\log(1/\epsilon),2k_2\log(1/\epsilon)]$. General finite depth gives $3\cdot2^{L-1}\to2^{L-1}\to\cdots\to1$.

Actual retained energy is at most $C_L[A^2J_{s+1}+T\ell^2]$. The nonlinear entropy-floor calculation N11–N16 converts that moment into an actual activation-entropy bound on each sheet and then in their finite mixture. It does not assume that a newly activated law is conditionally equilibrated. Analyze current hidden normals together with the fast retained loops, conditioned on future normals and the retained assignment $j$. The true parent still retains both loops and assignments; the KL chain N17–N19 bounds true discarded conditional KL by this larger analysis entropy. The finite-sheet entropy balance includes the changing source-prior score; no categorical dissipation is required because the assignments have zero mobility.

Global conditional convexity, the mixed derivative bound, the finite-horizon entropy budget, and the centered conditional score tails give N35–N37. After the entrance interval, uniformly through $H_*$,

\[
\Delta_{s-1:s}\le C_L\epsilon^2,
\qquad |\mathfrak g(Q,a)-\mathfrak g_s((P_s,\operatorname{id})_\#Q,a)|\le C_LT\epsilon.
\]

The second estimate concerns the complete joint covector at the same retained law and parameter. The separate own-law parameter discrepancy is $C_Lr_\epsilon$. These have distinct meanings. The moving physical and optimizing conditionals each differ between $a=1$ and the learned endpoint by KL greater than $1/200$ for the first eliminated block, uniformly in retained $(y,j)$, by E23 and its E29 sheet extension. For an elementary strict bound, $\log(81/80)>1/81$ implies $(1/2)\log(81/80)-2\cdot10^{-4}>1/200$. The model-posterior source row, averaged under the actual continuous law, changes by more than $0.37$ by E22. These positive changes coexist with vanishing approximation errors against the current hidden conditionals; no change of the fixed recognition assignment masses is claimed.

Finally, dissipative comparison and Gaussian or nonlinear concentration give a separate coupling of each projected source path to its own-law parent, initialized at the actual retained state. N44–N51 and F42–F44 yield

\[
\sup_{[\tau_s,H_*]}|P_sX-\bar X_s|\le C_LA\epsilon^2
\]

outside an event of probability at most $C_L(1+2/\epsilon)e^{-c_L/\epsilon^2}$. Couple the common root process and the retained assignment exactly, so the categorical path error is zero. Every parent initializes the entire joint $(y,j)$ from the actual preceding law; no label kernel is replaced by its optimizer. Finite sequential replacements telescope their bounds. Conditional KL is not used as a substitute for this path proof, and the result does not assert exact Markov closure of a projected fine path.

## Evidence and remaining scientific boundary

The mathematical evidence is the displayed construction, finite-dimensional algebra, exact integrals, and differential inequalities in the three component documents. A separate reconstruction checks the frozen target and the interfaces. Structural run validation checks record consistency only. No trajectory simulation, training run, production/configuration edit, GPU job, heavy replay, Lean work, or tamper check is part of this result.

The earlier independent scalar-deformation route is retained as a limited alternate in [its model note](nonlinear-attention-model-route.md); it does not supply the loop-coupled completion. The collapsed source-row realization E19 is also retained as a comparison, with its marked-activation limitation stated. The constructive advance here is the explicit common regime for a nonlinear adaptive family with changing posterior source attention, exact marked parents, actual-law learning, and retained dynamic loops. Zero categorical mobility, internal source support, calibration, supplied contrasts, and the shrinking thermal regime remain material assumptions for the next research phase.
