# Reconstruction of the nonlinear adaptive attention completion

September 13, 2026. This is a separate mathematical reconstruction of the frozen target with digest `3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a`. The conclusion below concerns the explicit retained-source realization E24–E29, N52–N60, and M1–M17. It does not identify its actual dynamics with the collapsed source-row dynamics E19. Source bytes are recorded at the end. No closure state is assigned here on behalf of the evidence validator.

## Target, quantifiers, and admissions

The target is an existence statement: for every finite integer $L\ge2$, there must exist a finite cyclic family, a nonempty admitted neighborhood of initial laws, and positive-temperature parameters indexed by sufficiently small $\epsilon>0$, such that $L$ successive formation episodes occur before a common horizon of order $\epsilon^{-1}$. Exact normalized marked parents must compose under fixed nested retentions. Independently evolving parents must start from the preceding actual retained law, use their own current law in the complete model covector, and inherit the declared kinetic prescription and metric. In one common limit, discarded conditional KL, the complete same-state score discrepancy, and a separately proved retained-path error must vanish. During that same interval, an eliminated physical conditional and an optimizing conditional must each change by a fixed positive KL, and one normalized source-attention row must change by fixed positive total variation. Its posterior or recognition meaning must be stated. The nonlinear coefficient must stay positive and fixed in the limit.

The user-supplied scope permits a fixed base point, finite supplied microscopic contrasts, compatible forcing, calibration, a proper correlated prior, fixed evaluator families, and constants depending on finite $L$. The construction adds a translation-fiber specialization; source choices restricted to the two internal neighbors of each triangle; a bounded smooth source deformation with $\delta=10^{-4}/n$; a coherent-coordinate observation; prepared strict initial residual margins; a shrinking amplitude and temperature; and zero mobility for the retained discrete source assignment. These are material assumptions. The last restriction is admitted by the target's requirement of one declared common microscopic kinetic prescription, which does not require positive mobility of every discrete coordinate or ergodicity of the source labels.

The intended exact equivalence is equality of normalized pushforwards, conditional probability identities, and direct versus sequential composition on the full marked state. The dynamical comparison is a coupling estimate for continuous paths, with identical retained discrete paths. It is not equality of a projected fine Markov law with an autonomous parent law.

## 1. Explicit carrier, graph, and normal flag

Put $b=2^{L-1}$, $n=3b$, and join $b$ triangles in a chain through portal vertices. There are $4b-1$ oriented independent links and

\[
x=(u,v,\alpha)\in\mathbb R^{10b-1},\qquad
d_i=u_i-v_i,\qquad r_e=u_i-u_j-\alpha_e.
\tag{R1}
\]

The link coordinates are independent variables. Setting $\alpha=Du$ is neither a definition nor an imposed constraint. The quadratic energy is the sum of the original squared discrepancies, with $J_1$ on all $d_i$ and triangle edges, and the assigned $J_s$ on each bridge level. Its matrix is $H\succeq0$. Its kernel is

\[
K=\{(t,t,Dt):t\in\mathbb R^n\},\qquad \dim K=n.
\tag{R2}
\]

Each triangle has one independent oriented loop coordinate. The $b$-dimensional loop subspace is orthogonal to the chosen normal rows and remains in every retention. The first normal rows consist of the $n$ node discrepancies and two independent residual contrasts per triangle, hence have rank $5b$. The remaining $b-1$ independent rows are bridge residuals, grouped by their binary merger level. Thus the full normal rank is $6b-1$, and $n+b+(6b-1)=10b-1$, which checks the dimension and exhausts the carrier.

Let $B_s$ be the normal row blocks and $P_s$ the orthogonal projection onto the common kernel of $B_1,\ldots,B_s$. Then $P_sP_p=P_s$ for $p<s$; all $P_s$ retain $K$ and every loop. In an orthonormal basis adapted to the nested row flag, the matrix of the independent rows is block lower triangular. Its diagonal blocks are invertible. Conjugation by the square roots of the descending weights puts factors $\sqrt{J_j/J_i}\le1$ into the relevant off-diagonal blocks of the matrix and its inverse. Finite dimension then gives

\[
c_L\operatorname{diag}(J_s I_s)\preceq H|_N
\preceq C_L\operatorname{diag}(J_s I_s).
\tag{R3}
\]

This calculation is the weighted flag argument in F3–F10; it does not assume separated eigenvectors of the unweighted graph. Schur complementation preserves these bounds, since its quadratic form is the minimum over eliminated coordinates. Write $H_p$ for the exact Gaussian Schur form after $P_p$. The current hidden block has restoring strength at least $c_LJ_s$, future blocks have size at most $C_LJ_{s+1}$, and retained loops have strength comparable to $J_1$. The root block is separate.

## 2. The normalized joint and the complete marked VFE

Fix $c\in(0,1)$, let $R=b_d^Tb_d/(1-c)$, and use the evaluator family from the normalized predecessor. Since the discrepancy energy contains $J_1b_d^Tb_d$,

\[
TR\preceq \frac{T}{J_1(1-c)}H\preceq \frac12H
\quad\text{when }T\le J_1(1-c)/2.
\tag{R4}
\]

Consequently $A_0=aH+P_K-TR$ is positive definite for $a\in[1,2.1]$, including on $K$, where it equals the identity. The prior $N(0,TA_0^{-1})$ is proper. The $K$-valued observation $O\mid x\sim N_K(P_Kx,(T/\kappa)I_K)$ is a density on its declared $n$-dimensional carrier. It is not treated as a positive ambient density on all of $\mathbb R^{10b-1}$. The calibration $Y\mid a\sim N(a,T)$, observed at $Y=2$, is normalized.

For every receiver, the two categorical probabilities sum to one. The success kernel

\[
p(S_i=1\mid x,J_i=j)=\frac12 e^{-\delta f(s_{ij})},\qquad
f(s)=1-e^{-s^2/2},\qquad s_{ij}=\sqrt{J_1/T}r_{ij},
\tag{R5}
\]

lies in $[e^{-\delta}/2,1/2]$; its complementary outcome is also strictly positive. The scaling is $s_{ij}^2/2=(J_1/T)\operatorname{KL}(N(u_i,1)\Vert N(u_j+\alpha_{ij},1))$. Multiplication by the prior, the normalized observations, all categorical and Bernoulli kernels, and all model/evaluator kernels therefore gives the normalized joint E5 by iterated integration. Conditioning on $O=z\in K,Y=2,S_i=1$ uses positive densities, not a claim that the exact continuous observation has positive atom mass.

Let $\mathcal J=\prod_i\mathcal N_i$, $\pi_j(a)=\prod_i\pi_{i,j_i}(a)$, and

\[
\phi_j(x)=\delta\sum_i f(s_{i,j_i}(x)),\qquad
0\le\phi_j\le D:=n\delta=10^{-4}.
\tag{R6}
\]

Writing $G_a=x^T[aH+(1+\kappa)P_K]x/2-\kappa z^Tx$, the full optimizing joint is

\[
\Pi_a(dx,j)=Z(a)^{-1}\pi_j(a)e^{-G_a(x)/T-\phi_j(x)}dx.
\tag{R7}
\]

Its physical counterpart uses $aH+(1+\kappa)P_K-TR$ in place of the optimizing precision. Summing R7 over $j$ gives exactly $e^{-G_a/T-\Phi_a}/Z$, where

\[
\Phi_a=-\sum_i\log\sum_j\pi_{ij}(a)e^{-\delta f(s_{ij})},
\qquad 0\le\Phi_a\le D.
\tag{R8}
\]

Thus the evidence and common scalar are the full integrals E9–E10. In particular, their ratio for the evaluator restriction is retained; replacing it with the old Gaussian determinant expression would be invalid. Gaussian bounds $e^{-D}Z_G\le Z\le Z_G$, R4, and compact $a$-intervals justify differentiation by domination. The derivatives are bounded functions times fixed-parameter Gaussian polynomials.

For any positive joint recognition law $Q(dx,j)=\lambda_jq_j(x)dx$, expansion of the normalized density gives

\[
\begin{split}
\mathcal F_T(Q,a)
={}&T\sum_j\lambda_j\int q_j\log q_j
 +T\sum_j\lambda_j\log\lambda_j
 +E_Q[G_a+T\phi_J]
 -T\sum_j\lambda_j\log\pi_j(a)\\
&+T\log Z_0(a)-T\log(c_Oc_Y2^{-n})
 +[\kappa|z|^2+(a-2)^2]/2\\
={}&T\operatorname{KL}(Q\Vert\Pi_a)+C_T(a).
\end{split}
\tag{R9}
\]

The root expectation already includes the linear term $-\kappa z^Tx$. The exact evaluator coupling cancels the prior's $-TR$ in the optimizing precision, as in the predecessor's explicit Gaussian conditional KL. Nothing in R9 sets the source recognition conditional equal to its optimizer. At fixed full $Q$, differentiation gives

\[
g(Q,a)=a-2+\frac12E_Qx^THx
-\frac T2\operatorname{tr}(A_0^{-1}H)
-T\sum_j\lambda_j\partial_a\log\pi_j(a).
\tag{R10}
\]

The active binary row has logit $4(a-3/2)$, so $|\partial_a\log\pi_j(a)|\le4$. The last term is bounded by $4T$ and cannot simply be omitted from a complete covector. The normalized full-experiment Fisher information is

\[
M(a)=T^{-1}+\frac12\operatorname{tr}[(A_0^{-1}H)^2]
+\operatorname{Var}_{\pi_{i_0}(a)}(t_J),\qquad (t_+,t_-)=(4,0).
\tag{R11}
\]

The Bernoulli kernel has no explicit $a$-derivative when $x,j$ are fixed. Conditional centering makes the cross terms among prior, calibration, and categorical scores vanish. The inherited scaled metric is $m=TM=1+O_L(T)\ge1$. Each parent uses this microscopic metric, rather than silently substituting its marginal Fisher information.

## 3. Nonlinearity and global parent curvature

For each fixed assignment, an undirected internal edge occurs at most twice. With $D_{\rm int}$ having rows $\sqrt{J_1}b_e$, $D_{\rm int}^TD_{\rm int}\preceq H$. Since $|f'|\le1$, $|f''|\le1$, and the edge multiplicities sum to $n$, direct differentiation gives

\[
|H^{-1/2}\nabla(T\phi_j)|\le \delta\sqrt{2nT},\qquad
-2\delta H\preceq D^2(T\phi_j)\preceq2\delta H.
\tag{R12}
\]

All norms here are on $K^\perp$, where $H$ is invertible. Source integration generates the familiar negative covariance in the Hessian of $T\Phi_a$; it is not absent. The component's bound $\eta=2(\delta+\delta^2)$, $G_0^2=2n\delta^2$ is a common upper bound adequate both before and after keeping the explicit assignments. In particular $\eta+G_0^2<1/2$ for every $n\ge6$ at the stated fixed $\delta$. No unspecified dimension-dependent smallness condition remains.

For a parent, Gaussian completion of the square gives $x=L_py+z$, $L_p^THL_p=H_p$, and $z$ centered with precision $aH_{EE}/T$. Define

\[
\phi_{p,a,j}(y)=-\log E_z e^{-\phi_j(L_py+z)}.
\tag{R13}
\]

This is the exact potential correction, bounded between $0$ and $D$. Differentiation under its dominated integral gives

\[
\begin{split}
\nabla(T\phi_{p,a,j})&=E_*L_p^T\nabla(T\phi_j),\\
D^2(T\phi_{p,a,j})&=E_*L_p^TD^2(T\phi_j)L_p
-T^{-1}\operatorname{Cov}_*(L_p^T\nabla(T\phi_j)).
\end{split}
\tag{R14}
\]

R12 bounds the first term and the covariance separately; R14 therefore yields relative force $G_0\sqrt T$ and lower Hessian $(a-\eta-G_0^2)H_p$. This proves global strong convexity of every hidden conditional, not merely convexity in a proposed formation region.

There is genuine nonquadratic dependence in a hidden coordinate. On any sheet choose a first normal direction with a selected internal residual $r_e(tv)=t\ell_e\ne0$. Since $f(s)=s^2/2-s^4/8+O(s^6)$, the fourth-order coefficient of $\phi_j(tv)$ is

\[
-\frac\delta8\sum_i (J_1/T)^2\ell_{i,j_i}^4<0.
\tag{R15}
\]

The Gaussian term has no fourth derivative. Every sheet selects internal edges and such a hidden direction exists by the first contrast construction. For the collapsed model E15 includes the additional nonpositive categorical variance term and is also strictly nonzero. This proves non-Gaussianity in the declared coordinates. The retained positive coefficient is the standardized thermal $\delta$; the result does not assert a fixed macroscopic nonlinear force while $T,A$ shrink.

A further bound is needed for conditional relaxation; global convexity alone is insufficient. The nonlinear source support involves only first-layer normals and loops. In residual coordinates for eliminated blocks, write the conditional precision as $D_E+C^TD_fC$, with the first diagonal block of $D_E^{-1}$ of order $J_1^{-1}$. The identity

\[
A^{-1}=D_E^{-1}(I-C^TD_fC A^{-1})
\tag{R16}
\]

and $|A^{-1}|\le C_L/J_p$, $|C^TD_fC|\le C_LJ_{p+1}$, give a first block row of order $J_1^{-1}$. Its mean response to future level $s+1$ is $O_L(J_{s+1}/J_1)$. Differentiating R13 using this response makes the loop/future mixed derivative $O_L(J_{s+1})$; normal current/future terms are no larger. This is N30–N34. Retained loops must be placed in the auxiliary fast block for this estimate. Treating them as slow coordinates would leave an unjustified large mixed derivative.

## 4. Actual dynamics, initial laws, and noncircular continuation

The declared state dynamics, on every sheet, are

\[
dX=-\nabla(G_a+T\phi_J)(X)dt+\sqrt{2T}dW,
\qquad J_t=J_0,\qquad
\dot a=-\epsilon m(a)^{-1}g(Q_t,a).
\tag{R17}
\]

For a parent, replace the continuous potential by the exact R13 parent and use its own current joint law in the derivative of $T\operatorname{KL}(Q_p\Vert\Pi_a^p)+C_T(a)$. The positive masses $\lambda_j$ are constant. Integration by parts in each continuous coordinate gives the actual dissipation

\[
\frac{d\mathcal F_T}{dt}
=-T^2\sum_j\lambda_j I(q_j\Vert\Pi_a(dx\mid j))
-\epsilon m(a)^{-1}g(Q,a)^2\le0.
\tag{R18}
\]

There is no missing categorical Fisher term: its mobility is explicitly zero. The full joint objective remains in R18, including the source conditional KL and categorical prior score.

Choose all sheet means $Av_j$ with $v_j$ in one sufficiently small neighborhood of the strict direction constructed in Section 6 below. Use Gaussian conditional covariance $T\widehat K_1^{-1}$, a common independent root law, and masses in an open neighborhood inside the positive simplex. Allow sufficiently small smooth compactly supported transport perturbations, measured both by a bounded smooth log-density ratio and by a coupling displacement less than $\epsilon\sqrt T$ in the $\widehat K_1$ norm. Such transports exist by choosing a compactly supported smooth vector field and reducing its coefficient until both its Jacobian and its displacement satisfy the strict bounds. The identity transport is an interior base point in this declared relative topology. Finite products over the finitely many sheets give a nonempty neighborhood with finite entropy, controlled quadratic and exponential moments, and strict residual margins. It is not an open ball in every conventional probability topology and not a temperature-independent neighborhood. A common product root is part of this admission.

For each fixed $\epsilon,T,L$, the sheet drifts are globally Lipschitz in the continuous variables and smooth in $a$ on a compact interval, with finite constants. The expectation of a quadratic is locally Lipschitz in a coupled $L^2$ metric on bounded second-moment sets, since

\[
|E X^THX-EY^THY|
\le\|H\|\bigl(\|X\|_2+\|Y\|_2\bigr)\|X-Y\|_2.
\tag{R19}
\]

The source derivatives in parent scores are smooth bounded Gaussian integrals for fixed parameters. Picard iteration on the finite vector of coupled sheet laws and the scalar parameter therefore gives a local solution. The following moment and inward-pointing bounds continue it through the whole interval. Positive-time elliptic smoothing on each sheet and positivity of its heat kernel preserve positive densities. Initial Gaussian tails, smooth bounded perturbations, and linear-growth drift permit cutoff integration by parts; moment bounds and positive-time smoothing justify passing to the limit in the entropy identities.

The continuation order matters. First assume only $a\in[1,2.1]$, without a bound on $\dot a$. On any active normal/loop block couple the nonlinear process to the linear process with the same actual initial state, Brownian noise, and coefficient $a(t)$. The latter need not initially be Gaussian. Their difference satisfies

\[
H_p^{1/2}e(t)=-\int_\tau^t H_p e^{-H_p\int_s^t a(u)du}
H_p^{-1/2}\nabla(T\phi_{p,a_s,J})(X_s)ds.
\tag{R20}
\]

For extreme eigenvalues $m_0,\Lambda_0$ of $H_p$, spectral maximization and splitting at $1/\Lambda_0,1/m_0$ give

\[
\int_0^\infty\|H_pe^{-H_pu}\|du
\le C[1+\log(\Lambda_0/m_0)].
\tag{R21}
\]

R12–R14 thus imply $e^TH_pe\le C_LT(1+\log J_1)^2$. If the actual initial second-moment matrix about the quadratic center is at most $K_\tau T H_p^{-1}$, the exact linear stochastic integral bounds its later counterpart by $(K_\tau+1)TH_p^{-1}$. The inequality $ee^T\preceq(e^TH_pe)H_p^{-1}$ then gives N16d. At a retention, the projected inverse equals the inverse Schur complement. These actual moment bounds therefore propagate over a finite number of activations. They do not require a speed bound, equilibrium initialization, or conditional relaxation.

The resulting current energy is at most $C_L[A^2J_1+T\ell^2]$, where

\[
\ell=1+|\log T|+\log J_1+|\log A|.
\tag{R22}
\]

At a parent, completing the square yields the full covector

\[
g_p=a-2+\sum_j\lambda_jE_{q_{p,j}}V_p
+T\sum_j\lambda_jE_{q_{p,j}}\partial_a\phi_{p,a,j}
-T\sum_j\lambda_j\partial_a\log\pi_j(a)+c_p(a,T),
\tag{R23}
\]

where $V_p=y^TH_py/2$ and

\[
c_p=-\frac T2\operatorname{tr}(A_0^{-1}H)+\frac{k_pT}{2a}=O_L(T).
\tag{R24}
\]

The derivative of the parent deformation is uniformly bounded: differentiating its centered Gaussian measure gives score $(k_p-|Z|^2)/(2a)$, whose Gaussian $L^2$ norm is finite; the tilt has density ratio between $e^{-D}$ and $e^D$. Its centered expectation under the tilt is bounded by $(e^D-1)\sqrt{k_p}/(\sqrt2a)$. At the microscopic sheet level $\partial_a\phi_j=0$. This checks the complete determinant and source terms in R23.

R11 and the actual moments now imply

\[
\dot a=\epsilon(2-a)+\epsilon R_t,
\qquad |R_t|\le r_\epsilon:=C_L[A^2J_1+T\ell^2].
\tag{R25}
\]

For $r_\epsilon<0.1$, both endpoint velocities point inward at $1$ and $2.1$. Continuation closes and gives $|\dot a|\le C_L\epsilon$. Starting at $a(0)=1$, variation of constants yields $a(2/\epsilon)\ge2-e^{-2}-r_\epsilon>1.5$. Two own-law processes starting from a common activation parameter differ by at most $2r_\epsilon$, because their difference satisfies the stable scalar equation with forcing bounded by $2\epsilon r_\epsilon$. This bound does not feed a parent's source law into its update. Using F22–F30, which already invoke a speed bound in part, as the only justification of this bootstrap would be circular; N16a–N16d and R20–R21 remove that dependency.

## 5. Conditional KL and complete score, including the marks

For each source sheet and exact parent, write $p_{p,a,j}\propto e^{-aV_p/T-\phi_{p,a,j}}$. These are bounded tilts of centered Gaussian normal/loop laws, so

\[
E_{p_{p,a,j}}e^{aV_p/(2T)}\le e^D2^{d_p/2}=:R_L.
\tag{R26}
\]

The entropy variational inequality, proved by nonnegativity of KL to the exponentially tilted density, gives

\[
E_q V_p\le \frac{2T}{a}[\operatorname{KL}(q\Vert p_{p,a,j})+\log R_L].
\tag{R27}
\]

If $H=T\operatorname{KL}(q\Vert p_{p,a,j})$, its differentiation along the actual diffusion and moving parameter yields

\[
H'\le -T^2I(q\Vert p_{p,a,j})
+\frac{2|\dot a|}{a}(H+C_LT).
\tag{R28}
\]

The bounded parent score in R23 is included in the constant. For the full joint, optimizer masses are $\rho_j(a)=\pi_j(a)Z_j(a)/\sum_k\pi_k(a)Z_k(a)$. Their ratio to $\pi_j$ is bounded by $e^{\pm D}$, and the finite positive source rows are bounded away from zero on the compact parameter interval. Hence $T\operatorname{KL}(\lambda\Vert\rho(a))=O_L(T)$. The joint normalized moving score adds the centered $\partial_a\log\pi_j$, bounded by four. Applying R27 to the disjoint union or summing the conditional-sheet balances proves the same finite-horizon budget, with no categorical dissipation. Common-channel projection at a fixed $a$ decreases the joint KL exactly. Since $\int|\dot a|/a=O_L(1)$ over $2/\epsilon$, the integrating factor in R28 gives

\[
T^2\int_\tau^{2/\epsilon}I_y(t)dt
\le C_L[H(\tau)+T].
\tag{R29}
\]

Here $I_y=E_q|\nabla_Y\log(q/p)|^2$ is the retained-coordinate part of the full joint relative Fisher information, and is bounded by the full dissipation in R28. It is not the marginal relative Fisher information $I(r\Vert p_Y)$, which need not satisfy that bound without a correction.

Actual activation entropy is needed in R29. For a $d$-dimensional actual sheet density and potential with $\Delta U\le d\Lambda$, entropy differentiation and the Gaussian entropy/Fisher inequality give

\[
h'=TI(q)-E\Delta U
\ge2\pi edT e^{-2h/d}-d\Lambda,
\quad
h(t)\ge\min\{h(\tau),\tfrac d2\log(2\pi eT/\Lambda)\}.
\tag{R30}
\]

The Fisher inequality follows by expanding Gaussian LSI for arbitrary variance and minimizing at $\sigma^2=d/I(q)$; no log-concavity of the actual law is assumed. If $x=(y,z)$, then $h(y)\ge h(x)-h(z)$, and the Gaussian maximum-entropy bound gives $h(z)\le(k/2)\log(2\pi eE|z|^2/k)$. Expanding the retained Gaussian log density and using the bounded tilt adds at most $TD$. R20–R22, $\Lambda\le C_LJ_1$, and the finite number of projections therefore prove

\[
H_p(\tau_p)\le C_L[A^2J_{p+1}+T\ell^2].
\tag{R31}
\]

This bound concerns the actual projected sheet densities and, after summing with the fixed masses, the actual full marked law.

At transition $s$, take future normals as $Y$, and take the current hidden normals together with all retained loops as an auxiliary fast variable $Z$. Condition on the retained assignment $J$. The true parent still retains both the loops and $J$; the ordinary conditional chain rule gives $\Delta_s\le\widehat\Delta_s$, where the latter additionally conditions the loop distribution on its optimizer. R3, R14, and R16 give conditional curvature $\lambda_s=c_LJ_s$ and mixed derivative $\Gamma_s=C_LJ_{s+1}$. At the last layer there is no future normal, so $\Gamma_L=0$.

The precise LSI used is: a $C^2$ potential $W$ on $\mathbb R^k$ with $D^2W\succeq\lambda I>0$ gives $\operatorname{KL}(q\Vert e^{-W/T}/Z)\le T I/(2\lambda)$. Here $W$ is each global conditional potential from R14. One may derive it by entropy dissipation and gradient contraction of $T\Delta-\nabla W\cdot\nabla$. The normalizations agree with [Gentil, Remark 3.2 and Theorem 3.3](https://arxiv.org/pdf/1009.3421), using $\psi=W/T$ and curvature $\lambda/T$; the stated result and its proof were inspected directly. This is the only standard convex-diffusion inequality used here. Quadratic domination, smoothness, and cutoff approximation check its regularity hypotheses.

For completeness, the conditional entropy estimate can be reconstructed directly. Let $r=q_Y$, $\rho=p(Z\mid Y,J)$, $w=\nabla_Y\log(q/p)$, $u=\nabla_Y\log(r/p_Y)$, and $h=E_{q(Z\mid Y,J)}\nabla_Y\log\rho$. Conditional normalization gives $E_{q(Z\mid Y,J)}w=u-h$. Subtracting the marginal entropy derivative from the full derivative gives, for fixed $a$,

\[
\widehat\Delta'=-T I_Z
-T E_r\operatorname{Var}_{q(Z\mid Y,J)}(w)
+T E_r[h\cdot E_{q(Z\mid Y,J)}w].
\tag{R32}
\]

Conditional LSI and its exponential-moment consequence for Lipschitz functions bound

\[
|h(Y,J)|\le\Gamma_s\sqrt{2\operatorname{KL}(q(\cdot\mid Y,J)\Vert\rho)/(\lambda_sT)}.
\tag{R33}
\]

The parameter derivative is controlled by the centered conditional score. In Gaussian standardized coordinates it is a centered quadratic $-|Z|^2/(2a)$, plus a uniformly bounded parent source derivative. Bounded density ratios and Gaussian quadratic exponential moments give finite constants $v_L,b_L$, independent of $T,J_s$, such that

\[
\log E_\rho e^{t(S-E_\rho S)}\le
\frac{v_Lt^2}{2(1-b_L|t|)},\qquad |t|<b_L^{-1}.
\tag{R34}
\]

For example, expanding moments of the Gaussian quadratic gives a bound of the form $M k!B^k$; the bounded tilt multiplies $M$ by a finite constant, the bounded additive term changes $B$, and centering changes these constants again. Optimizing the entropy variational inequality with R34 yields the mean-score discrepancy $\sqrt{2v_L\Delta}+b_L\Delta$. All prior source weights and joint normalization factors cancel from the hidden conditional at fixed $Y,J$.

Using $-TI_Z\le-2\lambda_s\widehat\Delta$, conditional Jensen to bound $E_r|E_{q(Z\mid Y,J)}w|^2$ by $I_Y$, two applications of Young's inequality in R32–R34, and $b_L|\dot a|\le\lambda_s/2$, gives

\[
\widehat\Delta'
\le-\frac{\lambda_s}{2}\widehat\Delta
+\frac{T\Gamma_s^2}{\lambda_s^2}I_Y
+\frac{v_L|\dot a|^2}{\lambda_s}.
\tag{R35}
\]

Summing this inequality over fixed $\lambda_j$ is legitimate; there is no moving sheet-mass derivative. R29, R31, and variation of constants now give the exact scaling in N36:

\[
\begin{split}
\Delta_{s-1:s}(t)\le C_L\bigl[&e^{-c_LJ_s(t-\tau_{s-1})}
\{(A^2/T)J_s+\ell^2\}\\
&+(A^2/T)J_{s+1}^2/J_s
+\ell^2J_{s+1}^2/J_s^2+\epsilon^2/J_s^2\bigr].
\end{split}
\tag{R36}
\]

The two future terms are zero for $s=L$. Finally, differentiating the exact conditional-KL chain rule at fixed full $Q$, retained law, and parameter gives the complete covector discrepancy as the expectation of this centered hidden score, multiplied by $T$. Thus

\[
|g(Q,a)-g_s((P_s,\mathrm{id})_\#Q,a)|
\le T[\sqrt{2v_L\Delta_s}+b_L\Delta_s].
\tag{R37}
\]

This includes the full source score because that score cancels between the two sides, rather than because it was excluded from either objective. R37 is a same-state comparison; the independent own-law comparison is R25.

## 6. Formation, a common regime, and two actual reductions

Choose $v\in N$ away from the finite collection of hyperplanes where a required current or future residual $b_eP_sv$ vanishes. These linear functionals are nonzero by independence of the normal rows. A finite union of their proper kernels cannot fill $N$: explicitly evaluate a basis polynomial vector $(1,t,\ldots,t^{\dim N-1})$ and avoid its finitely many nonzero polynomial roots. Normalize the resulting vector and take a sufficiently small neighborhood. It gives a common positive residual margin $m_L$. This is the prepared open set in the statement, not a claim that arbitrary initial laws produce the same hierarchy.

For the Gaussian companion after activation, split current fast and future mean coordinates. Its fast block obeys a stable equation with rate $c_LJ_s$ and forcing $O_L(AJ_{s+1})$. Its future derivative is $O_L(AJ_{s+1})$. Variation of constants therefore gives the current discrepancy

\[
C_LA[e^{-c_LJ_s(t-\tau_{s-1})}+J_{s+1}/J_s],
\tag{R38}
\]

while the future means remain close to $AP_sv$ throughout the current episode. Past normal rows vanish after their fixed projections; their original conditional residuals are recovered using the corresponding reverse kernels. Once R25 supplies $|\dot a|\le C_L\epsilon$, covariance comparison for the Gaussian companion, or its exact commuting propagator, controls its normal fluctuations by $C_LT H_p^{-1}$. The initial root and loop centers are zero in their normal/loop parts. Exponential Gaussian estimates on time intervals of length at most $2/\epsilon$ give the maximal residual probability bound in F34. The same-coefficient nonlinear difference satisfies

\[
\sup_{t\le2/\epsilon}|X-X^G|
\le |e_0|+C_L\sqrt{T/\epsilon},\qquad
\sup_t e^TH_pe\le C_LT(1+\log J_1)^2.
\tag{R39}
\]

The first follows by dissipating the quadratic difference energy and integrating the bounded dual force; the second is R20–R21. Both survive projection. These estimates hold on each sheet with the same constants, so averaging over the positive masses preserves the probability bound without any Gaussian assumption on the unconditional mixture.

Use the single regime

\[
q_L=0,\quad q_s=2q_{s+1}+20,\quad J_s=\epsilon^{-q_s},\quad
A^2=\epsilon^{3q_1+20},\quad T=A^2\epsilon^6,
\quad H_*=2/\epsilon.
\tag{R40}
\]

Then $A^2/T=\epsilon^{-6}$, $J_{s+1}^2/J_s=\epsilon^{20}$, $A^2J_1=\epsilon^{2q_1+20}$, and $\ell=O_L(\log(1/\epsilon))$. All positivity admissions, $r_\epsilon<0.1$, and the conditional score-speed condition hold for sufficiently small positive $\epsilon$. The coefficient $\delta=10^{-4}/n$ is independent of $\epsilon$.

Set $t_s=k_L\log(1/\epsilon)/J_s$, $I_s=[t_s,2t_s]$, and $\tau_s=2t_s$. Taking the finite constant $k_L$ large enough pays for both the initial entropy exponent in R36 and the mean exponent in R38. For small $\epsilon$, $\tau_{s-1}<t_s/2$ and $\tau_L<H_*$. On $I_s$, current and past residuals are below a chosen small multiple of $A$, while future bridge residuals exceed a different fixed multiple of $A$. R39 divided by $A$ is $O_L(\epsilon^{5/2})$, so it does not destroy the strict margin. The exceptional probability is at most

\[
C_L(1+2/\epsilon)e^{-c_L\epsilon^{-6}}.
\tag{R41}
\]

At the last level there are no future bridges and coherence persists to $H_*$. Physical hidden conditionals are bounded Gaussian tilts, with cumulative hidden precision at least $c_LJ_p$. Completing the physical conditional square gives the original eliminated residual second moment bounded by

\[
C_L[A^2(J_{p+1}/J_p)^2+T/J_p].
\tag{R42}
\]

The $TR$ correction has no new future or loop coupling and obeys R4. Thus the original physical residual interpretation survives the parent operation. R42 is an RMS statement about original Gaussian edge residuals, not a claim that a mixture KL equals the KL of averaged means.

In R36 the forcing term $(A^2/T)J_{s+1}^2/J_s$ is $\epsilon^{14}$, the logarithmic term is smaller, and the terminal moving-target floor is $O_L(\epsilon^2)$. Choosing $k_L$ as above removes the potentially large activation entropy. Consequently, throughout each post-entrance interval up to $H_*$,

\[
\Delta_{s-1:s}\le C_L\epsilon^2,\qquad
|g-g_s|\le C_LT\epsilon.
\tag{R43}
\]

For $L=2$, there are six vertices, seven independent links, two retained loops, and $19$ continuous coordinates. The first normal rank is $10$, and the second is $1$, giving

\[
\mathbb R^{19}\times\mathcal J
\longrightarrow\mathbb R^9\times\mathcal J
\longrightarrow\mathbb R^8\times\mathcal J,
\qquad |\mathcal J|=64.
\tag{R44}
\]

The actual coherence counts are $6\to2\to1$. Here $J_1=\epsilon^{-20},J_2=1,A=\epsilon^{40},T=\epsilon^{86}$. The intervals have orders $\epsilon^{20}\log(1/\epsilon)$ and $\log(1/\epsilon)$, both inside $2/\epsilon$. General finite depth has counts $3\cdot2^{L-1}\to2^{L-1}\to\cdots\to1$.

## 7. Exact marked parents and the positive-change discriminators

Every retention is $\mathcal C_s(x,j)=(P_sx,j)$. For any normalized source law $P$, define its parent as $\mathcal C_{s\#}P$. Its positive densities specify physical, optimizing, and actual reverse kernels separately. For $p<s$, $\mathcal C_s\mathcal C_p=\mathcal C_s$, so integrating a positive joint density in either order gives the same normalized parent and the same joint mark statistics. Receiver occupancy is $1/n$; selected-source readout is applied to the retained full assignment. If extra event or occupancy marks are random, their weights and conditional marks are integrated together against this joint law. Separately multiplying an averaged event weight and an averaged membership kernel would generally violate this identity.

The exact optimizer entropy identity is

\[
\operatorname{KL}(Q\Vert\Pi_a)
=\operatorname{KL}(\mathcal C_{s\#}Q\Vert\mathcal C_{s\#}\Pi_a)
+\sum_j\lambda_jE_{q_j^y}
\operatorname{KL}(q_j(dx_{\rm hidden}\mid y)\Vert\Pi_a(dx_{\rm hidden}\mid y,j)).
\tag{R45}
\]

At activation the entire actual joint is pushed forward and its parameter copied. Its conditional source law is not replaced by the optimizer. The parent then evolves its own conditional sheet densities under R17 and R23. This establishes the full marked interface omitted by the earlier collapsed construction: generally $E_{Q(dx_{\rm hidden}\mid y)}\beta(j\mid x)\ne E_{\Pi_a(dx_{\rm hidden}\mid y)}\beta(j\mid x)$, so a collapsed parent initialized with the latter row would not inherit the former actual law. R45 and the retained source state avoid that substitution.

The posterior row of the active binary source obeys

\[
\operatorname{logit}\beta_+(x,a)
=4(a-3/2)-\delta[f(s_+)-f(s_-)].
\tag{R46}
\]

At $a=1$, its value is at most $\operatorname{sigmoid}(-2+\delta)$; at the learned endpoint $a\ge1.5$, it is at least $\operatorname{sigmoid}(-\delta)$. Since the sigmoid derivative is at most $1/4$ and $e^2>7$, their difference exceeds $3/8-\delta/2>0.37$. The inequality is pointwise at both endpoints, so averaging under two different actual continuous laws preserves it. Binary-row total variation equals that difference. This is changing model-posterior attention. The actual assignment masses remain constant, and the actual force weights are $Q_t(J=j\mid X=x)$, not $\beta_j(x,a)$. The force still contains the selected true residual likelihood $-T\nabla\phi_J$, and its unconditional mixture uses the actual joint law. Thus the distinction does not remove the source-dependent force or replace it by an independent diagnostic.

For the first eliminated conditional, compare initial $a=1$ and final $a_f\ge1.5$ at any fixed retained $(y,j)$. The optimizing Gaussian hidden precision increases by at least a factor $1.5$. For the physical precision, write $D_1=F-TR\preceq F$ and $D_f=D_1+(a_f-1)F\succeq1.5D_1$. The same order survives Schur complementation if an earlier block has been eliminated, by its quadratic minimum characterization. The precision comparison does not require commuting $R$ and $F$.

If the precision ratio is at least $r>1$ in $k\ge1$ dimensions, direct Gaussian integration, including arbitrary means, bounds Hellinger affinity by $[2\sqrt r/(1+r)]^{k/2}$; differing means only reduce it. Each bounded nonlinear tilt changes normalized density by a factor in $[e^{-D},e^D]$, so joint affinity is at most $e^D$ times this Gaussian bound. Jensen's inequality gives $\operatorname{KL}(P\Vert Q)\ge-2\log\int\sqrt{pq}$. Taking the conservative $r=5/4$ yields

\[
\operatorname{KL}(P_1(\cdot\mid y,j)\Vert P_f(\cdot\mid y,j))
\ge \frac{k}{2}\log(81/80)-2D>\frac1{200}.
\tag{R47}
\]

Indeed $\log(81/80)>1/81$ makes the last strict inequality elementary already at $k=1,D=10^{-4}$. R47 holds for both physical and optimizing conditionals, uniformly over the retained value and source assignment. R43 controls closeness to the current optimizing conditional; it does not assert that this current conditional is unchanged. These two assertions are compatible.

## 8. Separate approximation of an independent parent's path

Conditional KL does not imply the required path result. A direct dissipative comparison supplies it. Center each actual process at its deterministic nonlinear drift solution. R14 gives uniform strong monotonicity, while the root is a separate contracting process. For a small fixed $\theta>0$, applying Itô's formula to $\exp(\theta|X-x_*|^2/T)$ gives a drift at most $-c_L\exp(\theta|X-x_*|^2/T)+C_L$. Stopping at radius $r$ and integrating the resulting supermartingale estimate yields a failure bound $C_L(1+H_*)e^{-c_Lr^2/T}$. The admitted initial laws have the necessary uniform exponential moment, and projection cannot increase the displacement. Take $r=A\epsilon^2$; then $r^2/T=\epsilon^{-2}$.

The deterministic nonlinear center differs from its quadratic center by $O_L(\sqrt T)$, because the energy-dual force is $O_L(\sqrt T)$ and

\[
\int_0^\infty\|e^{-a_-H_pu}H_p^{1/2}\|du\le C_L
\tag{R48}
\]

when the smallest retained normal/loop rate is bounded below. Near zero the integrand is $O(u^{-1/2})$, which is integrable, and at infinity it decays exponentially. For a source block and its exact Schur parent at the same coefficient, eliminating a stable fast block gives a deterministic retained-center error at most

\[
C_LA[J_{s+1}/J_s+H_*J_{s+1}^2/J_s].
\tag{R49}
\]

The first term is the integrated initial fast transient; the second is the future slow residual from the Schur completion. At the terminal layer they vanish. These are the block estimates N44–N48 and F42–F44. If coefficients differ by $\chi$, the exact quadratic propagators are functions of the same fixed $H_p$; eigenwise differentiation gives $\lambda t e^{-a_-\lambda t}\le1/(ea_-)$, hence a center perturbation at most $C_LA\chi$, without $J_1H_*$ in an exponential.

An independently activated parent has its own law and coefficient, but R25 gives $\chi\le2r_\epsilon$. Couple its initial continuous state to the actual projected source state and its initial source assignment identically. Keep that assignment unchanged on both paths and couple the common root exactly. The concentration estimates may be applied separately to the two continuous normal processes, so no unproved identity of their effective noises is needed. R48–R49, inherited initial coupling errors from R39, and a union bound give

\[
\Pr\left\{\sup_{[\tau_s,H_*]}
|P_sX-\overline X_s|>C_LA\epsilon^2\right\}
\le C_L(1+2/\epsilon)e^{-c_L/\epsilon^2}.
\tag{R50}
\]

Here R40 makes $H_*J_{s+1}^2/J_s=2\epsilon^{19}$, $\sqrt T/A=\epsilon^3$, and $r_\epsilon=o(\epsilon^2)$. The retained label discrepancy is identically zero in the metric $|y-\bar y|+\mathbf1_{j\ne\bar j}$. Finite sequential replacements telescope R50 with constants depending on $L$. This proves the required path approximation of own-law parents and retains exact equality only for the common label paths and the static probability identities.

## Skeptical checks, domain audit, and coverage

The principal defect found during this reconstruction was the collapsed source-row activation mismatch exhibited before R46. A positive continuous parent initialized from the actual marginal does not automatically inherit the actual marked law. E24–E29 and the explicit retained sheets repair this within the frozen target. The model-posterior row is now stated with its correct meaning. A stronger requirement that the recognition assignment masses adapt, or that the posterior row itself weight the actual nonequilibrium force, is not proved by this realization.

The second rejected shortcut was closing the parameter interval with moment arguments that already used a parameter-speed bound. R20–R25 instead establish the moment estimate using only the candidate interval, then prove the speed and inward-pointing conditions. Other attempted failure modes do not produce a counterexample to this admitted construction: the normal prior is positive by R4; the loop rate is handled in the auxiliary fast block; the Gaussian conditional is not substituted for its nonlinear tilt; the activation entropy is paid from actual projected densities; exact probability composition is not used to infer exact path closure; and a missing theorem at arbitrary coupling or arbitrary initial law is outside the quantified claim.

The mathematical domain remains one fixed $c_*$. Passive changes of presentation push forward all coordinates, probability laws, reference parameters, retentions, and metrics together; the probability diagrams and KL are invariant under this invertible change of variables. The fixed centered proper prior is not invariant under an active translation holding its parameters fixed. No normalized noncompact Haar prior is used. Independent network links and loops survive, and no base path, spatial transport, or connection descent appears. Unit continuous mobility and the inherited model metric are a chosen common kinetic prescription. The argument makes no physical-clock or scale-clock claim and no statement about resource savings, permanent intermediate groups, unbounded $L$, or arbitrary nonlinear strength.

An oracle-erasure pass removes the author's desired outcome, the target's affirmative wording, predecessor verdicts, and investigator agreement from the argument. What remains load-bearing is R1–R4 and the weighted flag; the positive normalized joint and exact integrals R5–R11; differentiated bounded tilts R12–R16; actual dynamics and the noncircular moment bootstrap R17–R25; entropy, conditional score, and mixing bounds R26–R37; explicit exponents and strict residual margins R38–R44; joint conditioning and lower bounds R45–R47; and the separate dissipative path comparison R48–R50. Each can be checked without assuming the proposed conclusion. The older component reconstruction of E1–E23 remains evidence for those static and collapsed calculations only; it cannot by itself certify the new marked generator.

| Claim | Reconstructed support | Scope of conclusion |
|---|---|---|
| c1: normalized law | R4–R11; E1–E10 and E24–E26 | Smooth positive normalized joint, physical/optimizing distinction, full evidence and complete covector. |
| c2: nonlinear curvature and marginals | R12–R16; E11–E15, N20–N34, M7–M9 | Fixed nonzero standardized deformation; global parent curvature and the required mixed bound. |
| c3: well-posedness and actual learning | R17–R25; N16a–N16d, N43a, N52–N58 | Actual own-law solution on the common interval, complete dissipation, inward parameter interval and endpoint $a>1.5$. |
| c4: formation and activation | R30–R31, R38–R44; F22–F41, M10–M13 | $L$ sequential actual episodes on the stated initial-law neighborhood, with explicit $L=2$. |
| c5: conditional entropy and score | R26–R37, R43; N1–N37 and N57–N58 | Global conditional KL and complete same-state covector bounds through $2/\epsilon$, initialized from actual laws. |
| c6: exact marked parents | R13, R45; E29, N56, M4–M6 | Exact common-channel laws and compositions with source assignments and loops retained; no conditional reset. |
| c7: positive changes | R46–R47; E22–E23 and their sheet extension | Posterior row TV $>0.37$; physical and optimizing hidden conditional KL $>1/200$. |
| c8: own-law paths | R25, R48–R50; N44–N51, N56 and M14 | Approximate continuous paths for independently learning parents; identical categorical paths. |
| target | R1–R50 in the single regime R40 | The frozen finite-depth existence target under the explicit admissions above. |

The strongest supported result is a reconstructed proof of this finite-depth existence construction, including full marked activation, with the stated posterior-attention meaning and zero categorical mobility. No missing mathematical obligation remains for that scoped target in the recorded components. The minimal next strengthening is to permit a nonzero source-label mobility while preserving the actual marked activation and to prove the resulting label/configuration entropy and force estimates. That would materially change the present kinetic restriction; it is not a consequence of this proof.

## Executed checks and artifact binding

The work was analytical reconstruction and direct source inspection. PowerShell read-only searches, file reads, and SHA-256 calculations were executed. The contract target digest was recomputed from canonical sorted compact JSON using `C:/Python314/python.exe` and its standard library, agreeing with the frozen digest above; this identifies the target and does not prove it. A final read-only document check counted 50 paired displays, the ordered distinct equation tags R1–R50, no unmatched inline math delimiters, no forbidden spacing macros, and seven source bindings matching the table below. These outputs are recorded in this paragraph; they are document and revision checks. The named Gentil LSI statement and proof were opened at the primary author paper linked above. The written mathematical output is this file. No numerical trajectory, finite test, agent agreement, or hash equality is used as proof. No GPU, scientific rerun, full suite, Lean, tamper check, source-component edit, vault edit, or Git action was performed by this checker.

The following SHA-256 values bind the source snapshot inspected in this reconstruction. They are revision diagnostics, not mathematical acceptance criteria.

| Source relative to this directory | SHA-256 |
|---|---|
| `nonlinear-endpoint-attention-model.md` | `725539e6e47d36bc27e54c42ea98602fbbe78a9f96f8aef1c833a0fd3c6e1f1e` |
| `nonlinear-adaptive-conditional-route.md` | `ebe3e146bab715bdeaa205c091461f4610e0d110effca0820f0d29f06ce65881` |
| `nonlinear-cyclic-formation-route.md` | `484f7fe08bbd3e0ecda3f03d386dc211f48ae9698cffd6d1bff52be77b47748b` |
| `nonlinear-adaptive-attention-completion.md` | `bab26dca4b4ede39a0b4e0fb46930020e32a9ad87ba676206ea3b16ecc8dd6ab` |
| `nonlinear-adaptive-attention-target.md` | `30518725d102da7a3b14d61bc0400d40831bf1733f4626ad84498884765c2034` |
| `evidence/2026-09-13-nonlinear-adaptive-attention-rg/problem-contract.json` | `f676ba9691cd48358a91115e9fc5d58d2e59c5919e998c9dcfaa12715d7150ea` |
| `../../reviews/2026-09-13-program-review-next-phase/independent-verification.md` | `55a1a8e372de195c9287257434d61a01d0a2d741a1b8daa6a064ed7f3b2d40d3` |
