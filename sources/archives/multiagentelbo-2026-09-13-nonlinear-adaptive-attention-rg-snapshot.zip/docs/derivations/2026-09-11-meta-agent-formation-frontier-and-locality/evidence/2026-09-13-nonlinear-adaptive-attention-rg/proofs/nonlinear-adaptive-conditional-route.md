# Nonlinear conditional control and independently learning parents

September 13, 2026. This construction lane belongs to the frozen target
`contract-sha256-3c854d92121f9f831556ef66aac508593cab131a3ca76dfea2be63996d3a901a`.
Its scope is a finite cyclic weighted flag at one fixed base point. This document
derives estimates for actual nonlinear densities. A Gaussian law is used as a
reference and a comparison process; no Gaussian covariance evolution is asserted
for the nonlinear law.

Sections 1–11 first establish the conditional estimates for collapsed continuous
configuration dynamics. Section 12 specifies the actual explicit-source-sheet
realization used to close the full marked activation interface. Its labels are
retained static sheets, its conditional configuration forces remain nonlinear,
and its posterior attention is distinguished from its recognition conditional.
The collapsed process remains a proved comparison construction; it is not
identified with the actual source-sheet process.

The source boundary is [the current gate](../../STATUS.md),
[the frozen target](nonlinear-adaptive-attention-target.md),
[the preceding conditional argument](adaptive-conditional-bounds.md),
[the normalized model](adaptive-normalized-model.md), and
[the cyclic flag](adaptive-cyclic-witness.md). The moving-conditional balance,
complete score identity, and finite-horizon entropy budget are existing results:
equations D1–D26 of [the dynamics review](../../reviews/2026-09-13-program-review-next-phase/dynamics-frontier-review.md)
and Sections 5–6 of [its reconstruction](../../reviews/2026-09-13-program-review-next-phase/independent-verification.md).
The new work below supplies bounded-tilt score tails, an actual activation-entropy
conversion, and the auxiliary fast-block treatment of retained loops.

The live [staged hierarchy synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Staged hierarchy formation and RG composability.md>)
and [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>),
`sec:timescales`, `eq:rg_reduced_hessian`, and the adjoining force-closure discussion,
were read first. The microscopic learning split is imposed. The reduced-attention
Hessian includes its negative covariance term. Small scalar free-energy error does
not establish a small force. These source distinctions are retained.

## 1. Target, realization, and additional admissions

The parent task asks, for every fixed finite integer L at least two, for an
exhibited cyclic family with L actual reductions, changing normalized source
attention and hidden physical and optimizing conditionals, exact marked parent
laws, and vanishing conditional, score, and path errors on an interval of length
c/epsilon. Nonlinear coefficients and the amount of row variation must remain
positive in the error limit. This lane supplies implications usable by that
construction; formation and the normalized generative record are supplied by
their corresponding components, not inferred from these estimates.

Use orthogonal Euclidean configuration coordinates with a fixed positive
temperature T and common microscopic mobility I. The parameter a is in a compact
interval I=[a_-,a_+] contained in (0,infinity). The actual continuous equations are

\[
 dX_t=-\nabla U_{a_t}(X_t)dt+\sqrt{2T}dB_t,
 \qquad
 \dot a_t=-\epsilon h(a_t)^{-1}g(Q_t,a_t),
 \qquad Q_t=\operatorname{Law}(X_t).
 \tag{N1}
\]

Here B is standard Brownian motion, h is the inherited microscopic model metric,
and g is the complete normalized VFE covector, including every scalar normalizer
and calibration term. The parameter is deterministic for the exact-law system.
There is no discretization, particle-gradient approximation, or implementation
claim. Exact equality concerns normalized common-channel pushforwards and their
composition. Independently evolving parent paths require a separate coupling.

All statements use global Euclidean product carriers, smooth potentials with
bounded Hessian for each fixed positive T and finite set of weights, quadratic
confinement, and smooth positive initial densities with finite entropy and
exponential quadratic moments. These hypotheses justify the displayed
integrations by parts by cutoff and dominated convergence. No compact-face
current is discarded. The weighted upper Hessian may diverge with the largest
weight; all dependence on that divergence is displayed below.

The admitted nonlinear source construction has

\[
 U_a(x)=U_a^G(x)+T\Phi_a(x),\qquad
 0\le\Phi_a\le D,\qquad |\partial_a\Phi_a|\le M,
 \tag{N2}
\]

with D,M independent of T and the weights. For the proposed finite-source
Bernoulli-success record, each row contributes

\[
 \Phi_{i,a}=-\log\sum_j\pi_{ij}(a)
       e^{-\delta f(s_{ij})},\qquad
 f(s)=1-e^{-s^2/2},\qquad s_{ij}=\sqrt{J_1/T}r_{ij}.
 \tag{N3}
\]

The two candidate neighbors in every added source row are internal neighbors in
the same triangle. No added row mixes an internal edge and a bridge. Thus Phi
depends on first-layer normals and retained triangle loops, and annihilates all
future normal layers and the compatible root sector. This restriction is part of
the admitted family. A row mixing levels can have a covariance-Hessian cross term
of order sqrt(J_1 J_next); its mixed derivative is not automatically O(J_next).

The coefficient delta is fixed and positive. The bound D is the number of source
rows times delta. If all source log-prior derivatives have absolute value at most
M_0, then |partial_a Phi| is at most the number of rows times M_0. Differentiating
the finite normalized sum, rather than freezing its weights, gives

\[
 T\nabla^2\Phi_i
 =T\delta E_{\beta_i}\nabla^2 f
  -T\delta^2\operatorname{Cov}_{\beta_i}(\nabla f,\nabla f).
 \tag{N4}
\]

Consequently the fixed delta must lie inside the positive relative-curvature
margin of the complete quadratic form. The normalized-model component verifies
that margin for its actual source rows. No source-attention derivative is removed
from N4.

## 2. A bounded-tilt entropy budget

This extends D10 to the parameter-dependent source likelihood in N2. Let

\[
 p_a(dx)=Z(a)^{-1}e^{-aV(x)/T-\Phi_a(x)}\mu(dx),
 \qquad V\ge0,
 \tag{N5}
\]

where mu is fixed. Suppose the untilted partition ratio at a/2 and a is at most
R_0, and N2 holds. Then

\[
 E_{p_a}e^{aV/(2T)}\le R:=e^D R_0.
 \tag{N6}
\]

For an arbitrary fixed normalized parameter-independent channel C with output Y,
let p_a^C=p_a C and m_a(Y)=E[V|Y]. Differentiating the normalized joint gives

\[
 T\partial_a\log p_a^C(Y)
 =E_{p_a}V-m_a(Y)
  +T\left(E_{p_a}\Phi_a'-E[\Phi_a'|Y]\right).
 \tag{N7}
\]

For H=T KL(r||p_a^C), the exponential-tilt inequality and conditional Jensen give

\[
 |T E_r\partial_a\log p_a^C|
 \le {2H\over a}+{4T\log R\over a}+2TM.
 \tag{N8}
\]

In particular, for each actual active reversible parent diffusion with target
p_a^C and the common inherited constant configuration metric,

\[
 H'\le-T^2 I+{2|\dot a|\over a}(H+C_0T),
 \qquad C_0=2\log R+a_+M.
 \tag{N9}
\]

Set B(t)=integral |a'|/a. Multiplication by exp(-2B) and integration prove

\[
 e^{-2B(t)}[H(t)+C_0T]
 +T^2\int_{t_0}^t e^{-2B(u)}I(u)du
 \le H(t_0)+C_0T.
 \tag{N10}
\]

This holds through exact actual-law activations: both law and target are pushed
by the same channel, a is unchanged, and relative entropy drops. It is an account
of active dissipation at successive times, not a same-time sum of KL losses.
For a positive quadratic V on a d-dimensional normal sector, R_0=2^(d/2),
independently of its largest stiffness. Thus if |a'| is at most epsilon V_a through
c/epsilon, exp(2B) is at most exp(2c V_a/a_-). Calibration energy does not enter
this bound; calibration remains in the learning covector that supplies a'.

The compatible root sector is autonomous and common to every process. Its forced
mean need not be close to its stationary mean. For product preparations, apply
N10 to the normal-plus-loop marginal alone. If correlated preparations are
admitted, use the reference p_a^(normal) times the actual root marginal. The root
generator is common to law and reference and contributes a nonpositive relative
Fisher dissipation. The additional entropy is the actual mutual information. Its
initial value must be included, rather than spending the unrelated root
observation energy or declaring the correlation absent.

## 3. Actual activation entropy without conditional preparation

The following lemma is useful precisely because an actual retained law is not a
prepared conditional equilibrium. Its moment input is proved in Section 3.1.

**Lemma N1 (entropy floor and activation conversion).** Let a d-dimensional
active diffusion satisfy N1 and tr Hess U_a <=d Lambda on an active interval,
where Lambda>0 is time-independent on that interval. Write h_d(q)=-integral
q log q for differential entropy. Then

\[
 h_d(q_t)\ge h_*:=\min\left\{h_d(q_{t_0}),
             {d\over2}\log {2\pi e T\over\Lambda}\right\}.
 \tag{N11}
\]

For an orthogonal retention x=(y,z), with z in R^k, k>0, suppose
E|z-z_*|^2<=M_z for any deterministic z_*. The actual retained entropy obeys

\[
 h_{d-k}(r_t)\ge h_*-{k\over2}\log {2\pi e M_z\over k}.
 \tag{N12}
\]

Suppose the exact retained target is a bounded tilt, of oscillation at most D,
of G=N(mu,T S^(-1)) on R^(d-k). Put
E_ret=E_r[(Y-mu)^T S(Y-mu)]/2. Then

\[
 \begin{split}
 T\operatorname{KL}(r_t\Vert p_a^C)
 \le E_{\rm ret}-T h_*
 +{Tk\over2}\log {2\pi e M_z\over k}
 +{T(d-k)\over2}\log(2\pi T)
 -{T\over2}\log\det S+TD.
 \end{split}
 \tag{N13}
\]

For k=0 omit the conditional-entropy term. The formula uses the actual retained
moment E_ret, not an optimizing lift of the initial law.

*Proof.* Entropy differentiation gives
h_d'=T I(q)-E Delta U. The Gaussian logarithmic-Sobolev inequality, applied to
q relative to N(0,sigma^2 I), and expansion of both relative quantities give

\[
 -h_d+{d\over2}\log(2\pi\sigma^2)
 \le {\sigma^2\over2}I(q)-d.
\]

Choose sigma^2=d/I(q). Thus
I(q)>=2 pi e d exp(-2h_d/d), and

\[
 h_d'\ge2\pi e d T e^{-2h_d/d}-d\Lambda.
 \tag{N14}
\]

The right side is zero at the second value in N11 and positive below it. Scalar
comparison proves N11. The Gaussian logarithmic-Sobolev statement used here is
KL(q||G)<=sigma^2 I(q||G)/2 for every probability density of finite relative
Fisher information; no convexity hypothesis on q is needed. One proof uses the
Ornstein–Uhlenbeck semigroup: entropy is the integral of its relative Fisher
information, gradient commutation and Cauchy–Schwarz bound that Fisher information
by exp(-2t/sigma^2) times its initial value, and integration gives sigma^2/2.
Cutoff and positive-time smoothing cover the present densities.

Next h(y)=h(x)-h(z|y)>=h(x)-h(z). Nonnegativity of KL to
N(z_*,M_z I/k) gives h(z)<=k log(2 pi e M_z/k)/2, proving N12. Finally the density
ratio between the retained tilt and G is between exp(-D) and exp(D), so
KL(r||p_a^C)<=KL(r||G)+D. Expanding the Gaussian log density and substituting N12
gives N13. All three statements concern the nonlinear actual law. QED.

For the finite weighted flag Lambda<=C_L J_1. Repeated use of N11–N13 over a fixed
finite number of activations costs only logarithms of J_1, T, the dimensions, and
the stated moment bounds. In particular, Section 3.1 proves

\[
 E_{\rm ret}(\tau_s)
 \le C_L\left[A^2J_{s+1}+T\ell^2\right],
 \qquad
 \ell=1+|\log T|+\log J_1+|\log A|,
 \tag{N15}
\]

and the initial entropy and all logarithmic terms in N13 have absolute value at
most C_L ell, then

\[
 H_s(\tau_s)\le C_L[A^2J_{s+1}+T\ell^2].
 \tag{N16}
\]

At the terminal normal layer set J_(L+1)=0; loops remain and contribute their
actual thermal energy to N15. N16 is not an assumption of exact hidden
initialization. Its dynamical input is the actual moment estimate N15, proved
next using the relative force bound N23.

### 3.1. The actual weighted moment estimate

Here N23, proved independently in Section 5, closes the moment input. At an
active level p, couple X to the linear companion
dY=-a(t)H_pY dt+sqrt(2T)dB using the same actual initial state and Brownian motion.
This companion need not have a Gaussian law. Its purpose is an exact linear
propagator comparison. Writing e=X-Y gives

\[
 H_p^{1/2}e(t)
 =-\int_\tau^t H_p e^{-H_p\int_s^t a(u)du}
        H_p^{-1/2}T\nabla\Phi_{p,a_s}(X_s)ds.
 \tag{N16a}
\]

For m=lambda_min(H_p), Lambda=lambda_max(H_p), direct spectral maximization gives

\[
 \int_0^\infty\|H_pe^{-a_-H_pu}\|du
 \le {C\over a_-}[1+\log(\Lambda/m)].
 \tag{N16b}
\]

Indeed split the integral at 1/(a_-Lambda) and 1/(a_-m). On the three pieces
bound the integrand respectively by Lambda, 1/(e a_-u), and
m exp(-a_-mu). These three elementary integrals prove N16b. Therefore
|H_p^(1/2)e|<=C_L sqrt(T)(1+log J_1) pathwise and uniformly in time.

Let mu(t) solve the quadratic center equation mu'=-a(t)H_p mu. If the actual
initial second-moment matrix about mu(tau) satisfies

\[
 E[(X_\tau-\mu_\tau)(X_\tau-\mu_\tau)^T]
 \preceq K_\tau T H_p^{-1},
 \tag{N16c}
\]

the exact linear propagator and independence of future Brownian increments give
E[(Y_t-mu_t)(Y_t-mu_t)^T]<=(K_tau+1/a_-)T H_p^(-1). This statement does not
require Gaussian initial data or zero mean about mu. It follows by expanding
the linear stochastic integral; every propagator is a scalar function of H_p.
Since ee^T<=(e^TH_pe)H_p^(-1), the vector inequality
(v+w)(v+w)^T<=2vv^T+2ww^T proves

\[
 E[(X_t-\mu_t)(X_t-\mu_t)^T]
 \preceq C_L[K_\tau+(1+\log J_1)^2]T H_p^{-1}.
 \tag{N16d}
\]

At an actual retention P from p to s, the exact Gaussian inverse-Schur identity
is P H_p^(-1)P^T=H_s^(-1). Projecting N16d therefore supplies N16c at the next
stage with its actual recognition law and projected center. Induction over the
prescribed finite number of activations gives a common bound C_L T ell^2 H_s^(-1).
The initial bounded-density-tilted Gaussian class of Section 11 satisfies N16c
with a finite K_0 directly by integration of its density-ratio bound.

The quadratic normal center has norm at most C_L A by contraction and orthogonal
projection. Its loop center is exactly zero, since those Gaussian coordinates
decouple and start at zero. The retained normal Schur precision is at most
C_L J_(s+1)I. Thus its retained deterministic energy is at most
C_L A^2 J_(s+1), while N16d contributes at most C_L T ell^2 in actual fluctuating
energy, including loops. This proves N15 at every retention time, in particular
the actual activation times. The same argument before projection proves N41.
These are actual second-moment bounds; they do not give a covariance closure
equation for the nonlinear law.

## 4. Retained loops belong to the fast estimate

Let N_p be the normal space still active after p reductions, and H_h the retained
loop space. For an interface p<s, form the analysis split

\[
 Z_{p:s}=(N_p\cap N_s^\perp)\oplus H_h,
 \qquad Y_s=N_s.
 \tag{N17}
\]

The compatible root sector may be conditioned on throughout. The actual retained
parent keeps H_h; N17 is only the larger conditional entropy used to estimate
what is discarded. For actual and optimizing joint laws, define

\[
 \widehat\Delta_{p:s}
 =E_{Q_{Y_s}}\operatorname{KL}
       (Q(dZ_{p:s}|Y_s)\Vert\pi_a(dZ_{p:s}|Y_s)).
 \tag{N18}
\]

Disintegrating first at Y_s and then at the additionally retained loop gives

\[
 0\le\Delta^{\rm discarded}_{p:s}\le\widehat\Delta_{p:s}.
 \tag{N19}
\]

If source, occupancy, or other marks are generated by the same normalized
conditional kernel under recognition and target, include them in that joint
before applying the chain rule. The joint KL before retaining the marks is
unchanged, and the discarded marked conditional KL is again at most N18. This
does not authorize replacing a distinct recognition mark kernel by a posterior
kernel; any such mismatch requires its own joint KL term.

This construction avoids the incorrect treatment of a retained J_1-restoring
loop as a slow coordinate in D21. It neither discards loops from the true parent
nor asserts that projected paths are Markov.

## 5. The normalized observation and exact bounded-tilt parents

The selected construction observes only the compatible root coordinate:
O|x is Gaussian on K with mean P_K x and covariance T I_K/kappa. Its observed
value z belongs to K. The optimizing normal-plus-loop precision is therefore
exactly aH. The root precision is (1+kappa)I_K, independent of a. This is a
normalized observation on its stated carrier, not a singular full-dimensional
Gaussian density. The physical posterior still includes the separate evaluator
counterterm -TR. Its reverse kernel is not the optimizing kernel below.

Write G_a=N(0,(T/a)H^(-1)) on the normal-plus-loop space. For any fixed
orthogonal retention C_p, let H_p be its Gaussian Schur precision, let L_p be
the Gaussian conditional-mean lift, and write the full configuration as
x=L_p y+z, with C_p z=0. Then

\[
 L_p^THL_p=H_p,\qquad L_p^THz=0,
 \qquad z\sim N(0,(T/a)H_{EE}^{-1}).
 \tag{N20}
\]

The conditional mean L_p y is independent of a. Exact integration gives

\[
 \Phi_{p,a}(y)=-\log E_{G_a(dz|y)}e^{-\Phi_a(L_p y+z)},
 \qquad 0\le\Phi_{p,a}\le D,
 \tag{N21}
\]

and the normalized parent is the Gaussian G_a^p tilted by exp(-Phi_p). All
partition factors survive. Repeated integration gives the same Phi_p as direct
integration, so N21 is an exact representation of the existing common-channel
parent, not a fitted quadratic replacement.

Suppose the full source term obeys the relative derivative bounds

\[
 |\sqrt T H^{-1/2}\nabla\Phi_a|\le G_0,
 \qquad
 -\eta H\preceq T\nabla^2\Phi_a\preceq\eta H.
 \tag{N22}
\]

For N3, bounded f' and f'', the finite row incidence, and the covariance term in
N4 give G_0<=C_L delta and eta<=C_L(delta+delta^2). Choose the fixed positive
delta so that c_0:=a_- -eta-G_0^2>0. This is a sufficient, explicitly conservative
finite-L admission. In N21 differentiation in y holds the centered Gaussian z
fixed. The isometry H^(1/2)L_p H_p^(-1/2) and differentiation of the normalized
finite integral give

\[
 |\sqrt T H_p^{-1/2}\nabla\Phi_{p,a}|\le G_0,
 \tag{N23}
\]

\[
 T\nabla^2\Phi_{p,a}
 =E[L_p^T(T\nabla^2\Phi_a)L_p]
  -T\operatorname{Cov}(L_p^T\nabla\Phi_a,L_p^T\nabla\Phi_a).
 \tag{N24}
\]

Both expectations use the actual tilted hidden conditional. Thus every exact
parent potential U_(p,a)=a y^TH_p y/2+T Phi_(p,a) satisfies

\[
 c_0H_p\preceq\nabla^2U_{p,a}\preceq(a_++\eta)H_p.
 \tag{N25}
\]

In particular the source covariance correction has been paid after every
integration. The density is generally non-Gaussian. Its uniform convexity and
quadratic tails follow directly from N24–N25.

Every residual enters N3 through an even function. Hence Phi_a(-x)=Phi_a(x), and
Gaussian integration preserves Phi_p(-y)=Phi_p(y). The origin is the unique
normal-plus-loop minimizer by N25. Deterministic nonlinear normal-plus-loop
centers consequently have nonincreasing Euclidean norm.

There is also a stiffness-free parameter derivative. If k coordinates are
integrated in N21, their Gaussian scale score is
s_k=(k-|Z|^2)/(2a), Z standard Gaussian. It has mean zero and second moment
k/(2a^2). Hence

\[
 \partial_a\Phi_{p,a}=E[\Phi_a'-s_k],\qquad
 |\partial_a\Phi_{p,a}|
 \le M+(e^D-1){\sqrt{k}\over\sqrt2 a_-}
 \le\overline M.
 \tag{N26}
\]

To verify the middle bound, the density ratio of the tilted conditional to its
Gaussian reference lies between exp(-D) and exp(D), and E_G s_k=0. Thus
|E_tilt s_k|<=E_G|s_k||density ratio-1|
<= (exp(D)-1)sqrt(E_G s_k^2). The constant overline M uses the full finite
dimension for k and is uniform over all retained y and all weights. The K-only
observation is useful here: a moving Gaussian conditional center would add a
linear score with a retained-state-dependent coefficient. Such a term is absent
because of N20, not omitted.

## 6. Nonlinear conditional score tails

**Lemma N2 (uniform conditional score tails).** For every exact parent and every
further fixed orthogonal split of its normal-plus-loop coordinates, let k_a be
its optimizing hidden conditional. Under N2 and N20, the centered normalized
score partial_a log k_a satisfies

\[
 \log E_{k_a}e^{u\partial_a\log k_a}
 \le {v_0u^2\over2(1-b_0|u|)},\qquad |u|<1/b_0,
 \tag{N27}
\]

uniformly in every retained value. One conservative choice, for hidden dimension
k and overline M from N26, is

\[
 B_0=4/a_-+2\overline M,\quad
 M_1=e^D2^{k/2}+1,\quad
 b_0=2B_0,\quad v_0=2M_1b_0^2.
 \tag{N28}
\]

*Proof.* In centered Gaussian coordinates Z, the conditional score is the
conditional centering of
(k-|Z|^2)/(2a)-partial_a Phi_p. The density ratio to standard Gaussian is at most
exp(D). Since E_G exp(|Z|^2/4)=2^(k/2), its moments satisfy
E_tilt |Z|^(2j)<=exp(D)2^(k/2)4^j j!. If psi denotes
-|Z|^2/(2a)-partial_a Phi_p, the elementary inequality
|u+v|^j<=2^(j-1)(|u|^j+|v|^j) gives
E|psi|^j<=M_1 j! B_0^j. Centering gives
E|psi-Epsi|^j<=M_1 j! b_0^j. The first centered moment is zero. Summing the
absolutely convergent exponential series from j=2 and using log(1+x)<=x gives
N27–N28. No Gaussian law for the actual recognition density was used. QED.

For the inherited metric h>=h_*>0, D16 holds with v=v_0/h_* and
b=b_0/sqrt(h_*). Therefore, with Delta the actual discarded conditional KL,
the existing complete-score identity D24 gives the new applicable bound

\[
 |g(Q,a)-g_p(C_pQ,a)|
 \le T\left[\sqrt{2v_0\Delta}+b_0\Delta\right].
 \tag{N29}
\]

All prior, observation, calibration, and restricted-family scalar derivatives
are inside g_p. The estimate is for the complete covector difference. It is not
the expectation of an unnormalized quadratic energy alone.

For fully retained finite source labels the same proof applies label by label:
conditioning on a label replaces Phi by delta times the selected finite sum of
f's, still bounded between zero and D. Its label-prior factor pi_j(a) cancels
from the normalized hidden conditional. The parent covector still retains the
label-prior derivative. Its absolute value is bounded on the compact parameter
interval, so it contributes O_L(T) in the complete calibration comparison below.
When a conditional optimizing source kernel is used, this is equivalently its
normalized envelope representation. Different recognition mark kernels require
their separately specified conditional KL, as stated after N19.

## 7. Why the nonlinear mixed derivatives retain the flag scale

The mixed-derivative bound requires more than a uniform Hessian comparison. The
source restriction in N3 makes it provable. Use the fixed flag basis from W14–W19
of the cyclic witness, so B is block lower triangular with invertible diagonal
blocks and H_N=B^T diag(J_i I)B. After p>=1 normal layers are eliminated, write
E={1,...,p}, A={p+1,...,L}, and change eliminated variables to r_E=B_EE w_E.
The quadratic energy before integration has the form

\[
 r_E^T\mathsf D_Er_E+
 (Cr_E+B_Ay)^T\mathsf D_f(Cr_E+B_Ay),
 \qquad
 \mathsf A=\mathsf D_E+C^T\mathsf D_fC.
 \tag{N30}
\]

All unweighted matrices depend only on the fixed finite graph. The Gaussian
conditional mean is -mathsf A^(-1) C^T mathsf D_f B_A y. Put R=C^T mathsf D_f C.
Then ||R||<=C_L J_(p+1), mathsf A>=mathsf D_E, and
||mathsf A^(-1)||<=1/J_p. The first block row of

\[
 \mathsf A^{-1}=\mathsf D_E^{-1}
     -\mathsf D_E^{-1}R\mathsf A^{-1}
 \tag{N31}
\]

has norm at most C_L/J_1. The force column toward a retained layer s uses only
residual rows of level at least s, so its norm is at most C_L J_s. Because
w_1=B_11^(-1)r_1, the first-layer conditional-mean response satisfies

\[
 \|\partial_{w_s}m_1\|\le C_LJ_s/J_1.
 \tag{N32}
\]

The first conditional covariance is comparable to (T/J_1)I. Its upper bound
follows from N31. Its lower bound follows from
(mathsf A^(-1))_11>=mathsf A_11^(-1) and mathsf A_11<=C_L J_1 I. These comparisons
depend on the finite flag matrices and a_-,a_+, not on J_1/J_p. This proves the
needed response bound without substituting the cruder full-hidden inverse bound
1/J_p for its first block row.

All nonlinearity is a function of w_1 and the loop vector h. Thus Phi_p can be
calculated by integrating only this first-layer Gaussian marginal; the other
eliminated coordinates have already integrated out exactly. Its Gaussian mean
has response N32 and its covariance is independent of y. The original first and
second derivatives of Phi in (w_1,h) are bounded by C_L sqrt(J_1/T) and
C_L J_1/T. Differentiating the normalized integral twice therefore gives

\[
 \begin{split}
 T\|\partial_h\partial_{w_s}\Phi_p\|&\le C_LJ_s,\\
 T\|\partial_{w_i}\partial_{w_s}\Phi_p\|&\le C_LJ_iJ_s/J_1.
 \end{split}
 \tag{N33}
\]

The covariance terms from differentiating the expectation have the same bounds,
because they are products of the bounded first derivatives. At p=0, Phi itself
has no future-normal derivative. Combining N33 with the Gaussian Schur cross
estimate W18 proves, for the analysis split N17,

\[
 \|\nabla_{Z_{p:s}}\nabla_{Y_s}U_{p,a}\|
 \le\Gamma_s:=C_LJ_{s+1}.
 \tag{N34}
\]

For s=L the retained future-normal space is zero-dimensional and Gamma_L=0.
Retained loops, including their nonlinear covariance correction, are in Z for
this estimate. N34 would in general be false for the unrestricted mixed-level
source rows excluded in Section 1.

## 8. Conditional relaxation from actual activation laws

N25 and the weighted flag inequality imply that the Z-conditional in N17 has
Hessian at least lambda_s I, with lambda_s=c_L J_s. The uniformly convex
diffusion logarithmic-Sobolev statement used here is: if a C2 potential W on
R^k has Hess W>=lambda I and quadratic tails, its normalized density
exp(-W/T) satisfies KL(h||k)<=T I(h||k)/(2lambda). Its entropy-semigroup proof is
the one in Lemma N1, with gradient contraction exp(-lambda t) for the generator
T Delta-grad W dot grad and entropy derivative -T I. The present conditional
potentials meet those hypotheses globally by N25. In particular no local tube
is substituted for a global conditional LSI.

The primary source is [Ivan Gentil, *Logarithmic Sobolev inequality for diffusion
semigroups*, Remark 3.2, Theorem 3.3, and its proof](https://arxiv.org/pdf/1009.3421),
printed pages 8–10, inspected September 13, 2026. In its notation use
psi=W/T and rho=lambda/T. Its entropy dissipation and curvature proof give
KL<=T I/(2lambda). For Lemma N1 use psi=|x|^2/(2sigma^2) and rho=1/sigma^2.
These are the exact density and curvature hypotheses checked here; no
approximate convexity or unspecified mixing theorem is invoked.

Assume the actual learning equation supplies |a'|<=C_L epsilon in the admitted
interval. By N27–N28, b omega<=lambda_s/2 for sufficiently small epsilon. Apply
the previously proved D20–D21 to the auxiliary split N17, using N10 for its
normal Fisher dissipation. For an active process at level p starting at tau_p,

\[
 \begin{split}
 \widehat\Delta_{p:s}(t)
 &\le e^{-c_LJ_s(t-\tau_p)}\widehat\Delta_{p:s}(\tau_p)\\
 &\quad+C_L{J_{s+1}^2\over T J_s^2}
                [H_p(\tau_p)+C_0T]
       +C_L{\epsilon^2\over J_s^2}.
 \end{split}
 \tag{N35}
\]

All constants in N35 depend only on the prescribed finite depth, fixed source
admission, and bounded parameter interval. They contain neither a power of the
largest stiffness nor an exponential in 1/epsilon. The displayed weight ratios
are actual hypotheses to check.

At successive activation p=s-1, N16 and the entropy chain bound
widehat Delta<=H_p/T give

\[
 \begin{split}
 \widehat\Delta_{s-1:s}(t)
 \le C_L\bigg[&e^{-c_LJ_s(t-\tau_{s-1})}
                      (R_A^2J_s+\ell^2)\\
 &+R_A^2{J_{s+1}^2\over J_s}
  +\ell^2{J_{s+1}^2\over J_s^2}
  +{\epsilon^2\over J_s^2}\bigg],
 \qquad R_A=A/\sqrt T.
 \end{split}
 \tag{N36}
\]

The middle two terms vanish for s=L. A fixed initial covariance error or a fixed
bounded smooth density tilt contributes to the actual initial entropy; it is
removed by the displayed exponential relaxation, not set to zero. N19 and N29
then control the true discarded marked conditional KL and complete score.

For the common regime chosen with the other components,

\[
 q_L=0,\quad q_s=2q_{s+1}+20,\quad J_s=\epsilon^{-q_s},
 \qquad A^2=\epsilon^{3q_1+20},\quad T=A^2\epsilon^6,
 \quad H_*=2/\epsilon,
 \tag{N37}
\]

one has R_A^2=epsilon^(-6), J_(s+1)^2/J_s=epsilon^20,
and ell=O_L(log(1/epsilon)). At times at least
k_L log(1/epsilon)/J_s beyond the preceding activation, a sufficiently large
finite k_L makes N36 O_L(epsilon^2), uniformly through H_*. The floor at the
terminal normal layer is O(epsilon^2); the cross-force plateau at other layers
is O(epsilon^14), up to smaller logarithmic terms. Delta remains the error
against the actual nonlinear optimizing conditional with fixed delta>0.

## 9. Complete own-law learning without a stiffness exponential

Write V=x^THx/2 on the normal-plus-loop subsystem and V_p=y^TH_p y/2. Completing
the square in N20 gives exactly

\[
 V(L_py+z)=V_p(y)+z^TH_{EE}z/2.
 \tag{N38}
\]

Under its tilted optimizing conditional, the second term has expectation at
most exp(D) kT/(2a). Hence every parent uses its own actual law r in the complete
normalized covector

\[
 g_p(r,a)=a-2+E_rV_p+T E_r\partial_a\Phi_{p,a}+c_p(a,T),
 \qquad |c_p(a,T)|\le C_LT.
 \tag{N39}
\]

The scalar c_p contains the original prior partition derivative and the eliminated
Gaussian determinant derivative. The prior bound follows from
aH-TR>=aH/2 on the normal sector; the determinant derivative is kT/(2a).
Equivalently N39 follows by conditioning the complete fine covector and using
N38. It is not a replacement of a current-law expectation by an equilibrium
expectation. By N26 the displayed source derivative is uniformly bounded.

The normalized calibration observation contributes 1/T to the full Fisher
information, while the prior and finite categorical source experiments contribute
O_L(1). Consequently the inherited scaled metric obeys

\[
 h(a)=TM_{\rm full}(a)=1+O_L(T),\qquad h(a)\ge1.
 \tag{N40}
\]

This uses the full microscopic model experiment; the marginal parent Fisher
metric is not substituted. Suppose the actual energy-moment estimate, proved by
the formation comparison, holds on every active trajectory:

\[
 E_{r_t}V_p\le C_L[A^2J_1+T\ell^2].
 \tag{N41}
\]

Then N39–N40 give the actual equation

\[
 \dot a=\epsilon(2-a)+\epsilon R_t,
 \qquad |R_t|\le r_\epsilon:=C_L[A^2J_1+T\ell^2].
 \tag{N42}
\]

For b'=epsilon(2-b) with b(tau)=a(tau), exact variation of constants yields

\[
 |a(t)-b(t)|
 \le\epsilon\int_\tau^t e^{-\epsilon(t-s)}|R_s|ds
 \le r_\epsilon.
 \tag{N43}
\]

Choose the admitted interval [1,2.1]. At a=1 the velocity is
epsilon(1+R)>0; at a=2.1 it is epsilon(-0.1+R)<0 whenever r_epsilon<0.1. These
two strict inequalities close parameter confinement and the O(epsilon) speed
bootstrap. Starting at a=1 also gives
a(2/epsilon)>=2-exp(-2)-r_epsilon>1.5.

An independently learning parent initializes a from the actual preceding a and
then evaluates N39 from its own evolving law. Apply N43 separately to both
trajectories from that common activation value. Their discrepancy is at most
2 r_epsilon throughout the remaining interval. A finite number of successive
activations accumulates at most a finite-L multiple of this bound. In N37,
r_epsilon=O_L(epsilon^(2q_1+20)), with the smaller T ell^2 contribution retained.
This comparison is deliberately calibration dominated. It is an admitted
finite-family mechanism, not a theorem about arbitrary unsupervised model
feedback. The sharper same-state complete-score error N29 remains a separate
conditional-law result.

### 9.1. Well-posedness of the actual law-dependent equation

For fixed positive epsilon,T and finite weights, N25 makes the configuration
drift globally Lipschitz in x on the admitted parameter interval. Its a-derivative
has at most linear growth in x. For N3 this follows by differentiation of a
strictly positive finite sum with smooth logistic priors. For N21 the same
property follows by differentiating the Gaussian conditional integral; the
center is linear in the retained state, scale-score moments are finite, and the
source derivatives are bounded in standardized coordinates. All constants in
this local existence paragraph may depend on the fixed finite weights and T;
they are not used as long-horizon error constants.

On any second-moment ball E|X|^2,E|Y|^2<=M_2, a coupling gives

\[
 |E[X^TH_pX]-E[Y^TH_pY]|
 \le2\|H_p\|\sqrt{M_2}(E|X-Y|^2)^{1/2}.
 \tag{N43a}
\]

The remaining law-dependent source score is a bounded smooth function with
bounded spatial derivative for fixed weights and T. Its expectation is also
Lipschitz in this coupling distance. Parameter derivatives of the prior scalar,
the source scores, and h are bounded on the compact interval. Thus the map from
the current L2 random variable and parameter to the drift and parameter velocity
is locally Lipschitz on each such ball.

Fix the Brownian motion and apply Picard iteration to the integral equations
for X and a, with coefficients extended smoothly just beyond the parameter
interval. The preceding inequalities make the iteration a contraction in the
supremum L2 norm on a sufficiently short time interval. They also prove
uniqueness there. Each iterate's a is deterministic, because its score is an
expectation; the limit has the same property. A unique local strong solution
therefore exists. Before any parameter exit, N25 and the zero normal minimizer
give d E|X|^2/dt<=-2c_L E|X|^2+2Td. N16a–N16d give the stronger weighted moment
bound. Equation N42 and the two inward velocities rule out the parameter exit.
The bounded moments and compact parameter interval permit continuation through
every finite time, in particular 2/epsilon. Each exact activation restarts from
the actual positive-density retained law with finite moments, so the same
argument continues the sequential process.

The diffusion coefficient sqrt(2T)I is uniformly elliptic for each fixed T>0.
The smooth positive initial densities remain positive and smooth at positive
times: locally the parabolic equation is uniformly elliptic, and positivity
follows from its strong maximum principle, or from the strictly positive killed
Brownian transition density with the locally bounded drift change. The
exponential moments in N49 justify increasing the localization radii and the
entropy cutoff limits. Thus no boundary exit, explosion, or implicit
finite-time discretization is part of the argument.

## 10. A separate retained-path coupling

Conditional KL alone cannot prove this statement. The following argument uses
contractive nonlinear paths and the weighted Gaussian comparison directly.
N23 gives, at every exact parent,
|H_p^(-1/2) T grad Phi_p|<=G_0 sqrt T. Couple a deterministic nonlinear path
m'=-aH_p m-T grad Phi_p(m) to its quadratic companion
m_G'=-aH_p m_G with the same actual a and same initial value. Then

\[
 m(t)-m_G(t)
 =-\int_\tau^t e^{-H_p\int_s^t a(u)du}
                   T\nabla\Phi_{p,a_s}(m(s))ds.
 \tag{N44}
\]

For lambda_min(H_p)>=c_L,
integral_0^infinity ||exp(-a_-H_p u)H_p^(1/2)||du<=C_L. To check independence
from lambda_max, use the bound C/sqrt(u) for 0<u<=1/c_L and an exponentially
decaying bound for u>=1/c_L. The first bound is integrable at zero. Therefore

\[
 \sup_{t\ge\tau}|m(t)-m_G(t)|\le C_L\sqrt T.
 \tag{N45}
\]

This is a bound on deterministic centers, not on the means or covariances of
the nonlinear recognition law. It remains valid after actual activations.

For the quadratic normal split at one interface s, write its matrix as
[[F,G],[G^T,V]], with F>=c_L J_s I, ||G||<=C_L J_(s+1),
S=V-G^TF^(-1)G. All matrices are multiplied by the same actual scalar a(t).
The quadratic fine path has norm at most C_L A. Variation of constants gives

\[
 |u(t)|\le C_L A\left[e^{-c_LJ_s(t-\tau)}+J_{s+1}/J_s\right].
 \tag{N46}
\]

The difference between its retained y and the quadratic Schur parent initialized
at y(tau) has drift -aS times that difference, plus
-aG^T(u+F^(-1)Gy). Integrating the latter and using contraction gives

\[
 \sup_{\tau\le t\le\tau+H_*}|y(t)-\bar y(t)|
 \le C_L A\left[{J_{s+1}\over J_s}
                   +H_*{J_{s+1}^2\over J_s}\right].
 \tag{N47}
\]

Gaussian loop centers agree under the common a; the compatible root process is
shared exactly. For s=L both terms are zero. Repeated retentions add a finite
sum of N47. No equilibrium preparation of u was used.

If a and b are independently learned scalar paths with the same initial center,
their quadratic solutions are exp(-H_p integral a)m_0 and
exp(-H_p integral b)m_0. The scalar mean-value formula in each eigenvalue gives

\[
 \sup_t|m_a(t)-m_b(t)|
 \le {C_LA\over a_-}\sup_t|a(t)-b(t)|,
 \tag{N48}
\]

because sup_(v>=0) v exp(-v)=1/e. This is another place where a bound
exp(J_1 H_*) would be false bookkeeping. N48 is valid for deterministic actual
parameter paths even though those paths were generated by their own laws.

To pass to stochastic paths, let m solve the nonlinear deterministic equation
with the same a(t) as the actual diffusion and put Z=X-m. N25 gives
Z dot[b(m+Z)-b(m)]<=-c_L|Z|^2. For 0<theta<c_L/2,

\[
 (\partial_t+L_t)e^{\theta|Z|^2/T}
 \le\left[2\theta d-2\theta(c_L-2\theta)|Z|^2/T\right]
          e^{\theta|Z|^2/T}.
 \tag{N49}
\]

The right side is bounded above by a finite C_L independent of all stiffnesses.
Optional stopping at the first radius-r exit gives

\[
 P\{\sup_{\tau\le t\le\tau+H_*}|X_t-m(t)|>r\}
 \le C_L(1+H_*)e^{-\theta r^2/T},
 \tag{N50}
\]

provided the actual initial exponential moment about m(tau) is at most C_L.
It also stays bounded in expectation uniformly in time: the right side of N49
is at most -exp(theta|Z|^2/T)+C_L after increasing C_L. Orthogonal actual-law
activation does not increase this exponential moment when the next center is
the projected current center. The exact initialization law is therefore
admissible for the next estimate; it is not reset to a Gaussian.

Couple the parent initial value to the actual retained source value and use the
same root noise. Combining N45, N47, N48, N43, and N50 for the two processes
gives, outside an event of probability at most C_L(1+H_*)exp(-theta r^2/T),

\[
 \sup_{\tau\le t\le H_*}|C_sX_t-\bar X_t|
 \le C_LA\left[{J_{s+1}\over J_s}
       +H_*{J_{s+1}^2\over J_s}+r_\epsilon\right]
       +C_L\sqrt T+2r.
 \tag{N51}
\]

For sequential comparison the right side is summed over the finite number of
interfaces. In N37 choose r=A epsilon^2. Then N51 is O_L(A epsilon^2), and its
exceptional probability is at most
C_L(1+2/epsilon)exp(-c_L/epsilon^2). This is a coupling estimate for paths,
separate from N36 and N29. It does not assert exact Markov path-law equality or
remove conditional memory from an exact projected path representation.

## 11. Initial neighborhood, scope, and result

An explicit admitted initial class consists of means A v' in the open finite
formation neighborhood of the cyclic witness and positive normal covariance
matrices in a fixed strict relative neighborhood of (T/a_0)H^(-1). The root law
is a separate smooth positive law evolving under its common autonomous generator.
One may also multiply the normal Gaussian density by exp(psi)/E exp(psi), with
psi smooth, |psi|<eta_0 for any fixed finite eta_0, finite relative Fisher
information, and integrable derivatives. This supplies a nonempty nonlinear
density neighborhood in the indicated bounded-log-density topology. It permits
nonzero initial hidden conditional KL, maintains the initial entropy estimate,
and preserves the initial exponential moment in N50. It is not claimed to be a
neighborhood in every topology on all probability laws. No arbitrary initial
root-normal correlation is silently admitted; the mutual-information extension
in Section 2 states its additional entropy cost.

For the joined construction, intersect this initial class with the formation
component's bounded weighted W_infinity smooth-transport neighborhood. The
intersection is nonempty: the reference Gaussian itself and sufficiently small
smooth perturbations with compact support in standardized coordinates satisfy
both conditions. This intersection preserves the formation component's coupling
admission without requiring exact optimizing hidden conditionals.

Sections 3.1 and 5 prove the actual weighted moment estimate N15 at activation
and its uniform version N41. Its conversion to actual entropy is proved in
N11–N16. Thus N36 gives O_L(epsilon^2) true discarded conditional KL,
N29 gives O_L(T epsilon) complete same-state score discrepancy, N43 gives the
own-law parameter comparison, and N51 gives the separate retained-path error in
the one common regime N37. A fixed positive source deformation is present in all
of those optimizing conditionals.

The normalized physical and optimizing hidden-conditional changes and the fixed
positive attention-row variation are model-component obligations. They are not
proved by a small conditional approximation error. This lane proves neither
universality nor an unbounded-depth limit. Its new estimate is a finite-depth
conditional and own-law interface with explicit family admissions, global
nonlinear density control, retained loops, actual activation laws, and no hidden
largest-stiffness exponential.

The path statement concerns retained continuous configuration coordinates,
including loop coordinates. Source labels are normalized conditional marks of
the laws unless their own stochastic process is separately specified. In
particular, the actual retained recognition kernel of a source mark can differ
from the optimizing parent source kernel at an activation. N19 does not license
replacing that kernel by its optimizer. A claim about an independently evolving
full marked recognition process must state how the actual initial mark kernel
is inherited and evolved; N51 neither supplies a label generator nor asserts an
exact marked path law. This is the precise remaining model-interface obligation
for the collapsed construction. Section 12 supplies an explicit common kinetic
realization that resolves it without resetting any source conditional.

## 12. Full marked activation by explicit source sheets

The actual admitted realization retains the complete finite source assignment
j=(j_i)_i as part of the state. It is drawn once from a strictly positive
recognition mass vector lambda=(lambda_j)_j and remains fixed on each path.
Let Pi_j(a)=product_i pi_(i,j_i)(a) be its normalized generative prior weight and
put

\[
 \phi_j(x)=\delta\sum_i f(s_{i,j_i}(x)),\qquad 0\le\phi_j\le D,
 \qquad U_{a,j}(x)=aV(x)+T\phi_j(x).
 \tag{N52}
\]

The compatible root contribution is added independently as before. For each
fixed epsilon,T and finite depth, this is a finite disjoint union of Euclidean
carriers, with positive smooth densities on every sheet. The source labels have
zero mobility; every continuous peer coordinate has the same unit mobility.
This one microscopic kinetic prescription is inherited unchanged by all parents.
It is a constrained recognition dynamics with fixed positive label masses,
not an ergodic label sampler or a claim that label masses learn the model prior.

Write the actual joint recognition as Q_t(dx,j)=lambda_j q_(t,j)(x)dx, with each
q_(t,j) normalized. The actual equations are

\[
 \begin{split}
 dX_t&=-\nabla U_{a_t,J}(X_t)dt+\sqrt{2T}dB_t,
       \qquad dJ_t=0,\\
 \dot a_t&=-\epsilon h(a_t)^{-1}g(Q_t,a_t).
 \end{split}
 \tag{N53}
\]

Conditional on J, B is standard Brownian motion independent of the initial
configuration. The parameter is deterministic and uses the entire actual
mixture Q. Including the evaluator counterterm, normalized observations, and
calibration already specified in the model component, the normal contribution
to the full scaled VFE is exactly

\[
 \begin{split}
 F_T(Q,a)={}&T\sum_j\lambda_j\int q_j\log q_j
       +T\sum_j\lambda_j\log\lambda_j
       +\sum_j\lambda_j E_{q_j}[aV+T\phi_j]\\
 &-T\sum_j\lambda_j\log\Pi_j(a)
       +T\log Z_0(a)+{(a-2)^2\over2}+C_{\rm root,obs}.
 \end{split}
 \tag{N54}
\]

The root term retains its original normalized Gaussian observation and entropy;
its a-derivative is zero. Here Z_0 is the original proper prior partition
function, including the evaluator counterterm, and all observation density
constants remain in C_root,obs. Thus N53 is configuration gradient descent of
this same complete VFE within the fixed-label-mass class, together with its full
model natural gradient. Holding lambda fixed is an explicit zero-mobility
constraint; it is not an unrecorded E-step. In particular

\[
 {dF_T\over dt}
 =-T^2\left[\sum_j\lambda_j\int q_j
       |\nabla\log(q_j/\pi_{a,j})|^2+I_K\right]
       -\epsilon h(a)^{-1}g(Q,a)^2\le0,
 \tag{N55}
\]

where pi_(a,j) is the normalized configuration optimizer on sheet j. This
identity is obtained by integrating the sheet Fokker–Planck equations by parts
and then adding the full a-derivative. It makes no assertion that a different
collapsed-label free energy generates these paths.

The displayed gradients act on the normal-plus-loop subsystem; I_K is the
separate nonnegative root relative Fisher information. Equivalently include K
in each product sheet density and omit the separately displayed I_K.

At a fixed retention C_p keeping j and all loops, the exact generative and
optimizing marked parents are obtained by integrating the hidden configurations
on each sheet. In the optimizer, the resulting potential is
aV_p+T phi_(p,a,j), where phi_(p,a,j) is precisely N21 with Phi replaced by phi_j.
At an activation time tau the actual parent joint law is defined by

\[
 \overline Q_\tau(dy,j)
   =(C_p)_\#Q_\tau(dy,j)
   =\lambda_j (C_p)_\#q_{\tau,j}(dy),
 \qquad \bar a_\tau=a_\tau.
 \tag{N56}
\]

The parent then follows the same N53 prescription on its own sheet-specific
exact potential, with its own current q_(p,t,j), its own complete model score,
and the inherited h. No label is drawn again. The actual recognition conditional
Q_tau(j|y) is preserved by N56 and thereafter changes only through the distinct
sheet configuration laws. It need not equal the model posterior conditional.
Successive fixed retentions compose on this full marked joint; none discards j.

Every modified estimate can now be checked explicitly. First, N22 holds for
phi_j uniformly over the finite labels, with the same or smaller constants than
for the collapsed Phi. N23–N25 therefore prove global convexity and relative
force bounds for every exact sheet parent, including the covariance term created
by the hidden integration. N30–N34 still hold because each selected source edge
is an internal triangle edge; the source support is unchanged. N26 holds with
M=0 at the microscopic sheet level; only the Gaussian conditional scale score
appears after marginalization. N27–N29 consequently hold at every fixed retained
label, uniformly in j.

Second, N16a–N16d apply conditional on J. Choose the initial densities in the
common neighborhood uniformly over the finitely many sheets and lambda in a
compact positive simplex neighborhood. The same matrix second-moment bound and
entropy floor hold on each sheet. At activation N56 projects these actual
moments and densities. Summing with lambda proves the actual activation entropy
bound N16 without any source-kernel preparation. All moment and path constants
can depend on finite L and the chosen positive simplex neighborhood.

For an explicit check of the entropy budget, define

\[
 Z_j(a)=\int e^{-aV/T-\phi_j}dx,\qquad
 \rho_j(a)={\Pi_j(a)Z_j(a)\over\sum_k\Pi_k(a)Z_k(a)}.
 \tag{N57}
\]

The normalized joint optimizer is rho_j(a) pi_(a,j). Its relative entropy splits
as sum_j lambda_j T KL(q_j||pi_(a,j)) plus T KL(lambda||rho(a)). The latter term
is bounded by C_L T: exp(-D) times the common Gaussian partition bounds every
Z_j below, and every Pi_j has a positive lower bound on [1,2.1]. Each derivative
partial_a log Pi_j is bounded by a finite S_0 (S_0=4 when only the stated single
binary logistic row learns). The joint normalized score is the centered sum of
-V/T and partial_a log Pi_j. Therefore N6–N10 apply on the disjoint union with
R=exp(D)2^(d/2) and the bounded-score constant S_0 in place of M. The generator
has no label derivative, so its entropy dissipation is exactly the weighted sum
of the continuous Fisher informations. No fictitious J-Fisher term is needed.

For D20–D21 take retained variables (Y_s,J) and hidden variables Z_(p:s) from
N17. There is no derivative or current in the static J direction. Conditional
hidden score normalization cancels Pi_j(a), rho_j(a), and the joint partition
factor. Applying the conditional argument sheet by sheet and summing with
lambda gives exactly N35–N37 for the true marked discarded conditional KL.
Retained loops are again included in the auxiliary fast block, while J is
conditioned on throughout. This supplies the complete hidden-condition error
for the actual marked process, not only its configuration marginal.

Third, the complete parent covector is now

\[
 \begin{split}
 g_p(Q_p,a)={}&a-2+\sum_j\lambda_j E_{q_{p,j}}V_p
       +T\sum_j\lambda_j E_{q_{p,j}}\partial_a\phi_{p,a,j}\\
 &-T\sum_j\lambda_j\partial_a\log\Pi_j(a)+c_p(a,T),
       \qquad |c_p(a,T)|\le C_LT.
 \end{split}
 \tag{N58}
\]

The c_p term is the same prior-plus-eliminated-determinant derivative as in N39.
Thus the bounded categorical term is retained explicitly rather than omitted
from the claimed full score. The inherited microscopic metric is still N40.
The actual weighted moments give N42 with an increased finite constant, hence
the same [1,2.1] invariant interval, order-one parameter change, and independent
own-law comparison N43. The local existence proof in Section 9.1 applies to the
finite vector of sheet laws and their one shared expectation-driven parameter.
The complete dissipation N55 additionally verifies the actual update.

Finally, couple the fine and parent initial joint states using N56 and keep the
same J on both paths for all later times. All estimates N44–N50 are uniform in j.
N51 therefore holds for the full marked path under the metric
|y-y_bar|+1_(j!=j_bar): its label contribution is exactly zero, not a small
resampling error. This establishes approximate marked-path coupling while the
normalized marked parent laws and their composition remain exact. It does not
make an exact Markov claim for the projected fine continuous path.

The model posterior attention is still

\[
 \beta_{ij}(a,x)
 ={\pi_{ij}(a)e^{-\delta f(s_{ij}(x))}
      \over\sum_k\pi_{ik}(a)e^{-\delta f(s_{ik}(x))}}.
 \tag{N59}
\]

It is the posterior source row of the same normalized joint used in N54. The
fixed positive row variation proved in the model component therefore applies
to this posterior row and to its average under the actual configuration law.
It is not renamed the actual recognition row. In fact the actual marginal
configuration drift is exactly

\[
 -aHx-T\sum_j Q_t(J=j\mid X=x)\nabla\phi_j(x).
 \tag{N60}
\]

The label-specific nonlinear force and its actual law coupling have therefore
been retained. Replacing the recognition conditional in N60 by beta without
proving their equality would recover a different collapsed kinetic model; this
construction does not do so. Positive posterior-row variation follows from the
learned normalized model, while the actual mixture force is evaluated from its
own joint law. Static labels are the explicit kinetic restriction that permits
full marked initialization and recursive retention without a conditional reset.

For this source-sheet realization the marked activation obligation identified
at the end of Section 11 is closed by N52–N60. What remains outside this lane is
the model component's fixed positive physical/optimizing conditional-change
lower bound and posterior-row lower bound, and the formation component's actual
coalescence inequalities. No new stochastic label mixing theorem, label
equilibrium preparation, or exact projected Markov law is being assumed.

The work performed was source inspection and the displayed analytical
derivations. This file is the lane's only written output. No numerical diagnostic,
scientific rerun, GPU job, Lean work, tamper check, vault edit, or Git action was
performed.
