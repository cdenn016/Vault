"""Exact linearized Gaussian alignment ranks with retained nonflat holonomy."""
from fractions import Fraction as F
from pathlib import Path
import json
import sys

Matrix = list[list[F]]


def eye(k: int) -> Matrix:
    return [[F(i == j) for j in range(k)] for i in range(k)]


def zeros(n: int, k: int) -> Matrix:
    return [[F(0) for _ in range(k)] for _ in range(n)]


def transpose(a: Matrix) -> Matrix:
    return [list(row) for row in zip(*a)]


def mul(a: Matrix, b: Matrix) -> Matrix:
    return [[sum((a[i][r] * b[r][j] for r in range(len(b))), F(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def sub(a: Matrix, b: Matrix) -> Matrix:
    return [[x - y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def rank(a: Matrix) -> int:
    rows = [[F(v) for v in row] for row in a]
    pivot_row = 0
    for col in range(len(rows[0])):
        pivot = next((i for i in range(pivot_row, len(rows)) if rows[i][col]), None)
        if pivot is None:
            continue
        rows[pivot_row], rows[pivot] = rows[pivot], rows[pivot_row]
        scale = rows[pivot_row][col]
        rows[pivot_row] = [v / scale for v in rows[pivot_row]]
        for i in range(pivot_row + 1, len(rows)):
            scale = rows[i][col]
            if scale:
                rows[i] = [v - scale * u for v, u in zip(rows[i], rows[pivot_row])]
        pivot_row += 1
        if pivot_row == len(rows):
            break
    return pivot_row


def encoded(a: Matrix) -> list[list[str]]:
    return [[str(v) for v in row] for row in a]


def residual_jacobian(edges: list[tuple[int, int]], links: list[Matrix],
                      u: Matrix, n: int, k: int) -> Matrix:
    r"""Linearize v=dm_i-H dm_j-Xu and S=dC_i-H dC_j H^T-X-X^T."""
    symmetric = [(i, j) for i in range(k) for j in range(i, k)]
    variables = ([('mu', i, a, 0) for i in range(n) for a in range(k)]
                 + [('cov', i, a, b) for i in range(n) for a, b in symmetric]
                 + [('link', e, a, b) for e in range(len(edges)) for a in range(k) for b in range(k)])
    columns = []
    for kind, index, a, b in variables:
        dm = [zeros(k, 1) for _ in range(n)]
        dC = [zeros(k, k) for _ in range(n)]
        X = [zeros(k, k) for _ in edges]
        if kind == 'mu':
            dm[index][a][0] = F(1)
        elif kind == 'cov':
            dC[index][a][b] = dC[index][b][a] = F(1)
        else:
            X[index][a][b] = F(1)
        column = []
        for e, (i, j) in enumerate(edges):
            H = links[e]
            v = sub(sub(dm[i], mul(H, dm[j])), mul(X[e], u))
            S = sub(sub(sub(dC[i], mul(mul(H, dC[j]), transpose(H))), X[e]), transpose(X[e]))
            column.extend(row[0] for row in v)
            column.extend(S[a][b] for a, b in symmetric)
        columns.append(column)
    return transpose(columns)


def run_case(name: str, edges: list[tuple[int, int]], links: list[Matrix],
             mean: list[F], expected: int) -> dict:
    n, k = 3, len(mean)
    u = [[F(v)] for v in mean]
    for H in links:
        assert mul(H, transpose(H)) == eye(k)
        assert mul(H, u) == u
    B = residual_jacobian(edges, links, u, n, k)
    measured = rank(B)
    assert measured == expected, (name, measured, expected)
    stack = [row for H in links for row in sub(H, eye(k))]
    fixed_dimension = k - rank(stack)
    s = k * (k + 1) // 2
    d = s + k
    beta = len(edges) - n + 1
    rank_formula = ((n - 1) * d + beta * (d - 1)
                    if any(mean) else len(edges) * s + n * k - fixed_dimension)
    assert measured == rank_formula
    commutators_nonzero = any(any(v for row in sub(mul(A, B), mul(B, A)) for v in row)
                              for A in links for B in links)
    return {'name': name, 'K': k, 'N': n, 'edge_count': len(edges), 'cycle_rank': beta,
            'mean': [str(v) for v in mean], 'edge_order': edges, 'links': [encoded(H) for H in links],
            'fine_dimension': n * d + len(edges) * k * k,
            'residual_rows': len(B), 'exact_jacobian_rank': measured,
            'hessian_rank_same_by_positive_gaussian_fisher_weights': True,
            'common_fixed_vector_dimension': fixed_dimension,
            'formula_rank': rank_formula, 'has_noncommuting_links': commutators_nonzero}


def main() -> None:
    tri = [(0, 1), (1, 2), (2, 0)]
    four = tri + [(0, 2)]
    I2, I3 = eye(2), eye(3)
    reflection2 = [[F(1), F(0)], [F(0), F(-1)]]
    minus2 = [[F(-1), F(0)], [F(0), F(-1)]]
    reflection3 = [[F(1), F(0), F(0)], [F(0), F(-1), F(0)], [F(0), F(0), F(1)]]
    rotation3 = [[F(1), F(0), F(0)], [F(0), F(0), F(-1)], [F(0), F(1), F(0)]]
    t = F(1, 10)
    R = [[(1-t*t)/(1+t*t), -2*t/(1+t*t), F(0)],
         [2*t/(1+t*t), (1-t*t)/(1+t*t), F(0)], [F(0), F(0), F(1)]]
    perturbed = mul(mul(R, reflection3), transpose(R))
    cases = [
        run_case('K2_nonzero_mean_reflection_cycle', tri, [I2, I2, reflection2], [F(1), F(0)], 14),
        run_case('K2_centered_fixed_line_cycle', tri, [I2, I2, reflection2], [F(0), F(0)], 14),
        run_case('K2_centered_no_fixed_vector_cycle', tri, [I2, I2, minus2], [F(0), F(0)], 15),
        run_case('K3_nonzero_mean_noncommuting_two_cycles', four, [I3, I3, reflection3, rotation3], [t, F(0), F(0)], 34),
        run_case('K3_centered_singular_two_cycles', four, [I3, I3, reflection3, rotation3], [F(0), F(0), F(0)], 32),
        run_case('K3_centered_clean_perturbed_two_cycles', four, [I3, I3, perturbed, rotation3], [F(0), F(0), F(0)], 33),
        run_case('K3_centered_tree', tri[:2], [I3, I3], [F(0), F(0), F(0)], 18),
    ]
    assert cases[3]['has_noncommuting_links'] and cases[5]['has_noncommuting_links']
    result = {'scope': 'Exact tangent-rank and noncommuting-holonomy checks for the written GL(K) alignment construction. Not numerical integration, sampling, or proof of an asymptotic theorem.',
              'runtime': sys.version, 'executable': sys.executable, 'cases': cases, 'all_assertions_passed': True}
    Path(__file__).with_name('gl-rank-exact-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'cases': [{'name': c['name'], 'rank': c['exact_jacobian_rank'], 'fixed_dimension': c['common_fixed_vector_dimension']} for c in cases], 'all_assertions_passed': True}, indent=2))


if __name__ == '__main__':
    main()
