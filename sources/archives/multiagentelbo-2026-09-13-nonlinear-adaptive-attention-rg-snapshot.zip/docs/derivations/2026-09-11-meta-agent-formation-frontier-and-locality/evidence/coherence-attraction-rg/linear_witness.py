"""Exact tangent and inherited-metric checks for the local five-agent witness."""

from fractions import Fraction as F
import json
from pathlib import Path
import sys
from time import perf_counter


def zeros(rows: int, cols: int) -> list[list[F]]:
    return [[F(0) for _ in range(cols)] for _ in range(rows)]


def transpose(a: list[list[F]]) -> list[list[F]]:
    return [list(row) for row in zip(*a)]


def multiply(a: list[list[F]], b: list[list[F]]) -> list[list[F]]:
    return [[sum((x * y for x, y in zip(row, col)), F(0))
             for col in transpose(b)] for row in a]


def reduce_rows(a: list[list[F]]) -> tuple[list[list[F]], int]:
    out = [row[:] for row in a]
    pivot = 0
    for col in range(len(out[0])):
        selected = next((i for i in range(pivot, len(out)) if out[i][col]), None)
        if selected is None:
            continue
        out[pivot], out[selected] = out[selected], out[pivot]
        scale = out[pivot][col]
        out[pivot] = [x / scale for x in out[pivot]]
        for i in range(len(out)):
            if i != pivot:
                scale = out[i][col]
                out[i] = [x - scale * y for x, y in zip(out[i], out[pivot])]
        pivot += 1
        if pivot == len(out):
            break
    return out, pivot


def inverse(a: list[list[F]]) -> list[list[F]]:
    size = len(a)
    augmented = [row + [F(i == j) for j in range(size)] for i, row in enumerate(a)]
    reduced, _ = reduce_rows(augmented)
    assert [row[:size] for row in reduced] == [[F(i == j) for j in range(size)]
                                               for i in range(size)]
    return [row[size:] for row in reduced]


def main() -> None:
    started = perf_counter()
    n = 5
    edges = [(i, j) for i in range(n) for j in range(i)]
    dim = 4 * n + len(edges)
    residual = zeros(4 * len(edges), dim)
    for edge, (i, j) in enumerate(edges):
        for field, scale in enumerate((1, 2, 1, 2)):
            row = residual[4 * edge + field]
            row[4 * i + field], row[4 * j + field] = F(1), F(-1)
            row[4 * n + edge] = F(-scale)

    # Four root law parameters and four independent relative-frame scalings.
    tangent = zeros(dim, 4 + n - 1)
    for i in range(n):
        for field, scale in enumerate((1, 2, 1, 2)):
            tangent[4 * i + field][field] = F(1)
            if i:
                tangent[4 * i + field][4 + i - 1] = F(scale)
    for edge, (i, j) in enumerate(edges):
        if i:
            tangent[4 * n + edge][4 + i - 1] += 1
        if j:
            tangent[4 * n + edge][4 + j - 1] -= 1

    hessian = multiply(transpose(residual), [
        [x * (F(1) if k % 2 == 0 else F(1, 2)) for x in row]
        for k, row in enumerate(residual)
    ])
    metric_diag = [F(1), F(1, 2), F(10), F(5)] * n + [F(100)] * len(edges)
    metric_tangent = [[metric_diag[i] * x for x in row] for i, row in enumerate(tangent)]
    parent_metric = multiply(transpose(tangent), metric_tangent)
    projector = multiply(multiply(tangent, inverse(parent_metric)), transpose(metric_tangent))
    force = [[F(i % 5 - 2)] for i in range(dim)]
    projected = multiply(projector, [[force[i][0] / metric_diag[i]] for i in range(dim)])
    inherited = multiply(multiply(tangent, inverse(parent_metric)), multiply(transpose(tangent), force))

    checks = {
        "residual_rank_22": reduce_rows(residual)[1] == 22,
        "hessian_rank_22": reduce_rows(hessian)[1] == 22,
        "tangent_rank_8": reduce_rows(tangent)[1] == 8,
        "residual_annihilates_tangent": multiply(residual, tangent) == zeros(40, 8),
        "hessian_annihilates_tangent": multiply(hessian, tangent) == zeros(dim, 8),
        "projector_idempotent": multiply(projector, projector) == projector,
        "projector_fixes_tangent": multiply(projector, tangent) == tangent,
        "inherited_gradient_equals_projection": projected == inherited,
    }
    result = {"arithmetic": "fractions.Fraction", "agents": n, "internal_edges": len(edges),
              "ambient_dimension": dim, "coherent_dimension": 8, "normal_dimension": 22,
              "checks": checks, "all_passed": all(checks.values()),
              "python_version": sys.version, "executable": sys.executable,
              "elapsed_seconds": perf_counter() - started,
              "scope": "One linearized shared-link Gaussian witness; no trajectory or general RG proof."}
    Path(__file__).with_name("linear-witness.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))
    assert result["all_passed"]


if __name__ == "__main__":
    main()
