"""Exact straight-line geometry and resource coefficients; no sampled states."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

HERE = Path(__file__).parent
SOURCE = HERE.parent/'transported-parent-prior/result.json'
HELPER = HERE.parent/'parent-generation/generation_exact.py'
spec = importlib.util.spec_from_file_location('saved_generator_algebra', HELPER)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
h = g.h
Matrix = list[list[F]]


def mv_cost(a: Matrix) -> dict[str, int]:
    """Count a direct row sum; coefficient 1 is free, other nonzero coefficients multiply."""
    return {'multiply': sum(x != 0 and x != 1 for row in a for x in row),
            'add': sum(max(0, sum(x != 0 for x in row)-1) for row in a)}


def orthogonal_kernel(projector: Matrix) -> tuple[Matrix, list[F]]:
    """Rational Gram-Schmidt; normalized columns reconstruct the projector exactly."""
    cols: list[list[F]] = []
    norms: list[F] = []
    for seed in h.transpose(projector):
        v = seed[:]
        for b, norm in zip(cols, norms):
            coefficient = sum(x*y for x, y in zip(v,b))/norm
            v = [x-coefficient*y for x,y in zip(v,b)]
        norm = sum(x*x for x in v)
        if norm:
            cols.append(v)
            norms.append(norm)
    got = [[sum((b[i]*b[j]/n for b,n in zip(cols,norms)), F(0)) for j in range(4)] for i in range(4)]
    assert got == projector
    return h.transpose(cols) if cols else [[] for _ in range(4)], norms


def main() -> None:
    start = time.perf_counter()
    data = json.loads(SOURCE.read_text(encoding='utf-8'))
    rows = []
    for old in data['rows']:
        k = old['k']
        is_pair = old['partition'] == [[0,1],[2,3]]
        for dec in old['details']:
            c = [[F(x) for x in row] for row in dec['C']]
            d = [row for row in c if any(row)]
            inv = h.inverse(g.gram(d))
            lift = h.multiply(h.transpose(d),inv)
            projector = g.add(h.eye(4), h.multiply(lift,d),F(-1))
            basis, norms = orthogonal_kernel(projector)
            assert len(norms) == 4-k
            assert h.multiply(d,lift) == h.eye(k)
            assert h.multiply(d,basis) == [[F(0)]*(4-k) for _ in range(k)]
            path = [[F(x) for x in row] for row in dec['path_matrix']]
            assert sum(not any(row) for row in path) == k
            # U_ij = basis_ij/sqrt(norm_j); algebraically decide whether U_ij is 1.
            u_mult = sum(x != 0 and not (x > 0 and x*x == norms[j])
                         for row in basis for j,x in enumerate(row))
            lcost = mv_cost(lift)
            ell_add = sum(max(0,sum(x != 0 for x in a)+sum(x != 0 for x in b)-1)
                          for a,b in zip(lift,basis))
            pcost = mv_cost(path)
            q = 2*(4-k)
            # Shared after acceptance: eta, q independent uniforms/logs/radial scales.
            # Fine extra: q angular uniforms, q sqrt, 2q trig, q angle scales,
            # 2q products; ell=L V + U t; tree offsets; Z; mu.
            fine = {'uniform':q,'sqrt':q,'trig':2*q,
                    'multiply':3*q+4*(lcost['multiply']+u_mult+pcost['multiply']),
                    'add':4*(ell_add+pcost['add'])+32}
            # Parent extra: E_a,E_b,E_v; V^T inv V in each of four directions;
            # radius sum and E_c; z_A = Y + xi_A + average(epsilon_i).
            icost = mv_cost(inv)
            parent = {'multiply':20+8*k+4*icost['multiply']
                                  +4*sum(len(b)>1 for b in old['partition']),
                      'add':(17+4*k)+4*(icost['add']+max(0,k-1))+3
                             +max(0,q-1)+int(q>0)+(16+4*k)}
            # P-only optional second panel: compute four cut probabilities, two edge
            # Bernoulli flags and their OR. On merge, compute weighted root and loop.
            panel = {'multiply':14,'add':20,'exp':4,'uniform':2,'compare':2,'boolean_or':1} if is_pair else {}
            merge = {'multiply':4,'add':12} if is_pair else {}
            fine_fields = 36+4*k
            parent_fields = 12+8*k
            assert fine_fields-parent_fields == 24-4*k >= 8
            rows.append({'partition':old['partition'],'roots':dec['roots'],'trees':dec['trees'],'k':k,
                         'radial_pairs':q,'fine_fields':fine_fields,'first_parent_fields':parent_fields,
                         'merged_pair_fields':24 if is_pair else None,
                         'first_field_saving':fine_fields-parent_fields,
                         'merged_pair_field_saving':20 if is_pair else None,
                         'fine_extra':fine,'parent_extra':parent,
                         'pair_panel_extra':panel,'pair_merge_extra':merge,
                         'visible_lift':[[str(x) for x in row] for row in lift],
                         'hidden_orthogonal_columns':[[str(x) for x in row] for row in basis],
                         'hidden_column_squared_norms':[str(x) for x in norms]})
    assert len(rows)==45
    pair_rows = [r for r in rows if r['partition']==[[0,1],[2,3]]]
    assert len(pair_rows)==4
    # This threshold uses the already proved M_rec > 0.5130 at fixed P.
    fixed_pair_saving_lower = F(16)+4*F(513,1000)
    assert fixed_pair_saving_lower == F(4513,250) > 18
    output={'status':'PASS','runtime':sys.executable,'python':platform.python_version(),
            'command':[sys.executable,'-I','-B',str(Path(__file__).resolve())],
            'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
            'inputs_sha256':{str(p.relative_to(HERE.parent.parent)):sha256(p.read_bytes()).hexdigest()
                             for p in (SOURCE,HELPER,g.helper_path,g.g.HELPER)},
            'scope':'Exact linear-map identities and costs for the stated straight-line algorithms, not optimal-algorithm bounds. No Gaussian, uniform, flag, posterior sample or trajectory generated.',
            'fine_output':'(mu_i,Z_A,ell_e,Y); common discrete catalog and panel realization retained in both carriers',
            'parent_output':'(eight original p,four E,z_A,V); on merged P retain four new cut p and root z,loop',
            'cost_convention':'assignments excluded; coefficient 1 free; every other nonzero coefficient uses one multiplication; nonempty row sum costs n-1 additions; precomputed matrix constants and common accepted eta/radial generation excluded from BOTH counts',
            'pair_fixed_reference_storage_saving_strict_lower':str(fixed_pair_saving_lower),
            'all_45_first_storage_saving_range':[min(r['first_field_saving'] for r in rows),max(r['first_field_saving'] for r in rows)],
            'all_45_fine_extra_ranges':{key:[min(r['fine_extra'][key] for r in rows),max(r['fine_extra'][key] for r in rows)] for key in rows[0]['fine_extra']},
            'all_45_parent_extra_ranges':{key:[min(r['parent_extra'][key] for r in rows),max(r['parent_extra'][key] for r in rows)] for key in rows[0]['parent_extra']},
            'pair_rows':pair_rows,'rows':rows,'elapsed_seconds':time.perf_counter()-start,
            'not_run':['random sampling','numerical sampler','ODE','previous scientific mains','new likelihood integration','numerical prior choice','benchmark','test suite','GPU','Lean','tamper checks']}
    (HERE/'cost-coefficients.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:output[key] for key in ('status','all_45_first_storage_saving_range','all_45_fine_extra_ranges','all_45_parent_extra_ranges','pair_fixed_reference_storage_saving_strict_lower','elapsed_seconds')},indent=2))
    for r in pair_rows:
        print(json.dumps({key:r[key] for key in ('roots','fine_extra','parent_extra','pair_panel_extra','pair_merge_extra')}))


if __name__ == '__main__':
    main()
