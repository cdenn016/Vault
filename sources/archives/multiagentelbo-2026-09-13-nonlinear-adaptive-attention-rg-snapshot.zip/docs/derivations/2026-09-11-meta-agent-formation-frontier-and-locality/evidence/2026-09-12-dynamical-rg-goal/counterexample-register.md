<!-- rigorous-theory-search-metadata {"contract_id":"contract-sha256-e5dba6bac54379a2ad2d263508d099a3bbbff95ecfe99a3ad95130f9e8e8c9ad","schema_version":"rigorous-theory-search/v1","target_digest":"e5dba6bac54379a2ad2d263508d099a3bbbff95ecfe99a3ad95130f9e8e8c9ad"} -->
# Counterexamples and rejected stronger conclusions

The counterexamples delimit stronger statements; none is a nonexistence proof against the existential target.

The complete coherence report, equation (27), starts with zero edge KL in both channels but incompatible evaluator/link alignment. Its nonzero belief mismatch velocity disproves automatic tangency of that larger set. The positive basin theorem instead proves the narrower compatible minimum manifold.

Independent normal noise has generator derivative L D=T tr(H_D)>0 at exact coherence. Thus positive-temperature support invariance and permanent coherence are false. The admitted result uses a finite-horizon probability bound.

For U(y,z)=z^2/2 and E=-epsilon y z, the restricted potential on z=0 predicts stationary y, whereas the full forced equations give y(t)=y0+epsilon^2 y0 t^2/2+o(t^2). Tangent projection alone is not an exact forced trajectory. The source was corrected and retains an explicit trajectory error.

A density 2/[x(log x)^2] on x>=e^2 has infinite quartic energy and negative infinite differential entropy. Their formal sum is undefined, while the KL formulation remains meaningful. The source now restricts the split and uses the extended KL definition.

On a normalized angular Haar fiber, omission of the additive r T log(2 pi) term changes the displayed Laplace value. The force is unaffected, but the normalized value formula was corrected. Hidden-angle observations likewise require posterior-conditioned internal weights; reusing unforced weights changes the model. Equations (58)-(59) retain the parent likelihood, conditional cost and evidence.

Identical retained laws can have hidden Gaussian conditionals whose means differ by epsilon and whose variance is T. Their conditional KL is epsilon^2/(2T). Thus a retained-path error bound does not control dimensionless hidden KL; an O(epsilon) lag can have a large KL in the temperature-last regime. The full objective retains this residual explicitly.

At r=0 the circular law chart degenerates; at a=1 the evaluator used here becomes singular; deleting anchoring edges can destroy positive vertical stiffness. These cases fall outside the proved parameter domain. Failure of a sufficient persistence inequality is not itself a departure certificate; the final construction uses an explicit outward mismatch velocity and a positive crossing margin.
