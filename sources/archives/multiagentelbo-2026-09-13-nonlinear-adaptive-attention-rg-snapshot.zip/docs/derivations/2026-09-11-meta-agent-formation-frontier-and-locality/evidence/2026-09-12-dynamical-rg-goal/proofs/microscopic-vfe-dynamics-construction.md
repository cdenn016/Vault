# A normalized microscopic VFE with local law-point dynamics

September 12, 2026. This document addresses the microscopic obligation of the [six-step contract](evidence/2026-09-12-dynamical-rg-goal/problem-contract.json). It gives a normalized population experiment, an exact evaluator projection, and an actual local stochastic dynamics. Its [companion coherence analysis](complete-coherence-dynamics.md) examines attraction and forcing. This is an admitted conditional construction, not completion of the general hierarchy.

The exact result is a model with correlated recognition and independently moving links whose local reversible diffusion decreases its exact restricted VFE. Intrinsic inter-agent alignment is specified baseline dependence. A genuine normalized model evaluator gives a further belief–model force by conditional information projection. The generative prior, optimal variational target, and moving sample law are different objects. The nonzero radial well admits collective response; for d >= 3 the coherent sector also admits nonidentity stabilizer holonomy.

## 1. Target and source boundary

The user supplies the ambient single-point, common-principal-bundle, two-channel construction with local agents, overlap interactions, independent links, normalized generative laws and correlated recognition. The present existential specialization adds a finite graph, \(SO(d)\), fixed Gaussian conditional law families, proper radial priors, and a specified local reversible kinetic operator. The claims below hold for every parameter choice in the stated positive domain and every recognition law satisfying the stated integrability assumptions. They are not claims for arbitrary groups, variable covariances, kinetic rules, or infinite depth.

The source order is [Theory/01](../../../Theory/01_introduction.tex), its local-first architecture; [Theory/03](../../../Theory/03_probability.tex), model evaluation and recognition coupling; [Theory/04](../../../Theory/04_generative.tex), its explicitly normalized undirected alternative; [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), normalized records and the exact local–global potential identity; and [Theory/07c](../../../Theory/07c_full_graph_meta_agent_vfe.tex), complete two-channel states and common coarse channels. The [structural-learning calculation](pointwise-learning-parent-closure.md), [Gaussian link-learning example](pointwise-gaussian-link-learning.md), [agreement-conditioned construction](normalized-alignment-parent-limit.md), [alignment attraction result](coherence-attraction-and-dynamical-rg.md), and [fast/slow report](../2026-09-11-fast-slow-derived-hierarchy/final-report.md) fix the seams being extended.

The live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), sections labeled sec:complete_free_energy, sec:timescales, sec:adiabatic_hierarchy, sec:cross_scale_shadows, and app:augmented_joint, distinguishes its ansatz from an exact population ELBO, imposes microscopic mobilities, and separates predictive mixtures from expected-log variational coordinates. The [September wiki synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>) preserves the normalized-joint and conditional-KL requirements. These sources were consulted read-only. Their assumptions are not imported as theorems.

The introduced assumptions are \(d\ge2\), fixed isotropic Gaussian conditional covariances, an orthogonal cross-channel map, positive node and link mobilities, proper compatible radial boundary potentials, and attractive positive baseline edge weights. Strong/weak edge separation, when used, is supplied microscopic data. The compatibility between the radial prior and mobility is also supplied. None of these follows from a VFE value.

## 2. Coordinates, law points, presentations, and recognition

Fix one base point \(c_*\), nodes \(V=\{1,\ldots,N\}\), and a finite set of oriented edge copies \(e:j\to i\). Store one orientation per copy and invert its link when reversing orientation. The two associated fibers use the standard representation of the same \(SO(d)\) on distinct copies of \(\mathbb R^d\). This is a specialization of the ambient two-representation model.

Fix \(a\in(0,1)\). The complete outer configuration is
\[
 W=(u_i,v_i,R_e^b,R_e^m)_{i,e}
 \in\mathcal W=(\mathbb R^d\times\mathbb R^d)^N\times SO(d)^{2|E|}.
 \tag{1}
\]
It carries law points
\[
 b_{u_i}=N(u_i,I_d),\qquad m_{v_i}=N(v_i,aI_d).
 \tag{2}
\]
The vectors \(u,v\), laws \(b_u,m_v\), and recognition \(Q(dW)\) are different types. Links are independent coordinates of \(\mathcal W\), not vertex-frame ratios. Their posterior need not factorize.

The physical model presentation is \(\zeta_i\in\mathbb R^d\), and the physical state is \(k_i\in\mathbb R^d\). For a fixed orthogonal cross-channel map \(C_i\), declare
\[
 \operatorname{ev}_i(\zeta_i,dk_i)=N(C_i\zeta_i,(1-a)I_d)(dk_i),
 \qquad
 \int m_{v_i}(d\zeta_i)\operatorname{ev}_i(\zeta_i,dk_i)
 =N(C_iv_i,I_d)(dk_i).
 \tag{3}
\]
The evaluator consumes the sampled presentation \(\zeta_i\). It does not read live recognition. To verify the second formula, write \(\zeta_i=v_i+\xi_i\), \(k_i=C_i\zeta_i+\epsilon_i\), with independent centered noises of covariance \(aI_d\) and \((1-a)I_d\).

This is a conditional law-point realization, introducing an extra probability level allowed by Theory/05b. Conditional on \(W\), the recognition state/model marginals constructed below are exactly (2). The unconditional section laws are instead
\[
 \bar b_i=\int b_{u_i} Q(dW),\qquad
 \bar m_i=\int m_{v_i} Q(dW).
 \tag{4}
\]
They generally are Gaussian mixtures. They are not \(b_{\mathbb E_Q u_i}\) or \(m_{\mathbb E_Q v_i}\). In Theory/03, the complete agent block can contain \((u_i,v_i,\zeta_i,k_i)\); projection to \(k_i,\zeta_i\) gives (4). Configuration coherence below concerns the conditional law points (2), not automatically KL between the unconditional sections with random links.

Nor is the stochastic evolution below each agent's deterministic local Fisher inference on (4). It is an explicitly specified kinetic realization on law-point configurations, whose distribution optimizes an exact constrained VFE. That is an additional modeling commitment, not an identification forced by the original ontology.

## 3. A proper local-to-global generative law

Use product Lebesgue reference on \(u,v\) and normalized Haar reference on links, denoted \(\nu(dW)\). Fix \(T>0\), \(r_0>0\), positive mobilities \(\mu_b,\mu_m,\eta_e^x\), positive edge weights \(\kappa_e^x\), and \(\lambda_0>0\). Put
\[
 \phi(s)=\tfrac12(s-r_0^2)^2,\qquad
 V(W)=\tfrac12\sum_i\left[
 \mu_b^{-1}\phi(\|u_i\|^2)+\mu_m^{-1}\phi(\|v_i\|^2)\right],
 \tag{5}
\]
\[
 r_e^b=u_i-R_e^bu_j,\quad r_e^m=v_i-R_e^mv_j,\quad
 \delta_i=u_i-C_iv_i,
\]
\[
 D(W)=\tfrac12\sum_e
 [\kappa_e^b\|r_e^b\|^2+\kappa_e^m\|r_e^m\|^2],
 \qquad
 U_0=V+D+\tfrac{\lambda_0}{2}\sum_i\|\delta_i\|^2.
 \tag{6}
\]
Direct Gaussian log-density integration gives
\[
 \operatorname{KL}(b_{u_i}\Vert(R_e^b)_\#b_{u_j})=\tfrac12\|r_e^b\|^2,
 \quad
 \operatorname{KL}(m_{v_i}\Vert(R_e^m)_\#m_{v_j})=\frac{\|r_e^m\|^2}{2a}.
 \tag{7}
\]
Thus the coefficient multiplying model-channel KL in (6) is \(a\kappa_e^m\).

Local normalized mechanisms precede population coupling. Define
\[
 A_i(v)=\int \exp\left[-\frac1T
 \left(\frac{\lambda_0}2\|u-C_iv\|^2+
                         \frac{\phi(\|u\|^2)}{2\mu_b}\right)\right]du,
\]
\[
 K_i^{\rm law}(du\mid v)=A_i(v)^{-1}
 \exp\left[-\frac1T\left(\frac{\lambda_0}2\|u-C_iv\|^2+
                         \frac{\phi(\|u\|^2)}{2\mu_b}\right)\right]du,
 \quad
 \rho_i^m(dv)=z_i^{-1}A_i(v)e^{-\phi(\|v\|^2)/(2\mu_mT)}dv.
 \tag{8}
\]
Here \(z_i\) normalizes \(\rho_i^m\). The quartic factors are integrable, the bridge exponential is at most one, and every bounded open set has positive mass. Therefore all displayed normalizers are finite and positive. Their product is
\[
 \rho_i^m(dv)K_i^{\rm law}(du\mid v)
 =z_i^{-1}e^{-U_{0,i}(u,v)/T}du dv.
 \tag{9}
\]
The \(v\)-dependent \(A_i\) cancels only with the explicitly declared prior in (8).

The kernel \(K_i^{\rm law}\) generates belief-law coordinates \(u\); it is not the physical evaluator (3). The hyperprior \(\rho_i^m\) is on law coordinates \(v\); it is not \(m_v\), the model law on presentations \(\zeta\). Before a parent exists these are boundary/generative data.

Multiply the normalized product of (9) and Haar links by \(e^{-D/T}\in(0,1]\). Its expectation is in \((0,1]\). Consequently
\[
 P_{0,T}(dW)=Z_0(T)^{-1}e^{-U_0(W)/T}\nu(dW),
 \qquad 0<Z_0(T)<\infty.
 \tag{10}
\]
This uses the normalized undirected alternative of Theory/04; it is not a cycle of arbitrarily selected conditional laws. Its block conditionals are local because only incident factors depend on a changed block.

The full generative experiment is
\[
 P_T(dW,d\zeta,dk)=P_{0,T}(dW)
            \prod_i m_{v_i}(d\zeta_i)\operatorname{ev}_i(\zeta_i,dk_i).
 \tag{11}
\]
It is normalized by direct integration of the conditional kernels. Every factor was specified before recognition.

A concrete normalized gauge-invariant record kernel is
\[
 K_i(do_i\mid W)=N(\|u_i\|^2,\sigma_i^2)(do_i),\qquad \sigma_i>0.
 \tag{12}
\]
Finitely many such likelihoods are positive and bounded, so every fixed record has finite positive evidence. An edge sensor can similarly read \(u_i^TR_e^bu_j\). The unforced case has a singleton observation space. Integrating any appended unobserved normalized records leaves (11), including for binary agreement records. Their kernels supply no residual attraction. The attraction in \(D\) survives because it is an explicit intrinsic dependence in (10).

## 4. The exact evaluator projection over all couplings

Fix \(u,v,C\), with \(C\) orthogonal. Let \(\mathcal C(m_v,b_u)\) be all joint laws on \((\zeta,k)\) with the two prescribed marginals. Define \(R_{u,v}\) by
\[
 \zeta=v+\xi,\qquad k=u+C\xi+\epsilon,\qquad
 \xi\sim N(0,aI_d),\quad \epsilon\sim N(0,(1-a)I_d),\quad \xi\perp\epsilon.
 \tag{13}
\]
It has exactly these marginals and cross covariance \(aC^T\) in the \((\zeta,k)\) ordering. Write \(P_v^{\rm ev}=m_v\operatorname{ev}\), \(s=1-a\), and \(\delta=u-Cv\). The normalized conditional densities give
\[
 \log\frac{dR_{u,v}}{dP_v^{\rm ev}}(\zeta,k)
 =\frac{\delta^T(k-C\zeta)-\|\delta\|^2/2}{s}.
 \tag{14}
\]
For every \(S\in\mathcal C(m_v,b_u)\), its expectation is \(\|\delta\|^2/(2s)\), since the marginals fix \(\mathbb E_S(k-C\zeta)=\delta\). Therefore
\[
 \boxed{\operatorname{KL}(S\Vert P_v^{\rm ev})
 =\operatorname{KL}(S\Vert R_{u,v})
       +\frac{\|u-Cv\|^2}{2(1-a)}.}
 \tag{15}
\]
For finite KL this is direct addition of log ratios. It also holds in the extended sense: the affine ratio (14) is absolutely integrable for all these Gaussian marginals; a singular \(S\) has infinite KL to both positive Lebesgue densities. Equality in the minimum is attained uniquely at \(S=R_{u,v}\). This is an all-couplings result, not a Gaussian-only optimization.

Replacing \(R_{u,v}\) by the product \(m_v\otimes b_u\) adds
\[
 d\left[\frac{a}{1-a}+\frac12\log(1-a)\right]>0.
 \tag{16}
\]
This follows by the same quadratic expectation with cross covariance zero. It is constant only with \(a,d\) fixed; a learned covariance family cannot discard it.

## 5. Exact VFE, integrability, and the effective target

Select arbitrary correlated \(Q(dW)=q d\nu\), and conditional recognition
\[
 Q^{\rm aug}(dW,d\zeta,dk)
 =Q(dW)\prod_iR_{u_i,v_i}(d\zeta_i,dk_i).
 \tag{17}
\]
The outer dependence data are not determined by node marginals. Conditional independence of the inner pairs given \(W\) is an admitted recognition structure. Optimizing all conditional couplings with their prescribed marginals gives exactly the product in (17): any further conditional dependence contributes KL to that product.

For fixed observed records, define the scaled VFE before simplification:
\[
 \mathcal F_{T,o}
 =T\mathbb E_{Q^{\rm aug}}
 \left[\log\frac{q^{\rm aug}(W,\zeta,k)}{p_T(W,\zeta,k,o)}\right]
 =-T\log p_T(o)+T\operatorname{KL}(Q^{\rm aug}\Vert P_T(\cdot\mid o)).
 \tag{18}
\]
The ordinary VFE is \(\mathcal F_{T,o}/T\). The second expression defines its extended value without subtracting infinities.

For an energy–entropy split assume \(\int q|\log q|d\nu<\infty\), \(\mathbb E_QU_0<\infty\), and \(\mathbb E_Q|\log L_o|<\infty\). Quartic integrability then supplies the quadratic moments used below. Do not use the split for heavy-tailed \(Q\) with an undefined \(\infty-\infty\). Set
\[
 J=\sum_i\frac{\|\delta_i\|^2}{2(1-a)},\quad
 U_T=U_0+TJ
 =V+D+\frac{\lambda(T)}2\sum_i\|\delta_i\|^2,\qquad
 \lambda(T)=\lambda_0+\frac{T}{1-a}.
 \tag{19}
\]
Equations (11), (14), and (17) give the exact identity
\[
 \boxed{\mathcal F_{T,o}
 =\mathbb E_Q[U_T-T\log L_o]
      +T\int q\log q d\nu+T\log Z_0(T).}
 \tag{20}
\]
The term \(TJ\) is derived evaluator mismatch; \(\lambda_0\sum\|\delta_i\|^2/2\) is separately admitted prior dependence.

Define
\[
 Z_{{\rm eff},o}=\int e^{-U_T/T}L_o d\nu,\qquad
 \pi_{T,o}=Z_{{\rm eff},o}^{-1}e^{-U_T/T}L_o \nu.
\]
These are finite and positive, and
\[
 \boxed{\mathcal F_{T,o}
 =T\operatorname{KL}(Q\Vert\pi_{T,o})
                  +T\log\frac{Z_0}{Z_{{\rm eff},o}}.}
 \tag{21}
\]
This also supplies an extended definition. The unique optimal outer law is \(\pi_{T,o}\). Without observations,
\[
 \pi_T=\frac{e^{-J}P_{0,T}}{\mathbb E_{P_{0,T}}e^{-J}},\qquad
 \inf_Q\mathcal F_T=-T\log\mathbb E_{P_{0,T}}e^{-J}>0.
 \tag{22}
\]
The inequality is strict because \(J=0\) has zero Lebesgue measure and \(P_{0,T}\) is everywhere positive. The generative evidence is one. The optimized positive gap is the cost of evaluator-constrained recognition. In particular \(\pi_T\) is not the original generative prior \(P_{0,T}\).

A general unoptimized inner coupling adds \(T\mathbb E_Q\operatorname{KL}(S_W\Vert\prod_iR_{u_i,v_i})\). This vanishes only under exact conditional optimization. The generative evaluator does not become recognition dependent merely because its fixed-marginal variational optimizer depends on \(u,v\).

## 6. Local kinetics and the complete update

The configuration metric is
\[
 g=\bigoplus_i(\mu_b^{-1}I_d\oplus\mu_m^{-1}I_d)
       \oplus\bigoplus_{e,x}\eta_e^{x,-1}h,\qquad
 h(A,B)=-\tfrac12\operatorname{tr}(AB),\quad A,B\in\mathfrak{so}(d).
 \tag{23}
\]
The Gaussian mean Fisher metrics are \(I_d,a^{-1}I_d\); these node blocks are positive scalar multiples of them. The group block is an explicit positive Riemannian metric. A model rate relative to its unscaled Fisher metric is \(\mu_m/a\). The mobilities are added kinetic data, not consequences of the VFE.

Put \(H_o=U_T-T\log L_o\). The actual sample generator is
\[
 \mathcal L f=\sum_{i,x}\mu_x
 [T\Delta_{x_i}f-\nabla_{x_i}H_o\cdot\nabla_{x_i}f]
 +\sum_{e,x}\eta_e^x
 [T\Delta_hf-\langle\operatorname{grad}_{e,h}H_o,
                                 \operatorname{grad}_{e,h}f\rangle_h],
 \tag{24}
\]
with \(x_i=u_i\) or \(v_i\). Each term reads its block, incident endpoint/link blocks, and incident records. It never reads \(q\). Node marginal equations require the appropriate incident joint expectations; node marginals alone do not close them.

For common cross frames \(C_i=I\) and no records, define
\[
 F_i^x=\sum_{e:\operatorname{head}(e)=i}\kappa_e^xr_e^x
 -\sum_{e:\operatorname{tail}(e)=i}\kappa_e^x(R_e^x)^Tr_e^x.
\]
The node drift is
\[
 \dot u_i=-\mu_b[F_i^b+\lambda(T)(u_i-v_i)]
                       -(\|u_i\|^2-r_0^2)u_i,
\quad
 \dot v_i=-\mu_m[F_i^m+\lambda(T)(v_i-u_i)]
                       -(\|v_i\|^2-r_0^2)v_i.
 \tag{25}
\]
Both incoming and outgoing forces are included. For general \(C_i\), the bridge gradients are \(\lambda\delta_i\) and \(-\lambda C_i^T\delta_i\). Records add \(T\mu_x\nabla_{x_i}\log L_o\).

For edge \(j\to i\), write \(z_i=u_i\) or \(v_i\), \(t_e=R_e^xz_j\). Its spatial gradient coefficient and drift are
\[
 G_e^x=\kappa_e^x(t_ez_i^T-z_it_e^T),\qquad
 \dot R_e^x=-\eta_e^xG_e^xR_e^x.
 \tag{26}
\]
Here \(\dot RR^{-1}\) is the spatial/right-trivialized velocity. The convention is fixed by the direct variation
\[
 d[\kappa\|z_i-Rz_j\|^2/2](AR)
 =-\kappa z_i^TAt_e=-\tfrac12\operatorname{tr}(G_eA).
 \tag{27}
\]
For \(z_i=e_1,z_j=e_2,R=I\), the drift is
\(\eta\kappa(e_1e_2^T-e_2e_1^T)\ne0\). Thus an open set has genuinely moving independent links.

Equations (25)–(26) are only the drift. The node SDE adds independent noises \(\sqrt{2T\mu_x} dB_i^x\). With an \(h\)-orthonormal basis \(E_\alpha\), the link SDE is
\[
 dR_e^x=-\eta_e^xG_e^xR_e^xdt+
 \sqrt{2T\eta_e^x}\sum_\alpha E_\alpha R_e^x\circ dB_{e,\alpha}^x.
 \tag{28}
\]
This Stratonovich noise remains on \(SO(d)\), giving \(T\eta\Delta_h\). Its Itô correction in the standard matrix embedding is \(-T\eta(d-1)Rdt\), since \(\sum_\alpha E_\alpha^2=-(d-1)I\). All local noises are independent. The index is an inference/sampling parameter, not identified with physical time.

The unforced polynomial process is nonexplosive. Its coefficients are smooth and links live on a compact manifold. For
\(\mathcal V=\sum_i(\|u_i\|^2/\mu_b+\|v_i\|^2/\mu_m)\), direct calculation gives
\[
 \mathcal L\mathcal V=
 -4\left(D+\frac{\lambda(T)}2\sum_i\|\delta_i\|^2\right)
 -2\sum_i\left[
 \frac{\|u_i\|^4-r_0^2\|u_i\|^2}{\mu_b}
 +\frac{\|v_i\|^4-r_0^2\|v_i\|^2}{\mu_m}\right]+4NdT.
 \tag{29}
\]
This is bounded above and coercive at large radii. Stop at increasing radii, take expectations, and bound the probability of reaching the radius by its quadratic value to obtain nonexplosion for initial finite \(\mathbb E\mathcal V\). Arbitrary added forcing needs its own Lyapunov or stopped-domain hypothesis.

## 7. Exact density descent and its metric

For smooth positive densities with finite dissipation and vanishing Euclidean boundary flux, the forward equation is
\[
 \partial_tq=\operatorname{div}_\nu[qM\nabla(H_o+T\log q)]
 =T\operatorname{div}_\nu[qM\nabla\log(q/\pi_{T,o})],\qquad M=g^{-1}.
 \tag{30}
\]
The group divergence uses Haar measure. Integration by parts in (20) gives
\[
 \boxed{\frac{d}{dt}\mathcal F_{T,o}
 =-T^2\int q 
 \langle\nabla\log(q/\pi_{T,o}),
                    M\nabla\log(q/\pi_{T,o})\rangle d\nu\le0.}
 \tag{31}
\]
Smooth sufficiently decaying densities suffice for the displayed calculation. A theorem for arbitrary weak initial densities is not being asserted. Substitution proves that \(\pi_{T,o}\) is invariant. More explicitly,
\[
 \int f\mathcal Lg d\pi_{T,o}
 =-T\int\langle\nabla f,M\nabla g\rangle d\pi_{T,o},
 \tag{32}
\]
which proves reversibility on the smooth test domain. A positive smooth stationary density with zero dissipation equals \(\pi_{T,o}\), since the carrier is connected and every mobility is positive. These identities do not by themselves give a mixing rate.

The density metric is the transport metric whose tangent norm minimizes
\(\int q\langle v,M^{-1}v\rangle d\nu\) subject to
\(\dot q+\operatorname{div}(qv)=0\). It is not Fisher–Rao's
\(\int(\dot q)^2/q\). Equation (30) is not the full-joint Fisher flow
\(\dot q=-q[\log(q/\pi)-\mathbb E_q\log(q/\pi)]\).
The node metric for sampled law points and this density metric are separate. Merely exponentiating a scalar would not establish (28)–(32).

For one block generator the outside marginal is fixed, because integration over the moving block kills its divergence. Thus the KL chain rule gives exactly Theory/05b's fixed-outside-marginal local–global potential identity. Each local conditional contains every incident factor. Summing these local scalars would overcount edges; summing the compatible generators is legitimate and gives (31).

## 8. Nonzero coherence and the temperature/stiffness limits

In common cross frames define the stronger compatible set
\[
 \mathcal S=\{u_i=v_i,\quad u_i=R_e^bu_j,\quad
                              v_i=R_e^mv_j\text{ on internal edges}\}.
 \tag{33}
\]
This is stronger than zero edge KL in both channels separately. On a connected component it has a common radius \(r\). Its drift is
\[
 \dot u_i=(r_0^2-r^2)u_i,\quad
 \dot v_i=(r_0^2-r^2)v_i,\quad
 \dot R_e^x=0,\quad \dot r=(r_0^2-r^2)r.
 \tag{34}
\]
The prior–mobility compatibility in (5) makes this tangency exact for different channel mobilities. For \(r(0)>0\),
\[
 r(t)^2=\frac{r_0^2}{1+(r_0^2/r(0)^2-1)e^{-2r_0^2t}}.
 \tag{35}
\]
Hence the coherent radius tends to nonzero \(r_0\), not only the radial origin. The stronger set \(\mathcal S_{r_0}\) is a compact zero-energy manifold. Independent edges mapping nonzero equal-length vectors retain an \(SO(d-1)\) fiber. For \(d\ge3\), loop products may be nonidentity stabilizers; they need not be flat. Noncommuting stabilizers are available for \(d\ge4\). At \(d=2\), a nonzero vector has trivial stabilizer, so exact coherence instead forces the corresponding loop actions to identity. The companion document proves the regular normal-gap and attraction statements.

There is a concrete collective radial response mode. At \(u_i=v_i=r_0e_1\), with each link preserving \(e_1\), radial variations satisfy
\[
 \dot\alpha=-2r_0^2\alpha-\mu_b[L_b\alpha+\lambda(T)(\alpha-\beta)],
 \quad
 \dot\beta=-2r_0^2\beta-\mu_m[L_m\beta+\lambda(T)(\beta-\alpha)].
 \tag{36}
\]
First-order link variations are orthogonal to \(e_1\), so this sector is invariant under the linearization. If \(L_b=\kappa_bL,L_m=\kappa_mL\), a graph eigenvalue \(\ell\) gives rates
\[
 2r_0^2+\frac{A_\ell+D_\ell
 \pm\sqrt{(A_\ell-D_\ell)^2+4\mu_b\mu_m\lambda(T)^2}}2,
 \quad
 A_\ell=\mu_b(\kappa_b\ell+\lambda(T)),
 D_\ell=\mu_m(\kappa_m\ell+\lambda(T)).
 \tag{37}
\]
For \(\ell=0\) the rates are \(2r_0^2\) and
\(2r_0^2+\lambda(T)(\mu_b+\mu_m)\). Internal contrasts acquire graph-dependent rates while the common radial mode remains. Separated graph couplings are a hypothesis, not a derived grouping. This linear calculation alone is not nonlinear parent closure.

At positive \(T\), independent node noise has normal components, so exact coherent support is not invariant. The invariant density is positive on open sets and has positive expected edge mismatch whenever an edge is present. The relevant finite-\(T\) conclusion is a tube or concentration bound, not exact zero mismatch.

At fixed finite couplings, \(T\downarrow0\) yields the drift \(-M\nabla U_0\): \(\lambda(T)\to\lambda_0>0\). On a compact patch and bounded interval before exit, coefficient differences are \(O(T)\) and noise covariance is \(O(T)\). Itô's formula for squared SDE–ODE difference, expectation, and the inequality \(2xy\le x^2+y^2\) give
\(\mathbb E\|W_t^T-W_t^0\|^2\le C T(e^{Lt}-1)\) for common initial conditions, with constants depending on that patch and interval. This is a stopped finite-time small-noise statement. A deterministic trajectory does not sample \(\pi_T\); Dirac recognition has infinite positive-\(T\) KL.

The limits in stiffness and temperature must not be interchanged without proof. At fixed \(T\), writing \(\kappa_e^x=\kappa\bar\kappa_e^x\) and sending \(\kappa\to\infty\) concentrates the edge mismatch near zero by an exponential-tilt bound. The finite-strength bridge and radial variables do not thereby concentrate at their minima; zero-vector and enhanced-stabilizer strata can change that limiting measure.

One sufficient joint-limit admission is \(T\downarrow0\), \(\kappa\ge\kappa_{\min}>0\), and \(T\log(1+\kappa)\to0\). Fix a nonzero minimum \(W_*\). Locally,
\(U_0^\kappa\le C(1+\kappa)\|W-W_*\|^2\), so a ball of radius
\(c\sqrt{T/(1+\kappa)}\) gives a partition lower bound
\(c'[T/(1+\kappa)]^{n/2}\), \(n=\dim\mathcal W\), with the bounded factor \(e^{-J}\) included. Outside a fixed neighborhood of the common minimum set, properness gives \(U_0^{\kappa_{\min}}\ge\delta>0\). Splitting the exponential in half bounds that outside mass by \(C'e^{-\delta/(2T)}\). Their ratio tends to zero under the stated scaling. This proves concentration near nonzero minima in this admitted limit, not a uniform averaging theorem or unrestricted limit exchange.

## 9. Optional source labels and their entropy

No attention row is required by the concrete model. An optional intrinsic label extension with finite row prior \(\pi_{ij}>0,\sum_j\pi_{ij}=1\), and nonnegative energies \(E_{ij}(W)\), uses joint factor \(\pi_{ij}e^{-E_{ij}/T}\) and includes the global normalizer. Its conditional source law is
\[
 a_{ij}(W)=\frac{\pi_{ij}e^{-E_{ij}(W)/T}}
                         {\sum_k\pi_{ik}e^{-E_{ik}(W)/T}}.
 \tag{38}
\]
For a normalized nonnegative row \(w_i\),
\[
 \sum_jw_{ij}E_{ij}+T\sum_jw_{ij}\log(w_{ij}/\pi_{ij})
 =-T\log\sum_j\pi_{ij}e^{-E_{ij}/T}
                        +T\operatorname{KL}(w_i\Vert a_i(W)).
 \tag{39}
\]
The constrained derivative is \(E_j+T(\log(w_j/\pi_j)+1)+\Lambda=0\), giving the unique positive optimizer (38). Its reduced force is \(\sum_ja_{ij}\nabla E_{ij}\), including every endpoint/link derivative. The normalization is over sources at fixed receiver and fixed \(W\).

If the variational row is restricted to be independent of \(W\), its optimizer is instead proportional to
\(\pi_{ij}\exp[-\mathbb E_QE_{ij}/T]\), and the expected conditional KL in (39) remains. Appending an unobserved normalized record label after the baseline gives neither energy; it integrates to one. This extension does not import an engineered attention temperature into a different probabilistic construction.

## 10. Parent conditionals and the correction that must survive

Before formation, (8)–(10) are boundary data, not transported parent posteriors. For a fixed retained map \(Z=C(W)\), disintegrate the same baseline into \(P_{0,T}^c(dz)P_{0,T}(dW\mid z)\). These supply genuine generative child conditionals. No additional parent-child KL is inserted.

The effective variational law disintegrates differently. Define
\[
 A(z)=\mathbb E_{P_{0,T}(\cdot\mid z)}e^{-J(W)},\qquad
 c_T=\mathbb E_{P_{0,T}}e^{-J}=Z_{\rm eff}/Z_0.
\]
Then almost everywhere,
\[
 \pi_T^c(dz)=A(z)P_{0,T}^c(dz)/c_T,\qquad
 \pi_T(dW\mid z)=e^{-J(W)}P_{0,T}(dW\mid z)/A(z).
 \tag{40}
\]
The exact chain rule is
\[
 \frac{\mathcal F_T}{T}
 =\operatorname{KL}(Q^c\Vert P_{0,T}^c)
 +\mathbb E_{Q^c}[-\log A(Z)]
 +\mathbb E_{Q^c}\operatorname{KL}
             (Q(\cdot\mid Z)\Vert\pi_T(\cdot\mid Z)).
 \tag{41}
\]
All terms are nonnegative, with the standard extended conditional-KL meaning. The factor \(A\) is induced by evaluator-constrained recognition; it is not a fabricated observed agreement event. Any parent representation must retain this factor or the corresponding conditional cost. A common coarse channel can also act on the full augmented laws (11) and (17), carrying the evaluator variables as required. Neither route silently identifies \(P_{0,T}^c\) with \(\pi_T^c\).

A predictive child prior is
\(\int P_{0,T}(dW_i\mid Z=z)Q^c(dz)\).
An expected-log coordinate is proportional to
\(\exp[\mathbb E_{Q^c}\log p_{0,T}(W_i\mid Z)]\), generally a different law. Exact transported-parent shadows require a further rigid conditional limit. These distinctions implement the live source's caution rather than adding same-time parent feedback.

## 11. Actual generative-parameter learning is a separate block

Moving \(v_i\) changes a sampled model-law point; moving \(R_e^x\) changes a sampled link. Neither alone is learning a generative parameter \(\theta\). One may additionally learn declared \(\kappa_e^x,\lambda_0\), or record parameters while keeping \(a,r_0,\mu_x\) fixed. For a parameter entering \(U_0\), with recognition and references fixed,
\[
 g_\theta=\partial_\theta\mathcal F_T
 =\mathbb E_Q\partial_\theta U_0
                    -\mathbb E_{P_{0,T}}\partial_\theta U_0.
 \tag{42}
\]
This follows from \(T\partial_\theta\log Z_0=-\mathbb E_{P_{0,T}}\partial_\theta U_0\). With records add \(-T\mathbb E_Q\partial_\theta\log L_o\). Quartic domination justifies differentiation on compact subsets of positive parameters. Learning \(a\) changes the recognition restriction and needs further derivatives.

Declare positive parameter metric blocks \(H_\theta\), and set
\(\dot\theta=-H_\theta^{-1}g_\theta\).
For parameters entering only U_0, with all conditional kernels fixed, the full model Fisher, when nondegenerate, is
\(T^{-2}\operatorname{Cov}_{P_{0,T}}(\partial_\theta U_0)\) and can mix blocks. A block-diagonal local metric is another declared rule. In positive coordinates \(\kappa=e^s\), the covector and metric transform as
\(g_s=\kappa g_\kappa,\ H_s=\kappa^2H_\kappa\).
The combined exact derivative is
\[
 \frac{d}{dt}\mathcal F_T
 =-T^2\int q\|\nabla\log(q/\pi_{T,\theta})\|_M^2d\nu
                         -g_\theta^TH_\theta^{-1}g_\theta\le0.
 \tag{43}
\]
Local score functions require both recognition and generative-model expectations of local statistics. They are not determined by arbitrary singleton marginals. This identity assumes exact expectations; stochastic estimates require separate analysis. No parameter-convergence or unforced truth-identification claim follows. In particular learning may reduce the approximation gap (22). The microscopic witness can keep these quantities as fixed boundary data while its model-law points and links genuinely move.

## 12. Gauge covariance and final scope

For independent passive channel re-expressions \(h_i^b,h_i^m\in SO(d)\),
\[
 u_i'=h_i^bu_i,\quad v_i'=h_i^mv_i,\quad
 R_e^{x\prime}=h_i^xR_e^x(h_j^x)^{-1},\quad
 C_i'=h_i^bC_i(h_i^m)^{-1},\quad
 k_i'=h_i^bk_i,\quad \zeta_i'=h_i^m\zeta_i.
 \tag{44}
\]
Each residual transforms by its receiver's orthogonal map; Lebesgue/Haar references are invariant. Thus (3), (8), (11), and (13) push forward covariantly, and both normalizers are invariant. Isotropic node metrics and the bi-invariant group metric give covariance of the drift, generator and dissipation. The passive two-frame description does not create a second principal bundle. \(C=I\) is a common-frame specialization, not a license to omit its transformation.

The strongest result is the normalized microscopic experiment, exact all-couplings evaluator projection, explicit positive variational gap, and local reversible dynamics with exact descent. The nonzero compatible sector and radial rates give a concrete regime for the companion attraction analysis.

The minimal remaining bridge for this lane is a retained description admitting controlled elimination under the actual generator, with required holonomy, evaluator correction, inherited mobility and conditional dependence, followed by a second reduction. Gauge-angle/stabilizer directions need not be fast. A finite-temperature effective density cannot be replaced by deterministic slaving, and a parent cannot receive a new Fisher metric without changing the dynamics. A projectability identity or a quantitative conditional-mixing/Poisson estimate for an explicitly realized regular regime would materially change that answer.

No trajectory simulation, numerical test, old scientific rerun, GPU work, external theorem search, production-code change, or vault edit was performed for this file. Its evidence is the written construction. No formal closure certificate is claimed. The only owned output is this document; the parent task maintains shared status files and the daily log.

