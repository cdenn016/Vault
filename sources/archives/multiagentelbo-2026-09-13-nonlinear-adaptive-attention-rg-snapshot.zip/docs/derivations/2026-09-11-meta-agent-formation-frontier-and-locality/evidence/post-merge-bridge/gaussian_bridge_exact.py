"""Small exact Gaussian parent identities; no sampling or prior-science execution."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys
import time

Matrix = list[list[F]]


def mat(rows: list[list[int]]) -> Matrix:
    return [[F(x) for x in row] for row in rows]


def eye(n: int) -> Matrix:
    return [[F(i == j) for j in range(n)] for i in range(n)]


def transpose(a: Matrix) -> Matrix:
    return [list(row) for row in zip(*a)]


def multiply(a: Matrix, b: Matrix) -> Matrix:
    return [[sum((x*y for x, y in zip(row, col)), F(0))
             for col in zip(*b)] for row in a]


def inverse(a: Matrix) -> Matrix:
    n = len(a)
    aug = [row[:] + unit for row, unit in zip(a, eye(n))]
    for j in range(n):
        k = next(k for k in range(j, n) if aug[k][j])
        aug[j], aug[k] = aug[k], aug[j]
        pivot = aug[j][j]
        aug[j] = [v/pivot for v in aug[j]]
        for i in range(n):
            if i != j:
                coefficient = aug[i][j]
                aug[i] = [u-coefficient*v for u, v in zip(aug[i], aug[j])]
    return [row[n:] for row in aug]


def determinant(a: Matrix) -> F:
    b = [row[:] for row in a]
    result = F(1)
    for j in range(len(b)):
        k = next((k for k in range(j, len(b)) if b[k][j]), None)
        if k is None:
            return F(0)
        if k != j:
            b[k], b[j] = b[j], b[k]
            result = -result
        pivot = b[j][j]
        result *= pivot
        for i in range(j+1, len(b)):
            coefficient = b[i][j]/pivot
            b[i] = [u-coefficient*v for u, v in zip(b[i], b[j])]
    return result


def main() -> None:
    start = time.perf_counter()
    d = mat([[i+1 if i == j else 0 for j in range(4)] for i in range(4)])
    a = mat([[1], [2], [3], [4]])
    gram = multiply(a, transpose(a))
    sigma = [[d[i][j]+gram[i][j] for j in range(4)] for i in range(4)]
    precision = [[F(i == j, i+1)-F(1, 11) for j in range(4)] for i in range(4)]
    assert inverse(sigma) == precision
    assert determinant(sigma) == 264
    joint = [[F(11)]+[F(-1)]*4]
    joint += [[F(-1)]+[F(i == j, i+1) for j in range(4)] for i in range(4)]
    assert determinant(joint) == F(1, 24)
    omitted = [row[:] for row in joint]
    omitted[0][0] -= 1
    null_vector = mat([[1], [1], [2], [3], [4]])
    assert determinant(omitted) == 0
    assert multiply(omitted, null_vector) == mat([[0]]*5)
    # This one-child case also has the common unit noise used in PIFB2.
    assert determinant(mat([[2, -1], [-1, 1]])) == 1
    assert determinant(mat([[1, -1], [-1, 1]])) == 0
    counter = mat([[10, 1, 1, 1], [1, 10, 1, 2],
                   [1, 1, 10, 1], [1, 2, 1, 10]])
    u = mat([[1, 0], [1, 1], [1, 0], [1, 1]])
    noise = (9, 8, 9, 8)
    gram_two = multiply(u, transpose(u))
    reconstructed = [[gram_two[i][j]+(noise[i] if i == j else 0)
                      for j in range(4)] for i in range(4)]
    assert reconstructed == counter
    assert determinant(counter) == 9216
    assert min(counter[i][i]-sum(abs(counter[i][j]) for j in range(4) if j != i)
               for i in range(4)) == 6
    assert counter[0][1]*counter[2][3] != counter[0][2]*counter[1][3]
    # Lift the scalar two-factor realization to four-dimensional children.
    loading = [[u[i//4][j//4]*F(i % 4 == j % 4) for j in range(8)] for i in range(16)]
    covariance = multiply(loading, transpose(loading))
    for i in range(16):
        covariance[i][i] += noise[i//4]
    expected = [[counter[i//4][j//4]*F(i % 4 == j % 4)
                 for j in range(16)] for i in range(16)]
    assert covariance == expected
    assert determinant(covariance) == F(9216)**4
    block1, block2, block3, block4 = [loading[4*i:4*i+4] for i in range(4)]
    difference = [[x-y for x, y in zip(row4, row3)] for row4, row3 in zip(block4, block3)]
    assert multiply(block1, transpose(difference)) == mat([[0]*4]*4)
    assert multiply(block2, transpose(difference)) == eye(4)
    result = {
        'status': 'PASS', 'runtime': sys.executable, 'python': platform.python_version(),
        'command': [sys.executable, '-I', '-B', str(Path(__file__).resolve())],
        'script_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
        'one_factor': {'det_sigma': '264', 'det_joint_precision': '1/24',
                       'posterior_variance': '1/11', 'omitted_root_det': '0',
                       'omitted_root_null_vector': [1, 1, 2, 3, 4]},
        'four_child_four_coordinate_witness': {
            'scalar_covariance': [[str(x) for x in row] for row in counter],
            'scalar_det': '9216', 'full_det': str(determinant(covariance)),
            'full_dimension': 16, 'constructive_latent_dimension': 8,
            'minimum_latent_dimension': '8, lower bound by written row-space proof',
            'positive_child_noise_scalars': list(noise)},
        'dimension_count': {str(r): 40+16*r-r*(r-1)//2 for r in (4, 7, 8)},
        'ambient_spd_dimension': 136,
        'scope': 'Exact finite matrix identities only; general claims require the accompanying proofs.',
        'not_run': ['sampling', 'ODE integration', 'production model', 'previous scientific scripts',
                    'pytest', 'GPU', 'Lean', 'tamper checks'],
        'elapsed_seconds': time.perf_counter()-start,
    }
    Path(__file__).with_name('result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
