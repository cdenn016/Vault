"""Exact two-node Gaussian link-learning discriminator; no simulation or fitting."""
from fractions import Fraction as F
from pathlib import Path
import json
import sys

Matrix = tuple[tuple[F, F], tuple[F, F]]


def mul(a: Matrix, b: Matrix) -> Matrix:
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(2))
                       for j in range(2)) for i in range(2))


def add(a: Matrix, b: Matrix) -> Matrix:
    return tuple(tuple(a[i][j] + b[i][j] for j in range(2)) for i in range(2))


def scale(a: Matrix, c: F) -> Matrix:
    return tuple(tuple(c * a[i][j] for j in range(2)) for i in range(2))


def det(a: Matrix) -> F:
    return a[0][0] * a[1][1] - a[0][1] * a[1][0]


def inv(a: Matrix) -> Matrix:
    d = det(a)
    return ((a[1][1] / d, -a[0][1] / d),
            (-a[1][0] / d, a[0][0] / d))


def trace(a: Matrix) -> F:
    return a[0][0] + a[1][1]


def main() -> None:
    r"""Check M, dF/dtheta and the t^2 parent-rate defect by two routes."""
    theta = F(1, 2)
    J0: Matrix = ((1 + theta**2, -theta), (-theta, F(1)))
    Ja: Matrix = ((2 * theta, F(-1)), (F(-1), F(0)))
    Jaa: Matrix = ((F(2), F(0)), (F(0), F(0)))
    K = add(J0, ((F(0), F(0)), (F(0), F(1))))
    C0, C = inv(J0), inv(K)
    metric = trace(mul(mul(mul(C0, Ja), C0), Ja)) / 2
    gradient = trace(mul(add(C, scale(C0, F(-1))), Ja)) / 2
    velocity = -gradient / metric
    assert metric == 1
    assert gradient == theta / (2 + theta**2) == F(2, 9)
    assert det(Ja) == -1
    conditional_C = 1 / K[0][0]
    conditional_B = -K[0][1] / K[0][0]
    C_dot = -Ja[0][0] * velocity / K[0][0]**2
    B_dot = (-Ja[0][1] * K[0][0] + K[0][1] * Ja[0][0]) * velocity / K[0][0]**2
    speed_constant = (C_dot / conditional_C)**2 / 2
    speed_y_squared = B_dot**2 / conditional_C
    parent_variance = C[1][1]
    conditional_route = -parent_variance**2 * speed_y_squared
    # Independent Taylor reconstruction from Jdot=K(theta)-J and
    # the complete-joint natural M-flow, with q(0)=posterior(theta(0)).
    theta_t2 = -C[0][0] * velocity / 2
    J_t2 = scale(Ja, velocity / 2)
    K_t2 = add(scale(Ja, theta_t2), scale(Jaa, velocity**2 / 2))
    J_t3 = scale(add(K_t2, scale(J_t2, F(-1))), F(1, 3))
    variance_t2 = -mul(mul(C, J_t2), C)[1][1]
    fine_rate_t2 = -3 * mul(mul(C, J_t3), C)[1][1]
    target_precision_d1 = -2 * theta / (1 + theta**2)**2
    target_precision_d2 = (-2 + 6 * theta**2) / (1 + theta**2)**3
    target_precision_t2 = target_precision_d1 * theta_t2 + target_precision_d2 * velocity**2 / 2
    autonomous_rate_t2 = -variance_t2 - parent_variance**2 * target_precision_t2
    joint_route = fine_rate_t2 - autonomous_rate_t2
    assert conditional_route == joint_route == F(-16, 3645)
    assert conditional_B == F(2, 5) and conditional_C == F(4, 5)
    assert B_dot == F(-8, 75) and C_dot == F(32, 225)
    assert speed_constant == F(32, 2025)
    assert speed_y_squared == F(16, 1125)
    result = {
        "scope": "Exact rational coefficient check for one two-node scalar Gaussian instance; not a hierarchy or universal proof",
        "runtime": sys.version,
        "executable": sys.executable,
        "theta": str(theta),
        "observation": "0",
        "prior_precision": [[str(x) for x in row] for row in J0],
        "posterior_covariance": [[str(x) for x in row] for row in C],
        "model_fisher": str(metric),
        "model_fisher_log_theta_chart": str(theta**2 * metric),
        "gradient": str(gradient),
        "theta_velocity": str(velocity),
        "conditional_variance": str(conditional_C),
        "conditional_regression": str(conditional_B),
        "conditional_variance_velocity": str(C_dot),
        "conditional_regression_velocity": str(B_dot),
        "conditional_fisher_speed_constant": str(speed_constant),
        "conditional_fisher_speed_y_squared": str(speed_y_squared),
        "parent_variance_rate_defect_t_squared_conditional_route": str(conditional_route),
        "parent_variance_rate_defect_t_squared_joint_route": str(joint_route),
        "precision_derivative_determinant": str(det(Ja)),
        "all_assertions_passed": True,
    }
    output = Path(__file__).with_name("two-node-exact-result.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
