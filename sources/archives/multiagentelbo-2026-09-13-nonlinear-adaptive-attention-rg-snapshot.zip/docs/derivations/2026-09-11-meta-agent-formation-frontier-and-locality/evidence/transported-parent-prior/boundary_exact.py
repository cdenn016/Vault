"""Exact Taylor coefficients at zero child variance; no parameter sweep."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import permutations, product
import json
from pathlib import Path
import platform
import time

folder=Path(__file__).parent
source=folder.parent/'shared-parent-record/shared_parent_exact.py'
spec=importlib.util.spec_from_file_location('existing_gaussian_definitions',source)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
h=g.helper
Matrix=list[list[F]]


def determinant_polynomial(constant: Matrix, linear: Matrix) -> list[F]:
    n=len(constant)
    output=[F(0)]*(n+1)
    for sigma in permutations(range(n)):
        sign=(-1)**sum(sigma[i]>sigma[j] for i in range(n) for j in range(i+1,n))
        coefficients=[F(sign)]
        for i,j in enumerate(sigma):
            updated=[F(0)]*(len(coefficients)+1)
            for k,v in enumerate(coefficients):
                updated[k]+=v*constant[i][j]
                updated[k+1]+=v*linear[i][j]
            coefficients=updated
        output=[x+y for x,y in zip(output,coefficients)]
    return output


def reciprocal_series(coefficients: list[F], degree: int) -> list[F]:
    assert coefficients[0]>0
    result=[1/coefficients[0]]
    for k in range(1,degree+1):
        result.append(-sum((coefficients[j]*result[k-j] for j in range(1,min(k,len(coefficients)-1)+1)),F(0))/coefficients[0])
    return result


def cut_evidence(covariance: Matrix, counts: tuple[int, ...]) -> F:
    n=len(counts)
    value=F(0)
    for bits in product((0,1),repeat=n):
        powers=tuple(x+y for x,y in zip(counts,bits))
        matrix=[[F(i==j)+covariance[i][j]*powers[j] for j in range(n)] for i in range(n)]
        value+=(-1)**sum(bits)/h.determinant(matrix)
    assert value>0
    return value


def permanent(matrix: Matrix) -> F:
    total=F(0)
    for sigma in permutations(range(len(matrix))):
        term=F(1)
        for i,j in enumerate(sigma):
            term*=matrix[i][j]
        total+=term
    return total


def main() -> None:
    start=time.perf_counter()
    source_result=folder/'result.json'
    data=json.loads(source_result.read_text())
    lap=h.multiply(g.B,h.transpose(g.B))
    rows=[]
    checked=0
    for row in data['rows']:
        k=row['k']; degree=4-k
        detail=[]
        for dec in row['details']:
            gamma=[[F(v) for v in line] for line in dec['Gamma']]
            gamma0=[[gamma[i][j]-lap[i][j] for j in range(4)] for i in range(4)]
            coefficients=[F(0)]*(degree+1)
            for bits in product((0,1),repeat=4):
                powers=tuple(n+b for n,b in zip(g.N,bits))
                base=[[F(i==j)+gamma0[i][j]*powers[j] for j in range(4)] for i in range(4)]
                linear=[[lap[i][j]*powers[j] for j in range(4)] for i in range(4)]
                det=determinant_polynomial(base,linear)
                assert det[4]==0
                reciprocal=reciprocal_series(det,degree)
                coefficients=[x+(-1)**sum(bits)*y for x,y in zip(coefficients,reciprocal)]
            internal=sorted(e for tree in dec['trees'] for e in tree)
            cuts=[e for e in range(4) if e not in internal]
            tree_gram=[[lap[i][j] for j in internal] for i in internal]
            tree_moment=permanent(tree_gram)
            cut_cov=[[gamma0[i][j] for j in cuts] for i in cuts]
            limit=cut_evidence(cut_cov,tuple(g.N[i] for i in cuts))
            expected=tree_moment*limit
            assert coefficients[:-1]==[F(0)]*degree
            assert coefficients[-1]==expected and expected>0
            detail.append({'roots':dec['roots'],'trees':dec['trees'],'tree_moment':str(tree_moment),
                           'one_channel_leading_coefficient':str(expected),
                           'taylor_coefficients':[str(v) for v in coefficients]})
            checked+=1
        leading=sum((F(d['one_channel_leading_coefficient'])**2 for d in detail),F(0))/len(detail)
        rows.append({'partition':row['partition'],'joint_exponent':2*degree,'joint_leading_coefficient':str(leading),
                     'joint_leading_coefficient_float':float(leading),'details':detail})
    assert checked==45
    result={'status':'PASS','scope':'Exact rational Taylor coefficients at a=0 with b=c=1; general asymptotics are proved in the document.',
            'python':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
            'input_result_sha256':sha256(source_result.read_bytes()).hexdigest(),'decorations_checked':checked,'rows':rows,
            'elapsed_seconds':time.perf_counter()-start,'not_run':['nonzero-a parameter samples','parameter search','optimization','native-flow trajectory','new data','sampling','pytest','GPU','Lean','tamper checks']}
    Path(__file__).with_name('boundary-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','decorations_checked','elapsed_seconds')},indent=2))
    for row in rows:
        print(row['partition'],row['joint_exponent'],row['joint_leading_coefficient_float'])

if __name__=='__main__':
    main()
