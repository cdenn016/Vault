"""All connected ancestry/root/tree priors at one fixed covariance point."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import combinations, product
import json
from pathlib import Path
import platform
import sys
import time

folder = Path(__file__).parent
source = folder.parent/'shared-parent-record/shared_parent_exact.py'
spec = importlib.util.spec_from_file_location('existing_gaussian_definitions',source)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)  # Guarded main is not executed.
h = g.helper
Matrix = list[list[F]]
EDGES = ((0,1),(1,2),(2,3),(3,0))


def add(a: Matrix, b: Matrix, factor: F = F(1)) -> Matrix:
    return [[x+factor*y for x,y in zip(aa,bb)] for aa,bb in zip(a,b)]


def trace(a: Matrix) -> F:
    return sum((a[i][i] for i in range(len(a))),F(0))


def gram(a: Matrix) -> Matrix:
    return h.multiply(a,h.transpose(a))


def path_rows(block: tuple[int, ...], tree: tuple[int, ...], root: int) -> dict[int, list[F]]:
    paths = {root:[F(0)]*4}
    queue = [root]
    for u in queue:
        for e in tree:
            a,b = EDGES[e]
            if u not in (a,b):
                continue
            v = b if u == a else a
            if v in paths:
                continue
            row = paths[u][:]
            row[e] += 1 if u == a else -1
            paths[v] = row
            queue.append(v)
    return paths if set(paths)==set(block) else {}


def decorations(labels: tuple[int, ...]) -> list[dict]:
    blocks = [tuple(i for i,label in enumerate(labels) if label==j) for j in range(max(labels)+1)]
    choices = []
    for block in blocks:
        internal = [e for e,(u,v) in enumerate(EDGES) if u in block and v in block]
        options = []
        for tree in combinations(internal,len(block)-1):
            for root in block:
                paths = path_rows(block,tree,root)
                if paths:
                    options.append((tree,root,paths))
        if not options:
            return []
        choices.append(options)
    result = []
    for combo in product(*choices):
        p = [[F(0)]*4 for _ in range(4)]
        for tree,root,paths in combo:
            for i,row in paths.items():
                p[i] = row
        c = add(h.eye(4),h.multiply(g.B,p),F(-1))
        for tree,_,_ in combo:
            for e in tree:
                assert all(x==0 for x in c[e])
        assert [sum(c[i][j] for i in range(4)) for j in range(4)] == [F(1)]*4
        result.append({'roots':[item[1] for item in combo], 'trees':[list(item[0]) for item in combo], 'paths':p,'C':c})
    return result


def posterior(gamma: Matrix) -> tuple[F, Matrix, list[F]]:
    inv = h.inverse(gamma)
    numerator = h.mat([[0]*4]*4)
    evidence = F(0)
    for bits in product((0,1),repeat=4):
        powers = tuple(n+s for n,s in zip(g.N,bits))
        weight = (-1)**sum(bits)*g.moment(gamma,powers)
        precision = [[inv[i][j]+F(powers[i] if i==j else 0) for j in range(4)] for i in range(4)]
        numerator = add(numerator,h.inverse(precision),weight)
        evidence += weight
    assert evidence == g.evidence(gamma) and evidence>0
    cov = [[x/evidence for x in row] for row in numerator]
    for n in range(1,5):
        assert h.determinant([row[:n] for row in gamma[:n]])>0
        assert h.determinant([row[:n] for row in cov[:n]])>0
    delta = h.multiply(h.multiply(inv,add(cov,gamma,F(-1))),inv)
    panel = []
    for outcomes in product((0,1),repeat=4):
        failures = [i for i,v in enumerate(outcomes) if not v]
        value = F(0)
        for extras in product((0,1),repeat=len(failures)):
            powers = list(outcomes)
            for i,v in zip(failures,extras):
                powers[i] += v
            value += (-1)**sum(extras)*g.moment(gamma,tuple(powers))
        assert value>0
        panel.append(value)
    assert sum(panel)==1
    return evidence,delta,panel


def main() -> None:
    start = time.perf_counter()
    old_path = folder.parent/'shared-parent-record/result.json'
    old = json.loads(old_path.read_text())
    old_scores = {tuple(row['restricted_growth_labels']):F(row['two_channel_evidence']) for row in old['rows']}
    lap = gram(g.B)
    rows = []
    excluded = []
    cache = {}
    decorated_total = 0
    for labels in g.partitions():
        decs = decorations(labels)
        blocks = [[i for i,v in enumerate(labels) if v==j] for j in range(max(labels)+1)]
        if not decs:
            excluded.append(blocks)
            continue
        k = len(blocks)
        incidence = [[F(v==j) for j in range(k)] for v in labels]
        block_map = h.multiply(g.B,incidence)
        block_gram = gram(block_map)
        detail = []
        joint_panel = [F(0)]*256
        for dec in decs:
            c_gram = gram(dec['C'])
            gamma = add(add(lap,block_gram),c_gram)
            key = tuple(tuple(row) for row in gamma)
            if key not in cache:
                cache[key] = posterior(gamma)
            evidence,delta,panel = cache[key]
            m_a = 1+trace(h.multiply(lap,delta))/4
            m_b = 1+trace(h.multiply(block_gram,delta))/k
            m_c = 1+trace(h.multiply(c_gram,delta))/4
            assert min(m_a,m_b,m_c)>0
            # Independent reconstruction from all primitive-noise coordinates.
            noise_map = [g.B[i]+block_map[i]+[-x for x in dec['C'][i]]+[F(0)] for i in range(4)]
            full_cov = add(h.eye(9+k),h.multiply(h.multiply(h.transpose(noise_map),delta),noise_map))
            assert sum(full_cov[i][i] for i in range(4))/4 == m_a
            assert sum(full_cov[i][i] for i in range(4,4+k))/k == m_b
            assert sum(full_cov[i][i] for i in range(4+k,8+k))/4 == m_c
            assert full_cov[-1][-1]==1
            if k==1:
                assert m_b==1
            for a in range(16):
                for b in range(16):
                    joint_panel[16*a+b] += panel[a]*panel[b]/len(decs)
            detail.append({'roots':dec['roots'],'trees':dec['trees'],
                           'path_matrix':[[str(x) for x in row] for row in dec['paths']],
                           'C':[[str(x) for x in row] for row in dec['C']],
                           'Gamma':[[str(x) for x in row] for row in gamma],
                           'one_channel_evidence':str(evidence),'joint_evidence':str(evidence**2),
                           'M_energy_coordinates':[str(m_a),str(m_b),str(m_c)]})
        assert sum(joint_panel)==1
        score = sum((F(dec['joint_evidence']) for dec in detail),F(0))/len(decs)
        # Root and tree are shared between channels: average e_H squared, never square average e_H.
        squared_mean = (sum((F(dec['one_channel_evidence']) for dec in detail),F(0))/len(decs))**2
        assert score>=squared_mean
        pooled = [sum((F(dec['joint_evidence'])*F(dec['M_energy_coordinates'][j]) for dec in detail),F(0))/(len(decs)*score) for j in range(3)]
        row = {'partition':blocks,'labels':list(labels),'k':k,'decorations':len(decs),'details':detail,
               'evidence':str(score),'evidence_float':float(score),'incorrect_squared_channel_average':str(squared_mean),
               'shared_geometry_channel_correction':str(score-squared_mean),
               'posterior_M_energy_coordinates':[str(v) for v in pooled],
               'initial_native_variance_derivative':[str(v-1) for v in pooled],
               'initial_native_variance_derivative_float':[float(v-1) for v in pooled],
               'ratio_to_previous_untransported_same_partition':str(score/old_scores[labels]),
               'joint_one_panel_probabilities':[str(v) for v in joint_panel]}
        rows.append(row)
        decorated_total += len(decs)
    assert len(rows)==12 and len(excluded)==3 and decorated_total==45
    rows.sort(key=lambda row:F(row['evidence']),reverse=True)
    single = next(F(row['evidence']) for row in rows if row['k']==1)
    for row in rows:
        row['ratio_to_single_block']=str(F(row['evidence'])/single)
    best = F(rows[0]['evidence'])
    # Two-stage prior covariance witness at a=b=c=v=1, per coordinate.
    # Independent basis Y,xi_A,xi_B,epsbar_A,epsbar_B,V12,V30 has variances 1,1,1,1/2,1/2,2,2.
    d = h.mat([[F(0)]*7 for _ in range(7)])
    for i,v in enumerate((F(1),F(1),F(1),F(1,2),F(1,2),F(2),F(2))):
        d[i][i] = v
    z = h.mat([[1,F(1,2),F(1,2),F(1,2),F(1,2),F(-1,2),0],[0,0,0,0,0,1,1]])
    root_loop = h.multiply(h.multiply(z,d),h.transpose(z))
    assert root_loop == h.mat([[F(9,4),-1],[-1,4]])
    assert h.determinant(root_loop)==8
    assert root_loop[0][0]-root_loop[0][1]**2/root_loop[1][1]==2
    result={'status':'PASS','runtime':sys.executable,'python':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
            'source_script_sha256':sha256(source.read_bytes()).hexdigest(),'matrix_helper_sha256':sha256(g.HELPER.read_bytes()).hexdigest(),'previous_result_sha256':sha256(old_path.read_bytes()).hexdigest(),
            'model':'Declared transported child-coordinate prior; same original ordered record batch.',
            'unit_variances':{'a':'1','b':'1','c':'1','v':'1'},'partition_prior':'No numerical values selected.',
            'within_partition_prior':'Uniform roots and internal spanning trees, shared by both channels.',
            'connected_partitions':len(rows),'decorated_states':decorated_total,'distinct_covariances':len(cache),
            'excluded_disconnected_partitions':excluded,'maximizers':[row['partition'] for row in rows if F(row['evidence'])==best],
            'rows':rows,'root_loop_covariance':[[str(x) for x in row] for row in root_loop],
            'elapsed_seconds':time.perf_counter()-start,'not_run':['finite M update','parameter fitting','parameter search','stochastic samples','new data','ODE','previous helper mains','pytest','GPU','Lean','tamper checks','publication']}
    Path(__file__).with_name('result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:result[key] for key in ('status','connected_partitions','decorated_states','distinct_covariances','maximizers','root_loop_covariance','elapsed_seconds')},indent=2))
    for row in rows:
        print(row['partition'],row['evidence_float'],row['initial_native_variance_derivative_float'])

if __name__ == '__main__':
    main()
