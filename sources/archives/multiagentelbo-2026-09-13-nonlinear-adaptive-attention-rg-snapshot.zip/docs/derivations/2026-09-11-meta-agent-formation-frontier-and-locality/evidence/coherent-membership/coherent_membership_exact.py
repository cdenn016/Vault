"""Exact finite witnesses for the coherent-membership derivation; no simulation."""
from __future__ import annotations

from fractions import Fraction as F
from itertools import combinations
from math import comb, factorial
from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys
import time

Matrix = tuple[tuple[F, ...], ...]
Partition = tuple[tuple[int, ...], ...]
Counts = tuple[int, int, int, int]


def matrix(rows: list[list[int | F]]) -> Matrix:
    return tuple(tuple(F(x) for x in row) for row in rows)


def eye(n: int) -> Matrix:
    return tuple(tuple(F(i == j) for j in range(n)) for i in range(n))


def transpose(a: Matrix) -> Matrix:
    return tuple(zip(*a))


def multiply(a: Matrix, b: Matrix) -> Matrix:
    return tuple(tuple(sum((a[i][k] * b[k][j] for k in range(len(b))), F(0))
                       for j in range(len(b[0]))) for i in range(len(a)))


def scale(a: Matrix, value: F) -> Matrix:
    return tuple(tuple(value * x for x in row) for row in a)


def subtract(a: Matrix, b: Matrix) -> Matrix:
    return tuple(tuple(x-y for x, y in zip(ar, br)) for ar, br in zip(a, b))


def trace(a: Matrix) -> F:
    return sum((a[i][i] for i in range(len(a))), F(0))


def inverse(a: Matrix) -> Matrix:
    """Return the exact inverse by rational row elimination."""
    n = len(a)
    rows = [list(a[i]) + list(eye(n)[i]) for i in range(n)]
    for j in range(n):
        pivot = next(i for i in range(j, n) if rows[i][j])
        rows[j], rows[pivot] = rows[pivot], rows[j]
        value = rows[j][j]
        rows[j] = [x / value for x in rows[j]]
        for i in range(n):
            if i != j:
                value = rows[i][j]
                rows[i] = [x-value*y for x, y in zip(rows[i], rows[j])]
    return tuple(tuple(row[n:]) for row in rows)


def determinant(a: Matrix) -> F:
    """Return det(a) by exact elimination without floating arithmetic."""
    rows = [list(row) for row in a]
    value = F(1)
    for j in range(len(a)):
        pivot = next(i for i in range(j, len(a)) if rows[i][j])
        if pivot != j:
            rows[j], rows[pivot] = rows[pivot], rows[j]
            value = -value
        value *= rows[j][j]
        for i in range(j+1, len(a)):
            ratio = rows[i][j] / rows[j][j]
            rows[i] = [x-ratio*y for x, y in zip(rows[i], rows[j])]
    return value


def tensor(a: Matrix, b: Matrix) -> Matrix:
    return tuple(tuple(a[i][j]*b[k][l] for j in range(len(a[0])) for l in range(len(b[0])))
                 for i in range(len(a)) for k in range(len(b)))


def model_factor(c: F) -> Matrix:
    r"""Model covariance is M(c) tensor Sigma, M(c)=[[c,c],[c,c^2/(c-1)]]."""
    return matrix([[c, c], [c, c*c/(c-1)]])


def beta(a: int, b: int) -> F:
    r"""Euler integral B(a,b)=(a-1)!(b-1)!/(a+b-1)! for positive integers."""
    assert a > 0 and b > 0
    return F(factorial(a-1)*factorial(b-1), factorial(a+b-1))


def cut_evidence(counts: Counts, alpha: int, beta_shape: int) -> F:
    r"""Integrate p^S (1-p)^F (1+p)^f_m against Beta(alpha,beta_shape)."""
    s_b, f_b, s_m, f_m = counts
    s, failures = s_b+2*s_m, f_b+f_m
    return sum((comb(f_m,j)*beta(alpha+s+j,beta_shape+failures)
                for j in range(f_m+1)), F(0))/beta(alpha,beta_shape)


def independent_cut_integral(counts: Counts, alpha: int, beta_shape: int) -> F:
    r"""Integrate the original p^S(1-p)^f_b(1-p^2)^f_m by a separate expansion."""
    s_b, f_b, s_m, f_m = counts
    s = s_b+2*s_m
    return sum(((-1)**(u+v)*comb(f_b,u)*comb(f_m,v)*beta(alpha+s+u+2*v,beta_shape)
                for u in range(f_b+1) for v in range(f_m+1)), F(0))/beta(alpha,beta_shape)


def partitions(n: int) -> tuple[Partition, ...]:
    if n == 0:
        return ((),)
    result = []
    for old in partitions(n-1):
        result.append(old+((n-1,),))
        for j in range(len(old)):
            result.append(old[:j]+(old[j]+(n-1,),)+old[j+1:])
    return tuple(sorted(result))


def same_block(r: Partition, i: int, j: int) -> bool:
    return any(i in block and j in block for block in r)


def components(n: int, edges: list[tuple[int, int]]) -> Partition:
    pending = set(range(n))
    result = []
    while pending:
        block, todo = set(), [min(pending)]
        while todo:
            i = todo.pop()
            if i in block:
                continue
            block.add(i)
            todo.extend(j for a, j in edges if a == i and j not in block)
            todo.extend(a for a, j in edges if j == i and a not in block)
        pending -= block
        result.append(tuple(sorted(block)))
    return tuple(sorted(result))


def refine(q: Partition, r: Partition) -> bool:
    return all(any(set(a) <= set(b) for b in r) for a in q)


def label(r: Partition) -> str:
    return '|'.join(''.join(map(str, block)) for block in r)


def costs(r: Partition) -> tuple[int, int]:
    n, k = 4, 2
    s, h = k*(k+1)//2, k*(k-1)//2
    internal = sum(same_block(r,i,j) for i,j in combinations(range(n),2))
    cuts, loops = 6-internal, internal-n+len(r)
    fine, parent = n*s+internal*h+cuts*k*k, len(r)*s+loops*h+cuts*k*k
    assert fine-parent == (n-len(r))*k*k
    return fine, parent


def posterior_example(n: int, menu: tuple[Partition, ...]) -> dict:
    """Use a specified possible ordered-record word, never sampled data."""
    edges = tuple(combinations(range(4),2))
    word = {e: (n,0,n,0) if e in ((0,1),(2,3)) else (n-1,1,n,0) for e in edges}
    raw = {}
    for r in menu:
        value = F(1,len(menu))
        for e in edges:
            counts = word[e]
            value *= F(counts[1]+counts[3] == 0) if same_block(r,*e) else cut_evidence(counts,1,1)
        raw[r] = value
    evidence = sum(raw.values(),F(0))
    weights = {r:v/evidence for r,v in raw.items()}
    assert sum(weights.values(),F(0)) == 1
    target = ((0,1),(2,3))
    assert weights[target] == F((3*n+1)**2,(3*n+2)**2)
    assert sum(v > 0 for v in weights.values()) == 4
    if n == 2:
        assert evidence == F(4,142943535)
        assert sorted(v for v in weights.values() if v) == [F(1,64),F(7,64),F(7,64),F(49,64)]
    expected_fine = sum((v*costs(r)[0] for r,v in weights.items()),F(0))
    expected_parent = sum((v*costs(r)[1] for r,v in weights.items()),F(0))
    expected_blocks = sum((v*len(r) for r,v in weights.items()),F(0))
    if n == 2:
        assert (expected_fine,expected_parent,expected_blocks) == (F(123,4),F(95,4),F(9,4))
        assert expected_fine-expected_parent == 7
    return {'paired_rounds':n,'ordered_counts':{str(e):v for e,v in word.items()},
            'evidence':evidence,'all_partition_weights':{label(r):v for r,v in weights.items()},
            'expected_fine_coordinates':expected_fine,'expected_parent_coordinates':expected_parent,
            'expected_blocks':expected_blocks,'cut_nonfailure_tail':F(1,3*n+1),
            'two_pair_readout_error':1-(1-F(1,3*n+1))**4}


def main() -> None:
    start = time.perf_counter()
    script = Path(__file__).resolve()
    root = script.parents[5]
    document = script.parents[2]/'coherent-membership-and-recursion-limit.md'
    result_path = script.with_name('coherent-membership-exact-result.json')
    assert not result_path.exists()
    identity = eye(2)
    s_i, s_j = matrix([[2,1],[1,1]]), matrix([[1,0],[0,2]])
    sigma_i, sigma_j = multiply(s_i,s_i), multiply(s_j,s_j)
    b = matrix([[F(3,2),F(1,2)],[F(1,2),F(3,2)]])
    o = matrix([[0,1],[-1,0]])
    a = multiply(inverse(b),o)
    theta = multiply(multiply(s_i,a),inverse(s_j))
    target = multiply(multiply(theta,sigma_j),transpose(theta))
    y = multiply(b,b)
    assert trace(multiply(inverse(target),sigma_i)) == trace(y) == 5
    assert determinant(target)/determinant(sigma_i) == 1/determinant(y) == F(1,4)
    conditionals = []
    for c in (F(2),F(3)):
        xx = scale(sigma_i,c)
        xz = scale(sigma_i,c)
        zz = scale(sigma_i,c*c/(c-1))
        gain = multiply(xz,inverse(zz))
        conditional = subtract(xx,multiply(gain,transpose(xz)))
        assert conditional == sigma_i
        assert gain == scale(identity,(c-1)/c)
        conditionals.append({'c':c,'gain':gain,'conditional_covariance':conditional})
    m_i, m_j = model_factor(F(3)),model_factor(F(2))
    model_source, model_target = tensor(m_i,sigma_i), tensor(m_j,target)
    relative_trace = trace(multiply(inverse(model_target),model_source))
    relative_det = determinant(model_target)/determinant(model_source)
    a_ij = trace(multiply(inverse(m_j),m_i))
    assert a_ij == F(9,4)
    assert relative_trace == a_ij*trace(y) == F(45,4)
    assert relative_det == (determinant(m_j)/determinant(m_i))**2/determinant(y)**2 == F(4,81)
    amgm_ratio = ((1+a_ij)/3)**3*determinant(m_j)/determinant(m_i)
    assert amgm_ratio == F(2197,1944) > 1
    common_m = model_factor(F(2))
    common_source, common_target = tensor(common_m,sigma_i),tensor(common_m,target)
    assert trace(multiply(inverse(common_target),common_source)) == 2*trace(y)
    assert determinant(common_target)/determinant(common_source) == (determinant(target)/determinant(sigma_i))**2
    h1, h2 = matrix([[1,0],[0,-1]]), matrix([[0,1],[1,0]])
    h1, h2 = [multiply(multiply(s_i,h),inverse(s_i)) for h in (h1,h2)]
    assert multiply(h1,h2) != multiply(h2,h1)
    for h in (h1,h2):
        assert multiply(multiply(h,sigma_i),transpose(h)) == sigma_i
        lifted = tensor(identity,h)
        assert multiply(multiply(lifted,common_source),transpose(lifted)) == common_source
    u_i,u_j = o,matrix([[1,0],[0,-1]])
    r_i,r_j = matrix([[2,0],[0,3]]),matrix([[3,1],[1,1]])
    t_i = multiply(multiply(r_i,transpose(u_i)),inverse(s_i))
    t_j = multiply(multiply(r_j,transpose(u_j)),inverse(s_j))
    dressed = multiply(multiply(t_i,theta),inverse(t_j))
    a_hat = multiply(multiply(transpose(u_i),a),u_j)
    assert dressed == multiply(multiply(r_i,a_hat),inverse(r_j))
    root_i,root_j = multiply(r_i,r_i),multiply(r_j,r_j)
    root_target = multiply(multiply(dressed,root_j),transpose(dressed))
    assert trace(multiply(inverse(root_target),root_i)) == trace(y)
    assert determinant(root_target)/determinant(root_i) == F(1,4)
    assert trace(multiply(inverse(tensor(m_j,root_target)),tensor(m_i,root_i))) == relative_trace
    shapes = ((1,1),(2,1),(1,3),(2,3))
    count_cases = ((0,0,0,0),(2,0,2,0),(1,1,2,0),(0,2,1,2),(2,1,0,1))
    beta_cases = []
    for alpha,beta_shape in shapes:
        for counts in count_cases:
            positive = cut_evidence(counts,alpha,beta_shape)
            expanded = independent_cut_integral(counts,alpha,beta_shape)
            assert positive == expanded and 0 < positive <= 1
            beta_cases.append({'shapes':(alpha,beta_shape),'counts':counts,'evidence':positive})
    menu = partitions(4)
    assert len(menu) == len(set(menu)) == 15
    edges = tuple(combinations(range(4),2))
    refinement_checks = 0
    for r in menu:
        zero = [e for e in edges if same_block(r,*e)]
        assert components(4,zero) == r
        for q in menu:
            if not refine(q,r):
                continue
            quotient_edges = []
            for i,j in zero:
                qi = next(k for k,block in enumerate(q) if i in block)
                qj = next(k for k,block in enumerate(q) if j in block)
                if qi != qj:
                    quotient_edges.append((qi,qj))
            quotient = components(len(q),quotient_edges)
            composed = tuple(sorted(tuple(sorted(v for qi in block for v in q[qi])) for block in quotient))
            assert composed == r
            refinement_checks += 1
    assert costs(((0,1),(2,3))) == (30,22)
    examples = [posterior_example(n,menu) for n in (1,2,8)]
    likelihood = examples[1]['evidence']
    h_prior = (F(1,3),F(2,3))
    h_joint = tuple(x*likelihood for x in h_prior)
    assert tuple(x/sum(h_joint) for x in h_joint) == h_prior
    payload = {'status':'passed','arithmetic':'fractions.Fraction; no floating scientific comparisons',
               'source_head':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),
               'python':sys.version,'platform':platform.platform(),
               'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),
               'document_sha256':hashlib.sha256(document.read_bytes()).hexdigest(),
               'elapsed_seconds':time.perf_counter()-start,'gaussian_conditionals':conditionals,
               'full_model_relative_trace':relative_trace,'full_model_relative_determinant':relative_det,
               'common_link_amgm_ratio':amgm_ratio,'noncommuting_stabilizers':(h1,h2),
               'dressed_cut_trace_and_determinant_preserved':True,'beta_integral_identities':beta_cases,
               'partition_count':len(menu),'comparable_refinement_pairs':refinement_checks,
               'maximal_coherence_idempotence_finite_witness':True,'posterior_examples':examples,
               'higher_index_conditional_posterior_equals_prior':h_prior,
               'limits_not_numerically_proved':['Haar integration','general posterior consistency',
                   'infinite expected identification time','general controlled path equality','general idempotence theorem'],
               'new_observations_or_simulations':False,'old_science_rerun':False}
    result_path.write_text(json.dumps(payload,indent=2,default=str)+'\n',encoding='utf-8')
    print(json.dumps({'status':payload['status'],'result':str(result_path),'elapsed_seconds':payload['elapsed_seconds'],
                      'partition_count':len(menu),'refinement_pairs':refinement_checks,
                      'beta_identities':len(beta_cases),'two_pair_posterior':examples[1]['all_partition_weights']['01|23'],
                      'expected_coordinate_saving':examples[1]['expected_fine_coordinates']-examples[1]['expected_parent_coordinates']},default=str))


if __name__ == '__main__':
    main()
