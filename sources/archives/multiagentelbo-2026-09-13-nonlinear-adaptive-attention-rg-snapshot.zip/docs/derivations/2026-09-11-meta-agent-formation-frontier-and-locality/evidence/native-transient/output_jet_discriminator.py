"""One complete-Jacobian enclosure discriminator and directional-jet check."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import time

folder=Path(__file__).parent
source=folder/'validate_saved_path.py'
spec=importlib.util.spec_from_file_location('output_jet_validator',source)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)


def main() -> None:
    start=time.perf_counter()
    data=json.loads((folder/'determinant-polynomials.json').read_text(encoding='utf-8'))
    groups=g.m.prepare(data['rows'])
    pilot=json.loads((folder.parent/'fixed-pair-native/pilot-trajectory.json').read_text(encoding='utf-8'))
    failure=json.loads((folder/'path-enclosure-refined-failure.json').read_text(encoding='utf-8'))
    left=F(failure['completed_steps'][-1]['right'])
    segment=next(seg for seg in pilot['dense_segments'] if F.from_float(seg['t_old'])==left)
    right=F.from_float(segment['t'])
    local=g.restrict(g.dense_coefficients(segment),segment,left,right)
    point=[[g.I.q(row[0])] for row in local]
    e0=g.m.normalizers(groups,[g.d.exponential(x) for x in point[3:]],2)
    analytic=g.m.jacobian_jets(groups,point,e0)
    for k in range(6):
        jets=[[x[0],g.I.q(int(j==k))] for j,x in enumerate(point)]
        ed=g.m.normalizers(groups,[g.d.exponential(x) for x in jets[3:]],1)
        differentiated=g.m.vector_field(groups,jets,ed)
        for j in range(6):
            a,b=analytic[j][k][0],differentiated[j][1]
            assert max(a.lo,b.lo)<=min(a.hi,b.hi),(j,k)
    residual,_=g.defect(groups,local,(right-left)/2)
    jac=g.jacobian_tube(groups,local,g.I.q(F(1,100000)))
    growth,certificate=g.lognorm(jac)
    result={'status':'PASS_DIRECTIONAL_JETS_AND_OUTPUT_ENCLOSURE','interval':[str(left),str(right)],'residual_order':g.N_RESIDUAL,'jacobian_order':g.N_JACOBIAN,'directional_entries':36,'weighted_residual_bound':str(F(residual.hi,g.S)),'weighted_residual_bound_float':residual.hi/g.S,'weighted_logarithmic_norm_bound':str(F(growth.hi,g.S)),'weighted_logarithmic_norm_bound_float':growth.hi/g.S,'jacobian_certificate':certificate,'elapsed_seconds':time.perf_counter()-start,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'validator_sha256':sha256(source.read_bytes()).hexdigest(),'model_helper_sha256':sha256((folder/'native_interval_model.py').read_bytes()).hexdigest(),'arithmetic_helper_sha256':sha256((folder/'dyadic_interval.py').read_bytes()).hexdigest(),'scope':'One saved interval. Formal directional differentiation is compared with the analytic Jacobian and the complete output expressions receive Taylor bounds. No full path pass or ODE integration.'}
    (folder/'output-jet-discriminator.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('status','directional_entries','weighted_residual_bound_float','weighted_logarithmic_norm_bound_float','elapsed_seconds')},indent=2),flush=True)


if __name__=='__main__':
    main()
