"""Taylor enclosure of both complete merge readouts on native times 35 to 40."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

folder=Path(__file__).parent
spec=importlib.util.spec_from_file_location('path_polynomial_definitions',folder/'validate_saved_path.py')
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
m,d,I=g.m,g.d,g.I
ORDER=10


def merge_jet(groups: list[list[dict]], log_jets: list[list[I]]) -> tuple[list[I],list[list[dict]]]:
    r=[d.exponential(x) for x in log_jets]
    e=[m.normalizers(batch,r,0) for batch in groups]
    return combine(groups,e),e


def combine(groups: list[list[dict]], all_e: list[list[dict]]) -> list[I]:
    joint=[]
    for batch,e in zip(groups,all_e):
        value=d.constant(0,ORDER)
        for group,row in zip(batch,e): value=d.add(value,d.scale(d.mul(row[()],row[()]),group['weight']))
        joint.append(value)
    numerator=d.add(d.add(joint[1],joint[2]),d.neg(joint[3]))
    return d.mul(numerator,d.inv(joint[0]))


def bound(groups: list[list[dict]], coefficients: list[list[F]], error: F) -> I:
    radius=I.q(error*2)
    perturb=I(-radius.hi,radius.hi)
    center=g.log_jets(coefficients,ORDER,False,perturb)
    box=g.log_jets(coefficients,ORDER,True,perturb)
    cc,ec=merge_jet(groups,center)
    rb=[d.exponential(x) for x in box]
    eb=[m.normalizers(batch,rb,0) for batch in groups]
    eb=[m.tighten_time(a,b,ORDER) for a,b in zip(ec,eb)]
    cb=combine(groups,eb)
    remainder=sum(v.abs_hi() for v in cc[1:ORDER])+cb[ORDER].abs_hi()
    result=I(cc[0].lo-remainder,cc[0].hi+remainder)
    return I(max(result.lo,cb[0].lo),min(result.hi,cb[0].hi))


def main() -> None:
    start=time.perf_counter()
    source=folder/'readout-determinant-polynomials.json'
    candidates=folder/'late-window-candidates.json'
    path=folder/'path-enclosure.json'
    data=json.loads(source.read_text(encoding='utf-8'))
    groups=[m.prepare(rows,0) for rows in data['masks']]
    windows=json.loads(candidates.read_text(encoding='utf-8'))
    certificate=json.loads(path.read_text(encoding='utf-8'))
    assert certificate['status']=='PASS_SAVED_PATH_ERROR_ENCLOSURE'
    assert certificate['model_helper_sha256']==sha256((folder/'native_interval_model.py').read_bytes()).hexdigest()
    assert certificate['arithmetic_helper_sha256']==sha256((folder/'dyadic_interval.py').read_bytes()).hexdigest()
    rows=[]
    for window in windows:
        coefficients=[[F(v) for v in row] for row in window['coefficients']]
        error=F(window['error_bound'])
        rec=bound(groups,coefficients[3:],error)
        mod=bound(groups,coefficients[:3],error)
        rows.append({'left':window['left'],'right':window['right'],'recognized_merge':rec.strings(),'model_posterior_merge':mod.strings(),'both_above_half':rec.lo>d.SCALE//2 and mod.lo>d.SCALE//2})
    assert F(rows[0]['left'])<=35 and F(rows[-1]['right'])==40
    assert all(F(a['right'])==F(b['left']) for a,b in zip(rows,rows[1:]))
    passed=all(row['both_above_half'] for row in rows)
    lower_rec=min(F(row['recognized_merge'][0]) for row in rows)
    lower_mod=min(F(row['model_posterior_merge'][0]) for row in rows)
    result={'status':'PASS_COMPLETE_SECOND_MERGE_WINDOW' if passed else 'INCONCLUSIVE_COMPLETE_MERGE_WINDOW','runtime':sys.executable,'python':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'model_helper_sha256':sha256((folder/'native_interval_model.py').read_bytes()).hexdigest(),'arithmetic_helper_sha256':sha256((folder/'dyadic_interval.py').read_bytes()).hexdigest(),'validator_helper_sha256':sha256((folder/'validate_saved_path.py').read_bytes()).hexdigest(),'coefficient_input_sha256':sha256(source.read_bytes()).hexdigest(),'candidate_input_sha256':sha256(candidates.read_bytes()).hexdigest(),'path_input_sha256':sha256(path.read_bytes()).hexdigest(),'jet_order':ORDER,'window':[35,40],'covered_intervals':rows,'recognized_uniform_lower_bound':str(lower_rec),'recognized_uniform_lower_bound_float':float(lower_rec),'model_uniform_lower_bound':str(lower_mod),'model_uniform_lower_bound_float':float(lower_mod),'elapsed_seconds':time.perf_counter()-start,'scope':'The same actual native path and fixed auxiliary readout; tighter bounds retain dependence across the full rational expression. No trajectory integration, source change or positive-prior selection.'}
    (folder/'merge-window-enclosure.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('status','recognized_uniform_lower_bound_float','model_uniform_lower_bound_float','elapsed_seconds')},indent=2),flush=True)
    assert passed,'Saved complete-readout bounds do not certify every interval'


if __name__=='__main__':
    main()
