"""Determinant-jet formulas for the unchanged fixed-pair native learner."""
from fractions import Fraction as F
from math import comb
import importlib.util
from itertools import combinations_with_replacement,product
from pathlib import Path

path=Path(__file__).with_name('dyadic_interval.py')
spec=importlib.util.spec_from_file_location('dyadic_kernel',path)
d=importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
I=d.I


def indices(order: int) -> list[tuple]:
    return [()]+[key for k in range(1,order+1) for key in combinations_with_replacement(range(3),k)]


def prepare(rows: list[dict], order: int = 3) -> list[dict]:
    groups=[]
    for row in rows:
        terms=[]
        for det in row['determinants']:
            original={tuple(v[:3]):F(v[3]) for v in det['coefficients']}
            polys={}
            for key in indices(order):
                poly=original.copy()
                for j in key:
                    updated={}
                    for p,c in poly.items():
                        if p[j]:
                            q=list(p)
                            q[j]-=1
                            updated[tuple(q)]=c*p[j]
                    poly=updated
                polys[key]=[(p,int(c) if c.denominator==1 else I.q(c)) for p,c in poly.items()]
            terms.append({'sign':det['sign'],'polys':polys})
        groups.append({'weight':I.q(F(row['weight'])),'terms':terms})
    return groups


def normalizers(groups: list[dict], r: list[list[I]], order: int) -> list[dict]:
    """Enclose all requested partial derivatives divided by time factorials."""
    n=len(r[0])-1
    zero=d.constant(0,n)
    powers=[]
    for value in r:
        p=[d.constant(1,n)]
        for _ in range(4): p.append(d.mul(p[-1],value))
        powers.append(p)
    monomials={}
    for a,b,c in product(range(5),repeat=3):
        if a+b+c<=4:
            monomials[(a,b,c)]=d.mul(d.mul(powers[0][a],powers[1][b]),powers[2][c])
    output=[]
    keys=indices(order)
    for group in groups:
        e={key:zero[:] for key in keys}
        for term in group['terms']:
            values={}
            for key in keys:
                value=zero[:]
                for p,c in term['polys'][key]: value=d.add(value,d.scale(monomials[p],c))
                values[key]=value
            inv=d.inv(values[()])
            inv2=d.mul(inv,inv)
            inv3=d.mul(inv2,inv) if order>=2 else None
            inv4=d.mul(inv3,inv) if order>=3 else None
            sign=term['sign']
            e[()]=d.add(e[()],d.scale(inv,sign))
            if order>=1:
                for j in range(3):
                    key=(j,)
                    e[key]=d.add(e[key],d.scale(d.mul(values[key],inv2),-sign))
            if order>=2:
                for j,k in combinations_with_replacement(range(3),2):
                    key=(j,k)
                    value=d.add(d.scale(d.mul(d.mul(values[(j,)],values[(k,)]),inv3),2),d.neg(d.mul(values[key],inv2)))
                    e[key]=d.add(e[key],d.scale(value,sign))
            if order>=3:
                for j,k,l in combinations_with_replacement(range(3),3):
                    key=(j,k,l)
                    value=d.scale(d.mul(d.mul(d.mul(values[(j,)],values[(k,)]),values[(l,)]),inv4),-6)
                    pairs=zero[:]
                    for x,y,z in ((j,k,l),(j,l,k),(k,l,j)):
                        pairs=d.add(pairs,d.mul(values[tuple(sorted((x,y)))],values[(z,)]))
                    value=d.add(value,d.scale(d.mul(pairs,inv3),2))
                    value=d.add(value,d.neg(d.mul(values[key],inv2)))
                    e[key]=d.add(e[key],d.scale(value,sign))
        output.append(e)
    return output


def tighten_time(center: list[dict], box: list[dict], order: int) -> list[dict]:
    """Taylor's theorem on normalized time u in [-1,1] tightens values."""
    result=[]
    for ec,eb in zip(center,box):
        row={}
        for key,v in eb.items():
            refined=[]
            for k in range(order):
                radius=sum(comb(l,k)*ec[key][l].abs_hi() for l in range(k+1,order))+comb(order,k)*v[order].abs_hi()
                enclosure=I(ec[key][k].lo-radius,ec[key][k].hi+radius)
                refined.append(I(max(enclosure.lo,v[k].lo),min(enclosure.hi,v[k].hi)))
            row[key]=refined+[v[order]]
        result.append(row)
    return result


def vector_field(groups: list[dict], log_jets: list[list[I]], e: list[dict]) -> list[list[I]]:
    """Native log rates retain E_j=d_j r_j+2 r_j**2 partial_j log Z."""
    n=len(log_jets[0])-1
    z=d.constant(0,n)
    scores=[d.constant(0,n) for _ in range(3)]
    for group,row in zip(groups,e):
        z=d.add(z,d.scale(d.mul(row[()],row[()]),group['weight']))
        for j in range(3): scores[j]=d.add(scores[j],d.scale(d.mul(row[()],row[(j,)]),group['weight']))
    invz=d.inv(z)
    model=[]
    recognition=[]
    for j,dim in enumerate((16,8,16)):
        ratio=d.exponential(d.add(log_jets[j+3],d.neg(log_jets[j])))
        factor=d.exponential(d.add(d.scale(log_jets[j+3],2),d.neg(log_jets[j])))
        model.append(d.add(d.add(ratio,d.constant(-1,n)),d.scale(d.mul(d.mul(factor,scores[j]),invz),I.q(F(4,dim)))))
        recognition.append(d.add(d.constant(1,n),d.neg(ratio)))
    return model+recognition


def jacobian_jets(groups: list[dict], log_jets: list[list[I]], e: list[dict]) -> list[list[list[I]]]:
    """Time-derivative jets of the analytic native log-coordinate Jacobian."""
    n=len(log_jets[0])-1
    zero=d.constant(0,n)
    z=zero[:]
    score=[zero[:] for _ in range(3)]
    second=[[zero[:] for _ in range(3)] for _ in range(3)]
    for group,row in zip(groups,e):
        weight=group['weight']
        z=d.add(z,d.scale(d.mul(row[()],row[()]),weight))
        for j in range(3):
            score[j]=d.add(score[j],d.scale(d.mul(row[()],row[(j,)]),weight))
            for k in range(3):
                value=d.add(d.mul(row[(j,)],row[(k,)]),d.mul(row[()],row[tuple(sorted((j,k)))]))
                second[j][k]=d.add(second[j][k],d.scale(value,weight))
    invz=d.inv(z)
    invz2=d.mul(invz,invz)
    r=[d.exponential(x) for x in log_jets[3:]]
    result=[[zero[:] for _ in range(6)] for _ in range(6)]
    for j,dim in enumerate((16,8,16)):
        ratio=d.exponential(d.add(log_jets[j+3],d.neg(log_jets[j])))
        factor=d.scale(d.exponential(d.add(d.scale(log_jets[j+3],2),d.neg(log_jets[j]))),I.q(F(4,dim)))
        normalized_score=d.mul(score[j],invz)
        result[j][j]=d.neg(d.add(ratio,d.mul(factor,normalized_score)))
        for k in range(3):
            derivative=d.add(d.mul(second[j][k],invz),d.scale(d.mul(d.mul(score[j],score[k]),invz2),-2))
            value=d.mul(d.mul(factor,r[k]),derivative)
            if j==k: value=d.add(value,d.add(ratio,d.scale(d.mul(factor,normalized_score),2)))
            result[j][k+3]=value
        result[j+3][j]=ratio
        result[j+3][j+3]=d.neg(ratio)
    return result
