"""Exact determinant polynomials for validating the saved fixed-pair path."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import permutations,product
import json
from pathlib import Path
import platform
import sys
import time

folder=Path(__file__).parent
source=folder.parent/'transported-parent-prior/result.json'
helper=folder.parent/'shared-parent-record/shared_parent_exact.py'
spec=importlib.util.spec_from_file_location('saved_geometry_definitions',helper)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)


def multiply(x: dict, y: dict) -> dict:
    z={}
    for a,v in x.items():
        for b,w in y.items():
            key=tuple(i+j for i,j in zip(a,b))
            z[key]=z.get(key,F(0))+v*w
    return {k:v for k,v in z.items() if v}


def main() -> None:
    start=time.perf_counter()
    old=json.loads(source.read_text(encoding='utf-8'))
    pair=next(row for row in old['rows'] if row['partition']==[[0,1],[2,3]])
    ga=g.helper.multiply(g.B,g.helper.transpose(g.B))
    j=g.helper.multiply(g.B,g.helper.mat([[1,0],[1,0],[0,1],[0,1]]))
    gb=g.helper.multiply(j,g.helper.transpose(j))
    groups={}
    for dec in pair['details']:
        c=[[F(x) for x in row] for row in dec['C']]
        gc=g.helper.multiply(c,g.helper.transpose(c))
        key=tuple(x for row in gc for x in row)
        if key not in groups: groups[key]={'grams':[ga,gb,gc],'multiplicity':0}
        groups[key]['multiplicity']+=1
    rows=[]
    for group in groups.values():
        grams=group['grams']
        dets=[]
        for bits in product((0,1),repeat=4):
            q=[F(n+b) for n,b in zip(g.N,bits)]
            entries=[[{(0,0,0):F(i==j),**{tuple(int(k==l) for k in range(3)):grams[l][i][j]*q[j] for l in range(3)}} for j in range(4)] for i in range(4)]
            determinant={}
            for perm in permutations(range(4)):
                sign=(-1)**sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))
                term={(0,0,0):F(sign)}
                for i in range(4): term=multiply(term,entries[i][perm[i]])
                for k,v in term.items(): determinant[k]=determinant.get(k,F(0))+v
            determinant={k:v for k,v in determinant.items() if v}
            assert determinant[(0,0,0)]==1 and all(v>0 for v in determinant.values())
            unit=sum(determinant.values(),F(0))
            matrix=[[F(i==j)+sum(gram[i][j] for gram in grams)*q[j] for j in range(4)] for i in range(4)]
            assert unit==g.helper.determinant(matrix)
            dets.append({'bits':list(bits),'sign':(-1)**sum(bits),'coefficients':[[*k,str(v)] for k,v in sorted(determinant.items())]})
        rows.append({'multiplicity':group['multiplicity'],'weight':str(F(group['multiplicity'],4)),'grams':[[[str(x) for x in row] for row in gram] for gram in grams],'determinants':dets})
    result={'status':'PASS_EXACT_DETERMINANT_POLYNOMIALS','runtime':sys.executable,'python':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':sha256(source.read_bytes()).hexdigest(),'helper_sha256':sha256(helper.read_bytes()).hexdigest(),'matrix_helper_sha256':sha256(g.HELPER.read_bytes()).hexdigest(),'rows':rows,'groups':len(rows),'determinants':sum(len(row['determinants']) for row in rows),'scope':'All fixed-P root decorations, original unshifted record masks; exact multivariate determinant coefficients for native-flow validation. This does not enclose a trajectory.','elapsed_seconds':time.perf_counter()-start}
    (folder/'determinant-polynomials.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','groups','determinants','elapsed_seconds')},indent=2),flush=True)


if __name__=='__main__':
    main()
