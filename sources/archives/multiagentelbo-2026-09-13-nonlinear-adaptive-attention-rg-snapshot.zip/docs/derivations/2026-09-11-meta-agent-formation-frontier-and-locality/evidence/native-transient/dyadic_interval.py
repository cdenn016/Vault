"""Dyadic outward intervals and finite derivative jets for one saved-path check.

Every interval endpoint is an integer divided by 2**128. Integer floor/ceiling
operations enclose the elementary rational operations. Exponential bounds use
its positive Taylor series and an explicit geometric tail after range reduction.
"""
from fractions import Fraction as F
from math import isqrt

BITS=128
SCALE=1<<BITS


class I:
    __slots__=('lo','hi')

    def __init__(self, lo: int, hi: int) -> None:
        assert lo<=hi
        self.lo,self.hi=lo,hi

    @staticmethod
    def q(value: F | int | str) -> 'I':
        f=F(value)
        n=f.numerator*SCALE
        return I(n//f.denominator,-((-n)//f.denominator))

    def __add__(self, other: 'I | int') -> 'I':
        if isinstance(other,int): other=I.q(other)
        return I(self.lo+other.lo,self.hi+other.hi)

    __radd__=__add__

    def __neg__(self) -> 'I':
        return I(-self.hi,-self.lo)

    def __sub__(self, other: 'I | int') -> 'I':
        return self+-other

    def __rsub__(self, other: 'I | int') -> 'I':
        return -self+other

    def __mul__(self, other: 'I | int') -> 'I':
        if isinstance(other,int):
            a,b=self.lo*other,self.hi*other
            return I(min(a,b),max(a,b))
        values=(self.lo*other.lo,self.lo*other.hi,self.hi*other.lo,self.hi*other.hi)
        return I(min(values)//SCALE,-((-max(values))//SCALE))

    __rmul__=__mul__

    def inv(self) -> 'I':
        assert self.lo>0 or self.hi<0,('interval denominator contains zero',self.floats())
        if self.hi<0: return -(-self).inv()
        return I(SCALE*SCALE//self.hi,-((-SCALE*SCALE)//self.lo))

    def __truediv__(self, other: 'I | int') -> 'I':
        if isinstance(other,int):
            assert other!=0
            if other<0: return -(self/-other)
            return I(self.lo//other,-((-self.hi)//other))
        return self*other.inv()

    def abs_hi(self) -> int:
        return max(abs(self.lo),abs(self.hi))

    def floats(self) -> list[float]:
        return [self.lo/SCALE,self.hi/SCALE]

    def strings(self) -> list[str]:
        return [str(F(self.lo,SCALE)),str(F(self.hi,SCALE))]


ZERO=I.q(0)
ONE=I.q(1)
HALF_SQRT=I(isqrt(SCALE*SCALE//2),isqrt(SCALE*SCALE//2)+1)


def exp_point(x: int) -> I:
    """Enclose exp(x/2**128) by positive terms and an explicit tail."""
    if x<0: return exp_point(-x).inv()
    if x==0: return ONE
    reductions=max(0,x.bit_length()-BITS+1)
    z=I(x,x)/(1<<reductions)
    assert 0<=z.lo<=z.hi<=SCALE//2
    total=ONE
    term=ONE
    for n in range(1,49):
        term=term*z/n
        total=total+term
    next_term=term*z/49
    tail=next_term/(ONE-z/50)
    value=I(total.lo,(total+tail).hi)
    for _ in range(reductions): value=value*value
    return value


def exp(x: I) -> I:
    return I(exp_point(x.lo).lo,exp_point(x.hi).hi)


def constant(value: I | int, n: int) -> list[I]:
    if isinstance(value,int): value=I.q(value)
    return [value]+[ZERO]*n


def add(x: list[I], y: list[I]) -> list[I]:
    return [a+b for a,b in zip(x,y)]


def neg(x: list[I]) -> list[I]:
    return [-a for a in x]


def scale(x: list[I], c: I | int) -> list[I]:
    return [a*c for a in x]


def mul(x: list[I], y: list[I]) -> list[I]:
    return [sum((x[j]*y[k-j] for j in range(k+1)),ZERO) for k in range(len(x))]


def inv(x: list[I]) -> list[I]:
    z=[x[0].inv()]
    for k in range(1,len(x)):
        z.append(-z[0]*sum((x[j]*z[k-j] for j in range(1,k+1)),ZERO))
    return z


def exponential(x: list[I]) -> list[I]:
    z=[exp(x[0])]
    for k in range(1,len(x)):
        z.append(sum((x[j]*z[k-j]*j for j in range(1,k+1)),ZERO)/k)
    return z


def evaluate(coefficients: list[I], x: I) -> I:
    result=ZERO
    for value in reversed(coefficients): result=result*x+value
    return result
