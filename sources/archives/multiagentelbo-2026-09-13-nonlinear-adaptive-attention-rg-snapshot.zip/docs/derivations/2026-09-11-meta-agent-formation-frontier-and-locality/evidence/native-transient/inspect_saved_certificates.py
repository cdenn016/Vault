"""Nonmutating inspection of saved interval certificates and preserved sources."""
from fractions import Fraction as F
from hashlib import sha256
import ast
import datetime
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

sys.set_int_max_str_digits(200000)
ROOT=Path(r'C:/tmp/elbo-cover-20260908')
BASE=ROOT/'docs/derivations/2026-09-11-meta-agent-formation-frontier-and-locality'
HERE=BASE/'evidence/native-transient'


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def read(name: str) -> dict:
    return json.loads((HERE/name).read_text(encoding='utf-8-sig'))


def determinant(matrix: list[list[F]]) -> F:
    work=[row[:] for row in matrix]
    value=F(1)
    for j in range(len(work)):
        assert work[j][j]!=0
        pivot=work[j][j]
        value*=pivot
        for i in range(j+1,len(work)):
            ratio=work[i][j]/pivot
            for k in range(j+1,len(work)): work[i][k]-=ratio*work[j][k]
    return value


def main() -> None:
    before=read('before.json')
    allowed={str(ROOT/'docs/STATUS.md'),str(BASE/'RG-COMPLETION.md'),str(BASE/'RECORD.md'),str(ROOT/'docs/change-logs/2026-09-12.md')}
    changed=[]
    for filename,old in before['files'].items():
        p=Path(filename)
        assert p.is_file(),filename
        if digest(p)!=old: changed.append(str(p))
    assert set(changed)==allowed,changed
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert head==before['head']
    parsed=[]
    for p in sorted(HERE.glob('*.py')):
        ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
        parsed.append(p.name)
    for name in ('attempt1-validator-source.txt','attempt1-native-interval-model.txt','attempt2-validator-source.txt','attempt2-native-interval-model.txt'):
        ast.parse((HERE/name).read_text(encoding='utf-8-sig'),filename=name)
    bindings=[]
    def bind(name: str, mapping: dict[str,Path]) -> None:
        data=read(name)
        for key,p in mapping.items():
            assert data[key]==digest(p),(name,key,str(p))
            bindings.append({'result':name,'field':key,'path':str(p),'sha256':data[key]})
    bind('continuation.json',{'script_sha256':HERE/'continuation.py','helper_sha256':HERE.parent/'fixed-pair-native/pilot_native.py','input_sha256':HERE.parent/'fixed-pair-native/pilot-trajectory.json'})
    bind('determinant-polynomials.json',{'script_sha256':HERE/'determinant_polynomials.py','input_sha256':HERE.parent/'transported-parent-prior/result.json','helper_sha256':HERE.parent/'shared-parent-record/shared_parent_exact.py','matrix_helper_sha256':HERE.parent/'post-merge-bridge/gaussian_bridge_exact.py'})
    for name,validator,model in (
      ('path-enclosure-failure.json','attempt1-validator-source.txt','attempt1-native-interval-model.txt'),
      ('path-enclosure-refined-failure.json','attempt2-validator-source.txt','attempt2-native-interval-model.txt'),
      ('path-enclosure.json','validate_saved_path.py','native_interval_model.py')):
        bind(name,{'script_sha256':HERE/validator,'model_helper_sha256':HERE/model,'arithmetic_helper_sha256':HERE/'dyadic_interval.py','determinant_input_sha256':HERE/'determinant-polynomials.json','pilot_input_sha256':HERE.parent/'fixed-pair-native/pilot-trajectory.json','continuation_input_sha256':HERE/'continuation.json'})
    bind('order-discriminator.json',{'script_sha256':HERE/'order_discriminator.py','validator_sha256':HERE/'attempt2-validator-source.txt','model_helper_sha256':HERE/'attempt2-native-interval-model.txt','failure_input_sha256':HERE/'path-enclosure-refined-failure.json'})
    bind('output-jet-discriminator.json',{'script_sha256':HERE/'output_jet_discriminator.py','validator_sha256':HERE/'validate_saved_path.py','model_helper_sha256':HERE/'native_interval_model.py','arithmetic_helper_sha256':HERE/'dyadic_interval.py'})
    bind('second-merge-entry-enclosure.json',{'script_sha256':HERE/'enclose_second_merge.py','path_input_sha256':HERE/'path-enclosure.json','window_input_sha256':HERE/'late-window-candidates.json','model_helper_sha256':HERE/'native_interval_model.py','arithmetic_helper_sha256':HERE/'dyadic_interval.py','coefficient_sha256':HERE/'readout-determinant-polynomials.json','previous_response_sha256':HERE.parent/'second-level-learning/second-level-response.json'})
    bind('merge-window-enclosure.json',{'script_sha256':HERE/'enclose_merge_window.py','model_helper_sha256':HERE/'native_interval_model.py','arithmetic_helper_sha256':HERE/'dyadic_interval.py','validator_helper_sha256':HERE/'validate_saved_path.py','coefficient_input_sha256':HERE/'readout-determinant-polynomials.json','candidate_input_sha256':HERE/'late-window-candidates.json','path_input_sha256':HERE/'path-enclosure.json'})
    continuation=read('continuation.json')
    assert continuation['status']=='NUMERICAL_CONTINUATION_COMPLETED'
    assert continuation['native_interval']==[20.,120.] and continuation['solver']['accepted_steps']==401
    assert len(continuation['accepted_times'])==len(continuation['accepted_log_states'])==402
    assert len(continuation['dense_segments'])==401 and len(continuation['detected_half_merge_events'])==1
    assert continuation['dense_evaluation_source_sha256']==sha256(continuation['dense_evaluation_source'].encode()).hexdigest()
    failure1=read('path-enclosure-failure.json')
    failure2=read('path-enclosure-refined-failure.json')
    assert failure1['status']==failure2['status']=='INCONCLUSIVE_PATH_ENCLOSURE'
    path=read('path-enclosure.json')
    assert path['status']=='PASS_SAVED_PATH_ERROR_ENCLOSURE' and len(path['steps'])==365
    spec=importlib.util.spec_from_file_location('saved_arithmetic_only',HERE/'dyadic_interval.py')
    d=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(d)
    prior=d.I.q(0)
    last=F(0)
    maximal=F(0)
    for row in path['steps']:
        left,right=F(row['left']),F(row['right'])
        assert left==last and 0<right-left<=F(1,8)
        last=right
        sym=[[[F(value) for value in pair] for pair in line] for line in row['logarithmic_norm_certificate']['symmetric_jacobian_enclosure']]
        assert all(sym[i][j]==sym[j][i] and sym[i][j][0]<=sym[i][j][1] for i in range(6) for j in range(6))
        midpoint=[[(pair[0]+pair[1])/2 for pair in line] for line in sym]
        rho=max(sum(((pair[1]-pair[0])/2 for pair in line),F(0)) for line in sym)
        cert=row['logarithmic_norm_certificate']
        assert rho==F(cert['radius_operator_norm_bound'])
        q=F(cert['midpoint_upper_eigenvalue_bound'])
        matrix=[[F(i==j)*q-midpoint[i][j] for j in range(6)] for i in range(6)]
        product=F(1)
        for k,pivot in enumerate(cert['positive_ldl_pivots'],start=1):
            pivot=F(pivot)
            assert pivot>0
            product*=pivot
            assert determinant([line[:k] for line in matrix[:k]])==product
        growth=d.I.q(F(row['weighted_logarithmic_norm_bound']))
        assert F(growth.lo,d.SCALE)>=q+rho
        residual=d.I.q(F(row['weighted_residual_bound']))
        incoming=prior+d.I.q(F(row['candidate_jump_bound']))
        width=d.I.q(right-left)
        radius=(incoming+residual*width)*4+d.I.q(F(1,10**10))
        factor=d.exp(growth*width)
        worst=d.I(max(d.SCALE,factor.hi),max(d.SCALE,factor.hi))
        within=(incoming+residual*width)*worst
        assert F(within.hi,d.SCALE)==F(row['within_interval_error_bound'])
        assert within.hi<radius.lo
        end=incoming*factor+residual*width*worst
        assert F(end.hi,d.SCALE)==F(row['weighted_error_bound'])
        prior=d.I(end.hi,end.hi)
        maximal=max(maximal,F(within.hi,d.SCALE))
    assert last==40 and F(prior.hi,d.SCALE)==F(path['weighted_error_bound'])
    assert maximal<F('0.0000000043') and F(path['weighted_error_bound'])<F('0.0000000042970')
    point=read('second-merge-entry-enclosure.json')
    assert point['status']=='PASS_UNIT_START_SECOND_MERGE_ENTRY'
    assert point['window_both_readouts_above_half'] is False
    rec=list(map(F,point['recognized_merge_at_40']))
    mod=list(map(F,point['model_posterior_merge_at_40']))
    assert F('0.5254967190')<rec[0]<=rec[1]<F('0.5254967309')
    assert F('0.5273019505')<mod[0]<=mod[1]<F('0.5273019621')
    window=read('merge-window-enclosure.json')
    assert window['status']=='PASS_COMPLETE_SECOND_MERGE_WINDOW' and window['window']==[35,40]
    rows=window['covered_intervals']
    assert len(rows)==41 and F(rows[0]['left'])<=35 and F(rows[-1]['right'])==40
    assert all(F(a['right'])==F(b['left']) for a,b in zip(rows,rows[1:]))
    assert all(row['both_above_half'] and F(row['recognized_merge'][0])>F(1,2) and F(row['model_posterior_merge'][0])>F(1,2) for row in rows)
    assert min(F(row['recognized_merge'][0]) for row in rows)==F(window['recognized_uniform_lower_bound'])>F('0.5130')
    assert min(F(row['model_posterior_merge'][0]) for row in rows)==F(window['model_uniform_lower_bound'])>F('0.5154')
    doc=BASE/'unit-start-second-merge-and-positive-prior-persistence.md'
    text=doc.read_text(encoding='utf-8')
    assert list(map(int,re.findall(r'\\tag\{(\d+)\}',text)))==list(range(1,22))
    assert not re.search(r'\\(?:quad|qquad)\b|\\[,;!]',text)
    assert all(line==line.rstrip() for line in text.splitlines())
    links=0
    for target in re.findall(r'\]\((<[^>]*>|[^)]*)\)',text):
        target=target.strip('<>')
        if re.match(r'https?://',target): continue
        p=Path(target) if re.match(r'^[A-Za-z]:/',target) else doc.parent/target
        assert p.exists(),str(p)
        links+=1
    for name in allowed: assert doc.name in Path(name).read_text(encoding='utf-8')
    proc=subprocess.run(['git','diff','--check'],cwd=ROOT,text=True,capture_output=True)
    (HERE/'git-diff-check.txt').write_text(proc.stdout+proc.stderr+f'\nexit_code={proc.returncode}\n',encoding='utf-8')
    assert proc.returncode==0,proc.stdout+proc.stderr
    receipt={'status':'PASS_SAVED_CERTIFICATE_INSPECTION_AND_PRESERVATION','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'scope':'Nonmutating source and saved-certificate inspection. Exact principal minors check the stored LDL claims; saved error recurrences and readout inequalities are checked. No ODE, determinant-jet force evaluation, prior scientific main, or independent-review/formal-ledger process was run.','preservation':{'baseline_files':len(before['files']),'unchanged':len(before['files'])-len(changed),'allowed_changed':changed,'unexpected_changed':[]},'parsed_sources':parsed,'bindings':bindings,'saved_failures_preserved':{'first_path_attempt':failure1['status'],'second_path_attempt':failure2['status'],'coarse_readout_window':point['window_both_readouts_above_half']},'path_subintervals':365,'principal_minor_checks':365*6,'maximal_weighted_error_bound':str(maximal),'maximal_weighted_error_bound_float':float(maximal),'certified_native_window':[35,40],'readout_cover_intervals':41,'recognized_uniform_lower_bound':window['recognized_uniform_lower_bound'],'model_uniform_lower_bound':window['model_uniform_lower_bound'],'document':{'path':str(doc),'sha256':digest(doc),'equations':21,'local_links_resolve':links},'record_hashes':{name:digest(Path(name)) for name in sorted(allowed)},'artifact_hashes':{p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='execution-and-inspection.json'},'not_run':['Scientific reruns','Second trajectory extension','Stationary retry','Numerical positive ancestry prior','New data','Sampling','Suite','GPU','Lean','Tamper checks','Production/configuration edit','Vault edit','Publication','Canonical synchronization']}
    (HERE/'execution-and-inspection.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':receipt['status'],'preservation':receipt['preservation'],'source_bindings':len(bindings),'path_subintervals':365,'principal_minor_checks':365*6,'maximal_weighted_error_bound_float':float(maximal),'readout_cover_intervals':41,'local_links':links,'git_diff_check':proc.returncode},indent=2),flush=True)


if __name__=='__main__':
    main()
