"""Enclose the second-merge readout on the certified native path."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import permutations,product
import json
from pathlib import Path
import platform
import sys
import time

folder=Path(__file__).parent
spec=importlib.util.spec_from_file_location('interval_native_readout',folder/'native_interval_model.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
d=m.d
I=d.I
S=d.SCALE


def multiply(x: dict, y: dict) -> dict:
    result={}
    for a,v in x.items():
        for b,w in y.items():
            key=tuple(i+j for i,j in zip(a,b))
            result[key]=result.get(key,F(0))+v*w
    return {key:value for key,value in result.items() if value}


def activated_rows(rows: list[dict], mask: int) -> list[dict]:
    t=((F(1,2),F(1),F(1,2),F(0)),(F(1,2),F(0),F(1,2),F(1)))
    output=[]
    for row in rows:
        grams=[[[F(v) for v in line] for line in gram] for gram in row['grams']]
        determinants=[]
        for bits in product((0,1),repeat=4):
            q=[[F((8,1,8,1)[i]+bits[i]) if i==j else F(0) for j in range(4)] for i in range(4)]
            q=[[q[i][j]+sum((t[k][i]*t[k][j] for k in range(2) if mask&(1<<k)),F(0)) for j in range(4)] for i in range(4)]
            entries=[[{(0,0,0):F(i==j),**{tuple(int(k==l) for k in range(3)):sum((grams[l][i][k]*q[k][j] for k in range(4)),F(0)) for l in range(3)}} for j in range(4)] for i in range(4)]
            determinant={}
            for perm in permutations(range(4)):
                sign=(-1)**sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))
                term={(0,0,0):F(sign)}
                for i in range(4): term=multiply(term,entries[i][perm[i]])
                for key,value in term.items(): determinant[key]=determinant.get(key,F(0))+value
            determinant={key:value for key,value in determinant.items() if value}
            assert determinant[(0,0,0)]==1 and all(value>0 for value in determinant.values())
            determinants.append({'sign':(-1)**sum(bits),'bits':list(bits),'coefficients':[[*key,str(value)] for key,value in sorted(determinant.items())]})
        output.append({'weight':row['weight'],'multiplicity':row['multiplicity'],'determinants':determinants})
    return output


def merge_enclosure(groups: list[list[dict]], center: list[F], log_box: list[I]) -> I:
    r0=[d.exp(I.q(value)) for value in center]
    rb=[d.exp(value) for value in log_box]
    joint=[]
    for batch in groups:
        point=m.normalizers(batch,[[value] for value in r0],1)
        box=m.normalizers(batch,[[value] for value in rb],1)
        z=d.ZERO
        for group,ep,eb in zip(batch,point,box):
            value=ep[()][0]
            for j in range(3): value=value+eb[(j,)][0]*(rb[j]-r0[j])
            raw=eb[()][0]
            enclosure=I(max(value.lo,raw.lo),min(value.hi,raw.hi))
            assert enclosure.lo>0,('One-channel readout normalizer not enclosed positive',enclosure.floats())
            z=z+group['weight']*enclosure*enclosure
        joint.append(z)
    return (joint[1]+joint[2]-joint[3])/joint[0]


def unit_readout(rows: list[list[dict]]) -> F:
    joint=[]
    for batch in rows:
        z=F(0)
        for row in batch:
            value=sum((F(term['sign'])/sum((F(v[3]) for v in term['coefficients']),F(0)) for term in row['determinants']),F(0))
            z+=F(row['weight'])*value**2
        joint.append(z)
    return (joint[1]+joint[2]-joint[3])/joint[0]


def main() -> None:
    start=time.perf_counter()
    path_source=folder/'path-enclosure.json'
    window_source=folder/'late-window-candidates.json'
    path=json.loads(path_source.read_text(encoding='utf-8'))
    assert path['status']=='PASS_SAVED_PATH_ERROR_ENCLOSURE'
    assert path['model_helper_sha256']==sha256((folder/'native_interval_model.py').read_bytes()).hexdigest()
    assert path['arithmetic_helper_sha256']==sha256((folder/'dyadic_interval.py').read_bytes()).hexdigest()
    original=json.loads((folder/'determinant-polynomials.json').read_text(encoding='utf-8'))
    rows=[original['rows']]+[activated_rows(original['rows'],mask) for mask in (1,2,3)]
    (folder/'readout-determinant-polynomials.json').write_text(json.dumps({'masks':rows,'scope':'The unshifted 48 determinant polynomials are reused; 144 positive-activation polynomials are new exact calculations.'},indent=2)+'\n',encoding='utf-8')
    groups=[m.prepare(batch,1) for batch in rows]
    unit=unit_readout(rows)
    old=json.loads((folder.parent/'second-level-learning/second-level-response.json').read_text(encoding='utf-8'))
    assert unit==F(old['merge_probability'])<F(1,2)
    center=[F(value) for value in path['terminal_log_candidate']]
    error=F(path['weighted_error_bound'])
    log_box=[I.q(value)+I.q(F(2)*error)*I(-S,S) for value in center]
    recognized=merge_enclosure(groups,center[3:],log_box[3:])
    model=merge_enclosure(groups,center[:3],log_box[:3])
    assert recognized.lo>S//2 and model.lo>S//2
    windows=json.loads(window_source.read_text(encoding='utf-8'))
    window_results=[]
    for row in windows:
        coefficients=[[F(v) for v in line] for line in row['coefficients']]
        radius=I.q(F(row['error_bound'])*2)
        box=[d.evaluate([I.q(v) for v in line],I(-S,S))+I(-radius.hi,radius.hi) for line in coefficients]
        middle=[line[0] for line in coefficients]
        rec=merge_enclosure(groups,middle[3:],box[3:])
        mod=merge_enclosure(groups,middle[:3],box[:3])
        window_results.append({'left':row['left'],'right':row['right'],'recognized_merge':rec.strings(),'model_posterior_merge':mod.strings(),'both_above_half':rec.lo>S//2 and mod.lo>S//2})
    assert F(window_results[0]['left'])<=35 and F(window_results[-1]['right'])==40
    assert all(F(a['right'])==F(b['left']) for a,b in zip(window_results,window_results[1:]))
    window_pass=all(row['both_above_half'] for row in window_results)
    result={'status':'PASS_UNIT_START_SECOND_MERGE_ENTRY','runtime':sys.executable,'python':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'path_input_sha256':sha256(path_source.read_bytes()).hexdigest(),'window_input_sha256':sha256(window_source.read_bytes()).hexdigest(),'model_helper_sha256':sha256((folder/'native_interval_model.py').read_bytes()).hexdigest(),'arithmetic_helper_sha256':sha256((folder/'dyadic_interval.py').read_bytes()).hexdigest(),'coefficient_sha256':sha256((folder/'readout-determinant-polynomials.json').read_bytes()).hexdigest(),'previous_response_sha256':sha256((folder.parent/'second-level-learning/second-level-response.json').read_bytes()).hexdigest(),'unit_merge_probability':str(unit),'target_native_time':40,'weighted_log_state_error_bound':str(error),'recognized_merge_at_40':recognized.strings(),'recognized_merge_at_40_float':recognized.floats(),'model_posterior_merge_at_40':model.strings(),'model_posterior_merge_at_40_float':model.floats(),'window':[35,40],'window_both_readouts_above_half':window_pass,'window_enclosures':window_results,'elapsed_seconds':time.perf_counter()-start,'scope':'Fixed-P native learner, exact all-unit preparation, all root decorations. The ODE path error and common auxiliary readout are bounded. Positive-prior persistence requires the separate written continuity argument.','not_proved':['Exact crossing time','Return below half','Boundary-basin entry','Infinite-time convergence','Overlap with the earlier O/P crossing-prior family','Complete resource license']}
    (folder/'second-merge-entry-enclosure.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('status','recognized_merge_at_40_float','model_posterior_merge_at_40_float','window_both_readouts_above_half','elapsed_seconds')},indent=2),flush=True)


if __name__=='__main__':
    main()
