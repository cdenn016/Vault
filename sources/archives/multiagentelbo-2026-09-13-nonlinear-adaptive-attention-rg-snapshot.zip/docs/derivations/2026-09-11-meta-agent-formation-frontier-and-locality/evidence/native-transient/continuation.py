"""One native continuation from the saved time-20 numerical endpoint."""
from hashlib import sha256
import importlib.util
import inspect
import json
from pathlib import Path
import platform
import sys
import time
import numpy as np
import scipy
from scipy.integrate import solve_ivp

folder=Path(__file__).parent
helper_path=folder.parent/'fixed-pair-native/pilot_native.py'
input_path=folder.parent/'fixed-pair-native/pilot-trajectory.json'
spec=importlib.util.spec_from_file_location('native_definitions',helper_path)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)


def main() -> None:
    start=time.perf_counter()
    previous=json.loads(input_path.read_text(encoding='utf-8'))
    assert previous['accepted_times'][-1]==20.
    initial=np.array(previous['accepted_log_states'][-1])
    solution=solve_ivp(g.rhs,(20.,120.),initial,method='DOP853',rtol=1e-10,atol=1e-12,max_step=.25,dense_output=True,events=g.crossing)
    assert solution.success and solution.t[-1]==120.
    rows=[]
    for t in (20.,25.,30.,40.,60.,80.,120.):
        state=np.exp(solution.sol(t))
        rows.append({'native_time':t,'model_variances':state[:3].tolist(),'recognition_variances':state[3:].tolist(),'merge_probability':g.merge(state[3:])})
    events=[]
    for t,state in zip(solution.t_events[0],solution.y_events[0]):
        events.append({'native_time':float(t),'log_state':state.tolist(),'merge_probability':g.merge(np.exp(state[3:]))})
    values=[g.merge(np.exp(state[3:])) for state in solution.y.T]
    maximum=int(np.argmax(values))
    dense_source=inspect.getsource(type(solution.sol.interpolants[0])._call_impl)
    result={'status':'NUMERICAL_CONTINUATION_COMPLETED','runtime':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
      'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),'input_sha256':sha256(input_path.read_bytes()).hexdigest(),
      'scope':'One fixed-P, all-four-decoration six-variable native trajectory continued from the saved numerical endpoint. No earlier interval is reintegrated. This is not a rigorous ODE enclosure.',
      'native_interval':[20.,120.],'solver':{'method':'DOP853','rtol':1e-10,'atol':1e-12,'max_step':.25,'success':solution.success,'message':solution.message,'nfev':solution.nfev,'accepted_steps':len(solution.t)-1},
      'readouts':rows,'detected_half_merge_events':events,'maximum_at_accepted_states':{'native_time':float(solution.t[maximum]),'merge_probability':values[maximum]},
      'accepted_times':solution.t.tolist(),'accepted_log_states':solution.y.T.tolist(),'accepted_merge_probabilities':values,
      'dense_segments':[{'t_old':seg.t_old,'t':seg.t,'h':seg.h,'y_old':seg.y_old.tolist(),'F':seg.F.tolist()} for seg in solution.sol.interpolants],
      'dense_evaluation_source':dense_source,'dense_evaluation_source_sha256':sha256(dense_source.encode()).hexdigest(),'evaluation_metrics':g.METRICS,'elapsed_seconds':time.perf_counter()-start,
      'not_proved':['Continuous trajectory enclosure','Unit-start basin entry','Long-time convergence','Positive-prior transient episode','Complete useful hierarchy'],
      'not_run':['Earlier trajectory or scientific main','Another horizon extension','Interior solver retry','Numerical positive prior','Parameter grid','New data','Sampling','GPU','Suite','Lean','Tamper checks']}
    (folder/'continuation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('status','solver','readouts','detected_half_merge_events','maximum_at_accepted_states','evaluation_metrics','elapsed_seconds')},indent=2),flush=True)


if __name__=='__main__':
    main()
