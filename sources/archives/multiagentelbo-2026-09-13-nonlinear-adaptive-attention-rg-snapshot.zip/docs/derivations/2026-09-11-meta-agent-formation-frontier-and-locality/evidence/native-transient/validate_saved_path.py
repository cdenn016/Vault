"""A posteriori dyadic enclosure of the saved unit-start native path to time 40.

The program evaluates a fixed piecewise polynomial candidate; it does not solve
or reintegrate the ODE. Derivative jets bound its defect. Exact interval Jacobian
bounds and rational LDL pivots control a weighted Euclidean error differential
inequality on each tube. All displayed decimal estimates are secondary to the
saved rational bounds.
"""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import permutations,product
import json
from math import ceil,comb
from pathlib import Path
import platform
import sys
import time
import traceback
import numpy as np

folder=Path(__file__).parent
spec=importlib.util.spec_from_file_location('interval_native',folder/'native_interval_model.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
d=m.d
I=d.I
S=d.SCALE
W=[d.ONE,d.HALF_SQRT,d.ONE,d.ONE,d.HALF_SQRT,d.ONE]
WEIGHTS=np.array([1.,2**-.5,1.,1.,2**-.5,1.])
N_RESIDUAL=16
N_JACOBIAN=12
MAX_STEP=F(1,8)
TARGET=F(40)
records=[]


def fraction(x: float) -> F:
    return F.from_float(x)


def dense_coefficients(segment: dict) -> list[list[F]]:
    result=[]
    for j in range(6):
        coefficients=[F(0)]
        for k,row in enumerate(reversed(segment['F'])):
            coefficients[0]+=fraction(row[j])
            if k%2==0: coefficients=[F(0)]+coefficients
            else: coefficients=[coefficients[0]]+[coefficients[i]-coefficients[i-1] for i in range(1,len(coefficients))]+[-coefficients[-1]]
        coefficients[0]+=fraction(segment['y_old'][j])
        result.append(coefficients)
    return result


def restrict(coefficients: list[list[F]], segment: dict, left: F, right: F) -> list[list[F]]:
    midpoint=(left+right)/2
    half=(right-left)/2
    alpha=(midpoint-fraction(segment['t_old']))/fraction(segment['h'])
    beta=half/fraction(segment['h'])
    return [[sum((c*comb(k,j)*alpha**(k-j)*beta**j for k,c in enumerate(row) if k>=j),F(0)) for j in range(len(row))] for row in coefficients]


def log_jets(coefficients: list[list[F]], order: int, box: bool, perturb: I = d.ZERO) -> list[list[I]]:
    result=[]
    for row in coefficients:
        jet=[]
        for j in range(order+1):
            derivative=[I.q(comb(k,j)*row[k]) for k in range(j,len(row))]
            value=d.evaluate(derivative,I(-S,S)) if box else (derivative[0] if derivative else d.ZERO)
            if j==0: value=value+perturb
            jet.append(value)
        result.append(jet)
    return result


def defect(groups: list[dict], coefficients: list[list[F]], half: F) -> tuple[I,list[str]]:
    center=log_jets(coefficients,N_RESIDUAL+1,False)
    box=log_jets(coefficients,N_RESIDUAL+1,True)
    ec=m.normalizers(groups,[d.exponential(x[:N_RESIDUAL+1]) for x in center[3:]],1)
    eb=m.normalizers(groups,[d.exponential(x[:N_RESIDUAL+1]) for x in box[3:]],1)
    eb=m.tighten_time(ec,eb,N_RESIDUAL)
    fc=m.vector_field(groups,[x[:N_RESIDUAL+1] for x in center],ec)
    fb=m.vector_field(groups,[x[:N_RESIDUAL+1] for x in box],eb)
    components=[]
    for j in range(6):
        c=[fc[j][k]-center[j][k+1]*(k+1)/I.q(half) for k in range(N_RESIDUAL)]
        remainder=fb[j][N_RESIDUAL]-box[j][N_RESIDUAL+1]*(N_RESIDUAL+1)/I.q(half)
        bound=sum(x.abs_hi() for x in c)+remainder.abs_hi()
        components.append(I(bound,bound))
    total=sum((w*v for w,v in zip(W,components)),d.ZERO)
    return I(total.hi,total.hi),[str(F(v.hi,S)) for v in components]


def jacobian_tube(groups: list[dict], coefficients: list[list[F]], radius: I) -> list[list[I]]:
    perturb=I(-2*radius.hi,2*radius.hi)
    center=log_jets(coefficients,N_JACOBIAN,False,perturb)
    box=log_jets(coefficients,N_JACOBIAN,True,perturb)
    ec=m.normalizers(groups,[d.exponential(x) for x in center[3:]],2)
    eb=m.normalizers(groups,[d.exponential(x) for x in box[3:]],2)
    point=[d.exp(I.q(row[0])) for row in coefficients[3:]]
    thin=[d.exp(x[0]) for x in center[3:]]
    ep=m.normalizers(groups,[[x] for x in point],2)
    et=m.normalizers(groups,[[x] for x in thin],3)
    for h in range(len(groups)):
        for key in m.indices(2):
            value=ep[h][key][0]
            for j in range(3): value=value+et[h][tuple(sorted(key+(j,)))][0]*(thin[j]-point[j])
            old=ec[h][key][0]
            ec[h][key][0]=I(max(value.lo,old.lo),min(value.hi,old.hi))
    eb=m.tighten_time(ec,eb,N_JACOBIAN)
    jc=m.jacobian_jets(groups,center,ec)
    jb=m.jacobian_jets(groups,box,eb)
    result=[]
    for i in range(6):
        row=[]
        for j in range(6):
            bound=sum(v.abs_hi() for v in jc[i][j][1:N_JACOBIAN])+jb[i][j][N_JACOBIAN].abs_hi()
            value=I(jc[i][j][0].lo-bound,jc[i][j][0].hi+bound)
            old=jb[i][j][0]
            row.append(I(max(value.lo,old.lo),min(value.hi,old.hi)))
        result.append(row)
    return result


def ldl_pivots(matrix: list[list[F]]) -> list[F]:
    n=len(matrix)
    lower=[[F(i==j) for j in range(n)] for i in range(n)]
    diagonal=[]
    for j in range(n):
        value=matrix[j][j]-sum((lower[j][k]**2*diagonal[k] for k in range(j)),F(0))
        if value<=0: return []
        diagonal.append(value)
        for i in range(j+1,n):
            lower[i][j]=(matrix[i][j]-sum((lower[i][k]*lower[j][k]*diagonal[k] for k in range(j)),F(0)))/value
    return diagonal


def lognorm(jacobian: list[list[I]]) -> tuple[I,dict]:
    weighted=[[jacobian[i][j]*W[i]/W[j] for j in range(6)] for i in range(6)]
    symmetric=[[(weighted[i][j]+weighted[j][i])/2 for j in range(6)] for i in range(6)]
    midpoint=[[F(v.lo+v.hi,2*S) for v in row] for row in symmetric]
    radii=[[F(v.hi-v.lo,2*S) for v in row] for row in symmetric]
    rho=max(sum(row,F(0)) for row in radii)
    guess=float(np.linalg.eigvalsh(np.array([[float(v) for v in row] for row in midpoint]))[-1])
    q=F(ceil(guess*256)+1,256)
    for _ in range(8):
        pivots=ldl_pivots([[F(i==j)*q-midpoint[i][j] for j in range(6)] for i in range(6)])
        if pivots: break
        q+=F(1,256)
    assert pivots,'Rational positive-definiteness bound not found'
    bound=I.q(q+rho)
    return I(bound.hi,bound.hi),{'midpoint_upper_eigenvalue_bound':str(q),'radius_operator_norm_bound':str(rho),'positive_ldl_pivots':[str(v) for v in pivots],'symmetric_jacobian_enclosure':[[v.strings() for v in row] for row in symmetric]}


def polynomial_value(row: list[F], at: F) -> F:
    result=F(0)
    for v in reversed(row): result=result*at+v
    return result


def weighted_jump(x: list[F], y: list[F]) -> I:
    value=sum((I.q(abs(a-b))*w for a,b,w in zip(x,y,W)),d.ZERO)
    return I(value.hi,value.hi)


def check_path(groups: list[dict], segments: list[dict]) -> tuple[I,list[F],list[dict]]:
    error=I.q(0)
    previous=[F(0)]*6
    expected=F(0)
    terminal=[]
    readout_windows=[]
    for seg_index,segment in enumerate(segments):
        left=fraction(segment['t_old'])
        right=min(fraction(segment['t']),TARGET)
        if left>=TARGET: break
        assert left==expected,(float(left),float(expected))
        coefficients=dense_coefficients(segment)
        count=ceil((right-left)/MAX_STEP)
        for sub in range(count):
            a=left+(right-left)*sub/count
            b=left+(right-left)*(sub+1)/count
            local=restrict(coefficients,segment,a,b)
            start=[polynomial_value(row,F(-1)) for row in local]
            finish=[polynomial_value(row,F(1)) for row in local]
            jump=weighted_jump(previous,start)
            error=error+jump
            half=(b-a)/2
            residual,component_bounds=defect(groups,local,half)
            radius=(error+residual*I.q(b-a))*4+I.q(F(1,10**10))
            assert radius.hi<S//1000,('Candidate tube exceeds declared error cap',float(a),radius.floats())
            jac=jacobian_tube(groups,local,radius)
            growth,lognorm_certificate=lognorm(jac)
            factor=d.exp(growth*I.q(b-a))
            worst=I(max(S,factor.hi),max(S,factor.hi))
            within=(error+residual*I.q(b-a))*worst
            assert within.hi<radius.lo,('Tube exit inequality fails',float(a),within.floats(),radius.floats())
            end=error*factor+residual*I.q(b-a)*worst
            error=I(end.hi,end.hi)
            records.append({'left':str(a),'right':str(b),'source_segment':seg_index,'subsegment':sub,'residual_components':component_bounds,'weighted_residual_bound':str(F(residual.hi,S)),'weighted_logarithmic_norm_bound':str(F(growth.hi,S)),'tube_radius':str(F(radius.hi,S)),'weighted_error_bound':str(F(error.hi,S)),'within_interval_error_bound':str(F(within.hi,S)),'candidate_jump_bound':str(F(jump.hi,S)),'logarithmic_norm_certificate':lognorm_certificate})
            if b>=35: readout_windows.append({'left':a,'right':b,'coefficients':local,'error':within})
            previous=finish
            terminal=finish
            if len(records)%20==0:
                print(json.dumps({'enclosed_to':float(b),'steps':len(records),'error_bound':error.hi/S,'defect':residual.hi/S,'lognorm_bound':growth.hi/S}),flush=True)
        expected=right
    assert expected==TARGET
    return error,terminal,readout_windows


def main() -> None:
    start=time.perf_counter()
    coeff_path=folder/'determinant-polynomials.json'
    old_path=folder.parent/'fixed-pair-native/pilot-trajectory.json'
    new_path=folder/'continuation.json'
    data=json.loads(coeff_path.read_text(encoding='utf-8'))
    groups=m.prepare(data['rows'])
    old=json.loads(old_path.read_text(encoding='utf-8'))
    new=json.loads(new_path.read_text(encoding='utf-8'))
    metadata={'runtime':sys.executable,'python':platform.python_version(),'interval_bits':d.BITS,'residual_jet_order':N_RESIDUAL,'jacobian_jet_order':N_JACOBIAN,'maximum_substep':str(MAX_STEP),'target_time':str(TARGET),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'model_helper_sha256':sha256((folder/'native_interval_model.py').read_bytes()).hexdigest(),'arithmetic_helper_sha256':sha256((folder/'dyadic_interval.py').read_bytes()).hexdigest(),'determinant_input_sha256':sha256(coeff_path.read_bytes()).hexdigest(),'pilot_input_sha256':sha256(old_path.read_bytes()).hexdigest(),'continuation_input_sha256':sha256(new_path.read_bytes()).hexdigest(),'scope':'One a posteriori enclosure of the saved piecewise polynomial path from the exact all-unit preparation; no ODE reintegration or changed model.'}
    # The fixed-P exact unit moment supplies a distinct algebraic sanity check.
    geometry=json.loads((folder.parent/'transported-parent-prior/result.json').read_text(encoding='utf-8'))
    pair=next(row for row in geometry['rows'] if row['partition']==[[0,1],[2,3]])
    initial=[[d.ZERO] for _ in range(6)]
    es=m.normalizers(groups,[[d.ONE] for _ in range(3)],1)
    rates=m.vector_field(groups,initial,es)
    expected=[F(x)-1 for x in pair['posterior_M_energy_coordinates']]+[F(0)]*3
    assert all(F(v[0].lo,S)<=x<=F(v[0].hi,S) for v,x in zip(rates,expected))
    assert d.exp(d.ZERO).lo<=S<=d.exp(d.ZERO).hi
    try:
        error,terminal,windows=check_path(groups,old['dense_segments']+new['dense_segments'])
        result={**metadata,'status':'PASS_SAVED_PATH_ERROR_ENCLOSURE','weighted_error_bound':str(F(error.hi,S)),'terminal_log_candidate':[str(x) for x in terminal],'steps':records,'elapsed_seconds':time.perf_counter()-start,'not_proved':['Second-merge readout enclosure; separate endpoint calculation required','Boundary basin entry','Infinite-time convergence','A complete useful hierarchy']}
        (folder/'path-enclosure.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        window_data=[{'left':str(v['left']),'right':str(v['right']),'coefficients':[[str(x) for x in row] for row in v['coefficients']],'error_bound':str(F(v['error'].hi,S))} for v in windows]
        (folder/'late-window-candidates.json').write_text(json.dumps(window_data,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({key:result[key] for key in ('status','weighted_error_bound','elapsed_seconds')},indent=2),flush=True)
    except Exception as exc:
        result={**metadata,'status':'INCONCLUSIVE_PATH_ENCLOSURE','exception':repr(exc),'traceback':traceback.format_exc(),'completed_steps':records,'elapsed_seconds':time.perf_counter()-start}
        (folder/'path-enclosure-output-jet-failure.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        raise


if __name__=='__main__':
    main()
