"""One exact enclosure-order discriminator at the recorded failed interval."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import time

folder=Path(__file__).parent
source=folder/'validate_saved_path.py'
spec=importlib.util.spec_from_file_location('saved_validator_definitions',source)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)


def main() -> None:
    start=time.perf_counter()
    coefficients=json.loads((folder/'determinant-polynomials.json').read_text(encoding='utf-8'))
    groups=g.m.prepare(coefficients['rows'])
    previous=json.loads((folder.parent/'fixed-pair-native/pilot-trajectory.json').read_text(encoding='utf-8'))
    failure=json.loads((folder/'path-enclosure-refined-failure.json').read_text(encoding='utf-8'))
    left=F(failure['completed_steps'][-1]['right'])
    segment=next(seg for seg in previous['dense_segments'] if F.from_float(seg['t_old'])==left)
    right=F.from_float(segment['t'])
    local=g.restrict(g.dense_coefficients(segment),segment,left,right)
    g.N_RESIDUAL=12
    g.N_JACOBIAN=8
    residual,components=g.defect(groups,local,(right-left)/2)
    radius=g.I.q(F(1,100000))
    jac=g.jacobian_tube(groups,local,radius)
    growth,certificate=g.lognorm(jac)
    result={'status':'ENCLOSURE_ORDER_DISCRIMINATOR_COMPLETED','scope':'One interval from the preserved enclosure failure. Higher derivative orders change the enclosure method, not the native model or saved trajectory. No full path pass or ODE rerun.','interval':[str(left),str(right)],'residual_order':12,'jacobian_order':8,'weighted_radius':str(F(radius.hi,g.S)),'weighted_residual_bound':str(F(residual.hi,g.S)),'weighted_residual_bound_float':residual.hi/g.S,'weighted_logarithmic_norm_bound':str(F(growth.hi,g.S)),'weighted_logarithmic_norm_bound_float':growth.hi/g.S,'jacobian_certificate':certificate,'elapsed_seconds':time.perf_counter()-start,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'validator_sha256':sha256(source.read_bytes()).hexdigest(),'model_helper_sha256':sha256((folder/'native_interval_model.py').read_bytes()).hexdigest(),'failure_input_sha256':sha256((folder/'path-enclosure-refined-failure.json').read_bytes()).hexdigest()}
    (folder/'order-discriminator.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','weighted_residual_bound_float','weighted_logarithmic_norm_bound_float','elapsed_seconds')},indent=2),flush=True)


if __name__=='__main__':
    main()
