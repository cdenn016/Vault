"""Exact small matrix and scalar checks for the nonlinear formation derivation."""

from fractions import Fraction as F
import json
from pathlib import Path


def transpose(a: list[list[F]]) -> list[list[F]]:
    return [list(row) for row in zip(*a)]


def multiply(a: list[list[F]], b: list[list[F]]) -> list[list[F]]:
    return [[sum(x * y for x, y in zip(row, col)) for col in zip(*b)] for row in a]


def inverse(a: list[list[F]]) -> list[list[F]]:
    n = len(a)
    aug = [row[:] + [F(i == j) for j in range(n)] for i, row in enumerate(a)]
    for j in range(n):
        pivot = next(i for i in range(j, n) if aug[i][j])
        aug[j], aug[pivot] = aug[pivot], aug[j]
        v = aug[j][j]
        aug[j] = [x / v for x in aug[j]]
        for i in range(n):
            if i != j:
                v = aug[i][j]
                aug[i] = [x - v * y for x, y in zip(aug[i], aug[j])]
    return [row[n:] for row in aug]


def main() -> None:
    B_f = [[F(0) for _ in range(10)] for _ in range(5)]
    for i in range(3):
        B_f[i][i], B_f[i][i + 3] = F(1), F(-1)
    for row, entries in ((3, {0: 1, 1: -1, 6: -1}), (4, {3: 1, 4: -1, 8: -1})):
        for col, value in entries.items():
            B_f[row][col] = F(value)
    B_s = [[F(0) for _ in range(10)] for _ in range(2)]
    for row, entries in ((0, {1: 1, 2: -1, 7: -1}), (1, {4: 1, 5: -1, 9: -1})):
        for col, value in entries.items():
            B_s[row][col] = F(value)
    C = multiply(B_f, transpose(B_f))
    R = multiply(transpose(B_f), inverse(C))
    A = multiply(B_s, R)
    RB = multiply(R, B_f)
    P = [[F(i == j) - RB[i][j] for j in range(10)] for i in range(10)]
    S = multiply(multiply(B_s, P), transpose(B_s))
    expected_S = [[F(11, 6), F(5, 6)], [F(5, 6), F(11, 6)]]
    assert S == expected_S
    z0 = [[F(0)], [F(0)], [F(0)], [F(7, 24)], [F(7, 24)]]
    Az0 = multiply(A, z0)
    assert Az0 == [[F(-7, 72)], [F(-7, 72)]]
    assert F(7, 48) - Az0[0][0] == F(35, 144)
    checks = {
        "cut_mobility": S == expected_S,
        "symmetric_slow_eigenvalue": S[0][0] + S[0][1] == F(8, 3),
        "antisymmetric_slow_eigenvalue": S[0][0] - S[0][1] == 1,
        "initial_cut_center": F(5, 24) < F(35, 144) < F(5, 18),
        "initial_ellipsoid_margin_squared": 2 * F(5, 18) ** 2 < F(1, 2) ** 2,
        "early_parent_margin": F(25, 144) - F(1, 1024) > F(1, 10),
        "late_parent_margin": F(1, 3072) + F(1, 1024) < F(1, 256),
        "tangent_upper_bound": 2 * F(5, 36) / (1 - F(5, 36) ** 2 / 2) < F(1, 3),
        "exponential_lower_bound": F(8, 3) ** 8 > 1024,
    }
    assert all(checks.values())
    payload = {"arithmetic": "Python int and fractions.Fraction only", "checks": checks,
               "C": [[str(x) for x in row] for row in C],
               "A": [[str(x) for x in row] for row in A],
               "S": [[str(x) for x in row] for row in S]}
    output = Path(__file__).with_name("constants-output.json")
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checks": len(checks), "all_true": all(checks.values()), "output": str(output)}))


if __name__ == "__main__":
    main()
