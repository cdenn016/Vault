"""Exact two-channel, two-block first-variation response and access check."""
from __future__ import annotations

from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import traceback

Matrix = list[list[F]]
BASE = Path(__file__).resolve().parent


def zeros(m: int, n: int) -> Matrix:
    return [[F(0) for _ in range(n)] for _ in range(m)]


def eye(n: int) -> Matrix:
    return [[F(i == j) for j in range(n)] for i in range(n)]


def transpose(a: Matrix) -> Matrix:
    return [list(row) for row in zip(*a)]


def matmul(a: Matrix, b: Matrix) -> Matrix:
    out = zeros(len(a), len(b[0]))
    for i, row in enumerate(a):
        for k, val in enumerate(row):
            if val:
                for j, val_b in enumerate(b[k]):
                    if val_b:
                        out[i][j] += val * val_b
    return out


def inverse(a: Matrix) -> Matrix:
    n = len(a)
    rows = [row[:] + identity for row, identity in zip(a, eye(n))]
    for j in range(n):
        pivot = next(i for i in range(j, n) if rows[i][j])
        rows[j], rows[pivot] = rows[pivot], rows[j]
        scale = rows[j][j]
        rows[j] = [v / scale for v in rows[j]]
        for i in range(n):
            if i != j:
                scale = rows[i][j]
                if scale:
                    rows[i] = [x - scale*y for x, y in zip(rows[i], rows[j])]
    return [row[n:] for row in rows]


def rank(a: Matrix) -> int:
    rows = [row[:] for row in a]
    nrow, pivot = len(rows), 0
    for j in range(len(rows[0])):
        at = next((i for i in range(pivot, nrow) if rows[i][j]), None)
        if at is None:
            continue
        rows[pivot], rows[at] = rows[at], rows[pivot]
        scale = rows[pivot][j]
        rows[pivot] = [v / scale for v in rows[pivot]]
        for i in range(pivot + 1, nrow):
            scale = rows[i][j]
            if scale:
                rows[i] = [x - scale*y for x, y in zip(rows[i], rows[pivot])]
        pivot += 1
        if pivot == nrow:
            break
    return pivot


def determinant(a: Matrix) -> F:
    rows = [row[:] for row in a]
    out = F(1)
    for j in range(len(rows)):
        at = next((i for i in range(j, len(rows)) if rows[i][j]), None)
        if at is None:
            return F(0)
        if at != j:
            rows[j], rows[at] = rows[at], rows[j]
            out = -out
        pivot = rows[j][j]
        out *= pivot
        for i in range(j + 1, len(rows)):
            scale = rows[i][j] / pivot
            rows[i] = [x - scale*y for x, y in zip(rows[i], rows[j])]
    return out


def stats(n: int) -> list[tuple[int, ...]]:
    return [(i,) for i in range(n)] + [(i, j) for i in range(n) for j in range(i, n)]


def moment_map(f: Matrix) -> Matrix:
    """Linear map of first/raw-second Gaussian moments under y=F x."""
    r, n = len(f), len(f[0])
    source, target = stats(n), stats(r)
    source_index = {power: i for i, power in enumerate(source)}
    out = zeros(len(target), len(source))
    for a, power in enumerate(target):
        if len(power) == 1:
            for i, val in enumerate(f[power[0]]):
                out[a][source_index[(i,)]] += val
        else:
            left, right = power
            for i in range(n):
                for j in range(n):
                    out[a][source_index[tuple(sorted((i, j)))]] += f[left][i]*f[right][j]
    return out


def jsonable(value: object) -> object:
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    return value


def calculate() -> dict[str, object]:
    n, d = 8, 6
    c = F(1, 2)
    theta = [F(1, 3), F(1, 2), F(1, 2), F(2, 3), F(2, 3), F(1, 3)]
    names = ["m12", "b12", "m23", "b23", "m34", "b34"]
    # Coordinate order m1,b1,m2,b2,m3,b3,m4,b4.
    residual = eye(n)
    for i in range(4):
        residual[2*i+1][2*i] = -c
    routes: list[tuple[int, int]] = []
    for i in range(1, 4):
        for channel in range(2):
            receiving, parent = 2*i+channel, 2*(i-1)+channel
            a = len(routes)
            residual[receiving][parent] = -theta[a]
            routes.append((receiving, parent))
    r_inv = inverse(residual)
    prior_cov = matmul(r_inv, transpose(r_inv))
    prior_precision = matmul(transpose(residual), residual)
    assert determinant(residual) == 1
    assert matmul(prior_precision, prior_cov) == eye(n)

    fy = zeros(4, n)
    y_indices = [2, 3, 6, 7]
    for i, j in enumerate(y_indices):
        fy[i][j] = F(1)
    fz_y: Matrix = [[F(1, 2), F(0), F(1, 2), F(0)],
                    [F(0), F(1, 2), F(0), F(1, 2)]]
    fz = matmul(fz_y, fy)
    sensor = [[sum(row[j] for row in fz) for j in range(n)]]
    w = matmul(prior_cov, transpose(sensor))
    prior_sensor_var = matmul(sensor, w)[0][0]
    obs = F(4)
    total_sensor_var = obs**2
    noise = total_sensor_var - prior_sensor_var
    assert noise > 0
    mean = [row[0]/obs for row in w]
    post_cov = [[prior_cov[i][j]-w[i][0]*w[j][0]/total_sensor_var
                 for j in range(n)] for i in range(n)]
    post_precision = [[prior_precision[i][j]+sensor[0][i]*sensor[0][j]/noise
                       for j in range(n)] for i in range(n)]
    assert matmul(post_precision, post_cov) == eye(n)
    assert matmul(post_precision, [[x] for x in mean]) == [
        [sensor[0][i]*obs/noise] for i in range(n)]
    assert [[post_cov[i][j]+mean[i]*mean[j] for j in range(n)]
            for i in range(n)] == prior_cov

    @lru_cache(None)
    def moment(power: tuple[int, ...]) -> F:
        """Gaussian integration by parts with the actual nonzero posterior mean."""
        if not power:
            return F(1)
        first, rest = power[0], power[1:]
        value = mean[first]*moment(rest)
        for j, other in enumerate(rest):
            value += post_cov[first][other]*moment(rest[:j]+rest[j+1:])
        return value

    basis = stats(n)
    m = len(basis)
    assert m == 44
    index = {power: i for i, power in enumerate(basis)}
    score_coeff = zeros(d, m)
    j_derivatives: list[Matrix] = []
    for a, (receiving, parent) in enumerate(routes):
        for j, value in enumerate(residual[receiving]):
            score_coeff[a][index[tuple(sorted((parent, j)))]] += value
        ja = [[-(F(i == parent)*residual[receiving][j] +
                 residual[receiving][i]*F(j == parent))
               for j in range(n)] for i in range(n)]
        j_derivatives.append(ja)
    raw = [moment(power) for power in basis]
    assert matmul(score_coeff, [[x] for x in raw]) == zeros(d, 1)
    gram = [[moment(tuple(sorted(p+q)))-moment(p)*moment(q)
             for q in basis] for p in basis]
    drive = matmul(gram, transpose(score_coeff))
    posterior_info = matmul(score_coeff, drive)
    metric = [prior_cov[parent][parent] for _, parent in routes]
    assert all(value > 0 for value in metric)
    var_derivatives = [-matmul(transpose(w), matmul(ja, w))[0][0]
                       for ja in j_derivatives]
    evidence_hessian = [[x*y/(2*total_sensor_var**2)
                         for y in var_derivatives] for x in var_derivatives]
    assert rank(evidence_hessian) == 1
    assert [[F(i == j)*metric[i]-posterior_info[i][j] for j in range(d)]
            for i in range(d)] == evidence_hessian
    assert rank(posterior_info) == d

    # Independent target-moment derivatives, using Gaussian inverse calculus.
    independent_drive = zeros(m, d)
    for a, ja in enumerate(j_derivatives):
        c_dot = matmul(post_cov, matmul(ja, post_cov))
        c_dot = [[-v for v in row] for row in c_dot]
        mu_dot = [-row[0] for row in matmul(post_cov, matmul(ja, [[v] for v in mean]))]
        for k, power in enumerate(basis):
            if len(power) == 1:
                independent_drive[k][a] = mu_dot[power[0]]
            else:
                i, j = power
                independent_drive[k][a] = c_dot[i][j]+mu_dot[i]*mean[j]+mean[i]*mu_dot[j]
    assert drive == independent_drive

    my, mz_y, mz = moment_map(fy), moment_map(fz_y), moment_map(fz)
    assert matmul(mz_y, my) == mz

    fine = zeros(m+d, m+d)
    for i in range(m):
        fine[i][i] = -1
        fine[i][m:] = drive[i][:]
    for a in range(d):
        fine[m+a][:m] = [v/metric[a] for v in score_coeff[a]]
        fine[m+a][m+a] = -1

    def realization(moment_rows: Matrix) -> Matrix:
        r = len(moment_rows)
        out = zeros(r+2*d, r+2*d)
        local_drive = matmul(moment_rows, drive)
        for i in range(r):
            out[i][i] = -1
            out[i][r+d:] = local_drive[i][:]
        for a in range(d):
            out[r+a][r+a] = -1
            out[r+a][r+d:] = posterior_info[a][:]
            out[r+d+a][r+a] = 1/metric[a]
            out[r+d+a][r+d+a] = -1
        return out

    def retention(moment_rows: Matrix) -> Matrix:
        return ([row+[F(0)]*d for row in moment_rows] +
                [row+[F(0)]*d for row in score_coeff] +
                [[F(0)]*m+row for row in eye(d)])

    first_map, direct_map = retention(my), retention(mz)
    first_jac, root_jac = realization(my), realization(mz)
    second_map = [row+[F(0)]*(2*d) for row in mz_y]
    second_map += [[F(0)]*len(my)+row for row in eye(2*d)]
    assert matmul(first_map, fine) == matmul(first_jac, first_map)
    assert matmul(second_map, first_jac) == matmul(root_jac, second_map)
    assert matmul(second_map, first_map) == direct_map
    assert matmul(direct_map, fine) == matmul(root_jac, direct_map)
    assert [rank(first_map), rank(second_map), rank(direct_map)] == [26, 17, 17]

    # Distributed initializer: 7 local moments/scores per block, six interface scalars.
    local_rows: list[list[F]] = []
    local_dimensions = []
    for block_roots, internal_scores in [([2, 3], [0, 1]), ([6, 7], [4, 5])]:
        f = zeros(2, n)
        for i, j in enumerate(block_roots):
            f[i][j] = 1
        rows = moment_map(f)+[score_coeff[a] for a in internal_scores]
        local_dimensions.append(rank(rows))
        local_rows += rows
    interface_rows = [score_coeff[2], score_coeff[3]]
    for i in [2, 3]:
        for j in [6, 7]:
            row = [F(0)]*m
            row[index[(i, j)]] = 1
            interface_rows.append(row)
    distributed = ([row+[F(0)]*d for row in local_rows+interface_rows] +
                   [[F(0)]*m+row for row in eye(d)])
    assert local_dimensions == [7, 7]
    assert rank(interface_rows) == 6
    assert sorted(map(tuple, distributed)) == sorted(map(tuple, first_map))
    assert rank(distributed) == 26

    cuts = []
    for power, expected in [((2, 4), 2), ((3, 5), 3)]:
        perturbation = zeros(m, 1)
        perturbation[index[power]][0] = 1
        force = matmul(score_coeff, perturbation)
        assert force == [[F(a == expected)] for a in range(d)]
        assert matmul(my, perturbation) == zeros(len(my), 1)
        assert matmul(local_rows, perturbation) == zeros(len(local_rows), 1)
        cuts.append({"moment":power,"score_perturbation":force,
                     "link_velocity":1/metric[expected],"link":names[expected]})
    remote = [(i, a, val) for i, row in enumerate(matmul(my, drive)[:2])
              for a, val in enumerate(row) if a in [4, 5] and val]
    assert remote

    # A normalized score-sample lift does not share the tangent dimension saving.
    point = [F(v) for v in [1, 2, 3, 5, 7, 11, 13, 17]]
    sample_score_jac = zeros(d, n)
    for a, coeffs in enumerate(score_coeff):
        for power, coeff in zip(basis, coeffs):
            if not coeff:
                continue
            assert len(power) == 2
            i, j = power
            sample_score_jac[a][i] += coeff*point[j]
            sample_score_jac[a][j] += coeff*point[i]
    sample_first = fy+sample_score_jac
    sample_root = fz+sample_score_jac
    assert rank(sample_first) == rank(sample_root) == n
    root_det = determinant(sample_root)
    assert root_det
    local_sample_ranks = []
    for frows, scores, cols in [(fy[:2], [0, 1], list(range(4))),
                               (fy[2:], [4, 5], list(range(4, 8)))]:
        rows = frows+[sample_score_jac[a] for a in scores]
        local_sample_ranks.append(rank([[row[j] for j in cols] for row in rows]))
    assert local_sample_ranks == [4, 4]

    sens_y = [[F(1, 2)]*4]
    sens_z = [[F(1), F(1)]]
    assert matmul(sens_y, fy) == matmul(sens_z, fz) == sensor
    assert matmul(moment_map(sens_y), my) == moment_map(sensor)
    assert matmul(moment_map(sens_z), mz) == moment_map(sensor)
    observed_curvature = sum((evidence_hessian[a][a]/metric[a] for a in range(d)), F(0))
    assert 0 < observed_curvature < 1

    return {
        "status":"passed", "theta_reference":dict(zip(names,theta)), "bridge":c,
        "coordinate_order":["m1","b1","m2","b2","m3","b3","m4","b4"],
        "sensor":sensor, "observation":obs, "noise_variance":noise,
        "prior_sensor_variance":prior_sensor_var,
        "posterior_mean":mean, "posterior_covariance":post_cov,
        "generative_metric_diagonal":metric,
        "posterior_information":posterior_info, "evidence_hessian":evidence_hessian,
        "whitened_observed_curvature":observed_curvature, "evidence_hessian_rank":1,
        "native_neutral_structural_directions":5,
        "target_moment_derivatives":drive,
        "independent_target_derivative_check":True,
        "score_coefficients":score_coeff,
        "fine_jacobian":fine, "first_jacobian":first_jac, "root_jacobian":root_jac,
        "first_map":first_map, "second_map":second_map, "direct_map":direct_map,
        "evolving_dimensions":[50,26,17],
        "intertwiners_and_direct_staged_equal":True,
        "local_recognition_statistic_dimensions":local_dimensions,
        "first_interface_dimension":6,
        "cut_locality_witnesses":cuts,
        "remote_link_drives_local_mean":remote,
        "sample_lift_ranks":[rank(sample_first),rank(sample_root)],
        "sample_lift_local_ranks":local_sample_ranks,
        "sample_root_jacobian_point":point, "sample_root_jacobian_determinant":root_det,
        "compiled_dense_coefficients":{"fine":44*6+15+6,"first":14*6+36+6,"root":5*6+36+6},
        "scope":"Stationary first variation and Gaussian moment access only; not nonlinear formation.",
    }


def main() -> None:
    started=time.perf_counter()
    try:
        result=calculate()
    except Exception:
        (BASE/'result.json').write_text(json.dumps({
            "status":"failed","traceback":traceback.format_exc()},indent=2)+'\n',encoding='utf-8')
        raise
    result.update({"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   "python":sys.version,"elapsed_seconds":time.perf_counter()-started,
                   "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   "nonlinear_integration":False,"new_observation_collection":False})
    (BASE/'result.json').write_text(json.dumps(jsonable(result),indent=2)+'\n',encoding='utf-8')
    fields=["status","noise_variance","evolving_dimensions","local_recognition_statistic_dimensions",
            "first_interface_dimension","sample_lift_ranks","sample_root_jacobian_determinant",
            "native_neutral_structural_directions","elapsed_seconds"]
    print(json.dumps(jsonable({key:result[key] for key in fields})))


if __name__=="__main__":
    main()

