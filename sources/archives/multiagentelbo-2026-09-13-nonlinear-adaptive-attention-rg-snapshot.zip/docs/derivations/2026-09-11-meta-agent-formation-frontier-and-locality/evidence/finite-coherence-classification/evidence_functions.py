"""Construct every exact evidence function of child variance at b=c=1."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform
import sys
import time
import sympy as sp
from sympy.polys.fields import field

sys.set_int_max_str_digits(200000)
folder=Path(__file__).parent
helper_path=folder.parent/'transported-parent-prior/boundary_exact.py'
spec=importlib.util.spec_from_file_location('previous_polynomial_definitions',helper_path)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)  # No guarded main is executed.
K,a=field('a',sp.QQ)


def encode(poly: object) -> list[str]:
    values=poly.to_dict()
    return [str(values.get((i,),0)) for i in range(poly.degree()+1)]


def at_one(value: object) -> F:
    return F(str(value.numer.evaluate(0,1)))/F(str(value.denom.evaluate(0,1)))


def main() -> None:
    start=time.perf_counter()
    input_path=folder.parent/'transported-parent-prior/result.json'
    data=json.loads(input_path.read_text())
    lap=g.h.multiply(g.g.B,g.h.transpose(g.g.B))
    functions={}
    cases=[]
    for row in data['rows']:
        combined=K(0)
        decorated=[]
        for dec in row['details']:
            gamma=[[F(v) for v in line] for line in dec['Gamma']]
            key=tuple(tuple(line) for line in gamma)
            if key not in functions:
                gamma0=[[gamma[i][j]-lap[i][j] for j in range(4)] for i in range(4)]
                value=K(0)
                determinants=[]
                for bits in product((0,1),repeat=4):
                    powers=tuple(n+b for n,b in zip(g.g.N,bits))
                    base=[[F(i==j)+gamma0[i][j]*powers[j] for j in range(4)] for i in range(4)]
                    linear=[[lap[i][j]*powers[j] for j in range(4)] for i in range(4)]
                    coef=g.determinant_polynomial(base,linear)
                    assert coef[0]>0 and all(v>=0 for v in coef) and coef[4]==0
                    polynomial=sum((K(sp.QQ(v.numerator,v.denominator))*a**j for j,v in enumerate(coef)),K(0))
                    value+=K((-1)**sum(bits))/polynomial
                    determinants.append([str(v) for v in coef])
                assert at_one(value)==F(dec['one_channel_evidence'])
                functions[key]=(value,len(functions),determinants)
                print('covariance',len(functions),'degrees',value.numer.degree(),value.denom.degree(),flush=True)
            value,index,_=functions[key]
            combined+=value**2/len(row['details'])
            decorated.append(index)
        assert at_one(combined)==F(row['evidence'])
        cases.append({'partition':row['partition'],'labels':row['labels'],'k':row['k'],
                      'decorated_function_indices':decorated,'value':combined})
        print('partition',row['partition'],'degrees',combined.numer.degree(),combined.denom.degree(),flush=True)
    groups=[]
    for case in cases:
        match=next((i for i,entry in enumerate(groups) if entry['value']==case['value']),None)
        if match is None:
            groups.append({'value':case['value'],'partitions':[case['partition']]})
            match=len(groups)-1
        else:
            groups[match]['partitions'].append(case['partition'])
        case['function_group']=match
    output_functions=[]
    for value,index,determinants in functions.values():
        output_functions.append({'index':index,'numerator':encode(value.numer),'denominator':encode(value.denom),'positive_determinants':determinants})
    result={'status':'PASS','runtime':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'ground_types':sp.external.gmpy.GROUND_TYPES,
            'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'polynomial_helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),
            'input_sha256':sha256(input_path.read_bytes()).hexdigest(),'scope':'All positive a at fixed b=c=1; exact symbolic functions, no numerical variance sampling.',
            'coefficient_order':'ascending','conditional_functions':output_functions,
            'groups':[{'index':i,'partitions':entry['partitions'],'numerator':encode(entry['value'].numer),'denominator':encode(entry['value'].denom),
                       'degrees':[entry['value'].numer.degree(),entry['value'].denom.degree()]} for i,entry in enumerate(groups)],
            'cases':[{key:value for key,value in case.items() if key!='value'} for case in cases],
            'elapsed_seconds':time.perf_counter()-start,'not_run':['parameter point search','fit','ODE','new data','sampling','GPU','test suite','Lean','tamper checks']}
    Path(__file__).with_name('evidence-functions.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'groups':len(groups),'degrees':[g['degrees'] for g in result['groups']],'elapsed_seconds':result['elapsed_seconds']},indent=2),flush=True)

if __name__=='__main__':
    main()
