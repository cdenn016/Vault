"""Exact sign structure of every pairwise evidence comparison."""
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import platform
import time
import sympy as sp
from sympy.polys.fields import field

folder=Path(__file__).parent
K,a=field('a',sp.QQ)


def decode(coefficients: list[str]) -> object:
    return sum((K(sp.QQ(sp.Rational(v)))*a**j for j,v in enumerate(coefficients)),K(0))


def encode(poly: object) -> list[str]:
    values=poly.to_dict()
    return [str(values.get((i,),0)) for i in range(poly.degree()+1)]


def variations(coefficients: list[str]) -> int:
    signs=[sp.sign(sp.Rational(v)) for v in coefficients if sp.Rational(v)]
    return sum(signs[i]!=signs[i+1] for i in range(len(signs)-1))


def main() -> None:
    start=time.perf_counter()
    source=folder/'evidence-functions.json'
    data=json.loads(source.read_text())
    values=[decode(row['numerator'])/decode(row['denominator']) for row in data['groups']]
    comparisons=[]
    for i,j in combinations(range(len(values)),2):
        difference=values[i]-values[j]
        assert difference
        coefficients=encode(difference.numer)
        row={'groups':[i,j],'numerator':coefficients,'denominator':encode(difference.denom),
             'degree':difference.numer.degree(),'positive_root_bound':variations(coefficients),
             'sign_at_zero_plus':int(sp.sign(next(sp.Rational(v) for v in coefficients if sp.Rational(v)))),
             'sign_at_infinity':int(sp.sign(sp.Rational(coefficients[-1])))}
        assert all(sp.Rational(v)>=0 for v in row['denominator']) and sp.Rational(row['denominator'][0])>0
        comparisons.append(row)
        print(i,j,'degree',row['degree'],'variations',row['positive_root_bound'],'signs',row['sign_at_zero_plus'],row['sign_at_infinity'],flush=True)
    result={'status':'PASS','python':platform.python_version(),'sympy':sp.__version__,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
            'input_sha256':sha256(source.read_bytes()).hexdigest(),'coefficient_order':'ascending','comparisons':comparisons,
            'elapsed_seconds':time.perf_counter()-start,'scope':'All pairwise exact rational differences and Descartes upper bounds; root counts beyond zero/one remain a separate obligation.'}
    Path(__file__).with_name('comparison-polynomials.json').write_text(json.dumps(result,indent=2)+'\n')
    print('seconds',result['elapsed_seconds'],flush=True)

if __name__=='__main__':
    main()
