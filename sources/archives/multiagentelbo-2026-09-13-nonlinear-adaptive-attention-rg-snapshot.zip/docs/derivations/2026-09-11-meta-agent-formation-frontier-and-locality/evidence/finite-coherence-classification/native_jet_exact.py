"""Native finite-rate ancestry response at the common unit exact posterior."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import time

folder=Path(__file__).parent


def main() -> None:
    start=time.perf_counter()
    source=folder.parent/'transported-parent-prior/result.json'
    data=json.loads(source.read_text())
    rows=[]
    for row in data['rows']:
        velocity=[F(v) for v in row['initial_native_variance_derivative']]
        k=row['k']
        score=[8*velocity[0],2*k*velocity[1],8*velocity[2]]
        rows.append({'partition':row['partition'],'k':k,'evidence':F(row['evidence']),'velocity':velocity,'score':score})
    root=next(row for row in rows if row['k']==1)
    pair=next(row for row in rows if row['partition']==[[0,1],[2,3]])
    difference=[p-r for p,r in zip(pair['score'],root['score'])]
    assert all(v<0 for v in difference)
    assert all(row['velocity'][0]<0 and row['velocity'][2]<0 for row in rows)
    assert all(row['velocity'][1] <= 0 for row in rows)
    assert all(row['velocity'][1]<0 for row in rows if row['k']>1)
    minimum_a=min(-row['velocity'][0] for row in rows)
    minimum_c=min(-row['velocity'][2] for row in rows)
    lower=-difference[0]*minimum_a-difference[2]*minimum_c
    assert lower>0
    a_over_c_margin=min(row['velocity'][2]-row['velocity'][0] for row in rows)
    assert a_over_c_margin>0
    # Clear the positive Z*K_pi denominator of a_dot-b_dot. This is a quadratic in pi.
    ab_coefficients=[]
    for i,first in enumerate(rows):
        for j in range(i,len(rows)):
            second=rows[j]
            coefficient=first['evidence']*(second['k']*first['velocity'][0]-first['k']*first['velocity'][1])
            if i!=j:
                coefficient+=second['evidence']*(first['k']*second['velocity'][0]-second['k']*second['velocity'][1])
            ab_coefficients.append({'indices':[i,j],'coefficient':str(coefficient),'sign':(coefficient>0)-(coefficient<0)})
    all_nonpositive=all(row['sign']<=0 for row in ab_coefficients)
    strict_diagonal=any(row['sign']<0 and row['indices'][0]==row['indices'][1] for row in ab_coefficients)
    result={'status':'PASS','scope':'Exact initial native-flow jet for every fixed positive partition prior; no numerical prior or trajectory selected.',
            'python':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':sha256(source.read_bytes()).hexdigest(),
            'initial_state':'Model and recognition variances a=b=c=v=1, s=1, omega=0; exact old posterior.',
            'pair_minus_root_log_evidence_gradient':[str(v) for v in difference],
            'pair_minus_root_log_evidence_gradient_float':[float(v) for v in difference],
            'minimum_a_speed':str(minimum_a),'minimum_c_speed':str(minimum_c),
            'log_ancestry_odds_first_derivative':'0','log_ancestry_odds_second_derivative_lower_bound':str(lower),
            'log_ancestry_odds_second_derivative_lower_bound_float':float(lower),
            'a_over_c_negative_margin':str(a_over_c_margin),
            'a_over_b_quadratic_coefficients_all_nonpositive':all_nonpositive,'a_over_b_strict_for_positive_pi':all_nonpositive and strict_diagonal,
            'a_over_b_quadratic_coefficients':ab_coefficients,
            'rows':[{'partition':row['partition'],'k':row['k'],'evidence':str(row['evidence']),
                     'velocity':[str(v) for v in row['velocity']],'score':[str(v) for v in row['score']]} for row in rows],
            'elapsed_seconds':time.perf_counter()-start,
            'not_run':['ODE trajectory','parameter fit','ancestry-prior selection','new data','stochastic samples','test suite','GPU','Lean','tamper checks']}
    Path(__file__).with_name('native-jet.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:result[key] for key in ('status','pair_minus_root_log_evidence_gradient_float','log_ancestry_odds_second_derivative_lower_bound_float','a_over_b_quadratic_coefficients_all_nonpositive','a_over_b_strict_for_positive_pi','elapsed_seconds')},indent=2))

if __name__=='__main__':
    main()
