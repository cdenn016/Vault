"""Exact Descartes/root-isolation classification of all positive child variances."""
from fractions import Fraction as F
from functools import cmp_to_key, reduce
from hashlib import sha256
from math import gcd, lcm
import json
from pathlib import Path
import platform
import time

folder=Path(__file__).parent


def integer_coefficients(values: list[str]) -> list[int]:
    fractions=[F(v) for v in values]
    common=1
    for value in fractions:
        common=lcm(common,value.denominator)
    coefficients=[value.numerator*(common//value.denominator) for value in fractions]
    content=reduce(gcd,(abs(v) for v in coefficients if v))
    coefficients=[v//content for v in coefficients]
    while coefficients and coefficients[0]==0:
        coefficients.pop(0)  # Removing a power of positive a does not change its sign.
    assert coefficients and coefficients[0]
    return coefficients


def sign_at(coefficients: list[int], x: F) -> int:
    numerator=x.numerator; denominator=x.denominator
    value=coefficients[-1]; power=denominator
    for coefficient in reversed(coefficients[:-1]):
        value=value*numerator+coefficient*power
        power*=denominator
    return (value>0)-(value<0)


def isolate(coefficients: list[int]) -> tuple[F,F]:
    left=F(0);right=F(1)
    initial=sign_at(coefficients,left)
    while sign_at(coefficients,right)==initial:
        right*=2
    if sign_at(coefficients,right)==0:
        return right,right
    while right-left>F(1,2**48):
        middle=(left+right)/2
        sign=sign_at(coefficients,middle)
        if sign==0:
            return middle,middle
        if sign==initial:
            left=middle
        else:
            right=middle
    assert sign_at(coefficients,left)*sign_at(coefficients,right)==-1
    return left,right


def main() -> None:
    start=time.perf_counter()
    source=folder/'comparison-polynomials.json'; data=json.loads(source.read_text())
    definitions=json.loads((folder/'evidence-functions.json').read_text())
    signs={}
    roots=[]
    always=[]
    for row in data['comparisons']:
        i,j=row['groups']
        coefficients=integer_coefficients(row['numerator'])
        sequence=[(v>0)-(v<0) for v in coefficients if v]
        changes=sum(sequence[t]!=sequence[t+1] for t in range(len(sequence)-1))
        assert changes==row['positive_root_bound'] and changes in (0,1)
        signs[i,j]=row['sign_at_zero_plus'];signs[j,i]=-row['sign_at_zero_plus']
        if changes==0:
            assert row['sign_at_zero_plus']==row['sign_at_infinity']
            always.append({'groups':[i,j],'sign':row['sign_at_zero_plus']})
            continue
        assert row['sign_at_zero_plus']==-row['sign_at_infinity']
        left,right=isolate(coefficients)
        roots.append({'groups':[i,j],'interval':[str(left),str(right)],'left':left,'right':right,
                      'sign_below':row['sign_at_zero_plus'],'sign_above':row['sign_at_infinity'],
                      'midpoint_float':float((left+right)/2),'positive_root_count':1,'multiplicity':1})
    roots.sort(key=lambda row:row['left'])
    for earlier,later in zip(roots,roots[1:]):
        assert earlier['right']<later['left'],(earlier['groups'],later['groups'])
    order=sorted(range(len(definitions['groups'])),key=cmp_to_key(lambda i,j:-signs[i,j] if i!=j else 0))
    for i in range(len(order)):
        for j in range(i+1,len(order)):
            assert signs[order[i],order[j]]==1
    initial_order=order[:]
    phases=[]
    winner=order[0];start_root=None
    transitions=[]
    for root_index,root in enumerate(roots):
        i,j=root['groups'];ii=order.index(i);jj=order.index(j)
        assert abs(ii-jj)==1,(root_index,order,root['groups'])
        old_winner=order[0]
        order[ii],order[jj]=order[jj],order[ii]
        signs[i,j]*=-1;signs[j,i]*=-1
        root['order_above']=order[:]
        root['top_tie']=ii==0 or jj==0
        if order[0]!=old_winner:
            phases.append({'start_root':start_root,'end_root':root_index,'winning_group':winner,
                           'winning_partitions':definitions['groups'][winner]['partitions']})
            transitions.append({'root_index':root_index,'groups':root['groups'],'interval':root['interval'],
                                'midpoint_float':root['midpoint_float'],
                                'tied_partitions':definitions['groups'][i]['partitions']+definitions['groups'][j]['partitions']})
            winner=order[0];start_root=root_index
    phases.append({'start_root':start_root,'end_root':None,'winning_group':winner,'winning_partitions':definitions['groups'][winner]['partitions']})
    for row in data['comparisons']:
        i,j=row['groups']
        assert signs[i,j]==row['sign_at_infinity']
    result={'status':'PASS','python':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
            'input_sha256':sha256(source.read_bytes()).hexdigest(),'functions_sha256':sha256((folder/'evidence-functions.json').read_bytes()).hexdigest(),
            'scope':'Exact full ordering on a>0 for b=c=1. Descartes variations 0/1 prove counts; rational isolating intervals prove root order.',
            'positive_crossings':len(roots),'never_crossing':always,'initial_order':initial_order,'final_order':order,
            'roots':[{key:value for key,value in row.items() if key not in ('left','right')} for row in roots],
            'phases':phases,'maximizer_transitions':transitions,'elapsed_seconds':time.perf_counter()-start,
            'not_run':['parameter sweep','fit','ODE','new data','stochastic samples','Lean','tamper checks']}
    Path(__file__).with_name('classification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:result[key] for key in ('status','positive_crossings','initial_order','final_order','phases','maximizer_transitions','elapsed_seconds')},indent=2))

if __name__=='__main__':
    main()
