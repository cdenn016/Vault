"""Exact local boundary critical-point enclosure from the failed interior probe."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform
import sys
import time
import mpmath as mp
import sympy as sp
from sympy.polys.fields import field

sys.set_int_max_str_digits(200000)
folder=Path(__file__).parent
helper_path=folder.parent/'transported-parent-prior/boundary_exact.py'
spec=importlib.util.spec_from_file_location('existing_polynomial_definitions',helper_path)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
h=g.h
K,a,b=field('a,b',sp.QQ)
GENERATORS=(a.numer,b.numer)
Interval=tuple[F,F]


def encode(poly: object) -> list[list]:
    return [[i,j,str(v)] for (i,j),v in sorted(poly.to_dict().items())]


def pack(value: object) -> dict:
    return {'numerator':encode(value.numer),'denominator':encode(value.denom)}


def iv_add(x: Interval, y: Interval) -> Interval:
    return x[0]+y[0],x[1]+y[1]


def iv_neg(x: Interval) -> Interval:
    return -x[1],-x[0]


def iv_mul(x: Interval, y: Interval) -> Interval:
    v=[a*b for a in x for b in y]
    return min(v),max(v)


def iv_div(x: Interval, y: Interval) -> Interval:
    assert y[0]>0 or y[1]<0
    return iv_mul(x,(1/y[1],1/y[0]))


def iv_poly(poly: object, box: list[Interval]) -> Interval:
    degrees=poly.degrees()
    powers=[]
    for interval,degree in zip(box,degrees):
        sequence=[(F(1),F(1))]
        for _ in range(degree):
            sequence.append(iv_mul(sequence[-1],interval))
        powers.append(sequence)
    total=(F(0),F(0))
    for (i,j),value in poly.to_dict().items():
        coefficient=F(str(value))
        total=iv_add(total,iv_mul((coefficient,coefficient),iv_mul(powers[0][i],powers[1][j])))
    return total


def iv_function(value: object, box: list[Interval]) -> Interval:
    return iv_div(iv_poly(value.numer,box),iv_poly(value.denom,box))


def midpoint_value(poly: object, center: list[F]) -> F:
    return sum((F(str(v))*center[0]**i*center[1]**j for (i,j),v in poly.to_dict().items()),F(0))


def mp_poly(poly: object, values: tuple) -> mp.mpf:
    return sum((mp.mpf(str(v))*values[0]**i*values[1]**j for (i,j),v in poly.to_dict().items()),mp.mpf(0))


def interval_strings(value: Interval) -> list[str]:
    return [str(x) for x in value]


def main() -> None:
    start=time.perf_counter()
    source=folder.parent/'transported-parent-prior/result.json'
    probe_source=folder/'stationarity-probe.json'
    data=json.loads(source.read_text(encoding='utf-8'))
    probe=json.loads(probe_source.read_text(encoding='utf-8'))
    pair=next(row for row in data['rows'] if row['partition']==[[0,1],[2,3]])
    ga=h.multiply(g.g.B,h.transpose(g.g.B))
    j=h.multiply(g.g.B,h.mat([[1,0],[1,0],[0,1],[0,1]]))
    gb=h.multiply(j,h.transpose(j))
    gc=h.mat([[0]*4]*4)
    for dec in pair['details']:
        c=[[F(x) for x in row] for row in dec['C']]
        gram=h.multiply(c,h.transpose(c))
        gc=[[x+y/len(pair['details']) for x,y in zip(xx,yy)] for xx,yy in zip(gc,gram)]
    assert gc==h.mat([[0,0,0,0],[0,2,0,0],[0,0,0,0],[0,0,0,2]])
    gamma=[[a*ga[i][j]+b*gb[i][j] for j in range(4)] for i in range(4)]
    t=[F(1,2),F(1),F(1,2),F(0)]
    integrals=[]
    c_derivative=K(0)
    for multiplicity in range(3):
        integral=K(0)
        for bits in product((0,1),repeat=4):
            q=[[F(g.g.N[i]+bits[i]) if i==j else F(0) for j in range(4)] for i in range(4)]
            q=[[q[i][j]+multiplicity*t[i]*t[j] for j in range(4)] for i in range(4)]
            linear=h.multiply(gamma,q)
            constant=[[F(i==j)+linear[i][j] for j in range(4)] for i in range(4)]
            c_linear=h.multiply(gc,q) if multiplicity==0 else h.mat([[0]*4]*4)
            determinant=g.determinant_polynomial(constant,c_linear)
            value=K((-1)**sum(bits))/determinant[0]
            integral+=value
            if multiplicity==0:
                c_derivative-=value*determinant[1]/determinant[0]
        integrals.append(integral)
        print('boundary integral',multiplicity,'terms',len(integral.numer.to_dict()),len(integral.denom.to_dict()),flush=True)
    e=integrals[0]
    derivatives=[e.diff(variable) for variable in (a,b)]
    equations=[value.numer for value in derivatives]
    jacobian=[[value.diff(variable) for variable in GENERATORS] for value in equations]
    mp.mp.dps=100
    seed=tuple(mp.mpf(str(x)) for x in probe['candidate_variances'][:2])
    scales=[max(abs(mp_poly(jacobian[i][j],seed)) for j in range(2)) for i in range(2)]
    def fun(x: mp.mpf, y: mp.mpf) -> tuple:
        return tuple(mp_poly(poly,(x,y))/scale for poly,scale in zip(equations,scales))
    def jac(x: mp.mpf, y: mp.mpf) -> mp.matrix:
        return mp.matrix([[mp_poly(jacobian[i][j],(x,y))/scales[i] for j in range(2)] for i in range(2)])
    refined=mp.findroot(fun,seed,J=jac,tol=mp.mpf('1e-70'),maxsteps=12)
    center=[F(mp.nstr(x,80)) for x in refined]
    radius=F(1,10**20)
    box=[(x-radius,x+radius) for x in center]
    assert min(x[0] for x in box)>0
    f0=[midpoint_value(poly,center) for poly in equations]
    j0=[[midpoint_value(poly,center) for poly in row] for row in jacobian]
    determinant=j0[0][0]*j0[1][1]-j0[0][1]*j0[1][0]
    assert determinant!=0
    inverse=[[j0[1][1]/determinant,-j0[0][1]/determinant],[-j0[1][0]/determinant,j0[0][0]/determinant]]
    interval_jac=[[iv_poly(poly,box) for poly in row] for row in jacobian]
    defect=[]
    for i in range(2):
        row=[]
        for j in range(2):
            entry=(F(i==j),F(i==j))
            for k in range(2):
                entry=iv_add(entry,iv_neg(iv_mul((inverse[i][k],inverse[i][k]),interval_jac[k][j])))
            row.append(entry)
        defect.append(row)
    norms=[sum(max(abs(x) for x in interval) for interval in row) for row in defect]
    offsets=[abs(sum((inverse[i][j]*f0[j] for j in range(2)),F(0))) for i in range(2)]
    assert max(norms)<1 and all(offset+radius*norm<radius for offset,norm in zip(offsets,norms))
    e_iv=iv_function(e,box)
    assert e_iv[0]>0
    denominators=[iv_poly(value.denom,box) for value in derivatives]
    row_factors=[iv_div((F(2),F(2)),iv_mul(e_iv,d)) for d in denominators]
    hessian=[[iv_mul(row_factors[i],interval_jac[i][j]) for j in range(2)] for i in range(2)]
    det_h=iv_add(iv_mul(hessian[0][0],hessian[1][1]),iv_neg(iv_mul(hessian[0][1],hessian[1][0])))
    assert hessian[0][0][1]<0 and det_h[0]>0
    score=iv_div(iv_mul((F(2),F(2)),iv_function(c_derivative,box)),e_iv)
    e1=iv_function(integrals[1],box)
    e2=iv_function(integrals[2],box)
    merge=iv_div(iv_add(iv_mul((F(2),F(2)),iv_mul(e1,e1)),iv_neg(iv_mul(e2,e2))),iv_mul(e_iv,e_iv))
    assert score[1]<0 and 0<merge[0]<merge[1]<F(1,2)
    result={'status':'PASS_EXACT_LOCAL_BOUNDARY_ENCLOSURE','runtime':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'mpmath':mp.__version__,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':sha256(source.read_bytes()).hexdigest(),'probe_sha256':sha256(probe_source.read_bytes()).hexdigest(),'polynomial_helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),'gaussian_helper_sha256':sha256(g.source.read_bytes()).hexdigest(),'matrix_helper_sha256':sha256(g.g.HELPER.read_bytes()).hexdigest(),
    'scope':'One exact local critical point of the c=0 limiting pair evidence, all four root decorations retained. Multiprecision supplies a center; rational interval contraction proves existence and uniqueness within the stated box. This does not certify the unit-prepared native trajectory or an interior fixed point.',
    'polynomial_term_format':['a_exponent','b_exponent','coefficient'],'one_channel_integrals':[pack(value) for value in integrals],'mean_c_derivative_integral':pack(c_derivative),'critical_equation_numerators':[encode(poly) for poly in equations],'critical_equation_denominators':[encode(value.denom) for value in derivatives],
    'root_center':[str(x) for x in center],'root_center_float':[float(x) for x in center],'box_radius':str(radius),'root_box':[interval_strings(v) for v in box],'preconditioner':[[str(v) for v in row] for row in inverse],'contraction_row_norm_bounds':[str(x) for x in norms],'contraction_row_norm_bounds_float':[float(x) for x in norms],'center_correction_bounds':[str(x) for x in offsets],'center_correction_bounds_float':[float(x) for x in offsets],
    'boundary_evidence_hessian_at_root_enclosure':[[interval_strings(v) for v in row] for row in hessian],'boundary_evidence_hessian_at_root_float':[[[float(x) for x in v] for v in row] for row in hessian],'boundary_hessian_determinant_enclosure':interval_strings(det_h),'boundary_c_score_enclosure':interval_strings(score),'boundary_c_score_float':[float(x) for x in score],'native_center_quadratic_coefficient_enclosure':interval_strings(iv_div(score,(F(16),F(16)))),'boundary_merge_enclosure':interval_strings(merge),'boundary_merge_float':[float(x) for x in merge],'elapsed_seconds':time.perf_counter()-start,
    'not_run':['Native trajectory extension or enclosure','Additional interior solver attempt','Numerical positive ancestry prior','Parameter grid','New data','Sampling','GPU','Suite','Lean','Tamper checks','Earlier scientific mains']}
    (folder/'boundary-local-enclosure.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('status','root_center_float','contraction_row_norm_bounds_float','center_correction_bounds_float','boundary_evidence_hessian_at_root_float','boundary_c_score_float','boundary_merge_float','elapsed_seconds')},indent=2),flush=True)


if __name__=='__main__':
    main()
