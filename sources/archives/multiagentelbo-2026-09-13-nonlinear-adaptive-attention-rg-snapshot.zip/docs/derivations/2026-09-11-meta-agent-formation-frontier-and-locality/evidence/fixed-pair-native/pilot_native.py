"""One numerical fixed-pair native trajectory; not a validated ODE certificate."""
from fractions import Fraction
from hashlib import sha256
import importlib.util
import inspect
from itertools import product
import json
from pathlib import Path
import platform
import sys
import time
import numpy as np
import scipy
from scipy.integrate import solve_ivp

folder=Path(__file__).parent
source=folder.parent/'transported-parent-prior/result.json'
helper_path=folder.parent/'shared-parent-record/shared_parent_exact.py'
spec=importlib.util.spec_from_file_location('existing_record_definitions',helper_path)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
data=json.loads(source.read_text(encoding='utf-8'))
pair=next(row for row in data['rows'] if row['partition']==[[0,1],[2,3]])
B=np.array(g.B,dtype=float)
J=B@np.array([[1,0],[1,0],[0,1],[0,1]],dtype=float)
G_a=B@B.T
G_b=J@J.T
unique={}
for decoration in pair['details']:
    C=np.array([[float(Fraction(x)) for x in row] for row in decoration['C']])
    gram=C@C.T
    key=tuple(gram.ravel())
    if key not in unique:
        unique[key]={'grams':np.stack((G_a,G_b,gram)),'weight':0.0}
    unique[key]['weight']+=1/len(pair['details'])
    assert np.array_equal(G_a+G_b+gram,np.array([[float(Fraction(x)) for x in row] for row in decoration['Gamma']]))
GRAMS=np.stack([entry['grams'] for entry in unique.values()])  # (H, parameter, residual, residual)
W_H=np.array([entry['weight'] for entry in unique.values()])
DIMENSIONS=np.array([16.,8.,16.])
T=np.array([[.5,1.,.5,0.],[.5,0.,.5,1.]])
BITS=np.array(list(product((0,1),repeat=4)))
SIGNS=(-1.)**BITS.sum(axis=1)
Q=np.array([[np.diag(np.array(g.N)+bits)+sum((np.outer(T[j],T[j]) for j in range(2) if mask&(1<<j)),np.zeros((4,4))) for bits in BITS] for mask in range(4)])
Q_INV=np.linalg.inv(Q)
Q_DET=np.linalg.det(Q)
METRICS={'rhs_calls':0,'readout_calls':0,'minimum_signed_sum_ratio':1.0}


def moments(variance: np.ndarray) -> tuple[float,np.ndarray]:
    r"""Return Z and E_Q E_j from the full decorated Gaussian conditional."""
    gamma=np.einsum('j,hjkl->hkl',variance,GRAMS)
    s=gamma[:,None,:,:]+Q_INV[0][None,:,:,:]
    determinants=np.linalg.det(s)
    inverse=np.linalg.inv(s)
    terms=SIGNS[None,:]/(Q_DET[0][None,:]*determinants)
    evidence=terms.sum(axis=1)
    assert np.all(evidence>0) and np.all(determinants>0)
    METRICS['minimum_signed_sum_ratio']=min(METRICS['minimum_signed_sum_ratio'],float(np.min(evidence/np.abs(terms).sum(axis=1))))
    trace=np.einsum('hjkl,hnlk->hjn',GRAMS,inverse)
    delta=(-trace*terms[:,None,:]).sum(axis=2)
    conditional=DIMENSIONS[None,:]*variance[None,:]+4*variance[None,:]**2*delta/evidence[:,None]
    weights=W_H*evidence**2
    z=float(weights.sum())
    mean=weights@conditional/z
    assert z>0 and np.all(mean>0) and np.all(np.isfinite(mean))
    return z,mean


def merge(variance: np.ndarray) -> float:
    r"""Return the existing auxiliary parent merge expectation."""
    METRICS['readout_calls']+=1
    gamma=np.einsum('j,hjkl->hkl',variance,GRAMS)
    determinants=np.linalg.det(gamma[:,None,None,:,:]+Q_INV[None,:,:,:,:])
    evidence=(SIGNS[None,None,:]/(Q_DET[None,:,:]*determinants)).sum(axis=2)
    assert np.all(evidence>0)
    joint=W_H@(evidence**2)
    value=float((joint[1]+joint[2]-joint[3])/joint[0])
    assert 0<value<1
    return value


def rhs(t: float, log_state: np.ndarray) -> np.ndarray:
    r"""Native log-variance ODE: xdot=E_j/(d_j a_j)-1, ydot=1-r_j/a_j."""
    METRICS['rhs_calls']+=1
    state=np.exp(log_state)
    model,recognition=state[:3],state[3:]
    _,energy=moments(recognition)
    return np.concatenate((energy/(DIMENSIONS*model)-1,1-recognition/model))


def crossing(t: float, log_state: np.ndarray) -> float:
    return merge(np.exp(log_state[3:]))-.5


def main() -> None:
    start=time.perf_counter()
    z,energy=moments(np.ones(3))
    reference=np.array([float(Fraction(x)) for x in pair['posterior_M_energy_coordinates']])*DIMENSIONS
    assert abs(z/float(Fraction(pair['evidence']))-1)<1e-10
    assert np.max(np.abs(energy-reference))<1e-10
    previous=folder.parent/'second-level-learning/second-level-response.json'
    old=json.loads(previous.read_text(encoding='utf-8'))
    assert abs(merge(np.ones(3))-float(Fraction(old['merge_probability'])))<1e-10
    initial_rhs=rhs(0.,np.zeros(6))
    assert np.all(initial_rhs[:3]<0) and np.array_equal(initial_rhs[3:],np.zeros(3))
    solution=solve_ivp(rhs,(0.,20.),np.zeros(6),method='DOP853',rtol=1e-9,atol=1e-11,max_step=.1,dense_output=True,events=crossing)
    assert solution.success and solution.t[-1]==20.
    rows=[]
    for t in (0.,1.,2.,4.,8.,12.,20.):
        log_state=solution.sol(t)
        variance=np.exp(log_state)
        rows.append({'native_time':t,'model_variances':variance[:3].tolist(),'recognition_variances':variance[3:].tolist(),'merge_probability':merge(variance[3:]),'log_velocity':rhs(t,log_state).tolist()})
    events=[{'native_time':float(t),'log_state':state.tolist(),'variances':np.exp(state).tolist(),'merge_probability':merge(np.exp(state[3:]))} for t,state in zip(solution.t_events[0],solution.y_events[0])]
    segments=[{'t_old':float(segment.t_old),'t':float(segment.t),'h':float(segment.h),'y_old':segment.y_old.tolist(),'F':segment.F.tolist()} for segment in solution.sol.interpolants]
    dense_source=inspect.getsource(type(solution.sol.interpolants[0])._call_impl)
    result={'status':'NUMERICAL_DIAGNOSTIC_COMPLETED','runtime':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':sha256(source.read_bytes()).hexdigest(),'helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),'matrix_helper_sha256':sha256(g.HELPER.read_bytes()).hexdigest(),'previous_response_sha256':sha256(previous.read_bytes()).hexdigest(),
    'scope':'The pi_P=1 boundary reference, all four shared P decorations, unit model and exact-posterior preparation, s=1. This boundary run does not itself verify a positive full-prior family or an ODE enclosure.',
    'state_order':['log_model_a','log_model_b','log_model_c','log_recognition_a','log_recognition_b','log_recognition_c'],'native_interval':[0.,20.],'solver':{'method':'DOP853','rtol':1e-9,'atol':1e-11,'max_step':.1,'success':bool(solution.success),'message':solution.message,'nfev':solution.nfev,'accepted_steps':len(solution.t)-1},'initial_log_velocity':initial_rhs.tolist(),'readouts':rows,'detected_half_merge_events':events,'accepted_times':solution.t.tolist(),'accepted_log_states':solution.y.T.tolist(),'dense_segments':segments,'dense_evaluation_source':dense_source,'dense_evaluation_source_sha256':sha256(dense_source.encode()).hexdigest(),'evaluation_metrics':METRICS,'elapsed_seconds':time.perf_counter()-start,
    'not_proved':['Rigorous numerical error enclosure','Continuous-time crossing or no-crossing','Native entry for positive full ancestry priors','Long-time limit','Complete resource licensing'],
    'not_run':['positive-prior parameter search','fitting','new data','sampling','GPU','test suite','Lean','tamper checks','earlier scientific mains']}
    (folder/'pilot-trajectory.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'solver':result['solver'],'readouts':rows,'detected_half_merge_events':events,'evaluation_metrics':METRICS,'elapsed_seconds':result['elapsed_seconds']},indent=2))


if __name__=='__main__':
    main()
