"""One numerical stationary-equation probe seeded by the saved native endpoint."""
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time
import numpy as np
import scipy
from scipy.optimize import root

folder=Path(__file__).parent
helper_path=folder/'pilot_native.py'
spec=importlib.util.spec_from_file_location('native_definitions',helper_path)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)


def equations(log_variance: np.ndarray) -> np.ndarray:
    variance=np.exp(log_variance)
    _,energy=g.moments(variance)
    return energy/(g.DIMENSIONS*variance)-1


def main() -> None:
    start=time.perf_counter()
    source=folder/'pilot-trajectory.json'
    pilot=json.loads(source.read_text(encoding='utf-8'))
    initial=np.log(np.array(pilot['readouts'][-1]['model_variances']))
    solution=root(equations,initial,method='hybr',options={'xtol':1e-10,'maxfev':150})
    variance=np.exp(solution.x)
    residual=equations(solution.x)
    # A declared finite-difference Jacobian is diagnostic, not interval evidence.
    step=1e-5
    jac=np.column_stack([(equations(solution.x+step*np.eye(3)[j])-equations(solution.x-step*np.eye(3)[j]))/(2*step) for j in range(3)])
    missing=jac+np.eye(3)
    native=np.block([[-np.eye(3),missing],[np.eye(3),-np.eye(3)]])
    result={'status':'NUMERICAL_STATIONARITY_PROBE_COMPLETED','runtime':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),'input_sha256':sha256(source.read_bytes()).hexdigest(),
    'scope':'Stationary equations of the fixed-P native family, seeded only from the single saved t=20 model endpoint. No ancestry prior or observation is changed.',
    'solver_success':bool(solution.success),'solver_message':str(solution.message),'solver_nfev':solution.nfev,'candidate_log_variances':solution.x.tolist(),'candidate_variances':variance.tolist(),'normalized_stationarity_residual':residual.tolist(),'residual_max_abs':float(np.max(np.abs(residual))),'merge_probability':g.merge(variance),'diagnostic_jacobian_step':step,'equation_jacobian':jac.tolist(),'native_linearization_eigenvalues':[[float(v.real),float(v.imag)] for v in np.linalg.eigvals(native)],'interior_guard_min_variance':1e-8,'candidate_above_interior_guard':bool(np.min(variance)>1e-8),'elapsed_seconds':time.perf_counter()-start,
    'not_proved':['Existence or uniqueness of an exact stationary point','Certified local stability','Attraction from the original preparation','Long-time limit or a positive-prior native crossing'],
    'not_run':['Native trajectory extension','multiple root seeds','parameter grid','new data','sampling','GPU','suite','Lean','tamper checks','earlier scientific mains']}
    (folder/'stationarity-probe.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','solver_success','solver_message','solver_nfev','candidate_variances','residual_max_abs','merge_probability','native_linearization_eigenvalues','candidate_above_interior_guard','elapsed_seconds')},indent=2))


if __name__=='__main__':
    main()
