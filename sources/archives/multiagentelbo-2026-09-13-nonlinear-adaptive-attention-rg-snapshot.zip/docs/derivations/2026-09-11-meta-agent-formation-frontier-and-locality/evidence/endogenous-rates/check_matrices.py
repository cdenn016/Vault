"""Exact small matrices for the common-mobility angular construction."""

import json
from pathlib import Path

import sympy as sp


def calculate(include_second_cut: bool) -> dict:
    """Compute B_f B_f^T and the inherited cut mobility exactly."""
    edges = [(0, 1), (1, 2)]
    if include_second_cut:
        edges.append((0, 2))
    n_edges = len(edges)
    dimension = 6 + 2 * n_edges
    rows = []
    for i in range(3):
        row = [0] * dimension
        row[i], row[3 + i] = 1, -1
        rows.append(row)
    edge_rows = {}
    for channel in range(2):
        for edge, (i, j) in enumerate(edges):
            row = [0] * dimension
            row[3 * channel + i] = 1
            row[3 * channel + j] = -1
            row[6 + channel * n_edges + edge] = -1
            edge_rows[channel, edge] = row
    rows.extend([edge_rows[0, 0], edge_rows[1, 0]])
    fast = sp.Matrix(rows)
    slow = sp.Matrix([edge_rows[c, e] for c in range(2) for e in range(1, n_edges)])
    c_ff = fast * fast.T
    right_inverse = fast.T * c_ff.inv()
    projection = sp.eye(dimension) - right_inverse * fast
    mobility = slow * projection * slow.T
    assert fast * right_inverse == sp.eye(5)
    assert projection * projection == projection
    assert projection.T == projection
    assert fast * projection == sp.zeros(5, dimension)
    assert mobility.det() > 0
    convert = lambda matrix: [[str(x) for x in row] for row in matrix.tolist()]
    return {
        "angular_dimension": dimension,
        "full_residual_rank": fast.col_join(slow).rank(),
        "fast_gram": convert(c_ff),
        "fast_gram_eigenvalues": {str(k): v for k, v in c_ff.eigenvals().items()},
        "cut_mobility": convert(mobility),
        "cut_mobility_eigenvalues": {str(k): v for k, v in mobility.eigenvals().items()},
        "cut_gram_eigenvalues": {str(k): v for k, v in (slow * slow.T).eigenvals().items()},
        "projection_identities": "exact",
    }


if __name__ == "__main__":
    result = {"path": calculate(False), "triangle": calculate(True)}
    output = Path(__file__).with_name("matrix-results.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(output)
    print(json.dumps(result, indent=2))
