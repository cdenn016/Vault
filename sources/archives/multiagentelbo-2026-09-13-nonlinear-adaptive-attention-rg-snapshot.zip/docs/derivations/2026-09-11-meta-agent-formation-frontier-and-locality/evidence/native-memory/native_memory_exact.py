"""Exact Gaussian score and native-memory response identities.

The calculation checks one specified stationary point. It does not integrate
a trajectory or establish a nonlinear hierarchy.
"""
from __future__ import annotations

from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import datetime
import hashlib
import json
import math
import platform
import sys
import time
import traceback

Matrix = list[list[F]]
Poly = dict[tuple[int, int], F]
BASE = Path(__file__).resolve().parent
DOC = BASE.parent.parent / "native-memory-and-local-parent-reduction.md"


def eye(n: int) -> Matrix:
    return [[F(i == j) for j in range(n)] for i in range(n)]


def transpose(a: Matrix) -> Matrix:
    return [list(row) for row in zip(*a)]


def matmul(a: Matrix, b: Matrix) -> Matrix:
    return [[sum((x * y for x, y in zip(row, col)), F(0))
             for col in zip(*b)] for row in a]


def rank(a: Matrix) -> int:
    rows = [row[:] for row in a]
    pivot = 0
    for col in range(len(rows[0])):
        at = next((i for i in range(pivot, len(rows)) if rows[i][col]), None)
        if at is None:
            continue
        rows[pivot], rows[at] = rows[at], rows[pivot]
        scale = rows[pivot][col]
        rows[pivot] = [x / scale for x in rows[pivot]]
        for i in range(len(rows)):
            if i != pivot:
                factor = rows[i][col]
                rows[i] = [x - factor * y for x, y in zip(rows[i], rows[pivot])]
        pivot += 1
        if pivot == len(rows):
            break
    return pivot


def charpoly(a: Matrix) -> list[F]:
    """Return coefficients of det(lambda I - A), highest degree first."""
    n = len(a)
    b = eye(n)
    out = [F(1)]
    for k in range(1, n + 1):
        ab = matmul(a, b)
        c = -sum((ab[i][i] for i in range(n)), F(0)) / k
        out.append(c)
        b = [[ab[i][j] + (c if i == j else 0) for j in range(n)]
             for i in range(n)]
    assert all(value == 0 for row in b for value in row)
    return out


def polymul(a: list[F], b: list[F]) -> list[F]:
    out = [F(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return out


def polyprod(a: Poly, b: Poly) -> Poly:
    out: Poly = {}
    for (i, j), x in a.items():
        for (k, ell), y in b.items():
            key = (i + k, j + ell)
            out[key] = out.get(key, F(0)) + x * y
    return out


def jsonable(value: object) -> object:
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    return value


def calculate() -> dict[str, object]:
    theta, obs = F(1, 2), F(3, 2)
    s = 2 + theta * theta
    mu = [theta * obs / s, (1 + theta * theta) * obs / s]
    cov = [[2 / s, theta / s],
           [theta / s, (1 + theta * theta) / s]]
    assert mu == [F(1, 3), F(5, 6)]
    assert cov == [[F(8, 9), F(2, 9)], [F(2, 9), F(5, 9)]]
    prior_precision = [[1 + theta * theta, -theta], [-theta, F(1)]]
    post_precision = [[prior_precision[0][0], prior_precision[0][1]],
                      [prior_precision[1][0], F(2)]]
    assert matmul(post_precision, cov) == eye(2)
    assert matmul(post_precision, [[x] for x in mu]) == [[F(0)], [obs]]

    @lru_cache(None)
    def moment(a: int, b: int) -> F:
        r"""Gaussian integration by parts for E[x_1^a x_2^b]."""
        if a == b == 0:
            return F(1)
        if a:
            out = mu[0] * moment(a - 1, b)
            if a > 1:
                out += (a - 1) * cov[0][0] * moment(a - 2, b)
            if b:
                out += b * cov[0][1] * moment(a - 1, b - 1)
            return out
        out = mu[1] * moment(0, b - 1)
        if b > 1:
            out += (b - 1) * cov[1][1] * moment(0, b - 2)
        return out

    def expectation(p: Poly) -> F:
        return sum((c * moment(i, j) for (i, j), c in p.items()), F(0))

    basis = [(1, 0), (0, 1), (2, 0), (1, 1), (0, 2)]
    gram = [[moment(i + k, j + ell) - moment(i, j) * moment(k, ell)
             for k, ell in basis] for i, j in basis]
    score: Poly = {(1, 1): F(1), (2, 0): -theta}
    score_y: Poly = {(0, 2): F(8, 25), (0, 0): F(-2, 5)}
    score_h = score.copy()
    for key, val in score_y.items():
        score_h[key] = score_h.get(key, F(0)) - val
    assert expectation(score) == expectation(score_y) == expectation(score_h) == 0
    information = expectation(polyprod(score, score))
    information_y = expectation(polyprod(score_y, score_y))
    information_h = expectation(polyprod(score_h, score_h))
    assert (information, information_y, information_h) == (
        F(73, 81), F(448, 2025), F(17, 25))
    assert expectation(polyprod(score_h, score_y)) == 0
    assert information_y + information_h == information
    assert moment(2, 0) == 1

    # Independent conditional calculation from epsilon independent of y.
    conditional_check = F(9, 25) * moment(0, 2) * F(4, 5) + F(1, 2) * F(4, 5)**2
    assert conditional_check == information_h

    evidence_gradient = theta / s - theta * obs**2 / s**2
    a = 2 * theta**2 / s**2
    assert evidence_gradient == 0 and a == F(8, 81)
    assert a + information == moment(2, 0) == 1
    generative_fisher = F(1)  # E[x_1^2] under the normalized prior.
    assert theta * moment(2, 0) - moment(1, 1) == 0

    score_coeff = [F(0), F(0), -theta, F(1), F(0)]
    fine: Matrix = [[F(-1 if i == j else 0) for j in range(5)] + [score_coeff[i]]
                    for i in range(5)]
    # Explicit covariance of the centered posterior score with each basis.
    force_row = [expectation(polyprod(score, {power: F(1)})) for power in basis]
    fine.append(force_row + [-(a + information)])
    assert fine[0][0] == -1 and fine[0][1] == 0

    cy: Matrix = [[F(2, 5), F(1), F(0), F(0), F(0)],
                  [F(0), F(0), F(4, 25), F(2, 5), F(1)]]
    hidden_row = [expectation(polyprod(score_h, {power: F(1)})) for power in basis]
    retention: Matrix = [cy[0] + [F(0)], cy[1] + [F(0)],
                         [F(0)] * 5 + [F(1)], hidden_row + [F(0)]]
    assert rank(retention) == 4

    # Conditional means of each monomial verify C_y without covariance fitting.
    regression, conditional_var = F(2, 5), F(4, 5)
    conditional_raw: list[Poly] = [
        {(0, 1): regression}, {(0, 1): F(1)},
        {(0, 2): regression**2, (0, 0): conditional_var},
        {(0, 2): regression}, {(0, 2): F(1)}]
    assert [p.get((0, 1), F(0)) for p in conditional_raw] == cy[0]
    assert [p.get((0, 2), F(0)) for p in conditional_raw] == cy[1]
    for power, p in zip(basis, conditional_raw):
        assert expectation(p) == moment(*power)

    retained_force = [expectation(polyprod(score_y, {power: F(1)}))
                      for power in [(0, 1), (0, 2)]]
    coarse: Matrix = [[F(-1), F(0), F(0), F(0)],
                      [F(0), F(-1), F(8, 25), F(0)],
                      retained_force + [-(a + information), F(1)],
                      [F(0), F(0), information_h, F(-1)]]
    assert matmul(retention, fine) == matmul(coarse, retention)
    # A common y-only Gaussian sensor has first-variation mean/covariance
    # determined by the first two retained score coordinates.
    output: Matrix = [[moment(0, 2) - moment(0, 1)**2,
                       moment(0, 3) - moment(0, 1)*moment(0, 2), F(0), F(0)]]
    assert rank(matmul(output, retention)) == 1

    pair_poly = [F(1), F(2), a]
    expected_fine = pair_poly[:]
    expected_coarse = pair_poly[:]
    for _ in range(4):
        expected_fine = polymul(expected_fine, [F(1), F(1)])
    for _ in range(2):
        expected_coarse = polymul(expected_coarse, [F(1), F(1)])
    assert charpoly(fine) == expected_fine
    assert charpoly(coarse) == expected_coarse

    constrained_metric = generative_fisher + information_h
    constrained: Matrix = [[F(-1), F(0), F(0)],
                           [F(0), F(-1), F(8, 25)],
                           [v/constrained_metric for v in retained_force] +
                           [-(a + information_y)/constrained_metric]]
    constrained_pair = [F(1), F(2)/constrained_metric, a/constrained_metric]
    assert constrained_metric == F(42, 25)
    assert a + information_y + constrained_metric == 2
    assert charpoly(constrained) == polymul(constrained_pair, [F(1), F(1)])
    assert constrained_pair != pair_poly

    # Scalar delayed structural mobility at several exact Laplace arguments.
    frequencies = [F(0), F(1), F(3)]
    response_metrics = [generative_fisher + information_h/(lam + 1)
                        for lam in frequencies]
    assert response_metrics == [F(42, 25), F(67, 50), F(117, 100)]
    # Nested elimination adds the same-pole memories without matrix products.
    first = [[F(1), F(0)], [F(0), F(0)]]
    second = [[F(1), F(1)], [F(1), F(1)]]
    total = [[first[i][j] + second[i][j] for j in range(2)] for i in range(2)]
    assert rank(first) == rank(second) == 1 and rank(total) == 2
    for lam in frequencies:
        direct = [[v/(lam + 1) for v in row] for row in total]
        staged = [[first[i][j]/(lam+1) + second[i][j]/(lam+1)
                   for j in range(2)] for i in range(2)]
        assert direct == staged

    return {
        "status": "passed",
        "model": "same scalar Gaussian structural-link model; o=3/2, theta=1/2",
        "posterior_mean": mu,
        "posterior_covariance": cov,
        "evidence_gradient": evidence_gradient,
        "evidence_hessian": a,
        "generative_fisher": generative_fisher,
        "posterior_information": information,
        "retained_information": information_y,
        "hidden_information": information_h,
        "independent_conditional_information": conditional_check,
        "fine_jacobian": fine,
        "retention": retention,
        "retention_rank": rank(retention),
        "coarse_jacobian": coarse,
        "intertwining": True,
        "fine_characteristic_polynomial": charpoly(fine),
        "coarse_characteristic_polynomial": charpoly(coarse),
        "constrained_characteristic_polynomial": charpoly(constrained),
        "frequency_metrics": list(zip(frequencies, response_metrics)),
        "native_rate_approximations": [1-math.sqrt(73)/9, 1+math.sqrt(73)/9],
        "first_variation_evolving_counts": {"fine": 6, "retained_with_memory": 4},
        "sensor_mean": mu[1],
        "sensor_variance": cov[1][1] + 1,
        "scope": "exact rational first-variation identities; no nonlinear trajectory",
    }


def main() -> None:
    started = time.perf_counter()
    try:
        result = calculate()
    except Exception:
        result = {"status": "failed", "traceback": traceback.format_exc()}
        (BASE / "result.json").write_text(json.dumps(result, indent=2) + "\n")
        raise
    result.update({
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "elapsed_seconds": time.perf_counter() - started,
        "document_sha256": hashlib.sha256(DOC.read_bytes()).hexdigest(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "nonlinear_trajectory_integrated": False,
        "formal_verification_certificate": False,
    })
    (BASE / "result.json").write_text(json.dumps(jsonable(result), indent=2) + "\n")
    print(json.dumps(jsonable({k: result[k] for k in (
        "status", "evidence_hessian", "posterior_information", "hidden_information",
        "retention_rank", "intertwining", "first_variation_evolving_counts",
        "native_rate_approximations", "elapsed_seconds")})))


if __name__ == "__main__":
    main()

