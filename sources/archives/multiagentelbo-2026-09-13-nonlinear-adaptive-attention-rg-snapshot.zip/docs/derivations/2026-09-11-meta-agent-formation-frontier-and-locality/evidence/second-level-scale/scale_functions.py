"""Exact common-scale parent agreement; no fitted point or native trajectory."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform
import sys
import time
import sympy as sp
from sympy.polys.fields import field

sys.set_int_max_str_digits(200000)
folder=Path(__file__).parent
helper_path=folder.parent/'transported-parent-prior/boundary_exact.py'
spec=importlib.util.spec_from_file_location('existing_polynomial_definitions',helper_path)
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
h=g.h
K,tau=field('tau',sp.QQ)
T=[[F(1,2),F(1),F(1,2),F(0)],[F(1,2),F(0),F(1,2),F(1)]]


def encode(poly: object) -> list[str]:
    values=poly.to_dict()
    return [str(values.get((i,),0)) for i in range(poly.degree()+1)]


def evaluate(value: object, at: int = 1) -> F:
    return F(str(value.numer.evaluate(0,at)))/F(str(value.denom.evaluate(0,at)))


def pack(value: object) -> dict:
    return {'numerator':encode(value.numer),'denominator':encode(value.denom),'degrees':[value.numer.degree(),value.denom.degree()]}


def variations(values: list[str]) -> int:
    signs=[(F(v)>0)-(F(v)<0) for v in values if F(v)]
    return sum(a!=b for a,b in zip(signs,signs[1:]))


def main() -> None:
    start=time.perf_counter()
    source=folder.parent/'transported-parent-prior/result.json'
    previous=folder.parent/'second-level-learning/second-level-response.json'
    data=json.loads(source.read_text())
    old=json.loads(previous.read_text())
    pair=next(row for row in data['rows'] if row['partition']==[[0,1],[2,3]])
    functions={}
    totals=[K(0) for _ in range(4)]
    for dec in pair['details']:
        gamma=[[F(x) for x in row] for row in dec['Gamma']]
        gamma_key=tuple(tuple(row) for row in gamma)
        for mask in range(4):
            key=(gamma_key,mask)
            if key not in functions:
                integral=K(0)
                series=[F(0)]*7
                determinants=[]
                for bits in product((0,1),repeat=4):
                    q=[[F(g.g.N[i]+bits[i]) if i==j else F(0) for j in range(4)] for i in range(4)]
                    for edge in range(2):
                        if mask & (1<<edge):
                            q=[[q[i][j]+T[edge][i]*T[edge][j] for j in range(4)] for i in range(4)]
                    coefficients=g.determinant_polynomial(h.eye(4),h.multiply(gamma,q))
                    assert coefficients[0]==1 and min(coefficients)>0
                    polynomial=sum((K(sp.QQ(v.numerator,v.denominator))*tau**i for i,v in enumerate(coefficients)),K(0))
                    sign=(-1)**sum(bits)
                    integral+=K(sign)/polynomial
                    series=[x+sign*y for x,y in zip(series,g.reciprocal_series(coefficients,6))]
                    determinants.append([str(v) for v in coefficients])
                assert series[:4]==[0]*4 and series[4]==g.permanent(gamma)>0
                functions[key]=(integral,series,determinants)
                print('function',len(functions),'mask',mask,'degrees',integral.numer.degree(),integral.denom.degree(),flush=True)
            integral,series,determinants=functions[key]
            totals[mask]+=integral**2/len(pair['details'])
    assert evaluate(totals[0])==F(pair['evidence'])
    merged=totals[1]+totals[2]-totals[3]
    comparison=merged-totals[0]/2
    print('comparison degrees',comparison.numer.degree(),comparison.denom.degree(),flush=True)
    comparison_pack=pack(comparison)
    assert evaluate(merged)/evaluate(totals[0])==F(old['merge_probability'])
    # Do not repeat a large rational cancellation merely to divide by the evidence.
    small_coefficients=[F(0)]*3
    base_coefficient=F(0)
    for dec in pair['details']:
        key=tuple(tuple(F(x) for x in row) for row in dec['Gamma'])
        squared=[]
        for mask in range(4):
            v=functions[(key,mask)][1]
            squared.append([sum((v[i]*v[j] for i in range(7) for j in range(7) if i+j==degree),F(0)) for degree in range(8,11)])
        base_coefficient+=squared[0][0]/len(pair['details'])
        for power in range(3):
            small_coefficients[power]+=sum(sign*squared[mask][power] for mask,sign in enumerate((1,-1,-1,1)))/len(pair['details'])
    assert small_coefficients[:2]==[0,0] and small_coefficients[2]>0
    bounds=[]
    for row in data['rows']:
        coefficient=F(0)
        ceiling=F(0)
        for dec in row['details']:
            gamma=[[F(x) for x in rr] for rr in dec['Gamma']]
            permanent=g.permanent(gamma)
            diagonal_product=F(1)
            for i in range(4):
                diagonal_product*=gamma[i][i]
            upper=24*diagonal_product
            assert 0<permanent<=upper
            coefficient+=permanent**2/len(row['details'])
            ceiling+=upper**2/len(row['details'])
        bounds.append({'partition':row['partition'],'k':row['k'],'common_scale_evidence_leading_coefficient':str(coefficient),'simultaneous_variance_collapse_evidence_upper_coefficient':str(ceiling),'unit_evidence':row['evidence']})
    uniform_floor_power=min(F(row['unit_evidence']) for row in bounds)/max(F(row['simultaneous_variance_collapse_evidence_upper_coefficient']) for row in bounds)
    result={'status':'PASS','runtime':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'polynomial_helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),'gaussian_helper_sha256':sha256(g.source.read_bytes()).hexdigest(),'matrix_helper_sha256':sha256(g.g.HELPER.read_bytes()).hexdigest(),'input_sha256':sha256(source.read_bytes()).hexdigest(),'previous_response_sha256':sha256(previous.read_bytes()).hexdigest(),
    'scope':'All tau>0 on the static matched-posterior subfamily a=b=c=tau, v=1, all four pair decorations; the coupled native flow does not preserve this ray. All twelve full-prior coefficients retained for the native collapse bound.',
    'coefficient_order':'ascending','functions':[{'gamma':[[str(v) for v in line] for line in key[0]],'mask':key[1],**pack(value),'series_through_six':[str(v) for v in series],'positive_determinants':determinants} for key,(value,series,determinants) in functions.items()],
    'pair_evidence':pack(totals[0]),'merge_numerator':pack(merged),'half_merge_comparison':comparison_pack,'comparison_numerator_sign_variations':variations(comparison_pack['numerator']),'comparison_denominator_sign_variations':variations(comparison_pack['denominator']),
    'unit_merge_probability':old['merge_probability'],'small_scale_pair_evidence_coefficient':str(base_coefficient),'small_scale_split_numerator_coefficients_orders_eight_to_ten':[str(x) for x in small_coefficients],'small_scale_split_probability_quadratic_coefficient':str(small_coefficients[2]/base_coefficient),
    'all_ancestry_boundary_coefficients':bounds,'native_uniform_max_variance_floor_eighth_power':str(uniform_floor_power),'native_uniform_max_variance_floor_float':float(uniform_floor_power)**(1/8),'elapsed_seconds':time.perf_counter()-start,
    'not_run':['numerical ancestry prior','parameter point search','fit','ODE','new data','sampling','GPU','test suite','Lean','tamper checks','previous scientific mains']}
    (folder/'scale-functions.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','comparison_numerator_sign_variations','comparison_denominator_sign_variations','small_scale_pair_evidence_coefficient','small_scale_split_probability_quadratic_coefficient','native_uniform_max_variance_floor_float','elapsed_seconds')},indent=2),flush=True)


if __name__=='__main__':
    main()
