"""Exact native evidence-barrier constants from saved ancestry coefficients."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys
import time

sys.set_int_max_str_digits(200000)
folder=Path(__file__).parent


def main() -> None:
    start=time.perf_counter()
    source=folder/'scale-functions.json'
    classification=folder/'scale-classification.json'
    data=json.loads(source.read_text())
    classified=json.loads(classification.read_text())
    rows=[]
    for row in data['all_ancestry_boundary_coefficients']:
        leading=F(row['common_scale_evidence_leading_coefficient'])
        coarse=F(row['simultaneous_variance_collapse_evidence_upper_coefficient'])
        evidence=F(row['unit_evidence'])
        assert 0<leading<=coarse and evidence>0
        rows.append({'partition':row['partition'],'leading_coefficient':str(leading),'unit_evidence':str(evidence),'unit_evidence_to_leading_ratio':str(evidence/leading)})
    minimum=min(F(row['unit_evidence_to_leading_ratio']) for row in rows)
    previous=F(data['native_uniform_max_variance_floor_eighth_power'])
    assert minimum>previous
    alpha_low=F(classified['pair_evidence_lower_crossing_interval'][0])
    assert minimum<alpha_low**8
    likelihood_supremum=(F(8**8,9**9)**2*F(1,4)**2)**2
    assert all(F(row['unit_evidence'])<likelihood_supremum for row in rows)
    witnesses=[row['partition'] for row in rows if F(row['unit_evidence_to_leading_ratio'])==minimum]
    result={'status':'PASS','runtime':sys.executable,'python':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'scale_source_sha256':sha256(source.read_bytes()).hexdigest(),'classification_source_sha256':sha256(classification.read_bytes()).hexdigest(),
    'scope':'Scalar exact bounds for the full native model with any fixed positive ancestry prior, initially at unit model and exact posterior. Loewner/permanent monotonicity and ELBO dissipation are proved in the linked derivation.',
    'rows':rows,'uniform_model_max_variance_floor_eighth_power':str(minimum),'uniform_model_max_variance_floor_float':float(minimum)**(1/8),'minimum_ratio_ancestries':witnesses,'previous_diagonal_bound_floor_float':float(previous)**(1/8),'sharp_floor_below_evidence_lower_crossing':True,'ordered_batch_likelihood_supremum':str(likelihood_supremum),'ordered_batch_likelihood_supremum_float':float(likelihood_supremum),'elapsed_seconds':time.perf_counter()-start,
    'not_run':['Gaussian matrix integrals','numerical ancestry prior','parameter point search','fit','ODE','new data','sampling','GPU','test suite','Lean','tamper checks','previous scientific mains']}
    (folder/'native-barrier.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','uniform_model_max_variance_floor_float','minimum_ratio_ancestries','sharp_floor_below_evidence_lower_crossing','ordered_batch_likelihood_supremum_float','elapsed_seconds')},indent=2))


if __name__=='__main__':
    main()
