"""Exact positive-axis classification of saved scale functions; no new integrals."""
from fractions import Fraction as F
from hashlib import sha256
import json
from math import gcd,lcm
from pathlib import Path
import platform
import sys
import time

sys.set_int_max_str_digits(200000)
folder=Path(__file__).parent


def integers(values: list[str]) -> list[int]:
    coefficients=list(map(F,values))
    denominator=lcm(*(x.denominator for x in coefficients))
    output=[x.numerator*(denominator//x.denominator) for x in coefficients]
    common=gcd(*output)
    return [x//common for x in output]


def variations(values: list[int]) -> int:
    signs=[(x>0)-(x<0) for x in values if x]
    return sum(a!=b for a,b in zip(signs,signs[1:]))


def polynomial_sign(coefficients: list[int], x: F) -> int:
    numerator,denominator=x.numerator,x.denominator
    result=coefficients[-1]
    power=1
    for coefficient in reversed(coefficients[:-1]):
        power*=denominator
        result=result*numerator+coefficient*power
    return (result>0)-(result<0)


def isolate(coefficients: list[int]) -> tuple[F,F]:
    left,right=F(0),F(1)
    assert polynomial_sign(coefficients,left)>0 and polynomial_sign(coefficients,right)<0
    for _ in range(42):
        middle=(left+right)/2
        sign=polynomial_sign(coefficients,middle)
        assert sign!=0  # A rational exact zero would be recorded as a different isolation outcome.
        if sign>0:
            left=middle
        else:
            right=middle
    assert polynomial_sign(coefficients,left)>0 and polynomial_sign(coefficients,right)<0
    return left,right


def limit_leading(numerator: dict, denominator: dict) -> F:
    delta_n=len(numerator['numerator'])-len(numerator['denominator'])
    delta_d=len(denominator['numerator'])-len(denominator['denominator'])
    assert delta_n==delta_d
    return (F(numerator['numerator'][-1])/F(numerator['denominator'][-1]))/(F(denominator['numerator'][-1])/F(denominator['denominator'][-1]))


def main() -> None:
    start=time.perf_counter()
    source=folder/'scale-functions.json'
    data=json.loads(source.read_text())
    merge_comparison=integers(data['half_merge_comparison']['numerator'])
    while merge_comparison[0]==0:
        merge_comparison.pop(0)
    assert variations(merge_comparison)==1 and merge_comparison[0]>0 and merge_comparison[-1]<0
    assert all(F(x)>0 for x in data['half_merge_comparison']['denominator'])
    merge_interval=isolate(merge_comparison)
    evidence=data['pair_evidence']
    numerator=list(map(F,evidence['numerator']))
    denominator=list(map(F,evidence['denominator']))
    unit=sum(numerator)/sum(denominator)
    size=max(len(numerator),len(denominator))
    difference=[(numerator[i] if i<len(numerator) else 0)-unit*(denominator[i] if i<len(denominator) else 0) for i in range(size)]
    comparison=integers([str(x) for x in difference])
    assert sum(comparison)==0
    quotient=[0]*(len(comparison)-1)
    quotient[-1]=comparison[-1]
    for i in range(len(quotient)-1,0,-1):
        quotient[i-1]=comparison[i]+quotient[i]
    assert comparison[0]+quotient[0]==0
    common=gcd(*quotient)
    quotient=[x//common for x in quotient]
    assert variations(quotient)==1 and quotient[0]>0 and quotient[-1]<0
    evidence_interval=isolate(quotient)
    assert evidence_interval[1]<merge_interval[0]<merge_interval[1]<1
    large_merge=limit_leading(data['merge_numerator'],data['pair_evidence'])
    assert 0<large_merge<F(1,2)
    result={'status':'PASS','runtime':sys.executable,'python':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':sha256(source.read_bytes()).hexdigest(),
    'scope':'All positive common variance tau, pair sector with all four shared decorations. Descartes coefficient signs and exact rational root isolation; no variance point search or native trajectory.',
    'coefficient_order':'ascending','merge_half_polynomial_without_zero_root':[str(x) for x in merge_comparison],'merge_half_polynomial_degree':len(merge_comparison)-1,'merge_half_sign_variations':variations(merge_comparison),'merge_half_root_interval':[str(x) for x in merge_interval],'merge_half_root_interval_float':[float(x) for x in merge_interval],
    'pair_evidence_unit':str(unit),'pair_evidence_minus_unit_quotient_by_tau_minus_one':[str(x) for x in quotient],'pair_evidence_quotient_degree':len(quotient)-1,'pair_evidence_quotient_sign_variations':variations(quotient),'pair_evidence_lower_crossing_interval':[str(x) for x in evidence_interval],'pair_evidence_lower_crossing_interval_float':[float(x) for x in evidence_interval],
    'root_order_proved':'0 < evidence_lower_crossing < merge_half_crossing < 1','merge_above_half_interval':'0 < tau < merge_half_crossing','pair_evidence_above_unit_interval':'evidence_lower_crossing < tau < 1','simultaneous_strict_interval':'evidence_lower_crossing < tau < merge_half_crossing','large_scale_merge_limit':str(large_merge),'large_scale_merge_limit_float':float(large_merge),'elapsed_seconds':time.perf_counter()-start,
    'not_run':['new Gaussian integrals','numerical ancestry prior','parameter point search','fit','ODE','new data','sampling','GPU','test suite','Lean','tamper checks','previous scientific mains']}
    (folder/'scale-classification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','merge_half_polynomial_degree','merge_half_sign_variations','merge_half_root_interval_float','pair_evidence_quotient_degree','pair_evidence_quotient_sign_variations','pair_evidence_lower_crossing_interval_float','large_scale_merge_limit_float','elapsed_seconds')},indent=2))


if __name__=='__main__':
    main()
