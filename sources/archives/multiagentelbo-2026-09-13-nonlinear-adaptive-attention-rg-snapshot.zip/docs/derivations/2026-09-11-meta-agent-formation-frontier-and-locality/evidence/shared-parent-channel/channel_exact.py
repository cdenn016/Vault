"""Exact geometry composition and a local new-record obstruction; no sampling."""
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform
import time

N = 44
Row = list[F]

def unit(i: int) -> Row:
    return [F(j == i) for j in range(N)]

def add(a: Row, b: Row, coefficient: F = F(1)) -> Row:
    return [x+coefficient*y for x,y in zip(a,b)]

def scale(a: Row, value: F) -> Row:
    return [value*x for x in a]

def total(rows: list[Row]) -> Row:
    return [sum(column,F(0)) for column in zip(*rows)]

def value(a: Row, x: Row) -> F:
    return sum((u*v for u,v in zip(a,x)),F(0))

def quadratic_gradient(rows: list[Row], x: Row) -> Row:
    return total([scale(row,2*value(row,x)) for row in rows])

def rank(matrix: list[Row]) -> int:
    a = [row[:] for row in matrix]
    pivot = 0
    for column in range(len(a[0])):
        found = next((i for i in range(pivot,len(a)) if a[i][column]),None)
        if found is None:
            continue
        a[pivot],a[found] = a[found],a[pivot]
        divisor = a[pivot][column]
        a[pivot] = [v/divisor for v in a[pivot]]
        for i in range(pivot+1,len(a)):
            if a[i][column]:
                a[i] = add(a[i],a[pivot],-a[i][column])
        pivot += 1
        if pivot == len(a):
            break
    return pivot

def main() -> None:
    start = time.perf_counter()
    # Primitive order epsilon_0..3, xi_01,xi_23, ell_01,ell_12,ell_23,ell_30,Y.
    primitive = [[unit(4*j+d) for d in range(4)] for j in range(11)]
    zero = [F(0)]*N
    mu = [[total([primitive[i][d],primitive[4+i//2][d],primitive[10][d]]) for d in range(4)] for i in range(4)]
    ell = primitive[6:10]
    edges = [(0,1),(1,2),(2,3),(3,0)]
    residual = [[add(add(mu[v][d],mu[u][d],F(-1)),ell[e][d],F(-1)) for d in range(4)] for e,(u,v) in enumerate(edges)]
    first_paths = [[zero for _ in range(4)],ell[0],[zero for _ in range(4)],ell[2]]
    first_means = [[scale(total([add(mu[i][d],first_paths[i][d],F(-1)) for i in block]),F(1,2)) for d in range(4)] for block in ((0,1),(2,3))]
    cut12 = [add(ell[1][d],ell[0][d]) for d in range(4)]
    cut30 = [add(ell[3][d],ell[2][d]) for d in range(4)]
    new_residuals = [[add(add(first_means[1][d],first_means[0][d],F(-1)),cut12[d],F(-1)) for d in range(4)],
                     [add(add(first_means[0][d],first_means[1][d],F(-1)),cut30[d],F(-1)) for d in range(4)]]
    staged_mean = [scale(add(add(first_means[0][d],first_means[1][d]),cut12[d],F(-1)),F(1,2)) for d in range(4)]
    direct_paths = [[zero for _ in range(4)],ell[0],cut12,[add(cut12[d],ell[2][d]) for d in range(4)]]
    direct_mean = [scale(total([add(mu[i][d],direct_paths[i][d],F(-1)) for i in range(4)]),F(1,4)) for d in range(4)]
    staged_loop = [add(cut12[d],cut30[d]) for d in range(4)]
    direct_loop = [total([ell[e][d] for e in range(4)]) for d in range(4)]
    assert staged_mean == direct_mean and staged_loop == direct_loop
    # Translation covariance is a coefficient identity, independently of primitive noises.
    shifts = [[F((i+1)*(d+2),7) for d in range(4)] for i in range(4)]
    for d in range(4):
        edge_shift = [shifts[v][d]-shifts[u][d] for u,v in edges]
        path_shift = [F(0),edge_shift[0],edge_shift[0]+edge_shift[1],sum(edge_shift[:3],F(0))]
        assert sum((shifts[i][d]-path_shift[i] for i in range(4)),F(0))/4 == shifts[0][d]
        assert sum(edge_shift,F(0)) == 0
    x = [F((17*j+3*j*j)%97-48,17) for j in range(N)]
    record_rows = [r[2*c:2*c+2] for r in residual for c in range(2)]
    energies = [[row for item in primitive[a:b] for row in item] for a,b in ((0,4),(4,6),(6,10),(10,11))]
    record_values = [sum((value(row,x)**2 for row in pair),F(0)) for pair in record_rows]
    energy_values = [sum((value(row,x)**2 for row in group),F(0)) for group in energies]
    assert min(record_values+energy_values) > 0
    retained_jacobian = [quadratic_gradient(rows,x) for rows in record_rows+energies]+direct_mean+direct_loop
    new_record_rows = [r[2*c:2*c+2] for r in new_residuals for c in range(2)]
    new_jacobian = [quadratic_gradient(rows,x) for rows in new_record_rows]
    base_rank = rank(retained_jacobian)
    one_rank = rank(retained_jacobian+new_jacobian[:1])
    all_rank = rank(retained_jacobian+new_jacobian)
    first_rank = rank([quadratic_gradient(rows,x) for rows in record_rows+energies]+[row for group in first_means for row in group]+cut12+cut30)
    assert base_rank == 20 and one_rank == 21 and all_rank == 24 and first_rank == 28
    out = {'status':'PASS','scope':'Exact rational coefficient identities and Jacobian ranks at one declared interior point. The level-set argument is written separately.',
           'runtime':platform.python_version(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
           'primitive_order':['epsilon_0','epsilon_1','epsilon_2','epsilon_3','xi_01','xi_23','ell_01','ell_12','ell_23','ell_30','Y'],
           'point':[str(v) for v in x],'record_squared_residuals':[str(v) for v in record_values],
           'noise_energies':[str(v) for v in energy_values],
           'dimensions':{'fine':N,'first_parent':28,'second_parent':20,'second_with_four_new_labels':24},
           'ranks':{'first_parent':first_rank,'second_parent':base_rank,'second_plus_one_new_label':one_rank,'second_plus_four_new_labels':all_rank},
           'retained_jacobian':[[str(v) for v in row] for row in retained_jacobian],
           'new_label_jacobian':[[str(v) for v in row] for row in new_jacobian],
           'direct_staged_mean_coefficients_equal':True,'direct_staged_loop_coefficients_equal':True,
           'new_label_squared_residuals':[str(sum((value(row,x)**2 for row in rows),F(0))) for rows in new_record_rows],
           'elapsed_seconds':time.perf_counter()-start,
           'not_run':['ODE integration','stochastic samples','parameter or partition search','new observation collection','production code','test suite','GPU','Lean','tamper checks','Git publication']}
    Path(__file__).with_name('result.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({key:out[key] for key in ('status','dimensions','ranks','elapsed_seconds')},indent=2))

if __name__ == '__main__':
    main()
