"""Exact parent-generation identities and cost coefficients; no random draws."""
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

folder = Path(__file__).parent
helper_path = folder.parent/'shared-parent-record/shared_parent_exact.py'
spec = importlib.util.spec_from_file_location('existing_record_definitions', helper_path)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)  # Guarded scientific main is not executed.
h = g.helper
Matrix = list[list[F]]
Key = tuple[tuple[F, ...], ...]


def add(a: Matrix, b: Matrix, factor: F = F(1)) -> Matrix:
    return [[x+factor*y for x, y in zip(aa, bb)] for aa, bb in zip(a, b)]


def gram(a: Matrix) -> Matrix:
    return h.multiply(a, h.transpose(a))


def trace(a: Matrix) -> F:
    return sum((a[i][i] for i in range(len(a))), F(0))


def rank(matrix: Matrix) -> int:
    a = [row[:] for row in matrix]
    pivot = 0
    for column in range(len(a[0])):
        found = next((i for i in range(pivot, len(a)) if a[i][column]), None)
        if found is None:
            continue
        a[pivot], a[found] = a[found], a[pivot]
        divisor = a[pivot][column]
        a[pivot] = [v/divisor for v in a[pivot]]
        for i in range(pivot+1, len(a)):
            coefficient = a[i][column]
            if coefficient:
                a[i] = [u-coefficient*v for u, v in zip(a[i], a[pivot])]
        pivot += 1
    return pivot


@lru_cache(maxsize=None)
def residual_matrices(key: Key) -> tuple[Matrix, Matrix, Matrix]:
    r"""Return Gamma inverse, S inverse and the half-envelope residual covariance."""
    gamma = [list(row) for row in key]
    d = [[F(g.N[i], 2) if i == j else F(0) for j in range(4)] for i in range(4)]
    s = [[gamma[i][j]+(F(2, g.N[i]) if i == j else F(0)) for j in range(4)] for i in range(4)]
    inv_gamma = h.inverse(gamma)
    inv_s = h.inverse(s)
    covariance = add(gamma, h.multiply(h.multiply(gamma, inv_s), gamma), F(-1))
    assert covariance == h.inverse(add(inv_gamma, d))
    for n in range(1, 5):
        assert h.determinant([row[:n] for row in covariance[:n]]) > 0
    return inv_gamma, inv_s, covariance


def main() -> None:
    start = time.perf_counter()
    source = folder.parent/'transported-parent-prior/result.json'
    bound_source = folder.parent/'ancestry-screening/positive-envelopes.json'
    data = json.loads(source.read_text(encoding='utf-8'))
    bounds = json.loads(bound_source.read_text(encoding='utf-8'))
    envelope_rows = {tuple(tuple(b) for b in row['partition']): row for row in bounds['rows']}
    rows = []
    geometry_witness = None
    decorated = 0
    for original in data['rows']:
        partition = tuple(tuple(b) for b in original['partition'])
        k = original['k']
        incidence = [[F(original['labels'][i] == j) for j in range(k)] for i in range(4)]
        j_map = h.multiply(g.B, incidence)
        details = []
        for dec in original['details']:
            c_map = [[F(v) for v in row] for row in dec['C']]
            gamma = [[F(v) for v in row] for row in dec['Gamma']]
            inv_gamma, inv_s, residual_cov = residual_matrices(tuple(tuple(row) for row in gamma))
            cotree = [i for i, row in enumerate(c_map) if any(row)]
            assert len(cotree) == k
            d_h = [c_map[i] for i in cotree]
            dd = gram(d_h)
            inv_dd = h.inverse(dd)
            selector = [[F(i == e) for e in cotree] for i in range(4)]
            assert h.multiply(selector, d_h) == c_map
            visible = h.multiply(h.multiply(h.transpose(d_h), inv_dd), d_h)
            hidden = add(h.eye(4), visible, F(-1))
            assert h.multiply(visible, visible) == visible and visible == h.transpose(visible)
            assert rank(visible) == k and rank(hidden) == 4-k
            assert h.multiply(c_map, hidden) == h.mat([[0]*4]*4)
            n_full = 9+k
            n_reduced = 5+2*k
            # Per coordinate: full=(epsilon[4],xi[k],ell[4],Y).
            # Reduced=(epsilon[4],xi[k],V[k],Y), with V=D_H ell.
            projection = [h.eye(n_full)[i] for i in range(4+k)]
            projection += [[F(0)]*(4+k)+line+[F(0)] for line in d_h]
            projection += [h.eye(n_full)[-1]]
            assert len(projection) == n_reduced
            cov_reduced = gram(projection)
            assert h.determinant(cov_reduced) > 0
            a_full = [g.B[i]+j_map[i]+[-v for v in c_map[i]]+[F(0)] for i in range(4)]
            a_reduced = [g.B[i]+j_map[i]+[-v for v in selector[i]]+[F(0)] for i in range(4)]
            assert h.multiply(a_reduced, projection) == a_full
            assert gram(a_full) == gamma
            cross_full = h.transpose(a_full)
            cross_reduced = h.multiply(cov_reduced, h.transpose(a_reduced))
            conditional_full = add(h.eye(n_full), h.multiply(h.multiply(cross_full, inv_gamma), a_full), F(-1))
            conditional_reduced = add(cov_reduced, h.multiply(h.multiply(cross_reduced, inv_gamma), h.transpose(cross_reduced)), F(-1))
            assert h.multiply(h.multiply(projection, conditional_full), h.transpose(projection)) == conditional_reduced
            assert h.multiply(projection, h.multiply(cross_full, inv_gamma)) == h.multiply(cross_reduced, inv_gamma)
            assert rank(conditional_full) == 5+k
            assert rank(conditional_reduced) == 1+2*k
            proposal_full = add(h.eye(n_full), h.multiply(h.multiply(cross_full, inv_s), a_full), F(-1))
            proposal_reduced = add(cov_reduced, h.multiply(h.multiply(cross_reduced, inv_s), h.transpose(cross_reduced)), F(-1))
            assert h.multiply(h.multiply(projection, proposal_full), h.transpose(projection)) == proposal_reduced
            assert h.multiply(h.multiply(a_reduced, proposal_reduced), h.transpose(a_reduced)) == residual_cov
            link_cov = [row[4+k:8+k] for row in proposal_full[4+k:8+k]]
            mark_cov = h.multiply(h.multiply(d_h, link_cov), h.transpose(d_h))
            assert h.multiply(hidden, link_cov) == hidden
            assert h.multiply(h.multiply(d_h, link_cov), hidden) == h.mat([[0]*4 for _ in range(k)])
            energy_matrix = h.multiply(inv_dd, mark_cov)
            hidden_df = 4*(4-k)
            mean_full = 4*trace(link_cov)
            mean_reduced = 4*trace(energy_matrix)+hidden_df
            variance_full = 8*trace(h.multiply(link_cov, link_cov))
            variance_reduced = 8*trace(h.multiply(energy_matrix, energy_matrix))+2*hidden_df
            assert mean_full == mean_reduced and variance_full == variance_reduced
            if partition == ((0,1),(2,3)) and dec['roots'] == [0,2] and dec['trees'] == [[0],[2]]:
                assert cotree == [1,3]
                z_rows = []
                for block_index, block in enumerate(partition):
                    row = [F(i in block, len(block)) for i in range(4)] + [F(j == block_index) for j in range(k)] + [F(0)]*k + [F(1)]
                    z_rows.append(row)
                mark_rows = [h.eye(n_reduced)[4+k+i] for i in range(k)]
                final_z = [(u+v-w)/2 for u, v, w in zip(z_rows[0], z_rows[1], mark_rows[0])]
                final_loop = [u+v for u, v in zip(mark_rows[0], mark_rows[1])]
                second = [final_z, final_loop]
                second_full = h.multiply(second, projection)
                prior_cov = h.multiply(h.multiply(second, cov_reduced), h.transpose(second))
                assert prior_cov == h.mat([[F(9,4),-1],[-1,4]])
                proposal_cov = h.multiply(h.multiply(second, proposal_reduced), h.transpose(second))
                assert proposal_cov == h.multiply(h.multiply(second_full, proposal_full), h.transpose(second_full))
                geometry_witness = {'roots':dec['roots'],'trees':dec['trees'],'prior_second_barycenter_loop_covariance':[[str(v) for v in row] for row in prior_cov],
                                    'proposal_second_barycenter_loop_covariance':[[str(v) for v in row] for row in proposal_cov]}
            details.append({'roots':dec['roots'],'trees':dec['trees'],'cotree':cotree,
                            'visible_link_projection':[[str(v) for v in row] for row in visible],
                            'hidden_link_rank_per_coordinate':4-k,'conditional_full_rank_per_coordinate':5+k,
                            'conditional_reduced_rank_per_coordinate':1+2*k,
                            'link_energy_mean_under_envelope':str(mean_full),'link_energy_variance_under_envelope':str(variance_full)})
            decorated += 1
        envelope = envelope_rows[partition]
        attempt_ratio = F(envelope['mass_upper'])/F(original['evidence'])
        assert 1 < attempt_ratio < 24
        full_normals = 16*attempt_ratio+4*(5+k)
        reduced_normals = 16*attempt_ratio+4*(1+2*k)
        row = {'partition':original['partition'],'k':k,'decorations':len(details),
               'ancestry_envelope_ratio':str(attempt_ratio),'expected_attempts_float':float(attempt_ratio),
               'conditional_full_gaussian_variates_after_acceptance':4*(5+k),
               'conditional_reduced_gaussian_variates_after_acceptance':4*(1+2*k),
               'radial_chi_square_degrees':4*(4-k),'radial_uniform_and_log_count':2*(4-k),
               'full_expected_gaussian_variates_coefficient':str(full_normals),
               'reduced_expected_gaussian_variates_coefficient':str(reduced_normals),
               'fine_continuous_sample_count':36+4*k,'first_parent_continuous_sample_count':12+8*k,
               'reduced_generator_representation_count':4*(5+2*k)+int(k<4),'details':details}
        rows.append(row)
    assert len(rows)==12 and decorated==45 and residual_matrices.cache_info().misses==31
    assert geometry_witness is not None
    max_attempts=max(F(r['ancestry_envelope_ratio']) for r in rows)
    max_full=max(F(r['full_expected_gaussian_variates_coefficient']) for r in rows)
    max_reduced=max(F(r['reduced_expected_gaussian_variates_coefficient']) for r in rows)
    assert max_attempts<24 and max_full<395 and max_reduced<383
    result={'status':'PASS','runtime':sys.executable,'python':platform.python_version(),
            'command':[sys.executable,'-I','-B',str(Path(__file__).resolve())],
            'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':sha256(source.read_bytes()).hexdigest(),
            'bound_source_sha256':sha256(bound_source.read_bytes()).hexdigest(),'helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),
            'matrix_helper_sha256':sha256(g.HELPER.read_bytes()).hexdigest(),
            'scope':'All 45 decorated unit Gaussian instances; sampler law, positive-prior mixture bounds and radial law require the written derivation. No random variable or sample was drawn.',
            'connected_partitions':len(rows),'decorations':decorated,'residual_covariances':residual_matrices.cache_info().misses,
            'uniform_unit_expected_proposal_upper_bound':str(max_attempts),'uniform_unit_expected_proposal_upper_bound_float':float(max_attempts),
            'uniform_unit_full_expected_gaussian_variates_upper_bound':str(max_full),'uniform_unit_full_expected_gaussian_variates_upper_bound_float':float(max_full),
            'uniform_unit_reduced_expected_gaussian_variates_upper_bound':str(max_reduced),'uniform_unit_reduced_expected_gaussian_variates_upper_bound_float':float(max_reduced),
            'radial_uniform_log_draw_upper_bound':6,'geometry_witness':geometry_witness,'rows':rows,
            'elapsed_seconds':time.perf_counter()-start,
            'not_run':['random sampling','uniform or Gaussian draws','ODE','fitting','numerical prior selection','parameter search','new observations','GPU','test suite','Lean','tamper checks','previous scientific mains','production sampler implementation']}
    (folder/'generation-identities.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','connected_partitions','decorations','residual_covariances','uniform_unit_expected_proposal_upper_bound_float','uniform_unit_full_expected_gaussian_variates_upper_bound_float','uniform_unit_reduced_expected_gaussian_variates_upper_bound_float','radial_uniform_log_draw_upper_bound','elapsed_seconds')},indent=2))
    print('per-k conditional Gaussian and radial counts:',{row['k']:[row['conditional_full_gaussian_variates_after_acceptance'],row['conditional_reduced_gaussian_variates_after_acceptance'],row['radial_uniform_and_log_count']] for row in rows})


if __name__=='__main__':
    main()
