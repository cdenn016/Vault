"""Exact two-channel rejection work coefficients; no matrix or random rerun."""
from fractions import Fraction as F
from hashlib import sha256
import json
from math import isqrt
from pathlib import Path
import platform
import sys
import time


def rational_sqrt(value: F) -> F:
    numerator = isqrt(value.numerator)
    denominator = isqrt(value.denominator)
    result = F(numerator, denominator)
    assert result*result == value
    return result


def main() -> None:
    start = time.perf_counter()
    folder = Path(__file__).parent
    source = folder.parent/'transported-parent-prior/result.json'
    envelope_source = folder.parent/'ancestry-screening/positive-envelopes.json'
    generation_source = folder/'generation-identities.json'
    data = json.loads(source.read_text(encoding='utf-8'))
    envelope = json.loads(envelope_source.read_text(encoding='utf-8'))
    generation = json.loads(generation_source.read_text(encoding='utf-8'))
    bound_rows = {tuple(tuple(b) for b in row['partition']):row for row in envelope['rows']}
    one_channel_constant = rational_sqrt(F(envelope['half_power_likelihood_constant']))
    rows = []
    for original in data['rows']:
        partition = tuple(tuple(b) for b in original['partition'])
        bounds = bound_rows[partition]
        z = F(original['evidence'])
        bar_z = F(bounds['mass_upper'])
        cross = F(0)
        decorated = []
        for old, bound in zip(original['details'], bounds['details']):
            assert old['roots'] == bound['roots'] and old['trees'] == bound['trees']
            e = F(old['one_channel_evidence'])
            bar_e = rational_sqrt(F(bound['mass_upper']))
            assert 0 < e/bar_e < 1
            cross += e*bar_e/len(original['details'])
            decorated.append({'roots':old['roots'],'trees':old['trees'],'one_channel_acceptance':str(e/bar_e)})
        assert cross*cross <= z*bar_z
        attempt = bar_z/z
        cross_ratio = cross/z
        staged_residual = 8*(attempt+cross_ratio)
        old_residual = 16*attempt
        assert staged_residual < old_residual
        k = original['k']
        staged_reduced = staged_residual+4*(1+2*k)
        staged_full = staged_residual+4*(5+k)
        rows.append({'partition':original['partition'],'k':k,'mass_evidence':str(z),'envelope_mass':str(bar_z),'one_channel_cross_integral':str(cross),
                     'ancestry_envelope_ratio':str(attempt),'cross_integral_to_evidence_ratio':str(cross_ratio),
                     'staged_residual_gaussian_coefficient':str(staged_residual),'staged_residual_gaussian_coefficient_float':float(staged_residual),
                     'staged_full_gaussian_coefficient':str(staged_full),'staged_full_gaussian_coefficient_float':float(staged_full),
                     'staged_reduced_gaussian_coefficient':str(staged_reduced),'staged_reduced_gaussian_coefficient_float':float(staged_reduced),
                     'staged_acceptance_uniform_coefficient':str(attempt+cross_ratio),'categorical_uniform_coefficient':str(attempt),
                     'radial_uniform_log_count':2*(4-k),'details':decorated})
    maximum_full = max(F(row['staged_full_gaussian_coefficient']) for row in rows)
    maximum_reduced = max(F(row['staged_reduced_gaussian_coefficient']) for row in rows)
    maximum_acceptance = max(F(row['staged_acceptance_uniform_coefficient']) for row in rows)
    maximum_attempts = max(F(row['ancestry_envelope_ratio']) for row in rows)
    assert maximum_attempts == F(generation['uniform_unit_expected_proposal_upper_bound'])
    assert maximum_full < F(generation['uniform_unit_full_expected_gaussian_variates_upper_bound'])
    assert maximum_reduced < F(generation['uniform_unit_reduced_expected_gaussian_variates_upper_bound'])
    result = {'status':'PASS','runtime':sys.executable,'python':platform.python_version(),
              'command':[sys.executable,'-I','-B',str(Path(__file__).resolve())],
              'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':sha256(source.read_bytes()).hexdigest(),
              'envelope_source_sha256':sha256(envelope_source.read_bytes()).hexdigest(),'generation_source_sha256':sha256(generation_source.read_bytes()).hexdigest(),
              'scope':'Frozen-state two-channel rejection sampler for the unchanged original batch. Coefficients pool with the target ancestry weights. They are not waiting times conditional on the final accepted ancestry of the full sampler.',
              'one_channel_envelope_constant':str(one_channel_constant),'connected_partitions':len(rows),'decorations':sum(len(row['details']) for row in rows),
              'uniform_unit_full_gaussian_expectation_upper':str(maximum_full),'uniform_unit_full_gaussian_expectation_upper_float':float(maximum_full),
              'uniform_unit_reduced_gaussian_expectation_upper':str(maximum_reduced),'uniform_unit_reduced_gaussian_expectation_upper_float':float(maximum_reduced),
              'uniform_unit_acceptance_uniform_expectation_upper':str(maximum_acceptance),'uniform_unit_acceptance_uniform_expectation_upper_float':float(maximum_acceptance),
              'uniform_unit_categorical_uniform_expectation_upper':str(maximum_attempts),
              'rows':rows,'elapsed_seconds':time.perf_counter()-start,
              'not_run':['matrix integral reevaluation','random sampling','numerical prior selection','ODE','new observations','fitting','parameter search','GPU','test suite','Lean','tamper checks','earlier scientific mains']}
    (folder/'staged-costs.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','one_channel_envelope_constant','connected_partitions','decorations','uniform_unit_full_gaussian_expectation_upper_float','uniform_unit_reduced_gaussian_expectation_upper_float','uniform_unit_acceptance_uniform_expectation_upper_float','elapsed_seconds')},indent=2))


if __name__=='__main__':
    main()
