"""Enclose both native regime windows on the saved full O/P reference path."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('full_path_utilities',HERE/'validate_saved_path.py')
v=importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
m,d,I=v.m,v.d,v.I
ORDER=10
NAMES=['O','P_split','P_merge','P_mass','conditional_merge','split_minus_O','split_minus_merge','merge_minus_O','merge_minus_split','field_saving']


def combine(groups: list[dict], e: list[dict], lam: list[I]) -> list[list[I]]:
    """Complete probability ratios, using the same ancestry/decoration normalizer."""
    zero=d.constant(0,ORDER)
    totals={kind:zero[:] for kind in ('O','P','A1','A2','A3')}
    exp_lam=d.exponential(lam)
    for group,row in zip(groups,e):
        mass=d.scale(d.mul(row[()],row[()]),group['weight'])
        if group['k']==2: mass=d.mul(mass,exp_lam)
        totals[group['kind']]=d.add(totals[group['kind']],mass)
    norm=d.add(totals['O'],totals['P'])
    inverse=d.inv(norm)
    numerator=d.add(d.add(totals['A1'],totals['A2']),d.neg(totals['A3']))
    oo=d.mul(totals['O'],inverse)
    wp=d.mul(totals['P'],inverse)
    merged=d.mul(numerator,inverse)
    split=d.add(wp,d.neg(merged))
    conditional=d.mul(numerator,d.inv(totals['P']))
    return [oo,split,merged,wp,conditional,d.add(split,d.neg(oo)),d.add(split,d.neg(merged)),
            d.add(merged,d.neg(oo)),d.add(merged,d.neg(split)),d.add(d.constant(20,ORDER),d.scale(split,-4))]


def bound(groups: list[dict], coefficients: list[list[F]], error: F, model: bool) -> list[I]:
    radius=I.q(2*error); perturb=I(-radius.hi,radius.hi)
    # Model posterior has zero count memory; its variance uses the model coordinates.
    selected=coefficients[:3]+[[F(0)]] if model else coefficients[3:6]+[coefficients[6]]
    center=v.log_jets(selected,ORDER,False,perturb)
    box=v.log_jets(selected,ORDER,True,perturb)
    if model: center[3]=d.constant(0,ORDER); box[3]=d.constant(0,ORDER)
    rc=[d.exponential(x) for x in center[:3]]
    rb=[d.exponential(x) for x in box[:3]]
    ec=m.normalizers(groups,rc,0)
    eb=m.normalizers(groups,rb,0)
    eb=m.tighten_time(ec,eb,ORDER)
    cc=combine(groups,ec,center[3]); cb=combine(groups,eb,box[3])
    output=[]
    for a,b in zip(cc,cb):
        radius=sum(x.abs_hi() for x in a[1:ORDER])+b[ORDER].abs_hi()
        enclosure=I(a[0].lo-radius,a[0].hi+radius)
        output.append(I(max(enclosure.lo,b[0].lo),min(enclosure.hi,b[0].hi)))
    return output


def main() -> None:
    start=time.perf_counter()
    source=HERE/'determinant-polynomials.json'
    shifted=HERE.parent/'native-transient/readout-determinant-polynomials.json'
    candidates=HERE/'readout-window-candidates.json'
    certificate_path=HERE/'path-enclosure.json'
    data=json.loads(source.read_text()); shifts=json.loads(shifted.read_text())
    certificate=json.loads(certificate_path.read_text())
    assert certificate['status']=='PASS_FULL_NATIVE_PATH_ENCLOSURE'
    for name,expected in certificate['source_sha256'].items():
        assert sha256((HERE.parent.parent/name).read_bytes()).hexdigest()==expected,name
    pp=F(data['prior_exact'][1])
    rows=[{**row,'kind':row['ancestry']} for row in data['rows']]
    for mask in (1,2,3):
        rows += [{**row,'kind':'A'+str(mask),'k':2,'ancestry':'P','weight':str(pp*F(row['weight']))} for row in shifts['masks'][mask]]
    groups=m.prepare(rows,0)
    for group,row in zip(groups,rows): group['kind']=row['kind']
    assert len(groups)==16
    windows=json.loads(candidates.read_text())
    targets=[('P_split',F(5),F(7)),('P_merge',F(35),F(40))]
    results=[]
    for desired,left,right in targets:
        chosen=[row for row in windows if F(row['right'])>left and F(row['left'])<right]
        assert F(chosen[0]['left'])<=left and F(chosen[-1]['right'])>=right
        assert all(F(a['right'])==F(b['left']) for a,b in zip(chosen,chosen[1:]))
        out=[]
        for index,row in enumerate(chosen):
            coefficients=[[F(x) for x in line] for line in row['coefficients']]
            error=F(row['error_bound'])
            recognition=bound(groups,coefficients,error,False)
            model=bound(groups,coefficients,error,True)
            tests=[5,6] if desired=='P_split' else [7,8]
            passed=all(recognition[j].lo>0 and model[j].lo>0 for j in tests)
            out.append({'left':row['left'],'right':row['right'],'recognition':{name:x.strings() for name,x in zip(NAMES,recognition)},
                        'model_posterior':{name:x.strings() for name,x in zip(NAMES,model)},'desired_regime_strictly_modal':passed})
            if (index+1)%10==0: print(json.dumps({'regime':desired,'checked_intervals':index+1,'through':row['right'],'passed':passed}),flush=True)
        summary={}
        for law in ('recognition','model_posterior'):
            summary[law]={name:[float(min(F(row[law][name][0]) for row in out)),float(max(F(row[law][name][1]) for row in out))] for name in NAMES}
        results.append({'desired_regime':desired,'window':[str(left),str(right)],'passed':all(row['desired_regime_strictly_modal'] for row in out),
                        'range_summary_float':summary,'covered_intervals':out})
    passed=all(row['passed'] for row in results)
    output={'status':'PASS_TWO_NATIVE_REGIME_WINDOWS' if passed else 'INCONCLUSIVE_NATIVE_REGIME_WINDOWS',
            'runtime':sys.executable,'python':platform.python_version(),'source_sha256':{str(p.relative_to(HERE.parent.parent)):sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),source,shifted,candidates,certificate_path,HERE/'native_interval_model.py',HERE/'validate_saved_path.py')},
            'jet_order':ORDER,'results':results,'elapsed_seconds':time.perf_counter()-start,
            'scope':'All twenty O/P root/tree decorations and driven recognition count memory, on the certified reference path. Written continuity is required for a full-positive-prior theorem; no posterior majority is assumed.'}
    (HERE/'regime-window-enclosures.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'status':output['status'],'windows':[{key:row[key] for key in ('desired_regime','window','passed','range_summary_float')} for row in results],'elapsed_seconds':output['elapsed_seconds']},indent=2),flush=True)
    assert passed,'A requested window was not enclosed as strictly modal'


if __name__=='__main__': main()
