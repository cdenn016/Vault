"""Validate the saved seven-coordinate tie-reference path without reintegration."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time
import traceback

HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('full_path_utilities',HERE/'validate_saved_path.py')
v=importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
m,d,I=v.m,v.d,v.I


def main() -> None:
    start=time.perf_counter()
    coefficients=HERE/'determinant-polynomials.json'
    source=HERE/'reference-trajectory.json'
    data=json.loads(coefficients.read_text()); trajectory=json.loads(source.read_text())
    groups=m.prepare(data['rows'],3)
    evidence=HERE.parent/'transported-parent-prior/result.json'
    geometry=json.loads(evidence.read_text())
    O=next(row for row in geometry['rows'] if row['k']==1)
    P=next(row for row in geometry['rows'] if row['partition']==[[0,1],[2,3]])
    energy=[sum(F(row['posterior_M_energy_coordinates'][j])*([16,4*row['k'],16][j])/2 for row in (O,P)) for j in range(3)]
    kpi=F(data['K_pi_exact'])
    expected=[energy[0]/16-1,energy[1]/(4*kpi)-F(3,2)/kpi,energy[2]/16-1]+[F(0)]*4
    ev=m.normalizers(groups,[[d.ONE] for _ in range(3)],1)
    rates=m.vector_field(groups,[[d.ZERO] for _ in range(7)],ev)
    assert all(F(value[0].lo,d.SCALE)<=target<=F(value[0].hi,d.SCALE) for value,target in zip(rates,expected))
    files=[Path(__file__),HERE/'native_interval_model.py',HERE/'validate_saved_path.py',coefficients,source,
           HERE.parent/'native-transient/native_interval_model.py',HERE.parent/'native-transient/dyadic_interval.py']
    metadata={'runtime':sys.executable,'python':platform.python_version(),'source_sha256':{str(p.relative_to(HERE.parent.parent)):sha256(p.read_bytes()).hexdigest() for p in files},
              'interval_bits':d.BITS,'residual_jet_order':v.N_RESIDUAL,'jacobian_jet_order':v.N_JACOBIAN,
              'maximum_substep':str(v.MAX_STEP),'target_time':str(v.TARGET),'weights':[x.strings() for x in v.W],
              'prior_exact':data['prior_exact'],'K_pi_exact':data['K_pi_exact'],'exact_initial_log_rates':[str(x) for x in expected],
              'scope':'Exact initial O/P posterior-tie boundary prior, all 20 decorations, full native count memory; one a posteriori path enclosure of saved polynomial data. No ODE rerun.'}
    try:
        error,terminal,windows=v.check_path(groups,trajectory['dense_segments'])
        result={**metadata,'status':'PASS_FULL_NATIVE_PATH_ENCLOSURE','weighted_terminal_error':str(F(error.hi,d.SCALE)),
                'weighted_uniform_error':str(max(F(row['within_interval_error_bound']) for row in v.records)),
                'terminal_candidate':[str(x) for x in terminal],'steps':v.records,'elapsed_seconds':time.perf_counter()-start}
        (HERE/'path-enclosure.json').write_text(json.dumps(result,indent=2)+'\n')
        output=[{'left':str(row['left']),'right':str(row['right']),'coefficients':[[str(x) for x in line] for line in row['coefficients']],
                 'error_bound':str(F(row['error'].hi,d.SCALE))} for row in windows]
        (HERE/'readout-window-candidates.json').write_text(json.dumps(output,indent=2)+'\n')
        print(json.dumps({key:result[key] for key in ('status','weighted_terminal_error','weighted_uniform_error','elapsed_seconds')},indent=2),flush=True)
    except Exception as exc:
        result={**metadata,'status':'INCONCLUSIVE_FULL_NATIVE_PATH_ENCLOSURE','exception':repr(exc),'traceback':traceback.format_exc(),
                'completed_steps':v.records,'elapsed_seconds':time.perf_counter()-start}
        (HERE/'path-enclosure-failure.json').write_text(json.dumps(result,indent=2)+'\n')
        raise


if __name__=='__main__': main()
