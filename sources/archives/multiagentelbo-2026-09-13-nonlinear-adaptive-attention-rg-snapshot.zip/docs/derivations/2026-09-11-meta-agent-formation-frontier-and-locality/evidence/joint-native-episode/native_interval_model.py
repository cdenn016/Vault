"""Exact determinant jets and analytic Jacobian for the full O/P native reference."""
from fractions import Fraction as F
import importlib.util
import json
from pathlib import Path

HERE=Path(__file__).parent
BASE=HERE.parent/'native-transient/native_interval_model.py'
spec=importlib.util.spec_from_file_location('saved_determinant_jet_kernel',BASE)
base=importlib.util.module_from_spec(spec); spec.loader.exec_module(base)
d=base.d; I=d.I
indices=base.indices
normalizers=base.normalizers
tighten_time=base.tighten_time
COEFFICIENTS=json.loads((HERE/'determinant-polynomials.json').read_text())
K_PI=I.q(F(COEFFICIENTS['K_pi_exact']))


def prepare(rows: list[dict], order: int = 3) -> list[dict]:
    groups=base.prepare(rows,order)
    for group,row in zip(groups,rows):
        group['k']=row.get('k',2)
        group['ancestry']=row.get('ancestry','P')
    return groups


def mixture(groups: list[dict], state: list[list[I]], e: list[dict], second: bool = False) -> dict:
    """Weighted determinant moments; a common exp(lambda) factor cancels."""
    n=len(state[0])-1; zero=d.constant(0,n)
    z=zero[:]; kn=zero[:]; k2n=zero[:]
    scores=[zero[:] for _ in range(3)]
    kscores=[zero[:] for _ in range(3)]
    seconds=[[zero[:] for _ in range(3)] for _ in range(3)]
    for group,row in zip(groups,e):
        k=group['k']
        weight=d.scale(d.exponential(d.scale(state[6],k-1)),group['weight'])
        mass=d.mul(weight,d.mul(row[()],row[()]))
        z=d.add(z,mass); kn=d.add(kn,d.scale(mass,k)); k2n=d.add(k2n,d.scale(mass,k*k))
        for j in range(3):
            v=d.mul(weight,d.mul(row[()],row[(j,)]))
            scores[j]=d.add(scores[j],v); kscores[j]=d.add(kscores[j],d.scale(v,k))
            if second:
                for l in range(3):
                    v=d.add(d.mul(row[(j,)],row[(l,)]),d.mul(row[()],row[tuple(sorted((j,l)))]))
                    seconds[j][l]=d.add(seconds[j][l],d.mul(weight,v))
    invz=d.inv(z)
    a=[d.mul(v,invz) for v in scores]
    ek=d.mul(kn,invz)
    result={'score':a,'k':ek}
    if second:
        dl_a=[d.add(d.mul(v,invz),d.neg(d.mul(ai,ek))) for v,ai in zip(kscores,a)]
        dr_a=[[d.add(d.mul(seconds[j][l],invz),d.scale(d.mul(a[j],a[l]),-2)) for l in range(3)] for j in range(3)]
        result.update({'score_r':dr_a,'score_lambda':dl_a,
                       'k_r':[d.scale(v,2) for v in dl_a],
                       'k_lambda':d.add(d.mul(k2n,invz),d.neg(d.mul(ek,ek)))})
    return result


def vector_field(groups: list[dict], state: list[list[I]], e: list[dict]) -> list[list[I]]:
    """Native log-variance and count-memory equations at exact fixed tie weights."""
    n=len(state[0])-1; one=d.constant(1,n)
    v=mixture(groups,state,e)
    model=[]; rec=[]
    for j in range(3):
        ratio=d.exponential(d.add(state[j+3],d.neg(state[j])))
        factor=d.exponential(d.add(d.scale(state[j+3],2),d.neg(state[j])))
        rate=d.add(ratio,d.neg(one))
        if j==1:
            rate=d.scale(d.add(d.mul(v['k'],rate),d.mul(factor,v['score'][j])),d.ONE/K_PI)
        else:
            rate=d.add(rate,d.scale(d.mul(factor,v['score'][j]),I.q(F(1,4))))
        model.append(rate); rec.append(d.add(one,d.neg(ratio)))
    delta=d.add(state[4],d.neg(state[1]))
    forcing=d.add(d.add(d.exponential(delta),d.neg(one)),d.neg(delta))
    lam=d.add(d.neg(state[6]),d.scale(forcing,-2))
    return model+rec+[lam]


def jacobian_jets(groups: list[dict], state: list[list[I]], e: list[dict]) -> list[list[list[I]]]:
    """Analytic seven-by-seven Jacobian; evidence derivatives and count covariances retained."""
    n=len(state[0])-1; zero=d.constant(0,n); one=d.constant(1,n)
    v=mixture(groups,state,e,True)
    r=[d.exponential(x) for x in state[3:6]]
    jac=[[zero[:] for _ in range(7)] for _ in range(7)]
    for j in range(3):
        ratio=d.exponential(d.add(state[j+3],d.neg(state[j])))
        factor=d.exponential(d.add(d.scale(state[j+3],2),d.neg(state[j])))
        a=v['score'][j]
        invdim=d.ONE/K_PI if j==1 else I.q(F(1,4))
        baseline=d.scale(v['k'],d.ONE/K_PI) if j==1 else one
        jac[j][j]=d.neg(d.add(d.mul(baseline,ratio),d.scale(d.mul(factor,a),invdim)))
        for l in range(3):
            derivative=d.mul(r[l],v['score_r'][j][l])
            if j==l: derivative=d.add(derivative,d.scale(a,2))
            entry=d.scale(d.mul(factor,derivative),invdim)
            if j==l: entry=d.add(entry,d.mul(baseline,ratio))
            if j==1:
                correction=d.mul(d.mul(r[l],v['k_r'][l]),d.add(ratio,d.neg(one)))
                entry=d.add(entry,d.scale(correction,d.ONE/K_PI))
            jac[j][l+3]=entry
        lam=d.scale(d.mul(factor,v['score_lambda'][j]),invdim)
        if j==1:
            lam=d.add(lam,d.scale(d.mul(v['k_lambda'],d.add(ratio,d.neg(one))),d.ONE/K_PI))
        jac[j][6]=lam
        jac[j+3][j]=ratio; jac[j+3][j+3]=d.neg(ratio)
    delta=d.add(state[4],d.neg(state[1]))
    response=d.scale(d.add(d.exponential(delta),d.neg(one)),2)
    jac[6][1]=response; jac[6][4]=d.neg(response); jac[6][6]=d.constant(-1,n)
    return jac
