"""Check the newly added full-native Jacobian and three saved-path interval bounds."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import time

HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('path_definitions',HERE/'validate_saved_path.py')
v=importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
m,d,I=v.m,v.d,v.I


def main() -> None:
    start=time.perf_counter()
    data=json.loads((HERE/'determinant-polynomials.json').read_text())
    trajectory=json.loads((HERE/'reference-trajectory.json').read_text())
    groups=m.prepare(data['rows'],3)
    assert len(v.W)==7 and all(weight.lo>=d.SCALE//2 for weight in v.W)
    point=[F(x) for x in trajectory['accepted_log_states'][next(i for i,t in enumerate(trajectory['accepted_times']) if t>=12)]]
    constant=[[I.q(x)] for x in point]
    ev=m.normalizers(groups,[[d.exp(I.q(x))] for x in point[3:6]],2)
    jac=m.jacobian_jets(groups,constant,ev)
    rows=[]
    for col in range(7):
        state=[[I.q(x),I.q(int(j==col))] for j,x in enumerate(point)]
        es=m.normalizers(groups,[d.exponential(x) for x in state[3:6]],1)
        derivative=m.vector_field(groups,state,es)
        for row in range(7):
            aa=jac[row][col][0]; bb=derivative[row][1]
            assert max(aa.lo,bb.lo)<=min(aa.hi,bb.hi),(row,col,aa.floats(),bb.floats())
            rows.append({'row':row,'column':col,'analytic':aa.strings(),'directional':bb.strings()})
    probes=[]
    for target in (0,12,35):
        segment=next(s for s in trajectory['dense_segments'] if s['t_old']>=target)
        left=F(segment['t_old']); right=min(F(segment['t']),left+F(1,8))
        coefficients=v.restrict(v.dense_coefficients(segment),segment,left,right)
        residual,components=v.defect(groups,coefficients,(right-left)/2)
        jac=v.jacobian_tube(groups,coefficients,I.q(F(1,10**8)))
        growth,certificate=v.lognorm(jac)
        probes.append({'left':str(left),'right':str(right),'weighted_defect':str(F(residual.hi,d.SCALE)),
                       'lognorm':str(F(growth.hi,d.SCALE)),'lognorm_float':growth.hi/d.SCALE,
                       'defect_float':residual.hi/d.SCALE,'jacobian_certificate':certificate})
    result={'status':'PASS_FULL_NATIVE_JACOBIAN_AND_PROBES','runtime':sys.executable,
            'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'model_sha256':sha256((HERE/'native_interval_model.py').read_bytes()).hexdigest(),
            'validator_sha256':sha256((HERE/'validate_saved_path.py').read_bytes()).hexdigest(),'reference_sha256':sha256((HERE/'reference-trajectory.json').read_bytes()).hexdigest(),
            'directional_comparisons':rows,'interval_probes':probes,'elapsed_seconds':time.perf_counter()-start,
            'scope':'49 analytic-versus-directional derivative interval comparisons and three declared local error-tube probes. Not a global trajectory enclosure.'}
    (HERE/'jacobian-and-interval-probes.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'comparisons':len(rows),'probes':[{k:p[k] for k in ('left','right','defect_float','lognorm_float')} for p in probes],'elapsed_seconds':result['elapsed_seconds']},indent=2))


if __name__=='__main__': main()
