"""Uniform second-panel geometry for every ancestry and active-cut pattern."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

HERE=Path(__file__).parent
SOURCE=HERE.parent/'transported-parent-prior/result.json'
HELPER=HERE.parent/'shared-parent-record/shared_parent_exact.py'
spec=importlib.util.spec_from_file_location('existing_geometry',HELPER)
g=importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
h=g.helper
EDGES=((0,1),(1,2),(2,3),(3,0))
Matrix=list[list[F]]


def mv_cost(matrix: Matrix) -> tuple[int,int]:
    return (4*sum(x != 0 and x != 1 for row in matrix for x in row),
            4*sum(max(0,sum(x != 0 for x in row)-1) for row in matrix))


def main() -> None:
    start=time.perf_counter()
    data=json.loads(SOURCE.read_text()); outputs=[]
    for row in data['rows']:
        blocks=row['partition']; labels=row['labels']; k=row['k']; masses=[len(block) for block in blocks]
        cut=[e for e,(i,j) in enumerate(EDGES) if labels[i]!=labels[j]]
        assert len(cut)==(k if k>1 else 0)
        for dec in row['details']:
            old_paths=[[F(x) for x in line] for line in dec['path_matrix']]
            c=[[F(x) for x in line] for line in dec['C']]
            cotree=[i for i,line in enumerate(c) if any(line)]
            assert len(cotree)==k
            dmap=[c[e] for e in cotree]
            first=[]
            for block in blocks:
                first.append([F(i in block,len(block)) for i in range(4)]+[-sum(old_paths[i][e] for i in block)/len(block) for e in range(4)])
            first += [[F(0)]*4+c[e] for e in cotree]
            for mask in range(1<<len(cut)):
                parents=list(range(k)); chosen=[]
                def find(i: int) -> int:
                    while parents[i]!=i: i=parents[i]
                    return i
                for j,e in enumerate(cut):
                    a,b=(labels[i] for i in EDGES[e])
                    aa,bb=find(a),find(b)
                    if mask&(1<<j) and aa!=bb:
                        parents[bb]=aa; chosen.append(e)
                comps={}
                for a in range(k): comps.setdefault(find(a),[]).append(a)
                components=sorted(comps.values(),key=lambda group:min(dec['roots'][a] for a in group))
                q=len(components)
                t=[[F(0)]*k for _ in range(k)]
                for component in components:
                    root=min(component,key=lambda a:dec['roots'][a]); seen={root}; todo=[root]
                    while todo:
                        a=todo.pop()
                        for e in chosen:
                            u,w=(labels[i] for i in EDGES[e])
                            if a not in (u,w): continue
                            b=w if a==u else u
                            if b in seen: continue
                            t[b]=t[a][:]; t[b][cotree.index(e)]+=1 if a==u else -1
                            seen.add(b); todo.append(b)
                    assert seen==set(component)
                keep=[e for e in cotree if e not in chosen]
                assert len(keep)==q and len(chosen)==k-q
                transform=[]
                fine_components=[]
                for component in components:
                    n=sum(masses[a] for a in component)
                    transform.append([F(masses[a],n) if a in component else F(0) for a in range(k)]+[-sum((F(masses[a],n)*t[a][j] for a in component),F(0)) for j in range(k)])
                    fine_components.append(sorted(i for a in component for i in blocks[a]))
                for e in keep:
                    a,b=(labels[i] for i in EDGES[e])
                    transform.append([F(0)]*k+[F(e==other)+t[a][j]-t[b][j] for j,other in enumerate(cotree)])
                flat=[]
                for i in range(4):
                    offset=h.multiply([t[labels[i]]],dmap)[0]
                    flat.append([a+b for a,b in zip(old_paths[i],offset)])
                direct=[]
                for block in fine_components:
                    direct.append([F(i in block,len(block)) for i in range(4)]+[-sum(flat[i][e] for i in block)/len(block) for e in range(4)])
                for e in keep:
                    i,j=EDGES[e]
                    direct.append([F(0)]*4+[F(l==e)+flat[i][l]-flat[j][l] for l in range(4)])
                assert h.multiply(transform,first)==direct
                fields=12+8*q+(2*len(cut) if q<k else 0)
                fine_fields=36+4*k
                assert fields<=12+8*k and fine_fields-fields>=8
                mul,add=mv_cost(transform)
                assert mul<=192 and add<=168
                outputs.append({'partition':blocks,'roots':dec['roots'],'trees':dec['trees'],'cut_labels':cut,'active_mask':mask,
                                'second_partition':fine_components,'chosen_new_tree_edges':chosen,'retained_nontree_edges':keep,
                                'k':k,'q':q,'retained_new_probability_count':2*len(cut) if q<k else 0,'parent_fields':fields,'fine_fields':fine_fields,
                                'field_saving':fine_fields-fields,'geometry_multiply':mul,'geometry_add':add,
                                'geometry_map':[[str(x) for x in line] for line in transform]})
    assert len(outputs)==176
    pairs=[row for row in outputs if row['partition']==[[0,1],[2,3]]]
    assert len(pairs)==16
    assert all(row['parent_fields']==(28 if row['active_mask']==0 else 24) for row in pairs)
    result={'status':'PASS_UNIFORM_SECOND_PANEL_GEOMETRY','runtime':sys.executable,'python':platform.python_version(),
            'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':sha256(SOURCE.read_bytes()).hexdigest(),
            'helper_sha256':sha256(HELPER.read_bytes()).hexdigest(),'matrix_helper_sha256':sha256(g.HELPER.read_bytes()).hexdigest(),
            'cases':len(outputs),'decorations':45,'partitions':12,'field_saving_range':[min(row['field_saving'] for row in outputs),max(row['field_saving'] for row in outputs)],
            'geometry_multiply_max':max(row['geometry_multiply'] for row in outputs),'geometry_add_max':max(row['geometry_add'] for row in outputs),
            'rows':outputs,'elapsed_seconds':time.perf_counter()-start,
            'scope':'All active-cut masks use one uniform graph rule. Exact direct/staged linear-map identity and displayed resource counts, without drawing any flags or states. No tamper scenarios.'}
    (HERE/'uniform-panel-geometry.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:result[key] for key in ('status','cases','field_saving_range','geometry_multiply_max','geometry_add_max','elapsed_seconds')},indent=2))


if __name__=='__main__': main()
