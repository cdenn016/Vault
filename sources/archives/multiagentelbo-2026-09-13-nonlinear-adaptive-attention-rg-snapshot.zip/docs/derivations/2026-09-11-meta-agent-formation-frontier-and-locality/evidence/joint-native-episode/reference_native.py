"""One seven-coordinate native diagnostic at the exact initial O/P posterior tie."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import inspect
from itertools import product
import json
from pathlib import Path
import platform
import sys
import time
import numpy as np
import scipy
from scipy.integrate import solve_ivp

HERE=Path(__file__).parent
SOURCE=HERE.parent/'transported-parent-prior/result.json'
HELPER=HERE.parent/'shared-parent-record/shared_parent_exact.py'
spec=importlib.util.spec_from_file_location('existing_geometry',HELPER)
g=importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
old=json.loads(SOURCE.read_text(encoding='utf-8'))
O=next(row for row in old['rows'] if row['k']==1)
P=next(row for row in old['rows'] if row['partition']==[[0,1],[2,3]])
Z_O,Z_P=F(O['evidence']),F(P['evidence'])
PI_EXACT=[Z_P/(Z_O+Z_P),Z_O/(Z_O+Z_P)]
PI=np.array([float(v) for v in PI_EXACT])
K_PI_EXACT=PI_EXACT[0]+2*PI_EXACT[1]
K_PI=float(K_PI_EXACT)
B=np.array(g.B,dtype=float)
GA=B@B.T
GROUPS=[]
for ri,row in enumerate((O,P)):
    inc=np.array([[float(label==j) for j in range(row['k'])] for label in row['labels']])
    J=B@inc; GB=J@J.T
    grouped={}
    for dec in row['details']:
        C=np.array([[float(F(v)) for v in line] for line in dec['C']])
        GC=C@C.T; key=tuple(GC.ravel())
        if key not in grouped: grouped[key]={'grams':np.stack((GA,GB,GC)),'weight':0.}
        grouped[key]['weight']+=1/len(row['details'])
    for entry in grouped.values(): GROUPS.append({**entry,'index':ri,'k':row['k']})
GRAMS=np.stack([row['grams'] for row in GROUPS])
WH=np.array([row['weight'] for row in GROUPS])
RI=np.array([row['index'] for row in GROUPS])
K=np.array([row['k'] for row in GROUPS])
DIM=np.stack((np.full(len(K),16.),4*K,np.full(len(K),16.)),axis=1)
BITS=np.array(list(product((0,1),repeat=4)))
SIGNS=(-1.)**BITS.sum(axis=1)
T=np.array([[.5,1.,.5,0.],[.5,0.,.5,1.]])
Q=np.array([[np.diag(np.array(g.N)+bits)+sum((np.outer(T[j],T[j]) for j in range(2) if mask&(1<<j)),np.zeros((4,4))) for bits in BITS] for mask in range(4)])
QI=np.linalg.inv(Q); QD=np.linalg.det(Q)
METRICS={'rhs_calls':0,'minimum_signed_sum_ratio':1.}


def moments(variance: np.ndarray, lam: float) -> tuple[np.ndarray,float,float]:
    """Return full-mixture energy, expected block count and recognized P mass."""
    gamma=np.einsum('j,hjkl->hkl',variance,GRAMS)
    matrices=gamma[:,None,:,:]+QI[0][None,:,:,:]
    determinant=np.linalg.det(matrices)
    inverse=np.linalg.inv(matrices)
    terms=SIGNS[None,:]/(QD[0][None,:]*determinant)
    ev=terms.sum(axis=1)
    assert np.all(ev>0) and np.all(determinant>0)
    METRICS['minimum_signed_sum_ratio']=min(METRICS['minimum_signed_sum_ratio'],float(np.min(ev/np.abs(terms).sum(axis=1))))
    trace=np.einsum('hjkl,hnlk->hjn',GRAMS,inverse)
    derivative=(-trace*terms[:,None,:]).sum(axis=2)
    energy=DIM*variance[None,:]+4*variance[None,:]**2*derivative/ev[:,None]
    weights=PI[RI]*WH*np.exp(lam*(K-1))*ev**2
    weights/=weights.sum()
    mean=weights@energy
    assert np.all(mean>0) and np.all(np.isfinite(mean))
    return mean,float(weights@K),float(weights[RI==1].sum())


def merge(variance: np.ndarray) -> float:
    """Return the old parent merge readout conditional on P, with all four roots."""
    gamma=np.einsum('j,hjkl->hkl',variance,GRAMS[RI==1])
    determinant=np.linalg.det(gamma[:,None,None,:,:]+QI[None,:,:,:,:])
    ev=(SIGNS[None,None,:]/(QD[None,:,:]*determinant)).sum(axis=2)
    assert np.all(ev>0)
    z=WH[RI==1]@(ev**2)
    return float((z[1]+z[2]-z[3])/z[0])


def rhs(t: float, state: np.ndarray) -> np.ndarray:
    """Full native rates, including K_pi in the model metric and driven count memory."""
    METRICS['rhs_calls']+=1
    model=np.exp(state[:3]); rec=np.exp(state[3:6]); lam=float(state[6])
    energy,ek,_=moments(rec,lam)
    rate=energy/(np.array([16.,4*K_PI,16.])*model)-np.array([1.,ek/K_PI,1.])
    delta=state[4]-state[1]
    return np.concatenate((rate,1-rec/model,[-lam-2*(np.expm1(delta)-delta)]))


def readout(t: float, state: np.ndarray) -> dict:
    model=np.exp(state[:3]); rec=np.exp(state[3:6]); lam=float(state[6])
    _,_,wp=moments(rec,lam); _,_,wp_model=moments(model,0.)
    mp=merge(rec); mp_model=merge(model)
    masses=[1-wp,wp*(1-mp),wp*mp]
    model_masses=[1-wp_model,wp_model*(1-mp_model),wp_model*mp_model]
    return {'native_time':float(t),'model_variances':model.tolist(),'recognition_variances':rec.tolist(),'lambda':lam,
            'P_recognition_mass':wp,'P_model_posterior_mass':wp_model,'conditional_merge_recognition':mp,'conditional_merge_model_posterior':mp_model,
            'regime_order':['O','P_split','P_merge'],'recognition_regime_masses':masses,'model_posterior_regime_masses':model_masses,
            'recognition_winner':['O','P_split','P_merge'][int(np.argmax(masses))],
            'field_saving':24-4*(1+wp)+4*wp*mp}


def main() -> None:
    start=time.perf_counter()
    assert len(GROUPS)==7
    energy,ek,wp=moments(np.ones(3),0.)
    expected=np.zeros(3)
    for row in (O,P): expected+=.5*np.array([float(F(v)) for v in row['posterior_M_energy_coordinates']])*np.array([16.,4*row['k'],16.])
    assert np.max(np.abs(energy-expected))<1e-9 and abs(wp-.5)<1e-10 and abs(ek-1.5)<1e-10
    old_merge=json.loads((HERE.parent/'second-level-learning/second-level-response.json').read_text())
    assert abs(merge(np.ones(3))-float(F(old_merge['merge_probability'])))<1e-10
    solution=solve_ivp(rhs,(0.,40.),np.zeros(7),method='DOP853',rtol=1e-10,atol=1e-12,max_step=.125,dense_output=True)
    assert solution.success and solution.t[-1]==40.
    rows=[readout(t,solution.sol(t)) for t in (0.,.1,.5,1.,2.,4.,8.,12.,16.,20.,25.,30.,35.,40.)]
    accepted=[readout(t,state) for t,state in zip(solution.t,solution.y.T)]
    transitions=[]
    for a,b in zip(accepted,accepted[1:]):
        if a['recognition_winner']!=b['recognition_winner']:
            transitions.append({'accepted_time_bracket':[a['native_time'],b['native_time']],'from':a['recognition_winner'],'to':b['recognition_winner']})
    dense_source=inspect.getsource(type(solution.sol.interpolants[0])._call_impl)
    result={'status':'NUMERICAL_REFERENCE_COMPLETED','runtime':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
            'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'input_sha256':sha256(SOURCE.read_bytes()).hexdigest(),'helper_sha256':sha256(HELPER.read_bytes()).hexdigest(),'matrix_helper_sha256':sha256(g.HELPER.read_bytes()).hexdigest(),
            'scope':'One source-defined O/P initial posterior-tie boundary reference; all 20 decorations; full seven-coordinate native equations. A numerical diagnostic, not a path enclosure or a selected scientific prior.',
            'prior_exact':[str(v) for v in PI_EXACT],'prior_float':PI.tolist(),'K_pi_exact':str(K_PI_EXACT),'unit_conditional_evidence_exact':[str(Z_O),str(Z_P)],
            'native_interval':[0.,40.],'state_order':['log_model_a','log_model_b','log_model_c','log_recognition_a','log_recognition_b','log_recognition_c','lambda'],
            'solver':{'method':'DOP853','rtol':1e-10,'atol':1e-12,'max_step':.125,'success':bool(solution.success),'message':solution.message,'nfev':solution.nfev,'accepted_steps':len(solution.t)-1},
            'readouts':rows,'accepted_times':solution.t.tolist(),'accepted_log_states':solution.y.T.tolist(),'accepted_readouts':accepted,'accepted_winner_transition_brackets':transitions,
            'dense_segments':[{'t_old':seg.t_old,'t':seg.t,'h':seg.h,'y_old':seg.y_old.tolist(),'F':seg.F.tolist()} for seg in solution.sol.interpolants],
            'dense_evaluation_source':dense_source,'dense_evaluation_source_sha256':sha256(dense_source.encode()).hexdigest(),'evaluation_metrics':METRICS,'elapsed_seconds':time.perf_counter()-start,
            'not_proved':['Rigorous path/error or time-window enclosure','All-positive-prior continuation','Unique mode-transition times','Operational selection or actual resource license'],
            'not_run':['Earlier scientific mains','Fixed-P trajectory rerun','Horizon extension','Prior grid','Parameter fitting','New data','Sampling','Suite','GPU','Lean','Tamper checks']}
    (HERE/'reference-trajectory.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('status','prior_float','solver','accepted_winner_transition_brackets','evaluation_metrics','elapsed_seconds')},indent=2))
    for row in rows: print(json.dumps({key:row[key] for key in ('native_time','P_recognition_mass','conditional_merge_recognition','recognition_regime_masses','model_posterior_regime_masses','recognition_winner')}))


if __name__=='__main__': main()
