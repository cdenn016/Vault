"""Add the O determinant polynomials; reuse the saved P coefficients unchanged."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import permutations,product
import json
from pathlib import Path
import platform
import sys
import time

HERE=Path(__file__).parent
OLD=HERE.parent/'native-transient/determinant_polynomials.py'
spec=importlib.util.spec_from_file_location('existing_polynomial_definitions',OLD)
p=importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
g=p.g


def main() -> None:
    start=time.perf_counter()
    source=HERE.parent/'transported-parent-prior/result.json'
    old_p=HERE.parent/'native-transient/determinant-polynomials.json'
    data=json.loads(source.read_text())
    oo=next(row for row in data['rows'] if row['k']==1)
    pp=next(row for row in data['rows'] if row['partition']==[[0,1],[2,3]])
    zo,zp=F(oo['evidence']),F(pp['evidence'])
    prior=[zp/(zo+zp),zo/(zo+zp)]
    ga=g.helper.multiply(g.B,g.helper.transpose(g.B))
    gb=[[F(0)]*4 for _ in range(4)]
    groups={}
    for dec in oo['details']:
        c=[[F(v) for v in line] for line in dec['C']]
        gc=g.helper.multiply(c,g.helper.transpose(c)); key=tuple(v for line in gc for v in line)
        if key not in groups: groups[key]={'grams':[ga,gb,gc],'multiplicity':0}
        groups[key]['multiplicity']+=1
    rows=[]
    for group in groups.values():
        determinants=[]; grams=group['grams']
        for bits in product((0,1),repeat=4):
            q=[F(n+x) for n,x in zip(g.N,bits)]
            entries=[[{(0,0,0):F(i==j),**{tuple(int(k==l) for k in range(3)):grams[l][i][j]*q[j] for l in range(3)}} for j in range(4)] for i in range(4)]
            det={}
            for perm in permutations(range(4)):
                sign=(-1)**sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))
                term={(0,0,0):F(sign)}
                for i in range(4): term=p.multiply(term,entries[i][perm[i]])
                for key,value in term.items(): det[key]=det.get(key,F(0))+value
            det={key:value for key,value in det.items() if value}
            assert det[(0,0,0)]==1 and all(value>0 for value in det.values())
            assert all(key[1]==0 for key in det)
            determinants.append({'bits':list(bits),'sign':(-1)**sum(bits),'coefficients':[[*key,str(value)] for key,value in sorted(det.items())]})
        rows.append({'ancestry':'O','k':1,'weight':str(prior[0]*F(group['multiplicity'],16)),
                     'within_weight':str(F(group['multiplicity'],16)),'multiplicity':group['multiplicity'],
                     'grams':[[[str(x) for x in line] for line in gram] for gram in grams],'determinants':determinants})
    old_rows=json.loads(old_p.read_text())['rows']
    rows += [{**row,'ancestry':'P','k':2,'within_weight':row['weight'],'weight':str(prior[1]*F(row['weight']))} for row in old_rows]
    unit=[]
    for ancestry,reference in (('O',zo),('P',zp)):
        z=F(0)
        for row in rows:
            if row['ancestry']==ancestry:
                ev=sum((F(term['sign'])/sum(F(v[3]) for v in term['coefficients']) for term in row['determinants']),F(0))
                z+=F(row['within_weight'])*ev**2
        assert z==reference
        unit.append(str(z))
    assert len(rows)==7 and sum(row['multiplicity'] for row in rows)==20
    output={'status':'PASS_EXACT_OP_POLYNOMIALS','runtime':sys.executable,'python':platform.python_version(),
            'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':sha256(source.read_bytes()).hexdigest(),
            'reused_P_polynomial_sha256':sha256(old_p.read_bytes()).hexdigest(),'polynomial_helper_sha256':sha256(OLD.read_bytes()).hexdigest(),
            'prior_exact':[str(v) for v in prior],'K_pi_exact':str(prior[0]+2*prior[1]),'unit_evidence_exact':unit,
            'new_O_determinants':64,'reused_P_determinants':48,'rows':rows,'elapsed_seconds':time.perf_counter()-start}
    (HERE/'determinant-polynomials.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({key:output[key] for key in ('status','new_O_determinants','reused_P_determinants','elapsed_seconds')}))


if __name__=='__main__': main()
