"""Exact feedback memory, episode, and two-stage carrier calculations."""
from __future__ import annotations

from collections import Counter
from fractions import Fraction as F
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
from math import comb, prod
from pathlib import Path
import hashlib
import json
import platform
import sys
import time

HERE = Path(__file__).resolve().parent
HELPER = HERE.parent / 'learned-multilabel' / 'learned_multilabel_exact.py'
OLD = HERE.parent / 'kinetic-realization' / 'result.json'
SPEC = spec_from_file_location('feedback_exact_helpers', HELPER)
assert SPEC is not None and SPEC.loader is not None
MODULE = module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)  # Definitions only; the prior main is not run.
Radical, cast, moment = MODULE.Radical, MODULE.cast, MODULE.moment
EDGES = MODULE.EDGES


def from_record(value: dict[str, str | float]) -> Radical:
    return Radical(F(value['rational']), F(value['sqrt2']))


def matvec(matrix: list[list[Radical]], vector: list[Radical]) -> list[Radical]:
    return [sum((entry * value for entry, value in zip(row, vector)), cast(0)) for row in matrix]


def dot(left: list[Radical], right: list[Radical]) -> Radical:
    return sum((x * y for x, y in zip(left, right)), cast(0))


def encode_matrix(matrix: list[list[Radical]]) -> list[list[dict[str, str | float]]]:
    return [[value.record() for value in row] for row in matrix]


def main() -> dict[str, object]:
    started = time.perf_counter()
    zero, one = cast(0), cast(1)
    alpha_i, alpha_c = Radical(F(8), F(6)), Radical(F(1), F(1))
    old = json.loads(OLD.read_text(encoding='utf-8'))
    old_a = [from_record(value) for value in old['pair_moments']]
    channels = []
    data = {}
    filter_checks = 0
    for name, alpha in [('internal', alpha_i), ('cut', alpha_c)]:
        total = alpha + 2
        mu = alpha / total
        variance = moment(alpha, 1, 2) - mu**2
        lam = 1 / (total + 1)
        means = [(alpha + h) / (total + 1) for h in range(2)]
        seconds = [(alpha + h) * (alpha + h + 1) / ((total + 1) * (total + 2)) for h in range(2)]
        transition = [[1 - means[h], means[h]] for h in range(2)]
        emissions = [[[one - 2 * means[h] + seconds[h], means[h] - seconds[h]] for h in range(2)],
                     [[means[h] - seconds[h], seconds[h]] for h in range(2)]]
        stationary = [1 - mu, mu]
        assert (stationary[0] * transition[0][1]) == stationary[1] * transition[1][0]
        assert means[1] - means[0] == lam
        for h in range(2):
            assert sum(transition[h], zero) == one
            for dest in range(2):
                assert emissions[0][h][dest] + emissions[1][h][dest] == transition[h][dest]
                assert emissions[0][h][dest].sign() > 0
                assert emissions[1][h][dest].sign() > 0
        p_two_successes = dot(stationary, matvec(emissions[1], matvec(emissions[1], [one, one])))
        assert p_two_successes == mu**2 + lam * variance
        for theta in [zero, cast(F(1, 3)), one]:
            weights = [1 - theta, theta]
            m1, m2 = dot(weights, means), dot(weights, seconds)
            for outcome in range(2):
                row = [sum((weights[h] * emissions[outcome][h][dest] for h in range(2)), zero) for dest in range(2)]
                expected = m2 / m1 if outcome else (m1 - m2) / (1 - m1)
                assert row[1] / sum(row, zero) == expected
                filter_checks += 1
        lam_two = 2 / (total + 2)
        lam_two_degree_two = 2 / ((total + 2) * (total + 3))
        assert lam_two.sign() > 0 and (one - lam_two).sign() > 0
        assert (lam_two - lam_two_degree_two).sign() > 0
        for point in [F(0), F(1, 3), F(1)]:
            p = cast(point)
            weights = [comb(2, b) * p**b * (1-p)**(2-b) for b in range(3)]
            conditional_first = [(alpha+b)/(total+2) for b in range(3)]
            conditional_second = [(alpha+b)*(alpha+b+1)/((total+2)*(total+3)) for b in range(3)]
            assert dot(weights, conditional_first) == (alpha+2*p)/(total+2)
            assert dot(weights, conditional_second) == (alpha*(alpha+1)+4*(alpha+1)*p+2*p**2)/((total+2)*(total+3))
        # Each of the five (number of flags, successes) types is distinguished by its next-label mean.
        types = [(1,0),(1,1),(2,0),(2,1),(2,2)]
        type_means = [(alpha+s)/(total+t) for t,s in types]
        assert len(set(type_means)) == 5
        channels.append({'label_class':name, 'stationary_flag_success':mu.record(),
                         'transition':encode_matrix(transition), 'emission_zero':encode_matrix(emissions[0]),
                         'emission_one':encode_matrix(emissions[1]), 'nonconstant_eigenvalue':lam.record(),
                         'record_covariance_lag_one':(lam*variance).record(),
                         'rank_transport_record_covariance':variance.record(),
                         'two_full_flag_eigenvalues':[one.record(),lam_two.record(),lam_two_degree_two.record()],
                         'type_means':[{'flags':t,'successes':s,'mean':v.record()} for (t,s),v in zip(types,type_means)]})
        data[name] = (mu, means, transition, lam, lam_two)

    mu_i, means_i, _, _, _ = data['internal']
    mu_c, means_c, dc, lambda_max, bound_two = data['cut']
    cut_states = [(0,0),(0,1),(1,0)]
    cut_matrix = [[dc[left[0]][right[0]]*dc[left[1]][right[1]] for right in cut_states] for left in cut_states]
    cut_weights = [(1-mu_c)**2,(1-mu_c)*mu_c,mu_c*(1-mu_c)]
    internal_stay = means_i[1]**4
    vector = [one,one,one]
    consecutive = []
    for n in range(9):
        consecutive.append(mu_i**4 * internal_stay**n * dot(cut_weights,vector)**2)
        vector = matvec(cut_matrix,vector)
    assert consecutive[0] == old_a[1]
    assert consecutive[1] == old_a[2]
    assert (old_a[3]-consecutive[2]).sign() > 0
    flux = consecutive[0]-consecutive[1]
    assert flux == from_record(old['stationary_entrance_flux_per_tick'])
    mean = consecutive[0]/flux
    assert mean == from_record(old['mean_pair_episode_ticks_from_entrance'])
    survival = []
    for n in range(7):
        fresh = (consecutive[n]-consecutive[n+1])/flux
        previous = from_record(old['survival'][n]['entrance_survival'])
        assert fresh.sign() > 0
        if n==0:
            assert fresh==one
        if n==1:
            assert (fresh-previous).sign()>0
        survival.append({'additional_ticks':n,'feedback':fresh.record(),'rank_transport':previous.record(),'difference':(fresh-previous).record()})
    partition_row_gap=internal_stay*means_c[0]*(means_c[1]-means_c[0])*(1-means_c[0]**2)
    assert partition_row_gap.sign()>0
    episode_upper_two=1/((1-bound_two)*(1-consecutive[0]))

    # Enumerate only the finite panel carrier, not its 6541-by-6541 transition matrix.
    counts: Counter[tuple[tuple[int,int],...]] = Counter()
    raw_histories=0
    for first in product((0,1),repeat=8):
        bonds=tuple(first[2*edge]*first[2*edge+1] for edge in range(4))
        partition=MODULE.components(bonds)
        owner={node:block for block,nodes in enumerate(partition) for node in nodes}
        cuts=[edge for edge,(left,right) in enumerate(EDGES) if owner[left]!=owner[right]]
        for second in product((0,1),repeat=2*len(cuts)):
            values=[(1,value) for value in first]
            for index,edge in enumerate(cuts):
                for channel in range(2):
                    j=2*edge+channel
                    values[j]=(2,first[j]+second[2*index+channel])
            counts[tuple(values)]+=1
            raw_histories+=1
    assert raw_histories==28525
    assert len(counts)==6541
    by_cuts=Counter(sum(values[2*edge][0]==2 for edge in range(4)) for values in counts)
    assert dict(by_cuts)=={0:13,2:384,3:2048,4:4096}
    # Normalization as an identity in the degree-two Bernstein-product basis.
    coefficients: Counter[tuple[int,...]]=Counter()
    for values,multiplicity in counts.items():
        options=[(s,) if t==2 else (s,s+1) for t,s in values]
        for exponent in product(*options):
            coefficients[exponent]+=multiplicity
    expected={exponent:prod(comb(2,r) for r in exponent) for exponent in product(range(3),repeat=8)}
    assert dict(coefficients)==expected
    rows=[]
    for values,multiplicity in sorted(counts.items()):
        edge_types=[]
        for edge in range(4):
            t,sb=values[2*edge]
            tm,sm=values[2*edge+1]
            assert t==tm
            edge_types.append([t,sb,sm])
        rows.append({'edge_types':edge_types,'multiplicity':multiplicity})
    carrier={'edges':[list(edge) for edge in EDGES],'labels':['belief','model'],
             'encoding':'Each edge stores [number of sampled flags per label, belief successes, model successes]. Root/tree choices are separate normalized marks.',
             'rows':rows}
    carrier_path=HERE/'two-stage-count-carrier.json'
    carrier_path.write_text(json.dumps(carrier,separators=(',',':'))+'\n',encoding='utf-8')
    return {'status':'PASS','scope':'Exact one-panel response/filter/episode coefficients and two-stage count-carrier normalization; no dense two-stage transition or trajectory run.',
            'runtime':{'executable':sys.executable,'version':platform.python_version(),'platform':platform.platform()},
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'helper_sha256':hashlib.sha256(HELPER.read_bytes()).hexdigest(),
            'prior_result_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),
            'carrier_sha256':hashlib.sha256(carrier_path.read_bytes()).hexdigest(),
            'elapsed_seconds':time.perf_counter()-started,'channels':channels,'filter_update_checks':filter_checks,
            'one_panel_pair':{'restricted_cut_kernel':encode_matrix(cut_matrix),'stationary_occupancy':consecutive[0].record(),
                              'entrance_flux':flux.record(),'entrance_mean_ticks':mean.record(),'survival_comparison':survival,
                              'same_partition_next_pair_row_gap':partition_row_gap.record()},
            'two_stage_carrier':{'raw_flag_histories':raw_histories,'count_states':len(counts),
                                 'count_states_by_cut_edges':dict(by_cuts),'polynomial_coefficients_checked':len(expected),
                                 'generic_filter_probabilities':len(counts)-1,'full_column_rank_by_written_tensor_decomposition':len(counts)},
            'two_stage_contraction_bound':bound_two.record(),'two_stage_pair_episode_upper_bound_ticks':episode_upper_two.record(),
            'not_run':['previous scientific mains','ODE integration','sampling','dense two-stage transition matrix','pytest','GPU','Lean','tamper checks']}


if __name__=='__main__':
    result=main()
    (HERE/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
