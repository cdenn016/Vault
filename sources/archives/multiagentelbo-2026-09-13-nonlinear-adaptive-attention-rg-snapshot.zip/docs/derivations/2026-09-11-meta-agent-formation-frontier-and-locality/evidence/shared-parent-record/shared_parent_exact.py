"""Exact common-record evidence for an explicitly declared hierarchical Gaussian family."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import itertools
import json
from pathlib import Path
import platform
import sys
import time

HELPER = Path(__file__).parents[1]/'post-merge-bridge/gaussian_bridge_exact.py'
spec = importlib.util.spec_from_file_location('previous_matrix_definitions', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)  # Its guarded main is not called.
Matrix = list[list[F]]
B = helper.mat([[-1, 1, 0, 0], [0, -1, 1, 0], [0, 0, -1, 1], [1, 0, 0, -1]])
N = (8, 1, 8, 1)


def partitions(prefix: tuple[int, ...] = (0,)) -> list[tuple[int, ...]]:
    if len(prefix) == 4:
        return [prefix]
    return [result for label in range(max(prefix)+2)
            for result in partitions(prefix+(label,))]


def covariance(labels: tuple[int, ...], a: F, b: F, c: F) -> Matrix:
    r = [[F(labels[i] == k) for k in range(max(labels)+1)] for i in range(4)]
    h = helper.multiply(B, r)
    bb = helper.multiply(B, helper.transpose(B))
    hh = helper.multiply(h, helper.transpose(h))
    return [[a*bb[i][j]+b*hh[i][j]+c*F(i == j) for j in range(4)] for i in range(4)]


def moment(gamma: Matrix, powers: tuple[int, ...]) -> F:
    r"""Return E prod(p_e**powers_e) = det(I + Gamma diag(powers))**(-1)."""
    matrix = [[F(i == j)+gamma[i][j]*powers[j] for j in range(4)] for i in range(4)]
    d = helper.determinant(matrix)
    assert d > 0
    return 1/d


def evidence(gamma: Matrix) -> F:
    r"""Integrate prod(p_e**n_e*(1-p_e)); one failure at every original label."""
    result = sum(((-1)**sum(bits)*moment(gamma, tuple(n+s for n, s in zip(N, bits)))
                  for bits in itertools.product((0,1), repeat=4)), F(0))
    assert 0 < result < 1
    return result


def main() -> None:
    start = time.perf_counter()
    candidates = partitions()
    assert len(candidates) == len(set(candidates)) == 15
    rows = []
    fingerprints = {}
    identity = helper.eye(4)
    for labels in candidates:
        gamma = covariance(labels, F(1), F(1), F(1))
        # The covariance remains SPD because its independent-link contribution is I.
        for n in range(1,5):
            assert helper.determinant([row[:n] for row in gamma[:n]]) > 0
        one_channel = evidence(gamma)
        powers = list(itertools.product((0,1), repeat=4))
        fingerprints[labels] = tuple(moment(gamma, v) for v in powers)
        # A full observed panel is an independent check of record-kernel normalization.
        panel = []
        for outcomes in powers:
            failures = [i for i, success in enumerate(outcomes) if not success]
            probability = F(0)
            for subset in itertools.product((0,1), repeat=len(failures)):
                p = list(outcomes)
                for i, bit in zip(failures, subset):
                    p[i] += bit
                probability += (-1)**sum(subset)*moment(gamma, tuple(p))
            assert probability > 0
            panel.append(probability)
        assert sum(panel) == 1
        blocks = [[i for i, label in enumerate(labels) if label == k]
                  for k in range(max(labels)+1)]
        rows.append({'partition': blocks, 'restricted_growth_labels': list(labels),
                     'residual_covariance': [[str(v) for v in row] for row in gamma],
                     'one_channel_evidence': str(one_channel),
                     'two_channel_evidence': str(one_channel**2),
                     'two_channel_evidence_float': float(one_channel**2),
                     'one_panel_probabilities': [str(v) for v in panel],
                     'record_moment_fingerprint': [str(v) for v in fingerprints[labels]],
                     'explicit_tree_sample_coordinates': 36+4*len(blocks)})
    groups = {}
    for labels, signature in fingerprints.items():
        groups.setdefault(signature, []).append(list(labels))
    # An all-child parent has no inter-block contrast; singleton blocks combine a+b.
    assert covariance((0,0,0,0), F(1), F(1), F(1)) == covariance((0,0,0,0), F(1), F(17), F(1))
    assert covariance((0,1,2,3), F(1), F(1), F(1)) == covariance((0,1,2,3), F(1,2), F(3,2), F(1))
    assert helper.multiply(B, helper.mat([[1],[1],[1],[1]])) == helper.mat([[0]]*4)
    rows.sort(key=lambda row: F(row['two_channel_evidence']), reverse=True)
    best = F(rows[0]['two_channel_evidence'])
    reference = next(F(row['two_channel_evidence']) for row in rows if len(row['partition']) == 1)
    for row in rows:
        row['evidence_ratio_to_single_block'] = str(F(row['two_channel_evidence'])/reference)
    result = {'status':'PASS', 'runtime':sys.executable, 'python':platform.python_version(),
              'command':[sys.executable, '-I', '-B', str(Path(__file__).resolve())],
              'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
              'helper_sha256':sha256(HELPER.read_bytes()).hexdigest(),
              'model':'New source-motivated hierarchical prior; unchanged labeled record evaluator.',
              'parameters':{'a_child_variance':'1','b_block_variance':'1','c_link_variance':'1',
                            'v_root_variance':'any positive value; cancels analytically'},
              'success_counts_per_channel':list(N), 'failures_per_label':1,
              'candidate_count':15, 'partition_prior':'Not selected; evidence and ratios only.',
              'rows':rows, 'maximizers':[row['partition'] for row in rows if F(row['two_channel_evidence']) == best],
              'distinct_one_panel_laws':len(groups),
              'one_panel_equivalence_classes':list(groups.values()),
              'root_information':'Zero for the common translation root, proved by B*1=0 and independence.',
              'not_run':['previous helper main','parameter search','posterior fitting','sampling','ODE integration',
                         'pytest','GPU','Lean','tamper checks'],
              'elapsed_seconds':time.perf_counter()-start}
    Path(__file__).with_name('result.json').write_text(json.dumps(result, indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','candidate_count','maximizers','distinct_one_panel_laws','elapsed_seconds')},indent=2))
    for row in rows:
        print(row['partition'], row['two_channel_evidence_float'])


if __name__ == '__main__':
    main()
