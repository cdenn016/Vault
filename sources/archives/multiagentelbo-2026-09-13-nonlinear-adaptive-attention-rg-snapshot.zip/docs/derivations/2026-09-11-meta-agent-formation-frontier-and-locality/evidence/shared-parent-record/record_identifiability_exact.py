"""Reconstruct covariance from saved record moments and check ancestry spectral identities."""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from math import isqrt
from pathlib import Path
import sys
import time

folder = Path(__file__).parent
helper_path = folder.parent/'post-merge-bridge/gaussian_bridge_exact.py'
spec = importlib.util.spec_from_file_location('matrix_definitions', helper_path)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
Matrix = list[list[F]]


def add(a: Matrix, b: Matrix, coefficient: F = F(1)) -> Matrix:
    return [[x+coefficient*y for x,y in zip(row_a,row_b)] for row_a,row_b in zip(a,b)]


def sqrt_fraction(x: F) -> F:
    a,b = isqrt(x.numerator),isqrt(x.denominator)
    assert a*a == x.numerator and b*b == x.denominator
    return F(a,b)


def main() -> None:
    start = time.perf_counter()
    source_path = folder/'result.json'
    source = json.loads(source_path.read_text(encoding='utf-8'))
    assert source['status'] == 'PASS'
    identity = h.eye(4)
    center = [[F(i == j)-F(1,4) for j in range(4)] for i in range(4)]
    constant = [[F(1,4)]*4 for _ in range(4)]
    b = h.mat([[-1,1,0,0],[0,-1,1,0],[0,0,-1,1],[1,0,0,-1]])
    pinv = h.multiply(h.inverse(add(h.multiply(h.transpose(b),b),constant)),h.transpose(b))
    assert h.multiply(pinv,b) == center
    zero = h.mat([[0]*4]*4)
    results = []
    for row in source['rows']:
        moments = {bits:F(value) for bits,value in zip(product((0,1),repeat=4),row['record_moment_fingerprint'])}
        def moment(indices: tuple[int, ...]) -> F:
            return moments[tuple(int(i in indices) for i in range(4))]
        diagonal = [1/moment((i,)) for i in range(4)]
        squares = {(i,j):diagonal[i]*diagonal[j]-1/moment((i,j)) for i in range(4) for j in range(i+1,4)}
        gamma = [[F(0) for _ in range(4)] for _ in range(4)]
        for i in range(4):
            gamma[i][i] = diagonal[i]-1
        for i,j in ((0,1),(1,2),(2,3),(0,3)):
            gamma[i][j] = gamma[j][i] = -sqrt_fraction(squares[(i,j)])
        for i,j,k in ((0,1,2),(1,2,3)):
            numerator = (1/moment((i,j,k))-diagonal[i]*diagonal[j]*diagonal[k]
                         +diagonal[i]*squares[(j,k)]+diagonal[j]*squares[(i,k)]
                         +diagonal[k]*squares[(i,j)])
            gamma[i][k] = gamma[k][i] = numerator/(2*gamma[i][j]*gamma[j][k])
        expected = [[F(value) for value in line] for line in row['residual_covariance']]
        assert gamma == expected
        c = sum(gamma[0])
        assert all(sum(line) == c for line in gamma)
        m = h.multiply(h.multiply(pinv,add(gamma,identity,-c)),h.transpose(pinv))
        labels = row['restricted_growth_labels']
        k = [[F(labels[i] == labels[j]) for j in range(4)] for i in range(4)]
        centered_k = h.multiply(h.multiply(center,k),center)
        assert m == add(center,centered_k)  # Saved a=b=1, not a parameter fit.
        sizes = sorted(len(block) for block in row['partition'])
        if len(sizes) == 1:
            assert centered_k == zero
            spectrum = ['0','0','0']
        elif len(sizes) == 2:
            eigenvalue = F(sizes[0]*sizes[1],2)
            assert h.multiply(centered_k,centered_k) == [[eigenvalue*x for x in line] for line in centered_k]
            assert sum(centered_k[i][i] for i in range(4)) == eigenvalue
            spectrum = ['0','0',str(eigenvalue)]
        elif len(sizes) == 3:
            assert h.multiply(h.multiply(centered_k,add(centered_k,center,F(-1))),add(centered_k,center,F(-3,2))) == zero
            assert sum(centered_k[i][i] for i in range(4)) == F(5,2)
            squared = h.multiply(centered_k,centered_k)
            assert sum(squared[i][i] for i in range(4)) == F(13,4)
            pair = next(block for block in row['partition'] if len(block) == 2)
            difference = [[F(i == pair[0])-F(i == pair[1])] for i in range(4)]
            assert h.multiply(centered_k,difference) == h.mat([[0]]*4)
            spectrum = ['0','1','3/2']
        else:
            assert centered_k == center
            spectrum = ['1','1','1']
        results.append({'partition':row['partition'],'centered_partition_spectrum':spectrum,
                        'covariance_reconstruction':'exact equality'})
    output = {'status':'PASS','runtime':sys.executable,
              'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
              'source_result_sha256':sha256(source_path.read_bytes()).hexdigest(),
              'helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),
              'scope':'Finite reconstruction and polynomial identities; universal identifiability follows from the written proof.',
              'rows':results,'nonendpoint_partitions':13,
              'endpoint_equivalence':'All-one-block and all-singleton record-law families coincide when a and b can vary independently.',
              'elapsed_seconds':time.perf_counter()-start,
              'not_run':['previous science mains','parameter fit','parameter search','sampling','ODE','pytest','Lean','tamper checks']}
    (folder/'identifiability-result.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:output[key] for key in ('status','nonendpoint_partitions','endpoint_equivalence','elapsed_seconds')},indent=2))


if __name__ == '__main__':
    main()
