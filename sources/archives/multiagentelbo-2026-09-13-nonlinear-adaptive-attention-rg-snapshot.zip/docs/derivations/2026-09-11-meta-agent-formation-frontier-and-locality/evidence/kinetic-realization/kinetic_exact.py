"""Exact equilibrium episode and response checks for the declared kinetic realization."""
from __future__ import annotations

from fractions import Fraction as F
from importlib.util import module_from_spec, spec_from_file_location
from math import comb
from pathlib import Path
import hashlib
import json
import platform
import sys
import time

HERE = Path(__file__).resolve().parent
HELPER = HERE.parent / 'learned-multilabel' / 'learned_multilabel_exact.py'
SPEC = spec_from_file_location('retained_labeled_helpers', HELPER)
assert SPEC is not None and SPEC.loader is not None
MODULE = module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)  # Guarded definitions only; no prior main is called.
Radical, cast, moment = MODULE.Radical, MODULE.cast, MODULE.moment


def main() -> dict[str, object]:
    started = time.perf_counter()
    zero, one = cast(0), cast(1)
    alpha_i = Radical(F(8), F(6))
    alpha_c = Radical(F(1), F(1))

    def mi(k: int) -> Radical:
        return moment(alpha_i, 1, k)

    def mc(k: int) -> Radical:
        return moment(alpha_c, 1, k)

    def cut(k: int, probe: bool = False) -> Radical:
        r"""Return E[(1-p_b p_m)^k p_b^probe] on one cut edge."""
        return sum(((-1)**r * comb(k, r) * mc(r + int(probe)) * mc(r)
                    for r in range(k + 1)), zero)

    def ak(k: int) -> Radical:
        r"""Return A_k = E[s(p)^k] for the exact pair-membership row."""
        return mi(k)**4 * cut(k)**2

    def ck(k: int, internal: bool) -> Radical:
        r"""Return E[p_j s(p)^k] for one original external label."""
        if internal:
            return mi(k + 1) * mi(k)**3 * cut(k)**2
        return mi(k)**4 * cut(k, True) * cut(k)

    moments = [ak(k) for k in range(9)]
    assert moments[0] == one
    assert moments[1] == Radical(F(384, 2401), F(256, 2401))
    assert all((moments[k] - moments[k + 1]).sign() > 0 for k in range(8))
    flux = moments[1] - moments[2]
    mean = moments[1] / flux
    assert mean.sign() > 0
    assert (mean - one).sign() > 0
    survival = []
    response = []
    for elapsed in range(7):
        denominator = moments[elapsed + 1] - moments[elapsed + 2]
        entrance = denominator / flux
        occupancy = moments[elapsed + 1] / moments[1]
        assert entrance.sign() > 0 and occupancy.sign() > 0
        if elapsed:
            assert (occupancy - entrance).sign() > 0
        else:
            assert entrance == occupancy == one
        survival.append({'additional_ticks': elapsed,
                         'entrance_survival': entrance.record(),
                         'occupancy_survival': occupancy.record()})
        row = {'additional_ticks': elapsed}
        for label, internal in [('internal_label', True), ('cut_label', False)]:
            prediction = (ck(elapsed + 1, internal) - ck(elapsed + 2, internal)) / denominator
            assert prediction.sign() > 0 and (one - prediction).sign() > 0
            row[label] = prediction.record()
        response.append(row)
    # Finite survival sum telescopes with its exact positive remainder.
    subtotal = sum(((moments[k + 1] - moments[k + 2]) / flux for k in range(7)), zero)
    assert mean - subtotal == moments[8] / flux
    assert (mean - subtotal).sign() > 0

    response_drift = []
    for label, internal in [('internal_label', True), ('cut_label', False)]:
        initial = (ck(1, internal) - ck(2, internal)) / flux
        after_one = (ck(2, internal) - ck(3, internal)) / (moments[2] - moments[3])
        drift = after_one - initial
        assert drift.sign() == (1 if internal else -1)
        response_drift.append({'label': label, 'one_survived_tick_prediction_change': drift.record()})

    record_only = []
    for label, alpha in [('internal_label', alpha_i), ('cut_label', alpha_c)]:
        first, second = moment(alpha, 1, 1), moment(alpha, 1, 2)
        variance = second - first**2
        assert variance.sign() > 0
        after_success = second / first
        after_failure = (first - second) / (one - first)
        assert after_success == (alpha + 1) / (alpha + 3)
        assert after_failure == alpha / (alpha + 3)
        assert (after_success - first).sign() > 0
        assert (first - after_failure).sign() > 0
        record_only.append({'label': label, 'prior_success': first.record(),
                            'two_successes': second.record(),
                            'success_covariance': variance.record(),
                            'next_after_success': after_success.record(),
                            'next_after_failure': after_failure.record()})

    # Native (alpha,beta,u)=(1,1,1), n=1: nonzero rank-transport velocity.
    alpha_dot = F(1) + 1 - 1
    beta_dot = F(1) - 1
    u_dot = F(1) - (F(1) + F(1, 2))
    # F_a(1/2) = 1/4 - (3/4) log(2), F_p(1/2)=1.
    # Integral_1^2 dx/x > 1/2 supplies an exact strict positive lower bound.
    p_dot_lower = alpha_dot * (F(3, 4) * F(1, 2) - F(1, 4))
    assert alpha_dot == 1 and beta_dot == 0 and u_dot == F(-1, 2)
    assert p_dot_lower == F(1, 8) > 0

    return {'status': 'PASS', 'scope': 'Exact equilibrium episode moments, original-label forecasts, and one native velocity coefficient; no ODE trajectory or general proof certificate.',
            'runtime': {'executable': sys.executable, 'version': platform.python_version(), 'platform': platform.platform()},
            'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'helper_sha256': hashlib.sha256(HELPER.read_bytes()).hexdigest(),
            'elapsed_seconds': time.perf_counter() - started,
            'pair_moments': [v.record() for v in moments],
            'stationary_pair_occupancy': moments[1].record(),
            'stationary_entrance_flux_per_tick': flux.record(),
            'mean_pair_episode_ticks_from_entrance': mean.record(),
            'survival': survival, 'episode_conditioned_response': response,
            'episode_response_drift': response_drift, 'record_only_response': record_only,
            'native_velocity_witness': {'alpha_dot': str(alpha_dot), 'beta_dot': str(beta_dot), 'u_dot': str(u_dot), 'p_dot': '(3 log(2)-1)/4', 'strict_lower_bound': str(p_dot_lower)},
            'not_run': ['prior helper main', 'ODE integration', 'sampling experiment', 'pytest', 'GPU', 'Lean', 'tamper checks']}


if __name__ == '__main__':
    result = main()
    (HERE / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
