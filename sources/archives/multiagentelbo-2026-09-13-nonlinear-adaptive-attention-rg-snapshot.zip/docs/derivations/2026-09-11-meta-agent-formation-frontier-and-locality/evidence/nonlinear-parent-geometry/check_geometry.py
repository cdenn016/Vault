"""Exact rational geometry checks for the compact nonlinear two-stage parents."""

from __future__ import annotations

import json
from pathlib import Path

import sympy as sp


def encoded(matrix: sp.Matrix) -> list[list[str]]:
    return [[str(value) for value in row] for row in matrix.tolist()]


def main() -> None:
    B_f = sp.Matrix([
        [1, 0, 0, -1, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, -1, 0, 0, 0, 0, 0],
        [0, 0, 1, 0, 0, -1, 0, 0, 0, 0],
        [1, -1, 0, 0, 0, 0, -1, 0, 0, 0],
        [0, 0, 0, 1, -1, 0, 0, 0, -1, 0],
    ])
    B_s = sp.Matrix([
        [0, 1, -1, 0, 0, 0, 0, -1, 0, 0],
        [0, 0, 0, 0, 1, -1, 0, 0, 0, -1],
    ])
    C = B_f * B_f.T
    R = B_f.T * C.inv()
    P = sp.eye(10) - R * B_f
    A = B_s * R
    Gamma = B_s * P * B_s.T
    L_2 = P * B_s.T * Gamma.inv()
    P_2 = P - L_2 * B_s * P
    E_0 = sp.Matrix([
        [1, 0, 0], [0, 1, 0], [0, 0, 1],
        [1, 0, 0], [0, 1, 0], [0, 0, 1],
        [1, -1, 0], [0, 1, -1],
        [1, -1, 0], [0, 1, -1],
    ])
    G_0 = E_0.T * E_0
    checks = {
        "BfR_identity": B_f * R == sp.eye(5),
        "BfL2_zero": B_f * L_2 == sp.zeros(5, 2),
        "BsL2_identity": B_s * L_2 == sp.eye(2),
        "orthogonal_splits": R.T * L_2 == sp.zeros(5, 2),
        "L2_gram_Gamma_inverse": L_2.T * L_2 == Gamma.inv(),
        "BfE0_zero": B_f * E_0 == sp.zeros(5, 3),
        "BsE0_zero": B_s * E_0 == sp.zeros(2, 3),
        "P2_E0_projector": P_2 == E_0 * G_0.inv() * E_0.T,
        "P2_symmetric": P_2.T == P_2,
        "P2_idempotent": P_2 * P_2 == P_2,
        "cross_covariance_nonzero": (A * A.T)[0, 1] != 0,
    }
    assert all(checks.values())
    output = {
        "arithmetic": "exact SymPy rational matrices; no numerical dynamics",
        "B_f": encoded(B_f), "B_s": encoded(B_s),
        "C": encoded(C), "det_C": str(C.det()),
        "R": encoded(R), "A": encoded(A), "AA_transpose": encoded(A * A.T),
        "Gamma": encoded(Gamma), "Gamma_inverse": encoded(Gamma.inv()),
        "L_2": encoded(L_2), "E_0": encoded(E_0),
        "G_0": encoded(G_0), "G_0_inverse": encoded(G_0.inv()),
        "checks": checks,
    }
    output_path = Path(__file__).with_name("geometry-results.json")
    output_path.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(f"{sum(checks.values())} exact checks passed; {output_path}")


if __name__ == "__main__":
    main()
