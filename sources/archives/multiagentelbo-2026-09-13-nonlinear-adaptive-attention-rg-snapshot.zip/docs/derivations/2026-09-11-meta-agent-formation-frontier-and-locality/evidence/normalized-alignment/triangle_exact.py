"""Exact Gaussian control for latent translation-link alignment; no sampling."""
from fractions import Fraction as F
from pathlib import Path
import json
import sys

Matrix = list[list[F]]


def transpose(a: Matrix) -> Matrix:
    return [list(row) for row in zip(*a)]


def mul(a: Matrix, b: Matrix) -> Matrix:
    return [[sum((a[i][k] * b[k][j] for k in range(len(b))), F(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def add(a: Matrix, b: Matrix, factor: F = F(1)) -> Matrix:
    return [[x + factor * y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def inverse(a: Matrix) -> Matrix:
    n = len(a)
    rows = [[F(v) for v in row] + [F(i == j) for j in range(n)] for i, row in enumerate(a)]
    for j in range(n):
        pivot = next(i for i in range(j, n) if rows[i][j])
        rows[j], rows[pivot] = rows[pivot], rows[j]
        denominator = rows[j][j]
        rows[j] = [v / denominator for v in rows[j]]
        for i in range(n):
            if i != j:
                factor = rows[i][j]
                rows[i] = [v - factor * u for v, u in zip(rows[i], rows[j])]
    return [row[n:] for row in rows]


def determinant(a: Matrix) -> F:
    rows = [[F(v) for v in row] for row in a]
    answer = F(1)
    for j in range(len(rows)):
        pivot = next(i for i in range(j, len(rows)) if rows[i][j])
        if pivot != j:
            rows[j], rows[pivot] = rows[pivot], rows[j]
            answer *= -1
        value = rows[j][j]
        answer *= value
        for i in range(j + 1, len(rows)):
            factor = rows[i][j] / value
            rows[i] = [v - factor * u for v, u in zip(rows[i], rows[j])]
    return answer


def trace(a: Matrix) -> F:
    return sum((row[i] for i, row in enumerate(a)), F(0))


def quadratic(a: Matrix, x: Matrix) -> F:
    return mul(mul(transpose(x), a), x)[0][0]


def encoded(a: Matrix) -> list[list[str]]:
    return [[str(x) for x in row] for row in a]


def main() -> None:
    r"""Check pi_s=N((J0+s B^T W B)^-1 h0,(J0+s B^T W B)^-1)."""
    B = [[F(v) for v in row] for row in
         [[1, -1, 0, -1, 0, 0], [0, 1, -1, 0, -1, 0], [-1, 0, 1, 0, 0, -1]]]
    W = [[F((i + 1) if i == j else 0) for j in range(3)] for i in range(3)]
    J0 = [[F((i + 1) if i == j else 0) for j in range(6)] for i in range(6)]
    C0 = inverse(J0)
    mu0 = [[F(v)] for v in [0, 0, 0, 1, 0, 0]]
    h0 = mul(J0, mu0)
    L = mul(mul(transpose(B), W), B)
    cycle = [[F(v) for v in [0, 0, 0, 1, 1, 1]]]
    rows = []
    previous = None
    for strength in [0, 1, 4, 16, 64]:
        J = add(J0, L, F(strength))
        C = inverse(J)
        mu = mul(C, h0)
        mean_energy = (trace(mul(L, C)) + quadratic(L, mu)) / 2
        LC = mul(L, C)
        variance_energy = trace(mul(LC, LC)) / 2 + quadratic(mul(mul(L, C), L), mu)
        C_dot = mul(mul(C, L), C)
        mu_dot_negative = mul(mul(C, L), mu)
        derivative_energy = -trace(mul(L, C_dot)) / 2 - mul(mul(transpose(mu), L), mu_dot_negative)[0][0]
        assert derivative_energy == -variance_energy < 0
        if previous is not None:
            assert mean_energy < previous
        previous = mean_energy
        rows.append({
            'strength': strength,
            'expected_total_kl': str(mean_energy),
            'minus_strength_derivative': str(-derivative_energy),
            'variance_total_kl': str(variance_energy),
            'cycle_mean': str(mul(cycle, mu)[0][0]),
            'cycle_variance': str(mul(mul(cycle, C), transpose(cycle))[0][0]),
            'determinant_ratio': str(determinant(J0) / determinant(J)),
            'evidence_exponent': str((quadratic(C, h0) - quadratic(J0, mu0)) / 2),
        })
    residual_C0 = mul(mul(B, C0), transpose(B))
    gain = mul(mul(C0, transpose(B)), inverse(residual_C0))
    C_limit = add(C0, mul(mul(gain, B), C0), F(-1))
    mu_limit = add(mu0, mul(mul(gain, B), mu0), F(-1))
    assert all(v == 0 for row in mul(B, C_limit) for v in row)
    assert all(v == 0 for row in mul(B, mu_limit) for v in row)
    assert mul(cycle, mu_limit)[0][0] == 0
    assert mul(mul(cycle, C_limit), transpose(cycle))[0][0] == 0
    incidence = [row[:3] for row in B]
    graph_L = mul(mul(transpose(incidence), W), incidence)
    reduced_L = [row[1:] for row in graph_L[1:]]
    assert determinant(reduced_L) == 11
    assert determinant(W) * 2**2 * determinant(reduced_L) == 264
    result = {
        'scope': 'Exact finite Gaussian control on three law means and three independent translation links; fixed unit law variance. Not saved-data replay or a formation experiment.',
        'runtime': sys.version, 'executable': sys.executable,
        'edge_order': ['1<-2', '2<-3', '3<-1'],
        'weights': [1, 2, 3], 'prior_precision_diagonal': [1, 2, 3, 4, 5, 6],
        'prior_mean': [0, 0, 0, 1, 0, 0],
        'evidence_formula': 'Z_s = sqrt(determinant_ratio) * exp(evidence_exponent)',
        'rows': rows,
        'limit_mean': encoded(mu_limit), 'limit_covariance': encoded(C_limit),
        'limit_residual_mean_and_covariance_zero': True,
        'limit_cycle_mean_and_variance_zero': True,
        'free_variance_three_node_normal_hessian_determinant': '264 * exp(-6 s)',
        'all_assertions_passed': True,
    }
    Path(__file__).with_name('triangle-exact-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'rows': rows, 'limit_mean': encoded(mu_limit), 'checks_passed': True}, indent=2))


if __name__ == '__main__':
    main()
