"""Exact coefficient check for the Gaussian prior after three-node alignment."""
from fractions import Fraction as F
from pathlib import Path
import json
import runpy
import sys


def main() -> None:
    r"""Check R^T J0 R and the entropy information shift E e_s."""
    support = runpy.run_path(str(Path(__file__).with_name('triangle_exact.py')))
    mul, transpose = support['mul'], support['transpose']
    inverse, determinant = support['inverse'], support['determinant']
    R = [[F(v) for v in row] for row in [
        [1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0],
        [0, 0, 0, 1], [0, 0, 0, 1], [0, 0, 0, 1],
        [1, -1, 0, 0], [0, 1, -1, 0], [-1, 0, 1, 0],
    ]]
    J0 = [[F(i + 1 if i == j else 0) for j in range(9)] for i in range(9)]
    J_retained = mul(mul(transpose(R), J0), R)
    C_retained = inverse(J_retained)
    h_entropy = [[F(v)] for v in [0, 0, 0, 3]]
    mean_retained = mul(C_retained, h_entropy)
    parent_indices = [0, 3]
    parent_C = [[C_retained[i][j] for j in parent_indices] for i in parent_indices]
    parent_mean = [mean_retained[i][0] for i in parent_indices]
    ratio_after_normal_hessian = determinant(J0) / determinant(J_retained) / 264
    exponent = mul(mul(transpose(h_entropy), C_retained), h_entropy)[0][0] / 2
    assert parent_mean == [F(0), F(1, 5)]
    assert parent_C == [[F(276, 1327), F(0)], [F(0), F(1, 15)]]
    assert ratio_after_normal_hessian == F(1008, 14597)
    assert exponent == F(3, 10)
    result = {
        'scope': 'Exact matrix coefficient check for the proved strong-agreement asymptotic parent; not a numerical integration of the nonlinear finite-strength model.',
        'runtime': sys.version, 'executable': sys.executable,
        'fine_coordinate_order': ['mu_1', 'mu_2', 'mu_3', 'log_sigma_1', 'log_sigma_2', 'log_sigma_3', 'a_12', 'a_23', 'a_31'],
        'fine_dimension': 9, 'coherent_dimension': 4, 'parent_dimension_after_internal_frame_integration': 2,
        'prior_precision_diagonal': list(range(1, 10)), 'prior_mean_zero': True,
        'normal_codimension': 5, 'normal_hessian_determinant': '264 * exp(-6 s)',
        'retained_precision': support['encoded'](J_retained),
        'entropy_information_shift': ['0', '0', '0', '3'],
        'parent_coordinate_order': ['mu_1', 's'],
        'parent_mean': [str(v) for v in parent_mean], 'parent_covariance': support['encoded'](parent_C),
        'evidence_asymptotic': 'Z_n ~ n^(-5/2) * sqrt(1008/14597) * exp(3/10)',
        'all_assertions_passed': True,
    }
    Path(__file__).with_name('gaussian-parent-exact-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
