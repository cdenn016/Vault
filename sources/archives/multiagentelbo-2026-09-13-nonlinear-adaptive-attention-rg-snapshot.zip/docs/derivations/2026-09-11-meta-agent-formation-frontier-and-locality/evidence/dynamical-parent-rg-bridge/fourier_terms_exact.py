"""Exact Fourier averages for the nonlinear parent bridge; no samples or simulation."""
from __future__ import annotations

import json
import platform
from fractions import Fraction
from pathlib import Path
from time import perf_counter

Exponent = tuple[int, ...]
Polynomial = dict[Exponent, Fraction]


def cosine(exponent: Exponent) -> Polynomial:
    """Return the Laurent representation of cos(exponent dot angles)."""
    return {exponent: Fraction(1, 2), tuple(-v for v in exponent): Fraction(1, 2)}


def add(left: Polynomial, right: Polynomial) -> Polynomial:
    """Add exact finite Laurent polynomials."""
    result = dict(left)
    for exponent, value in right.items():
        result[exponent] = result.get(exponent, Fraction()) + value
    return {exponent: value for exponent, value in result.items() if value}


def multiply(left: Polynomial, right: Polynomial) -> Polynomial:
    """Multiply exact finite Laurent polynomials."""
    result: Polynomial = {}
    for a, va in left.items():
        for b, vb in right.items():
            exponent = tuple(x + y for x, y in zip(a, b))
            result[exponent] = result.get(exponent, Fraction()) + va * vb
    return {exponent: value for exponent, value in result.items() if value}


def average(poly: Polynomial, hidden: tuple[int, ...]) -> Polynomial:
    """Integrate hidden angles against normalized Haar measure."""
    return {e: v for e, v in poly.items() if all(e[i] == 0 for i in hidden)}


def serialize(poly: Polynomial) -> list[dict[str, object]]:
    """Make exact rational coefficients JSON readable."""
    return [{"exponent": list(e), "coefficient": str(v)} for e, v in sorted(poly.items())]


def main() -> None:
    """Check the cycle and mixed-channel parent terms once."""
    started = perf_counter()
    # Coordinates: theta0, theta1, theta2, phi01, phi12, phi20.
    e0 = (1, -1, 0, -1, 0, 0)
    e1 = (0, 1, -1, 0, -1, 0)
    e2 = (-1, 0, 1, 0, 0, -1)
    terms = [cosine(e) for e in (e0, e1, e2)]
    total = add(add(terms[0], terms[1]), terms[2])
    square = average(multiply(total, total), (1, 2))
    cubic = average(multiply(multiply(total, total), total), (1, 2))
    second = {e: v / 2 for e, v in square.items()}
    third = {e: v / 6 for e, v in cubic.items()}
    zero = (0,) * 6
    loop = (0, 0, 0, -1, -1, -1)
    opposite_loop = tuple(-v for v in loop)
    assert average(total, (1, 2)) == {}
    assert second == {zero: Fraction(3, 4)}
    assert third == {loop: Fraction(1, 8), opposite_loop: Fraction(1, 8)}
    # Coordinates: theta1, psi1, theta2, psi2, phi_b, phi_m.
    b = cosine((-1, 0, 1, 0, -1, 0))
    m = cosine((0, -1, 0, 1, 0, -1))
    intra = cosine((0, 0, 1, -1, 0, 0))
    mixed = average(multiply(multiply(b, m), intra), (2, 3))
    retained = (-1, 1, 0, 0, -1, 1)
    assert mixed == {retained: Fraction(1, 8), tuple(-v for v in retained): Fraction(1, 8)}
    result = {
        "status": "passed",
        "arithmetic": "Python int and fractions.Fraction",
        "runtime": platform.python_version(),
        "checks": {
            "linear_cycle_average_zero": True,
            "quadratic_exponential_coefficient": serialize(second),
            "cubic_exponential_holonomy_coefficient": serialize(third),
            "mixed_channel_hidden_node_average": serialize(mixed),
        },
        "elapsed_seconds": perf_counter() - started,
        "scope": "Finite Fourier identities only; not a proof by simulation or a trajectory run.",
    }
    path = Path(__file__).with_name("fourier-terms-result.json")
    path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
