"""Exact second-level prior, parent agreement and native-response coefficients."""
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform
import sys
import time

sys.set_int_max_str_digits(200000)
folder = Path(__file__).parent
helper_path = folder.parent/'shared-parent-record/shared_parent_exact.py'
spec = importlib.util.spec_from_file_location('existing_record_definitions', helper_path)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)  # Definitions only; its guarded scientific main is not executed.
h = g.helper
Matrix = list[list[F]]
Key = tuple[tuple[F, ...], ...]
T_PARENT = [[F(1,2),F(1),F(1,2),F(0)], [F(1,2),F(0),F(1,2),F(1)]]


def add(a: Matrix, b: Matrix, factor: F = F(1)) -> Matrix:
    return [[x+factor*y for x, y in zip(aa, bb)] for aa, bb in zip(a, b)]


def key(matrix: Matrix) -> Key:
    return tuple(tuple(row) for row in matrix)


def trace_product(a: Matrix, b: Matrix) -> F:
    return sum((a[i][j]*b[j][i] for i in range(len(a)) for j in range(len(a))), F(0))


def quadratic(row: list[F], matrix: Matrix) -> F:
    return sum((row[i]*matrix[i][j]*row[j] for i in range(len(row)) for j in range(len(row))), F(0))


@lru_cache(maxsize=None)
def exponent_matrix(bits: tuple[int, ...], mask: int) -> tuple[Matrix, F]:
    r"""Return Q^(-1), det(Q), with Q = diag(n+bits)+sum t_e^T t_e."""
    q = [[F(g.N[i]+bits[i]) if i==j else F(0) for j in range(4)] for i in range(4)]
    for edge in range(2):
        if mask & (1<<edge):
            t = T_PARENT[edge]
            q = add(q, [[t[i]*t[j] for j in range(4)] for i in range(4)])
    return h.inverse(q), h.determinant(q)


@lru_cache(maxsize=None)
def shifted_integral(gamma_key: Key, mask: int) -> tuple[F, Matrix]:
    r"""Return one-channel shifted evidence and sum of its signed Delta matrices."""
    gamma = [list(row) for row in gamma_key]
    evidence = F(0)
    delta_sum = h.mat([[0]*4]*4)
    for bits in product((0,1), repeat=4):
        inv_q, det_q = exponent_matrix(bits, mask)
        s = add(gamma, inv_q)
        weight = F((-1)**sum(bits))/(det_q*h.determinant(s))
        evidence += weight
        delta_sum = add(delta_sum, h.inverse(s), -weight)
    assert evidence>0
    return evidence, delta_sum


def kernel_case(a: F, b: F, c: F, v: F) -> dict:
    r"""Check the conditional Gaussian reconstruction of first-parent geometry."""
    q = a+2*b
    variance_h = v+(q+c)/4
    tau = 4*c-c*c/variance_h
    assert q>0 and tau>0
    first = h.mat([[v+q/2,v,0,0],[v,v+q/2,0,0],[0,0,2*c,0],[0,0,0,2*c]])
    top = h.mat([[variance_h,0],[0,4*c]])
    mean = h.mat([[1-c/(4*variance_h),0],[1-c/(4*variance_h),0],[-c/(2*variance_h),F(1,2)],[c/(2*variance_h),F(1,2)]])
    lift = h.mat([[F(-1,2),F(1,4)],[F(1,2),F(1,4)],[0,F(1,2)],[0,F(-1,2)]])
    conditional = h.multiply(h.multiply(lift,h.mat([[q,0],[0,tau]])),h.transpose(lift))
    reconstructed = add(h.multiply(h.multiply(mean,top),h.transpose(mean)),conditional)
    assert reconstructed==first
    forward = h.mat([[F(1,2),F(1,2),F(-1,4),F(1,4)],[0,0,1,1]])
    assert h.multiply(h.multiply(forward,first),h.transpose(forward))==top
    assert h.multiply(forward,mean)==h.eye(2)
    assert h.multiply(forward,conditional)==h.mat([[0]*4]*2)
    return {'a':str(a),'b':str(b),'c':str(c),'v':str(v),'q':str(q),'h':str(variance_h),'tau':str(tau),
            'first_geometry_covariance':[[str(x) for x in row] for row in first],
            'conditional_mean_matrix':[[str(x) for x in row] for row in mean],
            'conditional_covariance':[[str(x) for x in row] for row in conditional],
            'original_internal_record_prior_success':str(1/(1+2*a))}


def main() -> None:
    start=time.perf_counter()
    source=folder.parent/'transported-parent-prior/result.json'
    data=json.loads(source.read_text(encoding='utf-8'))
    old_pair=next(r for r in data['rows'] if r['partition']==[[0,1],[2,3]])
    z=F(old_pair['evidence'])
    k=2
    incidence=[[F(i//2==j) for j in range(k)] for i in range(4)]
    j_map=h.multiply(g.B,incidence)
    ga=h.multiply(g.B,h.transpose(g.B))
    gb=h.multiply(j_map,h.transpose(j_map))
    counts=[16,8,16]
    moments=[F(0)]*3
    moment_numerators=[[F(0)]*3 for _ in range(3)]
    relative_second=F(0)
    details=[]
    for dec in old_pair['details']:
        gamma=[[F(x) for x in row] for row in dec['Gamma']]
        c_map=[[F(x) for x in row] for row in dec['C']]
        gc=h.multiply(c_map,h.transpose(c_map))
        grams=[ga,gb,gc]
        a_full=[g.B[i]+j_map[i]+[-x for x in c_map[i]]+[F(0)] for i in range(4)]
        parent_rows=[h.mat([[F(-1,2),F(-1,2),F(1,2),F(1,2),-1,1]])[0]+[-x for x in c_map[1]]+[F(0)],
                     h.mat([[F(1,2),F(1,2),F(-1,2),F(-1,2),1,-1]])[0]+[-x for x in c_map[3]]+[F(0)]]
        assert h.multiply(T_PARENT,a_full)==parent_rows
        e0,delta0=shifted_integral(key(gamma),0)
        assert e0==F(dec['one_channel_evidence'])
        base_means=[F(d)+4*trace_product(gj,delta0)/e0 for d,gj in zip(counts,grams)]
        assert base_means==[F(d)*F(m) for d,m in zip(counts,dec['M_energy_coordinates'])]
        cross=[F(0),F(3),F(0),F(-3)]
        relative_second+=(3*e0*e0+e0*quadratic(cross,delta0))/len(old_pair['details'])/z
        row={'roots':dec['roots'],'trees':dec['trees'],'shifted':[]}
        for position,mask in enumerate((1,2,3)):
            e,delta=shifted_integral(key(gamma),mask)
            assert e<e0
            weighted=e*e
            energy=[e*(d*e+4*trace_product(gj,delta)) for d,gj in zip(counts,grams)]
            assert min(energy)>0
            moments[position]+=weighted/len(old_pair['details'])/z
            moment_numerators[position]=[u+w/len(old_pair['details']) for u,w in zip(moment_numerators[position],energy)]
            row['shifted'].append({'mask':mask,'one_channel_integral':str(e),'joint_energy_numerator':[str(x) for x in energy]})
        details.append(row)
    first,second,both=moments
    flags=[1-first-second+both,first-both,second-both,both]
    assert min(flags)>0 and sum(flags)==1
    merge=first+second-both
    weighted_energy=[(moment_numerators[0][j]+moment_numerators[1][j]-moment_numerators[2][j])/z for j in range(3)]
    base_means=[F(d)*F(m) for d,m in zip(counts,old_pair['posterior_M_energy_coordinates'])]
    covariance=[n-merge*m for n,m in zip(weighted_energy,base_means)]
    derivative=[-v/2 for v in covariance]
    assert relative_second>0
    velocities=[]
    for original in data['rows']:
        deficit=[1-F(x) for x in original['posterior_M_energy_coordinates']]
        assert deficit[0]>0 and deficit[2]>0 and deficit[1]>=0
        evidence=F(original['evidence'])
        u=evidence*(derivative[0]*deficit[0]+derivative[2]*deficit[2])
        v=evidence*derivative[1]*original['k']*deficit[1]
        velocities.append({'partition':original['partition'],'k':original['k'],'evidence':evidence,'deficit':deficit,'u':u,'v':v})
    coefficients=[]
    matrix_coefficients=[]
    for i,ri in enumerate(velocities):
        for j in range(i,len(velocities)):
            rj=velocities[j]
            value=ri['u']*ri['k']+ri['v'] if i==j else ri['u']*rj['k']+rj['u']*ri['k']+ri['v']+rj['v']
            coefficients.append({'indices':[i,j],'coefficient':str(value),'sign':(value>0)-(value<0)})
            matrix_coefficients.append(value if i==j else value/2)
    all_positive=min(matrix_coefficients)>0
    all_negative=max(matrix_coefficients)<0
    bound=None
    maximum_denominator=4*max(row['evidence'] for row in velocities)
    if all_positive:
        bound=min(matrix_coefficients)/maximum_denominator
    elif all_negative:
        bound=max(matrix_coefficients)/maximum_denominator
    min_a=min(row['deficit'][0] for row in velocities)
    min_c=min(row['deficit'][2] for row in velocities)
    h_speed_lower=(min_a+min_c)/4
    prior_fisher_speed_lower=h_speed_lower*h_speed_lower/2+2*min_c*min_c
    cases=[kernel_case(F(1),F(1),F(1),F(1)),kernel_case(F(3,2),F(3,4),F(1),F(1))]
    assert cases[0]['first_geometry_covariance']==cases[1]['first_geometry_covariance']
    assert cases[0]['conditional_covariance']==cases[1]['conditional_covariance']
    assert cases[0]['original_internal_record_prior_success']=='1/3'
    assert cases[1]['original_internal_record_prior_success']=='1/4'
    full_fisher=h.mat([[8,0,0],[0,4,0],[0,0,8]])
    transform=h.mat([[1,0,0],[F(-1,2),F(1,2),0],[0,0,1]])
    transformed=h.multiply(h.multiply(h.transpose(transform),full_fisher),transform)
    assert transformed==h.mat([[9,-1,0],[-1,1,0],[0,0,8]])
    dh=[F(1,4),F(1,2),F(1,4)]
    top_fisher=[[dh[i]*dh[j]/2+2*F(i==2 and j==2) for j in range(3)] for i in range(3)]
    direction=[F(2),F(-1),F(0)]
    assert quadratic(direction,top_fisher)==0 and quadratic(direction,full_fisher)==36
    result={'status':'PASS','runtime':sys.executable,'python':platform.python_version(),'command':[sys.executable,'-I','-B',str(Path(__file__).resolve())],
            'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'source_sha256':sha256(source.read_bytes()).hexdigest(),
            'helper_sha256':sha256(helper_path.read_bytes()).hexdigest(),'matrix_helper_sha256':sha256(g.HELPER.read_bytes()).hexdigest(),
            'scope':'Current transported pair ancestry with all four roots, original observations unchanged; three native velocity coefficients remain symbolic in the full twelve-ancestry prior. No prior or trajectory is selected.',
            'pair_decorations':len(details),'conditional_flag_outcomes':['00','10','01','11'],'conditional_flag_probabilities':[str(v) for v in flags],
            'conditional_flag_probabilities_float':[float(v) for v in flags],'merge_probability':str(merge),'merge_probability_float':float(merge),
            'merge_greater_than_one_half':merge>F(1,2),'merge_precision_gradient':[str(v) for v in derivative],'merge_precision_gradient_float':[float(v) for v in derivative],
            'merge_energy_covariances':[str(v) for v in covariance],
            'native_second_derivative_quadratic_coefficients':coefficients,
            'native_second_derivative_coefficients_all_positive':all_positive,'native_second_derivative_coefficients_all_negative':all_negative,
            'native_second_derivative_uniform_bound':str(bound) if bound is not None else None,'native_second_derivative_uniform_bound_float':float(bound) if bound is not None else None,
            'prior_coefficient_order':[row['partition'] for row in velocities],
            'relative_parent_prior_variance_per_coordinate':'3','relative_parent_recognition_second_moment_per_coordinate':str(relative_second),
            'relative_parent_recognition_second_moment_float':float(relative_second),'naive_gaussian_downward_variance_error':str(3-relative_second),
            'second_prior_learning_bounds':{'minimum_a_decrease':str(min_a),'minimum_c_decrease':str(min_c),'minimum_h_decrease':str(h_speed_lower),'conditional_second_prior_fisher_speed_squared_lower_bound':str(prior_fisher_speed_lower),'conditional_second_prior_fisher_speed_squared_lower_bound_float':float(prior_fisher_speed_lower)},
            'kernel_and_counterexample_cases':cases,'transformed_full_fisher_at_unit':[[str(v) for v in row] for row in transformed],
            'gaussian_geometry_fisher_null_direction':[str(v) for v in direction],'full_fisher_norm_squared_in_that_direction':'36',
            'details':details,'integral_cache':{'distinct_covariance_and_shift_pairs':shifted_integral.cache_info().misses,'gaussian_terms':16*shifted_integral.cache_info().misses,'distinct_exponent_matrices':exponent_matrix.cache_info().misses},
            'elapsed_seconds':time.perf_counter()-start,
            'not_run':['sampling','new observations','new parent likelihood or prior tilt','numerical ancestry prior','ODE','fitting','parameter search','GPU','test suite','Lean','tamper checks','previous scientific mains','full 496-term evaluation']}
    (folder/'second-level-response.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','pair_decorations','merge_probability_float','merge_greater_than_one_half','merge_precision_gradient_float','native_second_derivative_coefficients_all_positive','native_second_derivative_coefficients_all_negative','native_second_derivative_uniform_bound_float','relative_parent_recognition_second_moment_float','integral_cache','elapsed_seconds')},indent=2))
    print('conditional second prior Fisher speed squared lower bound:',float(prior_fisher_speed_lower))


if __name__=='__main__':
    main()
