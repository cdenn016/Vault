"""Tiny exact witnesses for agreement-sufficient marked parents, no production imports."""
from __future__ import annotations

from fractions import Fraction as F
from itertools import product
from math import factorial
from pathlib import Path
import json
import platform
import time

EDGES = ((0, 1), (1, 2), (2, 3), (3, 0))
PANELS = tuple(product((0, 1), repeat=4))
COMPONENTS = ((F(1, 3), (1,) * 4, (2,) * 4),
              (F(2, 3), (3,) * 4, (1,) * 4))
ETA = ((1, 0, 2, 0), (0, 1, 0, 1))
TARGET = ((2, 1, 3, 1), (1, 1, 0, 2))


def components(panel: tuple[int, ...]) -> tuple[tuple[int, ...], ...]:
    """Return the vertex components of one labeled four-cycle panel."""
    labels = list(range(4))
    for (i, j), bit in zip(EDGES, panel):
        if bit:
            old, new = labels[j], labels[i]
            labels = [new if label == old else label for label in labels]
    return tuple(sorted(tuple(i for i, label in enumerate(labels) if label == value)
                        for value in set(labels)))


def beta(a: int, b: int) -> F:
    """Evaluate B(a,b) exactly for positive integer shapes."""
    assert a > 0 and b > 0
    return F(factorial(a - 1) * factorial(b - 1), factorial(a + b - 1))


def harmonic(n: int) -> F:
    """Evaluate H_n exactly."""
    return sum((F(1, k) for k in range(1, n + 1)), F(0))


def component_integral(a: tuple[int, ...], b: tuple[int, ...],
                       u: tuple[int, ...], v: tuple[int, ...]) -> tuple[F, tuple[F, ...]]:
    """Return a beta-product moment and its unnormalized log-moment vector."""
    value = F(1)
    for ae, be, ue, ve in zip(a, b, u, v):
        value *= beta(ae + ue, be + ve) / beta(ae, be)
    means_p = tuple(harmonic(ae + ue - 1) - harmonic(ae + be + ue + ve - 1)
                    for ae, be, ue, ve in zip(a, b, u, v))
    means_f = tuple(harmonic(be + ve - 1) - harmonic(ae + be + ue + ve - 1)
                    for ae, be, ue, ve in zip(a, b, u, v))
    return value, tuple(value * mean for mean in means_p + means_f)


def integral(u: tuple[int, ...], v: tuple[int, ...],
             mixture: tuple = COMPONENTS) -> tuple[F, tuple[F, ...]]:
    """Integrate a monomial and its logarithmic derivatives under the full mixture."""
    value = F(0)
    derivative = [F(0)] * 8
    for weight, a, b in mixture:
        part, logs = component_integral(a, b, u, v)
        value += weight * part
        for k in range(8):
            derivative[k] += weight * logs[k]
    return value, tuple(derivative)


def conditional_partition(eta: tuple[tuple[int, ...], tuple[int, ...]],
                          partition: tuple[tuple[int, ...], ...]) -> tuple[F, tuple[F, ...]]:
    """Integrate the exact connectivity polynomial with its selection factor once."""
    total = F(0)
    derivative = [F(0)] * 8
    for panel in PANELS:
        if components(panel) != partition:
            continue
        u = tuple(x + bit for x, bit in zip(eta[0], panel))
        v = tuple(x + 1 - bit for x, bit in zip(eta[1], panel))
        value, logs = integral(u, v)
        total += value
        for k in range(8):
            derivative[k] += logs[k]
    assert total > 0
    return total, tuple(value / total for value in derivative)


def dot(x: tuple, y: tuple) -> F:
    """Exact scalar product."""
    return sum((a * b for a, b in zip(x, y)), F(0))


def mul(a: tuple, b: tuple) -> tuple:
    """Multiply two exact 2-by-2 matrices in the declared order."""
    return tuple(tuple(sum((a[i][k] * b[k][j] for k in range(2)), F(0))
                       for j in range(2)) for i in range(2))


def inv(a: tuple) -> tuple:
    """Invert a nonsingular exact 2-by-2 matrix."""
    det = a[0][0] * a[1][1] - a[0][1] * a[1][0]
    assert det != 0
    return ((a[1][1] / det, -a[0][1] / det),
            (-a[1][0] / det, a[0][0] / det))


def diag(x: F) -> tuple:
    """Return diag(x,1/x)."""
    return ((x, F(0)), (F(0), 1 / x))


def energy(x: F) -> F:
    """KL of centered unit-covariance laws across diag(x,1/x)."""
    return (x * x + 1 / (x * x)) / 2 - 1


def encode(value: object) -> object:
    """Serialize exact fractions and nested values without rounding."""
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(key): encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(item) for item in value]
    return value


def main() -> None:
    """Check the finite witnesses once and write the exact result."""
    started = time.perf_counter()
    partitions = tuple(sorted({components(b) for b in PANELS}))
    # Four-cycle connectivity supports 12 partitions, not all 15 Bell partitions.
    assert len(partitions) == 12
    z, dz = integral(*ETA)
    z_target, _ = integral(*TARGET)
    mean = tuple(value / z for value in dz)
    eta_flat, target_flat = ETA[0] + ETA[1], TARGET[0] + TARGET[1]
    delta = tuple(x - y for x, y in zip(eta_flat, target_flat))
    rows = []
    for partition in partitions:
        zr, mr = conditional_partition(ETA, partition)
        ztr, _ = conditional_partition(TARGET, partition)
        r = zr / z
        v_direct = -r * dot(delta, tuple(a - b for a, b in zip(mr, mean)))
        # log(r/pi)+Gamma_R = delta.m_R + log(Z_target/Z),
        # so the centered logarithmic constants cancel exactly.
        gamma_rational_part = dot(delta, mr)
        centered = gamma_rational_part - dot(delta, mean)
        v_fisher = -r * centered
        assert v_direct == v_fisher
        rows.append(dict(partition=partition, mass=r, target_mass=ztr / z_target,
                         current_conditional_normalizer=zr,
                         target_conditional_normalizer=ztr,
                         conditional_log_moments=mr,
                         gamma_rational_part=gamma_rational_part,
                         gamma_log_argument=ztr / zr,
                         fisher_velocity=v_direct))
    assert sum(row['mass'] for row in rows) == 1
    assert sum(row['target_mass'] for row in rows) == 1
    assert sum(row['fisher_velocity'] for row in rows) == 0
    # The 16 mutually exclusive full panels integrate to the unchanged evidence.
    panel_values = [integral(tuple(x + b for x, b in zip(ETA[0], panel)),
                            tuple(x + 1 - b for x, b in zip(ETA[1], panel)))[0]
                    for panel in PANELS]
    assert sum(panel_values) == z
    # p01 p23 q12 q30 (1-q12 q30), using the same latent p for both panels.
    first_u, first_v = (1, 0, 1, 0), (0, 1, 0, 1)
    second_v = (0, 2, 0, 2)
    uniform = ((F(1), (1,) * 4, (1,) * 4),)
    uniform_event = (integral(first_u, first_v, uniform)[0]
                     - integral(first_u, second_v, uniform)[0])
    assert uniform_event == F(5, 144)
    event_u = tuple(a + b for a, b in zip(ETA[0], first_u))
    event_v1 = tuple(a + b for a, b in zip(ETA[1], first_v))
    event_v2 = tuple(a + b for a, b in zip(ETA[1], second_v))
    correlated_event = (integral(event_u, event_v1)[0]
                        - integral(event_u, event_v2)[0]) / z
    assert 0 < correlated_event < 1
    # Exact noncommutative direct/staged geometric assembly.
    a = tuple(tuple(tuple(F(x) for x in row) for row in matrix) for matrix in
              (((2, 1), (0, 1)), ((1, 0), (1, 1)),
               ((1, 1), (0, 2)), ((1, 0), (1, 2))))
    factors = (diag(F(2)), diag(F(3)), diag(F(4)), diag(F(5)))
    theta = tuple(mul(mul(factors[i], ae), inv(factors[j]))
                  for (i, j), ae in zip(EDGES, a))
    v12, v30 = mul(theta[0], theta[1]), mul(theta[2], theta[3])
    v12_reduced = mul(mul(mul(factors[0], a[0]), a[1]), inv(factors[2]))
    v30_reduced = mul(mul(mul(factors[2], a[2]), a[3]), inv(factors[0]))
    assert v12 == v12_reduced and v30 == v30_reduced
    h_staged = mul(v12, v30)
    h_direct = mul(mul(mul(theta[0], theta[1]), theta[2]), theta[3])
    assert h_staged == h_direct
    assert mul(a[0], a[1]) != mul(a[1], a[0])
    assert h_staged != diag(F(1))
    # Same initial parent; different later holonomy under the specified quantile path.
    rotation = ((F(3, 5), -F(4, 5)), (F(4, 5), F(3, 5)))
    initial = (diag(F(2)), diag(F(1, 2)))
    conjugated_initial = tuple(mul(mul(rotation, x), inv(rotation)) for x in initial)
    assert mul(*initial) == mul(*conjugated_initial) == diag(F(1))
    d0 = energy(F(2))
    rates = (F(25, 56), F(49, 275))
    later_energy = tuple(rate * d0 / (rate + 1) for rate in rates)
    assert d0 == F(9, 8)
    assert later_energy == (energy(F(3, 2)), energy(F(4, 3)))
    assert later_energy == (F(25, 72), F(49, 288))
    h_later = mul(diag(F(3, 2)), diag(F(3, 4)))
    h_rotated = mul(mul(rotation, h_later), inv(rotation))
    assert h_later == diag(F(9, 8))
    assert h_rotated[0][1] == F(17, 150) and h_later[0][1] == 0
    result = dict(
        status='passed', arithmetic='Python int and Fraction; no rounded scientific values',
        interpreter=platform.python_version(), elapsed_seconds=time.perf_counter() - started,
        scope='Finite exact witnesses; not a trajectory simulation, benchmark, or universal proof.',
        supported_component_partitions=len(partitions), full_panels=len(PANELS),
        normalization=z, target_normalization=z_target, partition_rows=rows,
        normalized_auxiliary_panel_leaves_evidence_unchanged=True,
        uniform_two_stage_event=uniform_event, correlated_tilted_two_stage_event=correlated_event,
        staged_and_direct_holonomy=h_staged,
        stored_real_entries=dict(fine=28, first_pairs=18, grandparent=11),
        trajectory_obstruction=dict(initial_energy=d0, prior_rates=rates,
                                    later_energies=later_energy, initial_holonomy=diag(F(1)),
                                    later_holonomy=h_later,
                                    conjugated_later_holonomy=h_rotated,
                                    off_diagonal_difference=F(17, 150)),
        not_run=['Existing scientific replays', 'New data', 'Pytest', 'GPU',
                 'Nonlinear integration', 'Timing benchmark', 'Lean', 'Tamper checks'])
    output = Path(__file__).with_name('marked-parent-exact-result.json')
    output.write_text(json.dumps(encode(result), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(encode({key: result[key] for key in
                            ('status', 'supported_component_partitions', 'full_panels',
                             'normalization', 'uniform_two_stage_event',
                             'correlated_tilted_two_stage_event', 'elapsed_seconds')})))


if __name__ == '__main__':
    main()
