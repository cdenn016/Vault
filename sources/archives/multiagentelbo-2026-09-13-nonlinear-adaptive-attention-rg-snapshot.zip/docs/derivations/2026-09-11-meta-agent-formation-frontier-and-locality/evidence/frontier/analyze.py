"""Frozen-archive retrospective; no collection, no ladder regeneration."""
from pathlib import Path
import sys, json, gzip, csv, math, hashlib, platform
from fractions import Fraction as F
from dataclasses import asdict
ROOT=Path(__file__).resolve().parents[5]
sys.path.insert(0,str(ROOT/'src'))
from multiagent_elbo.rg_v2.finite_data_formation import fit_parent, score, Parent, heterogeneous_process, _advance
OUT=Path(__file__).parent
DATA=ROOT/'docs/reports/data/2026-09-11-finite-data-formation'
def dump(name: str, obj: object) -> None:
    (OUT/name).write_text(json.dumps(obj,indent=2,default=str)+'\n',encoding='utf8')
def table(name: str, rows: list[dict]) -> None:
    with (OUT/name).open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def episodes(raw: list) -> tuple: return tuple((y,tuple(tuple(s) for s in seq)) for y,seq in raw)
def losses(model: Parent, eps: tuple, initial_blocks: tuple | None = None) -> list[tuple[float, float]]:
    result=[]
    for y,seq in eps:
        if initial_blocks is None: belief=[float(z==model.blocks[y]) for z in range(model.size)]
        else:
            fiber=[i for i,z in enumerate(initial_blocks) if z==initial_blocks[y]]
            belief=[float(i in fiber)/len(fiber) for i in range(model.size)]
        previous=None;nll=0.;brier=0.
        for _,a,_,e in seq:
            belief,p=_advance(belief,model.rows(a,previous),e)
            nll-=math.log(p);brier+=(1-p)**2;previous=e
        result.append((nll/len(seq),brier/len(seq)))
    return result
def mean(v: list) -> float: return sum(v)/len(v)
def delta_stats(v: list) -> tuple[float, float, float]:
    m=mean(v);sd=math.sqrt(sum((x-m)**2 for x in v)/(len(v)-1))
    return m,sd,sd/math.sqrt(len(v))
def rationalize(x: object) -> object:
    if isinstance(x,list): return tuple(rationalize(v) for v in x)
    if isinstance(x,str): return F(x)
    return x
result=json.loads((DATA/'results.json').read_text())
with gzip.open(DATA/'observations.json.gz','rt') as f: datasets=json.load(f)
lookup={(r['seed'],r['samples_per_row']):r for r in result['runs']}
prior=F(result['configuration']['NUMERICS']['prior']);cost=F(result['configuration']['NUMERICS']['complexity_cost'])
allrows=[];coverage=[];coverage_summary=[];checks=[];cache=[];choices=[];intervals=[]
maxdiff=0.
for d in datasets:
    seed,b=d['seed'],d['samples_per_row'];r=lookup[seed,b];rows=tuple(map(tuple,d['rows']));train=episodes(d['training']);val=episodes(d['validation'])
    models=[];local=[];vl=[]
    for blocks in r['candidate_ladder']:
        blocks=tuple(blocks);k=max(blocks)+1
        counts=[[[0]*k for _ in range(2)] for _ in range(2)]
        for _,seq in train:
            for t,(y,a,_,e) in enumerate(seq):
                if t: counts[seq[t-1][3]][a][blocks[y]]+=1
        occ=[n for ctx in counts for action in ctx for n in action]
        coverage_summary.append(dict(seed=seed,budget=b,classes=k,rows=4*k,total=sum(occ),mean=mean(occ),minimum=min(occ),maximum=max(occ),zero=sum(n==0 for n in occ),below5=sum(n<5 for n in occ),below10=sum(n<10 for n in occ)))
        for p in range(2):
            for a in range(2):
                for z,n in enumerate(counts[p][a]):coverage.append(dict(seed=seed,budget=b,classes=k,previous=p,action=a,source_class=z,count=n))
        for memory in (False,True):
            i=len(models);model=fit_parent(rows,train,blocks,2,memory,prior);s=score(model,val);v=losses(model,val)
            saved=r['ranking'][i];effective=k*(2 if memory else 1);criterion=s['nll']+float(cost)*math.log2(effective)
            diffs=[abs(s[x]-saved[x]) for x in ('nll','brier')]+[abs(criterion-saved['criterion'])]
            maxdiff=max(maxdiff,*diffs)
            assert max(diffs)<=1e-12,(seed,b,i,diffs)
            assert saved['classes']==k and saved['memory']==memory and saved['effective_states']==effective
            local.append(dict(seed=seed,budget=b,index=i,classes=k,memory=int(memory),effective_states=effective,nll=s['nll'],binary_brier=s['brier'],criterion=criterion,log2_effective=math.log2(effective),filter_coordinates=k-1,memory_bits=int(memory),stored_entries=4*k*k*(3 if memory else 1),normalized_row_coordinates=2*k*(2*k-1)*(3 if memory else 1),partition_fixed_width_bits=16*math.ceil(math.log2(k)),blocks=' '.join(map(str,blocks))))
            models.append(model);vl.append(v)
    selected=min(range(32),key=lambda i:(local[i]['criterion'],local[i]['effective_states'],i))
    saved=r['selection']['model'];saved_model=Parent(tuple(saved['blocks']),rationalize(saved['base']),rationalize(saved['memory']))
    assert models[selected]==saved_model and selected==r['selection']['selected_index']
    ranking=sorted(range(32),key=lambda i:(local[i]['criterion'],local[i]['effective_states'],i))
    assert ranking==sorted(range(32),key=lambda i:(r['ranking'][i]['criterion'],r['ranking'][i]['effective_states'],i))
    # Strict Pareto definition, no tolerance used to manufacture equality.
    frontier=[i for i,x in enumerate(local) if not any(j!=i and q['nll']<=x['nll'] and q['log2_effective']<=x['log2_effective'] and (q['nll']<x['nll'] or q['log2_effective']<x['log2_effective']) for j,q in enumerate(local))]
    chosen=[0,30];seen={models[0].blocks,models[30].blocks}
    for i in sorted(frontier,key=lambda i:(local[i]['nll'],i)):
        if models[i].blocks not in seen:chosen.append(i);seen.add(models[i].blocks)
        if len(chosen)==5:break
    choices.append(dict(seed=seed,budget=b,frontier=frontier,oracle_indices=chosen))
    for i,x in enumerate(local):
        x['validation_rank']=ranking.index(i)+1;x['pareto']=int(i in frontier)
        for label,idx in [('constant',30),('identity',0)]:
            m,sd,se=delta_stats([a[0]-c[0] for a,c in zip(vl[i],vl[idx])]);x['paired_minus_'+label]=m;x['paired_sd_'+label]=sd;x['paired_se_'+label]=se
        lo=0.;hi=math.inf;possible=True
        for j,q in enumerate(local):
            dc=x['log2_effective']-q['log2_effective'];dl=q['nll']-x['nll']
            if dc>0:hi=min(hi,dl/dc)
            elif dc<0:lo=max(lo,dl/dc)
            elif dl<0:possible=False
        possible=possible and hi>=lo and hi>=0
        x['lower_envelope']=int(possible);x['lambda_min']=lo if possible else '';x['lambda_max']=hi if possible else ''
        if possible:intervals.append(dict(seed=seed,budget=b,index=i,lambda_min=lo,lambda_max=hi,tie_rule='criterion, effective_states, index'))
    allrows.extend(local);cache.append((d,models,frontier,chosen));checks.append(dict(seed=seed,budget=b,selected=selected,rational_rows_equal=True,ranking_equal=True))
    print('reconstructed',seed,b,'frontier',frontier,'oracles',chosen,flush=True)
# Complete reconstruction gate before any oracle or heldout evaluation.
dump('reconstruction.json',dict(tolerance=1e-12,max_absolute_difference=maxdiff,runs=checks,runtime=sys.version,executable=sys.executable,platform=platform.platform(),input_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in DATA.iterdir() if p.is_file()}))
dump('oracle-selection.json',dict(rule='ascending validation NLL then index; at most three distinct nonendpoint Pareto partitions; endpoints 0 and 30 always',runs=choices))
table('validation-frontier.csv',allrows);table('coverage-rows.csv',coverage);table('coverage-summary.csv',coverage_summary);table('coefficient-intervals.csv',intervals)
print('RECONSTRUCTION GATE PASSED',flush=True)
theory=result['configuration']['THEORY'];couplings=tuple(F(x) for x in theory['couplings'])
processes={env:heterogeneous_process(c,F(theory['field']),F(theory['signal']))[0] for env,c in [('original',couplings),('reversed_couplings',tuple(reversed(couplings)))]}
# Exact two-event hidden sum for a uniform constant fiber, positive then negative action, record ordinals 1,0.
p=processes['original'];direct=sum(F(1,16)*p.emitted[1][y][2*v+1]*p.emitted[0][v][2*w] for y in range(16) for v in range(16) for w in range(16))
belief=[1/16]*16;fm=Parent(tuple(range(16)),p.emitted,None);belief,p1=_advance(belief,fm.rows(1,None),1);belief,p2=_advance(belief,fm.rows(0,1),0)
assert abs(p1*p2-float(direct))<1e-14
assert all(sum(row)==1 for p in processes.values() for tab in p.emitted for row in tab)
dump('filter-check.json',dict(exact_two_event_probability=str(direct),floating_probability=p1*p2,absolute_difference=abs(p1*p2-float(direct)),all_exact_rows_normalized=True))
heldout=[];attribution=[];episode_rows=[]
for d,models,frontier,chosen in cache:
    seed,b=d['seed'],d['samples_per_row']
    for cell in d['heldout']:
        env,policy=cell['environment'],cell['policy'];eps=episodes(cell['episodes']);idxs=sorted(set(frontier+[0,30]));ls={i:losses(models[i],eps) for i in idxs}
        fine=Parent(tuple(range(16)),processes[env].emitted,None);full=losses(fine,eps)
        for i in idxs:
            row=dict(seed=seed,budget=b,environment=env,policy=policy,index=i,classes=models[i].size,memory=int(models[i].memory is not None),episodes=len(eps),nll=mean([v[0] for v in ls[i]]),binary_brier=mean([v[1] for v in ls[i]]))
            for label,j in [('constant',30),('identity',0)]:
                m,sd,se=delta_stats([v[0]-w[0] for v,w in zip(ls[i],ls[j])]);row['paired_minus_'+label]=m;row['paired_sd_'+label]=sd;row['paired_se_'+label]=se
            heldout.append(row)
        for i in chosen:
            same=losses(fine,eps,models[i].blocks);fitted=ls[i]
            prep=[v[0]-w[0] for v,w in zip(same,full)];mismatch=[v[0]-w[0] for v,w in zip(fitted,same)]
            attribution.append(dict(seed=seed,budget=b,environment=env,policy=policy,index=i,classes=models[i].size,memory=int(models[i].memory is not None),episodes=len(eps),full_nll=mean([v[0] for v in full]),same_nll=mean([v[0] for v in same]),fitted_nll=mean([v[0] for v in fitted]),preparation_difference=mean(prep),preparation_paired_se=delta_stats(prep)[2],mismatch_difference=mean(mismatch),mismatch_paired_se=delta_stats(mismatch)[2]))
            for j in range(len(eps)):episode_rows.append(dict(seed=seed,budget=b,environment=env,policy=policy,index=i,episode=j,full_nll=full[j][0],same_nll=same[j][0],fitted_nll=fitted[j][0]))
    print('evaluated',seed,b,flush=True)
table('heldout-frontier.csv',heldout);table('preparation-attribution.csv',attribution);table('attribution-episodes.csv',episode_rows)
dump('summary.json',dict(candidates=len(allrows),heldout_rows=len(heldout),attribution_rows=len(attribution),frontier_sizes=[len(x[2]) for x in cache],completed=True))
