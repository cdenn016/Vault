"""Descriptive publication figures from retained CSV tables; no refitting."""
from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=Path(__file__).parent
plt.rcParams.update({'font.size':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','axes.labelsize':9})
def read(n: str) -> list[dict[str, str]]:
    with (OUT/n).open() as f:return list(csv.DictReader(f))
def save(fig: object, name: str) -> None:
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight');fig.savefig(OUT/(name+'.png'),dpi=300,bbox_inches='tight');plt.close(fig)
colors=['#0072B2','#D55E00','#009E73'];seeds=[1701,2903,4307];budgets=[32,128,512]
r=read('validation-frontier.csv')
fig,axes=plt.subplots(2,3,figsize=(10,5.8),layout='constrained')
for c,b in enumerate(budgets):
    for row,metric in enumerate(['log2_effective','stored_entries']):
        ax=axes[row,c]
        for color,seed in zip(colors,seeds):
            for mem,style in [(0,'-'),(1,'--')]:
                q=[x for x in r if int(x['budget'])==b and int(x['seed'])==seed and int(x['memory'])==mem]
                ax.plot([float(x[metric]) for x in q],[float(x['nll']) for x in q],color=color,ls=style,lw=.9,label=str(seed) if not mem else None)
                f=[x for x in q if int(x['pareto'])];ax.scatter([float(x[metric]) for x in f],[float(x['nll']) for x in f],s=16,facecolors='none',edgecolors=color)
        ax.set_title(f'{b} samples / row');ax.set_ylabel('Validation NLL (nats / event)');ax.set_xlabel('log2 effective state count' if row==0 else 'Stored transition entries')
        if row:ax.set_xscale('log')
axes[0,0].legend(title='Training seed',frameon=False)
fig.suptitle('Saved validation frontier: solid base, dashed previous-record rows; circles Pareto\n256 episodes per fit; descriptive point estimates, no selection-adjusted intervals',fontsize=9)
save(fig,'loss-resources')
a=read('preparation-attribution.csv');fig,axes=plt.subplots(2,3,figsize=(10,5.8),layout='constrained')
for row,env in enumerate(['original','reversed_couplings']):
    for col,b in enumerate(budgets):
        ax=axes[row,col]
        for i,marker,label in [(30,'o','constant'),(0,'s','identity')]:
            q=[x for x in a if x['environment']==env and int(x['budget'])==b and int(x['index'])==i]
            ax.scatter([float(x['preparation_difference']) for x in q],[float(x['mismatch_difference']) for x in q],s=22,marker=marker,facecolors='none',edgecolors=colors[i==0],label=label)
        q=[x for x in a if x['environment']==env and int(x['budget'])==b and int(x['index']) not in (0,30)]
        ax.scatter([float(x['preparation_difference']) for x in q],[float(x['mismatch_difference']) for x in q],s=14,marker='x',color='#777777',label='bounded frontier')
        ax.axhline(0,color='#aaaaaa',lw=.6);ax.axvline(0,color='#aaaaaa',lw=.6);ax.set_title(f'{env.replace("_"," ")}; b={b}')
        ax.set_xlabel('Same minus full oracle (nats / event)');ax.set_ylabel('Fitted minus same oracle (nats / event)')
axes[0,0].legend(frameon=False,fontsize=7)
fig.suptitle('Preparation and model discrepancy: individual seed / policy cells\n256 paired episodes per point; signed sample differences, no population nonnegativity claim',fontsize=9)
save(fig,'preparation-attribution')
cov=read('coverage-summary.csv');fig,axes=plt.subplots(3,3,figsize=(10,7),layout='constrained')
for row,seed in enumerate(seeds):
    for col,b in enumerate(budgets):
        ax=axes[row,col];q=sorted([x for x in cov if int(x['budget'])==b and int(x['seed'])==seed],key=lambda x:int(x['classes']));k=[int(x['classes']) for x in q]
        ax.fill_between(k,[float(x['minimum']) for x in q],[float(x['maximum']) for x in q],color='#0072B2',alpha=.2,label='min–max occupancy')
        ax.plot(k,[float(x['mean']) for x in q],color='#0072B2',lw=1,label='mean occupancy');ax.set_title(f'seed {seed}; b={b}');ax.set_xlabel('Response classes');ax.set_ylabel('Observations / memory row');ax.set_xticks([1,8,16])
axes[0,0].legend(frameon=False,fontsize=7)
fig.suptitle('Conditional-memory coverage: 4k context/action/class rows share 3b transitions\nBands are observed occupancy ranges, not uncertainty intervals',fontsize=9)
save(fig,'memory-coverage')
print('wrote 3 PDF and 3 PNG figures')
