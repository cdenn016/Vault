from pathlib import Path
import sys,json
from fractions import Fraction as F
from itertools import combinations,product
ROOT=Path(__file__).resolve().parents[5];sys.path.insert(0,str(ROOT/'src'))
from multiagent_elbo.rg_v2.finite_data_formation import heterogeneous_process
OUT=Path(__file__).parent
r=json.loads((ROOT/'docs/reports/data/2026-09-11-finite-data-formation/results.json').read_text());t=r['configuration']['THEORY'];couplings=tuple(F(x) for x in t['couplings']);eta=F(t['signal']);field=F(t['field']);checks=[]
for env,c in [('original',couplings),('reversed_couplings',tuple(reversed(couplings)))]:
    p,states=heterogeneous_process(c,field,eta)
    for ai,a in enumerate((-field,field)):
        for yi,y in enumerate(states):
            parity=y[0]*y[1]*y[2]*y[3]
            formula=eta*parity/F(4)*(a*sum(y)+2*sum(j*y[u]*y[v] for (u,v),j in zip(combinations(range(4),2),c)))
            actual=sum(p.emitted[ai][yi][2*v+e]*p.records[e] for v in range(16) for e in range(2))
            assert formula==actual and sum(p.emitted[ai][yi])==1
            checks.append(dict(environment=env,action=str(a),state=y,mean=str(actual)))
        row0=[sum(p.emitted[ai][0][e::2]) for e in range(2)];row15=[sum(p.emitted[ai][15][e::2]) for e in range(2)]
        assert sum(abs(x-z) for x,z in zip(row0,row15))/2==eta*field
# One typed local adapter, A={0}, retains exterior source as action and next exterior as record.
p,states=heterogeneous_process(couplings,field,eta)
local_checks=0
for a in range(2):
    for exterior in product((-1,1),repeat=3):
        for local in (-1,1):
            y=states.index((local,*exterior));row={}
            for v,dest in enumerate(states):
                for ei,e in enumerate(p.records):row[(dest[0],('STEP',e,dest[1:]))]=p.emitted[a][y][2*v+ei]
            row[(local,('START',))]=F(0)
            assert sum(row.values())==1 and row[(local,('START',))]==0
            initial={('START',):F(1)};assert sum(initial.values())==1
            local_checks+=1
(OUT/'response-certificate.json').write_text(json.dumps(dict(response_equalities=checks,total_equalities=len(checks),all_plus_minus_tv=str(eta*field),constant_floor=str(eta*field/2),adapter_subset=[0],adapter_rows=local_checks,adapter_start_mass=0,initial_start_mass=1),indent=2)+'\n')
print('64 exact response equalities; 32 singleton-adapter rows; no refinement')
