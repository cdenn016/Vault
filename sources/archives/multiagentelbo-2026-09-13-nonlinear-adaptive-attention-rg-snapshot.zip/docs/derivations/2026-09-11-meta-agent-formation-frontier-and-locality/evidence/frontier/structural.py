"""Exact structural diagnostics on the preselected bounded oracle subset only."""
from pathlib import Path
import sys,json,gzip,csv
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[5];sys.path.insert(0,str(ROOT/'src'))
from multiagent_elbo.rg_v2.finite_data_formation import fit_parent,heterogeneous_process,oracle_error
OUT=Path(__file__).parent;DATA=ROOT/'docs/reports/data/2026-09-11-finite-data-formation'
r=json.loads((DATA/'results.json').read_text());chosen=json.loads((OUT/'oracle-selection.json').read_text())['runs']
with gzip.open(DATA/'observations.json.gz','rt') as f: data=json.load(f)
t=r['configuration']['THEORY'];prior=F(r['configuration']['NUMERICS']['prior']);couplings=tuple(F(x) for x in t['couplings'])
processes={env:heterogeneous_process(c,F(t['field']),F(t['signal']))[0] for env,c in [('original',couplings),('reversed_couplings',tuple(reversed(couplings)))]}
output=[]
for run,d,selection in zip(r['runs'],data,chosen):
    assert (run['seed'],run['samples_per_row'])==(d['seed'],d['samples_per_row'])==(selection['seed'],selection['budget'])
    rows=tuple(map(tuple,d['rows']));episodes=tuple((y,tuple(map(tuple,seq))) for y,seq in d['training'])
    for i in selection['oracle_indices']:
        blocks=tuple(run['candidate_ladder'][i//2]);k=max(blocks)+1;model=fit_parent(rows,episodes,blocks,2,bool(i%2),prior)
        for env,p in processes.items():
            defect=F(0);witness=None
            for a,table in enumerate(p.emitted):
                coarse=[tuple(sum((row[2*v+e] for v,z in enumerate(blocks) if z==dest),F(0)) for dest in range(k) for e in range(2)) for row in table]
                for y in range(16):
                    for v in range(y):
                        if blocks[y]==blocks[v]:
                            tv=sum((abs(x-w) for x,w in zip(coarse[y],coarse[v])),F(0))/2
                            if tv>defect:defect=tv;witness=(a,y,v)
            epsilon=oracle_error(p,model);assert epsilon>=defect/2
            output.append(dict(seed=d['seed'],budget=d['samples_per_row'],index=i,environment=env,classes=k,memory=int(bool(i%2)),intrinsic_d=str(defect),row_floor=str(defect/2),fitted_oracle_error=str(epsilon),witness=str(witness)))
with (OUT/'structural-diagnostics.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=output[0]);w.writeheader();w.writerows(output)
print('exact bounded structural diagnostics',len(output))
