"""One independently recomputed exact observable minor, reduced modulo 1009."""
from __future__ import annotations
import ast
from fractions import Fraction
import hashlib
import json
from math import isqrt
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).parent
PRIME = 1009
OMITTED = 15
sys.path.insert(0, str(ROOT / "src"))
from multiagent_elbo.rg_v2.finite_data_formation import heterogeneous_process


def digest(path: Path) -> str:
    """Return provenance hash without changing an input."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def determinant(matrix: list[list[int]], prime: int) -> tuple[int, list[int]]:
    r"""Compute one determinant over F_p using elementary row operations."""
    rows = [row[:] for row in matrix]
    value = 1
    pivots = []
    for j in range(len(rows)):
        pivot = next((i for i in range(j, len(rows)) if rows[i][j]), None)
        if pivot is None:
            return 0, pivots
        if pivot != j:
            rows[j], rows[pivot] = rows[pivot], rows[j]
            value = -value
        diagonal = rows[j][j]
        pivots.append(diagonal)
        value = value * diagonal % prime
        inverse = pow(diagonal, -1, prime)
        for i in range(j + 1, len(rows)):
            coefficient = rows[i][j] * inverse % prime
            for k in range(j, len(rows)):
                rows[i][k] = (rows[i][k] - coefficient * rows[j][k]) % prime
    return value % prime, pivots


def run() -> None:
    """Check selected entries and one fixed minor; do not enumerate/rerank words."""
    started = time.perf_counter()
    prime_remainders = {str(d): PRIME % d for d in range(2, isqrt(PRIME) + 1)}
    assert all(prime_remainders.values())
    source = OUT / "observable-rank.json"
    retained = json.loads(source.read_text(encoding="utf-8"))
    saved_path = ROOT / "docs/reports/data/2026-09-11-finite-data-formation/results.json"
    saved = json.loads(saved_path.read_text(encoding="utf-8"))
    theory = saved["configuration"]["THEORY"]
    assert theory == retained["configuration"]
    profile_path = ROOT / "experiments/rg_v2/formation_data.py"
    module = ast.parse(profile_path.read_text(encoding="utf-8"))
    profile = next(ast.literal_eval(node.value) for node in module.body
                   if isinstance(node, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == "THEORY" for t in node.targets))
    assert profile == theory
    for name, expected in retained["source_sha256"].items():
        assert digest(ROOT / "src/multiagent_elbo/rg_v2" / name) == expected
    assert digest(saved_path) == retained["results_sha256"]
    process, states = heterogeneous_process(tuple(Fraction(x) for x in theory["couplings"]),
                                          Fraction(theory["field"]), Fraction(theory["signal"]))
    assert [list(state) for state in states] == retained["source_states"]
    words = [entry["word_action_record_ordinals"] for entry in retained["selected_words"]]
    assert len(words) == 15
    columns = []
    for entry, word in zip(retained["selected_words"], words, strict=True):
        values = [Fraction(1)] * len(states)
        for action, record in reversed(word):
            values = [sum((row[2 * target + record] * values[target]
                           for target in range(len(states))), Fraction(0))
                      for row in process.emitted[action]]
        assert values == [Fraction(x) for x in entry["probabilities_by_preparation"]]
        columns.append(values)
    matrix = [[column[i] for column in columns] for i in range(16) if i != OMITTED]
    denominators = sorted({value.denominator for row in matrix for value in row})
    assert all(denominator % PRIME for denominator in denominators)
    residues = [[value.numerator * pow(value.denominator, -1, PRIME) % PRIME
                 for value in row] for row in matrix]
    det, pivots = determinant(residues, PRIME)
    bindings = {"observable-rank.json": digest(source), "saved_results": digest(saved_path),
                "active_profile": digest(profile_path), "checker": digest(Path(__file__))}
    bindings.update({name: digest(ROOT / "src/multiagent_elbo/rg_v2" / name)
                     for name in retained["source_sha256"]})
    result = {"scope": "One fixed 15 by 15 original-word minor; no rank-producer rerun",
              "revision": retained["revision"], "configuration": theory,
              "executable": sys.executable, "runtime": sys.version,
              "prime": PRIME, "prime_trial_remainders": prime_remainders,
              "omitted_preparation_index": OMITTED, "omitted_preparation": states[OMITTED],
              "words": words, "recomputed_entries_matching_saved": 240,
              "exact_minor": [[str(v) for v in row] for row in matrix],
              "denominators": denominators, "minor_mod_prime": residues,
              "determinant_mod_prime": det, "pivots_mod_prime": pivots,
              "nonzero_minor_certified": det != 0, "bindings": bindings,
              "elapsed_seconds": time.perf_counter() - started,
              "determinants_run": 1, "simulations_run": False, "pytest_run": False}
    payload = json.dumps(result, indent=2) + "\n"
    (OUT / "observable-minor-check.json").write_text(payload, encoding="utf-8")
    (OUT / "observable-minor-check.log").write_text(payload, encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("prime", "determinant_mod_prime",
          "nonzero_minor_certified", "recomputed_entries_matching_saved", "elapsed_seconds")}))


if __name__ == "__main__":
    run()