"""Exact finite-word rank certificate for the saved preparation experiment."""
from __future__ import annotations

import ast
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT / "src"))
from multiagent_elbo.rg_v2.finite_data_formation import heterogeneous_process

Vector = tuple[F, ...]
Word = tuple[tuple[int, int], ...]


def digest(path: Path) -> str:
    """Return the byte-exact SHA-256 binding."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reduce_vector(vector: Vector, basis: list[tuple[int, Vector]]) -> Vector:
    r"""Subtract exact echelon rows: v <- v - v[p] b, with b[p] = 1."""
    residual = list(vector)
    for pivot, row in basis:
        coefficient = residual[pivot]
        if coefficient:
            residual = [x - coefficient * y for x, y in zip(residual, row)]
    return tuple(residual)


def admit(vector: Vector, basis: list[tuple[int, Vector]]) -> bool:
    """Append one independent normalized exact echelon row, if it exists."""
    residual = reduce_vector(vector, basis)
    pivot = next((i for i, value in enumerate(residual) if value), None)
    if pivot is None:
        return False
    scale = residual[pivot]
    basis.append((pivot, tuple(value / scale for value in residual)))
    basis.sort(key=lambda entry: entry[0])
    return True


def apply(matrix: tuple[Vector, ...], vector: Vector) -> Vector:
    r"""Compute v_(a,e,w) = K_(a,e) v_w in the declared word order."""
    return tuple(sum((x * y for x, y in zip(row, vector)), F(0)) for row in matrix)


def run() -> None:
    """Bind saved inputs, enumerate words through horizon four, and prove rank."""
    started = time.perf_counter()
    binding_path = OUT.parent / "input-binding.json"
    binding = json.loads(binding_path.read_text(encoding="utf-8"))
    for entry in binding["inputs"]:
        assert digest(ROOT / entry["path"]) == entry["sha256"], entry["path"]
    saved_path = ROOT / "docs/reports/data/2026-09-11-finite-data-formation/results.json"
    saved = json.loads(saved_path.read_text(encoding="utf-8"))
    theory = saved["configuration"]["THEORY"]
    profile_path = ROOT / "experiments/rg_v2/formation_data.py"
    profile_ast = ast.parse(profile_path.read_text(encoding="utf-8"))
    profile_theory = next(ast.literal_eval(node.value) for node in profile_ast.body
                         if isinstance(node, ast.Assign)
                         and any(isinstance(target, ast.Name) and target.id == "THEORY"
                                 for target in node.targets))
    assert profile_theory == theory
    assert theory["horizon"] == 4
    process, states = heterogeneous_process(tuple(F(v) for v in theory["couplings"]),
                                             F(theory["field"]), F(theory["signal"]))
    matrices = {(a, e): tuple(tuple(row[2 * dest + e] for dest in range(16))
                             for row in process.emitted[a])
                for a, e in product(range(2), repeat=2)}
    parity = tuple(F(y[0] * y[1] * y[2] * y[3]) for y in states)
    null_checks = 0
    for matrix in matrices.values():
        for dest in range(16):
            assert sum((parity[y] * matrix[y][dest] for y in range(16)), F(0)) == 0
            null_checks += 1
    basis: list[tuple[int, Vector]] = []
    selected: list[tuple[Word, Vector]] = []
    layer: dict[Word, Vector] = {(): (F(1),) * 16}
    profile = []
    total_words = 0
    for horizon in range(5):
        for word, vector in layer.items():
            assert sum((x * y for x, y in zip(parity, vector)), F(0)) == 0
            if admit(vector, basis):
                selected.append((word, vector))
        total_words += len(layer)
        profile.append({"horizon": horizon, "words_at_horizon": len(layer),
                        "cumulative_words": total_words, "cumulative_rank": len(basis)})
        if horizon < 4:
            layer = {(symbol,) + word: apply(matrix, vector)
                     for symbol, matrix in matrices.items() for word, vector in layer.items()}
    # All retained vectors are original word probabilities, not signed mixtures.
    closure_checks = 0
    for _, vector in selected:
        for matrix in matrices.values():
            assert not any(reduce_vector(apply(matrix, vector), basis))
            closure_checks += 1
    row_basis: list[tuple[int, Vector]] = []
    row_rank = sum(admit(tuple(vector[y] for _, vector in selected), row_basis)
                   for y in range(16))
    assert row_rank == len(basis)
    # Removing any one preparation must leave independent rows if parity is the only relation.
    deletion_ranks = []
    for omitted in range(16):
        remaining: list[tuple[int, Vector]] = []
        rank = sum(admit(tuple(vector[y] for _, vector in selected), remaining)
                   for y in range(16) if y != omitted)
        deletion_ranks.append(rank)
    result = {
        "scope": "Exact record-word probabilities for every deterministic preparation, both open-loop actions, horizons zero through four; invariant observable span is checked separately.",
        "revision": binding["revision"], "configuration": theory,
        "frozen_inputs_checked": len(binding["inputs"]),
        "input_binding_sha256": digest(binding_path), "results_sha256": digest(saved_path),
        "profile_sha256": digest(profile_path), "script_sha256": digest(Path(__file__)),
        "source_sha256": {name: digest(ROOT / "src/multiagent_elbo/rg_v2" / name)
                          for name in ("finite_data_formation.py", "finite_formation.py")},
        "executable": sys.executable, "runtime": sys.version,
        "arithmetic": "fractions.Fraction exact rational arithmetic",
        "source_states": states, "action_codebook": list(enumerate(process.actions)),
        "record_codebook": list(enumerate(process.records)),
        "rank_profile": profile, "selected_word_count": len(selected),
        "selected_words": [{"word_action_record_ordinals": word, "probabilities_by_preparation": vector}
                           for word, vector in selected],
        "echelon_pivots": [pivot for pivot, _ in basis],
        "exact_parity_left_null_vector": parity, "emitted_matrix_left_null_checks": null_checks,
        "word_span_invariance_checks": closure_checks, "transposed_rank": row_rank,
        "rank_after_removing_each_preparation": deletion_ranks,
        "elapsed_seconds": time.perf_counter() - started, "pytest_run": False,
        "new_data_collected": False,
    }
    (OUT / "observable-rank.json").write_text(json.dumps(result, indent=2, default=str) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("rank_profile", "selected_word_count",
          "emitted_matrix_left_null_checks", "word_span_invariance_checks",
          "rank_after_removing_each_preparation", "elapsed_seconds")}, indent=2), flush=True)


if __name__ == "__main__":
    run()