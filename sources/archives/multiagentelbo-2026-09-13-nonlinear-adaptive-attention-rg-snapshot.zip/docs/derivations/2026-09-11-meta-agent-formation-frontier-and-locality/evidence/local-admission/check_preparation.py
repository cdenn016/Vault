"""Finite certificates for preparation separation and history-repair limits."""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import csv
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / "src"))
from multiagent_elbo.rg_v2.finite_data_formation import heterogeneous_process
OUT = Path(__file__).parent


def run() -> None:
    """Check only the named question: can equal retained initialization be exact?"""
    saved = json.loads((ROOT / "docs/reports/data/2026-09-11-finite-data-formation/results.json").read_text())
    theory = saved["configuration"]["THEORY"]
    couplings = tuple(F(x) for x in theory["couplings"])
    field, eta = F(theory["field"]), F(theory["signal"])
    process, states = heterogeneous_process(couplings, field, eta)
    j = [[F(0)]*4 for _ in range(4)]
    for (u, v), value in zip(combinations(range(4), 2), couplings):
        j[u][v] = j[v][u] = value
    degrees = tuple(sum(row, F(0)) for row in j)
    exterior_certificates = []
    for size in range(1, 4):
        for subset in combinations(range(4), size):
            exterior_site = next(i for i in range(4) if i not in subset)
            local_states = tuple(product((-1, 1), repeat=size))
            signals = tuple(sum((j[exterior_site][i]*u[n] for n, i in enumerate(subset)), F(0)) for u in local_states)
            assert len(set(signals)) == len(local_states)
            min_gap = min(abs(a-b) for a, b in combinations(signals, 2))
            exterior_certificates.append({"subset": [i+1 for i in subset],
                "exterior_site": exterior_site+1, "local_states": local_states,
                "weighted_sign_sums": signals, "minimum_signal_gap": min_gap,
                "minimum_next_exterior_bit_tv": min_gap/8})
    first_means = tuple(tuple(sum((row[2*v+e]*process.records[e] for v in range(16) for e in range(2)), F(0))
                             for row in table) for table in process.emitted)
    plus_transition = tuple(tuple(row[2*v]+row[2*v+1] for v in range(16)) for row in process.emitted[1])
    second_means = tuple(sum((plus_transition[y][v]*first_means[1][v] for v in range(16)), F(0)) for y in range(16))
    signatures = tuple(tuple((1+mean)/2 for mean in (first_means[0][i], first_means[1][i], second_means[i])) for i in range(16))
    assert len(set(signatures)) == 16
    assert len(set(zip(*first_means))) == 13
    complementary_zero_m = []
    for i, y in enumerate(states):
        if sum(y) != 0:
            continue
        v = states.index(tuple(-x for x in y))
        if i >= v:
            continue
        degree_signal = sum((d*x for d, x in zip(degrees, y)), F(0))
        actual_mean_difference = second_means[i]-second_means[v]
        predicted_mean_difference = -3*eta*field*degree_signal/8
        assert actual_mean_difference == predicted_mean_difference
        assert predicted_mean_difference != 0
        complementary_zero_m.append({"source_indices": [i, v], "states": [y, states[v]],
            "degree_signal": degree_signal, "mean_difference": actual_mean_difference,
            "second_record_tv": abs(actual_mean_difference)/2})
    pairs = []
    for y, v in combinations(range(16), 2):
        coordinate = next(c for c in range(3) if signatures[y][c] != signatures[v][c])
        pairs.append({"sources": [y, v], "horizon": 1 if coordinate < 2 else 2,
            "open_loop_actions": [str(-field)] if coordinate == 0 else [str(field)]*(1 if coordinate == 1 else 2),
            "event": "final record +1, earlier records marginalized",
            "left_probability": signatures[y][coordinate], "right_probability": signatures[v][coordinate],
            "difference": signatures[y][coordinate]-signatures[v][coordinate]})
    # Directly verify the exterior expectation formula for every proper subset source and action.
    exterior_checks = 0
    for item in exterior_certificates:
        site = item["exterior_site"]-1
        for a, action in enumerate((-field, field)):
            for source, y in enumerate(states):
                actual = sum((process.emitted[a][source][2*v+e]*states[v][site]
                              for v in range(16) for e in range(2)), F(0))
                expected = F(3,4)*y[site]+(action+sum((j[site][k]*y[k] for k in range(4)), F(0)))/4
                assert actual == expected
                exterior_checks += 1
    result = {"scope": "deterministic retained preparation and memory initialized only from that preparation",
        "source_degrees": degrees, "proper_subset_certificates": exterior_certificates,
        "exterior_expectation_checks": exterior_checks,
        "first_response_distinct_signatures": 13, "two_response_distinct_signatures": 16,
        "pair_witnesses": pairs, "zero_magnetization_complements": complementary_zero_m,
        "source_states": states, "positive_record_signatures": signatures,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "executable": sys.executable, "runtime": sys.version, "pytest_run": False}
    (OUT/"preparation-separation.json").write_text(json.dumps(result, indent=2, default=str)+"\n", encoding="utf-8")
    with (OUT/"preparation-signatures.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["state_index", "state", "p_first_plus_negative_action", "p_first_plus_positive_action", "p_second_plus_positive_positive"])
        writer.writerows((i, repr(y), *map(str, signature)) for i, (y, signature) in enumerate(zip(states, signatures)))
    print(f"{len(exterior_certificates)} injective exterior probes; {exterior_checks} exact exterior expectations", flush=True)
    print(f"{len(pairs)} distinct preparation pairs; {sum(p['horizon']==2 for p in pairs)} need the second-response probe", flush=True)
    print(json.dumps(complementary_zero_m, default=str), flush=True)


if __name__ == "__main__":
    run()
