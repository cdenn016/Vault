"""Exact local-block admission for the frozen heterogeneous four-spin process.

This consumes normalized source tables, never samples observations, and uses
one exterior-independent local quotient per nonempty subset.
"""
from __future__ import annotations

from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
from typing import Any
import csv
import hashlib
import json
import platform
import sys

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / "src"))
from multiagent_elbo.rg_v2.finite_data_formation import heterogeneous_process
from multiagent_elbo.rg_v2.finite_formation import (
    ControlledProcess, coarsest_partition, quotient_process,
)

OUT = Path(__file__).parent
State = tuple[int, ...]


def dump(name: str, value: Any) -> None:
    """Save exact rationals as reduced strings and integers without conversion."""
    (OUT / name).write_text(json.dumps(value, indent=2, default=str) + "\n", encoding="utf-8")


def assemble(local: State, exterior: State, subset: tuple[int, ...]) -> State:
    """Embed ordered local and exterior spin coordinates into the four-spin carrier."""
    complement = tuple(i for i in range(4) if i not in subset)
    values = dict(zip(subset, local)) | dict(zip(complement, exterior))
    return tuple(values[i] for i in range(4))


def adapter(
    process: ControlledProcess,
    states: tuple[State, ...],
    subset: tuple[int, ...],
) -> tuple[ControlledProcess, tuple[State, ...], tuple[State, ...], tuple, tuple]:
    r"""Construct L^(a,x)(u', STEP,e,x' | u) = K^a(u',x',e | u,x)."""
    local_states = tuple(product((-1, 1), repeat=len(subset)))
    exteriors = tuple(product((-1, 1), repeat=4-len(subset)))
    actions = tuple((a, x) for a in range(len(process.actions)) for x in exteriors)
    records = (("START",),) + tuple(("STEP", e, x) for x in exteriors for e in process.records)
    state_index = {y: i for i, y in enumerate(states)}
    tables = []
    sensors = []
    for a, x in actions:
        rows = []
        for u in local_states:
            source = state_index[assemble(u, x, subset)]
            row = [F(0)] * (len(local_states)*len(records))
            for vi, v in enumerate(local_states):
                for ri, (_, e, xp) in enumerate(records[1:], start=1):
                    destination = state_index[assemble(v, xp, subset)]
                    ordinal = process.records.index(e)
                    row[vi*len(records)+ri] = process.emitted[a][source][2*destination+ordinal]
            assert sum(row, F(0)) == 1
            assert all(row[v*len(records)] == 0 for v in range(len(local_states)))
            rows.append(tuple(row))
        tables.append(tuple(rows))
        sensors.append(tuple((F(1),) + (F(0),)*(len(records)-1) for _ in local_states))
    result = ControlledProcess(tuple(map(repr, local_states)), tuple(map(repr, actions)),
                               tuple(range(len(records))), tuple(tables), tuple(sensors))
    return result, local_states, exteriors, actions, records


def aggregate_row(row: tuple[F, ...], blocks: tuple[int, ...], width: int) -> tuple[F, ...]:
    r"""Sum a fine emitted row into next retained class and unchanged record."""
    result = [F(0)]*((max(blocks)+1)*width)
    for destination, label in enumerate(blocks):
        for record in range(width):
            result[label*width+record] += row[destination*width+record]
    return tuple(result)


def refinement_trace(process: ControlledProcess) -> tuple[list[dict], list[dict]]:
    """Independently trace refinement and retain a separating atom for each split pair."""
    width = len(process.records)
    blocks = (0,)*process.size  # All initial sensors are delta_START.
    trace = [{"labels": blocks, "classes": 1}]
    witnesses = []
    while True:
        signatures = [tuple(aggregate_row(table[y], blocks, width) for table in process.emitted)
                      for y in range(process.size)]
        keys = [(blocks[y], signatures[y]) for y in range(process.size)]
        unique: dict[tuple, int] = {}
        refined = tuple(unique.setdefault(key, len(unique)) for key in keys)
        if refined == blocks:
            return trace, witnesses
        for y, v in combinations(range(process.size), 2):
            if blocks[y] != blocks[v] or refined[y] == refined[v]:
                continue
            found = False
            for a in range(len(process.actions)):
                for column, (p, q) in enumerate(zip(signatures[y][a], signatures[v][a])):
                    if p != q:
                        target_class, record = divmod(column, width)
                        witnesses.append({"round": len(trace), "source_indices": [y, v],
                            "action": a, "target_class": target_class, "record": record,
                            "left_probability": p, "right_probability": q, "difference": p-q,
                            "previous_labels": blocks})
                        found = True
                        break
                if found:
                    break
            assert found
        blocks = refined
        trace.append({"labels": blocks, "classes": max(blocks)+1})


def run() -> None:
    """Execute the fixed fifteen-subset menu and all exact admission checks serially."""
    input_path = ROOT / "docs/reports/data/2026-09-11-finite-data-formation/results.json"
    saved = json.loads(input_path.read_text(encoding="utf-8"))
    theory = saved["configuration"]["THEORY"]
    process, states = heterogeneous_process(tuple(F(x) for x in theory["couplings"]),
                                            F(theory["field"]), F(theory["signal"]))
    outputs = []
    summaries = []
    row_checks = 0
    for size in range(1, 5):
        for subset in combinations(range(4), size):
            local, local_states, exteriors, actions, records = adapter(process, states, subset)
            labels, history = coarsest_partition(local)
            quotient = quotient_process(local, labels)
            trace, witnesses = refinement_trace(local)
            assert trace[-1]["labels"] == labels
            assert tuple(item["classes"] for item in trace) == history
            for a, table in enumerate(local.emitted):
                for y, row in enumerate(table):
                    actual = aggregate_row(row, labels, len(records))
                    assert actual == quotient.emitted[a][labels[y]]
                    assert local.initial_sensor[a][y] == quotient.initial_sensor[a][labels[y]]
                    row_checks += 1
            local_index = {u: i for i, u in enumerate(local_states)}
            complement = tuple(i for i in range(4) if i not in subset)
            global_map = tuple((labels[local_index[tuple(y[i] for i in subset)]], tuple(y[i] for i in complement)) for y in states)
            fibers = []
            for z in range(quotient.size):
                for x in exteriors:
                    actual = [y for y, g in zip(states, global_map) if g == (z, x)]
                    expected = [assemble(u, x, subset) for u, label in zip(local_states, labels) if label == z]
                    assert actual == expected
                    fibers.append({"class": z, "exterior": x, "fine_states": actual})
            item = {"subset_zero_based": subset, "subset": [i+1 for i in subset],
                    "local_states": local_states, "exterior_states": exteriors,
                    "action_codebook": actions, "record_codebook": records,
                    "map": labels, "local_classes": quotient.size,
                    "refinement_trace": trace, "separating_witnesses": witnesses,
                    "global_map": global_map, "source_fibers": fibers,
                    "quotient_emitted": quotient.emitted,
                    "quotient_initial_sensor": quotient.initial_sensor,
                    "exact_source_row_factorization": True,
                    "initial_sensor_descends": True,
                    "start_emitted_probability": F(0),
                    "start_initial_probability": F(1)}
            name = "subset-" + "".join(str(i+1) for i in subset) + ".json"
            dump(name, item)
            summary = {"subset": "".join(str(i+1) for i in subset),
                       "children": size, "local_configurations": len(local_states),
                       "local_classes": quotient.size, "full_parent_states": quotient.size*len(exteriors),
                       "interface_bits": 4-size, "record_only_filter_coordinates": quotient.size*len(exteriors)-1,
                       "local_filter_coordinates_given_exterior": quotient.size-1,
                       "adapter_actions": len(actions), "adapter_records_with_start": len(records),
                       "adapter_stored_entries": len(actions)*quotient.size**2*len(records),
                       "physical_joint_stored_entries": 2*(quotient.size*len(exteriors))**2*2,
                       "refinement_counts": ";".join(map(str, history)),
                       "proper_local_compression": quotient.size < len(local_states),
                       "separating_pairs": len(witnesses), "artifact": name}
            summaries.append(summary)
            outputs.append(name)
            print(summary, flush=True)
    with (OUT / "admission.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)
    assert len(outputs) == 15 and row_checks == 480
    dump("execution.json", {"source_revision": "ed8f22a56df353b1535744509cc23fae46d5813c",
         "configuration": theory, "runtime": sys.version, "executable": sys.executable,
         "platform": platform.platform(), "subsets": 15, "source_rows_checked": row_checks,
         "compressed_subsets": [r["subset"] for r in summaries if r["proper_local_compression"]],
         "source_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in [input_path, ROOT/"src/multiagent_elbo/rg_v2/finite_data_formation.py",
                      ROOT/"src/multiagent_elbo/rg_v2/finite_formation.py"]},
         "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         "pytest_run": False, "artifacts": outputs})


if __name__ == "__main__":
    run()
