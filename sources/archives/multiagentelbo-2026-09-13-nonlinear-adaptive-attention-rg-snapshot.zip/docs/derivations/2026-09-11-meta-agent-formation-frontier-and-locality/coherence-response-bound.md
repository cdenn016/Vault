# Finite coherence and collective boundary response

September 12, 2026. Source worktree HEAD: `ed8f22a56df353b1535744509cc23fae46d5813c`. This is a conditional analytical result in the existing two-channel translation family at one base point. It gives an explicit error curve for a newly declared collective-response diagnostic. It selects no numerical tolerance, observes no new record, and specifies no kinetics.

## 1. Source continuity and exact target

Live [PIFB2.tex](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:epistemic_collapse` around line 1657, explicitly distinguishes useful finite coherence from perfect consensus. Its `eq:rg_closure` and surrounding argument around lines 3650–3695 separate a scalar energy estimate from the independent derivative estimate needed for a reduced force; the adiabatic-elimination discussion around line 3934 retains that distinction. The [wiki](<C:/Users/chris and christine/Desktop/Research/wiki/concepts/Meta-agents and hierarchical emergence.md>), opening operational definition and “Definitional hierarchy in the source manuscript,” requires joint law, evaluator, boundary access, marks and memory. None of these sources licenses deducing persistence from a one-state coherence statistic.

[Transported parent priors](transported-parent-priors-and-induced-couplings.md), Sections 2–4, defines the normalized Gaussian specialization and its actual transported child contrasts. [Complete parent channels](shared-parent-complete-channel-and-recursive-cost.md), Sections 3–7, supplies the retained carrier, translation covariance, mass-weighted geometric composition and the distinction between original probabilities and new parent-cut probabilities. [Common-prior hierarchy episodes](common-prior-native-hierarchy-episodes.md), Sections 4 and 8, already proves its fixed-query composition statement and explicitly leaves additional operational response and individual persistence separate. Those results are inputs here, not rederived formation claims.

The user-supplied direction is to preserve coherence and collective response. The diagnostic choice introduced here is the following: for each fixed realized rooted-tree partition, shift all child means within each block by the same channel-specific vector, while holding every interaction link and the structure fixed. This is an active hypothetical intervention on law-point means, not a passive gauge transformation, new observation, or motion prescribed by the native learner. The direction supplied by the user does not uniquely specify this intervention family.

The target quantifiers are: for every fixed realized structure, every finite configuration in the existing four-cycle family, each of the two channels separately, every original labeled cut, and every vector of collective shifts, bound the probability and its first derivative when the true child residual is replaced by the transported parent residual. Error is absolute probability error and Euclidean derivative error in the stated input coordinates. A subsequent corollary bounds total variation of finite Bernoulli-query transcripts under a common adaptive policy and a frozen latent draw. Exact native negative-ELBO and Fisher sufficiency continue to use the existing complete carrier; no approximate substitution into that native model is made.

Three mechanisms have distinct first obligations. The direct route needs an endpoint-contrast bound from retained tree disagreement. The variational route needs a positive conductance-normalizer floor before passing from probability derivatives to logarithmic interaction forces. The obstruction route needs a failure-probability singularity showing why the first two results are not a uniform bound for the full record likelihood. The direct route is proved first; the other two delimit its reach.

## 2. Residual identity and a certificate from retained probabilities

Let x be either channel b or m, each with mean vectors in R² and unit covariance. Suppress x temporarily. Fix a connected block A, its root, and its internal spanning tree. With the existing oriented tree-path translations g_i, put

\[
 z_A=\frac1{n_A}\sum_{i\in A}(\mu_i-g_i),\qquad
 \delta_i=\mu_i-g_i-z_A,\qquad \sum_{i\in A}\delta_i=0.
 \tag{1}
\]

For an original oriented edge e=(i,j), with i in A and j in B, retain its individual dressed mark V_e=ell_e+g_i-g_j. Define

\[
 r_e=\mu_j-\mu_i-\ell_e,
 \quad d_e=z_B-z_A-V_e,
 \quad \eta_e=\delta_j-\delta_i.
 \tag{2}
\]

Direct substitution gives r_e=d_e+eta_e. On an internal tree edge, V_e=0 and A=B, so r_e=delta_j-delta_i. The retained original probability p_e=exp(-||r_e||²/2) therefore gives the exact tree disagreement length sqrt(-2 log p_e). Every finite mean/link configuration has 0<p_e<=1; log p_e is well-defined, including p_e=1. No observed Bernoulli outcome is being substituted for p_e.

Choose positive, fixed diagnostic weights w_f on internal tree edges; w_f=1 requires no added model parameter. Define

\[
 D_A=\sum_{f\in T_A}w_f\|r_f\|^2
     =-2\sum_{f\in T_A}w_f\log p_f,
 \quad L_A=B_A^T\operatorname{diag}(w_f)B_A.
 \tag{3}
\]

Here B_A is the oriented incidence of the internal tree. These diagnostic weights are not a change to native couplings or learned energies. Connectivity and positive weights imply that ker L_A consists exactly of constant vectors: v^T L_A v is a sum of positive multiples of squared tree differences, which vanishes precisely for a constant v.

For n_A>1, define lambda_A as the least eigenvalue of L_A on the zero-sum subspace. It is positive because the quadratic form is positive there and the unit sphere is compact. Applying the defining inequality to each of the two coordinate columns in (1) gives

\[
 \sum_i\|\delta_i\|^2\le D_A/\lambda_A,\qquad
 \|\delta_i\|\le
 \sqrt{(1-1/n_A)D_A/\lambda_A}.
 \tag{4}
\]

For the second inequality, delta_i=(e_i-(1/n_A)1)^T delta and the squared norm of that coefficient vector is 1-1/n_A. Thus average internal disagreement is useful only together with its tree size and gap. For example, writing bar K_A=D_A/(2 sum_f w_f) gives the explicit factor 2(1-1/n_A)(sum_f w_f)/lambda_A multiplying bar K_A in the squared endpoint bound; an average alone does not give a graph-independent estimate.

A sharper endpoint coefficient is available without a spectral approximation. Let a_i=e_i-(1/n_A)1 and let L_A^dagger denote the inverse on the zero-sum subspace, extended as zero on constants. Set c_Ai=a_i^T L_A^dagger a_i. Then

\[
 \|\delta_i\|^2\le c_{Ai}D_A.
 \tag{5}
\]

To prove (5), put v=L_A^dagger a_i. For any scalar zero-sum contrast f, a_i^T f=v^T L_A f. Cauchy–Schwarz for the positive quadratic form on that subspace gives (a_i^T f)²<=(v^T L_A v)(f^T L_A f)=c_Ai(f^T L_A f). Sum over the channel coordinates. Equality is attained by a contrast proportional to v in one coordinate direction, so c_Ai is the sharp coefficient when only D_A is specified.

The individual retained lengths give an alternative exact worst-case radius. For a tree edge f, let N_i(f) be the number of vertices in the component of T_A\{f} that does not contain i. Define

\[
 R_{Ai}=\sum_{f\in T_A}\frac{N_i(f)}{n_A}
                         \sqrt{-2\log p_f}.
 \tag{6}
\]

Indeed, delta_i=n_A^(-1) sum_j[(mu_i-g_i)-(mu_j-g_j)]. Expanding each difference along its unique tree path gives signed coefficients with magnitudes N_i(f)/n_A. The triangle inequality proves ||delta_i||<=R_Ai. This is sharp for the individual edge-length information at that endpoint: orient all signed path increments along a common vector and center the reconstructed tree coordinates. These configurations exist because a tree imposes no cycle constraint. Other retained data can sharpen the radius further; no optimality relative to the complete carrier is asserted. For a singleton all these radii and D_A are zero, and no lambda_A is needed.

For a cut e=(i,j) between distinct blocks, let rho_Ai be any of (4), (5), or (6), or their minimum. Then the retained data certify

\[
 \|\eta_e\|\le\varepsilon_e:=\rho_{Ai}+\rho_{Bj}.
 \tag{7}
\]

For an internal non-tree edge the same method gives ||eta_e||²<=R_ij^eff D_A, where R_ij^eff=(e_j-e_i)^T L_A^dagger(e_j-e_i). Its tree expression is the sum of 1/w_f along the i-to-j path, obtained by sending unit flow along that unique path. Keep that edge's loop mark in d_e=-V_e. Thus retained nonzero holonomy is compatible with this calculation; no loop is silently set to zero.

Every definition and bound (1)–(7) is applied separately in channels b and m, using their own retained probabilities. The laws of their configurations may be correlated.

## 3. Uniform collective probability and derivative bounds

Apply mu_i(u)=mu_i+u_A to every i in A, with links fixed. Then z_A(u)=z_A+u_A, while delta_i, every internal disagreement, and every certificate (7) are unchanged. For a cut e,

\[
 r_e(u)=d_e+u_B-u_A+\eta_e.
 \tag{8}
\]

Put phi(v)=exp(-||v||²/2), p_e(u)=phi(r_e(u)), and hat p_e(u)=phi(d_e+u_B-u_A). The latter is the parent barycenter approximation. The existing carrier still retains exact p_e(0), so using hat p_e(0) is unnecessary for the original experiment.

For every v in Euclidean space,

\[
 \nabla\phi(v)=-v\phi(v),\qquad
 \nabla^2\phi(v)=(vv^T-I)\phi(v),
 \quad \|\nabla\phi(v)\|\le e^{-1/2},
 \quad \|\nabla^2\phi(v)\|_{\rm op}\le1.
 \tag{9}
\]

The gradient norm is t exp(-t²/2), maximized at t=1. The Hessian has tangential eigenvalue -exp(-t²/2) and radial eigenvalue (t²-1)exp(-t²/2). Their absolute values are at most one: for t>=1 the positive radial maximum is 2exp(-3/2)<1, and on 0<=t<=1 its absolute value is at most one. Integrating the first and second derivatives on the finite segment from v to v+eta proves, uniformly over all u,

\[
 |p_e(u)-\widehat p_e(u)|\le
       q_e:=\min\{1,e^{-1/2}\varepsilon_e\},\qquad
 \|\nabla_h p_e-\nabla_h\widehat p_e\|\le\varepsilon_e,
 \quad h=u_B-u_A.
 \tag{10}
\]

Each endpoint input derivative has the same bound epsilon_e. If U collects all block shifts with the ordinary Euclidean product norm, the incidence map U to u_B-u_A has operator norm sqrt(2); consequently the full U-gradient error is at most sqrt(2)epsilon_e. An internal edge is invariant under these block-uniform inputs and its U-gradient is zero. These are uniform bounds on a specified response and its derivative, not a bound for the complete VFE force.

In the two-pair sector A={0,1}, B={2,3}, with internal edges 01 and 23, the identity is particularly short:

\[
 \eta_{12}^x=\eta_{30}^x=-\tfrac12(r_{01}^x+r_{23}^x),\qquad
 \varepsilon_{12}^x=\varepsilon_{30}^x
 =\tfrac12\left[\sqrt{-2\log p_{01}^x}
                 +\sqrt{-2\log p_{23}^x}\right].
 \tag{11}
\]

Here x=b,m. A common relative input h=u_B-u_A enters edge 12 as +h and edge 30 as -h. The two errors share the same omitted vector; treating them as independent errors is not required by (10).

Conditional on the full frozen configuration, the existing two-channel success flags have their declared independent Bernoulli noises. Their joint-success probability is phi(r_e^b)phi(r_e^m), equal to the same radial exponential on R⁴. Thus (10) also bounds that scalar readout using sqrt((epsilon_e^b)²+(epsilon_e^m)²). A joint two-flag outcome, however, is a four-outcome kernel; coupling its two uniforms gives a TV bound at most min(1,q_e^b+q_e^m). After integrating the common structure and latent state, probabilities need not factor over channels, cuts, or parents. All these comparisons use the full correlated pushforward law.

## 4. Finite adaptive query law

Freeze a complete fine draw X, its structure and its parent pushforward. A permitted query selects a labeled edge, channel and collective input; it returns one Bernoulli draw with the probability in (10). Let the same possibly randomized policy select successive queries using only common retained information and the previous query transcript. It has no extra fine-only state access. Couple the policy randomness and the Bernoulli uniforms until the first differing answer.

If every possible query has error bound q_t at step t, the conditional probability of a first mismatch at that step, given an identical past, is at most q_t: for two Bernoulli probabilities the common-uniform mismatch probability is exactly their absolute difference. Induction therefore gives

\[
 \operatorname{TV}(\mathcal L_X(\text{fine transcript}),
                   \mathcal L_X(\text{parent transcript}))
 \le1-\prod_{t=1}^K(1-q_t)
 \le\min\{1,\sum_{t=1}^Kq_t\}.
 \tag{12}
\]

The first inequality follows because any event can differ between the coupled transcripts only if some answer differs. Query labels and inputs are part of the transcript; they remain identical before that first mismatch. When q(X) is the maximum of the retained per-label certificate over the permitted queries, integrating the same coupling against any joint model or recognition law Q gives

\[
 \operatorname{TV}(\mathcal L_Q(\text{fine transcript}),
                   \mathcal L_{Q_R}(\text{parent transcript}))
 \le\mathbb E_Q[\min\{1,Kq(X)\}].
 \tag{13}
\]

In particular, a good-state set with Q-probability at least 1-delta and q(X)<=q there gives delta+Kq, capped at one. It does not justify conditioning away the complement. Gradient readouts are covered by the Euclidean bound in (10), not by this Bernoulli TV theorem: unequal deterministic real-valued outputs can have TV distance one. No infinite-query or evolving-latent process equivalence follows from (12).

## 5. A conditional interaction-potential force bound

The source's raw-conductance mechanism admits a limited C1 conclusion here. Fix one channel, finitely many incident labels, coefficients a_e>=0 independent of U with A_0=sum_e a_e>0, and tau>0. On a declared input domain D, set

\[
 Z(U)=\sum_e a_ep_e(U),\qquad
 \widehat Z(U)=\sum_e a_e\widehat p_e(U),\qquad
 F=-\tau\log Z,\quad \widehat F=-\tau\log\widehat Z.
 \tag{14}
\]

These are diagnostic interaction potentials, not the full native free energy. Assume the explicit additional floor Z(U),hat Z(U)>=m>0 throughout D. Define b_e as the operator norm of the label's input incidence map (sqrt(2) for an unrestricted cut), and

\[
 a_0=e^{-1/2}\sum_ea_e\varepsilon_e,\quad
 a_1=\sum_ea_eb_e\varepsilon_e,\quad
 M_1=e^{-1/2}\sum_ea_eb_e.
 \tag{15}
\]

The finite sums and (10) imply |Z-hat Z|<=a_0, ||grad Z-grad hat Z||<=a_1 and ||grad hat Z||<=M_1. Since the derivative of log t is 1/t,

\[
 \|F-\widehat F\|_\infty\le\tau a_0/m,\qquad
 \|\nabla F-\nabla\widehat F\|_\infty
 \le\tau\left(a_1/m+M_1a_0/m^2\right).
 \tag{16}
\]

For the derivative estimate, subtract grad Z/Z and grad hat Z/hat Z, first subtracting their numerators with denominator Z and then subtracting the reciprocal denominators. The two terms have exactly the bounds displayed in (16). No differentiation under an infinite integral is used.

One sufficient floor is a bounded domain with ||d_e+B_eU||<=R for every label and epsilon_e<=epsilon_*: then m=A_0 exp(-(R+epsilon_*)²/2). An already present common positive constant conductance would also supply a floor. Adding such a term to obtain a bound would change the potential and is not performed here. If only hat Z>=m_0 is known and a_0<m_0, use m=m_0-a_0. If coefficients depend on U, their derivative contributions must be included separately; (15) does not cover them.

Thus a genuine first-derivative error is established for the expressly defined interaction term under a normalizer floor. Neither the other VFE terms nor changes of the native Fisher metric are bounded by this argument. Full natural-gradient closure would require those further terms and a controlled inverse metric. The independent force-level obligation in PIFB2 is narrowed in this specialization, not closed for its full functional class.

## 6. Recursive displacement errors and what must remain accessible

At any stage, let the actual current nodes A have masses m_A, means z_A and individual marks V_e. For a next block C choose path translations t_A along its actual retained cut tree and form

\[
 z_C=\frac{\sum_{A\subset C}m_A(z_A-t_A)}{M_C},\qquad
 \Delta_A=z_A-t_A-z_C,\qquad
 \sum_{A\subset C}m_A\Delta_A=0,
 \quad M_C=\sum_{A\subset C}m_A.
 \tag{17}
\]

For a retained original edge copy from A in C to B in D, the existing mark update is V_e^new=V_e+t_A-t_B. Direct substitution, without replacing the current means by fresh fitted parents, gives

\[
 d_e^{\rm old}=d_e^{\rm new}+\Delta_B-\Delta_A.
 \tag{18}
\]

On a next-stage tree edge inside C, d_e^old=Delta_B-Delta_A. The argument of Section 2 applies again with weighted centering: replace a_A by e_A-m/M_C in (5), or replace N_i(f)/n_A by the total mass across f divided by M_C in (6). The energy uses that stage's tree residuals d_e^old, obtained from its own parent-cut probabilities exp(-||d_e^old||²/2). These are generally not the original fine p_e. Scalars or geometry needed to compute them must be retained before their arguments are discarded.

Iterating (18) along any fixed finite hierarchy gives the exact telescoping identity

\[
 r_e=d_e^{(L)}+\eta_e^{(0)}
          +\sum_{s=1}^{L-1}(\Delta_{B_s}^{(s)}-\Delta_{A_s}^{(s)}),
 \quad
 \|r_e-d_e^{(L)}\|\le\varepsilon_e^{(0)}
          +\sum_{s=1}^{L-1}\varepsilon_e^{(s)}.
 \tag{19}
\]

At the top, collective inputs are lifted uniformly to all constituents of each current top block. All lower contrasts in (19) are then unchanged, so (10) applies with the summed radius. This does not preserve the ability to independently move two earlier blocks after they merge: those older input directions require their own retained response evaluator or decoder. Every original cut that becomes a loop keeps its label, incidence history and mark; its current top-level input incidence is zero. Dropping those labels would be a changed query contract.

A fixed per-level error need not remain small at large depth. A uniform-depth claim would need a bounded sum of the actual stage radii (and the desired finite-query budget). The present result is finite-depth only. The existing exact geometric and native-law composition theorem is not itself an error estimate for these new inputs.

## 7. Limits, accounting, and remaining obligation

Coherence controls an approximation, not exact response sufficiency. Equation (10) does not reconstruct the omitted vector eta_e from its norm bound. Exact response reconstruction is a distinct problem; no continuous-dimension or bit lower bound is claimed in this report.

The logarithmic failure likelihood gives a sharp limit on the conclusion. For eta!=0 choose the relative input so that d+h=-eta. Then the exact response is p=1, while hat p=exp(-||eta||²/2)<1. Consequently -log(1-p) is infinite and -log(1-hat p) is finite, even when ||eta|| is arbitrarily small. Near a zero residual, the failure score has magnitude of order 2/||r||. Thus neither uniform probability error nor its derivative bound controls failure log likelihoods on all collective inputs. Original failure observations can exclude p=1 under the original posterior without removing the singularity from this unrestricted hypothetical input domain. By contrast, the coherence statistic -log p itself is finite at p=1. For a success term, the energy discrepancy is (d+h) dot eta+||eta||²/2, which has no uniform scalar bound on an unbounded input domain either.

The added first-stage radii are computable from the already retained internal p entries and tree/mass metadata. They can be evaluated on demand or cached with explicit cost; they do not establish additional compression. Keeping S, the original p catalog, all geometric means/marks and the existing parent-cut probabilities preserves the previous exact native-statistics result and its counts. On the four-cycle the geometric carrier still has 12+8q continuous fields before any required new evaluator additions; the uniform-panel carrier retains its existing count $12+8q+2k\mathbf1_{q<k}$. No field saving is credited to (10). Endpoint lookup, shared access, tree coefficients, logarithms and square roots, derivative evaluation, caching and controller memory require their ordinary storage/computation charges. A fine implementation can use the same certificate and shared evaluator.

The invariant contrasts under (8) mean that internal coherence survives this particular collective diagnostic exactly. They do not mean that coherence remains small during native inference, model learning or changing sampled links. The existing prior/recognition laws remain correlated and their downward kernels remain the existing correlated conditionals; no product reset is introduced. The native hierarchy episodes do not certify these new radii along a sampled path. Persistence of one evolving sampled configuration would additionally need specified state kinetics and an invariant/tube estimate for its contrasts.

The strongest supported result is a label-preserving, two-channel, finite-tree certificate for uniform collective probability and derivative error, with finite adaptive Bernoulli-query TV control, finite-depth telescoping, and the conditional interaction-potential C1 estimate (16). Its proof is the written algebra above. No symbolic/numerical experiment, old scientific rerun, ODE, GPU, Lean, tamper check or formal-ledger closure was run. Only this report was written in this assignment; source manuscripts and other workers' files were left intact.

The companion [response-access analysis](coherence-response-access.md) supplies the separate exact-access result; it is summarized together with this bound in [coherence and collective response](coherence-and-collective-response.md). For approximate access, (7) and (10) already provide the error curve without choosing a tolerance. The next bounded mathematical step is to bound the law-level quantity in (13) over an existing native interval, using its full correlated Q_t and, where required, the current model posterior. A uniform bound would establish persistence of the frozen-query guarantee across that family of laws without introducing individual-state kinetics. It would not specify the joint path law of a changing sampled state, and no such stronger physical-persistence claim is made here.
