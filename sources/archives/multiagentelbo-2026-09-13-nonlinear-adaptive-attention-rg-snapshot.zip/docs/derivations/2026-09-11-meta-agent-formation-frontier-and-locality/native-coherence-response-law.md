# Collective-response bounds under the native population law

September 12, 2026. This analytical continuation applies [the frozen-query certificate](coherence-response-bound.md) to the existing native population family. It specifies one geometric candidate probe on every generative ancestry, retains the full joint law, and adds no observation, fitted parameter, tolerance, trajectory or sampled-state kinetics.

## 1. Sources, domains and one common query task

[Common-prior native hierarchy episodes](common-prior-native-hierarchy-episodes.md), Sections 1–6, fixes the forty-five decorated connected ancestries, the original ordered records, the seven-coordinate native learner, its existing path enclosure, and the distinction between law preference and permanent membership. [Transported parent priors](transported-parent-priors-and-induced-couplings.md), Sections 2–4, supplies the normalized Gaussian generator and the transported child-noise energy. [Complete parent channels](shared-parent-complete-channel-and-recursive-cost.md), Sections 3–4, permits a geometric output partition different from the retained generative ancestry. The [response-access report](coherence-response-access.md) separates exact point-preparation response from native conditional prediction. The previously consulted live PIFB2 `sec:epistemic_collapse` and `eq:rg_closure`, and the wiki's operational parent definition, retain their scope: probability response, full VFE force and sampled-state persistence are different questions.

Fix the same geometric candidate on every fine draw: A={0,1}, B={2,3}, roots 0 and 2, tree paths g_0=g_2=0, g_1=ell_01, g_3=ell_23. Write this probe partition as R_probe to distinguish it from the latent generative ancestry in H. Form its actual barycenters and dressed cuts using these paths, even when H is one-block ancestry O or another ancestry. This deterministic probe changes neither H nor its generative density and conditions away no branch. It tests this candidate grouping; it is not a claim that the native learner selected it.

For each channel x=b,m and edges e=12,30, shift all child means in A or B uniformly with relative input h^x=u_B^x-u_A^x, holding links fixed. The response and its barycenter approximation are

\[
 p_e^x(X,h)=\phi(r_e^x+s_eh^x),\quad
 \widehat p_e^x(X,h)=\phi(d_e^x+s_eh^x),\quad
 \phi(z)=e^{-\|z\|^2/2},\quad s_{12}=1,\ s_{30}=-1.
 \tag{1}
\]

The earlier algebra gives, for every fine configuration and every generative H,

\[
 r_e^x=d_e^x+\eta^x,\qquad
 \eta^x=-\tfrac12(r_{01}^x+r_{23}^x),\qquad e=12,30.
 \tag{2}
\]

This follows from the two zero-sum contrasts within each probe pair and does not require its tree paths to equal the generative tree paths. The complete output retains H, every original p and energy statistic, both probe barycenters and both dressed cuts. Thus the same input/label policy and the same comparison are defined on every native draw.

The result below holds at every finite native time for positive model and recognition variances and likelihood power s=1, which is invariant on the existing unit-start learner. All four cycle labels and both channels remain in the conditioning records. Norms are ordinary Euclidean channel norms. The transcript result concerns each finite K and all common adaptive policies using retained information and preceding Bernoulli answers, with one frozen draw reused throughout that transcript. Native time indexes the preparation law; it does not define a process joining draws at different times.

## 2. Exact residual moments from the original positive likelihood

Use edge order (01,12,23,30), indices 0,1,2,3, and success vector n=(8,1,8,1). Given H, one coordinate direction of a channel has centered Gaussian covariance

\[
 \Gamma_H(r)=r_aG_a+r_bG_{b,H}+r_cG_{c,H}>0.
 \tag{3}
\]

Positivity follows from the transported-generator proof: the first term has only the constant cycle direction in its kernel, and the link term is positive on that direction. The two coordinate directions are independent before their common channel likelihood. Put S_e=||r_e^x||²/2. That likelihood is L_x=prod_e exp(-n_e S_e)(1-exp(-S_e)). It lies in [0,1], is strictly positive off the finite union of sets r_e^x=0, and hence is positive almost everywhere under the nonsingular Gaussian. Its integral e_H therefore satisfies 0<e_H<=1. All polynomial moments of the tilted law are finite.

For a failure mask M contained in the four labels, define

\[
 D_M=\operatorname{diag}(n+\mathbf1_M),\quad
 d_{H,M}=\det(I+\Gamma_HD_M),\quad
 \Lambda_{H,M}=(\Gamma_H^{-1}+D_M)^{-1},
 \tag{4}
\]
\[
 e_H=\sum_M\frac{(-1)^{|M|}}{d_{H,M}},\qquad
 T_H=\sum_M\frac{(-1)^{|M|}\Lambda_{H,M}}{d_{H,M}},\qquad C_H=T_H/e_H.
 \tag{5}
\]

These inverses and determinants exist: Gamma_H and D_M are positive definite, and det(I+Gamma_H D_M)=det(Gamma_H)det(Gamma_H^(-1)+D_M)>0. Expanding the four failure factors is a finite identity. For one coordinate direction, completing the Gaussian square gives integral d_HM^(-1/2) and unnormalized second moment d_HM^(-1/2)Lambda_HM. Multiplying by the other direction's integral proves (5). Thus C_H is the actual per-coordinate residual second-moment matrix of the original normalized positive likelihood tilt. In particular C_H is positive definite: every nonzero linear residual coordinate has a nonzero square on a set of positive tilted density.

The alternating terms in (5) are not mixture probabilities. If a positive integral representation is desired, each failure factor also equals S_e times the integral from 0 to 1 of exp(-t S_e) dt; their product gives a positive integral of polynomial-weighted Gaussian densities. The original positive density, not signs in the finite expansion, establishes normalization and moment positivity. No signed term is sampled or clamped.

Let v=(1,0,1,0)^T and define

\[
 \nu_H=\tfrac12v^TT_Hv,\qquad
 m_H=\mathbb E[\|\eta^x\|^2\mid H,o]=\nu_H/e_H
     =\tfrac12(C_{H,00}+C_{H,22}+2C_{H,02}).
 \tag{6}
\]

The factor one half includes both coordinate directions: each has eta-coordinate variance v^T C_H v/4. Channel rotation symmetry makes the two directions identically distributed and their cross moment zero. For exact computation without inverting Gamma_H, the numerator is equivalently half the sum over M of (-1)^|M| v^T adj(I+Gamma_H D_M)Gamma_H v divided by d_HM², since Lambda_HM=(I+Gamma_H D_M)^(-1)Gamma_H.

## 3. Full native mixing and response curves

The two channels have the same records and are conditionally independent given H under the native preparation. They share H. With the existing recognition count coordinate lambda and structural prior pi_R w(H|R), define

\[
 a_H=\pi_{R(H)}w(H\mid R(H))e^{\lambda k_H},\quad
 Z=\sum_H a_He_H^2,\quad \alpha_H=a_He_H^2/Z,
 \quad M_Q=\sum_H\alpha_Hm_H
          =\frac{\sum_Ha_He_H\nu_H}{Z}.
 \tag{7}
\]

The common exponential factor exp(lambda) may be canceled as in the existing evaluator. Every generative ancestry with positive prior is included. The two-channel evidence is e_H² before summing over H; squaring a separately mixed one-channel evidence would change the law. Although the two channel moments each equal M_Q, the unconditional channels need not be independent. The current model-posterior formula is identical with model variances (a,b,c) in (3) and lambda=0; denote its result by M_Pi. Root variance cancels from all residuals.

The retained coherence radius epsilon_x=(||r_01^x||+||r_23^x||)/2 also obeys

\[
 \mathbb E(\varepsilon_x^2\mid H,o)
 \le\tfrac12(\sqrt{C_{H,00}}+\sqrt{C_{H,22}})^2
 \le C_{H,00}+C_{H,22}.
 \tag{8}
\]

The first inequality is Cauchy–Schwarz for the mixed norm moment; the second is 2sqrt(ab)<=a+b. Averaging (8) gives a certificate from the retained length bound. Formula (6) is potentially sharper because it includes the actual cross moment C_H,02. It is a law-level calculation from the correlated joint, not a claim that the omitted direction is pointwise known from the compressed carrier. Mean-zero eta alone does not cancel a first-order response term, since eta can be correlated with d_e.

The frozen-query proof gives a statewise probability error at most exp(-1/2)||eta^x||, uniformly in h and in either cut. Cauchy–Schwarz implies E||eta^x||<=sqrt(M_Q). Integrating the same common-uniform transcript coupling gives the following bounds, each capped at one:

| One query returns | Permitted channel choice | TV bound for K queries |
| --- | --- | --- |
| One Bernoulli flag | A fixed channel or externally preassigned schedule independent of the draw, with adaptive cut/input | K sqrt(M_Q/e) |
| One Bernoulli flag | Either channel chosen adaptively from the common history | K sqrt(2M_Q/e) |
| One Bernoulli flag for joint success of both channels | Adaptive cut and two-channel input | K sqrt(2M_Q/e) |
| Both channel flags separately | Adaptive cut and two-channel input | 2K sqrt(M_Q/e) |

For an adaptive choice of channel, the statewise error is bounded by exp(-1/2) max(||eta^b||,||eta^m||). Its expectation is at most sqrt(2M_Q/e), using max(a,b)²<=a²+b²; no independence is used. A preassigned channel schedule independent of the draw and query outcomes gives the first row by summing the corresponding unconditional norm expectations. For joint success, phi(r^b)phi(r^m) is the same exponential on R⁴ and its omitted squared norm has expectation 2M_Q. For two separately returned flags, couple both uniforms and sum their mismatch probabilities. A fixed-channel average cannot be used when the channel choice depends on retained state information or the history without this additional bound.

One may retain the sharper intermediate expectation E[min(1,Kq(X))] or average sqrt(m_H) before the final Cauchy–Schwarz step. The table is the simple certificate requiring only (7). It bounds the same full-law task for fine and parent preparations, without discarding non-P ancestries, selecting a favorable decoration, or granting a special exact branch. Replace M_Q by M_Pi for the model posterior. The averaged relative-input probability-gradient error is at most sqrt(M_Q) for a fixed channel, by the earlier statewise gradient bound and Cauchy–Schwarz. Passing the derivative through the preparation integral is valid because the probability gradient is uniformly bounded by exp(-1/2); the preparation law is held fixed while differentiating h.

## 4. An anchored response using the already retained probability

The actual carrier knows p_e^x(X,0) exactly. Define a second normalized Bernoulli query evaluator using that anchor:

\[
 \widehat p_{e,\mathrm{anc}}^x(X,h)=
 \operatorname{clip}_{[0,1]}\{p_e^x(X,0)
       +\phi(d_e^x+s_eh^x)-\phi(d_e^x)\}.
 \tag{9}
\]

It is measurable, lies in [0,1], and agrees exactly with the original probability at h=0. It modifies only the declared diagnostic response kernel; the original record likelihood and native learner are unchanged. The clipping is required for this additive construction to be a Bernoulli probability on every finite configuration and input.

Suppress channel/edge indices and put k=s_e h. The true response minus the unclipped anchored expression is

\[
 [\phi(d+\eta+k)-\phi(d+\eta)]-[\phi(d+k)-\phi(d)]
 =\int_0^1\int_0^1 k^T\nabla^2\phi(d+t k+u\eta)\eta du dt.
 \tag{10}
\]

The Hessian norm is at most one by the previous proof. Consequently its absolute value is at most ||h||||eta||. Alternatively, subtracting the two displaced-point probability errors gives 2exp(-1/2)||eta||. Projection onto [0,1] cannot increase the error relative to the true probability in that interval: below zero it moves toward every such target, above one likewise, and inside the interval it changes nothing. Thus for all ||h||<=R, the anchored probability error is at most c_R||eta||, where c_R=min(R,2exp(-1/2)).

The same transcript coupling now gives TV at most min(1,K c_R sqrt(M_Q)) for a fixed/external channel schedule, and min(1,K c_R sqrt(2M_Q)) when the policy may choose the channel from common retained state/history. Inputs and cuts may remain adaptive. Both separately reported channel flags give min(1,2K c_R sqrt(M_Q)) when each channel input has norm at most R. A joint-success Bernoulli admits the R⁴ construction if R bounds the combined input norm; its omitted second moment is 2M_Q. The current model posterior uses M_Pi instead. These are explicit radius-by-query-count curves with no chosen R, tolerance or horizon. Clipping can create nondifferentiable boundaries, so this paragraph makes no C1 or full-force claim for the anchored kernel.

## 5. Uniform native intervals and positive-prior continuation

For either existing compact interval I=[5,7] or I=[35,40], an outward readout of (7) over the already enclosed native path can provide upper bounds U_Q,I and U_Pi,I. Substituting these constants for the moments in the table and the anchored curves proves a guarantee uniform over t in I, every finite K and every permitted policy. The comparison is a family of frozen-query experiments indexed by native time. It is not a total-variation estimate for an evolving hidden-state path, a new native trajectory, or a change to its retained observation likelihood.

There is an exact conditional continuation theorem. Suppose the reference path at the existing O/P boundary prior satisfies a strict inequality M_Q(t)<U on a compact interval, uniformly with positive margin; impose any finite collection of such strict inequalities for the two moment readouts or their interval comparisons. Then these inequalities persist on a nonempty relatively open family of strictly positive priors sufficiently close to the reference, simultaneously with the earlier strict split/merge regime inequalities.

To prove this, the reference positive-variance path lies in a compact coordinate tube. Gamma_H stays positive definite there; all e_H are positive continuous functions, the finite mixture denominator Z stays positive, and K_pi stays positive. Formula (5) and the native vector field therefore have bounded state and prior derivatives on a smaller tube, including a neighborhood of the boundary prior. If B bounds the prior derivative and L the state derivative of that field, a perturbation delta of the fixed prior gives state error at most B delta t exp(Lt), up to the tube exit. This bound follows by differentiating the state-difference norm inequality and comparing with that explicit supersolution; choosing delta small enough prevents the exit. Bounded derivatives of (7) then give a uniform moment perturbation bound tending to zero with delta. Choosing it below half every strict margin proves preservation. This is the same finite-time dependence mechanism already used for the hierarchy preferences, now matched to the explicit new readout.

The existing curve pi_O=pi_O^0+epsilon, pi_P=pi_P^0-epsilon-10epsilon², and pi_R=epsilon² for the other ten ancestries enters the full-positive simplex for all sufficiently small epsilon>0. Intersect its sufficiently small members with the strict-margin neighborhoods just proved. Each such member has a relative-open neighborhood with the same inequalities. No numerical prior is selected, and no data-dependent prior optimization is performed. If a readout gives only a non-strict limiting comparison, this argument does not promote it to a strict open-family conclusion; if it gives no useful upper bound, the table remains valid but possibly vacuous.

## 6. Certified readout on the existing native windows

The new [exact numerator record](evidence/native-coherence-response/moment-polynomials.json) reports `PASS_EXACT_RESPONSE_MOMENT_COEFFICIENTS`. [response_moments.py](evidence/native-coherence-response/response_moments.py) produced rank-one and diagonal moment numerators for 112 failure terms across seven distinct covariance maps, reusing the existing evidence denominators. Every term was checked against an independently evaluated exact Fraction covariance inverse at unit variances. This run took 0.2993387000024086 seconds under pinned CPython 3.14.7. The stored exact unit moment is approximately 0.2159921242554.

The new [window record](evidence/native-coherence-response/moment-window-enclosures.json) reports `PASS_NATIVE_RESPONSE_MOMENT_WINDOWS`. [enclose_response_windows.py](evidence/native-coherence-response/enclose_response_windows.py) evaluated 17 intervals covering [5,7] and 41 covering [35,40], using 128-bit dyadic intervals and order-10 response jets. It reconstructed candidate coefficients from the saved DOP853 dense segments as exact fractions, and enlarged them by twice the existing weighted path error to cover each coordinate of the actual native solution. The record binds the scripts, moment coefficients, saved trajectory, earlier path enclosure and regime-window receipt by source hashes. All 58 new readout intervals passed in 12.642194700005348 seconds under the same pinned runtime. The old ODE and its path enclosure were not rerun.

The table gives outward-rounded decimal supersets of the stored exact rational enclosures. The numerical reference has the existing O/P prior, with twenty decorations and seven distinct residual covariances. The fixed geometric pair probe is applied to every one of those draws, including generative O. No conditional-P replacement is used.

| Native window | Recognition M_Q | Current model-posterior M_Pi |
| --- | --- | --- |
| [5,7] | [0.181245915, 0.196359349] | [0.174707415, 0.190241281] |
| [35,40] | [0.119453661, 0.121633988] | [0.119438088, 0.121538063] |

The exact upper square-root bounds give sqrt(2M_Q)<0.626673 and sqrt(2M_Pi)<0.616833 throughout the early window, and respectively <0.493223 and <0.493028 throughout the late window. Choosing the strictly larger shared coefficients 0.628 and 0.494 yields, for either complete law and for policies choosing either channel adaptively,

\[
 \operatorname{TV}_{\rm anchored}\le
 \begin{cases}
 \min\{1,0.628 K\min(R,2e^{-1/2})\},&t\in[5,7],\\
 \min\{1,0.494 K\min(R,2e^{-1/2})\},&t\in[35,40].
 \end{cases}
 \tag{11}
\]

In particular the simpler bounds min(1,0.628 K R) and min(1,0.494 K R) hold. For the unanchored barycenter evaluator the corresponding bounds are min(1,0.628 K exp(-1/2)) and min(1,0.494 K exp(-1/2)). These are curves for all finite K and input radii R; neither is a selected workload or loss tolerance. Their constants have strict slack, so Section 5 proves that the same constants and the earlier split/merge preference windows coexist on a smaller nonempty relative-open family of priors positive on all twelve connected ancestries. That extension uses all forty-five decorations analytically. No perturbed trajectory was numerically evaluated, and the narrow table ranges are asserted only for the reference.

The late moment upper bound is strictly below the early moment lower bound under each law. This proves a uniform reduction in this fixed probe's omitted-vector second moment between the two windows. It does not attribute that reduction causally to the parent merge, establish monotonicity between the windows, or prove that every realized sample improves. For comparison, the looser retained-length quantity T_Q=sum_H alpha_H(C_H,00+C_H,22) lies in [0.364893793,0.396688237] early and [0.237452661,0.242181303] late. Thus using the joint residual moment gives a strictly sharper bound than discarding its directional/cross-moment information in (8).

## 7. Evidence boundary and next obligation

Equations (2)–(10), the query table, anchored bounds and the continuation theorem are analytical derivations. The two new calculations just cited instantiate the window constants; their saved outputs were read without rerunning them during this report update. No new ODE, parameter grid, sample path, observation, GPU, Lean, tamper check or formal-ledger closure was run. Existing scientific outputs and other workers' files were preserved. The positive posterior formula does not excuse an interval evaluation whose denominator enclosure includes zero or whose cancellation error is uncontrolled.

The fixed candidate's complete carrier still retains H and the original native sufficient statistics; computing a moment certificate adds no proved storage compression and its evaluator cost must be counted. Exact point-preparation response can use the separate directional augmentation already derived, while this report assesses the unaugmented barycenter approximation under the native law. Neither option is selected as preferable here. Applying the same probe to O ancestry is intentional and leaves that ancestry in the law; it must not be described as evidence that O spontaneously split.

The strongest supported statement is the full-law response certificate with (11) uniformly on the existing native windows, including an anchored kernel exact at zero input and a strict continuation to a nonempty open full-positive-prior family. The moment-readout obligation is now completed within this finite specialization. The next bounded step is comparison of complete candidate interfaces for this same query task using these error curves and actual evaluator/storage costs. A final loss tolerance or workload selection is not supplied by this theorem, and persistence of a single changing sampled state is not claimed.
