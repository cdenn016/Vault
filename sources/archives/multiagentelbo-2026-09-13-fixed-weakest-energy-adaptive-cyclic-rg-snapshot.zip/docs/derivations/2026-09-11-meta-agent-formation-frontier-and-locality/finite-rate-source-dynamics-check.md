# Reconstruction of the finite-rate source investigation

September 13, 2026. This bounded check covers S1–S13 of [the finite-rate investigation](finite-rate-source-dynamics-investigation.md), including the conditional S7 discriminator, the rate-composition identity, and the two-hidden-state counterexample. The identities are correct under their stated assumptions. They establish a reversible positive-mobility candidate and exact identities for its rates and entropy. They do not establish the positive-mobility formation hierarchy or a path-averaging theorem.

## Exact target and source assumptions

Fix a finite source-assignment set $\mathcal J$, $T>0$, $\nu>0$, and $a$ in the compact interval $[1,2.1]$. The input is the normalized optimizing joint

\[
p_a(x,j)=Z_a^{-1}\pi_j(a)e^{-G_a(x)/T-\phi_j(x)},
\qquad x\in\mathbb R^d,\quad j\in\mathcal J,
\tag{C1}
\]

with positive smooth source priors, bounded smooth $\phi_j$, a confining quadratic continuous core, and the regularity from E24–E29. Recognition is an unrestricted positive joint density $q(x,j)$. For descent identities, assume a smooth solution, finite displayed entropy/Fisher terms, and decay sufficient for integration by parts. For the frozen-parameter or prescribed-parameter process, the sheet drifts are globally Lipschitz with linear growth at each fixed finite choice of parameters. These are supplied assumptions; the check does not infer uniform estimates or coupled continuation from them.

The assertions quantified over such inputs are normalization, frozen-parameter reversibility, the full VFE derivative, source-mass identities, optimizer-conditioned rate reversibility and fixed-parameter composition, and the same-time generator bound. S7 has the additional specific hypothesis $a_t\ge7/4$ throughout the final ten units of the horizon. The counterexample is existential on a finite hidden carrier. The target notion of exactness is equality of normalized static laws and conditional expectations, not equality of projected and autonomous path laws.

The source consultation used the current STATUS; Theory/05b from the recognition factorization through the posterior, correlated-recognition, and replicator formulas; attention-admission R9–R11; live PIFB2 section sec:mixture_derivation; the September 13 paragraphs of the live staged-hierarchy synthesis; and published E24–E29. Their distinctions are retained: the posterior source row, actual conditional recognition row, and constant-row Fisher coordinate flow are different objects. The scalar F is inherited from the same normalized model. No physical posterior is substituted for its optimizer, and the investigation remains at one fixed base point.

## 1. Generator, full score, and exact dissipation

Let $q_X=\sum_jq_j$, $\eta_j=q_j/q_X$, and $b_j=p_{a,j}/p_{a,X}$. In C1 the additive receiver costs and product prior imply that $b$ factors over receiver rows at a fixed $x$. They do not force $\eta$ to factor or to be independent of $x$.

For $j\ne k$ the jump rate in S2 is $K_{jk}(x)=\nu b_k(x)$. Its conservative diagonal is $K_{jj}=-\nu(1-b_j)$. Thus its exit rate is $\nu(1-b_j)\le\nu$. A Poisson clock of rate $\nu$ with complete-assignment redraws from $b$ implements that generator; events redrawing the same assignment are allowed clock events and contribute zero to the generator. No factor of $|\mathcal J|$, no factor of $T^{-1}$, and no additional independent per-receiver clock belongs in S2.

The associated forward jump equation is

\[
\left.\partial_tq_j(x)\right|_{\mathrm{jump}}
=\sum_{k\ne j}\nu q_kb_j-\nu q_j(1-b_j)
=\nu(q_Xb_j-q_j).
\tag{C2}
\]

The diffusion on sheet $j$ can be written

\[
L_jf=T p_{a,j}^{-1}\nabla_x\cdot(p_{a,j}\nabla_x f),
\tag{C3}
\]

because $\nabla_x\log p_{a,j}=-T^{-1}\nabla_x(G_a+T\phi_j)$. The unnormalized sheet mass in $p_{a,j}$ is constant in $x$, so it does not alter C3. The jump conductance satisfies

\[
p_{a,j}K_{jk}=\nu p_{a,X}b_jb_k=p_{a,k}K_{kj}.
\tag{C4}
\]

Consequently both parts are reversible for the same frozen optimizing joint. Given a continuous compact-valued parameter path, interlacing the unique sheet SDEs with the bounded-rate Poisson clock gives a nonexplosive process. This construction alone says nothing about the claimed future coupled parameter bootstrap.

The full VFE is $F_T=T D(q\Vert p_a)+C_T(a)$. At fixed $q$, expanding C1 together with the inherited evidence scalar yields exactly the S3 covector

\[
\partial_aF_T
=a-2+\tfrac12E_qx^THx
-\tfrac T2\operatorname{tr}(A_0^{-1}H)
-T\sum_j\lambda_j\partial_a\log\pi_j(a),
\qquad \lambda_j=\int q_j(x)dx.
\tag{C5}
\]

The fact that $\lambda_j(t)$ now changes does not add a second parameter-score term: its time derivative is already included in the variation with respect to $q$. C5 is the partial derivative holding that entire current law fixed. The same inherited microscopic metric $m(a)$ gives the parameter contribution $-\epsilon m(a)^{-1}g^2$.

For the continuous contribution, integration by parts gives

\[
\left.\frac{dF_T}{dt}\right|_{\mathrm{diffusion}}
=-T^2\sum_j\int q_j
\left|\nabla_x\log(q_j/p_{a,j})\right|^2dx.
\tag{C6}
\]

For the jump contribution, use $\sum_j(b_j-\eta_j)=0$ to cancel all terms depending only on $x$, including the $+1$ in the entropy derivative:

\[
\begin{split}
\left.\frac{dF_T}{dt}\right|_{\mathrm{jump}}
&=\nu T\int q_X\sum_j(b_j-\eta_j)\log(\eta_j/b_j)dx\\
&=-\nu T\int q_X\{D(\eta\Vert b)+D(b\Vert\eta)\}dx.
\end{split}
\tag{C7}
\]

C5–C7 prove S4 with its stated factors. There is no missing $1/2$ in C7. Writing the same quantity as a sum over ordered conductance pairs introduces a $1/2$ because each unordered pair is counted twice. The reverse categorical KL must be finite for the displayed finite identity; positivity alone does not ensure that integrability, and the note expressly assumes finite terms.

The jump equation is linear relaxation toward $b$ when the configuration and its marginal density are frozen. Theory/05b instead gives a logarithmic replicator vector field for a constrained constant recognition row and fixed expected costs. These are different kinetic prescriptions. In particular, the expected-cost log-odds bound R11 cannot be applied pathwise to a Brownian configuration without an additional argument.

## 2. Recognition-mass movement and the conditional lower bound

Integrating the full forward equation removes the continuous divergence by the stated boundary condition. Summing C2 over assignments with the distinguished receiver choosing $+$ gives

\[
\dot\lambda_{i,+}
=\nu(E_{q_X}b_{i,+}-\lambda_{i,+}).
\tag{C8}
\]

Variation of constants proves both identities S5. The full assignment row is used in the generator, while its receiver marginal appears in C8. This marginalization is exact and does not set the actual conditional recognition row equal to $b$.

The distinguished posterior log odds are

\[
\log\frac{b_{i,+}}{1-b_{i,+}}
=4(a-3/2)-\delta[f(s_+)-f(s_-)],
\tag{C9}
\]

where each $f$ lies in $[0,1]$. Monotonicity of the sigmoid gives S6. With $\nu=1$, write the C8 solution starting at $H_*-10$. If $a_t\ge7/4$ on that whole interval, then

\[
\lambda_{i,+}(H_*)
\ge (1-e^{-10})\operatorname{sigmoid}(1-\delta),
\tag{C10}
\]

because the decayed mass at $H_*-10$ is nonnegative. Subtracting the prescribed initial mass $\operatorname{sigmoid}(-2)$ proves the first S7 inequality.

For its strict numerical comparison, the note's elementary exponential inequalities give

\[
\begin{split}
&(1-e^{-10})\operatorname{sigmoid}(1-\delta)
-\operatorname{sigmoid}(-2)-\tfrac12\\
&\qquad>
(1-2^{-10})\frac{249}{349}-\frac18-\frac12
=\frac{31367}{357376}>0.
\end{split}
\tag{C11}
\]

Here $0<\delta<10^{-4}$ suffices, and $H_*\ge10$ makes the last interval admissible. Since both receiver distributions are binary, the positive mass difference is precisely their total-variation distance. S7 is therefore a correct conditional discriminator for actual recognition-mass change. Neither S5 nor S7 proves its parameter-history assumption. The completed fixed-label theorem cannot supply that assumption for the switching process without rederiving the relevant coupled estimates.

## 3. Exact inherited rates and their composition

Disintegrate the two different joints using their own kernels:

\[
p_a(y,z,j)=s_a(y,j)k_{a,j}(z\mid y),\qquad
q(y,z,j)=r(y,j)h_j(z\mid y).
\tag{C12}
\]

All conditionals here refer to fixed retained $y,j$. S9 uses $k_{a,j}$, the optimizing hidden conditional, rather than $h_j$, the actual hidden conditional. Multiplying its rate by the optimizing retained density gives

\[
\begin{split}
c_{jk}(y)
&=s_a(y,j)\nu\int k_{a,j}(z\mid y)b_k(y,z)dz\\
&=\nu\int p_{a,X}(y,z)b_j(y,z)b_k(y,z)dz
=c_{kj}(y).
\end{split}
\tag{C13}
\]

Positivity is immediate, and the sum of off-diagonal rates is at most $\nu$. The exact sheet diffusion for the parent is reversible with respect to $s_a(y,j)$. Thus it is consistent to combine that diffusion with the inherited reversible rates.

For its jump entropy derivative set $u_j=r_j/s_j$. The incoming-minus-outgoing equation and C13 give

\[
\begin{split}
\left.\frac{dF_T^s}{dt}\right|_{\mathrm{jump}}
&=T\int\sum_{j,k}c_{jk}(u_k-u_j)\log u_j dy\\
&=-\frac T2\int\sum_{j,k}c_{jk}
(u_j-u_k)(\log u_j-\log u_k)dy\le0.
\end{split}
\tag{C14}
\]

This proves S10. The diagonal contributes zero. The parameter contribution and sheet diffusion dissipation must still be added for the complete parent derivative, using that parent's own current $r$ and the inherited scalar and metric. The note states that prescription correctly.

For a further deterministic retention $V=R(Y)$ keeping the same assignment, the sigma-field generated by $(V,J)$ is contained in that generated by $(Y,J)$. For each source state $j$,

\[
\begin{split}
E_{p_a}[\overline K_{jk}(Y)\mid V,J=j]
&=\nu E_{p_a}[E_{p_a}[b_k(X)\mid Y,J]\mid V,J=j]\\
&=\nu E_{p_a}[b_k(X)\mid V,J=j].
\end{split}
\tag{C15}
\]

This is S11. All expectations use one normalized optimizer and one fixed parameter. The diagonal also composes because finite summation commutes with conditional expectation. No dynamic stationarity of the actual law is needed for this static identity. Using an actual hidden conditional at one step, changing $a$ between the two operations, or fitting a new heat-bath rule at the parent would be different operations and is not justified by C15.

The rate identity is not a semigroup identity for projected histories. The autonomous parent remains a declared reversible approximation candidate, even when it is initialized from the exact actual joint $r(y,j)$. Exact initialization preserves all current retained dependence, but generally does not remove the hidden dependence on the retained past.

## 4. Exact counterexample and its scope

In S12, the positive normalized joint table, with columns $+,-$, is

\[
\begin{array}{c|cc}
 &+&-\\ \hline
x=0&1/8&3/8\\
x=1&3/8&1/8
\end{array}.
\tag{C16}
\]

It gives $s_+=s_-=1/2$ and $p(x=0\mid +)=1/4$, $p(x=1\mid +)=3/4$. Therefore direct averaging of the fine exit rate yields

\[
\overline K_{+-}
=\frac14\frac{3\nu}{4}+\frac34\frac{\nu}{4}
=\frac{3\nu}{8},
\qquad
K^{\mathrm{regenerated}}_{+-}=\nu s_-=\frac{\nu}{2}.
\tag{C17}
\]

The difference is exactly $\nu/8$. Both resulting two-state generators have the same invariant source distribution. Equal invariant laws therefore do not identify their rates.

For clarity, define strong lumpability here as existence of one projected Markov generator giving the projected law for every fine initial state with the same retained state. Starting from $(0,+)$ gives probability $3\nu t/4+O(t^2)$ of a $-$ transition by short time $t$; starting from $(1,+)$ gives $\nu t/4+O(t^2)$. These derivatives differ inside the same retained fiber, so that property fails directly. This proof does not invoke a general lumpability theorem.

Even at the displayed invariant joint, keep the hidden $x$ static and observe source changes. Conditional on starting in $+$, the probability of no source change up to time $t$ is

\[
\frac14e^{-3\nu t/4}+\frac34e^{-\nu t/4}.
\tag{C18}
\]

It is not exponential: its second derivative at zero is $3\nu^2/16$, whereas a Markov holding time with the same initial rate $3\nu/8$ has second derivative $9\nu^2/64$. Thus stationary averaging of rates still does not give the exact retained holding-time law.

The finite hidden carrier in C16 is a kinetic counterexample to the general regeneration identity. It is not itself the smooth small-$\delta$ triangle family. Its mechanism is not tied to the large variation between $1/4$ and $3/4$. For an arbitrary binary posterior on any hidden carrier, let $s=E_{p_X}b_+\in(0,1)$. Then

\[
\overline K_{+-}
=\frac{\nu E[b_+(1-b_+)]}{s}
=\nu(1-s)-\frac{\nu\operatorname{Var}_{p_X}(b_+)}s.
\tag{C19}
\]

Every positive posterior variance produces a mismatch, including arbitrarily small nonconstant variation. More generally at fixed retained $y$ the full-assignment conductance is $\nu p_Y(y)E[b_jb_k\mid y]$, while regenerated heat-bath conductance is $\nu p_Y(y)E[b_j\mid y]E[b_k\mid y]$. Their difference is the corresponding conditional covariance. All off-diagonal discrepancies vanish only when every posterior assignment weight is conditionally constant, since the row sum of the covariance matrix is zero and its diagonal entries are variances. These algebraic statements locate the obstruction without claiming that it prevents a controlled approximation.

## 5. Actual rates and the precise remaining gap

The instantaneous actual outgoing rate from the current retained state is

\[
K^q_{jk}(y)=\nu E_{h_j(\cdot\mid y)}b_k(y,Z,a).
\tag{C20}
\]

It need not equal S9. For a fixed test function with $\|f\|_\infty\le1$, set $B_f(y,z)=\sum_kb_k(y,z)f(y,k)$. Then $B_f\in[-1,1]$, and the conservative diagonal term cancels between the two generators:

\[
[(K^q-\overline K)f](y,j)
=\nu(E_{h_j}B_f-E_{k_{a,j}}B_f).
\tag{C21}
\]

Using total variation in the convention $\mathrm{TV}(h,k)=\tfrac12\int|h-k|$, bounded expectations differ by at most $2\mathrm{TV}$. The elementary entropy inequality $\mathrm{TV}(h,k)\le\sqrt{D(h\Vert k)/2}$ therefore gives

\[
\begin{split}
|E_r[(K^q-\overline K)f]|
&\le\nu\sum_j\int r(y,j)\sqrt{2D(h_j\Vert k_{a,j})}dy\\
&\le\nu\sqrt{2\Delta},
\qquad
\Delta=\sum_j\int r(y,j)D(h_j\Vert k_{a,j})dy.
\end{split}
\tag{C22}
\]

For a direct justification of the entropy-to-TV step, apply data processing to the measurable set where $h\ge k$. For binary probabilities $p,q$, the second derivative of $D(\mathrm{Bern}(p)\Vert\mathrm{Bern}(q))$ in $p$ is $1/[p(1-p)]\ge4$; its value and first derivative vanish at $p=q$. Taylor integration gives $D\ge2(p-q)^2$. This proves the stated convention without a hidden constant change. Jensen in C22 uses that the full retained law $r$ is normalized, and proves S13 exactly.

If $\Delta(t)\le C\epsilon^2$ throughout $[0,2/\epsilon]$, integrating C22 yields at most $2\nu\sqrt{2C}$, which is independent of $\epsilon$ and does not tend to zero. This is a limitation of the estimate, not a proof that a path error must stay positive. Moreover, the projected path's predictable jump intensity conditions on its entire retained past. C20 conditions only on the current retained state. A same-time generator estimate cannot silently replace that history-conditioned hazard.

The note correctly leaves open the moving conditional-entropy balance for diffusion plus jumps, the coupled parameter continuation needed by S7, and integrated-hazard or fast-hidden averaging estimates on the common horizon. In particular full VFE descent does not imply descent of its discarded conditional-KL part, and the old analysis with fixed sheet masses cannot be reused without rederivation. The next material step is the first-elimination conditional-entropy and history-dependent hazard estimate with $\nu=1$ fixed. No result here proves or refutes the complete positive-mobility hierarchy.

## Check outcome and binding

The bounded identities S1–S13, including all displayed rate and temperature factors, have been reconstructed above. No correction to those identities is required. The explicit conditional scope of S7, the distinction between the finite counterexample and the smooth family, and the absence of a full path theorem are essential to this conclusion. The extra calculations C18–C19 explain the counterexample's kinetic scope; they do not promote it into a nonexistence claim.

The checker performed source reads and non-mutating SHA-256 calculations. The mathematical evidence is C1–C22 in this file. The rational margin C11 and the finite rates C17 were derived exactly; no numerical experiment was needed. The parent's exact Fraction diagnostic was separately read at [result.json](evidence/finite-rate-source-dynamics/result.json). It reports Python 3.14.4, eight true diagnostic fields, parent rate 3/8, regenerated rate 1/2, and defect 1/8. Those values agree with C11 and C17; the eight fields are finite arithmetic diagnostics, not theorem coverage or a test-suite total. This checker did not rerun that diagnostic. No prior proof, evidence ledger, code, configuration, vault file, or Git state was edited. No GPU job, suite, Lean work, or tamper check was run.

The inspected investigation has SHA-256 9786ac9b8c60d60c81b1a81c22351aa52ebb6016da7d3fc5ea721f4a62e472bd. Supporting source hashes are 725539e6e47d36bc27e54c42ea98602fbbe78a9f96f8aef1c833a0fd3c6e1f1e for nonlinear-endpoint-attention-model.md; b0ef14dbe891d7890740d6f1e27ced56a6d05c2512804d2de672891a98aab84b for Theory/05b_local_collective_elbo.tex; and aeaf7a531b248138ad30d3c6c6ef0b62b71d1e2782851eb862c520361fbef8ba for the earlier attention-admission.md. The inspected diagnostic result has SHA-256 7d982d762dbf18d46046155d8d110d0f1644432819558b6b5e5bd22e2158300f. These values bind the read snapshot and are not mathematical pass/fail conditions.
