# Reconstruction of the fixed weakest-energy hierarchy

September 13, 2026. This is a separate nonauthor reconstruction of the [frozen weakest-one target](evidence/2026-09-13-fixed-weakest-energy-adaptive-cyclic-rg/problem-contract.json), digest `c574ab277c6be97d9c483ffcc4a76b87fc074d03d184a731b8a4973a7944f952`. The reconstruction shares prior research context, a filesystem and communication with the component authors. It is not blind independent corroboration. Candidate ledger states, favorable expectations, author conclusions and structural validation are not premises of the proof below.

The result is a reconstructed proof of the frozen finite-depth existence target, with weakest energy exactly one and source proposal rate exactly one. The previously unresolved terminal conditional estimate is replaced by joint diffusion-plus-jump entropy contraction. The previously unresolved history estimate is replaced by exact integration of the later normal variables, followed by a fast-coordinate comparison that retains the actual stochastic environment. Neither mechanism uses the preceding globally accelerated theorem as a conclusion.

## 1. Exact target and the serious falsification attempts

For every prescribed finite integer $L\ge2$, the claim is that there exist $\epsilon_L>0$, constants depending on $L$, fixed nested marked retentions and a nonempty initial-law neighborhood such that every $0<\epsilon<\epsilon_L$ gives the complete conjunction on $[0,2/\epsilon]$. The required regime is

\[
Q_L=0,\quad Q_s=2Q_{s+1}+20,\quad J_s=\epsilon^{-Q_s},\quad
A^2=\epsilon^{3Q_1+20},\quad T=A^2\epsilon^6.
\tag{V1}
\]

Thus $Q_s=20(2^{L-s}-1)$, $J_L=1$, $Q_1\ge20$, and $J_2/\sqrt{J_1}=\epsilon^{10}$. The domain is the fixed-point triangle-chain Euclidean belief/model/link carrier times all finite source assignments, with Lebesgue/counting measure, a regular scalar model parameter and positive smooth correlated recognition laws. Every true parent retains all loop coordinates, assignments and the complete conditional physical, optimizing, evaluator and occupancy records. It starts from the complete actual preceding retained joint law and parameter, then computes its own model covector from its own law.

The conjunction requires $L$ actual successive coalescence episodes; exact normalized marked-law and inherited-rate composition; own-law continuation; actual binary recognition-source TV change greater than $1/2$; first hidden physical and optimizing KL changes each greater than $1/200$; vanishing discarded conditional and complete same-state score errors; $o(A)$ uniform retained continuous-path error outside a vanishing exceptional probability; and an entire-assignment-history coupling with vanishing disagreement probability. Exact static composition, approximate independent dynamics and physical-time interpretation are separate notions. In particular, the target asks neither exact temporal lumpability nor TV convergence of continuous path measures.

The contract supplies the normalized source/evaluator/calibration model, fixed positive standardized nonlinear coefficient $\delta=10^{-4}/n$, internal-neighbor source support, compatible root observation, proper correlated prior, supplied finite-depth energy contrasts, unit continuous mobility, unit microscopic full-assignment proposal rate and the regime V1. It permits the specified shrinking common-center preparation and smaller nonempty neighborhoods. The construction chooses the fixed strict-margin normal vector neighborhood, zero loop center, independent equilibrium root, and bounded small sheet-dependent transports described below. These are admissions, not derived hierarchy selection or universal initial conditions. No global energy acceleration, vanishing source mobility, weakened likelihood or additional kinetic multiplier is allowed or used.

The first attacks targeted the two steps that previously failed. Setting $J_L=1$ in the earlier separate conditional estimate leaves a nonvanishing upper-bound source term. Therefore importing that estimate at the terminal interface would fail. The new argument instead keeps categorical dissipation in a full joint entropy inequality, reconstructed in Section 4. Likewise, setting $J_L=1$ in the previous global-mixing history proof makes its long-enough mixing interval incompatible with its short-interval error. The new argument mixes only the first normal layer and loops, after an exact static identity and an explicit bound for the evolving remaining coordinates; Sections 6–8 reconstruct that replacement.

A second attack concerned whether integrating later normals can remove their coupling to the source-relevant coordinates exactly. It can here because the residual matrix is block lower triangular with fixed invertible diagonal blocks, the domain is all Euclidean space, and the nonlinear source factor is independent of all later normal coordinates. The constant-Jacobian change in V19 proves the exact marginal; it would fail for mixed-level source support or a restricted integration domain. A third attack concerned the covariance of the first hidden normal block after intermediate marginalization. V21 retains and bounds that covariance change; replacing it by its terminal value without the sandwich bound would not be valid.

A fourth attack concerned histories: an unconditional generator bound cannot control source kernels conditioned on a complete observed prefix, and conditioning on a common activation sample can make the initial continuous law a point mass. The proof uses pointwise fast mixing, conditions on an independent full proposal grid and past marks only, and averages the resulting conditional forcing terms over actual prefixes. It never divides by a rare history probability or assumes equilibrium at activation. A fifth attack concerned terminal activation: it occurs at order $\log(1/\epsilon)$, so the former $\tau_L=o(1)$ source-mass argument is unavailable. V17 uses the actual forcing envelope instead. These attacks do not produce an admissible counterexample to the new conjunction; their resolved obligations are part of the proof, not an inference from failure to find a counterexample.

## 2. Normalized family and exact marked inheritance: c1

There are $b=2^{L-1}$ triangles, $n=3b$ vertices and $4b-1$ independent oriented links. Write $x=(u,v,\alpha)$, $d_i=u_i-v_i$ and $r_e=u_i-u_j-\alpha_e$. On each triangle the two orthonormal residual contrasts and the normalized loop coordinate decompose the original three edge energies. If $B_1$ stacks all $d_i$ and these internal contrasts, and $B_s$ stacks the level-$s$ bridges, then $B$ has independent rows: link columns first kill any proposed contrast/bridge relation, and model columns kill the remaining $d_i$ relation. Thus

\[
\mathbb R^{10b-1}=N\oplus H_h\oplus K,\qquad
H=B^T\operatorname{diag}(J_s I)B+J_1P_{H_h},\qquad
K=\{(t,t,Dt):t\in\mathbb R^n\}.
\tag{V2}
\]

The $b$ loop directions $H_h$ survive all projections. The orthonormal flag basis is fixed by the kernels of the initial row blocks and is independent of the strengths. Its matrix $\mathsf B=B[Q_1\cdots Q_L]$ is block lower triangular with invertible diagonal blocks. Weighted conjugation multiplies each permitted off-diagonal block by $\sqrt{J_j/J_i}\le1$. Applying the same observation to its inverse proves

\[
c_L\sum_sJ_s|w_s|^2\le w^TH_Nw\le C_L\sum_sJ_s|w_s|^2.
\tag{V3}
\]

Schur complementation preserves the corresponding lower bounds because its quadratic form is the minimum over eliminated coordinates. In particular $H_p\succeq h_L I$ for a fixed $h_L>0$ at every retained nonroot level when $J_L=1$. No increasing lower bound is inferred.

With $\mathcal J$ the entire set of $2^n$ binary internal-neighbor assignments, the selected-source potential is

\[
\phi_j(x)=\delta\sum_i(1-e^{-J_1r_{i,j_i}^2/(2T)}),\qquad
0\le\phi_j\le B_0=10^{-4}.
\tag{V4}
\]

The complete normalized experiment remains [E1–E10 and E24–E29](nonlinear-endpoint-attention-model.md). Each success/failure observation is a normalized positive Bernoulli kernel, each source prior is positive, the root observation is a density on its declared root carrier, and the evaluator kernels remain normalized. The corrected physical prior precision $A_0=aH+P_K-TR$ is positive on $a\in[1,2.1]$ for small $\epsilon$, since $R$ is fixed and $T\to0$ while V3 gives a nonzero normal lower bound. Bounded source tilt preserves positive finite Gaussian partition integrals and their differentiated moments. The optimizing marked law is proportional to $\pi_j(a)e^{-G_a(x)/T-\phi_j(x)}$; the physical posterior has the separate corrected precision and its own conditional kernels. They are not identified.

After $p$ eliminations, the optimizing nonroot density and exact row are

\[
p_a^p(x,j)=Z_p(a)^{-1}e^{-\psi_{p,j}(x,a)}G_a^p(x)\pi_j(a),\quad
G_a^p=N(0,(T/a)H_p^{-1}),\quad 0\le\psi_{p,j}\le B_0,
\]
\[
R^p_{jk}(x,a)=E_{\Pi_a}[b_k(X,a)\mid P_pX=x,J=j],\quad
b_k=\frac{\pi_k(a)e^{-\phi_k}}{\sum_j\pi_j(a)e^{-\phi_j}}.
\tag{V5}
\]

Each row sums to one, including its self-proposal entry, and $R^p_{jk}\ge e^{-B_0}\pi_k(a)>0$. The generator uses $R_{jj}-1$ on its conservative diagonal, so its off-diagonal exit rate is at most one and its full proposal clock has rate exactly one. The identity $\Pi_a(x,j)b_k=\Pi_{a,X}(x)b_jb_k$ is symmetric. Conditional integration proves detailed balance $p_a^p(x,j)R^p_{jk}=p_a^p(x,k)R^p_{kj}$. Another retention composes these rows exactly by the conditional-expectation tower. Separate disintegration of the physical, optimizing and actual joint laws through the same fixed channel gives the complete normalized marked-law tower. All loops and assignments are retained; neither recognition independence nor a source reset is imposed.

A regenerated parent heat bath would be a different generator. For hidden states $0,1$ of equal probability and $b_+(0)=1/4,b_+(1)=3/4$, the inherited $+\to-$ rate is $3/8$ while the regenerated rate is $1/2$. The microscopic exit also differs between the two states in the same retained fiber. This exact finite example falsifies regeneration and strong lumpability as shortcuts. It does not contradict the approximate-history claim under V1.

## 3. Preparation and own-law continuation without acceleration: c2

Use a common Gaussian normal center $Av_0$, zero loop center and covariance $T\widehat K_1^{-1}$ on every sheet, with the independent common equilibrium root. The positive initial source masses satisfy $|\lambda_{i,+}(0)-\operatorname{sigmoid}(-2)|<10^{-2}$. A fixed small neighborhood of the strict-margin $v_0$ is admitted. Smooth within-sheet transports are allowed if their coupled displacement obeys $|\widehat K_1^{1/2}(X_0-X_0^G)|<\epsilon\sqrt T$ and their log-density ratios are bounded. Small compactly supported maps in standardized coordinates with small displacement and Jacobian give a nonempty positive smooth neighborhood. Its topology and size depend on the declared weighted-transport and density bounds; no neighborhood uniform in $\epsilon$ or arbitrary-law basin is claimed. The common center is necessary for the stated small covariance budget; arbitrary order-$A$ differences between sheet centers are not admitted.

Exact Gaussian integration gives the sheet potential
$V_{p,j}(x,a)=a x^TH_px/2+C_p(a)+T\psi_{p,j}(x,a)$,
with $C_p'=Td_p/(2a)$ and $d_p$ the cumulative hidden dimension. The hidden Gaussian center is independent of $a$ and its scale is $T/a$. Differentiating the source integral includes its gradient covariance. Since $|f'|,|f''|\le1$, selected residuals occur at most twice, and the squared energy-dual force is bounded by $2n\delta^2T$, the total relative Hessian correction is at most $2(\delta+\delta^2)+2n\delta^2<1/2$. The same Gaussian integral and bounded tilt give

\[
c_LH_p\preceq\nabla^2V_{p,j}\preceq C_LH_p,\quad
|H_p^{-1/2}T\nabla\psi_{p,j}|\le C_L\sqrt T,\quad
|\partial_a\psi_{p,j}|\le C_L.
\tag{V6}
\]

These estimates need $J_L\ge1$, not $J_L\to\infty$. The centered hidden Gaussian scale score is $(d_p-|Z|^2)/(2a)$, so its tilted moments are independent of stiffness and temperature. The complete covector and inherited metric are

\[
g_p=a-2+\frac12E_qX^TH_pX+\frac{Td_p}{2a}
+TE_q\partial_a\psi_{p,J}-\frac T2\operatorname{tr}(A_0^{-1}H)
-TE_q\partial_a\log\pi_J(a),
\]
\[
m(a)=TM(a)=1+O_L(T)\ge1,\qquad
\dot a=-\epsilon m(a)^{-1}g_p(q,a).
\tag{V7}
\]

The full generative Fisher is $M=T^{-1}+\frac12\operatorname{tr}[(A_0^{-1}H)^2]+\sum_i\operatorname{Var}_{\pi_i}t_i$. Prior, calibration and source scores have zero mean and zero cross expectations in the normalized joint; the other conditional kernels have no explicit $a$ derivative. The only changing row has $t_+=4,t_-=0$. Thus $|m'|\le C_LT$. V7 includes the raw normalizer, hidden determinant and categorical terms. A time derivative of actual masses is not part of a partial parameter derivative at fixed $q$.

For fixed positive $T,J$, V6 gives globally Lipschitz sheet drifts of linear growth, and V5 has bounded derivatives and a positive finite-depth rate lower bound. Poisson interlacing constructs a nonexplosive solution for a prescribed continuous coefficient. For the law feedback, differentiate the backward expectation of a smooth quadratic or bounded score observable through the interlaced representation. Fixed-instance flow derivatives are bounded on bounded time intervals; each differentiated rate weight is bounded by a constant times its positive weight; and the Poisson count has all exponential moments. These bounds and polynomial diffusion moments justify termwise differentiation. Applying the backward identity along two coefficient paths yields
$|E_a f(X_t,J_t)-E_{\widetilde a}f(X_t,J_t)|\le C\int_0^t|a-\widetilde a|ds$.
The explicit terminal score dependence contributes a local Lipschitz term. Picard contraction then constructs the coupled law and coefficient locally. The local constants may depend on the fixed positive instance.

Stop at a first possible coefficient exit from $[1,2.1]$. Compare each actual process to its linear reference, using its same actual deterministic coefficient and Brownian motion. Jumps move no continuous coordinate. The uniform source force gives, for every adapted label path,

\[
\frac d{dt}|e|^2\le-e^TH_pe+C_LT,\quad
\sup_{t\le H_*}|e_t|\le|e_0|+C_L\sqrt{TH_*},\quad
\sup_t|H_p^{1/2}e_t|\le C_L\sqrt T\ell,
\quad \ell=1+\log(1/\epsilon).
\tag{V8}
\]

The last inequality follows from the commuting propagator $e^{-H_p\int_s^ta}$ and
$\int_0^\infty\|H_pe^{-H_pu}\|du\le C_L[1+\log(J_1/J_L)]$.
Split the integral at inverse largest and smallest stiffness; the intervening $1/u$ bound gives the logarithm. At $J_L=1$ this is still $O_L(\ell)$. Schur energy contracts under projection, and the inverse-covariance Schur identity preserves the Gaussian covariance barrier $\Sigma_G\preceq C_LT H_p^{-1}$ using only $a\ge1$. The common center has norm $O_L(A)$ and no loop component. Consequently

\[
E_qX^TH_pX\le C_L[A^2J_{p+1}+T\ell^2],\quad
E_q|X|^2\le C_L[A^2+T\ell^2],\quad
J_1E_q|X_{H_h}|^2\le C_LT.
\tag{V9}
\]

Here $J_{L+1}=0$. The sharper loop estimate uses its actual restoring rate $aJ_1$ and force bounded by $C_L\sqrt{TJ_1}$; it does not assign a slow normal rate to the loop.

Substituting V9 into V7 gives

\[
r_\epsilon=A^2J_1+T\ell^2,\qquad
\dot a=\epsilon(2-a)+O_L(\epsilon r_\epsilon),\qquad
\sup_{t\le H_*}|a_p(t)-(2-e^{-\epsilon t})|\le C_Lr_\epsilon.
\tag{V10}
\]

The field points inward at $1$ and $2.1$ for small $\epsilon$, so the stopped exit is excluded. Moments exclude explosion; smooth elliptic diffusion and positive finite rates preserve positive smooth densities. The last inequality is variation of constants, including every actual activation coefficient, and also gives $|\dot a|\le C_L\epsilon$. All parents use their own law in V7. The reference $2-e^{-\epsilon t}$ is derived for comparison and is not a prescribed learner. No entropy or history result has entered this continuation argument.

## 4. Joint entropy contraction at weakest energy one: c3

Write $p=p_a^p$, $\rho=G_a^p\otimes\pi(a)$ and $u=q/p$. V5 implies the uniform density and conductance comparisons

\[
e^{-B_0}\le p/\rho\le e^{B_0},\qquad
p(x,j)R^p_{jk}(x,a)\ge e^{-2B_0}G_a^p(x)\pi_j(a)\pi_k(a).
\tag{V11}
\]

Define $I_p(u)=\sum_j\int p_j|\nabla u_j|^2/u_j$ and
$\mathcal D_p(u)=\frac12\int\sum_{j,k}p_jR_{jk}(u_j-u_k)(\log u_j-\log u_k)$.
The entropy representation
$\operatorname{Ent}_\mu(u)=\inf_{r>0}E_\mu[u\log(u/r)-u+r]$
has a pointwise nonnegative integrand. It proves $\operatorname{Ent}_p(u)\le e^{B_0}\operatorname{Ent}_\rho(u)$ even though $u$ need not integrate to one against $\rho$.

For the product measure, the chain rule gives
$\operatorname{Ent}_\rho(u)=\sum_j\pi_j\operatorname{Ent}_G(u_j)+\operatorname{Ent}_\pi(E_Gu)$.
The last entropy functional is convex by the log-sum inequality, so its last term is bounded by $E_G\operatorname{Ent}_\pi(u)$. The Gaussian covariance is $(T/a)H_p^{-1}$, and the Gaussian log-Sobolev inequality is
$\operatorname{Ent}_G(v)\le T E_G(|\nabla v|^2/v)/(2a h_p)$,
$h_p=\lambda_{\min}(H_p)\ge h_L$.
For completeness, its normalized form follows from the Ornstein–Uhlenbeck derivative contraction $I_G(P_tf)\le e^{-2a h_p t}I_G(f)$ for generator $T\Delta-aH_px\cdot\nabla$ and entropy derivative $-T I_G(P_tf)$. Integrate to equilibrium, first for bounded positive smooth densities and then by truncation and smoothing. Dividing a general $v$ by its integral gives the stated unnormalized form.

The finite-source inequality is elementary:

\[
\frac12\sum_{j,k}\pi_j\pi_k(v_j-v_k)(\log v_j-\log v_k)
=\sum_j\pi_jv_j\log v_j-\bar v\sum_j\pi_j\log v_j
\ge\operatorname{Ent}_\pi(v),\quad \bar v=\sum_j\pi_jv_j.
\tag{V12}
\]

The final inequality is Jensen for $\log$. Comparing the continuous integral and the nonnegative conductance integral using V11 now proves

\[
D(q\Vert p)\le e^{2B_0}\frac{T}{2a h_p}I_p(u)+e^{3B_0}\mathcal D_p(u),\qquad
T I_p(u)+\mathcal D_p(u)\ge c_*D(q\Vert p),
\]
\[
c_*:=\min(2h_Le^{-2B_0},e^{-3B_0})>0.
\tag{V13}
\]

This calculation does not use a lower bound on actual source masses or a numerical minimum of the model prior. Positive normalized model rows and their exact conductance comparison suffice. Infinite dissipation cases follow by the nonnegative extended limits.

The complete normalized score is the centered version of
$r=-x^TH_px/(2T)+\partial_a\log\pi_j-\partial_a\psi_{p,j}$.
Its bounded terms are uniformly bounded by V6 and $|\partial_a\log\pi_j|\le4$. In standardized coordinates $Z=\sqrt{a/T}H_p^{1/2}x$, bounded tilt gives
$E_p|Z|^{2k}\le e^{B_0}2^{d_0/2}4^k k!$.
Thus centering and the exponential series give constants $v,b>0$, uniform in $T,J$, with
$\log E_pe^{z\xi}\le vz^2/[2(1-b|z|)]$, $\xi=\partial_a\log p$, $|z|<1/b$.
Entropy duality yields $|E_q\xi|\le\sqrt{2vD(q\Vert p)}+bD(q\Vert p)$: apply $D(q\Vert e^{z\xi}p/E_pe^{z\xi})\ge0$ with either sign and optimize $z$.

Let $\mathcal E(t)=D(q_t\Vert p_{a(t)}^p)$. Integration by parts and detailed balance give

\[
\mathcal E'=-T I_p(u)-\mathcal D_p(u)-\dot a E_q\xi
\le-c\mathcal E+C_L\epsilon^2,\qquad c=c_*/2>0.
\tag{V14}
\]

Indeed $b|\dot a|\mathcal E\le c_*\mathcal E/4$ for small $\epsilon$, and Young's inequality absorbs the square-root term into another $c_*\mathcal E/4$ with remainder $C_L\epsilon^2$. The changing source masses are accounted for by the jump generator, not omitted. Calibration and the restricted scalar are needed by V7; they are not extra terms in normalized relative entropy. This proves $\mathcal E(t)\le e^{-c(t-\tau)}\mathcal E(\tau)+C_L\epsilon^2$ on every active interval.

All identities can first be written for positive regularizations and compact spatial cutoffs. V6 and the linear comparison give Gaussian-type exponential moments for fixed positive instances; the preparation has bounded density perturbations. These bounds remove boundary terms, and lower semicontinuity preserves the nonnegative dissipation in the limit. The carrier is global Euclidean space and the root is the specified independent equilibrium factor, so no suppressed boundary current or omitted root entropy is used.

## 5. Actual activation, conditional bounds, formation and changes: c4–c6

An exact marked projection at unchanged $a$ decreases full relative entropy by its conditional KL. Therefore V14 concatenates through every actual activation, and independently continued descendants inherit the same global-time bound from their actual starting law. Expanding the admitted initial Gaussian density, its bounded transport perturbation and the bounded target tilt gives
$\mathcal E(0)\le C_L[\epsilon^{-(Q_1+6)}+\ell^2]$.
The categorical entropy is bounded above by $\log(1/\pi_{\min})$ independently of actual masses. A logarithmic time can suppress this large but explicitly polynomial initial entropy.

For the earlier interfaces, the global rate in V14 is too slow, so the preceding conditional balance must still be used at its proved dependence on the strengths. Its activation budget is $T D(q_p\Vert p_a^p)\le C_L[A^2J_{p+1}+T\ell^2]$. This follows from V9 and the varying-mass entropy floor: differential/counting entropy satisfies
$h'\ge2\pi e d'Te^{-2h/d'}-d'C_LJ_1-\log|\mathcal J|$.
The continuous inequality follows by expanding Gaussian log-Sobolev and optimizing its scale to obtain $I(f)\ge2\pi e d'e^{-2h(f)/d'}$, followed by Jensen over sheet masses. The discrete conditional entropy derivative is bounded below by $-\log|\mathcal J|$ by concavity under a rate-one update. On discarding $k$ continuous coordinates, $h(Y,J)\ge h(X,J)-\frac k2\log(2\pi e E|Z|^2/k)$ by the Gaussian maximum-entropy bound. Iteration costs only $O_L(\ell)$ because all scales are powers. Thus this is an actual projected joint-law budget; it uses neither Gaussian recognition at later times nor equilibrium activation.

The auxiliary conditional estimate integrates the current hidden normals and loops while conditioning on future normals and $J$. The real parent retains the loops, and the KL chain rule makes its true discarded conditional smaller. Its hidden curvature is $c_LJ_s$, and the source support gives mixed derivative at most $C_LJ_{s+1}$. To check that latter scale, in eliminated residual coordinates the first block row of $(D_E+C^TD_fC)^{-1}=D_E^{-1}-D_E^{-1}C^TD_fC(D_E+C^TD_fC)^{-1}$ is $O_L(J_1^{-1})$, while the force column from future layer $s$ is $O_L(J_s)$. Hence the first hidden mean response is $O_L(J_s/J_1)$. Differentiating its Gaussian source integral gives loop/future derivative $O_L(J_s)$ and internal/future derivative $O_L(J_iJ_s/J_1)$, including the generated covariance. This supplies the required mixed bound without pretending all normal directions have stiffness $J_1$.

A source proposal can increase auxiliary conditional KL, but its contribution is at most $C_J=\log|\mathcal J|+2B_0$: relative to the common hidden Gaussian, the changing part is conditional mutual information, whose convexity in the source channel bounds its rate by $\log|\mathcal J|$; the two bounded log-density corrections contribute at most $2B_0$. The hidden log-Sobolev inequality, centered hidden parameter-score tails, and the full actual relative-Fisher budget therefore give the retained predecessor bound

\[
\widehat\Delta_s(t)\le C_L\left[
e^{-c_sJ_s(t-\tau_{s-1})}(\epsilon^{-6}J_s+\ell^2)
+\epsilon^{-6}\frac{J_{s+1}^2}{J_s}
+\ell^2\frac{J_{s+1}^2}{J_s^2}
+\frac{\epsilon^2}{J_s^2}+\frac{C_J}{J_s}\right].
\tag{V15}
\]

Every input to this balance needs only $J_L\ge1$ and $1+\log(J_1/J_L)=O_L(\ell)$; the full relative Fisher component, rather than a marginal Fisher information substituted for it, is used. In particular, V15 is not imported from the accelerated conclusion. For $s<L$, $J_s\ge\epsilon^{-20}$ and $J_{s+1}^2/J_s=\epsilon^{20}$. After a wait with exponent greater than $Q_1+20$, its terms are respectively $o(\epsilon^{14})$, $\epsilon^{14}$, at most $\ell^2\epsilon^{40}$, at most $\epsilon^{42}$ and at most $C_J\epsilon^{20}$.

Set $t_s=k_L\log(1/\epsilon)/J_s$, $I_s=[t_s,2t_s]$, $\tau_s=2t_s$. Choose a finite $k_L$ with $\underline c k_L/2>Q_1+20$ for $\underline c=\min_{s<L}c_s$, $ck_L>Q_1+8$, and the geometric and history lower bounds below. The contrast recursion gives $t_s-\tau_{s-1}\ge t_s/2$ for small $\epsilon$. V15 proves early discarded KL $O_L(\epsilon^{14})$. At $t_L=k_L\log(1/\epsilon)$, V14 and the initial entropy bound instead prove full joint entropy $O_L(\epsilon^2)$. The terminal hidden-conditional entropy is smaller than that joint entropy by the KL chain rule; its true discarded conditional is smaller still. Differentiating the exact scalar identity at fixed actual law and fixed channel gives

\[
\Delta_{s-1:s}=\begin{cases}O_L(\epsilon^{14}),&s<L,\\O_L(\epsilon^2),&s=L,\end{cases}
\qquad
|g_{s-1}(q,a)-g_s(C_sq,a)|\le C_LT(\sqrt\Delta+\Delta).
\tag{V16}
\]

The normalized hidden score has uniform centered Gaussian-quadratic tails. Source-prior terms cancel from that conditional only after being included in both complete covectors; hidden determinant, observation, calibration and restriction scalars are retained. Thus the complete score errors are $O_L(T\epsilon^7)$ and $O_L(T\epsilon)$, respectively. These are same-state comparisons, distinct from independent parameter-path bounds.

Formation uses the fixed strict-margin vector from the geometric flag. Existence follows by avoiding finitely many nonzero residual hyperplanes in the relevant normal subspaces; row independence makes those linear forms nonzero. A polynomial curve avoids all their finitely many roots, and the resulting finite minimum margin survives a small fixed neighborhood. In the linear comparison, the current block mean is bounded by $C_LA[e^{-c_LJ_s(t-\tau_{s-1})}+J_{s+1}/J_s]$, and a future retained mean differs from $AP_sv_0$ by at most $C_LAJ_{s+1}t$. Earlier projections preserve that future coordinate. On $I_s$, the latter error vanishes for $s<L$; at $s=L$ there is no future normal block. The Gaussian maximum bound is $C_L(1+H_*)e^{-c_L\rho^2A^2/T}$ for radius $\rho A$, obtained by applying Itô and stopping to an exponential quadratic with coefficient below the uniform smallest precision. Stronger stiffness contributes negatively to its generator. V8 adds scaled nonlinear error $O_L(\epsilon^{5/2})$ for any adapted assignments. Hence formed residuals fall below fixed small multiples of $A$ and future bridges remain above fixed positive multiples, outside the stated vanishing probability. The exact conditional marks recover previously removed residuals by their Schur conditional centers and bounded-tilt variances; their mismatch bound has terms $C_LA^2(J_{p+1}/J_p)^2+C_LT/J_p$, which preserve these margins. The counts are $3\cdot2^{L-1}\to2^{L-1}\to\cdots\to1$, and final coherence persists through $H_*$. The last window is logarithmic, but $\tau_L/H_*\to0$.

For actual source movement, let $\lambda$ be the distinguished binary marginal on a fine process, a parent or a lineage. The exact averaged row preserves the pointwise source envelope, so

\[
\lambda'=\zeta-\lambda,\qquad
\operatorname{sigmoid}(4(a-3/2)-\delta)\le\zeta\le\operatorname{sigmoid}(4(a-3/2)+\delta).
\tag{V17}
\]

Before $\tau_L$, V10 gives $a\le1+C_L\epsilon\log(1/\epsilon)+C_Lr_\epsilon$. The scalar forcing equation cannot exceed the maximum of its initial value and its forcing envelope. Therefore every activation mass is at most $\operatorname{sigmoid}(-2)+10^{-2}+\delta/4+o(1)$, regardless of how many proposals occurred. On the last ten units, V10 gives $a\ge7/4$, and $\lambda(H_*)\ge(1-e^{-10})\operatorname{sigmoid}(1-\delta)$. The lower bound before preparation tolerance exceeds $(1023/1024)(249/349)-1/8>0.587$. Thus the change from any activation is greater than $1/2$ for small $\epsilon$. This is an actual recognition marginal, not a substituted optimizing posterior. It replaces the invalid $\tau_L=o(1)$ shortcut.

For each first hidden physical or optimizing kernel, the final Gaussian precision is at least $5/4$ times the initial one. The optimizing precision scales with $a$; the physical precision $D_1=H-TR\preceq H$ obeys $D_f=D_1+(a_f-1)H\succeq a_fD_1$, with positivity already checked. Conditional restriction and Schur minimization preserve the order. The Gaussian affinity bound permits arbitrary means; bounded success tilts enlarge affinity by at most $e^{B_0}$. Hence, for hidden dimension $k\ge1$,

\[
D(k_1\Vert k_f)\ge\frac k2\log(81/80)-2B_0>1/200.
\tag{V18}
\]

This holds uniformly in retained input and label, separately for the physical and optimizing kernels. The elementary comparison uses $\log(81/80)\ge1/81$. Non-Gaussianity persists: along a first-hidden direction with a selected nonzero internal residual, the standardized source expansion has negative fourth-order coefficient $-\delta A_j^2/8$. The common tilt and unit source rate are not sent to zero.

## 6. Exact source-relevant marginal and intermediate response: c7

Write the nonroot orthonormal flag coordinates as $(w_1,\ldots,w_L,h)$, with $h$ the normalized loop coordinates. Set $u=w_1$ and $A_*=J_1\mathsf B_{11}^T\mathsf B_{11}$. The source factor depends only on $(u,h)$. The normal quadratic is

\[
w^TH_Nw=J_1|\mathsf B_{11}w_1|^2+
\sum_{s=2}^LJ_s\left|\sum_{r\le s}\mathsf B_{sr}w_r\right|^2.
\tag{V19}
\]

At fixed $u,h$, change the later variables to their residuals $r_s=\sum_{r\le s}\mathsf B_{sr}w_r$. Its Jacobian is the product of the fixed diagonal-block determinants. The integration domain stays all Euclidean space. The later Gaussian integrals therefore contribute a factor independent of $u,h,j$, even though that factor depends on $a,T,J$. It cancels on normalizing the conditional sheet law. The exact source-relevant optimizing marginal is

\[
\mu^*_{a,j}(du,dh)\propto
e^{-a(u^TA_*u+J_1|h|^2)/(2T)-\phi_j(u,h)}du dh.
\tag{V20}
\]

No environment has been frozen in this identity. Define its conditional $\kappa^*_{a,j}(du\mid h)$, loop marginal $\mu^{h,*}_{a,j}$, loop row $R^*_{jk}(h,a)=E_{\kappa^*}b_k$, and common averaged row $\mathcal B_{jk}(a)=E_{\mu^*_{a,j}}b_k=E_{\mu^{h,*}}R^*_{jk}$. Since V20 is the full optimizer's exact marginal, this is exactly $E_{\Pi_a(\cdot\mid J=j)}b_k$ at every retained level by the tower. It need not be a heat-bath row independent of $j$.

At an intermediate parent $p\ge1$, let $y=(w_{p+1},\ldots,w_L)$. Integrating $w_2,\ldots,w_p$ first gives a Gaussian conditional for $u$ with mean $m_p(y)$ and covariance $(T/a)\mathsf C_p^{-1}$. Setting $y=0$ and minimizing the nonnegative later-row quadratic in V19 proves the lower bound below. Setting the integrated variables to zero proves the upper bound:

\[
A_*\preceq\mathsf C_p\preceq(H_N)_{11}\preceq A_*+C_LJ_2I,
\qquad |\partial_{w_s}m_p|\le C_LJ_s/J_1,
\qquad |m_p(y)|\le C_L(J_2/J_1)|y|.
\tag{V21}
\]

The first-row inverse argument following V15 proves the mean response without substituting the much larger full-hidden inverse norm. At $p=L$, V19 gives $\mathsf C_L=A_*$ exactly. Let $\rho=J_2/J_1$, $\alpha=J_2/\sqrt{J_1T}$ and $d(y)=\rho+\alpha|y|$. The KL between this Gaussian and $g_*=N(0,(T/a)A_*^{-1})$ is
$\frac12[(a/T)m_p^TA_*m_p+\operatorname{tr}(A_*\mathsf C_p^{-1})-\dim u-\log\det(A_*\mathsf C_p^{-1})]$.
The mean term is $O_L(\alpha^2|y|^2)$; the eigenvalues of the matrix in the trace/determinant lie in $[(1+C_L\rho)^{-1},1]$, so the covariance term is $O_L(\rho^2)$. Pinsker yields Gaussian TV at most $C_Ld(y)$.

Tilting both Gaussians by the same $e^{-\phi_j(u,h)}\in[e^{-B_0},1]$ multiplies TV by at most $2e^{B_0}$, by subtracting normalized densities and bounding the normalizer difference. Thus the actual optimizing hidden kernel $\kappa^p(du\mid y,h,j)$ and $\kappa^*(du\mid h,j)$ differ in TV by at most $C_Ld(y)$, uniformly in the unbounded loop coordinate. Integrating a stochastic row contracts TV. Differentiating the loop potentials includes only the source derivative because the Gaussian core has no loop/normal cross block. Consequently

\[
\|R^p_{j\cdot}(y,h,a)-R^*_{j\cdot}(h,a)\|_{\rm TV}\le C_Ld(y),\qquad
|\nabla_hV_{p,j}-\nabla_hV^{h,*}_{a,j}|
\le C_L\sqrt{TJ_1}d(y).
\tag{V22}
\]

The original row and the reference loop row have Lipschitz constants at most $C_L\sqrt{J_1/T}$ in their respective fast coordinates. For the loop row, differentiate both the row and its normalized hidden conditional; the latter contributes its covariance with $\nabla_h\phi_j$, which has the same bound. The Gaussian $g_*$ is independent of $h$, so there is no discarded Gaussian derivative. These estimates retain the intermediate covariance and the exact loop force.

## 7. Fast mixing and the actual stochastic environment

The auxiliary fine potential is $V^*_{a,j}=a(u^TA_*u+J_1|h|^2)/2+T\phi_j(u,h)$; the auxiliary parent potential is its exact loop marginal. Their core contains every selected internal residual. The bounded Hessian and generated covariance calculation in V6 therefore gives

\[
c_LJ_1I\preceq\nabla^2V^*_{a,j},\nabla^2V^{h,*}_{a,j}\preceq C_LJ_1I.
\tag{V23}
\]

Both potentials are even, their minimizer is the origin, and their equilibrium second moments are $O_L(T/J_1)$. This is a fast-space statement; no full-system restoring rate of order $J_1$ is asserted.

For a fixed label over a proposal-free interval, either auxiliary diffusion using the actual deterministic $a(t)$ satisfies, for $t-s\ge1/(c_LJ_1)$,

\[
\|P^*_{s,t}(z,\cdot)-\mu^*_{a(t),j,\mathrm{type}}\|_{\rm TV}
\le C_L(1+\sqrt{J_1/T}|z|)e^{-c_LJ_1(t-s)}+C_L\epsilon/J_1.
\tag{V24}
\]

Here the parent type uses the loop marginal. To reconstruct the point-start term, reflect Brownian increments across the displacement between two copies of the same time-dependent diffusion and join them on meeting. The distance until meeting has drift at most $-\lambda D$ and noise $2\sqrt{2T}$, $\lambda=c_LJ_1$. Multiplication by $e^{\lambda(t-s)}$ gives Brownian variance $4T(e^{2\lambda(t-s)}-1)/\lambda$. The reflection principle bounds nonmeeting by $C|z-z'|\sqrt{\lambda/T}/\sqrt{e^{2\lambda(t-s)}-1}$. Integrating $z'$ against equilibrium supplies the stated first term. The predictable reflecting noise matrix is orthogonal, so each marginal is the required Brownian motion; globally Lipschitz drift gives the construction up to meeting, after which the copies coincide.

For the moving-reference lag, standardize by $\sqrt{J_1/T}$. The full fast sheet score is its centered quadratic energy; on a fixed small parameter interval its logarithmic moment generating function has second derivative equal to a bounded tilted Gaussian quadratic variance. The loop score is its conditional expectation and inherits that exponential bound by Jensen. Entropy duality gives a score expectation at most $C_L(\sqrt D+D)$. V23 supplies the log-Sobolev inequality $D\le T I/(2\lambda)$ by derivative-flow contraction and entropy integration, with the same truncation argument used in Section 4. Starting at the reference equilibrium at $s$, moving-target entropy then obeys $D'\le-\lambda D+C_L\epsilon^2/\lambda$, hence $D\le C_L\epsilon^2/J_1^2$. Pinsker supplies $C_L\epsilon/J_1$. This proves V24 from a point and does not assume a thermal conditional at activation. The same centered-score calculation and $\sum_k|\partial_ab_k|\le8$ give $\|\mathcal B_{j\cdot}(a)-\mathcal B_{j\cdot}(a')\|_{\rm TV}\le C_L|a-a'|$.

On a proposal-free fine interval, start the auxiliary fast state at the actual $(w_1,h)$ and use the same fast Brownian increments. The force omitted from the auxiliary equation is
$a[(H_N)_{11}-A_*]w_1+a(H_N)_{1,>1}w_{>1}$,
with norm at most $C_LJ_2|w|$. Strong monotonicity gives

\[
|\xi_t-\xi_t^*|\le C_LJ_2\int_s^te^{-c_LJ_1(t-v)}|w_v|dv.
\tag{V25}
\]

The integrand is the actual adapted normal process. For a parent use V22, start the auxiliary loop at the actual loop value, and similarly obtain

\[
|h_t-h_t^*|\le C_L\sqrt{TJ_1}\int_s^te^{-c_LJ_1(t-v)}d(y_v)dv.
\tag{V26}
\]

Combining these bounds with the Lipschitz rows gives a fine row error bounded by $C_LJ_2\sqrt{J_1/T}\int e^{-c_LJ_1(t-v)}|w_v|dv$, and a parent row error bounded by $C_L[d(y_t)+J_1\int e^{-c_LJ_1(t-v)}d(y_v)dv]$. No environment derivative or frozen-environment approximation occurs.

To average these errors, condition on the entire exogenous proposal grid. Brownian motion retains its law because the grid is independent. Every actual sheet potential is even and has Hessian at least $c_LI$, so
$\mathcal L|X_M|^2\le2T\dim M-2c_L|X_M|^2$.
Proposals preserve the norm and deterministic orthogonal activations decrease it. From the actual preparation, $E|X_{M,0}|^2\le C_L(A^2+T)$, whence

\[
\sup_tE[|X_{M,t}|^2\mid\mathrm{grid}]\le C_L(A^2+T).
\tag{V27}
\]

This remains true at grid-selected interval starts. If common activation information fixes a sample, use that sample's squared norm first and integrate its actual law at the end. Future Poisson increments are independent of that information because activation times are deterministic. Thus V27 does not assert a uniform moment bound over every conditioned starting point. Averaging the conditional forcing errors over actual proposal prefixes removes their conditioning exactly and yields a per-proposal error at most

\[
C_L\eta_\epsilon,\qquad
\eta_\epsilon=\frac{J_2}{J_1}+\frac{J_2}{\sqrt{J_1}}(1+A/\sqrt T)
=O_L(\epsilon^7).
\tag{V28}
\]

For example the fine convolution integrates to $O_L(J_1^{-1})$, leaving $C_L(J_2/\sqrt{J_1})(1+A/\sqrt T)$. The parent direct and convolution terms give the same bound plus $C_LJ_2/J_1$. This is the specific small-environment estimate that replaces global acceleration.

## 8. Complete histories and the compatible continuous coupling: c8 and c9

Use the same independent rate-one proposal grid for an actual process and the auxiliary assignment chain with row $\mathcal B_{j\cdot}(a_0(t))$, $a_0(t)=2-e^{-\epsilon t}$, started at the actual initial assignment. Condition on the grid, common actual initial information and strictly preceding proposal marks, including self proposals. Let $\sigma$ be the most recent proposal, activation or start. On $[\sigma,t]$ the label and level are fixed. Future fast Brownian increments conditional on the starting state have their ordinary law; no future continuous observation is in the conditioning.

If $t-\sigma\ge h_*$, V25–V28 compare the actual row to the auxiliary row, V24 compares the latter to its equilibrium average, and V10 with the Lipschitz averaged row replaces the actual parameter by $a_0(t)$. Averaged over actual prefixes and initial information, the resulting error is at most
$C_L[(1+A\sqrt{J_1/T})e^{-c_LJ_1h_*}+\epsilon/J_1+\eta_\epsilon+r_\epsilon]$.
The moment bound also contains a possible $\sqrt{J_1}$ term, which is absorbed here because $A/\sqrt T=\epsilon^{-3}\ge1$. For shorter intervals use the bound one.

For a fixed finite grid, telescope laws with actual prefixes and comparison tails. A common stochastic tail contracts TV, so the joint mark-law distance is bounded by the sum of conditional kernel distances averaged over actual prefixes. This is a complete joint-sequence estimate, not a product of one-time marginal estimates. The expected number of close ordered Poisson pairs is at most $H_*h_*$, from $\int_0^{H_*}\int_{\max(0,t-h_*)}^t ds dt$. Each of at most $L+1$ deterministic activation/start times contributes at most $h_*$ more expected proposals. Since $E N=H_*$, the total bound is

\[
\Pr\{J\ne J^{\rm av}\text{ somewhere on the horizon}\}
\le C_L\left[(H_*+L+1)h_*+H_*(1+A\sqrt{J_1/T})e^{-c_LJ_1h_*}
+H_*\epsilon/J_1+H_*\eta_\epsilon+H_*r_\epsilon\right].
\tag{V29}
\]

Conditional maximal coupling of finite mark sequences given the grid and shared initial information realizes the TV bound. Integrating over the Poisson-finite grids is justified by nonnegative summation. The assignment path is a deterministic step function of the grid and marks, and forgetting self proposals cannot increase disagreement. Two actual processes can be joined through the same conditional comparison-chain law; this preserves their shared actual activation sample and source label, rather than merely matching starting marginals. A finite replacement lineage changes only constants.

Choose $h_*=k_LJ_1^{-1}\log(1/\epsilon)$ with $c_Lk_L\ge Q_1/2+12$. Then the terms in V29 are at most orders $\epsilon^{Q_1-1}\log(1/\epsilon)$, $\epsilon^8$, $\epsilon^{Q_1}$, $\epsilon^6$ and

\[
r_\epsilon/\epsilon=\epsilon^{2Q_1+19}+\epsilon^{3Q_1+25}\ell^2.
\tag{V30}
\]

Thus complete assignment-history disagreement is $O_L(\epsilon^6)$. The history conclusion includes jump times through the shared proposal grid. It is an existence coupling, not a claim of a causal coupling or exact Markov lumpability.

For the separate continuous estimate, the linear retained fine and Schur-parent mean comparison costs $C_LA[J_{s+1}/J_s+H_*J_{s+1}^2/J_s]$ at an interface. The first term is the hidden transient and the second its accumulated retained feedback; they follow by block variation of constants and the weighted cross-block bound $C_LJ_{s+1}$. At the terminal interface the future normal block is absent. Different actual own-law parameters add $C_LAr_\epsilon$: integrate the reference mean's energy, or use $\lambda t e^{-a_{\min}\lambda t}\le1/(e a_{\min})$ on each mode, rather than multiplying by $J_1H_*$. V8 contributes $C_LA\epsilon^{5/2}$. Taking radius $A\epsilon^2$ in each correct Gaussian marginal maximum bound then proves

\[
\Pr\{\sup_{\tau_s\le t\le H_*}|P_sX_t-\bar X_t|>C_LA\epsilon^2\}
\le C_L(1+H_*)e^{-c_L/\epsilon^2}.
\tag{V31}
\]

Here $H_*J_{s+1}^2/J_s=2\epsilon^{19}$ and all other deterministic comparison terms are $o(A\epsilon^2)$. The actual initial retained sample is preserved. The independent root factors can be coupled identically.

To combine V31 with V29, restore each process's conditional continuous-path law given its coupled marks and common initial information. Euclidean continuous-path and finite-state càdlàg-path spaces are standard Borel, so these kernels exist. Augment each correct marginal process by its own linear reference. The deterministic center comparison holds and each marginal concentration event has the same probability under any coupling. A union bound therefore gives V31 under the history coupling. This avoids incorrectly treating Brownian increments as independent after conditioning on future marks. It does not assert closeness in TV of the continuous path laws.

## 9. Joined scope, oracle erasure and remaining obligations

One finite $k_L$ can satisfy the geometric decay, early conditional entrance, terminal joint-entropy entrance and fast-history mixing inequalities simultaneously. Under V1, $t_s-\tau_{s-1}\ge t_s/2$, the first $L-1$ windows shrink, $t_L=k_L\log(1/\epsilon)$, and $\tau_L<2/\epsilon$ eventually. The same preparation yields the moment and entropy inputs for every component. All processes use their actual law in the model update and copy the full actual retained law on activation. Thus the components are joined in one regime, rather than separate limits with incompatible initializations or kinetic clocks.

For $L=2$, triangles $(1,2,3)$ and $(4,5,6)$ with bridge $(3,4)$ give $n=6,E=7,d=19$. The first formation rows have rank ten and the bridge contributes one more, so the carriers are $\mathbb R^{19}\times\mathcal J\to\mathbb R^9\times\mathcal J\to\mathbb R^8\times\mathcal J$, with $|\mathcal J|=64$ and both loop coordinates retained. The agent counts are $6\to2\to1$. The regime is $J_1=\epsilon^{-20}$, $J_2=1$, $A=\epsilon^{40}$, $T=\epsilon^{86}$. This is an exact specialization of the arbitrary finite-depth derivation, not finite-test evidence for the universal quantifier.

The existing claim ledger has c1–c9 and `target`. V2–V5 reconstruct c1; V6–V10 reconstruct c2; V11–V14 reconstruct c3; V15–V16 and the actual activation arguments reconstruct c4; the strict margins and common windows reconstruct c5; V17–V18 reconstruct c6; V19–V22 reconstruct c7; V23–V30 reconstruct c8; and V31 with its coupling argument reconstructs c9. Their simultaneous choice of constants and the explicit two-level instance reconstruct the target. Machine-readable state assignment remains the responsibility of the existing record's designated procedure; this report does not close a claim because a schema, hash or another reviewer says it is closed.

The semantic oracle-erasure check uses no affirmative search prior; the contract's `search_priors` is empty. Removing author expectations, prior positive verdicts, the accelerated theorem's conclusion, posterior-reset assumptions and imposed coefficient schedules leaves the declared admissions plus the displayed derivations. The argument specifically continues to work with $J_L=1$ in V3, V8–V15 and V27; only the source-relevant auxiliary fast potentials have lower curvature of order $J_1$. V20 is a proved exact identity, not a presumed closure ansatz. V25–V28 keep the actual environment and V29 controls complete conditional mark sequences. These are the load-bearing replacements for the earlier unresolved obligations.

The earlier conditional-jump counterexample survives: with hidden targets $(1/4,3/4)$ and $(3/4,1/4)$ and actual masses $(3/4,1/4)$, conditional KL rises from zero as $t^2/32+O(t^3)$. It does not contradict V13, which contracts full joint entropy. Setting source mobility to zero would destroy V13 for incorrect label masses with equilibrated sheet conditionals; disconnected source classes would likewise invalidate its conductance hypothesis. Neither is admitted here. Allowing source costs on later bridge residuals would destroy V20's factorization and require a new argument. These are explicit falsifiers of extensions, not defects in the checked admission.

The strongest supported result is the finite-depth nonlinear adaptive cyclic construction in V1, with exact normalized marked parents, actual own-law continuation, actual source and kernel movement, early conditional KL $O_L(\epsilon^{14})$, terminal conditional KL $O_L(\epsilon^2)$, the corresponding complete-score bounds, continuous error $O_L(A\epsilon^2)$ and entire-history disagreement $O_L(\epsilon^6)$. No mathematical interface remains unresolved within that declared conjunction. Constants and preparation neighborhoods depend on finite depth; all limits are taken through positive $\epsilon$ and positive temperature. The source nonlinearity and source mobility remain fixed.

The result does not establish formation of unsupplied contrasts, arbitrary mixed-level source support, a universal basin, unique grouping, infinite depth, computational savings, a physical clock or base transport. Formation completes on logarithmic time while order-one model/source learning occurs on $1/\epsilon$, so it does not show that source learning creates the supplied hierarchy. The next mathematical action that would change this scope is to admit later-level source support and then derive a replacement for the exact fast marginal and the evolving-environment bounds; it is not to rerun the present theorem or an old experiment.

## 10. Source continuity and revision binding

The current `docs/STATUS.md`, the two September 13 sections of the live Research synthesis, live `PIFB2.tex` section `sec:mixture_derivation`, and `Theory/05b_local_collective_elbo.tex` at the posterior, correlated-recognition and replicator equations were consulted. They distinguish a source-independent row ansatz from unrestricted joint recognition and distinguish pointwise posterior inference from actual source kinetics. Their status statements are context, not proof of the present claim. The proof uses the current normalized model and exact rate identities plus the geometric interfaces checked above; it leaves every preceding proof and its historical scope unchanged.

No trajectory, numerical experiment, GPU computation, full suite, old scientific replay, Lean proof or prohibited tamper check was run. No manuscript, vault, ledger or predecessor proof was edited by this reconstruction. Its evidence is the written derivation and exact calculations. Final read-only standard-library checks recompute the frozen target digest and source hashes and inspect the document; their output is recorded here. Those checks bind reviewed bytes and document structure, not mathematical truth.

The read-only check ran with `C:/Python314/python.exe` and only `hashlib`, `json`, `pathlib`, `re` and `sys`. Canonical UTF-8 serialization of the contract's `target` object with sorted keys and compact separators reproduced the target digest above; its affirmative-search-prior list was empty. The complete contract file SHA-256 was `aba95778725a53a0a8d393f52498fa3edc125995bc51ee28464f8e4c4a950504`. The document check found V1–V31 each once and in order, balanced display delimiters, resolving local Markdown links, and no prohibited LaTeX spacing commands. These are read-only document checks, not scientific tests.

| Reviewed source | SHA-256 |
| :--- | :--- |
| [Weakest-one continuation W1–W13](fixed-weakest-energy-continuation.md) | `d69fc9d232b5f9010240247f24a28a13c827bd24f45f8fdae6af0e45fb133a68` |
| [Weakest-one conditional entropy C1–C27](fixed-weakest-energy-conditional-entropy.md) | `71313ed7a4981e8a9d35514de61a51d0ee40a74114e91217accaffdb1ad0a170` |
| [Weakest-one source histories U1–U36](fixed-weakest-energy-source-histories.md) | `7ad803a637eebe5f2bdc7b59a39fe383e222a8fdaf557c19f92ddc371fb78027` |
| [Weakest-one completion Z1–Z3](fixed-weakest-energy-completion.md) | `97cb81d6dc4d0f9f266903b45df71002bca29ac50e2f9d0c5e655ee4a8e1b2fc` |
| [Normalized marked model](nonlinear-endpoint-attention-model.md) | `725539e6e47d36bc27e54c42ea98602fbbe78a9f96f8aef1c833a0fd3c6e1f1e` |
| [Exact finite-rate identities](finite-rate-source-dynamics-investigation.md) | `9786ac9b8c60d60c81b1a81c22351aa52ebb6016da7d3fc5ea721f4a62e472bd` |
| [Cyclic geometry and uniform sheet interfaces](nonlinear-cyclic-formation-route.md) | `484f7fe08bbd3e0ecda3f03d386dc211f48ae9698cffd6d1bff52be77b47748b` |
| [Conditional geometric interfaces](nonlinear-adaptive-conditional-route.md) | `ebe3e146bab715bdeaa205c091461f4610e0d110effca0820f0d29f06ce65881` |
| [Preceding coupled continuation](finite-rate-coupled-formation.md) | `dc6c8845bba1f7ff131f8fc03c78473963570c9fb8eea32746119034bbca3db5` |
| [Preceding varying-mass conditional estimates](finite-rate-conditional-entropy.md) | `8c3cd74e41b38608017678a79c633070be23961aed87ee28a20a13d515968d4f` |
| [Point-start mixing and history-kernel method](finite-rate-source-history-averaging.md) | `f55fc6981ca98ab374029d76f5ec7f56568bd8ebadee6013fd3a557cb64631b2` |
| [Preceding separate reconstruction](finite-rate-independent-reconstruction.md) | `6736850b5b11b22541df5e1a98cd4a6c72a39b86e4302399de0a7d7bec330a44` |

The preceding sources are reused only at the specific dependence on $J_L$ reconstructed in this report. Their accelerated conclusion is not imported. The table records the reviewed mathematical source bytes; later changes to a load-bearing formula require checking the affected dependency. Matching a source hash or passing a document validator does not certify that formula.
