"""Check current document links and source bindings without certifying mathematics."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote


RUN = Path(__file__).resolve().parent
FRONTIER = RUN.parent.parent
NAMES = (
    "fixed-weakest-energy-continuation.md",
    "fixed-weakest-energy-conditional-entropy.md",
    "fixed-weakest-energy-source-histories.md",
    "fixed-weakest-energy-completion.md",
    "fixed-weakest-energy-independent-reconstruction.md",
)


def main() -> None:
    """Record non-mutating checks of the source artifacts and their retained copies."""
    errors: list[str] = []
    hashes: dict[str, str] = {}
    links = 0
    equation_counts: dict[str, int] = {}
    for name in NAMES:
        source = FRONTIER / name
        data = source.read_bytes()
        hashes[name] = hashlib.sha256(data).hexdigest()
        text = data.decode("utf-8")
        if re.search(r"\\[,!;]", text):
            errors.append("Forbidden LaTeX spacing: " + name)
        if text.count("\\[") != text.count("\\]"):
            errors.append("Unbalanced display delimiters: " + name)
        if any(line.rstrip() != line for line in text.splitlines()):
            errors.append("Trailing whitespace: " + name)
        tags = re.findall(r"\\tag\{([^}]+)\}", text)
        equation_counts[name] = len(tags)
        if len(tags) != len(set(tags)):
            errors.append("Repeated equation tag: " + name)
        prose = re.sub(r"\\\[[\s\S]*?\\\]", "", text)
        for match in re.finditer(r"\[[^\]\n]*\]\((<[^>]+>|[^)\n]+)\)", prose):
            target = unquote(match.group(1).strip("<>"))
            if target.startswith(("https://", "http://", "#")):
                continue
            path = Path(target.split("#", 1)[0])
            if not path.is_absolute():
                path = source.parent / path
            links += 1
            if not path.exists():
                errors.append("Missing local link: " + name + " -> " + target)
    reconstruction = (FRONTIER / NAMES[-1]).read_text(encoding="utf-8")
    for name in NAMES[:-1]:
        if hashes[name] not in reconstruction:
            errors.append("Reconstruction source binding absent or stale: " + name)
    bindings = json.loads((RUN / "document-bindings.json").read_text(encoding="utf-8"))["proof_bindings"]
    for binding in bindings:
        current = (FRONTIER / binding["source"]).read_bytes()
        snapshot = (RUN / binding["snapshot"]).read_bytes()
        if current != snapshot or hashlib.sha256(current).hexdigest() != binding["sha256"]:
            errors.append("Source/snapshot mismatch: " + binding["source"])
    result = {"scope": "Current links, formatting and source/snapshot identity; not mathematical proof or a test-suite total.",
              "source_hashes": hashes, "equation_counts": equation_counts, "local_links": links,
              "source_bindings": len(bindings), "errors": errors,
              "experiments_run": False, "tamper_checks": "user-excluded/not run"}
    (RUN / "document-validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
