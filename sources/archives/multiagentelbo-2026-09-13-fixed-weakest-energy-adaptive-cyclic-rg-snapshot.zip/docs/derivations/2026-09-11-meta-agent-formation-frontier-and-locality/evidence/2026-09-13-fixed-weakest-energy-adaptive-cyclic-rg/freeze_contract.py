"""Freeze the weakest-energy-one continuation before certification."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

RUN = Path(__file__).resolve().parent
PREVIOUS = RUN.parent / "2026-09-13-finite-rate-adaptive-cyclic-rg/problem-contract.json"
target = json.loads(PREVIOUS.read_text(encoding="utf-8"))["target"]
target["statement"] = "Construct finite-depth nonlinear adaptive cyclic RG with weakest energy fixed at one, source-assignment proposal rate one, actual recognition-source change, full actual-law parent activation, and vanishing conditional, complete-score, continuous-path and entire source-history errors on one learning horizon."
target["quantifiers"] = target["quantifiers"].replace("and an explicit positive-temperature energy-contrast regime as epsilon tends to zero.", "and the weakest-one regime Q_L=0, Q_s=2Q_(s+1)+20, J_s=epsilon^(-Q_s), A^2=epsilon^(3Q_1+20), T=A^2 epsilon^6 as epsilon tends to zero. In particular J_L=1 is fixed and may not grow.")
target["premises"][2] = "The weakest energy is fixed at J_L=1. Use the original contrast recursion Q_L=0, Q_s=2Q_(s+1)+20 and the displayed amplitude/temperature regime. No common energy acceleration, weakening of the source likelihood, vanishing source mobility, or additional kinetic multiplier is admissible."
target["premises"].append("Use a common strict-margin normal center with the small explicitly bounded sheet-dependent transport perturbations admitted in the previous finite-rate construction. A narrower nonempty preparation neighborhood may be proved and stated; do not assume equilibrium at actual activations.")
target["falsification_criterion"] = "A negative target verdict requires a nonexistence proof for the frozen weakest-one finite-depth existence target. Failure of a global mixing estimate or one proposed entropy argument is a scoped obstruction, not nonexistence. No conclusion about the already proved accelerated-energy family is changed."
target["permitted_theorems"].append("The finite-rate coupled continuation, entropy and full-history results are reusable only after checking the exact dependence of each estimate on J_L; their accelerated theorem may not be imported wholesale.")
digest = hashlib.sha256(json.dumps(target, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
meta = {"schema_version": "rigorous-theory-search/v1", "contract_id": "contract-sha256-" + digest, "target_digest": digest}
for path in RUN.glob("*.json"):
    data = json.loads(path.read_text(encoding="utf-8"))
    data.update(meta)
    if path.name == "problem-contract.json":
        data["target"] = target
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
header = "<!-- rigorous-theory-search-metadata " + json.dumps(meta, sort_keys=True, separators=(",", ":")) + " -->"
for path in RUN.glob("*.md"):
    body = path.read_text(encoding="utf-8").split("\n", 1)[1]
    path.write_text(header + "\n" + body, encoding="utf-8")
print(json.dumps(meta))
