"""Bind the weakest-one construction and its separate reconstruction."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

RUN = Path(__file__).resolve().parent
FRONTIER = RUN.parent.parent
CONTRACT = json.loads((RUN / "problem-contract.json").read_text(encoding="utf-8"))
META = {k: CONTRACT[k] for k in ("schema_version", "contract_id", "target_digest")}
HEADER = "<!-- rigorous-theory-search-metadata " + json.dumps(META, separators=(",", ":")) + " -->\n"
SOURCES = {
    "model": "nonlinear-endpoint-attention-model.md",
    "rates": "finite-rate-source-dynamics-investigation.md",
    "geometry": "nonlinear-cyclic-formation-route.md",
    "conditional-geometry": "nonlinear-adaptive-conditional-route.md",
    "previous-coupled": "finite-rate-coupled-formation.md",
    "previous-conditional": "finite-rate-conditional-entropy.md",
    "previous-history": "finite-rate-source-history-averaging.md",
    "previous-reconstruction": "finite-rate-independent-reconstruction.md",
    "coupled": "fixed-weakest-energy-continuation.md",
    "conditional": "fixed-weakest-energy-conditional-entropy.md",
    "history": "fixed-weakest-energy-source-histories.md",
    "joined": "fixed-weakest-energy-completion.md",
    "reconstruction": "fixed-weakest-energy-independent-reconstruction.md",
}


def sha(path: Path) -> str:
    """Identify current source bytes; hashes are not mathematical evidence."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(name: str, data: dict) -> None:
    """Write a record under the frozen target binding."""
    (RUN / name).write_text(json.dumps(META | data, indent=2) + "\n", encoding="utf-8")


def prose(name: str, body: str) -> None:
    """Write one of the target-bound narrative records."""
    (RUN / name).write_text(HEADER + body + "\n", encoding="utf-8")


def main(release: bool) -> None:
    """Assemble a candidate checkpoint or record a separately reconstructed release."""
    if release and any(not (FRONTIER / name).is_file() for name in SOURCES.values()):
        raise RuntimeError("All proof components and separate reconstruction are required.")
    assumptions = [
        {"id": "A1", "kind": "MODELING_POSTULATE", "statement": "Fixed c_*, finite prescribed L>=2, the normalized triangle-chain model with independent links, complete retained loops and assignments, compatible root observation, proper prior and calibration."},
        {"id": "A2", "kind": "MODELING_POSTULATE", "statement": "Internal-neighbor source support, fixed delta=10^-4/n, Q_L=0, Q_s=2Q_(s+1)+20, J_s=epsilon^-Q_s, A^2=epsilon^(3Q_1+20), and T=A^2 epsilon^6; weakest energy stays one."},
        {"id": "A3", "kind": "MODELING_POSTULATE", "statement": "Unit continuous mobility and source proposal rate, exact optimizer-conditioned parent rates, complete own-law natural-gradient parameter updates and inherited metric."},
        {"id": "A4", "kind": "MODELING_POSTULATE", "statement": "Common strict-margin normal center, equilibrium independent root, positive assignment masses near their initial prior, and the nonempty bounded sheet-dependent transport preparation specified in W1."},
        {"id": "A5", "kind": "MODELING_POSTULATE", "statement": "Actual complete-law marked activations at W9 with one sufficiently large finite k_L; no equilibrium reset, extra kinetic scaling, base transport or physical-clock identification."},
    ]
    evidence, bindings = [], []
    proof_dir = RUN / "proofs"
    proof_dir.mkdir(exist_ok=True)
    for key, name in SOURCES.items():
        source = FRONTIER / name
        if not source.is_file():
            continue
        snapshot = proof_dir / name
        snapshot.write_bytes(source.read_bytes())
        evidence.append({"id": "proof-" + key, "kind": "DERIVATION", "supports": True,
                         "scope": "Displayed derivation and explicitly checked interfaces in " + name,
                         "side_conditions": [a["statement"] for a in assumptions],
                         "artifact_path": "proofs/" + name, "artifact_sha256": sha(snapshot)})
        bindings.append({"source": name, "snapshot": "proofs/" + name, "sha256": sha(source)})
    specs = [
        ("c1", "The normalized marked parents have exact optimizer-conditioned reversible proposal rows and exact nested probability and rate composition.", ["model", "rates", "coupled"], "Every admitted finite level and parameter.", "An omitted mark, normalizer or regenerated heat bath invalidates the identity."),
        ("c2", "The coupled fine and own-law parent processes exist through 2/epsilon with the W6 moment and W7 parameter bounds when J_L=1.", ["coupled", "previous-coupled"], "Every admitted preparation for sufficiently small epsilon at each finite L.", "Circular dependence on unproved averaging, a moment failure or parameter exit invalidates continuation."),
        ("c3", "Diffusion plus the inherited source jumps contracts full joint relative entropy uniformly at J_L=1, with moving-target remainder O_L(epsilon^2).", ["conditional"], "Every active parent and admitted own-law coefficient on the full horizon.", "A failed conductance comparison, entropy tensorization or full-score bound invalidates contraction."),
        ("c4", "Actual activations give early discarded-conditional KL O_L(epsilon^14) and terminal KL O_L(epsilon^2), with complete-score errors O_L(T epsilon^7) and O_L(T epsilon).", ["conditional", "previous-conditional", "conditional-geometry", "coupled"], "Every finite successive interface after its common prescribed entrance time.", "An unproved actual activation budget, incompatible entrance constant or omitted score term invalidates the bounds."),
        ("c5", "The weakest-one family undergoes L actual successive cyclic coalescence episodes on W9, with every loop retained and future residuals separated.", ["coupled", "geometry", "joined"], "For every finite L>=2, including the explicit 6-to-2-to-1 carrier.", "A lost residual margin, insufficient terminal time or incompatible conditional window invalidates formation."),
        ("c6", "Actual source mass changes by TV>1/2 from every activation to the horizon, and both first hidden physical and optimizing kernels change by KL>1/200.", ["coupled", "rates", "model"], "For all admitted preparations and fixed retained kernel inputs at each finite L.", "Borrowing a parameter schedule or using tau_L=o(1) in the weakest-one regime invalidates the movement argument."),
        ("c7", "Integrating all later normal coordinates leaves exactly the intrinsic source-relevant fast marginal, and every level has the same optimizer-averaged proposal row.", ["history", "geometry"], "Every positive descending energy family and each finite exact retention in the admitted source model.", "A residual dependence on slow coordinates, a nonconstant Jacobian or missing nonlinear term invalidates the identity."),
        ("c8", "Complete assignment histories of fine and exact parents admit a coupling with disagreement probability O_L(epsilon^6) under unit source mobility.", ["history", "coupled", "joined"], "The entire remaining learning horizon after every actual activation and each finite replacement lineage.", "Instantaneous rates alone, conditioning away an actual activation sample or freezing the evolving environment invalidates history comparison."),
        ("c9", "The compatible history coupling also has continuous-coordinate path error O_L(A epsilon^2) outside the stated exponentially small exceptional probability.", ["coupled", "history", "joined"], "Uniformly from actual activation to 2/epsilon at each finite interface.", "Incorrect marginal references, incompatible initial coupling or a hidden continuous-path TV assertion invalidates the claim."),
    ]
    available = {e["id"] for e in evidence}
    claims = []
    for key, statement, refs, quantifiers, falsifier in specs:
        ids = ["proof-" + x for x in refs if "proof-" + x in available]
        if release:
            ids.append("proof-reconstruction")
        claims.append({"id": key, "statement": statement, "quantifiers": quantifiers,
                       "kind": "MATHEMATICAL", "target_digest": META["target_digest"],
                       "state": "EVIDENCE_VERIFIED" if release else "CANDIDATE",
                       "assumption_ids": [a["id"] for a in assumptions], "evidence_ids": ids,
                       "bridge_premise_ids": [], "falsifier": falsifier})
    target = CONTRACT["target"]
    claims.append({"id": "target", **{k: target[k] for k in ("statement", "quantifiers", "kind")},
                   "target_digest": META["target_digest"], "state": "EVIDENCE_VERIFIED" if release else "CANDIDATE",
                   "assumption_ids": [a["id"] for a in assumptions],
                   "evidence_ids": (["proof-joined"] if "proof-joined" in available else []) + (["proof-reconstruction"] if release else []),
                   "bridge_premise_ids": [], "falsifier": target["falsification_criterion"]})
    record("claim-ledger.json", {"assumptions": assumptions, "evidence": evidence, "claims": claims})
    deps = {"target": [s[0] for s in specs], "c2": ["c1"], "c3": ["c1", "c2"],
            "c4": ["c1", "c2", "c3"], "c5": ["c2", "c4"], "c6": ["c1", "c2"],
            "c7": ["c1"], "c8": ["c1", "c2", "c7"], "c9": ["c2", "c5", "c8"]}
    ids = [c["id"] for c in claims]
    record("dependency-dag.json", {"nodes": ids, "edges": [{"from": k, "to": v} for k, vs in deps.items() for v in vs]})
    rows = [
        ("whole-space-mixing", ["c8"], "Uniformly mix every non-root coordinate on each short proposal gap.", "The inherited prior global bound mixes only at J_L=1.", "With H=2/epsilon, the short-gap penalty H h cannot vanish while a global rate-one contraction forgets the entrance state.", ["Prior global-mixing estimate fails to close the weakest-one history target."], ["No nonexistence result follows."], "retired"),
        ("joint-entropy-terminal-entrance", ["c3", "c4"], "Entropy comparison with a Gaussian-times-prior reference and exact inherited conductance.", "Positive categorical dissipation complements within-sheet diffusion.", "Use joint contraction on logarithmic terminal time and faster conditional estimates at earlier interfaces.", ["Direct entropy and score derivation in the conditional component."], [] if release else ["Separate reconstruction."], "supported" if release else "under reconstruction"),
        ("intrinsic-fast-marginal", ["c7", "c8"], "Triangular Gaussian elimination and mixing only the first normal layer plus loops.", "The optimizer fast marginal is exactly independent of later energy strengths.", "Bound actual evolving-environment perturbations, then telescope conditional proposal-prefix kernels.", ["Exact marginal and history derivations in the history component."], [] if release else ["Complete conditional-prefix and separate reconstruction checks."], "supported" if release else "under reconstruction"),
        ("weakest-one-joined", ["target"], "Join actual-law continuation, early/terminal entropy, fast history mixing and compatible marginal concentration.", "All estimates use one weakest-one regime and the same actual activations.", "W7 precedes entropy; one finite k_L meets all entrance conditions; histories retain common actual samples.", ["The joined target is stated in the completion component."], [] if release else ["Separate full-contract reconstruction."], "supported" if release else "under reconstruction"),
    ]
    families = []
    for key, targets, mechanism, invariant, bridge, results, gaps, disposition in rows:
        families.append({"family_id": key, "core_mechanism": mechanism, "target_obligation_ids": targets,
                         "representation": mechanism, "invariant_or_obstruction": invariant,
                         "obligations": targets, "bridge": bridge,
                         "failure_test": "Check the frozen target and the explicit mechanism-specific failure tests in the bound proofs.",
                         "verified_results": results if release else [], "open_gaps": gaps,
                         "novelty_fingerprint": key + " | " + invariant + " | fixed J_L=1, unit source rate, internal source support",
                         "disposition": disposition})
    record("approach-registry.json", {"mechanism_families": families})
    if release:
        artifact = {"artifact_path": "proofs/" + SOURCES["reconstruction"],
                    "artifact_sha256": sha(FRONTIER / SOURCES["reconstruction"])}
        attacks = [
            ("normalization", ["c1"], "A regenerated coarse heat bath or missing source mark changes the retained process.", "The exact conditional-expectation construction and its conductance tower are reconstructed."),
            ("continuation", ["c2"], "Continuation might assume the mixing or moment conclusion needed later.", "Stopped moments and inward parameter bounds precede all entropy and history estimates."),
            ("entropy", ["c3", "c4"], "A bounded conditional jump source leaves an order-one terminal error.", "Joint categorical-plus-diffusion coercivity and logarithmic terminal entrance are derived; earlier interfaces retain their explicit jump term."),
            ("windows", ["c5", "c6"], "The terminal activation is not o(1), so the previous source-mass estimate may fail.", "The S6 forcing envelope replaces the small-activation-time argument and the common finite k_L is checked."),
            ("fast-marginal", ["c7"], "Partial Gaussian elimination may change the nonlinear source law or its covariance.", "The exact triangular integration identity and intermediate first-layer precision sandwich retain both contributions."),
            ("histories", ["c8", "c9"], "Same-time averaging cannot control history-conditioned kernels or a compatible continuous coupling.", "The pointwise fast estimates, actual-prefix telescoping and correct marginal concentration are reconstructed with actual activations."),
            ("scope", ["target"], "The fixed-energy theorem might secretly accelerate J_L or weaken a source or preparation assumption.", "The frozen Q_L=0 regime, fixed positive delta and source rate, and explicit nonempty preparation are checked at every interface."),
        ]
        record("adversarial-report.json", {"attacks": [{"id": k, "claim_ids": cs, "attack": a, "response": r, "disposition": "REJECTED", **artifact} for k, cs, a, r in attacks],
               "independent_reconstruction": {"claim_ids": ids, "method": "Separate nonauthor reconstruction from the frozen target and written components; shared source context is disclosed.", "result": "PASS", "conclusion": "The displayed reconstruction supports all components and their weakest-one join.", **artifact},
               "oracle_erasure": {"claim_ids": ids, "method": "Inspect assumptions, proof dependencies and every join for semantic circularity without an affirmative search prior.", "result": "PASS", "conclusion": "The construction uses the declared source support, contrasts and preparation and derived estimates; no favorable search expectation is a premise.", **artifact}})
    strongest = "For every prescribed finite L>=2, the admitted nonlinear cyclic model with J_L=1 and source proposal rate one has L actual formations, exact marked actual-law activations, actual source and hidden-kernel changes, vanishing conditional and complete-score errors, O_L(A epsilon^2) continuous-path error and O_L(epsilon^6) complete assignment-history disagreement."
    record("release.json", {"checkpoint": "separately reconstructed" if release else "joined derivation under reconstruction",
                           "target_claim": "target", "terminal_status": "COMPLETE_AFFIRMATIVE" if release else None,
                           "certificate_claim": "target" if release else None,
                           "strongest_result": strongest if release else "Candidate weakest-one join; separate reconstruction pending.",
                           "unresolved_obligations": [] if release else ["Independent reconstruction of all component and full-history interfaces."]})
    prose("construction-or-strongest-theorem.md", "# Weakest-one construction\n\n" + strongest + "\n\nThe exact preparation and simultaneous bounds are in proofs/fixed-weakest-energy-completion.md. Consult release.json for the current reconstruction and terminal status.")
    prose("counterexample-register.md", "# Route limits and required corrections\n\nThe previous global mixing estimate fails at J_L=1; it does not prove nonexistence. A jump can increase hidden conditional KL even when full VFE decreases. Diffusion alone does not contract an incorrect source marginal, and bounded exit rates alone do not imply connected categorical mixing. The new proof uses the actual positive inherited conductances. The earlier tau_L=o(1) source-mass argument is invalid in this regime and is replaced by the exact forcing envelope. Regenerated parent heat baths remain excluded by the retained S12 counterexample. None of these failures refutes the frozen weakest-one target.")
    prose("final-report.md", f"""# Rigorous theory search report

## Frozen contract

{META['target_digest']}. {target['quantifiers']}

## Terminal status

{'COMPLETE_AFFIRMATIVE.' if release else 'Checkpoint only; no terminal status.'}

## Certificate

The target depends on c1-c9 under A1-A5. The bound construction and direct source snapshots state the exact finite-depth witness, preparation and estimates. The quantifier is existence at every prescribed finite L>=2 in the frozen weakest-one family.

## Strongest verified result

{strongest if release else 'The joined construction is written; full separate reconstruction remains pending.'}

## Dependency closure

Exact normalized parent laws precede coupled continuation. Joint entropy contraction and the early conditional estimates use the proved continuation. The intrinsic fast-marginal identity precedes the full-history estimate. Formation, source movement and marginal concentration share the same coefficients, preparation and activation schedule.

## Independent reconstruction

The separate nonauthor reconstruction re-derives the load-bearing claims and joins from the frozen target. Shared prior source context and filesystem are disclosed; no blind-review or independent-corroboration claim is made. Written derivation, not agreement, supplies the mathematical evidence.

## Oracle erasure

There is no affirmative search prior in the contract. The semantic check inspects the fixed source support, prescribed contrasts, preparation, actual-law feedback and all estimates for assumptions that would merely assert the conclusion. No growing weakest energy is admitted.

## Unresolved obligations

{'None within the frozen weakest-one target.' if release else 'The complete independent reconstruction remains open.'} Arbitrary mixed-level source support, learned creation of supplied contrasts, universal initial conditions, infinite depth and resource advantages are outside this result.

## Scope and limitations

This is an analytical finite-family construction under explicit model and kinetic postulates. It removes common energy acceleration but retains internal-neighbor source support, calibration and shrinking thermal preparation. The final formation time is logarithmic while source learning occurs on 1/epsilon. Exact probability composition, conditional entropy, continuous paths and source histories remain distinct. No simulation, production implementation, numerical experiment, GPU work, full suite, Lean proof or prohibited tamper check ran; tamper checks are user-excluded/not run.
""")
    record("document-bindings.json", {"proof_bindings": bindings, "scope": "Current source/snapshot identity is diagnostic provenance, not mathematical certification."})
    print(json.dumps({"claims": len(claims), "snapshots": len(bindings), "release": release}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", action="store_true")
    main(parser.parse_args().release)
