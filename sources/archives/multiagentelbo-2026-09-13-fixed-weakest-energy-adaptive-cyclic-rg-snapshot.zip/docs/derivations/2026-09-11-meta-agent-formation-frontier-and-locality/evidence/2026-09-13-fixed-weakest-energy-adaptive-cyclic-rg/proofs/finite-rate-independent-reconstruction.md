# Reconstruction of the finite-rate cyclic hierarchy

September 13, 2026. This reconstructs the mathematical target in [the frozen contract](evidence/2026-09-13-finite-rate-adaptive-cyclic-rg/problem-contract.json), whose target digest is `2f673c3806f5838530bd025b43174018904da19fe6af74fc8c24ae2e7bcf3e09`. The result is a reconstructed proof for the explicitly accelerated-energy family. It does not settle the weakest-strength-one family. The reconstruction was performed separately from the component authors, with shared research context and communication about precise interfaces; it was not a blinded review. Its evidence consists of the calculations below and the identified source calculations, not agreement among reviewers or a document validator.

## 1. Quantifiers, admission and conclusion

For every prescribed finite integer $L\ge2$, there are constants $\epsilon_L,c_L,C_L>0$, a fixed positive nonlinear coefficient, fixed nested marked retentions, and a nonempty preparation neighborhood such that every $0<\epsilon<\epsilon_L$ gives the following positive-temperature construction. There are $L$ successive formation episodes on $[0,H_*]$, $H_*=2/\epsilon$; exact normalized physical, optimizing and actual marked parent laws; exact composition of optimizer-conditioned parent jump rates at a fixed parameter; and well-posed independent parent processes initialized from the complete actual preceding retained law and parameter. An actual binary recognition-source row changes by TV greater than $1/2$. Each first hidden physical and optimizing conditional changes by KL greater than $1/200$, uniformly in the retained input and label. At every active interface, after its stated entrance wait, discarded conditional KL is $O_L(\epsilon^8)$ and the complete same-state model covector discrepancy is $O_L(T\epsilon^4)$. Independently evolving retained continuous paths admit error $O_L(A\epsilon^2)$ in the uniform norm outside a vanishing exceptional probability. Complete assignment histories admit a coupling with disagreement probability $O_L(\epsilon^7\log(1/\epsilon))$. These assertions use one simultaneous regime.

The carrier is Euclidean space times the entire finite source-assignment set, with Lebesgue and counting measures. It is a pointwise view at $c_*$ of the declared local-section model; the links are independent dynamic variables and network loop holonomy survives. Static law and rate composition are exact. Continuous path approximation is a scaled uniform-norm statement. Assignment-history approximation includes all jump times through a common proposal grid. Neither approximation asserts exact temporal lumpability or total variation convergence of continuous path laws.

The supplied contract admits the normalized source/evaluator/calibration experiment, finite prescribed depth, supplied energy contrasts, compatible root observation, shrinking preparation neighborhoods, and an accelerated-energy family distinct from the old $J_L=1$ family. The selected construction additionally fixes binary internal-triangle source support, an independent equilibrium root, a common strict-margin initial normal center, and the particular powers

\[
Q_L=8,\quad Q_s=2Q_{s+1}+20,\quad J_s=\epsilon^{-Q_s},\quad
A^2=\epsilon^{3Q_1+20},\quad T=A^2\epsilon^6.
\tag{R1}
\]

Continuous mobility and the microscopic full-assignment proposal rate are both one. There is no level-dependent kinetic multiplier and no source-mobility limit. The nonlinear coefficient is $\delta=10^{-4}/n$, fixed for each finite $L$. The prescribed diffusion, jump process and natural-gradient model equation are inference kinetics; VFE does not uniquely select them. All constants and the neighborhood may depend on $L$. Uniformity in unbounded depth, a fixed-temperature limit, unsupplied formation of contrasts, generic source support, physical time and base transport are outside these quantifiers.

The preparation in [D1](finite-rate-coupled-formation.md) uses the same Gaussian normal center $Av_0$ on every sheet, zero loop center, covariance $T\widehat K_1^{-1}$, and an independent common equilibrium root. The vector $v_0$ varies in a fixed neighborhood of the strict-margin vector constructed in the geometric source. Positive source masses vary near the initial product prior, with distinguished binary mass within $10^{-2}$ of $\operatorname{sigmoid}(-2)$. Within-sheet smooth positive transports are admitted when

\[
|\widehat K_1^{1/2}(X_0-X_0^G)|<\epsilon\sqrt T
\tag{R2}
\]

almost surely and their log-density ratios are bounded. Small smooth maps supported on a compact set in standardized coordinates give such perturbations: taking their displacement and Jacobian sufficiently small preserves positivity and bounds both the Gaussian density change and the determinant. This is a nonempty neighborhood in the declared weighted-transport and bounded-log-density topology. It is not asserted to be open in every usual topology of probability laws or to have a size uniform in $\epsilon$. The common center matters: unrestricted sheet means separated by order $A$ would introduce an order-$A^2$ covariance and would not satisfy the later $T H^{-1}$ moment preparation.

## 2. Normalization, geometry and exact marked inheritance: c1

Write $b=2^{L-1}$, $n=3b$, $E=4b-1$ and $d=2n+E=10b-1$. In $x=(u,v,\alpha)$ the original residuals are $d_i=u_i-v_i$ and $r_e=u_i-u_j-\alpha_e$. The quadratic form $H$ sums $J_1d_i^2$ and $J_er_e^2$. Its kernel is $K=\{(t,t,Dt):t\in\mathbb R^n\}$; the $b$ triangle loop directions form $H_h$; the remaining normal space is $N$. The linearly independent formation rows define nested orthogonal projections $P_s$ which retain $K$, all of $H_h$, and future normal modes. The geometric source proves independence by eliminating the triangle rows first and then the bridge rows. Its matrix $\mathcal B=BO$ in the orthogonal flag basis is block lower triangular. The weighted conjugation of this matrix and its inverse has bounded entries because its off-diagonal factors are $\sqrt{J_j/J_i}\le1$ for descending strengths. Consequently

\[
c_L\operatorname{diag}(J_s)\preceq H|_N\preceq C_L\operatorname{diag}(J_s).
\tag{R3}
\]

Schur complements obey the corresponding bounds by minimizing the quadratic form over eliminated coordinates. The loop block remains positive with strength of order $J_1$. In particular every retained nonroot Schur complement $H_p$ is bounded below by $c_LJ_L I$. No base connection is used in this calculation.

The source assignment is $j=(j_i)_i\in\mathcal J$, with $|\mathcal J|=2^n$. Its normalized prior is $\pi_j(a)=\prod_i\pi_{i,j_i}(a)$. Set

\[
\phi_j(x)=\delta\sum_i(1-e^{-J_1r_{i,j_i}^2/(2T)}),\qquad 0\le\phi_j\le B_0=10^{-4}.
\tag{R4}
\]

The complete generative experiment [E1–E10](nonlinear-endpoint-attention-model.md) uses prior precision $A_0=aH+P_K-TR$, calibration $Y\mid a\sim N(a,T)$ observed at $2$, a normalized Gaussian observation on $K$, and source successes with probabilities $(1/2)e^{-\delta f}$. Their complementary failure probabilities are also strictly positive. Every factor is a probability kernel. Since $R$ is a fixed finite positive operator in the first normal layer and $T/J_L\to0$, $TR\preceq H/2$ for small $\epsilon$; hence $A_0\succ0$ throughout $1\le a\le2.1$. All partition integrals are positive and finite because multiplication by $e^{-\phi_j}$ changes Gaussian integrals by a factor in $[e^{-B_0},1]$.

The optimizing marked density is

\[
\Pi_a(dx,j)=Z_a^{-1}\pi_j(a)e^{-G_a(x)/T-\phi_j(x)}dx.
\tag{R5}
\]

The physical posterior instead uses the corrected quadratic precision $aH+(1+\kappa)P_K-TR$. It is not R5. The exact scalar $C_T$ retains the prior normalizer, observation constants, calibration term and optimizing partition integral as in E10. Expanding the full joint entropy yields $\mathcal F_T(q,a)=T D(q\Vert\Pi_a)+C_T(a)$ for unrestricted joint recognition. In particular it contains the conditional-source KL $D(q(j\mid x)\Vert b(x,a))$; that term is not removed by resetting labels. Here

\[
b_k(x,a)=\frac{\pi_k(a)e^{-\phi_k(x)}}{\sum_j\pi_j(a)e^{-\phi_j(x)}}.
\tag{R6}
\]

The original zero-mobility realization E27 is not used as the new generator. The new microscopic generator is [S2](finite-rate-source-dynamics-investigation.md), with rate-one full-assignment proposals from R6 and continuous drift $-\nabla(G_a+T\phi_j)$ on sheet $j$. If $q_X=\sum_jq_j$ and $\eta_j=q_j/q_X$, its jump forward equation is $\dot q_j|_{\rm jump}=q_Xb_j-q_j$. At fixed $a$, $\Pi_a(x,j)b_k=\Pi_{a,X}(x)b_jb_k$ is symmetric in $j,k$. Direct differentiation therefore gives

\[
\frac{d\mathcal F_T}{dt}=-T^2\sum_j\int q_j|\nabla\log(q_j/\Pi_{a,j})|^2
-T\int q_X[D(\eta\Vert b)+D(b\Vert\eta)]
-\epsilon m(a)^{-1}g(q,a)^2.
\tag{R7}
\]

For a true retention $(P_p,\operatorname{id}_{\mathcal J})$, disintegrate R5 as $s_a(y,j)k_{a,j}(z\mid y)$. Its exact inherited proposal row is

\[
R^p_{jk}(y,a)=E_{\Pi_a}[b_k(X,a)\mid P_pX=y,J=j].
\tag{R8}
\]

Rows sum to one, every entry is at least $e^{-B_0}\min_{a,k}\pi_k(a)>0$, and off-diagonal exit rates sum to at most one. Integrating the preceding symmetric identity proves $s_a(y,j)R^p_{jk}=s_a(y,k)R^p_{kj}$. Thus the parent jump contribution to VFE is

\[
-\frac T2\int\sum_{j,k}c_{jk}(u_j-u_k)(\log u_j-\log u_k)\le0,
\quad c_{jk}=s_jR^p_{jk},\quad u_j=q_j/s_j.
\tag{R9}
\]

For another retention $V=P_{p+1}X$, the conditional-expectation tower gives $E[R^p_{jk}(P_pX,a)\mid V,J=j]=E[b_k(X,a)\mid V,J=j]$. This proves exact rate composition. Separate disintegration of the physical, optimizing and actual joint measures gives their own exact normalized kernels and the same channel composition, including evaluator, occupancy and loop records. Receiver occupancy $1/n$ and source selection are applied inside the joint readout, not multiplied after separate averaging. All laws live on standard Euclidean/finite carriers, so positive densities provide their conditional kernels explicitly. Pushing the full actual joint law at an activation retains its actual source dependence.

This exact rate is generally not a new heat bath on the marginal source posterior. For the positive joint with hidden $x=0,1$ equiprobable and $b_+(0)=1/4,b_+(1)=3/4$, the inherited $+\to-$ rate is $3/8$, whereas a regenerated heat bath gives $1/2$. The two hidden states in the same retained $+$ fiber have microscopic exits $3/4$ and $1/4$, respectively. Thus neither rate composition nor normalization implies strong temporal lumpability.

## 3. Global nonlinear bounds and complete own-law continuation: c2

For each exact parent, cumulative Gaussian integration gives

\[
V_{p,j}(y,a)=\frac a2y^TH_py+C_p(a)+T\psi_{p,j}(y,a),\quad
\psi_{p,j}=-\log E_{\gamma_{p,a}(\cdot\mid y)}e^{-\phi_j},\quad
C_p'(a)=\frac{Td_p}{2a}.
\tag{R10}
\]

The Gaussian hidden center is independent of $a$ and its covariance is $T/a$ times a fixed matrix. Every $\psi_{p,j}$ lies in $[0,B_0]$. Differentiating the integral in its retained coordinate gives an expected Hessian minus a covariance of gradients. For $f(s)=1-e^{-s^2/2}$, $|f'|,|f''|\le1$, so before marginalization

\[
|H^{-1/2}T\nabla\phi_j|\le G_0\sqrt T,\qquad
-\eta H\preceq T D^2\phi_j\preceq\eta H,
\quad \eta=2(\delta+\delta^2),\quad G_0^2\le2n\delta^2.
\tag{R11}
\]

The constants have been enlarged to cover every sheet. The covariance correction in an exact marginal contributes at most $G_0^2H_p$. Since $\eta+G_0^2<1/2$ for $n\ge6$, this proves

\[
c_LH_p\preceq D_y^2V_{p,j}\preceq C_LH_p,\qquad
|H_p^{-1/2}T\nabla\psi_{p,j}|\le C_L\sqrt T.
\tag{R12}
\]

These are global bounds, including the induced covariance, not Hessians with frozen source weights. Gaussian domination justifies every displayed differentiation. The centered parameter score of the cumulative hidden Gaussian is $(d_p-|Z|^2)/(2a)$, with $Z\sim N(0,I)$. Bounded tilt bounds its moments and gives $|\partial_a\psi_{p,j}|\le C_L$, uniformly in the retained input and the asymptotic parameters.

Differentiating the full parent VFE at fixed actual law gives precisely

\[
g_p(q,a)=a-2+\frac12E_qy^TH_py+\frac{Td_p}{2a}
+TE_q\partial_a\psi_{p,J}-\frac T2\operatorname{tr}(A_0^{-1}H)
-TE_q\partial_a\log\pi_J(a).
\tag{R13}
\]

No derivative of the time-varying actual label masses belongs in this partial covector. The complete generative Fisher is

\[
M(a)=T^{-1}+\tfrac12\operatorname{tr}[(A_0^{-1}H)^2]
+\sum_i\operatorname{Var}_{\pi_i}t_i,\qquad m(a)=TM(a)=1+O_L(T)\ge1.
\tag{R14}
\]

Here only the distinguished row has $t_+=4,t_-=0$. The prior, categorical and calibration scores have zero means and zero cross expectations in the normalized generative joint. The conditional observation/evaluator kernels have no explicit parameter derivative at fixed conditioning arguments. This verifies R14 as the inherited microscopic model metric, not the Fisher metric of a posterior or a newly marginalized model.

For fixed positive $T,J$ and a prescribed parameter path in a compact neighborhood of $[1,2.1]$, R12 gives globally Lipschitz sheet drifts with linear growth. R8 and its derivatives are bounded for that fixed instance and have a strictly positive row lower bound. Interlacing the sheet SDEs with a rate-one Poisson grid constructs a unique nonexplosive process. To close the law-dependent equation, the backward expectation of a smooth terminal quadratic or bounded score can be differentiated through the interlaced representation. Flow derivatives are bounded on bounded time intervals, a differentiated proposal weight is at most a constant times the original weight, and the proposal count has all exponential moments. Polynomial moment bounds therefore justify the differentiated expectation. Applying the resulting backward identity to two prescribed paths yields

\[
|E_a f(X_t,J_t)-E_{\widetilde a}f(X_t,J_t)|
\le C\int_0^t|a(s)-\widetilde a(s)|ds.
\tag{R15}
\]

The explicit terminal dependence of a score on $a$ contributes an additional $C|a(t)-\widetilde a(t)|$. These inequalities make the integral equation $\dot a=-\epsilon m^{-1}g_p$ a contraction on a sufficiently short interval. Constants in this local existence step may depend on the fixed positive instance; no uniform-in-$\epsilon$ local existence constant is claimed.

Continuation is not obtained by assuming tracking. Stop at a possible exit from $[1,2.1]$ and compare the actual process with the linear process driven by the same Brownian motion, actual deterministic $a(t)$ and Gaussian initial reference. A source jump changes neither continuous coordinate. The error $e$ obeys, for every adapted assignment path,

\[
\frac d{dt}|e|^2\le-e^TH_pe+C_LT,\qquad
\sup_{t\le H_*}|e_t|\le|e_0|+C_L\sqrt{TH_*}.
\tag{R16}
\]

The exact linear propagator is $\exp[-H_p\int_s^ta]$. Spectral calculus, splitting elapsed time at $1/(C_LJ_1)$ and $1/(c_LJ_L)$, gives

\[
\int_0^t\|H_pe^{-H_p\int_s^ta}\|ds
\le C_L[1+\log(J_1/J_L)].
\tag{R17}
\]

The bounds being integrated are $C_LJ_1$, $C_L/(t-s)$ and the exponential tail. Hence the squared energy of the nonlinear error is $O_L(T\ell^2)$, $\ell=1+\log(1/\epsilon)$. The Gaussian covariance is bounded by $C_LT H_p^{-1}$ using only $a\ge1$. At a projection, the inverse-covariance identity $P H_p^{-1}P^T=H_{p+1}^{-1}$ and the Schur quadratic minimum preserve these estimates. The common deterministic center has norm $O_L(A)$, no loop component, and only future normal strengths remain after formation. Induction through the finite number of stages gives

\[
E_qX^TH_pX\le C_L[A^2J_{p+1}+T\ell^2],\qquad
J_1E_q|X_{H_h}|^2\le C_LT.
\tag{R18}
\]

The convention is $J_{L+1}=0$. The second estimate follows by using the actual loop decay of order $J_1$ and its bounded force; it does not assign the loop the weaker future-normal scale.

R13–R18 imply

\[
\dot a=\epsilon(2-a)+O_L(\epsilon r_\epsilon),\quad
r_\epsilon=A^2J_1+T\ell^2\longrightarrow0.
\tag{R19}
\]

For small $\epsilon$ the derivative is inward at both endpoints $1$ and $2.1$. Thus the stopped solution never exits, its moment bounds allow continuation to $H_*$, and $|\dot a|\le C_L\epsilon$. Variation of constants gives

\[
\sup_{t\le H_*}|a_p(t)-(2-e^{-\epsilon t})|\le C_Lr_\epsilon.
\tag{R20}
\]

Each new parent starts with its actual activation parameter, so only a finite accumulated discrepancy enters R20. Its coefficient is computed from its own evolving law in R13. The reference in R20 is a comparison function, not an externally supplied learning schedule. Since $2-e^{-2}>7/4$, every such parameter exceeds $7/4$ on the last ten units of the horizon for small $\epsilon$.

## 4. Moving labels, actual activation and conditional tracking: c3

The discarded-conditional entropy argument uses an auxiliary hidden block $Z$ consisting of the current discarded normals and all retained loops, with future normals $Y$ and the full assignment $J$ retained in the conditioning. The true parent still retains every loop. The conditional KL chain rule gives $\Delta_{\rm discarded}\le\widehat\Delta$, where $\widehat\Delta$ is the auxiliary conditional KL. For $s-1\to s$, R12 gives hidden curvature $\lambda_s=c_LJ_s$. The restricted source support also gives mixed curvature $\Gamma_s=C_LJ_{s+1}$, with $\Gamma_L=0$.

The mixed estimate requires the special source geometry. In the residual coordinates used in [N30–N34](nonlinear-adaptive-conditional-route.md), the cumulative hidden matrix is $D_E+C^TD_fC$. Its first-row inverse is the first row of $D_E^{-1}(I-RA^{-1})$, bounded by $C_L/J_1$. A future level-$s$ direction therefore changes the first hidden conditional mean by $O_L(J_s/J_1)$. Applying this to the Gaussian integral in R10 gives a loop/future mixed derivative of order $J_s$, and an internal/future derivative of order $J_iJ_s/J_1$. This proves the stated $\Gamma_s$; a generic row spanning several energy levels would not inherit this argument.

Jumps need not decrease $\widehat\Delta$. At fixed $Y=y$, let $\theta(j\mid z)$ denote the actual source conditional and let $\gamma$ be the common Gaussian reference for the optimizing hidden conditionals $k_j$. The relative entropy with reference $\gamma$ decomposes as $D(q_Z\Vert\gamma)+I(Z;J)$. A rate-one proposal leaves $q_Z$ fixed. Mutual information is convex in the channel $\theta$ for a fixed input law, so its directional derivative toward $\theta R$ is at most $I(\theta R)-I(\theta)\le\log|\mathcal J|$. Since $|\log(\gamma/k_j)|\le B_0$, the correction contributes at most $2B_0$. Consequently

\[
\left.\frac d{dt}\widehat\Delta\right|_{\rm jump}
\le C_J:=\log|\mathcal J|+2B_0.
\tag{R21}
\]

This holds for configuration-dependent rows and variable actual masses. Positivity, approximation and one-sided derivatives handle any entropy derivative limit; it uses no lower bound on actual history probabilities or actual source masses.

An activation budget also needs a lower entropy bound. Let $h=-\sum_j\int q_j\log q_j$ be differential/counting entropy in the $d'$ nonroot continuous dimensions. Gaussian log-Sobolev expansion gives $I(f)\ge2\pi e d' e^{-2h(f)/d'}$: expand the inequality against $N(0,\sigma^2I)$, cancel the second moments, and optimize $\sigma^2=d'/I(f)$. The Gaussian inequality itself follows from the semigroup gradient-contraction argument given below in the history proof. Jensen over the sheet masses and their nonnegative discrete entropy yield the same lower bound with $h$ replacing the within-sheet average. Sheet diffusion and bounded curvature above by $\Lambda_+ I$ therefore give $h'_{\rm diff}\ge2\pi e d'Te^{-2h/d'}-d'\Lambda_+$. Discrete conditional entropy is concave; its derivative toward a proposal update is at least $-\log|\mathcal J|$. Thus

\[
h'\ge2\pi e d'Te^{-2h/d'}-d'\Lambda_+-\log|\mathcal J|.
\tag{R22}
\]

This gives the lower floor equal to the minimum of the initial entropy and
$\frac{d'}2\log[2\pi e d'T/(d'\Lambda_++\log|\mathcal J|)]$.
If a $k$-dimensional block $Z$ is discarded, conditional entropy is at most its Gaussian maximum-entropy bound, so
$h(Y,J)\ge h(X,J)-\frac k2\log(2\pi e E|Z|^2/k)$.
The maximum-entropy bound follows directly from nonnegativity of KL to the Gaussian with the corresponding second moment. Here $\Lambda_+\le C_LJ_1$, the dimension is fixed, and all scales in R1 are powers. Iterating these bounds makes their logarithmic costs $O_L(\ell)$.

Expanding the exact normalized parent density against its common Gaussian and bounded tilt, using R18 and the fixed positive model prior masses, now gives at every actual activation

\[
\mathcal H_p:=T D(q_p\Vert\Pi_a^p)
\le C_L[A^2J_{p+1}+T\ell^2].
\tag{R23}
\]

This is an estimate on the full projected actual law, including correlations and changed source masses. It is not a replacement by a sheet equilibrium or a Gaussian ansatz. Its common-center moment input was checked in R2 and R18.

The normalized parameter score has the form $T\partial_a\log\Pi_a=E_\Pi V-V+T(w-E_\Pi w)$, where $V$ is the nonnegative quadratic energy and $w=\partial_a\log\pi_j-\partial_a\psi_{p,j}$ is bounded. Gaussian exponential moments and bounded tilt imply $E_\Pi e^{aV/(2T)}\le e^{B_0}2^{d'/2}$. The entropy variational inequality follows by writing $D(q\Vert e^f\Pi/E_\Pi e^f)\ge0$; applying it here bounds the score expectation by $2\mathcal H_p/a+C_LT$. Full diffusion and reversible jump entropy dissipation, followed by the integrating factor for $\int|\dot a|/a=O_L(1)$, give

\[
T^2\int\mathcal I_{\rm full}(t)dt\le C_L(\mathcal H_{\rm activation}+T).
\tag{R24}
\]

Actual projection decreases full relative entropy by its exact conditional KL. Thus R24 remains valid across the finite sequence of activations.

For the conditional balance, $\mathcal I_Y$ means the $Y$-component of the full relative Fisher information, not the marginal Fisher information. The hidden logarithmic-Sobolev estimate is $\widehat\Delta\le T\mathcal I_Z/(2\lambda_s)$. Conditional differentiation produces the mixed covariance term, controlled by $\Gamma_s$, and the centered hidden parameter score. The latter is a Gaussian centered quadratic plus a bounded-tilt derivative and has a uniform subgamma bound
$\log E e^{uS}\le v_0u^2/[2(1-b_0|u|)]$.
This follows by expanding Gaussian quadratic exponential moments and using the bounded density ratio; centering only enlarges constants depending on the finite dimension. Conditional entropy duality therefore gives $|E_qS|\le\sqrt{2v_0\widehat\Delta}+b_0\widehat\Delta$. Young's inequality, $b_0|\dot a|\le\lambda_s/2$, and R21 give

\[
\widehat\Delta'\le-\frac{\lambda_s}{2}\widehat\Delta
+\frac{T\Gamma_s^2}{\lambda_s^2}\mathcal I_Y
+\frac{C_L\dot a^2}{\lambda_s}+C_J.
\tag{R25}
\]

The diffusion calculation keeps the negative conditional variance of the retained relative score before applying Young's inequality; dropping it prematurely would not give R25. This is the explicit balance in [F26–F28](finite-rate-conditional-entropy.md), with R12 and the mixed estimate above supplying its hypotheses. Using R23–R24 to integrate R25 gives

\[
\widehat\Delta(t)\le C_L\left[
e^{-c_LJ_s(t-\tau_{s-1})}(\epsilon^{-6}J_s+\ell^2)
+\epsilon^{-6}\frac{J_{s+1}^2}{J_s}
+\ell^2\frac{J_{s+1}^2}{J_s^2}
+\frac{\epsilon^2}{J_s^2}+\frac{C_J}{J_s}\right].
\tag{R26}
\]

At the last interface the two mixed terms vanish, but the jump term remains. For the exact true channel, differentiating $\mathcal F(q,a)-\mathcal F^s(C_sq,a)=T\Delta_{\rm discarded}$ at fixed $q$ and fixed channel leaves precisely the centered hidden model score. Prior source terms cancel because $J$ is retained; they were included before cancellation. Hence

\[
|g(q,a)-g_s(C_sq,a)|\le T[\sqrt{2v_0\Delta_{\rm discarded}}+b_0\Delta_{\rm discarded}].
\tag{R27}
\]

R1 has $J_{s+1}^2/J_s=\epsilon^{20}$. Choosing an entrance wait $\kappa_L\log(1/\epsilon)/J_s$ with $c_L\kappa_L>Q_1+14$ makes the initial term $O_L(\epsilon^8)$. The remaining terms have orders $\epsilon^{14}$, at most $\ell^2\epsilon^{56}$, at most $\epsilon^{18}$ and at most $C_J\epsilon^8$. Therefore R26–R27 give the claimed $O_L(\epsilon^8)$ conditional KL and $O_L(T\epsilon^4)$ complete same-state score bounds. They do not yet compare independently evolving laws.

## 5. Actual successive formation and positive changes: c4 and c5

The geometric source's strict-margin vector can be reconstructed by avoiding finitely many nonzero residual hyperplanes. Independence of the formation rows ensures every future bridge row remains nonzero on the relevant retained normal subspace. A polynomial curve through that subspace is not identically in any of these hyperplanes, so avoiding its finitely many roots gives a vector $v_0$ with a positive minimum margin. A sufficiently small fixed neighborhood preserves the margin. This establishes existence of the preparation without assuming the subsequent formation.

In the linear comparison, variation of constants for the current normal block and integration of the future rows give

\[
|E u_t|\le C_LA[e^{-c_LJ_s(t-\tau_{s-1})}+J_{s+1}/J_s],\qquad
|E P_sX_G(t)-AP_sv_0|\le C_LAJ_{s+1}t.
\tag{R28}
\]

Earlier projections leave the latter retained coordinate unchanged. Itô's formula and stopping for $\exp(c|X_G-EX_G|^2/(4T))$, with $c$ below the uniform precision lower bound, give

\[
\Pr\{\sup_{t\le H_*}|X_G-EX_G|>\rho A\}
\le C_L(1+H_*)e^{-c_L\rho^2A^2/T}.
\tag{R29}
\]

The generator is bounded above by a constant: its negative quadratic drift dominates its quadratic diffusion term outside a fixed $\sqrt T$ ball. Orthogonal projections contract this Lyapunov function. Large $J_1$ does not enter its upper bound. R16 adds $O_L(\sqrt{TH_*}/A)=O_L(\epsilon^{5/2})$ to the scaled actual path error, uniformly in the assignment path.

Choose $k_L\ge2\kappa_L$, also sufficiently large for R28, and set $t_s=k_L\log(1/\epsilon)/J_s$, $I_s=[t_s,2t_s]$, $\tau_s=2t_s$. Since $J_s/J_{s+1}\to\infty$, the windows are disjoint and $t_s-\tau_{s-1}\ge t_s/2$. Thus the conditional entrance wait is satisfied throughout each formation window. On $I_s$, formed residuals are smaller than a fixed small multiple of $A$ while future bridges remain greater than a fixed positive multiple of $A$. These are actual residual conditions outside the probability in R29; final coherence persists through $H_*$. The number of agents is $3\cdot2^{L-1}\to2^{L-1}\to\cdots\to1$.

For $L=2$ there are two triangles and one bridge: $n=6,E=7,d=19$. The first formation rows have rank ten and the next bridge contributes rank one, giving $19\to9\to8$ continuous coordinates and $6\to2\to1$ agents. Both triangle loops and all $2^6=64$ assignments survive. R1 becomes $J_1=\epsilon^{-36},J_2=\epsilon^{-8},A=\epsilon^{64},T=\epsilon^{134}$.

The distinguished actual source mass obeys $\dot\lambda_+=E_qb_{i,+}-\lambda_+$. Its posterior proposal log odds lie in $[4(a-3/2)-\delta,4(a-3/2)+\delta]$. R20 therefore implies

\[
\lambda_+(H_*)-\lambda_+(0)
\ge(1-e^{-10})\operatorname{sigmoid}(1-\delta)-\operatorname{sigmoid}(-2)-10^{-2}>\frac12.
\tag{R30}
\]

For a rational certificate before the preparation tolerance, $e^{1-\delta}>2.49$, $e^2>7$ and $e^{10}>2^{10}$ imply the lower bound $(1023/1024)(249/349)-1/8>0.587$. The margin over $1/2$ is $31367/357376$. Averaging a proposal row inside R8 preserves the same pointwise envelope; actual projection leaves label masses unchanged. Measuring a parent's change from its own activation costs at most $\tau_L=o(1)$ because $|\dot\lambda_+|\le1$. Thus the bound also survives that stronger interpretation for sufficiently small $\epsilon$. This is movement of the actual binary recognition marginal, not only movement of a model-posterior row.

For the first hidden physical or optimizing conditional, the final Gaussian precision is at least $5/4$ times its initial precision. For the optimizer it scales with $a$; for the physical law $D_1=H-TR\preceq H$ and $D_f=D_1+(a_f-1)H\succeq a_fD_1$, with $D_1\succ0$. Restriction to a conditional block preserves this order, and Schur marginalization preserves it by the quadratic minimum formula when needed. Gaussian affinity, allowing arbitrary means, is at most $[2\sqrt r/(1+r)]^{k/2}$ when the precision ratio is at least $r\ge1$. To see the covariance part, conjugate one precision to identity, diagonalize the other and bound each eigenvalue factor by its decreasing value at $r$; the mean term is at most one. Each conditional success tilt has density ratio at most $e^{B_0}$ relative to its Gaussian conditional, including after exact previous marginalization. Therefore affinity grows by at most $e^{B_0}$, and Jensen's inequality gives

\[
D(k_1\Vert k_f)\ge-2\log\operatorname{Aff}(k_1,k_f)
\ge\frac k2\log(81/80)-2B_0>\frac1{200}.
\tag{R31}
\]

For $k\ge1$, $\log(81/80)\ge1/81$ makes the final strict comparison elementary. The bound is uniform in the retained input and label. A selected nonzero internal residual also has expansion $\delta(A_jh^2/2-A_j^2h^4/8+O(h^6))$ in standardized coordinates. Its negative fourth-order coefficient proves a non-Gaussian hidden conditional on every sheet in a suitable first-hidden direction. Neither $\delta$ nor source mobility vanishes in R1.

## 6. Complete assignment-history comparison: c6

This part cannot be obtained from a one-time generator comparison. Remove only the decoupled root from the proof notation and let $\mu^0_{a,j}$ be the normalized nonroot sheet density proportional to $e^{-ax^THx/(2T)-\phi_j}$. Put $\mu^p_{a,j}=P_{p\#}\mu^0_{a,j}$. Define an auxiliary row

\[
\mathsf B_{jk}(a)=E_{\mu^0_{a,j}}b_k(X,a)
=E_{\mu^p_{a,j}}R^p_{jk}(Y,a).
\tag{R32}
\]

The equality follows from the exact tower, so this row is common to every actual level. This auxiliary average includes all nonroot coordinates, including loops. The actual parent does not discard those coordinates. The row is uniformly Lipschitz in $a$: the derivative of $b$ has summed absolute value at most eight, and the sheet density score is the centered quadratic $E F-F$, $F=x^THx/(2T)$, whose absolute moments are bounded by Gaussian moments and the fixed tilt. Thus $\sum_k|\partial_a\mathsf B_{jk}|\le C_L$ without a $J$ or $T$ prefactor.

Set $\Lambda=J_L$. Every fixed-sheet parent potential is even, has gradient zero at zero, and satisfies $D^2V\succeq c_L\Lambda I$. Its equilibrium second moment is at most $C_LT/\Lambda$. The following transition estimate is needed from a point, including a point supplied by a common actual activation:

\[
\|P^{p,j,a}_{s,t}(x,\cdot)-\mu^p_{a(t),j}\|_{\rm TV}
\le C_L(1+\sqrt{\Lambda/T}|x|)e^{-c_L\Lambda(t-s)}
+C_L\epsilon/\Lambda,
\quad t-s\ge(c_L\Lambda)^{-1}.
\tag{R33}
\]

Here the label stays fixed on the interval and $a$ is the actual deterministic path. There is no equilibrium assumption on $x$. To reconstruct the first term, reflect one Brownian increment across the displacement of two copies of the same inhomogeneous sheet SDE, and join them when they meet. Until meeting their distance has radial noise $2\sqrt{2T}$ and drift at most $-\lambda r$, $\lambda=c_L\Lambda$. Multiplying by $e^{\lambda u}$ bounds survival by that of a Brownian motion above $-r_0$ with variance
$4T(e^{2\lambda u}-1)/\lambda$.
The reflection principle bounds that survival probability by $C r_0\sqrt{\lambda/T}e^{-\lambda u}$ for $u\ge1/\lambda$. Integrate the second starting point against $\mu^p_{a(s),j}$ to obtain the first term of R33.

For the moving equilibrium term, the frozen diffusion's gradient contraction is $|\nabla P_tf|\le e^{-\lambda t}P_t|\nabla f|$. For positive bounded regular $f$, Cauchy–Schwarz gives $I(P_tf)\le e^{-2\lambda t}I(f)$. Differentiating entropy and integrating to equilibrium yields $D(q\Vert\mu)\le T I(q\Vert\mu)/(2\lambda)$. The limit at infinity follows first for bounded Lipschitz $f$ from the same contraction and the finite invariant second moment, then by regularization and truncation. This provides the precise logarithmic-Sobolev inequality used here and earlier, with its curvature hypothesis R12.

The sheet parameter score has a uniform local Gaussian quadratic exponential moment. After marginalization it is its conditional expectation, so Jensen preserves that exponential bound. Entropy duality therefore controls its mean under an arbitrary $q$ by $C_L(\sqrt D+D)$. Relative entropy to the moving sheet target obeys $D'\le-\lambda D+C_L\epsilon^2/\lambda$ once $\lambda\gg\epsilon$. Starting in $\mu^p_{a(s),j}$ gives $D\le C_L\epsilon^2/\lambda^2$. Pinsker then gives $C_L\epsilon/\Lambda$. For clarity, Pinsker here follows by mapping to the set attaining TV and applying the binary KL inequality: its second derivative in the first probability is $1/[p(1-p)]\ge4$, so binary KL is at least twice the squared probability difference. Combining this moving-target bound with reflection proves R33.

Use a rate-one Poisson proposal grid independent of the initial state and Brownian motion. Conditional on the entire grid, the source outcomes remain adapted. The generator bound
$\mathcal L|x|^2\le2Td'-2c_L\Lambda|x|^2$
holds on every sheet; jumps preserve $|x|$ and actual orthogonal retentions decrease it. Hence, including at grid-selected starting times $\sigma$,

\[
E[|X_\sigma|^2\mid\text{grid}]\le C_L(A^2+T/\Lambda).
\tag{R34}
\]

This estimate uses the actual initial moment and is valid without conditioning on any future continuous retained path. When the common initial information fixes $X_0$, use $|X_0|^2$ in the conditional estimate and integrate that common information afterwards. This avoids imposing a uniform conditional moment bound on every possible actual starting point.

Condition on the grid, common actual activation information, and actual proposal outcomes strictly before the current proposal $t_\ell$. Let $\sigma_\ell$ be the latest preceding proposal, starting time or deterministic activation. Between $\sigma_\ell$ and $t_\ell$ the label and active level are fixed. Apply R33 from the conditional random state at $\sigma_\ell$, then R32 and the Lipschitz parameter bound R20. If this interval has length at least $h$, the actual next-mark kernel differs from $\mathsf B_{j\cdot}(2-e^{-\epsilon t_\ell})$ by at most

\[
C_LE[1+\sqrt{\Lambda/T}|X_{\sigma_\ell}|\mid\text{prefix, grid, initial information}]
e^{-c_L\Lambda h}+C_L\epsilon/\Lambda+C_Lr_\epsilon.
\tag{R35}
\]

For short intervals use the bound one. The conditioning includes previous self proposals but does not condition on the subsequent continuous path. The future Brownian increments on this event-free interval have their ordinary law. This is the filtration distinction required to make the application of R33 valid.

For a finite sequence of proposal outcomes, replace its conditional kernels successively by the comparison kernels. Adjacent hybrid laws have the actual prefix and common comparison tail. A common stochastic tail contracts TV, so the total TV is at most the sum of kernel TV errors averaged over actual prefixes. Thus these prefix expectations remove the conditional expectation in R35 exactly; no history-probability denominator appears. The expected number of close ordered Poisson pairs is at most $H_*h$, since
$\int_0^{H_*}\int_{\max(0,t-h)}^t ds dt\le H_*h$.
Each fixed activation or start contributes at most another $h$. R34 and $E N=H_*$ therefore give

\[
\|\mathcal L(\text{grid, marks})-\mathcal L(\text{grid, comparison marks})\|_{\rm TV}
\le C_L\left[(H_*+L+1)h
+H_*(1+A\sqrt{\Lambda/T})e^{-c_L\Lambda h}
+H_*\epsilon/\Lambda+H_*r_\epsilon\right].
\tag{R36}
\]

This is the complete finite-history estimate, not the product of one-time marginal estimates. The Poisson count is finite almost surely and has finite expectation, justifying summation and integration over the grid.

In R1, $\Lambda=\epsilon^{-8}$ and $A\sqrt{\Lambda/T}=\epsilon^{-7}$. Choose $h=k\epsilon^8\log(1/\epsilon)$ with $c_Lk\ge16$. The terms in R36 have orders $\epsilon^7\log(1/\epsilon)$, $\epsilon^8$, $\epsilon^8$ and $r_\epsilon/\epsilon$, respectively. Moreover

\[
\frac{r_\epsilon}{\epsilon}
=O_L(\epsilon^{2Q_1+19}+\epsilon^{3Q_1+25}\ell^2).
\tag{R37}
\]

Conditional maximal coupling of the finite mark sequences, measurable in the grid and common initial information, therefore gives the claimed vanishing disagreement for their entire step-function assignment paths. Fine and parent histories can be joined through the same comparison chain, with their common actual activation state and assignment preserved. Integrating over that initial information and adding finitely many interface bounds proves the lineage statement. Self proposals and the grid may then be forgotten; doing so cannot increase disagreement.

This is an existence coupling and need not be causal. Conditional on the coupled histories and common initial information, regular conditional continuous path laws recover each full process marginal. The spaces are Euclidean continuous-path spaces and finite-assignment càdlàg-path spaces, so this disintegration is available. The next section checks continuous closeness under that coupling separately; it does not assume conditional-on-future-marks Brownian increments remain independent.

## 7. Independent continuous paths and compatibility: c7

For a fine/parent interface, compare each nonlinear process with its linear reference using its own actual deterministic parameter. R16 bounds the scaled nonlinear errors by $C_L\epsilon^{5/2}$, uniformly over assignment histories. The deterministic linear retained fine and exact Schur-parent centers differ by

\[
C_LA[J_{s+1}/J_s+H_*J_{s+1}^2/J_s].
\tag{R38}
\]

Variation of constants gives the first term from the current hidden transient and the second from its quasi-static feedback into the retained block. The terminal interface has no such future block. Actual initialization is projected, not equilibrated. Different independently learned parameters add at most $C_LA\sup|a-\bar a|$: on each eigenmode the response is bounded using $\lambda t e^{-a_{\min}\lambda t}\le1/(e a_{\min})$, which avoids an erroneous $J_1H_*$ factor. R20 supplies the needed $O_L(r_\epsilon)$ parameter discrepancy, including preceding activations.

Use R29 with $\rho=\epsilon^2$. Each marginal reference fluctuation is then at most $A\epsilon^2$ outside probability $C_L(1+H_*)e^{-c_L/\epsilon^2}$. R1 gives $H_*J_{s+1}^2/J_s=2\epsilon^{19}$, $J_{s+1}/J_s=o(\epsilon^2)$ and $r_\epsilon=o(\epsilon^2)$. Consequently each interface has uniform continuous-path error $O_L(A\epsilon^2)$, with the stated exceptional probability. A fixed finite number of interfaces changes only the constants. The root factors are independent and identical and can be coupled identically.

Compatibility with the history coupling does not require a common Brownian motion conditioned on the entire source history. Augment each correct marginal process with its own linear reference, as in R16. Its marginal concentration event in R29 has the same probability under every coupling of the two processes. Both reference centers are deterministic and obey R38; a union bound on the two marginal concentration events therefore supplies continuous closeness under the already constructed common-history coupling. The common activation information is preserved by that coupling. This checks the join between c6 and c7 without replacing either actual parent law or its feedback.

## 8. Skeptical checks, scope and final coverage

Several tempting shortcuts fail, and none is needed above. First, the inherited rate cannot be replaced by a regenerated coarse heat bath; the explicit $3/8$ versus $1/2$ calculation after R9 demonstrates the defect. Second, full VFE descent does not imply conditional KL descent. For the same two-hidden-state target, take actual sheet masses $(3/4,1/4)$ and optimizing hidden conditionals $k_+=(1/4,3/4)$, $k_-=(3/4,1/4)$. The joint columns are $(3/16,9/16)$ and $(3/16,1/16)$. Their heat-bath derivatives are $(-3/32,-3/32)$ and $(3/32,3/32)$; quotient differentiation gives hidden-conditional derivatives $(-1/16,1/16)$ and $(-3/16,3/16)$. Thus conditional KL, initially zero, is $t^2/32+O(t^3)>0$. R21 explicitly pays for this possibility. These finite examples disprove the shortcuts, not the admitted smooth existence theorem.

Third, retaining loops while proving hidden relaxation cannot be accomplished by silently discarding them from the real parent. The auxiliary conditional chain rule before R21 and the separate all-nonroot average R32 leave all actual loop coordinates intact. Fourth, ordinary parameter-speed or equilibrium hypotheses would be circular if imported into continuation. R15–R20 close continuation from stopped actual moments before they are used in R24–R36. Fifth, a one-time generator estimate cannot identify kernels conditioned on full source histories. R33–R36 prove the needed history statement from points on event-free intervals, with the precise conditioning stated. Sixth, arbitrary fixed sheet-dependent order-$A$ centers would invalidate the covariance preparation used in R23; R2 uses a common center and only much smaller sheet-dependent perturbations.

The oracle-erasure check starts with no affirmative search prior: the frozen contract's `search_priors` is empty. Removing favorable expectations, proposed equilibrium resets, reviewer verdicts and borrowed coefficient schedules leaves a complete chain: positive normalized model and exact source-conditioned parent rates; local law-dependent existence; stopped moments and inward parameter continuation; actual activation entropy; conditional coercivity with a jump source term; residual-margin formation; pointwise sheet mixing and proposal-history kernel telescoping; and continuous marginal concentration. These are declared admissions followed by displayed bounds for c1–c7 and their target join. Every learning coefficient in that chain is computed from the actual process law, except the explicitly identified reference functions used only for estimates. The analytical tools have their hypotheses matched above: global smooth bounded Hessians and positive temperature for the diffusions; finite positive bounded-rate sources for interlacing; Gaussian domination for derivatives and moments; positive curvature for contraction and log-Sobolev bounds; and Euclidean/finite standard Borel carriers for disintegration. Localization with the proved polynomial moments, bounded initial density perturbations and entropy floors justifies the integration-by-parts limits. There are no boundary currents at a finite boundary because the carrier is global Euclidean space.

The record contains c1–c7 and `target`, not a separate c8. R3–R9 reconstruct c1; R10–R20 reconstruct c2; R21–R27 reconstruct c3; R28–R29 and their timing join reconstruct c4; R30–R31 reconstruct c5; R32–R37 reconstruct c6; and R38 with the compatible concentration argument reconstructs c7. R1 and the explicit finite-depth and two-level constructions join those seven claims to the frozen target. This is a mathematical reconstruction result. The existing ledger's validator and designated closure procedure remain responsible for its machine-readable states; this report does not infer mathematical closure from their output.

The strongest supported result is the finite-family existence theorem stated in Section 1, for the accelerated-energy admission R1 and the declared preparation. There is no unresolved mathematical interface left in that scoped join. The original fixed weakest energy $J_L=1$ with source rate one remains unresolved. R26 then leaves an order-one terminal upper-bound term, and R36 cannot both make $H_*h$ vanish and suppress its initial-state mixing term. Those are failures of these estimates, not lower bounds on actual error and not a nonexistence theorem. A materially different next result would require conditional-history mixing for the source-relevant fast subsystem in a slowly varying retained environment, together with a terminal conditional estimate at $J_L=1$.

The accelerated formation interval ends at $O_L(\epsilon^8\log(1/\epsilon))$. A source proposal before then has probability at most that duration, whereas the order-one recognition change occurs later on $2/\epsilon$. Thus the result does not say source switching causes the supplied formation hierarchy or that formation occupies a fixed fraction of the learning horizon. It also makes no claim of computational savings, arbitrary deformation size, arbitrary initial laws, full noncompact Haar invariance, base transport or physical-clock derivation.

## 9. Evidence and revision binding

The source-first context for this continuation is the live `PIFB2.tex` mixture derivation, the source-posterior/correlated-recognition/replicator distinctions in `Theory/05b_local_collective_elbo.tex`, and the linked prior normalized and finite-rate investigations. Their exposition is context rather than authority for a mathematical step. The exact source components used in the proof are recorded below. The former collapsed and zero-label-mobility theorems keep their original scopes; only their normalized model and checked uniform geometric interfaces are reused here.

No numerical trajectory, Monte Carlo experiment, GPU computation, training run, test suite, Lean proof or prohibited tamper check was run for this reconstruction. The new evidence is the displayed derivation. A final read-only standard-library calculation recomputes the frozen target digest and records the SHA-256 of each source below. Those hashes bind the reviewed bytes; they do not prove the mathematics. The command output is summarized here so no separate unassigned artifact is created.

The read-only calculation ran with `C:/Python314/python.exe`, using only `hashlib`, `json`, `pathlib`, `re` and `sys`. Canonical serialization of the contract's `target` object with sorted keys, compact separators and UTF-8 reproduced the digest at the beginning of this report. The complete contract file SHA-256 was `f8a9d37a180a6c75ae5532eceb44e9069e4d603db87e6fd44a4465dc03665db1`. The document check found R1–R38 each once and in order, balanced display delimiters, no prohibited LaTeX spacing commands, and resolving local Markdown links. These are document checks, not scientific tests.

| Reviewed source | SHA-256 |
| :--- | :--- |
| [Normalized marked model](nonlinear-endpoint-attention-model.md) | `725539e6e47d36bc27e54c42ea98602fbbe78a9f96f8aef1c833a0fd3c6e1f1e` |
| [Finite-rate source identities](finite-rate-source-dynamics-investigation.md) | `9786ac9b8c60d60c81b1a81c22351aa52ebb6016da7d3fc5ea721f4a62e472bd` |
| [Separate rate reconstruction](finite-rate-source-dynamics-check.md) | `9730378f91ce8e89e78bf31ae9f1a979fc546d3ac74a1eca7aae515eb20f6a95` |
| [Cyclic geometry and uniform sheet interfaces](nonlinear-cyclic-formation-route.md) | `484f7fe08bbd3e0ecda3f03d386dc211f48ae9698cffd6d1bff52be77b47748b` |
| [Conditional geometric interfaces](nonlinear-adaptive-conditional-route.md) | `ebe3e146bab715bdeaa205c091461f4610e0d110effca0820f0d29f06ce65881` |
| [Coupled continuation and formation](finite-rate-coupled-formation.md) | `dc6c8845bba1f7ff131f8fc03c78473963570c9fb8eea32746119034bbca3db5` |
| [Moving-label conditional entropy](finite-rate-conditional-entropy.md) | `8c3cd74e41b38608017678a79c633070be23961aed87ee28a20a13d515968d4f` |
| [Complete assignment-history averaging](finite-rate-source-history-averaging.md) | `f55fc6981ca98ab374029d76f5ec7f56568bd8ebadee6013fd3a557cb64631b2` |
| [Joined finite-rate completion](finite-rate-adaptive-completion.md) | `cb78cf5aaaface0e3f6b6ffc771e8893400586fe7fe00008deab7f15ae633f68` |

These bindings apply to the current source bytes, including D1's common-center preparation, the conditional entrance-time join, the pointwise mixing argument, and the explicit accelerated-family scope. A later mathematical source change requires checking its affected dependency; a matching hash by itself would still supply no mathematical proof.
