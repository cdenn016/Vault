<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-c574ab277c6be97d9c483ffcc4a76b87fc074d03d184a731b8a4973a7944f952","target_digest":"c574ab277c6be97d9c483ffcc4a76b87fc074d03d184a731b8a4973a7944f952"} -->
# Actual conditional entropy with weakest energy fixed at one

September 13, 2026. This component proves a joint diffusion-plus-jump entropy contraction and uses it to remove the terminal conditional-entropy plateau in the previous estimate. It is bound to the [frozen weakest-one contract](evidence/2026-09-13-fixed-weakest-energy-adaptive-cyclic-rg/problem-contract.json). No earlier proof artifact, physical model, kinetic multiplier, or source likelihood is changed.

## 1. Exact target and source continuity

For every prescribed finite $L\ge2$, the target fixes

\[
Q_L=0,\qquad Q_s=2Q_{s+1}+20,\qquad
J_s=\epsilon^{-Q_s},\qquad
A^2=\epsilon^{3Q_1+20},\qquad
T=A^2\epsilon^6,\qquad H_*=2/\epsilon.
\tag{C1}
\]

Thus $J_L=1$ for all $\epsilon$, the microscopic full-assignment proposal rate is one, and the standardized nonlinear coefficient $\delta=B_0/n>0$ is fixed at each finite depth. The full contract additionally requires actual formation, own-law model learning, source and hidden-kernel movement, retained continuous-path comparison, and entire source-history comparison. This component addresses actual activation, discarded-conditional KL, and the complete same-state model covector. It returns quantitative hypotheses for the other components rather than replacing their path-law or formation obligations by an entropy statement.

The source entry point was [STATUS](../../STATUS.md), its current result and next gate. The first two September 13 sections of the live [vault synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>) distinguish the positive-rate accelerated result from the preceding fixed-label result. Live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:mixture_derivation`, explicitly identifies its source-independent recognition restriction. [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), `prop:obs-attention-elbo`, `eq:obs-attention-correlated-ledger`, and `eq:obs-attention-replicator`, separately defines posterior rows, constrained recognition rows, conditional total correlation, and a particular row flow. Those restrictions are not imposed on the actual marked law here.

The normalized model remains [E24–E29](nonlinear-endpoint-attention-model.md). The actual source and parent generators remain [S2 and S9–S11](finite-rate-source-dynamics-investigation.md). The [preceding conditional proof](finite-rate-conditional-entropy.md), F1–F35, supplies explicit sheet geometry, score tails, moment estimates, and actual activation formulas. Their dependence on the weakest energy is checked below. The preceding full-history theorem is not imported into this regime.

At one fixed base point $c_*$, the active non-root carrier at level $p$ is $M_p\times\mathcal J$, where $M_p\simeq\mathbb R^{d_p}$ is the retained normal-plus-loop space and $\mathcal J$ is the full finite assignment set. Measures are Lebesgue times counting measure. Every true retention keeps all loops and all assignments. The compatible independent root factor is common to the processes and to their optimizer and may be appended unchanged. No base transport or physical-time identification is introduced.

For fixed positive $\epsilon$, the active process is the continuous Euclidean diffusion with Brownian covariance $2T I dt$, interlaced with a rate-one Poisson proposal clock. Its conservative jump generator has entries $K^p_{jk}=R^p_{jk}$ for $j\ne k$, diagonal $K^p_{jj}=R^p_{jj}-1$, and

\[
\begin{split}
U_{p,a,j}(x)&=\frac a2x^TH_px+T\phi_{p,a,j}(x),\\
R^p_{jk}(x,a)&=E_{\Pi_a}[b_k(X,a)\mid P_pX=x,J=j],\\
\mathcal L^p_af(x,j)&=T\Delta f-\nabla U_{p,a,j}\cdot\nabla f
+\sum_kR^p_{jk}(x,a)[f(x,k)-f(x,j)].
\end{split}
\tag{C2}
\]

The proposals include self proposals; no continuous coordinate is refreshed. These are the exact inherited rates, not a regenerated parent heat bath. The normalized optimizer is

\[
p^p_a(x,j)=\frac{e^{-\phi_{p,a,j}(x)}}{Z_p(a)}\rho^p_a(x,j),
\qquad
\rho^p_a(x,j)=G^p_a(x)\pi_j(a),
\qquad
G^p_a=N\bigl(0,(T/a)H_p^{-1}\bigr),
\quad 0\le\phi_{p,a,j}\le B_0.
\tag{C3}
\]

The prior, physical posterior, and restricted-VFE optimizer remain distinct. C3 is the optimizer used in the relative entropy below; the same full restricted-objective scalar is retained in each parent's model covector.

Until the own-law continuation is joined, work on an interval where each process's deterministic exact-law coefficient satisfies

\[
1\le a(t)\le2.1,\qquad |\dot a(t)|\le C_a\epsilon.
\tag{C4}
\]

The constants may depend on finite $L$ and the fixed source admission. These are explicit continuation interfaces, not a prescribed replacement for the own-law learner. The construction uses smooth positive joint initial densities in the common-center and small sheet-dependent transport class of the contract, with finite entropy and Gaussian tails. The actual later laws and all activation laws may have unrestricted label/configuration dependence. No positive lower bound on their label masses is assumed.

The companion [weakest-one continuation proof](fixed-weakest-energy-continuation.md), equation W7 in that file, establishes the bounds in the present C4 from actual moments and the full own-law model covector before using conditional entropy or source-history averaging. That is the continuation input to this component; the entropy estimates below do not feed back into its proof.

## 2. A uniform joint entropy inequality

Let $h_p=\lambda_{\min}(H_p)$. The finite weighted-flag coercivity gives $H\succeq h_LI$ on the initial non-root space with $h_L>0$ independent of $\epsilon$, since every $J_s\ge J_L=1$. Exact Gaussian Schur complementation preserves this lower bound: for a retained vector $y$,
$y^TH_py=\inf_z(y,z)^TH(y,z)\ge h_L|y|^2$.
Thus $h_p\ge h_L$ for every active level, without increasing $J_L$.

Since $e^{-B_0}\le Z_p(a)\le1$, and each microscopic source row has $b_k\ge e^{-B_0}\pi_k(a)$, C3 and exact conditional expectation imply

\[
e^{-B_0}\le\frac{p^p_a}{\rho^p_a}\le e^{B_0},
\qquad R^p_{jk}(x,a)\ge e^{-B_0}\pi_k(a),
\qquad
p^p_a(x,j)R^p_{jk}(x,a)
\ge e^{-2B_0}G^p_a(x)\pi_j(a)\pi_k(a).
\tag{C5}
\]

The rows in C5 need not be independent of $x$ or $j$. Their detailed balance with $p^p_a$ is S10. The lower bound follows from a property of the model's proposal rows and survives every exact inherited-rate conditional expectation. It does not bound any actual recognition mass.

For a probability measure $\mu$ and nonnegative integrable $u$, define
$\operatorname{Ent}_\mu(u)=E_\mu[u\log u]-(E_\mu u)\log(E_\mu u)$.
For $q\ll p=p^p_a$, put $u=q/p$ and

\[
\begin{split}
\mathcal E(q,a)&=D(q\Vert p)=\operatorname{Ent}_p(u),\\
I_p(u)&=\sum_j\int p(x,j)\frac{|\nabla u_j(x)|^2}{u_j(x)}dx,\\
\mathcal D_p(u)&=\frac12\int\sum_{j,k}p(x,j)R^p_{jk}(x,a)
(u_j-u_k)(\log u_j-\log u_k)dx.
\end{split}
\tag{C6}
\]

Terms at zero are defined by their nonnegative extended limits. In the constructed positive smooth laws, the usual values apply.

**Lemma 1 (joint entropy coercivity).** For every active $p$, every $a\in[1,2.1]$, every positive $T$, and every normalized $q$ for which C6 is defined,

\[
\mathcal E(q,a)
\le e^{2B_0}\frac{T}{2ah_p}I_p(u)
+e^{3B_0}\mathcal D_p(u).
\tag{C7}
\]

In particular,

\[
T I_p(u)+\mathcal D_p(u)\ge c_*\mathcal E(q,a),
\qquad
c_*:=\min\{2h_Le^{-2B_0},e^{-3B_0}\}>0,
\tag{C8}
\]

uniformly over C1 and every active level. The constant does not use a lower bound on an actual label mass or even a numerical minimum of the model prior entries.

*Proof.* The elementary representation

\[
\operatorname{Ent}_\mu(u)
=\inf_{r>0}E_\mu\left[u\log\frac ur-u+r\right]
\tag{C9}
\]

has a pointwise nonnegative integrand. Consequently, if $d\mu/d\eta\le C$, then $\operatorname{Ent}_\mu(u)\le C\operatorname{Ent}_\eta(u)$. Apply this to C5 to obtain $\operatorname{Ent}_p(u)\le e^{B_0}\operatorname{Ent}_{G\otimes\pi}(u)$.

For the product reference, the entropy chain rule is

\[
\operatorname{Ent}_{G\otimes\pi}(u)
=\sum_j\pi_j\operatorname{Ent}_G(u_j)
+\operatorname{Ent}_\pi(E_Gu).
\tag{C10}
\]

The finite-dimensional entropy $\operatorname{Ent}_\pi$ is convex by the log-sum inequality, so its second term is at most $E_G\operatorname{Ent}_\pi(u(x,\cdot))$. The Gaussian logarithmic-Sobolev inequality in precisely the required form is
$\operatorname{Ent}_G(v)\le[T/(2ah_p)]E_G(|\nabla v|^2/v)$.
It follows from the normalized-density version by dividing $v$ by its integral. The Gaussian covariance is $(T/a)H_p^{-1}$, so its largest variance is $T/(ah_p)$; this checks its constant. The normalized-density theorem and curvature proof are in [Gentil, Remark 3.2 and Theorem 3.3](https://arxiv.org/pdf/1009.3421), with Gaussian potential $a x^TH_px/(2T)$. No convexity of the actual density $q$ is required.

For any positive finite vector $v$, write $\bar v=\sum_j\pi_jv_j$. Direct expansion gives

\[
\begin{split}
\frac12\sum_{j,k}\pi_j\pi_k(v_j-v_k)(\log v_j-\log v_k)
&=\sum_j\pi_jv_j\log v_j-\bar v\sum_j\pi_j\log v_j\\
&\ge\sum_j\pi_jv_j\log v_j-\bar v\log\bar v
=\operatorname{Ent}_\pi(v).
\end{split}
\tag{C11}
\]

The inequality is concavity of the logarithm. Substitute the Gaussian and categorical inequalities into C10. For the continuous term use $\rho\le e^{B_0}p$, and for the nonnegative categorical integrand use the conductance comparison in C5. After the initial factor $e^{B_0}$ from C9, the resulting constants are $e^{2B_0}T/(2ah_p)$ and $e^{3B_0}$, proving C7. C8 follows because $a\ge1$ and $h_p\ge h_L$. Truncation and positive approximation extend the statement when a dissipation term is infinite. QED.

This proof distinguishes two mechanisms. Diffusion controls continuous variation within a sheet. The positive inherited rates control entropy carried by differences between sheets. Their combination controls the entire joint law even though a jump alone can increase discarded-conditional KL.

## 3. Uniform full-score tails and a moving target

The normalized parameter score in C3 is

\[
\xi_{p,a}(x,j)=\partial_a\log p^p_a(x,j)
=r_{p,a}(x,j)-E_{p_a^p}r_{p,a},
\qquad
r_{p,a}=-\frac{x^TH_px}{2T}
+\partial_a\log\pi_j(a)-\partial_a\phi_{p,a,j}(x).
\tag{C12}
\]

In particular, every Gaussian determinant, nonlinear marginal normalizer, and categorical prior derivative in the normalized score has been included. Exact Gaussian hidden means are independent of $a$. The N26 calculation, or differentiation of their centered Gaussian scale score directly, gives

\[
|\partial_a\phi_{p,a,j}|
\le(e^{B_0}-1)\frac{\sqrt{d_0}}{\sqrt2 a_-},
\qquad |\partial_a\log\pi_j(a)|\le4.
\tag{C13}
\]

The first estimate also covers $p=0$, where its left side is zero. Here $d_0$ is the original finite non-root dimension and $a_-=1$.

For completeness, a single pair of score-tail constants can be constructed explicitly. Let $M=4+(e^{B_0}-1)\sqrt{d_0}/(\sqrt2 a_-)$, $C=e^{B_0}2^{d_0/2}$, $K=4/a_-+2M$, $b=2K$, and $v=2(C+1)b^2$. In standardized coordinates $Z=\sqrt{a/T}H_p^{1/2}x$, C5 implies
$E_p|Z|^{2n}\le C4^n n!$.
The inequality $|x+y|^n\le2^{n-1}(|x|^n+|y|^n)$ then gives $E_p|r|^n\le(C+1)n!K^n$, and centering gives $E_p|\xi|^n\le(C+1)n!b^n$. The centered first moment vanishes. Summing the exponential series from $n=2$ proves

\[
\log E_p e^{z\xi_{p,a}}
\le\frac{v z^2}{2(1-b|z|)},\qquad |z|<b^{-1}.
\tag{C14}
\]

All these constants are uniform in stiffness and temperature. They use the whole normalized score, including the varying prior, rather than only a fixed-sheet quadratic score.

The entropy variational inequality applied to either sign of $\xi$ gives

\[
|E_q\xi_{p,a}|\le\sqrt{2v\mathcal E(q,a)}+b\mathcal E(q,a).
\tag{C15}
\]

One can check the coefficient by substituting
$z=\sqrt{2\mathcal E/v}/(1+b\sqrt{2\mathcal E/v})$
in $\mathcal E/z+vz/[2(1-bz)]$.

For the actual generator C2, integration by parts and detailed balance give the exact moving-target identity

\[
\mathcal E'(t)
=-T I_p(u_t)-\mathcal D_p(u_t)
-\dot a(t)E_{q_t}\xi_{p,a(t)}.
\tag{C16}
\]

The calibration scalar is needed by the own-law model equation but is not part of $\mathcal E$ or of this dissipation account. No derivative of an actual label mass is omitted: it is included in the jump term of C16.

Combine C8, C15, and C4. For $\epsilon\le c_*/(4bC_a)$, the linear score term is at most $c_*\mathcal E/4$. Young's inequality bounds $C_a\epsilon\sqrt{2v\mathcal E}$ by $c_*\mathcal E/4+2vC_a^2\epsilon^2/c_*$. Hence

\[
\mathcal E'(t)\le-c\mathcal E(t)+C_2\epsilon^2,
\qquad c=c_*/2,
\qquad C_2=2vC_a^2/c_*.
\tag{C17}
\]

For any active interval starting at $\tau$, this proves

\[
\mathcal E(t)\le e^{-c(t-\tau)}\mathcal E(\tau)
+\frac{C_2}{c}\epsilon^2.
\tag{C18}
\]

For each fixed positive instance, C2 has smooth globally Lipschitz sheet drifts of linear growth, bounded smooth finite-state rates, and nondegenerate diffusion. Poisson interlacing gives a nonexplosive process for a prescribed C4 coefficient. The admitted initial Gaussian-tail class and the bounded nonlinear force give finite exponential moments on finite intervals by the linear-companion representation. Entropy identities may first be written for positive regularizations and compact spatial cutoffs. The same confining moments remove boundary terms, and the nonnegative dissipation plus lower semicontinuity gives C16 in integrated form and C17–C18 after the cutoff limit. The model is on global Euclidean space, so no chart current or reflecting boundary is suppressed. The own-law coefficient's continuation is a separate input, not an assumption derived from an unproved mixing claim.

## 4. Exact activations and the earlier-interface estimate

At an actual retention $C$, both the full law and its target are pushed through the same channel at the same current $a$. Thus

\[
D(C_\#q\Vert C_\#p_a)\le D(q\Vert p_a).
\tag{C19}
\]

All labels and loops are retained in this identity; neither is redrawn. Concatenating C17 through these downward jumps proves C18 on global time with $\tau=0$ for a lineage with finitely many actual activations. A descendant independently evolved from an actual ancestor state inherits the same bound at its start and then obeys C17 with its own coefficient satisfying C4. This uses exact actual activation, not equilibrium initialization.

The initial Gaussian with common normal center $A v_0$, zero loop center, and covariance comparable to $TH_0^{-1}$, together with the specified small sheet-dependent transport perturbations, satisfies

\[
\mathcal E(0)\le C_L\left[\frac{A^2J_1}{T}+\ell^2\right]
=C_L[\epsilon^{-(Q_1+6)}+\ell^2],
\qquad
\ell=1+|\log T|+\log J_1+|\log A|.
\tag{C20}
\]

This follows by expanding the Gaussian log density and using the bounded density tilt. The actual label term is bounded above by $\log(1/\pi_{\min})$, where the fixed finite model prior has $\pi_{\min}>0$ on $[1,2.1]$. It requires no actual-label lower bound. The class is nonempty and allows label/configuration correlation through the perturbations.

For early reductions, global rate $c$ does not make the large normal initial entropy small on the fast formation window. The preceding conditional argument therefore remains necessary there. Its dependence on $J_L$ is as follows. F3, F6–F8, and F7 use bounded tilts and exact Schur geometry, not $J_L\to\infty$. The actual joint entropy floor F12 has $\Lambda\le C_LJ_1$ and a finite $\log|\mathcal J|$ correction. Its projection formula F17 uses actual retained moments. F18–F21 depend on $J_L$ only through a lower spectral bound and $1+\log(J_1/J_L)$; at $J_L=1$ these are still bounded by $C_L\ell$. Thus their actual stage budget is unchanged:

\[
H_p(\tau_p):=T D(q^p_{\tau_p}\Vert p^p_{a_{\tau_p}})
\le C_L[A^2J_{p+1}+T\ell^2],
\tag{C21}
\]

including $p=0$ by C20. This is the varying-mass joint-entropy proof, not the older fixed-label entropy argument. The common-center preparation gives its unconditional moment matrix directly. Positive source jumps preserve the moment comparison because the force bound is uniform over arbitrary adapted label histories and $X$ is continuous at an event.

Consequently F29 applies without alteration. Write $\widehat\Delta_{s-1:s}$ for its auxiliary conditional KL, integrating the current/earlier normal block and loops while conditioning on future normals and the current assignment. The true discarded conditional keeps the loops and obeys $0\le\Delta^{\mathrm{discarded}}\le\widehat\Delta$. For $s<L$,

\[
\begin{split}
\widehat\Delta_{s-1:s}(t)\le C_L\bigg[&
e^{-c_sJ_s(t-\tau_{s-1})}(\epsilon^{-6}J_s+\ell^2)
+\epsilon^{-6}\frac{J_{s+1}^2}{J_s}
+\ell^2\frac{J_{s+1}^2}{J_s^2}\\
&+\frac{\epsilon^2}{J_s^2}
+\frac{\log|\mathcal J|+2B_0}{J_s}\bigg].
\end{split}
\tag{C22}
\]

All terms are evaluated under the actual evolving joint law. The separate positive jump upper bound is retained in C22, where it is harmless because $J_s\ge\epsilon^{-20}$ for every $s<L$.

## 5. One common regime, including the terminal interface

Let $\underline c=\min_{s<L}c_s>0$, and choose a finite $k_L$ satisfying

\[
\frac{\underline c k_L}{2}>Q_1+20,
\qquad ck_L>Q_1+8.
\tag{C23}
\]

Use the formation schedule
$t_s=k_L\log(1/\epsilon)/J_s$ and $\tau_s=2t_s$.
In addition to the finite geometric lower bound $k_{\mathrm{geom},L}$ in the companion formation proof, an explicit sufficient selection is
$k_L>\max\{k_{\mathrm{geom},L},2(Q_1+20)/\underline c,(Q_1+8)/c\}$.
At sufficiently small $\epsilon$, $\tau_{s-1}<t_s/2$ for every $s\ge2$. The first inequality in C23 therefore suppresses the entrance term in C22 uniformly for $t\ge t_s$ until the next activation. The remaining early-interface terms in C22 have orders $\epsilon^{14}$, at most $\ell^2\epsilon^{40}$, at most $\epsilon^{42}$, and at most $C_L\epsilon^{20}$. Hence

\[
\sup_{t\in[t_s,\tau_s]}\Delta^{\mathrm{discarded}}_{s-1:s}(t)
\le\sup_{t\in[t_s,\tau_s]}\widehat\Delta_{s-1:s}(t)
=O_L(\epsilon^{14}),\qquad s<L.
\tag{C24}
\]

If that active process is continued instead of replaced, C22 gives the same bound thereafter while its C4 hypothesis holds.

At $s=L$, the terminal window begins at $t_L=k_L\log(1/\epsilon)$, rather than at a time tending to zero. C18–C20 and the second inequality in C23 give

\[
\sup_{t_L\le t\le H_*}\mathcal E(t)=O_L(\epsilon^2)
\tag{C25}
\]

for the active lineage and for each independently continued ancestor or descendant with actual activation and C4. At the terminal interface, the auxiliary hidden block is the full non-root continuous space. Its conditional entropy given the actual current assignment is bounded by the full joint entropy through the KL chain rule. The true discarded normal conditional is smaller still because loops remain retained. Therefore

\[
\sup_{t\in[t_L,\tau_L]}\Delta^{\mathrm{discarded}}_{L-1:L}(t)
\le\sup_{t\in[t_L,\tau_L]}\widehat\Delta_{L-1:L}(t)
\le\sup_{t\in[t_L,\tau_L]}\mathcal E(t)
=O_L(\epsilon^2).
\tag{C26}
\]

The same bound holds after the terminal window for a continued comparison. Since $\tau_L=2k_L\log(1/\epsilon)<2/\epsilon$ eventually, all windows fit the fixed horizon. Their geometric coherence conditions remain the formation component's obligation; C23 supplies the additional entropy requirement on its one common choice of $k_L$.

For every true marked retention $C_s$, the exact scalar identity is
$F(q,a)-F^s(C_sq,a)=T\Delta^{\mathrm{discarded}}$.
The hidden normalized score has the uniform sub-gamma constants established in F7, which depend on neither $J_L\to\infty$ nor actual label masses. Differentiation at fixed actual $q$ and fixed channel gives the complete covector bound

\[
|g(q,a)-g_s(C_sq,a)|
\le C_LT\left(\sqrt{\Delta^{\mathrm{discarded}}}
+\Delta^{\mathrm{discarded}}\right).
\tag{C27}
\]

Every source-prior, hidden-determinant, observation, and calibration contribution is included in $g$ and $g_s$. The prior factor cancels only from the normalized hidden conditional used to bound their difference. Thus early windows have complete-score error $O_L(T\epsilon^7)$, and the terminal window has $O_L(T\epsilon)$. Uniformly over all finite levels the conditional KL is $O_L(\epsilon^2)$ and complete same-state score error is $O_L(T\epsilon)$. Dividing C27 by the square root of the inherited metric gives its dual-norm version; the metric lower bound is the same one supplied by the own-law continuation calculation.

For $L=2$, C1 reads $J_1=\epsilon^{-20}$, $J_2=1$, $A=\epsilon^{40}$, and $T=\epsilon^{86}$. The first conditional window begins at $k_2\epsilon^{20}\log(1/\epsilon)$ and the terminal one at $k_2\log(1/\epsilon)$. C24 and C26 apply to the existing $19\to9\to8$ marked carrier, preserving both loops and all assignments. This is a concrete specialization of the general calculation, not numerical evidence for its quantifier over finite $L$.

## 6. Failure tests, returned construction, and remaining joins

The earlier heat-bath counterexample F34–F35 remains valid: a jump can create positive conditional KL from zero when actual label masses differ from the target masses and hidden conditional targets depend on the label. Lemma 1 does not assert conditional monotonicity. It contracts the full relative entropy by retaining the categorical dissipation that the earlier separate conditional bound did not use.

Both terms in C8 are necessary for this argument. If source mobility is set to zero and $q(x,j)=\lambda_jp(x\mid j)$ with incorrect label masses, the continuous Fisher information vanishes while joint relative entropy can be positive. Thus diffusion alone cannot prove C8. If the conductance comparison C5 is removed, bounded exit rates alone do not imply any uniform categorical contraction: two disconnected label classes give a counterexample. The actual S9–S11 rates satisfy C5, so neither failure case applies here. The proof also does not establish an entire source-history coupling: small unconditional joint relative entropy at one time is not a bound on conditional kernels given an observed history.

The returned approach family is `joint-entropy-terminal-entrance`, of type `LEMMA` plus an explicit finite-depth conditional construction. Its representation is the exact marked optimizer as a bounded tilt of a Gaussian-times-prior reference; its mechanism is entropy comparison, product entropy decomposition, and inherited-conductance comparison; its invariant is joint diffusion-plus-jump entropy coercivity with $J_L\ge1$; its bridge is a logarithmic terminal entrance time combined with the existing faster conditional estimates. Its assumptions are the frozen C1–C4 model, the admitted common-center initial neighborhood, exact actual activations, and the already checked internal-source support and relative-curvature bounds. Its target obligations are actual activation, every discarded-conditional KL, and complete same-state model-score error. The novelty is the use of the joint categorical dissipation at the terminal interface; it is not a rephrasing of the constant conditional jump bound or the accelerated global-mixing theorem.

The strongest supported result is C7–C8 and C24–C27. The continuation interface C4 is discharged by equation W7 of the companion continuation file; its W9 formation schedule admits the explicit finite $k_L$ above, and its W13 supplies the continuous-coordinate estimate. Thus the conditional-entropy upper-bound limitation at $J_L=1$ is resolved without reducing source mobility or likelihood strength. The separately requested complete source-history coupling remains the obligation of the [history component](fixed-weakest-energy-source-histories.md), followed by reconstruction of the full conjunction. A failure of that history construction would not undo the joint entropy inequality. The next material action is the separate reconstruction of the present C7, C17, and activation/terminal-time joins against the companion continuation and history arguments.
