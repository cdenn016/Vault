# Complete source histories with weakest energy fixed at one

September 13, 2026. This is the source-history component of the [fixed weakest-energy contract](evidence/2026-09-13-fixed-weakest-energy-adaptive-cyclic-rg/problem-contract.json), digest c574ab277c6be97d9c483ffcc4a76b87fc074d03d184a731b8a4973a7944f952. For every fixed finite depth, it proves a coupling of entire assignment histories with error $O_L(\epsilon^6)$ in the prescribed $J_L=1$ regime. The actual continuous coordinates and source updates keep their unit mobilities.

The new estimate uses the source support restriction in [N30–N34](nonlinear-adaptive-conditional-route.md), the marked geometry [F3–F10 and M7–M9](nonlinear-cyclic-formation-route.md), and the exact parent rates [S9–S11](finite-rate-source-dynamics-investigation.md). The previous [global-mixing argument](finite-rate-source-history-averaging.md) cannot supply this conclusion: its weakest restoring rate stays of order one. Here only the first normal layer and the retained loops are compared with a rapidly mixing auxiliary diffusion. The actual remaining normal environment continues to evolve, and its influence is bounded explicitly.

Source continuity also includes live PIFB2, section on mixture derivation, and Theory/05b, the exact posterior/recognition proposition, correlated-recognition ledger and conditional replicator equation. These distinguish an optimizing source row from the actual recognition conditional and from a constrained constant-row update. The process here is the unrestricted joint diffusion with full-assignment proposals; no recognition factorization or instantaneous posterior replacement is imposed.

## 1. Quantified statement and actual dynamics

Fix $L\ge2$, $b=2^{L-1}$, $n=3b$ and the full assignment set $\mathcal J$ of size $2^n$. At the fixed base point $c_*$, use the existing triangle-chain carrier, independent interaction links, root space $K$, normal flag coordinates $w=(w_1,\ldots,w_L)$, and all $b$ loop coordinates $h$. Retentions remove only the indicated initial normal layers and keep every loop and every assignment. The non-root state after $p$ eliminations is $(y,h)$, where $y=(w_{p+1},\ldots,w_L)$. The root is independent of the source rates and separates in the potential.

Use exactly the frozen regime

\[
Q_L=0,\qquad Q_s=2Q_{s+1}+20,\qquad
J_s=\epsilon^{-Q_s},\qquad
A^2=\epsilon^{3Q_1+20},\qquad
T=A^2\epsilon^6,\qquad H_*=\frac2\epsilon.
\tag{U1}
\]

Thus $J_L=1$, $Q_1\ge20$, and $J_2/\sqrt{J_1}=\epsilon^{10}$ for every admitted finite depth. The nonlinear coefficient $\delta=B_0/n$ has the fixed value $B_0=10^{-4}$. Source costs are

\[
\phi_j(w,h)=\widehat\phi_j\left(\sqrt{J_1/T}w_1,
\sqrt{J_1/T}h\right),\qquad
0\le\widehat\phi_j\le B_0,
\tag{U2}
\]

where $\widehat\phi_j$ is the same selected-source finite sum of $f(s)=1-e^{-s^2/2}$ on internal triangle edges. It has bounded derivatives of the orders used below. It is independent of $w_2,\ldots,w_L$, even in its combined arguments, and does not depend on $\epsilon$ or $a$. No bridge is a possible selected source.

The actual optimizing joint is the normalized E24–E29 joint. Its full proposal row and exact inherited rows are

\[
b_k(w_1,h,a)=
\frac{\pi_k(a)e^{-\phi_k(w_1,h)}}
{\sum_\ell\pi_\ell(a)e^{-\phi_\ell(w_1,h)}},
\]

\[
R^p_{jk}(y,h,a)=
E_{\Pi_a}[b_k(w_1,h,a)\mid P_pX=(y,h),J=j].
\tag{U3}
\]

The rate-one Poisson clock redraws the entire assignment from this row, including possible self proposals. The continuous process has generator $T\Delta-\nabla V_{p,j}\cdot\nabla$ on its exact sheet potential, with Brownian covariance $2T I dt$. Its jump term is $\sum_kR^p_{jk}(f_k-f_j)$. A proposal changes no continuous coordinate. Its off-diagonal rates are $R^p_{jk}$ and its conservative diagonal is $R^p_{jj}-1$. These are S2 and S9, not regenerated parent heat baths.

The [companion continuation](fixed-weakest-energy-continuation.md), W4–W7, supplies the well-posed actual own-law coefficient for every process and every lineage:

\[
1\le a(t)\le2.1,\qquad |\dot a(t)|\le C_L\epsilon,\qquad
\sup_{t\le H_*}|a(t)-a_0(t)|\le C_Lr_\epsilon,
\]

\[
a_0(t)=2-e^{-\epsilon t},\qquad
r_\epsilon=A^2J_1+T\ell_\epsilon^2,\qquad
\ell_\epsilon=1+\log(1/\epsilon).
\tag{U4}
\]

Each coefficient is computed from that process's own full law and complete covector. It is deterministic as a function of time because the feedback uses the exact law. Conditioning on a realized source history later in the proof does not recompute that coefficient from a conditioned law.

Use the common strict-margin preparation and its bounded small sheet-dependent transports from W1. The source-history argument uses only its moment consequence

\[
E|X_{M,0}|^2\le C_L(A^2+T),
\tag{U5}
\]

where $M=K^\perp$. More generally the proof holds for any positive joint initial law with this moment bound and coefficients satisfying (U4). Thus no conditional equilibrium is required. The stated preparation is nonempty: the common Gaussian center with the declared positive assignment masses is an example, and the permitted small smooth transports preserve (U5).

Every parent activates at a fixed deterministic time from the complete actual retained joint law and the actual coefficient. In a coupling its retained initial sample and assignment are exactly the projection of the source sample. At most $m\le L$ deterministic activations may occur in one lineage. The normal coordinates are projected, while loops and labels remain unchanged.

The conclusion concerns equality of the entire assignment-valued path on the comparison interval, with probability tending to one. It also preserves the common actual initial information in the coupling. It does not assert equality of joint continuous/discrete path laws, strong Markov lumpability, or total variation convergence of continuous path laws.

For every fixed positive instance, the sheet potentials are smooth, globally confining and have globally bounded Hessians, and there are finitely many labels with a bounded proposal rate. The sheet diffusions and their Poisson interlacing are nonexplosive. The global domain is Euclidean space times a finite set, with Lebesgue/counting reference measures and no boundary conditions beyond integrable decay at infinity. The time here is the declared inference parameter. No discretization or implementation is part of this result.

## 2. The exact source-relevant optimizer marginal

Let $\mathsf B=B[Q_1\cdots Q_L]$ be the fixed block lower-triangular flag matrix of F6. To avoid confusing its block entries with the exponents $Q_s$, write its blocks as $\mathsf B_{sr}$. Its diagonal blocks are invertible. Define

\[
C_*=\mathsf B_{11}^T\mathsf B_{11},\qquad
A_*=J_1C_*.
\tag{U6}
\]

The normal quadratic energy is

\[
w^TH_Nw
=J_1|\mathsf B_{11}w_1|^2+
\sum_{s=2}^LJ_s\left|\sum_{r\le s}\mathsf B_{sr}w_r\right|^2.
\tag{U7}
\]

At fixed $w_1$, change variables from $(w_2,\ldots,w_L)$ to the later residual blocks
$r_s=\sum_{r\le s}\mathsf B_{sr}w_r$, $s\ge2$.
The Jacobian is the product of the fixed diagonal-block determinants. Its value is independent of $w_1,h,j$. The later Gaussian integrals consequently produce a factor independent of these variables. Since the nonlinearity depends only on $(w_1,h)$, the full optimizing sheet has the exact marginal

\[
\mu^*_{a,j}(du,dh)=Z^*_j(a)^{-1}
\exp\left[-\frac{a}{2T}(u^TA_*u+J_1|h|^2)
-\phi_j(u,h)\right]du dh,
\qquad u=w_1.
\tag{U8}
\]

This is an exact optimizer marginal for every set of positive later strengths, with Lebesgue measure on the two coordinate factors. It does not result from freezing the environment.

Let $\mu^{h,*}_{a,j}$ be its loop marginal, and write

\[
\kappa^*_{a,j}(du\mid h)\ \propto\
\exp[-a u^TA_*u/(2T)-\phi_j(u,h)]du,
\qquad
R^*_{jk}(h,a)=E_{\kappa^*_{a,j}(\cdot\mid h)}b_k(u,h,a).
\tag{U9}
\]

Define the common stochastic matrix

\[
\mathcal B_{jk}(a)
=E_{\mu^*_{a,j}}b_k(u,h,a)
=E_{\mu^{h,*}_{a,j}}R^*_{jk}(h,a).
\tag{U10}
\]

Because (U8) is the exact full optimizer marginal, this is also
$E_{\Pi_a(\cdot\mid J=j)}b_k$.
For every exact parent, integrating (U3) against its optimizing sheet gives precisely (U10). Nested optimizer-conditioned rows compose by the same conditional-expectation tower S11, including their self-proposal entries. Thus all actual levels have the same fully averaged row exactly at fixed $a$.

The finite-rate comparison chain will start from the actual initial assignment and use proposal row $\mathcal B_{j\cdot}(a_0(t))$ at its rate-one Poisson times. It is not initialized at an optimizing assignment distribution. Its proposal row can depend on the current label $j$; detailed balance alone does not turn it into a newly generated heat bath.

## 3. Intermediate Gaussian covariances and mean response

The exact identity (U8) does not imply that an intermediate parent's conditional source kernel is independent of its actual retained normal state. We next bound that dependence, including the covariance change from further hidden integrations.

Fix $p\ge1$ and retain $y=(w_{p+1},\ldots,w_L)$. In the Gaussian core, integrate out $w_2,\ldots,w_p$ at fixed $(u,y)$. The resulting quadratic precision in $u$ is a positive matrix $\mathsf C_p$ and the conditional Gaussian law of $u$ at fixed $y$ is

\[
g_{p,a,y}=N\left(m_p(y),\frac Ta \mathsf C_p^{-1}\right).
\tag{U11}
\]

The precision satisfies the stronger statement

\[
A_*\preceq \mathsf C_p\preceq (H_N)_{11}
\preceq A_*+C_LJ_2I.
\tag{U12}
\]

To prove the lower bound, minimize the nonnegative later-row sum in (U7) over $w_2,\ldots,w_p$ at fixed $(u,y)$, and then set $y=0$. The result is still nonnegative, so its $u$-quadratic coefficient is $\mathsf C_p-A_*\succeq0$. For the upper bound, the admissible choice $w_2=\cdots=w_p=0$, with $y=0$, gives the original block $(H_N)_{11}$. Finally every row contributing to $(H_N)_{11}-A_*$ has strength at most $J_2$ and a fixed finite matrix. This proves (U12) uniformly in $p$ and in all descending contrasts. At $p=L$, the residual change in Section 2 gives $\mathsf C_L=A_*$ exactly.

The first-block mean-response calculation N30–N32 gives

\[
|\partial_{w_s}m_p|\le C_LJ_s/J_1\quad(s>p),
\qquad
|m_p(y)|\le C_L(J_2/J_1)|y|.
\tag{U13}
\]

Here $m_p$ is linear and vanishes at zero; the factor $a$ cancels in the Gaussian conditional mean. One can check the first bound in residual coordinates: the first block row of
$(\mathsf D_E+C^T\mathsf D_f C)^{-1}$ has norm $O_L(J_1^{-1})$ by N31, whereas a force column from retained layer $s$ has norm $O_L(J_s)$. Summing the finitely many retained blocks gives the second bound. No inverse of the weakest eliminated rate replaces this first-row estimate.

Put

\[
\rho_\epsilon=\frac{J_2}{J_1},\qquad
\alpha_\epsilon=\frac{J_2}{\sqrt{J_1T}},\qquad
d_\epsilon(y)=\rho_\epsilon+\alpha_\epsilon|y|.
\tag{U14}
\]

Let $g_{*,a}=N(0,(T/a)A_*^{-1})$. Then

\[
\|g_{p,a,y}-g_{*,a}\|_{\rm TV}
\le C_Ld_\epsilon(y).
\tag{U15}
\]

For an explicit check, the Gaussian relative entropy is one half the sum of
$(a/T)m_p^TA_*m_p$ and
$\operatorname{tr}(A_*\mathsf C_p^{-1})-\dim u-\log\det(A_*\mathsf C_p^{-1})$.
The mean term is at most $C_L\alpha_\epsilon^2|y|^2$. By (U12), the eigenvalues of $A_*\mathsf C_p^{-1}$ lie between $(1+C_L\rho_\epsilon)^{-1}$ and one, so the remaining term is at most $C_L\rho_\epsilon^2$ for small $\epsilon$. The probability inequality $\|\nu-\mu\|_{\rm TV}\le\sqrt{D(\nu\Vert\mu)/2}$ proves (U15). It follows directly by mapping the measures to a two-cell partition attaining total variation and using the binary bound $d(v\Vert u)\ge2(v-u)^2$; that bound follows from its second derivative $1/[v(1-v)]\ge4$ and its minimum at $v=u$.

The actual optimizing conditional of $u$ at fixed $(y,h,j)$ is the normalized tilt

\[
\kappa^p_{a,j}(du\mid y,h)
\ \propto\ e^{-\phi_j(u,h)}g_{p,a,y}(du).
\tag{U16}
\]

Tilting two probability measures by the same function in $[e^{-B_0},1]$ multiplies their total variation by at most $2e^{B_0}$: subtract the two normalized densities, and bound their normalizing-constant difference by the integral of the absolute density difference. Applying this fact to (U15) proves

\[
\|\kappa^p_{a,j}(\cdot\mid y,h)
-\kappa^*_{a,j}(\cdot\mid h)\|_{\rm TV}
\le C_Ld_\epsilon(y),
\tag{U17}
\]

uniformly in the entire unbounded loop coordinate $h$. This uniformity is essential; no restriction to a typical loop tube has been made.

## 4. Exact rate and loop-force comparisons

Because $b$ is a stochastic row, integrating it against two measures contracts total variation. Equations (U3), (U9), and (U17) imply

\[
\|R^p_{j\cdot}(y,h,a)-R^*_{j\cdot}(h,a)\|_{\rm TV}
\le C_Ld_\epsilon(y),\qquad p\ge1.
\tag{U18}
\]

This includes the entire assignment row and its self entry. It is not just a bound on one receiver's marginal.

Let $V^{h,*}_{a,j}=-T\log\mu^{h,*}_{a,j}$, up to an additive constant. The Gaussian quadratic core has no loop/normal cross term. Differentiating the normalized integrals in (U16) and (U9) therefore gives

\[
\nabla_hV_{p,j}(y,h,a)
=aJ_1h+T E_{\kappa^p_{a,j}}\nabla_h\phi_j,
\qquad
\nabla_hV^{h,*}_{a,j}(h)
=aJ_1h+T E_{\kappa^*_{a,j}}\nabla_h\phi_j.
\tag{U19}
\]

Since $\|\nabla_h\phi_j\|_\infty\le C_L\sqrt{J_1/T}$, (U17) gives the uniform force bound

\[
|\nabla_hV_{p,j}(y,h,a)-\nabla_hV^{h,*}_{a,j}(h)|
\le C_L\sqrt{TJ_1}d_\epsilon(y).
\tag{U20}
\]

The derivative bound and the common bounded tilt make (U20) uniform in $h$, despite its unbounded domain.

Both the original row and the reference loop row are globally Lipschitz on their fast coordinates:

\[
\|b(\xi,a)-b(\xi',a)\|_{\rm TV}
\le C_L\sqrt{J_1/T}|\xi-\xi'|,
\]

\[
\|R^*_{j\cdot}(h,a)-R^*_{j\cdot}(h',a)\|_{\rm TV}
\le C_L\sqrt{J_1/T}|h-h'|.
\tag{U21}
\]

For the first bound differentiate the normalized source probabilities; the absolute sum of derivatives is bounded by twice the largest source-cost derivative. For the second, differentiating (U9) contributes the expectation of the row derivative and its covariance with $\nabla_h\phi_j$. Each is bounded by the same finite constant times $\sqrt{J_1/T}$. The Gaussian reference in (U9) has no $h$ dependence, so no missing mean or covariance derivative occurs.

## 5. Fast reference mixing, with its hypotheses checked

The auxiliary fine fast diffusion has potential

\[
V^*_{a,j}(u,h)=\frac a2(u^TA_*u+J_1|h|^2)+T\phi_j(u,h)
\tag{U22}
\]

and unit continuous mobility. The auxiliary parent fast diffusion is its exact loop-marginal diffusion with potential $V^{h,*}_{a,j}$. They are comparison processes; neither replaces an actual coordinate or update.

The M7–M9 Hessian calculation applies to these fast potentials directly. Their quadratic core consists of the complete level-one normal energy and all loop energy, which contains every selected internal residual. The selected-source Hessian has relative bound $2\delta$, and the marginal covariance correction adds at most $2n\delta^2$. Therefore, with constants depending only on finite $L$,

\[
c_LJ_1I\preceq\nabla^2V^*_{a,j}\preceq C_LJ_1I,\qquad
c_LJ_1I\preceq\nabla^2V^{h,*}_{a,j}\preceq C_LJ_1I.
\tag{U23}
\]

Both potentials are even, and each reference has fast-coordinate second moment at most $C_LT/J_1$. This is a statement about the auxiliary fast spaces only, not a lower bound $c_LJ_1$ for the full actual normal environment.

For a fixed label $j$ and either auxiliary fast type, let $\mathcal P^*_{s,t}$ use the actual deterministic $a(r)$ on $[s,t]$. Then

\[
\|\mathcal P^*_{s,t}(z,\cdot)-\mu^*_{a(t),j,\mathrm{type}}\|_{\rm TV}
\le C_L(1+\sqrt{J_1/T}|z|)e^{-c_LJ_1(t-s)}
+C_L\epsilon/J_1
\tag{U24}
\]

for $t-s\ge1/(c_LJ_1)$. The reference measure here is (U8) for the fine type and its loop marginal for the parent type.

For completeness, the proof of (U24) uses only the following elementary curvature and entropy argument. Reflection coupling of two solutions of the same time-dependent fast diffusion gives a distance bounded above, until meeting, by
$dD=-\lambda Ddt+2\sqrt{2T}d\beta$, with $\lambda=c_LJ_1$.
After multiplication by $e^{\lambda(t-s)}$, the Brownian variance accumulated over duration $v$ is $4T(e^{2\lambda v}-1)/\lambda$. The one-dimensional reflection principle bounds nonmeeting probability by
$C|z-z'|\sqrt{\lambda/T}(e^{2\lambda v}-1)^{-1/2}$.
The reflecting noise matrix is predictable and orthogonal, so each marginal is the required Brownian motion. Local construction off the diagonal, coupling together after meeting, and the globally linear growth of the drifts justify this coupling.

The remaining moving-reference lag is uniform. In variables $\zeta=\sqrt{J_1/T}(u,h)$, (U8) is a bounded tilt of a fixed-dimensional Gaussian with quadratic score
$F_*(\zeta)=(u_\zeta^TC_*u_\zeta+|h_\zeta|^2)/2$.
Its centered parameter score is $E F_*-F_*$. For $|\vartheta|\le1/4$, the second derivative of its logarithmic moment generating function is
$\operatorname{Var}_{\mu^*_{a+\vartheta,j}}F_*\le C_L$.
This follows from Gaussian quadratic moments and the common bounded tilt. Its centered log moment generating function is therefore bounded by $C_L\vartheta^2$. The loop-marginal parameter score is the conditional expectation of this score, so conditional Jensen preserves that bound. For either type, the entropy variational inequality with
$|\vartheta|=\min(1/4,c_L\sqrt D)$ gives
$|E_q\partial_a\log\mu^*|\le C_L(\sqrt D+D)$,
where $D=D(q\Vert\mu^*)$.

For any frozen reference in (U23), its diffusion semigroup obeys
$I_\mu(P_tf)\le e^{-2\lambda t}I_\mu(f)$:
the derivative flow contracts by $e^{-\lambda t}$, and weighted Cauchy–Schwarz gives this inequality before integration against the invariant measure. Entropy differentiation gives
$d\operatorname{Ent}_\mu(P_tf)/dt=-T I_\mu(P_tf)$.
For bounded positive Lipschitz densities bounded away from zero, synchronous contraction against a stationary starting point gives convergence to the constant density, with entropy tending to zero. Integration yields
$D(q\Vert\mu)\le T I(q\Vert\mu)/(2\lambda)$.
Truncation, normalization and short semigroup smoothing extend this inequality to finite entropy and Fisher information. Gaussian domination justifies the limiting integrations by parts.

Start the varying-parameter reference process at its equilibrium at time $s$. Its entropy relative to its current reference satisfies exactly
$D'=-T I-\dot a E_q\partial_a\log\mu^*$.
The preceding bounds and (U4) imply
$D'\le-\lambda D+C_L\epsilon^2/\lambda$, with $D(s)=0$.
Hence $D\le C_L\epsilon^2/J_1^2$ and total variation is at most $C_L\epsilon/J_1$. Finally integrate the reflection-coupling bound against the equilibrium starting point, whose moment is $C_LT/J_1$, and add this lag. This proves (U24).

All potentials used in this argument have the global smoothness, curvature and Gaussian tails just checked. All derivatives and entropy identities can first be performed with compact cutoffs and then passed to their integrable limits. No full-system mixing theorem or mixing at rate $J_L$ has been used.

The same score calculation, together with $|\partial_a\log\pi_k|\le4$ for the only learning binary prior, gives

\[
\sup_j\|\mathcal B_{j\cdot}(a)-\mathcal B_{j\cdot}(a')\|_{\rm TV}
\le C_L|a-a'|.
\tag{U25}
\]

Indeed $\sum_k|\partial_ab_k|\le8$, and differentiating its expectation against (U8) adds at most the first absolute moment of the centered quadratic score. Both are bounded independently of strengths and temperature.

## 6. Contractive forcing estimates for the evolving environment

Fix an interval $[s,t]$ containing no proposals or activations, so its label and level are fixed. Its environment remains the actual stochastic environment throughout.

For a fine process, set $\xi=(w_1,h)$ and start the auxiliary process $\xi^*$ at the same fast state at $s$, using the same fast Brownian increments and the same actual parameter. The difference between the actual fast force and (U22) is

\[
a\big((H_N)_{11}-A_*\big)w_1+a(H_N)_{1,>1}w_{>1}
\]

in the $w_1$ coordinate and zero in the loop coordinate. Its norm is at most $C_LJ_2|w|$ by (U7). Strong monotonicity (U23), followed by integration of the distance differential inequality, gives the pathwise bound

\[
|\xi_t-\xi_t^*|
\le C_LJ_2\int_s^t e^{-c_LJ_1(t-v)}|w_v|dv.
\tag{U26}
\]

This treats $w_{>1,v}$ as its actual adapted process. It imposes neither a frozen environment nor differentiability of a Brownian environment.

For an actual parent $p\ge1$, couple its loop coordinate with the auxiliary loop diffusion starting at its actual loop value and driven by its same Brownian increments. Equations (U20) and (U23) similarly give

\[
|h_t-h_t^*|
\le C_L\sqrt{TJ_1}\int_s^t
e^{-c_LJ_1(t-v)}d_\epsilon(y_v)dv.
\tag{U27}
\]

Combining (U26) with the first inequality of (U21), or combining (U27) with (U18) and the second inequality of (U21), bounds the actual next proposal row against the auxiliary row at its auxiliary fast state. For the fine type the bound is
$C_LJ_2\sqrt{J_1/T}\int_s^t e^{-c_LJ_1(t-v)}|w_v|dv$.
For a parent type it is
$C_L[d_\epsilon(y_t)+J_1\int_s^t e^{-c_LJ_1(t-v)}d_\epsilon(y_v)dv]$.
These bounds are pointwise before taking the conditional expectations appropriate to source histories.

We now supply the moments that will average those conditional bounds. Let $\mathcal T$ be the entire exogenous proposal grid after the common initial time. Conditional on $\mathcal T$, proposal times are fixed and the Brownian noises retain their laws. The actual marked potentials are even on $M_p$, and W4 gives $\nabla^2V_{p,j}\succeq c_LI$ because $J_L=1$. Therefore

\[
\mathcal L^p_a|X_M|^2
\le 2T\dim M-2c_L|X_M|^2.
\tag{U28}
\]

Proposals leave this norm unchanged; orthogonal activations decrease it. Integrating this inequality between the fixed events and applying (U5) proves

\[
\sup_{t\le H_*}E[|X_{M,t}|^2\mid\mathcal T]
\le C_L(A^2+T).
\tag{U29}
\]

This is after integrating the actual initial information, which is independent of the future proposal grid. Starting at an actual deterministic activation gives the same conclusion by projection and the future independence of Poisson increments. A fixed initial-state conditioning replaces (U5) by that state's squared norm and is integrated at the end. Thus (U29) also covers a random shared actual activation sample, without imposing a uniform moment bound for every individual sample.

Define

\[
\eta_\epsilon=\frac{J_2}{J_1}
+\frac{J_2}{\sqrt{J_1}}\left(1+\frac A{\sqrt T}\right).
\tag{U30}
\]

After averaging any proposal-prefix conditional expectation over its actual prefix law and common initial information, (U29) bounds each of the row errors following (U27) by $C_L\eta_\epsilon$, even conditional on the complete proposal grid. In particular this is not a bound obtained by dividing an unconditional estimate by the probability of a rare observed source history.

## 7. Complete conditional proposal histories

Let $0<h_*\le H_*$ with $h_*\ge1/(c_LJ_1)$. For an actual lineage with at most $m$ deterministic activations and the comparison chain from Section 2, there is a coupling preserving their common actual initial assignment and information for which

\[
\begin{split}
\Pr\{\mathsf J\ne\mathsf J^{\rm av}
\text{ somewhere on }[0,H_*]\}
\le C_L\bigg[
&(H_*+m+1)h_*\\
&+H_*(1+A\sqrt{J_1/T})e^{-c_LJ_1h_*}\\
&+\frac{H_*\epsilon}{J_1}
+H_*\eta_\epsilon+H_*r_\epsilon\bigg].
\end{split}
\tag{U31}
\]

The interval may begin at a common actual deterministic activation; then all times in the coefficient are absolute times and its length is at most $H_*$. The estimate uses the inherited moment bound at that starting time.

Here is the joint-history proof. Condition on the proposal grid $t_1<\cdots<t_N$, the shared initial information $I$, and an actual proposal-mark prefix $j_0,\ldots,j_{\ell-1}$. Include self proposals in the prefix. Put $\sigma_\ell$ equal to the most recent preceding proposal, activation or starting time. On $[\sigma_\ell,t_\ell]$ the label and active level are fixed. At $\sigma_\ell$ initialize the relevant auxiliary fast diffusion at the actual fast state. Its future fast Brownian increments, conditional on that starting state, have the ordinary Brownian law: the conditioning contains only past mark outcomes and an independent Poisson grid, with no subsequent continuous path observation.

If $t_\ell-\sigma_\ell\ge h_*$, equations (U26)–(U27) and (U21) compare the actual conditional proposal row with the auxiliary row at $t_\ell$. Equation (U24), contracted by that stochastic row, then compares it with $\mathcal B_{j_{\ell-1}\cdot}(a(t_\ell))$. Equation (U25) and (U4) replace the parameter by $a_0(t_\ell)$ with error $C_Lr_\epsilon$. The full conditional bound contains the conditional fast-state moment and the conditional forcing integrals just displayed. Its expectation over actual prefixes and initial information is, by (U29), at most

\[
C_L\left[
(1+A\sqrt{J_1/T})e^{-c_LJ_1h_*}
+\epsilon/J_1+\eta_\epsilon+r_\epsilon\right].
\tag{U32}
\]

For a shorter interval bound the row difference by one. This reasoning conditions on entire source proposal prefixes but not on the future continuous retained path; no conditional mixing claim given such a continuous path is used.

For a fixed finite grid, let $P$ be the actual law of its proposal marks and let $Q$ use the comparison rows. The sequential-kernel inequality is

\[
\|P-Q\|_{\rm TV}
\le\sum_{\ell=1}^N E_{P\text{ prefix}}
\|p_\ell(\cdot\mid\text{prefix})
-\mathcal B_{j_{\ell-1}\cdot}(a_0(t_\ell))\|_{\rm TV}.
\tag{U33}
\]

It follows by telescoping hybrid laws with an actual prefix and a comparison tail; their common stochastic tail cannot increase total variation. This identity concerns the complete joint sequence, rather than a product of one-time marginal approximations. Its actual-prefix expectation is exactly what permits the averaging in (U32).

The expected number of short intervals is at most $(H_*+m+1)h_*$. Indeed, the expected number of ordered Poisson pairs less than $h_*$ apart is
$\int_0^{H_*}\int_{\max(0,t-h_*)}^t ds dt\le H_*h_*$,
and each of the $m+1$ activation/start times has at most $h_*$ expected subsequent proposals within that distance. This may overcount. For all remaining terms use (U32) and $EN=H_*$. Summation proves (U31).

Conditional maximal coupling of the finite mark sequences given the common grid and $I$ realizes this bound; the construction preserves $I$ exactly. Integrating the finite grids and using that $N$ is Poisson and finite almost surely is justified by nonnegative summation. The assignment path is a deterministic step function of the grid and marks, so forgetting self proposals cannot increase disagreement probability.

For two actual independently evolving processes activated with the same retained sample and label, use the same conditional comparison-chain law and apply the sum of their two bounds. A common source initial sample can be included in $I$, with the parent initial sample its exact projection; the estimates are averaged over that actual joint information. Conditional gluing therefore retains that common sample, not merely equality of its marginal distribution.

This coupling need not be causal in the pair's simultaneous states. Each correct continuous-path marginal can be restored by sampling its conditional path law given its coupled mark history and $I$; the path spaces are standard Borel, so those conditional probability kernels exist. The argument does not claim those conditional continuous laws are close. The separate continuous-coordinate comparison from the companion continuation is uniform over adapted assignments and uses marginal exceptional-event bounds, so it can be combined with this history coupling without changing either process's marginal law.

## 8. Scaling, scope, and the remaining join

Choose

\[
h_*=k_LJ_1^{-1}\log(1/\epsilon),
\qquad c_Lk_L\ge Q_1/2+12.
\tag{U34}
\]

The finite constant $k_L$ may depend on the prescribed depth. Then
$1+A\sqrt{J_1/T}=1+\epsilon^{-Q_1/2-3}$, so the mixing contribution in (U31) is $O_L(\epsilon^8)$. Its short-interval contribution is
$O_L(\epsilon^{Q_1-1}\log(1/\epsilon))$, at most order $\epsilon^{19}\log(1/\epsilon)$. Its moving-parameter lag is $O_L(\epsilon^{Q_1})$. The new environment term obeys

\[
\eta_\epsilon
=\epsilon^{Q_1-Q_2}+\epsilon^{10}(1+\epsilon^{-3})
=O_L(\epsilon^7),
\qquad H_*\eta_\epsilon=O_L(\epsilon^6).
\tag{U35}
\]

Finally,
$r_\epsilon/\epsilon
=\epsilon^{2Q_1+19}
+\epsilon^{3Q_1+25}\ell_\epsilon^2$.
Therefore (U31) proves

\[
\Pr\{\text{any assignment-history disagreement on }[0,H_*]\}
\le C_L\epsilon^6.
\tag{U36}
\]

This holds for any exact source/parent pair started from their common actual marked activation sample, and for finitely many successive actual activations after adding at most a finite-depth constant. The bound concerns the complete assignment set, whose size remains $2^n$, rather than a single learned source row.

At depth two the exact prescribed instance is
$J_1=\epsilon^{-20}$, $J_2=1$, $A=\epsilon^{40}$ and $T=\epsilon^{86}$.
The actual carrier remains
$\mathbb R^{19}\times\mathcal J\to
\mathbb R^9\times\mathcal J\to
\mathbb R^8\times\mathcal J$, with $|\mathcal J|=64$.
Both loops and all receiver source assignments remain present throughout.

The result resolves the source-history obstruction of the global-mixing proof within this fixed internal-neighbor model and the frozen weakest-one regime. The load-bearing replacement is the exact fast optimizer marginal (U8), the intermediate covariance sandwich (U12), and the evolving-environment forcing estimates (U26)–(U27). None requires the remaining normal environment to equilibrate between source proposals. The small factor comes from the supplied contrast relation $J_2/\sqrt{J_1}=\epsilon^{10}$ and the prepared amplitude ratio $A/\sqrt T=\epsilon^{-3}$, not from reducing the source rate or the standardized likelihood strength.

The theorem is restricted to the source support $(w_1,h)$. Allowing source costs to involve later bridge residuals would invalidate the exact fast marginal and would require a new estimate. It makes no claim that learning creates the supplied energy hierarchy or that algorithmic time is physical time. Static normalized composition and optimizer-conditioned rate composition remain exact; source histories are approximately equivalent in the stated coupling sense.

The remaining join for the complete frozen target is the separate switching conditional-entropy and complete-score calculation together with the continuation/formation component's shared preparation and activation hypotheses. History coupling proves none of those by itself. The next check that can change the whole-target conclusion is their independent reconstruction against (U4)–(U5), (U31), and the common regime (U1).

No simulation, numerical experiment, test suite, GPU work, Lean work, or tamper check was run. The artifact consists of the displayed exact calculations and asymptotic bounds.
