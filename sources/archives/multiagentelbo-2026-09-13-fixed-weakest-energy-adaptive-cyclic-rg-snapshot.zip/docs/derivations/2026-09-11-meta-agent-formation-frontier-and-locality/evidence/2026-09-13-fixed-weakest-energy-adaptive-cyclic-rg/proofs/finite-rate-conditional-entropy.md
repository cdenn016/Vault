# Conditional entropy and actual activation with finite source mobility

September 13, 2026. This is the conditional and activation component of [the frozen finite-rate contract](evidence/2026-09-13-finite-rate-adaptive-cyclic-rg/problem-contract.json), target digest `2f673c3806f5838530bd025b43174018904da19fe6af74fc8c24ae2e7bcf3e09`. It leaves the completed [zero-mobility proof](nonlinear-adaptive-conditional-route.md) unchanged. All results below are analytical; no trajectory experiment or numerical closure is used.

## 1. Target, existing inputs, and scope

The full target quantifies over every prescribed finite depth $L\ge2$. It asks for a nonempty positive-temperature family of the normalized triangle-chain model, fixed $\delta=B_0/n>0$, microscopic full-assignment redraw rate $\nu=1$, exact marked parent activations, and vanishing conditional, complete-score, continuous-path, and full source-history errors on $H_*=2/\epsilon$. The full target also requires successive formation, own-law parameter continuation, and quantitative actual recognition-source and hidden-kernel movement. This component proves the conditional and activation estimates. It supplies explicit inputs to the continuation and history components; it does not substitute conditional KL for a statement about joint path laws.

The supplied model is [E24–E29](nonlinear-endpoint-attention-model.md), with the positive-rate generator [S2](finite-rate-source-dynamics-investigation.md) and the exact inherited rates S9–S11. The prior, physical posterior, optimizing density, and restricted-objective scalar remain distinct. The source support consists of internal triangle neighbors, as in the completed construction; rows mixing different edge levels are outside that admission. The exact posterior and correlated-recognition ledger in [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), `prop:obs-attention-elbo` and `eq:obs-attention-correlated-ledger`, and its separate replicator equation were consulted. So were live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>), `sec:mixture_derivation`, and the September 13 paragraphs of the [vault synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>) and [staged-hierarchy note](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Staged hierarchy formation and RG composability.md>). Their fixed-label and source-independence restrictions are not transferred to the present actual joint law.

The new scale assumption used for the positive result is explicitly displayed in Section 8: the weakest energy strength grows as $\epsilon^{-8}$. This is the separately admitted uniformly accelerated energy family. The alternative normalization $J_L=1$ remains a distinct problem; Section 9 records exactly what these estimates do and do not establish for it.

Work is at one base point $c_*$. At active level $p$, the state is $(X,J)\in\mathbb R^{d_p}\times\mathcal J$, with Lebesgue measure in the normal-plus-loop coordinates and counting measure on the complete assignment set. Put $m_J=|\mathcal J|<\infty$. Every loop and every assignment is retained by the actual channels. The compatible autonomous root sector may be appended as a common independent product; no root observation energy is used in the estimates below. Initial label/configuration correlation is allowed.

The inference time is $t\in[0,H_*]$; no physical-time interpretation is asserted. The process has continuous unit mobility, Brownian noise covariance $2T I$, and an independent rate-one Poisson clock used to implement the finite-state transitions. Its active generator is

\[
\begin{split}
\mathcal L_{p,a}f(x,j)
&=T\Delta_xf-\nabla U_{p,a,j}(x)\cdot\nabla_xf
  +\sum_{k\ne j}K^p_{jk}(x,a)[f(x,k)-f(x,j)],\\
U_{p,a,j}(x)&=\frac a2x^TH_px+T\phi_{p,a,j}(x),
\qquad 0\le\phi_{p,a,j}\le B_0.
\end{split}
\tag{F1}
\]

Here $H_p$ is the exact Gaussian Schur precision. Microscopically $K^0_{jk}=b_k$ for $k\ne j$; at every parent it is the exact optimizer-conditioned S9 rate, equivalently the conditional expectation of the original rate. Its exit rate is at most one. There is no new kinetic multiplier and no reset at an activation.

For the estimates, first stop a continuous parameter path before it exits $a\in[a_-,a_+]=[1,2.1]$, and suppose $|\dot a|\le C_L\epsilon$. These are interfaces for the separate own-law continuation proof, not assumptions of its conclusion. Constants may depend on finite $L$, the fixed admitted source family, and these compact-interval bounds; they do not depend on $\epsilon,T,A$, or powers of the stiffnesses unless displayed. Each fixed $\epsilon>0$ gives globally Lipschitz sheet drifts with linear growth, smooth bounded finite-state rates, and nonexplosive Poisson interlacing. There is no boundary or reflecting modification of the Euclidean diffusion. The estimates concern the continuous generator F1, not a time discretization or a training implementation.

## 2. The conditional geometry remains uniform over moving assignments

Exact integration of a sheet gives

\[
p^p_a(x,j)=\mathcal Z_p(a)^{-1}\pi_j(a)G^p_a(x)e^{-\phi_{p,a,j}(x)},
\qquad G^p_a=N\bigl(0,(T/a)H_p^{-1}\bigr),
\qquad e^{-B_0}\le\mathcal Z_p(a)\le1.
\tag{F2}
\]

The Gaussian reference is independent of $j$. Its conditional mean under any fixed orthogonal retention is independent of $a$, because the whole normal-plus-loop precision is $aH$. The sheet version of N20–N28 consequently proves

\[
\left|\sqrt T H_p^{-1/2}\nabla\phi_{p,a,j}\right|\le C_L,
\quad c_0H_p\preceq\nabla^2U_{p,a,j}\preceq C_LH_p,
\quad |\partial_a\phi_{p,a,j}|\le C_L,
\tag{F3}
\]

uniformly in every $x,j,p$. These statements are about each exact target sheet and hence are unaffected by changing actual label masses. In particular, exact marginalization includes the conditional covariance term in its Hessian. The fixed positive $\delta$ satisfies the original relative-curvature admission; no additional limit $\delta\to0$ is used.

For interface $p<s$, use the auxiliary split from N17,

\[
Z=(N_p\cap N_s^\perp)\oplus H_h,
\qquad Y=N_s,
\qquad
\widehat\Delta_{p:s}
=\sum_j\int q_Y(y,j)
 D\bigl(q(dz\mid y,j)\Vert k_{a,j}(dz\mid y)\bigr)dy.
\tag{F4}
\]

The loop space $H_h$ is integrated only in this auxiliary estimate. The true parent retains the loops and the full $j$. The conditional KL chain rule, first conditioning on $(Y,J)$ and then on the additionally retained loops, gives

\[
0\le\Delta^{\mathrm{discarded}}_{p:s}\le\widehat\Delta_{p:s}.
\tag{F5}
\]

Write $\gamma_a(dz\mid y)$ for the conditional of $G_a^p$. By F2,

\[
e^{-B_0}\le\frac{dk_{a,j}(\cdot\mid y)}{d\gamma_a(\cdot\mid y)}\le e^{B_0}.
\tag{F6}
\]

For this auxiliary split, the published N30–N34 incidence calculation and F3 supply conditional curvature $\lambda_s=c_LJ_s$ and mixed Hessian bound $\Gamma_s=C_LJ_{s+1}$, with $J_{L+1}=0$ and $\Gamma_L=0$. The incidence calculation uses the restricted internal source rows: the first hidden Gaussian row inverse has size $O_L(J_1^{-1})$, and its response to a future-normal force column of size $J_{s+1}$ is $O_L(J_{s+1}/J_1)$. Thus this bound survives the source force's dependence on retained loop coordinates. It is not a bound obtained by dropping those coordinates.

The precise logarithmic-Sobolev statement used below is: if a $C^2$ potential $W$ on $\mathbb R^k$ satisfies $\nabla^2W\succeq\lambda I$ and has the stated confining tails, its normalized density $k\propto e^{-W/T}$ satisfies $D(h\Vert k)\le T I(h\Vert k)/(2\lambda)$. F3 verifies the hypotheses for every fixed $(y,j)$ with $\lambda=\lambda_s$. This is the curvature criterion in [Gentil, Remark 3.2 and Theorem 3.3](https://arxiv.org/pdf/1009.3421), with $\psi=W/T$ and $\rho=\lambda/T$; the Gaussian case uses $\psi=|x|^2/(2\sigma^2)$. The source was inspected September 13, 2026.

The same hidden Gaussian scale-score calculation N26–N28 gives constants $v_0,b_0$ independent of $y,j,T,J_s$ such that

\[
\log E_{k_{a,j}}e^{u\partial_a\log k_{a,j}}
\le\frac{v_0u^2}{2(1-b_0|u|)},\qquad |u|<b_0^{-1}.
\tag{F7}
\]

Indeed the score is the conditional centering of $(k-|Z_0|^2)/(2a)-\partial_a\phi_{p,a,j}$ in centered standard-Gaussian coordinates $Z_0$, followed by a density tilt bounded by F6. Gaussian exponential moments and the bounded second term give the displayed sub-gamma bound. The categorical factor $\pi_j(a)$ cancels from this hidden conditional; it remains present in the full covector.

## 3. The jump contribution to conditional entropy

**Lemma 1.** Suppose the continuous coordinates $(Y,Z)$ are unchanged by a conservative finite-state generator $K(y,z)$ whose exit rate is at most $\nu$. Suppose its hidden targets obey F6 relative to one label-independent $\gamma(dz\mid y)$. At a fixed parameter and for the actual joint law, the jump contribution satisfies

\[
\left.\frac{d\widehat\Delta}{dt}\right|_{\mathrm{jump}}
\le\nu\bigl(\log m_J+2B_0\bigr).
\tag{F8}
\]

No lower bound on an actual label mass or conditional probability is required. Reversibility is not needed for this lemma.

*Proof.* Condition on a retained $y$. The jump leaves the actual $q_Z(dz\mid y)$ fixed. Let $\theta_j(z)=q(j\mid y,z)$ and uniformize $K$ by $R(z)=I+K(z)/\nu$. Every $R(z)$ is stochastic, and the jump direction is $\dot\theta=\nu(\theta R-\theta)$. The conditional entropy relative to $\gamma$ decomposes exactly as

\[
\widehat\Delta_\gamma(y)
=D(q_Z(\cdot\mid y)\Vert\gamma(\cdot\mid y))
 +I_{q(\cdot\mid y)}(Z;J).
\tag{F9}
\]

For a fixed input law $q_Z$, mutual information is convex in the channel $\theta$. To check this directly, it is the relative entropy between $q_Z(dz)\theta_j(z)$ and $q_Z(dz)\bar\theta_j$, where $\bar\theta_j=\int\theta_jdq_Z$; both measures depend affinely on $\theta$, and joint convexity of relative entropy applies. For $\theta'=\theta R$, convexity bounds its directional derivative by $\nu[I(\theta')-I(\theta)]\le\nu\log m_J$. This remains true when $R$ depends on $z$.

The difference between the desired entropy and F9 is the linear functional

\[
\widehat\Delta(y)-\widehat\Delta_\gamma(y)
=\sum_j\int q_Z(dz\mid y)\theta_j(z)
          \log\frac{\gamma(z\mid y)}{k_{a,j}(z\mid y)}.
\tag{F10}
\]

Its integrand is between $-B_0$ and $B_0$. Replacing $\theta$ by $\theta'$ changes the expectation by at most $2B_0$, so its jump derivative is at most $2\nu B_0$. The law of $Y$ also stays fixed under jumps. Integrating F9–F10 against that law proves F8. Positive densities justify ordinary derivatives; approximation by positive channels and the same convexity inequalities gives the upper Dini-derivative version if a conditional mass vanishes. QED.

Apply the lemma to every active microscopic or inherited generator, with $\nu=1$. S9–S11 give the required exit bound, including after any number of exact retentions. The proof uses the actual $q(j\mid y,z)$, and its changing marginal $q(j\mid y)$ is included in F9. It never substitutes an optimizing source row for either one.

## 4. An entropy floor for the actual joint law

For a normalized density $q(x,j)$ on $\mathbb R^d\times\mathcal J$, define the joint differential/counting entropy

\[
\mathfrak h(q)=-\sum_j\int q(x,j)\log q(x,j)dx.
\tag{F11}
\]

It is distinct from the differential entropy of the continuous marginal and from the sum of fixed-mass sheet entropies.

**Lemma 2.** On an active interval starting at $\tau$, suppose $\operatorname{tr}\nabla^2 U_{a,j}\le d\Lambda$ uniformly, the source exit rate is at most $\nu$, and the entropy and integrations below are finite. Then

\[
\begin{split}
\mathfrak h'(q_t)&\ge2\pi e d T\exp[-2\mathfrak h(q_t)/d]-d\Lambda-\nu\log m_J,\\
\mathfrak h(q_t)&\ge\min\left\{\mathfrak h(q_\tau),
\frac d2\log\frac{2\pi e dT}{d\Lambda+\nu\log m_J}\right\}=:\mathfrak h_*.
\end{split}
\tag{F12}
\]

*Proof.* For the diffusion part, integration by parts gives

\[
\left.\mathfrak h'\right|_{\mathrm{diff}}
=T\sum_j\lambda_j I(f_j)-E_q\operatorname{tr}\nabla^2U_{a,j},
\qquad q(x,j)=\lambda_j f_j(x).
\tag{F13}
\]

For each normalized continuous density $f$, Gaussian LSI and expansion relative to $N(0,\sigma^2I)$ give
$-h(f)+\frac d2\log(2\pi\sigma^2)\le\frac{\sigma^2}2I(f)-d$.
Choosing $\sigma^2=d/I(f)$ proves $I(f)\ge2\pi e d e^{-2h(f)/d}$. Jensen's inequality therefore yields

\[
\sum_j\lambda_j I(f_j)
\ge2\pi e d\exp\left[-\frac2d\sum_j\lambda_jh(f_j)\right]
\ge2\pi e d e^{-2\mathfrak h(q)/d},
\tag{F14}
\]

because $\mathfrak h(q)=H(\lambda)+\sum_j\lambda_jh(f_j)$ and $H(\lambda)\ge0$. The instantaneous $\lambda_j$ are used in F14; none is frozen in time.

For the jump part, write $\mathfrak h(q)=h(q_X)+E_{q_X}H(\theta(\cdot\mid X))$. The continuous marginal is unchanged. Entropy is concave on the categorical simplex, so uniformization gives

\[
\left.\mathfrak h'\right|_{\mathrm{jump}}
\ge\nu E_{q_X}\{H(\theta R)-H(\theta)\}
\ge-\nu\log m_J.
\tag{F15}
\]

Combining F13–F15 proves the first inequality. Its scalar right side is zero at the second value in F12 and positive below it, so comparison gives the floor. QED.

Now let an actual activation retain $(Y,J)$ and discard $Z\in\mathbb R^k$. For any deterministic center $z_*$, suppose $E|Z-z_*|^2\le M_z$. The entropy chain rule and the Gaussian maximum-entropy bound give

\[
\mathfrak h(Y,J)
=\mathfrak h(X,J)-h(Z\mid Y,J)
\ge\mathfrak h_*-\frac k2\log\frac{2\pi eM_z}{k}.
\tag{F16}
\]

The conditioning can only reduce the entropy relative to $h(Z)$, and comparison with $N(z_*,M_zI/k)$ bounds that entropy. If $k=0$, omit its term. This is a statement about the full actual projected density $q(Y,J)$.

For the exact retained optimizer F2, set $S=aH_s$ and
$E_{\mathrm{ret}}=\frac12E[Y^TSY]$.
The model prior has the derived constant
$\pi_{\min}=\min_{a\in[1,2.1],j}\pi_j(a)>0$,
since its finitely many continuous positive priors are fixed by the model. This is not a lower bound on $q(J=j)$ or $q(J=j\mid Y=y)$. Expanding the Gaussian log density in F2 and using F16 proves

\[
\begin{split}
T D(q_{Y,J}\Vert p^s_a)
\le{}&E_{\mathrm{ret}}-T\mathfrak h_*
+\frac{Tk}{2}\log\frac{2\pi eM_z}{k}
+\frac{T(d-k)}2\log(2\pi T)
-\frac T2\log\det S\\
&+T\log(1/\pi_{\min})+TB_0.
\end{split}
\tag{F17}
\]

Thus a label mass tending to zero does not invalidate the activation conversion. No division by that mass occurs in its bound.

## 5. The required actual moments survive arbitrary adapted labels

This step verifies the activation input directly rather than borrowing the old fixed-label conclusion. Let $a(t)$ be a deterministic exact-law parameter path satisfying the stopped bounds of Section 1. At an active level $p$, couple the nonlinear $X$ to the linear companion
$dY=-a(t)H_pYdt+\sqrt{2T}dW$
using the same actual initial state and Brownian motion. Its initial law need not be Gaussian. For every adapted label history, F3 and variation of constants imply

\[
\begin{split}
H_p^{1/2}(X_t-Y_t)
&=-\int_\tau^t H_pe^{-H_p\int_u^t a(v)dv}
             H_p^{-1/2}T\nabla\phi_{p,a_u,J_u}(X_u)du,\\
\sup_{t\ge\tau}|H_p^{1/2}(X_t-Y_t)|
&\le C_L\sqrt T\left[1+\log\frac{\lambda_{\max}(H_p)}{\lambda_{\min}(H_p)}\right].
\end{split}
\tag{F18}
\]

For the second line, integrate $\|H_pe^{-a_-H_pu}\|$ over $u\ge0$, splitting at the inverse largest and smallest eigenvalues. The bounds on its three pieces are respectively $\lambda_{\max}$, $(ea_-u)^{-1}$, and $\lambda_{\min}e^{-a_-\lambda_{\min}u}$. The result is the displayed logarithm. Neither a jump nor a source-conditioned noise covariance appears in this estimate: $X$ is continuous at source events and the force estimate is uniform in $j$.

Let $\mu'=-aH_p\mu$. If at the actual activation

\[
E[(X_\tau-\mu_\tau)(X_\tau-\mu_\tau)^T]
\preceq K_\tau T H_p^{-1},
\tag{F19}
\]

the explicit linear stochastic integral and independence of future Brownian increments give
$E[(Y_t-\mu_t)(Y_t-\mu_t)^T]\preceq(K_\tau+a_-^{-1})TH_p^{-1}$.
Use $vv^T\preceq(v^TH_pv)H_p^{-1}$ for the error in F18. The inequality
$(u+v)(u+v)^T\preceq2uu^T+2vv^T$ then gives

\[
E[(X_t-\mu_t)(X_t-\mu_t)^T]
\preceq C_L\left[K_\tau+\left(1+\log\frac{\lambda_{\max}(H_p)}{\lambda_{\min}(H_p)}\right)^2\right]TH_p^{-1}.
\tag{F20}
\]

For an exact orthogonal retention $P$ from $p$ to $s$, the Gaussian inverse-Schur identity is $PH_p^{-1}P^T=H_s^{-1}$. Projection of the full actual state therefore propagates F19 to the next active level. This uses an unconditional moment matrix of the joint law, summed over its actual labels; a conditional moment bound on every label sheet is neither claimed nor required.

For the prepared normal center $|\mu_0|\le C_LA$ and zero loop center, contraction and orthogonal projection give $|\mu_t|\le C_LA$ and preserve the zero loop center. The retained normal Schur precision after $s$ reductions is at most $C_LJ_{s+1}I$. Induction over at most $L$ activations, with
$\ell=1+|\log T|+\log J_1+|\log A|$,
therefore proves

\[
E_{\mathrm{ret}}(\tau_s)
\le C_L[A^2J_{s+1}+T\ell^2],
\qquad
E\left[\frac12X_t^TH_pX_t\right]
\le C_L[A^2J_{p+1}+T\ell^2].
\tag{F21}
\]

In the second inequality the center is the actual active center after $p$ reductions; the cruder uniform bound replaces $J_{p+1}$ by $J_1$. At $s=L$, set $J_{L+1}=0$; the retained loops still contribute the actual fluctuation term. These are moment estimates for the nonlinear law, not covariance-closure equations.

A nonempty initial class is given by positive label weights and bounded smooth density tilts, allowed to differ across labels, of the Gaussian $N(\mu_0,TH_0^{-1})$. For example,
$q_0(x,j)=\lambda_jG_{\mu_0,T H_0^{-1}}(x)e^{\psi_j(x)}/E_Ge^{\psi_j}$,
where $|\psi_j|\le C_L$ and their derivatives are bounded. This includes label/configuration correlation, verifies F19, and has joint entropy bounded below by $-C_L\ell$ without a lower bound on the chosen positive $\lambda_j$. Strict formation-center restrictions can be intersected with this class separately. They are not needed for the entropy proof.

From F3, $\Lambda\le C_LJ_1$ in F12. The discarded centered moment in F16 is bounded by F20, so all logarithms in F17 cost at most $C_L\ell$ in the polynomial regime of Section 8. Repeated F12 and F16 over finitely many actual activations preserves the same entropy lower bound. Consequently F17 and F21 give the required actual activation budget

\[
H_s(\tau_s):=T D(q^s_{\tau_s}\Vert p^s_{a_{\tau_s}})
\le C_L[A^2J_{s+1}+T\ell^2].
\tag{F22}
\]

This includes the actual conditional label kernel at every level. It does not invoke a sheet-mass entropy conservation law.
At $p=0$, the same bound $H_0(0)\le C_L[A^2J_1+T\ell^2]$ follows directly from the initial Gaussian-tilt preparation and F17 with $k=0$, so the first interface is included.

## 6. The normal-plus-loop dissipation budget with jumps

The exact sheet density F2 has bounded tilt and bounded derivative
$w_j=\partial_a\log\pi_j-\partial_a\phi_{p,a,j}$.
Only one source row changes, and its full-assignment prior score has absolute value at most four. Hence $|w_j|\le M_L$. Put $V_p=x^TH_px/2$. Gaussian scaling gives

\[
E_{p^p_a}e^{aV_p/(2T)}\le R_L:=e^{B_0}2^{d_p/2}.
\tag{F23}
\]

The entropy variational inequality applied to this exponential moment yields
$aE_qV_p\le2H_p+2T\log R_L$ and $aE_{p_a^p}V_p\le2T\log R_L$.
Since
$T\partial_a\log p^p_a=E_{p^p_a}V_p-V_p+T(w_j-E_{p^p_a}w)$,
it follows that

\[
|T E_q\partial_a\log p^p_a|
\le\frac{2H_p}{a}+\frac{4T\log R_L}{a}+2TM_L.
\tag{F24}
\]

At each fixed $a$, the inherited rates are reversible for F2. With $u=q/p_a^p$, their entropy dissipation is
$-\frac T2\int\sum_{j,k}p_a^p(x,j)K^p_{jk}(x,a)(u_j-u_k)(\log u_j-\log u_k)dx\le0$.
Thus they only improve the full relative-entropy budget, even though they can increase the conditional entropy F4. Write
$I_p=\sum_j\int q(x,j)|\nabla\log(q(x,j)/p_a^p(x,j))|^2dx$ and $B(t)=\int_\tau^t|\dot a|/a$.
The diffusion identity, jump dissipation, and F24 imply, for a finite $C_L$,

\[
e^{-2B(t)}[H_p(t)+C_LT]
+T^2\int_\tau^t e^{-2B(u)}I_p(u)du
\le H_p(\tau)+C_LT.
\tag{F25}
\]

On $H_*=2/\epsilon$, the assumed stopped speed bound gives $B(t)\le C_L$. Common-channel actual activation decreases relative entropy at the same parameter. The calibration scalar is retained by the learning equation but is absent from this Fisher-dissipation account. In particular,
$T^2\int_\tau^t I_p(u)du\le C_L[H_p(\tau)+T]$.

For each fixed positive $\epsilon,T$, the initial Gaussian-tail class, the linear-companion representation, and F3 give finite exponential moments on finite intervals. The nondegenerate diffusion and smooth bounded finite-state coupling preserve positive smooth densities at positive times. The entropy calculations can first be made with spatial cutoffs and positive density regularization. The quadratic-moment and exponential-tail bounds remove the spatial boundary terms; F25 supplies locally integrable relative Fisher information for the dissipation limit. Lower semicontinuity gives the displayed inequalities after regularization is removed. Thus no omitted boundary current, conditional-equilibrium preparation, or infinite-horizon ergodicity assumption is used. The existence and stopping argument for the coupled own-law parameter still belongs to the continuation component.

## 7. Actual conditional tracking and complete same-state score

During a continuous part of F1, the exact actual-law conditional balance D19, now summed over the instantaneous retained $(Y,J)$ law, is

\[
\left.\widehat\Delta'\right|_{\mathrm{cont}}
=-T I_Z-T E_r\operatorname{Var}_h(w_Y)
+T E_r[e_Y\cdot E_hw_Y]-\dot a E_re_a,
\tag{F26}
\]

where $w_Y=\nabla_Y\log(q/p_a^p)$, $e_Y=E_h\nabla_Y\log k_{a,j}$, and $e_a=E_h\partial_a\log k_{a,j}$. This identity is obtained by differentiating $D(q\Vert p)-D(r\Vert p_{Y,J})$. It does not suppose that the actual conditional $h$ is fixed as $r$ changes. The jump derivative is a separate linear-generator contribution and is exactly the object bounded in Lemma 1.

For clarity, the constants in the continuous estimate follow as follows. Conditional LSI gives $T I_Z\ge2\lambda_s\widehat\Delta$. Applying that LSI to exponential tilts of each component of $\nabla_Y\log k$ gives
$|E_h\nabla_Y\log k|\le\Gamma_s\sqrt{2D(h\Vert k)/(T\lambda_s)}$.
F7 and the entropy variational inequality give
$|E_h\partial_a\log k|\le\sqrt{2v_0D(h\Vert k)}+b_0D(h\Vert k)$.
Jensen, Cauchy–Schwarz, and Young's inequality bound the $Y$ term in F26 by
$\lambda_s\widehat\Delta/2+T\Gamma_s^2I_Y/\lambda_s^2$
and the model term by
$\lambda_s\widehat\Delta/2+v_0\dot a^2/\lambda_s+b_0|\dot a|\widehat\Delta$.
For sufficiently small $\epsilon$, $b_0|\dot a|\le\lambda_s/2$. Combining these facts with F8, for $C_J=\log m_J+2B_0$, proves

\[
\widehat\Delta'
\le-\frac{\lambda_s}{2}\widehat\Delta
+\frac{T\Gamma_s^2}{\lambda_s^2}I_Y
+\frac{v_0\dot a^2}{\lambda_s}+C_J.
\tag{F27}
\]

Variation of constants, $I_Y\le I_p$, and F25 yield, for $t\ge\tau_p$ within the active interval,

\[
\begin{split}
\widehat\Delta_{p:s}(t)
\le{}&e^{-c_LJ_s(t-\tau_p)}\widehat\Delta_{p:s}(\tau_p)
+C_L\frac{J_{s+1}^2}{T J_s^2}[H_p(\tau_p)+T]\\
&+C_L\frac{\epsilon^2}{J_s^2}
+C_L\frac{C_J}{J_s}.
\end{split}
\tag{F28}
\]

In particular, at successive interface $p=s-1$, F22 and the KL chain bound $\widehat\Delta(\tau_p)\le H_p(\tau_p)/T$ give

\[
\begin{split}
\widehat\Delta_{s-1:s}(t)
\le C_L\bigg[&e^{-c_LJ_s(t-\tau_{s-1})}
                 (R_A^2J_s+\ell^2)
+R_A^2\frac{J_{s+1}^2}{J_s}
+\ell^2\frac{J_{s+1}^2}{J_s^2}\\
&+\frac{\epsilon^2}{J_s^2}+\frac{C_J}{J_s}\bigg],
\qquad R_A=A/\sqrt T.
\end{split}
\tag{F29}
\]

Both mixed-force terms vanish at the last interface. The jump contribution remains there; it has not been mistaken for full VFE dissipation.

For the exact true retention $C_s$, the same normalized scalar and channel give
$F(q,a)-F^s(C_sq,a)=T\Delta^{\mathrm{discarded}}$.
Differentiate at fixed actual $q$ and fixed channel, including every prior, determinant, calibration, and source term. F7 and F5 prove the complete same-state covector bound

\[
|g(q,a)-g_s(C_sq,a)|
\le T\left[\sqrt{2v_0\Delta^{\mathrm{discarded}}}
               +b_0\Delta^{\mathrm{discarded}}\right]
\le C_LT(\sqrt{\widehat\Delta}+\widehat\Delta).
\tag{F30}
\]

If the inherited model metric is $m(a)\ge m_*>0$, the corresponding dual-norm bound is divided by $\sqrt{m(a)}$. The same-state natural-gradient velocity difference is at most $\epsilon m_*^{-1}$ times F30. These do not compare two already separated parameter paths; that requires the own-law continuation and coupling argument.

## 8. One simultaneous accelerated-energy regime

For each fixed finite $L$, choose

\[
Q_L=8,\qquad Q_s=2Q_{s+1}+20,\qquad
J_s=\epsilon^{-Q_s},\qquad
A^2=\epsilon^{3Q_1+20},\qquad
T=A^2\epsilon^6,\qquad
H_*=2/\epsilon,
\tag{F31}
\]

with $0<\epsilon<\epsilon_L$. The coefficient $\delta=B_0/n$ and the redraw rate $\nu=1$ remain fixed. This family is a uniform energy acceleration of the family with exponents $q_s=Q_s-8$: the latter has $q_L=0$, while $J_s=\epsilon^{-8}\epsilon^{-q_s}$. The energy ratios are unchanged by that uniform acceleration. The contrast recursion for this particular weakest-one comparison family is $q_s=2q_{s+1}+28$; it need not be identified with the older recursion N37.

In F31,
$R_A^2=\epsilon^{-6}$,
$J_{s+1}^2/J_s=\epsilon^{20}$ for $s<L$,
and $\ell=O_L(\log(1/\epsilon))$.
After a wait

\[
t-\tau_{s-1}\ge\frac{\kappa_L\log(1/\epsilon)}{J_s},
\qquad c_L\kappa_L>Q_1+14,
\tag{F32}
\]

the initial term in F29 is $O_L(\epsilon^8)$. Its energy-induced mixed term is $\epsilon^{14}$, its second mixed term has exponent at least $56$ times a squared logarithm, and its model-motion term is at most $\epsilon^{18}$. The jump term is at most $C_J\epsilon^8$. Therefore, simultaneously at every one of the finitely many interfaces, including $s=L$,

\[
\widehat\Delta_{s-1:s}(t)=O_L(\epsilon^8),
\qquad
\Delta^{\mathrm{discarded}}_{s-1:s}(t)=O_L(\epsilon^8),
\qquad
|g(q_t,a_t)-g_s(C_sq_t,a_t)|=O_L(T\epsilon^4).
\tag{F33}
\]

These bounds hold uniformly from the indicated wait through the active interval. The sum of the finitely many required waits is $O_L(\epsilon^8\log(1/\epsilon))$, which fits inside $H_*$. Formation times must satisfy these lower waits; this component does not assert their geometric separation merely from that sum. The moment bound also gives $A^2J_1+T\ell^2\to0$, the quantitative input used by the separate learning bootstrap.

The companion [coupled continuation and formation proof](finite-rate-coupled-formation.md), D9, establishes the compact parameter interval and speed used here by a stopped moment argument that does not assume F27. Its common-center preparation, with small label-dependent weighted transport perturbations, satisfies F19 and the entropy preparation above. Its D13 times have $t_s-\tau_{s-1}\ge t_s/2$ for small $\epsilon$. Choosing its $k_L\ge2\kappa_L$ therefore verifies F32 on every formation window $[t_s,2t_s]$. These are direct joins to the constructed family, not further equilibrium assumptions.

The source-history component may use F33 and the exact bounded rates, but F33 alone is not a theorem about conditional jump kernels given an entire observed past. In particular, $H_*\sqrt{\widehat\Delta}=O_L(\epsilon^3)$ is only an available scalar estimate. A proof must still connect it to the actual path filtration or use a different coupling argument.

## 9. Failure tests and the remaining obligation

Full relative-entropy descent does not imply that jumps decrease the discarded conditional KL. An exact finite-state example makes the distinction explicit. Let $Z\in\{0,1\}$, $J\in\{+,-\}$, and use the target from S12:

\[
p(Z=0)=p(Z=1)=\tfrac12,\qquad
b_+(0)=\tfrac14,\qquad b_+(1)=\tfrac34.
\tag{F34}
\]

Then $k_+=(1/4,3/4)$ and $k_-=(3/4,1/4)$. Prepare the actual hidden conditionals exactly at these targets but with label masses $(3/4,1/4)$, so its joint columns are $q_+=(3/16,9/16)$ and $q_-=(3/16,1/16)$. Under the rate-one heat bath, $\dot q_j(z)=q_Z(z)b_j(z)-q_j(z)$. At zero, $\dot q_+=(-3/32,-3/32)$ and $\dot q_-=(3/32,3/32)$. Quotient differentiation gives
$\dot h_+=(-1/16,1/16)$ and $\dot h_-=(-3/16,3/16)$.
The conditional KL starts at zero but its Taylor expansion is

\[
\widehat\Delta(t)
=\frac{t^2}{2}\sum_j\lambda_j\sum_z\frac{\dot h_j(z)^2}{k_j(z)}+O(t^3)
=\frac{t^2}{32}+O(t^3)>0
\tag{F35}
\]

for sufficiently small positive $t$. All entries remain positive, so this expansion has no support singularity. Replacing $1/4,3/4$ by $1/2-\eta,1/2+\eta$ gives leading coefficient $2\eta^2(1-4\eta^2)/3>0$ for every $0<\eta<1/2$, including arbitrarily weak fixed source dependence. This is a finite-carrier discriminator for the claimed monotonicity implication, not a counterexample to the admitted smooth finite-depth existence target.

With the original weakest-strength normalization $J_L=1$ and fixed $\nu=1$, F29 has a terminal upper-bound term $C_LC_J$. It therefore does not prove terminal conditional KL tends to zero. This is a limitation of the estimate, not a lower bound on the actual error and not a nonexistence theorem for that normalization. In particular, at exact joint equilibrium the conditional error and its jump derivative can both be zero.

The strongest result of this component is F22 together with F28–F33: actual marked activation and vanishing conditional and complete same-state score errors for every finite depth in the explicit accelerated-energy regime. Its compact-parameter speed and formation-time interfaces are discharged by the companion D9 and D13 as specified above. It requires no actual source-mass floor, no label reset, no recognition factorization, and no instantaneous source equilibrium. Full source-history comparison remains a separate mathematical obligation for the [history component](finite-rate-source-history-averaging.md), while D15 supplies the independently evolving continuous-path estimate. The next action is a reconstruction of these component joins, including the actual conditional jump kernels along complete histories; full VFE descent by itself cannot discharge that remaining history obligation.
