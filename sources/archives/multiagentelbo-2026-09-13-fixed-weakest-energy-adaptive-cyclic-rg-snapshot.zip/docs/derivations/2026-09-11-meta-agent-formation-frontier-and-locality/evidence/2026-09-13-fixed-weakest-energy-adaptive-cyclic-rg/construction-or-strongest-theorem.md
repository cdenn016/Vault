<!-- rigorous-theory-search-metadata {"schema_version":"rigorous-theory-search/v1","contract_id":"contract-sha256-c574ab277c6be97d9c483ffcc4a76b87fc074d03d184a731b8a4973a7944f952","target_digest":"c574ab277c6be97d9c483ffcc4a76b87fc074d03d184a731b8a4973a7944f952"} -->
# Weakest-one construction

For every prescribed finite L>=2, the admitted nonlinear cyclic model with J_L=1 and source proposal rate one has L actual formations, exact marked actual-law activations, actual source and hidden-kernel changes, vanishing conditional and complete-score errors, O_L(A epsilon^2) continuous-path error and O_L(epsilon^6) complete assignment-history disagreement.

The exact preparation and simultaneous bounds are in proofs/fixed-weakest-energy-completion.md. Consult release.json for the current reconstruction and terminal status.
