# Finite-rate source dynamics: exact descent and the remaining kinetic closure

September 13, 2026. This is the bounded next-phase investigation requested after publication of the [nonlinear adaptive completion](nonlinear-adaptive-attention-completion.md). That construction and its vault ingestion were merged as MultiAgentELBO PR 76 and Vault PR 31; both canonical Desktop checkouts were synchronized before this investigation began. Its completed zero-mobility theorem remains unchanged. The present note derives a candidate with positive source mobility and its exact parent jump rates. It does not claim the complete positive-mobility hierarchy.

## Source continuity and the precise change

The current [STATUS](../../STATUS.md), [RG record](RG-COMPLETION.md), [normalized marked model E24–E29](nonlinear-endpoint-attention-model.md), and [independent reconstruction](nonlinear-adaptive-attention-reconstruction.md) supply the starting point. In that realization the assignment $J$ is retained and fixed, although model-posterior attention changes. The live [PIFB2](<C:/Users/chris and christine/Desktop/Research/manuscripts/PIFB2.tex>) section `sec:mixture_derivation` already motivates source inference and declares its source-independence restriction. [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), `prop:obs-attention-elbo`, `eq:obs-attention-correlated-ledger`, and `eq:obs-attention-replicator`, separates conditional posterior rows, constrained recognition rows, and correlated recognition. The [earlier attention investigation](../../reviews/2026-09-13-program-review-next-phase/attention-admission.md), R9–R11, gives a log-odds lag equation for the constant-row Fisher flow. It does not apply directly to a source-conditioned diffusion with Brownian configuration paths. The live [vault synthesis](<C:/Users/chris and christine/Desktop/Research/wiki/themes/Gauge-VFE RG research synthesis September 2026.md>) now records the fixed-label completion and its restrictions.

There are two different possible continuations. A constrained constant-row Fisher update retains the factorization assumed in Theory/05b and must prove that actual marked activation stays in its recognition family. A jump process on the unrestricted joint state retains arbitrary label/configuration dependence. The latter addresses the activation issue directly, so it is developed here. Its rates are declared inference kinetics; VFE alone does not select them or supply physical time. All work stays at $c_*$ with independent links, retained loops, supplied interaction contrasts, and the same physical model, optimizer, evidence scalar and parameter metric. No base transport is introduced.

## 1. A positive-mobility process for the same normalized joint

Let $x\in\mathbb R^d$, $j\in\mathcal J$, and use the optimizing joint density of E25,

\[
p_a(x,j)=Z_a^{-1}\pi_j(a)\exp[-G_a(x)/T-\phi_j(x)],
\qquad b_j(x,a)=\frac{\pi_j(a)e^{-\phi_j(x)}}{\sum_k\pi_k(a)e^{-\phi_k(x)}}.
\tag{S1}
\]

Here $T>0$, $a\in[1,2.1]$, all source priors are positive, $0\le\phi_j\le B_0$, and the global smoothness, confining quadratic core and force bounds are those of the published finite family. The full assignment row $b$ is the product of the posterior receiver rows at a fixed configuration. The optimizing joint $p_a$ is not relabeled as the physical posterior. Use unrestricted positive joint recognition density $q(x,j)$ with finite VFE and the integrability required by the formulas below.

For fixed $\nu>0$, set

\[
\mathcal L_a f(x,j)=T\Delta_x f-\nabla(G_a+T\phi_j)\cdot\nabla_x f
+\nu\sum_k b_k(x,a)[f(x,k)-f(x,j)].
\tag{S2}
\]

An implementation of the last term uses a Poisson clock of rate $\nu$ and redraws the complete assignment from $b(x,a)$ at a clock event. A redraw may leave the assignment unchanged; self events do not count as jumps. Neither the continuous configuration nor its hidden coordinates are refreshed. For each fixed finite depth the sheet drifts are globally Lipschitz with linear growth, the jump rate is bounded by $\nu$, and the source set is finite. For a given continuous parameter path in the compact interval, interlacing the unique sheet diffusions with the nonexplosive Poisson events constructs this process. This statement does not by itself establish the coupled law-dependent parameter continuation or any uniform small-parameter estimate.

Write $q_X=\sum_jq_j$ and $\eta_j(x)=q_j(x)/q_X(x)$. E25 and the same full parameter covector define

\[
F_T(q,a)=T D(q\Vert p_a)+C_T(a),\qquad
\dot a=-\epsilon m(a)^{-1}g(q,a),\qquad
g(q,a)=a-2+\tfrac12E_qx^THx-\tfrac T2\operatorname{tr}(A_0^{-1}H)
-T\sum_j\lambda_j\partial_a\log\pi_j(a),
\tag{S3}
\]

where $\lambda_j=\int q_j(x)dx$ now varies with time. At fixed $x$, the forward jump equation is $\partial_tq_j|_{\rm jump}=\nu(q_Xb_j-q_j)$. The equality
$p_a(x,j)b_k(x,a)=p_{a,X}(x)b_j(x,a)b_k(x,a)$ is symmetric in $j,k$, so the frozen-parameter jump operator is reversible for the same joint optimizer as the diffusion.

For smooth positive solutions with finite terms and vanishing integration-by-parts boundaries, direct differentiation yields

\[
\frac{dF_T}{dt}=-T^2\sum_j\int q_j\left|\nabla_x\log\frac{q_j}{p_{a,j}}\right|^2dx
-\nu T\int q_X\{D(\eta\Vert b)+D(b\Vert\eta)\}dx
-\epsilon m(a)^{-1}g(q,a)^2.
\tag{S4}
\]

To check the jump term, sum $\nu Tq_X(b_j-\eta_j)\log(\eta_j/b_j)$ over $j$; terms depending only on $x$ cancel. This gives the negative sum of the two categorical KL divergences. The diffusion term follows by integration by parts; the last term is the complete chain rule using S3, so no parameter-dependent normalization is dropped. Equation S4 is an exact descent identity under its stated regularity assumptions. It is not the categorical Fisher replicator equation R9. Reversible finite-chain entropy flows also admit a distinct transport-metric formulation; see [Maas, 2011](https://arxiv.org/abs/1102.5238). Only the elementary calculation above is used here.

## 2. Actual source-mass motion and a conditional quantitative discriminator

Integrating the forward equation gives an identity for every receiver and its selected source,

\[
\dot\lambda_{i,+}=\nu(E_{q_X}b_{i,+}(X,a)-\lambda_{i,+}),\qquad
\lambda_{i,+}(t)=e^{-\nu t}\lambda_{i,+}(0)
+\nu\int_0^t e^{-\nu(t-u)}E_{q_{X,u}}b_{i,+}(X,a_u)du.
\tag{S5}
\]

This describes actual recognition-mass movement; it does not replace $\eta(x)$ by $b(x,a)$. For the distinguished receiver the bounded source costs give, for every $x$,

\[
\operatorname{sigmoid}(4(a-3/2)-\delta)\le b_{i,+}(x,a)
\le\operatorname{sigmoid}(4(a-3/2)+\delta).
\tag{S6}
\]

For a concrete conditional discriminator take $\nu=1$, $H_*=2/\epsilon\ge10$, and prepare $\lambda_{i,+}(0)=\operatorname{sigmoid}(-2)$. If the actual coupled solution satisfies $a_t\ge7/4$ on $[H_*-10,H_*]$, then S5–S6 imply

\[
\lambda_{i,+}(H_*)-\lambda_{i,+}(0)
\ge(1-e^{-10})\operatorname{sigmoid}(1-\delta)-\operatorname{sigmoid}(-2)
>\frac12.
\tag{S7}
\]

The bound uses only nonnegativity of the earlier contribution to S5. Here $\delta=B_0/n<10^{-4}$. For an elementary lower estimate, $e^{1-\delta}>1+(1-\delta)+(1-\delta)^2/2>2.49$, $e^2>7$, and $e^{10}>2^{10}$. Thus the right side is larger than $(1-2^{-10})(249/349)-1/8>1/2$. For a binary receiver row this is its total-variation change. Establishing the assumed actual parameter interval for the coupled switching process is a continuation obligation, not something S7 obtains from the zero-mobility theorem by citation.

## 3. The exact inherited jump rates

Use the same orthogonal retained continuous coordinate $y=P_sx$, hidden coordinate $z$, and retained full assignment $j$. Disintegrate

\[
p_a(y,z,j)=s_a(y,j)k_{a,j}(z\mid y),\qquad
q(y,z,j)=r(y,j)h_j(z\mid y).
\tag{S8}
\]

For $k\ne j$ define the optimizer-conditioned rate and conductance

\[
\overline K_{jk}^a(y)=\nu\int k_{a,j}(z\mid y)b_k(y,z,a)dz,\qquad
c_{jk}^a(y)=s_a(y,j)\overline K_{jk}^a(y).
\tag{S9}
\]

The complete row is conservative by choosing its diagonal as minus the sum of its off-diagonal entries. Each exit rate is at most $\nu$. Integrating the detailed-balance identity preceding S4 gives $c_{jk}=c_{kj}$. Consequently the parent with its exact sheet diffusion and S9 decreases its own full E29 VFE; the categorical dissipation, writing $u_j=r_j/s_j$, is

\[
-\frac T2\int\sum_{j,k}c_{jk}(u_j-u_k)(\log u_j-\log u_k)dy\le0.
\tag{S10}
\]

This is obtained by swapping $j,k$ in one copy of the entropy derivative and averaging. The parameter equation still uses that parent's own full covector and inherited metric. This autonomous parent prescription is admissible, but it is not asserted to be the exact temporal projection of S2.

Nested retentions compose these optimizer-conditioned rates exactly at fixed $a$: if $y$ is subsequently reduced to $v$, then

\[
E_{p_a}[\overline K_{jk}^a(Y)\mid V=v,J=j]
=\nu E_{p_a}[b_k(X,a)\mid V=v,J=j].
\tag{S11}
\]

This is the conditional-expectation tower on the same normalized joint. Static physical, optimizing and actual laws still push forward through the same fixed marked channels. At an actual activation the parent starts from the full current $r(y,j)$, including its actual source conditional; no label reset or refactorization is required. Neither S11 nor static channel composition identifies independently evolved parent histories with projected fine histories.

Even a two-point hidden space disproves regeneration of a parent heat bath. Let $p_X(0)=p_X(1)=1/2$, with $b_+(0)=1/4$ and $b_+(1)=3/4$. The joint $p(x,j)=p_X(x)b_j(x)$ is positive and normalized. Its source marginal is $s_+=s_-=1/2$, but

\[
\overline K_{+-}=\frac{\nu E_{p_X}(b_+b_-)}{s_+}=\frac{3\nu}{8},
\qquad K^{\rm regenerated}_{+-}=\nu s_-=\frac\nu2.
\tag{S12}
\]

Their difference is $\nu/8$, including at the common invariant joint. Moreover the fine exit rate is $3\nu/4$ or $\nu/4$ at the two hidden points in the same retained $+$ fiber. Therefore strong lumpability fails. This finite example is a kinetic discriminator, not a member of the smooth small-deformation family. For any binary posterior row on a hidden carrier the same calculation gives $\overline K_{+-}=\nu(1-s_+)-\nu\operatorname{Var}_{p_X}(b_+)/s_+$, since $E b_+^2=s_+^2+\operatorname{Var}(b_+)$. Hence a nonconstant posterior already separates these rates at arbitrarily small positive variance. The example concerns kinetics, not failure of normalized marginalization or of the completed fixed-label theorem.

## 4. What remains to prove

The instantaneous actual outgoing rate is $K^q_{jk}(y)=\nu E_{h_j}b_k$. For a test function $f(y,j)$ with $\lVert f\rVert_\infty\le1$, the categorical generator discrepancy averaged under $r$ obeys

\[
\left|E_r[(K^q-\overline K)f]\right|
\le\nu\sqrt{2\Delta},\qquad
\Delta=\sum_j\int r(y,j)D(h_j\Vert k_{a,j})dy.
\tag{S13}
\]

Indeed the bounded function $\sum_k b_k(y,z)f(y,k)$ lies in $[-1,1]$, the diagonal test term cancels, total variation bounds the difference of its expectations by twice total variation, and Pinsker plus Jensen gives S13. This is a same-time marginal generator estimate. On a horizon $2/\epsilon$, a uniform $\Delta\le C\epsilon^2$ would bound its accumulated magnitude only by a constant. It would not prove a vanishing error by this estimate. A jump-history comparison additionally conditions on the retained past, whereas S13 uses only the current retained state.

The two unresolved estimates are therefore specific. First, derive the conditional-entropy balance for the coupled diffusion and jumps, including the source transitions between different optimizing hidden kernels, and close it at every actual activation. Full VFE descent S4 alone does not imply that this conditional entropy decreases. Second, control integrated jump hazards or solve the fast hidden Poisson equation on the common learning horizon, including the parent parameter discrepancy and retained-history dependence. Directly comparing pointwise rates over that horizon can pay a nonvanishing hidden-rate variance even at conditional equilibrium. The fast hidden mixing must enter a proof of averaging; matching invariant laws cannot replace it.

The uniform sheet force bound survives an arbitrary adapted assignment path, so the commuting linear-companion moment argument is a concrete starting route for the coupled parameter bound needed by S7. It must be written for switching paths and for the exact parent rates before using it as a theorem. The preparation and entropy analysis previously conditioned on fixed sheet masses; those steps need rederivation. Once these interfaces are controlled, the existing finite-depth formation geometry and exact parent-law construction can be reused only through their stated uniform bounds. No new hierarchy theorem, physical clock or computational saving is claimed here.

This investigation stops at the explicit generator, descent identity, conditional source-mass discriminator, recursively inherited rates, and exact regeneration counterexample. The next decisive task is the mixed continuous/discrete conditional-entropy and integrated-hazard bound at the first elimination, with $\nu=1$ fixed. A successful estimate must then be propagated through the existing finite-depth actual-activation scheme. A vanishing rate chosen merely to recover fixed labels would not address this proposed strengthening.
