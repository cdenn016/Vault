# Finite-rate cyclic formation with the weakest energy fixed at one

September 13, 2026. Joined construction for the [frozen weakest-one target](evidence/2026-09-13-fixed-weakest-energy-adaptive-cyclic-rg/problem-contract.json), digest `c574ab277c6be97d9c483ffcc4a76b87fc074d03d184a731b8a4973a7944f952`. The [release record](evidence/2026-09-13-fixed-weakest-energy-adaptive-cyclic-rg/release.json) states whether the component derivations and separate reconstruction have completed. The preceding [accelerated construction](finite-rate-adaptive-completion.md) retains its original scope.

## Statement and assumptions

For every prescribed finite depth $L\ge2$, the normalized triangle-chain model has a nonempty positive-temperature family and a declared neighborhood of positive smooth correlated initial laws with $L$ actual successive coalescence episodes, exact normalized marked parents, positive-rate actual source learning and controlled reduction errors. Each parent retains every source assignment and loop and activates from the complete preceding actual retained law and parameter. Its later natural-gradient model update uses its own complete actual-law covector and inherited metric. Continuous microscopic mobility and source-assignment proposal rate are both one.

Use

\[
Q_L=0,\qquad Q_s=2Q_{s+1}+20,\qquad J_s=\epsilon^{-Q_s},\qquad
A^2=\epsilon^{3Q_1+20},\qquad T=A^2\epsilon^6,\qquad H_*=2/\epsilon.
\tag{Z1}
\]

The weakest energy is $J_L=1$ for every $\epsilon$; no common acceleration factor is added. The nonlinear source coefficient remains fixed at $\delta=10^{-4}/n$. Internal-neighbor source support, supplied energy contrasts, calibration-assisted scalar learning, compatible root observation, proper correlated prior and the common-center preparation from W1 are explicit assumptions. The initial-law neighborhood may shrink with $\epsilon$ and depend on finite $L$. All source rows are part of the same normalized joint experiment.

The carrier is at one base point $c_*$ in the declared principal/associated-bundle model. Independent translation links retain network holonomy. There is no base transport, spatial descent or physical-time identification. The diffusion and jump prescription is one VFE-descending inference realization; VFE alone does not select unique kinetics.

## Proof interfaces

[W2–W7](fixed-weakest-energy-continuation.md) establish the exact normalized parent rates and complete model score, local coupled construction, stopped moments, inward parameter continuation and own-law parameter comparison. They use $J_L\ge1$, not growing $J_L$. No entropy-matching or averaged-law assumption is used to prove those inputs. The inherited rates remain optimizer-conditioned expectations of the original microscopic row; they are not regenerated parent heat baths.

The [conditional component](fixed-weakest-energy-conditional-entropy.md) uses two distinct mechanisms. Before the terminal reduction, the existing conditional entropy balance retains its explicit source-jump input, but $J_s\to\infty$ for $s<L$. At the terminal reduction, diffusion and source jumps jointly dissipate the complete joint relative entropy at a rate bounded below independently of $\epsilon$. This full-state contraction includes the positive-rate source entropy term. The complete normalized parameter score controls its moving-target contribution. Exact actual-law projection cannot increase this joint relative entropy at the same current parameter.

Choose a sufficiently large finite $k_L$, satisfying conditional entrance C23, geometric decay and fast-history mixing U34, and activate on W9:
$I_s=[t_s,2t_s]$, $t_s=k_L\log(1/\epsilon)/J_s$, $\tau_s=2t_s$.
The first $L-1$ windows shrink; the final window has order $\log(1/\epsilon)$ and remains small compared with $H_*$. On their active intervals, the resulting bounds are

\[
\Delta_{s-1:s}=
\begin{cases}
O_L(\epsilon^{14}),&s<L,\\
O_L(\epsilon^2),&s=L,
\end{cases}
\qquad
|g_{s-1}(q,a)-g_s(C_sq,a)|
=
\begin{cases}
O_L(T\epsilon^7),&s<L,\\
O_L(T\epsilon),&s=L.
\end{cases}
\tag{Z2}
\]

These are actual conditional KL and complete same-state score comparisons, not entropy claims inferred from path proximity. The score identity keeps source-prior, hidden determinant, normalizer and evaluator-restriction terms.

W8–W9 give successive separated residual margins outside the stated exponentially small exceptional probability. The upper source forcing envelope W10–W11 is needed because the terminal activation is no longer $o(1)$. It bounds the actual source mass before every activation even when many jumps have occurred. W12 then proves that the actual distinguished binary source row changes by total variation greater than $1/2$ from any activation to $H_*$. E23 and W7 give changes greater than $1/200$ for both first hidden physical and optimizing conditionals at a fixed retained input and label. Physical and optimizing kernels remain distinct.

The [source-history component](fixed-weakest-energy-source-histories.md) uses an exact static identity and a separate dynamic estimate. Because the nonlinear source terms depend only on the first normal layer and loops, integrating all later normal layers through the triangular residual coordinates leaves the same normalized fast marginal. Its average proposal row is exactly the full optimizer's average at every retained level. This identity alone is not temporal averaging. Contractive fast-coordinate estimates bound the effect of the actual evolving remaining normals on microscopic and inherited parent rates; pointwise fast mixing and conditional proposal-prefix comparison then control entire histories, preserving the common actual activation sample.

Together those estimates provide

\[
\Pr\{\text{any assignment-history disagreement on }[\tau,H_*]\}
=O_L(\epsilon^6),
\qquad
\Pr\left\{\sup_{\tau\le t\le H_*}|P_sX_t-\overline X_t|
>C_LA\epsilon^2\right\}
\le C_L(1+H_*)e^{-c_L/\epsilon^2}.
\tag{Z3}
\]

The second statement follows from W13 under a coupling compatible with the first, using correct marginal linear references and a union bound. It is not total variation convergence of continuous path laws. A finite sequence of actual replacements changes only the finite-depth constants.

For $L=2$, two triangles joined by one bridge give $6\to2\to1$ agents and $19\to9\to8$ continuous coordinates, with both loops and all 64 source assignments retained. Z1 gives $J_1=\epsilon^{-20}$, $J_2=1$, $A=\epsilon^{40}$ and $T=\epsilon^{86}$. The same preparation, entrance constants and learning horizon meet all bounds simultaneously for sufficiently small $\epsilon$.

## Scope

This construction removes the growing-weakest-energy assumption from the preceding positive-rate result. It retains the explicitly supplied contrast hierarchy and internal source support. Formation completes on logarithmic time while the order-one model and recognition change occurs on $1/\epsilon$; it does not establish that source learning creates the supplied energy hierarchy.

The proof does not assert arbitrary mixed-level source support, arbitrary initial conditions, a unique merger sequence, an infinite-depth limit, permanent membership under arbitrary later forcing, computational savings or a physical clock. Exact probability composition, actual conditional entropy, continuous trajectory approximation and complete assignment-history comparison are separate results. The separate reconstruction and bound record, rather than an agreement count or numerical experiment, determine the completed mathematical scope.
