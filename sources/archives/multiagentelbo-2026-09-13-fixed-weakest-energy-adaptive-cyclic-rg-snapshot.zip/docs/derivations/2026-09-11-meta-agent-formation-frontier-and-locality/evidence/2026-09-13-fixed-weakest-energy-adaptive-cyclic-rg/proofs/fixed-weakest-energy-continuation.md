# Continuation and formation with weakest energy one

September 13, 2026. This is the continuation component of the [fixed weakest-energy contract](evidence/2026-09-13-fixed-weakest-energy-adaptive-cyclic-rg/problem-contract.json), digest `c574ab277c6be97d9c483ffcc4a76b87fc074d03d184a731b8a4973a7944f952`. It checks which parts of the [positive-rate continuation](finite-rate-coupled-formation.md) survive without common energy acceleration and supplies the missing terminal-activation source-mass argument. Conditional entropy and entire source histories remain separate proof obligations.

The starting sources are the normalized marked model [E24–E29](nonlinear-endpoint-attention-model.md), exact finite-rate identities [S1–S13](finite-rate-source-dynamics-investigation.md), the fixed geometric flag [F3–F10](nonlinear-cyclic-formation-route.md), and the previous separate reconstruction [R10–R20 and R28–R38](finite-rate-independent-reconstruction.md). Live PIFB2, `sec:mixture_derivation`, and [Theory/05b](../../../Theory/05b_local_collective_elbo.tex), `prop:obs-attention-elbo` and its correlated-recognition ledger, distinguish posterior source inference from actual recognition and from constrained constant-row learning. Those distinctions are retained.

## 1. Fixed family and exact inherited processes

For each finite $L\ge2$, use the same $b=2^{L-1}$ triangles, $n=3b$ vertices, $4b-1$ independent translation links, root $K$, loop space $H_h$ and normal flag $N=N_0\supset N_1\supset\cdots\supset N_L=0$. The full finite assignment set is $\mathcal J$ with $|\mathcal J|=2^n$. The channels keep $K$, every loop and every assignment, and remove only the specified normal layers. Work at the fixed base point $c_*$. This is a pointwise specialization of the declared bundle model, not a replacement of its ambient types.

The regime is

\[
Q_L=0,\qquad Q_s=2Q_{s+1}+20,\qquad J_s=\epsilon^{-Q_s},\qquad
A^2=\epsilon^{3Q_1+20},\qquad T=A^2\epsilon^6,\qquad H_*=2/\epsilon.
\tag{W1}
\]

Thus $J_L=1$ exactly. The microscopic continuous mobility and full-assignment proposal rate are both one. Keep $B_0=10^{-4}$, $\delta=B_0/n$, the original smooth bounded source costs $\phi_j$, the distinguished prior $\pi_{i,+}(a)=\operatorname{sigmoid}(4(a-3/2))$, the compatible root observation, the normalized evaluator experiment and calibration record. There is no further kinetic or likelihood scaling.

Use the common normal center $Av_0$ in the strict-margin neighborhood of F31, zero loop center, covariance $T\widehat K_1^{-1}$, and the independent common equilibrium root factor. Initial assignment masses have $|\lambda_{i,+}(0)-\operatorname{sigmoid}(-2)|<10^{-2}$. The allowed sheet-dependent perturbations obey the D1 weighted transport bound $\epsilon\sqrt T$ and a bounded log-density ratio. This is a nonempty neighborhood of positive smooth correlated laws: sufficiently small compactly supported smooth transport maps in standardized coordinates provide examples. Its size may depend on $\epsilon$ and finite $L$. The actual evolving law is not restricted to that Gaussian preparation class.

The optimizing marginal at level $p$ has exact sheet potential and generator

\[
\begin{split}
V_{p,j}(x,a)&=\frac a2x^TH_px+C_p(a)+T\psi_{p,j}(x,a),\\
\psi_{p,j}&=-\log E_{\gamma_{p,a}(\cdot\mid x)}e^{-\phi_j},
\qquad 0\le\psi_{p,j}\le B_0,\qquad C_p'(a)=Td_p/(2a),\\
R^p_{jk}(x,a)&=E_{\Pi_a}[b_k(X,a)\mid P_pX=x,J=j],\\
\mathcal L^p_af&=T\Delta f-\nabla V_{p,j}\cdot\nabla f
+\sum_kR^p_{jk}(f_k-f_j).
\end{split}
\tag{W2}
\]

Here $d_p$ is the cumulative eliminated dimension; the separate root terms are unchanged. The self-proposal entries are retained, so rows sum to one and the Poisson clock has rate one. Since $b_k\ge e^{-B_0}\min_a\pi_k(a)>0$, every inherited row has the same finite-depth positive lower bound. S9–S11 prove detailed balance and exact nested composition by the conditional-expectation tower. Replacing this row by a new coarse heat bath would change the process.

At activation, both the full retained actual joint law and the actual parameter are projected or copied exactly. Each autonomous parent subsequently uses its own actual law in the complete covector

\[
g_p(q,a)=a-2+\frac12E_qX^TH_pX+\frac{Td_p}{2a}
+TE_q\partial_a\psi_{p,J}
-\frac T2\operatorname{tr}(A_0^{-1}H)
-TE_q\partial_a\log\pi_J(a),
\qquad
\dot a=-\epsilon m(a)^{-1}g_p(q,a).
\tag{W3}
\]

The scalar inherited metric is $m=TM$, as in E18. Formula W3 is a partial derivative at fixed actual $q$ and includes all source, hidden determinant and prior-normalizer terms. Changing source masses is not an additional term in that partial derivative. The physical posterior and the restricted optimizer retain their distinct precision and scalar formulas.

## 2. Local existence and uniform continuation

The following argument uses only $J_1\ge\cdots\ge J_L\ge1$, not $J_L\to\infty$. The weighted flag comparison F6 and its Schur variational characterization F8 give
$c_LI\preceq H_p\preceq C_LJ_1I$. The proper prior precision $A_0=aH+P_K-TR$ remains positive on $a\in[1,2.1]$ for small $\epsilon$: $R$ is a fixed finite operator and $T\to0$. Its trace scores remain bounded. Gaussian domination, the bounded source tilt and its bounded standardized derivatives yield

\[
|H_p^{-1/2}T\nabla\psi_{p,j}|\le C_L\sqrt T,\qquad
c_LH_p\preceq\nabla^2V_{p,j}\preceq C_LH_p,\qquad
|\partial_a\psi_{p,j}|\le C_L,\qquad
1\le m(a)\le1+C_LT,\quad |m'(a)|\le C_LT.
\tag{W4}
\]

These are D2–D4 and the marked versions of F16–F17; none uses accelerated weakest energy. Differentiating the hidden Gaussian score proves the parameter bound because its centered standardized quadratic moments are independent of $T$ and stiffness. Exact marginal Hessians include the covariance correction.

For each fixed positive instance, W4 gives smooth globally Lipschitz sheet drifts with linear growth. The rates and their derivatives are bounded for that instance. Interlacing sheet diffusions at the bounded Poisson clock constructs the unique nonexplosive process for a prescribed continuous parameter path. To close the law dependence, the D5 argument differentiates its backward expectation of a smooth polynomial-growth observable. Conditional on the Poisson grid, flow derivatives are bounded on compact time intervals and derivatives of rate weights are bounded by constants times those weights because every rate has a positive lower bound. Poisson exponential moments and diffusion polynomial moments justify summing the differentiated terms. The resulting backward function and gradient have polynomial growth. Ito's formula and localization then give
$|E_a f(X_t,J_t)-E_{\widetilde a}f(X_t,J_t)|\le C\int_0^t|a-\widetilde a|ds$.
The explicit parameter dependence of the score adds a local Lipschitz term. Picard contraction supplies the local coupled law and coefficient. These local constants need not be uniform in $\epsilon$.

For continuation stop only at a possible exit of $a$ from $[1,2.1]$. Couple each actual process to its linear reference with the same actual deterministic coefficient, common preparation reference and Brownian motion. The label path is unrestricted. With $e=X-X_G$, W4 gives

\[
\frac d{dt}|e|^2\le-e^TH_pe+C_LT,\qquad
\sup_{t\le H_*}|e_t|\le |e_0|+C_L\sqrt{TH_*},\qquad
\sup_t|H_p^{1/2}e_t|\le C_L\sqrt T\ell_\epsilon,
\quad \ell_\epsilon=1+\log(1/\epsilon).
\tag{W5}
\]

A source jump leaves both continuous states unchanged. The last estimate follows by variation of constants and
$\int_0^\infty\|H_pe^{-H_pu}\|du\le C_L[1+\log(J_1/J_L)]$.
Split the integral at $1/(C_LJ_1)$ and $1/(c_LJ_L)$ to obtain the constant, logarithmic and tail terms. With $J_L=1$, the bound is still $C_L\ell_\epsilon$. At each actual projection Euclidean norm contracts and Schur energy does not increase. A finite number of inherited preparation errors only changes $C_L$.

The covariance barrier $\Sigma_G\preceq C_LT H_p^{-1}$ holds for every $a\ge1$ without a bound on $\dot a$, and is preserved by projection using the Schur inverse identity. The reference normal mean is $O_L(A)$ and its loop mean is zero. Hence

\[
E_qX^TH_pX\le C_L[A^2J_{p+1}+T\ell_\epsilon^2],\qquad
E_q|X|^2\le C_L[A^2+T\ell_\epsilon^2],\qquad
J_1E_q|X_{H_h}|^2\le C_LT.
\tag{W6}
\]

Use $J_{L+1}=0$ in the energy bound. The loop estimate follows separately from its scalar quadratic rate $aJ_1$ and nonlinear force bounded by $C_L\sqrt{TJ_1}$. The full force bound alone would give an unnecessary logarithmic loss there.

Combining W3 and W6 proves, before any assumed slow-learning estimate,

\[
r_\epsilon=A^2J_1+T\ell_\epsilon^2,\qquad
\dot a=\epsilon(2-a)+O_L(\epsilon r_\epsilon),\qquad
1\le a(t)\le2.1,\qquad
|\dot a|\le C_L\epsilon,\qquad
\sup_{t\le H_*}|a_p(t)-(2-e^{-\epsilon t})|\le C_Lr_\epsilon.
\tag{W7}
\]

The vector field points inward at both endpoints for small $\epsilon$, excluding the stopped exit. The moment bounds exclude explosion. Variation of constants proves the last estimate; parent activation copies the actual source coefficient and adds only a finite inherited discrepancy. This extends every coupled process through $H_*$. In W1, $r_\epsilon=O_L(\epsilon^{2Q_1+20})$ up to a smaller logarithmic term. In particular, every process has $a\ge7/4$ throughout the last ten units of the horizon for small $\epsilon$. Conditional entropy or history averaging is not used to obtain W7.

## 3. Formation windows and the terminal activation correction

The strict-margin vector and the weighted linear comparison from D11 do not depend on the accelerated normalization. Before the $s$th activation the current and future reference means satisfy
$|Eu_t|\le C_LA[e^{-c_LJ_s(t-\tau_{s-1})}+J_{s+1}/J_s]$
and
$|EP_sX_G(t)-AP_sv_0|\le C_LAJ_{s+1}t$.
The Gaussian maximum estimate needs only the uniform precision lower bound $c_L$:

\[
\Pr\{\sup_{t\le H_*}|X_G(t)-EX_G(t)|>\rho A\}
\le C_L(1+H_*)\exp[-c_L\rho^2A^2/T].
\tag{W8}
\]

Its proof applies Ito's formula to an exponential quadratic with coefficient below $c_L$, then uses stopping, the Gaussian initial exponential moment and projection contraction. Bounds on all higher stiffnesses are unnecessary: their negative contribution to the generator absorbs the additional quadratic variation. This is the same calculation as D12 at the lower bound $J_L=1$.

Choose a fixed finite $k_L$ large enough for the geometric and conditional entrance estimates proved in the companion component, and put

\[
t_s=k_L\log(1/\epsilon)/J_s,\qquad I_s=[t_s,2t_s],\qquad
\tau_s=2t_s.
\tag{W9}
\]

For $s<L$, $J_{s+1}t_s\to0$ and $\tau_{s-1}<t_s/2$. At $s=L$ there is no future normal block and
$t_L=k_L\log(1/\epsilon)$.
Although this last window no longer tends to zero, $\tau_L/H_*\to0$ and it precedes the final learning interval. On each window W5, W8 and the strict margins imply that formed residuals are smaller than a fixed $\eta_LA$ and future bridges are larger than a fixed $m_LA/3$, outside probability $C_L(1+H_*)e^{-c_L/\epsilon^6}$. Final coherence persists through $H_*$. All source paths are allowed in W5, so the many proposals before the terminal formation do not invalidate this comparison.

The earlier D4 claim that activation changes source masses by at most $\tau_L=o(1)$ is unavailable here. Replace it by the exact source envelope. Let $\lambda(t)$ be the actual distinguished binary mass on a fine process, any autonomous parent, or a lineage. W2 averages the microscopic S6 bounds, so

\[
\lambda'(t)=\zeta(t)-\lambda(t),\qquad
\operatorname{sigmoid}(4(a(t)-3/2)-\delta)
\le\zeta(t)\le
\operatorname{sigmoid}(4(a(t)-3/2)+\delta).
\tag{W10}
\]

Projection does not change $\lambda$, so variation of constants holds through all activations. For $t\le\tau_L$, W7 gives $a(t)\le1+C_L\epsilon\log(1/\epsilon)+C_Lr_\epsilon$. Therefore, including the initial tolerance,

\[
\lambda(\tau_s)\le\operatorname{sigmoid}(-2)+10^{-2}+\delta/4
+O_L(\epsilon\log(1/\epsilon)+r_\epsilon),
\quad 0\le s\le L.
\tag{W11}
\]

Indeed a solution of $\lambda'=\zeta-\lambda$ cannot exceed the larger of its initial value and the supremum forcing envelope. No small bound on the number of proposals is assumed. On the last ten units, W7 and W10 give
$\lambda(H_*)\ge(1-e^{-10})\operatorname{sigmoid}(1-\delta)$.
Subtract W11. The conservative rational bounds in S7 leave more than $0.08$ above $1/2$, so the $10^{-2}$ tolerance, fixed $\delta<10^{-4}$ and vanishing remainder preserve

\[
\lambda(H_*)-\lambda(\tau_s)>1/2,\qquad 0\le s\le L.
\tag{W12}
\]

This is actual recognition-source movement, including when measured from a parent's activation. It is not a statement about a model posterior row substituted into the recognition law.

The first hidden physical and optimizing kernels each change by KL greater than $1/200$ between $a=1$ and the final $a\ge7/4$, uniformly at the same retained input and source label, by E23. The required bounded tilt and precision increase are unchanged: $-TR$ remains a vanishing correction and the normal scale grows with $a$. This compares normalized kernels, without resetting any actual hidden law.

For $L=2$, use triangles $(1,2,3)$ and $(4,5,6)$ and bridge $(3,4)$. There are $19\to9\to8$ continuous coordinates and $6\to2\to1$ agents, with both loops and all 64 source assignments retained. W1 becomes $J_1=\epsilon^{-20}$, $J_2=1$, $A=\epsilon^{40}$ and $T=\epsilon^{86}$. The two windows have orders $\epsilon^{20}\log(1/\epsilon)$ and $\log(1/\epsilon)$.

## 4. Continuous path comparison and remaining interfaces

For a source and its exact parent, activate with the same full actual retained sample and parameter. The Gaussian current/future variation-of-constants comparison D14 uses only the weighted flag and gives error
$C_LA[J_{s+1}/J_s+H_*J_{s+1}^2/J_s]$.
The second term equals $2C_LA\epsilon^{19}$ for every $s<L$ under W1; at the terminal interface the future normal block is absent. Different own-law parameters add $C_LAr_\epsilon$: the homogeneous energy estimate integrates the reference mean's energy, rather than multiplying by the largest stiffness and the full horizon. W5 adds at most $C_LA\epsilon^{5/2}$, and W8 at $\rho=\epsilon^2$ controls each marginal reference fluctuation. Therefore

\[
\Pr\left\{\sup_{\tau_s\le t\le H_*}
|P_sX_t-\overline X_t|>C_LA\epsilon^2\right\}
\le C_L(1+H_*)e^{-c_L/\epsilon^2}.
\tag{W13}
\]

A finite number of replacements changes only $C_L$. Couple the independent root sectors identically. The actual common sample at activation is preserved; the linear references only provide estimates and are not new initialization laws.

W13 is compatible with a coupling of entire source histories once that coupling has been constructed: augment each correct marginal process by its own reference as above. Each marginal concentration event keeps its probability under any coupling, and W5 is valid for arbitrary adapted source paths. A union bound gives W13 on that history coupling without imposing a common Brownian motion after conditioning on a source history. This supplies a uniform-coordinate metric estimate, not total variation convergence of continuous path measures.

This component proves the typed model, exact inherited processes, own-law continuation, actual source and hidden-kernel movement, formation, and the conditional compatibility of the continuous estimate. The [conditional entropy component](fixed-weakest-energy-conditional-entropy.md) and [source-history component](fixed-weakest-energy-source-histories.md) must supply their respective estimates and entrance constants before the frozen conjunction can close. The final joined construction and its separate reconstruction determine that status. No simulation, production implementation, resource-saving claim, infinite-depth limit or physical-clock conclusion is supplied here.
