# Coupled continuation and formation with positive source mobility

September 13, 2026. This component addresses the positive-rate continuation left open by [S1–S13](finite-rate-source-dynamics-investigation.md). It uses the normalized marked model [E24–E29](nonlinear-endpoint-attention-model.md), the fixed-point cyclic carrier and weighted flag [F3–F10](nonlinear-cyclic-formation-route.md), and the frozen contract `2f673c3806f5838530bd025b43174018904da19fe6af74fc8c24ae2e7bcf3e09`. The label mobility is one. The complete source-history and conditional-entropy arguments are separate components linked below.

## 1. Explicit family and preparation

Fix finite $L\ge2$, $b=2^{L-1}$ triangles, $n=3b$ vertices and $E=4b-1$ independent links. Use $x=(u,v,\alpha)$, the residuals $d_i=u_i-v_i$, $r_e=u_i-u_j-\alpha_e$, the orthogonal decomposition $N\oplus H_h\oplus K$, and all fixed marked retentions $(P_s,\operatorname{id}_{\mathcal J})$ of F3–F10. The source set consists of all binary internal-neighbor assignments, so $m=|\mathcal J|=2^n$. Every loop coordinate in $H_h$ survives. Take $B_0=10^{-4}$ and $\delta=B_0/n>0$. The source costs are the nonquadratic functions $\phi_j=\delta\sum_i(1-e^{-J_1r_{i,j_i}^2/(2T)})$. The distinguished generative row is $\pi_{i,+}(a)=\operatorname{sigmoid}(4(a-3/2))$; the other rows are fixed and strictly positive.

Unlike the predecessor normalization $J_L=1$, this family has

\[
Q_L=8,\qquad Q_s=2Q_{s+1}+20,\qquad J_s=\epsilon^{-Q_s},\qquad
A^2=\epsilon^{3Q_1+20},\qquad T=A^2\epsilon^6,\qquad H_*=2/\epsilon.
\tag{D1}
\]

All continuous microscopic mobilities are still one and the full-assignment Poisson proposal rate is one. Increasing the weakest energy to $J_L=\epsilon^{-8}$ is an additional separation assumption. It is not a result for the predecessor $J_L=1$ family, nor a vanishing source rate. The fixed standardized nonlinear tilt remains $\delta$, and the exact normalized physical prior, evaluator, source-success records, root observation and calibration record are E1–E10 with these new positive energies. In particular $A_0=aH+P_K-TR$ is positive on $1\le a\le2.1$ for small $\epsilon$: $R$ is a fixed finite positive operator on the first normal layer, whereas $H|_{K^\perp}\succeq c_LJ_LI$. Its trace scores and their derivatives are bounded by constants depending on $L$. No physical posterior is identified with the restricted-VFE optimizer.

On every initial sheet use the Gaussian with common normal mean $Av_0$, zero loop mean, and covariance $T\widehat K_1^{-1}$. The root has the common equilibrium Gaussian of the compatible root observation, independent of the normal variables and label. The common $v_0$ lies in a fixed small neighborhood of the explicitly constructed strict-margin vector F31. The positive initial assignment masses lie in a sufficiently small neighborhood of the product prior at $a=1$, so $|\lambda_{i,+}(0)-\operatorname{sigmoid}(-2)|<10^{-2}$. All inequalities below have room for that tolerance. This class can be enlarged by smooth positive within-sheet transport perturbations whose normal/loop initial coupling satisfies $|\widehat K_1^{1/2}(X_0-X_0^G)|<\epsilon\sqrt T$ almost surely and whose log-density ratio is bounded. Keep the root factor as specified. Small smooth compactly supported maps with sufficiently small Jacobian provide a nonempty neighborhood in this weighted transport and bounded-log-density topology. The actual evolving laws are unrestricted correlated marked laws, not Gaussian ansatzes.

## 2. Exact parent generator and score

Remove the decoupled root from the notation. On active level $p$, let $H_p$ be the Schur complement on $M_p=N_p\oplus H_h$. Exact Gaussian integration writes the sheet potential, including its scalar, as

\[
V_{p,j}(y,a)=\tfrac a2 y^TH_py+C_p(a)+T\psi_{p,j}(y,a),\qquad
\psi_{p,j}=-\log E_{\gamma_{p,a}(\cdot\mid y)}e^{-\phi_j},\qquad 0\le\psi_{p,j}\le B_0.
\tag{D2}
\]

Here $\gamma_{p,a}$ is the cumulative hidden Gaussian conditional and $C_p'(a)=Td_p/(2a)$, with $d_p$ the cumulative hidden dimension. At $p=0$, $\psi_{0,j}=\phi_j$ and $d_0=0$. Root factors give no $a$ score. The complete parent proposal row is

\[
R^p_{jk}(y,a)=E_{\Pi_a}[b_k(X,a)\mid P_pX=y,J=j],\qquad
\mathcal L^p_a f=T\Delta f-\nabla V_{p,j}\cdot\nabla f+
\sum_kR^p_{jk}(f_k-f_j).
\tag{D3}
\]

Rows sum to one, and $R^p_{jk}\ge b_{\min,L}>0$ on the parameter interval, since $b_k\ge e^{-B_0}\min_a\pi_k(a)$. Formula D3 includes self proposals and has exit rate at most one. S9–S11 give its reversible conductance and exact nested composition. Each parent starts from the complete actual retained law and current actual $a$ at activation, without changing labels, conditional marks or correlations.

The inherited metric is $m(a)=TM(a)$ from E18. Differentiating the full E29 objective while holding its actual law fixed gives

\[
g_p(q,a)=a-2+\tfrac12E_q y^TH_py+\frac{Td_p}{2a}
+TE_q\partial_a\psi_{p,J}-\frac T2\operatorname{tr}(A_0^{-1}H)
-TE_q\partial_a\log\pi_J(a),\qquad \dot a=-\epsilon m(a)^{-1}g_p(q,a).
\tag{D4}
\]

The Gaussian conditional mean is independent of $a$ and its covariance is $T/a$ times a fixed inverse precision. Its centered parameter score is $d_p/(2a)-|Z|^2/(2a)$ in standardized coordinates $Z\sim N(0,I)$. Its first few absolute moments are bounded uniformly in $y,T,J$ and $a$ in the interval. Bounded tilt then gives $|\partial_a\psi_{p,j}|\le C_L$. Also $1\le m(a)\le1+C_LT$, $|m'(a)|\le C_LT$. These facts account for the hidden determinant and all prior and categorical terms in D4. In particular, varying actual assignment masses does not add their time derivative to a partial model covector.

## 3. Local construction and a noncircular continuation bound

For fixed positive parameters and a prescribed continuous path $a(t)$ in a compact neighborhood of $[1,2.1]$, construct D3 by interlacing sheet diffusions at a rate-one Poisson clock. The exact marginal potentials have globally bounded Hessians and bounded nonlinear gradients for this fixed instance. This follows either by differentiating the Gaussian integral in D2 or from the relative Hessian and dual-force bounds F16–F17; the denominator is at least $e^{-B_0}$. Their $a$ derivatives grow at most linearly. The proposal rows and their spatial and parameter derivatives are bounded: differentiate the same Gaussian integrals; the linear Gaussian conditional mean has a fixed derivative, the centered quadratic parameter score has bounded tilted moments, and $b$ and its derivatives are bounded for fixed $T,J$. There are finitely many sheets. Thus the prescribed-path process is unique, nonexplosive and has finite moments of every fixed order for the preparation above.

Here is a direct local law-dependence argument, avoiding an assumption of the desired coupled continuation. For a terminal function $f_j(x)$ with quadratic growth and smooth derivatives of polynomial growth, let $u^a_j(s,x)=E_a[f(X_t,J_t)\mid X_s=x,J_s=j]$. Conditioning on the Poisson proposal times and finite label sequence represents this expectation by globally Lipschitz sheet flows with products of $R^p$ weights. Differentiate those flows and weights. Flow derivatives are bounded on a bounded time interval; a derivative of a weight is bounded by a constant times that weight because $R^p_{jk}\ge b_{\min,L}$. The number of terms is at most the number of proposals, which has all exponential moments. Polynomial moment bounds for every sheet sequence justify termwise differentiation and give $|u|+|\nabla u|\le C(1+|x|^r)$ for some finite $r$. The constants here may depend on the fixed positive instance. The standard backward identity can equivalently be obtained from this interlaced representation.

For two prescribed paths $a,\widetilde a$ and the same initial law, apply Ito's formula to $u^{\widetilde a}$ along the $a$ process, first with bounded spatial stopping and then using these moment bounds. It yields

\[
|E_a f(X_t,J_t)-E_{\widetilde a}f(X_t,J_t)|
\le C\int_0^t|a(s)-\widetilde a(s)|ds.
\tag{D5}
\]

Indeed the difference of diffusion drifts is bounded by $C|a-\widetilde a|(1+|x|)$, the difference of proposal rows by $C|a-\widetilde a|$, and the second-order coefficients agree. D5 applies to the quadratic energy and the bounded smooth score terms in D4; their explicit parameter dependence contributes $C|a(t)-\widetilde a(t)|$. The integral map for D4 is a contraction for sufficiently short time. This constructs a unique coupled law and parameter locally. Smooth positive densities follow from positive-temperature elliptic diffusion and positive finite proposal rows. Polynomial moments and bounded density perturbations allow entropy identities by localization and smoothing; the quantitative entropy bounds are supplied in the [conditional component](finite-rate-conditional-entropy.md).

To extend the local solution, assume only $1\le a\le2.1$ up to its first possible exit. Do not assume a bound on $\dot a$. Couple its normal/loop configuration to the linear comparison with the same actual deterministic $a(t)$, initial Gaussian reference and Brownian motion. This comparison ignores future label changes. With $e=X-X_G$ and $g_{p,j}=T\nabla\psi_{p,j}$, the uniform energy-dual force bound gives

\[
|H_p^{-1/2}g_{p,j}|\le C_L\sqrt T,\qquad
\frac d{dt}|e|^2\le-e^TH_pe+C_LT,\qquad
\sup_{t\le H_*}|e_t|\le |e_0|+C_L\sqrt{TH_*}.
\tag{D6}
\]

These inequalities hold for every adapted assignment path. A jump changes the force but leaves $X$, $X_G$ and $e$ continuous. The propagator is $\exp[-H_p\int_s^ta(u)du]$. Spectral calculus bounds the integral of $\|H_p\exp[-H_p\int_s^ta]\|$ by $C_L[1+\log(J_1/J_L)]$: split elapsed times at $1/(C_LJ_1)$ and $1/(c_LJ_L)$ and integrate the bounds $C_LJ_1$, $C_L/(t-s)$, and the exponential tail. Consequently

\[
\sup_t|H_p^{1/2}e_t|\le C_L\sqrt T\ell_\epsilon,
\qquad \ell_\epsilon=1+\log(1/\epsilon).
\tag{D7}
\]

The prepared error is included. At activation Euclidean projection contracts D6 and the Schur variational identity contracts D7. Only a finite factor depending on $L$ is lost. The Gaussian covariance satisfies $\Sigma_G\preceq C_LT H_p^{-1}$ without differentiating $a$: this is an invariant covariance barrier for $a\ge1$, and exact projected covariances satisfy the next barrier by the Schur inverse identity. Its mean has norm at most $C_LA$ and zero loop component. Thus throughout a level-$p$ stage, including its actual initial law,

\[
E_qX^TH_pX\le C_L[A^2J_{p+1}+T\ell_\epsilon^2],\qquad
J_1E_q|X_{H_h}|^2\le C_LT.
\tag{D8}
\]

Use $J_{L+1}=0$. The sharper loop estimate follows directly from its scalar linear rate $aJ_1$ and the bound $|g_{H_h}|\le C_L\sqrt{TJ_1}$, so it remains valid when labels switch. Every contribution to D4 other than $a-2$ is now at most $C_Lr_\epsilon$, where

\[
r_\epsilon=A^2J_1+T\ell_\epsilon^2,\qquad
\dot a=\epsilon(2-a)+O_L(\epsilon r_\epsilon).
\tag{D9}
\]

At $a=1$ the derivative is positive and at $a=2.1$ it is negative for small $\epsilon$. The first-exit alternative is excluded. Moment bounds exclude explosion, so the local construction extends to the entire horizon and gives $|\dot a|\le C_L\epsilon$. This establishes the hypothesis used in the subsequent entropy and averaging arguments, rather than assuming it there.

Variation of constants, with $a_0(t)=2-e^{-\epsilon t}$ used only as a reference, gives

\[
\sup_{0\le t\le H_*}|a_p(t)-a_0(t)|\le C_Lr_\epsilon.
\tag{D10}
\]

For a parent this bound starts at its actual activation coefficient; the initial discrepancy and the forcing error accumulate only a finite factor through $L$ activations. Independently learning ancestors and descendants therefore differ by at most $C_Lr_\epsilon$. Since $a_0(H_*-10)\to2-e^{-2}>7/4$, every such coefficient is at least $7/4$ on the last ten units for sufficiently small $\epsilon$.

## 4. Actual changes and successive formation

For each fine receiver, S5–S7 and D10 imply actual binary recognition-mass change greater than $1/2$. The analytic lower bound in S7 is greater than $0.587$ with its stated conservative rational estimates, so the $10^{-2}$ preparation tolerance is harmless. The same proof holds for an independently evolving parent or a sequence of actual activations: D3 averages a row satisfying S6, preserving that envelope, and neither projection nor activation changes the actual label mass. If its change is measured from the parent activation rather than time zero, $|\dot\lambda_{i,+}|\le1$ and $\tau_L\to0$ reduce the strict lower bound by at most $\tau_L$. The first hidden physical and optimizing kernels each change by KL greater than $1/200$ between $a=1$ and the final $a\ge7/4$, by the bounded-tilt affinity calculation E23. The physical precision correction $-TR$ is small and confined to the first normal layer; its precision growth is at least the weaker factor $5/4$ used there. This statement compares kernels at the same retained input and label, uniformly over that input; it is not a claim about a refreshed actual hidden law.

The strict-margin construction F31 uses only the fixed residual rows and remains unchanged by the new strengths. On each Gaussian comparison, the weighted flag algebra F6 and F10 gives, for current normal block $u$ and future block $P_sX_G$,

\[
|E u_t|\le C_LA[e^{-c_LJ_s(t-\tau_{s-1})}+J_{s+1}/J_s],\qquad
|E P_sX_G(t)-AP_sv_0|\le C_LAJ_{s+1}t.
\tag{D11}
\]

These are obtained by variation of constants for the current block and by integrating the future row, whose norm is $O_L(J_{s+1})$. They use $1\le a\le2.1$, not fixed assignment paths. The Gaussian reference starts at the same strict-margin center on all sheets. Label-dependent initial perturbations are included in D6, so its centered covariance does not acquire an order-$A^2$ between-sheet spread. Earlier projections preserve $P_sX_G$. The centered Gaussian comparison has the maximum bound F34, which remains valid because its precision lower bound has only increased:

\[
\Pr\{\sup_{t\le H_*}|X_G(t)-EX_G(t)|>\rho A\}
\le C_L(1+H_*)\exp[-c_L\rho^2A^2/T].
\tag{D12}
\]

The proof applies Ito's formula to $\exp(c|Z|^2/(4T))$, whose generator is bounded above by a constant for a fixed $c$ below the uniform precision lower bound, and uses stopping and projection contraction. Brownian motion and initial reference have their correct marginal laws even though actual labels subsequently depend on them.

Choose a finite $k_L\ge2\kappa_L$, where $\kappa_L$ is the entrance constant in conditional F32, and also large enough for the following geometric decays. Define

\[
t_s=k_L\log(1/\epsilon)/J_s,\qquad I_s=[t_s,2t_s],\qquad \tau_s=2t_s.
\tag{D13}
\]

These windows are disjoint, $\tau_{s-1}<t_s/2$ for small $\epsilon$, and $J_{s+1}t_s\to0$. On $I_s$, D11–D12 and $\sqrt{TH_*}/A=\sqrt2\epsilon^{5/2}$ show that every already formed residual is below a fixed small tolerance $\eta_LA$, while every future bridge exceeds $m_LA/3$, outside probability $C_L(1+H_*)e^{-c_L/\epsilon^6}$. The inherited nonlinear error from every activation is included by D6. Current residuals remain small after their formation by the same stable current-block equation, and final coherence persists through $H_*$. The physical conditional residual interpretation follows F36: conditional hidden precision is at least $c_LJ_p$, hidden/future ratio is $O_L(J_{p+1}/J_p)$, and its bounded tilt multiplies second-moment bounds by at most $e^{B_0}$. No dynamics is changed at $t_s$; $\tau_s$ only selects the actual parent for the next description.

For $L=2$, the carrier is two oriented triangles $(1,2,3)$ and $(4,5,6)$ with bridge $(3,4)$. There are nineteen coordinates, with exact retentions $19\to9\to8$ and agent counts $6\to2\to1$. Both loops survive. D1 becomes $J_1=\epsilon^{-36}$, $J_2=\epsilon^{-8}$, $A=\epsilon^{64}$ and $T=\epsilon^{134}$; the windows have orders $\epsilon^{36}\log(1/\epsilon)$ and $\epsilon^8\log(1/\epsilon)$. Both formation windows precede the order-$1/\epsilon$ recognition-row change. Thus this example does not claim that slow source learning creates the initial energy hierarchy.

## 5. Continuous paths and the remaining joined interfaces

For a source and an independently learning exact parent, activate with their full common actual retained state and coefficient. Compare each with its own linear companion. At common parameter the split current/future linear equations and variation of constants give relative mean error

\[
C_L[J_{s+1}/J_s+H_*J_{s+1}^2/J_s].
\tag{D14}
\]

Indeed the current block is bounded by the first estimate D11; integrating its $O(J_{s+1})$ effect on the future gives the two terms in D14. At different parameters, put $\chi=\sup|a-\widetilde a|$. For the two homogeneous parent means the relative form bound for $(a-\widetilde a)H_p$ and Young's inequality give $(|d|^2)'\le-d^TS_pd+C_L\chi^2\mu^TS_p\mu$. The integral of the last energy is at most $C_LA^2$, so this error is $C_LA\chi$. D10 supplies $\chi\le C_Lr_\epsilon$. Use D12 with $\rho=\epsilon^2$ for both references and D6 for their actual paths. This gives

\[
\Pr\left\{\sup_{\tau\le t\le H_*}|P_sX_t-\overline X_t|
>C_LA[\epsilon^2+\epsilon^{5/2}+r_\epsilon+\epsilon^{19}]\right\}
\le C_L(1+H_*)e^{-c_L/\epsilon^2}.
\tag{D15}
\]

The root follows the identical decoupled equation and is coupled identically. Finite successive replacements sum these errors. The argument permits different adapted label histories: D6 is uniform over them, and each centered Gaussian maximum estimate needs only its own marginal law. Therefore D15 also holds under a coupling designed to match complete assignment histories, by a union bound on those marginal exceptional events. Its construction can leave the independent root noise common. This proves an $o(A)$ uniform continuous-coordinate error, not total variation convergence of continuous path measures.

The [conditional component](finite-rate-conditional-entropy.md) derives the additional jump contribution, actual mixed-entropy budget, stagewise discarded-conditional KL and complete same-state covector error. Its use of D8–D10 is downstream of the local continuation proof above. The [source-history component](finite-rate-source-history-averaging.md) uses these same bounds and $J_L=\epsilon^{-8}$ to average complete rate-one proposal histories through a common finite-state row. Exact inherited rows, rather than regenerated heat baths, are essential to its conditional-expectation tower. The full target is established only when those two components and their joins pass the separate reconstruction.
