# Entire source histories at fixed positive update rate

September 13, 2026. This note proves the source-history part of the frozen finite-rate contract, with target digest 2f673c3806f5838530bd025b43174018904da19fe6af74fc8c24ae2e7bcf3e09. It concerns the additional globally accelerated energy family admitted by that contract. It does not settle the corresponding averaging problem with weakest strength $J_L=1$.

The starting point is the normalized marked model [E24–E29](nonlinear-endpoint-attention-model.md), the exact finite-rate generator and inherited rates [S1–S13](finite-rate-source-dynamics-investigation.md), their [separate reconstruction](finite-rate-source-dynamics-check.md), and the uniform marked geometry [M7–M9](nonlinear-cyclic-formation-route.md). The live PIFB2 section on mixture derivation and the September 2026 vault synthesis supply the prior distinction between optimizing source rows and actual recognition. No posterior resampling of the continuous state is introduced here.

The proof has two distinct operations. Actual parents retain every loop and every assignment, and use their exact optimizer-conditioned rates. An auxiliary finite-rate assignment chain averages all non-root continuous coordinates, including loops, solely to compare source histories. This auxiliary chain is not substituted for a parent.

## 1. Target, assumptions, and the actual processes

Fix any finite depth $L\ge2$. Write $b=2^{L-1}$, $n=3b$, and let $\mathcal J$ be the full finite assignment set of cardinality $2^n$. Work at the fixed base point $c_*$ in the declared local-section model. The continuous triangle-chain carrier splits orthogonally into the root space $K$ and the non-root space

\[
M=K^\perp=N\oplus H_h.
\tag{H1}
\]

Every allowed retention keeps $K$, all $b$ loop coordinates $H_h$, and the remaining normal coordinates. Let $P_p:M\longrightarrow M_p$ be the resulting orthogonal continuous retention at level $p$, with $P_0$ the identity. All labels are retained. These are the existing fixed channels, not channels selected from the evolving law.

For fixed positive temperature $T$ and fixed energy strengths $J_1\ge\cdots\ge J_L=\Lambda>0$, the optimizing sheet law on $M$ is

\[
\mu_{a,j}^0(dx)=Z_j(a)^{-1}
\exp\left[-\frac{a}{2T}x^THx-\phi_j(x)\right]dx,
\qquad
0\le\phi_j\le B_0,\quad \phi_j(-x)=\phi_j(x).
\tag{H2}
\]

The nonlinear coefficient is the fixed positive value $\delta=B_0/n$, with the shared choice $B_0=10^{-4}$. The source costs and matrix $H$ are those of E24–E29 and M7. They do not acquire an additional dependence on $a$. The root factor separates from (H2) and from the source proposal rows, so the root process can be omitted from this history proof without discarding any source dependence.

Define the exact retained sheet law $\mu_{a,j}^p=P_{p\#}\mu_{a,j}^0$ and write its potential as $V_{a,j}^p=-T\log\mu_{a,j}^p$, up to a constant independent of the retained continuous coordinate. The inherited proposal row, including its self proposal, is

\[
R_{jk}^p(y,a)
=E_{\mu_{a,j}^0}\left[b_k(X,a)\mid P_pX=y\right],
\qquad
b_k(x,a)=
\frac{\pi_k(a)e^{-\phi_k(x)}}{\sum_\ell\pi_\ell(a)e^{-\phi_\ell(x)}}.
\tag{H3}
\]

Thus $\sum_kR_{jk}^p=1$, $R_{jk}^p\ge0$, and $R_{jk}^0(x,a)=b_k(x,a)$. At level $p$ the continuous process and the assignment process have generator

\[
\mathcal L_{a}^{p} f(y,j)
=T\Delta_yf-\nabla V_{a,j}^p\cdot\nabla_yf
+\sum_kR_{jk}^p(y,a)\{f(y,k)-f(y,j)\}.
\tag{H4}
\]

Its continuous mobility is one and its Brownian covariance is $2T I dt$. Its proposal clock has rate exactly one for every $\epsilon$ and every level. The actual off-diagonal jump rates are $R_{jk}^p$, and the diagonal of the conservative generator is $R_{jj}^p-1$. In particular, an unsuccessful self proposal consumes a clock event. No continuous coordinate is refreshed at an event. The state space is global Euclidean space times a finite set, with no reflecting or absorbing boundary.

The exact-law feedback in the companion [coupled formation calculation](finite-rate-coupled-formation.md) supplies, for each independently evolving process, a deterministic parameter path $a(t)$ satisfying

\[
1\le a(t)\le2.1,\qquad
|\dot a(t)|\le C_L\epsilon,\qquad
\sup_{0\le t\le H}|a(t)-a_0(t)|\le r_\epsilon,
\qquad
a_0(t)=2-e^{-\epsilon t}.
\tag{H5}
\]

The history theorem below is conditional on (H5); it does not infer (H5) by prescribing the desired parameter path. The companion D8–D10 prove these bounds from each process's own law and covector, with

\[
r_\epsilon=C_L\left[A^2J_1+
T(1+\log J_1)^2\right].
\tag{H6}
\]

Each comparison can start at an actual deterministic activation time. Source and newly activated parent start with exactly the same retained continuous state and assignment under a coupling, distributed according to the complete actual preceding retained joint law. More generally a lineage may have at most $m\le L$ fixed deterministic activations, at which its coordinates are projected and its assignment is unchanged. Between activations it uses (H4) and its own parameter in (H5). Initial and activation laws may contain arbitrary label/configuration dependence.

The only preparation condition used for source-history comparison is the unconditional non-root moment bound

\[
E|X_0|^2\le C_L\left(A^2+\frac{T}{\Lambda}\right).
\tag{H7}
\]

At a comparison starting from an actual activation, (H7) is required for its common initial source state and follows below from the same bound at time zero. The permitted Gaussian preparation with bounded normal mean $Av_j$, covariance bounded by $C_LT H^{-1}$, and arbitrary positive assignment masses satisfies (H7). Small bounded-density perturbations also satisfy it. Thus this history argument imposes a nonempty moment preparation and does not require conditional equilibrium at activation, a lower bound on probabilities of entire source histories, or a reset of source masses.

For any fixed $\epsilon>0$, the sheet potentials are smooth with globally bounded Hessians and confining quadratic cores. Interlacing the unique globally defined sheet diffusions with the rate-one Poisson events constructs (H4) without explosion. The independent Poisson clock and the Brownian noises used here are part of the specified kinetic realization. No numerical discretization or implementation is analyzed.

The intended equivalence is a coupling of the entire assignment-valued paths on a finite horizon. It is stronger than agreement of one-time marginals and weaker than equality of the continuous/discrete joint path laws. The error estimate will also hold when conditioning the construction on a common actual activation state and then integrating that state.

## 2. A common finite-rate comparison chain

Define the matrix

\[
\mathsf B_{jk}(a)
=E_{\mu_{a,j}^0}b_k(X,a).
\tag{H8}
\]

It is a stochastic proposal matrix. For every level $p$, including a parent formed by successive reductions, the exact tower gives

\[
E_{\mu_{a,j}^p}R_{jk}^p(Y,a)
=E_{\mu_{a,j}^0}b_k(X,a)
=\mathsf B_{jk}(a).
\tag{H9}
\]

Indeed substitute (H3) and integrate against the pushforward of the same sheet law. For two nested reductions, applying conditional expectation first onto the intermediate retained coordinate and then onto the final coordinate gives the same conditional expectation directly onto the final coordinate. This proves S11 including the self-proposal entry, and hence its conservative-generator diagonal. No actual evolving conditional law is inserted into this static identity.

For fixed $a$, let $\Pi_j(a)$ be the assignment marginal of the full optimizing joint. Integrating the microscopic detailed-balance identity over $x$ shows

\[
\Pi_j(a)\mathsf B_{jk}(a)
=\Pi_k(a)\mathsf B_{kj}(a).
\tag{H10}
\]

Neither (H9) nor (H10) states that $\mathsf B_{jk}$ is independent of $j$. In general it is not. In particular, replacing the row by a newly generated heat bath from a parent source marginal would change the kinetic, as S12 demonstrates.

The comparison chain starts from the actual initial assignment and, at the same rate-one proposal times, redraws from $\mathsf B_{j\cdot}(a_0(t))$. It keeps finite-rate source dynamics throughout the learning horizon. It is never initialized at $\Pi(a)$ merely to facilitate comparison.

The finite-source family also gives a uniform row bound

\[
\sup_j\|\mathsf B_{j\cdot}(a)-\mathsf B_{j\cdot}(a')\|_{\rm TV}
\le C_L|a-a'|,\qquad a,a'\in[1,2.1].
\tag{H11}
\]

Here and below $\|\cdot\|_{\rm TV}$ denotes the supremum difference over measurable events, or half the $\ell^1$ difference for probability vectors. To prove (H11), put $F(x)=x^THx/(2T)$. Differentiating the normalized sheet density gives

\[
s_{a,j}^0(x)=\partial_a\log\mu_{a,j}^0(x)
=E_{\mu_{a,j}^0}F-F(x).
\tag{H12}
\]

The bounded tilt in (H2) and the Gaussian quadratic moments imply $E|s_{a,j}^0|\le C_L$ uniformly in strengths and temperature. Only one binary source prior learns, with logit $4(a-3/2)$, so $|\partial_a\log\pi_k|\le4$. Consequently

\[
\sum_k|\partial_ab_k(x,a)|\le8,
\qquad
\sum_k|\partial_a\mathsf B_{jk}(a)|
\le8+E_{\mu_{a,j}^0}|s_{a,j}^0|
\le C_L.
\tag{H13}
\]

The derivative of the expectation contributes $\sum_kE[b_k s_{a,j}^0]$, whose absolute sum is bounded by $E|s_{a,j}^0|$. This proves (H11) without needing a pointwise parameter derivative bound on every inherited rate (H3).

## 3. Uniform relaxation while the assignment is fixed

The geometry needed here is the positive-definite geometry on all of $M_p$. M7–M9 give constants depending only on finite $L$ such that

\[
c_L\Lambda I\preceq\nabla^2V_{a,j}^p(y)
\preceq C_LJ_1I,\qquad
\nabla V_{a,j}^p(0)=0,
\tag{H14}
\]

uniformly in $p,j,a,y$. For clarity, if $H_p$ is the Schur complement of $H$ on retained non-root coordinates, the marginal quadratic core is $aH_p$ and the nonlinear Hessian error is bounded in relative magnitude by $\theta_*aH_p$, where $\theta_*=2\delta+2n\delta^2<1/2$. Schur minimization yields

\[
y^TH_py=\min_z (y,z)^TH(y,z)
\ge c_L\Lambda|y|^2.
\tag{H15}
\]

The upper bound follows by setting $z=0$. Evenness of the original density and linearity of the retention give evenness of every marginal potential and its zero gradient at the origin. Thus (H14) includes the retained loops, which have energy strength $J_1$, and the weakest remaining normal modes, which have strength at least $c_L\Lambda$. The bounded normalized Gaussian tilt also gives

\[
E_{\mu_{a,j}^p}|Y|^2\le \frac{C_LT}{\Lambda}.
\tag{H16}
\]

We now prove the transition estimate needed at proposal times. For a fixed label $j$ and a fixed active level $p$, let $\mathcal P_{s,t}^{p,j}(x,\cdot)$ denote the time-inhomogeneous sheet diffusion driven by the actual deterministic parameter $a(r)$ on $[s,t]$. Then, provided $t-s\ge1/(c_L\Lambda)$ and $\Lambda/\epsilon$ is sufficiently large,

\[
\left\|\mathcal P_{s,t}^{p,j}(x,\cdot)
-\mu_{a(t),j}^p\right\|_{\rm TV}
\le
C_L\left(1+\sqrt{\frac{\Lambda}{T}}|x|\right)
e^{-c_L\Lambda(t-s)}
+\frac{C_L\epsilon}{\Lambda}.
\tag{H17}
\]

The two terms have different proofs: contraction of two solutions with the same varying coefficient removes the initial state; a moving-equilibrium entropy estimate bounds the remaining lag.

For the first part set $\lambda=c_L\Lambda$ small enough that (H14) holds with this lower bound. Before two solutions meet, couple their Brownian increments by reflection in the direction $e=(X-Y)/|X-Y|$ of their displacement. The reflected increment has the same Brownian law because its predictable coefficient is orthogonal. The reflection SDE has locally Lipschitz coefficients off the diagonal; stop at the diagonal and then use common Brownian increments. Linear growth precludes explosion. Before meeting, the distance satisfies

\[
d|X-Y|
\le-\lambda|X-Y|dt+2\sqrt{2T}d\beta_t.
\tag{H18}
\]

There is no transverse radial Itô term because the difference noise is entirely radial. Multiplication by $e^{\lambda(t-s)}$ shows that survival without meeting for duration $u$ implies that a one-dimensional Brownian motion, with elapsed variance

\[
q(u)=8T\int_0^u e^{2\lambda r}dr
=\frac{4T}{\lambda}(e^{2\lambda u}-1),
\tag{H19}
\]

has not crossed below $-|x-z|$. Reflection of one-dimensional Brownian paths after their first hit gives this survival probability as $2\Phi(|x-z|/\sqrt{q(u)})-1$. It is at most $C|x-z|/\sqrt{q(u)}$. Therefore the coupling inequality gives

\[
\|\mathcal P_{s,t}^{p,j}(x,\cdot)
-\mathcal P_{s,t}^{p,j}(z,\cdot)\|_{\rm TV}
\le
C|x-z|\sqrt{\frac{\lambda}{T}}
(e^{2\lambda(t-s)}-1)^{-1/2}.
\tag{H20}
\]

This argument uses strong monotonicity at the actual time-dependent parameter; it does not freeze that parameter during the interval.

For the moving-equilibrium estimate, first note a uniform centered score bound valid for every exact marginal. For $|\vartheta|\le1/4$, differentiating the logarithmic moment generating function of (H12) twice gives

\[
\frac{d^2}{d\vartheta^2}
\log E_{\mu_{a,j}^0}e^{\vartheta s_{a,j}^0}
=\operatorname{Var}_{\mu_{a+\vartheta,j}^0}F
\le C_L.
\tag{H21}
\]

Indeed under the unperturbed Gaussian the moments of $F$ are those of a fixed-dimensional quadratic variable with coefficient $a+\vartheta\ge3/4$; the bounded tilt changes its nonnegative moments by at most $e^{B_0}$. At zero the logarithmic moment generating function and its derivative both vanish. Hence it is at most $C_L\vartheta^2$ on that interval. Differentiation through marginalization gives

\[
s_{a,j}^p(y)=\partial_a\log\mu_{a,j}^p(y)
=E_{\mu_{a,j}^0}[s_{a,j}^0(X)\mid P_pX=y].
\tag{H22}
\]

Conditional Jensen transfers the same centered exponential bound to $s_{a,j}^p$. The entropy variational inequality now implies, for any probability density $q$ of finite relative entropy $D=D(q\Vert\mu_{a,j}^p)$,

\[
|E_qs_{a,j}^p|\le C_L(\sqrt D+D).
\tag{H23}
\]

One direct verification is to apply Jensen to the probability density ratio:
$\vartheta E_qs\le D+\log E_\mu e^{\vartheta s}$.
Use both signs and choose $|\vartheta|$ to be the smaller of $1/4$ and a constant times $\sqrt D$. This proves (H23) without asserting that the unbounded score is uniformly bounded.

We also record the entropy inequality used here with its hypotheses. For a smooth potential $V$ on a Euclidean space with globally bounded Hessian and $\nabla^2V\ge\lambda I>0$, let $\mu\propto e^{-V/T}$. Then every density of finite entropy and Fisher information satisfies

\[
D(q\Vert\mu)\le\frac{T}{2\lambda}
I(q\Vert\mu),\qquad
I(q\Vert\mu)=\int q\left|\nabla\log\frac q\mu\right|^2.
\tag{H24}
\]

A semigroup calculation supplies a proof in the present setting. For the frozen diffusion semigroup $P_t$, the derivative flow obeys
$\|D_xX_t\|\le e^{-\lambda t}$. Differentiating $P_tf$ and using weighted Cauchy–Schwarz yields
$|\nabla P_tf|^2/(P_tf)\le e^{-2\lambda t}P_t(|\nabla f|^2/f)$.
Invariance of $\mu$ implies $I_\mu(P_tf)\le e^{-2\lambda t}I_\mu(f)$, while integration by parts gives
$d\operatorname{Ent}_\mu(P_tf)/dt=-T I_\mu(P_tf)$.
For a bounded positive Lipschitz density $f$ bounded away from zero, synchronous contraction against a stationary initial point gives $P_tf\to\int f d\mu$ pointwise; dominated convergence gives entropy convergence to zero. Integration over $t\in[0,\infty)$ proves (H24) for these densities. Truncating a general density above and below, normalizing, applying an arbitrarily short semigroup smoothing, and taking the truncation and smoothing limits proves the stated finite-entropy, finite-information form by lower semicontinuity. Gaussian tails and bounded Hessians justify the integrations by parts; compact cutoffs give the same identities before the limit. Thus the hypotheses match every potential in (H14), and no unproved averaging theorem is used.

Let $q_t$ now be the sheet diffusion law that starts from $\mu_{a(s),j}^p$ at $s$ but evolves with the varying actual parameter. Differentiating its relative entropy against the moving reference gives

\[
\frac{d}{dt}D(q_t\Vert\mu_{a(t),j}^p)
=-T I(q_t\Vert\mu_{a(t),j}^p)
-\dot a(t)E_{q_t}s_{a(t),j}^p.
\tag{H25}
\]

Equations (H5), (H23), and (H24) imply

\[
\dot D\le-2\lambda D+C_L\epsilon(\sqrt D+D)
\le-\lambda D+\frac{C_L\epsilon^2}{\lambda}
\tag{H26}
\]

once $\lambda/\epsilon$ is large enough. Since $D(s)=0$, scalar integration gives $D(t)\le C_L\epsilon^2/\lambda^2$. We use the probability inequality
$\|q-\mu\|_{\rm TV}\le\sqrt{D(q\Vert\mu)/2}$.
One proof maps both measures to an event attaining total variation (or an approximating sequence of events), uses Jensen on that event and its complement to decrease relative entropy, and applies the binary inequality $d(u\Vert v)\ge2(u-v)^2$. The latter follows by twice integrating $\partial_u^2d(u\Vert v)=1/[u(1-u)]\ge4$ from its minimum at $u=v$, with endpoint cases obtained by limits. Applied to the present normalized positive densities, this gives
$\|q_t-\mu_{a(t),j}^p\|_{\rm TV}\le C_L\epsilon/\Lambda$.
All terms in (H25) are obtained first with the cutoffs just described and then by their integrable limits; (H21) controls the score term.

Finally integrate (H20) against $z\sim\mu_{a(s),j}^p$, use (H16), and add this moving-reference error. For $t-s\ge1/\lambda$ the denominator in (H20) is bounded below by a constant times $e^{\lambda(t-s)}$. This proves (H17).

## 4. Moment control does not require source-history probability bounds

Let $\mathcal T$ be the entire exogenous rate-one proposal grid on the horizon. Conditional on $\mathcal T$, the grid times are deterministic and the Brownian noises keep their usual laws. The label choices may still depend on every previous continuous state. Nevertheless (H14) gives on every active sheet

\[
\mathcal L_a^p|y|^2
=2T\dim M_p-2y\cdot\nabla V_{a,j}^p(y)
\le2T\dim M-2c_L\Lambda|y|^2.
\tag{H27}
\]

The proposal operator contributes zero because a proposal changes only the label. A retention decreases the squared norm. Integration between the now-fixed proposal and activation times, followed by these norm-preserving or norm-decreasing operations, yields

\[
\sup_{t\le H}E[|X_t|^2\mid\mathcal T]
\le E|X_0|^2+\frac{C_LT}{\Lambda}
\le C_L\left(A^2+\frac T\Lambda\right).
\tag{H28}
\]

This statement integrates over the initial law, which is independent of the future proposal grid. For a comparison starting at an actual activation, the future Poisson grid is independent of the inherited state and preceding history, so the same calculation applies after averaging that actual initial state. A fixed initial-state conditioning can replace $E|X_0|^2$ by its conditioned value and is integrated out at the end.

Equation (H28) holds at proposal times, at activation times, and at times selected from the proposal grid. It does not require dividing by the probability of a particular observed source prefix. This point will allow full-history kernel comparison even though very long source prefixes can have extremely small probabilities.

## 5. Proposal-history comparison

We prove a quantitative statement. Suppose (H2)–(H7) and the exact parent prescription hold, and let $H>0$ be a finite horizon. Let $0<h\le H$ with $h\ge1/(c_L\Lambda)$. For an actual process, possibly following a lineage with $m$ deterministic activations, let $\mathsf J$ be its entire assignment path and let $\mathsf J^{\rm av}$ be the rate-one comparison chain of Section 2. They start from the same actual initial assignment. There is a coupling for which

\[
\Pr\{\mathsf J\ne\mathsf J^{\rm av}
\text{ somewhere on }[0,H]\}
\le C_L\left[
(H+m+1)h
+H\left(1+A\sqrt{\frac{\Lambda}{T}}\right)e^{-c_L\Lambda h}
+\frac{H\epsilon}{\Lambda}
+Hr_\epsilon\right].
\tag{H29}
\]

The same bound controls total variation of their assignment path laws jointly with a common initial state or preceding activation history, after averaging that state's moment in (H7). For two exact independently evolving processes beginning at the same actual marked activation state, each compared to this same chain, the sum of their two bounds gives a coupling of their complete assignment paths. The construction preserves the common actual initial state.

Here is the full-history argument. Condition on the finite proposal grid $0<t_1<\cdots<t_N\le H$, its common initial information $I$, and a realized proposal-mark prefix $j_0,\ldots,j_{\ell-1}$. The common information may include the preceding actual path up to a deterministic activation. Conditioning never recomputes the own-law parameter: the deterministic path furnished by the full unconditioned law remains the coefficient of its conditioned process. Define $\sigma_\ell$ to be the latest of the preceding proposal time, the starting time, and any deterministic activation preceding $t_\ell$. Between $\sigma_\ell$ and $t_\ell$, both the active level and the realized label are fixed.

Write $p_\ell(k\mid j_0,\ldots,j_{\ell-1},\mathcal T,I)$ for the actual conditional distribution of the next proposal mark. It is the conditional expectation of $R^p_{j_{\ell-1}k}(X_{t_\ell},a(t_\ell))$. After conditioning on its arbitrary starting state at $\sigma_\ell$, the evolution over that interval is the fixed-label diffusion of Section 3. No additional proposals occur there, and no source observation conditions its Brownian motion inside the interval. Therefore, when $t_\ell-\sigma_\ell\ge h$, contraction of total variation by the stochastic row (H3), (H9), (H11), and (H17) gives

\[
\begin{split}
&\|p_\ell(\cdot\mid j_0,\ldots,j_{\ell-1},\mathcal T,I)
-\mathsf B_{j_{\ell-1}\cdot}(a_0(t_\ell))\|_{\rm TV}\\
&\quad\le
C_L E\left[
1+\sqrt{\frac{\Lambda}{T}}|X_{\sigma_\ell}|
\mid j_0,\ldots,j_{\ell-1},\mathcal T,I\right]
e^{-c_L\Lambda h}
+\frac{C_L\epsilon}{\Lambda}+C_Lr_\epsilon.
\end{split}
\tag{H30}
\]

For a shorter interval use the trivial bound one. Notice that the conditioning includes the proposal outcomes, including self proposals, but does not include a subsequent continuous retained path. Mixing all non-root coordinates is legitimate for this conditioning. It would not be justified simply by invoking equilibrium conditioned on the full continuous retained past.

For completeness, a finite sequential-kernel identity compares the whole mark sequence. If $P$ is the actual distribution of $j_1,\ldots,j_N$ and $Q$ uses the comparison rows, then

\[
\|P-Q\|_{\rm TV}
\le\sum_{\ell=1}^N
E_{P\text{ prefix}}
\|p_\ell(\cdot\mid\text{prefix})
-\mathsf B_{j_{\ell-1}\cdot}(a_0(t_\ell))\|_{\rm TV}.
\tag{H31}
\]

To prove it, replace the kernels one at a time using hybrid laws whose prefix is actual and whose remaining tail is the comparison chain. Adjacent hybrid laws differ only at the current kernel; their common stochastic tail cannot increase total variation. The triangle inequality proves (H31). Its expectation is over actual prefixes, so averaging (H30) removes its prefix conditioning exactly. This is a comparison of joint finite histories, not a product of one-time marginal bounds.

It remains to count the short intervals and average the initial-state term. A short interval can be assigned to a preceding Poisson point less than $h$ earlier, or to an activation or starting time less than $h$ earlier. The expected number of ordered pairs of rate-one Poisson points $s<t\le H$ with $t-s<h$ is

\[
\int_0^H\int_{\max(0,t-h)}^t ds dt\le Hh.
\tag{H32}
\]

There are at most $m+1$ fixed activation/start times, with at most $h$ expected proposals following each within distance $h$. Thus the expected number of short intervals is at most $(H+m+1)h$. This bound can overcount, which is harmless.

For the other terms use (H28) conditional on the grid and Cauchy–Schwarz:
$E[|X_{\sigma_\ell}|\mid\mathcal T]\le C_L(A+\sqrt{T/\Lambda})$.
This holds at every grid-selected $\sigma_\ell$. Summation and $E N=H$ turn (H30)–(H31) into (H29). The initial information $I$ has been integrated with its actual law, so no conditional moment bound uniform in every possible initial state is being assumed.

Both processes can use identically distributed proposal grids, independent of their initial state, and the preceding calculation bounds total variation of the joint grid/mark laws. Conditional maximal coupling of the finite mark sequences gives a coupling attaining that bound; standard finite-dimensional disintegration on the finite sequence spaces constructs it measurably in the grid and initial information. The assignment path is the deterministic step function of this grid and these marks. Forgetting self proposals and the grid cannot increase disagreement probability. Since $N<\infty$ almost surely and $E N=H$, integration over $N$ and the grid is justified by nonnegative summation.

This is an existence coupling of full assignment histories; it need not be a causal coupling which makes the two decisions using only their simultaneous current states. Given the coupled histories and common initial information, one can sample each process's conditional continuous path law to recover its correct full marginal process law. That extension does not itself prove continuous-path closeness. The companion continuous-path estimate is separately uniform over adapted source histories and can therefore be combined with this construction using its marginal probability bounds.

## 6. One explicit simultaneous energy regime

The additional family admitted by the contract uses, for each fixed finite $L$,

\[
Q_L=8,\qquad Q_s=2Q_{s+1}+20\quad(s<L),
\qquad J_s=\epsilon^{-Q_s},
\]

\[
A^2=\epsilon^{3Q_1+20},
\qquad T=A^2\epsilon^6,\qquad H=\frac2\epsilon.
\tag{H33}
\]

These are energy strengths and a positive-temperature/amplitude choice. They change neither the unit continuous mobility nor the rate-one source proposal clock, and leave $\delta=10^{-4}/n$ fixed. In particular $\Lambda=J_L=\epsilon^{-8}$.

Choose

\[
h=k_L\Lambda^{-1}\log(1/\epsilon)
=k_L\epsilon^8\log(1/\epsilon),
\qquad c_Lk_L\ge16.
\tag{H34}
\]

For all sufficiently small $\epsilon$, this meets the lower bound required by (H17). The moment prefactor is $1+A\sqrt{\Lambda/T}=1+\epsilon^{-7}$. Substitution in (H29) gives

\[
\Pr\{\mathsf J\ne\mathsf J^{\rm av}
\text{ somewhere on }[0,2/\epsilon]\}
\le C_L\left[
\epsilon^7\log(1/\epsilon)
+\epsilon^8+\frac{r_\epsilon}{\epsilon}\right].
\tag{H35}
\]

The parameter bound (H6) makes its last term negligible:

\[
\frac{r_\epsilon}{\epsilon}
\le C_L\left[
\epsilon^{2Q_1+19}
+\epsilon^{3Q_1+25}(1+\log(1/\epsilon))^2\right].
\tag{H36}
\]

Consequently any source and its exact activated parent admit a coupling of their entire assignment histories, starting at their common actual activation state, with disagreement probability $O_L(\epsilon^7\log(1/\epsilon))$. The same conclusion holds for a fixed finite sequence of exact actual activations, by applying (H29) to each lineage or adding at most $L$ such comparison bounds. No assignment occupancy, loop coordinate, or observed proposal outcome is dropped from an actual parent.

At depth two the explicit values are

\[
Q_1=36,\quad Q_2=8,\quad
J_1=\epsilon^{-36},\quad J_2=\epsilon^{-8},
\quad A=\epsilon^{64},\quad T=\epsilon^{134}.
\tag{H37}
\]

The actual carriers remain
$\mathbb R^{19}\times\mathcal J\to
\mathbb R^9\times\mathcal J\to
\mathbb R^8\times\mathcal J$, with $|\mathcal J|=64$.
Both loops and all six receiver source choices remain present after both reductions.

## 7. Scope, the unaccelerated route, and the remaining join

Equations (H9) and S11 establish exact composition of optimizer-conditioned parent rates at a fixed parameter. Equations (H29) and (H35) establish approximate equivalence of complete finite-horizon source-assignment histories in the accelerated family, under the actual own-law parameter and moment hypotheses. They do not assert strong Markov lumpability, instantaneous source equilibrium, or total variation equivalence of continuous path laws. The global auxiliary average includes every non-root continuous mode precisely because the retained loops can relax on the same scale as the first hidden contrasts.

The accelerated formation windows in the companion construction end by
$\tau_L=O_L(\Lambda^{-1}\log(1/\epsilon))$. At the fixed unit proposal rate,

\[
\Pr\{\text{a source proposal occurs before }\tau_L\}
=1-e^{-\tau_L}\le\tau_L
=O_L(\epsilon^8\log(1/\epsilon)).
\tag{H38}
\]

Thus most realizations retain their initial assignments during these short formation windows, while the actual recognition-source row changes later on the common $2/\epsilon$ learning horizon. This theorem does not claim that source switching causes those formation episodes or that the episodes occupy a fixed fraction of the learning horizon.

For the old normalization $\Lambda=J_L=1$, this particular global-mixing proof does not close. In (H29), the short-interval term $Hh$ vanishes only if $h=o(\epsilon)$, whereas suppression of the initial-state mixing term requires $h$ to grow at least logarithmically for this bound. The conditions are incompatible. This is a failure of the present estimate and its global relaxation mechanism, not a nonexistence result for the old family or the target contract. A different route could average only a source-relevant fast subsystem together with its coupled loops while retaining a slowly changing environment. It would have to prove its own uniform conditional-history kernels in that drifting environment; that estimate is not supplied here.

Likewise, S13 alone with conditional entropy $O(\epsilon^2)$ supplies only an order-one accumulated generator bound on $2/\epsilon$, and says nothing by itself about conditioning on complete source histories. Matching invariant laws or reusing a regenerated heat bath cannot repair that gap. The proposal-time joint-kernel estimate above is the additional argument that closes it in the accelerated family.

The strongest result of this note is therefore the explicit full-history coupling (H35) for every fixed finite depth with exact S9–S11 parents, unchanged mobilities, fixed positive nonlinear coefficient, full actual-law activation, and (H5)–(H7). The remaining join for the entire frozen contract is to combine this result with the companion proofs of own-law parameter continuation, switching conditional entropy, complete-score error, and formation/continuous-path approximation. Those statements are separate obligations and are not inferred from history coupling. The next materially useful check is reconstruction of their shared regime and activation hypotheses against (H5)–(H7).

No simulation, numerical experiment, test suite, GPU execution, Lean work, or tamper check was run for this artifact. Its evidence is the displayed exact derivation and its explicit asymptotic bounds.
