# Persistence contribution, September 26, 2026

The two integrated modules are `../staged/pifb2/08_section.tex` and `../staged/pifb2/29_section.tex`. Copies are `section_8_revised.tex` and `appendix_b_replacement.tex`. Only these assigned staged modules and this directory were written. The live Research manuscript and wiki were not edited.

## Target, assumptions, and result

The task is to determine what persistence and inertia follow from the manuscript's specified first-order variational dynamics, and to replace Appendix B with checkable mathematics. User-supplied assumptions are local agents over a continuous contextual base, overlapping interactions, matrix-valued selective links, and a wish to minimize new postulates. The derivations here hold at a single base point and do not infer a base metric, physical time, atoms, or electromagnetic dynamics. No base transport is introduced.

Introduced conditional models are: (1) a Gaussian receiver with frozen Gaussian message, prior, and weight; (2) a constant-mobility quadratic gradient system with strictly positive full Hessian, partitioned into retained and hidden coordinates; (3) that system with explicitly supplied independent additive Brownian noises of common strength; (4) a reflected scalar double-well diffusion; and (5) an optional mechanical extension with a supplied positive kinetic tensor or antisymmetric operator. Their state spaces, noise, boundaries, and regularity are stated in the TeX.

Exact results include a positive-cone-invariant precision solution, distinct mean and relative-covariance responses, a complete hidden-coordinate elimination identity, a short-memory error bound, a real-pole scalar second-order representation with its actual forcing map, an exact colored-noise fluctuation/memory relation, a stationary Gaussian non-Markov witness, and an exact mean-exit integral with logarithmic small-noise scaling. The quadratic memory equations are exact globally for that model and only local linearizations of a general smooth VFE system. The noise law and barrier are supplied rather than derived.

The strongest conclusion is that internal first-order coordinates produce genuine retained memory without a kinetic postulate, but symmetric positive-mobility equilibrium gradient dynamics cannot produce underdamped linear poles merely by hiding coordinates. This is not a global no-go theorem for driven, nonreciprocal, antisymmetric, or nonequilibrium agent dynamics. Persistence and intrinsic recursive formation remain separate obligations, consistently with R14.

## Source-first continuity

Read live `Research/manuscripts/PIFB2.tex`, `sec:mass`, `sec:time_info`, `sec:scale_dependent_time`, and Appendix B; live wiki `Belief inertia.md` and `Mass as Fisher information.md`; kinetic passages in `belief_inertia.tex`; `Theory/c08_two_timescales.tex`; the current top of `docs/STATUS.md`; and `docs/derivations/2026-09-11-meta-agent-formation-frontier-and-locality/r14-slow-model-memory.md`.

The July belief-inertia memory entry was used to locate the corrected theorem-first manuscript. All substantive continuity claims above were checked against current live sources. The existing sharp-prior mean-suppression and relative-covariance defect are retained and generalized. The new construction resumes from the existing statement that first-order Fisher dynamics is friction rather than mass.

## Corrections and additions in Section 8

The consensus potential is now denoted `mathcal E`, distinct from normalized `mathcal F_V`. Existing invertible-link Gaussian Hessians are retained as explicitly scoped results. The new selective-link subsection has no inverse of L: covariance is `L Sigma L^T + D`, with positive noise; sender stiffness is `L^T W L`, so discarded directions contribute no sender stiffness through that edge. A full quadratic-form identity proves the mean Hessian is positive for positive prior precisions. The attention-reduction correction is retained with its actual vanishing condition.

The optional kinetic equation now includes the state-dependent metric's connection term. The older version was Euler-Lagrange only for a constant kinetic metric or at linear order about a stationary point. The section retains the unit-frequency degeneracy when kinetic metric and stiffness are identified at the same equilibrium. Its replacement avoids conflating Lie-algebra chart velocity with a trivialized group velocity and avoids declaring a Frobenius frame metric physical.

## Appendix B changes

Removed claims that atoms literally maintain beliefs, that photons are inferred agent channels, that row-normalized attention being near one establishes physical coupling strength, and that selective or independent link products telescope. The replacement explains record stability without asserting physical constituents have been derived.

A new distinction sharpens the old covariance defect: repeated full KL penalties duplicate receiver entropy, yielding `Sigma*=(1+beta)(P+beta W)^-1`. A Gaussian likelihood factor in a normalized prior-likelihood model yields the same optimal mean and `Sigma*=(P+beta W)^-1`. Only the latter has vanishing relative covariance response for sharp `P=delta^-1 I` with bounded message precision. These are explicitly different objectives; no replacement is made silently.

The Fisher clock point is also corrected: mean response can vanish in Fisher norm while covariance speed stays finite. Thus a sharp prior does not alone imply a slow full Fisher clock.

## Primary references verified on September 26

The literature check was bounded to foundational memory elimination and reversible metastability. It is not a systematic literature review. Primary texts were opened, and no external theorem is used as a substitute for the displayed proofs.

1. Robert Zwanzig, *Memory Effects in Irreversible Thermodynamics*, Physical Review 124 (1961), 983-992, DOI 10.1103/PhysRev.124.983. Official full PDF: https://harvest.aps.org/v2/journals/articles/10.1103/PhysRev.124.983/fulltext . It explicitly derives memory terms after projecting microscopic dynamics, and distinguishes short-memory approximations. Its assumptions include constrained equilibrium preparation and undriven evolution. Cited only for the precedent; the finite-dimensional forced calculation is derived in the appendix itself.
2. Hazime Mori, *Transport, Collective Motion, and Brownian Motion*, Progress of Theoretical Physics 33 (1965), 423-455, DOI 10.1143/PTP.33.423. Publisher: https://academic.oup.com/ptp/article-lookup/doi/10.1143/PTP.33.423 . Full primary PDF hosted by UCSD: https://courses.physics.ucsd.edu/2020/Fall/physics210b/Mori-1965.pdf . Provides the generalized Langevin and fluctuation/damping relation precedent; the OU identity here is proved independently.
3. Anton Bovier, Michael Eckhoff, Veronique Gayrard, and Markus Klein, *Metastability in reversible diffusion processes I: Sharp asymptotics for capacities and exit times*, JEMS 6 (2004), 399-424, DOI 10.4171/JEMS/14. Official full PDF: https://ems.press/content/serial-article-files/31525 . Cited for the existence and scope of sharper general reversible-diffusion results. The appendix's one-dimensional logarithmic exit-time result is independently derived, and does not claim those multidimensional hypotheses hold for the agent model.

Root is coordinating downloads and authorized wiki ingestion. `references.bib` contains ready entries under unique keys `Zwanzig1961Memory`, `Mori1965Transport`, and `BovierEtAl2004Metastability`.

## Executed validation

Ran `C:/anaconda/python.exe docs/research/2026-09-26-pifb2-refactor/persistence/check_algebra.py`, using SymPy 1.14.0. Nine exact symbolic checks passed; their names and outcomes are recorded in `symbolic-checks.json`. They check scalar characteristic and response identities, a low-frequency expansion, Gaussian stationary equations and precision dynamics, the non-Markov conditional-covariance defect, the colored-noise covariance, and a rank-deficient matrix sender derivative. They supplement the written proofs and do not certify nonlinear or physical extensions. No numerical simulation, GPU workload, Lean, or tamper check ran. Root performs the staged monograph compile and integration checks.

## Integration follow-up and unresolved obligation

Retained `app:examples`, `sec:rock_derivations`, and most historical response labels for compatibility. The obsolete photon consensus label `eq:rock_consensus` is removed and must not be cited elsewhere. The global status table and notation inventory need their old rock/photon language replaced; root owns those modules. Section 8 uses `mathcal E`; Appendix B uses `mathcal E_KL` for consensus, `mathcal F_V` for the normalized likelihood model, and ordinary F or U for explicitly declared generic potentials.

The minimal unresolved physical obligation is a derived retained position/momentum pair, reversible coupling, force/time calibration, and an appropriate joint response law for an actually formed agent cluster. The next calculation that would materially change the answer is its exact or controlled retained response kernel under a specified perturbation, including poles, forcing map, and colored-noise law. This would discriminate memory-mediated persistence from an additional kinetic structure; no physical mass law has been obtained.
