from pathlib import Path
import json
import sympy as s
out=Path(__file__).parent
checks={}
a,b,c,z,T,t=s.symbols('a b c z T t', positive=True)
H=s.Matrix([[a,b],[b,c]])
checks['two_mode_characteristic']=s.simplify((z*s.eye(2)+H).det()-(z*z+(a+c)*z+a*c-b*b))==0
response=((z*s.eye(2)+H).inv())[0,0]
checks['forced_transfer']=s.simplify(response-(z+c)/((z+a)*(z+c)-b*b))==0
invresponse=z+a-b*b/(z+c)
expected=a-b*b/c+z*(1+b*b/c**2)-z*z*b*b/c**3
checks['inverse_response_second_order']=s.simplify(s.series(invresponse,z,0,3).removeO()-expected)==0
mu,bar,m,P,W,beta,Sigma,eta=s.symbols('mu bar m P W beta Sigma eta',real=True,positive=True)
E=(P*(mu-bar)**2+P*Sigma-s.log(Sigma)+beta*(W*(mu-m)**2+W*Sigma-s.log(Sigma)))/2
A=P+beta*W
mustar=(P*bar+beta*W*m)/A
checks['gaussian_mean_stationary']=s.simplify(s.diff(E,mu).subs(mu,mustar))==0
checks['gaussian_covariance_stationary']=s.simplify(s.diff(E,Sigma).subs(Sigma,(1+beta)/A))==0
checks['precision_ode']=s.simplify(-(-2*eta*Sigma**2*s.diff(E,Sigma))/Sigma**2-eta*(A-(1+beta)/Sigma))==0
C0=T*s.Rational(2,3)
Ct=T*(s.exp(-t)+s.exp(-3*t)/3)/2
C2=T*(s.exp(-2*t)+s.exp(-6*t)/3)/2
checks['stationary_nonmarkov_defect']=s.simplify(C2*C0-Ct**2-T**2*(s.exp(-t)-s.exp(-3*t))**2/12)==0
u=s.symbols('u',real=True,nonnegative=True)
ss=s.symbols('ss',real=True,nonnegative=True)
initial=T*b*b/c*s.exp(-c*(t+ss))
noise=2*T*b*b*s.integrate(s.exp(-c*(t-u))*s.exp(-c*(ss-u)),(u,0,ss))
checks['colored_noise_covariance']=s.simplify(initial+noise-T*b*b/c*s.exp(-c*(t-ss)))==0
r,v,w,e=s.symbols('r v w e',real=True)
L=s.diag(1,0); V=s.Matrix([[r,v],[v,w]])
Q=s.diag(5,7); Cov=s.diag(2,3); D=s.eye(2); d=s.Matrix([2,3]); C=L*Cov*L.T+D; Prec=C.inv()
Ce=L*(Cov+e*V)*L.T+D
edge=(s.log(Ce.det())+s.trace(Ce.inv()*Q)+(d.T*Ce.inv()*d)[0])/2
G=L.T*(Prec-Prec*(Q+d*d.T)*Prec)*L/2
checks['rank_deficient_sender_covariance_derivative']=s.simplify(s.diff(edge,e).subs(e,0)-s.trace(G*V))==0
result={'scope':'Exact symbolic supplement; analytic derivations in TeX supply assumptions and proofs. No simulation, GPU, or tamper checks.','python':'C:/anaconda/python.exe','sympy_version':s.__version__,'checks':checks,'all_checks_pass':all(checks.values())}
(out/'symbolic-checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
