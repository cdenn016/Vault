"""Exact finite-instance checks for the unified-belief research memo; no torch."""
from fractions import Fraction as F
from pathlib import Path
import json
import platform
import re


def matmul(a: list[list[F]], b: list[list[F]]) -> list[list[F]]:
    return [[sum((a[i][k] * b[k][j] for k in range(len(b))), F(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def matvec(a: list[list[F]], v: list[F]) -> list[F]:
    return [sum((x*y for x, y in zip(row, v)), F(0)) for row in a]


def transpose(a: list[list[F]]) -> list[list[F]]:
    return [list(row) for row in zip(*a)]


def main() -> None:
    root = Path(__file__).resolve().parent
    checks: dict[str, bool] = {}
    eps = F(1, 7)
    gen = [[-1-eps, F(1), eps, F(0)], [F(1), -1-eps, F(0), eps],
           [eps, F(0), -1-eps, F(1)], [F(0), eps, F(1), -1-eps]]
    vectors = [[F(x) for x in v] for v in [(1,1,1,1), (1,1,-1,-1),
                                           (1,-1,1,-1), (1,-1,-1,1)]]
    rates = [F(0), -2*eps, F(-2), -2*(1+eps)]
    for i, (v, rate) in enumerate(zip(vectors, rates)):
        checks[f'four_state_eigenvector_{i}'] = matvec(gen, v) == [rate*x for x in v]
    checks['four_state_detailed_balance'] = gen == transpose(gen)
    checks['four_state_lumpability'] = all(sum(gen[i][j] for j in (2,3)) == eps for i in (0,1))
    checks['four_state_generator_rows'] = all(sum(row) == 0 for row in gen)
    alpha = [F(1), F(2), F(3)]
    counts = [F(2), F(3), F(1)]
    prev_total = sum(alpha) + sum(counts)
    prev = [(a+n)/prev_total for a,n in zip(alpha,counts)]
    observed = 0
    nxt = [(a+n+(i == observed))/(prev_total+1) for i,(a,n) in enumerate(zip(alpha,counts))]
    checks['dirichlet_predictive_update'] = all(nxt[i]-prev[i] == (F(i == observed)-prev[i])/(prev_total+1) for i in range(3))
    checks['dirichlet_tv_bound'] = sum(abs(x-y) for x,y in zip(nxt,prev))/2 <= 1/(prev_total+1)
    marginal_target = [F(2,5), F(3,5)]
    conditional_target_at_zero = [F(1,4), F(2,3)]
    weights = [x*y for x,y in zip(marginal_target, conditional_target_at_zero)]
    normalizer = sum(weights)
    checks['conditional_delta_model_optimizer'] = [x/normalizer for x in weights] == [F(1,5), F(4,5)]
    proj = [[F(1,2),F(1,2),F(0)], [F(1,2),F(1,2),F(0)], [F(0),F(0),F(1)]]
    residual = [[F(i == j)-proj[i][j] for j in range(3)] for i in range(3)]
    l3 = [[F(-1),F(1),F(0)], [F(1),F(-3),F(2)], [F(0),F(2),F(-2)]]
    d3 = matmul(matmul(residual,l3),residual)
    b3 = matmul(matmul(proj,l3),residual)
    c3 = matmul(matmul(residual,l3),proj)
    checks['conditional_projection_idempotent'] = matmul(proj,proj) == proj
    checks['residual_rate_three'] = d3 == [[-3*x for x in row] for row in residual]
    checks['memory_adjoint_blocks'] = b3 == transpose(c3)
    checks['nonzero_memory_witness'] = any(x != 0 for row in matmul(b3,c3) for x in row)
    tex = (root / 'unified-subsections.tex').read_text(encoding='utf-8-sig')
    labels = re.findall(r'\\label\{([^}]+)\}', tex)
    checks['tex_unique_local_labels'] = len(labels) == len(set(labels))
    stack: list[str] = []
    balanced = True
    for kind, name in re.findall(r'\\(begin|end)\{([^}]+)\}', tex):
        if kind == 'begin':
            stack.append(name)
        elif not stack or stack.pop() != name:
            balanced = False
            break
    checks['tex_balanced_environments'] = balanced and not stack
    checks['tex_no_manual_spacing_macros'] = not any(token in tex for token in ['\\,', '\\;', '\\!'])
    output = {'scope': 'Exact rational finite examples and local TeX structure only; not a proof of the general propositions.',
              'python': platform.python_version(), 'checks': checks, 'all_passed': all(checks.values())}
    (root / 'exact-check-output.json').write_text(json.dumps(output, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(output, indent=2))
    if not output['all_passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
