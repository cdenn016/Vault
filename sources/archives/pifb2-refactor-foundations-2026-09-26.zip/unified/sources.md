# Primary sources for the unified statistical-bundle revision

Checked September 26, 2026. Source scope is deliberately narrow: whether inference and learning already admit one joint posterior, how slow predictive memory can arise, and whether model structure is supplied or discovered. Mathematical results specific to this memo are proved in `memo.md` and the TeX, not attributed to these papers. The parent agent coordinates download and authorized vault ingestion; this file records the direct primary URLs and exact used portions.

## Sources used in the manuscript text

1. Karl Friston, Thomas FitzGerald, Francesco Rigoli, Philipp Schwartenbeck, John O'Doherty, Giovanni Pezzulo. **Active inference and learning.** Neuroscience & Biobehavioral Reviews 68 (2016), 862–879. DOI: https://doi.org/10.1016/j.neubiorev.2016.06.022 . Open author PDF: https://www.fil.ion.ucl.ac.uk/~karl/Active%20inference%20and%20learning.pdf . Read title page, Section 2 and its state/parameter posterior formulation. Used for the limited claim that state inference and parameter learning are both probabilistic belief updating. The existing `friston2016active` BibTeX entry is missing O'Doherty and should be corrected. No quotation is used. This source does not prove a spontaneous smooth slow model subbundle.

2. Lancelot Da Costa, Thomas Parr, Noor Sajid, Sebastijan Veselic, Victorita Neacsu, Karl Friston. **Active inference on discrete state-spaces: A synthesis.** Journal of Mathematical Psychology 99 (2020), 102447. DOI: https://doi.org/10.1016/j.jmp.2020.102447 . Open primary preprint: https://arxiv.org/abs/2001.07203 ; PDF: https://arxiv.org/pdf/2001.07203 . Read Section 8, especially Eq. (17), and Appendix A.1. Used for explicit parameter learning with posterior factorization and sufficient-statistic accumulation. The exact observed-category Dirichlet calculation in our manuscript is independently derived; hidden-state expected counts are a restricted variational calculation. Note metadata discrepancy: arXiv's journal-reference line says 2021, while UCL's publication listing and the publisher's Volume 99 issue say December 2020. Use the publisher year. Proposed key: `DaCosta2020DiscreteSynthesis`.

3. Karl J. Friston, Lancelot Da Costa, Alexander Tschantz, Alex Kiefer, Tommaso Salvatori, Victorita Neacsu, Magnus Koudahl, Conor Heins, Noor Sajid, Dimitrije Markovic, Thomas Parr, Tim Verbelen, Christopher L. Buckley. **Supervised structure learning.** Biological Psychology 193 (2024), 108891. DOI: https://doi.org/10.1016/j.biopsycho.2024.108891 . Open primary preprint: https://arxiv.org/abs/2311.10300 ; PDF: https://arxiv.org/pdf/2311.10300 . Read Sections 1–3, Eq. (1), and the explicit candidate state/path/factor augmentations on preprint pp. 2–3. Used only for structure selection within supplied candidate families and priors. The paper does not establish that generic VFE produces a unique hierarchy, and its expected-free-energy model priors are not a proof that ordinary VFE alone determines priors. Proposed key: `Friston2024StructureLearning`.

## BibTeX additions for the parent

```bibtex
@article{DaCosta2020DiscreteSynthesis,
  author = {Da Costa, Lancelot and Parr, Thomas and Sajid, Noor and Veselic, Sebastijan and Neacsu, Victorita and Friston, Karl},
  title = {Active inference on discrete state-spaces: A synthesis},
  journal = {Journal of Mathematical Psychology},
  volume = {99},
  pages = {102447},
  year = {2020},
  doi = {10.1016/j.jmp.2020.102447},
  eprint = {2001.07203},
  archivePrefix = {arXiv},
  url = {https://arxiv.org/abs/2001.07203}
}
@article{Friston2024StructureLearning,
  author = {Friston, Karl J. and Da Costa, Lancelot and Tschantz, Alexander and Kiefer, Alex and Salvatori, Tommaso and Neacsu, Victorita and Koudahl, Magnus and Heins, Conor and Sajid, Noor and Markovic, Dimitrije and Parr, Thomas and Verbelen, Tim and Buckley, Christopher L.},
  title = {Supervised structure learning},
  journal = {Biological Psychology},
  volume = {193},
  pages = {108891},
  year = {2024},
  doi = {10.1016/j.biopsycho.2024.108891},
  eprint = {2311.10300},
  archivePrefix = {arXiv},
  url = {https://arxiv.org/abs/2311.10300}
}
```

## Leads routed to the parent's RG investigation, not used as proof here

- Friston et al., **From pixels to planning: scale-free active inference**, arXiv:2407.20292, https://arxiv.org/abs/2407.20292 and https://arxiv.org/pdf/2407.20292 . Abstract/metadata checked only in this subtask.
- Zaghw et al., **Renormalising Generative Models for Active Inference: Foundations, Derivations, and Verification**, arXiv:2608.09512, https://arxiv.org/abs/2608.09512 and https://arxiv.org/pdf/2608.09512 . August 2026 lead, abstract/metadata checked only in this subtask. Sent to parent for the RG arm; no theorem imported.

## Source continuity pointers

Live local sections used: PIFB2 `sec:statistical_manifolds`, associated bundles, `sec:agent_definition`, `sec:free_energy`, `eq:observation_typing_ledger`, `sec:adiabatic_hierarchy`; Theory `c02_geometry.tex`, `c03_probability.tex`, `c04_generative.tex`, `c05_evidence_bound.tex`, `c08_two_timescales.tex`; `docs/STATUS.md`; `docs/derivations/2026-09-11-meta-agent-formation-frontier-and-locality/r14-slow-model-memory.md`. Wiki: `Generative model.md`, `Variational free energy.md`, `Meta-agents and hierarchical emergence.md`.
