# One statistical bundle, conditional models, and derived memory

Research memo for the PIFB2 refactor, September 26, 2026. Scope: the agent fibers at one fixed base point, retaining the ambient smooth principal bundle and local-section types. This memo does not edit the Research vault or the live manuscript. Its companion `unified-subsections.tex` supplies integration text.

## Result and exact target

A single associated statistical bundle can carry the complete joint recognition law of each agent. The existing state and model laws then become marginal or conditional descriptions of that one object. This is an exact reformulation, and it strictly enlarges the old product-family description when state/model correlations are retained. It is not a derivation of a model ontology from beliefs.

There are two constructive, distinct reductions. A posterior over model parameters yields a predictive model whose response to each additional record can become small by evidence accumulation. Alternatively, a single finite state process with a separated kinetic spectrum can carry slow predictive coordinates; eliminating its other coordinates produces an exact memory equation. Neither result says that VFE alone chooses the initial generative law, kinetic operator, spectral gap, or finite predictive dimension. In fact, at a regular exact-posterior optimum, unit Fisher-gradient descent on VFE has linearization minus the identity. Thus local curvature of exact KL, measured in its own Fisher metric, cannot by itself justify different linear fast and slow clocks.

The target supplied by the user is: replace two primitive associated belief/model bundles, if possible, by one bundle; derive slow model or memory behavior from agent interactions and updating; identify coherent origins of priors; retain agents as smooth local sections on overlapping domains over a continuous base. The intended equivalence is equality of the normalized joint law, all declared observation predictions, and the exact VFE, not only equality of marginal means. Where dynamics are reduced, equality of one-time laws and equality of path laws are separate targets.

Introduced hypotheses are explicit below. General laws live on standard Borel fibers. Smooth differential statements use a finite-dimensional, identifiable, dominated statistical family with differentiation justified under the integral, a nondegenerate Fisher metric, and a smooth group action preserving the family. The spectral-memory construction uses a finite irreducible reversible continuous-time Markov process. The accumulation example uses a proper Dirichlet prior and conditionally independent categorical records. These are conditional constructions, not assumptions imposed on the whole monograph.

## Source-first continuity and required changes

The live PIFB2 sections `sec:statistical_manifolds`, associated bundles, `sec:agent_definition`, `sec:free_energy`, `eq:observation_typing_ledger`, and `sec:adiabatic_hierarchy` were read. They currently introduce two primitive Gaussian fibers, already retain the mutual-information correction for a correlated private block, and explicitly classify the population consensus objective as a composite potential. The proposed joint-law presentation extends this existing exact observation identity; it is not a recovered idea presented as new.

The companion Theory already supplies the general ingredients. `c02_geometry.tex` defines measurable law fibers and a separately declared smooth tier. `c03_probability.tex`, `def:prob-model-evaluation`, distinguishes model samples, model laws, and evaluators. `c04_generative.tex` fixes a normalized joint and prohibits generative factors from reading the recognition law being varied. `c05_evidence_bound.tex` derives the support-aware KL chain rule, total correlation, exact conditional updates, and the moving-target boundary. `c08_two_timescales.tex` declares the mobility split, derives conditional reduction, and distinguishes instantaneous refresh from finite-memory evolution.

The current `docs/STATUS.md` and the September 25 `r14-slow-model-memory.md` were also read. The R14 memory is a slow relaxation mode under supplied mobility; its tested effect is persistence or delay, not recursive second-stage formation. The present construction must not overwrite that scoped negative result. The wiki pages `Generative model`, `Variational free energy`, and `Meta-agents and hierarchical emergence` preserve relevant prior work, but the latter's older Gaussian/species-gating definition is superseded in its own current-scope paragraph and by the live Theory.

Recommended replacement: introduce one joint-law section as the primitive agent datum; retain the old two-channel Gaussian formulas as an explicitly factorized specialization. Replace claims that priors necessarily come from a parent by the exact predictive rule below. Treat a parent-supplied prior as a special conditional kernel, whose existence and approximation error need separate derivation. Replace any unqualified assertion that models are slow by one of the two conditional mechanisms proved here, or by an explicit kinetic assumption.

## 1. Geometry and probability are different layers

Let `P_G -> C` be the principal right G-bundle. Let Y be one standard Borel sample fiber with a measurable bijective G-action `rho(g)`, and let B be an invariant family of probability laws on Y. The single associated bundle is

\[
\mathcal E=\mathscr P_G\times_{\widehat\rho}\mathcal B,
\qquad \widehat\rho(g)Q=\rho(g)_\#Q,
\qquad (u g,Q)\sim(u,\widehat\rho(g)Q).
\]

Agent i is a local section `sigma_i: U_i -> E`, represented in its frame by `Q_i(c)`. Interaction links act between fibers over the same c on overlaps. Their being rectangular or rank-deficient does not prevent the gauge action itself from being bijective. The link must act as a typed channel, and KL comparisons must use laws on a common output space. This memo does not add a base connection or transport theory.

For comparison with the old notation, take `Y=K x M` with the product action. A joint law has a regular conditional decomposition

\[
Q_i(dk,dm)=s_i(dm)q_i(dk\mid m),
\qquad q_i^{\rm marg}(dk)=\int q_i(dk\mid m)s_i(dm).
\]

On standard Borel spaces this holds up to s_i-null sets. No independence is asserted. The two old marginal sections are induced bundle maps whenever the marginal projections are equivariant. Conversely, the two marginals do not reconstruct their coupling. For binary variables the laws assigning mass one half to `(0,0),(1,1)` and one half to `(0,1),(1,0)` have the same marginals and opposite dependence. Only after declaring the product family does the pair of marginals determine Q. For Gaussian Y, the off-diagonal state/model covariance is precisely the information discarded by that product restriction.

More intrinsically, one need not begin with K x M. An equivariant statistic `T:Y -> M` gives `s=T_#Q`, and a conditional law of Y given T gives the residual belief. The statistic must be found or declared; calling it a model requires a predictive evaluator, not merely a new letter. A law over m without a map `m -> K_m` into normalized prediction kernels is not a generative model. This is exactly the distinction already made in Theory `def:prob-model-evaluation`.

## 2. Fixed joint, exact conditional VFE, and constrained stationarity

Suppress agent and c labels. Fix standard Borel K, M, O, probability prior r on M, a normalized prior kernel p(dk|m), and a normalized observation kernel with density ell(o|k,m) against a sigma-finite record reference nu_O. At one admitted observation o require

\[
0<Z_o=\int r(dm)p(dk\mid m)\ell(o\mid k,m)<\infty.
\]

The complete joint is

\[
P(dm,dk,do)=r(dm)p(dk\mid m)\ell(o\mid k,m)\nu_O(do).
\]

Every factor is fixed while Q varies. This is normalized by iterated integration. r and p are priors; s is a recognition law over model samples m; P is the full generative law. A likelihood is denoted ell, not p, in the integration text to keep these roles visible.

For `Q(dk,dm)=s(dm)q(dk|m)`, first define the extended free energy without subtracting infinities:

\[
F_o(Q)=-\log Z_o+D_{\rm KL}(Q\Vert P(\cdot\mid o)).
\]

If Q is absolutely continuous with respect to the joint prior P_0 and both `log(dQ/dP_0)` and `log ell(o|.)` are Q-integrable, the defining expectation is

\[
F_o(Q)=\mathbb E_Q\left[\log\frac{dQ}{dP_0}(K,M)-\log\ell(o\mid K,M)\right].
\]

This yields, by conditional Radon--Nikodym factorization,

\[
F_o(Q)=D_{\rm KL}(s\Vert r)
+\int D_{\rm KL}(q(\cdot\mid m)\Vert p(\cdot\mid m))s(dm)
-\int\log\ell(o\mid k,m)q(dk\mid m)s(dm).
\tag{1}
\]

This is an exact conditional factorization. It is not mean field. The KL-only chain identity remains valid in the extended nonnegative reals; the displayed energy split requires the stated integrability so that positive and negative infinite terms are not subtracted.

Let `Z_o(m)=int ell(o|k,m)p(dk|m)`. On the set `0<Z_o(m)<infinity`, define

\[
s^*(dm)=Z_o(m)r(dm)/Z_o,
\qquad q^*(dk\mid m)=\ell(o\mid k,m)p(dk\mid m)/Z_o(m).
\]

Finite-VFE laws cannot charge the zero-evidence subset. Null or exceptional conditional versions do not affect the joint identity. The exact posterior is `s^*(dm)q^*(dk|m)`, and

\[
F_o(Q)+\log Z_o
=D_{\rm KL}(s\Vert s^*)
+\int D_{\rm KL}(q(\cdot\mid m)\Vert q^*(\cdot\mid m))s(dm).
\tag{2}
\]

Proof: write the joint density ratio as the marginal ratio times the conditional ratio, take the Q-expectation, and apply disintegration. Both terms are nonnegative. Thus for every fixed s with finite divergence, unrestricted conditional optimization gives q=q* s-almost everywhere and reduces the objective to `KL(s||s*)-log Z_o`. Unrestricted optimization of s then gives s=s*. This also states the equality conditions.

To check normalization and positivity in the stationarity calculation, use conditional perturbations `q_epsilon=(1+epsilon v_m)q` with bounded v_m of zero q-mean. The derivative is `E_q[v_m log(dq/dq*)]`. Vanishing for all such v_m implies the log ratio is constant q-almost everywhere; an interior minimizer on the target support is therefore q*. Boundary minimizers are covered directly by nonnegativity and the equality case of KL. With q_m held fixed, write `d(m)=KL(q_m||q_m*)`. The minimizing marginal is

\[
s_q(dm)=\frac{e^{-d(m)}s^*(dm)}{\int e^{-d(v)}s^*(dv)}
\tag{3}
\]

provided the denominator is positive; otherwise the whole restricted block has infinite cost. The integrand is at most one, so normalization is finite. Equation (3) follows by rewriting the marginal objective as `KL(s||s_q)-log int exp(-d)ds*`; it is a Gibbs optimizer with unit entropy coefficient, not a claim about finite-time updates.

## 3. Exact accounting of the product restriction

For an independent prior `P_0=p x r` and any correlated Q with marginals q and s,

\[
D_{\rm KL}(Q\Vert p\otimes r)=D_{\rm KL}(q\Vert p)+D_{\rm KL}(s\Vert r)+I_Q(K;M).
\tag{4}
\]

This is already present in PIFB2. Two different approximations must be distinguished. Replacing only `E_Q log Q` by the marginal entropies while retaining the correlated energy expectation drops I_Q and can destroy the evidence bound. Actually replacing Q by `bar Q=q x s` is a legitimate variational restriction, but also changes every coupled expectation. When all terms are finite,

\[
F_o(Q)-F_o(\bar Q)=I_Q(K;M)-\{\mathbb E_Q-\mathbb E_{\bar Q}\}\log P_o(K,M),
\tag{5}
\]

where P_o is the density of the fixed generative slice against a common product reference. Consequently the error is not generally I_Q and has no universal sign for an arbitrary Q. The optimized restricted penalty is exactly

\[
\inf_{q,s}F_o(q\otimes s)+\log Z_o
=\inf_{q,s}D_{\rm KL}(q\otimes s\Vert P(\cdot\mid o)).
\tag{6}
\]

The infimum need not be attained. A correlated recognition family should therefore be the general formulation, with Gaussian block-diagonal covariance introduced only where it is used.

## 4. Priors are inherited by prediction; an initial law remains input

A single normalized temporal law suffices. For fixed normalized transition kernels T_t and record kernels R_t, and proper initial p_0,

\[
P(dy_{0:n},do_{1:n})=p_0(dy_0)\prod_{t=1}^nT_t(dy_t\mid y_{t-1})R_t(do_t\mid y_t).
\tag{7}
\]

All dependence on agent links, overlap data, or declared controls can be conditioned on and included in T_t and R_t. At positive-evidence histories,

\[
p_t^-(dy)=\int T_t(dy\mid y')P(dy'\mid o_{1:t-1}),
\qquad P(dy\mid o_{1:t})\propto\ell_t(o_t\mid y)p_t^-(dy).
\tag{8}
\]

Thus an earlier posterior supplies the next prior by a normalized prediction kernel. For a deterministic channel this is a pushforward; a parent's shadow is one special case. A same-time identity between parent posterior and child prior is not automatically a directed joint. Conditioning or a separately normalized cyclic joint must establish it.

If recognition uses Q_{t-1} in (8), the resulting prior is approximate unless that recognition is exact. The prediction error obeys

\[
D_{\rm KL}(Q_{t-1}T_t\Vert P_{t-1}T_t)\leq D_{\rm KL}(Q_{t-1}\Vert P_{t-1}).
\tag{9}
\]

Proof: the joint input-output laws have initial divergence because both use T_t; disintegrating over their output drops a nonnegative conditional divergence. For two priors mu and nu and a common record kernel R, the sharper expectation identity is

\[
D_{\rm KL}(\mu\Vert\nu)=D_{\rm KL}(\mu R\Vert\nu R)
+\mathbb E_{o\sim\mu R}D_{\rm KL}(\mu(\cdot\mid o)\Vert\nu(\cdot\mid o)).
\tag{10}
\]

It gives an average posterior guarantee under the approximate predictive record law, not a worst-case bound for each observed record. The initial p_0, its hyperprior, or a separately justified stationary law remains a boundary datum. VFE does not determine a unique prior without such assumptions.

## 5. A positive example: predictive memory slows through accumulation

Let `m` be a categorical probability vector in the open d-simplex, `r(dm)=Dir(alpha_1,...,alpha_d)` with every alpha_a>0, and let records K_t|m be independent with mass m_a. Base measure on m is (d-1)-dimensional Lebesgue measure on the simplex; records carry counting measure. The normalized joint density is the Dirichlet density times `prod_t m_{k_t}`. Given observed categories, multiplication gives the exact posterior

\[
s_n=\operatorname{Dir}(\alpha+N_n),
\qquad p^-_{n+1}(a)=\bar m_{n,a}=\frac{\alpha_a+N_{n,a}}{A+n},
\quad A=\sum_a\alpha_a.
\tag{11}
\]

No variational approximation is used. The normalized predictive vector satisfies

\[
\bar m_n-\bar m_{n-1}=\frac{e_{K_n}-\bar m_{n-1}}{A+n},
\qquad \|\bar m_n-\bar m_{n-1}\|_{\rm TV}\leq\frac{1}{A+n}.
\tag{12}
\]

Proof: expand both fractions; categorical TV is half the l1 norm, and `TV(delta_a,mu)<=1`. Current-category beliefs can move by order one between records while the predictive model changes by O(1/n) per record. Slowness of this predictive readout follows from accumulating evidence, not a separately declared epsilon mobility. It is not a claim that the entire Dirichlet law changes by O(1/n) in every statistical metric. It also does not derive the sample space, the evaluator `m -> Cat(m)`, stationarity of the latent parameter, or the proper initial prior.

For hidden categories, the exact parameter posterior is generally a mixture of Dirichlet laws rather than one Dirichlet law with fractional counts. The expected-count update requires a specified factorization or conjugate variational coordinate update. This qualification is needed when importing active-inference formulas.

A fully predictive definition can avoid calling m primitive. For finite observation alphabets, assign to every positive-probability history h the conditional law `S(h)=P(O_future in . | h)`. Histories are predictively equivalent exactly when these continuation laws agree. The update after a record a with positive probability is the conditional tail of S(h), since

\[
S(ha)(B)=\frac{S(h)(\{a\}\times B)}{S(h)(\{a\}\times\mathsf O^{\mathbb N})}.
\tag{13}
\]

Therefore the predictive equivalence class is a closed information state: its next value and future predictions depend only on the current class and the new record. This follows directly by conditioning. It is a derived predictive model carried by one belief state. Its dimension may be infinite and it need not be slow. The finite-dimensional, smooth, gauge-equivariant realization of these predictive classes is a specific remaining obligation, not supplied by renaming a product fiber.

## 6. A local obstruction that prevents a misleading spectral argument

**Proposition.** Let `{Q_theta:theta in U subset R^d}` be a C^2 dominated identifiable family on common support, let theta* be an interior point, and let `Pi=Q_theta*`. Assume first and second derivatives can pass through normalization and the KL integral. Suppose the Fisher matrix `G_ab=E_Q[partial_a log q partial_b log q]` is C^1 and positive definite near theta*. For `F(theta)=KL(Q_theta||Pi)-log Z`,

\[
\nabla F(\theta_*)=0,\qquad \nabla^2F(\theta_*)=G(\theta_*).
\tag{14}
\]

Hence the vector field `V(theta)=-G(theta)^(-1) grad F(theta)` has derivative `DV(theta*)=-I_d`. A common scalar rate eta replaces it by `-eta I_d`.

**Proof.** Since `int partial_a q=0`,

\[
\partial_aF=\int(\partial_aq)\log(q/\pi),
\quad
\partial_b\partial_aF=\int(\partial_{ab}q)\log(q/\pi)
+\int\frac{\partial_aq\partial_bq}{q}.
\]

At q=pi the first term vanishes and the second is G_ab. Differentiating V makes the derivative of G^{-1} multiply the zero gradient, leaving `-G^{-1}G=-I`. Under any smooth invertible coordinate change, the linearization at an equilibrium changes by similarity, so its eigenvalues are unchanged. This is a local statement for a regular exact-posterior family. It does not apply at a misspecified variational optimum, singular/boundary point, nonsmooth attention switch, constrained non-Fisher kinetics, or to parameter-learning directions that change the generative joint.

Consequently, a proposal to infer a slow model sector only from the small Euclidean Hessian eigenvalues of a KL objective is incomplete. The actual generalized eigenproblem is `H v=lambda G v`. At exact posterior its eigenvalues are all one. A Gaussian check makes the issue transparent: if `Q_mu=N(mu,H^{-1})` and `Pi=N(0,H^{-1})`, then `F=mu^T H mu/2`, `G=H`, and `dot mu=-mu`, however ill-conditioned H is.

## 7. One law with exact slow modes and the memory left by projection

Now specify kinetics as part of the model. Let X be finite, let L be an irreducible continuous-time Markov generator with nonnegative off-diagonal entries and zero row sums, and let pi>0 satisfy detailed balance. The normalized path law is determined by pi_0 and `exp(tL)`. For the density `r_t=dQ_t/dpi`, reversibility gives `dot r_t=L r_t` in `L^2(pi)`. The same KL free energy `E_pi[r log r]` decreases because

\[
\frac{d}{dt}D_{\rm KL}(Q_t\Vert\pi)
=-\frac12\sum_{x,y}\pi_xL_{xy}(r_x-r_y)(\log r_x-\log r_y)\leq0.
\tag{15}
\]

This is a kinetic descent law, not the Fisher-gradient flow of Proposition (14).

Let `Pi_c f=E_pi[f|T]` be the orthogonal conditional-expectation projection for a partition statistic T and let `R_c=I-Pi_c`. Write `a=Pi_c r`, `b=R_c r`, and operators on their respective ranges

\[
A=\Pi_cL\Pi_c,\ B=\Pi_cLR_c,\ C=R_cL\Pi_c,\ D=R_cLR_c.
\]

Variation of constants gives the exact projected evolution

\[
\dot a(t)=Aa(t)+Be^{tD}b(0)
+\int_0^tBe^{(t-u)D}Ca(u)du.
\tag{16}
\]

This is a proof by solving `dot b=Ca+Db` and substituting it into `dot a=Aa+Bb`; no limiting or closure approximation is used. The history term and the initial residual are the information discarded by a static coarse state. Because L is self-adjoint, `B=C*`. The partition is strongly lumpable exactly when `C=0`, equivalently the total jump rate from any x in a coarse cell to each other cell is independent of x. In that case B=0 too, and all initial laws have a closed coarse Markov evolution. Necessity follows by applying L to every cell indicator, and sufficiency follows because L preserves their span.

An explicit approximation bound makes the adiabatic obligation concrete. If `D<=-gamma I` on the residual space, gamma>0, then for `M_t=sup_{0<=u<=t}||dot a(u)||`,

\[
\left\|\int_0^tBe^{(t-u)D}Ca(u)du+BD^{-1}Ca(t)\right\|
\leq\|B\|\|C\|\left(\frac{e^{-\gamma t}}{\gamma}\|a(t)\|+\frac{M_t}{\gamma^2}\right).
\tag{17}
\]

The initial residual has norm at most `||B|| exp(-gamma t)||b(0)||`. To prove (17), put v=t-u, replace a(t-v) by a(t), extend the integral to infinity, and bound the omitted tail and the difference by `||e^{vD}||<=exp(-gamma v)` and `||a(t-v)-a(t)||<=v M_t`. The approximate effective operator is `A-BD^{-1}C`. Calling it a probability generator requires a separate positivity check; the bound alone does not supply one.

For spectral coordinates instead, suppose the eigenvalues of -L are `0=lambda_0<=...<=lambda_{N-1}`, and let E_s project onto eigenfunctions 0 through r. Then exactly

\[
\|(I-E_s)r_t\|\leq e^{-\lambda_{r+1}t}\|(I-E_s)r_0\|,
\quad
\|E_sr_t-E_sr_0\|\leq\lambda_r t\|E_sr_0\|.
\tag{18}
\]

The bounds follow by expanding in the orthonormal eigenbasis and using `1-exp(-u)<=u`. A window `lambda_{r+1}^{-1}<<t<<lambda_r^{-1}` gives fast relaxation and persistent slow coordinates. Spectral projection is not generally positivity preserving, so it does not automatically define a statistical-law bundle or a Markov parent. The conditional projection in (16) does preserve positivity, but generally leaves memory. Both tests matter.

A four-state witness is exact. Take X={1,2,3,4}, unit rates on edges 1--2 and 3--4, rates epsilon>0 on 1--3 and 2--4, and no other edges. Uniform pi is invariant. The vectors `(1,1,1,1)`, `(1,1,-1,-1)`, `(1,-1,1,-1)`, `(1,-1,-1,1)` have L-eigenvalues `0,-2epsilon,-2,-2(1+epsilon)`. The cell label T with cells {1,2} and {3,4} is an exact Markov slow variable with flip rate epsilon, while within-cell contrasts decay at rates at least two. Records that read the cell label have a persistent predictive model. This constructs two clocks within one statistical state, but the weak-edge kinetics are supplied; the stationary pi and the KL objective are identical for every epsilon. It therefore also proves that VFE alone cannot choose this clock ratio.

## 8. Literature disposition and minimal remaining obligation

Friston and colleagues already unify state inference and parameter learning as probabilistic belief updating. In the 2016 paper, Section 2 and Eq. (2) assign beliefs to states and model parameters; learning accumulates Dirichlet concentration statistics. Da Costa et al. 2020, Section 8 and Appendix A.1, give the parameter-learning coordinate equations under explicit approximate-posterior factorization. Friston et al. 2023/2024, Sections 1--3, add model-structure selection with specified candidate expansions and priors. These support the present interpretation of a model law as one sector of a joint belief. They do not prove spontaneous discovery of a finite, smooth, slow associated subbundle in this gauge network. Exact source URLs and download instructions are in `sources.md`.

The strongest supported integration is one primitive statistical bundle, exact conditional inference and predictive prior inheritance, with model memory defined operationally by future predictions. Evidence accumulation and separated kinetics are proved examples of slow predictive behavior. The minimal unresolved obligation for the user's stronger emergence target is to exhibit, for the actual interacting link dynamics, an equivariant predictive statistic whose dimension remains controlled, whose retained dynamics close or have a quantified memory residual, and whose slow spectrum follows from that dynamics without a new imposed model mobility. The next materially useful action is to test those three criteria on the existing selective-interface process, starting with the exact projected operator and its conditional-memory term, rather than adding another primitive model bundle or an unproved hierarchy postulate.

## Checks and handoff

All displayed propositions are supported by the derivations above; no general result is inferred from finite tests. No GPU, Lean, tamper checks, heavy producer, or repository-wide test suite ran. `exact_checks.py` and `exact-check-output.json` provide only exact rational checks of the four-state eigenvectors, lumpability, conditional stationarity normalization on a finite example, and the Dirichlet predictive update. They supplement, rather than prove, the general statements. The parent agent owns final independent checking, manuscript integration, bibliography reconciliation, and authorized source ingestion.

