# Lorentz-sector research handoff, September 26, 2026

The exact extension is `SL(2,C) / {+I,-I} = SO+(1,3)` acting on Hermitian two-by-two tensors by congruence, with `GL(2,C)` acting conformally. This is a proved conditional kinematic construction, not a derivation of physical spacetime from VFE. The complete derivation and replacement prose are in `replacement.tex`, also copied to the assigned staged manuscript module `../staged/pifb2/19_section.tex` (relative to the refactor root, `staged/pifb2/19_section.tex`). The latter is the only file edited outside this subdirectory, under the parent's explicit follow-up assignment.

## Target and assumptions

For every smooth complex rank-two vector bundle W over a smooth contextual base C, describe the real rank-four associated Hermitian-tensor bundle H(W), its determinant conformal geometry, and the exact group action. For every declared invertible soldering e:TC -> H(W) on a four-dimensional region, establish that the determinant pullback is Lorentzian, gauge invariant under determinant-preserving frame changes, and conformally covariant under arbitrary complex invertible frame changes. Establish what this says about independent selective links, and locate the missing implication from actual VFE dynamics to physical spacetime.

The user supplies an ambient smooth contextual base, agents as local sections, pointwise attention networks over overlaps, and independent possibly rank-deficient matrix links. The user does not supply a complex rank-two selected channel, determinant scale, nondegenerate collective soldering, physical causal characteristic law, or Lorentz-invariant dynamics. Those are explicitly conditional additions here. The result does not weaken the ultimate emergence target to an internal representation: it solves the representation step and retains the missing emergence implication.

The equivalences proved are an exact group quotient and exact tensor covariance. No path-law, dynamical, or physical equivalence is claimed. The standard spinor correspondence is prior mathematics, not a new discovery of this project.

## Convention table and typed dictionary

| Object | Type and convention |
| --- | --- |
| Base | Smooth paracompact contextual manifold C; dimension is not silently set to four. |
| Principal bundle | Frame bundle P of an introduced complex rank-two vector bundle W; structure group GL(2,C). A chosen complex volume reduces it to SL(2,C). |
| Associated vector bundle | W = P x_rho C^2 with left column-coordinate action z' = g z. |
| Hermitian tensor bundle | H(W) is the real fixed subspace of W tensor conjugate(W) under conjugate flip, not a space of Hermitian endomorphisms defined by a hidden fixed inner product. Coordinates obey X' = g X g^dagger. |
| Cone | H_+(W), the positive semidefinite tensors; positive definiteness is the future timelike interior, rank one the nonzero future null boundary. |
| Moment section | M(c) = E[z z^dagger], a smooth finite-second-moment section where assumed; q remains a normalized classical law. |
| Interface links | L_ij:W_j -> W_i, first index receiver, independent of bundle transitions and not required invertible. L'_ij = g_i L_ij g_j^-1. |
| Transitions | g_ab g_bc = g_ac on triple overlaps. Interaction links do not satisfy this by definition. |
| Lorentz form | eta(X,Y) = (tr(XY)-tr(X)tr(Y))/2, with eta(X,X) = -det X and signature (-+++). |
| Fisher form | Positive definite on identifiable statistical tangents, positive semidefinite after a possibly rank-deficient covariant base pullback; never identified with eta. |
| Scale line | det W tensor conjugate(det W), restricted to its real line, with transition multiplier abs(det g)^2; positive trivialization fixes a metric representative. |
| Soldering | e:TC -> H(W), smooth and pointwise invertible only on a four-dimensional base region; transforms e' = g e g^dagger. |
| Optional connection | D=d+B on W, B'=gBg^-1-dg g^-1; on H(W), D M=dM+BM+MB^dagger. No connection evolution is proposed. |
| Link derivative | nabla L_ij=dL_ij+B_i L_ij-L_ij B_j; transforms g_i(nabla L_ij)g_j^-1. |
| Invertible-link defect | K_ij=(nabla L_ij)L_ij^-1, an End(W_i)-valued one-form. Re tr(K_mu K_nu) is gauge invariant but connection relative and need not be Lorentzian. |
| Indices | mu,nu=0,1,2,3 label Pauli components; a,b=1,2,3 label spatial components. Pauli trace extraction is a coordinate formula, not Lorentz raising/lowering. |
| Trivialization | The explicit flat example uses a declared reference connection B=0. Under c-dependent reframing, e=dM must be replaced by the covariant equation e=D M. |

## Existing work preserved and exact defects corrected

Live `Research/manuscripts/PIFB2.tex`, original lines 1738-1859, already contains the single-generator rank-two obstruction and the commuting, all-real, coordinate-flat four-dimensional construction. These are retained compactly as historical propositions; they are not presented as newly discovered results. The old postulate stack is removed from the main route.

The exact defect is original line 1820 and its reuse in open problem C3: tr[(A_i-A_j)_mu(A_i-A_j)_nu] equals the corresponding ordinary derivative expression for Omega_ij, but it is not invariant under independent c-dependent agent frames. It is invariant under one common right reference change. For Ui=Uj=I2, gi=e^c I2, gj=I2, the alleged invariant changes from zero to 2 dc^2. This counterexample is analytic and included in the finite algebra check.

The corrected invertible-link construction needs declared connections. If L_ij=Ui Uj^-1 and Bi=-dUi Ui^-1, its covariant defect vanishes exactly. Thus adding the correct connection does not rescue geometry carried solely by those removable pure frames. The formula requires an inverse and does not cover singular communication links.

The replacement also corrects the categorical suggestion that complex two-component data require a quantum or complex-valued probability theory. Ordinary probability on C^2 as a real four-dimensional sample space is enough for Hermitian second moments. Its Fisher geometry remains Riemannian. This is not an endorsement of quantum claims.

## Proved constructions and limiting cases

Theorem `thm:lor-hermitian-cover` gives the determinant law, all of SO+(1,3), kernel ±I, local covering proof, and GL(2,C) conformal multiplier. Surjectivity is constructive: map the time axis to a given unit timelike vector using a positive Hermitian square root, then realize the residual spatial rotation with an SU(2) axis-angle matrix. A separate two-line calculation proves that all invariant real quadratic forms in this representation are multiples of det X. No invariant scalar product on the original noncompact defining representation is smuggled in.

The selective-message identity is

`det(sum_r w_r z_r z_r^dagger) = sum_{r<s} w_r w_s abs(z_r1 z_s2-z_r2 z_s1)^2`.

For positive-weight messages the aggregate is timelike exactly when their span is C^2. This gives a precise algebraic bridge from selective contributions to cone geometry. It does not identify the determinant with physical mass. Rank-one link congruence maps all positive inputs into one null ray. The sum of four rank-one channels Phi(X)=tr(X)I/2 sends a null input to a timelike one, so a general communication network does not acquire Lorentz symmetry merely by using such messages.

Minimal cases that invalidate overextended interpretations are explicit. At fixed trace the tangent space is three-dimensional and eta is positive definite there. A constant moment readout produces e=0 and no metric. Positive-definite moment histories can have spacelike derivative: M(t)=diag(e^t,e^-t). A lower-dimensional base has no rank-four soldering. An exact-differential invertible soldering e=dX gives a flat metric. A curved FLRW-form soldering produces the ordinary scalar curvature 6[a''/a+(a'/a)^2], but that curvature is supplied by the declared a(t), not selected by VFE.

## Global conditions

GL(2,C) gives a conformal Lorentz bundle because its determinant is line valued. A positive scale choice produces a representative; an SL(2,C) reduction additionally needs a complex determinant trivialization. If one starts only from Lorentz transition matrices, local spin lifts may multiply to -I on triple overlaps; signs can be repaired globally exactly when their sign cocycle is a coboundary. The replacement states this directly without claiming that a spin bundle or soldering is automatically present.

For dim C > 4, a surjective e gives a Lorentz metric on TC/ker e, with a degenerate base tensor. Turning this vector-bundle quotient into tangent geometry of a four-dimensional observable space requires integrability of ker e and descent of the tensor along its leaves. No quotient theorem is inferred from pointwise rank alone. No base-transport dynamics, connection selection, or causal propagation equation is added to the single-point formation theory.

## Sources consulted before construction

- Live `Research/manuscripts/PIFB2.tex`: original `sec:signature_resolution` through the beginning of `sec:collective_geometry`, including references back to the pullback block and forward to C3-C5.
- Live `Theory/b02_base_direction_geometry.tex`, sections on covariant first jets, exact connection dependence, two-channel geometry, and rank/radical quotients; `Theory/b01_base_geometry.tex`, base-curve and relative-frame conventions.
- `docs/STATUS.md`, current scope and the distinction between general bundle geometry and fixed-point formation.
- Wiki `Emergent spacetime and holography`, `Physics from Fisher information`, and `Dressing field method`. These already distinguish positive Fisher pullbacks, physicalization obligations, and frame-removal issues.
- Memory registry `MEMORY.md:3516-3518` only for source-first continuity and prior evidence-boundary practice; all relevant mathematical statements were checked against live sources. No remembered theorem was used as authority.

## Primary bibliography and downloaded sources

`references.bib` contains three new candidate citation entries. All three papers have been downloaded into this subdirectory's `sources/` folder for the parent's authorized vault ingest. The standalone validation bibliography additionally copies the exact existing Dennis Supplement B entry; do not append that duplicate to the manuscript bibliography.

1. Han, Kim, Noz, *Stokes Parameters as a Minkowskian Four-vector* (1997), Physical Review E 56, 6065-6076, DOI 10.1103/PhysRevE.56.6065. Verified arXiv metadata and primary PDF. Sections II-IV give classical coherency matrices and their boost/rotation action. Download: https://arxiv.org/pdf/physics/9707016 . Metadata: https://arxiv.org/abs/physics/9707016 . This supports a classical matrix realization, not emergence of spacetime.
2. Simon, Chaturvedi, Srinivasan, Mukunda, *Hamilton's Turns for the Lorentz Group* (2006), DOI 10.1007/s10773-006-9171-7. Verified arXiv metadata and primary PDF. Section III, equations (3.4)-(3.7), gives Hermitian congruence and the double cover; Section V discusses polar decomposition. Download: https://arxiv.org/pdf/quant-ph/0601060 . Metadata: https://arxiv.org/abs/quant-ph/0601060 . Caution: its sign-of-trace statement adjacent to equation (3.5) requires the causal domain; our proof uses positive-definite X only and makes no such claim for spacelike X.
3. Verstraete, Dehaene, De Moor, *Local filtering operations on two qubits* (2001), Physical Review A 64, 010101(R), DOI 10.1103/PhysRevA.64.010101. Verified publisher/arXiv metadata and primary PDF. Theorem 2 gives Lorentz action up to normalization under local filtering. Download: https://arxiv.org/pdf/quant-ph/0011111 . Metadata: https://arxiv.org/abs/quant-ph/0011111 . This is cited as a related use of the same representation; none of its entanglement conclusions is imported into the classical agent model.

## Executed validation

`check_algebra.py` ran under `C:/anaconda/python.exe`, Python 3.12.7, SymPy 1.14.0. All 14 named exact-algebra checks are true in `symbolic-checks.json`. They include the fully symbolic eight-real-parameter complex 2x2 determinant identity, the Pauli Gram form, boost metric invariance, a composition example, three-message determinant expansion, rank-one collapse, normalized-tangent positivity, the independent-frame counterexample, vanishing pure-frame covariant defect, a cone-preserving channel that changes nullity, and direct Levi-Civita scalar-curvature computation. These finite symbolic calculations are supporting checks; the general proofs are in `replacement.tex`.

The isolated section compiled using the installed TeX Live 2025 through the `latex-compile` skill into `build/section-validation.pdf` (7 pages). The final log has no undefined citations/references, LaTeX warnings, errors, or overfull boxes. It has one underfull hbox in the long theorem statement. The theorem page and the gauge-correction page were rendered and visually inspected; equations fit the page. Direct `view_image` failed with the known sandbox ACL startup error, so the rendered JPEG bytes were emitted through the working escalated read path instead. No full manuscript build, GPU work, Lean, heavy experiment, tamper check, or vault edit was performed by this worker.

## Integration changes for the parent

Keep labels `sec:signature_resolution`, `sec:worked_signature`, `sec:causal_cone_route`, `prop:rank_obstruction`, and `prop:4d_signature`. The causal-route label now marks the concluding conditional physicalization subsection; if a more literal target is desired, move it to the finite-speed paragraph.

Retired labels from the replaced section are `post:noncompact`, `post:pairing`, `post:imaginary`, `post:realpart`, `post:collapse`, `post:traceorth`, `prop:conditional_signature`, `eq:complex_gauge_frame`, `eq:lorentzian_metric`, `eq:tangent_decomp`, and `eq:lor_belief_metric`. The independent abstract claim register and other chapters should be rewritten, not given alias labels that pretend their old claims survive.

Update the following original manuscript locations in the parent's other modules:

- Original line 1715: replace the old frame-cone slope critique by the missing physical scale and missing causal dynamics of the conditional determinant construction.
- Original line 1872: remove the claim that every signature construction now lives in the removable frame-twist block. Orbit averaging is not needed for the Hermitian determinant form; local determinant scaling is handled by the explicit conformal weight.
- Original line 1892: P4/P5 references and a compulsory two-dimensional working base are stale under the user's continuous-base intent and the new conditional rank-four soldering.
- Original line 1954: the cognitive-frame paragraph should retain the absence of a derived propagation principle but no longer describe the replacement merely as the old postulated frame-twist signature.
- Original C3-C4, lines 1995-1996: replace the commuting-generator selection task and false ordinary pair-derivative invariant by covariant channel selection, collective soldering/rank/descent, and characteristic-cone compatibility. Existing matrix attention links alone solve none of those steps.
- Original C5, line 1997: do not imply that classical complex random messages require a quantum extension. The Hermitian moment construction is classical; quantum density operators remain a separate program.
- Update P4/P5 in the global assumption register and the claim-status table. The theorem is conditional algebra, while physical spacetime remains unproved.

## Strongest result and next obligation

The replacement gives a full analytic construction of SO+(1,3), its exact connection to complex two-component classical moments and selective messages, and corrected passive-gauge tensor laws. It proves no VFE mechanism choosing that representation, no causal propagation law, and no physical spacetime emergence. The minimal next obligation that materially changes the answer is one explicit normalized VFE model whose dynamics covariantly select the rank-two complex statistic and a rank-four collective readout, with principal propagation characteristics matching its determinant cone. A generic search for more Lorentz analogies would not close that obligation.
