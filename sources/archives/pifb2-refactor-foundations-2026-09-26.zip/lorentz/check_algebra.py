"""Exact finite algebra checks accompanying an analytic Lorentz construction."""
from pathlib import Path
import json
import platform
import sys
import sympy as s

root = Path(__file__).resolve().parent
I = s.I
pauli = [s.eye(2), s.Matrix([[0, 1], [1, 0]]), s.Matrix([[0, -I], [I, 0]]), s.diag(1, -1)]
x = s.symbols('x0:4', real=True)
y = s.symbols('y0:4', real=True)
X = sum((x[a]*pauli[a] for a in range(4)), s.zeros(2))
Y = sum((y[a]*pauli[a] for a in range(4)), s.zeros(2))
eta = s.diag(-1, 1, 1, 1)
def bilinear(U: s.Matrix, V: s.Matrix) -> s.Expr:
    return s.expand((s.trace(U*V)-s.trace(U)*s.trace(V))/2)
def four(M: s.Matrix) -> s.Matrix:
    return s.Matrix([s.simplify(s.trace(P*M)/2) for P in pauli])
def image(A: s.Matrix) -> s.Matrix:
    return s.Matrix.hstack(*[four(A*P*A.conjugate().T) for P in pauli])
checks = {}
checks['determinant_polynomial'] = s.expand(X.det() - x[0]**2 + sum(z*z for z in x[1:])) == 0
checks['polarization_gram'] = s.Matrix(4,4,lambda a,b: bilinear(pauli[a],pauli[b])) == eta
# General GL(2,C), eight independent real coefficients, exact expansion.
a = s.symbols('a0:8', real=True)
A = s.Matrix([[a[0]+I*a[1],a[2]+I*a[3]],[a[4]+I*a[5],a[6]+I*a[7]]])
checks['general_complex_congruence_determinant'] = s.expand((A*X*A.conjugate().T).det()-A.det()*s.conjugate(A.det())*X.det()) == 0
r = s.symbols('r', positive=True)
boost = image(s.diag(r,1/r))
checks['boost_metric_invariance'] = s.simplify(boost.T*eta*boost-eta) == s.zeros(4)
# Exact noncommuting complex example; determinant one.
A0=s.Matrix([[1,I],[0,1]])
B0=s.Matrix([[1,0],[1,1]])
checks['representation_composition'] = image(A0*B0)==image(A0)*image(B0)
checks['minus_identity_kernel'] = image(-s.eye(2))==s.eye(4)
# Cauchy-Binet determinant for three complex rank-one messages.
b=s.symbols('b0:12',real=True)
Z=s.Matrix([[b[0]+I*b[1],b[4]+I*b[5],b[8]+I*b[9]],[b[2]+I*b[3],b[6]+I*b[7],b[10]+I*b[11]]])
minor_sum=sum(Z[:,[j,k]].det()*s.conjugate(Z[:,[j,k]].det()) for j in range(3) for k in range(j+1,3))
checks['three_message_determinant_identity']=s.expand((Z*Z.conjugate().T).det()-minor_sum)==0
projector=s.diag(1,0)
checks['rank_one_congruence_image_rank']=image(projector).rank()==1
checks['rank_one_congruence_null']=s.expand((projector*X*projector).det())==0
checks['trace_normalized_tangent_positive']=bilinear(sum((x[a]*pauli[a] for a in range(1,4)),s.zeros(2)),sum((x[a]*pauli[a] for a in range(1,4)),s.zeros(2)))==sum(z*z for z in x[1:])
t=s.symbols('t',real=True)
Ui=s.exp(t)*s.eye(2)
Ai=Ui.inv()*Ui.diff(t)
checks['independent_frame_trace_counterexample']=s.trace(Ai*Ai)==2
Bi=-Ui.diff(t)*Ui.inv()
checks['pure_frame_covariant_defect_vanishes']=s.simplify(Ui.diff(t)+Bi*Ui)==s.zeros(2)
null_state=s.diag(1,0)
checks['positive_map_can_move_null_to_timelike']=(s.trace(null_state)*s.eye(2)/2).det()==s.Rational(1,4)
# Curved soldering example: compute the Levi-Civita curvature directly.
coords=s.symbols('t x y z',real=True)
t0=coords[0]
af=s.Function('a')(t0)
g=s.diag(-1,af**2,af**2,af**2)
ginv=g.inv()
Gamma=[[[s.simplify(sum(ginv[k,l]*(s.diff(g[l,j],coords[i])+s.diff(g[l,i],coords[j])-s.diff(g[i,j],coords[l])) for l in range(4))/2) for j in range(4)] for i in range(4)] for k in range(4)]
Ric=s.Matrix(4,4,lambda b,d:s.simplify(sum(s.diff(Gamma[k][d][b],coords[k])-s.diff(Gamma[k][k][b],coords[d])+sum(Gamma[k][k][l]*Gamma[l][d][b]-Gamma[k][d][l]*Gamma[l][k][b] for l in range(4)) for k in range(4))))
scalar=s.simplify(sum(ginv[b,d]*Ric[b,d] for b in range(4) for d in range(4)))
checks['curved_soldering_scalar_curvature']=s.simplify(scalar-6*(s.diff(af,t0,2)/af+(s.diff(af,t0)/af)**2))==0
output={'python':sys.executable,'python_version':platform.python_version(),'sympy_version':s.__version__,'checks':checks,'all_passed':all(checks.values()),'boost_matrix':str(boost),'scope':'Exact symbolic identities and explicit finite counterexamples only. The analytic proof supplies the general claims.'}
(root/'symbolic-checks.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
print(json.dumps(output,indent=2))
assert output['all_passed']

