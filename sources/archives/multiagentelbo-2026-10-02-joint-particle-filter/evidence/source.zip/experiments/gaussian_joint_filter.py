"""Replay joint retained observations through a source-aware particle filter."""
from __future__ import annotations
import os
from pathlib import Path
import subprocess
import sys

RUN={"input_root":"artifacts/gaussian-joint-parent/20261002T161127396348Z",
     "n_paths":128,"batch_size":8,"particle_seed":20261012}
THEORY={"n_agents":[512,1024],"block":16,"particles":[16,64],"reset_particles":64}
NUMERICS={"device":"cpu","dtype":"float64","cpu_threads":1}
OUTPUT={"root":str(Path(__file__).resolve().parents[1]/"artifacts/gaussian-joint-filter")}


def main() -> int:
    """Select isolated sequential-MKL CPU execution before importing torch."""
    sequential=os.environ.get("MKL_THREADING_LAYER")=="SEQUENTIAL"
    os.environ["MKL_THREADING_LAYER"]="SEQUENTIAL"
    for key in ("OMP_NUM_THREADS","MKL_NUM_THREADS"):
        os.environ[key]=str(NUMERICS["cpu_threads"])
    interpreter=Path(os.environ.get("CUDA_PYTHON","C:/anaconda/python.exe"))
    same=os.path.normcase(str(Path(sys.executable).resolve()))==os.path.normcase(str(interpreter.resolve()))
    if not same or not sys.flags.isolated or not sequential:
        return subprocess.run([str(interpreter),"-I","-B",str(Path(__file__).resolve())],
                              env=os.environ.copy(),check=False).returncode
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
    from multiagent_elbo.realizations.gaussian.joint_filter_experiment import run_joint_filter_study
    run_joint_filter_study(RUN,THEORY,NUMERICS,OUTPUT)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
